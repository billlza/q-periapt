from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;folder=root/'research/sdk-alpha1/evidence/20261018-native-mac-2328';folder.mkdir()
def sha(data):return hashlib.sha256(data).hexdigest()
r=json.loads((out/'READBACK.json').read_text());entries={}
for name in ['ARTIFACT.json','JOB.json','public-vectors.zip','terminal-job.log','TEST_RESULTS.json','READBACK.json','download.py','download.stdout','download.stderr','read-terminal-log.py','read-terminal-log.stdout','read-terminal-log.stderr','replay-public.stdout','replay-public.stderr','replay-anchor.stdout','replay-anchor.stderr','review.py','review.stdout','review.stderr','seal.py']:
 entries[name]=(out/name).read_bytes()
for stem in ['read-terminal-log','replay-public','replay-anchor','review']:assert not entries[stem+'.stderr']
for name,expected in r['source_files'].items():
 data=subprocess.check_output(['git','show',r['head']+':'+name]);assert sha(data)==expected;entries['source/'+name]=data
for directory in ['replay-public','replay-anchor']:
 for p in sorted((out/directory).rglob('*')):
  if p.is_file():
   assert not p.is_symlink();entries[directory+'/'+str(p.relative_to(out/directory))]=p.read_bytes()
entries['DIAGNOSTIC_LIMITS.json']=(json.dumps({'download':'Artifact digest/inventory validation and extraction succeeded. Ancillary terminal-log request then failed because gh refused printing ANSI escapes. read-terminal-log.py independently rechecks terminal success and captures the raw bytes directly to a file with the documented flag; displayed test summaries have escapes removed. Original failed command and diagnostic preserved.','producer_boundary':r['scope']},indent=2)+'\n').encode()
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
a=folder/'CAPTURE.zip'
with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):
  i=zipfile.ZipInfo(n,(2026,10,18,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
with zipfile.ZipFile(a) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(entries) and z.testzip() is None
 for n,v in manifest.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
result={'readback':r,'capture':{'bytes':a.stat().st_size,'members':len(entries),'sha256':sha(a.read_bytes())}}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
