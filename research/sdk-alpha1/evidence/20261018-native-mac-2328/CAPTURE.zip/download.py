from pathlib import Path,PurePosixPath
import hashlib,json,stat,subprocess,zipfile
out=Path(__file__).resolve().parent;head='23280124efd2f0f3003d4ce85e3db665f6ec8a25'
def api(path):return subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+path],timeout=60)
job=json.loads(api('actions/jobs/117680781073'));assert job['status']=='completed' and job['conclusion']=='success' and job['head_sha']==head and job['run_id']==39129232908
artifact=json.loads(api('actions/artifacts/12146575765'));assert artifact['workflow_run']['head_sha']==head and not artifact['expired'] and artifact['size_in_bytes']<4*1024**2
(out/'JOB.json').write_text(json.dumps(job,indent=2)+'\n');(out/'ARTIFACT.json').write_text(json.dumps(artifact,indent=2)+'\n')
blob=api('actions/artifacts/12146575765/zip');assert len(blob)==artifact['size_in_bytes'] and 'sha256:'+hashlib.sha256(blob).hexdigest()==artifact['digest']
(out/'public-vectors.zip').write_bytes(blob);folder=out/'public';folder.mkdir()
with zipfile.ZipFile(out/'public-vectors.zip') as z:
 items=z.infolist();assert len(items)==len({i.filename for i in items})<5000 and sum(i.file_size for i in items)<64*1024**2
 for i in items:
  n=PurePosixPath(i.filename);assert not i.is_dir() and not n.is_absolute() and '..' not in n.parts and str(n)==i.filename and '\\' not in i.filename and not i.flag_bits&1 and not stat.S_ISLNK(i.external_attr>>16)
  data=z.read(i);p=folder.joinpath(*n.parts);p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(data)
 print(json.dumps({'artifact_bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'members':len(items),'top_level':sorted({PurePosixPath(i.filename).parts[0] for i in items})}))
# Terminal-only log acquisition: the completed success check above is mandatory.
(out/'terminal-job.log').write_bytes(api('actions/jobs/117680781073/logs'))
