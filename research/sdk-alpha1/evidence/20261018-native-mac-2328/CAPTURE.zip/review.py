"""Reconcile terminal hosted native tests with independently replayed public bytes."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;public=out/'public';head='23280124efd2f0f3003d4ce85e3db665f6ec8a25'
sys.path.insert(0,str(root/'artifact'))
from evidence_io import parse_strict_json_bytes as parse
from continuity_contract import compare

def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return parse(path.read_bytes(),label=str(path))
def check(value,why):
 if not value:raise ValueError(why)
job=read(out/'JOB.json');a=read(out/'ARTIFACT.json');raw=(out/'public-vectors.zip').read_bytes()
check(job['head_sha']==a['workflow_run']['head_sha']==head and job['status']=='completed' and job['conclusion']=='success','terminal source')
check(a['size_in_bytes']==len(raw)==1936823 and 'sha256:'+sha(raw)==a['digest'],'downloaded artifact')
for stem in ['read-terminal-log','replay-public','replay-anchor']:check(not (out/(stem+'.stderr')).read_bytes(),'verification diagnostics')
log=read(out/'TEST_RESULTS.json');check(sha((out/'terminal-job.log').read_bytes())==log['log_sha256'],'terminal log hash')
counts=[]
for line in log['results']:
 match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',line)
 check(match is not None,'test disposition');counts.append(int(match[1]))
check(counts==[1037,4,2,4,3,17]*2+[27,4]*2,'exact debug/release test sequence')
comparisons={}
for label,hosted,ignored in [('public','continuity-public-verification',{'openssl','commands'}),('anchor','continuity-anchor-verification',{'openssl_commands'})]:
 remote=read(public/hosted/'result.json');local=read(out/('replay-'+label)/'result.json')
 check({k:v for k,v in remote.items() if k not in ignored}=={k:v for k,v in local.items() if k not in ignored},'public semantic equality '+label)
 hashes=local['fixture_sha256' if label=='public' else 'inputs_sha256']
 for name,value in hashes.items():
  p=Path(name);check(not p.is_absolute() and '..' not in p.parts,'fixture path')
  check(sha((public/'continuity-public-vectors'/p).read_bytes())==value,'public fixture hash')
 comparisons[label]={'matching_fields':sorted(set(local)-ignored),'input_files':len(hashes),'signed_envelopes':local['signed_envelopes']}
check(comparisons['public']['signed_envelopes']==20 and comparisons['anchor']['signed_envelopes']==57,'signature counts')
contract=read(public/'continuity-wire-contract/CONTRACT.json');budgets=subprocess.check_output(['git','show',head+':docs/continuity/BUDGETS_V1.json'])
check(contract['completed'] and contract['returncode']==0 and contract['release_claim_eligible'] is False and 'failure' not in contract,'candidate contract receipt')
check(sha(budgets)==contract['budgets_sha256'] and not (public/'continuity-wire-contract/consumer.stderr').read_bytes(),'budget identity/diagnostics')
compiled=parse((public/'continuity-wire-contract/consumer.stdout').read_bytes(),label='hosted compiled contract')
check(compare(parse(budgets,label='committed budgets'),compiled)==contract['contract'],'compiled/public budget equality')
bundle=read(public/'continuity-bootstrap-bundle-verification/report.json');folder=public/'continuity-bootstrap-bundle-verification'
check(bundle['positive']==1 and bundle['negatives']==25 and len(bundle['cases'])==26 and bundle['fixture_trust_supplied_separately'] and bundle['production_binding_qualified'] is False,'bundle boundary')
seen=set()
for row in bundle['cases']:
 name=row['name'];check(re.fullmatch(r'[A-Za-z0-9_-]{1,60}',name) and name not in seen,'bundle case');seen.add(name)
 check(sha((folder/(name+'.bin')).read_bytes())==row['sha256'],'actual bundle bytes')
 stdout=(folder/(name+'.stdout')).read_bytes();stderr=(folder/(name+'.stderr')).read_bytes()
 if row['accepted']:check(name=='valid' and row['exit']==0 and not stderr and stdout.decode().strip()==bundle['context_digest'],'accepted exact context')
 else:check(row['exit']==1 and not stdout and stderr.startswith(b'Error:'),'rejected bundle without output')
source_paths=['research/continuity-identity-candidate/scripts/verify_public_vectors.py','research/continuity-identity-candidate/scripts/verify_anchor_vectors.py','research/continuity-identity-candidate/scripts/exercise_bootstrap_bundle.py','artifact/python-run.sh','artifact/python_bootstrap.py','artifact/bounded_process.py','artifact/prekey_selection.py','artifact/evidence_io.py','artifact/continuity_contract.py','docs/continuity/BUDGETS_V1.json','.github/workflows/ci.yml']
sources={}
for name in source_paths:
 data=subprocess.check_output(['git','show',head+':'+name]);check((root/name).read_bytes()==data,'current executed reader differs from tested Git source '+name);sources[name]=sha(data)
record={'head':head,'run':39129232908,'job':job['id'],'job_conclusion':'success','artifact_id':a['id'],'artifact_bytes':len(raw),'artifact_sha256':sha(raw),'artifact_members':1939,'terminal_log':log,'source_files':sources,'public_replays':comparisons,'bootstrap_bundle':{'accepted':1,'refused':25,'native_execution':'producer observations, public input/output hashes checked locally'},'contract_matches_reviewed_budget':True,'scope':'Terminal AppleSilicon native candidate and sealed-SDK producer tests, plus new independent OpenSSL replay of that downloaded artifact. No native executable supplied in this artifact; compiler/runtime execution and binary hashes remain producer receipts. Not complete installed-consumer workflow, physical-device/power-loss, construction-wide security or final release admission.'}
(out/'READBACK.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('source_files','terminal_log')}))
