from pathlib import Path
import json,subprocess,re,hashlib
out=Path(__file__).resolve().parent;endpoint='repos/billlza/q-periapt/actions/jobs/117680781073'
j=json.loads(subprocess.check_output(['gh','api',endpoint],timeout=60));assert j['status']=='completed' and j['conclusion']=='success' and j['head_sha']=='23280124efd2f0f3003d4ce85e3db665f6ec8a25'
data=subprocess.check_output(['gh','api','--allow-escape-sequences',endpoint+'/logs'],timeout=60);assert len(data)<16*1024**2
(out/'terminal-job.log').write_bytes(data)
clean=re.sub(rb'\x1b\[[0-?]*[ -/]*[@-~]',b'',data).decode('utf-8');assert '\x1b' not in clean
results=[line for line in clean.splitlines() if 'test result:' in line]
(out/'TEST_RESULTS.json').write_text(json.dumps({'log_bytes':len(data),'log_sha256':hashlib.sha256(data).hexdigest(),'terminal_job':j['id'],'results':results},indent=2)+'\n')
print(json.dumps({'log_bytes':len(data),'test_results':results}))
