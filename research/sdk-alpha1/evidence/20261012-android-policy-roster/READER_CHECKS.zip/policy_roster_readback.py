from pathlib import Path, PurePosixPath
import hashlib
import json
import tempfile
import zipfile
import continuity_android_roster as local
import continuity_android_policy_renewal as policy
import continuity_android_roster_witness as witness

root = Path.cwd()
evidence = root / 'research/sdk-alpha1/evidence/20261012-android-policy-roster'
archive = evidence / 'CAPTURE.zip'
checks = json.loads((evidence / 'PROTOTYPE_CHECKS.json').read_text())
supplement = json.loads((evidence / 'SUPPLEMENT_CHECKS.json').read_text())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest == checks['capture_sha256']
outcomes = {}
verified_members = 0
extracted = set()
with tempfile.TemporaryDirectory(prefix='qperiapt-policy-roster-readback-') as temporary:
    base = Path(temporary)
    for selected, expected_digest in ((archive, digest), (evidence / 'PUBLIC_INPUT_SUPPLEMENT.zip', supplement['supplement_sha256'])):
      assert hashlib.sha256(selected.read_bytes()).hexdigest() == expected_digest
      with zipfile.ZipFile(selected) as bundle:
        names = bundle.namelist()
        manifest = json.loads(bundle.read('MANIFEST.json'))
        assert len(names) == len(set(names))
        if selected == archive: assert len(names) == checks['members']
        assert set(manifest) == set(names) - {'MANIFEST.json'}
        verified_members += len(manifest)
        for name, expected in manifest.items():
            data = bundle.read(name)
            assert hashlib.sha256(data).hexdigest() == expected, name
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            if relative.parts[0] not in {'host', 'art'}:
                continue
            assert name not in extracted, name
            extracted.add(name)
            lane, route, *parts = relative.parts
            _, carrier, profile, terminal = route.split('_')
            target = base / lane / route / (carrier + '-' + profile)
            target = target.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    for lane in ('host', 'art'):
        outcomes[lane] = {}
        for route in sorted((base / lane).iterdir()):
            _, carrier, profile, terminal = route.name.split('_')
            case = route / (carrier + '-' + profile)
            record = policy.verify_route(route, profile, carrier, with_roster=True)
            witness.verify_records(case, terminal == 'closed', selected=True)
            local.check_processes(case, profile, witness.steps(terminal == 'closed', True))
            assert (case / 'execution.stderr').read_bytes() == b''
            outcomes[lane][route.name] = dict(record, terminal=terminal)
    assert len(outcomes['host']) == 8 and len(outcomes['art']) == 2
    assert sum(x['foreign_processes'] for x in outcomes['host'].values()) == 544
    assert sum(x['foreign_processes'] for x in outcomes['art'].values()) == 136
result = dict(completed=True, capture_sha256=digest, supplement_sha256=supplement['supplement_sha256'],
              manifest_members_verified=verified_members,
              outcomes=outcomes, reader_sha256={name:hashlib.sha256((root/'artifact'/name).read_bytes()).hexdigest()
              for name in ('continuity_android_policy_renewal.py','continuity_android_roster_witness.py','continuity_android_roster.py')},
              scope='Current readers verify retained prototype records only; this is not a fresh integrated runtime run.',
              physical_device_scope='The existing accepted phone suffices; no additional device is required.')
(evidence / 'ARCHIVE_READBACK.json').write_text(json.dumps(result, indent=2) + '\n')
print('Archived policy/roster composition readback passed: 8 host routes (544 calls), 2 ART routes (136 calls).')
