from pathlib import Path
import hashlib
import json
import zipfile
import continuity_android_policy_roster as policy

root = Path.cwd()
evidence = root / 'research/sdk-alpha1/evidence/20261012-android-policy-roster'
archive = evidence / 'CAPTURE.zip'
checks = json.loads((evidence / 'PROTOTYPE_CHECKS.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == checks['capture_sha256']
members = {}; comparisons = {}
with zipfile.ZipFile(archive) as bundle:
    names = set(bundle.namelist())
    routes = sorted({tuple(name.split('/')[:2]) for name in names if name.startswith(('host/', 'art/'))})
    for lane, route in routes:
        _, carrier, profile, terminal = route.split('_')
        source = (root / 'target/continuity-android-roster-next' / ('policy-' + route) / 'cases'
                  if lane == 'host' else root / 'target/continuity-android-policy-roster-device' / ('cases-' + route))
        source /= carrier + '-' + profile
        existing = {}; recovered = {}
        for name in policy.public(carrier, terminal):
            member = lane + '/' + route + '/' + name
            data = (source / name).read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            if member in names:
                assert data == bundle.read(member), member
                existing[name] = digest
            else:
                members[member] = data
                recovered[name] = digest
        comparisons[lane + '/' + route] = dict(source=str(source), unchanged_archived_public_inputs=existing,
                                               recovered_original_public_inputs=recovered)
assert len(routes) == 10 and members
manifest = {name:hashlib.sha256(value).hexdigest() for name,value in members.items()}
with zipfile.ZipFile(evidence / 'PUBLIC_INPUT_SUPPLEMENT.zip', 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, value in sorted(members.items()): bundle.writestr(name, value)
    bundle.writestr('MANIFEST.json', json.dumps(manifest, sort_keys=True, indent=2)+'\n')
supplement = evidence / 'PUBLIC_INPUT_SUPPLEMENT.zip'
result = dict(completed=True, original_archive_sha256=checks['capture_sha256'],
              supplement_sha256=hashlib.sha256(supplement.read_bytes()).hexdigest(),
              recovered_public_files=len(members), comparisons=comparisons,
              trigger='Current full policy reader rejected the unchanged archive because inputs/renewal-operation was omitted.',
              scope='Only missing allowlisted public inputs copied from the original retained completed cases after byte-for-byte comparison of every overlapping public file. No derived replacement inputs and no changes to the original capture.')
(evidence / 'SUPPLEMENT_CHECKS.json').write_text(json.dumps(result, indent=2)+'\n')
print('Recovered original public fields:', len(members), 'across', len(routes), 'routes; original capture unchanged.')
