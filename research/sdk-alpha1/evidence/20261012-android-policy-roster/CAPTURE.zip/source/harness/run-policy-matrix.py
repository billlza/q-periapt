from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import json,subprocess,os
root=Path.cwd();out=root/'target/continuity-android-roster-next'
names=['roster_'+c+'_'+p+'_'+t for c in ['signed','tls'] for p in ['fixed','recoverable'] for t in ['applied','closed'] if (c,p,t) not in [('signed','fixed','applied'),('tls','recoverable','closed')]]
def run(name):
 env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14')
 result=subprocess.run(['/bin/sh','artifact/python-run.sh','target/continuity-android-roster-next/run-policy-roster.py',name],cwd=root,env=env,capture_output=True,text=True,timeout=880)
 (out/('batch-'+name+'.stdout')).write_text(result.stdout);(out/('batch-'+name+'.stderr')).write_text(result.stderr)
 if result.returncode!=0:raise RuntimeError(name+' failed; see batch stderr')
 print(result.stdout.strip(),flush=True)
 return name
with ThreadPoolExecutor(max_workers=2) as executor:
 futures=[executor.submit(run,name) for name in names]
 for future in as_completed(futures):future.result()
records={name:json.loads((out/('policy-'+name)/'VERIFIED.json').read_text()) for name in ['roster_'+c+'_'+p+'_'+t for c in ['signed','tls'] for p in ['fixed','recoverable'] for t in ['applied','closed']]}
assert all(x['completed'] and x['java_processes']==68 for x in records.values())
(out/'POLICY_MATRIX.json').write_text(json.dumps({'completed':True,'host_java_processes':544,'cases':records},indent=2)+'\n')
print('Eight policy-roster host routes and 544 calls complete',flush=True)
