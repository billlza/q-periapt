from pathlib import Path
import tempfile,shutil,subprocess,os,json
root=Path.cwd();out=root/'target/continuity-android-roster-next/reader-policy-checks-v2';out.mkdir();source=root/'target/continuity-android-roster-next/policy-roster_signed_fixed_applied/cases/signed-fixed';work=Path(tempfile.mkdtemp(prefix='qperiapt-policy-roster-reader-'));env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14')
inputs=['roster-proposal','roster-operation','trusted-roster-version','trusted-roster-digest','renewal-version','renewal-digest','policy-target/policy-version','policy-target/policy-digest','policy-version','policy-digest','renewal-statement']
results={}
for name,mutation in [('original',None),('substituted-authorization',('roster-proposal',300)),('substituted-original-subject',('roster-proposal',45)),('new-terminal-in-history',('roster-historical-transcript',205))]:
 case=work/name;case.mkdir()
 for p in source.iterdir():
  if p.is_file():shutil.copy2(p,case/p.name)
 for field in inputs:
  target=case/'inputs'/field;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/'inputs'/field,target)
 if mutation:
  path=case/mutation[0];data=bytearray(path.read_bytes());data[mutation[1]]=16 if name=='new-terminal-in-history' else data[mutation[1]]^1;path.write_bytes(data)
  if name in ['substituted-authorization','substituted-original-subject']:
   for field in ['roster-proposal-replayed','roster-proposal-recovered','inputs/roster-proposal']:(case/field).write_bytes(data)
 r=subprocess.run(['/bin/sh','artifact/python-run.sh','target/continuity-android-roster-next/verify-policy-roster.py',str(case),'applied'],cwd=root,env=env,capture_output=True,text=True,timeout=30)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 if mutation:assert r.returncode!=0 and 'AssertionError' in r.stderr
 else:assert r.returncode==0
 results[name]={'exit_code':r.returncode,'accepted':r.returncode==0,'expected':mutation is None}
(out/'VERIFIED.json').write_text(json.dumps({'completed':True,'cases':results},indent=2)+'\n');print('Reader accepts original and rejects authorization, subject and extra-terminal mutations',flush=True)
