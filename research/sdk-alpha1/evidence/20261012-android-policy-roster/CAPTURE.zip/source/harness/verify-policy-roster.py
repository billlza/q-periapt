from pathlib import Path
import hashlib,json,sys
import rust_sdk_profile as sdk
root=Path.cwd();base=Path(sys.argv[1]);terminal=sys.argv[2];assert terminal in ['applied','closed']
def read(name):return sdk.snapshot(base/name).data
identity=read('original.identity');prepared=read('prepared');assert len(identity)==64 and len(prepared)==164 and identity[32:]==prepared[4:36]
assert read('original.request')==read('activated.request') and read('final.identity')==identity
assert read('roster-renewed-identity')==identity==read('policy-renewed-identity')
unknown=read('policy-message-unknown');assert len(unknown)==64 and unknown[:32]==read('policy-connected') and read('policy-message-acknowledged')==unknown
assert read('policy-effect-before')==read('policy-effect-after')==unknown+b'persisted before process exit'
assert read('roster-peer-admitted.stdout')==b'peer-roster-admitted\n' and read('roster-peer-admitted.stderr')==b''
expiry=read('policy-expiry-observation');assert len(expiry)==32;until,at,renewed_at,target_until=[int.from_bytes(expiry[i:i+8],'big') for i in range(0,32,8)];assert until<=at<=renewed_at<target_until
assert read('expired-activation')==(104).to_bytes(4,'big') and read('expired-identity')==identity
proposal=read('roster-proposal');assert len(proposal)==417 and proposal[:8]==b'QPRWNP01'
assert all(read(name)==proposal for name in ['roster-proposal-replayed','roster-proposal-recovered','inputs/roster-proposal'])
assert proposal[40:136]==prepared[36:132] and proposal[136:168]==read('inputs/roster-operation')
assert proposal[168:208]==read('inputs/trusted-roster-version')+read('inputs/trusted-roster-digest')
assert proposal[208:248]==read('inputs/renewal-version')+read('inputs/renewal-digest')
assert proposal[248:288]==read('inputs/policy-target/policy-version')+read('inputs/policy-target/policy-digest')
assert proposal[248:288]!=read('inputs/policy-version')+read('inputs/policy-digest')
assert proposal[288:289]==b'\x01' and proposal[289:321]==read('inputs/renewal-statement')
scope=proposal[136:288]+proposal[289:321]+(1).to_bytes(4,'big')+bytes(4)
assert read('roster-reserved')==(2).to_bytes(4,'big')+bytes(4)+scope+proposal+bytes(7)
phase,state,kind=(4,3,18) if terminal=='closed' else (3,2,16)
assert read('roster-retired')==phase.to_bytes(4,'big')+(1).to_bytes(4,'big')+scope+proposal+bytes(7)
assert read('roster-terminal')==state.to_bytes(4,'big')
for name in ['historical-unmanaged','reconciled','close-exact','commit-exact']:assert read('roster-'+name)==state.to_bytes(4,'big')
for name,code in [('bad-roster',102),('cancelled',302),('no-policy-fallback',1),('original-expired',104)]:assert read('roster-'+name)==code.to_bytes(4,'big') and read('roster-'+name+'-absent')==bytes(624)
for name,code in [('unavailable',5),('no-local-abandon',211),('substitution-refused',211),('unknown',218),('no-local-resolve',216),('registry-required',211)]:assert read('roster-'+name)==code.to_bytes(4,'big')
assert len(read('roster-lost-terminal-request'))==3674 and read('roster-lost-terminal-request')[204]==kind and len(read('roster-lost-terminal-reply'))==3659
trace=read('roster-historical-transcript');assert trace and len(trace)%7334==0 and all(trace[i]==1 and trace[i+205] not in [16,18] for i in range(0,len(trace),7334))
assert read('policy-process-count')==(68).to_bytes(8,'big')
sdk.write_json(Path(sys.argv[3]) if len(sys.argv)==4 else base.parent/('READBACK-'+base.name+'.json'),{'completed':True,'terminal':terminal,'foreign_processes':68,'actual_expired_original_policy':True,'selected_policy_authorization_bound':True,'original_subject_session_message':True,'business_effects':1,'terminal_reply_lost':True,'historical_without_new_terminal_commands':True,'public_payload_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.is_file()}})
print('Policy-roster readback passed '+str(base),flush=True)
