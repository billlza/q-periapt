from pathlib import Path
import json,shutil
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-roster-next';s=json.loads((out/'HARNESS_STATE.json').read_text());assert not s['live_producer'];source=Path(s['source']);tool=Path(s['environment']['RUSTC']).parent
pairs=[('android_policy_renewal.rs','android_policy_renewal.rs'),('android_policy_roster.rs','android_policy_renewal/roster.rs'),('android_roster_traffic.rs','android_roster_traffic.rs'),('android_roster_witness.rs','android_roster_witness.rs')]
sdk.command([str(tool/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(out/a) for a,_ in pairs]],out/'rustfmt-policy-v2',root)
for a,b in pairs: shutil.copy2(out/a,source/'tests/common'/b)
s['live_producer']=True;(out/'HARNESS_STATE.json').write_text(json.dumps(s,indent=2)+'\n')
try: sdk.command([str(tool/'cargo'),'test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2'],out/'harness-policy-v2',source,environment=s['environment'])
finally:
 s['live_producer']=False;(out/'HARNESS_STATE.json').write_text(json.dumps(s,indent=2)+'\n')
print('Independent-policy roster harness compiled',flush=True)
