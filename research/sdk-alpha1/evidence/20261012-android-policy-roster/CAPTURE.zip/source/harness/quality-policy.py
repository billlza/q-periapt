from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-roster-next';s=json.loads((out/'HARNESS_STATE.json').read_text());source=Path(s['source']);tool=Path(s['environment']['RUSTC']).parent
env=dict(s['environment'],CARGO_TARGET_DIR=str(Path(s['work'])/'clippy-build'))
sdk.command([str(tool/'cargo'),'clippy','--locked','--offline','--test','android','-j','2','--','-D','warnings'],out/'clippy-policy',source,environment=env)
print('Independent-policy roster harness strict Clippy passed',flush=True)
