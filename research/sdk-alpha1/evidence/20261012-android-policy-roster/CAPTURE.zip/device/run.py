from pathlib import Path
import hashlib,json,re,subprocess,shutil
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=Path(__file__).resolve().parent;prototype=root/'target/continuity-android-roster-next';s=json.loads((prototype/'HARNESS_STATE.json').read_text());assert not s['live_producer'];source=Path(s['source']);env=s['environment'];built=c.built_artifact((prototype/'harness-policy-v2.stdout').read_bytes(),source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android');binary=out/'android-harness';shutil.copy2(built,binary);assert sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256==sdk.snapshot(built,maximum=c.MAX_BINARY).sha256
package=json.loads((out/'PACKAGE.json').read_text());h={'copied_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'test_sources':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'tests').rglob('*.rs')},'receiver':json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text())['native']['execution']['debug']['binaries']['C_client']['path'],'target_client':json.loads((root/'target/continuity-android-policy-renewal-host-resumed-v2/android-jni-debug-policy-target-client.json').read_text())['argv'][-1]};sdk.write_json(out/'HARNESS.json',h)
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest

def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.policyroster20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(path.read_text())
  if not state.get('installation_attempted') or (state.get('cleanup') and not state.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
  def call(args):
   result=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(state.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);state['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;path.write_text(json.dumps(state,indent=2)+'\n')
results={}
try:
 for name in ['roster_signed_fixed_applied','roster_tls_recoverable_closed']:
  cases=out/('cases-'+name);runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=h['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=h['target_client'])
  stdout=sdk.command([str(binary),'--exact','android_policy_renewal::'+name,'--nocapture'],out/name,source,environment=runtime)
  assert stdout.count(b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 20 filtered out;')==1
  _,carrier,trust,terminal=name.split('_');label=carrier+'-'+trust;count=int.from_bytes((cases/label/'policy-process-count').read_bytes(),'big');assert count==68
  assert stdout.count(('qualified policy renewal '+carrier+'/'+trust+': 68 foreign processes; expired P0, independent P2, original identity session message and one effect').encode())==1
  results[name]={'foreign_processes':count,'case':str(cases/label),'terminal':terminal,'trust':trust,'device_label':carrier+'-'+trust+'-'+terminal}
  sdk.write_json(out/('OUTCOME-'+name+'.json'),results[name])
 sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('policy-roster qualification and owned cleanup failed',[original,failure])
 raise
print('136 ART policy-roster calls passed on the accepted phone',flush=True)
