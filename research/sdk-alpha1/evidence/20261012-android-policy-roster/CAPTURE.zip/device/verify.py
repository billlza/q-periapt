from pathlib import Path
import hashlib,json,re,subprocess,sys
import rust_sdk_profile as sdk
root=Path.cwd();out=Path(__file__).resolve().parent;results=json.loads((out/'OUTCOMES.json').read_text());assert len(results)==2
for name,record in results.items():
 base=Path(record['case']);label=record['device_label'];trust=record['trust'];state=json.loads((out/('device-'+label)/'STATE.json').read_text())
 sdk.command(['/bin/sh','artifact/python-run.sh','target/continuity-android-roster-next/verify-policy-roster.py',str(base),record['terminal'],str(out/('PUBLIC-'+name+'.json'))],out/('readback-final-'+name),root,environment=dict(__import__('os').environ,QPERIAPT_PYTHON=sys.executable))
 assert state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports') and len(state['cases'])==record['foreign_processes']==68
 assert len({c['pid'] for c in state['cases']})==68
 for case in state['cases']:
  payload=sdk.snapshot(base/case['label']).data
  assert case['process_absent_after_stop'] and case['installed_apk_sha256']==state['apk_sha256'] and case['result_sha256']==hashlib.sha256(payload).hexdigest()
  assert sdk.snapshot(base/(case['label']+'.stdout')).data==(trust+':'+case['mode']+':passed\n').encode() and not sdk.snapshot(base/(case['label']+'.stderr')).data
 record.update(original_session=(base/'policy-connected').read_bytes().hex(),original_message=(base/'policy-message-unknown').read_bytes()[32:].hex(),business_effects=1,installation_retired=True,apk_sha256=state['apk_sha256'],aar_sha256=state['aar_sha256'])
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
def call(args):
 r=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,check=True,timeout=20);assert not r.stderr;return r.stdout
assert not call(['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.policyroster20261012']).strip()
active={row.split()[1] for row in call(['reverse','--list']).splitlines() if len(row.split())==3}
for p in out.glob('device-*/*-reverse-create-*.json'):
 r=json.loads(p.read_text())
 if r['exit_code']==0:assert r['command'][-2] not in active
assert sum(r['foreign_processes'] for r in results.values())==136
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':results,'art_processes':136,'same_phone_accepted':True,'additional_api36_hardware_required':False,'scope':'Actual expired P0, independent P2, required-witness same-credential roster Applied/Closed with terminal reply loss and original-message recovery; signed/fixed/Applied and TLS/recoverable/Closed.'})
print('136 ART policy-roster calls, original-message effects and owned cleanup verified',flush=True)
