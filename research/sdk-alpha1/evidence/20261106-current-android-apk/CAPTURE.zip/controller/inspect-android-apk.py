from pathlib import Path
import hashlib
import json
import os
import sys
import zipfile

import rust_sdk_profile as sdk
from android_agp_consumer import verify_diagnostic_log

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = sdk.ROOT
REPO = SOURCE.parents[2]
ROOT = REPO / 'target/continuity-current-android-apk-5678'
BUILD = ROOT / 'build-03'
OUT = ROOT / 'inspection-01'
OUT.mkdir()
record = json.loads((BUILD / 'APK_BUILD.json').read_bytes())
assert record['completed'] is True
apk = BUILD / record['unsigned_apk']['file']
snap = sdk.snapshot(apk, maximum=256 * 1024**2)
assert snap.sha256 == record['unsigned_apk']['sha256'] and snap.size == record['unsigned_apk']['bytes']
TOOLS = REPO / 'target/continuity-android-tools-20261105/apk-tools'
tool_record = json.loads((TOOLS / 'TOOLS.json').read_bytes())['records']['build-tools;36.0.0']
inventory = json.loads((TOOLS / (tool_record['file'] + '.FILES.json')).read_bytes())
build_tools = Path(tool_record['root'])
identities = {}
for name in ['dexdump', 'aapt2', 'zipalign']:
    path = build_tools / name
    actual = sdk.snapshot(path)
    assert actual.sha256 == inventory[name]['sha256'] and actual.size == inventory[name]['bytes']
    identities[name] = {'sha256': actual.sha256, 'bytes': actual.size}
with zipfile.ZipFile(apk) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 14
    dex_names = [name for name in archive.namelist() if name.endswith('.dex')]
    assert dex_names == ['classes.dex']
    dex = archive.read('classes.dex')
    assert dex.startswith(b'dex\n') and len(dex) <= 16 * 1024**2
    (OUT / 'classes.dex').write_bytes(dex)
environment = {k: v for k, v in os.environ.items() if not k.startswith(('JAVA_', 'JDK_', 'DYLD_', 'LD_', 'QPERIAPT_', 'QPC_'))}
for key in ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'CLASSPATH']:
    environment.pop(key, None)
commands = [
    ('dexdump', [str(build_tools / 'dexdump'), str(OUT / 'classes.dex')]),
    ('manifest', [str(build_tools / 'aapt2'), 'dump', 'xmltree', '--file', 'AndroidManifest.xml', str(apk)]),
    ('zipalign', [str(build_tools / 'zipalign'), '-c', '-P', '16', '-v', '4', str(apk)]),
    ('tool-architecture', ['/usr/bin/file', *[str(build_tools / name) for name in identities]]),
]
for label, command in commands:
    sdk.command(command, OUT / label, SOURCE, environment=environment)
    assert (OUT / (label + '.stderr')).read_bytes() == b''
    verify_diagnostic_log((OUT / (label + '.stdout')).read_text())
sdk.write_json(OUT / 'TOOLS.json', identities)
print('Actual APK DEX/manifest/alignment inspection completed; semantic readback follows', flush=True)
