from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

import continuity_android_jni as android
from android_agp_consumer import verify_diagnostic_log
import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
ROOT = REPO / 'target/continuity-current-android-apk-5678'
assert ROOT.is_dir()
OUT = ROOT / 'build-03'
OUT.mkdir()
TOOLS = REPO / 'target/continuity-android-tools-20261105/apk-tools'
tools = json.loads((TOOLS / 'TOOLS.json').read_bytes())
assert tools['completed'] is True
platform_tools = json.loads((TOOLS / 'PLATFORM_TOOLS.json').read_bytes())
assert platform_tools['completed'] is True
tools['records'].update(platform_tools['records'])
for row in tools['records'].values():
    inventory = json.loads((TOOLS / (row['file'] + '.FILES.json')).read_bytes())
    for name, expected in inventory.items():
        actual = sdk.snapshot(Path(row['root']) / name, maximum=512 * 1024**2)
        assert actual.sha256 == expected['sha256'] and actual.size == expected['bytes']
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == ('5678d1019861fa1b04f3a219ba3fde7e0ddaaba8', False)
source_inputs = package.source_inputs()
aar_root = REPO / 'target/continuity-current-android-aar-5678/package-02'
aar_report = json.loads((aar_root / 'ANDROID_AAR_PACKAGE.json').read_bytes())
assert aar_report['completed'] and aar_report['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
aar = aar_root / aar_report['aar']['file']
assert sdk.snapshot(aar).sha256 == aar_report['aar']['sha256']
java_home = REPO / 'target/continuity-jvm-tools/installed/jdk-25.0.5+8/Contents/Home'
assert android.tool_identity(java_home) == aar_report['java_tools']
project = Path(tempfile.mkdtemp(prefix='qperiapt-current-android-agp-')).resolve()
gradle_home = ROOT / 'gradle-home'
assert gradle_home.is_dir()
sdk.write_json(OUT / 'LOCATION.json', {'project': str(project), 'gradle_home': str(gradle_home)})
template = SOURCE / 'artifact/android-agp-consumer'
for name in ['settings.gradle.kts', 'build.gradle.kts', 'gradle.properties']:
    shutil.copy2(template / name, project / name)
assert 'version "9.4.1"' in (project / 'build.gradle.kts').read_text()
(project / 'libs').mkdir()
shutil.copy2(aar, project / 'libs/continuity.aar')
app = project / 'app'
java_root = app / 'src/main/java'
source_files = {}
host_boundary_sources = {}
expected_host_boundary = {'AccountBridgeProbe', 'BridgeProbe', 'CredentialBridgeProbe', 'JointPolicyBridgeProbe',
    'PendingWriteBridgeProbe', 'PolicyBridgeProbe', 'RecoveryBridgeProbe', 'RetiredBridgeProbe', 'RootBridgeProbe', 'RosterBridgeProbe'}
for folder in [android.SOURCE / 'src/test/java', android.SOURCE / 'src/androidTest/java']:
    for source in sorted(folder.rglob('*.java')):
        data = source.read_bytes()
        matches = re.findall(r'^package ([A-Za-z0-9_.]+);$', data.decode(), re.M)
        assert len(matches) == 1
        if matches[0] == 'dev.qperiapt.continuity.android':
            assert folder == android.SOURCE / 'src/test/java' and source.stem in expected_host_boundary
            host_boundary_sources[source.stem] = {'source': source.relative_to(SOURCE).as_posix(), 'sha256': hashlib.sha256(data).hexdigest()}
            continue
        assert matches[0] == 'dev.qperiapt.continuity.android.tests'
        relative = Path(*matches[0].split('.')) / source.name
        target = java_root / relative
        assert not target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        source_files[source.relative_to(SOURCE).as_posix()] = {'project_file': target.relative_to(project).as_posix(), 'sha256': hashlib.sha256(data).hexdigest()}
assert set(host_boundary_sources) == expected_host_boundary and len(source_files) == 43
for value in source_files.values():
    text = (project / value['project_file']).read_text()
    assert not any(re.search(r'\b' + re.escape(name) + r'\b', text) for name in expected_host_boundary)
sdk.write_json(OUT / 'HOST_BOUNDARY_SOURCES.json', {'sources': host_boundary_sources,
    'scope': 'Unchanged host JNI boundary probes, outside the original Android instrumentation source namespace and reference closure; remain in the separately running original host gate.'})
application = 'dev.qperiapt.continuity.qualification20261106'
(app / 'src/main/AndroidManifest.xml').write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:allowBackup="false" android:label="Continuity qualification"/><instrumentation android:name="dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation" android:targetPackage="' + application + '"/></manifest>\n')
(app / 'build.gradle.kts').write_text('''import groovy.json.JsonOutput
import java.security.MessageDigest
plugins { id("com.android.application") }
android {
    namespace = "dev.qperiapt.continuity.android.tests"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    defaultConfig {
        applicationId = "dev.qperiapt.continuity.qualification20261106"
        minSdk = 36
        targetSdk = 36
        versionCode = 1
        versionName = "qualification"
    }
    buildTypes {
        getByName("release") {
            isDebuggable = false
            isMinifyEnabled = true
            vcsInfo.include = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildFeatures { buildConfig = false }
    packaging.jniLibs {
        useLegacyPackaging = false
        keepDebugSymbols += setOf("**/libq_periapt_continuity_c_consumer.so", "**/libqperiapt_continuity_jni.so")
    }
}
dependencies { implementation(files(rootProject.file("libs/continuity.aar"))) }
tasks.withType<JavaCompile>().configureEach {
    options.compilerArgs.addAll(listOf("-Xlint:all", "-Werror"))
    doFirst {
        check(!options.isFork)
        fun digest(f: java.io.File) = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
        file("compile-inputs.json").writeText(JsonOutput.toJson(source.files.sortedBy { it.canonicalPath }.map { mapOf("path" to it.canonicalPath, "sha256" to digest(it)) }) + "\\n")
        file("compile-classpath.json").writeText(JsonOutput.toJson(classpath.files.sortedBy { it.canonicalPath }.map { entry ->
            when {
                entry.isFile -> mapOf("path" to entry.canonicalPath, "kind" to "file", "sha256" to digest(entry))
                entry.isDirectory -> mapOf("path" to entry.canonicalPath, "kind" to "directory", "files" to entry.walkTopDown().filter { it.isFile }.sortedBy { it.canonicalPath }.map { mapOf("path" to it.relativeTo(entry).path, "sha256" to digest(it)) }.toList())
                else -> {
                    val emptyKotlin = tasks.named("compileReleaseKotlin").get().state
                    check(entry.canonicalFile == file("build/intermediates/built_in_kotlinc/release/compileReleaseKotlin/classes").canonicalFile)
                    check(emptyKotlin.executed && emptyKotlin.noSource && emptyKotlin.failure == null)
                    mapOf("path" to entry.canonicalPath, "kind" to "absent-no-source-output", "producer" to ":app:compileReleaseKotlin", "producer_no_source" to true)
                }
            }
        }) + "\\n")
        file("compiler-identity.json").writeText(JsonOutput.toJson(mapOf("java_home" to System.getProperty("java.home"), "java_version" to System.getProperty("java.version"), "compiler_home" to javaCompiler.get().metadata.installationPath.asFile.canonicalPath, "fork" to options.isFork)) + "\\n")
    }
}
''')
project_inputs = {p.relative_to(project).as_posix(): sdk.snapshot(p).sha256 for p in project.rglob('*') if p.is_file()}
sdk.write_json(OUT / 'PROJECT_INPUTS.json', project_inputs)
sdk.write_json(OUT / 'SOURCE_FILES.json', source_files)
environment = {k: v for k, v in os.environ.items() if not k.startswith(('JAVA', 'JDK', 'GRADLE', 'ANDROID', 'DYLD', 'LD_', 'QPERIAPT_', 'QPC_', 'CARGO_', 'RUST'))}
for key in ['_JAVA_OPTIONS', 'CLASSPATH']:
    environment.pop(key, None)
environment.update(JAVA_HOME=str(java_home), ANDROID_HOME=str(TOOLS / 'sdk'), ANDROID_SDK_ROOT=str(TOOLS / 'sdk'),
    GRADLE_USER_HOME=str(gradle_home), PATH=str(java_home / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin')
gradle = TOOLS / 'gradle-9.7.1/bin/gradle'
common = [str(gradle), '--project-dir', str(project), '--no-daemon', '--no-build-cache',
    '--no-configuration-cache', '--max-workers=2', '--warning-mode=fail', '--console=plain', '-Dorg.gradle.java.home=' + str(java_home)]
record = {'completed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': aar_report['source_commit'], 'aar_sha256': aar_report['aar']['sha256'],
    'project': str(project), 'application_id': application, 'source_files': source_files,
    'agp_version': '9.4.1', 'gradle_version': '9.7.1', 'compile_sdk': 36, 'app_min_sdk': 36,
    'library_min_sdk': 23, 'minify_enabled': True, 'app_q_keep_rules': False,
    'art_executed': False, 'physical_device_executed': False, 'release_claim_eligible': False,
    'scope': 'Build-only current candidate qualification APK from actual AAR and original instrumentation. Existing API36 APK compile floor does not request API36 hardware or change library support. No runtime inputs, signing, device action or installed runtime acceptance.'}
try:
    for label, arguments in [('version', common + ['--version']), ('assemble', common + [':app:assembleRelease'])]:
        print(label, flush=True)
        with (OUT / (label + '.stdout')).open('xb') as out, (OUT / (label + '.stderr')).open('xb') as err:
            completed = subprocess.run(arguments, cwd=project, env=environment, stdout=out, stderr=err, timeout=900)
        sdk.write_json(OUT / (label + '.json'), {'argv': arguments, 'returncode': completed.returncode, 'cwd': str(project)})
        assert completed.returncode == 0, label + ' failed; preserve its complete logs'
        verify_diagnostic_log((OUT / (label + '.stdout')).read_text() + (OUT / (label + '.stderr')).read_text())
    apk = app / 'build/outputs/apk/release/app-release-unsigned.apk'
    snap = sdk.snapshot(apk, maximum=256 * 1024**2)
    shutil.copy2(apk, OUT / 'consumer-unsigned.apk')
    for name in ['compile-inputs.json', 'compile-classpath.json', 'compiler-identity.json']:
        shutil.copy2(app / name, OUT / name)
    for p in sorted((app / 'build/outputs/mapping/release').iterdir()):
        if p.is_file():
            shutil.copy2(p, OUT / p.name)
    compiled = json.loads((OUT / 'compile-inputs.json').read_bytes())
    expected = {str(project / value['project_file']): value['sha256'] for value in source_files.values()}
    assert len(compiled) == len(expected) and {row['path']: row['sha256'] for row in compiled} == expected
    identity = json.loads((OUT / 'compiler-identity.json').read_bytes())
    assert identity['fork'] is False and identity['java_home'] == identity['compiler_home'] == str(java_home)
    for name, expected_hash in project_inputs.items():
        assert sdk.snapshot(project / name).sha256 == expected_hash
    assert package.source_inputs() == source_inputs
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (aar_report['source_commit'], False)
    cache_inventory = {p.relative_to(gradle_home).as_posix(): {'bytes': p.stat().st_size, 'sha256': sdk.snapshot(p, maximum=256 * 1024**2).sha256}
        for p in sorted((gradle_home / 'caches/modules-2/files-2.1').rglob('*')) if p.is_file()}
    sdk.write_json(OUT / 'GRADLE_MODULES.json', cache_inventory)
    record.update(completed=True, unsigned_apk={'file': 'consumer-unsigned.apk', 'sha256': snap.sha256, 'bytes': snap.size},
        compiled_sources=len(compiled), runtime_classpath_files=len(json.loads((OUT / 'compile-classpath.json').read_bytes())),
        sources_unchanged=True)
except BaseException as error:
    record.update(error_type=type(error).__name__, failure=str(error))
    raise
finally:
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    sdk.write_json(OUT / 'APK_BUILD.json', record)
print(json.dumps({key: record[key] for key in ['completed', 'unsigned_apk', 'compiled_sources']}), flush=True)
