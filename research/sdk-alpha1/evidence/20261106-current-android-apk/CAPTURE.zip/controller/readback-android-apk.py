from pathlib import Path
import hashlib
import json
import re
import struct
import sys
import zipfile

import android_elf as elf
from android_agp_consumer import DEFAULT_PROGUARD_SHA256, verify_diagnostic_log
import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
ROOT = REPO / 'target/continuity-current-android-apk-5678'
BUILD = ROOT / 'build-03'
OUT = ROOT / 'inspection-01'
report = json.loads((BUILD / 'APK_BUILD.json').read_bytes())
assert report['completed'] is True and report['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert report['minify_enabled'] is True and report['app_q_keep_rules'] is False
assert not report['art_executed'] and not report['physical_device_executed'] and not report['release_claim_eligible']
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (report['source_commit'], False)
aar_root = REPO / 'target/continuity-current-android-aar-5678/package-02'
aar_report = json.loads((aar_root / 'ANDROID_AAR_PACKAGE.json').read_bytes())
aar = aar_root / aar_report['aar']['file']
assert sdk.snapshot(aar).sha256 == report['aar_sha256'] == aar_report['aar']['sha256']
project = Path(report['project'])
for name, expected in json.loads((BUILD / 'PROJECT_INPUTS.json').read_bytes()).items():
    assert sdk.snapshot(project / name).sha256 == expected
source_files = json.loads((BUILD / 'SOURCE_FILES.json').read_bytes())
assert len(source_files) == report['compiled_sources'] == 43
compiled = json.loads((BUILD / 'compile-inputs.json').read_bytes())
assert len(compiled) == 43 and {row['path']: row['sha256'] for row in compiled} == {
    str(project / value['project_file']): value['sha256'] for value in source_files.values()}
for name, expected in source_files.items():
    assert sdk.snapshot(SOURCE / name).sha256 == sdk.snapshot(project / expected['project_file']).sha256 == expected['sha256']
identity = json.loads((BUILD / 'compiler-identity.json').read_bytes())
assert identity['fork'] is False and identity['java_home'] == identity['compiler_home'] == aar_report['java_tools']['root']
assert identity['java_version'] == '25.0.5'
classpath = json.loads((BUILD / 'compile-classpath.json').read_bytes())
assert len(classpath) == 7 and len({row['path'] for row in classpath}) == 7
absent = [row for row in classpath if row['kind'] != 'file']
assert absent == [{'path': str(project / 'app/build/intermediates/built_in_kotlinc/release/compileReleaseKotlin/classes'),
    'kind': 'absent-no-source-output', 'producer': ':app:compileReleaseKotlin', 'producer_no_source': True}]
assert not Path(absent[0]['path']).exists()
for row in classpath:
    if row['kind'] == 'file':
        assert sdk.snapshot(Path(row['path'])).sha256 == row['sha256']
for label in ['version', 'assemble']:
    command = json.loads((BUILD / (label + '.json')).read_bytes())
    assert command['returncode'] == 0
    verify_diagnostic_log((BUILD / (label + '.stdout')).read_text() + (BUILD / (label + '.stderr')).read_text())
log = (BUILD / 'assemble.stdout').read_text()
assert '> Task :app:compileReleaseKotlin NO-SOURCE\n' in log
for task in ['compileReleaseJavaWithJavac', 'minifyReleaseWithR8', 'lintVitalRelease', 'packageRelease']:
    assert '> Task :app:' + task + '\n' in log
assert 'BUILD SUCCESSFUL' in log and '43 actionable tasks: 43 executed' in log
default = project / 'app/build/intermediates/default_proguard_files/global/proguard-android-optimize.txt-9.4.1'
assert sdk.snapshot(default).sha256 == DEFAULT_PROGUARD_SHA256
rules = (BUILD / 'configuration.txt').read_text()
assert rules.count('-keep class dev.qperiapt.continuity.android.Native { *; }') == 1
assert 'dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:\n' in (BUILD / 'mapping.txt').read_text()
classes = elf.parse_consumer_dex_classes((OUT / 'dexdump.stdout').read_text())
native = classes['Ldev/qperiapt/continuity/android/Native;']
methods = {name: descriptor for name, descriptor, flags in native if 'NATIVE' in flags.split()}
assert len(methods) == 23 and methods == aar_report['native_methods']
for name, descriptor in methods.items():
    matches = [(d, set(flags.split())) for n, d, flags in native if n == name]
    assert matches == [(descriptor, {'PUBLIC', 'STATIC', 'NATIVE'})]
for name, descriptor in aar_report['static_callbacks'].items():
    matches = [(d, set(flags.split())) for n, d, flags in native if n == name]
    assert matches == [(descriptor, {'PRIVATE', 'STATIC'})]
instrumentation = classes['Ldev/qperiapt/continuity/android/tests/ConfigurationInstrumentation;']
for name, descriptor in [('<init>', '()V'), ('onCreate', '(Landroid/os/Bundle;)V'), ('onStart', '()V')]:
    matches = [(d, set(flags.split())) for n, d, flags in instrumentation if n == name]
    assert len(matches) == 1 and matches[0][0] == descriptor and 'PUBLIC' in matches[0][1]
    assert not matches[0][1].intersection({'NATIVE', 'ABSTRACT', 'STATIC'})
manifest = (OUT / 'manifest.stdout').read_text()
assert re.findall(r'\bE: (\S+) \(line=', manifest) == ['manifest', 'uses-sdk', 'uses-permission', 'instrumentation', 'application']
assert re.findall(r'^    A: package="([^"]+)"', manifest, re.M) == [report['application_id']]
assert ':targetPackage(0x01010021)="' + report['application_id'] + '"' in manifest
assert ':name(0x01010003)="dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation"' in manifest
assert ':minSdkVersion(0x0101020c)=36\n' in manifest and ':targetSdkVersion(0x01010270)=36\n' in manifest
assert ':allowBackup(0x01010280)=false\n' in manifest and ':extractNativeLibs(0x010104ea)=false\n' in manifest
assert 'debuggable' not in manifest and 'testOnly' not in manifest
apk = BUILD / report['unsigned_apk']['file']
apk_data = apk.read_bytes()
assert hashlib.sha256(apk_data).hexdigest() == report['unsigned_apk']['sha256']
binary_rows = {}
with zipfile.ZipFile(aar) as library, zipfile.ZipFile(apk) as application:
    assert len(application.namelist()) == len(set(application.namelist())) == 14
    assert application.read('classes.dex') == (OUT / 'classes.dex').read_bytes()
    assert application.read('META-INF/com/android/build/gradle/app-metadata.properties') == b'appMetadataVersion=1.1\nandroidGradlePluginVersion=9.4.1\n'
    expected_names = {'lib/arm64-v8a/' + row['file'] for row in aar_report['native_binaries'].values()}
    assert {name for name in application.namelist() if name.startswith('lib/')} == expected_names
    for row in aar_report['native_binaries'].values():
        name = 'lib/arm64-v8a/' + row['file']
        info = application.getinfo(name)
        actual = application.read(name)
        assert actual == library.read('jni/arm64-v8a/' + row['file'])
        assert hashlib.sha256(actual).hexdigest() == row['sha256'] and len(actual) == row['bytes']
        assert info.compress_type == zipfile.ZIP_STORED
        header = apk_data[info.header_offset:info.header_offset + 30]
        assert header[:4] == b'PK\x03\x04'
        length, extra = struct.unpack_from('<HH', header, 26)
        offset = info.header_offset + 30 + length + extra
        assert offset % 16384 == 0 and apk_data[offset:offset + len(actual)] == actual
        binary_rows[row['file']] = {'sha256': row['sha256'], 'bytes': len(actual), 'zip_stored': True, 'data_offset': offset, 'zip_alignment': 16384}
assert (OUT / 'zipalign.stdout').read_text().endswith('Verification successful\n')
for label in ['dexdump', 'manifest', 'zipalign', 'tool-architecture']:
    command = json.loads((OUT / (label + '.json')).read_bytes())
    assert command['returncode'] == 0 and (OUT / (label + '.stderr')).read_bytes() == b''
    verify_diagnostic_log((OUT / (label + '.stdout')).read_text())
result = {'completed': True, 'source_commit': report['source_commit'], 'aar_sha256': report['aar_sha256'],
    'apk': report['unsigned_apk'], 'minified_release': True, 'native_members_equal_to_aar': True,
    'native_binaries': binary_rows, 'dex_sha256': hashlib.sha256((OUT / 'classes.dex').read_bytes()).hexdigest(),
    'dex_bytes': (OUT / 'classes.dex').stat().st_size, 'dex_class_definitions': len(classes),
    'native_method_definitions': 23, 'static_callback_definitions': 3, 'instrumentation_entrypoints': 3,
    'compiled_device_sources': 43, 'unchanged_host_boundary_sources': 10,
    'compile_classpath_files': 6, 'explicit_no_source_outputs': 1,
    'agp_version': '9.4.1', 'gradle_version': '9.7.1', 'jdk_version': '25.0.5',
    'library_compile_floor': 23, 'qualification_apk_compile_floor': 36,
    'signed': False, 'art_executed': False, 'physical_device_executed': False,
    'release_claim_eligible': False,
    'scope': 'Actual current AAR consumed by original device instrumentation namespace through strict javac, R8 and AGP Release packaging; independent actual DEX/manifest/native-byte/ZIP alignment inspection. No runtime inputs, signed installation, ART or device execution.'}
sdk.write_json(OUT / 'READBACK.json', result)
print(json.dumps(result))
