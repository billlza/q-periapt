from pathlib import Path
import ast
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
TOOLS = REPO / 'target/continuity-android-tools-20261105/apk-tools'
DEST = REPO / 'research/sdk-alpha1/evidence/20261106-current-android-apk'
DEST.mkdir()
report = json.loads((ROOT / 'inspection-01/READBACK.json').read_bytes())
assert report['completed'] is True
files = {}

def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            name = prefix + '/' + path.relative_to(directory).as_posix()
            assert name not in files
            files[name] = path

for name in ['build-01', 'build-02', 'build-03', 'inspection-01']:
    tree(name, ROOT / name)
for name in ['build-01', 'build-02', 'build-03']:
    project = Path(json.loads((ROOT / name / 'LOCATION.json').read_bytes())['project'])
    inputs = json.loads((ROOT / name / 'PROJECT_INPUTS.json').read_bytes())
    for relative, expected in inputs.items():
        if relative == 'libs/continuity.aar':
            continue
        path = project / relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
        files[name + '/project-inputs/' + relative] = path
    problems = project / 'build/reports/problems/problems-report.html'
    if problems.is_file():
        files[name + '/problems-report.html'] = problems
aar_root = REPO / 'target/continuity-current-android-aar-5678/package-02'
aar_report = json.loads((aar_root / 'ANDROID_AAR_PACKAGE.json').read_bytes())
files['aar/' + aar_report['aar']['file']] = aar_root / aar_report['aar']['file']
files['aar/ANDROID_AAR_PACKAGE.json'] = aar_root / 'ANDROID_AAR_PACKAGE.json'
files['aar/STATIC_READBACK.json'] = REPO / 'target/continuity-current-android-aar-5678/identity-02/READBACK.json'
files['aar/CAPTURE.json'] = REPO / 'research/sdk-alpha1/evidence/20261106-current-android-aar/CAPTURE.json'
classpath = json.loads((ROOT / 'build-03/compile-classpath.json').read_bytes())
classpath_records = {}
for index, row in enumerate(classpath):
    if row['kind'] == 'file':
        path = Path(row['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        name = 'classpath/' + str(index) + '-' + path.name
        files[name] = path
        classpath_records[name] = row
project = Path(json.loads((ROOT / 'build-03/LOCATION.json').read_bytes())['project'])
for relative in ['app/build/intermediates/default_proguard_files/global/proguard-android-optimize.txt-9.4.1',
                 'app/build/intermediates/aapt_proguard_file/release/processReleaseResources/aapt_rules.txt']:
    files['shrink-inputs/' + Path(relative).name] = project / relative
gradle_home = ROOT / 'gradle-home'
module_inventory = json.loads((ROOT / 'build-03/GRADLE_MODULES.json').read_bytes())
for relative, row in module_inventory.items():
    if relative.endswith('.jar') and '/com.android.tools.build/gradle/' in relative:
        path = gradle_home / relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        files['tools/agp/' + path.name] = path
for path in sorted(TOOLS.iterdir()):
    if path.is_file() and not path.name.endswith(('.zip', '.partial')):
        files['tool-preparation/' + path.name] = path
for name in ['build-tools;36.0.0', 'platforms;android-36']:
    row = json.loads((TOOLS / 'TOOLS.json').read_bytes())['records'][name]
    directory = Path(row['root'])
    for leaf in ['NOTICE.txt', 'source.properties', 'package.xml']:
        path = directory / leaf
        if path.is_file():
            files['tool-preparation/' + name.replace(';', '/') + '/' + leaf] = path
files['tool-preparation/repository2-3.xml'] = TOOLS.parent / 'repository2-3.xml'
drivers = ['build-android-apk.py', 'build-android-apk02.py', 'build-android-apk03.py', 'inspect-android-apk.py', 'readback-android-apk.py']
for name in drivers:
    files['controller/' + name] = SOURCE / 'target/current-rust-readback' / name
for label in ['android-apk-build', 'android-apk-build02', 'android-apk-build03', 'android-apk-inspect', 'android-apk-readback']:
    for suffix in ['stdout', 'stderr']:
        files['controller/' + label + '.' + suffix] = SOURCE.parent / (label + '.' + suffix)
files['controller/capture.py'] = ROOT / 'capture.py'
tree('source/bindings/android/ContinuityPackageConsumer', SOURCE / 'bindings/android/ContinuityPackageConsumer')
queue = [SOURCE / 'target/current-rust-readback' / name for name in drivers]
seen = set()
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.is_relative_to(SOURCE / 'artifact'):
        files['source/' + path.relative_to(SOURCE).as_posix()] = path
    for node in ast.walk(ast.parse(path.read_bytes())):
        modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
        for module in modules:
            dependency = SOURCE / 'artifact' / (module.replace('.', '/') + '.py')
            if dependency.is_file():
                queue.append(dependency)
for name in ['python-run.sh', 'python-env.sh', 'python_bootstrap.py']:
    files['source/artifact/' + name] = SOURCE / 'artifact' / name
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.writestr(name, data)
with zipfile.ZipFile(DEST / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
data = (DEST / 'CAPTURE.zip').read_bytes()
assert len(data) < 95 * 1024**2
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(DEST / 'CLASSPATH.json').write_text(json.dumps(classpath_records, indent=2, sort_keys=True) + '\n')
(DEST / 'READBACK.json').write_bytes((ROOT / 'inspection-01/READBACK.json').read_bytes())
summary = {'source_commit': report['source_commit'], 'members': len(manifest), 'bytes': len(data),
    'sha256': hashlib.sha256(data).hexdigest(), 'aar_sha256': report['aar_sha256'], 'apk': report['apk'],
    'successful_build': 'build-03', 'failed_builds_preserved': ['build-01', 'build-02'],
    'all_members_reread': True, 'signed': False, 'art_executed': False, 'physical_device_executed': False,
    'release_claim_eligible': False, 'scope': report['scope']}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
