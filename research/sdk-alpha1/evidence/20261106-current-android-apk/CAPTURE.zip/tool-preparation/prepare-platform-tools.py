from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
metadata = (ROOT.parent / 'repository2-3.xml').read_bytes()
assert hashlib.sha256(metadata).hexdigest() == 'fe899e662573cc77c76d1234628d0d61330112ef81aa190b9ba85b31562036cb'
document = ET.fromstring(metadata)
plan = {}
nodes = [node for node in document.findall('.//{*}remotePackage') if node.get('path') == 'platform-tools' and node.find('./{*}channelRef').get('ref') == 'channel-0']
assert len(nodes) == 1
node = nodes[0]
assert [node.findtext('./{*}revision/{*}' + field) for field in ['major', 'minor', 'micro']] == ['37', '0', '1']
items = [item for item in node.findall('./{*}archives/{*}archive') if item.findtext('./{*}host-os') == 'macosx']
assert len(items) == 1
item = items[0].find('./{*}complete')
assert item.find('./{*}checksum').get('type') == 'sha1'
assert item.findtext('./{*}url') == 'platform-tools_r37.0.1-darwin.zip'
plan['platform-tools'] = {'url': 'https://dl.google.com/android/repository/' + item.findtext('./{*}url'),
    'file': item.findtext('./{*}url'), 'bytes': int(item.findtext('./{*}size')),
    'algorithm': 'sha1', 'digest': item.findtext('./{*}checksum').strip(), 'destination': 'sdk/platform-tools',
    'license_ref': node.find('./{*}uses-license').get('ref'), 'channel': 'stable', 'revision': '37.0.1'}
(ROOT / 'PLATFORM_TOOLS_PLAN.json').write_text(json.dumps(plan, indent=2) + '\n')
records = {}
for label, row in plan.items():
    print('download', label, flush=True)
    partial = ROOT / (row['file'] + '.partial')
    assert not partial.exists() and not (ROOT / row['file']).exists()
    result = {'completed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **row}
    try:
        command = ['/usr/bin/curl', '--fail', '--location', '--proto', '=https', '--proto-redir', '=https',
            '--connect-timeout', '30', '--max-time', '240', '--max-filesize', str(256 * 1024**2),
            '--retry', '0', '--output', str(partial), row['url']]
        with (ROOT / (row['file'] + '.stdout')).open('xb') as out, (ROOT / (row['file'] + '.stderr')).open('xb') as err:
            run = subprocess.run(command, stdout=out, stderr=err, timeout=250)
        result['exit_code'] = run.returncode
        assert run.returncode == 0
        data = partial.read_bytes()
        result.update(observed_bytes=len(data), observed_sha256=hashlib.sha256(data).hexdigest(),
            observed_digest=hashlib.new(row['algorithm'], data).hexdigest())
        assert 0 < len(data) <= 256 * 1024**2
        if 'bytes' in row:
            assert len(data) == row['bytes']
        assert result['observed_digest'] == row['digest']
        partial.rename(ROOT / row['file'])
        target = ROOT / row['destination']
        target.mkdir(parents=True)
        inventory = {}
        with zipfile.ZipFile(ROOT / row['file']) as archive:
            infos = archive.infolist()
            assert len(infos) <= 100000 and sum(i.file_size for i in infos) <= 2 * 1024**3
            roots = {PurePosixPath(i.filename).parts[0] for i in infos}
            assert len(roots) == 1
            names = set()
            for info in infos:
                name = info.filename.rstrip('/')
                p = PurePosixPath(name)
                assert name and p.as_posix() == name and not p.is_absolute()
                assert '..' not in p.parts and '.' not in p.parts and '\\' not in name and ':' not in name
                key = unicodedata.normalize('NFC', name).casefold()
                assert key not in names
                names.add(key)
                assert stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG, stat.S_IFDIR)
                assert info.file_size <= 512 * 1024**2
                if len(p.parts) == 1:
                    assert info.is_dir()
                    continue
                relative = Path(*p.parts[1:])
                output = target / relative
                if info.is_dir():
                    output.mkdir(parents=True, exist_ok=True)
                    continue
                output.parent.mkdir(parents=True, exist_ok=True)
                payload = archive.read(info)
                with output.open('xb') as stream:
                    stream.write(payload)
                mode = 0o755 if (info.external_attr >> 16) & 0o111 else 0o644
                output.chmod(mode)
                inventory[relative.as_posix()] = {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(), 'mode': mode}
        (ROOT / (row['file'] + '.FILES.json')).write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
        result.update(completed=True, root=str(target), files=len(inventory))
    except BaseException as error:
        result.update(error_type=type(error).__name__, failure=str(error))
        raise
    finally:
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (ROOT / (row['file'] + '.RESULT.json')).write_text(json.dumps(result, indent=2) + '\n')
    records[label] = result
    print('installed', label, result['files'], flush=True)
assert 'Pkg.Revision=36.0.0' in (ROOT / 'sdk/build-tools/36.0.0/source.properties').read_text().replace(' ', '')
assert 'AndroidVersion.ApiLevel=36' in (ROOT / 'sdk/platforms/android-36/source.properties').read_text().replace(' ', '')
(ROOT / 'PLATFORM_TOOLS.json').write_text(json.dumps({'completed': True, 'records': records,
    'scope': 'Project-private Android compile/build tools and original Gradle pin only; no global install, device action or license acceptance command.'}, indent=2) + '\n')
