import groovy.json.JsonOutput
import java.security.MessageDigest
plugins { id("com.android.application") }
android {
    namespace = "dev.qperiapt.continuity.android.tests"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    defaultConfig {
        applicationId = "dev.qperiapt.continuity.qualification20261106"
        minSdk = 36
        targetSdk = 36
        versionCode = 1
        versionName = "qualification"
    }
    buildTypes {
        getByName("release") {
            isDebuggable = false
            isMinifyEnabled = true
            vcsInfo.include = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildFeatures { buildConfig = false }
    packaging.jniLibs {
        useLegacyPackaging = false
        keepDebugSymbols += setOf("**/libq_periapt_continuity_c_consumer.so", "**/libqperiapt_continuity_jni.so")
    }
}
dependencies { implementation(files(rootProject.file("libs/continuity.aar"))) }
tasks.withType<JavaCompile>().configureEach {
    options.compilerArgs.addAll(listOf("-Xlint:all", "-Werror"))
    doFirst {
        check(!options.isFork)
        fun digest(f: java.io.File) = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
        file("compile-inputs.json").writeText(JsonOutput.toJson(source.files.sortedBy { it.canonicalPath }.map { mapOf("path" to it.canonicalPath, "sha256" to digest(it)) }) + "\n")
        file("compile-classpath.json").writeText(JsonOutput.toJson(classpath.files.sortedBy { it.canonicalPath }.map { entry ->
            when {
                entry.isFile -> mapOf("path" to entry.canonicalPath, "kind" to "file", "sha256" to digest(entry))
                entry.isDirectory -> mapOf("path" to entry.canonicalPath, "kind" to "directory", "files" to entry.walkTopDown().filter { it.isFile }.sortedBy { it.canonicalPath }.map { mapOf("path" to it.relativeTo(entry).path, "sha256" to digest(it)) }.toList())
                else -> {
                    val emptyKotlin = tasks.named("compileReleaseKotlin").get().state
                    check(entry.canonicalFile == file("build/intermediates/built_in_kotlinc/release/compileReleaseKotlin/classes").canonicalFile)
                    check(emptyKotlin.executed && emptyKotlin.noSource && emptyKotlin.failure == null)
                    mapOf("path" to entry.canonicalPath, "kind" to "absent-no-source-output", "producer" to ":app:compileReleaseKotlin", "producer_no_source" to true)
                }
            }
        }) + "\n")
        file("compiler-identity.json").writeText(JsonOutput.toJson(mapOf("java_home" to System.getProperty("java.home"), "java_version" to System.getProperty("java.version"), "compiler_home" to javaCompiler.get().metadata.installationPath.asFile.canonicalPath, "fork" to options.isFork)) + "\n")
    }
}
