from pathlib import Path
import subprocess,json,hashlib,time
out=Path(__file__).resolve().parent
part=out/'rust-job.log.02.part';final=out/'rust-job.log';assert not part.exists() and not final.exists()
command=['gh','api','--allow-escape-sequences','repos/billlza/q-periapt/actions/jobs/114172082617/logs'];start=time.monotonic()
# Preserve raw bytes only in a regular file. Do not emit terminal control sequences.
with part.open('xb') as stdout,(out/'rust-job-download-02.stderr').open('wb') as stderr:
 r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=900)
h=hashlib.sha256()
with part.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
record={'job':114172082617,'returncode':r.returncode,'bytes':part.stat().st_size,'sha256':h.hexdigest(),'seconds':time.monotonic()-start,'remote_digest_available':False,'raw_output_redirected_to_regular_file':True,'first_attempt':'Retained as RUST_JOB_DOWNLOAD.json and rust-job-download.stderr; gh refused ANSI control sequences even though output was redirected.'}
(out/'RUST_JOB_DOWNLOAD_02.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0 and record['bytes']>0
part.rename(final)
run=json.loads((out/'RUN.json').read_text());job=json.loads((out/'RUST_JOB.json').read_text());download=json.loads((out/'RUST_DOWNLOAD.json').read_text());assert download['verified'] and job['status']=='completed' and run['status']=='completed'
summary={'run':run['id'],'job':job['id'],'head':run['head_sha'],'job_conclusion':job['conclusion'],'workflow_conclusion':run['conclusion'],'rust_diagnostics_verified':True,'rust_job_log_downloaded':True,'completed':True,'all_findings_cleared':False,'release_claim_eligible':False}
(out/'COLLECTION.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(record));print(json.dumps(summary))
