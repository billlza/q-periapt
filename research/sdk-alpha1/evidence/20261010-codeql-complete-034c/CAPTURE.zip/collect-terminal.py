from pathlib import Path
import datetime,hashlib,json,subprocess,time,zipfile
out=Path(__file__).resolve().parent
run=38037903199;job=114172082617
expected_head='034cfd8b47353600a7e392b504e07a8388e2105c'
def api(endpoint):
 return json.loads(subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+endpoint],timeout=120))
def save(name,data):
 (out/name).write_text(json.dumps(data,indent=2)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
start=time.monotonic();previous=None
while True:
 data=api(f'actions/jobs/{job}');save('RUST_JOB.json',data)
 current=(data['status'],data['conclusion'],tuple(s['name'] for s in data['steps'] if s['status']=='in_progress'))
 if current!=previous:
  print(json.dumps({'job':job,'status':current[0],'conclusion':current[1],'active':current[2]}),flush=True);previous=current
 if data['status']=='completed':break
 if time.monotonic()-start>1800:raise TimeoutError('job is still live; collector deadline is not a terminal job result')
 time.sleep(30)
workflow=api(f'actions/runs/{run}');save('RUN.json',workflow)
assert workflow['head_sha']==expected_head
artifacts=api(f'actions/runs/{run}/artifacts?per_page=100');save('ARTIFACTS.json',artifacts)
rust=[a for a in artifacts['artifacts'] if a['name'].startswith('codeql-rust-diagnostics-') and not a['expired']]
assert len(rust)==1,rust
artifact=rust[0];part=out/'rust-diagnostics.zip.part';final=out/'rust-diagnostics.zip'
assert not part.exists() and not final.exists()
with part.open('xb') as stdout,(out/'rust-download.stderr').open('wb') as stderr:
 result=subprocess.run(['gh','api',f"repos/billlza/q-periapt/actions/artifacts/{artifact['id']}/zip"],stdout=stdout,stderr=stderr,timeout=900)
record={'id':artifact['id'],'name':artifact['name'],'returncode':result.returncode,'bytes':part.stat().st_size,'sha256':sha(part),'expected_bytes':artifact['size_in_bytes'],'expected_digest':artifact['digest']}
record['verified']=result.returncode==0 and record['bytes']==artifact['size_in_bytes'] and 'sha256:'+record['sha256']==artifact['digest'];save('RUST_DOWNLOAD.json',record)
assert record['verified'],record
part.rename(final)
with zipfile.ZipFile(final) as z:
 assert z.testzip() is None
 save('RUST_ZIP_INDEX.json',[{'name':i.filename,'bytes':i.file_size,'compressed':i.compress_size} for i in z.infolist()])
print(json.dumps({'rust_diagnostics':record,'job_conclusion':data['conclusion']}),flush=True)
part=out/'rust-job.log.part';final=out/'rust-job.log';assert not part.exists() and not final.exists()
with part.open('xb') as stdout,(out/'rust-job-download.stderr').open('wb') as stderr:
 result=subprocess.run(['gh','api',f'repos/billlza/q-periapt/actions/jobs/{job}/logs'],stdout=stdout,stderr=stderr,timeout=900)
log={'job':job,'returncode':result.returncode,'bytes':part.stat().st_size,'sha256':sha(part),'remote_digest_available':False};save('RUST_JOB_DOWNLOAD.json',log)
assert result.returncode==0 and log['bytes']>0,log
part.rename(final)
summary={'run':run,'job':job,'head':expected_head,'job_conclusion':data['conclusion'],'workflow_status':workflow['status'],'workflow_conclusion':workflow['conclusion'],'rust_diagnostics_verified':True,'rust_job_log_downloaded':True,'seconds':time.monotonic()-start,'completed':True,'all_findings_cleared':False,'release_claim_eligible':False}
save('COLLECTION.json',summary);print(json.dumps(summary),flush=True)
