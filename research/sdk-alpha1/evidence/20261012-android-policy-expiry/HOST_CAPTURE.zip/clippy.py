from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-expiry-host';s=json.loads((out/'STATE.json').read_text());source=Path(s['work'])/'c-consumer'
# A private target directory avoids mutating the ongoing JNI producer's build tree.
env=dict(s['environment'],CARGO_TARGET_DIR=str(out/'clippy-build'))
harness=json.loads((root/'target/continuity-android-policy-expiry-device/HARNESS.json').read_text())
for name,digest in harness['test_sources'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
 relative=Path(name).relative_to('bindings/c/ContinuityPackageConsumer')
 assert hashlib.sha256((source/relative).read_bytes()).hexdigest()==digest
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--locked','--offline','--test','android','--test','first_configuration','-j','2','--','-D','warnings'],out/'clippy',source,environment=env)
print('Android and shared first-configuration Clippy passed in a private build tree',flush=True)
