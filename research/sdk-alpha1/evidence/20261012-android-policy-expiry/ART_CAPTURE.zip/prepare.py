from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_policy_expiry as expiry
root=Path.cwd();out=root/'target/continuity-android-policy-expiry-device';smoke=root/'target/continuity-android-policy-expiry-authorized'
s=json.loads((smoke/'STATE.json').read_text());env=s['environment'];source=Path(s['work'])/'c-consumer'
assert json.loads((smoke/'execution.json').read_text())['returncode']==0
compiled=sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json','-j','2'],out/'harness-build',source,environment=env)
original=c.built_artifact(compiled,source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
binary=out/'android-harness';sdk.copy(original,binary,maximum=c.MAX_BINARY);binary.chmod(0o700)
sdk.write_json(out/'HARNESS.json',{'base_commit':'deaf34d59bbd7b9d381d02bdfab62d92a2277a00','source':str(original),'copied_sha256':sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256,'test_sources':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_policy_expiry.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs']}})
print('Fresh formatted-source Android harness prepared',flush=True)
