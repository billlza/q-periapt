from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_policy_expiry as expiry
root=Path.cwd();out=root/'target/continuity-android-policy-expiry-device';smoke=root/'target/continuity-android-policy-expiry-authorized'
s=json.loads((smoke/'STATE.json').read_text());env=s['environment'];source=Path(s['work'])/'c-consumer'
assert json.loads((smoke/'execution.json').read_text())['returncode']==0
binary=out/'android-harness';harness=json.loads((out/'HARNESS.json').read_text());assert sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256==harness['copied_sha256']
for name,digest in harness['test_sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest

def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.policyexpiry20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(path.read_text())
  if not state.get('installation_attempted') or (state.get('cleanup') and not state.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r.split()[0] for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1
  def call(args):
   result=subprocess.run([adb,'-s',selected[0],*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(state.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);state['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;path.write_text(json.dumps(state,indent=2)+'\n')
results={}
try:
 for trust,test in expiry.TESTS.items():
  cases=out/('cases-'+trust);runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'))
  stdout=sdk.command([str(binary),'--exact',test,'--nocapture'],out/('android-policy-'+trust),source,environment=runtime)
  results.update(expiry.verify_execution(stdout,cases,trust))
 sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('policy expiry qualification and owned cleanup failed',[original,failure])
 raise
print('144 real ART original-policy expiry processes passed on the accepted phone',flush=True)
