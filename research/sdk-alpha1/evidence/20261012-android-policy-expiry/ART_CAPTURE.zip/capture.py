from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_android_local_credential as local
import continuity_android_credential as credential
import continuity_android_remote_credential as remote
import continuity_android_credential_terminal as terminal
import continuity_android_policy_expiry as expiry
root=Path.cwd();phone=root/'target/continuity-android-policy-expiry-device';host=root/'target/continuity-android-policy-expiry-host';aar=root/'target/continuity-android-policy-expiry-aar';smoke=root/'target/continuity-android-policy-expiry-authorized';out=root/'research/sdk-alpha1/evidence/20261012-android-policy-expiry'
v=json.loads((phone/'VERIFIED.json').read_text());h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert v['completed'] and h['completed'] and a['completed']
assert json.loads((host/'clippy.json').read_text())['returncode']==0
assert set(h['profiles'])=={'debug','release'}
host_processes=0
for profile in h['profiles'].values():
 assert profile['boundary_checks']
 count=1+sum(item['foreign_processes'] for key,value in profile.items() if key=='outcomes' or key.endswith('_outcomes') for item in value.values())
 assert count==507
 host_processes+=count
assert host_processes==1014 and sum(item['foreign_processes'] for item in v['profiles'].values())==144
engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());assert engines['completed'] and not engines['live_producer'] and a['native_engine_sha256']==engines['android_library_sha256']
for name,digest in engines['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==a['source_sha256'][name]==digest
libraries={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];lib=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')));libraries[profile]=lib
 assert local.verify_execution((host/('android-jni-'+profile+'-execution.stdout')).read_bytes(),lib/'cases')==h['profiles'][profile]['outcomes']
 assert terminal.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),lib/'credential-cases')==h['profiles'][profile]['credential_outcomes']
 results={}
 for trust in expiry.TESTS:results.update(expiry.verify_execution((host/('android-jni-'+profile+'-policy-expiry-'+trust+'.stdout')).read_bytes(),lib/('policy-expiry-'+trust+'-cases'),trust))
 assert results==h['profiles'][profile]['policy_expiry_outcomes']
serials=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
for row in subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines():
 if ' device ' in row:serials.append(row.split()[0].encode())
private=[]
for cases in [*(phone/('cases-'+t) for t in expiry.TESTS),*(lib/'credential-cases' for lib in libraries.values()),*(lib/('policy-expiry-'+t+'-cases') for lib in libraries.values() for t in expiry.TESTS)]:
 for path in cases.glob('*/inputs/witness-tls-key'):
  value=path.read_bytes();private.extend([value,base64.b64encode(value),value.hex().encode()])
assert not subprocess.run(['git','status','--porcelain'],check=True,capture_output=True,text=True).stdout.strip(),'commit verified code before capture'
out.mkdir()
def archive(name,files):
 with zipfile.ZipFile(out/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for leaf,path in sorted(files.items()):
   data=path.read_bytes();assert not any(value and value in data for value in serials+private),'private value in '+leaf
   info=zipfile.ZipInfo(leaf);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
 return hashlib.sha256((out/name).read_bytes()).hexdigest()
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for pattern in ['device-*/*','agp-*/*']:
 for p in phone.glob(pattern):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for trust in expiry.TESTS:
 for label in [n for n in v['profiles'] if '-'+trust+'-' in n]:
  for name in expiry.public(label.endswith('-applied')):files['cases-'+trust+'/'+label+'/'+name]=phone/('cases-'+trust)/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
for name in ['ANDROID_JNI_CONSUMER.json','qualify.py','clippy.py','clippy.json','clippy.stdout','clippy.stderr','rustfmt.stdout','rustfmt.stderr','rustfmt-source-layout.stdout','rustfmt-source-layout.stderr','rustfmt-recursive.stdout','rustfmt-recursive.stderr','reader-tests.stdout','reader-tests.stderr','package-tests.stdout','package-tests.stderr','package-tests-worktree.stdout','package-tests-worktree.stderr','code-source-gate.stdout','code-source-gate.stderr']:files[name]=host/name
baseline=tuple(n+'.'+s for n,_ in android.CASES for s in ('stdout','stderr'))+('original.request','resumed.request','after-rejection.request','activated.request','rejected','active-reopened','rekeyed','cancelled','connected.session','uncertain.message','acknowledged.message','reverse.result')
for profile,lib in libraries.items():
 for label in h['profiles'][profile]['outcomes']:
  for name in baseline+local.PUBLIC:files['cases/'+profile+'/'+label+'/'+name]=lib/'cases'/label/name
 for label in h['profiles'][profile]['credential_outcomes']:
  for name in credential.PUBLIC+remote.PUBLIC+terminal.PUBLIC:files['credential-cases/'+profile+'/'+label+'/'+name]=lib/'credential-cases'/label/name
 for trust in expiry.TESTS:
  for label in [n for n in h['profiles'][profile]['policy_expiry_outcomes'] if '-'+trust+'-' in n]:
   for name in expiry.public(label.endswith('-applied')):files['policy-expiry/'+profile+'/'+label+'/'+name]=lib/('policy-expiry-'+trust+'-cases')/label/name
host_hash=archive('HOST_CAPTURE.zip',files)
files={p.name:p for p in smoke.iterdir() if p.is_file() and p.name!='STATE.json' and p.suffix in {'.py','.json','.stdout','.stderr'}}
for trust in ['fixed']:
 for label in [c.name for c in (smoke/'cases').iterdir() if c.is_dir()]:
  for name in expiry.public(label.endswith('-applied')):files['cases/'+label+'/'+name]=smoke/'cases'/label/name
for folder in ['continuity-android-policy-expiry-smoke','continuity-android-policy-expiry-smoke-qualified']:
 base=root/'target'/folder
 for p in base.iterdir():
  if p.is_file() and p.name!='STATE.json' and p.suffix in {'.py','.json','.stdout','.stderr'}:files[folder+'/'+p.name]=p
smoke_hash=archive('FOCUSED_CAPTURE.zip',files)
aar_hash=archive('AAR_BUILD_CAPTURE.zip',{p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}})
code={('bindings/android/ContinuityPackageConsumer/'+n):hashlib.sha256(b).hexdigest() for n,b in android.source_files().items()}
for name in ['artifact/continuity_android_jni.py','artifact/continuity_android_policy_expiry.py','artifact/continuity_android_witness.py','artifact/continuity_package.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_policy_expiry.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs']:
 code[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
record={'kind':'qperiapt.android_original_policy_expiry','completed':True,'base_commit':'deaf34d59bbd7b9d381d02bdfab62d92a2277a00','code_commit':subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip(),'code_sha256':code,'profiles':v['profiles'],'art_processes':144,'host_java_processes':host_processes,'device_scope':{'accepted':True,'api':37,'device_count':1,'additional_api36_hardware_required':False},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'unchanged_native_source_sha256':engines['source_sha256'],'native_regression_scope':'Native runtime sources and engine bytes match the preceding local-roster-expiry qualification. Its 909 native tests were not rerun for this test-only increment.','artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'FOCUSED_CAPTURE.zip':smoke_hash,'AAR_BUILD_CAPTURE.zip':aar_hash},'scope':['Real original P0 expires while SDK policy and successor credential/roster remain live.','Fixed and recoverable SDK trust, signed TCP and mutual TLS, each with pre-expiry Applied/lost reply and uncommitted Prepared branches.','Historical proposal replay and original terminal recovery preserve identity and journal. Pending is not classified as non-commit; explicit Close yields Closed and competing Applied stays Committed.','Expired policy refuses staging, a new Commit and activation; captured recovery transcripts contain no Commit.'],'limitations':['This does not qualify SDK authority expiry/revocation, independent policy renewal or restored business traffic under a successor policy.','Witness and issuer are native reference endpoints on the same Mac host; no independent protocol implementation is claimed.'],'release_claim_eligible':False}
record['verification_notes'] = ['The initial focused build rejected two Arc reference types; the corrected build completed the four real-clock routes.', 'First preparation requires a selected live registry; historical proposal replay uses its separate retained-preparation path.', 'A reader initially expected a 32-byte SDK binding; the canonical source defines 68 bytes. The corrected reader and a truncated-binding rejection test pass.', 'All changed Rust files pass individual rustfmt checks. A recursive check reports unchanged peer_bundle formatting; both diagnostics are retained.', 'Two source-inventory unit tests reject the development worktree by contract; the complete suite is rerun in a standalone Git repository.']
sdk.write_json(out/'CHECKS.json',record);print('Captured original-policy expiry across actual AAR and complete JNI profiles',flush=True)
