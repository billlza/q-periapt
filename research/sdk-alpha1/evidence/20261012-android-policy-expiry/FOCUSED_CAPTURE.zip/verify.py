from pathlib import Path
import continuity_android_policy_expiry as expiry
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent
results=expiry.verify_execution((out/'execution.stdout').read_bytes(),out/'cases','fixed')
assert sum(r['foreign_processes'] for r in results.values())==72
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':results})
print('72 fixed-trust real-clock policy-expiry process outcomes verified')
