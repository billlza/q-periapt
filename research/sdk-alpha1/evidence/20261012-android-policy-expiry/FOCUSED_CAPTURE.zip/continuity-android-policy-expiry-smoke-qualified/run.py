from pathlib import Path
import hashlib,json,shutil
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_jni as android
root=Path.cwd();out=root/'target/continuity-android-policy-expiry-smoke-qualified';s=json.loads((out/'STATE.json').read_text());env=s['environment'];source=Path(s['work'])/'c-consumer';old=root/'target/continuity-android-local-credential-qualified-host'
argv=json.loads((old/'android-jni-debug-boundary.json').read_text())['argv'];lib=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')))
java=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java');jar=Path(argv[argv.index('-cp')+1].split(':')[0])
# Reuse the completed production JAR/engine, but compile the revised probes freshly.
assert jar.exists();classes=out/'classes';classes.mkdir()
sdk.command([str(java.with_name('javac')),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),*[str(p) for p in sorted((root/'bindings/android/ContinuityPackageConsumer/src/test/java').glob('*.java'))]],out/'java-probes',root,environment=env)
driver=android._driver(out,java,jar,classes,lib)
compiled=sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json','-j','2'],out/'build',source,environment=env)
binary=c.built_artifact(compiled,source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
runtime=dict(env,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(driver))
sdk.command([str(binary),'--exact','android_policy_expiry::fixed','--nocapture'],out/'execution',source,environment=runtime)
print('Fixed trust signed/TLS Applied/Closed policy-expiry routes passed',flush=True)
