import os, sys
mode, profile, inputs, target, output = sys.argv[1:]
probe = 'CredentialProbe' if mode.startswith('credential-') else ('AuthorityProbe' if mode.startswith('authority-') else ('WitnessProbe' if mode.startswith(('witness-', 'managed-')) else ('PeerProbe' if mode.startswith('peer-') else 'EnrollmentProbe')))
command = ['/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java', '--enable-native-access=ALL-UNNAMED', '-Xcheck:jni', '-Djava.library.path=/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qperiapt-android-jni-ci-lxtcypzr/android-jni-3_3tm23k/debug', '-cp', '/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-android-local-credential-qualified-host/continuity-android-classes.jar:/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-android-policy-expiry-authorized/classes']
command += ['dev.qperiapt.continuity.android.tests.' + probe, inputs, target, profile, mode, output]
os.execv(command[0], command)
