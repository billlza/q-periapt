//! Isolated opening-future cancellation control; not a public SDK API.
use wasm_bindgen::prelude::*;
use q_periapt_continuity_identity_candidate::browser::BrowserDevice;
use std::{future::Future,pin::Pin,task::{Context,Waker}};
type Opening = Pin<Box<dyn Future<Output=Result<BrowserDevice,JsValue>>>>;
/// Own an actual unmodified browser opening future for one controlled cancellation cut.
#[wasm_bindgen]
pub struct PendingOpening { future:Option<Opening>, polled:bool }
#[wasm_bindgen]
impl PendingOpening {
    /// Prepare, but do not poll, the shared opening.
    #[wasm_bindgen(constructor)]
    pub fn new(name:String,id:String,root:Vec<u8>,description:Vec<u8>,mode:String)->Result<Self,JsValue>{
        let future:Opening=match mode.as_str(){
          "create"=>Box::pin(BrowserDevice::create(name,id,root,description)),
          "open"=>Box::pin(BrowserDevice::open(name,id,root,description)),
          "resume"=>Box::pin(BrowserDevice::resume(name,id,root,description)),
          _=>return Err(JsValue::from_str("mode")),
        };
        Ok(Self{future:Some(future),polled:false})
    }
    /// Poll once and require suspension on the real host opening.
    pub fn poll_once(&mut self)->Result<(),JsValue>{
        if self.polled{return Err(JsValue::from_str("already polled"))}self.polled=true;
        let mut context=Context::from_waker(Waker::noop());
        let future=self.future.as_mut().ok_or_else(||JsValue::from_str("closed"))?;
        if future.as_mut().poll(&mut context).is_ready(){return Err(JsValue::from_str("opening did not suspend"))}Ok(())
    }
    /// Drop the pending Rust future without terminating the Worker or browser.
    pub fn cancel(&mut self){self.future.take();}
}
