from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();stage=root/'target/continuity-browser-recovery';dest=root/'research/sdk-alpha1/evidence/20261013-browser-opening-recovery';dest.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runs={name:json.loads((stage/name/'RESULT.json').read_text()) for name in ['red','green','green-io','green-immediate']}
for name,run in runs.items():
 assert run['completed'] and len(run['result']['results'])==3
 assert all(row['leaked']==(name=='red') for row in run['result']['results'])
for row in runs['green-io']['result']['results']:assert row['held_until_native_receipt']
for row in runs['green-immediate']['result']['results']:assert row['before_lease'] and row['outcome']=={'accepted':False,'code':'Closed'}
life=json.loads((stage/'lifecycle-final/RESULT.json').read_text());assert life['completed'] and len(life['cases'])==9
assert sum(len(c['witness_records']) for c in life['cases'])==357
phases=sorted({s['phase'] for op in life['observations'] for s in op['result'] if 'phase' in s});assert phases==[1,2,3,4,5]
for case in ['corrupt','oversized']:
 values=[o for o in life['observations'] if o['case'].endswith('-'+case) and o['phase']=='activate']
 assert next(s['phase'] for s in values[1]['result'] if s['label']=='opened')==4
for case in life['cases']:
 assert case['active']==case['reopened'] and len(case['active']['prekey'])==1184
 if case['case']!='healthy':assert case['rejected']['ownerClosed'] is True
assert life['cases'][0]['badProtocol']['code']=='Authentication'
assert life['cases'][0]['badGrant']['code']=='Checkpoint' and life['cases'][0]['badGrant']['ownerClosed'] is True
base=json.loads((stage/'base-final/RESULT.json').read_text());assert base['completed'] and len(base['report']['cases'])==10
creation=json.loads((stage/'creation-regression/public/BROWSER_ENROLLMENT.json').read_text());assert creation['completed'] and len(creation['native_verified'])==19
source=json.loads((stage/'PACKAGE_SOURCE.json').read_text())
for name,digest in source['files'].items():assert sha(root/name)==sha(stage/'package-source'/name)==digest
legacy=root/'target/continuity-browser-ci/package-source/target/qualification-19108614'
oldrun=json.loads((legacy/'RUN.json').read_text());old=json.loads((legacy/'continuity/CONTINUITY_PACKAGE.json').read_text());c=json.loads((legacy/'continuity/C_CONSUMER.json').read_text());swift=json.loads((legacy/'continuity/SWIFT_CONSUMER.json').read_text())
assert oldrun['live_producer'] is False and oldrun['completed'] is False and old['completed'] is False and c['completed'] is True and swift['completed'] is False
termination={'source':'191086147028762d081b4e73bbaabe9a1d5c2583','driver_terminal':True,'aggregate_completed':False,'c_completed':True,'swift_completed':False,'reason':'outer driver SIGTERM after 10800-second aggregate deadline; related processes verified absent','receipts':{name:sha(legacy/name) for name in ['RUN.json','continuity/CONTINUITY_PACKAGE.json','continuity/C_CONSUMER.json','continuity/SWIFT_CONSUMER.json']}}
(stage/'LEGACY_PACKAGE_TERMINATION.json').write_text(json.dumps(termination,indent=2)+'\n')
members={}
def add(path,name):
 assert path.is_file() and not path.is_symlink() and name not in members;members[name]=path
for name in source['files']:add(root/name,'source-overlay/'+name)
for p in (stage/'baseline-inputs').rglob('*'):
 if p.is_file():add(p,'baseline-inputs/'+p.relative_to(stage/'baseline-inputs').as_posix())
for name in ['research/continuity-identity-candidate/src/storage/browser.rs','research/continuity-identity-candidate/src/storage/browser/storage-root.js','research/continuity-identity-candidate/src/storage/browser/storage-opening.js','crates/q-periapt-sdk-wasm/src/lib.rs','crates/q-periapt-sdk-wasm/src/opening_probe.rs']:
 add(stage/'source'/name,'opening-control-source/'+name)
for folder in ['red','green','green-io','green-immediate','lifecycle-final']:
 add(stage/folder/'RESULT.json',folder+'/RESULT.json')
 if (stage/folder/'WEB.zip').exists():add(stage/folder/'WEB.zip',folder+'/WEB.zip')
 for sub in ['logs','captures','witness','native']:
  for p in (stage/folder/sub).rglob('*'):
   if p.is_file() and not any(part.startswith('.') for part in p.relative_to(stage/folder).parts):add(p,folder+'/'+p.relative_to(stage/folder).as_posix())
for p in (stage/'base-final').iterdir():
 if p.is_file():add(p,'base-browser/'+p.name)
for p in (stage/'creation-regression/public').rglob('*'):
 if p.is_file() and not any(part.startswith('.') for part in p.relative_to(stage/'creation-regression/public').parts):add(p,'creation/'+p.relative_to(stage/'creation-regression/public').as_posix())
for name in ['root.bin','description.bin']:add(stage/'creation-regression/web/inputs'/name,'creation-public/'+name)
package=stage/'package-source/target/recovery-package-01';receipt=json.loads((package/'INSTALLED_CONSUMER.json').read_text())
for p in package.iterdir():
 if p.is_file():add(p,'package/'+p.name)
add(package/'package/PACKAGE_CONTENTS.json','package/PACKAGE_CONTENTS.json')
add(package/'package/THIRD_PARTY/rust/INVENTORY.json','package/LICENSE_INVENTORY.json')
consumer=Path(receipt['installed']).parent.parent
for p in (consumer/'inputs').glob('*.json'):add(p,'public-inputs/'+p.name)
for p in stage.iterdir():
 if p.is_file() and p.suffix in ['.py','.js','.sh','.json','.stdout','.stderr']:add(p,'driver/'+p.name)
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
checks={'completed':True,'release_claim_eligible':False,'base_commit':source['base'],'capture':{'sha256':sha(archive),'members':len(members),'bytes':archive.stat().st_size},
 'opening_controls':{'reproduced_leaks':3,'fixed_completed_native_return_cuts':3,'pending_native_receipt_cuts':3,'before_lease_cuts':3},
 'installed_lifecycle_cases':9,'witness_requests':357,'durable_phases_observed':phases,'installed_base_browser_cases':10,'creation_native_verified_requests':19,
 'package':{'sha256':receipt['sha256'],'manifest_sha256':receipt['manifest_sha256'],'node':receipt['runtime']['version'],'typescript':receipt['typescript'],'node_tests':receipt['installed_node_tests']},
 'validation':{'artifact_tests':22,'native_original_enrollment_regression':1,'engine_wasm_clippy':True,'product_wasm_clippy':True,'rustfmt':True,'js_syntax':True},
 'legacy_package_termination':termination,
 'remaining':['live browser roster refresh/resolution workflows (status mapping is exposed; not exercised here)','signed prekey publication and full session/root/roster/migration browser APIs','HTTPS deployment','minimum compiler/browser matrix','full release and PCS/recovery research scope']}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks['capture']))
