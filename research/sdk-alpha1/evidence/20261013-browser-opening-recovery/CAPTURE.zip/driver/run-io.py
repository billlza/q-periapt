from pathlib import Path
import contextlib,hashlib,json,os,sys,uuid,zipfile
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-recovery';out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();web=stage/'web'
node=Path('/opt/homebrew/bin/node');cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js');binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
session='qpc-opening-'+uuid.uuid4().hex
files={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
report={'completed':False,'expected_leak':sys.argv[2]=='red','web':files,'native_binary':sdk.snapshot(binary,maximum=256*1024*1024).sha256}
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=140,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode})
 sdk.require(r.returncode==0 and not r.stderr,'browser CLI failed: '+label);return r.stdout.decode()
try:
 with serving(web,out,stage/'private-authority',binary) as (origin,records,failures):
  try:
   browser(['open',origin+'/index.html','--browser','chrome'],'open')
   text=browser(['run-code','--filename',str(stage/'io-check.js')],'check')
   sdk.require('### Error' not in text and text.count('### Result\n')==1,'browser execution failed')
   result=parse_strict_json_bytes(text.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='opening')
   sdk.require(len(result['results'])==3 and all(r['leaked']==report['expected_leak'] for r in result['results']),'wrong leak control')
   report['result']=result
  finally:browser(['close'],'close')
 native=out/'native';native.mkdir(mode=0o700)
 for row in report['result']['results']:
  request=out/'captures'/(row['mode']+'.bin');sdk.require(sdk.snapshot(request).sha256==row['request_sha256'],'request changed')
  sdk.command([str(binary),'issue',str(stage/'private-authority'),str(request),str(native/(row['mode']+'.json'))],logs/('verify-'+row['mode']),root,environment=dict(os.environ))
 for name,digest in files.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web changed during proof')
 with zipfile.ZipFile(out/'WEB.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name in files:archive.write(web/name,name)
 report['completed']=True
finally:sdk.write_json(out/'RESULT.json',report)
print(json.dumps({'completed':True,'cases':len(report['result']['results']),'expected_leak':report['expected_leak']}))
