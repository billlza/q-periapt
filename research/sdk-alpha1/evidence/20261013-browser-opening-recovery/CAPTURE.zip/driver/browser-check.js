async page=>{
 return await page.evaluate(async()=>{
  const results=[];
  for(const mode of ['create','open','resume']){
   const result=await new Promise((resolve,reject)=>{const worker=new Worker('/worker.js',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('worker deadline'))},30000);worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message))};worker.onmessage=({data})=>{if(data.ready)worker.postMessage({mode});else if(data.done){clearTimeout(timer);worker.terminate();if(data.error)reject(Error(data.error));else resolve(data.result)}}});
   const response=await fetch('/capture/'+mode+'.bin',{method:'POST',body:new Uint8Array(result.request)});if(!response.ok)throw Error('capture');delete result.request;results.push(result);
  }
  return {results};
 });
}
