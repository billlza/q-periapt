from pathlib import Path
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-swift-hosted-20261105/source-232'
DEST = REPO / 'research/sdk-alpha1/evidence/20261105-hosted-kotlin-pair'
DEST.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def capture(label, files):
    manifest = {}
    with zipfile.ZipFile(DEST / (label + '.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(files.items()):
            assert not path.is_symlink()
            data = path.read_bytes()
            manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
            archive.writestr(name, data)
    with zipfile.ZipFile(DEST / (label + '.zip')) as archive:
        assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
        assert archive.testzip() is None
        for name, expected in manifest.items():
            data = archive.read(name)
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
    data = (DEST / (label + '.zip')).read_bytes()
    assert len(data) < 95 * 1024**2
    summary = {'bytes': len(data), 'sha256': sha(data), 'members': len(manifest)}
    (DEST / (label + '_FILES.json')).write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps({label: summary}), flush=True)
    return summary

captures = {}
readers = {}
for profile in ('debug', 'release'):
    directory = ROOT / ('kotlin-' + profile)
    selected = directory / 'identity-01'
    result = json.loads((selected / 'READBACK.json').read_bytes())
    readers.update(result['loaded_original_modules'])
    files = {}
    for path in sorted(selected.rglob('*')):
        if path.is_file() and not path.is_relative_to(selected / 'package'):
            files['readback/' + path.relative_to(selected).as_posix()] = path
    for name in ('ARTIFACT.json', 'DOWNLOAD.json'):
        files['controller/' + name] = directory / name
    for suffix in ('stdout', 'stderr'):
        files['controller/replay.' + suffix] = SOURCE.parent / ('kotlin-' + profile + '-readback.' + suffix)
    captures[profile.upper()] = capture(profile.upper(), files)
    (DEST / (profile.upper() + '_READBACK.json')).write_bytes((selected / 'READBACK.json').read_bytes())
files = {'source/' + name: SOURCE / name for name in readers}
for name, digest in readers.items():
    assert sha((SOURCE / name).read_bytes()) == digest
for name in ('python-run.sh', 'python-env.sh', 'python_bootstrap.py'):
    files['source/artifact/' + name] = SOURCE / 'artifact' / name
for name in ('verify_kotlin.py', 'verify_kotlin_retention.py'):
    files['source/target/' + name] = SOURCE / 'target' / name
for name in ('kotlin-retention.stdout', 'kotlin-retention.stderr', 'READER_SOURCE.json'):
    files['controller/' + name] = SOURCE.parent / name
for name in ('JOBS.json', 'KOTLIN_RETENTION.json', 'capture_kotlin.py'):
    files['controller/' + name] = ROOT / name
captures['READERS'] = capture('READERS', files)
(DEST / 'RETENTION.json').write_bytes((ROOT / 'KOTLIN_RETENTION.json').read_bytes())
summary = {'source_commit': '232ace17915407596d66f3a5fd7c7765251a38cc', 'captures': captures,
    'source_bytes_dependency': '../20261105-hosted-swift-pair/INPUTS.zip',
    'source_bytes_dependency_sha256': '9a46fb9d761588cb6da670168d140838a94a17a222608a05aac54447c8e119cd',
    'original_archives_retained': {profile: json.loads((ROOT / ('kotlin-' + profile) / 'DOWNLOAD.json').read_bytes()) for profile in ('debug', 'release')},
    'scope': 'Installed Kotlin package/native bytes, 79 tests in each publication and installed lane, 21 selected public reader groups per profile, 26 original C2 logs per profile, 15 negative-control receipts per profile. Full original ZIPs retained; missing publication bytes and three unexported runtime JARs remain explicit. No new native workload, current-source, all-JVM or device acceptance.'}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
