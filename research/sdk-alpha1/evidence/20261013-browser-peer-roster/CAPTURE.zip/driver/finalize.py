from pathlib import Path
import json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-roster';clone=root/'target/continuity-browser-publication/source'
checks=json.loads((root/'research/sdk-alpha1/evidence/20261013-browser-peer-roster/CHECKS.json').read_text())
paths=list(checks['source']['overlay'])+[f'research/sdk-alpha1/evidence/20261013-browser-peer-roster/{n}' for n in ['CAPTURE.zip','CHECKS.json','README.md']]
for name,digest in checks['source']['overlay'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed: '+name)
sdk.command(['git','add','--',*paths],stage/'commit-stage',root)
sdk.command(['git','diff','--cached','--check'],stage/'commit-check',root)
staged=sdk.command(['git','diff','--cached','--name-only'],stage/'commit-paths',root).decode().splitlines();sdk.require(set(staged)==set(paths),'unexpected staged paths')
sdk.command(['git','commit','-m','Add browser peer roster admission and revocation'],stage/'commit',root)
head=sdk.command(['git','rev-parse','HEAD'],stage/'head',root).decode().strip();sdk.require(not sdk.command(['git','status','--porcelain'],stage/'main-status',root),'main not clean')
sdk.command(['git','fetch',str(root),'HEAD'],stage/'clone-fetch',clone);sdk.command(['git','checkout','--detach',head],stage/'clone-checkout',clone)
sdk.require(not sdk.command(['git','status','--porcelain'],stage/'clone-status',clone),'clone not clean')
environment=dict(os.environ);environment['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';environment['PYTHONPATH']='artifact'
sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',sdk.snapshot(clone/'artifact/results.json').sha256,head],stage/'source-gate',clone,environment=environment)
sdk.write_json(stage/'FINALIZED.json',{'head':head,'main_clean':True,'clone_clean':True,'source_gate':'passed','release_claim_eligible':False,'pushed':False});print(head)
