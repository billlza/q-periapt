from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-roster';package=root/'target/continuity-browser-publication/source/target/peer-roster-package-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
overlay=load(stage/'SOURCE_OVERLAY.json')
for name,digest in overlay['overlay'].items():assert sha(root/name)==digest,name
reports=[load(stage/n/'RESULT.json') for n in ['run-01','run-02']];assert all(r['completed'] for r in reports)
cases={c['case']:c for r in reports for c in r['cases']};assert set(cases)=={'happy','before','after','cancel'} and sum(len(r['cases']) for r in reports)==4
expected={'rollback':'Checkpoint','fork':'Checkpoint','unknown':'Absent','local':'Conflict','family':'Conflict','signature':'Authentication','closed-policy':'Closed','closed-runtime':'Closed'}
for name,c in cases.items():
 assert c['installed']['version']=='2' and c['installed']['scalarRejections']==5 and c['installed']['hooks']==0
 assert {b['case']:b['code'] for b in c['boundaries']}==expected
 assert c['revoked']['version']=='3' and c['revoked']['retainedSessionDenied']=='Scope'
 assert c['reopen_denied']['code']=='Scope' and c['reopen_denied']['ownerClosed']
 assert c['old_retry_denied']['code']=='Checkpoint' and c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
 assert c['first_message']!=c['second_message'] and c['received']['application']['effects']==c['received']['application']['calls']==1
 assert c['reverse']['same_original_wire'] and c['reverse']['authenticated_browser_consumption'] and len(c['peer_records'])==4
 if name!='happy':
  cut=c['loss_cut'];assert cut['trigger'] and cut['native_dispatched']==cut['changed']==(name!='before')
  assert c['unknown_result']['ownerClosed'] and c['unknown_result']['code']==('Cancelled' if name=='cancel' else 'WitnessTransport')
  if name=='cancel':assert c['unknown_result']['cancellationRequested']
browser=load(stage/'base-01/RESULT.json');assert browser['completed'] and len(browser['report']['cases'])==10
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz') and receipt['source_bound'] and receipt['sources_unchanged']
assert '8 passed; 0 failed' in (stage/'native-tests.log').read_text()
assert 'Ran 53 tests' in (stage/'controls.log').read_text() and (stage/'controls.log').read_text().rstrip().endswith('OK')
for name in ['msrv.log','wasm-clippy.log','native-clippy.log']:
 text=(stage/name).read_text();assert 'Finished ' in text and 'error:' not in text and 'warning:' not in text
assert not (stage/'fmt.log').read_bytes()
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),p
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and not p.name.startswith(('seal.stdout','seal.stderr','finalize.stdout','finalize.stderr','codeql-','HANDOFF')) and p.suffix in ['.py','.js','.json','.stdout','.stderr','.log','.sh']:add(p,'driver/'+p.name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/name,'native-peer/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','authority/witness.rs')
web=Path(load(package/'consumer-location.json')['path'])
for directory,report in zip(['run-01','run-02'],reports):
 base=stage/directory;add(base/'RESULT.json',directory+'/RESULT.json')
 for p in sorted(base.iterdir()):
  if p.is_file() and p.name!='RESULT.json':add(p,directory+'/'+p.name)
 for part in ['logs','captures','peer']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():add(p,directory+'/'+p.relative_to(base).as_posix())
 for part in ['witness','native']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():raw[directory+'/'+p.relative_to(base).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for c in report['cases']:
  key=directory+'-'+c['case'];folder=base/'witness'/key;selected=set()
  for r in c['witness_records']:
   if r['trigger']:selected.update([r['number']-1,r['number'],r['number']+1])
  add(folder/'RECORDS.json',directory+'/witness/'+key+'/RECORDS.json')
  for number in sorted(selected):
   for suffix in ['request','reply','json']:
    p=folder/f'{number:03}.{suffix}'
    if p.is_file():add(p,directory+'/witness/'+key+'/'+p.name)
  for p in sorted((web/'inputs').glob(key+'*')):
   if p.is_file():add(p,'public-inputs/'+p.name)
for p in (stage/'base-01').iterdir():
 if p.is_file():add(p,'base/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json','build-nodejs.json','build-web.json','typescript.json','consumer-product.json','consumer-installed.json']:
 add(package/name,'package/'+name)
for name in overlay['overlay']:add(root/name,'source/'+name)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)}
encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();dest=root/'research/sdk-alpha1/evidence/20261013-browser-peer-roster';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,meta in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==meta['sha256'] and len(z.read(n))==meta['bytes']
checks={'completed':True,'release_claim_eligible':False,'source':overlay,'cases':sorted(cases),'case_count':4,'boundary_rejections_per_cohort':expected,'scalar_rejections_per_cohort':5,'coercion_hooks':0,
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged','typescript']},
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},
 'validation':{'native_peer_roster_cases':8,'base_browser_cases':10,'browser':browser['report']['browser'],'artifact_controls':53,'wasm_clippy':'-D warnings passed','native_clippy':'all targets -D warnings passed','wasm_msrv':'Rust1.90.0 passed','format':'passed'},
 'semantics':'An original active device accepts only an independently pinned, valid, known remote-account roster. Identical retries remain subject to current local/runtime authority. Original session and bidirectional consumption survive a membership-preserving update. An empty next roster rejects sends through an already held session and rejects later reopen, without peer dispatch. Old target cannot roll back revocation; canonical revocation retry remains available. Local account still requires original enrollment R.',
 'fault_scope':'Fault arming occurs after activation, immediately before the target API. Before drops the first selected request without native witness dispatch, not an asserted unprocessed Commit. After and hold process the first actual head advance, then lose/hold its reply; hold is cancelled by owner.close. Each result closes the owner and the same canonical signed target recovers on original reopen.',
 'trace_policy':'Full raw witness/native traffic remains in task-local closed runs and is hashed in FULL_RAW_TRACE_MANIFEST.json. Complete peer traffic, public inputs, operation logs/results, witness metadata and raw traces adjacent to fault cuts are archived. Private signing/wrapping keys, stores and browser profiles are excluded.',
 'scope':'Real installed npm browser package, Chrome Workers with IndexedDB/Web Locks/OPFS, loopback native counterpart and signed witness sharing the Rust engine. Explicit peer roster admission/revocation is demonstrated; automatic roster distribution, account-root/credential/policy transitions, deployment, independent implementation, representative performance, PCS and full-release qualification are not established.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Installed browser peer roster admission and revocation

The browser device now exposes `admit_peer_roster` through the original owning operation. It verifies the independently pinned signed roster and calls the shared active service's existing admission algorithm. The binding adds no protocol, storage format, private-key export or parallel authority logic. A known remote account is required; the local account still uses original enrollment R. An exact canonical retry checks live authority and reports the installed checkpoint, not which attempt first committed it.

Four fresh installed Chrome Worker cohorts cover normal admission, an unprocessed request loss, a processed head-advance reply loss and cancellation after the processed advance. Faults are armed after device activation and immediately before the target API. The before case drops the selected read/request before native dispatch; it is not labelled an unprocessed Commit. Unknown results close the owner, and original reopen plus the same signed target recovers the actual head.

Every cohort establishes an original session and exchanges real application data. After the new member-preserving peer roster is installed, the same historical bundle/session carries authenticated traffic in both directions. An empty next roster then revokes the peer. A session descriptor retained across that update cannot send (`Scope`), later reopen is refused, and neither rejection emits a peer request. The old target is rejected rather than rolling revocation back; exact canonical revocation retry remains available. The local journal and prekey remain unchanged, and application effects are not duplicated.

Each cohort also rejects rollback, same-version fork, unknown account, local-account substitution, wrong family, corrupted signature, closed policy and closed runtime. Five invalid timestamp aliases are rejected without coercion hooks or closing a still-valid owner. Eight native peer-roster regression cases, ten installed base browser modes, 53 package/inventory controls, strict native/WASM Clippy, WASM Rust 1.90, formatting and installed Node/TypeScript consumers passed.

The archive binds the exact source overlay, package and native binaries to complete operation results and peer traffic. Repetitive raw witness/native traces remain in the original task-local runs with a complete hash manifest; witness metadata and raw messages adjacent to the selected loss cuts are included. No private signing/wrapping material, journal databases or browser profiles are included. This exercises manual receipt/admission of independently trusted rosters, not an automatic distribution service. Credential, policy, account-root transition, migration, deployed-network, independent-implementation, performance, PCS and full-release obligations remain separate. Reopening an owner for every action is deliberate persistence testing, not steady-state performance measurement.
''')
print(json.dumps(checks['capture']))
