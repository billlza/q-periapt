from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-peer-roster';package=root/'target/continuity-browser-publication/source/target/peer-roster-package-01'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Known peer roster admission and revocation</title><script type="module" src="./controller.js"></script>')
session='qpc-peer-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug';authority=binary/'examples/browser_activation_authority';peer=binary/'q-periapt-browser-peer-roster-peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed browser known peer roster admission with original session and required signed witness; same Rust native counterpart over loopback, not independent implementation/deployment/PCS/release evidence','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,peer]},'cases':[],'observations':[]}
allowed={'happy','before','after','cancel'};sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='peer roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'observations':value['result'].get('observations',[])});return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def trace(case,name):
 p=out/'native'/case/name;p.mkdir(mode=0o700,parents=True);return p
def head(value,target):sdk.require(value['version']==str(target['version']) and value['digest']==target['digest'],'wrong canonical peer head')
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="peer_roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("peer_roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(authority,['prepare',directory],case+'-authority');shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    peer_public=inputs/(key+'-peer.json');native(peer,['prepare',directory,grant,peer_public,trace(case,'prepare')],case+'-peer-prepare')
    args.update(action='session');args['requestId']=success({**args,'sessionAction':'new-request'})['requestId'];args['session']=success({**args,'sessionAction':'establish'})['session'];row['session']=args['session']
    first=success({**args,'sessionAction':'new-message'})['message'];sdk.require(success({**args,'sessionAction':'send','message':first})=={'consumption':1,'status':3},'baseline traffic failed');row['first_message']=first
    targets={}
    for label,version,kind in [('next',2,'member'),('fork',2,'revoke'),('revoked',3,'revoke'),('unknown',2,'unknown')]:
     p=inputs/(key+'-'+label+'.json');native(peer,['peer-target',directory,version,kind,p],case+'-'+label);targets[label]=(p,json.loads(p.read_text()))
    target=targets['next'][1];update={**args,'sessionAction':'peer-roster','targetFile':targets['next'][0].name}
    if case!='happy':
     mode='hold' if case=='cancel' else case;options={'armFault':mode}
     if case=='cancel':options['cancelOnAdvance']=True
     failed=rejected({**update,**options},'Cancelled' if case=='cancel' else 'WitnessTransport');row['unknown_result']=failed
     cut=[r for r in witness_records[key] if r.get('armedMode')==mode and r['trigger']];sdk.require(len(cut)==1,'fault not at selected target cut')
     sdk.require(cut[0]['native_dispatched']==(case!='before') and cut[0]['changed']==(case!='before'),'wrong dispatch/commit cut');row['loss_cut']=cut[0]
     if case=='cancel':sdk.require(failed['cancellationRequested'],'cancel missed pending I/O')
    installed=success({**update,'checkScalars':True});head(installed,target);sdk.require(installed['scalarRejections']==5 and installed['hooks']==0,'scalar boundary');row['installed']=installed
    head(success(update),target)
    row['boundaries']=[]
    for label,options,code in [
      ('rollback',{'targetFile':peer_public.name},'Checkpoint'),
      ('fork',{'targetFile':targets['fork'][0].name},'Checkpoint'),
      ('unknown',{'targetFile':targets['unknown'][0].name,'targetTrust':'unknown'},'Absent'),
      ('local',{'targetFile':grant.name,'targetTrust':'local'},'Conflict'),
      ('family',{'wrongFamily':True},'Conflict'),
      ('signature',{'badSignature':True},'Authentication'),
      ('closed-policy',{'closeAfterAdmission':'policy'},'Closed'),
      ('closed-runtime',{'closeAfterAdmission':'runtime'},'Closed')]:
     peers_before=len(peer_records[key]);result=rejected({**update,**options},code);sdk.require(len(peer_records[key])==peers_before,'invalid roster dispatched peer traffic');row['boundaries'].append({'case':label,'code':result['code'],'observations':result['observations']})
    head(success(update),target)
    second=success({**args,'sessionAction':'new-message'})['message'];sdk.require(second!=first and success({**args,'sessionAction':'send','message':second,'plaintext':'after peer roster'})=={'consumption':1,'status':3},'updated session failed');row['second_message']=second
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    reverse_prepared=parse_strict_json_bytes(native(peer,['send-prepare',directory,session_file,reverse,trace(case,'reverse-prepare')],case+'-reverse-prepare'),label='reverse');sdk.require(reverse_prepared['original_dispatched'] and reverse_prepared['owner_closed'],'reverse unknown result');args['reverseMessage']=reverse_prepared['message']
    received=success({**args,'sessionAction':'receive'});duplicate=success({**args,'sessionAction':'receive'});sdk.require(received['application']['effects']==received['application']['calls']==1 and duplicate['application']==received['application'] and not duplicate['callbackInvoked'] and received['reply']==duplicate['reply'],'reverse host/duplicate');row['received']=received
    ack=out/(case+'-ack.bin');ack.write_bytes(bytes(received['reply']));row['reverse']=parse_strict_json_bytes(native(peer,['send-finish',directory,reverse,ack,trace(case,'reverse-finish')],case+'-reverse-finish'),label='reverse consumed');sdk.require(row['reverse']['same_original_wire'] and row['reverse']['authenticated_browser_consumption'],'reverse ACK not authenticated')
    peers_before=len(peer_records[key]);revoked={**args,'sessionAction':'peer-roster','targetFile':targets['revoked'][0].name};denied=success({**revoked,'holdSession':True});head(denied,targets['revoked'][1]);sdk.require(denied['retainedSessionDenied']=='Scope' and len(peer_records[key])==peers_before,'cached session emitted after revocation');row['revoked']=denied
    row['reopen_denied']=rejected({**args,'sessionAction':'new-message'},'Scope');sdk.require(len(peer_records[key])==peers_before,'revoked reopen dispatched')
    head(success(revoked),targets['revoked'][1]);row['old_retry_denied']=rejected(update,'Checkpoint');head(success(revoked),targets['revoked'][1])
    current=success({**args,'action':'activate'});sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'remote update replaced local owner');row['current']=current
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==2 and any(p.read_bytes()==bytes(args['session'])+bytes(first)+b'browser to native' for p in effects) and any(p.read_bytes()==bytes(args['session'])+bytes(second)+b'after peer roster' for p in effects),'native host effects changed')
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'boundaries':len(row['boundaries']),'witness_requests':len(row['witness_records']),'peer_requests':len(row['peer_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
