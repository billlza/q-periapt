from pathlib import Path
import json,shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-roster';clone=root/'target/continuity-browser-publication/source';old=root/'target/continuity-browser-roster-sessions'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'source-paths',root).decode().splitlines();overlay={}
for name in paths:
 p=root/name;overlay[name]=sdk.snapshot(p).sha256;dest=clone/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'source-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'5bfb879954428fbc7de7f90c5cc76211c8cb903e','overlay':overlay,'source':str(clone)})
(stage/'build-package.sh').write_text((root/'target/continuity-browser-roster/build-package.sh').read_text().replace('roster-package-01','peer-roster-package-01'))
for name in ['worker.js','controller.js','server.py','session-checks.js']:shutil.copyfile(old/name,stage/name)
shutil.copytree(old/'native-peer',stage/'native-peer',ignore=shutil.ignore_patterns('target'))
for name in ['Cargo.toml','Cargo.lock']:
 p=stage/'native-peer'/name;p.write_text(p.read_text().replace('q-periapt-browser-roster-session-peer','q-periapt-browser-peer-roster-peer'))
p=stage/'native-peer/src/main.rs';text=p.read_text()
text=text.replace('drop(p::JournalKey::provision(&base.join("wrap.key"))?);\n let root=p::RootSigningKey::generate()?;', 'let wrap=p::JournalKey::provision(&base.join("wrap.key"))?;let root_id=p::SigningKeyId::generate()?;\n let root=p::RootSigningKey::provision(&base.join("root.key"),&wrap,root_id)?;publish_private_bytes(&base.join("root-id.bin"),root_id.as_bytes())?;')
assert 'root-id.bin' in text
needle='fn main()->Result<()>{';assert text.count(needle)==1
text=text.replace(needle,'''fn peer_target(dir:&Path,version:u64,kind:&str,output:&Path)->Result<()> {
 let base=dir.join("peer");let config=load(&dir.join("PUBLIC.json"))?;let peer=load(&base.join("PUBLIC.json"))?;
 let wrap=p::JournalKey::open(&base.join("wrap.key"))?;
 let root=if kind=="unknown" {p::RootSigningKey::generate()?} else {p::RootSigningKey::open(&base.join("root.key"),&wrap,p::SigningKeyId::from_trusted_state(read(&base.join("root-id.bin"),32)?.as_slice().try_into()?)?)?};
 let validity=p::Validity::new(number(&config,"from")?,number(&config,"until")?)?;
 let entries=match kind {"member"=>vec![root.roster_entry(&bytes(&peer,"certificate")?)?],"revoke"|"unknown"=>vec![],_=>return Err("target kind".into())};
 let roster=root.issue_roster(version,validity,&entries)?;
 publish(output,&json!({"root":root.public_key()?.encode(),"account":root.account_id()?,"family":array(&config,"family")?,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),"digest":roster.checkpoint().digest()}))?;
 println!("{}",json!({"version":version,"kind":kind}));Ok(())
}
fn main()->Result<()>{''')
text=text.replace('  "prepare" if args.len()==6=>prepare', '  "peer-target" if args.len()==6=>peer_target(dir,args[3].parse()?,&args[4],Path::new(&args[5]))?,\n  "prepare" if args.len()==6=>prepare')
p.write_text(text)
(stage/'base-browser.py').write_text((root/'target/continuity-browser-roster/base-browser.py').read_text().replace('continuity-browser-roster','continuity-browser-peer-roster').replace('roster-package-02','peer-roster-package-01'))
