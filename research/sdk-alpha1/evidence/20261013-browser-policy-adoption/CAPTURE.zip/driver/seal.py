from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-adoption';package=root/'target/continuity-browser-publication/source/target/policy-adoption-package-02'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={n:load(stage/n/'RESULT.json') for n in ['run03','run04','run05','run06']}
sdk.require(all(r['completed'] for r in reports.values()),'incomplete browser run')
cases={c['case']:c for r in reports.values() for c in r['cases']}
sdk.require(set(cases)=={'local','required','close','commit-loss','ack-loss','cancel','wrong-witness','no-local-fallback','expired-required','kill-commit','kill-ack'},'wrong cases')
for name,c in cases.items():
 sdk.require(c['staged']['status']['phase']==2 and c['staged']['negativeApproval'],'missing exact stage or negative approval')
 if name=='close':
  sdk.require(c['committed']['remote']==3 and c['committed']['progress']['stage']==3 and c['committed']['progress']['retired'] and c['activation_refused']['ownerClosed'],'closed target not retained')
 else:
  sdk.require(c['active']==c['reopened'] and c['active']['journal']==c['original']['journal'] and c['active']['status']['phase']==3,'original activation/reopen failed')
 if name in ['commit-loss','ack-loss','cancel']:
  sdk.require(c['rejection']['ownerClosed'] and c['committed']['remote']==2 and c['committed']['progress']['retired'],'unknown outcome recovery failed')
 if name=='ack-loss':sdk.require(c['interrupted']['progress']['stage']==2 and not c['interrupted']['progress']['retired'],'terminal-before-ACK absent')
 if name=='cancel':sdk.require(c['rejection']['cancellationRequested'],'no actual cancellation')
 if name in ['kill-commit','kill-ack']:
  sdk.require(c['terminated']['killed'] and c['committed']['remote']==2 and c['committed']['progress']['retired'],'worker crash recovery failed')
  if name=='kill-ack':sdk.require(c['interrupted']['progress']['stage']==2 and not c['interrupted']['progress']['retired'],'worker kill lacked durable terminal')
 if name=='local':sdk.require(not c['historical']['runtimeCreated'] and c['historical']['status']['phase']==3,'historical local completion')
e=cases['expired-required']['real_expiry'];sdk.require(e['activated_at']<e['valid_until']<e['request_at'],'not actual P0 expiry')
base=load(stage/'base10-02/RESULT.json');sdk.require(base['completed'] and len(base['report']['cases'])==10,'base browser not passed')
sdk.require('73 passed; 0 failed' in (stage/'native-policy-regressions.log').read_text(),'native policy regressions')
sdk.require('Ran 53 tests' in (stage/'controls-02.log').read_text() and (stage/'controls-02.log').read_text().rstrip().endswith('OK'),'controls')
for name in ['native-clippy-02.log','wasm-clippy-04.log','wasm-msrv-02.log']:
 text=(stage/name).read_text();sdk.require('Finished' in text and 'error:' not in text and 'warning:' not in text,name)
sdk.require(not (stage/'format.log').read_text(),'format')
source=load(stage/'SOURCE_OVERLAY_V2.json')
for n,d in source['overlay'].items():sdk.require(sha(root/n)==d,'source drift '+n)
receipt=load(package/'INSTALLED_CONSUMER.json');sdk.require(receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz'),'package receipt')
installed=Path(load(package/'consumer-location.json')['path'])
for run,r in reports.items():
 for n,d in r['native'].items():sdk.require(sha(Path(n))==d,'native binary drift')
 for n,d in r['source']['inputs'].items():sdk.require(sha(root/n)==d,'package source drift '+n)
 for n,d in r['static_web'].items():
  sdk.require(sha(stage/(run+'-web')/n)==d,'static drift')
  if not n.startswith('creation/'):sdk.require(sha(installed/n)==d,'installed drift')
members={};raw={}
def add(path,name):
 sdk.require(path.is_file() and not path.is_symlink() and name not in members,'bad archive member')
 sdk.require(not any(x.endswith('-private') or x.startswith('private-') for x in path.parts),'private member')
 members[name]=path
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.sh'] and p.name not in ['seal.log','finalize.log','HANDOFF.json']:
  add(p,'driver/'+p.name)
for part in ['issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/part/n,'native/'+part+'/'+n)
for part in ['authority','issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/'target/continuity-browser-policy-requests'/part/n,'prior-native/'+part+'/'+n)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','native/witness.rs')
for run in ['run01','run02','run03','run04','run05','run06','base10','base10-02']:
 folder=stage/run
 for p in sorted(folder.iterdir()):
  if p.is_file():add(p,run+'/'+p.name)
 for part in ['logs','captures']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for p in sorted((folder/'witness').rglob('*')):
  if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted((folder/'witness').rglob('RECORDS.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for row in load(p):
   if row['trigger']:
    for q in sorted(p.parent.glob(f"{row['number']:03}.*")):
     if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((stage/(run+'-web')/'inputs').glob('*')):
  if p.is_file():add(p,'public-inputs/'+p.name)
for number in [1,2]:
 location=package.parent/f'policy-adoption-package-{number:02}'
 for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(location/n,f'package{number}/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())}
manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-policy-adoption';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 sdk.require(z.testzip() is None,'archive corruption')
 for n,m in manifest.items():sdk.require(hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes'],'member hash')
checks={'completed':True,'release_claim_eligible':False,'source':source,'case_count':len(cases),'cases':sorted(cases),'real_policy_expiry':e,'validation':{'native_policy_regressions':73,'controls':53,'base_browser':10,'actual_worker_termination_cuts':2,'strict_clippy_native_wasm':'passed','wasm_msrv':'1.90 passed','format':'passed','browser':base['report']['browser']},'excluded_results':{'run01_run02':'Old package fails witnessed preparation at native file database open. Local case passed but is not current qualification.','base10':'Old exact export list missed newly added approved policy types.','controls.log':'Two inventory tests refused worktree .git indirection; rerun all 53 in real source clone.','wasm-clippy-01.log':'Default features did not compile Continuity.','wasm-clippy-02.log':'Needless question-mark lint repaired without suppression.','native-gp-regressions.log':'Unmatched file-name filter; zero tests, not qualification. The 73-test run includes actual credential-composition module.'},'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Installed browser local/required independent P adoption and exact recovery; actual P0 expiry. Shared Rust engine and loopback; not browser G/P/T/roster full composition, established-session proof, independent implementation, devices, migration, performance, PCS or full release.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
