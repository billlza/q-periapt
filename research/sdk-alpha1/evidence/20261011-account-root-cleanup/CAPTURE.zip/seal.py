from pathlib import Path
import hashlib,json,re,subprocess,zipfile
out=Path(__file__).resolve().parent
root=out.parent.parent
implementation='69a807efb7ac252f19fbe982e969a62dd20311eb'
labels=['current-root','current-retired','current-clippy','current-release','current-msrv-root','current-msrv-traffic','current-msrv-clippy','current-msrv-witness']
validation=[]
for label in labels:
    record=json.loads((out/label/'RESULT.json').read_text())
    assert record['completed'] and record['source_unchanged'] and record['head']==implementation,label
    for path,digest in record['source_sha256'].items():
        assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,(label,path)
    output=(out/label/'stdout').read_text()
    match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',output)
    validation.append({'label':label,'command':record['command'],'seconds':record['seconds'],'tests':int(match[1]) if match else None,'completed':True,'source_matches_implementation_commit':True})
artifact=json.loads((out/'ARTIFACT_RESULT.json').read_text())
assert artifact['returncode']==0 and artifact['source_clean'] and artifact['head']==implementation
log=(out/'artifact-current.log').read_text()
match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK(?: \(skipped=(\d+)\))?',log)
assert match,'artifact test summary'
artifact.update(tests=int(match[1]),skipped=int(match[3] or 0))
assert 'SDK_SOURCE_READINESS_PASS' in (out/'source-gate.log').read_text()
assert implementation in (out/'source-gate.log').read_text()
assert 'FAILED' in (out/'ci-assertion-red.log').read_text() and '\nOK\n' in (out/'ci-assertion-green.log').read_text()
evidence=root/'research/sdk-alpha1/evidence/20261011-account-root-cleanup'
evidence.mkdir(parents=True,exist_ok=True)
assert not (evidence/'CAPTURE.zip').exists()
files=[]
for p in out.rglob('*'):
    if not p.is_file() or p.name=='STATE.json': continue
    if p.suffix in ('.json','.log','.patch','.py') or p.name in ('stdout','stderr'):
        files.append(p)
manifest=[]
with zipfile.ZipFile(evidence/'CAPTURE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        data=p.read_bytes();name=str(p.relative_to(out))
        z.writestr(name,data)
        manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=(evidence/'CAPTURE.zip').read_bytes()
checks={'schema':1,'implementation_commit':implementation,'ci_assertion_fix_commit':'fc9ac29d','release_claim_eligible':False,'scope':'Native original-account retirement inventory, report, independent host acknowledgement and logical journal/signer erasure. Managed-controller and installed foreign integration remain open.',
'behavior':[
'Only a verified permanent account retirement selects an original frozen subject; the actual domain-separated root proposal binding is retained.',
'Witness lookup uses the original subject account; previously retained device inventories cannot be overwritten by a later account-root inventory.',
'The original enrollment lease transfers into the existing restricted cleanup owner. Root history and original enrollment bytes remain alongside the exact cleanup inventory.',
'The journal image, pending intent and exact root fence are erased in one transaction only after purpose-21 host acknowledgement. The original signer is prepared and erased separately afterwards.',
'Actual unconfirmed ciphertext identities survive reporting. Prepared and committed pending targets remain distinct. No delivery success, successor authority or physical erasure is inferred.'
], 'validation':validation,'artifact_validation':artifact,'new_process_loss_cuts':['parent-before','parent-after','journal-before','journal-after'],'sync_fault_coverage':'Calibrate every observed parent-inventory, parent-signer-plan and journal-erasure sync barrier, inject before and after each, reopen the exact original identity and reconcile; Release and both Debug toolchains execute these checks.',
'compatibility':'Existing root-replacement and retirement row formats now permit a strictly bound combination in the same parent. Older parsers reject this combined parent. No downgrade/recreation path or new product C ABI is claimed.',
'maintainability':{'production_rust_lines_added':228,'production_rust_lines_removed':33,'test_rust_lines_added':741,'test_rust_lines_removed':9,'design':'Reuse existing inventory/report/ACK/erasure engine; add a focused parent-transfer module. Borrow the retired proof in SnapshotAdmission instead of widening every variant to a 376-byte payload. No throughput or energy claim.'},
'iterations_retained':['Initial large-enum Clippy rejection corrected by borrowing the verified proof, without suppressing the lint.','Initial test import error fixed. Missing fixture session archive correctly caused ArchiveRequired; the actual archive is now retained before retirement.','Test-only indexing/panic lint errors corrected without suppressions.','A premature linked-worktree artifact run was interrupted and is not qualification; the complete final run uses the clean full checkout.','Old-head hosted check failed on its exact bounded diagnostic upload expectation. Reproduced red locally, then green after adding the existing guest-logcat path. No workflow check was weakened.'],
'limits':['Fresh same-host macOS arm64 fixtures and controlled fixture times; not deployed control-plane transport, an independent protocol implementation, or physical/minimum-platform qualification.','Logical erasure does not erase retained pages, backups, wrapping keys or previously copied signing owners.','Managed root controller and installed C/Swift/Kotlin still need to expose and own this cleanup sequence.','No new full 948-test native library run; targeted suites and all-target strict Clippy qualify this component.','The old-head CodeQL run is tracked separately; local validation does not replace current-head CI.'],
'source_gate':(out/'source-gate.log').read_text().strip(),'tracked_rust_sources':530,
'archive':{'path':'CAPTURE.zip','bytes':len(archive),'sha256':hashlib.sha256(archive).hexdigest(),'members':manifest}}
(evidence/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'evidence':str(evidence),'archive_bytes':len(archive),'archive_sha256':checks['archive']['sha256'],'members':len(manifest),'artifact_tests':artifact['tests'],'artifact_skipped':artifact['skipped']},indent=2))
