"""Verify actual oracle input/output histories and explicitly incomplete results."""
from pathlib import Path
import hashlib
import json
import re
import runpy

root = Path.cwd()
stage = Path(__file__).resolve().parent
model_hash = 'b7ed452927e3659b1bbe5fd6625213743cb8c2d6c1859719e074909716984424'
specs = [
    ('p0-generation-self-peer-701-01', 'generation-self-peer', 14, 0),
    ('p0-generation-peer-first-701-02', 'generation-peer-first', 15, 0),
    ('p0-generation-frontier-701-03', 'generation-peer-frontier', 35, 21),
]
rows = []
histories = []
drivers = set()
for name, label, expected_frames, expected_stops in specs:
    folder = root / 'target' / name
    terminal = json.loads((folder / (label + '-TERMINAL.json')).read_text())
    outer = json.loads((folder / 'DRIVER_TERMINAL.json').read_text())
    assert not terminal['accepted'] and not terminal['release_claim_eligible']
    assert outer['terminal_exit'] == 1 and not terminal['output_exceeded']
    assert hashlib.sha256((folder / 'model.spthy').read_bytes()).hexdigest() == model_hash == terminal['input_sha256']
    drivers.add(hashlib.sha256((folder / 'run.py').read_bytes()).hexdigest())
    frames = [json.loads(path.read_text()) for path in sorted((folder / 'initial-send-oracle-frames').glob('*.json'))]
    log = (folder / (label + '.stderr')).read_text()
    parts = log.split('>>>>>>>>>>>>>>>>>>>>>>>> START INPUT\n')[1:]
    assert len(frames) == len(parts) == expected_frames
    assert sum(frame['diagnostic_stop'] for frame in frames) == expected_stops
    rank = runpy.run_path(str(folder / 'initial-send-oracle.py'))['rank']
    verified_frames = []
    last_normal_goals = []
    for index, (frame, part) in enumerate(zip(frames, parts, strict=True)):
        section, output = part.split('>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT\n', 1)
        matches = [value for value in {section, section.removesuffix('\n')} if hashlib.sha256(value.encode()).hexdigest() == frame['input_sha256']]
        assert len(matches) == 1
        raw = matches[0]
        assert len(raw) == frame['input_characters'] and len(raw.encode()) == frame['input_bytes']
        goals, ranking = rank(raw)
        actual = [int(value) for value in output.split('>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call', 1)[0].split()]
        assert [number for number, _ in goals] == frame['goal_numbers']
        assert actual == frame['ranking']
        if frame['diagnostic_stop']:
            assert expected_stops and index >= 14 and not actual
            assert frame['stop_reason'] == 'callback-budget'
            assert (folder / 'initial-send-oracle-frames' / frame['captured_input']).read_text() == raw
        else:
            assert actual == ranking and sorted(actual) == sorted(frame['goal_numbers'])
            last_normal_goals = goals
        verified_frames.append({'index': index, 'input_sha256': frame['input_sha256'], 'characters': len(raw), 'bytes': len(raw.encode()), 'goal_count': len(goals), 'diagnostic_stop': frame['diagnostic_stop'], 'actual_ranking': actual})
    if expected_stops:
        assert terminal['returncode'] == 0 and not terminal['timed_out']
        assert terminal['results']['epoch_generation_secret_derivation_origin'] == {'mode': 'all-traces', 'status': 'analysis incomplete', 'steps': 40}
        assert len(terminal['results']) == 27
        proof = folder / (label + '-proof.spthy')
        assert hashlib.sha256(proof.read_bytes()).hexdigest() == terminal['output_sha256']
        assert 'by sorry /* Oracle ranked no proof methods */' in proof.read_text()
    else:
        assert terminal['returncode'] == -2 and terminal['timed_out']
        assert terminal['results'] == {} and terminal['output_sha256'] is None
    rows.append({'stage': name, 'terminal': terminal, 'outer_terminal': outer, 'oracle_sha256': hashlib.sha256((folder / 'initial-send-oracle.py').read_bytes()).hexdigest(), 'frames': verified_frames})
    histories.append(frames)
assert len(drivers) == 1
old = root / 'target/p0-generation-parent-tags-700-02/initial-send-oracle-frames'
previous = [json.loads(path.read_text()) for path in sorted(old.glob('*.json'))]
comparisons = []
for prior, current, changed in [(previous, histories[0], 6), (histories[0], histories[1], 11)]:
    assert all(prior[index]['input_sha256'] == current[index]['input_sha256'] and prior[index]['ranking'] == current[index]['ranking'] for index in range(changed))
    assert prior[changed]['input_sha256'] == current[changed]['input_sha256']
    assert prior[changed]['ranking'] != current[changed]['ranking']
    comparisons.append({'identical_input_and_ranking_prefix': changed, 'first_changed_ranking_index': changed, 'first_changed_input_identical': True, 'prior_first': prior[changed]['ranking'][0], 'current_first': current[changed]['ranking'][0]})
assert all(histories[1][index]['input_sha256'] == histories[2][index]['input_sha256'] and histories[1][index]['ranking'] == histories[2][index]['ranking'] for index in range(14))
assert histories[1][14]['input_sha256'] == histories[2][14]['input_sha256'] == 'c37e70bf63501ec3beb35af0542ae17285e48b85c9dd6998cca16a927464045e'
text = (root / 'target' / specs[0][0] / 'model.spthy').read_text()
prefix = text[:re.search(r'^lemma ', text, re.M).start()]
# The export contains commented AC variants with another copy of each premise.
# Producer analysis must inspect the real rule, not those explanatory comments.
rule_text = re.sub(r'/\*.*?\*/', '', prefix, flags=re.S)
assert '/*' not in rule_text and '*/' not in rule_text
rule_matches = list(re.finditer(r'^rule \(modulo E\) (\w+):', rule_text, re.M))
producers = {fact: [] for fact in ['Peers', 'Signer', 'SignerFile', 'Pinned', 'Wrap', 'Context', 'IdentityKey', 'StorageKey']}
for index, match in enumerate(rule_matches):
    block = rule_text[match.end():rule_matches[index + 1].start() if index + 1 < len(rule_matches) else len(rule_text)]
    output = re.split(r'-->|\]\s*->', block, maxsplit=1)[1]
    for fact in producers:
        if re.search(r'!' + fact + r'\(', output):
            producers[fact].append(match.group(1))
assert all(producers[fact] == ['Setup'] for fact in ['Peers', 'Signer', 'SignerFile', 'Pinned', 'Wrap', 'Context'])
assert producers['IdentityKey'] == ['Identity_Key'] and producers['StorageKey'] == ['Storage_Key']
partial = root / 'target/p0-generation-frontier-701-03/ORIGIN_PARTIAL.txt'
stack = []
for line in partial.read_text().splitlines():
    case = re.match(r'^(\s*)case (\S+)', line)
    if case:
        depth = len(case[1])
        stack = [(level, label) for level, label in stack if level < depth]
        stack.append((depth, case[2]))
    if 'by sorry' in line:
        break
result = {'verified': True, 'model_sha256': model_hash, 'operational_prefix_sha256': hashlib.sha256(prefix.encode()).hexdigest(), 'queries': len(re.findall(r'^lemma ', text, re.M)), 'comparisons': comparisons, 'diagnostic_prefix_matches_predecessor': True, 'ordinary_rankings_preserve_every_goal': True, 'source_producers': producers, 'first_exported_frontier_case_path': [label for _, label in stack], 'experiments': rows, 'main_origin_proof_complete': False, 'release_claim_eligible': False, 'interpretation': 'Both ordinary searches timed out without a certificate. The separate lower-callback diagnostic exported a 40-step incomplete proof, with 14 ordinary callbacks followed by 21 explicitly latched diagnostic stops; its driver correctly rejected acceptance. These counts are not proof progress or a security result. The case path begins with Application_Message knowledge-source analysis and reaches Final_Commit_8 after recursive Ready/Receipt history. Static per-session signer/pin/wrapping bindings remain unresolved at the first stopped frontier. Their relevance must be traced before another bounded search; no new assumption, rule or threat restriction has been added.'}
graph = json.loads((root / 'target/p0-generation-frontier-701-03/generation-peer-frontier-traces.json').read_text())
assert len(graph['graphs']) == 1
assert '_initial_epoch_traffic_advances_counter_is_executable-' in graph['graphs'][0]['jgLabel']
result['json_graph_scope'] = {'graphs': 1, 'label': graph['graphs'][0]['jgLabel'], 'belongs_to_existing_initial_traffic_witness': True, 'is_origin_frontier_graph': False}
result['initial_local_reader_failure'] = 'The first producer scan included commented AC-variant premises. The correction removes only block comments for this static scan; the prover model bytes and all query/goal checks remain unchanged. Initial reader exit1 and stderr are retained.'
destination = stage / 'READBACK.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'path': str(destination), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'case_path': result['first_exported_frontier_case_path'], 'comparisons': comparisons}))
