#!/bin/sh
exec /usr/bin/env QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 /bin/sh /Users/bill/Documents/Codex/sdk-020-windows-private-store-20261017/artifact/python-run.sh /Users/bill/Documents/Codex/sdk-020-windows-private-store-20261017/target/p0-generation-frontier-701-03/initial-send-oracle.py "$@"
