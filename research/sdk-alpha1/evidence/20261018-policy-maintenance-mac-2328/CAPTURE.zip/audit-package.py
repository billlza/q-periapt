"""Audit a terminal, exact-head maintenance artifact before executing it."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,subprocess,sys,tarfile,tempfile
root=Path.cwd();out=Path(__file__).resolve().parent;public=out/'public';head='23280124efd2f0f3003d4ce85e3db665f6ec8a25'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(name):return subprocess.check_output(['git','show',head+':'+name])
def check(c,m):
 if not c:raise ValueError(m)
result=json.loads((public/'RESULT.json').read_text());before=json.loads((public/'sources-before.json').read_text())
check(result['source_commit']==result['builder_commit']==head and result['completed'] and result['sources_unchanged'],'producer identity')
for name,digest in before['files'].items():check(sha(git(name))==digest,'source '+name)
# The package verifier and its imported helpers must be exactly the producer revision.
for name in ['policy_maintenance_package','rust_sdk_profile','third_party_licenses','c_package_manifest','evidence_io','rust_sdk_msrv','deterministic_archive','git_provenance']:
 p='artifact/'+name+'.py';check((root/p).read_bytes()==git(p),'verification helper '+p)
sys.path.insert(0,str(root/'artifact'))
import policy_maintenance_package as package
import c_package_manifest as cp
files=subprocess.check_output(['git','ls-tree','-rz','--name-only',head,'--',*cp.RUST_WORKSPACE_INPUTS]).split(b'\0');files=sorted(n.decode()for n in files if n)
h=hashlib.sha256()
process=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
 for name in files:
  process.stdin.write((head+':'+name+'\n').encode());process.stdin.flush()
  header=process.stdout.readline().split();check(len(header)==3 and header[1]==b'blob','git blob')
  size=int(header[2]);body=process.stdout.read(size);check(len(body)==size and process.stdout.read(1)==b'\n','git body')
  h.update(name.encode()+b'\0'+hashlib.sha256(body).digest()+b'\0')
finally:process.stdin.close();check(process.wait()==0,'git batch')
check(h.hexdigest()==before['rust_workspace_sha256'],'exact workspace closure')
archive=public/result['archive'];check(sha(archive.read_bytes())==result['archive_sha256'],'archive digest')
installation=Path(tempfile.mkdtemp(prefix='qperiapt-maintenance-2328-')).resolve();installation.chmod(0o700)
(out/'INSTALLATION.json').write_text(json.dumps({'path':str(installation),'scope':'Isolated actual downloaded package; retained on failure and success.'},indent=2)+'\n')
with tarfile.open(archive) as z:
 entries=z.getmembers();check(len(entries)==len({i.name for i in entries}) and sum(i.size for i in entries)<64*1024**2,'archive resource bound')
 top=archive.name.removesuffix('.tar.gz')
 for item in entries:
  p=PurePosixPath(item.name);check(p.parts[0]==top and not p.is_absolute() and '..'not in p.parts and str(p)==item.name,'archive path')
  check(item.isdir() or item.isreg(),'special archive entry');check(item.mode==(0o755 if item.isdir() or str(p)==top+'/bin/qperiapt' else 0o644),'archive mode')
  dest=installation.joinpath(*p.parts)
  if item.isdir():dest.mkdir(exist_ok=False)
  else:
   with dest.open('xb')as f:f.write(z.extractfile(item).read())
   dest.chmod(item.mode)
installed=installation/top
manifest=package.verify_payload(installed,result['target'],result['manifest_sha256'])
check(manifest['source_inputs']==before and manifest['source_commit']==manifest['builder_commit']==head,'manifest scope')
for destination,source in package.PAYLOAD_SOURCES.items():check((installed/destination).read_bytes()==git(source),'package document '+source)
binary=installed/'bin/qperiapt';check(sha(binary.read_bytes())==result['binary_sha256'],'binary digest')
observations={}
for name,command in [('file',['file',str(binary)]),('load',['otool','-l',str(binary)]),('version',[str(binary),'--version'])]:
 p=subprocess.run(command,capture_output=True,cwd=installation,timeout=30)
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 check(p.returncode==0 and not p.stderr,'actual binary '+name);observations[name]={'command':command,'exit':p.returncode,'stdout_sha256':sha(p.stdout)}
check(b'Mach-O 64-bit executable arm64' in (out/'file.stdout').read_bytes(),'native architecture')
check(b'minos 13.0' in (out/'load.stdout').read_bytes(),'deployment target')
installed_report=json.loads((public/'installed/RESULT.json').read_text());check(installed_report['binary_sha256']==result['binary_sha256'],'producer installed binary')
for item in installed_report['attempts']:
 for stream in ['stdout','stderr']:check(sha((public/'installed'/(item['case']+'.'+stream)).read_bytes())==item[stream+'_sha256'],'producer installed raw output')
check(len(installed_report['attempts'])==7,'producer seven scenarios')
# Retain every real migration fixture instead of TemporaryDirectory cleanup.
source=git('artifact/policy_store_migration_installed.py').decode()
old='with tempfile.TemporaryDirectory(prefix="qperiapt-installed-migration-") as temporary:'
new='with __import__("contextlib").nullcontext(tempfile.mkdtemp(prefix="qperiapt-installed-migration-2328-")) as temporary:'
check(source.count(old)==1,'migration lifetime adaptation')
source=source.replace(old,new).replace('work = Path(temporary).resolve()','work = Path(temporary).resolve()\n        (output / "private-fixture-path").write_text(str(work) + "\\n")')
source=source.replace('ROOT = Path(__file__).resolve().parent.parent','ROOT = Path('+repr(str(root))+')')
(out/'retained-migration.py').write_text(source)
report={'head':head,'source_files':len(before['files']),'workspace_files':len(files),'workspace_sha256':h.hexdigest(),
 'archive':{'sha256':sha(archive.read_bytes()),'members':len(entries)},'binary_sha256':result['binary_sha256'],
 'manifest_sha256':result['manifest_sha256'],'payload_files':len(manifest['files']),'license_packages':result['license_packages'],
 'producer_migration_cases':7,'binary':str(binary),'observations':observations,
 'scope':'Package bytes and producer raw outputs verified. Minimum OS, Continuity migration, power-loss and release not claimed.'}
(out/'PACKAGE_READBACK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
