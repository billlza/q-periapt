"""Seal exact-head Apple Silicon maintenance package consumption."""
from pathlib import Path
import hashlib,json,zipfile
out=Path(__file__).resolve().parent;root=Path.cwd();folder=root/'research/sdk-alpha1/evidence/20261018-policy-maintenance-mac-2328'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((out/'PACKAGE_READBACK.json').read_text());run=json.loads((out/'RUN_LOCAL.json').read_text());assert run['exit']==0
local=json.loads((out/'local-installed/RESULT.json').read_text());assert local['binary_sha256']==report['binary_sha256'] and len(local['attempts'])==7
for row in local['attempts']:
 for stream in ['stdout','stderr']:assert sha((out/'local-installed'/(row['case']+'.'+stream)).read_bytes())==row[stream+'_sha256']
assert [r['returncode']for r in local['attempts']]==[0,0,1,1,1,1,0]
entries={}
for name in ['policy-maintenance.zip','JOB.json','ARTIFACT.json','PACKAGE_READBACK.json','RUN_LOCAL.json','INSTALLATION.json','download.py','download.stdout','download.stderr','audit-package.py','audit-package.stdout','audit-package.stderr','retained-migration.py','local-installed.stdout','local-installed.stderr','file.stdout','file.stderr','load.stdout','load.stderr','version.stdout','version.stderr','seal.py']:
 entries[name]=(out/name).read_bytes()
for path in sorted((out/'local-installed').glob('*')):
 assert path.is_file() and not path.is_symlink();entries['local-installed/'+path.name]=path.read_bytes()
for name in ['download.stderr','audit-package.stderr','local-installed.stderr','file.stderr','load.stderr','version.stderr']:assert not entries[name]
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
folder.mkdir();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(entries.items()):
  i=zipfile.ZipInfo(name,(2026,10,18,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,data)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(entries)==len(set(z.namelist()))
 for name,m in manifest.items():assert sha(z.read(name))==m['sha256']and len(z.read(name))==m['bytes']
result={'package_readback':report,'local_consumption':local,'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':'Exact terminal CI archive executed outside checkout on Apple Silicon using retained public redb2.6.3 fixture. Seven local cases and producer raw outputs. No global installation, real user database, minimum macOS execution, Continuity migration, power-loss or release claim.'}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
