from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,tempfile,time
base=Path(__file__).resolve().parent
label,build_file=sys.argv[1:3]
record=json.loads((base/build_file).read_text());assert record['completed']
binary=Path(record['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==record['binary_sha256']
output=base/label;output.mkdir()
test='ipc::tests::the_accept_wait_times_out_when_idle_and_reports_a_waiting_client'
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))}
args=['/bin/sh','-c','kill -STOP $$; exec "$@"','qperiapt-owned-test',str(binary),'--exact',test,'--nocapture','--test-threads=1']
result={'test':test,'binary':str(binary),'binary_sha256':record['binary_sha256'],'source_commit':record['head'],'source_sha256':record['source_sha256'],'command':args,'completed':False,'scope':'Only a newly created private fixture and its canary; deterministic stopped shell retains its PID across exec of the real test binary. No debugger or process-memory inspection.'}
start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='qpi-',dir='/tmp') as directory:
    root=Path(directory).resolve();root.chmod(0o700)
    temporary=root/'temporary';temporary.mkdir(mode=0o700)
    victim=root/'owned-canary';victim.mkdir(mode=0o700)
    canary=victim/'accept-wait.sock';payload=b'owned regression canary\n';canary.write_bytes(payload);canary.chmod(0o600)
    selected=dict(env,TMPDIR=str(temporary))
    with (output/'stdout').open('wb') as stdout,(output/'stderr').open('wb') as stderr:
        child=subprocess.Popen(args,env=selected,cwd=record['source'],stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            waited,status=os.waitpid(child.pid,os.WUNTRACED)
            assert waited==child.pid and os.WIFSTOPPED(status) and os.WSTOPSIG(status)==signal.SIGSTOP
            alias=temporary/f'qperiapt-accept-wait-{child.pid}';alias.symlink_to(victim,target_is_directory=True)
            assert alias.resolve()==victim and canary.read_bytes()==payload
            os.kill(child.pid,signal.SIGCONT)
            code=child.wait(timeout=30)
        except BaseException:
            if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise
    stdout=(output/'stdout').read_text();stderr=(output/'stderr').read_text()
    exists=canary.exists();preserved=exists and canary.is_file() and canary.read_bytes()==payload
    result.update(completed=code==0 and 'test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout and not stderr,returncode=code,canary_preserved=preserved,canary_exists=exists,alias_still_symlink=alias.is_symlink(),seconds=time.monotonic()-start)
(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'completed':result['completed'],'canary_preserved':result['canary_preserved'],'returncode':result['returncode']}))
assert result['completed'], 'real IPC test did not pass; preserved stdout/stderr and canary observation'
