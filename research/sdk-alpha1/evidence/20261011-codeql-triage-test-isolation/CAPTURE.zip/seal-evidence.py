from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path(__file__).resolve().parent
main=base.parent.parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()
assert head=='4d17b09d76a70f0941dc4e5b2b6ac54aae64ad2e'
assert head in (base/'source-gate.stdout').read_text() and 'SDK_SOURCE_READINESS_PASS' in (base/'source-gate.stdout').read_text()
for name in ('agent-final-build','agent-msrv-build','agent-clippy-final','agent-msrv-clippy'):
    r=json.loads((base/(name+'.json')).read_text());assert r['completed'] and r['head']==head
for name in ('agent-final-tests','agent-msrv-tests','ipc-old-short','ipc-final','ipc-msrv'):
    r=json.loads((base/name/'RESULT.json').read_text());assert r['completed']
assert not json.loads((base/'ipc-old-short/RESULT.json').read_text())['canary_preserved']
assert all(json.loads((base/name/'RESULT.json').read_text())['canary_preserved'] for name in ('ipc-final','ipc-msrv'))
output=main/'research/sdk-alpha1/evidence/20261011-codeql-triage-test-isolation';output.mkdir(parents=True,exist_ok=False)
files=[]
for name in ('agent-final-tests','agent-msrv-tests','ipc-old-short','ipc-final','ipc-msrv','ipc-old'):
    for p in (base/name).iterdir():
        assert p.is_file() and not p.is_symlink();files.append((p,name+'/'+p.name))
for name in ('agent-old-build','agent-final-build','agent-msrv-build','agent-clippy-final','agent-msrv-clippy'):
    for extension in ('json','stdout','stderr'):
        files.append((base/(name+'.'+extension),name+'.'+extension))
for name in ('TRIAGE.json','IR_CHECK.json','peer-mutation-function.ll','peer-mutation-release.asm','compile.stdout','compile.stderr','run-ipc-isolation.py','run-agent-tests.py','build-agent.py','seal-evidence.py','source-gate.stdout','source-gate.stderr'):
    files.append((base/name,name))
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,name in sorted(files,key=lambda row:row[1]):z.write(p,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
checks={'source_commit':head,'completed':True,'release_claim_eligible':False,'scope':'Initial CodeQL alert triage and private ownership of policy-agent IPC/activation test sockets; not complete security adjudication.',
'fixed_behavior':'Old actual accept-wait test passes but deletes a canary through a preplaced predictable-directory symlink. Exclusive TempDir preserves the canary while the same test passes. Related activation fixtures retain private short directories and check cleanup.',
'validation':{'actual_canary_reproduction':'old return 0/canary lost; final Rust 1.98.1 and 1.90.0 return 0/canary preserved','targeted_tests_per_toolchain':6,'strict_Clippy':['1.90.0','1.98.1'],'source_gate':'passed','public_input_mutation':'7 overwrites retained in inspected release IR and linked arm64 executable'},
'limits':['Test isolation repair, not a demonstrated production IPC vulnerability','Static C mutation evidence belongs to the inspected macOS arm64 compiler/binary','CodeQL source scan remains at 252eb954 / merge506eaba2, not this local commit','Remaining alert groups require reachability and capability review; no alert dismissed or rule disabled','Initial long-path canary setup exceeded macOS SUN_LEN; the actual old/new comparison uses a fresh private short /tmp fixture','No debugger or live-process memory inspection; only controlled child stop/exec and static disassembly'],
'initial_triage':json.loads((base/'TRIAGE.json').read_text()),
'capture':{'file':'CAPTURE.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)}}
(output/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'capture':checks['capture']}))
