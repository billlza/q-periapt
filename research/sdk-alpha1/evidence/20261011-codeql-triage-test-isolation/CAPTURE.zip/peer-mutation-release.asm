/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qperiapt-account-owner-tjvakd4h/first-credential-installed-release-05/qpc-c-client:
(__TEXT,__text) section
_configured_device_peer_open:
10000a620:	f8 5f bc a9	stp	x24, x23, [sp, #-0x40]!
10000a624:	f6 57 01 a9	stp	x22, x21, [sp, #0x10]
10000a628:	f4 4f 02 a9	stp	x20, x19, [sp, #0x20]
10000a62c:	fd 7b 03 a9	stp	x29, x30, [sp, #0x30]
10000a630:	fd c3 00 91	add	x29, sp, #0x30
10000a634:	09 7c 86 52	mov	w9, #0x33e0
10000a638:	29 00 a0 72	movk	w9, #0x1, lsl #16
10000a63c:	b0 00 00 d0	adrp	x16, 22 ; 0x100020000
10000a640:	10 fa 41 f9	ldr	x16, [x16, #0x3f0] ; literal pool symbol address: ___chkstk_darwin
10000a644:	00 02 3f d6	blr	x16
10000a648:	ff 4f 40 d1	sub	sp, sp, #0x13, lsl #12
10000a64c:	ff 83 0f d1	sub	sp, sp, #0x3e0
10000a650:	f4 03 03 aa	mov	x20, x3
10000a654:	f5 03 01 aa	mov	x21, x1
10000a658:	f3 03 00 aa	mov	x19, x0
10000a65c:	a8 00 00 d0	adrp	x8, 22 ; 0x100020000
10000a660:	08 09 42 f9	ldr	x8, [x8, #0x410] ; literal pool symbol address: ___stack_chk_guard
10000a664:	08 01 40 f9	ldr	x8, [x8]
10000a668:	a8 83 1c f8	stur	x8, [x29, #-0x38]
10000a66c:	f6 c3 08 91	add	x22, sp, #0x230
10000a670:	00 e4 00 6f	movi.2d	v0, #0000000000000000
10000a674:	c0 02 0c ad	stp	q0, q0, [x22, #0x180]
10000a678:	c0 02 0b ad	stp	q0, q0, [x22, #0x160]
10000a67c:	c0 02 0a ad	stp	q0, q0, [x22, #0x140]
10000a680:	c0 02 09 ad	stp	q0, q0, [x22, #0x120]
10000a684:	c0 02 08 ad	stp	q0, q0, [x22, #0x100]
10000a688:	c0 02 07 ad	stp	q0, q0, [x22, #0xe0]
10000a68c:	c0 02 06 ad	stp	q0, q0, [x22, #0xc0]
10000a690:	c0 02 05 ad	stp	q0, q0, [x22, #0xa0]
10000a694:	c0 02 04 ad	stp	q0, q0, [x22, #0x80]
10000a698:	c0 02 03 ad	stp	q0, q0, [x22, #0x60]
10000a69c:	c0 02 02 ad	stp	q0, q0, [x22, #0x40]
10000a6a0:	c0 02 01 ad	stp	q0, q0, [x22, #0x20]
10000a6a4:	c0 06 80 3d	str	q0, [x22, #0x10]
10000a6a8:	68 00 00 d0	adrp	x8, 14 ; 0x100018000
10000a6ac:	00 3d 43 fd	ldr	d0, [x8, #0x678]
10000a6b0:	e0 1b 01 fd	str	d0, [sp, #0x230]
10000a6b4:	28 00 80 52	mov	w8, #0x1
10000a6b8:	e8 3b 02 b9	str	w8, [sp, #0x238]
10000a6bc:	e2 3f 02 b9	str	w2, [sp, #0x23c]
10000a6c0:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a6c4:	21 08 33 91	add	x1, x1, #0xcc2 ; literal pool for: "initiator"
10000a6c8:	c8 42 00 91	add	x8, x22, #0x10
10000a6cc:	e2 4b 40 91	add	x2, sp, #0x12, lsl #12
10000a6d0:	42 5c 30 91	add	x2, x2, #0xc17
10000a6d4:	e0 03 15 aa	mov	x0, x21
10000a6d8:	40 0e 00 94	bl	_peer_config_device
10000a6dc:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a6e0:	21 30 33 91	add	x1, x1, #0xccc ; literal pool for: "responder"
10000a6e4:	f7 0b 40 91	add	x23, sp, #0x2, lsl #12
10000a6e8:	f7 42 11 91	add	x23, x23, #0x450
10000a6ec:	e8 0b 40 91	add	x8, sp, #0x2, lsl #12
10000a6f0:	08 41 11 91	add	x8, x8, #0x450
10000a6f4:	e2 4b 40 91	add	x2, sp, #0x12, lsl #12
10000a6f8:	42 58 11 91	add	x2, x2, #0x456
10000a6fc:	e0 03 15 aa	mov	x0, x21
10000a700:	36 0e 00 94	bl	_peer_config_device
10000a704:	c0 9e c8 3d	ldr	q0, [x22, #0x2270]
10000a708:	c1 a2 c8 3d	ldr	q1, [x22, #0x2280]
10000a70c:	c2 a6 c8 3d	ldr	q2, [x22, #0x2290]
10000a710:	c1 0a 08 ad	stp	q1, q2, [x22, #0x100]
10000a714:	c1 aa c8 3d	ldr	q1, [x22, #0x22a0]
10000a718:	c1 4a 80 3d	str	q1, [x22, #0x120]
10000a71c:	c1 8e c8 3d	ldr	q1, [x22, #0x2230]
10000a720:	c2 92 c8 3d	ldr	q2, [x22, #0x2240]
10000a724:	c3 96 c8 3d	ldr	q3, [x22, #0x2250]
10000a728:	c2 0e 06 ad	stp	q2, q3, [x22, #0xc0]
10000a72c:	c2 9a c8 3d	ldr	q2, [x22, #0x2260]
10000a730:	c2 02 07 ad	stp	q2, q0, [x22, #0xe0]
10000a734:	c0 8a c8 3d	ldr	q0, [x22, #0x2220]
10000a738:	c0 06 05 ad	stp	q0, q1, [x22, #0xa0]
10000a73c:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a740:	21 58 33 91	add	x1, x1, #0xcd6 ; literal pool for: "directory"
10000a744:	c2 c2 04 91	add	x2, x22, #0x130
10000a748:	e0 03 15 aa	mov	x0, x21
10000a74c:	03 04 80 52	mov	w3, #0x20
10000a750:	a5 05 00 94	bl	_enrollment_read
10000a754:	1f 80 00 f1	cmp	x0, #0x20
10000a758:	61 0f 00 54	b.ne	0x10000a944
10000a75c:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a760:	21 80 33 91	add	x1, x1, #0xce0 ; literal pool for: "bootstrap.bundle"
10000a764:	e2 0b 40 91	add	x2, sp, #0x2, lsl #12
10000a768:	42 40 11 91	add	x2, x2, #0x450
10000a76c:	e0 03 15 aa	mov	x0, x21
10000a770:	23 00 a0 52	mov	w3, #0x10000
10000a774:	9c 05 00 94	bl	_enrollment_read
10000a778:	f7 c3 01 f9	str	x23, [sp, #0x380]
10000a77c:	e0 c7 01 f9	str	x0, [sp, #0x388]
10000a780:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a784:	21 c4 33 91	add	x1, x1, #0xcf1 ; literal pool for: "tls-peer"
10000a788:	f7 43 11 91	add	x23, sp, #0x450
10000a78c:	e2 43 11 91	add	x2, sp, #0x450
10000a790:	e0 03 15 aa	mov	x0, x21
10000a794:	03 00 84 52	mov	w3, #0x2000
10000a798:	93 05 00 94	bl	_enrollment_read
10000a79c:	f7 cb 01 f9	str	x23, [sp, #0x390]
10000a7a0:	e0 cf 01 f9	str	x0, [sp, #0x398]
10000a7a4:	81 00 00 d0	adrp	x1, 18 ; 0x10001c000
10000a7a8:	21 e8 33 91	add	x1, x1, #0xcfa ; literal pool for: "tls-peer-name"
10000a7ac:	f7 43 0f 91	add	x23, sp, #0x3d0
10000a7b0:	e2 43 0f 91	add	x2, sp, #0x3d0
10000a7b4:	e0 03 15 aa	mov	x0, x21
10000a7b8:	03 10 80 52	mov	w3, #0x80
10000a7bc:	8a 05 00 94	bl	_enrollment_read
10000a7c0:	f7 d3 01 f9	str	x23, [sp, #0x3a0]
10000a7c4:	e0 d7 01 f9	str	x0, [sp, #0x3a8]
10000a7c8:	74 01 00 b4	cbz	x20, 0x10000a7f4
10000a7cc:	80 06 40 ad	ldp	q0, q1, [x20]
10000a7d0:	c0 06 0c ad	stp	q0, q1, [x22, #0x180]
10000a7d4:	ff 0f 00 f9	str	xzr, [sp, #0x18]
10000a7d8:	e1 c3 08 91	add	x1, sp, #0x230
10000a7dc:	e2 c3 0e 91	add	x2, sp, #0x3b0
10000a7e0:	e3 63 00 91	add	x3, sp, #0x18
10000a7e4:	e4 93 00 91	add	x4, sp, #0x24
10000a7e8:	e0 03 13 aa	mov	x0, x19
10000a7ec:	d8 36 00 94	bl	0x10001834c ; symbol stub for: _qpc_peer_v1_prepare_configured_reopen
10000a7f0:	07 00 00 14	b	0x10000a80c
10000a7f4:	ff 0f 00 f9	str	xzr, [sp, #0x18]
10000a7f8:	e1 c3 08 91	add	x1, sp, #0x230
10000a7fc:	e2 63 00 91	add	x2, sp, #0x18
10000a800:	e3 93 00 91	add	x3, sp, #0x24
10000a804:	e0 03 13 aa	mov	x0, x19
10000a808:	ce 36 00 94	bl	0x100018340 ; symbol stub for: _qpc_peer_v1_prepare_configured
10000a80c:	e8 27 40 b9	ldr	w8, [sp, #0x24]
10000a810:	1f 01 00 6b	cmp	w8, w0
10000a814:	41 09 00 54	b.ne	0x10000a93c
10000a818:	e9 2b 40 b9	ldr	w9, [sp, #0x28]
10000a81c:	3f 01 08 71	cmp	w9, #0x200
10000a820:	e8 08 00 54	b.hi	0x10000a93c
10000a824:	e8 2f 40 b9	ldr	w8, [sp, #0x2c]
10000a828:	1f 09 00 71	cmp	w8, #0x2
10000a82c:	82 08 00 54	b.hs	0x10000a93c
10000a830:	c0 08 00 35	cbnz	w0, 0x10000a948
10000a834:	08 01 09 2a	orr	w8, w8, w9
10000a838:	a8 08 00 35	cbnz	w8, 0x10000a94c
10000a83c:	f3 0f 40 f9	ldr	x19, [sp, #0x18]
10000a840:	93 08 00 b4	cbz	x19, 0x10000a950
10000a844:	e0 4b 40 91	add	x0, sp, #0x12, lsl #12
10000a848:	00 5c 30 91	add	x0, x0, #0xc17
10000a84c:	21 f8 80 52	mov	w1, #0x7c1
10000a850:	66 35 00 94	bl	0x100017de8 ; symbol stub for: _bzero
10000a854:	e0 4b 40 91	add	x0, sp, #0x12, lsl #12
10000a858:	00 58 11 91	add	x0, x0, #0x456
10000a85c:	21 f8 80 52	mov	w1, #0x7c1
10000a860:	62 35 00 94	bl	0x100017de8 ; symbol stub for: _bzero
10000a864:	e0 0b 40 91	add	x0, sp, #0x2, lsl #12
10000a868:	00 40 11 91	add	x0, x0, #0x450
10000a86c:	21 00 a0 52	mov	w1, #0x10000
10000a870:	5e 35 00 94	bl	0x100017de8 ; symbol stub for: _bzero
10000a874:	e0 43 11 91	add	x0, sp, #0x450
10000a878:	01 00 84 52	mov	w1, #0x2000
10000a87c:	5b 35 00 94	bl	0x100017de8 ; symbol stub for: _bzero
10000a880:	00 e4 00 6f	movi.2d	v0, #0000000000000000
10000a884:	c0 02 10 ad	stp	q0, q0, [x22, #0x200]
10000a888:	c0 02 0f ad	stp	q0, q0, [x22, #0x1e0]
10000a88c:	c0 02 0e ad	stp	q0, q0, [x22, #0x1c0]
10000a890:	c0 02 0d ad	stp	q0, q0, [x22, #0x1a0]
10000a894:	c0 02 0c ad	stp	q0, q0, [x22, #0x180]
10000a898:	c0 02 00 ad	stp	q0, q0, [x22]
10000a89c:	c0 02 01 ad	stp	q0, q0, [x22, #0x20]
10000a8a0:	c0 02 02 ad	stp	q0, q0, [x22, #0x40]
10000a8a4:	c0 02 03 ad	stp	q0, q0, [x22, #0x60]
10000a8a8:	c0 02 04 ad	stp	q0, q0, [x22, #0x80]
10000a8ac:	c0 02 05 ad	stp	q0, q0, [x22, #0xa0]
10000a8b0:	c0 02 06 ad	stp	q0, q0, [x22, #0xc0]
10000a8b4:	c0 02 07 ad	stp	q0, q0, [x22, #0xe0]
10000a8b8:	c0 02 08 ad	stp	q0, q0, [x22, #0x100]
10000a8bc:	c0 02 09 ad	stp	q0, q0, [x22, #0x120]
10000a8c0:	c0 02 0a ad	stp	q0, q0, [x22, #0x140]
10000a8c4:	c0 02 0b ad	stp	q0, q0, [x22, #0x160]
10000a8c8:	e1 93 00 91	add	x1, sp, #0x24
10000a8cc:	e0 03 13 aa	mov	x0, x19
10000a8d0:	72 36 00 94	bl	0x100018298 ; symbol stub for: _qpc_owner_v1_finish_open
10000a8d4:	e8 27 40 b9	ldr	w8, [sp, #0x24]
10000a8d8:	1f 01 00 6b	cmp	w8, w0
10000a8dc:	21 03 00 54	b.ne	0x10000a940
10000a8e0:	e9 2b 40 b9	ldr	w9, [sp, #0x28]
10000a8e4:	3f 01 08 71	cmp	w9, #0x200
10000a8e8:	c8 02 00 54	b.hi	0x10000a940
10000a8ec:	e8 2f 40 b9	ldr	w8, [sp, #0x2c]
10000a8f0:	1f 09 00 71	cmp	w8, #0x2
10000a8f4:	62 02 00 54	b.hs	0x10000a940
10000a8f8:	e0 02 00 35	cbnz	w0, 0x10000a954
10000a8fc:	08 01 09 2a	orr	w8, w8, w9
10000a900:	c8 02 00 35	cbnz	w8, 0x10000a958
10000a904:	e0 0f 40 f9	ldr	x0, [sp, #0x18]
10000a908:	a8 83 5c f8	ldur	x8, [x29, #-0x38]
10000a90c:	a9 00 00 d0	adrp	x9, 22 ; 0x100020000
10000a910:	29 09 42 f9	ldr	x9, [x9, #0x410] ; literal pool symbol address: ___stack_chk_guard
10000a914:	29 01 40 f9	ldr	x9, [x9]
10000a918:	3f 01 08 eb	cmp	x9, x8
10000a91c:	a1 03 00 54	b.ne	0x10000a990
10000a920:	ff 4f 40 91	add	sp, sp, #0x13, lsl #12
10000a924:	ff 83 0f 91	add	sp, sp, #0x3e0
10000a928:	fd 7b 43 a9	ldp	x29, x30, [sp, #0x30]
10000a92c:	f4 4f 42 a9	ldp	x20, x19, [sp, #0x20]
10000a930:	f6 57 41 a9	ldp	x22, x21, [sp, #0x10]
10000a934:	f8 5f c4 a8	ldp	x24, x23, [sp], #0x40
10000a938:	c0 03 5f d6	ret
10000a93c:	97 2b 00 94	bl	_main.cold.51
10000a940:	96 2b 00 94	bl	_main.cold.51
10000a944:	2d 2c 00 94	bl	_main.cold.103
10000a948:	a9 00 00 35	cbnz	w9, 0x10000a95c
10000a94c:	77 2b 00 94	bl	_main.cold.44
10000a950:	69 30 00 94	bl	_configured_device_peer_open.cold.5
10000a954:	49 00 00 35	cbnz	w9, 0x10000a95c
10000a958:	74 2b 00 94	bl	_main.cold.44
10000a95c:	a8 00 00 d0	adrp	x8, 22 ; 0x100020000
10000a960:	08 0d 42 f9	ldr	x8, [x8, #0x418] ; literal pool symbol address: ___stderrp
10000a964:	08 01 40 f9	ldr	x8, [x8]
10000a968:	ea 93 00 91	add	x10, sp, #0x24
10000a96c:	4a 31 00 91	add	x10, x10, #0xc
10000a970:	e9 ab 00 a9	stp	x9, x10, [sp, #0x8]
10000a974:	e0 03 00 f9	str	x0, [sp]
10000a978:	81 00 00 f0	adrp	x1, 19 ; 0x10001d000
10000a97c:	21 8c 00 91	add	x1, x1, #0x23 ; literal pool for: "C owner status %d: %.*s\n"
10000a980:	e0 03 08 aa	mov	x0, x8
10000a984:	37 35 00 94	bl	0x100017e60 ; symbol stub for: _fprintf
10000a988:	20 00 80 52	mov	w0, #0x1
10000a98c:	20 35 00 94	bl	0x100017e0c ; symbol stub for: _exit
10000a990:	13 35 00 94	bl	0x100017ddc ; symbol stub for: ___stack_chk_fail
