from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path(__file__).resolve().parent
label,build_file=sys.argv[1:3];record=json.loads((base/build_file).read_text());assert record['completed']
binary=Path(record['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==record['binary_sha256']
output=base/label;output.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))}
result={'source_commit':record['head'],'binary':str(binary),'binary_sha256':record['binary_sha256'],'runs':[],'completed':False}
for name,selector,expected in [('activation','activation::tests::',5),('ipc','ipc::tests::the_accept_wait_times_out_when_idle_and_reports_a_waiting_client',1)]:
 args=[str(binary),selector,'--nocapture','--test-threads=1']
 if name=='ipc':args.insert(1,'--exact')
 start=time.monotonic()
 with (output/(name+'.stdout')).open('wb') as so,(output/(name+'.stderr')).open('wb') as se:
  p=subprocess.run(args,cwd=record['source'],env=env,stdout=so,stderr=se,timeout=30)
 text=(output/(name+'.stdout')).read_text();error=(output/(name+'.stderr')).read_text()
 result['runs'].append({'command':args,'returncode':p.returncode,'seconds':time.monotonic()-start,'expected_tests':expected})
 (output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 assert p.returncode==0 and f'test result: ok. {expected} passed; 0 failed; 0 ignored;' in text and not error
assert hashlib.sha256(binary.read_bytes()).hexdigest()==record['binary_sha256']
result['completed']=True;(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'completed':True,'tests':6}))
