define internal fastcc i64 @configured_device_peer_open(i64 noundef range(i64 1, 0) %0, ptr noundef %1, i32 noundef range(i32 0, 3) %2, ptr noundef readonly captures(address_is_null) %3) unnamed_addr #0 {
  %5 = alloca [1985 x i8], align 1
  %6 = alloca [1985 x i8], align 1
  %7 = alloca [65536 x i8], align 1
  %8 = alloca [8192 x i8], align 1
  %9 = alloca [128 x i8], align 1
  %10 = alloca [32 x i8], align 1
  %11 = alloca %struct.qpc_peer_configuration_v1, align 8
  %12 = alloca %struct.qpc_peer_device_v1, align 8
  %13 = alloca i64, align 8
  %14 = alloca %struct.qpc_error_v1, align 4
  call void @llvm.lifetime.start.p0(i64 1985, ptr nonnull %5) #18
  call void @llvm.lifetime.start.p0(i64 1985, ptr nonnull %6) #18
  call void @llvm.lifetime.start.p0(i64 65536, ptr nonnull %7) #18
  call void @llvm.lifetime.start.p0(i64 8192, ptr nonnull %8) #18
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %9) #18
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %10) #18
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %10, i8 0, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 384, ptr nonnull %11) #18
  %15 = getelementptr inbounds nuw i8, ptr %11, i64 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(368) %15, i8 0, i64 368, i1 false)
  store <2 x i32> <i32 384, i32 1>, ptr %11, align 8, !tbaa !25
  %16 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store i32 1, ptr %16, align 8, !tbaa !151
  %17 = getelementptr inbounds nuw i8, ptr %11, i64 12
  store i32 %2, ptr %17, align 4, !tbaa !156
  call fastcc void @peer_config_device(ptr dead_on_unwind writable sret(%struct.qpc_peer_device_v1) align 8 %15, ptr noundef %1, ptr noundef nonnull @.str.675, ptr noundef %5)
  %18 = getelementptr inbounds nuw i8, ptr %11, i64 160
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %12) #18
  call fastcc void @peer_config_device(ptr dead_on_unwind writable sret(%struct.qpc_peer_device_v1) align 8 %12, ptr noundef %1, ptr noundef nonnull @.str.676, ptr noundef %6)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(144) %18, ptr noundef nonnull align 8 dereferenceable(144) %12, i64 144, i1 false), !tbaa.struct !157
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %12) #18
  %19 = getelementptr inbounds nuw i8, ptr %11, i64 304
  %20 = call fastcc i64 @enrollment_read(ptr noundef %1, ptr noundef nonnull @.str.677, ptr noundef nonnull %19, i64 noundef 32)
  %21 = icmp eq i64 %20, 32
  br i1 %21, label %23, label %22

22:                                               ; preds = %4
  call void @configured_device_peer_open.cold.1() #17
  unreachable

23:                                               ; preds = %4
  %24 = getelementptr inbounds nuw i8, ptr %11, i64 336
  %25 = call fastcc i64 @enrollment_read(ptr noundef %1, ptr noundef nonnull @.str.678, ptr noundef %7, i64 noundef 65536)
  store ptr %7, ptr %24, align 8, !tbaa !6
  %26 = getelementptr inbounds nuw i8, ptr %11, i64 344
  store i64 %25, ptr %26, align 8, !tbaa !26
  %27 = getelementptr inbounds nuw i8, ptr %11, i64 352
  %28 = call fastcc i64 @enrollment_read(ptr noundef %1, ptr noundef nonnull @.str.679, ptr noundef %8, i64 noundef 8192)
  store ptr %8, ptr %27, align 8, !tbaa !6
  %29 = getelementptr inbounds nuw i8, ptr %11, i64 360
  store i64 %28, ptr %29, align 8, !tbaa !26
  %30 = getelementptr inbounds nuw i8, ptr %11, i64 368
  %31 = call fastcc i64 @enrollment_read(ptr noundef %1, ptr noundef nonnull @.str.680, ptr noundef %9, i64 noundef 128)
  store ptr %9, ptr %30, align 8, !tbaa !6
  %32 = getelementptr inbounds nuw i8, ptr %11, i64 376
  store i64 %31, ptr %32, align 8, !tbaa !26
  %33 = icmp eq ptr %3, null
  br i1 %33, label %36, label %34

34:                                               ; preds = %23
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %10, ptr noundef nonnull align 1 dereferenceable(32) %3, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %13) #18
  store i64 0, ptr %13, align 8, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 524, ptr nonnull %14) #18
  %35 = call i32 @qpc_peer_v1_prepare_configured_reopen(i64 noundef %0, ptr noundef nonnull %11, ptr noundef nonnull %10, ptr noundef nonnull %13, ptr noundef nonnull %14) #18
  br label %38

36:                                               ; preds = %23
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %13) #18
  store i64 0, ptr %13, align 8, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 524, ptr nonnull %14) #18
  %37 = call i32 @qpc_peer_v1_prepare_configured(i64 noundef %0, ptr noundef nonnull %11, ptr noundef nonnull %13, ptr noundef nonnull %14) #18
  br label %38

38:                                               ; preds = %36, %34
  %39 = phi i32 [ %35, %34 ], [ %37, %36 ]
  %40 = load i32, ptr %14, align 4, !tbaa !12
  %41 = icmp eq i32 %40, %39
  br i1 %41, label %42, label %50

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %14, i64 4
  %44 = load i32, ptr %43, align 4, !tbaa !15
  %45 = icmp ugt i32 %44, 512
  br i1 %45, label %50, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %14, i64 8
  %48 = load i32, ptr %47, align 4, !tbaa !16
  %49 = icmp ugt i32 %48, 1
  br i1 %49, label %50, label %51

50:                                               ; preds = %38, %42, %46
  call void @configured_device_peer_open.cold.6() #17
  unreachable

51:                                               ; preds = %46
  %52 = icmp eq i32 %39, 0
  br i1 %52, label %53, label %56

53:                                               ; preds = %51
  %54 = or i32 %48, %44
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %63, label %58

56:                                               ; preds = %51
  %57 = icmp eq i32 %44, 0
  br i1 %57, label %58, label %59

58:                                               ; preds = %53, %56
  call void @configured_device_peer_open.cold.2() #17
  unreachable

59:                                               ; preds = %56
  %60 = load ptr, ptr @__stderrp, align 8, !tbaa !17
  %61 = getelementptr inbounds nuw i8, ptr %14, i64 12
  %62 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %60, ptr noundef nonnull @.str.717, i32 noundef %39, i32 noundef %44, ptr noundef nonnull %61) #18
  call void @exit(i32 noundef 1) #19
  unreachable

63:                                               ; preds = %53
  %64 = load i64, ptr %13, align 8, !tbaa !27
  %65 = icmp eq i64 %64, 0
  br i1 %65, label %66, label %67

66:                                               ; preds = %63
  call void @configured_device_peer_open.cold.5() #17
  unreachable

67:                                               ; preds = %63
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(1985) %5, i8 0, i64 1985, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(1985) %6, i8 0, i64 1985, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(65536) %7, i8 0, i64 65536, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(8192) %8, i8 0, i64 8192, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(128) %9, i8 0, i64 128, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %10, i8 0, i64 32, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(384) %11, i8 0, i64 384, i1 false)
  %68 = call i32 @qpc_owner_v1_finish_open(i64 noundef %64, ptr noundef nonnull %14) #18
  %69 = load i32, ptr %14, align 4, !tbaa !12
  %70 = icmp eq i32 %69, %68
  br i1 %70, label %71, label %77

71:                                               ; preds = %67
  %72 = load i32, ptr %43, align 4, !tbaa !15
  %73 = icmp ugt i32 %72, 512
  br i1 %73, label %77, label %74

74:                                               ; preds = %71
  %75 = load i32, ptr %47, align 4, !tbaa !16
  %76 = icmp ugt i32 %75, 1
  br i1 %76, label %77, label %78

77:                                               ; preds = %67, %71, %74
  call void @configured_device_peer_open.cold.4() #17
  unreachable

78:                                               ; preds = %74
  %79 = icmp eq i32 %68, 0
  br i1 %79, label %80, label %83

80:                                               ; preds = %78
  %81 = or i32 %75, %72
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %90, label %85

83:                                               ; preds = %78
  %84 = icmp eq i32 %72, 0
  br i1 %84, label %85, label %86

85:                                               ; preds = %80, %83
  call void @configured_device_peer_open.cold.3() #17
  unreachable

86:                                               ; preds = %83
  %87 = load ptr, ptr @__stderrp, align 8, !tbaa !17
  %88 = getelementptr inbounds nuw i8, ptr %14, i64 12
  %89 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %87, ptr noundef nonnull @.str.717, i32 noundef %68, i32 noundef %72, ptr noundef nonnull %88) #18
  call void @exit(i32 noundef 1) #19
  unreachable

90:                                               ; preds = %80
  %91 = load i64, ptr %13, align 8, !tbaa !27
  call void @llvm.lifetime.end.p0(i64 524, ptr nonnull %14) #18
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %13) #18
  call void @llvm.lifetime.end.p0(i64 384, ptr nonnull %11) #18
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %10) #18
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %9) #18
  call void @llvm.lifetime.end.p0(i64 8192, ptr nonnull %8) #18
  call void @llvm.lifetime.end.p0(i64 65536, ptr nonnull %7) #18
  call void @llvm.lifetime.end.p0(i64 1985, ptr nonnull %6) #18
  call void @llvm.lifetime.end.p0(i64 1985, ptr nonnull %5) #18
  ret i64 %91
}
