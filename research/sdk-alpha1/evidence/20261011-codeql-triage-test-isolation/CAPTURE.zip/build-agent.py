from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main/'target/peer-account-retirement-process-current/source'
label,version,mode=sys.argv[1:4];assert mode in ('build','clippy') and version in ('1.98.1','1.90.0')
root=Path(json.loads((main/'target/managed-enrollment-current/RESULT.json').read_text())['outside'])
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/(version+'-aarch64-apple-darwin')
assert subprocess.check_output(['git','status','--porcelain'],cwd=src)==b''
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/('agent-triage-build' if version=='1.98.1' else 'agent-triage-msrv')),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
args=[str(tc/'bin/cargo'),'test' if mode=='build' else 'clippy','-p','q-periapt-policy-agent']
args += ['--lib','--no-run','--message-format=json'] if mode=='build' else ['--all-targets']
args += ['--locked','--offline','-j','2']
record={'source':str(src),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'source_sha256':hashlib.sha256((src/'services/q-periapt-policy-agent/src/ipc.rs').read_bytes()).hexdigest(),'command':args,'completed':False}
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:
 p=subprocess.Popen(args,cwd=src,env=env,stdout=so,stderr=se,start_new_session=True)
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise
record.update(returncode=code,seconds=time.monotonic()-start)
if code==0:
 if mode=='build':
  rows=[json.loads(line) for line in (out/(label+'.stdout')).read_text().splitlines()];binaries=[x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='q_periapt_policy_agent' and x.get('profile',{}).get('test') and x.get('executable')];assert len(binaries)==1
  record['binary']=binaries[0];record['binary_sha256']=hashlib.sha256(Path(binaries[0]).read_bytes()).hexdigest()
 record['completed']=True
assert hashlib.sha256((src/'services/q-periapt-policy-agent/src/ipc.rs').read_bytes()).hexdigest()==record['source_sha256']
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('command','source_sha256')}));assert record['completed']
