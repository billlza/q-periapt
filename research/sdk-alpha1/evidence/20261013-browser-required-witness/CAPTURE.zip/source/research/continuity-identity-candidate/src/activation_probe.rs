//! Isolated test adapter: all authority comes from real signed public inputs.
use super::*;
use crate::{AccountPin,PolicyPin,PolicyCheckpoint,RosterCheckpoint,VerifiedSessionPolicy,InstallationPreparation,PrekeyId,LeafKind};
use serde_json::{Value,json};
use std::sync::Arc;
fn bytes(value:&Value,name:&str)->Result<Vec<u8>,DurableError>{serde_json::from_value(value.get(name).ok_or(crate::Error::Encoding)?.clone()).map_err(|_|crate::Error::Encoding.into())}
fn array(value:&Value,name:&str)->Result<[u8;32],DurableError>{bytes(value,name)?.try_into().map_err(|_|crate::Error::Encoding.into())}
fn number(value:&Value,name:&str)->Result<u64,DurableError>{value.get(name).and_then(Value::as_u64).ok_or_else(||crate::Error::Encoding.into())}
fn parse(text:&str)->Result<Value,DurableError>{if text.len()>131072{return Err(DurableError::Capacity)}serde_json::from_str(text).map_err(|_|crate::Error::Encoding.into())}
fn policy(config:&Value,kind:&str,now:u64)->Result<VerifiedSessionPolicy,DurableError>{
 let state=q_periapt_policy::TrustedPolicyState::decode(&bytes(config,"sdk_state")?).map_err(|_|crate::Error::Encoding)?;
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(config,"sdk_policy")?,&bytes(config,"sdk_signature")?,&bytes(config,"sdk_root")?,Some(&state),q_periapt_sdk::Limits::default()).map_err(crate::Error::from)?;
 let statement=config.get("policies").and_then(|value|value.get(kind)).ok_or(crate::Error::Encoding)?;
 let pin=PolicyPin::new(array(config,"family")?,PublicKey::decode(&bytes(config,"policy_root")?)?,PolicyCheckpoint::from_trusted_state(number(statement,"version")?,array(statement,"digest")?)?)?;
 Ok(pin.verify(&bytes(statement,"wire")?,Arc::new(runtime),now)?)
}
async fn run(mut enrollment:DeviceEnrollment,config:&Value,grant:&Value,phase:&str,kind:&str,now:u64,cancel:crate::Cancellation)->Result<Value,DurableError>{
 let policy=policy(config,kind,now)?;
 let pin=AccountPin::new(array(config,"account")?,PublicKey::decode(&bytes(config,"root")?)?,RosterCheckpoint::from_trusted_state(number(grant,"version")?,array(grant,"digest")?)?,array(config,"family")?)?;
 let journal=enrollment.accept(&bytes(grant,"certificate")?,&bytes(grant,"roster")?,&pin,&policy,now).await?;
 match phase {
  "accept" => Ok(json!({"phase":"accepted","journal":journal.as_bytes()})),
  "prepare" => match enrollment.prepare(&policy,now).await? {
    InstallationPreparation::Local => Ok(json!({"phase":"prepared-local","journal":journal.as_bytes()})),
    InstallationPreparation::RequiresEnrollment(genesis) => Ok(json!({"phase":"requires-witness-enrollment","journal":journal.as_bytes(),"genesis":genesis.image_digest(),"subject":genesis.subject().to_bytes()})),
  },
  "activate" | "activate-only" => {
    if config.get("cancel_before").and_then(Value::as_bool)==Some(true) {cancel.cancel();}
    let anchor=if kind=="required" {
      let endpoint=config.get("endpoint").and_then(Value::as_str).ok_or(crate::Error::Encoding)?;
      let carrier=crate::AnchorFetchTransport::for_loopback(endpoint,cancel)?;
      let pin=crate::AnchorPin::new(crate::AnchorIdentity::from_trusted_state(array(config,"witness_id")?)?,PublicKey::decode(&bytes(config,"witness_public")?)?);
      Some(enrollment.anchor_client(&policy,now,pin,Box::new(carrier),std::time::Duration::from_millis(number(config,"timeout_ms")?)).await?)
    } else {None};
    let mut active=enrollment.activate(&policy,now,anchor).await?;
    let (service,signer,device)=active.parts()?;signer.check_device(device)?;
    let (store,archives)=service.stores()?;
    if store.identity()?!=journal{return Err(DurableError::Conflict)}
    if phase=="activate-only" { let result=json!({"phase":"active-only","journal":journal.as_bytes()}); active.close();policy.close();return Ok(result); }
    let public=store.generate_prekey(&policy,device,PrekeyId::from_trusted_state([55;32])?,LeafKind::OneTimePq,Validity::new(number(config,"from")?,number(config,"until")?)?,now).await?;
    let value=json!({"phase":"active","journal":journal.as_bytes(),"prekey":public.public_key(),"archive_count":archives.session_ids()?.len()});
    active.close();policy.close();Ok(value)
  },
  _ => Err(crate::Error::State.into()),
 }
}
/// Test the shared owner; never imports private fixture keys or supplies a policy digest alone.
#[wasm_bindgen]
pub async fn activation_step(name:String,id:String,config:String,grant:String,phase:String,now:u64,cancel:&WitnessCancellation)->Result<String,JsValue>{
 let config=parse(&config).map_err(js)?;let grant=parse(&grant).map_err(js)?;
 let root=bytes(&config,"root").map_err(js)?;let description=bytes(&config,"description").map_err(js)?;
 let owner=BrowserEnrollmentProbe::open(name,id,root,description).await?;
 let enrollment=owner.enrollment.borrow_mut().take().ok_or_else(||js(DurableError::Closed))?;
 let result=run(enrollment,&config,&grant,&phase,"required",now,cancel.inner.clone()).await;
 let cleanup=owner.close().await;
 match (result,cleanup) {
  (Ok(value),Ok(()))=>Ok(value.to_string()),
  (Err(error),Ok(()))=>Err(js(error)),
  (Ok(_),Err(error))=>Err(error),
  (Err(primary),Err(cleanup))=>Err(Storage::combine_failures(&js(primary),&cleanup)),
 }
}

/// Isolated binding for the shared one-way cancellation signal.
#[wasm_bindgen]
pub struct WitnessCancellation { inner: crate::Cancellation }
#[wasm_bindgen]
impl WitnessCancellation {
    /// Create a fresh signal for this operation.
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self { Self { inner: crate::Cancellation::default() } }
    /// Request cancellation; no statement about remote commitment is made.
    pub fn cancel(&self) { self.inner.cancel(); }
}

/// Poll the actual carrier once, then drop its pending Rust future.
#[wasm_bindgen]
pub fn drop_fetch(endpoint:String)->Result<(),JsValue>{
    use crate::AnchorTransport;
    use std::future::Future;
    let mut transport=crate::AnchorFetchTransport::for_loopback(&endpoint,crate::Cancellation::default()).map_err(|e|JsValue::from_str(&e.to_string()))?;
    let bytes=[0u8;3674];
    let mut future=Box::pin(transport.exchange(&bytes,crate::MonotonicInstant::now()+std::time::Duration::from_secs(5)));
    let mut context=std::task::Context::from_waker(std::task::Waker::noop());
    if future.as_mut().poll(&mut context).is_ready(){return Err(JsValue::from_str("carrier did not suspend"))}
    drop(future);Ok(())
}
