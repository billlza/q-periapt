async page => {
  const result = await page.evaluate(async () => {
    const { witnessEndpoint, WitnessExchange } = await import('/pkg/witness-fetch.js');
    const rows=[];
    for (const [url,loopback,expected] of [
      ['https://example.com/witness',false,'https://example.com/witness'],
      ['http://127.0.0.1:8080/witness',true,'http://127.0.0.1:8080/witness'],
      ['http://[::1]:8080/witness',true,'http://[::1]:8080/witness'],
      ['http://127.0.0.1/witness',false,'InvalidEndpoint'],
      ['http://example.com/witness',true,'InvalidEndpoint'],
      ['https://example.com/witness',true,'InvalidEndpoint'],
      ['https://user:secret@example.com/witness',false,'InvalidEndpoint'],
      ['https://example.com/witness#secret',false,'InvalidEndpoint'],
      ['/witness',false,'InvalidEndpoint'],['file:///witness',false,'InvalidEndpoint']]) {
      let actual;try{actual=witnessEndpoint(url,loopback)}catch(error){actual=error.code}
      if(actual!==expected)throw Error('endpoint validation: '+rows.length);rows.push({loopback,expected,actual});
    }
    document.cookie='ambient_carrier_control=present; Path=/carrier/; SameSite=Strict';
    const frames=[];
    for(const [name,expected] of [['status','HttpStatus'],['redirect','Network'],['short','InvalidResponse'],['overflow','InvalidResponse']]){
      const exchange=WitnessExchange.start(new URL('/carrier/'+name,location.origin).href,new Uint8Array(3674),2000,()=>false);
      let actual,status;try{await exchange.reply();actual='accepted'}catch(error){actual=error.code;status=error.status}
      if(actual!==expected || (name==='status' && status!==503))throw Error('carrier control: '+name+' '+actual);
      frames.push({name,actual,status});
    }
    const diagnostics=[];const onerror=event=>diagnostics.push(event.message);const onrejection=event=>diagnostics.push(String(event.reason));
    addEventListener('error',onerror);addEventListener('unhandledrejection',onrejection);
    try{
      const module=await import('/pkg/q_periapt_continuity_identity_candidate.js');await module.default();
      module.drop_fetch(new URL('/carrier/slow',location.origin).href);
      await new Promise(resolve=>setTimeout(resolve,150));
      if(diagnostics.length)throw Error('dropped carrier invoked released callback');
    }finally{removeEventListener('error',onerror);removeEventListener('unhandledrejection',onrejection)}
    return {passed:true,endpoints:rows,frames,dropped_polled_future:true,diagnostics};
  });
  return result;
}
