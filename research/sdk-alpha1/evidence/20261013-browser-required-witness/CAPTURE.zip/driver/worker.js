import init, { BrowserEnrollmentProbe, activation_step, WitnessCancellation } from '../pkg/q_periapt_continuity_identity_candidate.js';
await init();
let token;
self.onmessage = async ({ data }) => {
  if (data.cancel) { if (!token) throw Error('no pending operation'); token.cancel(); postMessage({ cancellation_requested: true }); return; }
  let owner;
  try {
    const response = await fetch('/inputs/' + data.case + '.json'); if (!response.ok) throw Error('public inputs');
    const config = await response.json();
    if (data.operation === 'create') {
      owner = await BrowserEnrollmentProbe.create(data.name, data.id, new Uint8Array(config.root), new Uint8Array(config.description));
      const request = await owner.request(BigInt(Math.floor(Date.now() / 1000)));
      await owner.close(); owner.free(); owner = undefined;
      postMessage({ done: true, value: { request: [...request] } }); return;
    }
    const grantResponse = await fetch('/inputs/' + data.case + '-grant.json'); if (!grantResponse.ok) throw Error('grant');
    const grant = await grantResponse.json();
    config.endpoint = new URL('/witness/' + data.case + '?mode=' + (data.mode ?? 'normal'), location.origin).href;
    config.timeout_ms = data.timeout ?? 5000;
    config.cancel_before = data.cancelBefore ?? false;
    if (data.wrongPin) config.witness_public = config.root;
    token = new WitnessCancellation();
    const result = await activation_step(data.name, data.id, JSON.stringify(config), JSON.stringify(grant), data.phase, BigInt(Math.floor(Date.now() / 1000)), token);
    postMessage({ done: true, value: JSON.parse(result) });
  } catch (error) { postMessage({ done: true, error: String(error), code: error.code }); }
  finally { if (owner) { await owner.close(); owner.free(); } if (token) { token.free(); token = undefined; } }
};
postMessage({ ready: true });
