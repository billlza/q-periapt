from pathlib import Path
base=Path('target/continuity-browser-witness/source/research/continuity-identity-candidate')
p=base/'examples/browser_activation_authority.rs';s=p.read_text()
s=s.replace('''            let witness=p::AnchorSigningKey::provision(&dir.join("private-witness.key"),&wrap,p::SigningKeyId::generate()?)?;
            let pin=p::AnchorPin::new(p::AnchorIdentity::generate()?,witness.public_key()?);''','''            let witness_wrap=p::JournalKey::provision(&dir.join("private-witness-wrap.key"))?;
            let witness_signer=p::SigningKeyId::generate()?;
            let witness=p::AnchorSigningKey::provision(&dir.join("private-witness.key"),&witness_wrap,witness_signer)?;
            let mut witness_store=p::AnchorStore::provision(&dir.join("private-witness.redb"),witness_wrap,witness,p::AnchorIdentity::generate()?)?;
            let pin=witness_store.pin()?;witness_store.close();''')
s=s.replace('"policies":policies}', '"policies":policies,"witness_id":pin.identity().as_bytes(),"witness_public":pin.public_key().encode(),"witness_signer_id":witness_signer.as_bytes()}')
s=s.replace('''        _ => return Err("mode".into()),''','''        "enroll" => {
            if args.len()!=5 { return Err("enroll arguments".into()); }
            let config:Value=serde_json::from_slice(&fs::read(dir.join("PUBLIC.json"))?)?;
            let grant:Value=serde_json::from_slice(&fs::read(args.get(3).ok_or("grant")?)?)?;
            let genesis:Value=serde_json::from_slice(&fs::read(args.get(4).ok_or("genesis")?)?)?;
            let policy=protocol_policy(&config)?;
            let device=p::AccountPin::new(array(&config,"account")?,p::PublicKey::decode(&bytes(&config,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&grant,"version")?,array(&grant,"digest")?)?,array(&config,"family")?)?.verify_device(&bytes(&grant,"certificate")?,&bytes(&grant,"roster")?,now()?)?;
            let journal=p::JournalIdentity::from_trusted_state(array(&genesis,"journal")?)?;
            let subject=p::AnchorSubject::for_device(journal,&device,&policy)?;
            if subject.to_bytes()!=bytes(&genesis,"subject")? { return Err("original genesis subject differs".into()); }
            let mut store=witness(dir,&config)?;
            store.enroll(&p::AnchorGenesis::from_trusted_state(subject,array(&genesis,"genesis")?)?,&device,&policy,now()?)?;
            println!("{}",head(store.browser_probe_head(journal)?));store.close();
        }
        "handle" => {
            if args.len()!=7 { return Err("handle arguments".into()); }
            let config:Value=serde_json::from_slice(&fs::read(dir.join("PUBLIC.json"))?)?;
            let genesis:Value=serde_json::from_slice(&fs::read(args.get(3).ok_or("genesis")?)?)?;
            let request=fs::read(args.get(4).ok_or("request")?)?;
            if request.len()!=3674 { return Err("request width".into()); }
            let journal=p::JournalIdentity::from_trusted_state(array(&genesis,"journal")?)?;
            let mut store=witness(dir,&config)?;let before=store.browser_probe_head(journal)?;
            let reply=store.handle(&request,now()?)?;
            let after=store.browser_probe_head(journal)?;
            let command=store.browser_probe_command(&request)?;
            store.close();
            publish_private_bytes(Path::new(args.get(5).ok_or("reply")?),&reply)?;
            let trace=json!({"before":head(before),"after":head(after),"command":command,"changed":before!=after});
            publish_private_bytes(Path::new(args.get(6).ok_or("trace")?),&serde_json::to_vec_pretty(&trace)?)?;
        }
        _ => return Err("mode".into()),''')
idx=s.index('fn main()')
s=s[:idx]+'''fn array(v:&Value,name:&str)->Result<[u8;32]>{Ok(bytes(v,name)?.try_into()?)}
fn number(v:&Value,name:&str)->Result<u64>{v.get(name).and_then(Value::as_u64).ok_or_else(||"number".into())}
fn head(h:p::AnchorHead)->Value{json!({"revision":h.revision(),"fence":h.fence(),"digest":h.digest()})}
fn protocol_policy(v:&Value)->Result<p::VerifiedSessionPolicy>{
    let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(v,"sdk_policy")?,&bytes(v,"sdk_signature")?,&bytes(v,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
    let policy=v.get("policies").and_then(|v|v.get("required")).ok_or("policy")?;
    let pin=p::PolicyPin::new(array(v,"family")?,p::PublicKey::decode(&bytes(v,"policy_root")?)?,p::PolicyCheckpoint::from_trusted_state(number(policy,"version")?,array(policy,"digest")?)?)?;
    Ok(pin.verify(&bytes(policy,"wire")?,std::sync::Arc::new(runtime),now()?)?)
}
fn witness(dir:&Path,v:&Value)->Result<p::AnchorStore>{
    let key=p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
    let signer=p::AnchorSigningKey::open(&dir.join("private-witness.key"),&key,p::SigningKeyId::from_trusted_state(array(v,"witness_signer_id")?)?)?;
    let store=p::AnchorStore::open(&dir.join("private-witness.redb"),key,signer,p::AnchorIdentity::from_trusted_state(array(v,"witness_id")?)?)?;
    if store.pin()?.public_key().encode()!=bytes(v,"witness_public")? { return Err("witness pin changed".into()); }
    Ok(store)
}
'''+s[idx:];p.write_text(s)
p=base/'src/anchor/store.rs';p.write_text(p.read_text()+'''
// Isolated native readback for the real witness acceptance harness.
#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
impl AnchorStore {
    /// Read authenticated public witness state through its existing owner.
    pub fn browser_probe_head(&mut self, journal: crate::JournalIdentity) -> Result<AnchorHead, DurableError> {
        self.image()?.entries.get(journal.as_bytes()).map(|entry|entry.head).ok_or(DurableError::Absent)
    }
    /// Extract stable public command identity after the caller has handled the signed request.
    pub fn browser_probe_command(&self, wire:&[u8]) -> Result<[u8;32], DurableError> {
        Ok(super::incoming(&self.pin()?,wire)?.command)
    }
}
''')
p=base/'src/activation_probe.rs';s=p.read_text()
s=s.replace('"genesis":genesis.image_digest()', '"genesis":genesis.image_digest(),"subject":genesis.subject().to_bytes()')
s=s.replace('''    let mut active=enrollment.activate(&policy,now,None).await?;''','''    let cancel=crate::Cancellation::default();
    if config.get("cancel_before").and_then(Value::as_bool)==Some(true) {cancel.cancel();}
    let anchor=if kind=="required" {
      let endpoint=config.get("endpoint").and_then(Value::as_str).ok_or(crate::Error::Encoding)?;
      let carrier=crate::AnchorFetchTransport::for_loopback(endpoint,cancel)?;
      let pin=crate::AnchorPin::new(crate::AnchorIdentity::from_trusted_state(array(config,"witness_id")?)?,PublicKey::decode(&bytes(config,"witness_public")?)?);
      Some(enrollment.anchor_client(&policy,now,pin,Box::new(carrier),std::time::Duration::from_millis(number(config,"timeout_ms")?)).await?)
    } else {None};
    let mut active=enrollment.activate(&policy,now,anchor).await?;''')
p.write_text(s)
