//! Actual enrolled-owner outbox capacity; process costs are not isolated SDK memory.
#[path = "/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/research/continuity-identity-candidate/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;
use q_periapt_continuity_identity_candidate as p;
use q_periapt_core::Xof256;
use p::connection_transport::{ConnectionEndpoint, Consumption, Run, Submission};
use observer_peer::{Server, Task};
use serde_json::{json, Value};
use std::{fs, io::Write, path::PathBuf, sync::Arc, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
fn check(value: bool, message: &str) -> Result<()> {
    if value { Ok(()) } else { Err(message.to_owned().into()) }
}
fn body(index: usize, length: usize) -> Vec<u8> {
    (0..length).map(|offset| ((index + offset) % 251) as u8).collect()
}
fn digest(bytes: &[u8]) -> [u8; 32] {
    let mut hash = q_periapt_backends::Sha3_256Xof::new();
    hash.absorb_public(bytes);
    hash.squeeze32()
}
unsafe extern "C" {
    fn qpc_observer_memory(values: *mut u64) -> i32;
    fn qpc_observer_pressure_relief() -> u64;
    fn qpc_observer_regions(values: *mut u64, page_size: *mut u64) -> i32;
}
fn memory(label: &str, path: &std::path::Path) -> Result<Value> {
    let mut regions = [0u64; 256 * 8];
    let mut page_size = 0u64;
    let region_status = unsafe { qpc_observer_regions(regions.as_mut_ptr(), &mut page_size) };
    check(region_status == 0 && page_size > 0, &format!("VM region enumeration failed: {region_status}"))?;
    check(regions.chunks_exact(8).any(|row| row[0] > 0 && row[2] > 0), "empty VM region census")?;
    let mut current = [0u64; 6];
    let status = unsafe { qpc_observer_memory(current.as_mut_ptr()) };
    check(status == 0, &format!("task_info failed: {status}"))?;
    // The observer reads documented OS process counters. No product allocator,
    // entropy source, journal representation or timing interval is replaced.
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    let result = unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) };
    if result != 0 { return Err(std::io::Error::last_os_error().into()); }
    let usage = unsafe { usage.assume_init() };
    Ok(json!({"stage":label,"max_rss_bytes":usage.ru_maxrss,
        "resident_bytes":current[0],"physical_footprint_bytes":current[1],
        "malloc_blocks_in_use":current[2],"malloc_size_in_use_bytes":current[3],
        "malloc_max_size_in_use_bytes":current[4],"malloc_size_allocated_bytes":current[5],
        "vm_page_size_bytes":page_size,"vm_tags":regions.chunks_exact(8).enumerate().filter(|(_,row)|row[0]>0).map(|(tag,row)|json!({
            "tag":tag,"regions":row[0],"virtual_bytes":row[1],"resident_pages":row[2],"dirty_pages":row[3],
            "swapped_pages":row[4],"reusable_pages":row[5],"external_resident_pages":row[6],"internal_pager_resident_pages":row[7]
        })).collect::<Vec<_>>(),
        "journal_file_bytes":fs::metadata(path.join("journal.redb"))?.len()}))
}
fn transmit(client: &mut fixture::Peer, endpoint: &ConnectionEndpoint,
    address: std::net::SocketAddr, session: [u8;32], message: p::MessageId,
    plaintext: &[u8], ad: &[u8]) -> Result<()> {
    let name = client.peer_name.clone();
    let delivered = endpoint.send(client.actor()?, Submission { session, message,
        plaintext, associated_data:ad }, Run { address, server_name:&name,
        limits:p::connection_transport::RunLimits { exchanges:1,..fixture::limits() },
        cancel:&p::Cancellation::default() }, fixture::now)?;
    check(delivered.consumption == Consumption::Confirmed, "peer consumption not confirmed")
}


#[test]
fn measure_journal_capacity() -> Result<()> {
    let profile = std::env::var("QPC_JOURNAL_PROFILE")?;
    check(matches!(profile.as_str(), "local" | "witness"), "unknown journal profile")?;
    let length = p::contract::MAX_PLAINTEXT_BYTES;
    let output = PathBuf::from(std::env::var_os("QPC_JOURNAL_OUTPUT").ok_or("output required")?);
    let root = PathBuf::from(std::env::var_os("QPERIAPT_PUBLIC_SERVICE_EVIDENCE").ok_or("fresh private root required")?);
    check(output.is_absolute() && !output.exists() && root.is_absolute() && !root.exists(), "fresh output and runtime required")?;
    let mut witness = if profile == "witness" { Some(observer_io::Witness::start(&root.with_extension("witness"))?) } else { None };
    let pin = witness.as_ref().map(|w| &w.configured);
    let setup = fixture::setup_enrolled_with_witness(pin)?;
    let mut client = fixture::Peer::open_with_witness(&setup.initiator, pin)?;
    let mut endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
    let server_witness = pin.map(|w| fixture::WitnessFixture { store:Arc::clone(&w.store), address:w.address });
    let mut server = Server::start(setup.responder.clone(), server_witness)?;
    server.begin(Task::Bootstrap)?;
    let name = client.peer_name.clone();
    let established = endpoint.establish(client.actor()?, p::InitiationId::generate()?, Run { address:server.address,
        server_name:&name, limits:fixture::limits(), cancel:&p::Cancellation::default() }, fixture::now)?;
    check(server.finish_operation()?["established"] == json!(established.session), "bootstrap peers differ")?;
    let session = established.session;
    let ad = vec![0x73; p::contract::MAX_ASSOCIATED_DATA_BYTES];
    let epoch_capacity = p::contract::MAX_OUTSTANDING_MESSAGES;
    check(epoch_capacity == 64 && p::contract::MAX_JOURNAL_IMAGE_BYTES == 2*1024*1024, "resource profile changed")?;
    let mut samples = Vec::with_capacity(2*epoch_capacity);
    let mut retained = Vec::with_capacity(2*epoch_capacity);
    let mut resources = vec![memory("established", &setup.initiator)?];
    for index in 0..epoch_capacity {
        let plaintext = body(index, length);
        let journal = client.service.stores()?.0;
        let id = journal.next_message_id(&client.context, session, fixture::now()?)?;
        let start = Instant::now();
        let wire = journal.send_message(&client.context, session, id, &plaintext, &ad, fixture::now()?)?;
        let elapsed = start.elapsed().as_nanos();
        check(journal.message_status(&client.context, session, id)? == p::MessageStatus::Committed, "epoch-zero outbox not committed")?;
        retained.push((id, digest(&wire)));
        samples.push(json!({"index":index,"epoch":0,"epoch_index":index,"message":id.as_bytes(),"wire_sha3_256":digest(&wire),"wire_bytes":wire.len(),"commit_ns":elapsed}));
        drop(wire);
        if [1,16,32,64].contains(&(index+1)) { resources.push(memory(&format!("epoch-zero-retained-{}",index+1),&setup.initiator)?); }
    }
    println!("JOURNAL_CAPACITY_STAGE epoch=0 retained=64");
    server.begin(Task::Rekey {session,target:1})?;
    let start=Instant::now();
    let control=p::control_transport::ControlEndpoint::client(&client.context,session,client.credentials(),fixture::tls_limits())?;
    let (service,signer)=client.service.parts()?;let (journal,_)=service.stores()?;
    let done=control.run(p::control_transport::Session{journal,context:&client.context,signer},p::control_transport::Run{
        target:1,address:server.address,server_name:&client.peer_name,limits:fixture::limits(),cancel:&p::Cancellation::default()},fixture::now)?;
    let rekey_ns=start.elapsed().as_nanos();let peer_rekey=server.finish_operation()?;
    check(done.epoch==1 && peer_rekey["epoch"]==1,"both peers must confirm epoch one with old outboxes retained")?;
    drop(control);
    resources.push(memory("epoch-one-confirmed",&setup.initiator)?);
    println!("JOURNAL_CAPACITY_STAGE epoch_one_confirmed old_retained=64");
    let mut capacity_refusal=None;
    for epoch_index in 0..epoch_capacity {
        let before_attempt=memory("before-aggregate-refusal",&setup.initiator)?;
        let index=epoch_capacity+epoch_index;
        let plaintext=body(index,length);let journal=client.service.stores()?.0;
        let id=journal.next_message_id(&client.context,session,fixture::now()?)?;
        let start=Instant::now();
        match journal.send_message(&client.context,session,id,&plaintext,&ad,fixture::now()?) {
            Ok(wire)=>{
                let elapsed=start.elapsed().as_nanos();
                check(journal.message_status(&client.context,session,id)?==p::MessageStatus::Committed,"epoch-one outbox not committed")?;
                retained.push((id,digest(&wire)));
                samples.push(json!({"index":index,"epoch":1,"epoch_index":epoch_index,"message":id.as_bytes(),"wire_sha3_256":digest(&wire),"wire_bytes":wire.len(),"commit_ns":elapsed}));
                drop(wire);
                if [1,16,32,48].contains(&(epoch_index+1)) {resources.push(memory(&format!("epoch-one-retained-{}",epoch_index+1),&setup.initiator)?);}
            }
            Err(p::DurableError::Capacity)=>{
                check(epoch_index>0,"first epoch-one message unexpectedly full")?;
                println!("JOURNAL_CAPACITY_STAGE capacity_error total={index} epoch_one={epoch_index}");
                // Unlike the per-epoch count preflight, image sealing occurs in
                // persist(). Its failure closes the owner before returning.
                check(matches!(journal.message_status(&client.context,session,id),Err(p::DurableError::Closed)),"persist-capacity failure did not close journal")?;
                resources.push(before_attempt);
                capacity_refusal=Some((id,index,epoch_index));break;
            }
            Err(error)=>return Err(error.into()),
        }
    }
    let (next,total_retained,epoch_one_retained)=capacity_refusal.ok_or("aggregate byte bound not reached before second epoch fills")?;
    check(total_retained==retained.len() && epoch_one_retained<epoch_capacity,"capacity census differs")?;
    resources.push(memory("aggregate-refused-owner-closed",&setup.initiator)?);
    println!("JOURNAL_CAPACITY_STAGE aggregate_full total={total_retained} epoch_one={epoch_one_retained}");
    let witness_at_capacity=match witness.as_ref(){Some(w)=>w.snapshot()?,None=>json!({"requests":0})};
    server.begin(Task::Reopen)?;
    drop(endpoint);client.close();
    client=fixture::Peer::open_with_witness(&setup.initiator,witness.as_ref().map(|w|&w.configured))?;
    endpoint=ConnectionEndpoint::client(&client.context,client.credentials(),fixture::tls_limits())?;
    check(server.finish_operation()?["reopened"]==true,"original responder did not reopen")?;
    resources.push(memory("reopened-aggregate-full",&setup.initiator)?);
    let extra=body(total_retained,length);let journal=client.service.stores()?.0;
    check(journal.next_message_id(&client.context,session,fixture::now()?)?==next,"restart changed next ID")?;
    check(journal.message_status(&client.context,session,next)?==p::MessageStatus::Absent,"first refusal reserved input")?;
    check(matches!(journal.send_message(&client.context,session,next,&extra,&ad,fixture::now()?),Err(p::DurableError::Capacity)),"restart lost aggregate capacity refusal")?;
    check(matches!(journal.message_status(&client.context,session,next),Err(p::DurableError::Closed)),"repeated persist-capacity failure did not close journal")?;
    drop(endpoint);client.close();
    client=fixture::Peer::open_with_witness(&setup.initiator,witness.as_ref().map(|w|&w.configured))?;
    endpoint=ConnectionEndpoint::client(&client.context,client.credentials(),fixture::tls_limits())?;
    let journal=client.service.stores()?.0;
    check(journal.next_message_id(&client.context,session,fixture::now()?)?==next,"second reopen changed next ID")?;
    check(journal.message_status(&client.context,session,next)?==p::MessageStatus::Absent,"repeated refusal reserved input")?;
    resources.push(memory("second-original-reopen",&setup.initiator)?);
    let mut deliveries=Vec::with_capacity(total_retained+1);
    for index in 0..=total_retained {
        let (id,expected)=*retained.get(index).ok_or("original message absent")?;
        let plaintext=body(index,length);let journal=client.service.stores()?.0;
        let wire=journal.send_message(&client.context,session,id,&plaintext,&ad,fixture::now()?)?;
        check(digest(&wire)==expected,"old or current epoch ciphertext changed on replay")?;drop(wire);
        server.begin(Task::Message{fail_after_effect:false})?;
        transmit(&mut client,&endpoint,server.address,session,id,&plaintext,&ad)?;
        let peer=server.finish_operation()?;
        check(peer["effects"]==1 && peer["calls"]==1,"original effect census differs")?;
        check(client.service.stores()?.0.message_status(&client.context,session,id)?==p::MessageStatus::Acknowledged,"ACK not durable")?;
        deliveries.push(json!({"index":index,"message":id.as_bytes(),"peer":peer}));
        if index==0 {
            let journal=client.service.stores()?.0;
            check(journal.next_message_id(&client.context,session,fixture::now()?)?==next,"old epoch ACK replaced original next ID")?;
            let start=Instant::now();let wire=journal.send_message(&client.context,session,next,&extra,&ad,fixture::now()?)?;
            let elapsed=start.elapsed().as_nanos();retained.push((next,digest(&wire)));
            samples.push(json!({"index":total_retained,"epoch":1,"epoch_index":epoch_one_retained,"message":next.as_bytes(),"wire_sha3_256":digest(&wire),"wire_bytes":wire.len(),"commit_ns":elapsed}));
            drop(wire);resources.push(memory("old-epoch-ack-reclaimed-and-refilled",&setup.initiator)?);
        }
    }
    resources.push(memory("all-acknowledged",&setup.initiator)?);
    let server_summary=server.finish()?;
    check(server_summary["effects"]==total_retained+1 && server_summary["calls"]==total_retained+1,"final business census differs")?;
    for (index,(id,_)) in retained.iter().enumerate() {
        let name=id.as_bytes().iter().map(|b|format!("{b:02x}")).collect::<String>();
        let actual=fs::read(setup.responder.join("measured-effects").join(name))?;
        let mut expected=session.to_vec();expected.extend_from_slice(id.as_bytes());expected.extend_from_slice(&body(index,length));
        check(actual==expected,"durable business bytes differ")?;
    }
    client.close();drop(endpoint);drop(client);
    let witness_record=match witness.as_mut(){Some(w)=>w.finish()?,None=>json!({"closed":true,"rows":[]})};drop(witness);
    resources.push(memory("all-owners-closed",&setup.initiator)?);
    for (seconds,delay) in [(1,1),(5,4),(15,10)] {
        std::thread::sleep(std::time::Duration::from_secs(delay));
        resources.push(memory(&format!("closed-idle-{seconds}s"),&setup.initiator)?);
    }
    let pressure_start = Instant::now();
    let pressure_released = unsafe { qpc_observer_pressure_relief() };
    let pressure_elapsed_ns = pressure_start.elapsed().as_nanos();
    resources.push(memory("after-malloc-pressure-relief", &setup.initiator)?);
    let value=json!({"completed":true,"profile":profile,"payload_bytes":length,"associated_data_bytes":ad.len(),
        "epoch_capacity":epoch_capacity,"journal_image_limit_bytes":p::contract::MAX_JOURNAL_IMAGE_BYTES,
        "total_retained_at_refusal":total_retained,"epoch_one_retained":epoch_one_retained,"rejected_message":next.as_bytes(),
        "session":session,"server_open_ns":server.open_ns,"samples":samples,"deliveries":deliveries,"resources":resources,
        "rekey":{"target":1,"elapsed_ns":rekey_ns,"server":peer_rekey},"server":server_summary,
        "witness_at_capacity":witness_at_capacity,"witness":witness_record,
        "aggregate_refused_before_epoch_capacity":true,"persist_capacity_closes_journal":true,"capacity_refused_without_reservation":true,
        "original_owners_reopened_at_capacity":true,"old_epoch_ack_reclaimed_capacity":true,
        "all_replays_exact":true,"all_business_effects_verified":true,"sdk_and_server_closed":true,
        "pressure_probe":{"invoked_after_all_owners_closed":true,"reported_released_bytes":pressure_released,"elapsed_ns":pressure_elapsed_ns},
        "memory_scope":"Darwin whole-process resident/physical footprint and high-water RSS; includes peers, witness and observer; not isolated SDK allocation", "release_claim_eligible":false});
    let mut file=fs::OpenOptions::new().create_new(true).write(true).open(output)?;
    file.write_all(&serde_json::to_vec_pretty(&value)?)?;file.sync_all()?;
    println!("JOURNAL_CAPACITY_COMPLETE profile={profile} retained={total_retained} effects={}",total_retained+1);
    Ok(())
}
