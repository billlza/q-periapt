#include <mach/mach.h>
#include <mach/task_info.h>
#include <stdint.h>
#include <mach/mach_vm.h>
#include <mach/vm_region.h>
#include <mach/vm_statistics.h>
#include <limits.h>
#include <malloc/malloc.h>

int qpc_observer_memory(uint64_t values[6]) {
    task_vm_info_data_t info = {0};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (values == NULL) return KERN_INVALID_ARGUMENT;
    kern_return_t status = task_info(mach_task_self(), TASK_VM_INFO,
                                    (task_info_t)&info, &count);
    if (status != KERN_SUCCESS) return status;
    if (count < TASK_VM_INFO_REV1_COUNT) return KERN_FAILURE;
    values[0] = info.resident_size;
    values[1] = info.phys_footprint;
    malloc_statistics_t allocations = {0};
    malloc_zone_statistics(NULL, &allocations);
    values[2] = allocations.blocks_in_use;
    values[3] = allocations.size_in_use;
    values[4] = allocations.max_size_in_use;
    values[5] = allocations.size_allocated;
    return KERN_SUCCESS;
}

/* Counts only this process. No addresses, paths, contents or object handles
 * are published. Regions may change during enumeration; this is not atomic. */
int qpc_observer_regions(uint64_t values[256 * 8], uint64_t *page_size) {
    if (values == NULL || page_size == NULL) return KERN_INVALID_ARGUMENT;
    *page_size = vm_page_size;
    mach_vm_address_t address = 0;
    natural_t depth = 0;
    for (uint32_t step = 0; step < 8192; ++step) {
        mach_vm_size_t size = 0;
        vm_region_submap_info_data_64_t info = {0};
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
        kern_return_t result = mach_vm_region_recurse(mach_task_self(), &address,
            &size, &depth, (vm_region_recurse_info_t)&info, &count);
        if (result == KERN_INVALID_ADDRESS) return KERN_SUCCESS;
        if (result != KERN_SUCCESS) return result;
        if (count < VM_REGION_SUBMAP_INFO_V1_COUNT_64) return KERN_FAILURE;
        if (info.is_submap) {
            if (depth >= 64) return KERN_RESOURCE_SHORTAGE;
            ++depth;
            continue;
        }
        if (info.user_tag >= 256 || size == 0 || UINT64_MAX - address < size)
            return KERN_FAILURE;
        uint64_t fields[8] = {1, size, info.pages_resident, info.pages_dirtied,
            info.pages_swapped_out, info.pages_reusable,
            info.external_pager ? info.pages_resident : 0,
            info.external_pager ? 0 : info.pages_resident};
        for (unsigned int column = 0; column < 8; ++column) {
            uint64_t *total = &values[info.user_tag * 8 + column];
            if (UINT64_MAX - *total < fields[column]) return KERN_FAILURE;
            *total += fields[column];
        }
        address += size;
    }
    return KERN_RESOURCE_SHORTAGE;
}
