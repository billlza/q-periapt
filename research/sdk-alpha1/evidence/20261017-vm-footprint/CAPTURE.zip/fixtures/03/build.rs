fn main() {
    println!("cargo:rerun-if-changed=native/memory.c");
    cc::Build::new()
        .file("native/memory.c")
        .warnings(true)
        .extra_warnings(true)
        .warnings_into_errors(true)
        .flag("-Wpedantic")
        .compile("qpc_observer_memory");
}
