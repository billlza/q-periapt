"""Run a fresh two-epoch aggregate-capacity cohort with unchanged product limits."""
from pathlib import Path
import json,os,platform,re,subprocess,sys,time
from codeql_rust_profile import ProfileRun
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
label,profile=sys.argv[1:]
sdk.require(re.fullmatch('[a-z0-9-]+',label) is not None and profile in {'local','witness'},'cohort scope invalid')
build=json.loads((stage/'BUILD_OBSERVED_03.json').read_text());binary=Path(build['binary'])
sdk.require(build['completed'] and sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'observer identity differs')
out=stage/label;out.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPERIAPT_PUBLIC_SERVICE_','QPC_JOURNAL_'))}
env.update(QPC_JOURNAL_PROFILE=profile,QPC_JOURNAL_OUTPUT=str(out/'RESULT.json'),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'runtime'),RUST_BACKTRACE='1')
run=ProfileRun(root,out,root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
record={'completed':False,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],'profile':profile,
 'payload_bytes':16384,'associated_data_bytes':1024,'epoch_capacity':64,'journal_image_limit_bytes':2097152,
 'machine':platform.machine(),'os_release':platform.release(),'started_unix':time.time(),'load_before':os.getloadavg(),
 'host_controls':'Other applications/power settings unchanged; uncontrolled host; no task builds or broad tests overlap runtime.',
 'release_claim_eligible':False}
try:
 sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product tree dirty')
 sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'],'compiled source commit changed')
 print(json.dumps({'cohort':label,'profile':profile,'phase':'fresh aggregate-capacity runtime'}),flush=True)
 raw=run.command('runtime',['/usr/bin/time','-l','-o',str(out/'time.txt'),str(binary),'--exact','measure_journal_capacity','--nocapture','--test-threads=1'],seconds=900)
 sdk.require(b'test result: ok. 1 passed; 0 failed; 0 ignored;' in raw,'aggregate-capacity test incomplete')
 value=json.loads((out/'RESULT.json').read_text());count=value['total_retained_at_refusal']
 sdk.require(value['completed'] and value['sdk_and_server_closed'] and value['profile']==profile,'runtime scope differs')
 sdk.require(64<count<128 and value['epoch_one_retained']==count-64,'aggregate bound not distinct from epoch bound')
 sdk.require(len(value['samples'])==len(value['deliveries'])==value['server']['effects']==count+1,'business census differs')
 for key in ('persist_capacity_closes_journal','aggregate_refused_before_epoch_capacity','capacity_refused_without_reservation','original_owners_reopened_at_capacity',
             'old_epoch_ack_reclaimed_capacity','all_replays_exact','all_business_effects_verified'):
  sdk.require(value[key] is True,'required aggregate outcome missing: '+key)
 resource=(out/'time.txt').read_text();rss=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resource,re.M)
 cpu=re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys',resource)
 sdk.require(rss is not None and cpu is not None,'Darwin process resource receipt missing')
 sdk.require(all(sdk.snapshot(stage/'fixture'/p).sha256==digest for p,digest in build['fixture_files'].items()),'observer source changed')
 sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product changed during runtime')
 record.update(completed=True,result_sha256=sdk.snapshot(out/'RESULT.json',maximum=32*1024**2).sha256,total_retained_at_refusal=count,
  effects=count+1,resources={'max_rss_bytes':int(rss[1]),'real_seconds':float(cpu[1]),'user_seconds':float(cpu[2]),'system_seconds':float(cpu[3])})
except BaseException as exc:
 record['failure']=repr(exc);raise
finally:
 record.update(finished_unix=time.time(),load_after=os.getloadavg(),runtime_state_preserved=True)
 sdk.write_json(out/'RUN.json',record)
print(json.dumps({'completed':True,'cohort':label,'retained':record['total_retained_at_refusal'],'effects':record['effects'],'resources':record['resources']}),flush=True)
