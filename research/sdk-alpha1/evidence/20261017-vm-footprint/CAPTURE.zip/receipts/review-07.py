"""Validate fresh aggregate workloads and non-atomic VM-tag observations."""
from pathlib import Path
import copy
import hashlib
import json
import runpy
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
base = runpy.run_path(str(stage / 'base-review-07.py'))
require = base['require']
BASE_STAGES = tuple(base['STAGES'])
IDLE = ('closed-idle-1s', 'closed-idle-5s', 'closed-idle-15s')
CASES = (('local-vm-census', '03', False), ('local-pressure-probe', '05', True))
MALLOC_TAGS = {1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13}


def validate(value, run, stdout, effects, pressure):
    # Only extend the exact observation-stage inventory. The frozen reader's
    # capacity, original-ID recovery, ciphertext, and business checks remain.
    stages = [*BASE_STAGES, *IDLE]
    if pressure:
        stages.append('after-malloc-pressure-relief')
    base['validate'].__globals__['STAGES'] = stages
    summary = base['validate'](value, run, stdout, effects)
    require(value['profile'] == run['profile'] == 'local', 'profile changed')
    page_sizes = set()
    for row in value['resources']:
        page_size = row['vm_page_size_bytes']
        require(type(page_size) is int and page_size > 0 and page_size & (page_size-1) == 0, 'invalid page size')
        page_sizes.add(page_size)
        for name in ('malloc_blocks_in_use', 'malloc_size_in_use_bytes', 'malloc_max_size_in_use_bytes', 'malloc_size_allocated_bytes'):
            require(type(row[name]) is int and row[name] >= 0, 'invalid malloc counter')
        tags = row['vm_tags']
        require(bool(tags) and any(t['resident_pages'] > 0 for t in tags), 'empty VM census')
        require([t['tag'] for t in tags] == sorted({t['tag'] for t in tags}), 'duplicate or unordered tags')
        for tag in tags:
            require(type(tag['tag']) is int and 0 <= tag['tag'] < 256, 'invalid VM tag')
            for name in ('regions', 'virtual_bytes', 'resident_pages', 'dirty_pages', 'swapped_pages', 'reusable_pages', 'external_resident_pages', 'internal_pager_resident_pages'):
                require(type(tag[name]) is int and tag[name] >= 0, 'invalid region counter')
            require(tag['regions'] > 0 and tag['virtual_bytes'] > 0, 'empty published tag')
            require(tag['external_resident_pages'] + tag['internal_pager_resident_pages'] == tag['resident_pages'], 'pager partition differs')
    require(len(page_sizes) == 1, 'page size changed within process')
    if pressure:
        probe = value['pressure_probe']
        require(probe['invoked_after_all_owners_closed'] is True, 'intervention order not recorded')
        require(type(probe['reported_released_bytes']) is int and probe['reported_released_bytes'] >= 0, 'invalid release count')
        require(type(probe['elapsed_ns']) is int and probe['elapsed_ns'] > 0, 'invalid intervention duration')
    else:
        require('pressure_probe' not in value, 'baseline unexpectedly intervened')
    summary['resources'] = {}
    for row in value['resources']:
        summary['resources'][row['stage']] = {
            **{k: row[k] for k in ('resident_bytes', 'physical_footprint_bytes', 'malloc_size_in_use_bytes', 'malloc_size_allocated_bytes')},
            'malloc_tag_resident_bytes': sum(t['resident_pages'] for t in row['vm_tags'] if t['tag'] in MALLOC_TAGS) * row['vm_page_size_bytes'],
            'malloc_large_resident_bytes': sum(t['resident_pages'] for t in row['vm_tags'] if t['tag'] == 3) * row['vm_page_size_bytes'],
        }
    summary['pressure_probe'] = value.get('pressure_probe')
    return summary


def main():
    reports = []
    controls = 0
    sessions = set()
    for label, version, pressure in CASES:
        folder = stage / label
        raw = (folder / 'RESULT.json').read_bytes()
        value = json.loads(raw)
        run = json.loads((folder / 'RUN.json').read_text())
        build = json.loads((stage / f'BUILD_OBSERVED_{version}.json').read_text())
        require(run['source_commit'] == build['source_commit'] and run['binary_sha256'] == build['binary_sha256'], 'build differs')
        require(hashlib.sha256(raw).hexdigest() == run['result_sha256'], 'result bytes changed')
        stdout = (folder / 'evidence/runtime.stdout').read_text()
        require('test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout, 'native test incomplete')
        effects = {}
        for p in (folder / 'runtime/responder/measured-effects').iterdir():
            require(p.is_file() and not p.is_symlink(), 'invalid effect file')
            effects[p.name] = p.read_bytes()
        reports.append({'case': label, 'build': version, **validate(value, run, stdout, effects, pressure)})
        require(bytes(value['session']) not in sessions, 'session reused')
        sessions.add(bytes(value['session']))
        mutations = []
        for index in range(125):
            altered = copy.deepcopy(value)
            altered['samples'][index]['epoch_index'] += 1
            mutations.append(altered)
        for flag in ('persist_capacity_closes_journal', 'original_owners_reopened_at_capacity', 'old_epoch_ack_reclaimed_capacity'):
            altered = copy.deepcopy(value)
            altered[flag] = False
            mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['rejected_message'] = altered['samples'][0]['message']
        mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['resources'][-1]['vm_tags'] = []
        mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['resources'][-1]['vm_tags'][0]['internal_pager_resident_pages'] += 1
        mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['resources'][-1]['vm_tags'].append(altered['resources'][-1]['vm_tags'][0])
        mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['resources'][-1]['vm_page_size_bytes'] = 3
        mutations.append(altered)
        altered = copy.deepcopy(value)
        altered['resources'].pop()
        mutations.append(altered)
        if pressure:
            altered = copy.deepcopy(value)
            altered['pressure_probe']['invoked_after_all_owners_closed'] = False
            mutations.append(altered)
        for altered in mutations:
            try:
                validate(altered, run, stdout, effects, pressure)
            except ValueError:
                controls += 1
            else:
                raise ValueError('reader accepted substituted observation')
        changed = dict(effects)
        changed[next(iter(changed))] += b'changed'
        try:
            validate(value, run, stdout, changed, pressure)
        except ValueError:
            controls += 1
        else:
            raise ValueError('reader accepted altered business bytes')
    result = {
        'completed': True, 'source_commit': build['source_commit'],
        'cases': reports, 'business_effects_checked': 250,
        'negative_controls_rejected': controls,
        'scope': 'Two fresh local-profile processes: unchanged allocator census and a separate post-close pressure-relief intervention. VM region counters are non-atomic and include shared mappings; they must not be summed as per-task physical footprint. No witness, isolated SDK allocation, leak-free, latency-tail or energy claim.',
        'release_claim_eligible': False,
    }
    sdk.write_json(stage / 'READBACK_07.json', result)
    print(json.dumps({'completed': True, 'effects': 250, 'negative_controls': controls}))


if __name__ == '__main__':
    main()
