"""Read public aggregate-capacity results against independent durable effects."""
from pathlib import Path
import copy,hashlib,json,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
CASES=(('local-original-reopen','local','03'),('witness-original-reopen','witness','03'),('local-malloc-diagnostic','local','05'))
STAGES=['established','epoch-zero-retained-1','epoch-zero-retained-16','epoch-zero-retained-32','epoch-zero-retained-64',
 'epoch-one-confirmed','epoch-one-retained-1','epoch-one-retained-16','epoch-one-retained-32','epoch-one-retained-48',
 'before-aggregate-refusal','aggregate-refused-owner-closed','reopened-aggregate-full','second-original-reopen',
 'old-epoch-ack-reclaimed-and-refilled','all-acknowledged','all-owners-closed']
def require(value,message):
 if not value:raise ValueError(message)
def validate(value,run,stdout,effects):
 require(value['completed'] is True and run['completed'] is True,'runtime incomplete')
 require(value['payload_bytes']==16384 and value['associated_data_bytes']==1024,'workload differs')
 require(value['epoch_capacity']==64 and value['journal_image_limit_bytes']==2097152,'limits differ')
 matches=re.findall(r'JOURNAL_CAPACITY_STAGE capacity_error total=(\d+) epoch_one=(\d+)',stdout)
 require(matches==[('124','60')],'observed capacity boundary absent or substituted')
 count=value['total_retained_at_refusal'];require(count==124 and value['epoch_one_retained']==60,'result disagrees with independent runtime trace')
 for name in ('aggregate_refused_before_epoch_capacity','persist_capacity_closes_journal','capacity_refused_without_reservation',
              'original_owners_reopened_at_capacity','old_epoch_ack_reclaimed_capacity','all_replays_exact','all_business_effects_verified','sdk_and_server_closed'):
  require(value[name] is True,'outcome missing: '+name)
 require(value['release_claim_eligible'] is False,'release scope inflated')
 require(value['rekey']['target']==value['rekey']['server']['epoch']==1,'epoch-one confirmation missing')
 require(value['server']['closed'] is True and value['server']['calls']==value['server']['effects']==125,'business census differs')
 samples=value['samples'];deliveries=value['deliveries'];resources=value['resources']
 require(len(samples)==len(deliveries)==125,'partial message inventory')
 require([r['stage'] for r in resources]==STAGES,'memory stage inventory differs')
 require([r['max_rss_bytes'] for r in resources]==sorted(r['max_rss_bytes'] for r in resources),'RSS high-water declined')
 for r in resources:
  for k in ('resident_bytes','physical_footprint_bytes','journal_file_bytes','max_rss_bytes'):
   require(type(r[k]) is int and r[k]>0,'memory observation absent')
  require(r['max_rss_bytes']>=r['resident_bytes'],'high-water below prior resident sample')
 require(run['resources']['max_rss_bytes']>=resources[-1]['max_rss_bytes'],'external process peak contradicts final sample')
 session=bytes(value['session']);require(len(session)==32,'invalid session')
 names=set()
 for index,(sample,delivery) in enumerate(zip(samples,deliveries,strict=True)):
  epoch,ordinal=(0,index) if index<64 else (1,index-64)
  require(sample['index']==delivery['index']==index and sample['epoch']==epoch and sample['epoch_index']==ordinal,'epoch/sample substitution')
  message=bytes(sample['message']);require(len(message)==32 and int.from_bytes(message[:8],'big')==epoch and int.from_bytes(message[8:16],'big')==ordinal,'message identity differs')
  require(sample['wire_bytes']==16493 and len(bytes(sample['wire_sha3_256']))==32,'ciphertext observation differs')
  require(type(sample['commit_ns']) is int and sample['commit_ns']>0,'invalid API time')
  peer=delivery['peer'];require(bytes(delivery['message'])==message and bytes(peer['message'])==message and bytes(peer['session'])==session,'peer identity differs')
  require(peer['consumed'] is True and peer['duplicate'] is False and peer['calls']==peer['effects']==1,'consumption differs')
  name=message.hex();require(name not in names,'duplicate business effect');names.add(name)
  expected=session+message+bytes((index+offset)%251 for offset in range(16384))
  require(effects.get(name)==expected,'durable effect bytes differ')
 require(set(effects)==names,'effect inventory differs')
 require(bytes(value['rejected_message'])==bytes(samples[-1]['message']),'reclaimed capacity used a replacement ID')
 return {'profile':value['profile'],'total_retained_at_refusal':124,'effects':125,
  'whole_process_peak_rss_bytes':run['resources']['max_rss_bytes'],
  'resources':{r['stage']:r for r in resources if r['stage'] in ('established','before-aggregate-refusal','aggregate-refused-owner-closed','all-acknowledged','all-owners-closed')}}
def main():
 reports=[];controls=0;sessions=set()
 for label,profile,version in CASES:
  folder=stage/label;run=json.loads((folder/'RUN.json').read_text());raw=(folder/'RESULT.json').read_bytes();value=json.loads(raw)
  build=json.loads((stage/f'BUILD_OBSERVED_{version}.json').read_text())
  require(run['source_commit']==build['source_commit'] and run['binary_sha256']==build['binary_sha256'],'compiled source identity differs')
  require(run['profile']==value['profile']==profile,'profile differs')
  require(hashlib.sha256(raw).hexdigest()==run['result_sha256'],'result hash differs')
  stdout=(folder/'evidence/runtime.stdout').read_text();require('test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout,'terminal native result absent')
  effects={p.name:p.read_bytes() for p in (folder/'runtime/responder/measured-effects').iterdir() if p.is_file() and not p.is_symlink()}
  reports.append({'case':label,'build':version,**validate(value,run,stdout,effects)})
  require(bytes(value['session']) not in sessions,'fresh session reused');sessions.add(bytes(value['session']))
  for index in range(125):
   altered=copy.deepcopy(value);altered['samples'][index]['epoch_index']+=1
   try:validate(altered,run,stdout,effects)
   except ValueError:controls+=1
   else:raise ValueError('reader accepted message substitution')
  for flag in ('persist_capacity_closes_journal','original_owners_reopened_at_capacity','old_epoch_ack_reclaimed_capacity'):
   altered=copy.deepcopy(value);altered[flag]=False
   try:validate(altered,run,stdout,effects)
   except ValueError:controls+=1
   else:raise ValueError('reader accepted missing lifecycle outcome')
  altered=copy.deepcopy(value);altered['rejected_message']=altered['samples'][0]['message']
  try:validate(altered,run,stdout,effects)
  except ValueError:controls+=1
  else:raise ValueError('reader accepted replacement operation ID')
  changed=dict(effects);key=next(iter(changed));changed[key]+=b'changed'
  try:validate(value,run,stdout,changed)
  except ValueError:controls+=1
  else:raise ValueError('reader accepted altered durable bytes')
 report={'completed':True,'source_commit':'68e05c56a195bee0a2f964e20738cbfde8446d13','cases':reports,
  'business_effects_checked':375,'negative_controls_rejected':controls,'failed_first_cohort_preserved':True,
  'scope':'Two successful native aggregate-capacity cohorts and one separate malloc-statistics diagnostic. Whole-process observations, not isolated SDK memory, energy, controlled tails or a leak/root-cause proof.',
  'release_claim_eligible':False}
 sdk.write_json(stage/'READBACK_07.json',report)
 print(json.dumps({'completed':True,'business_effects':375,'negative_controls':controls,'cases':[{'case':r['case'],'peak_rss_mib':round(r['whole_process_peak_rss_bytes']/1024**2,3)} for r in reports]},indent=2))
if __name__=='__main__':main()
