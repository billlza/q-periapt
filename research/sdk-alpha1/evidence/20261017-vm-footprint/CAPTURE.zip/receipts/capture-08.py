"""Seal VM observations and the separate intervention without private runtime state."""
from pathlib import Path
import hashlib,json,runpy,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
review=runpy.run_path(str(stage/'review-07.py'));validate=review['validate']
out=root/'research/sdk-alpha1/evidence/20261017-vm-footprint';out.mkdir()
blobs={}
def add(name,path):
 sdk.require(name not in blobs and path.is_file() and not path.is_symlink(),'invalid archive member: '+name)
 blobs[name]=path.read_bytes()
for label,version,pressure in review['CASES']:
 for name in ('RESULT.json','RUN.json','time.txt','evidence/runtime.stdout','evidence/runtime.stderr','evidence/runtime.json'):
  add('cases/'+label+'/'+name,stage/label/name)
 for file in sorted((stage/label/'runtime/responder/measured-effects').iterdir()):
  sdk.require(len(file.name)==64 and all(c in '0123456789abcdef' for c in file.name),'invalid public effect filename')
  add('cases/'+label+'/business/'+file.name,file)
for version,folder in (('03','fixture-v3'),('05','fixture')):
 build=json.loads((stage/f'BUILD_OBSERVED_{version}.json').read_text())
 for name,digest in build['fixture_files'].items():
  p=stage/folder/name;sdk.require(sdk.snapshot(p).sha256==digest,'frozen observer source differs')
  add(f'fixtures/{version}/'+name,p)
 for name in (f'BUILD_STARTED_{version}.json',f'BUILD_OBSERVED_{version}.json',f'build-{version}.py'):
  add('receipts/'+name,stage/name)
 for p in sorted((stage/f'build-{version}'/'evidence').iterdir()):
  if p.is_file():add(f'builds/{version}/'+p.name,p)
for name in ('run-04.py','run-06.py','review-07.py','base-review-07.py','READBACK_07.json','HEADER_IDENTITIES.json','capture-08.py'):
 add('receipts/'+name,stage/name)
reference=root/'research/continuity-identity-candidate/tests'
add('reference/owned_connection.rs',reference/'owned_connection.rs')
for p in sorted((reference/'owned_connection').glob('*.rs')):add('reference/owned_connection/'+p.name,p)
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(blobs.items()):
  i=zipfile.ZipInfo(name,(2026,10,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.create_system=3;i.external_attr=0o100644<<16;z.writestr(i,data)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.infolist())==len(blobs) and set(z.namelist())==set(blobs),'archive inventory differs')
 for name,data in blobs.items():sdk.require(z.read(name)==data,'archive bytes differ: '+name)
 for label,version,pressure in review['CASES']:
  prefix='cases/'+label+'/'
  effects={n[len(prefix+'business/'):]:z.read(n) for n in z.namelist() if n.startswith(prefix+'business/')}
  validate(json.loads(z.read(prefix+'RESULT.json')),json.loads(z.read(prefix+'RUN.json')),z.read(prefix+'evidence/runtime.stdout').decode(),effects,pressure)
sdk.write_json(out/'SUMMARY.json',json.loads((stage/'READBACK_07.json').read_text()))
report={'completed':True,'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'archive_bytes':archive.stat().st_size,
 'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(blobs.items())},'all_members_read_back':True,
 'all_successful_censuses_read_back':True,'business_effects_read_back':250,'failed_runtime_cohorts':0,'unexecuted_prototype_preserved_locally':True,
 'private_state_excluded':['keys','encrypted journal/witness/archive databases','private installation configuration','executables and compiler caches'],
 'release_claim_eligible':False}
sdk.write_json(out/'CAPTURE.json',report)
print(json.dumps({'archive_sha256':report['archive_sha256'],'archive_bytes':report['archive_bytes'],'members':len(blobs),'effects':250}))
