package dev.qperiapt.continuity.android.tests;

import android.system.Os;
import android.system.OsConstants;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Test-only transfer of public fixture inputs and its explicit local TLS identity. */
final class AccountDeviceInputs {
    private AccountDeviceInputs() { }
    static File directory(File parent,String leaf) throws Exception {
        File path=new File(parent,leaf);
        try {Os.mkdir(path.getPath(),0700);}
        catch(android.system.ErrnoException error) {if(error.errno!=OsConstants.EEXIST)throw error;}
        android.system.StructStat stat=Os.lstat(path.getPath());
        if(!OsConstants.S_ISDIR(stat.st_mode) || (stat.st_mode&0777)!=0700 || stat.st_uid!=android.os.Process.myUid())
            throw new IllegalStateException("private fixture directory");
        return path;
    }
    private static int maximum(String name) {
        if(name.matches("account-peer-[01]/(initiator|responder)-(account|roster-digest)"))return 32;
        if(name.matches("account-peer-[01]/(initiator|responder)-(roster-version|generation)"))return 8;
        if(name.matches("account-peer-[01]/(initiator|responder)-device"))return 16;
        if(name.matches("account-peer-[01]/(initiator|responder)-root"))return 1985;
        if(name.matches("account-peer-[01]/(family|directory)"))return 32;
        if(name.matches("account-peer-[01]/bootstrap\\.bundle"))return 65536;
        if(name.matches("account-peer-[01]/tls-peer"))return 8192;
        if(name.matches("account-peer-[01]/tls-peer-name"))return 128;
        switch(name) {
            case "sdk-policy": return 65536;
            case "sdk-signature": case "recovery-enrollment": return 3309;
            case "sdk-root": case "recovery-root": return 1952;
            case "policy-root": case "enrollment-root": return 1985;
            case "family": case "policy-digest": case "recovery-scope": case "trusted-account":
            case "trusted-roster-digest": case "account-operation": case "account-recipient":
            case "account-initiation-0": case "account-initiation-1": case "recovery-session": return 32;
            case "policy-version": case "trusted-roster-version": return 8;
            case "protocol-policy": case "tls-cert": case "tls-key": case "grant-certificate": case "grant-roster": return 8192;
            case "enrollment-intent": return 72;
            case "account-sessions": return 64;
            case "account-selected": return 4;
            case "account-address": case "account-address-0": case "account-address-1": return 128;
            default: throw new IllegalArgumentException("unapproved fixture field");
        }
    }
    static void install(File root,String encoded) throws Exception {
        if(encoded==null || encoded.length()>110000)throw new IllegalArgumentException("fixture packet bound");
        byte[] raw=android.util.Base64.decode(encoded,android.util.Base64.NO_WRAP);
        try {
            if(raw.length<4 || raw.length>80000 || !android.util.Base64.encodeToString(raw,android.util.Base64.NO_WRAP).equals(encoded))
                throw new IllegalArgumentException("fixture packet encoding");
            ByteBuffer packet=ByteBuffer.wrap(raw);int count=packet.getInt();
            if(count<0 || count>64)throw new IllegalArgumentException("fixture count");
            Set<String> seen=new HashSet<>();
            for(int i=0;i<count;i++) {
                int length=Short.toUnsignedInt(packet.getShort());
                if(length==0 || length>64 || length>packet.remaining())throw new IllegalArgumentException("field length");
                byte[] label=new byte[length];packet.get(label);String name=new String(label,StandardCharsets.US_ASCII);
                if(!name.matches("[a-z0-9./-]+") || !seen.add(name))throw new IllegalArgumentException("field name");
                int size=packet.getInt();
                if(size<1 || size>maximum(name) || size>packet.remaining())throw new IllegalArgumentException("field size");
                byte[] value=new byte[size];packet.get(value);
                try {
                    int slash=name.indexOf('/');File parent=slash<0 ? root : directory(root,name.substring(0,slash));
                    File destination=new File(parent,slash<0 ? name : name.substring(slash+1));
                    boolean mutable=name.equals("account-address") || name.equals("account-selected")
                        || name.equals("account-operation") || name.equals("recovery-session");
                    if(mutable)Files.write(destination.toPath(),value);
                    else {
                        try {Files.write(destination.toPath(),value,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);}
                        catch(java.nio.file.FileAlreadyExistsException exists) {
                            byte[] previous=Files.readAllBytes(destination.toPath());
                            try {if(!Arrays.equals(previous,value))throw new IllegalStateException("original fixture changed: "+name,exists);}
                            finally {Arrays.fill(previous,(byte)0);}
                        }
                    }
                } finally {Arrays.fill(value,(byte)0);}
            }
            if(packet.hasRemaining())throw new IllegalArgumentException("fixture trailing data");
        } finally {Arrays.fill(raw,(byte)0);}
    }
}
