package dev.qperiapt.continuity.android.tests;

import android.app.Instrumentation;
import android.os.Bundle;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;

/** Installed AAR consumer; every invocation runs in a new ART process. */
public final class AccountDeviceInstrumentation extends Instrumentation {
    private Bundle arguments;
    private static String digest(String path) throws Exception {
        java.security.MessageDigest hash=java.security.MessageDigest.getInstance("SHA-256");
        try(InputStream source=new java.io.FileInputStream(path)) {
            byte[] buffer=new byte[8192];int count;
            while((count=source.read(buffer))!=-1)hash.update(buffer,0,count);
        }
        StringBuilder result=new StringBuilder();
        for(byte value:hash.digest())result.append(String.format(java.util.Locale.ROOT,"%02x",value&255));
        return result.toString();
    }
    @Override public void onCreate(Bundle supplied) {arguments=supplied;start();}
    @Override public void onStart() {
        Bundle result=new Bundle();result.putInt("pid",android.os.Process.myPid());
        try {
            result.putString("apk_sha256",digest(getTargetContext().getPackageCodePath()));
            String profile=arguments.getString("profile"),operation=arguments.getString("operation"),label=arguments.getString("label");
            if(!("fixed".equals(profile) || "recoverable".equals(profile)))throw new IllegalArgumentException("profile");
            if(operation==null || !operation.matches("(enrollment|account|recovery)-[a-z-]+") && !operation.equals("fixture-stage"))throw new IllegalArgumentException("operation");
            if(label==null || !label.matches("[a-z][a-z0-9.-]{0,63}"))throw new IllegalArgumentException("label");
            File base=AccountDeviceInputs.directory(getTargetContext().getFilesDir().getCanonicalFile(),"account-"+profile);
            File inputs=AccountDeviceInputs.directory(base,"inputs");
            AccountDeviceInputs.install(inputs,arguments.getString("fixture"));
            File output=new File(base,label);
            String[] call={inputs.getPath(),new File(base,"installation").getPath(),profile,operation,output.getPath()};
            byte[] bytes;
            if(operation.equals("fixture-stage")) {
                bytes=java.security.MessageDigest.getInstance("SHA-256").digest(android.util.Base64.decode(arguments.getString("fixture"),android.util.Base64.NO_WRAP));
            } else {
            if(operation.startsWith("enrollment-"))EnrollmentProbe.main(call);
            else if(operation.startsWith("account-"))AccountProbe.main(call);
            else FirstUseRecoveryProbe.main(call);
            bytes=Files.readAllBytes(output.toPath());
            }
            if(bytes.length<1 || bytes.length>65536)throw new IllegalStateException("result width");
            if(operation.equals("recovery-session-freeze") || operation.equals("recovery-session-ack")) {
                byte[] session=Files.readAllBytes(new File(inputs,"recovery-session").toPath());
                if(session.length!=32)throw new IllegalStateException("session width");
                StringBuilder identity=new StringBuilder();
                for(byte value:session)identity.append(String.format(java.util.Locale.ROOT,"%02x",value&255));
                byte[] report=Files.readAllBytes(new File(new File(base,"installation"),"c-member-loss-"+identity).toPath());
                if(report.length<1 || report.length>65536)throw new IllegalStateException("complete report bound");
                result.putString("closure_report_payload",android.util.Base64.encodeToString(report,android.util.Base64.NO_WRAP));
            }
            result.putString("result_payload",android.util.Base64.encodeToString(bytes,android.util.Base64.NO_WRAP));
            result.putString("result",profile+":"+operation+":passed");finish(-1,result);
        } catch(Exception | AssertionError failure) {
            result.putString("failure",failure.toString());finish(1,result);
        }
    }
}
