from pathlib import Path
import os,shutil
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;out=stage/'record-checks';out.mkdir(mode=0o700);source=out/'source';source.mkdir();classes=out/'classes';classes.mkdir()
for p in (stage/'cohort3/source/src/test/java').glob('*.java'):
    if p.name!='RecoveryProbeFiles.java':shutil.copy2(p,source/p.name)
shutil.copy2(stage/'portable-records/RecoveryProbeFiles.java',source/'RecoveryProbeFiles.java');shutil.copy2(stage/'HostRecordChecks.java',source/'HostRecordChecks.java')
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');jar=stage/'cohort3/classes.jar'
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
sdk.command([str(jdk/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),*map(str,sorted(source.glob('*.java')))],out/'compile',stage,environment=env)
sdk.command([str(jdk/'bin/java'),'-cp',str(jar)+os.pathsep+str(classes),'dev.qperiapt.continuity.android.tests.HostRecordChecks'],out/'execution',stage,environment=env)
print('Portable host report retention checks passed')
