from pathlib import Path
import hashlib,json,os,shlex,sys
import rust_sdk_profile as sdk
import continuity_android_recovery_records as records
stage=Path(__file__).resolve().parent;root=Path.cwd();run=stage/'runtime3';run.mkdir(mode=0o700)
build=json.loads((stage/'cohort3/BUILD.json').read_text());apk=json.loads((stage/'apk3/STATE.json').read_text());device=json.loads((stage/'DEVICE.json').read_text())
assert build['completed'] and not build['live_producer'] and apk['completed'] and not apk['live_producer']
binary=Path(build['host_binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['host_binary_sha256']
assert hashlib.sha256(Path(apk['apk']).read_bytes()).hexdigest()==apk['apk_sha256']
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.account20261013'
env={k:v for k,v in os.environ.items() if not k.startswith(('QPC_','QPERIAPT_','DYLD_','LD_'))}
tc=root/'target/android-physical-current/rustup/toolchains/1.98.1-aarch64-apple-darwin';env.update(DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),QPC_ART_RUN=str(run))
state={'completed':False,'live_producer':True,'installation_attempted':False,'cleanup':False,'source_commit':build['source_commit'],'apk_sha256':apk['apk_sha256'],'host_binary_sha256':build['host_binary_sha256'],'transport':'wireless ADB with owned reverse TCP mappings; real SDK mutual TLS'}
def save():(run/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def command(name,args):return sdk.command([adb,'-P',str(device['server_port']),'-s',device['serial'],*map(str,args)],run/name,root,environment=env)
save();primary=None
try:
    assert not command('preexisting',['shell','pm','list','packages','--user','0',pkg]).strip()
    assert command('api',['shell','getprop','ro.build.version.sdk']).strip()==b'37'
    assert command('abi',['shell','getprop','ro.product.cpu.abi']).strip()==b'arm64-v8a'
    state['installation_attempted']=True;save()
    assert command('install',['install','--no-incremental','-t',apk['apk']]).splitlines().count(b'Success')==1
    launcher=run/'driver';launcher.write_text('#!/bin/sh\nexec '+shlex.join([sys.executable,str(stage/'device-driver.py')])+' "$@"\n');launcher.chmod(0o700)
    cases=run/'cases';runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(launcher))
    stdout=sdk.command([str(binary),'--exact',records.FIRST_USE_TEST,'--nocapture'],run/'execution',Path(build['consumer']),environment=runtime)
    result=records.first_use(stdout,cases)
    for profile,expected in result.items():
        calls=json.loads((run/(profile+'-STATE.json')).read_text())['calls']
        assert len(calls)==expected['foreign_processes'] and all(row['process_absent'] and row['apk_sha256']==apk['apk_sha256'] for row in calls)
        for index in (0,1):
            before=(run/(profile+'-recovery-frozen-'+str(index))/'complete-session-report.txt').read_bytes()
            after=(run/(profile+'-recovery-ack-'+str(index))/'complete-session-report.txt').read_bytes()
            assert before==after
        expected['installed_art_processes']=len(calls)
    state.update(completed=True,outcomes=result)
except BaseException as error:primary=error;raise
finally:
    cleanup_errors=[]
    if state['installation_attempted']:
        try:command('final-stop',['shell','am','force-stop',pkg])
        except Exception as error:cleanup_errors.append(repr(error))
        for path in run.glob('*/OWNED_PORTS.json'):
            for port in json.loads(path.read_text()):
                try:command('final-reverse-remove-'+str(port),['reverse','--remove','tcp:'+str(port)])
                except Exception as error:cleanup_errors.append(repr(error))
        try:
            assert command('uninstall',['uninstall',pkg]).strip()==b'Success'
            assert not command('uninstalled',['shell','pm','list','packages','--user','0',pkg]).strip()
            state['cleanup']=True
        except Exception as error:cleanup_errors.append(repr(error))
    state.update(live_producer=False,cleanup_errors=cleanup_errors);save()
    if cleanup_errors:
        raise RuntimeError('run-owned device cleanup incomplete: '+repr(cleanup_errors)) from primary
print('Installed Android first-use and original recovery completed; run-owned app removed',flush=True)
