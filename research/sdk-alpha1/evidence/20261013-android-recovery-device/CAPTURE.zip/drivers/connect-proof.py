from pathlib import Path
import hashlib,json,subprocess
stage=Path(__file__).resolve().parent;adb='/Users/bill/Library/Android/sdk/platform-tools/adb';serial='10.249.100.11:35241';server=5038
def read(args):
    result=subprocess.run([adb,'-P',str(server),'-s',serial,*args],capture_output=True,text=True,check=True,timeout=15)
    assert not result.stderr;return result.stdout.strip()
assert read(['get-state'])=='device'
fields={name:read(['shell','getprop',prop]) for name,prop in [('api','ro.build.version.sdk'),('abi','ro.product.cpu.abi'),('model','ro.product.model')]}
assert fields['api']=='37' and fields['abi']=='arm64-v8a'
identity=hashlib.sha256(read(['shell','getprop','ro.serialno']).encode()).hexdigest()
assert identity=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'
state={'serial':serial,'server_port':server,'owned_adb_server':True,'hardware_serial_sha256':identity,**fields}
with (stage/'DEVICE.json').open('x') as destination:destination.write(json.dumps(state,indent=2)+'\n')
print('Connected accepted API37 arm64 phone; hardware identity matched; isolated ADB server5038')
