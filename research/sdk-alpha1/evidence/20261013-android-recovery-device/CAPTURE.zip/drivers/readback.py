from pathlib import Path
import base64,hashlib,json,re
import continuity_android_account as account
import continuity_android_recovery_records as recovery

def verify(directory:Path,apk_sha256:str)->dict:
    state=json.loads((directory/'STATE.json').read_text())
    assert state['completed'] and not state['live_producer'] and state['cleanup'] and not state['cleanup_errors']
    assert state['apk_sha256']==apk_sha256
    outcomes=recovery.first_use((directory/'execution.stdout').read_bytes(),directory/'cases')
    assert state['outcomes']=={key:dict(value,installed_art_processes=value['foreign_processes']) for key,value in outcomes.items()}
    expected=dict(account.CASES+recovery.FIRST_USE_CASES);pids=set();all_calls=[];reports=0;staging=0
    for profile,summary in outcomes.items():
        rows=json.loads((directory/(profile+'-STATE.json')).read_text())['calls']
        assert len(rows)==len(expected) and {row['label'] for row in rows}==set(expected)
        for row in rows:
            label=row['label'];mode=expected[label];case=directory/(profile+'-'+label)
            assert row['operation']==mode and row['apk_sha256']==apk_sha256 and row['process_absent']
            assert row['pid'] not in pids;pids.add(row['pid'])
            for stage in row['stages']:
                prefix=stage['prefix'];assert stage['pid'] not in pids;pids.add(stage['pid']);staging+=1
                raw=(case/(prefix+'-instrument.stdout')).read_text()
                assert raw.rstrip().endswith('INSTRUMENTATION_CODE: -1')
                assert raw.splitlines().count('INSTRUMENTATION_RESULT: apk_sha256='+apk_sha256)==1
                assert raw.splitlines().count('INSTRUMENTATION_RESULT: result='+profile+':fixture-stage:passed')==1
                assert int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',raw,re.M)[1])==stage['pid']
                payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',raw,re.M)[1],validate=True)
                assert payload.hex()==stage['packet_sha256']
                for suffix,code in [('instrument',0),('stop',0),('process-absent',1)]:
                    assert json.loads((case/(prefix+'-'+suffix+'.json')).read_text())['returncode']==code
                    assert (case/(prefix+'-'+suffix+'.stderr')).read_bytes()==b''
                assert (case/(prefix+'-process-absent.stdout')).read_bytes()==b''
            text=(case/'instrument.stdout').read_text()
            assert text.rstrip().endswith('INSTRUMENTATION_CODE: -1')
            assert text.splitlines().count('INSTRUMENTATION_RESULT: apk_sha256='+apk_sha256)==1
            assert text.splitlines().count('INSTRUMENTATION_RESULT: result='+profile+':'+mode+':passed')==1
            assert int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',text,re.M)[1])==row['pid']
            result=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',text,re.M)[1],validate=True)
            assert result==(directory/'cases'/profile/label).read_bytes()
            assert hashlib.sha256(result).hexdigest()==row['result_sha256']
            for name,code in [('instrument',0),('stop',0),('process-absent',1)]:
                assert json.loads((case/(name+'.json')).read_text())['returncode']==code
                assert (case/(name+'.stderr')).read_bytes()==b''
            assert (case/'process-absent.stdout').read_bytes()==b'' and json.loads((case/'OWNED_PORTS.json').read_text())==[]
            if mode in ('recovery-session-freeze','recovery-session-ack'):
                report=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: closure_report_payload=([^\n]+)$',text,re.M)[1],validate=True)
                assert report==(case/'complete-session-report.txt').read_bytes()
                lines=report.decode('ascii').splitlines();assert lines[:2]==['QPC-C-LOSS/1','report '+result.hex()]
                index=int(label[-1]);session=(directory/'cases'/profile/'sessions').read_bytes()[index*32:(index+1)*32].hex()
                header=lines[2].split();assert len(header)==14 and header[0]=='header' and header[1]==session
                assert all(re.fullmatch('[0-9a-f]{'+str(size)+'}',value) for value,size in zip(header[1:5],[64,64,64,32]))
                reservations,epochs=map(int,header[-2:]);assert 0<=reservations<=4 and 0<=epochs<=4
                assert sum(line.startswith('reserved ') for line in lines)==reservations
                epoch_lines=[line.split() for line in lines if line.startswith('epoch ')];assert len(epoch_lines)==epochs
                for i,epoch in enumerate(epoch_lines):
                    assert len(epoch)==14 and epoch[1]==str(i)
                    for kind,count in zip(('unconfirmed','delivery','skipped'),map(int,epoch[-3:])):
                        entries=[line.split() for line in lines if line.startswith(kind+' '+str(i)+' ')]
                        assert len(entries)==count and [int(entry[2]) for entry in entries]==list(range(count))
                reports+=1
            all_calls.append(case.name)
        for index in (0,1):
            assert (directory/(profile+'-recovery-frozen-'+str(index))/'complete-session-report.txt').read_bytes()==(directory/(profile+'-recovery-ack-'+str(index))/'complete-session-report.txt').read_bytes()
    assert {p.parent.name for p in directory.glob('*/instrument.json')}==set(all_calls)
    assert (directory/'uninstalled.stdout').read_bytes()==b'' and (directory/'uninstall.stdout').read_bytes().strip()==b'Success'
    return {'completed':True,'art_sdk_processes':len(all_calls),'fixture_staging_processes':staging,'complete_session_reports':reports,'profiles':outcomes,'app_removed':True,'apk_sha256':apk_sha256}

if __name__=='__main__':
    stage=Path(__file__).resolve().parent;apk=json.loads((stage/'apk3/STATE.json').read_text())
    result=verify(stage/'runtime3',apk['apk_sha256'])
    with (stage/'READBACK.json').open('x') as file:file.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
