from pathlib import Path
import hashlib,json,struct,subprocess
stage=Path(__file__).resolve().parent;run=stage/'runtime1'
original=json.loads((run/'fixed-STATE.json').read_text())['inputs'];inputs=run/'cases/fixed/inputs'
values={p.relative_to(inputs).as_posix():p.read_bytes() for p in inputs.rglob('*') if p.is_file()}
changed={name:value for name,value in values.items() if original.get(name)!=hashlib.sha256(value).hexdigest()}
size=4+sum(2+len(name.encode())+4+len(value) for name,value in changed.items())
observations=[]
for width in (60000,66000):
    r=subprocess.run(['/Users/bill/Library/Android/sdk/platform-tools/adb','-P','5038','-s','10.249.100.11:35241','shell','true','x'*width],capture_output=True,text=True,timeout=10)
    observations.append({'input_bytes':width,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
assert observations[0]['returncode']==0 and observations[0]['stderr']=='' and observations[1]['returncode']==1 and observations[1]['stderr']=='error: closed\n'
result={'observed_packet_decoded_bytes':size,'base64_bytes':4*((size+2)//3),'shell_boundary_without_SDK':observations,'failed_run_app_removed':json.loads((run/'STATE.json').read_text())['cleanup']}
with (stage/'PAYLOAD_BOUNDARY.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
