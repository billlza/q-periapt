from pathlib import Path
import hashlib, json, os, shutil, subprocess, tempfile, zipfile, tarfile
import rust_sdk_profile as sdk
import third_party_licenses as licenses

root=Path.cwd(); out=Path(__file__).resolve().parent/'cohort3';out.mkdir(mode=0o700)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='7290c6f02b0fdebbaaed5b2916dc68904267710a'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
old=Path('/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qperiapt-continuity-package-j225537j/c-consumer')
cohort=root/'target/peer-account-retirement-process-current/source/target/continuity-browser-package-01'
report=cohort/'sdk/RUST_SDK_PACKAGE.json'
assert hashlib.sha256(report.read_bytes()).hexdigest()=='aae9cf1b23c6772d70e3aaae2724166e7deb245e44e812fd98b8a313b6218583'
work=Path(tempfile.mkdtemp(prefix='qperiapt-android-20261013-')).resolve()
consumer=work/'consumer'; shutil.copytree(old,consumer)
source=out/'source'; shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',source)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
inputs={}
for relative in ['src','tests','c']:
    for p in (root/'bindings/c/ContinuityPackageConsumer'/relative).rglob('*'):
        if p.is_file():
            name=p.relative_to(root/'bindings/c/ContinuityPackageConsumer')
            assert digest(p)==digest(consumer/name),str(name)
            inputs[str(p.relative_to(root))]=digest(p)
for p in source.rglob('*'):
    if p.is_file(): inputs[str((root/'bindings/android/ContinuityPackageConsumer'/p.relative_to(source)).relative_to(root))]=digest(p)
archives=[cohort/'sdk/crates'/(name+'-0.2.0.crate') for name in sdk.CONSUMER_CRATES]+list((cohort/'continuity').glob('*.crate'))
assert len(archives)==10
archived={}
for path in archives:
    with tarfile.open(path,'r:gz') as archive:
        for member in archive.getmembers():
            if member.isfile():
                value=archive.extractfile(member).read()
                assert (consumer/'packages'/member.name).read_bytes()==value,member.name
    archived[path.name]=digest(path)
tc=root/'target/android-physical-current/rustup/toolchains/1.98.1-aarch64-apple-darwin'
ndk=Path('/Users/bill/Library/Android/sdk/ndk/29.0.14206865');llvm=ndk/'toolchains/llvm/prebuilt/darwin-x86_64/bin';cc=llvm/'aarch64-linux-android23-clang'
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPC_','QPERIAPT_','JAVA','JDK','GRADLE'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_TARGET_DIR=str(work/'build'),CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
android=dict(env,RUSTFLAGS='-D warnings -C link-arg=-Wl,-z,max-page-size=16384',CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=str(cc),CC_aarch64_linux_android=str(cc),AR_aarch64_linux_android=str(llvm/'llvm-ar'))
state={'completed':False,'live_producer':True,'work':str(work),'consumer':str(consumer),'source_commit':head,'source_inputs':inputs,'archives_sha256':archived,'phase':'android-native'}
def save(): (out/'BUILD.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,label,cwd=consumer,runtime=env): return sdk.command(list(map(str,cmd)),out/label,cwd,environment=runtime)
def archive(path,items):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(items.items()):
            info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
save()
try:
    run([tc/'bin/cargo','build','--offline','--locked','--lib','--target','aarch64-linux-android','--release','-j','2'],'android-native',runtime=android)
    native=out/'native';native.mkdir();engine=work/'build/aarch64-linux-android/release/libq_periapt_continuity_c_consumer.so';shutil.copy2(engine,native/engine.name)
    classes=out/'classes';classes.mkdir()
    run([jdk/'bin/javac','--release','11','-Xlint:all','-Werror','-d',classes,*sorted((source/'src/main/java').rglob('*.java'))],'javac')
    run([cc,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-I'+str(consumer),'-fPIC','-shared',*sorted((source/'jni').glob('*.c')),'-L'+str(native),'-lq_periapt_continuity_c_consumer','-Wl,--no-undefined','-Wl,-soname,libqperiapt_continuity_jni.so','-Wl,-z,max-page-size=16384','-o',native/'libqperiapt_continuity_jni.so'],'jni')
    jar=out/'classes.jar';archive(jar,{p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob('*.class')})
    metadata=json.loads(run([tc/'bin/cargo','metadata','--locked','--offline','--format-version','1','--filter-platform','aarch64-linux-android'],'license-metadata',runtime=android))
    notices=out/'notices';notices.mkdir();licenses.collect(consumer,notices,'aarch64-linux-android',root_package='q-periapt-continuity-c-consumer',resolved_metadata=metadata);licenses.verify(notices,expected_target='aarch64-linux-android',root_package='q-periapt-continuity-c-consumer')
    files={'classes.jar':jar.read_bytes(),'proguard.txt':(source/'consumer-rules.pro').read_bytes(),'AndroidManifest.xml':b'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.qperiapt.continuity.android"><uses-sdk android:minSdkVersion="23"/></manifest>\n'}
    for p in native.glob('*.so'):files['jni/arm64-v8a/'+p.name]=p.read_bytes()
    for p in notices.rglob('*'):
        if p.is_file():files['META-INF/native-notices/'+p.relative_to(notices).as_posix()]=p.read_bytes()
    for name in ['Apache-2.0.txt','MIT.txt','Rust-1.98.1-library.html']:files['META-INF/LICENSES/'+name]=(root/'LICENSES'/name).read_bytes()
    for name in ['INVENTORY.sha256','LICENSE-INVENTORY.md','LICENSE.mlkem-native','PROVENANCE.md']:files['META-INF/LICENSES/mlkem-native/'+name]=(root/'crates/q-periapt-mlkem-native-sys/vendor'/name).read_bytes()
    aar=out/'q-periapt-continuity-android-0.0.0.aar';archive(aar,files)
    sdk.write_json(out/'PACKAGE.json',{'completed':True,'aar':str(aar),'aar_sha256':digest(aar),'source':str(source),'source_commit':head,'native_engine_sha256':digest(engine),'jni_sha256':digest(native/'libqperiapt_continuity_jni.so'),'source_sha256':{p.relative_to(source).as_posix():digest(p) for p in source.rglob('*') if p.is_file()},'members_sha256':{name:hashlib.sha256(data).hexdigest() for name,data in files.items()},'release_claim_eligible':False})
    print('Current installed-package Android arm64 AAR built',flush=True)
    state['phase']='host-fixture';save()
    result=run([tc/'bin/cargo','test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2'],'host-fixture')
    messages=[json.loads(line) for line in result.splitlines()]
    binaries=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='android']
    assert len(binaries)==1
    for name,sha in inputs.items():assert digest(root/name)==sha,name
    state.update(completed=True,phase='complete',host_binary=binaries[0],host_binary_sha256=digest(Path(binaries[0])))
finally:
    state['live_producer']=False;save()
