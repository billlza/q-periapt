from pathlib import Path
import os
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;out=stage/'integrated-checks';out.mkdir(mode=0o700);classes=out/'classes';classes.mkdir()
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');jar=stage/'cohort3/classes.jar'
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
source=root/'bindings/android/ContinuityPackageConsumer/src/test/java'
sdk.command([str(jdk/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),*map(str,sorted(source.glob('*.java')))],out/'compile',root,environment=env)
stdout=sdk.command([str(jdk/'bin/java'),'-cp',str(jar)+os.pathsep+str(classes),'dev.qperiapt.continuity.android.tests.RecoveryProbeFilesChecks'],out/'execution',root,environment=env)
assert stdout==b'host-record-retention:passed\n' and (out/'execution.stderr').read_bytes()==b''
assert (source/'RecoveryProbeFiles.java').read_bytes()==(stage/'portable-records/RecoveryProbeFiles.java').read_bytes()
print('Integrated host record retention compiled and executed without diagnostics')
