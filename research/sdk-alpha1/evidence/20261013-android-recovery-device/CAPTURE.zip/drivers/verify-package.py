from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
import continuity_c_consumer as consumer
stage=Path(__file__).resolve().parent;out=stage/'package-checks';out.mkdir(mode=0o700)
record=json.loads((stage/'cohort3/PACKAGE.json').read_text());assert record['completed']
llvm=Path('/Users/bill/Library/Android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/darwin-x86_64/bin')
observed={}
with zipfile.ZipFile(record['aar']) as archive:
    assert len(archive.namelist())==len(set(archive.namelist())) and set(archive.namelist())==set(record['members_sha256'])
    for name,digest in record['members_sha256'].items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest,name
for kind,filename in [('engine','libq_periapt_continuity_c_consumer.so'),('jni','libqperiapt_continuity_jni.so')]:
    file=stage/'cohort3/native'/filename
    symbols=sdk.command([str(llvm/'llvm-nm'),'--defined-only','--extern-only','-D',str(file)],out/(kind+'-exports'),stage).decode()
    names={line.split()[-1] for line in symbols.splitlines() if line.strip()}
    if kind=='engine':assert names==consumer.EXPORTS,(names-consumer.EXPORTS,consumer.EXPORTS-names)
    else:assert names=={'JNI_OnLoad'}
    program=sdk.command([str(llvm/'llvm-readelf'),'-lW',str(file)],out/(kind+'-elf'),stage).decode()
    loads=[line.split() for line in program.splitlines() if line.lstrip().startswith('LOAD ')]
    assert len(loads)>=2 and all(int(row[-1],16)>=16384 for row in loads)
    observed[kind]={'exports':len(names),'load_segments':len(loads),'all_load_alignments_at_least_16KiB':True,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
sdk.write_json(out/'CHECKS.json',{'completed':True,'aar_members':len(record['members_sha256']),'aar_sha256':record['aar_sha256'],'libraries':observed})
print('AAR readback, exact exports and both native 16KiB load alignments passed')
