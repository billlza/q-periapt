from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;out=stage/'apk1';out.mkdir(mode=0o700)
package=json.loads((stage/'cohort3/PACKAGE.json').read_text());assert package['completed']
source=Path(package['source']);project=Path(tempfile.mkdtemp(prefix='qperiapt-account-art-')).resolve()
template=root/'artifact/android-agp-consumer';jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home');bt=Path('/Users/bill/Library/Android/sdk/build-tools/36.0.0')
for name in ['gradlew','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties','settings.gradle.kts','build.gradle.kts','gradle.properties']:
    path=project/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(template/name,path)
(project/'gradlew').chmod(0o700);(project/'libs').mkdir();shutil.copy2(package['aar'],project/'libs/continuity.aar')
app=project/'app';java=app/'src/main/java/dev/qperiapt/continuity/android/tests';java.mkdir(parents=True)
for p in (source/'src/test/java').glob('*.java'):shutil.copy2(p,java/p.name)
for p in (stage/'appsrc').glob('*.java'):shutil.copy2(p,java/p.name)
(app/'src/main/AndroidManifest.xml').write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:allowBackup="false" android:label="Continuity recovery qualification"/><instrumentation android:name="dev.qperiapt.continuity.android.tests.AccountDeviceInstrumentation" android:targetPackage="dev.qperiapt.continuity.account20261013"/></manifest>\n')
(app/'build.gradle.kts').write_text('''plugins { id("com.android.application") }
android {
 namespace="dev.qperiapt.continuity.android.tests"
 compileSdk=36
 buildToolsVersion="36.0.0"
 defaultConfig {applicationId="dev.qperiapt.continuity.account20261013";minSdk=36;targetSdk=36;versionCode=1;versionName="qualification"}
 buildTypes {getByName("release") {isDebuggable=false;isMinifyEnabled=true;vcsInfo.include=false;proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))}}
 compileOptions {sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 buildFeatures {buildConfig=false}
 packaging.jniLibs {useLegacyPackaging=false;keepDebugSymbols+=setOf("**/libq_periapt_continuity_c_consumer.so","**/libqperiapt_continuity_jni.so")}
}
dependencies {implementation(files(rootProject.file("libs/continuity.aar")))}
tasks.withType<JavaCompile>().configureEach {
 options.compilerArgs.addAll(listOf("-Xlint:all","-Werror"))
 doFirst {file("compile-inputs.txt").writeText(source.files.map {it.canonicalPath}.sorted().joinToString("\\n",postfix="\\n"))}
}
''')
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK','GRADLE','ANDROID','DYLD','LD_'))}
env.update(JAVA_HOME=str(jdk),ANDROID_HOME='/Users/bill/Library/Android/sdk',GRADLE_USER_HOME='/Users/bill/.gradle',PATH=str(jdk/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
record={'completed':False,'live_producer':True,'project':str(project),'aar_sha256':package['aar_sha256'],'source_commit':package['source_commit'],'sources_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in java.glob('*.java')}}
def save():(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
def run(cmd,name):return sdk.command(list(map(str,cmd)),out/name,project,environment=env)
save()
try:
    run([project/'gradlew','--project-dir',project,'--offline','--no-daemon','--no-build-cache','--no-configuration-cache','--max-workers=2','--warning-mode=fail','--console=plain','-Dorg.gradle.java.home='+str(jdk),':app:assembleRelease'],'build')
    compiled=[Path(p) for p in (app/'compile-inputs.txt').read_text().splitlines()]
    assert set(compiled)==set(java.glob('*.java'))
    for p in compiled:assert hashlib.sha256(p.read_bytes()).hexdigest()==record['sources_sha256'][p.name]
    unsigned=app/'build/outputs/apk/release/app-release-unsigned.apk'
    assert 'dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:' in (app/'build/outputs/mapping/release/mapping.txt').read_text()
    with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(unsigned) as apk:
        for name in ['libqperiapt_continuity_jni.so','libq_periapt_continuity_c_consumer.so']:assert aar.read('jni/arm64-v8a/'+name)==apk.read('lib/arm64-v8a/'+name)
    run([jdk/'bin/keytool','-genkeypair','-keystore',out/'qualification.p12','-storepass','qualification-only','-alias','qualification','-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Local Continuity Qualification','-noprompt'],'keytool');(out/'qualification.p12').chmod(0o600)
    apk=out/'consumer.apk'
    run([bt/'apksigner','sign','--ks',out/'qualification.p12','--ks-pass','pass:qualification-only','--out',apk,unsigned],'sign')
    run([bt/'apksigner','verify','--verbose',apk],'signature')
    run([bt/'zipalign','-c','-P','16','-v','4',apk],'alignment')
    record.update(completed=True,apk=str(apk),apk_sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),signed=True,native_members_equal=True)
finally:record['live_producer']=False;save()
