from pathlib import Path
import hashlib,importlib.util,json,shutil,tempfile,zipfile
import rust_sdk_profile as sdk
import continuity_android_recovery_records as records
root=Path.cwd();stage=Path(__file__).resolve().parent
destination=root/'research/sdk-alpha1/evidence/20261013-android-recovery-device';destination.mkdir(mode=0o700)
spec=importlib.util.spec_from_file_location('device_readback',stage/'readback.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
apk=json.loads((stage/'apk3/STATE.json').read_text());current=reader.verify(stage/'runtime3',apk['apk_sha256'])
members={}
def add(path,name):
    assert path.is_file() and not path.is_symlink() and name not in members
    members[name]=path.read_bytes()
def runtime(source,prefix,complete):
    for path in source.iterdir():
        if path.is_file():add(path,prefix+'/'+path.name)
        elif path.name!='cases':
            for child in path.iterdir():
                assert child.is_file(),child
                add(child,prefix+'/'+path.name+'/'+child.name)
    for profile in ('fixed','recoverable'):
        for name in records.FIRST_USE_PUBLIC:
            file=source/'cases'/profile/name
            if file.exists():add(file,prefix+'/cases/'+profile+'/'+name)
            else:assert not complete,(profile,name)
runtime(stage/'runtime3','runtime',True)
for index in (1,2):runtime(stage/('runtime'+str(index)),'failed-runtime-'+str(index),False)
for folder in ('cohort2','cohort3','apk1','apk2','apk3','package-checks','record-checks','integrated-checks'):
    for path in (stage/folder).iterdir():
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr'):
            add(path,'build/'+folder+'/'+path.name)
for folder in ('apk1','apk2','apk3'):
    project=Path(json.loads((stage/folder/'STATE.json').read_text())['project'])
    for path in (project/'app/src/main/java').rglob('*.java'):
        add(path,'apk-sources/'+folder+'/'+path.name)
    for name in ('build.gradle.kts','src/main/AndroidManifest.xml'):
        add(project/'app'/name,'apk-sources/'+folder+'/'+name)
for path in stage.iterdir():
    if path.is_file() and path.suffix in ('.py','.json','.stdout','.stderr'):add(path,'drivers/'+path.name)
for folder in ('appsrc','portable-records','failed-driver1','failed-driver2'):
    for path in (stage/folder).rglob('*'):
        if path.is_file():add(path,'drivers/'+folder+'/'+path.relative_to(stage/folder).as_posix())
for path in (stage/'cohort3/source').rglob('*'):
    if path.is_file():add(path,'aar-source-at-7290/'+path.relative_to(stage/'cohort3/source').as_posix())
for name in ('RecoveryProbeFiles.java','RecoveryProbeFilesChecks.java'):
    add(root/'bindings/android/ContinuityPackageConsumer/src/test/java'/name,'integrated-test-host/'+name)
add(root/'artifact/continuity_android_recovery.py','integrated-test-host/continuity_android_recovery.py')
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(members.items())}
archive=destination/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,data)
controls=[]
with tempfile.TemporaryDirectory(prefix='qpc-art-capture-readback-') as work:
    work=Path(work)
    with zipfile.ZipFile(archive) as bundle:
        assert len(bundle.namelist())==len(set(bundle.namelist()))==len(manifest)
        for name,sha in manifest.items():
            data=bundle.read(name);assert hashlib.sha256(data).hexdigest()==sha
            if name.startswith('runtime/'):
                path=work/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    assert reader.verify(work/'runtime',apk['apk_sha256'])==current
    for case in ('omitted-process','wrong-apk','truncated-report','changed-original-result'):
        changed=work/case;shutil.copytree(work/'runtime',changed)
        if case=='omitted-process':
            path=changed/'fixed-STATE.json';value=json.loads(path.read_text());value['calls'].pop();path.write_text(json.dumps(value))
        elif case=='wrong-apk':
            path=changed/'fixed-request/instrument.stdout';path.write_text(path.read_text().replace(apk['apk_sha256'],'0'*64))
        elif case=='truncated-report':
            path=changed/'fixed-recovery-frozen-0/complete-session-report.txt';path.write_bytes(path.read_bytes().rsplit(b'\n',2)[0]+b'\n')
        else:
            path=changed/'cases/fixed/recovery-final-results';data=path.read_bytes();path.write_bytes(data[:-4]+(4).to_bytes(4,'big'))
        try:reader.verify(changed,apk['apk_sha256'])
        except (AssertionError,ValueError):controls.append(case)
        else:raise AssertionError('changed capture admitted: '+case)
assert len(controls)==4
sdk.write_json(destination/'CHECKS.json',{'completed':True,'scope':'current AAR, single accepted API37 phone, first-use account delivery and original cleanup/recovery; shared native protocol engine',
    'source_commit':'7290c6f02b0fdebbaaed5b2916dc68904267710a','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_members':len(manifest),
    'aar_sha256':apk['aar_sha256'],'apk_sha256':apk['apk_sha256'],'runtime':current,'rejected_controls':controls,
    'source_exception':'Only qualification-host RecoveryProbeFiles changed from hard-link publication to writer-locked atomic rename; production AAR source remains7290.',
    'excluded':'Private keys, fixture inputs, journals, environment snapshots, signing keystores, binaries; local AAR/APK retained separately with hashes.',
    'members_sha256':manifest,'release_claim_eligible':False})
print(json.dumps({'archive':str(archive),'members':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'sdk_processes':current['art_sdk_processes'],'controls':len(controls)}))
