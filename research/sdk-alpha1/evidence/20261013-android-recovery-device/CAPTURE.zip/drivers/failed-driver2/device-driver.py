from pathlib import Path
import base64,hashlib,json,os,re,secrets,struct,subprocess,sys

stage=Path(__file__).resolve().parent;run=Path(os.environ['QPC_ART_RUN']).resolve()
mode,profile,inputs,installation,output=sys.argv[1:];inputs=Path(inputs);output=Path(output)
assert profile in ('fixed','recoverable') and mode.startswith(('enrollment-','account-','recovery-'))
label=output.name;assert re.fullmatch('[a-z][a-z0-9.-]{0,63}',label)
proof=json.loads((stage/'apk2/STATE.json').read_text());device=json.loads((stage/'DEVICE.json').read_text())
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.account20261013'
case=run/(profile+'-'+label);case.mkdir(mode=0o700)
state_path=run/(profile+'-STATE.json');state=json.loads(state_path.read_text()) if state_path.exists() else {'inputs':{},'calls':[]}
assert not any(row['label']==label for row in state['calls'])
owned=[];receipts=[]
def save_ports():(case/'OWNED_PORTS.json').write_text(json.dumps(owned)+'\n')
save_ports()
def command(name,args,expected=(0,),timeout=30,fixture=None):
    command=[adb,'-P',str(device['server_port']),'-s',device['serial'],*args]
    result=subprocess.run(command,capture_output=True,text=True,timeout=timeout)
    redacted=list(command)
    if fixture is not None:
        redacted[redacted.index(fixture)]='<bounded fixture packet>'
        assert fixture not in result.stdout and fixture not in result.stderr
    (case/(name+'.stdout')).write_text(result.stdout);(case/(name+'.stderr')).write_text(result.stderr)
    receipt={'argv':redacted,'returncode':result.returncode};(case/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');receipts.append(receipt)
    if result.returncode not in expected or result.stderr:raise RuntimeError(name+' failed; inspect '+str(case/(name+'.stderr')))
    return result.stdout
base_names={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','recovery-scope','recovery-root','recovery-enrollment','enrollment-root','enrollment-intent','grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest','account-operation','account-recipient','account-initiation-0','account-initiation-1','recovery-session','account-sessions','account-selected','account-address','account-address-0','account-address-1'}
peer_names={prefix+'-'+field for prefix in ('initiator','responder') for field in ('account','root','roster-version','roster-digest','device','generation')}|{'family','directory','bootstrap.bundle','tls-peer','tls-peer-name'}
values={}
for p in sorted(inputs.rglob('*')):
    if not p.is_file():continue
    name=p.relative_to(inputs).as_posix()
    if name not in base_names and not any(name=='account-peer-'+str(i)+'/'+leaf for i in (0,1) for leaf in peer_names):continue
    assert not p.is_symlink();value=p.read_bytes();assert 0<len(value)<=65536;values[name]=value
primary=None
try:
    ports={}
    names=('account-address-0','account-address-1') if mode=='account-connect' else ('account-address',) if mode in ('account-send','account-unknown','account-reversed','account-changed','account-omit-retained') else ()
    for name in names:
        value=values[name];match=re.fullmatch(rb'127\.0\.0\.1:(\d+)',value);assert match
        host=int(match[1]);assert 1<=host<=65535
        if host==1:continue
        if host not in ports:
            for attempt in range(8):
                port=host if attempt==0 else 49152+secrets.randbelow(16384)
                result=subprocess.run([adb,'-P',str(device['server_port']),'-s',device['serial'],'reverse','--no-rebind','tcp:'+str(port),'tcp:'+str(host)],capture_output=True,text=True,timeout=15)
                (case/('reverse-'+str(host)+'-'+str(attempt)+'.json')).write_text(json.dumps({'host':host,'port':port,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})+'\n')
                if result.returncode==1 and not result.stdout.strip() and result.stderr.strip()=='adb: error: cannot bind listener: Address already in use':continue
                assert result.returncode==0 and not result.stderr and result.stdout.strip()==str(port)
                owned.append(port);save_ports();ports[host]=port;break
            else:raise RuntimeError('eight owned reverse-port attempts exhausted')
        values[name]=('127.0.0.1:'+str(ports[host])).encode()
    # Only the addressed operation needs a transport address. Previously published
    # account bootstrap endpoints are immutable and are not sent after establishment.
    for name in ('account-address-0','account-address-1'):
        if mode!='account-connect':values.pop(name,None)
    changed={name:value for name,value in values.items() if state['inputs'].get(name)!=hashlib.sha256(value).hexdigest()}
    entries=[]
    for name,value in sorted(changed.items()):
        encoded=name.encode('ascii');entries.append(struct.pack('>H',len(encoded))+encoded+struct.pack('>I',len(value))+value)
    batches=[];batch=[];width=4
    for entry in entries:
        assert len(entry)+4<=45000,'one fixture field exceeds transport budget'
        if width+len(entry)>45000:batches.append(batch);batch=[];width=4
        batch.append(entry);width+=len(entry)
    batches.append(batch);assert len(batches)<=4
    packets=[struct.pack('>I',len(batch))+b''.join(batch) for batch in batches];stages=[]
    for index,packet in enumerate(packets[:-1]):
        encoded=base64.b64encode(packet).decode('ascii');prefix='stage-'+str(index)
        args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation','fixture-stage','-e','label',label+'-'+prefix,'-e','fixture',encoded,pkg+'/dev.qperiapt.continuity.android.tests.AccountDeviceInstrumentation']
        assert sum(len(x.encode())+1 for x in args)<64000
        staged=command(prefix+'-instrument',args,timeout=30,fixture=encoded)
        assert staged.rstrip().endswith('INSTRUMENTATION_CODE: -1') and 'INSTRUMENTATION_RESULT: result='+profile+':fixture-stage:passed\n' in staged
        assert 'INSTRUMENTATION_RESULT: apk_sha256='+proof['apk_sha256']+'\n' in staged
        pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',staged,re.M)[1])
        payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',staged,re.M)[1],validate=True)
        assert payload==hashlib.sha256(packet).digest()
        command(prefix+'-stop',['shell','am','force-stop',pkg]);assert not command(prefix+'-process-absent',['shell','pidof',pkg],expected=(1,)).strip()
        stages.append({'prefix':prefix,'pid':pid,'packet_sha256':payload.hex()})
    packet=packets[-1]
    encoded=base64.b64encode(packet).decode('ascii')
    args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation',mode,'-e','label',label,'-e','fixture',encoded,pkg+'/dev.qperiapt.continuity.android.tests.AccountDeviceInstrumentation']
    assert sum(len(x.encode())+1 for x in args)<64000
    raw=command('instrument',args,timeout=90,fixture=encoded)
    expected=profile+':'+mode+':passed'
    assert raw.rstrip().endswith('INSTRUMENTATION_CODE: -1') and 'INSTRUMENTATION_RESULT: result='+expected+'\n' in raw,'instrumentation failed: '+str(case/'instrument.stdout')
    assert 'INSTRUMENTATION_RESULT: apk_sha256='+proof['apk_sha256']+'\n' in raw
    pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',raw,re.M)[1])
    payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',raw,re.M)[1],validate=True)
    assert 0<len(payload)<=65536
    if mode in ('recovery-session-freeze','recovery-session-ack'):
        report=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: closure_report_payload=([^\n]+)$',raw,re.M)[1],validate=True)
        assert 0<len(report)<=65536 and report.startswith(b'QPC-C-LOSS/1\nreport '+payload.hex().encode()+b'\n')
        (case/'complete-session-report.txt').write_bytes(report)
    command('stop',['shell','am','force-stop',pkg]);assert not command('process-absent',['shell','pidof',pkg],expected=(1,)).strip()
    assert pid not in [row['pid'] for row in state['calls']]
    with output.open('xb') as stream:stream.write(payload)
    state['inputs'].update({name:hashlib.sha256(value).hexdigest() for name,value in changed.items()})
    state['calls'].append({'label':label,'operation':mode,'pid':pid,'apk_sha256':proof['apk_sha256'],'result_sha256':hashlib.sha256(payload).hexdigest(),'fixture_fields':sorted(changed),'fixture_packet_sha256':hashlib.sha256(packet).hexdigest(),'process_absent':True,'stages':stages})
    state_path.write_text(json.dumps(state,indent=2)+'\n')
except BaseException as error:primary=error;raise
finally:
    errors=[]
    for port in list(owned):
        try:
            command('reverse-remove-'+str(port),['reverse','--remove','tcp:'+str(port)])
            owned.remove(port);save_ports()
        except Exception as cleanup:errors.append(repr(cleanup))
    if errors:
        failure=RuntimeError('owned reverse-map cleanup failed: '+repr(errors))
        if primary is not None:raise failure from primary
        raise failure
print(expected)
