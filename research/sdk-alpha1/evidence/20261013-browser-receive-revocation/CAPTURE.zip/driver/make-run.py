from pathlib import Path
root=Path.cwd();stage=root/'target/continuity-browser-receive-revocation'
old=(root/'target/continuity-browser-peer-roster/run.py').read_text()
prefix=old.split('   for case in sys.argv[2:]:')[0];suffix='  finally:browser'+old.split('  finally:browser',1)[1]
prefix=prefix.replace("stage=root/'target/continuity-browser-peer-roster'","stage=root/'target/continuity-browser-receive-revocation'")
prefix=prefix.replace('q-periapt-browser-peer-roster-peer','q-periapt-browser-receive-revocation-peer')
prefix=prefix.replace("allowed={'happy','before','after','cancel'}","allowed={'member-new','revoked-new','member-duplicate','revoked-duplicate'}")
prefix=prefix.replace('Known peer roster admission and revocation','Retained receive descriptor across peer roster revocation')
prefix=prefix.replace('actual installed browser known peer roster admission with original session and required signed witness','actual installed browser retained receive descriptor with real original ciphertext across peer roster admission/revocation')
(stage/'run.py').write_text(prefix+(stage/'body.py.txt').read_text()+suffix)
