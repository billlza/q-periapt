from pathlib import Path
import json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-receive-revocation';clone=root/'target/continuity-browser-publication/source'
paths=[f'research/sdk-alpha1/evidence/20261013-browser-receive-revocation/{n}' for n in ['CAPTURE.zip','CHECKS.json','README.md']]
sdk.require(sdk.command(['git','rev-parse','HEAD'],stage/'base-head',root).decode().strip()=='e858ec00a7b7974fd90066ee2f3e517023f07b86','unexpected source revision')
sdk.require(not sdk.command(['git','diff','--name-only'],stage/'product-status',root),'unexpected tracked changes')
sdk.command(['git','add','--',*paths],stage/'commit-stage',root);sdk.command(['git','diff','--cached','--check'],stage/'commit-check',root)
staged=sdk.command(['git','diff','--cached','--name-only'],stage/'commit-paths',root).decode().splitlines();sdk.require(set(staged)==set(paths),'unexpected staged paths')
sdk.command(['git','commit','-m','Qualify retained session receive after peer revocation'],stage/'commit',root)
head=sdk.command(['git','rev-parse','HEAD'],stage/'head',root).decode().strip();sdk.require(not sdk.command(['git','status','--porcelain'],stage/'main-status',root),'main not clean')
sdk.command(['git','fetch',str(root),'HEAD'],stage/'clone-fetch',clone);sdk.command(['git','checkout','--detach',head],stage/'clone-checkout',clone)
sdk.require(not sdk.command(['git','status','--porcelain'],stage/'clone-status',clone),'clone not clean')
environment=dict(os.environ);environment['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';environment['PYTHONPATH']='artifact'
sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',sdk.snapshot(clone/'artifact/results.json').sha256,head],stage/'source-gate',clone,environment=environment)
sdk.write_json(stage/'FINALIZED.json',{'head':head,'main_clean':True,'clone_clean':True,'source_gate':'passed','release_claim_eligible':False,'pushed':False});print(head)
