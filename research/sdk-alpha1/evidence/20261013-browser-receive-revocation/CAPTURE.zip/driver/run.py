from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-receive-revocation';package=root/'target/continuity-browser-publication/source/target/peer-roster-package-01'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Retained receive descriptor across peer roster revocation</title><script type="module" src="./controller.js"></script>')
session='qpc-peer-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug';authority=binary/'examples/browser_activation_authority';peer=binary/'q-periapt-browser-receive-revocation-peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed browser retained receive descriptor with real original ciphertext across peer roster admission/revocation; same Rust native counterpart over loopback, not independent implementation/deployment/PCS/release evidence','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,peer]},'cases':[],'observations':[]}
allowed={'member-new','revoked-new','member-duplicate','revoked-duplicate'};sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='peer roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'observations':value['result'].get('observations',[])});return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def trace(case,name):
 p=out/'native'/case/name;p.mkdir(mode=0o700,parents=True);return p
def head(value,target):sdk.require(value['version']==str(target['version']) and value['digest']==target['digest'],'wrong canonical peer head')
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="peer_roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("peer_roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    denied=case.startswith('revoked-');consumed=case.endswith('-duplicate')
    native(authority,['prepare',directory],case+'-authority');shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    peer_public=inputs/(key+'-peer.json');native(peer,['prepare',directory,grant,peer_public,trace(case,'prepare')],case+'-peer-prepare')
    args.update(action='session');args['requestId']=success({**args,'sessionAction':'new-request'})['requestId'];args['session']=success({**args,'sessionAction':'establish'})['session'];row['session']=args['session']
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    prepared=parse_strict_json_bytes(native(peer,['send-prepare',directory,session_file,reverse,trace(case,'reverse-prepare')],case+'-reverse-prepare'),label='reverse prepare');sdk.require(prepared['original_dispatched'] and prepared['owner_closed'] and not prepared['consumption_confirmed'],'native message not pending');row['prepared']=prepared;args['reverseMessage']=prepared['message']
    before=parse_strict_json_bytes(native(peer,['send-status',directory,trace(case,'status-pending')],case+'-status-pending'),label='pending status');sdk.require(before['status']=='Committed' and before['session']==args['session'] and before['message']==args['reverseMessage'],'native pending identity/status');row['sender_before']=before
    if consumed:
     received=success({**args,'sessionAction':'receive'});sdk.require(received['application']['calls']==received['application']['effects']==1,'baseline effect');row['baseline_receive']=received
     ack=out/(case+'-baseline-ack.bin');ack.write_bytes(bytes(received['reply']));finished=parse_strict_json_bytes(native(peer,['send-finish',directory,reverse,ack,trace(case,'baseline-finish')],case+'-baseline-finish'),label='baseline consumption');sdk.require(finished['same_original_wire'] and finished['authenticated_browser_consumption'],'baseline ACK not authenticated');row['baseline_sender']=finished
    target_file=inputs/(key+'-target.json');native(peer,['peer-target',directory,2,'revoke' if denied else 'member',target_file],case+'-target');target=json.loads(target_file.read_text())
    peers_before=len(peer_records[key]);received=success({**args,'sessionAction':'receive-after-roster','targetFile':target_file.name,'expectDenied':denied,'alreadyConsumed':consumed});head(received,target);row['received']=received
    sdk.require(len(peer_records[key])==peers_before,'receive boundary unexpectedly dispatched peer traffic')
    if denied:
     sdk.require(received['code']=='Scope' and received['ownerClosed'] and received['callbacks']==0 and received['reply'] is None,'revoked receive released an output')
     sdk.require(received['effect']==(row['baseline_receive']['application'] if consumed else None),'revoked receive changed host state')
     row['reopen_denied']=rejected({**args,'sessionAction':'receive'},'Scope');sdk.require(len(peer_records[key])==peers_before,'revoked reopen dispatched')
    else:
     sdk.require(received['code'] is None and not received['ownerClosed'] and received['callbacks']==(0 if consumed else 1) and received['effect']['calls']==received['effect']['effects']==1,'positive receive control')
     if consumed:sdk.require(received['reply']==row['baseline_receive']['reply'],'member-preserving update changed duplicate ACK')
     duplicate=success({**args,'sessionAction':'receive'});sdk.require(not duplicate['callbackInvoked'] and duplicate['reply']==received['reply'] and duplicate['application']==received['effect'],'duplicate receive changed effect or ACK');row['duplicate']=duplicate
     if not consumed:
      ack=out/(case+'-final-ack.bin');ack.write_bytes(bytes(received['reply']));finished=parse_strict_json_bytes(native(peer,['send-finish',directory,reverse,ack,trace(case,'final-finish')],case+'-final-finish'),label='final consumption');sdk.require(finished['same_original_wire'] and finished['authenticated_browser_consumption'],'positive ACK not authenticated');row['sender_finished']=finished
    after=parse_strict_json_bytes(native(peer,['send-status',directory,trace(case,'status-final')],case+'-status-final'),label='final native status');sdk.require(after['status']==('Committed' if denied and not consumed else 'Acknowledged') and after['message']==args['reverseMessage'] and after['session']==args['session'],'native status fabricated consumption');row['sender_after']=after
    current=success({**args,'action':'activate'});sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'peer update changed local owner');row['current']=current
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(len(row['peer_records'])==2 and not failures,'unexpected bootstrap/fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'callbacks':received['callbacks'],'reply':received['reply'] is not None,'sender_status':after['status']}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
