from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-receive-revocation';package=root/'target/continuity-browser-publication/source/target/peer-roster-package-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
report=load(stage/'run-02/RESULT.json');assert report['completed']
cases={c['case']:c for c in report['cases']};assert set(cases)=={'member-new','revoked-new','member-duplicate','revoked-duplicate'} and len(report['cases'])==4
old=load(stage/'run-01/RESULT.json');assert not old['completed'] and 'member-duplicate-final-finish' in old['failure']
assert 'Durable(Protocol(Retired))' in (stage/'run-01/logs/member-duplicate-final-finish.stderr').read_text()
for name,c in cases.items():
 denied=name.startswith('revoked-');consumed=name.endswith('-duplicate');r=c['received']
 assert c['sender_before']['status']=='Committed' and c['sender_after']['status']==('Committed' if denied and not consumed else 'Acknowledged')
 assert c['sender_before']['message']==c['sender_after']['message']==c['prepared']['message'] and c['sender_before']['session']==c['sender_after']['session']==c['session']
 assert c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey'] and len(c['peer_records'])==2
 assert r['version']=='2'
 if denied:
  assert r['code']=='Scope' and r['ownerClosed'] and r['callbacks']==0 and r['reply'] is None
  assert r['effect']==(c['baseline_receive']['application'] if consumed else None)
  assert c['reopen_denied']['code']=='Scope' and c['reopen_denied']['ownerClosed']
 else:
  assert r['code'] is None and not r['ownerClosed'] and r['callbacks']==(0 if consumed else 1) and r['reply']
  assert r['effect']['calls']==r['effect']['effects']==1 and not c['duplicate']['callbackInvoked'] and c['duplicate']['reply']==r['reply']
  if consumed:assert c['baseline_sender']['authenticated_browser_consumption'] and c['baseline_receive']['reply']==r['reply']
  else:assert c['sender_finished']['authenticated_browser_consumption'] and c['sender_finished']['same_original_wire']
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz') and receipt['source_bound'] and receipt['sources_unchanged']
for n,d in report['native'].items():assert sha(Path(n))==d
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),p
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and not p.name.startswith(('seal.stdout','seal.stderr','finalize.stdout','finalize.stderr','codeql-','HANDOFF')) and p.suffix in ['.py','.js','.json','.stdout','.stderr','.log','.txt']:add(p,'driver/'+p.name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/name,'native-peer/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','authority/witness.rs')
web=Path(load(package/'consumer-location.json')['path'])
for directory in ['run-01','run-02']:
 base=stage/directory;result=load(base/'RESULT.json');add(base/'RESULT.json',directory+'/RESULT.json')
 for p in sorted(base.iterdir()):
  if p.is_file() and p.name!='RESULT.json':add(p,directory+'/'+p.name)
 for part in ['logs','captures','peer']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():add(p,directory+'/'+p.relative_to(base).as_posix())
 for part in ['witness','native']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():raw[directory+'/'+p.relative_to(base).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for c in result['cases']:
  key=directory+'-'+c['case'];folder=base/'witness'/key
  if (folder/'RECORDS.json').is_file():add(folder/'RECORDS.json',directory+'/witness/'+key+'/RECORDS.json')
  for p in sorted((web/'inputs').glob(key+'*')):
   if p.is_file():add(p,'public-inputs/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/name,'package/'+name)
add(root/'research/sdk-alpha1/evidence/20261013-browser-peer-roster/CHECKS.json','peer-roster/CHECKS.json')
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)}
encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();dest=root/'research/sdk-alpha1/evidence/20261013-browser-receive-revocation';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,meta in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==meta['sha256'] and len(z.read(n))==meta['bytes']
checks={'completed':True,'release_claim_eligible':False,'engine_commit':'e858ec00a7b7974fd90066ee2f3e517023f07b86','production_code_changed':False,'cases':sorted(cases),'case_count':4,
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},
 'outcomes':{n:{'callbacks':c['received']['callbacks'],'reply_returned':c['received']['reply'] is not None,'code':c['received']['code'],'sender_before':c['sender_before']['status'],'sender_after':c['sender_after']['status']} for n,c in cases.items()},
 'failed_attempt':'First fixture tried to redeliver an already acknowledged, retired sender outbox after validating duplicate reception. SDK returned Durable(Protocol(Retired)). Corrected duplicate-case fixture reads original sender status and compares the duplicate ACK with the already authenticated baseline. No SDK checks were changed; failed run and original driver retained.',
 'trace_policy':'Complete public operation results, input ciphertext, peer traffic and witness metadata are archived. Repetitive raw witness/native traces remain in closed task-local runs with FULL_RAW_TRACE_MANIFEST.json. Private keys, journal stores and browser profiles are excluded.',
 'scope':'Actual installed Chrome Worker receive path using a session descriptor opened before the roster update, real native ciphertext, original required signed witness and IndexedDB/Web Locks/OPFS. Native counterpart shares the Rust engine and loopback transport. Not automatic distribution, independent implementation, deployment, device coverage, representative performance, PCS or full-release qualification.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Retained browser receive descriptors after peer revocation

Four fresh actual installed browser/native cohorts test the receive half of peer-roster admission on engine revision `e858ec00`. Each establishes an original session, creates a real native ciphertext through the owned SDK, and opens the browser session descriptor before installing the new signed roster. The target either preserves the peer or revokes it with an empty roster. New ciphertext and already consumed duplicates are tested separately.

With membership preserved, new ciphertext invokes the host once and returns an authenticated consumption reply; a duplicate invokes no host callback and returns the exact original ACK. With the peer revoked, both new and duplicate ciphertext return `Scope`, close the owner, execute zero plaintext callbacks and return no reply. The original application effect remains absent for new ciphertext or unchanged for an already consumed duplicate. Fresh session reopening is also refused. Local journal identity and prekey remain unchanged.

The native sender's actual durable status is checked before and after the boundary. An unconsumed revoked message remains `Committed`; it is never reported as acknowledged. Already consumed messages remain `Acknowledged` because their baseline receipt was authenticated before revocation, not because the rejected call produced a new receipt.

The first fixture incorrectly tried to send an already acknowledged outbox again after the positive duplicate test. The SDK correctly returned `Retired`. The corrected fixture compares the returned duplicate ACK against the authenticated baseline and reads the retained sender status. The failed attempt and original driver are retained; no product code or assertion on the receive boundary was weakened.

`CHECKS.json` and `CAPTURE.zip` bind the package, native binaries, fixture code, public inputs and operation results. Full repetitive witness/native raw traces stay task-local with a complete hash manifest. No private signing/wrapping material, journal databases or browser profiles are included. The peer and witness share the Rust implementation and run on loopback. This complements the installed cached-send and reopen revocation tests; it does not establish automatic roster distribution, cross-platform deployment, independent implementation, performance, PCS or release readiness.
''')
print(json.dumps(checks['capture']))
