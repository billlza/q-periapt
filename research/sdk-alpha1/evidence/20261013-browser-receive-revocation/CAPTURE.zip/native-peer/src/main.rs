use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json,Value};
use std::{fs,io::{self,Read},path::{Path,PathBuf},sync::Arc,time::{Duration,SystemTime,UNIX_EPOCH}};
type Result<T> = std::result::Result<T,Box<dyn std::error::Error>>;
fn now()->Result<u64>{Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs())}
fn clock()->io::Result<u64>{SystemTime::now().duration_since(UNIX_EPOCH).map(|v|v.as_secs()).map_err(io::Error::other)}
fn read(path:&Path,max:u64)->Result<Vec<u8>>{let mut v=Vec::new();fs::File::open(path)?.take(max+1).read_to_end(&mut v)?;if v.len() as u64>max{return Err("oversize".into())}Ok(v)}
fn load(path:&Path)->Result<Value>{Ok(serde_json::from_slice(&read(path,1048576)?)?)}
fn bytes(v:&Value,key:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(key).ok_or("missing bytes")?.clone())?)}
fn array(v:&Value,key:&str)->Result<[u8;32]>{Ok(bytes(v,key)?.as_slice().try_into()?)}
fn number(v:&Value,key:&str)->Result<u64>{v.get(key).and_then(Value::as_u64).ok_or_else(||"missing number".into())}
fn publish(path:&Path,value:&Value)->Result<()>{publish_private_bytes(path,&serde_json::to_vec_pretty(value)?)?;Ok(())}
fn policy(v:&Value)->Result<Arc<p::VerifiedSessionPolicy>>{
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(v,"sdk_policy")?,&bytes(v,"sdk_signature")?,&bytes(v,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
 let s=v.get("policies").and_then(|v|v.get("required")).ok_or("policy")?;
 let pin=p::PolicyPin::new(array(v,"family")?,p::PublicKey::decode(&bytes(v,"policy_root")?)?,p::PolicyCheckpoint::from_trusted_state(number(s,"version")?,array(s,"digest")?)?)?;
 Ok(Arc::new(pin.verify(&bytes(s,"wire")?,Arc::new(runtime),now()?)?))
}
fn witness(dir:&Path,v:&Value)->Result<p::AnchorStore>{
 let key=p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
 let signer=p::AnchorSigningKey::open(&dir.join("private-witness.key"),&key,p::SigningKeyId::from_trusted_state(array(v,"witness_signer_id")?)?)?;
 let store=p::AnchorStore::open(&dir.join("private-witness.redb"),key,signer,p::AnchorIdentity::from_trusted_state(array(v,"witness_id")?)?)?;
 if store.pin()?.public_key().encode()!=bytes(v,"witness_public")?{return Err("witness pin differs".into())}Ok(store)
}
struct Witness {dir:PathBuf,config:Value,trace:PathBuf,sequence:u32}
impl p::AnchorTransport for Witness {
 fn exchange(&mut self,request:&[u8],deadline:p::MonotonicInstant)->io::Result<Vec<u8>>{
  let mut operation=||->Result<Vec<u8>>{
   if p::MonotonicInstant::now()>=deadline{return Err(io::Error::from(io::ErrorKind::TimedOut).into())}
   self.sequence+=1;let prefix=self.trace.join(format!("witness-{:03}",self.sequence));
   publish_private_bytes(&prefix.with_extension("request"),request)?;
   let mut store=witness(&self.dir,&self.config)?;let reply=store.handle(request,now()?)?;store.close();
   publish_private_bytes(&prefix.with_extension("reply"),&reply)?;Ok(reply)
  };
  operation().map_err(|e|io::Error::other(e.to_string()))
 }
}
fn paths(base:&Path)->Result<p::EnrollmentPaths>{Ok(p::EnrollmentPaths::new(&base.join("wrap.key"),&base.join("device.key"),&base.join("enrollment.redb"),p::InstallationPaths::new(&base.join("installation.redb"),&base.join("journal.redb"),&base.join("archives.redb"))?)?)}
fn intent(v:&Value)->Result<p::EnrollmentIntent>{Ok(p::EnrollmentIntent::new(p::PublicKey::decode(&bytes(v,"root")?)?,p::DeviceDescription::new(bytes(v,"device")?.as_slice().try_into()?,number(v,"generation")?,array(v,"family")?,p::Validity::new(number(v,"from")?,number(v,"until")?)?)?))}
fn pin(v:&Value)->Result<p::AccountPin>{Ok(p::AccountPin::new(array(v,"account")?,p::PublicKey::decode(&bytes(v,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(v,"version")?,array(v,"digest")?)?,array(v,"family")?)?)}
fn activate(mut pending:p::DeviceEnrollment,dir:&Path,config:&Value,policy:&p::VerifiedSessionPolicy,trace:&Path)->Result<p::EnrolledDevice>{
 let witness_pin=p::AnchorPin::new(p::AnchorIdentity::from_trusted_state(array(config,"witness_id")?)?,p::PublicKey::decode(&bytes(config,"witness_public")?)?);
 let anchor=pending.anchor_client(policy,now()?,witness_pin,Box::new(Witness {dir:dir.to_owned(),config:config.clone(),trace:trace.to_owned(),sequence:0}),Duration::from_secs(5))?;
 Ok(pending.activate(policy,now()?,Some(anchor))?)
}
fn requirements<'a>(a:&'a p::AccountPin,b:&'a p::AccountPin)->Result<p::BootstrapRequirements<'a>>{Ok(p::BootstrapRequirements{initiator:p::ExpectedDevice::new(a,[73;16],1)?,responder:p::ExpectedDevice::new(b,[82;16],1)?,quality:p::PrekeyQuality::OneTimeBoth,directory:p::DirectoryExpectation::from_trusted_state([77;32])?})}
fn prepare(dir:&Path,grant:&Path,output:&Path,trace:&Path)->Result<()>{
 use std::os::unix::fs::PermissionsExt;
 let config=load(&dir.join("PUBLIC.json"))?;let browser_grant=load(grant)?;let policy=policy(&config)?;
 let base=dir.join("peer");fs::create_dir(&base)?;fs::set_permissions(&base,fs::Permissions::from_mode(0o700))?;
 let wrap=p::JournalKey::provision(&base.join("wrap.key"))?;let root_id=p::SigningKeyId::generate()?;
 let root=p::RootSigningKey::provision(&base.join("root.key"),&wrap,root_id)?;publish_private_bytes(&base.join("root-id.bin"),root_id.as_bytes())?;let validity=p::Validity::new(number(&config,"from")?,number(&config,"until")?)?;
 let mut peer=json!({"root":root.public_key()?.encode(),"account":root.account_id()?,"device":Vec::from([82;16]),"generation":1,"family":array(&config,"family")?,"from":validity.from(),"until":validity.until()});
 let original=intent(&peer)?;let mut pending=p::DeviceEnrollment::provision(paths(&base)?,original.clone())?;
 let request=pending.request(now()?)?;let request=p::VerifiedEnrollmentRequest::verify(&request,&original,now()?)?;
 let certificate=root.issue_enrollment(&request,now()?)?;let roster=root.issue_roster(1,validity,&[root.roster_entry(&certificate)?])?;
 peer["certificate"]=json!(certificate);peer["roster"]=json!(roster.as_bytes());peer["version"]=json!(roster.checkpoint().version());peer["digest"]=json!(roster.checkpoint().digest());
 let pin=pin(&peer)?;pending.accept(&bytes(&peer,"certificate")?,&bytes(&peer,"roster")?,&pin,&policy,now()?)?;
 let device=pin.verify_device(&bytes(&peer,"certificate")?,&bytes(&peer,"roster")?,now()?)?;
 let p::InstallationPreparation::RequiresEnrollment(genesis)=pending.prepare(&policy,now()?)? else{return Err("required witness omitted".into())};
 let mut store=witness(dir,&config)?;store.enroll(&genesis,&device,&policy,now()?)?;store.close();
 let mut owner=activate(pending,dir,&config,&policy,trace)?;
 let plan=p::PrekeyPublicationPlan::new([77;32],validity,&[p::LeafKind::SignedClassical,p::LeafKind::LastResortPq,p::LeafKind::OneTimeClassical,p::LeafKind::OneTimePq].map(|kind|p::PrekeyPublicationKey::generate(kind,validity)))?;
 let id=owner.next_prekey_publication_id()?;let cancel=p::Cancellation::default();
 let prepared=owner.prepare_prekey_publication(id,&plan,&policy,p::PrekeyPublicationRun{cancel:&cancel,deadline:p::MonotonicInstant::now()+Duration::from_secs(30)},clock)?;
 let manifest=prepared.manifest();let verified=device.verify_manifest(manifest.as_bytes(),now()?)?;
 let mut proofs=std::collections::BTreeMap::new();
 for i in 0..manifest.leaf_count(){let proof=manifest.proof(i)?;let leaf=verified.verify_leaf(&proof,now()?)?;proofs.insert(leaf.kind() as u8,proof.encode()?);}
 let proof=|kind:p::LeafKind|->Result<&[u8]>{proofs.get(&(kind as u8)).map(Vec::as_slice).ok_or_else(||"required proof".into())};
 let bundle=p::BootstrapBundle::from_materials(p::PrekeyQuality::OneTimeBoth,p::BootstrapMaterials{initiator_credential:&bytes(&browser_grant,"certificate")?,initiator_roster:&bytes(&browser_grant,"roster")?,responder_credential:&bytes(&peer,"certificate")?,responder_roster:&bytes(&peer,"roster")?,responder_manifest:manifest.as_bytes(),signed_classical:proof(p::LeafKind::SignedClassical)?,last_resort_pq:proof(p::LeafKind::LastResortPq)?,one_time_classical:Some(proof(p::LeafKind::OneTimeClassical)?),one_time_pq:Some(proof(p::LeafKind::OneTimePq)?)})?;
 peer["bundle"]=json!(bundle.as_bytes());peer["inventory"]=json!(prepared.inventory_requests().iter().map(|id|id.as_bytes()).collect::<Vec<_>>());
 let mut browser=config.clone();browser["version"]=browser_grant["version"].clone();browser["digest"]=browser_grant["digest"].clone();
 publish(&base.join("BROWSER.json"),&browser)?;publish(&base.join("PUBLIC.json"),&peer)?;publish(output,&peer)?;owner.close();Ok(())
}
struct Effects {base:PathBuf,mode:String,calls:u32,created:u32}
impl p::session_exchange::Consumer for Effects {
 fn commit(&mut self,session:[u8;32],delivery:&p::CommittedPlaintext)->io::Result<()>{
  self.calls+=1;let name=delivery.message_id().as_bytes().iter().map(|v|format!("{v:02x}")).collect::<String>();let path=self.base.join(name);
  let mut value=session.to_vec();value.extend_from_slice(delivery.message_id().as_bytes());value.extend_from_slice(delivery.as_bytes());
  match fs::read(&path){Ok(original)=>{if original!=value{return Err(io::ErrorKind::InvalidData.into())}return Ok(())},Err(e) if e.kind()==io::ErrorKind::NotFound=>{},Err(e)=>return Err(e)}
  if self.mode=="reject-effect"{return Err(io::ErrorKind::StorageFull.into())}
  publish_private_bytes(&path,&value).map_err(io::Error::other)?;self.created+=1;
  if self.mode=="after-effect"{return Err(io::Error::other("external effect outcome unknown"))}Ok(())
 }
}
fn handle(dir:&Path,request:&Path,reply:&Path,trace:&Path,mode:&str)->Result<()>{
 if read(request,32768)?.get(8)==Some(&4) {
  let id:Vec<u8>=serde_json::from_slice(&read(&dir.join("peer/session.json"),4096)?)?;
  let (mut owner,session)=existing_session(dir,id.as_slice().try_into()?,trace)?;
  let cancel=p::Cancellation::default();let response=owner.serve_session_control(&session,&read(request,32768)?,&p::session_exchange::Run::new(&cancel,Duration::from_secs(30))?,clock)?;
  publish_private_bytes(reply,&response)?;println!("{}",json!({"control":true,"reply_bytes":response.len()}));owner.close();return Ok(());
 }

 use std::os::unix::fs::DirBuilderExt;
 let config=load(&dir.join("PUBLIC.json"))?;let base=dir.join("peer");let peer=load(&base.join("PUBLIC.json"))?;let browser=load(&base.join("BROWSER.json"))?;
 let policy=policy(&config)?;let mut owner=activate(p::DeviceEnrollment::open(paths(&base)?,intent(&peer)?)?,dir,&config,&policy,trace)?;
 let a=pin(&browser)?;let b=pin(&peer)?;let bundle=p::BootstrapBundle::from_bytes(&bytes(&peer,"bundle")?)?;
 let context=Arc::new(bundle.verify(Arc::clone(&policy),requirements(&a,&b)?,now()?)?);
 let admitted=owner.parts()?.0.admit_peer(context,p::BootstrapRole::Responder,now()?)?;
 let app=base.join("effects");match fs::DirBuilder::new().mode(0o700).create(&app){Ok(())=>{},Err(e) if e.kind()==io::ErrorKind::AlreadyExists&&app.is_dir()=>{},Err(e)=>return Err(e.into())}
 let mut consumer=Effects{base:app,mode:mode.into(),calls:0,created:0};let cancel=p::Cancellation::default();
 let reply_bytes=owner.serve_session_exchange(&admitted,&read(request,32768)?,&mut consumer,&p::session_exchange::Run::new(&cancel,Duration::from_secs(30))?,clock)?;
 publish_private_bytes(reply,&reply_bytes)?;
 println!("{}",json!({"consumer_calls":consumer.calls,"effects_created":consumer.created,"reply_bytes":reply_bytes.len()}));owner.close();Ok(())
}
fn existing_session(dir:&Path,id:[u8;32],trace:&Path)->Result<(p::EnrolledDevice,p::session_exchange::Session)>{
 let config=load(&dir.join("PUBLIC.json"))?;let base=dir.join("peer");let peer=load(&base.join("PUBLIC.json"))?;let browser=load(&base.join("BROWSER.json"))?;
 let policy=policy(&config)?;let mut owner=activate(p::DeviceEnrollment::open(paths(&base)?,intent(&peer)?)?,dir,&config,&policy,trace)?;
 let a=pin(&browser)?;let b=pin(&peer)?;let bundle=p::BootstrapBundle::from_bytes(&bytes(&peer,"bundle")?)?;
 let reopened=owner.parts()?.0.reopen_peer_bundle(&bundle,policy,requirements(&a,&b)?,p::BootstrapRole::Responder,id,now()?)?;
 Ok((owner,p::session_exchange::Session::from_reopened(&reopened)))
}
struct Capture<'a>{path:&'a Path,calls:u32}
impl p::session_exchange::Transport for Capture<'_>{
 fn exchange(&mut self,wire:&[u8],deadline:p::MonotonicInstant,cancel:&p::Cancellation)->io::Result<Vec<u8>>{
  if cancel.is_cancelled(){return Err(io::ErrorKind::Interrupted.into())}if p::MonotonicInstant::now()>=deadline{return Err(io::ErrorKind::TimedOut.into())}
  self.calls+=1;publish_private_bytes(self.path,wire).map_err(io::Error::other)?;Err(io::Error::other("original frame dispatched; reply unavailable"))
 }
}
struct ReturnReply {request:Vec<u8>,reply:Vec<u8>,calls:u32}
impl p::session_exchange::Transport for ReturnReply {
 fn exchange(&mut self,wire:&[u8],deadline:p::MonotonicInstant,cancel:&p::Cancellation)->io::Result<Vec<u8>>{
  if cancel.is_cancelled(){return Err(io::ErrorKind::Interrupted.into())}if p::MonotonicInstant::now()>=deadline{return Err(io::ErrorKind::TimedOut.into())}
  if wire!=self.request{return Err(io::Error::other("recovery changed original frame"))}self.calls+=1;Ok(self.reply.clone())
 }
}
fn send_prepare(dir:&Path,session_file:&Path,output:&Path,trace:&Path)->Result<()>{
 let session_id:Vec<u8>=serde_json::from_slice(&read(session_file,4096)?)?;let session_id:[u8;32]=session_id.as_slice().try_into()?;
 let (mut owner,session)=existing_session(dir,session_id,trace)?;let message=owner.next_session_message_id(&session,now()?)?;
 let path=dir.join("peer/reverse.json");publish(&path,&json!({"session":session_id,"message":message.as_bytes()}))?;
 let cancel=p::Cancellation::default();let mut carrier=Capture {path:output,calls:0};
 let outcome=owner.deliver_session_message(&session,p::session_exchange::Submission{message,plaintext:b"native to browser",associated_data:b"reverse/v1"},&mut carrier,&p::session_exchange::Run::new(&cancel,Duration::from_secs(30))?,clock);
 if !matches!(outcome,Err(p::session_exchange::Error::Transport(_)))||carrier.calls!=1||owner.parts().is_ok(){return Err("original dispatch failure contract".into())}
 println!("{}",json!({"original_dispatched":true,"consumption_confirmed":false,"owner_closed":true,"session":session_id,"message":message.as_bytes()}));Ok(())
}
fn send_finish(dir:&Path,request:&Path,reply:&Path,trace:&Path)->Result<()>{
 let saved=load(&dir.join("peer/reverse.json"))?;let (mut owner,session)=existing_session(dir,array(&saved,"session")?,trace)?;let message=p::MessageId::from_trusted_state(array(&saved,"message")?)?;
 let mut carrier=ReturnReply{request:read(request,32768)?,reply:read(reply,32768)?,calls:0};let cancel=p::Cancellation::default();
 let outcome=owner.deliver_session_message(&session,p::session_exchange::Submission{message,plaintext:b"native to browser",associated_data:b"reverse/v1"},&mut carrier,&p::session_exchange::Run::new(&cancel,Duration::from_secs(30))?,clock)?;
 if outcome!=p::session_exchange::Consumption::Confirmed||carrier.calls!=1||owner.session_message_status(&session,message)?!=p::MessageStatus::Acknowledged{return Err("consumption not confirmed".into())}
 println!("{}",json!({"same_original_wire":true,"authenticated_browser_consumption":true,"message":message.as_bytes()}));owner.close();Ok(())
}

struct ControlStep { previous:Option<(Vec<u8>,Vec<u8>)>, output:PathBuf, calls:u16 }
impl p::session_exchange::Transport for ControlStep {
 fn exchange(&mut self,wire:&[u8],deadline:p::MonotonicInstant,cancel:&p::Cancellation)->io::Result<Vec<u8>> {
  if cancel.is_cancelled(){return Err(io::ErrorKind::Interrupted.into())}if p::MonotonicInstant::now()>=deadline{return Err(io::ErrorKind::TimedOut.into())}
  self.calls+=1;
  if self.calls==1 {if let Some((request,reply))=&self.previous {if wire!=request{return Err(io::Error::other("control replay changed original"))}return Ok(reply.clone())}}
  if self.calls>2{return Err(io::Error::other("unexpected control exchanges"))}
  publish_private_bytes(&self.output,wire).map_err(io::Error::other)?;Err(io::Error::other("control dispatched; result unavailable"))
 }
}
fn control_step(dir:&Path,target:u64,previous:Option<(&Path,&Path)>,output:&Path,trace:&Path)->Result<()> {
 let id:Vec<u8>=serde_json::from_slice(&read(&dir.join("peer/session.json"),4096)?)?;
 let (mut owner,session)=existing_session(dir,id.as_slice().try_into()?,trace)?;
 let previous=previous.map(|(a,b)|Ok::<_,Box<dyn std::error::Error>>((read(a,32768)?,read(b,32768)?))).transpose()?;
 let expected_calls=if previous.is_some(){2}else{1};let mut carrier=ControlStep {previous,output:output.to_owned(),calls:0};let cancel=p::Cancellation::default();
 let result=owner.drive_session_rekey(&session,target,4,&mut carrier,&p::session_exchange::Run::new(&cancel,Duration::from_secs(30))?,clock);
 match result {
  Ok(done)=>{if done.epoch!=target||output.exists(){return Err("invalid local completion".into())}println!("{}",json!({"done":true,"epoch":done.epoch,"exchanges":done.exchanges}));owner.close();},
  Err(p::session_exchange::Error::Transport(_)) if carrier.calls==expected_calls&&output.is_file()&&owner.parts().is_err()=>println!("{}",json!({"done":false,"original_dispatched":true,"owner_closed":true})),
  other=>return Err(format!("unexpected native control result: {other:?}").into()),
 }Ok(())
}

fn peer_target(dir:&Path,version:u64,kind:&str,output:&Path)->Result<()> {
 let base=dir.join("peer");let config=load(&dir.join("PUBLIC.json"))?;let peer=load(&base.join("PUBLIC.json"))?;
 let wrap=p::JournalKey::open(&base.join("wrap.key"))?;
 let root=if kind=="unknown" {p::RootSigningKey::generate()?} else {p::RootSigningKey::open(&base.join("root.key"),&wrap,p::SigningKeyId::from_trusted_state(read(&base.join("root-id.bin"),32)?.as_slice().try_into()?)?)?};
 let validity=p::Validity::new(number(&config,"from")?,number(&config,"until")?)?;
 let entries=match kind {"member"=>vec![root.roster_entry(&bytes(&peer,"certificate")?)?],"revoke"|"unknown"=>vec![],_=>return Err("target kind".into())};
 let roster=root.issue_roster(version,validity,&entries)?;
 publish(output,&json!({"root":root.public_key()?.encode(),"account":root.account_id()?,"family":array(&config,"family")?,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),"digest":roster.checkpoint().digest()}))?;
 println!("{}",json!({"version":version,"kind":kind}));Ok(())
}
fn send_status(dir:&Path,trace:&Path)->Result<()> {
 let saved=load(&dir.join("peer/reverse.json"))?;let (mut owner,session)=existing_session(dir,array(&saved,"session")?,trace)?;
 let message=p::MessageId::from_trusted_state(array(&saved,"message")?)?;let status=owner.session_message_status(&session,message)?;
 println!("{}",json!({"session":saved["session"],"message":message.as_bytes(),"status":format!("{status:?}")}));owner.close();Ok(())
}
fn main()->Result<()>{
 let args=std::env::args().collect::<Vec<_>>();let mode=args.get(1).ok_or("mode")?;let dir=Path::new(args.get(2).ok_or("directory")?);
 match mode.as_str(){
  "send-status" if args.len()==4=>send_status(dir,Path::new(&args[3]))?,
  "peer-target" if args.len()==6=>peer_target(dir,args[3].parse()?,&args[4],Path::new(&args[5]))?,
  "prepare" if args.len()==6=>prepare(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]))?,
  "handle" if args.len()==7=>{if !["normal","reject-effect","after-effect"].contains(&args[6].as_str()){return Err("mode".into())}handle(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]),&args[6])?;},
  "send-prepare" if args.len()==6=>send_prepare(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]))?,
  "send-finish" if args.len()==6=>send_finish(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]))?,
  "control-start" if args.len()==6=>control_step(dir,args[3].parse()?,None,Path::new(&args[4]),Path::new(&args[5]))?,
  "control-step" if args.len()==8=>control_step(dir,args[3].parse()?,Some((Path::new(&args[4]),Path::new(&args[5]))),Path::new(&args[6]),Path::new(&args[7]))?,
  _=>return Err("arguments".into()),
 }Ok(())
}
