from pathlib import Path
import json,shutil
import rust_sdk_profile as sdk
r=Path.cwd();s=r/'target/continuity-android-joint-policy';consumer=s/'c-consumer-03';shutil.copytree(r/'target/continuity-swift-policy-credential/ipad-01/c-consumer',consumer,ignore=lambda path,names: [n for n in names if n == 'target' or (n == 'tests' and Path(path).name == 'c-consumer')])
for p in (r/'bindings/c/ContinuityPackageConsumer/tests').rglob('*'):
 if p.is_file():sdk.copy(p,consumer/'tests'/p.relative_to(r/'bindings/c/ContinuityPackageConsumer/tests'))
env=json.loads((r/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);cargo=Path(env['RUSTC']).parent/'cargo';sdk.command([str(cargo),'test','--locked','--offline','--no-run','--test','android','--message-format','json','--target-dir',str(s/'host-target-03'),'-j','2'],s/'build-harness-05',consumer,environment=env);print('Android joint policy native harness built')
