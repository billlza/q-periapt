from pathlib import Path
import hashlib,json,subprocess,zipfile
import rust_sdk_profile as sdk
import continuity_android_joint_policy as q
r=Path.cwd();s=r/'target/continuity-android-joint-policy';e=r/'research/sdk-alpha1/evidence/20261014-android-joint-policy'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
items={};results={}
def add(path,name):
 sdk.require(name not in items and path.is_file() and not path.is_symlink(),'capture member '+name)
 items[name]=path.read_bytes()
for surface,labels in [('host',list(q.TESTS)),('device',['recoverable-applied','recoverable-pending'])]:
 for label in labels:
  profile,outcome=label.split('-');committed=outcome=='applied'
  root=s/('host-'+label+('-03' if committed else '-02')) if surface=='host' else s/'device-03'/('run-'+label)
  record=json.loads((root/'RESULT.json').read_text());sdk.require(record['completed'] and record['inputs_unchanged'],'nonterminal capture')
  result=q.verify_execution((root/'execution.stdout').read_bytes(),root/'public',profile,committed)
  sdk.require(result==record['result'],'readback changed')
  prefix=surface+'/'+label+'/';results[surface+'/'+label]=record
  for name in ['RESULT.json','execution.stdout','execution.stderr','catalog.stdout','catalog.stderr']:
   add(root/name,prefix+name)
  for name in q.public(committed):add(root/'public'/('local-'+profile)/name,prefix+'public/local-'+profile+'/'+name)
  if surface=='device':
   device=s/'device-03'/('device-local-'+profile+'-'+outcome);state=json.loads((device/'STATE.json').read_text())
   sdk.require(state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports') and len(state['cases'])==result['foreign_processes'],'device cleanup/census')
   add(device/'STATE.json',prefix+'device-state.json')
   for name in ['final.identity-uninstall.stdout','final.identity-uninstalled.stdout','final.identity-uninstalled.stderr']:
    add(device/name,prefix+name)
   rows=[]
   for call in state['cases']:
    path=device/(call['label']+'-instrument.json');entry=json.loads(path.read_text())
    sdk.require(entry['exit_code']==0,'instrumentation return')
    # Keep hash/length provenance without republishing full provisioning argv.
    rows.append({'label':call['label'],'command_record_sha256':sha(path),'recorded_argument_bytes':sum(len(x.encode())+1 for x in entry['command'])})
   sdk.require(max(x['recorded_argument_bytes'] for x in rows)<60000,'device argument budget')
   items[prefix+'argument-lengths.json']=(json.dumps(rows,indent=2)+'\n').encode()
for old in ['host-fixed-applied-01','host-recoverable-pending-01','host-fixed-applied-02','host-recoverable-applied-02','device-02/run-recoverable-applied']:
 for name in ['RESULT.json','execution.stdout','execution.stderr']:
  add(s/old/name,'failures/'+old.replace('/','-')+'/'+name)
for name in ['ADB_ARGUMENT_BOUNDARY.json','ACTIONLINT.json','actionlint-before.stdout','actionlint-after.stdout',
             'build-harness-04.stdout','build-harness-04.stderr','build-harness-05.stdout','build-harness-05.stderr']:
 add(s/name,'checks/'+name)
for name in ['RESULT.json','main-compile.stdout','main-compile.stderr','test-compile.stdout','test-compile.stderr','jni-compile.stdout','jni-compile.stderr','boundary.stdout','boundary.stderr']:
 add(s/'jni03'/name,'checks/jni/'+name)
for name in ['PACKAGE.json','PREPARED_APK.json','agp-prepared/STATE.json','agp-prepared/build.stdout','agp-prepared/build.stderr','signature.stdout','signature.stderr']:
 add(s/'device-03'/name,'package/'+name)
for name in ['run-host-03.py','prepare-runtime-06.py','build-harness-05.py','boundary.py','capture.py']:
 add(s/name,'tooling/'+name)
for name in ['build-aar.py','build-consumer.py','prepare-apk.py','device-driver.py','run-device.py']:
 add(s/'device-03'/name,'tooling/device/'+name)
# Every runtime Java/JNI source is identical to both the host builder and actual AAR builder.
source=r/'bindings/android/ContinuityPackageConsumer';device=s/'device-03/source';host=s/'jni03/source'
for directory in ['src/main','jni']:
 for path in (source/directory).rglob('*'):
  if path.is_file():
   relative=path.relative_to(source);sdk.require(path.read_bytes()==(device/relative).read_bytes()==(host/relative).read_bytes(),'runtime source drift '+str(relative))
for path in (device/'src').rglob('*'):
 if path.is_file():sdk.require(path.read_bytes()==(source/path.relative_to(device)).read_bytes(),'APK fixture source drift')
with zipfile.ZipFile(s/'device-03/q-periapt-continuity-android-0.0.0.aar') as z:
 sdk.require(z.read('classes.jar')==(s/'jni03/qperiapt-continuity-android.jar').read_bytes(),'AAR/JNI Java artifact mismatch')
# Include the changed source and public fixture implementation, excluding private cohorts.
changed=subprocess.run(['git','ls-files','--modified','--others','--exclude-standard','--','.github/workflows/ci.yml','artifact','bindings'],check=True,capture_output=True,text=True).stdout.splitlines()
for name in sorted(set(changed)):add(r/name,'source/'+name)
items['SOURCE_SHA256.json']=(json.dumps({name:hashlib.sha256(value).hexdigest() for name,value in items.items() if name.startswith('source/')},indent=2)+'\n').encode()
e.mkdir(parents=True,exist_ok=True);archive=e/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name,value in sorted(items.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,value)
sdk.write_json(e/'CAPTURE.json',{'completed':True,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(items),
 'scope':'Four host JNI routes and two accepted physical API37 ART routes for local joint G/T; independent issuer and same-engine C counterparty',
 'host_processes':sum(v['result']['foreign_processes'] for k,v in results.items() if k.startswith('host/')),
 'physical_processes':sum(v['physical_processes'] for k,v in results.items() if k.startswith('device/')),
 'aar_sha256':sha(s/'device-03/q-periapt-continuity-android-0.0.0.aar'),'apk_sha256':sha(s/'device-03/consumer.apk'),
 'java_sha256':sha(s/'jni03/qperiapt-continuity-android.jar'),'release_claim_eligible':False,'routes':results})
print('CAPTURE',sha(archive),archive.stat().st_size,len(items))
