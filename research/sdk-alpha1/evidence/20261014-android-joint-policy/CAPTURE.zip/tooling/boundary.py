from pathlib import Path
import hashlib,json,os,shutil,sys,zipfile
import rust_sdk_profile as sdk
r=Path.cwd();s=r/'target/continuity-android-joint-policy';out=s/sys.argv[1];out.mkdir();original=r/'bindings/android/ContinuityPackageConsumer';source=out/'source';shutil.copytree(original,source)
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=lambda root:{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
before=files(source);header=r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h';header_hash=sha(header);lib=r/'target/continuity-policy-credential-interop/native-target/debug/libq_periapt_continuity_c_consumer.dylib';lib_hash=sha(lib)
record={'completed':False,'scope':'Packaged Java/JNI boundary checks with current source-linked C engine; not installed lifecycle or physical acceptance','source_files':before,'native_sha256':lib_hash,'header_sha256':header_hash}
env={k:v for k,v in os.environ.items() if k not in {'JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','CLASSPATH'} and not k.startswith(('JAVA_','GRADLE_','KOTLIN_','QPERIAPT_','QPC_','LD_','DYLD_'))}
def run(args,name):return sdk.command([str(x) for x in args],out/name,r,environment=env)
try:
 sdk.require(run([jdk/'bin/javac','--version'],'javac-version').startswith(b'javac 25'),'JDK version')
 classes=out/'classes';tests=out/'tests';classes.mkdir();tests.mkdir()
 run([jdk/'bin/javac','--release','11','-Xlint:all','-Werror','-d',classes,*sorted((source/'src/main/java').rglob('*.java'))],'main-compile')
 jar=out/'qperiapt-continuity-android.jar'
 with zipfile.ZipFile(jar,'x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(classes.rglob('*.class')):
   info=zipfile.ZipInfo(p.relative_to(classes).as_posix());info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
 run([jdk/'bin/javac','--release','17','-Xlint:all','-Werror','-cp',jar,'-d',tests,*sorted((source/'src/test/java').glob('*.java'))],'test-compile')
 clang=Path(run(['xcrun','--sdk','macosx','--find','clang'],'clang-path').decode().strip()).resolve()
 sdkroot=Path(run(['xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()).resolve()
 installed=out/'installed';installed.mkdir();shutil.copyfile(lib,installed/lib.name);shutil.copyfile(header,installed/'qpc_owner.h')
 bridge=installed/'libqperiapt_continuity_jni.dylib'
 run([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-isysroot',sdkroot,'-I'+str(installed),'-I'+str(jdk/'include'),'-I'+str(jdk/'include/darwin'),'-dynamiclib',*sorted((source/'jni').glob('*.c')),'-L'+str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',bridge],'jni-compile')
 result=run([jdk/'bin/java','--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(installed),'-cp',str(jar)+os.pathsep+str(tests),'dev.qperiapt.continuity.android.BridgeProbe'],'boundary')
 sdk.require(result==b'configuration:bridge:passed\n' and not (out/'boundary.stderr').read_bytes(),'boundary output')
 sdk.require(files(source)==before and files(original)==before and sha(header)==header_hash and sha(lib)==lib_hash,'consumed inputs drift')
 record.update(completed=True,jar_sha256=sha(jar),jni_sha256=sha(bridge),sources_unchanged=True)
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',record)
print(json.dumps({k:v for k,v in record.items() if k!='source_files'}))
