from pathlib import Path
import hashlib,json,os,sys
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_contract as contract
import continuity_android_joint_policy as qualification
r=Path.cwd();d=Path(__file__).resolve().parent;s=d.parent;label=sys.argv[1];sdk.require(label in qualification.TESTS,'route');out=d/('run-'+label);out.mkdir()
consumer=s/'c-consumer-03';binary=c.built_artifact((s/'build-harness-05.stdout').read_bytes(),consumer,s/'host-target-03/debug',library=False,test_name='android')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();installed=s/'jni03/installed';profile,outcome=label.split('-');committed=outcome=='applied';prepared=json.loads((d/'PREPARED_APK.json').read_text());sdk.require(prepared['completed'],'APK not prepared')
inputs={str(p):sha(p) for p in [binary,d/'device-driver.py',d/'consumer.apk',installed/'qpc-c-client',installed/'qpc-configuration-client',installed/'libq_periapt_continuity_c_consumer.dylib']}
sdk.require(inputs[str(d/'consumer.apk')]==prepared['apk_sha256'],'APK differs')
env={k:v for k,v in os.environ.items() if not k.startswith(('QPC_','QPERIAPT_','LD_','DYLD_'))}
env.update(QPC_ANDROID_JOINT_OUTCOME=outcome,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(d/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=str(installed/'qpc-c-client'),QPC_CONFIGURATION_TARGET_CLIENT=str(installed/'qpc-configuration-client'))
record={'completed':False,'release_claim_eligible':False,'route':label,'inputs':inputs,'apk_sha256':prepared['apk_sha256'],'aar_sha256':prepared['aar_sha256'],'scope':'Accepted API37 physical phone, actual R8 APK containing current AAR, source-linked C peer and independent host issuer/witness; original application message; no independent protocol implementation claim'}
try:
 catalog=sdk.command([str(binary),'--list'],out/'catalog',consumer,environment=env);contract.verify_catalog(catalog)
 stdout=sdk.command([str(binary),'--exact',qualification.TESTS[label],'--nocapture'],out/'execution',consumer,environment=env)
 result=qualification.verify_execution(stdout,out/'cases',profile,committed)
 state=json.loads((d/('device-local-'+profile+'-'+outcome)/'STATE.json').read_text())
 sdk.require(state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports'), 'device completion or cleanup missing')
 sdk.require(len(state['cases'])==result['foreign_processes'] and len({row['pid'] for row in state['cases']})==len(state['cases']),'ART process census')
 for row in state['cases']:
  path=out/'cases'/('local-'+profile)/row['label'];sdk.require(sha(path)==row['result_sha256'] and row['process_absent_after_stop'] and row['installed_apk_sha256']==prepared['apk_sha256'],'ART result provenance')
 for name in qualification.public(committed):sdk.copy(out/'cases'/('local-'+profile)/name,out/'public'/('local-'+profile)/name)
 sdk.require(qualification.verify_execution(stdout,out/'public',profile,committed)==result,'public readback differs')
 sdk.require(all(sha(Path(p))==digest for p,digest in inputs.items()),'live inputs changed')
 record.update(completed=True,result=result,physical_processes=len(state['cases']),cleanup=True,inputs_unchanged=True)
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',record)
print(json.dumps(record))
