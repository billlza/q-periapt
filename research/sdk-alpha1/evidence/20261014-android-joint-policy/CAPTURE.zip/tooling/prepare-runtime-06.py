from pathlib import Path
import hashlib,json,os
import rust_sdk_profile as sdk
import continuity_android_jni as android
r=Path.cwd();s=r/'target/continuity-android-joint-policy';j=s/'jni03';source=s/'c-consumer-03';installed=j/'installed'
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
record=json.loads((j/'RESULT.json').read_text());sdk.require(record['completed'],'JNI boundary incomplete')
env={k:v for k,v in os.environ.items() if not k.startswith(('QPC_','QPERIAPT_','LD_','DYLD_'))}
def run(args,name):return sdk.command([str(x) for x in args],s/(name+'-06'),r,environment=env)
cc=Path(run(['xcrun','--sdk','macosx','--find','clang'],'runtime-clang').decode().strip())
platform=Path(run(['xcrun','--sdk','macosx','--show-sdk-path'],'runtime-sdk').decode().strip())
common=[cc,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,'-I',source,'-L',installed,'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path']
run([*common,'-pthread',source/'client.c',source/'recovery_client.c',source/'opening_client.c','-o',installed/'qpc-c-client'],'runtime-client')
run([*common,source/'first_configuration_client.c','-o',installed/'qpc-configuration-client'],'runtime-target-client')
driver=android._driver(installed,jdk/'bin/java',j/'qperiapt-continuity-android.jar',j/'tests',installed)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p):sha(p) for base in (source,j/'source',j/'tests',installed) for p in base.rglob('*') if p.is_file()};inputs[str(j/'qperiapt-continuity-android.jar')]=sha(j/'qperiapt-continuity-android.jar')
sdk.write_json(s/'RUNTIME_INPUTS_06.json',{'files':inputs,'driver':str(driver),'source_linked':True})
print('Native peer, target client and foreign-process driver prepared')
