"""Read a terminal job artifact and preserve its exact public bytes."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import subprocess
import zipfile

out = Path(__file__).resolve().parent
head = '115fb323c9082f4db573ff2fdbb17c75c4c3f372'
api = lambda path: subprocess.check_output(['gh', 'api', 'repos/billlza/q-periapt/' + path], timeout=180 if path.endswith('/zip') else 60)
job = json.loads(api('actions/jobs/117843019701'))
assert job['head_sha'] == head and job['run_id'] == 39184186420
assert job['status'] == 'completed' and job['conclusion'] == 'success'
a = next(a for a in json.loads(api('actions/runs/39184186420/artifacts'))['artifacts']
         if a['name'] == 'independent-bootstrap-ubuntu-24.04')
assert not a['expired'] and a['workflow_run']['head_sha'] == head and a['size_in_bytes'] < 64 * 1024**2
path = out / 'linux-115f.zip'
if not path.exists():
    path.write_bytes(api('actions/artifacts/' + str(a['id']) + '/zip'))
data = path.read_bytes()
assert len(data) == a['size_in_bytes'] and 'sha256:' + hashlib.sha256(data).hexdigest() == a['digest']
(out / 'ARTIFACT.json').write_text(json.dumps(a, indent=2) + '\n')
(out / 'JOB.json').write_text(json.dumps(job, indent=2) + '\n')
folder = out / 'public'
folder.mkdir(exist_ok=False)
with zipfile.ZipFile(path) as z:
    items = z.infolist()
    assert len(items) == len({i.filename for i in items}) < 18000
    assert sum(i.file_size for i in items) < 384 * 1024**2
    assert z.read('source-head.txt').decode().strip() == head
    assert 'x86_64' in z.read('host.txt').decode()
    assert z.read('rustc.txt').decode().startswith('rustc 1.98.1 ') and 'host: x86_64-unknown-linux-gnu' in z.read('rustc.txt').decode()
    for i in items:
        name = PurePosixPath(i.filename)
        assert not i.is_dir() and not name.is_absolute() and '..' not in name.parts
        assert str(name) == i.filename and '\\' not in i.filename and not i.flag_bits & 1
        assert not stat.S_ISLNK(i.external_attr >> 16)
        body = z.read(i)
        assert not body.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02', b'QPREFS03', b'QPREFS04', b'QPREFW01', b'QPREFS05', b'QPREFS06', b'QPREFS07', b'QPREFS08', b'QPRFLC01', b'QPRFLI01', b'QPREGS01'))
        if i.filename.endswith(('.stdout', '.stderr')) and re.search(rb'(?mi)^\s*(error:|warning:)', body):
            # Exact typed negative importer outcomes are expected evidence. No
            # other warning/error output is admitted by this exception.
            match = re.fullmatch(r'public-inputs/(local|witness)/(native-(?:wrong-quality|expired-advertisement|tampered-[0-6]))\.stderr', i.filename)
            assert match is not None, i.filename
            profile, case = match.groups()
            expected_error = 'Scope' if case == 'native-wrong-quality' else ('Validity' if case == 'native-expired-advertisement' else 'Authentication')
            assert body == ('Error: ' + expected_error + '\n').encode()
            report = json.loads(z.read('public-inputs/' + profile + '/RESULT.json'))
            rows = [r for r in report['native_imports'] if r['case'] == case]
            assert len(rows) == 1 and rows[0]['exit'] == 1 and rows[0]['stderr_sha256'] == hashlib.sha256(body).hexdigest()
            stdout = z.read('public-inputs/' + profile + '/' + case + '.stdout')
            assert not stdout and rows[0]['stdout_sha256'] == hashlib.sha256(stdout).hexdigest()
        target = folder.joinpath(*name.parts)
        target.parent.mkdir(exist_ok=True, parents=True)
        with target.open('xb') as f:
            f.write(body)
print(json.dumps({'run': job['run_id'], 'job': job['id'], 'head': head, 'artifact_id': a['id'],
                  'artifact_bytes': len(data), 'artifact_digest': a['digest'], 'members': len(items)}))
