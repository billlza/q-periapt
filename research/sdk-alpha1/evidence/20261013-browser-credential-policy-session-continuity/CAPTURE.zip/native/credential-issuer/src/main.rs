use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json,Value};
use std::{fs,io::Read,path::Path,time::{SystemTime,UNIX_EPOCH}};
type Result<T> = std::result::Result<T,Box<dyn std::error::Error>>;
fn now()->Result<u64>{Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs())}
fn load(path:&Path)->Result<Value>{let mut b=Vec::new();fs::File::open(path)?.take(1048577).read_to_end(&mut b)?;if b.len()>1048576{return Err("oversize issuer input".into())}Ok(serde_json::from_slice(&b)?)}
fn bytes(v:&Value,k:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(k).ok_or("missing bytes")?.clone())?)}
fn array(v:&Value,k:&str)->Result<[u8;32]>{Ok(bytes(v,k)?.as_slice().try_into()?)}
fn number(v:&Value,k:&str)->Result<u64>{v[k].as_u64().ok_or_else(||"missing number".into())}
fn decimal(v:&Value,k:&str)->Result<u64>{Ok(v[k].as_str().ok_or("missing decimal string")?.parse()?)}
fn main()->Result<()>{
 let args=std::env::args().collect::<Vec<_>>();if args.get(1).is_some_and(|v|v=="--witness"){return approve_witness(&args)}if args.len()!=6{return Err("directory original-grant request output profile".into())}
 let dir=Path::new(&args[1]);let cfg=load(&dir.join("PUBLIC.json"))?;let original=load(Path::new(&args[2]))?;let request=load(Path::new(&args[3]))?;let profile=&args[5];if !["local","required"].contains(&profile.as_str()){return Err("profile".into())}
 let policy=&cfg["policies"][profile];
 if bytes(&request,"original_credential")?!=bytes(&original,"certificate")?||bytes(&request,"previous_credential")?!=bytes(&original,"certificate")?||bytes(&request,"original_roster")?!=bytes(&original,"roster")?||bytes(&request,"previous_roster")?!=bytes(&original,"roster")?||decimal(&request,"original_roster_version")?!=number(&original,"version")?||decimal(&request,"previous_roster_version")?!=number(&original,"version")?||array(&request,"original_roster_digest")?!=array(&original,"digest")?||array(&request,"previous_roster_digest")?!=array(&original,"digest")?||array(&request,"original_policy_digest")?!=array(policy,"digest")?||decimal(&request,"current_policy_version")?!=number(policy,"version")?||array(&request,"current_policy_digest")?!=array(policy,"digest")?||!request["current_policy_authorization"].is_null(){return Err("request differs from independently retained registration/policy".into())}
 let pin=p::AccountPin::new(array(&cfg,"account")?,p::PublicKey::decode(&bytes(&cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&original,"version")?,array(&original,"digest")?)?,array(&cfg,"family")?)?;
 let previous=pin.verify_historical_device(&bytes(&original,"certificate")?,&bytes(&original,"roster")?)?;
 let wrap=p::JournalKey::open(&dir.join("private-wrap.key"))?;let root=p::RootSigningKey::open(&dir.join("private-root.key"),&wrap,p::SigningKeyId::from_trusted_state(fs::read(dir.join("root-id.bin"))?.as_slice().try_into()?)?)?;
 let at=now()?;let until=number(&cfg,"until")?.checked_add(600).ok_or("validity overflow")?;
 let successor=root.issue_credential_extension(&previous,until,at)?;
 let roster=root.issue_roster(number(&original,"version")?.checked_add(1).ok_or("version overflow")?,p::Validity::new(number(&cfg,"from")?,until.checked_add(60).ok_or("roster overflow")?)?,&[root.roster_entry(&successor)?])?;
 let target=p::AccountPin::new(array(&cfg,"account")?,root.public_key()?,roster.checkpoint(),array(&cfg,"family")?)?;
 let operation=p::CredentialRenewalId::from_trusted_state(array(&request,"operation")?)?;
 let authorization=p::CredentialRenewalAuthorization{operation,previous:previous.roster().checkpoint(),policy_digest:array(policy,"digest")?};
 let grant=root.issue_credential_renewal(p::CredentialRenewalMaterials{original_credential:&bytes(&request,"original_credential")?,previous_credential:&bytes(&request,"previous_credential")?,previous_roster:&bytes(&request,"previous_roster")?,successor_credential:&successor,successor_roster:roster.as_bytes()},&authorization,&target,at)?;
 let verified=p::VerifiedCredentialRenewal::verify(grant.as_bytes(),&target,authorization.policy_digest,at)?;
 if verified.operation()!=operation||verified.original_storage_owner()!=array(&request,"original_owner")?||verified.previous_device().credential_digest()!=previous.credential_digest(){return Err("issued G scope differs".into())}
 publish_private_bytes(Path::new(&args[4]),&serde_json::to_vec_pretty(&json!({"grant":grant.as_bytes(),"certificate":successor,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),"digest":roster.checkpoint().digest(),"operation":operation.as_bytes(),"statement":verified.statement_digest()}))?)?;
 println!("{}",json!({"issued_and_verified":true,"operation":operation.as_bytes(),"original_owner":verified.original_storage_owner(),"previous_expired":at>=decimal(&request,"previous_valid_until")?,"target_version":roster.checkpoint().version(),"same_key_and_generation":verified.previous_device().generation()==verified.successor_device().generation()}));Ok(())
}

fn approve_witness(args:&[String])->Result<()> {
 if args.len()!=6{return Err("--witness directory retained-renewal metadata prepare|cancel".into())}
 let dir=Path::new(&args[2]);let cfg=load(&dir.join("PUBLIC.json"))?;let renewed=load(Path::new(&args[3]))?;
 let bytes_metadata=fs::read(&args[4])?;if bytes_metadata.len()>1024{return Err("metadata oversize".into())}
 let pin=p::AccountPin::new(array(&cfg,"account")?,p::PublicKey::decode(&bytes(&cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&renewed,"version")?,array(&renewed,"digest")?)?,array(&cfg,"family")?)?;
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(&cfg,"sdk_policy")?,&bytes(&cfg,"sdk_signature")?,&bytes(&cfg,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
 let v=&cfg["policies"]["required"];
 let policy_pin=p::PolicyPin::new(array(&cfg,"family")?,p::PublicKey::decode(&bytes(&cfg,"policy_root")?)?,p::PolicyCheckpoint::from_trusted_state(number(v,"version")?,array(v,"digest")?)?)?;
 let policy=policy_pin.verify_historical(&bytes(v,"wire")?)?;
 let key=p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
 let signer=p::AnchorSigningKey::open(&dir.join("private-witness.key"),&key,p::SigningKeyId::from_trusted_state(array(&cfg,"witness_signer_id")?)?)?;
 let mut store=p::AnchorStore::open(&dir.join("private-witness.redb"),key,signer,p::AnchorIdentity::from_trusted_state(array(&cfg,"witness_id")?)?)?;
 if store.pin()?.public_key().encode()!=bytes(&cfg,"witness_public")?{return Err("wrong witness".into())}
 match args[5].as_str(){
  "prepare"=>{
   let at=now()?;let grant=p::VerifiedCredentialRenewal::verify(&bytes(&renewed,"grant")?,&pin,array(v,"digest")?,at)?;
   let current=policy_pin.verify(&bytes(v,"wire")?,std::sync::Arc::new(runtime),at)?;
   let proposal=p::AnchorCredentialRenewalProposal::from_trusted_state(&bytes_metadata)?;
   let state=store.prepare_credential_renewal(proposal,&grant,&current,at)?;
   if state!=p::AnchorCredentialRenewalState::Prepared{return Err("not Prepared".into())}
  },
  "cancel"=>{
   let grant=p::HistoricalCredentialRenewal::verify(&bytes(&renewed,"grant")?,&pin,array(v,"digest")?)?;
   let cancellation=p::AnchorCredentialRenewalCancellation::from_trusted_state(&bytes_metadata)?;
   let state=store.close_unprepared_credential_renewal(cancellation,&grant,&policy)?;
   if state!=p::AnchorCredentialCancellationState::Closed{return Err("not Closed".into())}
  },
  _=>return Err("witness action".into())
 }
 store.close();println!("{}",json!({"approved":args[5],"operation":renewed["operation"]}));Ok(())
}
