from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-credential-policy-sessions';package=root/'target/continuity-browser-publication/source/target/policy-session-package-01'
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/('controller-kill.js' if name=='controller.js' else name),web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Session continuity across original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug';authority=stage/'witness-target/debug/examples/browser_activation_authority';provisioner=root/'target/continuity-browser-policy-sessions/native-target/debug/q-periapt-browser-policy-session-authority';roster=stage/'issuer-target/debug/q-periapt-browser-credential-policy-issuer';credential=stage/'issuer-target/debug/q-periapt-browser-credential-policy-g-issuer';peer=root/'target/continuity-browser-policy-sessions/native-v2-target/debug/q-periapt-browser-policy-session-peer-v2'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
state={'completed':False,'scope':'Actual installed browser G then independent P with independently registered C1, original pending ciphertext/control replay, recovery and bidirectional traffic; same Rust implementation and loopback, not independent implementation/PCS/release','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,provisioner,roster,credential,peer]},'cases':[],'observations':[]}
allowed={'live','loss','kill-ack','expired-chain'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster session result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'observations':value['result'].get('observations',[])});return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def native_trace(case,name):
 trace=out/'native'/case/name;trace.mkdir(mode=0o700,parents=True);return trace
def peer_result(args,label):return parse_strict_json_bytes(native(peer,args,label),label=label)
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_session_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_session_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(provisioner,['prepare-expiring-policy' if case=='expired-chain' else 'prepare',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    if case=='expired-chain':
     cfg['peer_until']=cfg['until'];cfg['until']=int(time.time())+120
     cfg['description'][64:72]=list(cfg['until'].to_bytes(8,'big'))
     (directory/'PUBLIC.json').write_text(json.dumps(cfg))
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(provisioner,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace(case,'prepare')],case+'-peer-prepare')
    peer_data=json.loads((inputs/(key+'-peer.json')).read_text())
    args['requestId']=success({**args,'action':'session','sessionAction':'new-request'})['requestId']
    established=success({**args,'action':'session','sessionAction':'establish'});args['session']=established['session'];row['session']=args['session'];row['requestId']=args['requestId'];(directory/'peer/session.json').write_text(json.dumps(args['session']))
    args['message']=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['message']=args['message']
    row['pending_delivery']=rejected({**args,'action':'session','sessionAction':'send','peerMode':'drop-ack'},'PeerTransport')
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'lost application ACK not retained')
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    reverse_prepared=peer_result(['send-prepare',directory,session_file,reverse,native_trace(case,'reverse-prepare')],case+'-reverse-prepare');sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'],'native pending outcome');row['reverse_prepared']=reverse_prepared;args['reverseMessage']=reverse_prepared['message']
    row['pending_rekey']=rejected({**args,'action':'session','sessionAction':'drive-rekey','target':1,'peerMode':'control-drop-first'},'PeerTransport')
    pending=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(pending['confirmed']=='0' and pending['pending']=='1','original pending control absent');row['progress_before']=pending
    args['operationId']=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation'];row['credential_operation']=args['operationId']
    if case=='expired-chain':
     row['real_expiry']={'credential_until':cfg['until'],'policy_until':cfg['policy_until'],'pending_at':int(time.time())}
     sdk.require(time.time()<cfg['until']<cfg['policy_until'],'invalid expiry ordering')
     print(json.dumps({'case':case,'waiting_for_credential_expiry':cfg['until']+1}),flush=True)
     while time.time()<=cfg['until']:time.sleep(min(10,max(0.1,cfg['until']+1-time.time())))
     row['real_expiry']['credential_renew_at']=int(time.time())
    g_request=success({**args,'action':'credential-request','historicalOnly':True});row['credential_request']=g_request
    g_file=out/(case+'-credential-request.json');sdk.write_json(g_file,g_request['requestValue']);g_approval=inputs/(key+'-renewal.json')
    row['credential_issued']=parse_strict_json_bytes(native(credential,[directory,grant,g_file,g_approval,'required'],case+'-credential-issuer'),label='credential issuer')
    registered=json.loads(g_approval.read_text());shutil.copyfile(g_approval,directory/'REGISTERED_G.json');args['statement']=registered['statement']
    row['credential_staged']=success({**args,'action':'stage-credential'})
    g_prepared=success({**args,'action':'prepare-credential'});row['credential_prepared']=g_prepared;args['credentialProposal']=g_prepared['proposal']
    g_proposal=out/(case+'-credential-proposal.bin');g_proposal.write_bytes(bytes(g_prepared['proposal']))
    native(credential,['--witness',directory,g_approval,g_proposal,'prepare'],case+'-credential-witness')
    if case in ['loss','kill-ack']:
     mode='drop-after-advance' if case=='loss' else 'drop-ack'
     row['credential_loss']=rejected({**args,'action':'commit-credential','mode':mode},'WitnessTransport')
     row['credential_interrupted']=success({**args,'action':'recover-credential','historicalOnly':True})
     sdk.require(row['credential_interrupted']['status']['phase']==(2 if case=='loss' else 4),'wrong G terminal')
     row['credential_final']=success({**args,'action':'reconcile-credential','historicalOnly':True})
    else:row['credential_final']=success({**args,'action':'commit-credential'})
    sdk.require(row['credential_final']['phase']==4,'G not committed')
    retired=success({**args,'action':'recover-credential','historicalOnly':True});sdk.require(retired['proposal'] is None and retired['status']==row['credential_final'],'G not retired')
    row['peer_credential_admission']=peer_result(['admit-browser',directory,g_approval,native_trace(case,'admit-browser')],case+'-peer-credential')
    sdk.require(row['peer_credential_admission']['admitted'] and row['peer_credential_admission']['same_original_journal'] and row['peer_credential_admission']['session']==args['session'],'peer G did not preserve original session')
    row['after_g']=success({**args,'action':'session','sessionAction':'rekey-progress'})
    sdk.require(row['after_g']==pending,'G changed original PQ state')
    if case=='expired-chain':
     sdk.require(time.time()<cfg['policy_until'],'P0 expired before completed G and peer admission')
     print(json.dumps({'case':case,'waiting_for_policy_expiry':cfg['policy_until']+1}),flush=True)
     while time.time()<=cfg['policy_until']:time.sleep(min(10,max(0.1,cfg['policy_until']+1-time.time())))
     row['real_expiry']['policy_renew_at']=int(time.time())
    args['operationId']=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']
    request=success({**args,'action':'policy-request','historicalOnly':True});row['request']=request
    request_file=out/(case+'-request.json');sdk.write_json(request_file,request['requestValue']);renewal=inputs/(key+'-approval.json')
    sdk.require(request['requestValue']['original_credential']==grant_data['certificate'] and request['requestValue']['current_credential']==registered['certificate'] and request['requestValue']['current_roster']==registered['roster'],'P request did not retain C0/current C1')
    stale=dict(request['requestValue']);stale.update(current_credential=grant_data['certificate'],current_roster=grant_data['roster'],current_credential_digest=request['requestValue']['original_credential_digest'],current_roster_version=str(grant_data['version']),current_roster_digest=grant_data['digest'])
    stale_file=out/(case+'-stale-policy-request.json');sdk.write_json(stale_file,stale);stale_out=out/(case+'-stale-policy-approval.json')
    refused=capture_output([str(roster),str(directory),str(grant),str(stale_file),str(stale_out),'required'],timeout_seconds=30,maximum_stdout_bytes=65536,maximum_stderr_bytes=65536,environment=dict(os.environ))
    (logs/(case+'-stale-issuer.stdout')).write_bytes(refused.stdout);(logs/(case+'-stale-issuer.stderr')).write_bytes(refused.stderr)
    sdk.require(refused.returncode!=0 and b'request differs from independently retained registration/policy' in refused.stderr and not stale_out.exists(),'issuer trusted stale C0 as current')
    row['stale_current_refused']=True
    row['issued']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,renewal,'required'],case+'-policy-issuer'),label='policy issuer')
    row['staged']=success({**args,'action':'p-stage','historicalOnly':True})
    created=success({**args,'action':'p-prepare','historicalOnly':True});row['prepared']=created;args['proposal']=created['proposal']
    proposal=out/(case+'-proposal.bin');proposal.write_bytes(bytes(created['proposal']))
    row['witness_preparation']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,renewal,'required',proposal],case+'-policy-witness'),label='witness preparation')
    if case=='loss':
     row['policy_loss']=rejected({**args,'action':'p-commit','historicalOnly':True,'mode':'drop-ack'},'WitnessTransport')
    elif case=='kill-ack':
     row['terminated']=invoke({**args,'action':'p-commit','historicalOnly':True,'mode':'hold-ack','killOnFault':True});sdk.require(row['terminated'].get('killed') is True,'no actual Worker termination')
    if case in ['loss','kill-ack']:
     row['interrupted']=success({**args,'action':'p-status','historicalOnly':True});sdk.require(row['interrupted']['progress']['stage']==2 and not row['interrupted']['progress']['retired'],'P lacks terminal before ACK')
     row['committed']=success({**args,'action':'p-reconcile','historicalOnly':True})
    else:row['committed']=success({**args,'action':'p-commit','historicalOnly':True})
    sdk.require(row['committed']['remote']==2 and row['committed']['progress']['retired'],'P not retired')
    row['active']=success({**args,'action':'p-activate','historicalOnly':True})
    sdk.require(row['active']['journal']==original['journal'] and row['active']['status']['phase']==3,'policy replaced original journal or not committed')
    if case=='expired-chain':
     row['native_policy']=peer_result(['renew-policy',directory,renewal,native_trace(case,'native-policy')],case+'-native-policy')
     sdk.require(row['native_policy']['original_policy_expired'] and row['native_policy']['same_original_journal'] and row['native_policy']['session']==args['session'],'native P did not preserve original expired session')
    args.update(continued=True,historicalOnly=True)
    row['legacy_refused']=rejected({**args,'action':'session','sessionAction':'rekey-progress','legacyReopen':True},'Conflict')
    after=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(after==pending,'P changed original rekey');row['progress_after']=after
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'G lost original application outbox')
    completed=success({**args,'action':'session','sessionAction':'drive-rekey','target':1});sdk.require(completed['epoch']=='1','original rekey incomplete');row['rekey']=completed
    control_frames=[r for r in peer_records[key] if r['kind']==4];sdk.require(len(control_frames)>=2 and control_frames[0]['trigger'] and control_frames[0]['request_sha256']==control_frames[1]['request_sha256'],'P changed first control replay')
    delivery=success({**args,'action':'session','sessionAction':'send'});sdk.require(delivery=={'consumption':1,'status':3},'original application not acknowledged');row['delivery']=delivery
    message_frames=[r['request_sha256'] for r in peer_records[key] if r['kind']==3];sdk.require(len(message_frames)==2 and len(set(message_frames))==1,'P changed original ciphertext')
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(args['session'])+bytes(args['message'])+b'browser to native','native effect duplicated/changed')
    received=success({**args,'action':'session','sessionAction':'receive'});sdk.require(received['application']['calls']==1 and received['application']['effects']==1,'browser original effect');row['received']=received
    duplicate=success({**args,'action':'session','sessionAction':'receive'});sdk.require(not duplicate['callbackInvoked'] and duplicate['reply']==received['reply'] and duplicate['application']==received['application'],'duplicate released plaintext or changed ACK');row['duplicate']=duplicate
    ack=out/(case+'-reverse-ack.bin');ack.write_bytes(bytes(received['reply']));row['reverse_finished']=peer_result(['send-finish',directory,reverse,ack,native_trace(case,'reverse-finish')],case+'-reverse-finish')
    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;sdk.require(success({**args,'action':'session','sessionAction':'send','message':fresh,'plaintext':'after P'})=={'consumption':1,'status':3},'fresh post-P message failed')
    sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==row['credential_final'],'P erased original G outcome')
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records']),'peer_requests':len(row['peer_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
