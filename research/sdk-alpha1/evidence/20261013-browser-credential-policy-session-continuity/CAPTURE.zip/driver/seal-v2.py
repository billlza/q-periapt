from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-policy-sessions';package=root/'target/continuity-browser-publication/source/target/policy-session-package-01'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=load(stage/'run01/RESULT.json');sdk.require(r['completed'],'incomplete composed run')
cases={c['case']:c for c in r['cases']};sdk.require(set(cases)=={'live','loss','kill-ack','expired-chain'},'case coverage')
for name,c in cases.items():
 sdk.require(c['credential_final']['phase']==4 and c['credential_final']['operation']==c['credential_operation'],'G outcome lost')
 sdk.require(c['stale_current_refused'] and c['issued']['registered_successor_verified'],'independent issuer did not require C1')
 p=c['request']['requestValue'];sdk.require(p['original_credential']!=p['current_credential'] and p['current_roster_version']=='2','not actual successor')
 sdk.require(c['active']['journal']==c['original']['journal'] and c['active']['status']['phase']==3,'P did not retain original journal')
 sdk.require(c['progress_before']==c['after_g']==c['progress_after'] and c['rekey']['epoch']=='1','pending PQ identity changed')
 controls=[x for x in c['peer_records'] if x['kind']==4];messages=[x for x in c['peer_records'] if x['kind']==3]
 sdk.require(len(controls)>=2 and controls[0]['trigger'] and controls[0]['request_sha256']==controls[1]['request_sha256'],'control replay changed')
 sdk.require(len(messages)==3 and messages[0]['trigger'] and messages[0]['request_sha256']==messages[1]['request_sha256']!=messages[2]['request_sha256'],'ciphertext replay/fresh work')
 sdk.require(c['delivery']=={'consumption':1,'status':3} and c['received']['application']['effects']==1 and not c['duplicate']['callbackInvoked'] and c['duplicate']['reply']==c['received']['reply'],'delivery or duplicate changed')
 sdk.require(c['reverse_finished']['authenticated_browser_consumption'] and c['reverse_finished']['same_original_wire'],'reverse delivery changed')
 if name in ['loss','kill-ack']:
  sdk.require(c['credential_loss']['ownerClosed'] and c['credential_interrupted']['status']['phase']==(2 if name=='loss' else 4),'wrong G interruption')
  sdk.require(c['interrupted']['progress']['stage']==2 and not c['interrupted']['progress']['retired'] and c['committed']['progress']['retired'],'P ACK boundary lost')
  sdk.require(len([x for x in c['witness_records'] if x['trigger']])==2,'G and P did not both experience distinct faults')
 if name=='kill-ack':sdk.require(c['terminated']['killed'],'Worker not actually terminated')
e=cases['expired-chain']['real_expiry'];sdk.require(e['pending_at']<e['credential_until']<=e['credential_renew_at']<e['policy_until']<=e['policy_renew_at'],'not real sequential expiry')
sdk.require(cases['expired-chain']['credential_issued']['previous_expired'] and cases['expired-chain']['native_policy']['original_policy_expired'],'expiry not verified by independent issuers')
source=load(stage/'SOURCE_INPUTS.json')
for n,d in source['inputs'].items():sdk.require(sha(root/n)==d,'product source changed')
for n,d in source['witness_files'].items():sdk.require(sha(stage/'witness-source'/n)==d,'probe source changed')
for n,d in r['native'].items():sdk.require(sha(Path(n))==d,'native binary changed')
for n,d in r['static_web'].items():sdk.require(sha(stage/'run01-web'/n)==d,'static source changed')
receipt=load(package/'INSTALLED_CONSUMER.json');sdk.require(receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==source['package']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz'),'package binding')
for n in ['issuer-build.log','credential-issuer-build.log','witness-build-02.log']:
 text=(stage/n).read_text();sdk.require('Finished' in text and 'error:' not in text and 'warning:' not in text,n)
members={};raw={}
def add(p,n):
 sdk.require(p.is_file() and not p.is_symlink() and n not in members,'bad archive entry')
 sdk.require(not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),'private archive entry')
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.sh'] and p.name not in ['seal.log','finalize.log','HANDOFF.json']:add(p,'driver/'+p.name)
for part in ['policy-issuer','credential-issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/part/n,'native/'+part+'/'+n)
for n in ['Cargo.toml','Cargo.lock','src/anchor/store.rs','examples/browser_activation_authority.rs']:add(stage/'witness-source'/n,'witness-source/'+n)
for part in ['authority','native-peer-v2']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/'target/continuity-browser-policy-sessions'/part/n,'prior-native/'+part+'/'+n)
folder=stage/'run01'
for p in sorted(folder.iterdir()):
 if p.is_file():add(p,'run01/'+p.name)
for part in ['logs','captures']:
 for p in sorted((folder/part).rglob('*')):
  if p.is_file():add(p,'run01/'+p.relative_to(folder).as_posix())
for part in ['witness','native','peer']:
 for p in sorted((folder/part).rglob('*')):
  if p.is_file():raw['run01/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
for p in sorted((folder/'witness').rglob('RECORDS.json')):
 add(p,'run01/'+p.relative_to(folder).as_posix())
 for row in load(p):
  if row['trigger']:
   for q in sorted(p.parent.glob(f"{row['number']:03}.*")):
    if q.is_file():add(q,'run01/'+q.relative_to(folder).as_posix())
for p in sorted((folder/'peer').rglob('RECORD.json')):
 add(p,'run01/'+p.relative_to(folder).as_posix())
 for name in ['request.bin','reply.bin','native.stdout','native.stderr']:
  q=p.parent/name
  if q.is_file():add(q,'run01/'+q.relative_to(folder).as_posix())
for p in sorted((stage/'run01-web/inputs').glob('*')):
 if p.is_file():add(p,'public-inputs/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/n,'package/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-credential-policy-session-continuity';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 sdk.require(z.testzip() is None,'archive')
 for n,m in manifest.items():sdk.require(hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes'],'member digest')
checks={'completed':True,'release_claim_eligible':False,'engine_commit':source['head'],'product_code_changed':False,'source_inputs':source['inputs'],'witness_probes':source['witness_changes'],'case_count':4,'cases':sorted(cases),'real_expiry':e,'validation':{'independent_registered_G_verified_for_P':True,'stale_C0_current_refused':4,'actual_worker_termination_cuts':1,'same_message_and_control_bytes':True,'bidirectional_messages_and_host_deduplication':True},'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'diagnostics':'First isolated witness build lacked serde_json dev-dependency; pinned only in diagnostic clone and rebuilt offline. No product dependency or admission rule changed. Initial sealing incorrectly required strictly greater timestamps; identity.rs defines [from,until), so equality at C0 expiry is expired. Final sealing uses the actual half-open contract, preserves timestamps and requires both independent expiry observations. Earlier stage deadline failure remains preserved; this batch ran serially with unchanged caller bounds.','capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Installed browser completed plain G then independent P with original session continuity, independent C1 issuer expectations and sequential real C0/P0 expiry. Not reverse P->G/joint T, independent implementation/cross-host, new devices, deployed migration, performance, PCS or full release.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
