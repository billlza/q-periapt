from pathlib import Path
import json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-policy-sessions';clone=root/'target/continuity-browser-publication/source'
dest='research/sdk-alpha1/evidence/20261013-browser-credential-policy-session-continuity'
checks=json.loads((root/dest/'CHECKS.json').read_text());sdk.require(checks['completed'] and not checks['product_code_changed'],'wrong scope')
for n,d in checks['source_inputs'].items():sdk.require(sdk.snapshot(root/n).sha256==d,'product source changed: '+n)
paths=[dest+'/'+n for n in ['CAPTURE.zip','CHECKS.json','README.md']]
sdk.command(['git','add','--',*paths],stage/'commit-stage',root)
sdk.command(['git','diff','--cached','--check'],stage/'commit-check',root)
staged=sdk.command(['git','diff','--cached','--name-only'],stage/'commit-paths',root).decode().splitlines();sdk.require(set(staged)==set(paths),'unexpected staged paths')
sdk.command(['git','commit','-m','Qualify credential and policy session continuity'],stage/'commit',root)
head=sdk.command(['git','rev-parse','HEAD'],stage/'head',root).decode().strip();sdk.require(not sdk.command(['git','status','--porcelain'],stage/'main-status',root),'main not clean')
sdk.command(['git','fetch',str(root),'HEAD'],stage/'clone-fetch',clone);sdk.command(['git','checkout','--detach',head],stage/'clone-checkout',clone)
sdk.require(not sdk.command(['git','status','--porcelain'],stage/'clone-status',clone),'clone not clean')
env=dict(os.environ);env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';env['PYTHONPATH']='artifact'
sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',sdk.snapshot(clone/'artifact/results.json').sha256,head],stage/'source-gate',clone,environment=env)
sdk.write_json(stage/'FINALIZED.json',{'head':head,'main_clean':True,'clone_clean':True,'source_gate':'passed','product_code_changed':False,'release_claim_eligible':False,'pushed':False});print(head)
