from pathlib import Path
import runpy,tempfile,shutil,json
b=Path(__file__).resolve().parent;m=runpy.run_path(str(b/'verify-policy-capture.py'));verify=m['verify'];source=b/'public-c-debug-01/public';baseline=verify(source,'C');results=[]
for carrier in ('local','signed','tls'):
 for name in sorted(m['POLICY']| (m['LOCAL'] if carrier=='local' else m['WITNESS'])):
  for action in ('truncate','change-prefix'):
   with tempfile.TemporaryDirectory(prefix='qpc-public-policy-control-') as tmp:
    dest=Path(tmp)/'public';shutil.copytree(source,dest);p=dest/(carrier+'-fixed')/name;v=p.read_bytes();p.write_bytes(v[:-1] if action=='truncate' else bytes([v[0]^1])+v[1:])
    try:verify(dest,'C')
    except (AssertionError,ValueError,IndexError):results.append({'carrier':carrier,'file':name,'mutation':action,'refused':True})
    else:raise AssertionError((carrier,name,action))
assert verify(source,'C')==baseline
(b/'PUBLIC_READER_CONTROLS.json').write_text(json.dumps({'controls':results,'count':len(results),'original_unchanged':True,'scope':'Grammar/linkage mutation controls only; native verification remains responsible for signatures'},indent=2)+'\n');print('public record refusal controls:',len(results))
