"""Read public policy/replay linkage; signature checks remain in native execution."""
from pathlib import Path
import hashlib,json,sys

COMMON={"manifest.json","request.bin","replayed.bin","root.bin","intent.bin","session.bin","unknown.bin","acknowledged.bin","after-traffic.bin","effect.bin"}
POLICY={"policy-request.bin","policy-request-replayed.bin","policy-approvals.bin","policy-statement.bin","policy-root.bin","original-policy.bin","target-policy.bin","target-version.bin","target-digest.bin","policy-refused.bin","policy-after-refusal.bin","policy-staged.bin","policy-stage-replayed.bin"}
WITNESS={"genesis.bin","policy-proposal.bin","proposal-replayed.bin","proposal-recovered.bin","witness-applied.bin","witness-reconciled.bin"}
LOCAL={"policy-committed.bin","policy-commit-replayed.bin"}
def digest(domain,value):
    return hashlib.sha3_256(len(domain).to_bytes(8,'big')+domain+len(value).to_bytes(8,'big')+value).digest()
def counter(data,order=sys.byteorder): return int.from_bytes(data,order)
def check(folder,language):
    carrier,profile=folder.name.split('-')
    names=COMMON|POLICY|(LOCAL if carrier=='local' else WITNESS)
    assert not folder.is_symlink() and {p.name for p in folder.iterdir()}==names,'inventory'
    assert all(not (folder/n).is_symlink() and 0<(folder/n).stat().st_size<=33176 for n in names),'public bounds'
    d={n:(folder/n).read_bytes() for n in names}
    assert json.loads(d['manifest.json'])==dict(schema_version=1,language=language,profile=profile,carrier=carrier,release_claim_eligible=False),'metadata'
    raw=d['policy-request.bin'];assert len(raw)==33176 and raw==d['policy-request-replayed.bin']==d['policy-after-refusal.bin'],'original policy request'
    assert d['policy-refused.bin']==(102).to_bytes(4,sys.byteorder),'signature refusal'
    assert raw[280:320]==bytes(40),'first predecessor'
    account=digest(b'Q-PERIAPT-CONTINUITY-ACCOUNT-CANDIDATE/v1',d['root.bin'])
    assert raw[320:352]==account,'original account'
    credentials=[]
    for start in (392,8588,16784,24980):
        n=counter(raw[start:start+4]);record=raw[start+4:start+8196]
        assert 0<n<=8192 and record[n:]==bytes(8192-n),'public record tail'
        credentials.append(record[:n])
    assert credentials[0]==credentials[2] and credentials[1]==credentials[3],'identity/roster changed'
    assert raw[160:200]==raw[352:392],'roster checkpoint changed'
    pins=[];bodies=[]
    family=digest(b'Q-PERIAPT-CONTINUITY-POLICY-AUTHORITY-CANDIDATE/v1',d['policy-root.bin'])
    for name in ('original-policy.bin','target-policy.bin'):
        wire=d[name];n=counter(wire[:4],'big');body=wire[4:4+n]
        assert n in (168,200) and len(wire)==4+n+3373 and body[:8]==b'QPSESP03' and body[8:40]==family,'policy envelope/family'
        pins.append((counter(body[40:48],'big'),digest(b'Q-PERIAPT-CONTINUITY-SESSION-POLICY-CANDIDATE/v1',body)))
        bodies.append(body)
    assert family==d['intent.bin'][24:56] and pins[0][0]==1 and pins[1][0]==2,'policy versions'
    assert bodies[0][64:]==bodies[1][64:],'unexpected SDK/suite/modes/anchor/budget change'
    assert raw[200:240]==pins[0][0].to_bytes(8,sys.byteorder)+pins[0][1] and raw[240:280]==raw[200:240],'P0 binding'
    assert d['target-version.bin']==pins[1][0].to_bytes(8,'big') and d['target-digest.bin']==pins[1][1],'target checkpoint'
    approvals=d['policy-approvals.bin'];assert len(approvals)==7618 and approvals[:8]==b'QPPRNB01','approval container'
    offset=8;statements=[]
    for _ in range(2):
        n=counter(approvals[offset:offset+2],'big');assert n==3803;offset+=2
        wire=approvals[offset:offset+n];offset+=n
        assert counter(wire[:4],'big')==426 and wire[4:12]==b'QPPRNW01','approval envelope'
        statements.append(wire[4:430])
    body=statements[0];assert statements[1]==body and offset==len(approvals),'two-root statement mismatch'
    assert body[8:168]==raw[:160] and body[200:232]==family,'statement scope'
    assert body[232:272]==counter(raw[160:168]).to_bytes(8,'big')+raw[168:200],'statement roster'
    assert body[272:312]==pins[0][0].to_bytes(8,'big')+pins[0][1] and body[312:352]==body[272:312],'statement P0'
    assert body[352:392]==pins[1][0].to_bytes(8,'big')+pins[1][1] and body[392:]==bytes(33)+b'\x01','statement target/established-only'
    statement=digest(b'Q-PERIAPT-POLICY-RENEWAL-CANDIDATE/v1',body)
    assert d['policy-statement.bin']==statement,'statement digest'
    def status(name,phase):
        b=d[name];expected=phase.to_bytes(4,sys.byteorder)+bytes(4)+raw[:32]+statement+pins[1][0].to_bytes(8,sys.byteorder)+pins[1][1]+bytes(48)
        assert b==expected,'status '+name
    status('policy-staged.bin',1);assert d['policy-stage-replayed.bin']==d['policy-staged.bin'],'stage replay'
    if carrier=='local':
        status('policy-committed.bin',2);assert d['policy-commit-replayed.bin']==d['policy-committed.bin'],'commit replay'
    else:
        proposal=d['policy-proposal.bin'];genesis=d['genesis.bin']
        assert len(genesis)==164 and genesis[:4]==b'\x00\x00\x00\x02' and genesis[4:36]==genesis[36:68] and all(any(genesis[i:i+32]) for i in (4,36,68,100,132)),'original genesis'
        assert len(proposal)==296 and proposal[:8]==b'QPPWNP01' and proposal==d['proposal-replayed.bin']==d['proposal-recovered.bin'],'original proposal'
        assert proposal[40:136]==genesis[36:132] and raw[32:64]==genesis[4:36],'original journal subject'
        assert proposal[136:168]==raw[:32] and proposal[168:200]==statement,'proposal statement'
        assert proposal[200:208]==proposal[248:256] and 0<counter(proposal[200:208],'big')<2**64-1,'proposal fence'
        assert 0<counter(proposal[208:216],'big')<2**64-2 and counter(proposal[256:264],'big')==counter(proposal[208:216],'big')+1 and proposal[216:248]!=proposal[264:296],'one original sealed target'
        assert d['witness-applied.bin']==d['witness-reconciled.bin']==(2).to_bytes(4,sys.byteorder),'witness applied'
    original=d['request.bin'];unknown=d['unknown.bin']
    assert original==d['replayed.bin']==d['after-traffic.bin'] and len(unknown)==64 and d['session.bin']==unknown[:32] and d['acknowledged.bin']==unknown,'original registration/session/message'
    assert d['effect.bin']==unknown+b'persisted before process exit','one effect identity'
    return {'files':{n:hashlib.sha256(v).hexdigest() for n,v in d.items()},'operation':raw[:32].hex(),'statement':statement.hex(),'session':unknown[:32].hex(),'message':unknown[32:].hex()}
def verify(root,language):
    expected={f'{c}-{p}' for c in ('local','signed','tls') for p in ('fixed','recoverable')}
    assert {p.name for p in root.iterdir()}==expected,'scenario inventory'
    result={name:check(root/name,language) for name in sorted(expected)}
    assert len({v['operation'] for v in result.values()})==6,'operation reuse'
    assert sum(len(v['files']) for v in result.values())==166,'file count'
    return result
if __name__=='__main__':
    root=Path(sys.argv[1]);language=sys.argv[2];result=verify(root,language)
    output=root.parent/'PUBLIC_POLICY_VERIFIED.json';output.write_text(json.dumps(dict(language=language,scenarios=result,signature_verification='native execution only',release_claim_eligible=False),indent=2)+'\n');print(str(output))
