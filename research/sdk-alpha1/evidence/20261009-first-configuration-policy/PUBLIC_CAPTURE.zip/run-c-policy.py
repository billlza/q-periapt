from pathlib import Path
import hashlib,json,subprocess,os,time,sys,shutil
b=Path(__file__).resolve().parent;source=b/'consumer';label=sys.argv[1];profile=sys.argv[2];assert profile in ('debug','release');out=b/label;out.mkdir(mode=0o700)
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','PYTHON'))}
env.update(RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(b/'consumer-build'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
def inputs():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
record=dict(source=str(source),profile=profile,inputs=inputs(),runs=[],complete=False);(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,command,runtime=None):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:r=subprocess.run(command,cwd=source,env=runtime or env,stdout=so,stderr=se)
 rec=dict(name=name,command=command,returncode=r.returncode,seconds=time.monotonic()-start);record['runs'].append(rec);record['source_unchanged']=inputs()==record['inputs'];(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if r.returncode:print((out/(name+'.stderr')).read_text()[-6000:],flush=True)
 assert record['source_unchanged'];r.check_returncode();return (out/(name+'.stdout')).read_text()
extra=['--release'] if profile=='release' else [];cargo=['/usr/bin/caffeinate','-i',str(tc/'bin/cargo')];filename='libq_periapt_continuity_c_consumer.dylib'
liblog=run('library',cargo+['rustc','--locked','--offline','--lib','--message-format=json',*extra,'--','-C','link-arg=-Wl,-install_name,@rpath/'+filename])
artifacts=[json.loads(s) for s in liblog.splitlines() if s.startswith('{')];libpaths=[Path(p) for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='q_periapt_continuity_c_consumer' for p in v['filenames'] if p.endswith('.dylib')];assert len(libpaths)==1
installed=out/'installed';installed.mkdir(mode=0o700);shutil.copy2(libpaths[0],installed/filename)
cc=run('clang-path',['/usr/bin/xcrun','--sdk','macosx','--find','clang']).strip();sdk=run('sdk-path',['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path']).strip();client=installed/'qpc-c-client'
run('compile',[cc,'-isysroot',sdk,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread','-O2' if profile=='release' else '-O0',str(source/'client.c'),str(source/'recovery_client.c'),str(source/'opening_client.c'),'-I',str(source),'-L',str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(client)])
names={s.split()[-1].removeprefix('_') for s in run('exports',['/usr/bin/nm','-gU',str(installed/filename)]).splitlines() if s.strip()};assert len(names)==132 and {'qpc_peer_v1_prepare_configured','qpc_peer_v1_prepare_configured_reopen'}<=names
run('linkage',['/usr/bin/otool','-L',str(client)]);assert run('guard',[str(client),'peer-configuration-guard'])=='QPC_PEER_CONFIGURATION_HEADER_GUARD_PASS\n'

configuration=installed/'first-configuration-client'
run('configuration-compile',[cc,'-isysroot',sdk,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread','-O2' if profile=='release' else '-O0',str(source/'first_configuration_client.c'),'-I',str(source),'-L',str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(configuration)])
trace=run('trace-build',cargo+['test','--locked','--offline','--test','first_configuration','--no-run','--message-format=json',*extra]);values=[json.loads(s) for s in trace.splitlines() if s.startswith('{')];helpers=[Path(v['executable']) for v in values if v.get('reason')=='compiler-artifact' and v['target']['name']=='first_configuration' and v.get('executable')];assert len(helpers)==1;helper=installed/'first_configuration';shutil.copy2(helpers[0],helper)
evidence=out/'public';evidence.mkdir(mode=0o700)
runtime=dict(env,QPC_CONFIGURATION_CLIENT=str(configuration),QPC_CONFIGURATION_LANGUAGE='C',QPC_CONFIGURATION_RECEIVER=str(client),QPERIAPT_CONFIGURATION_EVIDENCE=str(evidence))
run('first-configuration-connection',[str(helper),sys.argv[3] if len(sys.argv)>3 else 'independent_c_','--nocapture','--test-threads=1'],runtime)
record.update(complete=True,source_unchanged=inputs()==record['inputs'],installed={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in installed.iterdir() if p.is_file()});assert record['source_unchanged'];(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print('first configuration connection completed',flush=True)
