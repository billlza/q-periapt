from pathlib import Path
import subprocess,os,json,time,hashlib
b=Path(__file__).resolve().parent;source=b/'consumer';out=b/'enrollment-regression-01';out.mkdir();tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin');env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','QPC','PYTHON'))};env.update(RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(b/'consumer-build'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()};result=dict(inputs=inputs,runs=[],completed=False)
def run(label,cmd,runtime):
 start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:p=subprocess.run(cmd,cwd=source,env=runtime,stdout=so,stderr=se,timeout=900)
 result['runs'].append(dict(label=label,command=cmd,returncode=p.returncode,seconds=time.monotonic()-start));(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode: print((out/(label+'.stderr')).read_text()[-4500:],flush=True)
 p.check_returncode();return (out/(label+'.stdout')).read_text()
for profile in ('debug',):
 log=run('build-'+profile,[str(tc/'bin/cargo'),'test','--locked','--offline','--test','enrollment','--no-run','--message-format=json',*(['--release'] if profile=='release' else [])],env)
 values=[json.loads(s) for s in log.splitlines() if s.startswith('{')];paths=[Path(v['executable']) for v in values if v.get('reason')=='compiler-artifact' and v['target']['name']=='enrollment' and v.get('executable')];assert len(paths)==1
 installed=b/'public-c-debug-01'/'installed';runtime=dict(env,QPERIAPT_C_OWNER_CLIENT=str(installed/'qpc-c-client'))
 log=run('execute-'+profile,[str(paths[0]),'--exact','credential_renewal::independent_policy::c_independent_policy_request_restarts_exact_stage_and_adopts_original_journal','credential_renewal::independent_policy::c_independent_policy_rejects_changed_requests_without_publishing_or_mutating_intent','--nocapture','--test-threads=1'],runtime)
 assert 'test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 28 filtered out;' in log
result['source_unchanged']={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}==inputs;assert result['source_unchanged'];result['completed']=True;(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
