from pathlib import Path
import hashlib,json,zipfile
import wasm_browser_storage as browser
import wasm_sdk_package as package
stage=Path(__file__).resolve().parent;repo=stage.parent.parent
out=repo/'research/sdk-alpha1/evidence/20261013-browser-policy-receipts'
built=stage/'policy-package-02';qualified=stage/'policy-qualified-02'
receipt=json.loads((built/'INSTALLED_CONSUMER.json').read_text())
report=json.loads((qualified/'BROWSER_STORAGE.json').read_text());assert report['completed']
assert hashlib.sha256(Path(receipt['archive']).read_bytes()).hexdigest()==receipt['sha256']==report['archive_sha256']
manifest=package.verify(Path(receipt['installed']),receipt['manifest_sha256'])
package.validate_consumer_source(manifest)
assert json.loads((built/'sources-before.json').read_text())==json.loads((built/'sources-after.json').read_text())
for name,marker in [('storage-acceptance.js','BROWSER_POLICY_STORAGE_PASS'),('storage-quota-acceptance.js','BROWSER_POLICY_QUOTA_PASS'),('storage-deadline-acceptance.js','BROWSER_POLICY_DEADLINE_PASS')]:
    assert browser.result((qualified/(name+'.stdout')).read_bytes(),marker)==report[name]
members={}
for directory,prefix in ((built,'package'),(qualified,'qualification')):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr'):
            members[prefix+'/'+path.name]=path.read_bytes()
members['package/PACKAGE_CONTENTS.json']=(built/'package/PACKAGE_CONTENTS.json').read_bytes()
for name in ('policy-reader-tests2.stdout','policy-reader-tests2.stderr','guard-format2.stdout','guard-format2.stderr','capture-final-policy-package.py'):
    members['validation/'+name]=(stage/name).read_bytes()
for name in ('artifact/test_wasm_browser_storage.py','crates/q-periapt-host-store/src/database_format.rs'):
    members['final-source/'+name]=(repo/name).read_bytes()
with zipfile.ZipFile(out/'FINAL_PACKAGE.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,body in sorted(members.items()):archive.writestr(name,body)
with zipfile.ZipFile(out/'FINAL_PACKAGE.zip') as archive:
    assert set(archive.namelist())==set(members)
    for name,body in members.items():assert archive.read(name)==body
body=(out/'FINAL_PACKAGE.zip').read_bytes()
record={'completed':True,'current_source_checked':True,'purpose':'Fresh installed package after the portable guard formatting correction.',
        'package_sha256':receipt['sha256'],'manifest_sha256':receipt['manifest_sha256'],
        'browser_groups_passed':3,'reader_tests_passed':15,'rustfmt_check_passed':True,
        'cleanup_completed':True,'release_claim_eligible':False,
        'capture':{'file':'FINAL_PACKAGE.zip','sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'members':len(members),
                   'member_sha256':{name:hashlib.sha256(value).hexdigest() for name,value in members.items()}}}
(out/'FINAL_PACKAGE.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key!='capture'}))
print(json.dumps({key:record['capture'][key] for key in ('sha256','members','bytes')}))
