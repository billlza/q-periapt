from pathlib import Path
import hashlib, json, shutil, zipfile
import wasm_browser_storage as browser
import wasm_sdk_package as package

stage=Path(__file__).resolve().parent;repo=stage.parent.parent
output=repo/'research/sdk-alpha1/evidence/20261013-browser-policy-receipts'
output.mkdir(mode=0o700)
qualified=stage/'policy-qualified-01';built=stage/'policy-package-01'
report=json.loads((qualified/'BROWSER_STORAGE.json').read_text());assert report['completed']
receipt=json.loads((built/'INSTALLED_CONSUMER.json').read_text())
assert report['archive_sha256']==receipt['sha256']
assert hashlib.sha256(Path(receipt['archive']).read_bytes()).hexdigest()==receipt['sha256']
package.verify(Path(receipt['installed']),receipt['manifest_sha256'])
red=json.loads((stage/'policy-red/RESULT.json').read_text())
assert red['completed'] and not red['held_until_receipt']
assert len(red['cases'])==2 and all(row['early_owner_admitted'] for row in red['cases'])
for filename,marker in [('storage-acceptance.js','BROWSER_POLICY_STORAGE_PASS'),
                        ('storage-quota-acceptance.js','BROWSER_POLICY_QUOTA_PASS'),
                        ('storage-deadline-acceptance.js','BROWSER_POLICY_DEADLINE_PASS')]:
    assert browser.result((qualified/(filename+'.stdout')).read_bytes(),marker)==report[filename]
installed=json.loads((stage/'installed-guard-04/RESULT.json').read_text());assert installed['completed']
assert 'test result: ok. 3 passed; 0 failed;' in (stage/'portable-guard-tests.stdout').read_text()
members={}
def add(path,name):
    assert name not in members and not path.is_symlink()
    body=path.read_bytes();assert len(body)<16*1024*1024
    members[name]=body
for path in qualified.iterdir():
    if path.is_file():add(path,'qualification/'+path.name)
for path in built.iterdir():
    if path.is_file() and path.suffix in ('.json','.stdout','.stderr'):
        add(path,'package/'+path.name)
add(built/'package/PACKAGE_CONTENTS.json','package/PACKAGE_CONTENTS.json')
for label in ('red','green'):
    add(stage/f'policy-{label}/RESULT.json',f'{label}/RESULT.json')
    add(stage/('POLICY_'+label.upper()+'.json'),f'{label}/WEB.json')
    for filename in ('policy-database.js','storage.js'):
        add(stage/f'web-policy-{label}/node_modules/q-periapt-sdk-wasm/web'/filename,f'{label}/'+filename)
    for phase in ('open','shutdown','close'):
        add(stage/f'policy-{label}-{phase}.stdout',f'{label}/{phase}.stdout')
for directory in ('installed-guard-01','installed-guard-02','installed-guard-03','installed-guard-04'):
    for path in (stage/directory).iterdir():
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr','.sh'):
            add(path,directory+'/'+path.name)
for name in ('portable-guard-tests.stdout','portable-guard-tests.stderr','check-installed-guard.py',
             'policy-reader-tests.stdout','policy-reader-tests.stderr','capture-policy-receipts.py',
             'policy-deadline-worker.mjs','prepare-policy-deadline.py','build-policy-package.sh'):
    add(stage/name,'drivers/'+name)
for name in ('crates/q-periapt-host-store/src/database_format.rs','crates/q-periapt-host-store/src/lib.rs',
             'crates/q-periapt-sdk-wasm/PackageREADME.md','crates/q-periapt-sdk-wasm/package/web/policy-database.js',
             'crates/q-periapt-sdk-wasm/package/web/storage.js','crates/q-periapt-sdk-wasm/package/web/storage.d.ts',
             'crates/q-periapt-sdk-wasm/tests/storage-deadline-worker.mjs','crates/q-periapt-sdk-wasm/tests/storage-deadline-acceptance.js',
             'crates/q-periapt-sdk-wasm/tests/serve.cjs','artifact/wasm_browser_storage.py','artifact/wasm_sdk_package.py'):
    add(repo/name,'source/'+name)
add(stage/'source/research/continuity-identity-candidate/src/storage/browser.rs','prototype/storage-browser.rs')
with zipfile.ZipFile(output/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,body in sorted(members.items()):archive.writestr(name,body)
with zipfile.ZipFile(output/'CAPTURE.zip') as archive:
    assert set(archive.namelist())==set(members)
    for name,body in members.items():assert archive.read(name)==body
capture=(output/'CAPTURE.zip').read_bytes()
record={'completed':True,'source_base':'9b90c76040a389235eb3064178832ab5ba479093',
        'cause':'The old IndexedDB adapter used its bounded result as an I/O completion receipt. On timeout it released the owner lease before late open/transaction callbacks settled.',
        'red':{'cases':2,'early_owner_admitted':True,'delayed_native_events':['transaction-complete','database-open']},
        'green':{'cases':2,'held_until_receipt':True,'primary_errors':['CommitUnknown','OpenUnknown'],
                 'cleanup_pending':'ClosePending retained in AggregateError; second owner Busy until actual settlement',
                 'original_policy_recovered':True},
        'installed_wasm':{'archive_sha256':receipt['sha256'],'manifest_sha256':receipt['manifest_sha256'],
                          'node':receipt['runtime']['version'],'typescript':receipt['typescript'],
                          'browser_groups':['quota','lifecycle','native completion deadlines'],'cleanup_completed':True},
        'portable_guard':{'native_regressions_passed':3,'cargo_archives_verified_and_installed_wasm_compiled':True,
                          'scope':'Portable header check only. Platform ownership/persistence are separate. Existing filesystem admission is unchanged.'},
        'limits':['Events were delayed by the test scheduler over real browser operations, not a claim about spontaneous browser failure frequency.',
                  'Full Continuity browser lifecycle and first-use recovery remain separate.',
                  'The independent Rust/C/Swift package producer was interrupted without a final report; this does not close that gate.',
                  'Portable guard packaging used explicitly dirty diagnostic source and exact recorded overlays; not a release package qualification.'],
        'capture':{'sha256':hashlib.sha256(capture).hexdigest(),'bytes':len(capture),'members':len(members),
                   'member_sha256':{name:hashlib.sha256(body).hexdigest() for name,body in sorted(members.items())}},
        'release_claim_eligible':False}
(output/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n')
enrollment=repo/'research/sdk-alpha1/evidence/20261013-browser-enrollment-storage'
shutil.copytree(stage/'sealed-experiment-01',enrollment)
print(json.dumps({'policy_capture_sha256':record['capture']['sha256'],'policy_members':len(members),'wasm_archive':receipt['sha256'],'enrollment':str(enrollment)}))
