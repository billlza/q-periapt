from pathlib import Path
import hashlib, json, shutil, sys
stage=Path(__file__).resolve().parent;repo=stage.parent.parent
label=sys.argv[1];assert label in ('red','green')
web=stage/('web-policy-'+label);web.mkdir()
package=repo/'target/browser-policy-storage/package9/package'
shutil.copytree(package,web/'node_modules/q-periapt-sdk-wasm')
if label=='green':
    for name in ('policy-database.js','storage.js'):
        shutil.copy2(repo/'crates/q-periapt-sdk-wasm/package/web'/name,web/'node_modules/q-periapt-sdk-wasm/web'/name)
(web/'fixtures').mkdir()
for name in ('signed-policy-vectors.json','sdk-policy-revocation-vectors.json'):
    shutil.copy2(repo/'bindings'/name,web/'fixtures'/name)
shutil.copy2(stage/'policy-deadline-worker.mjs',web/'policy-deadline-worker.mjs')
(web/'index.html').write_text('''<!doctype html><title>Policy pending completion</title><pre id="result">Running</pre><script type="module">
const worker=new Worker('./policy-deadline-worker.mjs',{type:'module'});
const timer=setTimeout(()=>{worker.terminate();globalThis.result={completed:false,error:'deadline'};document.querySelector('#result').textContent=JSON.stringify(result)},65000);
worker.onmessage=async({data})=>{if(data.progress){document.querySelector('#result').textContent=data.progress;return}clearTimeout(timer);globalThis.result=data.result;document.querySelector('#result').textContent=JSON.stringify(result);const response=await fetch('/capture/RESULT.json',{method:'POST',body:JSON.stringify(result,null,2)});if(!response.ok)throw Error('capture failed');worker.terminate()};
</script>''')
server=(stage/'serve3.py').read_text().replace("output=stage/'browser3'",f"output=stage/'policy-{label}'").replace("web=stage/'web3'",f"web=stage/'web-policy-{label}'")
(stage/('serve-policy-'+label+'.py')).write_text(server)
manifest={p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()}
(stage/('POLICY_'+label.upper()+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
