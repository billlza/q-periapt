"""Verify portable guard linkage from Cargo-produced archives, outside the checkout."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import tempfile
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
repo = stage.parent.parent
source = stage / 'source'
output = stage / 'installed-guard-04'
output.mkdir(mode=0o700)
outside = Path(tempfile.mkdtemp(prefix='qperiapt-browser-installed-guard-')).resolve()
sdk.write_json(output / 'LOCATION.json', {'outside': str(outside)})
report = repo / 'target/peer-account-retirement-process-current/source/target/continuity-browser-package-01/sdk/RUST_SDK_PACKAGE.json'
assert hashlib.sha256(report.read_bytes()).hexdigest() == 'aae9cf1b23c6772d70e3aaae2724166e7deb245e44e812fd98b8a313b6218583'
cohort = json.loads(report.read_text())
consumer = outside / 'consumer'
consumer.mkdir()
sdk.extract_recorded_crates(consumer, report.parent, cohort['crates'])
packages = consumer / 'packages'
installed = {name: packages / (name + '-0.2.0') for name in sdk.CONSUMER_CRATES}
patches = []
for name, path in installed.items():
    patches.extend(['--config', 'patch.crates-io.' + name + '.path=' + json.dumps(str(path))])
wrapper = output / 'cargo.sh'
wrapper.write_text((repo / 'target/continuity-browser-engine/cargo.sh').read_text().replace(
    str(repo / 'target/continuity-browser-engine/rust-target'), str(outside / 'build')))
def run(arguments, label, cwd=source):
    return sdk.command(['sh',str(wrapper),*arguments], output / label, cwd,
                       environment=dict(os.environ))

state = {'completed': False, 'experiment_only': True,
         'source_base': '7290c6f02b0fdebbaaed5b2916dc68904267710a',
         'sdk_report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
         'source_overlay_sha256': {}, 'outside': str(outside), 'archives': {}}
for name in ('crates/q-periapt-host-store/src/lib.rs','crates/q-periapt-host-store/src/database_format.rs',
             'research/continuity-identity-candidate/src/storage/browser.rs'):
    state['source_overlay_sha256'][name] = hashlib.sha256((source / name).read_bytes()).hexdigest()
try:
    for path in (source / 'crates/q-periapt-host-store').rglob('*'):
        if path.is_file():
            assert path.read_bytes() == (repo / path.relative_to(source)).read_bytes()
    package_arguments = ['package','--registry','crates-io','--locked','--offline','--allow-dirty','-j','2',
                         '--features','q-periapt-rustls/reference-connection']
    for name in sdk.CONSUMER_CRATES:
        package_arguments.extend(['-p', name])
    run(package_arguments, 'package-host-store', repo)
    archive = outside / 'build/package/q-periapt-host-store-0.2.0.crate'
    files = sdk.archive_files(archive.read_bytes(), 'q-periapt-host-store')
    for name in ('src/lib.rs','src/database_format.rs'):
        assert files[name] == (source / 'crates/q-periapt-host-store' / name).read_bytes()
    producer = outside / 'source'
    patches = []
    for crate in sdk.CONSUMER_CRATES:
        archived = outside / 'build/package' / (crate + '-0.2.0.crate')
        archive_files = sdk.archive_files(archived.read_bytes(), crate)
        destination = producer / 'crates' / crate
        for name, body in archive_files.items():
            path = destination / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
        patches.extend(['--config', 'patch.crates-io.' + crate + '.path=' + json.dumps(str(destination))])
        state['archives'][crate] = hashlib.sha256(archived.read_bytes()).hexdigest()
    shutil.copy2(archive, output / archive.name)
    state['archives']['host_store'] = hashlib.sha256(archive.read_bytes()).hexdigest()
    candidate_producer = producer / 'research/continuity-identity-candidate'
    shutil.copytree(source / 'research/continuity-identity-candidate', candidate_producer)
    run(['package','--manifest-path',str(candidate_producer / 'Cargo.toml'),
         '--all-features','--locked','--offline',*patches], 'package-candidate', producer)
    archive = outside / 'build/package/q-periapt-continuity-identity-candidate-0.0.0.crate'
    files = sdk.archive_files(archive.read_bytes(), 'q-periapt-continuity-identity-candidate', version='0.0.0')
    candidate = outside / 'installed-candidate'
    for name, body in files.items():
        path = candidate / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
    shutil.copy2(archive, output / archive.name)
    state['archives']['candidate'] = hashlib.sha256(archive.read_bytes()).hexdigest()
    resolved = json.loads(run(['metadata','--format-version','1','--offline',*patches], 'metadata', candidate))
    for package in resolved['packages']:
        if package['name'].startswith('q-periapt'):
            path = Path(package['manifest_path']).resolve()
            assert path.is_relative_to(outside) and not path.is_relative_to(source)
    run(['check','--lib','--target','wasm32-unknown-unknown','--locked','--offline',*patches], 'installed-wasm', candidate)
    for name, expected in state['source_overlay_sha256'].items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == expected
    state['completed'] = True
finally:
    sdk.write_json(output / 'RESULT.json', state)
print(json.dumps(state))
