"""Check source-case replay evidence without treating an incomplete goal as proved."""
from pathlib import Path
import hashlib
import json
import re
import runpy

root = Path.cwd()
stage = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline = (root / 'target/p0-generation-peer-first-701-02/model.spthy').read_text()
assert sha(baseline.encode()) == 'b7ed452927e3659b1bbe5fd6625213743cb8c2d6c1859719e074909716984424'
prefix = lambda text: text[:re.search(r'^lemma ', text, re.M).start()]
pattern = r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)\s*"([^"]*)"'
def declarations(text):
    rows = re.findall(pattern, text)
    assert all(not re.search(r'''["']''', attrs) for _, attrs, _, _ in rows)
    return [(name, ' '.join(attrs.split()), mode, formula) for name, attrs, mode, formula in rows]
queries = declarations(baseline)
assert len(queries) == 27
replays = []
for name, label, closed in [
    ('p0-application-role-replay-702', 'application-role-replay', False),
    ('p0-application-role-chain-replay-702', 'application-role-chain-replay', True),
]:
    directory = root / 'target' / name
    terminal = json.loads((directory / (label + '-TERMINAL.json')).read_text())
    outer = json.loads((directory / 'DRIVER_TERMINAL.json').read_text())
    model = (directory / 'model.spthy').read_text()
    certificate = (directory / (label + '-proof.spthy')).read_text()
    for text in [model, certificate]:
        assert prefix(text) == prefix(baseline)
        assert declarations(text) == queries
    assert sha(model.encode()) == terminal['input_sha256']
    assert sha(certificate.encode()) == terminal['output_sha256']
    assert terminal['returncode'] == 0 and outer['terminal_exit'] == 1
    assert not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
    assert not any(arg.startswith(('--prove', '--oracle', '--oraclename')) for arg in terminal['argv'])
    assert len(terminal['results']) == 27
    assert terminal['results']['epoch_generation_secret_derivation_origin'] == {
        'mode': 'all-traces', 'status': 'analysis incomplete', 'steps': 23}
    helpers = [name for name, result in terminal['results'].items() if result['mode'] == 'all-traces' and result['status'] == 'verified']
    assert len(helpers) == 11
    witness = terminal['results']['initial_epoch_traffic_advances_counter_is_executable']
    assert witness == {'mode': 'exists-trace', 'status': 'verified', 'steps': 414}
    if closed:
        branch = json.loads((directory / 'APPLICATION_BRANCH.json').read_text())
        assert branch['branch_text'] in certificate
        assert branch['branch_text'].count('by solve( (#vr.3, 0) ~~> (#known, 0) )') == 2
        assert 'sorry' not in branch['branch_text'] and 'invalid' not in branch['branch_text']
    else:
        block = certificate.split('    case Application_Message\n', 1)[1].split('    case Identity_Key', 1)[0]
        assert block.count('by sorry') >= 2
    replays.append({'stage': name, 'terminal': terminal, 'outer': outer, 'application_source_case_closed': closed, 'verified_helpers': helpers})
search = root / 'target/p0-role-shape-search-702'
terminal = json.loads((search / 'role-shape-search-TERMINAL.json').read_text())
assert terminal['timed_out'] and terminal['returncode'] == -9 and not terminal['accepted']
assert terminal['results'] == {} and terminal['output_sha256'] is None
assert sha((search / 'model.spthy').read_bytes()) == sha(baseline.encode())
frames = [json.loads(p.read_text()) for p in sorted((search / 'initial-send-oracle-frames').glob('*.json'))]
parts = (search / 'role-shape-search.stderr').read_text().split('>>>>>>>>>>>>>>>>>>>>>>>> START INPUT\n')[1:]
assert len(frames) == len(parts) == 20
rank = runpy.run_path(str(search / 'initial-send-oracle.py'))['rank']
history = []
for frame, part in zip(frames, parts, strict=True):
    section, output = part.split('>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT\n', 1)
    candidates = [value for value in {section, section.removesuffix('\n')} if sha(value.encode()) == frame['input_sha256']]
    assert len(candidates) == 1
    raw = candidates[0]
    goals, ranking = rank(raw)
    actual = [int(n) for n in output.split('>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call', 1)[0].split()]
    assert actual == ranking == frame['ranking']
    assert sorted(ranking) == sorted(frame['goal_numbers']) and not frame['diagnostic_stop']
    assert len(raw) == frame['input_characters'] and len(raw.encode()) == frame['input_bytes']
    history.append({'input_sha256': frame['input_sha256'], 'selected_prefix': frame['selected_prefix'],
                    'offered_chains': [n for n, text in goals if '~~>' in text]})
assert history[2]['selected_prefix'] == "(role = 'A')  ∥ (role = 'B')"
assert not history[3]['offered_chains']
ui = []
for name in ['p0-origin-frontier-ui-702', 'p0-origin-prefix-ui-702']:
    directory = root / 'target' / name
    receipt = json.loads((directory / 'TERMINAL.json').read_text())
    assert receipt['terminal_exit'] == -2
    ui.append({'stage': name, 'terminal': receipt})
prepared = root / 'target/p0-checked-origin-resume-702'
preparation = json.loads((prepared / 'PREPARED.json').read_text())
assert not preparation['search_started']
assert sha((prepared / 'model.spthy').read_bytes()) == replays[1]['terminal']['output_sha256']
result = {
    'verified': True, 'operational_prefix_sha256': sha(prefix(baseline).encode()),
    'queries_and_attributes_preserved': 27, 'replays': replays,
    'initial_reader_correction': 'Tamarin pretty-prints existing comma-separated lemma attributes across lines. The initial raw whitespace comparison failed; final comparison preserves every ordered attribute token, query name, modality and exact formula while normalizing whitespace in unquoted attributes only. Original reader and failure retained.',
    'search': {'terminal': terminal, 'oracle_frames_checked': 20, 'history': history},
    'viewers': ui, 'continuation_prepared_but_not_started': preparation,
    'application_source_subcase_checked': True, 'whole_origin_complete': False,
    'release_claim_eligible': False,
    'interpretation': 'Explicit role classification followed by the original stored deduction-chain goal closes both Application_Message branches under the existing calculus. The role-only control leaves both branches open. Automatic role priority still does not offer that chain to the oracle and reaches the unchanged 900-second deadline. This is checked partial-proof guidance, not a new assumption, full origin proof, search-speed claim or SDK security theorem.',
}
destination = stage / 'EXPERIMENTS.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'path': str(destination), 'sha256': sha(destination.read_bytes()), 'application_source_subcase_checked': True, 'whole_origin_complete': False}))
