"""Bounded local inspection of an explicitly incomplete proof prefix."""
from pathlib import Path
import hashlib
import json
import os
import signal
import socket
import subprocess
import time
from continuity_recovery_proof import prover_environment

root = Path.cwd()
stage = Path(__file__).resolve().parent
identity = json.loads((root / 'target/witness-renewal-01/P0_PINNED_PROVER_IDENTITY_01.json').read_text())
binaries = {name: identity[name]['path'] for name in ['tamarin', 'maude']}
for name, path in binaries.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == identity[name]['sha256']
with socket.socket() as probe:
    probe.bind(('127.0.0.1', 0))
    port = probe.getsockname()[1]
env = prover_environment()
env['PATH'] = os.pathsep.join([str(Path(binaries['tamarin']).parent), str(Path(binaries['maude']).parent), env['PATH']])
argv = [binaries['tamarin'], 'interactive', '--with-maude=' + binaries['maude'], '--interface=127.0.0.1', '--port=' + str(port), '--derivcheck-timeout=60', '--quit-on-warning', '--heuristic=s', str(stage), '+RTS', '-N1', '-M12G', '-c100', '-s', '-RTS']
started = time.monotonic()
reason = None
with (stage / 'server.stdout').open('xb') as out, (stage / 'server.stderr').open('xb') as err:
    process = subprocess.Popen(argv, cwd=root, env=env, stdout=out, stderr=err, start_new_session=True)
    (stage / 'STARTED.json').write_text(json.dumps({'pid': process.pid, 'port': port, 'interface': '127.0.0.1', 'argv': argv, 'maximum_seconds': 900, 'purpose': 'Inspect an existing proof prefix; do not apply methods or search.'}, indent=2) + '\n')
    print(json.dumps({'pid': process.pid, 'port': port}), flush=True)
    while process.poll() is None:
        if (stage / 'STOP').exists():
            reason = 'inspection_complete'
        elif time.monotonic() - started >= 900:
            reason = 'deadline'
        elif out.tell() > 16 * 1024**2 or err.tell() > 64 * 1024**2:
            reason = 'output_bound'
        if reason:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            break
        time.sleep(0.2)
    code = process.wait(timeout=5)
receipt = {'argv': argv, 'port': port, 'terminal_exit': code, 'elapsed_seconds': time.monotonic() - started, 'stop_reason': reason, 'source_input_sha256': hashlib.sha256((stage / 'prefix.spthy').read_bytes()).hexdigest(), 'stdout_sha256': hashlib.sha256((stage / 'server.stdout').read_bytes()).hexdigest(), 'stderr_sha256': hashlib.sha256((stage / 'server.stderr').read_bytes()).hexdigest(), 'main_origin_proof_complete': False}
(stage / 'TERMINAL.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(0 if reason == 'inspection_complete' else 1)
