from pathlib import Path
import ast
import json
import shutil
import subprocess
import tempfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;previous=root/'target/continuity-android-pending-query'
sdk.require(json.loads((previous/'CHECKPOINT_13.json').read_text())['completed'],'previous checkpoint incomplete')
new=['bindings/c/ContinuityPackageConsumer/tests/common/android_pending_process.rs',
     'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/process_loss.rs']
for name in ['ARTIFACT.md','artifact/codeql_rust_quality.py']:
    path=root/name;text=path.read_text();sdk.require(text.count('687')==1,'Rust inventory shape');path.write_text(text.replace('687','689'))
path=root/'artifact/test_codeql_rust_quality.py';text=path.read_text();key='            "bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write.rs",\n'
sdk.require(text.count(key)==2,'Rust inventory controls');path.write_text(text.replace(key,key+''.join('            '+json.dumps(name)+',\n' for name in new)))
subprocess.run(['git','add','--',*new],check=True)
# Keep the growing interruption reader separate from ordinary pending recovery.
path=root/'artifact/continuity_android_pending.py';text=path.read_text()
start=text.index('    if query_cancel or process_loss:\n');end=text.index('    return {result_label:',start)
body=text[start:end].splitlines(True)[1:]
sdk.require(all(line.startswith('    ') or not line.strip() for line in body),'reader indentation')
helper='def _verify_interruption(stdout: bytes, read, label: str, first: tuple, advance: bytes, *, process_loss: bool) -> None:\n'+''.join(line[4:] if line.strip() else line for line in body)+'\n\n'
text=text[:start]+'    if query_cancel or process_loss:\n        _verify_interruption(stdout, read, label, first, advance, process_loss=process_loss)\n'+text[end:]
text=text.replace('def verify_execution(',helper+'def verify_execution(',1);ast.parse(text);path.write_text(text)
env=json.loads((previous/'ENVIRONMENT_01.json').read_text())
rust=[str(p) for p in [Path(name) for name in subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines()] if p.suffix=='.rs']
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',*rust],stage/'format-01',root,environment=env)
for name in ['artifact/continuity_android_pending.py','artifact/continuity_android_contract.py','artifact/continuity_android_jni.py','artifact/test_continuity_android_pending.py']:ast.parse((root/name).read_text())
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
 'bindings/c/ContinuityPackageConsumer/src','bindings/c/ContinuityPackageConsumer/Cargo.toml','bindings/android/ContinuityPackageConsumer/src/main',
 'bindings/android/ContinuityPackageConsumer/jni']),'installed implementation changed')
old=json.loads((previous/'BUILD_06.json').read_text())['installed_base']
outside=Path(tempfile.mkdtemp(prefix='qpc-pending-process-')).resolve();consumer=outside/'c-consumer'
shutil.copytree(Path(old['consumer']),consumer)
fixture=root/'bindings/c/ContinuityPackageConsumer';hashes={}
for path in fixture.rglob('*'):
    if path.is_file() and path.name!='Cargo.toml':
        target=consumer/path.relative_to(fixture);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(sdk.snapshot(path).data);hashes[str(path.relative_to(root))]=sdk.snapshot(path).sha256
builder=outside/'android-source';shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',builder)
hashes.update({str(path.relative_to(root)):sdk.snapshot(path).sha256 for path in (root/'bindings/android/ContinuityPackageConsumer').rglob('*') if path.is_file()})
sdk.write_json(stage/'INPUTS_01.json',{'outside':str(outside),'consumer':str(consumer),'android_source':str(builder),
 'source_files':hashes,'installed_base':old,'candidate_sha256':old['candidate_sha256'],
 'scope':'Actual archives; application process exit at held Query and after confirmation before host result; no product change'})
sdk.write_json(stage/'ENVIRONMENT_01.json',env)
recipe=(previous/'build-06.py').read_text().replace('INPUTS_06.json','INPUTS_01.json').replace('-06','-02').replace('BUILD_06.json','BUILD_02.json')
with (stage/'build-02.py').open('x') as stream:stream.write(recipe)
print('Fresh actual-archive process-loss consumers prepared; Rust inventory689')
