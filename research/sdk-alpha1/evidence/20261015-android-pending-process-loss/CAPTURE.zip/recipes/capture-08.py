from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent;device=stage/'physical-06'
host=json.loads((stage/'RUN_RESULT_04.json').read_text());regression=json.loads((stage/'RUN_RESULT_05.json').read_text())
physical=json.loads((device/'run-07/RESULT.json').read_text());state=json.loads((device/'device-07/STATE.json').read_text())
sdk.require(host['completed'] and regression['completed'] and physical['completed'] and physical['cleanup'] and state['completed'] and state['cleanup']
 and not state.get('owned_reverse_ports'),'producer not terminal')
sdk.require(host['foreign_processes']==47 and regression['foreign_processes']==43 and physical['physical_processes']==23
 and physical['actual_process_cuts']==sum(row['actual_cut_observed'] for row in state['cases'])==2,'execution census')
source=json.loads((stage/'SOURCE_COMMIT_03.json').read_text())
sdk.require(source['source_commit']==host['source_commit']==regression['source_commit']==physical['source_commit'],'source differs')
out=root/'research/sdk-alpha1/evidence/20261015-android-pending-process-loss';out.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'capture duplicate');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(base,prefix,label):
    for suffix in ['json','stdout','stderr']:add(base/(prefix+'.'+suffix),label+'.'+suffix)
for name in ['readers-02','harness-02','catalog-02','clippy-02','java-02','source-gate-03','clone-controls-03','host-run-04','host-run-05']:
    logs(stage,name,'host/'+name)
for name in ['BUILD_02.json','RUN_RESULT_04.json','RUN_RESULT_05.json','SOURCE_03.json','SOURCE_COMMIT_03.json']:add(stage/name,'host/'+name)
for process_loss,number in [(True,'04'),(False,'05')]:
    suffix='-process-loss' if process_loss else '-query-cancel'
    for label in pending.PROCESS_TESTS:
        for name in pending.public(label.endswith('-applied'),process_loss=process_loss,query_cancel=not process_loss):
            add(stage/('public-'+number)/(label+suffix)/name,'host/public-'+number+'/'+label+suffix+'/'+name)
for name in source['source_paths']:add(root/name,'source/'+name)
for name in ['PACKAGE.json','PREPARED_APK_07.json']:add(device/name,'android/'+name)
for name in ['build','keytool','sign','signature']:logs(device/'agp-07',name,'android/'+name)
add(device/'agp-07/STATE.json','android/STATE.json')
logs(device/'run-07','catalog','device/catalog');logs(device/'run-07','execution','device/execution')
add(device/'run-07/RESULT.json','device/RESULT.json')
for path in sorted((device/'device-07').iterdir()):
    sdk.require(path.is_file() and path.suffix in ['.json','.stdout','.stderr'],'device receipt type');add(path,'device/commands/'+path.name)
label='tls-recoverable-applied';case_label=label+'-process-loss'
for name in pending.public(True,process_loss=True):add(device/'run-07/public'/case_label/name,'device/public/'+case_label+'/'+name)
for name in ['prepare-01.py','build-02.py','prepare-runs-03.py','commit-03.py','run-installed-04.py','run-regression-05.py',
             'apk-07.py','device-driver-07.py','run-device-07.py','capture-08.py']:add(stage/name,'recipes/'+name)
cohorts=[stage/'host-cases-04'/(r+'-process-loss') for r in pending.PROCESS_TESTS]
cohorts += [stage/'host-cases-05'/(r+'-query-cancel') for r in pending.QUERY_TESTS]
cohorts += [device/'run-07/cases'/case_label]
for cohort in cohorts:
    for key in ['tls-key','witness-tls-key']:
        path=cohort/'inputs'/key
        if not path.exists():
            sdk.require(key=='witness-tls-key' and cohort.name.startswith('signed-'),'missing expected test key');continue
        secret=path.read_bytes()
        for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'test private key included')
for name,payload in list(files.items()):
    if name.endswith(('.py','.json','.stdout','.stderr')):
        files[name]=payload.replace(b'<SELECTED_ANDROID_DEVICE>',b'<SELECTED_ANDROID_DEVICE>').replace(
            b'<SELECTED_ANDROID_DEVICE_SHA256>',b'<SELECTED_ANDROID_DEVICE_SHA256>')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,data)
manifest={'format':1,'source_commit':host['source_commit'],'engine_source_commit':physical['engine_source_commit'],
 'candidate_sha256':host['candidate_sha256'],'aar_sha256':physical['aar_sha256'],'apk_sha256':physical['apk_sha256'],
 'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'host_process_loss_routes':2,'host_process_loss_calls':47,'host_cancellation_regression_calls':43,
 'host_actual_process_cuts':4,'physical_ART_processes':23,'physical_actual_process_cuts':2,'physical_API':37,
 'release_claim_eligible':False,'recipe_hardware_selectors_redacted':True,'product_implementation_changed':False}
sdk.write_json(out/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-process-loss-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'capture inventory')
        for name,digest in manifest['members'].items():
            data=bundle.read(name);sdk.require(hashlib.sha256(data).hexdigest()==digest,'capture hash')
            if '/public' in name:
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        for process_loss,number,record in [(True,'04',host),(False,'05',regression)]:
            results={}
            for route in pending.PROCESS_TESTS:
                results.update(pending.verify_execution(bundle.read('host/host-run-'+number+'.stdout'),extracted/('host/public-'+number),route,
                    batch=True,process_loss=process_loss,query_cancel=not process_loss))
            sdk.require(results==record['cases'],'host readback')
        sdk.require(pending.verify_execution(bundle.read('device/execution.stdout'),extracted/'device/public',label,process_loss=True)==physical['result'],'phone readback')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256'],
 'all_host_and_device_public_readers':True,'private_test_keys_excluded':True})
print(json.dumps({'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256']}))
