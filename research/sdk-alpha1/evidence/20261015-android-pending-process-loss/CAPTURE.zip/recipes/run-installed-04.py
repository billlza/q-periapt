from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'BUILD_02.json').read_text())
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'probe source changed')
for name in ['harness','driver','receiver','library','jar','bridge']:
    sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'baseline runtime changed')
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'source not clean')
cases=stage/'host-cases-04';sdk.require(not cases.exists(),'output already exists')
record={'completed':False,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'candidate_sha256':cfg['candidate_sha256'],'scope':'Actual unchanged installed engine; public pending confirmation process loss; not full release acceptance',
 'physical_ART':False,'release_claim_eligible':False}
sdk.write_json(stage/'RUN_STATE_04.json',record)
env=dict(cfg['environment'],QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=cfg['driver'],QPC_CONFIGURATION_RECEIVER=cfg['receiver'])
try:
    stdout=sdk.command([cfg['harness'],'android_pending_process::','--test-threads=2','--nocapture'],stage/'host-run-04',Path(cfg['consumer']),environment=env)
    results={}
    for label in pending.PROCESS_TESTS:results.update(pending.verify_execution(stdout,cases,label,batch=True,process_loss=True))
    for label in pending.PROCESS_TESTS:
        case_label=label+'-process-loss'
        for name in pending.public(label.endswith('-applied'),process_loss=True):sdk.copy(cases/case_label/name,stage/'public-04'/case_label/name)
        sdk.require(pending.verify_execution(stdout,stage/'public-04',label,batch=True,process_loss=True)[case_label]==results[case_label],'public readback differs')
    record.update(completed=True,cases=results,foreign_processes=sum(value['foreign_processes'] for value in results.values()))
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(stage/'RUN_RESULT_04.json',record)
print('Both actual installed public pending confirmation process loss routes passed')
