from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_android_contract as contract
import continuity_c_witness_openssl as openssl

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'INPUTS_01.json').read_text())
consumer=Path(cfg['consumer']);outside=Path(cfg['outside']);builder=Path(cfg['android_source'])
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());cargo=str(Path(env['RUSTC']).parent/'cargo');target=outside/'build'
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'matrix source changed')
core=root/'target/continuity-browser-publication/source/target/pending-inspection-package-10'
archive_record=json.loads((core/'CORE_ARCHIVES.json').read_text())
for name,row in [*archive_record['crates'].items(),('q-periapt-continuity-identity-candidate',archive_record['candidate'])]:
    is_candidate=name=='q-periapt-continuity-identity-candidate';version='0.0.0' if is_candidate else '0.2.0'
    path=core/row['file'] if is_candidate else core/'crates'/row['file'];archive=sdk.snapshot(path)
    sdk.require(archive.sha256==row['sha256'],'original archive changed')
    contents=sdk.archive_files(archive.data,name,version=version)
    sdk.require(set(contents)==set(row['files']),'original archive inventory')
    for relative,data in contents.items():sdk.require((consumer/'packages'/(name+'-'+version)/relative).read_bytes()==data,'installed archive member changed')
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),'-m','unittest',
 'artifact.test_continuity_android_pending','artifact.test_continuity_android_jni','artifact.test_continuity_android_joint_cycle',
 'artifact.test_continuity_package'],stage/'readers-02',root)
output=sdk.command([cargo,'test','--locked','--offline','--test','android','--no-run','--message-format=json',
 '--target-dir',str(target),'-j','2'],stage/'harness-02',consumer,environment=env)
rows=[json.loads(line) for line in output.splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'matrix harness count')
contract.verify_catalog(sdk.command([tests[0],'--list'],stage/'catalog-02',consumer,environment=env))
sdk.command([cargo,'clippy','--locked','--offline','--tests','--target-dir',str(target),'-j','2','--','-D','warnings'],stage/'clippy-02',consumer,environment=env)
runtime=outside/'runtime';runtime.mkdir();old=cfg['installed_base']
for name in ['receiver','library','jar','bridge']:
    path=Path(old[name]);sdk.require(sdk.snapshot(path,maximum=256*1024**2).sha256==old[name+'_sha256'],'installed runtime changed')
    sdk.copy(path,runtime/path.name,maximum=256*1024**2)
    if name=='receiver':(runtime/path.name).chmod(0o700)
classes=outside/'tests';classes.mkdir()
java=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
jar=runtime/Path(old['jar']).name
sdk.command([str(java/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),
 *map(str,sorted((builder/'src/test/java').glob('*.java')))],stage/'java-02',outside,environment=env)
driver=android._driver(runtime,java/'bin/java',jar,classes,runtime)
clang=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],stage/'clang-02',outside).decode().strip()
platform=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],stage/'platform-02',outside).decode().strip()
def run(argv,label):return sdk.command(argv,stage/(label+'-02'),outside,environment=env)
peer,peer_record=openssl.build_peer(Path('/opt/homebrew/opt/openssl@3'),Path(clang),['-isysroot',platform],consumer,runtime,run,darwin=True,profile='debug')
files={'harness':Path(tests[0]),'driver':driver,'receiver':runtime/Path(old['receiver']).name,
       'library':runtime/Path(old['library']).name,'jar':jar,'bridge':runtime/Path(old['bridge']).name}
cfg.update({name:str(path) for name,path in files.items()});cfg.update({name+'_sha256':sdk.snapshot(path,maximum=256*1024**2).sha256 for name,path in files.items()})
cfg['openssl']=peer_record;cfg['test_classes']={str(path.relative_to(classes)):sdk.snapshot(path).sha256 for path in classes.rglob('*.class')}
cfg['environment']=old['environment'];cfg['built']=True;sdk.write_json(stage/'BUILD_02.json',cfg)
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'matrix source changed')
print('Actual archived engine, full matrix harness, strict checks and independent OpenSSL peer ready')
