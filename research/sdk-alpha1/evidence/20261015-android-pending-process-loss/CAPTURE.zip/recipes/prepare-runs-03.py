from pathlib import Path
import ast
import json
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;old=root/'target/continuity-android-pending-query'
def replace(text,old,new):
    sdk.require(text.count(old)==1,'recipe shape: '+old[:80]);return text.replace(old,new)
def template(name):
    return (old/name).read_text().replace('continuity-android-pending-query','continuity-android-pending-process').replace('dev.qperiapt.continuity.pendingquery20261014','dev.qperiapt.continuity.pendingprocess20261015')
commit=template('commit-10.py').replace('BUILD_06.json','BUILD_02.json').replace('-06','-02').replace('-10','-03').replace('_10.json','_03.json').replace('Qualify cancellation of in-flight pending recovery queries','Qualify process loss during pending recovery confirmation')
host=template('run-installed-07.py').replace('BUILD_06.json','BUILD_02.json').replace('-07','-04').replace('_07.json','_04.json').replace('QUERY_TESTS','PROCESS_TESTS').replace('query_cancel=True','process_loss=True').replace('-query-cancel','-process-loss').replace('android_pending_query::','android_pending_process::').replace('Query cancellation','confirmation process loss')
regression=template('run-installed-07.py').replace('BUILD_06.json','BUILD_02.json').replace('-07','-05').replace('_07.json','_05.json')
apk=template('apk-09.py').replace('physical-08','physical-06').replace('-09','-07').replace('_09.json','_07.json')
apk=replace(apk,"'PendingWriteCancellation']","'PendingWriteCancellation', 'PendingWriteProcessCut']")
driver=template('device-driver-09.py').replace('physical-08','physical-06').replace('-09','-07').replace('_09.json','_07.json').replace('tls-recoverable-applied-query-cancel','tls-recoverable-applied-process-loss')
driver=replace(driver,"'pending-confirm-inflight','pending-confirm-cancelled'","'pending-confirm-process-cut','pending-confirm-result-cut','pending-confirm-inflight','pending-confirm-cancelled'")
driver=replace(driver,'assert mode in allowed',"assert mode in allowed\ncut=mode in ['pending-confirm-process-cut','pending-confirm-result-cut']")
driver=driver.replace("if mode=='pending-confirm-inflight':","if mode in ['pending-confirm-inflight','pending-confirm-process-cut']:")
driver=replace(driver,'assert result.returncode==expected and not stderr',"assert result.returncode in ((expected,) if isinstance(expected,int) else expected) and not stderr")
driver=replace(driver,"result=command('instrument',args,timeout=90)","result=command('instrument',args,expected=(0,1) if cut else 0,timeout=90)")
start=driver.index("    expected=profile+':'+mode+':passed'");end=driver.index("    state['cases'].append",start)
driver=driver[:start]+'''    expected=profile+':'+mode+':passed'
    if cut:
        assert result.count('INSTRUMENTATION_STATUS: stage=pending-cut\\n')==1 and result.count('INSTRUMENTATION_STATUS_CODE: 3')==1,result
        for key,value in [('apk_sha256',state['apk_sha256']),('operation',mode),('label',label)]:
            assert result.count('INSTRUMENTATION_STATUS: '+key+'='+value+'\\n')==1,result
        assert 'INSTRUMENTATION_RESULT: shortMsg=Process crashed.' in result and 'INSTRUMENTATION_RESULT: result=' not in result,result
        pid=int(re.search(r'^INSTRUMENTATION_STATUS: pid=(\\d+)$',result,re.M).group(1))
        payload=base64.b64decode(re.search(r'^INSTRUMENTATION_STATUS: report=([^\\n]+)$',result,re.M).group(1),validate=True)
        phase=1 if mode=='pending-confirm-process-cut' else 2
        binding=(inputs.parent/'pending-before-expiry').read_bytes()[404:436]
        assert len(binding)==32 and payload==b'QPPCUT01'+bytes([phase])+binding
        assert not command('cut-process-absent',['shell','pidof',package],expected=1).strip()
    else:
        assert 'INSTRUMENTATION_RESULT: result='+expected+'\\n' in result,result
        assert result.rstrip().endswith('INSTRUMENTATION_CODE: -1')
        assert 'INSTRUMENTATION_RESULT: apk_sha256='+state['apk_sha256']+'\\n' in result
        pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\\d+)$',result,re.M).group(1))
        payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\\n]+)$',result,re.M).group(1),validate=True)
        assert 1<=len(payload)<=(65536 if mode.startswith('pending-') else 8192)
        command('stop',['shell','am','force-stop',package]);assert not command('process-absent',['shell','pidof',package],expected=1).strip()
    assert pid not in [row['pid'] for row in state['cases']]
    with output.open('xb') as stream:stream.write(payload)
'''+driver[end:]
driver=replace(driver,"'process_absent_after_stop':True","'process_absent_after_operation':True,'actual_cut_observed':cut")
driver=replace(driver,"    save();print(expected)","    save()\n    if cut:sys.exit(77)\n    print(expected)")
driver=replace(driver,"except BaseException as error:\n    state['failure']", "except BaseException as error:\n    if isinstance(error,SystemExit) and cut and error.code==77:raise\n    state['failure']")
run=template('run-device-09.py').replace('physical-08','physical-06').replace('-09','-07').replace('_09.json','_07.json').replace('BUILD_06.json','BUILD_02.json')
run=run.replace('-query-cancel','-process-loss').replace('QUERY_TESTS','PROCESS_TESTS').replace('query_cancel=True','process_loss=True').replace('process_absent_after_stop','process_absent_after_operation')
run=replace(run,"    for row in state['cases']:","    sdk.require(sum(row['actual_cut_observed'] for row in state['cases'])==2,'actual process-cut census')\n    for row in state['cases']:")
run=replace(run,"record.update(completed=True,cleanup=True,result=result,physical_processes=len(state['cases']))","record.update(completed=True,cleanup=True,result=result,physical_processes=len(state['cases']),actual_process_cuts=2)")
run=run.replace('pre-call and held Query cancellation','held Query process loss and confirmation result loss').replace('all 21 original pending recovery calls','all 23 original pending recovery calls with two actual process cuts')
package=json.loads((old/'physical-08/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
out=stage/'physical-06';out.mkdir()
sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');sdk.write_json(out/'PACKAGE.json',package)
recipes={'commit-03.py':commit,'run-installed-04.py':host,'run-regression-05.py':regression,
         'apk-07.py':apk,'device-driver-07.py':driver,'run-device-07.py':run}
for name,value in recipes.items():
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
sdk.write_json(stage/'RECIPES_03.json',{name:sdk.snapshot(stage/name).sha256 for name in recipes})
print('Fresh process-loss and cancellation regression recipes prepared; two ART cuts require scoped status and real process absence')
