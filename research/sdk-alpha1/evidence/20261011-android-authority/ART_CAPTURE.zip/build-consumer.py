from pathlib import Path
import json,os,sys,shutil,subprocess,tempfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[1];package=json.loads((out/'PACKAGE.json').read_text());inputs=Path(sys.argv[1]);label=sys.argv[2];receipt=out/('agp-'+label);receipt.mkdir(mode=0o700)
project=Path(tempfile.mkdtemp(prefix='qperiapt-continuity-android-agp-')).resolve();template=root/'artifact/android-agp-consumer';source=Path(package['source']);jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home')
for name in ['gradlew','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties','settings.gradle.kts','build.gradle.kts','gradle.properties']:
 target=project/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(template/name,target)
(project/'gradlew').chmod(0o700);(project/'libs').mkdir();shutil.copy2(package['aar'],project/'libs/continuity.aar')
app=project/'app';java=app/'src/main/java/dev/qperiapt/continuity/android/tests';java.mkdir(parents=True)
for name in ['ConfigurationProbe.java','EnrollmentProbe.java','PeerProbe.java','CancellationProbe.java','WitnessProbe.java','AuthorityProbe.java']:shutil.copy2(source/'src/test/java'/name,java/name)
for p in (source/'src/androidTest/java/dev/qperiapt/continuity/android/tests').glob('*.java'):shutil.copy2(p,java/p.name)
assets=app/'src/main/assets/inputs';assets.mkdir(parents=True)
for item in inputs.iterdir():
 if item.is_file():shutil.copy2(item,assets/item.name)
manifest=app/'src/main/AndroidManifest.xml';manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:allowBackup="false" android:label="Continuity qualification"/><instrumentation android:name="dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation" android:targetPackage="dev.qperiapt.continuity.authorityprobe20261011"/></manifest>')
(app/'build.gradle.kts').write_text(r"""import java.security.MessageDigest
plugins { id("com.android.application") }
android {
 namespace = "dev.qperiapt.continuity.android.tests"
 compileSdk = 36
 buildToolsVersion = "36.0.0"
 defaultConfig {
  applicationId = "dev.qperiapt.continuity.authorityprobe20261011"
  minSdk = 36
  targetSdk = 36
  versionCode = 1
  versionName = "qualification"
 }
 buildTypes {
  getByName("release") {
   isDebuggable = false
   isMinifyEnabled = true
   vcsInfo.include = false
   proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
  }
 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { buildConfig = false }
 packaging.jniLibs {
  useLegacyPackaging = false
  keepDebugSymbols += setOf("**/libq_periapt_continuity_c_consumer.so", "**/libqperiapt_continuity_jni.so")
 }
}
dependencies { implementation(files(rootProject.file("libs/continuity.aar"))) }
tasks.withType<JavaCompile>().configureEach {
 options.compilerArgs.addAll(listOf("-Xlint:all", "-Werror"))
 doFirst {
  file("compile-inputs.txt").writeText(source.files.map { it.canonicalPath }.sorted().joinToString("\n", postfix="\n"))
  file("compiler-home.txt").writeText(javaCompiler.get().metadata.installationPath.asFile.canonicalPath + "\n")
 }
}
""")
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK','GRADLE','ANDROID','DYLD','LD_'))};env.update(JAVA_HOME=str(jdk),ANDROID_HOME='/Users/bill/Library/Android/sdk',GRADLE_USER_HOME='/Users/bill/.gradle',PATH=str(jdk/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
cmd=[str(project/'gradlew'),'--project-dir',str(project),'--offline','--no-daemon','--no-build-cache','--no-configuration-cache','--max-workers=2','--warning-mode=fail','--console=plain','-Dorg.gradle.java.home='+str(jdk),':app:assembleRelease']
record={'completed':False,'project':str(project),'source':str(source),'aar_sha256':package['aar_sha256'],'command':cmd};(receipt/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
with (receipt/'build.stdout').open('wb') as stdout,(receipt/'build.stderr').open('wb') as stderr:r=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,timeout=900)
record['exit_code']=r.returncode;(receipt/'STATE.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,receipt/'build.stderr'
apk=app/'build/outputs/apk/release/app-release-unsigned.apk';assert apk.is_file();record.update(completed=True,unsigned_apk=str(apk),unsigned_apk_sha256=hashlib.sha256(apk.read_bytes()).hexdigest());(receipt/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
print(receipt,flush=True)
