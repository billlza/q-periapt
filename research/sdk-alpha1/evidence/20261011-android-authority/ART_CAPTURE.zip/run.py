from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=root/'target/continuity-android-authority-device-current';state=json.loads((root/'target/continuity-android-authority-retry/STATE.json').read_text());assert state['completed'] and not state['live_producer'];env=state['environment'];source=Path(state['source'])
compiled=sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json','-j','2'],out/'build',source,environment=env)
binary=c.built_artifact(compiled,source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
runtime=dict(env,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(out/'device-driver.py'))
sdk.command([str(binary),'--exact','android_witness::managed_first_registration','--nocapture'],out/'android-authority',source,environment=runtime)
print('Actual AAR Android account registry profiles passed',flush=True)
