"""Bounded loopback harness; each request reopens the independent native witness."""
from contextlib import contextmanager
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import hashlib,json,re,subprocess,threading,time
from urllib.parse import urlsplit,parse_qs

@contextmanager
def serving(web:Path, output:Path, private:Path, binary:Path, peer_binary:Path):
    captures=output/'captures';captures.mkdir(mode=0o700)
    traces=output/'witness';traces.mkdir(mode=0o700)
    records={};locks={};faulted=set();failures=[];counter={};mode_counts={};peers={};peer_faulted=set();ready_proofs={};control_receipts={}
    peer_traces=output/'peer';peer_traces.mkdir(mode=0o700)
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self,*args,**kw):super().__init__(*args,directory=str(web),**kw)
        def setup(self):self.request.settimeout(10);super().setup()
        def log_message(self,*args):pass  # Protocol records below, not raw URL/credential logs.
        def end_headers(self):
            self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp');self.send_header('Cache-Control','no-store');super().end_headers()
        def do_GET(self):
            match=re.fullmatch(r'/status/([a-z0-9-]+)',self.path)
            if match:
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(records.get(match[1],[])).encode());return
            match=re.fullmatch(r'/peer-status/([a-z0-9-]+)',self.path)
            if match:
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(peers.get(match[1],[])).encode());return
            super().do_GET()
        def peer(self,case,mode,data):
            allowed=['normal','drop-final','corrupt-ready','drop-ack','old-prefix','after-effect','reject-effect','timeout-peer','hold-peer','control-drop-first','control-drop-final','control-empty','control-corrupt','control-old']
            if mode not in allowed or not 10<=len(data)<=32768 or data[:8]!=b'QPCXCH01':self.send_error(400);return
            directory=private/case
            if not (directory/'peer/PUBLIC.json').is_file():self.send_error(404);return
            lock=locks.setdefault(case,threading.Lock())
            if not lock.acquire(blocking=False):self.send_error(503);return
            record=None
            try:
                number=len(peers.get(case,[]))+1;folder=peer_traces/case/f'{number:03}';folder.mkdir(mode=0o700,parents=True)
                request=folder/'request.bin';request.write_bytes(data);reply=folder/'reply.bin'
                kind=data[8]
                trigger=(case,mode) not in peer_faulted and ((kind==2 and mode in ['drop-final','corrupt-ready']) or (kind==3 and mode in ['drop-ack','old-prefix','after-effect','reject-effect']) or mode in ['timeout-peer','hold-peer'] or (kind==4 and (mode in ['control-drop-first','control-empty','control-corrupt','control-old'] or (mode=='control-drop-final' and data[13:21]==b'QPRKFN01'))))
                record={'number':number,'kind':kind,'mode':mode,'trigger':trigger,'request_sha256':hashlib.sha256(data).hexdigest()}
                if self.headers.get('Cookie') or self.headers.get('Authorization'):raise ValueError('peer ambient credentials')
                if trigger:peer_faulted.add((case,mode))
                if trigger and mode=='old-prefix':
                    body=b'QPCXCH01'+bytes([131])+ready_proofs[case]
                    record.update(replayed_empty_prefix=True,native_dispatched=False)
                else:
                    effect=mode if trigger and mode in ['after-effect','reject-effect'] else 'normal'
                    argv=[str(peer_binary),'handle',str(directory),str(request),str(reply),str(folder),effect]
                    with (folder/'native.stdout').open('xb') as out,(folder/'native.stderr').open('xb') as err:
                        completed=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=30,check=False)
                    record.update(native_dispatched=True,returncode=completed.returncode)
                    if completed.returncode:
                        if effect not in ['after-effect','reject-effect']:raise ValueError('native peer failed: '+case+'/'+str(number))
                        error=(folder/'native.stderr').read_text()
                        if 'Application' not in error:raise ValueError('unexpected native effect failure: '+error)
                        record['application_unconfirmed']=True;peers.setdefault(case,[]).append(record)
                        (folder/'RECORD.json').write_text(json.dumps(record,indent=2)+'\n');self.send_error(503);return
                    body=reply.read_bytes();record.update(json.loads((folder/'native.stdout').read_text()))
                    if body[:9]==b'QPCXCH01'+bytes([130]):
                        if int.from_bytes(body[9:11],'big')!=32:raise ValueError('ready identity width')
                        ready_proofs[case]=body[43:]
                if body[:10]==b'QPCXCH01'+bytes([132,1]) and body[14:22]==b'QPRKRC01':control_receipts[case]=body
                if trigger and mode=='control-empty':body=b'QPCXCH01'+bytes([132,0])
                if trigger and mode=='control-corrupt':body=body[:-1]+bytes([body[-1]^1])
                if trigger and mode=='control-old':body=control_receipts[case]
                record['reply_sha256']=hashlib.sha256(body).hexdigest();peers.setdefault(case,[]).append(record)
                (folder/'RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
            except Exception as error:
                failures.append(str(error));self.send_error(500);return
            finally:lock.release()
            if trigger and mode in ['drop-final','drop-ack','control-drop-first','control-drop-final']:self.close_connection=True;return
            if trigger and mode in ['timeout-peer','hold-peer']:
                time.sleep(12);self.close_connection=True;return
            if trigger and mode=='corrupt-ready':body=body[:-1]+bytes([body[-1]^1])
            self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(len(body)));self.end_headers()
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError) as error:failures.append('unexpected peer disconnect: '+case+': '+type(error).__name__)
        def do_POST(self):
            target=urlsplit(self.path);capture=re.fullmatch(r'/capture/([a-z0-9-]+)\.(bin|json)',target.path)
            witness=re.fullmatch(r'/witness/([a-z0-9-]+)',target.path)
            length=self.headers.get('Content-Length','')
            if self.headers.get('Origin')!=origin or not length.isdecimal() or not 0<int(length)<=131072:
                self.send_error(400);return
            data=self.rfile.read(int(length))
            if len(data)!=int(length):self.send_error(400);return
            if target.path.startswith('/carrier/'):
                name=target.path.removeprefix('/carrier/')
                if self.headers.get('Cookie') or self.headers.get('Authorization'):self.send_error(401);return
                if name=='status':self.send_response(503);self.end_headers();return
                if name=='redirect':self.send_response(302);self.send_header('Location','/carrier/unexpected');self.end_headers();return
                if name not in ['short','overflow','slow']:self.send_error(400);return
                if name=='slow':time.sleep(1)
                self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.end_headers()
                try:self.wfile.write(bytes(3658 if name=='short' else 3660 if name=='overflow' else 3659))
                except (BrokenPipeError,ConnectionResetError):
                    if name!='slow':raise
                return
            peer=re.fullmatch(r'/peer/([a-z0-9-]+)',target.path)
            if peer:
                modes=parse_qs(target.query).get('mode',['normal'])
                if len(modes)!=1:self.send_error(400);return
                self.peer(peer[1],modes[0],data);return
            if capture:
                path=captures/(capture[1]+'.'+capture[2])
                try:
                    with path.open('xb') as f:f.write(data)
                except FileExistsError:self.send_error(409);return
                self.send_response(201);self.end_headers();self.wfile.write(b'captured');return
            if not witness or len(data)!=3674:self.send_error(400);return
            case=witness[1];directory=private/case;genesis=captures/(case+'-genesis.json')
            mode=parse_qs(target.query).get('mode',['normal'])
            if len(mode)!=1 or mode[0] not in ['normal','drop-after-advance','timeout-after-advance','hold-after-advance','corrupt','oversized','drop-ack'] or not directory.is_dir() or not genesis.is_file():self.send_error(400);return
            mode=mode[0]
            lock=locks.setdefault(case,threading.Lock())
            if not lock.acquire(blocking=False):self.send_error(503);return
            try:
                number=counter.get(case,0)+1;counter[case]=number
                folder=traces/case;folder.mkdir(mode=0o700,exist_ok=True)
                prefix=folder/f'{number:03}'
                request=prefix.with_suffix('.request');request.write_bytes(data)
                reply=prefix.with_suffix('.reply');trace=prefix.with_suffix('.json')
                if self.headers.get('Cookie') or self.headers.get('Authorization'):raise ValueError('ambient credentials sent')
                argv=[str(binary),'handle',str(directory),str(genesis),str(request),str(reply),str(trace)]
                with prefix.with_suffix('.stdout').open('xb') as out,prefix.with_suffix('.stderr').open('xb') as err:
                    completed=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=10,check=False)
                if completed.returncode:raise ValueError('native witness failed: '+case+'/'+str(number))
                body=reply.read_bytes()
                if len(body)!=3659:raise ValueError('native reply width')
                record=json.loads(trace.read_text());record.update(number=number,mode=mode,request_sha256=hashlib.sha256(data).hexdigest(),reply_sha256=hashlib.sha256(body).hexdigest())
                records.setdefault(case,[]).append(record)
                mode_counts[(case,mode)]=mode_counts.get((case,mode),0)+1
                trigger=case not in faulted and (mode_counts[(case,mode)]==3 if mode=='drop-ack' else record['changed'] if 'advance' in mode else mode!='normal')
                record['trigger']=trigger
                if trigger:faulted.add(case)
                (folder/'RECORDS.json').write_text(json.dumps(records[case],indent=2)+'\n')
            except Exception as error:
                failures.append(str(error));self.send_error(500);return
            finally:lock.release()
            if trigger and mode in ['drop-after-advance','drop-ack']:self.close_connection=True;return
            if trigger and mode in ['timeout-after-advance','hold-after-advance']:
                time.sleep(7);self.close_connection=True;return
            if trigger and mode=='corrupt':body=body[:-1]+bytes([body[-1]^1])
            if trigger and mode=='oversized':body+=b'\0'
            self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(len(body)));self.end_headers()
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError) as error:
                failures.append('unexpected client disconnect: '+case+'/'+str(number)+': '+type(error).__name__)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=False
    origin=f'http://127.0.0.1:{server.server_port}';thread=threading.Thread(target=server.serve_forever);thread.start()
    try:yield origin,records,peers,failures
    finally:
        server.shutdown();server.server_close();thread.join(timeout=5)
        if thread.is_alive():raise RuntimeError('fixture server did not stop')
