from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-roster-sessions';package=root/'target/continuity-browser-publication/source/target/roster-package-02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
reports=[load(stage/n/'RESULT.json') for n in ['run-01','run-02']]
assert all(r['completed'] for r in reports)
cases={c['case']:c for r in reports for c in r['cases']}
assert set(cases)=={'applied','closed','drop-commit','drop-ack','close-after-commit'} and sum(len(r['cases']) for r in reports)==5
for name,c in cases.items():
 assert c['progress_before']==c['progress_after'] and c['progress_before']['pending']=='1' and c['progress_before']['confirmed']=='0'
 assert c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
 assert c['final']['state']==(3 if name=='closed' else 2) and c['final']['progress']['retired']
 assert c['rekey']['epoch']=='1' and c['delivery']==c['fresh_delivery']=={'consumption':1,'status':3}
 assert c['message']!=c['fresh_message'] and c['reverse']['same_original_wire'] and c['reverse']['authenticated_browser_consumption']
 assert c['received']['application']==c['duplicate']['application'] and c['received']['application']['effects']==c['received']['application']['calls']==1 and not c['duplicate']['callbackInvoked']
 assert c['received']['reply']==c['duplicate']['reply']
 control=[r for r in c['peer_records'] if r['kind']==4];messages=[r for r in c['peer_records'] if r['kind']==3]
 assert control[0]['trigger'] and control[0]['request_sha256']==control[1]['request_sha256']
 assert len(messages)==3 and messages[0]['trigger'] and messages[0]['request_sha256']==messages[1]['request_sha256']!=messages[2]['request_sha256']
 assert sum(r['kind']==1 for r in c['peer_records'])==sum(r['kind']==2 for r in c['peer_records'])==1
 if 'after_loss' in c:assert c['after_loss']['progress']['stage']==(4 if name=='drop-ack' else 3) and not c['after_loss']['progress']['retired']
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz') and receipt['source_bound'] and receipt['sources_unchanged']
for r in reports:
 for n,d in r['native'].items():assert sha(Path(n))==d
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),p
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.name not in ['HANDOFF.json','seal.stdout','seal.stderr'] and p.suffix in ['.py','.js','.json','.stdout','.stderr','.log']:add(p,'driver/'+p.name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/name,'native-peer/'+name)
add(root/'target/continuity-browser-roster/authority/src/main.rs','authority/roster.rs')
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','authority/witness.rs')
web=Path(load(package/'consumer-location.json')['path'])
for directory,report in zip(['run-01','run-02'],reports):
 base=stage/directory;add(base/'RESULT.json',directory+'/RESULT.json')
 for p in sorted(base.iterdir()):
  if p.is_file() and p.name!='RESULT.json':add(p,directory+'/'+p.name)
 for part in ['logs','captures','peer']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():add(p,directory+'/'+p.relative_to(base).as_posix())
 for part in ['witness','native']:
  for p in sorted((base/part).rglob('*')):
   if p.is_file():raw[directory+'/'+p.relative_to(base).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for c in report['cases']:
  key=directory+'-'+c['case'];records=c['witness_records'];selected=set()
  for record in records:
   if record['trigger']:selected.update([record['number']-1,record['number'],record['number']+1])
  folder=base/'witness'/key
  add(folder/'RECORDS.json',directory+'/witness/'+key+'/RECORDS.json')
  for number in sorted(selected):
   for suffix in ['request','reply','json']:
    p=folder/f'{number:03}.{suffix}'
    if p.is_file():add(p,directory+'/witness/'+key+'/'+p.name)
  for p in sorted((web/'inputs').glob(key+'*')):
   if p.is_file():add(p,'public-inputs/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:
 add(package/name,'package/'+name)
add(root/'research/sdk-alpha1/evidence/20261013-browser-roster-maintenance/CHECKS.json','prior-roster/CHECKS.json')
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())}
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)}
encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-roster-session-continuity';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,meta in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==meta['sha256'] and len(z.read(n))==meta['bytes']
checks={'completed':True,'release_claim_eligible':False,'engine_commit':'e8a829782fc44b4841c28015af25488821f3c439','cases':sorted(cases),'case_count':5,
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},
 'validated':['One original bootstrap and same session ID; no replacement handshake after R.','Committed outbound message with lost native consumption ACK; pending incoming native ciphertext captured before R.','One pending PQ rekey control reply lost before R; exact progress survives.','R Applied/Closed, lost Commit, lost ACK and Close-after-commit recover through original enrollment.','Original control/ciphertext bytes replay unchanged after R; target epoch1 finishes.','Original messages in both directions authenticate consumption; duplicate receive skips the host callback and retains the identical ACK.','New message after R and rekey has a distinct ID/ciphertext and commits exactly one additional native host effect.'],
 'trace_policy':'All raw witness and native witness files remain task-local under the original closed runs and are hashed in FULL_RAW_TRACE_MANIFEST.json. The archive includes complete peer/carrier traffic, public fixtures, operation logs/results, complete witness metadata and raw witness traces around the injected R loss cuts. Private keys, journal stores and browser profiles are excluded.',
 'scope':'Actual installed browser npm package with IndexedDB/Web Locks/OPFS, original public bundle/pins, current policy and loopback native signed witness/counterpart sharing the Rust engine. Original peer trust remains at its authenticated bootstrap roster; this does not claim remote adoption of the new roster, revocation propagation, independent implementation, deployment, representative performance, PCS or full-release qualification.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Browser session continuity across original roster maintenance

Five fresh cohorts use the actual installed npm web entry, Chrome dedicated Workers, browser persistent storage, a native counterpart and the required signed witness. They qualify the product session path across original R maintenance on engine revision `e8a82978`: Applied, Closed, lost Commit reply, lost ACK reply and Close after remote commit.

Before R, each cohort establishes exactly one session, loses the consumption ACK for a committed browser message, captures an unconfirmed native message, and loses the first reply to a pending PQ rekey. All these owners close and reopen the original stores. After R, the same session and pending rekey progress remain; the original control frame and application ciphertext replay byte-for-byte. Rekey reaches epoch 1, both original application messages receive authenticated consumption, duplicate receive does not invoke the host again, and a new message commits under a distinct ID. Native effects remain one per message; browser duplicate acknowledgement bytes are identical. The original journal identity and prekey are also preserved.

This does not infer no-commit from an error. A lost R Commit reply retains Reserved until historical reconciliation; a lost ACK retains Applied with cleanup incomplete; Close after a remote commit remains Applied. Historical R recovery creates no live runtime. Current policy/authority is checked again before operational activation and session use.

`CHECKS.json` and `CAPTURE.zip` retain source/package/binary bindings, exact fixture code, public inputs, complete operation results and carrier traffic. Repetitive raw witness traffic remains in the original task-local runs with a complete hash manifest; the archive includes full witness metadata and raw messages around injected R loss cuts. No private signing/wrapping keys, journals or browser profiles are included.

The counterpart still uses independently pinned original bootstrap trust; this record does not establish that it adopted the browser's new roster or received a revocation. Each operation deliberately reopens a Worker and owner to exercise persistence, so request counts are not representative steady-state performance. The peer and witness share the Rust implementation and use loopback. These results are not independent-implementation, deployed-network, PCS or release evidence. No production code or cryptographic construction changed for this qualification.
''')
print(json.dumps(checks['capture']))
