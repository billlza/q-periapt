from pathlib import Path
import os,sys,tarfile,json,hashlib,subprocess,time,platform
b=Path(__file__).resolve().parent;s=b/'source';s.mkdir()
with tarfile.open(b/'SOURCE.tar') as t:t.extractall(s,filter='data')
inputs=json.loads((b/'INPUTS.json').read_text())
for n,h in inputs['files'].items():assert hashlib.sha256((s/n).read_bytes()).hexdigest()==h,n
tc=Path('/opt/qperiapt/rustup/toolchains/1.98.1-aarch64-unknown-linux-gnu')
e=dict(PATH=str(tc/'bin')+':/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/opt/qperiapt/cargo-cache',CARGO_TARGET_DIR=str(b/'build'),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',HOME=os.environ['HOME'])
cmd=[str(tc/'bin/cargo'),'test','--locked','--offline','-p','q-periapt-cli','--features','policy-store-migration','--bin','qperiapt','--','--nocapture']
record=dict(command=cmd,base=inputs['base'],platform=platform.platform(),uid=os.getuid(),rustc=subprocess.check_output([str(tc/'bin/rustc'),'-vV'],text=True),gcc=subprocess.check_output(['gcc','--version'],text=True),source_files=len(inputs['files']))
(b/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (b/'stdout.log').open('wb') as so,(b/'stderr.log').open('wb') as se:r=subprocess.run(cmd,cwd=s,env=e,stdout=so,stderr=se)
record.update(returncode=r.returncode,seconds=time.monotonic()-start)
(b/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((b/'stdout.log').read_text()[-4000:]);print((b/'stderr.log').read_text()[-4000:]);r.check_returncode()
