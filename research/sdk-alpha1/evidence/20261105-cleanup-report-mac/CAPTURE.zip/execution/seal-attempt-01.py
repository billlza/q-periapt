from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-cleanup-report'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-cleanup-report-mac'
PIN = 'c32362567e748787a64ab767769e811f62cb87d5'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
files = {}
inventory = {}
names = [
    'Cargo.toml', 'Cargo.lock', 'research/continuity-identity-candidate/Cargo.toml',
    *['research/continuity-identity-candidate/src/' + n for n in [
        'codec.rs', 'contract.rs', 'identity.rs', 'durable.rs', 'durable/messages.rs',
        'durable/messages/closure.rs', 'durable/messages/resolution.rs',
        'durable/messages/fanout.rs', 'durable/messages/fanout/abandonment.rs',
        'durable/messages/fanout/codec.rs', 'durable/messages/validation.rs',
        'durable/messages/tests.rs', 'durable/messages/tests/closure.rs',
        'durable/messages/tests/fanout.rs', 'durable/messages/tests/fanout/abandonment.rs',
        'durable/messages/tests/fanout/process.rs']]]
for name in names:
    data = (ROOT / name).read_bytes()
    assert data == subprocess.check_output(['git', 'show', PIN + ':' + name], cwd=ROOT)
    files['source/' + name] = data
    inventory[name] = {'bytes': len(data), 'sha256': sha(data)}
source = lambda name: (ROOT / 'research/continuity-identity-candidate/src' / name).read_text()
closure = source('durable/messages/closure.rs')
cmac = closure.split('fn report_mac(', 1)[1].split('fn require_independent(', 1)[0]
assert '.checked_sub(64)' in cmac and 'mac.update(&[0; 64]);' in cmac
assert 'mac.update(record.payload.get(..prefix)' in cmac
assert 'pending.key.as_bytes()' in closure and 'pending.report.as_bytes()' in closure
begin = closure.split('async fn begin_closure(', 1)[1].split('pub async fn acknowledge_session_closure(', 1)[0]
assert begin.count('getrandom::fill(') == 1
assert 'if record.phase == DurableStatus::Messages {' in begin
def ordered(text, tokens):
    offset = 0
    result = []
    for token in tokens:
        where = text.index(token, offset)
        result.append({'token': token, 'offset': where})
        offset = where + len(token)
    return result
closure_order = ordered(begin, ['getrandom::fill(key.as_mut_bytes())',
    'SessionClosureId::from_trusted_state(', 'report_mac(&image, record, &key)?',
    'state.closure = Some(Pending { report, key })', 'record.phase = DurableStatus::MessagesClosing',
    'self.persist(&mut image).await?', 'self.check_release(&image).await?', 'Ok(report)'])
fanout = source('durable/messages/fanout/abandonment.rs')
fmac = fanout.split('fn report_mac(', 1)[1].split('pub(super) fn validate_report(', 1)[0]
assert 'mac.update(&batch.metadata());' in fmac and 'mac.update(&record.payload);' in fmac
fbegin = fanout.split('async fn begin_fanout_cleanup(', 1)[1].split('pub async fn acknowledge_fanout_abandonment(', 1)[0]
assert fbegin.count('getrandom::fill(') == 1 and 'BatchState::Abandoning { .. } => {}' in fbegin
fanout_order = ordered(fbegin, ['getrandom::fill(key.as_mut_bytes())',
    'FanoutAbandonmentId::from_trusted_state(', 'report_mac(&image, &batch, &key)?',
    'record.phase = DurableStatus::MessagesAbandoning', 'batch.state = BatchState::Abandoning { report, key }',
    'self.persist(&mut image).await?', 'let report = report(&image, &batch)?',
    'self.check_release(&image).await?', 'Ok(report)'])
codec = source('durable/messages/fanout/codec.rs')
metadata = codec.split('fn metadata(', 1)[1].split('pub(super) fn record(', 1)[0]
assert 'self.state' not in metadata and 'key.as_bytes()' not in metadata and 'report.as_bytes()' not in metadata
assert 'crate::codec::nonzero(&bytes)?;' in closure
assert 'crate::codec::nonzero(&bytes)?;' in fanout
assert 'Err(Error::Encoding)' in source('codec.rs').split('pub(crate) fn nonzero', 1)[1].split('pub(crate) fn generation', 1)[0]
session_test = source('durable/messages/tests/closure.rs')
selected_session = session_test.split('fn independent_session_closure_accounts_all_epochs_and_a_real_reserved_input()', 1)[1].split('#[test]', 1)[0]
assert selected_session.count('kill_responder(') == 1
fanout_test = source('durable/messages/tests/fanout/abandonment.rs')
selected_fanout = fanout_test.split('fn account_fanout_abandonment_process_cuts_freeze_and_close_all_sessions()', 1)[1].split('#[test]', 1)[0]
assert 'for stage in ["fanout-abandoning", "fanout-abandoned"]' in selected_fanout
assert selected_fanout.count('process::reserved(') == 1 and selected_fanout.count('process::abandonment_cut(') == 1
process = source('durable/messages/tests/fanout/process.rs')
assert 'child.0.kill()' in process.split('pub(super) fn reserved(', 1)[1].split('pub(super) fn abandonment_cut(', 1)[0]
assert 'child.0.kill()' in process.split('pub(super) fn abandonment_cut(', 1)[1]
result = json.loads((BASE / 'RESULT.json').read_bytes())
launch = json.loads((BASE / 'LAUNCH_RESULT.json').read_bytes())
assert result['completed'] and launch['completed'] and launch['returncode'] == 0
assert result['source_commit'] == PIN and result['selected_source_inputs_unchanged'] and result['tool_binaries_unchanged']
assert launch['timeout_seconds'] == 1800 and launch['component_timeout_seconds'] == 900
assert launch['component_stream_limit_bytes'] == 16 * 1024**2
tests = []
for profile, cases in result['profiles'].items():
    assert len(cases) == 3
    for label, case in cases.items():
        stem = BASE / (profile + '-' + label)
        receipt = json.loads(stem.with_suffix('.json').read_bytes())
        assert receipt['returncode'] == 0 and case['test'] in receipt['argv']
        assert sha(stem.with_suffix('.stdout').read_bytes()) == case['stdout_sha256']
        assert sha(stem.with_suffix('.stderr').read_bytes()) == case['stderr_sha256']
        assert '0 failed; 0 ignored; 0 measured; 1458 filtered out;' in case['summary']
        tests.append({'profile': profile, 'case': label, **case})
assert len(tests) == 6
binaries = {}
for profile in ['debug', 'release']:
    stderr = (BASE / (profile + '-session-report.stderr')).read_text()
    found = re.findall(r'Running unittests src/lib.rs \(([^\n]+)\)', stderr)
    assert len(found) == 1
    p = ROOT / found[0]
    binaries[profile] = {'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
for p in sorted(BASE.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json', '.stdout', '.stderr']:
        files['execution/' + p.name] = p.read_bytes()
for name in ['CLEANUP_REPORT_MAC_V1.md', 'SHARED_ROOT_HMAC_V1.md', 'MULTI_RECORD_COMMITMENTS_V1.md']:
    files['documents/' + name] = (ROOT / 'docs/continuity' / name).read_bytes()
audit = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': PIN,
    'source_inputs': inventory, 'source_scope': 'Literal source/order checks and manual interface proof, not a control-flow or computational proof checker.',
    'closure_order': closure_order, 'fanout_order': fanout_order,
    'report_key_bytes': 32, 'closure_excluded_tail_bytes': 64,
    'report_key_is_part_of_own_mac_transcript': False, 'zero_report_is_resampled': False,
    'zero_report_branch_executed_in_tests': False, 'zero_report_source_error': 'Error::Encoding',
    'fresh_key_calls_per_first_attempt': 1, 'retry_of_durable_report_draws_new_key': False,
    'tests': tests, 'test_binaries': binaries, 'test_binary_sources_changed': False,
    'owned_child_terminations_per_profile': 5, 'owned_child_terminations_total': 10,
    'parent_elapsed_seconds': launch['elapsed_seconds'],
    'physical_power_loss_claimed': False, 'full_native_suite_rerun': False,
    'conditional_one_report_bound': 'min(1, DFH(2,q+ell*T)+E_NMAC(T,q,ell)), unchanged-transcript interface only',
    'private_record_refinement_complete': False, 'changed_transcript_simulation_complete': False,
    'multi_epoch_computational_theorem_complete': False, 'release_claim_eligible': False}
files['SOURCE_AUDIT.json'] = encode(audit)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('SOURCE_AUDIT.json', files['SOURCE_AUDIT.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
