from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import runpy
import sys
import continuity_package as package
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-cleanup-report'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
BUILD = ROOT / 'target/continuity-aggregate-reservation-copy/build'
COMMIT = 'c32362567e748787a64ab767769e811f62cb87d5'
MANIFEST = 'research/continuity-identity-candidate/Cargo.toml'
TESTS = {
    'session-report': 'durable::messages::tests::closure::independent_session_closure_accounts_all_epochs_and_a_real_reserved_input',
    'rekey-fences': 'durable::messages::tests::closure::independent_session_closure_fences_pending_rekey_flights_before_and_after_cutover',
    'fanout-report': 'durable::messages::tests::fanout::abandonment::account_fanout_abandonment_process_cuts_freeze_and_close_all_sessions',
}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def main():
    assert ROOT == package.ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sdk.validate_no_registry_credentials(os.environ)
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    before = package.source_inputs()
    tools = package.compiler_identity(CHAIN)
    assert sdk.command(['git', 'rev-parse', 'HEAD'], BASE / 'source-head', ROOT).decode().strip() == COMMIT
    assert sdk.command(['git', 'diff', '--name-only'], BASE / 'tracked-delta', ROOT) == b''
    assert json.loads((BUILD.parent / 'RESULT.json').read_bytes())['completed'] and BUILD.is_dir()
    environment = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    environment.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
        CARGO_TARGET_DIR=str(BUILD), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
        CARGO_TERM_COLOR='never', RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
        RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'),
        PATH=str(CHAIN / 'bin') + os.pathsep + os.environ.get('PATH', os.defpath))
    state = {'completed': False, 'source_commit': COMMIT, 'source_inputs': before, 'tool_binaries': tools,
        'started_utc': datetime.now(timezone.utc).isoformat(), 'driver_sha256': digest(Path(__file__)),
        'command_helper_sha256': digest(helper), 'build_cache_reused': str(BUILD),
        'rust_source_changed': False, 'full_native_suite_rerun': False, 'hosted_ci_claimed': False,
        'scope': 'Existing immutable cleanup-report, private-state tamper, rekey fence and owned process-cut cases. No computational security theorem, zero-MAC sampling test, emulator, device or physical power-loss claim.',
        'release_claim_eligible': False, 'profiles': {}}
    write(BASE / 'INPUTS.json', state)
    try:
        for profile in ['debug', 'release']:
            records = {}
            for label, test in TESTS.items():
                argv = [str(CHAIN / 'bin/cargo'), 'test', '--manifest-path', MANIFEST, '--lib', '--all-features', '--locked', '--offline']
                if profile == 'release':
                    argv.append('--release')
                argv += [test, '--', '--exact', '--nocapture']
                stem = BASE / (profile + '-' + label)
                stdout = sdk.command(argv, stem, ROOT, environment=environment).decode()
                stderr = stem.with_suffix('.stderr').read_text()
                assert stdout.splitlines().count('test ' + test + ' ... ok') == 1
                summaries = re.findall(r'^test result: (.+)$', stdout, re.M)
                assert len(summaries) == 1 and summaries[0].startswith('ok. 1 passed; 0 failed; 0 ignored;')
                assert not re.search(r'(?im)^(?:warning|error)(?:\[|:)', stderr)
                markers = re.findall(r'^FANOUT_ABANDONMENT_PROCESS cut=(\S+) all_sessions_terminal=true contender=Busy$', stderr, re.M)
                if label == 'fanout-report':
                    assert markers == ['fanout-abandoning', 'fanout-abandoned']
                else:
                    assert not markers
                records[label] = {'test': test, 'summary': summaries[0], 'markers': markers,
                    'stdout_sha256': digest(stem.with_suffix('.stdout')), 'stderr_sha256': digest(stem.with_suffix('.stderr'))}
            state['profiles'][profile] = records
        assert package.source_inputs() == before and package.compiler_identity(CHAIN) == tools
        state.update(completed=True, selected_source_inputs_unchanged=True, tool_binaries_unchanged=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'RESULT.json', state)
        print(json.dumps({k: state.get(k) for k in ['completed', 'error_type', 'error', 'profiles']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
