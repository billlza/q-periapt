from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
# No --prove: replay the exported proof methods without launching a new search.
stdout=sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(stage/'export-19.spthy'),'--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS'],stage/'replay-20',root)
summary=stdout.decode().split('summary of summaries:');sdk.require(len(summary)==2,'missing proof summary')
line=re.findall(r'^  recovery_is_executable \(exists-trace\): verified \(([0-9]+) steps\)$',summary[-1],re.M)
sdk.require(len(line)==1,'normal witness not verified by fresh replay')
sdk.write_json(stage/'REPLAY_20.json',{'completed':True,'verified_lemma':'recovery_is_executable','proof_steps':int(line[0]),'theory_sha256':sdk.snapshot(stage/'export-19.spthy').sha256,'autoprove_requested':False,'other_lemmas_not_claimed':True})
print('Normal execution witness verified by a fresh proof-script replay: '+line[0]+' steps')
