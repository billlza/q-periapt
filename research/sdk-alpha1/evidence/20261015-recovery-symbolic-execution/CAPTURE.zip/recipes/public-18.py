from pathlib import Path
import contextlib,io,json,re,runpy,sys
stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))
from client2 import Page
source='trace-17-3-state.response'
for index in range(18):
 raw=(stage/source).read_text()
 try:html=json.loads(raw)['html']
 except json.JSONDecodeError:html=raw
 page=Page();page.feed(html)
 methods=[(p,re.sub(r'\s+',' ',t).strip()) for p,t in page.links if '/main/method/' in p]
 eligible=[(p,t) for p,t in methods if t.startswith('solve( !KU(')]
 if not eligible:
  print(json.dumps({'stopped_at':source,'remaining_methods':methods},ensure_ascii=False));break
 _,chosen=min(eligible,key=lambda row:len(row[1]));label='public-18-'+str(index)
 sys.argv=[str(stage/'advance-12.py'),source,chosen,label]
 with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(stage/'advance-12.py'),run_name='__main__')
 source=label+'-state.response'
 print('Applied public goal: '+chosen[:140],flush=True)
else:raise ValueError('public-goal step bound exhausted')
(stage/'PUBLIC_18.json').write_text(json.dumps({'last_state':source,'remaining_methods':methods},indent=2)+'\n')
