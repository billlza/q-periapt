from pathlib import Path
import runpy,sys
stage=Path(__file__).resolve().parent
sys.path.insert(0,str(stage))
runpy.run_path(str(stage/'steps-09.py'),run_name='__main__')
