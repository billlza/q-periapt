from pathlib import Path
import hashlib,json,re,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
verified=json.loads((stage/'VERIFIED_23.json').read_text());semantic=json.loads((stage/'SEMANTICS_22.json').read_text());missing=json.loads((stage/'MISSING_PROOF_24.json').read_text())
sdk.require(verified['completed'] and verified['verified_lemmas']=={'generation_secret_origin':182,'recovery_is_executable':59},'combined proof results differ')
sdk.require(semantic['completed'] and len(semantic['rejected_semantic_mutations'])==6 and semantic['identical_full_lemma_declarations']==5,'semantic checks incomplete')
sdk.require(missing['completed'] and missing['missing_proof_correctly_incomplete'] and not missing['proof_accepted'],'missing-proof control not enforced')
sdk.require(json.loads((stage/'CLEANUP_25.json').read_text())['completed'],'owned server cleanup incomplete')
sdk.require(sdk.snapshot(stage/'export-19.spthy').sha256==verified['theory_sha256']==semantic['candidate_sha256'],'proof certificate changed')
sdk.require(sdk.snapshot(root/'research/continuity-recovery-symbolic/protected-state.spthy').sha256==json.loads((stage/'SERVER_01.json').read_text())['input_sha256'],'canonical model changed')
requests=[json.loads(p.read_text()) for p in stage.glob('*.request.json')]
mutations=[row['path'] for row in requests if '/main/method/' in row['path']]
sdk.require(len(mutations)==32 and all(re.fullmatch(r'/thy/trace/[0-9]+/main/method/recovery_is_executable/[0-9]+(?:/.*)?',p) for p in mutations),'unexpected proof-method actions')
sdk.require(not any(any(part in row['path'] for part in ('/edit/','/delete/','/add/','/reload','/get_and_append/')) for row in requests),'model editing action present')
files={}
def add(path,name):
 sdk.require(name not in files,'duplicate archive member');files[name]=sdk.snapshot(path,maximum=16*1024**2).data
for path in stage.iterdir():
 if not path.is_file():continue
 if path.suffix=='.spthy':folder='proof/'
 elif path.suffix=='.py':folder='recipes/'
 elif path.suffix in ('.response','.html'):folder='interactive/'
 elif path.suffix in ('.json','.stdout','.stderr'):folder='receipts/'
 else:raise ValueError('unexpected top-level evidence file: '+path.name)
 add(path,folder+path.name)
add(stage/'model/transition.spthy','proof/initial-source.spthy')
add(root/'research/continuity-recovery-symbolic/README.md','source/research-README.md')
add(root/'docs/continuity/RECOVERY_DEPENDENCIES_V1.md','source/RECOVERY_DEPENDENCIES_V1.md')
prior=root/'target/continuity-recovery-symbolic-20261015'
for name in ['TOOLS_08.json','tool-contract-09.json','tool-contract-09.stdout','tool-contract-09.stderr']:
 add(prior/name,'toolchain/'+name)
output=root/'research/sdk-alpha1/evidence/20261015-recovery-symbolic-execution';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'format':1,'base_commit':'b31c8f9f5b197958e43b5fc2cf6e17ced64f8414','capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,
 'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},'initial_source_sha256':sdk.snapshot(stage/'model/transition.spthy').sha256,'certificate_sha256':verified['theory_sha256'],
 'verified_lemmas':verified['verified_lemmas'],'unproved_lemmas':verified['unproved_lemmas'],'interactive_proof_method_actions':32,'rules_equations_restrictions_unchanged':True,'all_five_lemma_declarations_unchanged':True,
 'semantic_mutations_rejected':6,'missing_proof_rejected_despite_exit_zero':True,'owned_server_closed':True,'production_code_changed':False,'release_claim_eligible':False}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.namelist())==len(set(z.namelist()))==len(files),'archive inventory differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'archive member digest differs')
 sdk.require(hashlib.sha256(z.read('proof/export-19.spthy')).hexdigest()==manifest['certificate_sha256'],'archived certificate differs')
 for record in ['receipts/REPLAY_20.json','receipts/VERIFIED_23.json','receipts/MISSING_PROOF_24.json','receipts/CLEANUP_25.json']:
  sdk.require(json.loads(z.read(record))['completed'],'archived final check incomplete')
sdk.write_json(output/'READBACK.json',{'completed':True,'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemma_count':2,'unproved_lemma_count':3,'private_sdk_runtime_data_selected':False})
print(json.dumps({'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemmas':2,'unproved_lemmas':3}))
