from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
stdout=sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(stage/'missing-proof-22.spthy'),'--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS'],stage/'missing-proof-24',root).decode()
summary=stdout.split('summary of summaries:');sdk.require(len(summary)==2,'summary absent')
sdk.require(summary[-1].splitlines().count('  recovery_is_executable (exists-trace): analysis incomplete (1 steps)')==1,'missing proof did not remain incomplete')
sdk.require(not re.search(r'^  recovery_is_executable .*: verified',summary[-1],re.M),'missing proof incorrectly accepted')
sdk.write_json(stage/'MISSING_PROOF_24.json',{'completed':True,'process_exit_code':0,'proof_accepted':False,'missing_proof_correctly_incomplete':True,'same_model_declarations':True})
print('Exit zero with a missing proof correctly remains unaccepted')
