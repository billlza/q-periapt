from pathlib import Path
import json,socket,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();s=Path(__file__).resolve().parent
meta=json.loads((s/'SERVER_01.json').read_text());terminal=json.loads((s/'SERVER_TERMINAL_01.json').read_text())
sdk.require(terminal['returncode']==-2 and not terminal['timed_out'],'server did not terminate after owned stop')
p=subprocess.run(['ps','-p',str(meta['pid']),'-o','command='],stdout=subprocess.PIPE,text=True,check=False)
sdk.require(p.returncode!=0,'owned server PID still exists')
try:
 with socket.create_connection(('127.0.0.1',meta['port']),timeout=1):raise ValueError('owned proof port still listening')
except ConnectionRefusedError:pass
sdk.write_json(s/'CLEANUP_25.json',{'completed':True,'owned_server_terminated':True,'owned_loopback_port_refused':True,'private_sdk_state_opened':False,'global_tool_installation_changed':False})
print('Owned proof server and local listener are closed')
