from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
argv=[t['tamarin'],'--with-maude='+t['maude'],str(stage/'export-19.spthy'),'--prove=generation_secret_origin','--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS']
stdout=sdk.command(argv,stage/'origin-23',root).decode();parts=stdout.split('summary of summaries:');sdk.require(len(parts)==2,'summary absent')
expected=['generation_secret_origin','recovery_is_executable'];verified={}
for name in expected:
 rows=re.findall(r'^  '+name+r' \((?:all-traces|exists-trace)\): verified \(([0-9]+) steps\)$',parts[-1],re.M)
 sdk.require(len(rows)==1,'required lemma not verified: '+name);verified[name]=int(rows[0])
sdk.write_json(stage/'VERIFIED_23.json',{'completed':True,'theory_sha256':sdk.snapshot(stage/'export-19.spthy').sha256,'verified_lemmas':verified,'unproved_lemmas':['clean_reservation_recovers_symbolic_message_secrecy','pre_cut_generation_reservation_remains_exposed','later_storage_access_defeats_fresh_reservations'],'release_claim_eligible':False})
print(json.dumps(verified))
