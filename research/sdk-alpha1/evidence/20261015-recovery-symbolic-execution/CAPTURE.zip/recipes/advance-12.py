from pathlib import Path
import contextlib,io,json,re,sys
stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))
from client2 import fetch,Page
source,selector,label=sys.argv[1:]
raw=(stage/source).read_text()
try:html=json.loads(raw)['html']
except json.JSONDecodeError:html=raw
page=Page();page.feed(html)
choices=[(p,re.sub(r'\s+',' ',t).strip()) for p,t in page.links if '/main/method/' in p and selector in re.sub(r'\s+',' ',t)]
if len(choices)!=1:raise ValueError('method selector must match exactly one: '+repr(choices))
path,method=choices[0]
with (stage/(label+'-attempt.json')).open('x') as f:json.dump({'path':path,'method':method,'source':source},f)
with contextlib.redirect_stdout(io.StringIO()):
 value,_,_=fetch(path,label+'-apply')
 value,links,text=fetch(value['redirect'],label+'-state')
summary={'method':method,'next_methods':[(p,t) for p,t in links if '/main/method/' in p],'branches':[(p,t) for p,t in links if '/main/proof/recovery_is_executable/' in p and t in ('sorry','SOLVED')],'downloads':[(p,t) for p,t in links if '/download/' in p]}
with (stage/(label+'-summary.json')).open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps({'method':method[:400],'next_methods':[(p,t[:400]) for p,t in summary['next_methods']],'branches':summary['branches']},ensure_ascii=False))
print(text.split('Applicable Proof Methods:',1)[-1][:1800])
