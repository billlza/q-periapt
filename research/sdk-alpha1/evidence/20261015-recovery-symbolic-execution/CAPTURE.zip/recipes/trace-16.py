from pathlib import Path
import contextlib,io,runpy,sys,json
stage=Path(__file__).resolve().parent
source='final-15-state.response'
for index,selector in enumerate(['solve( !Signer(', 'solve( !Wrap(', 'solve( !CanSend(', "Confirmed( ~sid, 'A' )"]):
 label='trace-16-'+str(index)
 sys.argv=[str(stage/'advance-12.py'),source,selector,label]
 with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(stage/'advance-12.py'),run_name='__main__')
 source=label+'-state.response'
 record=json.loads((stage/(label+'-summary.json')).read_text())
 print('Applied: '+record['method'][:200],flush=True)
print(json.dumps({'source':source,'methods':[(p,t[:250]) for p,t in record['next_methods']]},ensure_ascii=False))
