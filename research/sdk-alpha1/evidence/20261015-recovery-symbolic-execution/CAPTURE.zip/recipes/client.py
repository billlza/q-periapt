from pathlib import Path
from urllib.request import urlopen
from html.parser import HTMLParser
import json,re

STAGE=Path(__file__).resolve().parent
BASE=json.loads((STAGE/'SERVER_01.json').read_text())['url']
class Page(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.parts=[];self.current=None
 def handle_starttag(self,tag,attrs):
  if tag=='a':self.current=[dict(attrs).get('href',''),'']
 def handle_endtag(self,tag):
  if tag=='a' and self.current is not None:self.links.append(self.current);self.current=None
 def handle_data(self,data):
  self.parts.append(data)
  if self.current is not None:self.current[1]+=data

def fetch(path,label):
 if not path.startswith('/thy/trace/'):raise ValueError('outside owned theory route')
 with urlopen(BASE+path,timeout=45) as response:raw=response.read(8*1024*1024+1)
 if len(raw)>8*1024*1024:raise ValueError('response exceeds bound')
 with (STAGE/(label+'.response')).open('xb') as out:out.write(raw)
 try:value=json.loads(raw)
 except json.JSONDecodeError:value={'html':raw.decode()}
 with (STAGE/(label+'.request.json')).open('x') as out:json.dump({'path':path,'url':BASE+path},out)
 if not isinstance(value,dict):raise ValueError('unexpected response')
 page=Page();page.feed(value.get('html',''))
 links=[[p,re.sub(r'\s+',' ',t).strip()] for p,t in page.links]
 print(json.dumps({'title':value.get('title'),'other':{k:v for k,v in value.items() if k!='html' and k!='title'},'links':links},ensure_ascii=False))
 text=re.sub(r'\s+',' ',' '.join(page.parts)).strip()
 print(text[:6000])
 return value,links,text
