"""Apply only the observed setup-state proof methods; stop before other choices."""
from pathlib import Path
import contextlib,io,json,re
from client2 import fetch,Page,STAGE
raw=(STAGE/'step-08.response').read_text();page=Page();page.feed(raw);links=page.links
history=[]
for index in range(12):
 candidates=[(p,re.sub(r'\s+',' ',t).strip()) for p,t in links if '/main/method/' in p and any(token in t for token in ['solve( !Wrap(', 'solve( !Pinned(', 'solve( OfferStart(', 'solve( ResponseStart('])]
 if not candidates:break
 path,label=candidates[0];prefix='setup-09-'+str(index)
 with (STAGE/(prefix+'-attempt.json')).open('x') as f:json.dump({'path':path,'method':label},f)
 captured=io.StringIO()
 with contextlib.redirect_stdout(captured):
  value,_,_=fetch(path,prefix+'-apply')
  value,links,text=fetch(value['redirect'],prefix+'-state')
 history.append({'method':label,'redirect':value.get('redirect')})
 print('Applied: '+label,flush=True)
(STAGE/'SETUP_09.json').write_text(json.dumps({'methods':history,'last_state_prefix':prefix+'-state','links':links},indent=2)+'\n')
print(json.dumps({'next_methods':[[p,t] for p,t in links if '/method/' in p or ('/proof/recovery_is_executable' in p and t=='sorry')]},ensure_ascii=False))
print(text.split('Applicable Proof Methods:',1)[-1][:2000])
