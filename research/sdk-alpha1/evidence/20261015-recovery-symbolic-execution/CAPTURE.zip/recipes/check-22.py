"""Bind a proof certificate to the unchanged closed theory and all declarations."""
from pathlib import Path
import hashlib,json,re
stage=Path(__file__).resolve().parent
DECL=re.compile(r'(?ms)^lemma\s+\w+(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
EXPECTED=('generation_secret_origin','recovery_is_executable','clean_reservation_recovers_symbolic_message_secrecy','pre_cut_generation_reservation_remains_exposed','later_storage_access_defeats_fresh_reservations')

def check(baseline,candidate):
 if baseline.split('\nlemma ',1)[0]!=candidate.split('\nlemma ',1)[0]:raise ValueError('theory prefix changed')
 a=DECL.findall(baseline);b=DECL.findall(candidate)
 if len(a)!=5 or a!=b:raise ValueError('lemma declaration, type, annotation or formula changed')
 names=tuple(re.findall(r'(?m)^lemma\s+(\w+)',candidate))
 if names!=EXPECTED:raise ValueError('required lemma inventory changed')
 suffix=candidate.split('\nlemma ',1)[1]
 if re.search(r'(?m)^(rule|restriction|equations|functions|builtins)\b',suffix):raise ValueError('extra theory declarations')
 return True

baseline=(stage/'baseline-21.spthy').read_text();candidate=(stage/'export-19.spthy').read_text();check(baseline,candidate)
mutations={
 'renamed_required_lemma':candidate.replace('lemma recovery_is_executable:', 'lemma renamed_recovery:'),
 'changed_quantifier_kind':candidate.replace('lemma recovery_is_executable:\n  exists-trace','lemma recovery_is_executable:\n  all-traces'),
 'added_reuse_assumption':candidate.replace('[use_induction]', '[use_induction,reuse]'),
 'changed_signature_equation':candidate.replace('verify(sign(x.1, x.2), x.1, pk(x.2)) = true','verify(sign(x.1, x.2), x.1, pk(x.2)) = x.1'),
 'changed_formula':candidate.replace('IdentityLeak( any_session, r )', 'SignerFileCaptured( any_session, r )'),
 'extra_lemma':candidate.replace('\nend','\nlemma extra: "T" by sorry\nend'),
}
rejected=[]
for label,changed in mutations.items():
 if changed==candidate:raise ValueError('mutation did not apply: '+label)
 try:check(baseline,changed)
 except ValueError:rejected.append(label)
 else:raise ValueError('changed semantic input accepted: '+label)
blocks={re.match(r'lemma\s+(\w+)',m.group()).group(1):m for m in DECL.finditer(candidate)}
start=blocks['recovery_is_executable'].end();end=blocks['clean_reservation_recovers_symbolic_message_secrecy'].start()
missing=candidate[:start]+'\nby sorry\n\n'+candidate[end:]
check(baseline,missing)
with (stage/'missing-proof-22.spthy').open('x') as f:f.write(missing)
(stage/'SEMANTICS_22.json').write_text(json.dumps({'completed':True,'identical_rule_equation_restriction_prefix':True,'identical_full_lemma_declarations':5,'rejected_semantic_mutations':rejected,'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'missing_proof_semantically_equal':True,'missing_proof_replay_pending':True},indent=2)+'\n')
print('All five full declarations unchanged; six semantic substitutions rejected; proof-removal control prepared')
