from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime
import continuity_device_retirement as retirement
import continuity_c_consumer as consumer
b=Path(__file__).resolve().parent; root=b.parents[1]
dest=root/'research/sdk-alpha1/evidence/20261008-c-device-retirement';dest.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
files=sorted(set(changed+added));assert all(not x.startswith('research/sdk-alpha1/evidence/20261008-c-device-retirement') for x in files)
source={n:sha(root/n) for n in files}
runs={d.name:json.loads((d/'RESULT.json').read_text()) for d in b.iterdir() if d.is_dir() and (d/'RESULT.json').is_file()}
required=['build-04','retirement-test-build-debug','retirement-test-build-release','runtime-target-debug','runtime-target-release','enrollment-test-build-debug','registration-target-debug','native-regression-debug','unit-02','clippy-03','msrv-02','artifact-tests-03']
assert all(runs[n]['returncode']==0 for n in required)
for n in ['runtime-target-debug','runtime-target-release','registration-target-debug','native-regression-debug']:
 assert runs[n]['binaries_unchanged'] is True
 assert json.loads((b/n/'VERIFIED.json').read_text())['completed'] is True
captures={}
for label in sorted(runs):
 for name in ('RESULT.json','stdout.log','stderr.log','VERIFIED.json'):
  p=b/label/name
  if p.is_file():captures['runs/'+label+'/'+name]=p
for label in ['runtime-target-debug','runtime-target-release','native-regression-debug','registration-target-debug']:
 for p in (b/label/'exported-public').rglob('*'):
  if p.is_file(): captures['public/'+label+'/'+str(p.relative_to(b/label/'exported-public'))]=p
for p in b.glob('*.py'):captures['drivers/'+p.name]=p
for name in ('SOURCE_MAP.json',):captures[name]=b/name
for profile in ('debug-durable','release-durable'):
 captures['binaries/'+profile+'/IDENTITY.json']=b/'artifacts'/profile/'IDENTITY.json'
archive=dest/'CAPTURES.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(captures.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(captures)
 assert all(hashlib.sha256(z.read(n)).hexdigest()==sha(p) for n,p in captures.items())
record=dict(schema_version=1,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=base,source_files=source,development_source_consumption=True,installed_archive_qualified=False,required_passes=required,c_export_count=len(consumer.EXPORTS),runtime={n:runs[n] for n in ['runtime-target-debug','runtime-target-release','registration-target-debug','native-regression-debug']},checks={n:{k:v for k,v in runs[n].items() if k!='inputs'} for n in ['unit-02','clippy-03','msrv-02','artifact-tests-03']},captures=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(captures)),observed_failures=[dict(label='build-01',cause='Existing consumer lock lacked current host-store dependency edges. Offline metadata adjustment preserved external package versions, sources and checksums.'),dict(label='runtime-01',cause='Runner-created parent mode 0755 was refused by the native private-directory contract. A fresh 0700 evidence parent was used; failed directory retained.'),dict(label='registration-regression-01',cause='Actual registration passed but its unchanged reader refused the added enrollment-test census. New retirement workload moved to a standalone target; final registration passed the unchanged 27-filtered gate.')],scope='Eight C cleanup processes after native Rust enrollment/replacement; complete native readback, original host report/ACK, logical journal/signer erasure. Same host/implementation. Native fresh-generation TLS. No Swift/Kotlin retirement, independent implementation, physical erasure, physical-device or complete foreign replacement claim.',publication_performed=False,release_claim_eligible=False)
(dest/'QUALIFICATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record['captures']))
