from pathlib import Path
import subprocess,shutil,json,hashlib,sys
b=Path(__file__).resolve().parent;profile=sys.argv[1];out=b/'artifacts'/profile;out.mkdir(parents=True,exist_ok=False);c=b/'consumer';lib='libq_periapt_continuity_c_consumer.dylib';shutil.copyfile(b/'build'/profile/lib,out/lib)
cmd=['/usr/bin/xcrun','clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread',*(['-O2'] if profile=='release' else ['-O0','-g']),*[str(c/n) for n in ['client.c','recovery_client.c','opening_client.c']],'-I',str(c),'-L',str(out),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(out/'qpc-c-client')]
p=subprocess.run(cmd,capture_output=True);(out/'compile.stdout').write_bytes(p.stdout);(out/'compile.stderr').write_bytes(p.stderr);p.check_returncode();(out/'IDENTITY.json').write_text(json.dumps({'command':cmd,'binaries':{name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in [lib,'qpc-c-client']}},indent=2)+'\n');print(out)
