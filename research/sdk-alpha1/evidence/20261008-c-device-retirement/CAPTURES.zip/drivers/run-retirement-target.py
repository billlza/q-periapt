from pathlib import Path
import json,hashlib,subprocess,os,time,sys
b=Path(__file__).resolve().parent;profile=sys.argv[2];label=sys.argv[3];out=b/sys.argv[1];out.mkdir(mode=0o700);items=[json.loads(x) for x in (b/('retirement-test-build-release/stdout.log' if profile=='release' else 'retirement-test-build-debug/stdout.log')).read_text().splitlines()]
executables=[x['executable'] for x in items if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='retirement' and x.get('executable')];assert len(executables)==1
binary=Path(executables[0]);client=b/'artifacts'/label/'qpc-c-client';lib=b/'artifacts'/label/'libq_periapt_continuity_c_consumer.dylib';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):sha(p) for p in [binary,client,lib]}
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPC','QPERIAPT','DYLD','LD_','PYTHON'))};env['QPERIAPT_C_OWNER_CLIENT']=str(client);env['QPERIAPT_PUBLIC_SERVICE_EVIDENCE']=str(out/'evidence');env['PATH']='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
cmd=[str(binary),'--exact','c_retired_enrollment_preserves_complete_report_and_original_erasure_across_processes','--nocapture'];start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
 p=subprocess.run(cmd,env=env,cwd=b/'consumer',stdout=so,stderr=se,timeout=300)
r={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'binaries_before':before,'binaries_unchanged':all(sha(Path(path))==digest for path,digest in before.items())};(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((out/'stdout.log').read_text()[-3000:]);print((out/'stderr.log').read_text()[-3000:]);assert r['binaries_unchanged'];p.check_returncode()
