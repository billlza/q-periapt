from pathlib import Path
import hashlib,json
from continuity_device_retirement import export_foreign
from continuity_c_enrollment import export as export_registration
b=Path(__file__).resolve().parent; root=b.parents[1]
for profile in ('debug','release'):
 o=b/('runtime-target-'+profile)
 checked=export_foreign((o/'stdout.log').read_bytes(),o/'evidence-device-retirement/public',o/'exported-public',language='C')
 (o/'VERIFIED.json').write_text(json.dumps(checked,indent=2)+'\n')
o=b/'registration-target-debug'
checked=export_registration((o/'stdout.log').read_bytes(),o/'evidence',o/'exported-public')
(o/'VERIFIED.json').write_text(json.dumps(checked,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for base,dest in [(root/'bindings/c/ContinuityPackageConsumer',b/'consumer'),(root/'research/continuity-identity-candidate/tests',b/'consumer/packages/q-periapt-continuity-identity-candidate-0.0.0/tests')]:
 for p in base.rglob('*'):
  if p.is_file() and p.name not in ('Cargo.toml','Cargo.lock'):
   q=dest/p.relative_to(base)
   if q.is_file():
    assert sha(p)==sha(q),(p,q)
    files[str(p.relative_to(root))]={'sha256':sha(p),'copy':str(q.relative_to(b))}
   else: raise AssertionError(('missing consumer copy',str(p)))
(b/'SOURCE_MAP.json').write_text(json.dumps({'mode':'source-based development; generated manifest patches repository SDK and native dependencies, not installed archives','files':files},indent=2)+'\n')
print(json.dumps({'retirement_profiles':['debug','release'],'registration':'debug','source_files':len(files),'release_claim_eligible':False}))
