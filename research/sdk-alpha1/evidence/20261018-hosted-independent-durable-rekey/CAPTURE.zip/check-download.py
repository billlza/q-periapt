from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import subprocess
import zipfile

out = Path(__file__).resolve().parent
head = '0466b276ac4780489cc92d533eac0f02917f071a'
api = lambda path: json.loads(subprocess.check_output(['gh', 'api', 'repos/billlza/q-periapt/' + path], timeout=60))
job = api('actions/jobs/117708434545')
assert job['run_id'] == 39138698714 and job['head_sha'] == head
assert job['status'] == 'completed' and job['conclusion'] == 'success'
metadata = api('actions/runs/39138698714/artifacts')
a = next(x for x in metadata['artifacts'] if x['id'] == 12140683316)
assert a['name'] == 'independent-bootstrap-ubuntu-24.04' and a['workflow_run']['head_sha'] == head and not a['expired']
raw = (out / 'linux-0466.zip').read_bytes()
assert len(raw) == a['size_in_bytes'] == 3826322
assert 'sha256:' + hashlib.sha256(raw).hexdigest() == a['digest'] == 'sha256:08c5824dd079c4b8ef108c3f37473b3435cda619bfb0061b6b5f61927a9b1009'
(out / 'JOB.json').write_text(json.dumps(job, indent=2) + '\n')
(out / 'ARTIFACT.json').write_text(json.dumps(a, indent=2) + '\n')
with zipfile.ZipFile(out / 'linux-0466.zip') as z:
    items = z.infolist()
    assert len({i.filename for i in items}) == len(items) < 2000
    assert sum(i.file_size for i in items) < 32 * 1024**2
    assert z.read('source-head.txt').decode().strip() == head
    assert 'x86_64' in z.read('host.txt').decode()
    assert z.read('rustc.txt').decode().startswith('rustc 1.98.1 ') and 'host: x86_64-unknown-linux-gnu' in z.read('rustc.txt').decode()
    target = out / 'public'
    target.mkdir(exist_ok=False)
    for item in items:
        p = PurePosixPath(item.filename)
        assert not p.is_absolute() and '..' not in p.parts and str(p) == item.filename and '\\' not in item.filename
        assert not item.flag_bits & 1 and not stat.S_ISLNK(item.external_attr >> 16)
        data = z.read(item)
        assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02'))
        if item.filename.endswith(('.stdout', '.stderr')):
            assert not re.search(rb'(?mi)^\s*(error:|warning:)', data), item.filename
        output = target.joinpath(*p.parts)
        output.parent.mkdir(exist_ok=True, parents=True)
        with output.open('xb') as stream:
            stream.write(data)
print(json.dumps({'source': head, 'members': len(items), 'terminal_job': job['conclusion'], 'artifact_sha256': hashlib.sha256(raw).hexdigest()}))
