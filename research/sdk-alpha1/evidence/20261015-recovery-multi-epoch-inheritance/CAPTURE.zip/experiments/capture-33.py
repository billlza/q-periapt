"""Capture the completed inheritance proof, keeping live witness work separate."""
from pathlib import Path
import hashlib
import json
import os
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
certified = json.loads((stage / "CERTIFIED_25.json").read_text())
precompute = json.loads((stage / "PRECOMPUTATION_22.json").read_text())
sdk.require(certified["completed"] and certified["no_search_replay"] and precompute["completed"], "incomplete proof or diagnostic")
labels = ("precompute-19", "inheritance-20", "direct-21", "inheritance-replay-23", "execution-24", "inheritance-replay-27", "original-replay-29")
receipts = {}
for label in labels:
    started = json.loads((stage / (label + "-STARTED.json")).read_text())
    receipts[label] = json.loads((stage / (label + "-TERMINAL.json")).read_text())
    try:
        os.killpg(started["pid"], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError("selected prover group remains live: " + label)
sdk.require(all(receipts[name]["accepted"] for name in ("inheritance-20", "direct-21", "inheritance-replay-27")), "required positive execution changed")
sdk.require(all(receipts[name]["timed_out"] and not receipts[name]["accepted"] for name in ("inheritance-replay-23", "execution-24", "original-replay-29")), "diagnostic outcome changed; review before capture")
sdk.require(certified["certificate_sha256"] == sdk.snapshot(stage / "inheritance-replay-27-proof.spthy").sha256, "accepted certificate changed")
patterns = [
    "precompute-19*", "run-20.py", "inheritance-20*", "direct-21*", "multi-epoch-21.spthy", "parse-21*", "DIRECT_21.json",
    "verify-precompute-22.py", "PRECOMPUTATION_22.json", "inheritance-replay-23*", "execution-24*",
    "certify-25.py", "CERTIFIED_25.json", "*-parse-25*", "inheritance-replay-27*",
    "compose-28.py", "composed-28.spthy", "COMPOSED_28.json", "parse-28*", "original-replay-29*", "capture-33.py",
]
selected = {path for pattern in patterns for path in stage.glob(pattern) if path.is_file()}
sdk.require(selected and not any("execution-31" in path.name for path in selected), "mutable witness work selected")
files = {"experiments/" + path.name: path for path in selected}
prior = root / "research/sdk-alpha1/evidence/20261015-recovery-multi-epoch-model/CAPTURE.zip"
sdk.require(sdk.snapshot(prior).sha256 == "b65c5fade336985d09049adc3b60263a0140431fb26b4e3ba22911d19847031c", "prior record changed")
files["prior/model-CAPTURE.zip"] = prior
files["source/multi-epoch.spthy"] = root / "research/continuity-recovery-symbolic/multi-epoch.spthy"
files["source/annotated-search-input.spthy"] = stage / "multi-epoch-13.spthy"
files["tools/TOOLS_08.json"] = root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json"
public = root / "research/sdk-alpha1/evidence/20261015-recovery-multi-epoch-inheritance"
public.mkdir()
archive = public / "CAPTURE.zip"
digests = {}
total = 0
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(files.items()):
        data = sdk.snapshot(path).data
        total += len(data)
        sdk.require(total <= 16 * 1024**2, "capture exceeds bound")
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(info, data)
        digests[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(set(zipped.namelist()) == set(digests) and len(zipped.namelist()) == len(digests), "archive inventory differs")
    for name, digest in digests.items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, "archive readback differs")
capture_sha = sdk.snapshot(archive).sha256
sdk.write_json(public / "CAPTURE.json", {
    "capture_sha256": capture_sha, "members": digests, "expanded_bytes": total,
    "certified_inheritance": certified, "precomputation": precompute,
    "terminal_attempts": receipts, "all_selected_prover_groups_absent": True,
    "prior_archive_sha256": "b65c5fade336985d09049adc3b60263a0140431fb26b4e3ba22911d19847031c",
    "ongoing_execution_31_not_included": True,
    "private_sdk_device_data_included": False, "release_claim_eligible": False,
})
sdk.write_json(public / "READBACK.json", {
    "completed": True, "capture_sha256": capture_sha, "members": len(digests),
    "expanded_bytes": total, "all_members_rehashed": True,
    "independently_replayed_properties": 1, "multi_epoch_secrecy_proved": False,
    "release_claim_eligible": False,
})
print(json.dumps({"members": len(digests), "expanded_bytes": total,
                  "archive_bytes": archive.stat().st_size, "archive_sha256": capture_sha}))
