"""Bind independent inheritance replay to the full original multi-epoch theory."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only", "--quit-on-warning"],
                       stage / (label + "-parse-25"), root).decode()

def uncomment(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational(text):
    head, tail = text.split("\nlemma ", 1)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", uncomment(tail)), "late operational declaration")
    head = uncomment(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "missing expanded signature")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {"Any"} and result == "Any", "informational type differs")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap", "succ", "scope"}, set(functions)), "informational function inventory differs")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in (set(), {"hashing", "signing", "symmetric-encryption"}), "builtin summary differs")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    head = re.sub(r"\[(?:\+\s*,\s*)?no_precomp\]", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(uncomment(text)))
    sdk.require(len(matches) == 4 and len({match.group(1) for match in matches}) == 4, "query inventory differs")
    return {match.group(1): match.group() for match in matches}

lemma = "reservations_inherit_locally_confirmed_root"
receipt = json.loads((stage / "inheritance-replay-27-TERMINAL.json").read_text())
search = json.loads((stage / "inheritance-20-TERMINAL.json").read_text())
sdk.require(receipt["accepted"] and receipt["returncode"] == 0 and not receipt["timed_out"], "independent replay incomplete")
sdk.require(receipt["required_verified_lemmas"] == [lemma] and not any(arg.startswith("--prove") for arg in receipt["argv"]), "replay scope differs")
sdk.require(receipt["input_sha256"] == search["output_sha256"] == sdk.snapshot(stage / "inheritance-20-proof.spthy").sha256, "replay input differs")
sdk.require(receipt["output_sha256"] == sdk.snapshot(stage / "inheritance-replay-27-proof.spthy").sha256, "replay output differs")
sdk.require({name for name, item in receipt["results"].items() if item["status"] == "verified"} == {lemma}, "verified scope differs")
model_path = root / "research/continuity-recovery-symbolic/multi-epoch.spthy"
sdk.require(sdk.snapshot(model_path).sha256 == "1be3e576722af22586edf62eff1cacb913b981e162f3942e133fac613aaf4977", "canonical model changed")
canonical = parsed("canonical", model_path)
source = parsed("search-input", stage / "multi-epoch-13.spthy")
before = parsed("search-certificate", stage / "inheritance-20-proof.spthy")
after = parsed("replay-certificate", stage / "inheritance-replay-27-proof.spthy")
sdk.require(operational(canonical) == operational(source) == operational(before) == operational(after), "operational model differs after search-annotation erasure")
sdk.require(queries(canonical) == queries(source) == queries(before) == queries(after), "complete query declarations differ")
sdk.require(not re.search(r'\b(?:reuse|sources)\b', "\n".join(value.split(':',1)[0] for value in queries(after).values())), "unexpected reusable premise")

# These mutations must be rejected by complete operational/query identity, not
# accepted based on the one verified theorem name.
controls = {}
for name, mutant in {
    "changed_root_origin_event": before.replace("RootBefore(", "ChangedRootBefore(", 1),
    "new_disclosure_restriction": before.replace("\nlemma ", '\nrestriction NoCut: "All s #i. Cut(s)@i ==> F"\n\nlemma ', 1),
}.items():
    sdk.require(mutant != before and operational(mutant) != operational(before), "operational mutation was not rejected")
    controls[name] = True
changed_query = before.replace("(#ready < #reserved)", "(#ready = #reserved)", 1)
sdk.require(changed_query != before and queries(changed_query) != queries(before), "changed formula was not rejected")
controls["changed_complete_inheritance_formula"] = True
missing_query = declaration.sub(lambda match: "" if match.group(1) == lemma else match.group(), uncomment(before))
try:
    queries(missing_query)
except ValueError as exc:
    sdk.require(str(exc) == "query inventory differs", "unexpected missing-query failure")
    controls["deleted_inheritance_query"] = True
else:
    raise ValueError("missing query was accepted")
sdk.write_json(stage / "CERTIFIED_25.json", {
    "completed": True, "verified_property": lemma, "search_steps": search["results"][lemma]["steps"],
    "independent_replay_steps": receipt["results"][lemma]["steps"], "elapsed_seconds": receipt["elapsed_seconds"],
    "certificate_sha256": receipt["output_sha256"], "search_certificate_sha256": search["output_sha256"],
    "bare_model_sha256": sdk.snapshot(model_path).sha256,
    "all_four_complete_queries_unchanged": True, "operational_model_identical_after_annotation_erasure": True,
    "no_prior_reusable_premises": True, "no_search_replay": True, "identity_controls_rejected": controls,
    "scope": "Each reservation inherits the root and parent of an earlier local Ready event in the unbounded symbolic model.",
    "not_established": ["normal two-round reachability", "delayed-receipt attack witness", "multi-epoch message secrecy", "concrete SDK refinement"],
    "release_claim_eligible": False,
})
print("Independent inheritance replay bound to the original complete theory; four identity controls rejected")
