"""Read the exact terminal diagnostic without interpreting it as a proof."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
receipt = json.loads((stage / "precompute-19-TERMINAL.json").read_text())
sdk.require(receipt["returncode"] == 0 and receipt["precomputation_command_completed"]
            and not receipt["proof_search_requested"] and not receipt["proof_property_accepted"], "diagnostic not complete")
sdk.require("--precompute-only" in receipt["argv"] and not any(arg.startswith("--prove") for arg in receipt["argv"]), "proof was requested")
sdk.require(sdk.snapshot(stage / "multi-epoch-08.spthy").sha256 == receipt["input_sha256"], "input changed")
stdout = (stage / "precompute-19.stdout").read_text()
match = re.fullmatch(r"Multiset rewriting rules and restrictions: (\d+)\nRaw sources: (\d+) cases, (\d+) partial deconstructions left\nRefined sources: (\d+) cases, (\d+) partial deconstructions left\n", stdout)
sdk.require(match is not None, "unexpected precomputation summary")
rules, raw, raw_partial, refined, refined_partial = map(int, match.groups())
stderr = (stage / "precompute-19.stderr").read_text()
sdk.require("[Saturating Sources] Done" in stderr and not re.search(r"(?im)^\s*(warning|error|fatal)\b", stderr), "incomplete or failed diagnostic")
sdk.write_json(stage / "PRECOMPUTATION_22.json", {
    "completed": True, "base_commit": "dffd1d8831ed18a7b0dbd6d219080ca17a6edd5d",
    "input_sha256": receipt["input_sha256"], "elapsed_seconds": receipt["elapsed_seconds"],
    "rules_and_restrictions_count": rules,
    "raw_source_catalog_count": raw, "raw_partial_deconstructions": raw_partial,
    "refined_source_catalog_count": refined, "refined_partial_deconstructions": refined_partial,
    "interpretation": "Precomputation on this exact input can terminate within 300 seconds. It leaves unresolved derivation chains. This does not identify a counterexample or establish any query.",
    "upstream_source_commit": "82780bbaf3328a45f624ddb41e51bf75425f851c",
    "upstream_source_urls": [
        "https://github.com/tamarin-prover/tamarin-prover/blob/82780bbaf3328a45f624ddb41e51bf75425f851c/src/Main/Mode/Batch.hs#L200",
        "https://github.com/tamarin-prover/tamarin-prover/blob/82780bbaf3328a45f624ddb41e51bf75425f851c/lib/theory/src/ClosedTheory.hs#L547",
        "https://github.com/tamarin-prover/tamarin-prover/blob/82780bbaf3328a45f624ddb41e51bf75425f851c/lib/theory/src/Theory/Constraint/Solver/Sources.hs#L355",
    ],
    "counting_note": "The CLI calls them cases; ClosedTheory counts source catalogue entries, whereas each entry may contain multiple branches. The 266 count is unresolved chain constraints, not vulnerabilities.",
    "proof_property_accepted": False, "release_claim_eligible": False,
})
print(json.dumps({"precomputation_completed": True, "seconds": receipt["elapsed_seconds"], "partial_deconstructions": refined_partial}))
