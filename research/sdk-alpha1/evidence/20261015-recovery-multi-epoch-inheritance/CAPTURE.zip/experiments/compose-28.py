"""Replay the found proof while preserving the exact original model encoding."""
from pathlib import Path
import hashlib
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-13.spthy"
certificate = stage / "inheritance-20-proof.spthy"
sdk.require(sdk.snapshot(source).sha256 == "ae7043f56c640c808753ac4d0c4d6adf5af5a171aacc7415cb49c73324837ce9", "original search model changed")
sdk.require(sdk.snapshot(certificate).sha256 == "7375c491710e923ae6d4e156964a4ed1e2087c699efd335c8368ec07d01f30e8", "search certificate changed")
declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
name = "reservations_inherit_locally_confirmed_root"
before = source.read_text()
found = certificate.read_text()
original_queries = list(declaration.finditer(before))
exported_queries = list(declaration.finditer(found))
sdk.require(len(original_queries) == len(exported_queries) == 4 and original_queries[2].group(1) == exported_queries[2].group(1) == name, "query ordering changed")
chunk = found[exported_queries[2].end():exported_queries[3].start()]
starts = list(re.finditer(r"(?m)^induction\n", chunk))
sdk.require(len(starts) == 1, "unexpected proof method start")
body = chunk[starts[0].start():].strip()
sdk.require(body.endswith("qed") and not re.search(r"\b(sorry|admit)\b", body), "incomplete found proof")
position = original_queries[2].end()
after = before[:position] + "\n" + body + "\n" + before[position:]
sdk.require(after.split("\nlemma ",1)[0] == before.split("\nlemma ",1)[0], "operational encoding changed")
sdk.require([match.group() for match in declaration.finditer(after)] == [match.group() for match in original_queries], "query declarations changed")
output = stage / "composed-28.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-28", root)
sdk.write_json(stage / "COMPOSED_28.json", {
    "input_sha256": sdk.snapshot(source).sha256, "search_certificate_sha256": sdk.snapshot(certificate).sha256,
    "output_sha256": sdk.snapshot(output).sha256, "proof_body_sha256": hashlib.sha256(body.encode()).hexdigest(),
    "exact_original_operational_encoding_and_queries_preserved": True,
    "original_builtin_declarations_preserved": True, "proof_body_copied_without_changes": True,
    "no_proof_admitted_until_independent_replay": True,
})
print("Exact found proof inserted into original theory encoding; independent replay still required")
