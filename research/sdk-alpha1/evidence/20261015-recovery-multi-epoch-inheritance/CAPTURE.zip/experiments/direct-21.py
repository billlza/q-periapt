"""Compare direct proof search to induction for the same structural formula."""
from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-13.spthy"
before = source.read_text()
old = "lemma reservations_inherit_locally_confirmed_root [use_induction]:"
new = "lemma reservations_inherit_locally_confirmed_root:"
sdk.require(before.count(old) == 1, "unexpected inheritance declaration")
after = before.replace(old, new)
sdk.require(after.replace(new, old) == before, "other theory content changed")
output = stage / "multi-epoch-21.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-21", root)
sdk.write_json(stage / "DIRECT_21.json", {
    "source_sha256": sdk.snapshot(source).sha256, "output_sha256": sdk.snapshot(output).sha256,
    "only_change": "Remove use_induction proof-method hint from the unchanged inheritance formula.",
    "all_protocol_rules_and_query_formulas_unchanged": True, "proof_claim": False,
})
print("Direct-search method control parsed; original rules and formulas unchanged")
