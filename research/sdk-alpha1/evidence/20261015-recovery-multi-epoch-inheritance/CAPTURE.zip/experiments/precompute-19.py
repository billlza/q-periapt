"""Measure precomputation alone on an unchanged, already parsed theory."""
from pathlib import Path
import json
import os
import signal
import subprocess
import time
from continuity_recovery_proof import prover_environment
from formal_toolchain_contract import verify_installed
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-08.spthy"
snapshot = sdk.snapshot(source)
sdk.require(snapshot.sha256 == "a617cc76cdcb579127b7ef38ded92a2a2112b998bb5683597ea0949467cd7db1", "diagnostic input changed")
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
environment = prover_environment()
environment["PATH"] = os.pathsep.join((str(Path(tools["tamarin"]).parent), str(Path(tools["maude"]).parent), environment["PATH"]))
verify_installed("tamarin", path_environment=environment["PATH"])
argv = [tools["tamarin"], "--with-maude=" + tools["maude"], str(source),
        "--precompute-only", "--derivcheck-timeout=60", "--quit-on-warning",
        "+RTS", "-N1", "-M6G", "-s", "-RTS"]
started = time.monotonic()
timed_out = exceeded = False
with (stage / "precompute-19.stdout").open("xb") as stdout, (stage / "precompute-19.stderr").open("xb") as stderr:
    process = subprocess.Popen(argv, cwd=root, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
    sdk.write_json(stage / "precompute-19-STARTED.json", {"pid": process.pid, "argv": argv,
                   "maximum_seconds": 300, "input_sha256": snapshot.sha256})
    while process.poll() is None:
        timed_out = time.monotonic() - started >= 300
        exceeded = max(stdout.tell(), stderr.tell()) > 4 * 1024**2
        if timed_out or exceeded:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            break
        time.sleep(0.2)
    code = process.wait(timeout=5)
sdk.require(sdk.snapshot(source).sha256 == snapshot.sha256, "diagnostic input changed during execution")
sdk.write_json(stage / "precompute-19-TERMINAL.json", {
    "argv": argv, "returncode": code, "timed_out": timed_out, "output_exceeded": exceeded,
    "elapsed_seconds": time.monotonic() - started, "input_sha256": snapshot.sha256,
    "proof_search_requested": False, "proof_property_accepted": False,
    "precomputation_command_completed": code == 0 and not timed_out and not exceeded,
})
print(json.dumps({"returncode": code, "timed_out": timed_out, "proof_search_requested": False}), flush=True)
