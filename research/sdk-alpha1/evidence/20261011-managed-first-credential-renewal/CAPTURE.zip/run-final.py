from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main
sys.path.insert(0,str(src/"artifact"))
import continuity_c_consumer as c
import continuity_c_authority as authority
base=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=root/"c-consumer-first-credential-05"
run_dir=out/sys.argv[1];run_dir.mkdir()
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build-authority-check"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"),DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
record={"source_sha256":files,"consumer":str(consumer),"candidate_archive":base["candidate_archive"],"runs":[],"profiles":{},"completed":False,"release_claim_eligible":False}
(run_dir/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(argv,label,cwd=consumer,*,runtime=None):
    start=time.monotonic()
    with (run_dir/(label+".stdout")).open("wb") as so,(run_dir/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(argv,cwd=cwd,env=env if runtime is None else runtime,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":argv,"returncode":code,"seconds":time.monotonic()-start})
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; retained stderr")
    return (run_dir/(label+".stdout")).read_bytes()
cc=Path(run(["xcrun","--find","clang"],"clang").decode().strip())
sdk_path=run(["xcrun","--show-sdk-path"],"sdk-path").decode().strip()
cargo=[str(tc/"bin/cargo")]
filename="libq_periapt_continuity_c_consumer.dylib"
import continuity_first_configuration as configuration
runtime={k:v for k,v in env.items() if not k.startswith(("DYLD","LD_"))}
scope=root/sys.argv[1];scope.mkdir(mode=0o700)
mode=sys.argv[2];assert mode in ("credential","policy","ordinary")
for profile in ("debug","release"):
    installed=root/("enrollment-current-installed-"+profile)
    selected=dict(runtime,QPERIAPT_C_OWNER_CLIENT=str(installed/"qpc-c-client"))
    extra=["--release"] if profile=="release" else []
    prepared=json.loads((out/"prepared-05/RESULT.json").read_text());assert prepared["completed"]
    item=prepared["profiles"][profile];helper=Path(item["helper"])
    assert hashlib.sha256(helper.read_bytes()).hexdigest()==item["sha256"]
    installed=Path(item["installed"])
    selected=dict(runtime,QPERIAPT_C_OWNER_CLIENT=str(installed/"qpc-c-client"))
    library=c.sdk.snapshot(installed/filename,maximum=c.MAX_BINARY)
    expected={"debug":"e323b3f77f45a18862bd5bb43b169e9505d9ce8f87604dc66fd5bd13e8f8360d","release":"e22c4b7b1533916800f059032b31f740538d0bd6979d78a17577ede58a1e0b8b"}
    assert library.sha256==expected[profile]
    client=installed/"qpc-first-configuration-client"
    assert run([str(client),"--guard"],"guard-"+profile,runtime=selected)==b"QPC_CONFIGURATION_HEADER_GUARD_PASS\n"
    record["profiles"][profile]=configuration._qualify(scope,run_dir,profile,selected,helper,client,run,receiver=installed/"qpc-c-client",language="C",managed=mode!="ordinary",credential=mode=="credential")
    assert c.sdk.snapshot(installed/filename,maximum=c.MAX_BINARY).sha256==library.sha256
    record["profiles"][profile]["native_library"]={"path":str(installed/filename),"sha256":library.sha256}
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
record["inputs_unchanged"]=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
record["completed"]=record["inputs_unchanged"]
(run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"completed":record["completed"],"profiles":list(record["profiles"]),"inputs_unchanged":record["inputs_unchanged"]}),flush=True)
