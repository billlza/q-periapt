from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path(__file__).resolve().parent
main=base.parent.parent
names=('prepared-05','credential-final-01','policy-final-01','ordinary-final-01','clippy-current-02','clippy-msrv')
runs={name:json.loads((base/name/'RESULT.json').read_text()) for name in names}
assert all(value['completed'] for value in runs.values())
assert 'Ran 72 tests' in (base/'readers-full-git.stderr').read_text() and '\nOK\n' in (base/'readers-full-git.stderr').read_text()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()
assert 'SDK_SOURCE_READINESS_PASS' in (base/'source-gate.stdout').read_text() and head in (base/'source-gate.stdout').read_text()
consumer=Path(runs['prepared-05']['consumer']);product=main/'bindings/c/ContinuityPackageConsumer'
for source in product.rglob('*'):
    if source.is_file() and (source.parent==product and source.suffix in ('.c','.h') or source.is_relative_to(product/'tests') and source.suffix=='.rs'):
        assert source.read_bytes()==(consumer/source.relative_to(product)).read_bytes()
unchanged=subprocess.check_output(['git','diff','--name-only','6d70c61408148e9a0251a1dbc8247b48214d0e29',head,'--','research/continuity-identity-candidate/src','bindings/c/ContinuityPackageConsumer/src'],cwd=main,text=True)
assert not unchanged
profiles={}
for profile in ('debug','release'):
    row=runs['credential-final-01']['profiles'][profile]
    assert row['credential_renewal_qualified'] and row['real_clock_credential_expiry'] and not row['policy_renewal_composition']
    assert len(row['scenarios'])==4
    profiles[profile]={k:row[k] for k in ('scenarios','expiry_observations','binaries','native_library')}
    assert len(runs['policy-final-01']['profiles'][profile]['scenarios'])==4
    assert len(runs['ordinary-final-01']['profiles'][profile]['scenarios'])==6
output=main/'research/sdk-alpha1/evidence/20261011-managed-first-credential-renewal';output.mkdir(parents=True,exist_ok=False)
files=[]
for name in names:
    for path in (base/name).rglob('*'):
        if path.is_file():
            assert not path.is_symlink() and path.suffix not in ('.key','.redb','.dylib','.jar')
            files.append((path,name+'/'+path.relative_to(base/name).as_posix()))
for name in ('first-debug-01','first-debug-02','first-debug-03'):
    for leaf in ('START.json','RESULT.json','credential-first-debug.stdout','credential-first-debug.stderr'):
        files.append((base/name/leaf,name+'/'+leaf))
for name in ('prepare-05.py','run-final.py','run-clippy-05.py','seal-evidence.py','readers-initial.stdout','readers-initial.stderr','readers-full-git.stdout','readers-full-git.stderr','source-gate.stdout','source-gate.stderr','ci.json'):
    files.append((base/name,name))
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for path,name in sorted(files,key=lambda pair:pair[1]):z.write(path,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
checks={'source_commit':head,'completed':True,'release_claim_eligible':False,
'scope':'Installed C first-use managed credential renewal after real-clock expiry, lost applied Commit reply, historical recovery and original-message completion; same-host C peers sharing the native engine.',
'identity':'C clients, headers and Rust harness byte-match the code commit. Native implementation remains unchanged from the immutable 6d70c614 archive; exact Debug/Release native library hashes are recorded. This component composition is not full current-distribution qualification.',
'native_archive':runs['prepared-05']['candidate_archive'],
'validation':{'credential_scenarios':8,'managed_policy_regression_scenarios':8,'ordinary_regression_scenarios':12,'reader_and_inventory_tests':72,'tracked_Rust_sources':515,'strict_Clippy':['1.90.0','1.98.1'],'strict_C_compile':'both profiles, warnings as errors, ABI offset assertions','short_header_guard':'both profiles','source_gate':'passed'},
'profiles':profiles,
'invariants':['Expired original intent still refuses both fresh request and old credential activation (104)','Independent signed grant extends the same key and device under the original account','Missing/closed registry refuses new Commit dispatch (211/202) and failed C outputs remain untouched','Exactly one real Commit is applied; its signed TCP or encrypted TLS reply is lost (218)','Exact historical reconcile and terminal retry work without registry, with two signed exchanges and no new Commit','Historical recovery does not grant activation: missing registry still returns 211','Original signer, journal, session, message and one host business effect survive renewal','Peer independently admits the signed renewal before reopening the retained session'],
'maintainability':'Credential issuance, staging, commit/recovery and public export are separate helper functions. Existing registration, transport, ABI, witness and message engines are reused. No performance improvement is claimed from source length.',
'diagnostics':[{'run':'first-debug-01','cause':'Test client called current enrollment request before every operation, so the expired request blocked renewal before it ran. Kept request validity strict and used existing enrollment status for historical identity.'},{'run':'first-debug-02','cause':'New test decoder incorrectly used policy-status offset 8. Credential operation is at offset 4; C offsetof guards and named-field serialization now exclude padding.'},{'run':'first-debug-03','cause':'Receiver fixture shortcut validated the expired peer before using saved grants. The existing device/peer owner reopen path completes the original session with the admitted renewal.'}],
'parser_fixture':{'file':'artifact/fixtures/first-credential-public-v1.zip','sha256':'b4ff5b8aa153e50278579077556c818c977e0b5c83ab4a6618907d982ce0157d','scope':'Actual prototype-04 public C Debug records; parser mutation controls, not independent signature verification'},
'limits':['Swift/Kotlin first-use credential integration still pending','Same host and shared native engine; no independent endpoint or physical-device claim','No full SDK policy replacement, account replacement or release claim','No throughput, RSS or energy claim'],
'ci':json.loads((base/'ci.json').read_text()),
'capture':{'file':'CAPTURE.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)}}
(output/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'completed':True,'capture':checks['capture']}))
