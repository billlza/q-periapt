from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head='e8a3631661f9dc5015d8178505f927d572a6931f';run=39200435687
metadata=json.loads(subprocess.check_output(['gh','api',f'repos/billlza/q-periapt/actions/runs/{run}'],timeout=60))
assert metadata['head_sha']==head and metadata['status']=='completed' and metadata['conclusion']=='success'
(out/'RUN_TERMINAL.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=json.loads((out/'READBACK_ubuntu-24.04-macos-15.json').read_text());assert len(rows)==2
entries={}
for row in rows:
    assert row['head']==head and row['run']==run and len(row['test_names'])==23 and row['members']==16
    folder=out/row['platform'];data=(folder/'upstream.zip').read_bytes()
    assert len(data)==row['artifact_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==row['artifact_sha256']
    for p in sorted(folder.rglob('*')):
        if p.is_file():entries['local/'+p.relative_to(out).as_posix()]=p.read_bytes()
for p in sorted(out.iterdir()):
    if p.is_file() and p.suffix in {'.json','.py','.stdout','.stderr'}:entries['local/'+p.name]=p.read_bytes()
sources=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
assert len(sources)==26
for name in sources:entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-hosted-reference-reapproval';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for n,v in manifest.items():
        b=z.read(n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
data=archive.read_bytes()
checks={'head':head,'run':run,'source_files':len(sources),'readbacks':rows,'capture':{'bytes':len(data),'members':len(entries),'sha256':hashlib.sha256(data).hexdigest()},'scope':'Terminal hosted debug and release tests, strict Clippy/build and exact artifact/source/lock/architecture/compiler checks. Per profile23 entries include1 dispatcher; frozen producer tests assert14 distinct SIGKILL boundaries. No executable or child private/marker state was exported. Expiry fixtures are synthetic. Not enrollment HTTP/browser, installed-client, deployed HTTPS, full replacement, expired-unissued credential transition or release admission.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text('''# Hosted original-device reapproval checks

[Run 39200435687](https://github.com/billlza/q-periapt/actions/runs/39200435687)
completed successfully at `e8a3631661f9dc5015d8178505f927d572a6931f` on
Linux x86_64 and Apple Silicon. Each host ran both debug and release transaction
tests, formatting, strict all-target Clippy and the release build. No live job
logs were read.

Readback checked the exact source head and lock, Rust 1.98.1, expected target
architecture, all 23 test names and the 20 + 3 result summaries independently
for both profiles. There is one child dispatcher among those entries; frozen
producer tests assert 14 distinct actual SIGKILL boundaries per profile, original
request/key preservation, explicit schema upgrade, same-device reapproval and
actual TCP. Host authentication uses a software authenticator; expiry tests
include explicitly historical fixtures, not real-time expiry measurements.

Both 16-member upstream archives were verified against their GitHub digests.
The capture retains them, terminal metadata, readers and 26 exact app/workflow
source files. SDK dependency source is identified by the Git head. Binary hashes
are producer observations; executable bytes and child private/marker states were
not exported for independent replay. The actual local old/new CLI migration is
recorded separately.

HTTP/browser enrollment, installed independent clients, deployed HTTPS, full
root/device replacement and the expired-unissued-credential transition remain
open. This optional host does not make account registration an SDK requirement
and these checks do not establish full lifecycle or release admission.
''')
print(json.dumps(checks['capture']))
