"""Read terminal CI outputs only; no artifact code or binary is executed."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent.parent
HEAD = "e8a3631661f9dc5015d8178505f927d572a6931f"
RUN = 39200435687

def api(path):
    return subprocess.check_output(["gh", "api", "repos/billlza/q-periapt/" + path], timeout=60)

run = json.loads(api(f"actions/runs/{RUN}"))
assert run["head_sha"] == HEAD
assert run["path"] == ".github/workflows/reference-account.yml"
(OUT / "RUN_OBSERVED.json").write_text(json.dumps(run, indent=2) + "\n")
artifacts = json.loads(api(f"actions/runs/{RUN}/artifacts"))
expected = {
    "source-head.txt", "rustc.txt", "host.txt", "openssl.txt", "fmt.stdout", "fmt.stderr",
    "tests.stdout", "tests.stderr", "clippy.stdout", "clippy.stderr", "build.stdout",
    "build.stderr", "binary.sha256", "Cargo.lock", "release-tests.stdout", "release-tests.stderr",
}
source_paths = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "--", "research/continuity-reference-app/src"], cwd=REPO).decode().splitlines()
source_text = "\n".join(subprocess.check_output(["git", "show", f"{HEAD}:{name}"], cwd=REPO).decode() for name in source_paths if name.endswith(".rs"))
expected_test_names = set(re.findall(r"#\[(?:tokio::)?test\]\s*(?:async )?fn (\w+)", source_text))
assert len(expected_test_names) == 23
lock = subprocess.check_output(["git", "show", f"{HEAD}:research/continuity-reference-app/Cargo.lock"], cwd=REPO)
selected = sys.argv[1:] or ["ubuntu-24.04", "macos-15"]
assert selected and len(selected) == len(set(selected)) and set(selected) <= {"ubuntu-24.04", "macos-15"}
results = []
for os_name, job_id, architecture in [("ubuntu-24.04", 117892098646, "x86_64"), ("macos-15", 117892098527, "aarch64")]:
    if os_name not in selected:
        continue
    job = json.loads(api(f"actions/jobs/{job_id}"))
    assert job["run_id"] == RUN and job["head_sha"] == HEAD
    assert job["status"] == "completed" and job["conclusion"] == "success"
    folder = OUT / os_name
    folder.mkdir(exist_ok=True)
    (folder / "JOB.json").write_text(json.dumps(job, indent=2) + "\n")
    artifact, = [a for a in artifacts["artifacts"] if a["name"] == "reference-account-" + os_name]
    assert artifact["workflow_run"]["head_sha"] == HEAD and not artifact["expired"]
    assert 0 < artifact["size_in_bytes"] < 1024 * 1024
    path = folder / "upstream.zip"
    if not path.exists():
        path.write_bytes(api(f"actions/artifacts/{artifact['id']}/zip"))
    payload = path.read_bytes()
    assert len(payload) == artifact["size_in_bytes"]
    assert "sha256:" + hashlib.sha256(payload).hexdigest() == artifact["digest"]
    (folder / "ARTIFACT.json").write_text(json.dumps(artifact, indent=2) + "\n")
    with zipfile.ZipFile(path) as z:
        assert len(z.infolist()) == len(expected) and set(z.namelist()) == expected
        assert sum(i.file_size for i in z.infolist()) < 1024 * 1024
        for i in z.infolist():
            p = PurePosixPath(i.filename)
            assert not p.is_absolute() and ".." not in p.parts and not stat.S_ISLNK(i.external_attr >> 16)
            assert not i.flag_bits & 1
        assert z.testzip() is None
        data = {n: z.read(n) for n in expected}
    assert data["source-head.txt"].decode().strip() == HEAD
    assert data["Cargo.lock"] == lock
    assert "rustc 1.98.1 " in data["rustc.txt"].decode()
    assert f"host: {architecture}-" in data["rustc.txt"].decode()
    assert data["fmt.stderr"] == data["fmt.stdout"] == b""
    passed = set()
    for stage in ["tests", "release-tests"]:
        stage_passed = set(re.findall(r"^test [\w:]+::(\w+) \.\.\. ok$", data[stage + ".stdout"].decode(), re.M))
        assert stage_passed == expected_test_names
        assert all(f"test result: ok. {count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out" in data[stage + ".stdout"].decode() for count in [20, 3])
        passed = stage_passed
    for stage in ["tests", "release-tests", "clippy", "build"]:
        stderr = data[stage + ".stderr"].decode()
        assert "Finished " in stderr
        assert not re.search(r"^(?:error|warning)(?:\[|:)", stderr, re.M)
    assert "Finished `release` profile" in data["build.stderr"].decode()
    digest = data["binary.sha256"].decode().split()[0]
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    public = folder / "public"
    public.mkdir(exist_ok=True)
    for name, body in data.items():
        (public / name).write_bytes(body)
    results.append({"platform": os_name, "head": HEAD, "run": RUN, "job": job_id, "artifact": artifact["id"], "artifact_sha256": artifact["digest"], "artifact_bytes": len(payload), "members": len(data), "test_names": sorted(passed), "binary_sha256_producer_observation": digest, "scope": "Terminal fmt, debug and release23 test entries each (one child dispatcher), strict all-target clippy and release build. Frozen producer tests check14 distinct SIGKILL boundaries, original SDK signer/request retention and same-key reapproval, schema upgrades and actualTCP. Expiry fixtures use explicit historical inputs, not elapsed-time measurement. Executables and child private/marker states are not exported or replayed. No enrollment HTTP, installed-client, deployed HTTPS or full lifecycle qualification."})
(OUT / ("READBACK_" + "-".join(selected) + ".json")).write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
