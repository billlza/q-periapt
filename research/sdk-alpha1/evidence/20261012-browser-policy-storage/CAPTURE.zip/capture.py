from pathlib import Path
import hashlib,json,zipfile,tempfile
import rust_sdk_profile as sdk
import wasm_sdk_package as package
import wasm_browser_storage as browser
root=Path.cwd();base=root/'target/browser-policy-storage';run=base/'qualification10';build=base/'package9'
report=json.loads((run/'BROWSER_STORAGE.json').read_text());assert report['completed']
receipt=json.loads((build/'INSTALLED_CONSUMER.json').read_text())
package.verify(Path(receipt['installed']),receipt['manifest_sha256'])
assert report['archive_sha256']==receipt['sha256']==sdk.snapshot(build/'q-periapt-sdk-wasm-0.2.0.tgz').sha256
assert report['driver_sha256']==sdk.snapshot(root/'artifact/wasm_browser_storage.py').sha256
for name,marker in [('storage-acceptance.js','BROWSER_POLICY_STORAGE_PASS'),('storage-quota-acceptance.js','BROWSER_POLICY_QUOTA_PASS')]:
 assert browser.result((run/(name+'.stdout')).read_bytes(),marker)==report[name]
for name,digest in receipt['consumer_inputs'].items():
 assert sdk.snapshot(package.CRATE/'tests'/name).sha256==digest
out=root/'research/sdk-alpha1/evidence/20261012-browser-policy-storage';out.mkdir()
for name in ['BROWSER_STORAGE.json','storage-acceptance.js.stdout','storage-quota-acceptance.js.stdout']:
 sdk.copy(run/name,out/name)
files={}
def add(name,path):
 assert path.is_file() and not path.is_symlink();files[name]=path.read_bytes()
for path in build.iterdir():
 if path.is_file() and path.suffix in ('.json','.stdout','.stderr','.tgz'):add('package/'+path.name,path)
for path in run.iterdir():
 if path.is_file() and path.suffix in ('.json','.stdout','.stderr'):add('browser/'+path.name,path)
for path in package.CRATE.rglob('*'):
 if path.is_file():add('source/wasm/'+str(path.relative_to(package.CRATE)),path)
for name in ['artifact/wasm_sdk_package.py','artifact/wasm_browser_storage.py','.github/workflows/ci.yml']:
 add('source/'+name,root/name)
for name in ['chrome-storage1.log','chrome-diagnostic1.log','chrome-storage2.log','chrome-storage3.log',
             'worker-terminal3.log','chrome-quota4.log','chrome-quota5.log','quota-native-only5.log',
             'quota-reopen-red2.log','quota-new-backend7.log','quota-fresh7.log']:
 add('failures/'+name,base/name)
for n in (6,7,8):
 for path in (base/f'qualification{n}').iterdir():
  if path.is_file() and path.suffix in ('.json','.stdout','.stderr'):add(f'failures/qualification{n}/'+path.name,path)
for name in ('storage.js','policy-database.js'):
 add('red-source/'+name,base/'package5/package/web'/name)
add('red-source/INSTALLED_CONSUMER.json',base/'package5/INSTALLED_CONSUMER.json')
add('red-source/package.tgz',base/'package5/q-periapt-sdk-wasm-0.2.0.tgz')
add('capture.py',Path(__file__))
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory() as t,zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items())
 z.extractall(t)
 for name,marker in [('storage-acceptance.js','BROWSER_POLICY_STORAGE_PASS'),('storage-quota-acceptance.js','BROWSER_POLICY_QUOTA_PASS')]:
  assert browser.result((Path(t)/'browser'/(name+'.stdout')).read_bytes(),marker)==report[name]
checks={'completed':True,'scope':'installed browser SDK policy owner; not Continuity journal, root-authority recovery or independent implementation',
'package_sha256':receipt['sha256'],'manifest_sha256':receipt['manifest_sha256'],'Chrome':report['storage-acceptance.js']['browser'],
'Node':receipt['runtime']['version'],'typescript':receipt['typescript'],'real_quota_failures':3,'isolated_quota_partitions':2,
'worker_terminations':2,'window_and_worker':True,'quota_reopen_old_new_observed':True,'archive_members':len(files),
'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_hashes_and_extracted_browser_records_replayed':True,'release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',checks);print(json.dumps(checks,indent=2))
