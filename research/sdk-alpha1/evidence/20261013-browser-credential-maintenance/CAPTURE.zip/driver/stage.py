from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';old=root/'target/continuity-browser-credential-renewal';clone=root/'target/continuity-browser-publication/source'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay-paths',root).decode().splitlines();overlay={}
for name in paths:
 p=root/name;overlay[name]=sdk.snapshot(p).sha256;dest=clone/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'2f46daa0d82fdc4e7905da3895db4c50be46a69d','overlay':overlay,'source':str(clone)})
(stage/'build-package.sh').write_text((old/'build-package.sh').read_text().replace('credential-request-package-01','credential-commit-package-01'))
for name in ['controller.js','server.py']:shutil.copyfile(old/name,stage/name)
(stage/'base-browser.py').write_text((old/'base-browser.py').read_text().replace('continuity-browser-credential-renewal','continuity-browser-credential-commit').replace('credential-request-package-01','credential-commit-package-01'))
worker=(old/'worker.js').read_text();needle="   }else if(data.action==='scalar'){";assert worker.count(needle)==1
worker=worker.replace(needle,(stage/'worker-actions.js.txt').read_text()+needle)
needle=' try {\n  const cfg=';assert worker.count(needle)==1
worker=worker.replace(needle,''' const credentialStatus=async()=>{
  const s=own(await owner.credential_renewal_status()),cp=ownOptional(s.target()),head=ownOptional(s.observed_head());
  const id=s.operation_id(),statement=s.statement();return {phase:s.phase(),operation:id?[...id]:null,statement:statement?[...statement]:null,target:cp?{version:String(cp.version()),digest:[...cp.digest()]}:null,observed:head?{version:String(head.version()),digest:[...head.digest()]}:null,observedAt:s.observed_at()===undefined?null:String(s.observed_at())};
 };
 try {
  const cfg=''' )
needle="    const key=await owner.generate_prekey(";assert worker.count(needle)==1
worker=worker.replace(needle,"""    if(data.inventoryOnly){
     const prekeyStatus=await owner.prekey_status(policy,new Uint8Array(32).fill(55));
     const newKey=await owner.generate_prekey(policy,new Uint8Array(32).fill(56),sdk.QPeriaptContinuityPrekeyKind.OneTimePq,at,at+300n,at);
     value={journal:[...id],prekeyStatus,newPrekey:[...newKey],status:await snapshot()};
    }else{
    const key=await owner.generate_prekey(""")
needle='    value={journal:[...id],prekey:[...key],status:await snapshot(),progress:await rosterProgress()};';assert worker.count(needle)==1
worker=worker.replace(needle,needle+'\n    }')
(stage/'worker.js').write_text(worker)
authority=stage/'authority';(authority/'src').mkdir(parents=True)
for name in ['Cargo.toml','Cargo.lock']:(authority/name).write_text((old/'authority'/name).read_text().replace('q-periapt-browser-credential-authority','q-periapt-browser-credential-commit-authority'))
s=(old/'authority/src/main.rs').read_text();needle='let args=std::env::args().collect::<Vec<_>>();';assert s.count(needle)==1
s=s.replace(needle,needle+'if args.get(1).is_some_and(|v|v=="--witness"){return approve_witness(&args)}')
(authority/'src/main.rs').write_text(s+'\n'+(stage/'witness-approval.rs.txt').read_text())
s=(old/'run.py').read_text().replace('continuity-browser-credential-renewal','continuity-browser-credential-commit').replace('credential-request-package-01','credential-commit-package-01').replace('q-periapt-browser-credential-authority','q-periapt-browser-credential-commit-authority')
start=s.index('allowed=');end=s.index('\n\ndef browser',start)
s=s[:start]+"allowed={'applied','closed','drop-commit','drop-ack','close-after-commit','cancel','unprepared','cancel-unprepared','local','expired-original'}\nsdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0"+s[end:]
start=s.index('   for case in sys.argv[2:]:');end=s.index("  finally:browser(['close'],'close')",start)
body=(stage/'body.py.txt').read_text();needle="     current=success({**args,'action':'activate'});unchanged(original,current);row['current']=current";assert body.count(needle)==2
# Replace only the required-witness branch after ACK cleanup.
pos=body.rindex(needle);body=body[:pos]+"""     current=success({**args,'action':'activate','inventoryOnly':case=='expired-original'});row['current']=current
     if case=='expired-original':sdk.require(current['journal']==original['journal'] and current['prekeyStatus']==2 and current['newPrekey'],'expired predecessor lost journal/inventory or renewed authority')
     else:unchanged(original,current)"""+body[pos+len(needle):]
s=s[:start]+body+s[end:]
s=s.replace('installed browser public credential renewal requests and independently held native issuer pins; same Rust engine and loopback, not renewal commit or independent protocol implementation','installed browser original credential renewal staging, witness approval, commit/close/recovery and current activation; same native Rust engine and loopback, not independent implementation or PCS')
(stage/'run.py').write_text(s)
