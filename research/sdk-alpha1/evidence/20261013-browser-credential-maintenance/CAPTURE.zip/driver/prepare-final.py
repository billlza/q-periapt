from pathlib import Path
import json,re,shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';clone=root/'target/continuity-browser-publication/source'
for name in ['run01','run02']:sdk.require(json.loads((stage/name/'RESULT.json').read_text())['completed'],'initial producer incomplete')
p=root/'crates/q-periapt-sdk-wasm/tests/browser-suite.mjs';source=p.read_text();(stage/'browser-suite-v1.mjs').write_text(source)
literal=re.search(r'=== (\[.*\])\.join',source).group(1);expected=json.loads(literal.replace("'",'"'));sdk.require(expected!=sorted(expected) and len(expected)==len(set(expected)),'not expected list ordering defect')
p.write_text(source.replace('=== '+literal,'=== '+json.dumps(sorted(expected),separators=(',',':'))))
p=root/'research/continuity-identity-candidate/src/browser/credentials.rs';source=p.read_text();needle='''        let result = async {
            op.enrollment()?
                .reconcile_expired_credential_renewal''';sdk.require(source.count(needle)==1,'expiry method locator')
source=source.replace(needle,'''        let result = async {
            if policy.historical().anchor_requirement().binding().is_some() {
                return Err(DurableError::AnchorRequired);
            }
            op.enrollment()?
                .reconcile_expired_credential_renewal''');p.write_text(source)
sdk.command(['sh','target/continuity-browser-credential-renewal/cargo.sh','fmt','--manifest-path','research/continuity-identity-candidate/Cargo.toml'],stage/'format-final-candidate',root)
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay02-paths',root).decode().splitlines();overlay={}
for name in paths:
 p=root/name;overlay[name]=sdk.snapshot(p).sha256;dest=clone/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay02-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY_02.json',{'base_commit':'2f46daa0d82fdc4e7905da3895db4c50be46a69d','overlay':overlay,'source':str(clone)})
(stage/'build-package-02.sh').write_text((stage/'build-package.sh').read_text().replace('credential-commit-package-01','credential-commit-package-02'))
(stage/'base-browser-02.py').write_text((stage/'base-browser.py').read_text().replace('credential-commit-package-01','credential-commit-package-02'))
s=(stage/'run.py').read_text().replace('credential-commit-package-01','credential-commit-package-02')
needle="    if case=='local':";sdk.require(s.count(needle)==1,'local branch locator')
s=s.replace(needle,"""    if profile=='required':
     before=len(records.get(key,[]));row['no_local_expiry_fallback']=rejected({**args,'action':'expire-credential'},'AnchorRequired');sdk.require(len(records.get(key,[]))==before,'local expiry path contacted witness')
    if case=='local':""")
(stage/'run-final.py').write_text(s)
