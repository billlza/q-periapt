from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
stage=Path.cwd()/'target/continuity-browser-credential-commit';path=stage/'codeql-rust-job.raw.log'
sha=hashlib.sha256();size=0;count=0;started=set();completed={};errors=[];evictions=0;tail=[]
with path.open('rb') as f:
 for raw in f:
  sha.update(raw);size+=len(raw);count+=1;line=raw.decode('utf-8',errors='replace').rstrip()
  match=re.search(r'Starting evaluation of (codeql/rust-queries/\S+)\.ql\.',line)
  if match:started.add(match[1]+'.bqrs')
  match=re.search(r'Evaluation done; writing results to (codeql/rust-queries/\S+\.bqrs)',line)
  if match:completed.setdefault(match[1].rstrip('.'),line)
  if 'evict' in line.lower():evictions+=1
  if ('##[error]' in line or 'timed out after 300' in line) and len(errors)<20:errors.append(line)
  if 'TaintReach' in line:
   tail.append(line);tail=tail[-4:]
sdk.require(len(started)==39 and len(completed)==38,'unexpected query inventory')
remaining=sorted(started-set(completed));sdk.require(remaining==['codeql/rust-queries/queries/summary/SummaryStats.bqrs'],'different unresolved query')
value={'run':38367781556,'job':115198746245,'download_completed':True,'raw':str(path),'sha256':sha.hexdigest(),'bytes':size,'lines':count,'started':len(started),'completed':len(completed),'remaining':remaining,'completion_lines':list(completed.values()),'errors':errors,'eviction_mentions':evictions,'last_taint_reach_lines':tail,'claim':'Second observed full SummaryStats timeout; no completed full analysis, resource remedy, product runtime performance or release claim.'}
sdk.write_json(stage/'CODEQL_OBSERVATION.json',value)
print(json.dumps({k:value[k] for k in ['bytes','started','completed','remaining','eviction_mentions']}))
