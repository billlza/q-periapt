from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';package=root/'target/continuity-browser-publication/source/target/credential-commit-package-02'
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/'local-expiry-web';shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
authority=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority';roster=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-credential-expiry-authority'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
state={'completed':False,'scope':'installed browser original credential renewal staging, witness approval, commit/close/recovery and current activation; same native Rust engine and loopback, not independent implementation or PCS','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,roster]},'cases':[],'observations':[]}
allowed={'local-expired'}
sdk.require(sys.argv[2:]==['local-expired'],'exact local-expired scenario required');sequence=0

def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args['action'],'observations':value['result'].get('observations',[])});return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value

def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

def unchanged(original,current):sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'roster changed original identity/key')
try:
 with serving(web,out,private,authority) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(authority,['prepare',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    cfg['until']=int(time.time())+90;cfg['renewal_until']=cfg['until']+30;cfg['description'][64:72]=list(cfg['until'].to_bytes(8,'big'));(directory/'PUBLIC.json').write_text(json.dumps(cfg))
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'local'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});success({**args,'action':'prepare'});original=success({**args,'action':'activate'});row['original']=original
    args['operationId']=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation']
    request=success({**args,'action':'credential-request','historicalOnly':True});request_file=out/(case+'-request.json');sdk.write_json(request_file,request['requestValue'])
    renewal=inputs/(key+'-renewal.json');native(roster,[directory,grant,request_file,renewal,'local'],case+'-issue-renewal');renewal_data=json.loads(renewal.read_text());args['statement']=renewal_data['statement']
    pending=success({**args,'action':'stage-credential'});sdk.require(pending['phase']==2,'not pending');row['pending']=pending
    row['real_expiry']={'target_until':cfg['renewal_until'],'staged_at':int(time.time())};sdk.require(time.time()<cfg['renewal_until'],'target expired before staging')
    print(json.dumps({'case':case,'waiting_until':cfg['renewal_until']+1}),flush=True)
    while time.time()<=cfg['renewal_until']:time.sleep(min(10,max(0.1,cfg['renewal_until']+1-time.time())))
    row['activation_refused']=rejected({**args,'action':'activate'},'Validity')
    final=success({**args,'action':'expire-credential'});row['final']=final
    sdk.require(final['phase']==3 and final['operation']==args['operationId'] and final['statement']==args['statement'] and final['observed']['version']=='1' and int(final['observedAt'])>cfg['renewal_until'],'wrong ExpiredUncommitted scope or history')
    sdk.require(success({**args,'action':'expire-credential'})==final,'exact expiry retry changed original outcome')
    row['old_identity_still_expired']=rejected({**args,'action':'activate'},'Validity')
    new_id=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation'];actual=success({**args,'action':'credential-request','historicalOnly':True,'operationId':new_id})['requestValue'];row['actual_predecessor']=actual
    sdk.require(actual['previous_credential']==grant_data['certificate'] and actual['previous_roster']==grant_data['roster'] and actual['journal']==original['journal'],'expiry fabricated target adoption or changed journal')
    sdk.require(not records.get(key,[]) and not failures,'local recovery used witness or fixture failed');print(json.dumps({'case':case,'passed':True}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
