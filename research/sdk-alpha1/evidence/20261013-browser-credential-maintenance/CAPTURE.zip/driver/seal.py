from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';package=root/'target/continuity-browser-publication/source/target/credential-commit-package-02'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=load(stage/'run03/RESULT.json');expiry=load(stage/'run04/RESULT.json');assert report['completed'] and expiry['completed']
cases={c['case']:c for c in report['cases']};assert set(cases)=={'local','applied','closed','drop-commit','drop-ack','close-after-commit','cancel','unprepared','cancel-unprepared','expired-original'} and len(cases)==len(report['cases'])
def digest(domain,data):return hashlib.sha3_256(len(domain).to_bytes(8,'big')+domain+len(data).to_bytes(8,'big')+data).digest()
for name,c in cases.items():
 assert c['pending']['phase']==2
 assert c['final']['phase']==(5 if name in ['closed','cancel-unprepared'] else 4)
 assert c['actual_predecessor']['journal']==c['original']['journal']
 if name!='local':assert c['no_local_expiry_fallback']['code']=='AnchorRequired' and c['no_local_expiry_fallback']['ownerClosed']
 if name in ['drop-commit','drop-ack','close-after-commit','cancel']:
  assert c['after_loss']['proposal']==c['prepared']['proposal']
  assert c['after_loss']['status']['phase']==(4 if name=='drop-ack' else 2)
  assert c['rejection']['code']==('Cancelled' if name=='cancel' else 'WitnessTransport')
  proposal=bytes(c['prepared']['proposal']);binding=digest(b'Q-PERIAPT-ANCHOR-CREDENTIAL-PROPOSAL/v1',proposal)
  assert binding==bytes(c['prepared']['binding'])
  command=digest(b'Q-PERIAPT-CONTINUITY-ANCHOR-COMMAND/v1',proposal[8:136]+bytes([8 if name=='drop-ack' else 5])+binding+bytes(64))
  fault=[r for r in c['witness_records'] if r['trigger']];assert len(fault)==1 and bytes(fault[0]['command'])==command and fault[0]['changed']==(name!='drop-ack')
 if name=='cancel':assert c['rejection']['cancellationRequested']
 if name=='unprepared':assert c['unprepared']['phase']==2
 if name=='expired-original':
  assert c['real_expiry']['activated_at']<c['real_expiry']['valid_until']<c['real_expiry']['request_at']
  assert c['expired_activation']['code']=='Validity' and c['current']['prekeyStatus']==2 and c['current']['newPrekey']
c=expiry['cases'][0];assert len(expiry['cases'])==1 and c['case']=='local-expired' and c['final']['phase']==3 and c['final']['observed']['version']=='1'
assert c['real_expiry']['staged_at']<c['real_expiry']['target_until']<int(c['final']['observedAt']) and c['activation_refused']['code']==c['old_identity_still_expired']['code']=='Validity'
assert '101 passed; 0 failed' in (stage/'witness-renewal-tests.log').read_text()
assert '1 passed; 0 failed' in (stage/'cancellation-inventory-test.log').read_text()
assert 'Ran 53 tests' in (stage/'controls-02.log').read_text() and (stage/'controls-02.log').read_text().rstrip().endswith('OK')
for name in ['native-clippy.log','wasm-clippy-02.log','wasm-msrv-02.log']:
 s=(stage/name).read_text();assert 'Finished' in s and 'error:' not in s and 'warning:' not in s
assert not (stage/'format-final.log').read_text()
base=load(stage/'base10-02/RESULT.json');assert base['completed'] and len(base['report']['cases'])==10
assert not load(stage/'base10/RESULT.json')['completed'] and load(stage/'EXPORT_ORDER_DIAGNOSIS.json')['same_exact_export_set']
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz') and receipt['source_bound'] and receipt['sources_unchanged']
source=load(stage/'SOURCE_OVERLAY_02.json')
for n,d in source['overlay'].items():assert sha(root/n)==d,n
for result in [report,expiry]:
 for n,d in result['native'].items():assert sha(Path(n))==d,n
members={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),p
 members[n]=p
excluded={'codeql-rust-job.raw.log','seal.log','finalize.log','HANDOFF.json'}
for p in sorted(stage.iterdir()):
 if p.is_file() and p.name not in excluded and p.suffix in ['.py','.js','.mjs','.json','.log','.txt','.sh']:add(p,'driver/'+p.name)
for folder in ['authority','expiry-authority']:
 for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/folder/name,folder+'/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','authority/witness.rs')
for directory in ['run01','run02','run03','run04','base10','base10-02']:
 folder=stage/directory;add(folder/'RESULT.json',directory+'/RESULT.json')
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.name!='RESULT.json':add(p,directory+'/'+p.name)
 for part in ['logs','captures','witness']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,directory+'/'+p.relative_to(folder).as_posix())
for name in ['01','02']:
 p=root/f'target/continuity-browser-publication/source/target/credential-commit-package-{name}'
 for filename in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(p/filename,'package-'+name+'/'+filename)
 web=Path(load(p/'consumer-location.json')['path'])
 for f in sorted((web/'inputs').glob('run0[123]-*')):add(f,'public-inputs-'+name+'/'+f.name)
for p in sorted((stage/'local-expiry-web/inputs').glob('run04-*')):add(p,'public-inputs-local-expiry/'+p.name)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-credential-maintenance';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes']
checks={'completed':True,'release_claim_eligible':False,'source':source,'case_count':11,'cases':sorted(cases)+['local-expired'],'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'validation':{'native_witness_renewal_cases':101,'native_cancellation_inventory_cases':1,'artifact_controls':53,'installed_base_browser_modes':10,'native_clippy':'all targets -D warnings passed','wasm_clippy':'-D warnings passed','wasm_msrv':'1.90.0 passed','format':'passed','browser':base['report']['browser']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'ci':{'run':38367781556,'rust_job':115198746245,'conclusion':'failure','unfinished_query':'SummaryStats','quality_gate_reached':False},'scope':'Installed browser original same-key credential maintenance, required signed witness and local expiry. Original journal/prekey and actual credential predecessor inspected. Native issuer/witness share Rust implementation and loopback. Original established-session traffic across G, actual browser process-kill cuts, independent implementation, device/performance/PCS and full release remain separate qualification.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Installed browser original credential maintenance

Browser G maintenance now preserves the original enrollment owner through staging, exact preparation, independent witness approval, explicit Commit/Close, original-operation recovery, durable terminal retention, ACK cleanup and separate current activation. Journal access uses retained platform Storage leases rather than reopening browser logical paths as native files. Private database/signing owners are not exported. The original credential/roster/policy and operation checks remain in the shared engine.

Eleven fresh installed Chrome Worker cohorts cover local activation, witnessed commit and close, lost Commit and ACK replies, Close after an already applied Commit, cancellation of a held post-commit reply, an unprepared witness slot, target-free cancellation, actual old-credential expiry followed by renewal, and actual uncommitted local-target expiry. Exact retries keep the sealed proposal and operation. ACK loss retains Committed while original cleanup is pending; successful reconciliation removes only that original intent. Unavailable stays Pending. Close after Commit remains Committed. Every required-witness case explicitly rejects the local expiry path with AnchorRequired before witness dispatch.

Successful activation preserves the original journal and existing prekey; after actual old-credential expiry the original inventory remains Available and renewed authority creates a fresh prekey. A fresh issuer request then reports the actual successor credential, or the unchanged predecessor after Close. The local-expiry cohort stages while its target is live, waits for real wall-clock expiry, observes activation refused, retains ExpiredUncommitted against the original head, replays the exact outcome, refuses activation of the expired old identity and prepares fresh issuer metadata from the original predecessor. Historical results never confer current traffic authority.

The first package passed ten maintenance cohorts, but its base export-list assertion was unsorted after new exports were added. An independent comparison proved identical actual/expected export sets. The exact allowlist was sorted without changing its members. The final package additionally guards the local expiry entry point against required-witness policies; all ten maintenance cohorts were rerun and the separate local-expiry cohort was added. Ten window/worker base modes, 53 package/inventory controls, strict native/WASM Clippy, WASM Rust1.90 and formatting passed. Shared engine validation includes101 witness/renewal regressions with actual process and sync-failure cuts, plus the targeted target-free cancellation inventory regression. Initial compile errors and a zero-selected-test filter are retained and not counted as passes.

The separately downloaded current Rust CodeQL log contains39 query starts and38 completions. Full SummaryStats remained unfinished at the300-minute timeout. The raw583MB log remains task-local; CODEQL_OBSERVATION.json retains its hash, completions and diagnostic excerpts. The first gh download refused terminal escape sequences; the explicit file-only retry completed. No query, security model, quality gate or timeout was weakened, and the analysis failure remains open.

The archive binds public inputs, original outcomes, witness traces, package/source manifests, native issuer source and failed attempts. Private keys, journal databases and browser profiles are excluded. The local-expiry server uses a byte-checked copy of the installed static consumer to keep concurrently live fixtures immutable. This is same-engine loopback qualification. Existing-session traffic across G and browser process-kill recovery still need complementary installed tests. Same-key extension is not identity-key replacement, PCS, independent implementation or full-release qualification.
''')
print(json.dumps(checks['capture']))
