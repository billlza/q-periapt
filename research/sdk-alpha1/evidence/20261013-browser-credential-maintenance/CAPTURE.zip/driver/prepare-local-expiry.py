from pathlib import Path
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';dest=stage/'expiry-authority';(dest/'src').mkdir(parents=True)
for name in ['Cargo.toml','Cargo.lock']:(dest/name).write_text((stage/'authority'/name).read_text().replace('q-periapt-browser-credential-commit-authority','q-periapt-browser-credential-expiry-authority'))
s=(stage/'authority/src/main.rs').read_text();needle='let until=number(&cfg,"until")?.checked_add(600).ok_or("validity overflow")?;';assert s.count(needle)==1
s=s.replace(needle,'let until=match cfg.get("renewal_until"){Some(v)=>v.as_u64().ok_or("renewal_until must be unsigned integer")?,None=>number(&cfg,"until")?.checked_add(600).ok_or("validity overflow")?};')
(dest/'src/main.rs').write_text(s)
s=(stage/'run-final.py').read_text().replace('q-periapt-browser-credential-commit-authority','q-periapt-browser-credential-expiry-authority')
start=s.index('allowed=');end=s.index('\n\ndef browser',start)
s=s[:start]+"allowed={'local-expired'}\nsdk.require(sys.argv[2:]==['local-expired'],'exact local-expired scenario required');sequence=0"+s[end:]
start=s.index('   for case in sys.argv[2:]:');end=s.index("  finally:browser(['close'],'close')",start)
s=s[:start]+(stage/'local-expiry-body.py.txt').read_text()+s[end:];(stage/'run-local-expiry.py').write_text(s)
