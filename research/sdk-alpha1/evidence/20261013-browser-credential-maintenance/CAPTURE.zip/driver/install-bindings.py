from pathlib import Path
import shutil
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit'
for source,target in [
 ('browser.rs.txt','research/continuity-identity-candidate/src/browser/credentials.rs'),
 ('wasm.rs.txt','crates/q-periapt-sdk-wasm/src/continuity/credentials.rs'),
 ('types.rs.txt','crates/q-periapt-sdk-wasm/src/continuity/credentials/types.rs'),
]:
 p=root/target;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();shutil.copyfile(stage/source,p)
for path in ['research/continuity-identity-candidate/src/browser.rs','crates/q-periapt-sdk-wasm/src/continuity.rs']:
 p=root/path;s=p.read_text();assert s.count('mod credential_requests;')==1;p.write_text(s.replace('mod credential_requests;','mod credential_requests;\nmod credentials;'))
p=root/'research/continuity-identity-candidate/src/enrollment.rs';s=p.read_text();needle='impl EnrolledDevice {\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''    /// Historical original renewal outcome; current service admission is separate.
    pub fn credential_renewal_status(&mut self) -> Result<CredentialRenewalStatus, DurableError> {
        self.active.as_mut().ok_or(DurableError::Closed)?.enrollment.credential_renewal_status()
    }
''');p.write_text(s)
names=['QPeriaptContinuityCredentialGrant','QPeriaptContinuityCredentialProposal','QPeriaptContinuityCredentialCancellation','QPeriaptContinuityCredentialPhase','QPeriaptContinuityCredentialStatus']
for suffix in ['js','d.ts']:
 p=root/f'crates/q-periapt-sdk-wasm/package/web/index.{suffix}';s=p.read_text();s+='\nexport { '+', '.join(names)+" } from './q_periapt_sdk_wasm.js';\n";p.write_text(s)
p=root/'crates/q-periapt-sdk-wasm/tests/browser-suite.mjs';s=p.read_text();needle='"QPeriaptContinuityCredentialRequest"'
if needle not in s:needle="'QPeriaptContinuityCredentialRequest'"
assert s.count(needle)==1;s=s.replace(needle,needle+', '+', '.join(repr(n) for n in names));p.write_text(s)
for path in ['ARTIFACT.md','artifact/codeql_rust_quality.py']:
 p=root/path;s=p.read_text();assert '619' in s;p.write_text(s.replace('619','623'))
p=root/'artifact/test_codeql_rust_quality.py';s=p.read_text();needle='            "crates/q-periapt-sdk-wasm/src/continuity/credential_requests.rs",';assert s.count(needle)==1
s=s.replace(needle,needle+''.join('\n            "'+n+'",' for n in [
 'research/continuity-identity-candidate/src/enrollment/renewal/storage.rs',
 'research/continuity-identity-candidate/src/browser/credentials.rs',
 'crates/q-periapt-sdk-wasm/src/continuity/credentials.rs',
 'crates/q-periapt-sdk-wasm/src/continuity/credentials/types.rs',
]));p.write_text(s)
