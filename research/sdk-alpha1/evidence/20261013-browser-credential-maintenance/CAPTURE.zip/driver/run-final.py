from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';package=root/'target/continuity-browser-publication/source/target/credential-commit-package-02'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
authority=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority';roster=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-credential-commit-authority'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'installed browser original credential renewal staging, witness approval, commit/close/recovery and current activation; same native Rust engine and loopback, not independent implementation or PCS','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,roster]},'cases':[],'observations':[]}
allowed={'applied','closed','drop-commit','drop-ack','close-after-commit','cancel','unprepared','cancel-unprepared','local','expired-original'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0

def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args['action'],'observations':value['result'].get('observations',[])});return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value

def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

def unchanged(original,current):sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'roster changed original identity/key')
try:
 with serving(web,out,private,authority) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    profile='local' if case=='local' else 'required'
    native(authority,['prepare',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    if case=='expired-original':
     cfg['until']=int(time.time())+90;cfg['description'][64:72]=list(cfg['until'].to_bytes(8,'big'));(directory/'PUBLIC.json').write_text(json.dumps(cfg))
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':profile}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'})
    if profile=='required':native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    args['operationId']=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation']
    if case=='expired-original':
     row['real_expiry']={'valid_until':cfg['until'],'activated_at':int(time.time())};sdk.require(time.time()<cfg['until'],'expired baseline')
     print(json.dumps({'case':case,'waiting_until':cfg['until']+1}),flush=True)
     while time.time()<=cfg['until']:time.sleep(min(10,max(0.1,cfg['until']+1-time.time())))
     row['expired_activation']=rejected({**args,'action':'activate'},'Validity');row['real_expiry']['request_at']=int(time.time())
    request=success({**args,'action':'credential-request','historicalOnly':True});row['request']=request
    request_file=out/(case+'-request.json');sdk.write_json(request_file,request['requestValue'])
    renewal=inputs/(key+'-renewal.json');native(roster,[directory,grant,request_file,renewal,profile],case+'-issue-renewal');renewal_data=json.loads(renewal.read_text());args['statement']=renewal_data['statement']
    pending=success({**args,'action':'stage-credential'});sdk.require(pending['phase']==2 and pending['operation']==args['operationId'],'original pending scope');row['pending']=pending
    sdk.require(success({**args,'action':'stage-credential'})==pending,'staging retry changed original')
    if profile=='required':
     before=len(records.get(key,[]));row['no_local_expiry_fallback']=rejected({**args,'action':'expire-credential'},'AnchorRequired');sdk.require(len(records.get(key,[]))==before,'local expiry path contacted witness')
    if case=='local':
     current=success({**args,'action':'activate'});unchanged(original,current);row['current']=current
     final=success({**args,'action':'credential-status','historicalOnly':True});sdk.require(final['phase']==4,'local renewal not committed');row['final']=final
    elif case=='cancel-unprepared':
     cancel=success({**args,'action':'prepare-cancellation','historicalOnly':True});row['cancellation']=cancel
     sdk.require(success({**args,'action':'prepare-cancellation','historicalOnly':True})==cancel,'cancellation changed bytes')
     wire=out/(case+'-cancellation.bin');wire.write_bytes(bytes(cancel['cancellation']));native(roster,['--witness',directory,renewal,wire,'cancel'],case+'-approve-cancellation')
     final=success({**args,'action':'reconcile-credential','historicalOnly':True});sdk.require(final['phase']==5,'unprepared target not Closed');row['final']=final
     sdk.require(success({**args,'action':'reconcile-credential','historicalOnly':True})==final,'closed history lost')
     unchanged(original,success({**args,'action':'activate'}))
    else:
     created=success({**args,'action':'prepare-credential'});row['prepared']=created;args['credentialProposal']=created['proposal']
     sdk.require(success({**args,'action':'prepare-credential'})==created,'preparation resealed target')
     sdk.require(success({**args,'action':'recover-credential','historicalOnly':True})['proposal']==created['proposal'],'preparation recovery changed bytes')
     if case=='unprepared':
      unresolved=success({**args,'action':'commit-credential'});sdk.require(unresolved['phase']==2,'Unavailable claimed a terminal');row['unprepared']=unresolved
     wire=out/(case+'-proposal.bin');wire.write_bytes(bytes(created['proposal']));native(roster,['--witness',directory,renewal,wire,'prepare'],case+'-approve-witness')
     if case in ['drop-commit','drop-ack','close-after-commit','cancel']:
      mode={'drop-commit':'drop-after-advance','drop-ack':'drop-ack','close-after-commit':'drop-after-advance','cancel':'hold-after-advance'}[case]
      row['rejection']=rejected({**args,'action':'commit-credential','mode':mode,'cancelOnAdvance':case=='cancel'},'Cancelled' if case=='cancel' else 'WitnessTransport')
      if case=='cancel':sdk.require(row['rejection']['cancellationRequested'],'cancel not actually requested')
      recovered=success({**args,'action':'recover-credential','historicalOnly':True});row['after_loss']=recovered
      sdk.require(recovered['proposal']==created['proposal'] and recovered['status']['phase']==(4 if case=='drop-ack' else 2),'lost original proposal/terminal')
      final=success({**args,'action':'close-credential' if case=='close-after-commit' else 'reconcile-credential','historicalOnly':True})
     else:final=success({**args,'action':'close-credential','historicalOnly':True} if case=='closed' else {**args,'action':'commit-credential'})
     sdk.require(final['phase']==(5 if case=='closed' else 4),'wrong final outcome');row['final']=final
     sdk.require(success({**args,'action':'reconcile-credential','historicalOnly':True})==final,'original terminal changed')
     retired=success({**args,'action':'recover-credential','historicalOnly':True});sdk.require(retired['proposal'] is None and retired['status']==final,'original ACK cleanup incomplete')
     current=success({**args,'action':'activate','inventoryOnly':case=='expired-original'});row['current']=current
     if case=='expired-original':sdk.require(current['journal']==original['journal'] and current['prekeyStatus']==2 and current['newPrekey'],'expired predecessor lost journal/inventory or renewed authority')
     else:unchanged(original,current)
    new_id=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation']
    actual=success({**args,'operationId':new_id,'action':'credential-request','historicalOnly':True})['requestValue'];row['actual_predecessor']=actual
    expected=grant_data if case in ['closed','cancel-unprepared'] else renewal_data
    sdk.require(actual['previous_credential']==expected['certificate'] and actual['previous_roster']==expected['roster'] and actual['original_credential']==grant_data['certificate'] and actual['journal']==original['journal'],'wrong actual predecessor after original G outcome')
    row['witness_records']=records.get(key,[]);sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
