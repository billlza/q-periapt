from pathlib import Path
import contextlib,json,os,subprocess,sys,uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-commit';package=root/'target/continuity-browser-publication/source/target/credential-commit-package-02';consumer=Path(json.loads((package/'consumer-location.json').read_text())['path'])
out=stage/sys.argv[1];out.mkdir();session='qpc-product-base-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node');cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
serverout=(out/'server.stdout').open('xb');servererr=(out/'server.stderr').open('xb')
server=subprocess.Popen([str(node),str(consumer/'serve.cjs')],stdout=serverout,stderr=servererr,stdin=subprocess.DEVNULL,cwd=consumer)
result={'completed':False}
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=160,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
 sdk.write_json(out/(label+'.json'),{'returncode':r.returncode,'args':args})
 return r
try:
 import time
 deadline=time.monotonic()+10
 while not (out/'server.stdout').stat().st_size:
  sdk.require(server.poll() is None and time.monotonic()<deadline,'server did not start');time.sleep(0.02)
 url=json.loads((out/'server.stdout').read_text())['url']
 opened=browser(['open',url,'--browser','chrome'],'open');sdk.require(opened.returncode==0,'open failed')
 raw=browser(['run-code','--filename',str(consumer/'browser-acceptance.js')],'acceptance');text=raw.stdout.decode()
 sdk.require(raw.returncode==0 and not raw.stderr and text.count('### Result\n')==1 and '### Error' not in text,'browser acceptance failed')
 report=parse_strict_json_bytes(text.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='base browser')
 sdk.require(report['status']=='WASM_INSTALLED_BROWSER_PASS' and len(report['cases'])==10,'base browser incomplete')
 result.update(completed=True,report=report)
finally:
 closed=browser(['close'],'close');sdk.require(closed.returncode==0,'browser close failed')
 if server.poll() is None:server.terminate()
 server.wait(timeout=10);serverout.close();servererr.close()
 sdk.write_json(out/'RESULT.json',result)
print('base browser passed')
