from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ci-late-swift-coverage'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-ci-runtime-failures/late-swift-release-coverage'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
jobs = {j['id']: j for j in json.loads((BASE / 'JOBS.json').read_bytes())}
snapshot = json.loads((BASE / 'CI_STATUS.json').read_bytes())
checkout = '6084f3bfb09333f6b66291b38809ed512296a27b'
logs = {i: (BASE / f'job-{i}.log').read_bytes() for i in jobs}
for i, raw in logs.items():
    assert jobs[i]['conclusion'] == 'failure'
    assert re.search(r'^\S+Z ' + checkout + r'$', raw.decode(), re.M)
swift = logs[126463650237].decode()
coverage = logs[127038195710].decode()
assert 'ValueError: OpenSSL server exchange census differs' in swift
assert 'report["witness_exchanges"] == 142' in swift
assert 'result["c_consumer"] = qualify_c(' in swift
assert 'ValueError: partition is unfinished or makes a complete-package claim' in coverage
assert 'Total of 6 artifact(s) downloaded' in coverage
assert 'Download artifact has finished successfully' in coverage
steps = {s['number']: s for s in jobs[127038195710]['steps']}
assert steps[4]['conclusion'] == 'success'
assert steps[5]['conclusion'] == 'failure'
assert steps[6]['conclusion'] == 'skipped'
classification = {
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at': snapshot['observed_at'],
    'wave_counts': snapshot['counts'], 'actual_checkout': checkout,
    'swift_release': {
        'job_id': 126463650237, 'run_id': 41791854684,
        'failure': 'Old exact 142 server-count prerequisite in qualify_c.',
        'observed_p0_failure_ordinal': 15,
        'hosted_server_count_disclosed': False, 'swift_execution_established': False,
        'reported_artifact': {'id': 13386044520, 'bytes': 47608936,
            'sha256': '0f65a0d46dbc28a3c75e5a1626e52e384c28174699f377c582eda4da283f8765'},
    },
    'installed_coverage': {
        'job_id': 127038195710, 'run_id': 41791854684,
        'failure': 'The first partition completion/claim predicate rejects its parsed report.',
        'classification': 'Dependent coverage gate, separate from another runtime P0 occurrence.',
        'artifacts_downloaded_by_hosted_job': 6,
        'first_partition_from_pinned_source_order': 'continuity-installed-swift-debug',
        'exact_failed_conjunct_established': False,
        'reason_for_limit': 'The downloaded report bytes were not retrieved locally; the log exposes the compound predicate, not the individual failed fields.',
        'coverage_report_written': False, 'coverage_upload_skipped': True,
        'source_url': 'https://github.com/billlza/q-periapt/blob/' + checkout + '/artifact/continuity_profiles.py',
        'required_behavior': 'Retain the strict join and require all six same-source consumer profiles to finish.',
    },
    'logs': {str(i): {'bytes': len(b), 'sha256': sha(b), 'url': jobs[i]['html_url']} for i, b in logs.items()},
    'artifacts_downloaded_locally': False, 'effective_wave_open': True,
    'push_performed': False, 'rerun_performed': False, 'workflow_cancelled': False,
    'release_claim_eligible': False,
}
files = {'capture/' + p.name: p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for n, b in sorted(files.items()):
        info = zipfile.ZipInfo(n, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, b)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(files) and set(archive.namelist()) == set(files)
    for n, b in files.items(): assert archive.read(n) == b
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
DEST.mkdir(exist_ok=False)
for n, b in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
             ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / n).open('xb') as f: f.write(b)
print(json.dumps(summary, indent=2), flush=True)
