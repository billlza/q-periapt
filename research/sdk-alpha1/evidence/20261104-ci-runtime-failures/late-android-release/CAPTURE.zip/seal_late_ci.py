from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-c-managed-cohort'
DEST=ROOT/'research/sdk-alpha1/evidence/20261104-ci-runtime-failures/late-android-release'
encode=lambda v:(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
raw=(BASE/'CI_ANDROID_RELEASE_126489776722.zip').read_bytes()
digest=hashlib.sha256(raw).hexdigest()
assert len(raw)==47614735 and digest=='75ff00efb06f1c20bbfd4bc0156c28ff5cf8af9b6747fa618e9d18a55061261d'
selected=['CONTINUITY_PACKAGE.json','C_CONSUMER.json','c-witness-openssl-server-release.json','c-witness-openssl-server-release.stdout','c-witness-openssl-server-release.stderr']
files={}
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==17722
    for name in selected:
        info=z.getinfo(name)
        assert info.file_size<8*1024**2 and not stat.S_ISLNK(info.external_attr>>16)
        files['artifact/'+name]=z.read(name)
    assert not any(n.endswith('ANDROID_JNI_CONSUMER.json') for n in names)
    server_names=[n for n in names if 'openssl-server' in n or 'openssl-witness-server' in n]
    # Artifact member order is not part of the qualification contract.
    assert set(server_names)==set(selected[2:])
    preparation_failure={'error':'AssertionError at line 17 of the initial read-only sealing preparation',
        'reason':'The preparer compared ZIP member enumeration order with a selected list; their exact sets and contents agree.',
        'expected_order':selected[2:],'observed_order':server_names,
        'failed_preparation_created_capture':False,'product_verifier_changed':False,
        'runtime_rerun':False}
    assert server_names!=selected[2:]
    package=json.loads(files['artifact/CONTINUITY_PACKAGE.json'])
    native=json.loads(files['artifact/C_CONSUMER.json'])
    receipt=json.loads(files['artifact/c-witness-openssl-server-release.json'])
    assert package['source_commit']=='59bde0fd1a268de4d0e183c33bf3fc5e09c9be97'
    assert not package['completed'] and not package['partition_completed']
    assert package['requested_consumers']==['Rust','C','AndroidJNI']
    assert native['failure']==package['failure']=='OpenSSL server exchange census differs'
    assert native['execution']['release']['witness_openssl']['execution']=={}
    assert b'1 passed; 0 failed; 0 ignored; 0 measured; 10 filtered out' in files['artifact/c-witness-openssl-server-release.stdout']
    assert files['artifact/c-witness-openssl-server-release.stderr']==b''
for name,path in [('job.log','CI_ANDROID_RELEASE_126489776722.log'),('JOB.json','CI_ANDROID_RELEASE_JOB.json'),('CI_STATUS.json','CI_REFRESH_03.json')]:
    files[name]=(BASE/path).read_bytes()
files['PREPARATION_FAILURE.json']=encode(preparation_failure)
files['seal_late_ci.py']=Path(__file__).read_bytes()
classification={'observed_utc':datetime.now(timezone.utc).isoformat(),'run_id':41791861104,
    'job_id':126489776722,'job_name':'continuity-installed-android-release',
    'job_url':'https://github.com/billlza/q-periapt/actions/runs/41791861104/job/126489776722',
    'metadata_head_sha':'6084f3bfb09333f6b66291b38809ed512296a27b','actual_checkout':package['source_commit'],
    'classification':'existing P0 exact-count acceptance defect in macOS C/OpenSSL prerequisite',
    'old_exact_expectation':142,'hosted_observed_count':None,
    'hosted_count_reason':'The rejected private server report and negotiation trace were not exported by the old collector. The archived native command passed, followed by the old exact-count validator failure.',
    'native_test_passed':True,'native_command_receipt':receipt,'android_jni_started':False,
    'emulator_failure':False,'physical_device_claim':False,'workflow_mutated':False,
    'rerun_performed':False,'new_wave_started':False,
    'original_artifact':{'id':13367958301,'bytes':len(raw),'sha256':digest,'members':17722},
    'retained_selected_members':selected,'raw_artifact_retained_locally':True,
    'closure':'Already prepared local P0 correction and affected regressions; hosted corrected-candidate qualification remains pending until the effective wave ends.'}
files['CLASSIFICATION.json']=encode(classification)
manifest={name:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()} for name,body in sorted(files.items())}
files['FILES.json']=encode(manifest)
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,4,0,0,0))
        info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,body)
payload=buf.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as z:
    assert set(z.namelist())==set(files) and all(z.read(name)==body for name,body in files.items())
DEST.mkdir(parents=True,exist_ok=False)
for name,body in [('CAPTURE.zip',payload),('FILES.json',files['FILES.json']),('CLASSIFICATION.json',files['CLASSIFICATION.json'])]:
    with (DEST/name).open('xb') as stream:stream.write(body)
summary={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'members':len(files)}
with (DEST/'SHA256.json').open('xb') as stream:stream.write(encode(summary))
print(json.dumps(summary))
