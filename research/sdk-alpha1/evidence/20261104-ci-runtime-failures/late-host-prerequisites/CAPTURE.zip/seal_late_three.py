from datetime import datetime, timezone
from pathlib import Path
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-c-managed-cohort'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-ci-runtime-failures/late-host-prerequisites'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
snapshot_bytes = (BASE / 'CI_REFRESH_04.json').read_bytes()
snapshot = json.loads(snapshot_bytes)
assert not snapshot['errors'] and len(snapshot['runs']) == 12
jobs = {job['id']: (run['run_id'], job) for run in snapshot['runs'] for job in run['jobs']}
assert len(jobs) == 332
counts = {}
for _, job in jobs.values():
    state = job['conclusion'] or job['status']
    counts[state] = counts.get(state, 0) + 1
assert counts == {'success': 287, 'queued': 30, 'in_progress': 2, 'failure': 11, 'skipped': 2}
expected = {
    126489776791: ('59bde0fd1a268de4d0e183c33bf3fc5e09c9be97', 13370372648, '00c3e6beb8a8462416e84ee6b656cc9aa3c54ad2fb46063a136184a8bb4c621a'),
    126463649748: ('6084f3bfb09333f6b66291b38809ed512296a27b', 13368689223, '9b7c9178a07d2bf43c386f5b904d17f109234ac2600469164e2377fad5b253bc'),
    126463649756: ('6084f3bfb09333f6b66291b38809ed512296a27b', 13370345184, 'd736460eaeae347e8bb09134bee66b1116fb1d96518be69b7c011fc3cba36b33'),
}
files = {'CI_STATUS.json': snapshot_bytes, 'seal_late_three.py': Path(__file__).read_bytes()}
classifications = []
for job_id, (checkout, artifact_id, artifact_digest) in expected.items():
    run_id, job = jobs[job_id]
    assert job['conclusion'] == 'failure'
    body = (BASE / f'CI_LATE_{job_id}.log').read_bytes()
    log = body.decode('utf-8')
    assert re.search(r'git log -1 --format=%H\n[^\n]* ' + checkout + r'\n', log)
    assert 'in qualify_c' in log
    assert 'checked = witness_openssl.verify_execution(kind, tested, interop_evidence)' in log
    assert 'report["witness_exchanges"] == 142' in log
    assert 'ValueError: OpenSSL server exchange census differs' in log
    assert 'Process completed with exit code 1.' in log
    assert f'Artifact ID {artifact_id}' in log
    assert f'SHA256 digest of uploaded artifact is {artifact_digest}' in log
    files[f'jobs/{job_id}.log'] = body
    files[f'jobs/{job_id}.json'] = encode(job)
    classifications.append({
        'job_id': job_id, 'run_id': run_id, 'job_name': job['name'], 'job_url': job['html_url'],
        'metadata_head': job['head_sha'], 'actual_checkout': checkout,
        'failure': 'OpenSSL server exchange census differs',
        'boundary': 'macOS C/OpenSSL prerequisite inside qualify_c',
        'old_exact_expectation': 142,
        'hosted_observed_count': None,
        'hosted_count_reason': 'The complete job log contains the failed exact check but not the rejected report or negotiation trace.',
        'native_command_result_claimed': False,
        'wrapper_qualification_claimed': False,
        'emulator_failure': False,
        'physical_device_claim': False,
        'artifact_metadata_from_log': {'id': artifact_id, 'sha256': artifact_digest},
        'artifact_downloaded_in_this_capture': False,
    })
result = {
    'captured_at': snapshot['captured_at'], 'sealed_at': datetime.now(timezone.utc).isoformat(),
    'wave_counts': counts, 'new_failures': classifications,
    'interpretation': 'Three further observed instances of the existing P0 old-count validator failure; do not infer Kotlin, Android JNI or emulator outcomes from job names.',
    'evidence_scope': 'Complete job logs and current job inventories; no native execution-result assertion beyond the recorded Python traceback.',
    'total_observed_old_count_failures_in_wave': 8,
    'workflow_mutated': False, 'rerun_performed': False, 'push_performed': False,
    'new_wave_started': False, 'effective_wave_open': True,
}
files['CLASSIFICATION.json'] = encode(result)
manifest = {name: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']), ('FILES.json', files['FILES.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(), 'members': len(files)}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
