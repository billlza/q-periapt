from pathlib import Path
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-c-managed-cohort'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-ci-runtime-failures/late-kotlin-release'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
snapshot_bytes = (BASE / 'CI_REFRESH_12.json').read_bytes()
snapshot = json.loads(snapshot_bytes)
assert not snapshot['errors'] and len(snapshot['runs']) == 12
jobs = [job for run in snapshot['runs'] for job in run['jobs']]
counts = {}
for job in jobs:
    key = job['conclusion'] or job['status']
    counts[key] = counts.get(key, 0) + 1
assert counts == {'success': 288, 'queued': 23, 'failure': 16, 'in_progress': 3, 'skipped': 2}
selected = [job for job in jobs if job['id'] == 126463649783]
assert len(selected) == 1 and selected[0]['conclusion'] == 'failure'
log = (BASE / 'ci-late-kotlin-release-126463649783.log').read_bytes()
for text in ['git log -1 --format=%H', '6084f3bfb09333f6b66291b38809ed512296a27b',
             'in qualify_c', 'report["witness_exchanges"] == 142',
             'ValueError: OpenSSL server exchange census differs', 'Process completed with exit code 1.',
             'Artifact ID 13383322821', 'ab1b25e1c81271b0f50abf34cc4a35a531a528b85c1c510b5fdc6f255382b473']:
    assert text.encode() in log
classification = {'captured_at': snapshot['observed_at'], 'wave_counts': counts,
    'job_id': 126463649783, 'run_id': 41791854684, 'job_name': selected[0]['name'],
    'job_url': selected[0]['html_url'], 'actual_checkout': '6084f3bfb09333f6b66291b38809ed512296a27b',
    'classification': 'Thirteenth observed P0 old-count validator failure in the macOS C/OpenSSL prerequisite.',
    'old_exact_expectation': 142, 'hosted_observed_count': None,
    'native_test_result_claimed': False, 'kotlin_consumer_execution_claimed': False, 'emulator_failure': False,
    'artifact_metadata_from_log': {'id': 13383322821, 'bytes': 47602089,
        'sha256': 'ab1b25e1c81271b0f50abf34cc4a35a531a528b85c1c510b5fdc6f255382b473'},
    'artifact_downloaded_in_this_capture': False,
    'effective_wave_open': True, 'new_wave_started': False, 'rerun_performed': False,
    'workflow_cancelled': False, 'push_performed': False}
files = {'CI_STATUS.json': snapshot_bytes, 'JOB.json': (BASE / 'CI_FAILURE_KOTLIN_RELEASE_126463649783.json').read_bytes(), 'job.log': log,
         'CLASSIFICATION.json': encode(classification), 'seal_late_kotlin_release.py': Path(__file__).read_bytes()}
manifest = {name: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']), ('FILES.json', files['FILES.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': hashlib.sha256(payload).hexdigest()}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
