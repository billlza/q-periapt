from pathlib import Path
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-c-managed-cohort'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-ci-runtime-failures/late-android-debug'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
snapshot_bytes = (BASE / 'CI_REFRESH_06.json').read_bytes()
snapshot = json.loads(snapshot_bytes)
assert not snapshot['errors'] and len(snapshot['runs']) == 12
jobs = [job for run in snapshot['runs'] for job in run['jobs']]
counts = {}
for job in jobs:
    key = job['conclusion'] or job['status']
    counts[key] = counts.get(key, 0) + 1
assert counts == {'success': 287, 'queued': 30, 'failure': 13, 'skipped': 2}
selected = [job for job in jobs if job['id'] == 126489776821]
assert len(selected) == 1 and selected[0]['conclusion'] == 'failure'
log = (BASE / 'CI_LATE_126489776821.log').read_bytes()
for text in ['git log -1 --format=%H', '59bde0fd1a268de4d0e183c33bf3fc5e09c9be97',
             'in qualify_c', 'report["witness_exchanges"] == 142',
             'ValueError: OpenSSL server exchange census differs', 'Process completed with exit code 1.',
             'Artifact ID 13373619512', 'f75c6a944df9ff796268c324cf85beb1748e3250ab81d4bc018284cd278807a2']:
    assert text.encode() in log
classification = {'captured_at': snapshot['captured_at'], 'wave_counts': counts,
    'job_id': 126489776821, 'run_id': 41791861104, 'job_name': selected[0]['name'],
    'job_url': selected[0]['html_url'], 'actual_checkout': '59bde0fd1a268de4d0e183c33bf3fc5e09c9be97',
    'classification': 'Tenth observed P0 old-count validator failure in the macOS C/OpenSSL prerequisite.',
    'old_exact_expectation': 142, 'hosted_observed_count': None,
    'native_test_result_claimed': False, 'android_jni_execution_claimed': False, 'emulator_failure': False,
    'artifact_metadata_from_log': {'id': 13373619512, 'bytes': 47521939,
        'sha256': 'f75c6a944df9ff796268c324cf85beb1748e3250ab81d4bc018284cd278807a2'},
    'artifact_downloaded_in_this_capture': False,
    'effective_wave_open': True, 'new_wave_started': False, 'rerun_performed': False,
    'workflow_cancelled': False, 'push_performed': False}
files = {'CI_STATUS.json': snapshot_bytes, 'JOB.json': encode(selected[0]), 'job.log': log,
         'CLASSIFICATION.json': encode(classification), 'seal_late_android.py': Path(__file__).read_bytes()}
manifest = {name: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']), ('FILES.json', files['FILES.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': hashlib.sha256(payload).hexdigest()}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
