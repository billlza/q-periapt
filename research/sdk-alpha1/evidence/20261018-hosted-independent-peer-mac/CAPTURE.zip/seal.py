"""Seal reviewed terminal hosted outputs and their exact committed source closure."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root=Path.cwd(); out=Path(__file__).resolve().parent
folder=root/'research/sdk-alpha1/evidence/20261018-hosted-independent-peer-mac'
folder.mkdir(exist_ok=False)
def sha(data): return hashlib.sha256(data).hexdigest()
reports={name:json.loads((out/(name+'_READBACK.json')).read_text()) for name in ['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE']}
head='a0ac7cd99ac9465dec3cc4f3e0ba419b0e7cf20a'; sources=reports['RESOLUTION']['source_files']
assert len(sources)==63 and all(r['source_files']==sources and r['head']==head for n,r in reports.items() if n != 'REPLY_RELEASE')
assert len({r['native_sha256'] for n,r in reports.items() if n != 'REPLY_RELEASE'})==1
job=json.loads((out/'JOB.json').read_text()); artifact=json.loads((out/'ARTIFACT.json').read_text())
assert job['head_sha']==head and job['status']=='completed' and job['conclusion']=='success'
entries={name:(out/name).read_bytes() for name in ['ARTIFACT.json','JOB.json','mac-a0ac.zip','download.py','download.stdout','download.stderr','seal.py','source_readback.py']}
for label in ['regressions','control','resolution','witness','peer-lifecycle','reply-release']:
 for suffix in ['py','stdout','stderr']:
  name='review-'+label+'.'+suffix;entries[name]=(out/name).read_bytes()
for label in reports:
 name=label+'_READBACK.json';entries[name]=(out/name).read_bytes()
assert all(not data for name,data in entries.items() if name.endswith('.stderr'))
for name,expected in sources.items():
 data=subprocess.check_output(['git','show',head+':research/continuity-openssl-peer/'+name])
 assert sha(data)==expected
 entries['source/'+name]=data
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
  z.writestr(item,data)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(entries) and z.testzip() is None
 for name,item in manifest.items():
  data=z.read(name);assert len(data)==item['bytes'] and sha(data)==item['sha256']
result={'head':head,'run':job['run_id'],'job':job['id'],'job_conclusion':job['conclusion'],
 'artifact_id':artifact['id'],'artifact_bytes':artifact['size_in_bytes'],'artifact_digest':artifact['digest'],
 'artifact_members':len(zipfile.ZipFile(out/'mac-a0ac.zip').infolist()),'readbacks':reports,
 'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},
 'scope':'Thirteen completed Apple Silicon lanes; six public readers check exact committed sources, binary, signatures, application accounting, original IDs and process cuts. This is not private-MAC rederivation, physical erasure, power-loss qualification, network/installed independent lifecycle or PCS proof.'}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'native_sha256':reports['RESOLUTION']['native_sha256'],'capture':result['capture']}))
