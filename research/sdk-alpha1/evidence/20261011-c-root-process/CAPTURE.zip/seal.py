from pathlib import Path
import hashlib,json,re,subprocess,zipfile,sys
out=Path(__file__).resolve().parent;root=out.parent.parent;prior=root/'target/c-root-current';base=root/'bindings/c/ContinuityPackageConsumer'
sys.path.insert(0,str(root/'artifact'))
import continuity_c_root as component
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='1d0669445f256fea5547be17b0c9cf1cffd6daf8'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
checks=[]
for label,count in [('process-fix-admission',55),('process-fix-clippy',None),('process-fix-min-root',7),('process-fix-min-clippy',None)]:
 r=json.loads((prior/label/'RESULT.json').read_text());assert r['completed'] and r['source_unchanged'] and r['returncode']==0
 for name,digest in r['files'].items():
  if name.startswith(('src/','tests/')):assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest
 if count:assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in (prior/label/'stdout').read_text()
 checks.append({'label':label,'command':r['command'],'tests':count,'seconds':r['seconds'],'completed':True,'source_matches_implementation':True})
foreign={}
for profile,label in [('debug','integrated-debug'),('release','integrated-release')]:
 r=json.loads((out/label/'RESULT.json').read_text());assert r['completed'];stdout=(out/label/('root-'+profile+'.stdout')).read_bytes()
 checked=component.verify_execution(stdout,out/label/'c-root-public'/profile,darwin=True);assert checked['processes']==14 and checked['sigkill_cuts']==8
 foreign[profile]={'completed':True,'processes':14,'sigkill_cuts':8,'witness_exchanges':checked['witness']['exchanges'],'native_readbacks':3,'binaries':r['binaries'],'stacks':checked['default_thread_stacks']}
r=json.loads((out/'minimum-debug/RESULT.json').read_text());assert r['completed']
checked=component.verify_execution((out/'minimum-debug/trace.stdout').read_bytes(),out/'minimum-public',darwin=True)
foreign['minimum-debug']={'completed':True,'processes':14,'sigkill_cuts':8,'native_readbacks':3,'witness_exchanges':checked['witness']['exchanges'],'library_sha256':r['library_sha256'],'client_sha256':r['client_sha256'],'stacks':checked['default_thread_stacks']}
red=json.loads((out/'fifth-debug/START.json').read_text());green=json.loads((out/'sixth-debug/START.json').read_text())
for name in ('root_client.c','root_client.h','root_cleanup_client.c'):assert red['files'][name]==green['files'][name]
assert json.loads((out/'same-state-replay.json').read_text())['returncode']==0
assert 'signal: 10 (SIGBUS)' in (out/'fifth-debug/trace.stderr').read_text()
assert json.loads((out/'rustfmt.json').read_text())['returncode']==0
assert 'commit='+head in (out/'source-gate.stdout').read_text()
for label,count in [('codeql-tests',44),('consumer-tests',13),('package-tests',15)]:
 text=(out/(label+'.stderr')).read_text();assert f'Ran {count} tests' in text and text.rstrip().endswith('OK')
assert all(v['rejected'] for v in json.loads((out/'verifier-adversarial.json').read_text()).values())
state=json.loads((out/'STATE.json').read_text());state.update(phase='C default-stack root recovery fix and process qualification complete locally; full release and CI unresolved',local_producers_running=False,source_gate_commit=head);(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
dest=root/'research/sdk-alpha1/evidence/20261011-c-root-process';dest.mkdir()
files={}
for path in sorted(out.rglob('*')):
 if not path.is_file() or 'codeql-3b' in path.parts or 'verifier-adversarial' in path.parts:continue
 assert not path.is_symlink();files[path.relative_to(out).as_posix()]=path.read_bytes()
for label,_ in [('process-fix-admission',55),('process-fix-clippy',None),('process-fix-min-root',7),('process-fix-min-clippy',None)]:
 for path in (prior/label).iterdir():
  if path.is_file():files['rust-checks/'+label+'/'+path.name]=path.read_bytes()
files['toolchains.json']=(prior/'toolchains.json').read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();cap=dest/'CAPTURE.zip'
with zipfile.ZipFile(cap,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(cap) as z:
 assert set(z.namelist())==set(files)
 for name,detail in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==detail['sha256']
report={'schema':1,'implementation_commit':head,'release_claim_eligible':False,'scope':component.SCOPE,
 'root_cause':'Unoptimized by-value recovery/plan captures accumulated large stack frames across the foreign admission and panic boundaries. The default pthread hit its guard during roster ML-DSA verification while resuming a frozen original root.',
 'fix':'Keep the original recovery input and public plan in Box ownership until the native consuming call. No new thread, enlarged caller stack, skipped signature verification or storage format change.',
 'red_green':{'red':'fifth-debug: freeze-retry terminated by SIGBUS on the default C pthread; owned crash metadata records stack-guard protection failure','same_original_storage':'same-state-replay: same failed original registry/enrollment/journal and approved public inputs, unchanged C source, fixed library returned root-stage-pass:freeze-retry','fresh_workloads':foreign},
 'static_evidence':'Captured before/after disassembly for 15 matching C adapter frames. One qpc_root_v1_resume closure changes explicit stack subtraction from 0xd5f0 bytes to 0x1b0 bytes; this is a compiled frame observation, not whole-thread peak usage or a latency benchmark.',
 'validation':checks,'exports':json.loads((out/'exports.json').read_text()),'tracked_rust_sources':546,'source_gate':(out/'source-gate.stdout').read_text().strip(),'installed_rustfmt':True,'tool_tests':{'inventory':44,'consumer':13,'package':15},'adversarial_public_replays':6,
 'native_package_provenance':'Native candidate archive 90684e636f83632b84f6c49080fac6ea44268c96a1da06fb0290599c4c43f51e and the prior SDK archives are unchanged; only the C adapter and qualification paths changed. Original archive qualification retained in 20261011-c-root-controller.',
 'limitations':['Same-host macOS arm64; signed TCP witness and the same native engine. No Intel Mac support added. No physical-device or independent-implementation claim.',
 'The eight SIGKILL cuts follow public-call returns. They do not replace the separate native in-commit fault campaign.',
 'Compiled-C transition/adoption process variants, application TLS traffic after root cutover and Swift/Kotlin root controllers remain open.',
 'Policy/credential expiry, other hosts, independent interoperability, external review, full proof/performance/upgrade and remaining release requirements remain open as scoped gates.',
 'CodeQL run 38122738417 failed at the 180-minute full SummaryStats query; diagnostics preserved separately, no new push or gate relaxation in this component. Android emulator investigation remains sealed.'],
 'capture':{'file':'CAPTURE.zip','bytes':cap.stat().st_size,'members':len(files),'sha256':hashlib.sha256(cap.read_bytes()).hexdigest()}}
(dest/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
ci=out/'codeql-3b';ci_dest=root/'research/sdk-alpha1/evidence/20261011-codeql-3b-timeout';ci_dest.mkdir()
receipt=json.loads((ci/'RECEIPT.json').read_text());selected=[p for p in ci.iterdir() if p.is_file() and p.name not in ('rust.raw.log','diagnostics.zip')]
ci_cap=ci_dest/'CAPTURE.zip'
with zipfile.ZipFile(ci_cap,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(selected):z.write(p,p.name)
receipt.update(release_claim_eligible=False,raw_assets_retained_locally=str(ci),capture={'file':'CAPTURE.zip','bytes':ci_cap.stat().st_size,'sha256':hashlib.sha256(ci_cap.read_bytes()).hexdigest()})
(ci_dest/'CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'implementation_commit':head,'C_capture':report['capture'],'CI_capture':receipt['capture']}))
