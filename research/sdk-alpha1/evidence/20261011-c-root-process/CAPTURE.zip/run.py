from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parent.parent
previous=json.loads((root/'target/c-root-current/STATE.json').read_text());consumer=Path(previous['consumer']);work=Path(previous['work'])
label,profile,*selection=sys.argv[1:];runout=out/label;runout.mkdir()
for name in ('root_client.c','root_client.h','root_cleanup_client.c'):
 shutil.copyfile(root/'bindings/c/ContinuityPackageConsumer'/name,consumer/name)
shutil.copyfile(root/'bindings/c/ContinuityPackageConsumer/tests/root.rs',consumer/'tests/root.rs')
shutil.copytree(root/'bindings/c/ContinuityPackageConsumer/tests/root',consumer/'tests/root',dirs_exist_ok=True)
minimum=profile.startswith('msrv-');tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/('1.90.0-aarch64-apple-darwin' if minimum else '1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_')) and k not in ('CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','SDKROOT','MACOSX_DEPLOYMENT_TARGET')}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/('build-msrv' if minimum else 'build')),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
def run(argv,name,environment=env):
 with (runout/(name+'.stdout')).open('wb') as so,(runout/(name+'.stderr')).open('wb') as se:
  r=subprocess.run(argv,cwd=consumer,env=environment,stdout=so,stderr=se,timeout=1200)
 (runout/(name+'.json')).write_text(json.dumps({'command':argv,'returncode':r.returncode},indent=2)+'\n')
 if r.returncode:
  print((runout/(name+'.stdout')).read_text()[-1800:]);print((runout/(name+'.stderr')).read_text()[-3800:]);raise SystemExit(r.returncode)
 return (runout/(name+'.stdout')).read_bytes()
filename='libq_periapt_continuity_c_consumer.dylib'
if selection:
 assert selection==['fixed']
 prior=json.loads((out/('fixed-library-'+profile+'.json')).read_text());installed=Path(prior['installed'])
else:
 installed=work/('root-installed-'+profile)
 prior=json.loads((root/f'target/c-root-current/foreign-{profile}/RESULT.json').read_text())
assert hashlib.sha256((installed/filename).read_bytes()).hexdigest()==prior['library_sha256']
client=installed/('root-process-'+label)
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob('*') if p.is_file()}
(runout/'START.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'profile':profile,'files':files,'installed_library_sha256':prior['library_sha256']},indent=2)+'\n')
extra=['--release'] if profile=='release' else []
run(['/usr/bin/xcrun','--sdk','macosx','clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread','-O2' if profile=='release' else '-O0',str(consumer/'root_client.c'),'-I',str(consumer),'-L',str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(client)],'compile')
built=run([str(tc/'bin/cargo'),'test','--manifest-path',str(consumer/'Cargo.toml'),'--locked','--offline','--test','root','--no-run','--message-format=json','-j','2',*extra],'build')
messages=[json.loads(line) for line in built.splitlines()];bins=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable')];assert len(bins)==1
runtime={k:v for k,v in env.items() if not k.startswith(('DYLD_','LD_'))};evidence=work/('root-process-'+label+'-runtime')
runtime.update(QPC_ROOT_CLIENT=str(client),QPC_ROOT_EVIDENCE=str(evidence))
start=time.monotonic();run([bins[0],'--exact','installed_c_root_controller_recovers_original_state_and_erasure_after_process_loss','--nocapture'],'trace',runtime)
assert all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
result={'completed':True,'profile':profile,'seconds':time.monotonic()-start,'client':str(client),'client_sha256':hashlib.sha256(client.read_bytes()).hexdigest(),'library_sha256':prior['library_sha256'],'evidence':str(evidence),'source_unchanged':True}
(runout/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((runout/'trace.stdout').read_text()[-1800:])
