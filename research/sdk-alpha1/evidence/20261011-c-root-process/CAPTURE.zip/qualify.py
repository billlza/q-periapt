from pathlib import Path
import json,os,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parent.parent
sys.path.insert(0,str(root/'artifact'))
import rust_sdk_profile as sdk, continuity_c_root as component
s=json.loads((root/'target/c-root-current/STATE.json').read_text());work=Path(s['work']);consumer=Path(s['consumer']);profile=sys.argv[1]
runout=out/('integrated-'+profile);runout.mkdir()
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/'build'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
runtime={k:v for k,v in env.items() if not k.startswith(('DYLD_','LD_'))}
# Mirror the enclosing package collector's already-used main-traffic fixture.
runtime['QPERIAPT_PUBLIC_SERVICE_EVIDENCE']=str(work/'root-process-seventh-debug-runtime')
def run(argv,label,*,runtime=None):return sdk.command(argv,runout/label,consumer,environment=env if runtime is None else runtime)
cc=Path(subprocess.check_output(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],text=True).strip()).resolve();sysroot=subprocess.check_output(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],text=True).strip()
installed=Path(json.loads((out/('fixed-library-'+profile+'.json')).read_text())['installed'])
result=component.qualify(work,runout,consumer,installed,work/'build'/profile,cc,['-isysroot',sysroot],profile,[str(tc/'bin/cargo')],run,darwin=True,runtime=runtime,filename='libq_periapt_continuity_c_consumer.dylib')
(runout/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'completed':result['completed'],'profile':profile,'processes':result['processes'],'sigkill_cuts':result['sigkill_cuts'],'exchanges':result['witness']['exchanges']}))
