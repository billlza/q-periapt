from pathlib import Path
import hashlib,json,os,subprocess,shutil,sys
out=Path(__file__).resolve().parent;root=out.parent.parent;s=json.loads((root/'target/c-root-current/STATE.json').read_text());work=Path(s['work']);consumer=Path(s['consumer']);profile=sys.argv[1];minimum=profile.startswith('msrv-');cargo_profile='debug' if minimum else profile;tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/('1.90.0-aarch64-apple-darwin' if minimum else '1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/('build-msrv' if minimum else 'build')),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
filename='libq_periapt_continuity_c_consumer.dylib';label='fixed-library-'+profile;extra=['--release'] if profile=='release' else []
args=[str(tc/'bin/cargo'),'rustc','--locked','--offline','--lib','-j','2',*extra,'--','-C','link-arg=-Wl,-install_name,@rpath/'+filename]
with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:r=subprocess.run(args,cwd=consumer,env=env,stdout=so,stderr=se,timeout=1200)
assert r.returncode==0,(out/(label+'.stderr')).read_text()[-2500:]
installed=work/('root-process-fixed-'+profile);installed.mkdir();shutil.copyfile(work/('build-msrv' if minimum else 'build')/cargo_profile/filename,installed/filename)
record={'command':args,'returncode':r.returncode,'installed':str(installed),'library_sha256':hashlib.sha256((installed/filename).read_bytes()).hexdigest()}
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
