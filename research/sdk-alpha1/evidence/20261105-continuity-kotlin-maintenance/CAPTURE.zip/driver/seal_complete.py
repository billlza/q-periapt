"""Read back and seal the terminal, source-bound installed Kotlin extension."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import subprocess
import zipfile

import continuity_package as package
import continuity_kotlin_consumer as kotlin
import continuity_c_enrollment as enrollment
from continuity_apple_package import file_hashes
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-kotlin-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = SOURCE / 'target/kotlin-managed-qualification/result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-continuity-kotlin-maintenance'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()


def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def obj(path): return json.loads(read(path))
def encode(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


launch = obj(BASE / 'LAUNCH_RESULT.json')
driver = obj(BASE / 'DRIVER_RESULT.json')
consumer = obj(OUTPUT / 'KOTLIN_CONSUMER.json')
assert launch['completed'] and launch['returncode'] == 0 and driver['completed']
assert launch['timeout_seconds'] == 18000 and launch['component_timeout_seconds'] == 900
assert launch['component_stream_limit_bytes'] == 16 * 1024**2
assert driver['source_inputs_unchanged'] and driver['native_foundation_unchanged']
assert driver['source_commit'] == COMMIT and driver['sdk_report_sha256'] == REPORT_SHA
assert digest(REPORT) == REPORT_SHA
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
assert consumer == driver['kotlin_consumer'] and consumer['completed'] and consumer['partition_completed']
assert consumer['build_profiles'] == ['debug', 'release'] and set(consumer['profiles']) == {'debug', 'release'}
for suffix in ['stdout', 'stderr']:
    assert digest(BASE / ('driver.' + suffix)) == launch[suffix + '_sha256']
assert digest(BASE / 'launch.py') == launch['launch_driver_sha256']
assert digest(SOURCE / 'target/kotlin-managed-qualification/run.py') == driver['driver_sha256']
helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
assert digest(helper) == driver['stream_helper_sha256']
before = driver['source_inputs']
current = package.source_inputs()
assert current['rust_workspace_sha256'] == before['rust_workspace_sha256']
differences = {name: {'qualified': before['files'][name], 'current': current['files'][name]}
               for name in sorted(current['files'].keys() & before['files'].keys())
               if current['files'][name] != before['files'][name]}
added = {name: current['files'][name] for name in sorted(current['files'].keys() - before['files'].keys())}
assert set(differences) == {
    '.github/workflows/ci.yml', 'artifact/continuity_apple_package.py', 'artifact/continuity_apple_consumer.py',
    'bindings/swift/ContinuityPackageConsumer/ApplePackageREADME.md',
    'research/continuity-identity-candidate/src/durable/messages/tests.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'}
assert set(added) == {
    'research/continuity-identity-candidate/src/durable/messages/tests/classical_alias.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure/aggregate_copy.rs'}
assert not before['files'].keys() - current['files'].keys()
assert all(digest(SOURCE / name) == expected for name, expected in before['files'].items())
assert sdk.rust_workspace_source_digest(SOURCE) == before['rust_workspace_sha256']
assert file_hashes(Path(driver['outside']) / 'c-consumer') == driver['c_source_before']
for name, row in driver['tools'].items():
    assert kotlin.tool_identity(Path(row['root'])) == row
for row in driver['native_binaries'].values(): assert digest(Path(row['path'])) == row['sha256']
for row in driver['sdk_archives'].values(): assert digest(Path(row['path'])) == row['sha256']
for name, expected in driver['native_build_receipts'].items():
    assert digest(OUTPUT / name) == digest(SOURCE / 'target/c-managed-qualification/result-01' / name) == expected
assert len(driver['native_build_receipts']) == 18
for filename, key in [('CONTINUITY_PACKAGE.json', 'foundation_report_sha256'), ('C_CONSUMER.json', 'foundation_c_report_sha256')]:
    assert digest(OUTPUT / ('base-' + filename)) == driver[key]
    assert digest(SOURCE / 'target/c-managed-qualification/result-01' / filename) == driver[key]

expected_suites = {'OwnerTests': kotlin.TEST_NAMES, 'CredentialRenewalTests': kotlin.RENEWAL_TEST_NAMES,
                   'PolicyContinuationTests': kotlin.POLICY_TEST_NAMES, **kotlin.INDEPENDENT_TEST_SUITES}
owner_readback = {}
for label, row in [('publication-build', consumer['owner_tests']),
                   *((p, r['owner_tests']) for p, r in consumer['profiles'].items())]:
    assert set(row['suites']) == set(expected_suites)
    for name, expected in expected_suites.items():
        retained = row['suites'][name]
        checked = kotlin._verify_test_suite(read(OUTPUT / retained['report_file']), name, expected)
        assert checked == {k: v for k, v in retained.items() if k != 'report_file'}
    assert row['tests'] == sum(len(v) for v in expected_suites.values())
    owner_readback[label] = {'tests': row['tests'], 'suites': len(row['suites'])}

publications = {}
for profile, row in consumer['profiles'].items():
    assert digest(OUTPUT / row['archive']) == row['archive_sha256']
    assert digest(Path(row['launcher']['path'])) == row['launcher']['sha256']
    installed = Path(row['launcher']['path']).parent
    native_library = installed / 'native/lib/libq_periapt_continuity_c_consumer.dylib'
    assert digest(native_library) == row['native_library_sha256']
    for name, expected in row['jars'].items():
        assert digest(installed / 'consumer/build/install/continuity-installed-consumer/lib' / name) == expected
    assert set(row['enrollment']) == set(row['prepared_owner_gc']) == set(row['inflight_owner_gc']) == {'Serial', 'G1'}
    for collector in ['Serial', 'G1']:
        label = profile + '-' + collector.lower()
        directory = OUTPUT / 'kotlin-publication-public' / label
        checked = enrollment.verify_execution(read(OUTPUT / f'kotlin-publication-{label}.stdout'),
                                               directory, language='Kotlin', publication=True)
        assert checked == row['enrollment'][collector]['publication']['execution']
        assert {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()} == set(checked['public_readbacks'])
        gc_stem = f'kotlin-gc-{collector.lower()}-{profile}'
        assert kotlin.verify_gc_execution(read(OUTPUT / (gc_stem + '.stdout'))) == row['prepared_owner_gc'][collector]
        assert read(OUTPUT / (gc_stem + '.stderr')) == b''
        publications[label] = {'exact_publication_readback': True, 'files': len(checked['public_readbacks']),
                               'archive_sha256': row['archive_sha256'], 'native_library_sha256': row['native_library_sha256']}

workflow = read(ROOT / '.github/workflows/ci.yml')
section = workflow.decode().split('\n  continuity-installed-swift:\n', 1)[1]
section = re.split(r'\n  [A-Za-z0-9_-]+:\n', section, maxsplit=1)[0]
patterns = re.findall(r'^\s+target/continuity-installed-swift/(.+)$', section, re.M)
assert 'kotlin-publication-public/**' in patterns and 'kotlin-*-tests*.xml' in patterns and '*.zip' in patterns
selected = set()
for pattern in patterns:
    if pattern.endswith('/**'):
        for directory in OUTPUT.glob(pattern[:-3]):
            assert directory.is_dir() and not directory.is_symlink()
            selected.update(p for p in directory.rglob('*') if p.is_file())
    else:
        selected.update(p for p in OUTPUT.glob(pattern) if p.is_file())
actual = {p for p in OUTPUT.rglob('*') if p.is_file()}
assert selected == actual, {'unselected': sorted(str(p.relative_to(OUTPUT)) for p in actual - selected)}
assert not any(p.is_symlink() for p in OUTPUT.rglob('*'))
public_manifests = []
for path in sorted(OUTPUT.rglob('PUBLIC_FILES.json')):
    row = obj(path)
    assert row['completed'] and isinstance(row['files'], dict)
    for name, expected in row['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert digest(path.parent / relative) == expected
    leaves = {p.relative_to(path.parent).as_posix() for p in path.parent.rglob('*') if p.is_file()}
    assert leaves == set(row['files']) | {'PUBLIC_FILES.json'}
    public_manifests.append({'path': path.relative_to(OUTPUT).as_posix(), 'files': len(row['files']), 'sha256': digest(path)})
commands = []
for path in sorted(OUTPUT.glob('*.json')):
    row = obj(path)
    if isinstance(row, dict) and isinstance(row.get('argv'), list) and 'returncode' in row:
        commands.append({'receipt': path.name, 'returncode': row['returncode'],
                         'reused_native_build_receipt': path.name in driver['native_build_receipts']})
copied = [row for row in commands if row['reused_native_build_receipt']]
assert len(copied) == 6
print(json.dumps({'phase': 'validated', 'output_files': len(selected), 'commands': len(commands),
                  'copied_commands': len(copied), 'public_manifests': len(public_manifests)}), flush=True)
files = {'output/' + p.relative_to(OUTPUT).as_posix(): read(p) for p in sorted(selected)}
for name in ['PREPARATION.json', 'NATIVE_RECEIPT_PREPARATION.json', 'INPUTS.json', 'LAUNCH.json',
             'LAUNCH_RESULT.json', 'DRIVER_RESULT.json', 'launch.py', 'driver.stdout', 'driver.stderr',
             'launcher.stdout', 'launcher.stderr', 'run-before-build-receipts.py', 'seal_complete.py']:
    files['driver/' + name] = read(BASE / name)
files['driver/run.py'] = read(SOURCE / 'target/kotlin-managed-qualification/run.py')
files['driver/streamed_command.py'] = read(helper)
for name in ['PREPARATION.json', 'TOOLS.json']:
    files['tools/' + name] = read(ROOT / 'target/continuity-jvm-tools' / name)
for name in ['artifact/continuity_kotlin_consumer.py', 'artifact/continuity_c_enrollment.py', '.github/workflows/ci.yml']:
    files['source/qualified/' + name] = read(SOURCE / name)
files['source/current-ci.yml'] = workflow
files['producer/RUST_SDK_PACKAGE.json'] = read(REPORT)
current_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
readback = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed': True,
    'source_commit': COMMIT, 'current_main_commit': current_commit, 'sdk_producer_commit': driver['sdk_producer_commit'],
    'sdk_report_sha256': REPORT_SHA, 'scope': driver['scope'],
    'native_foundation_reused': True, 'native_foundation_unchanged': True,
    'all_selected_inputs_identical_to_current_main': False,
    'selected_input_changes': differences, 'selected_input_additions': added,
    'compatibility_scope': 'Selected native production, C/Kotlin runtime and Kotlin qualifier inputs are unchanged. Differences are CI export/artifact ordering, Apple packaging/consumer support, and candidate test-only sources. This is the ff072bd6 cohort, not a new full-suite or final-candidate qualification.',
    'publication_readback': publications, 'owner_test_reports_rechecked': owner_readback,
    'public_manifests': public_manifests, 'top_level_command_receipts': commands,
    'new_top_level_commands': len(commands) - len(copied), 'reused_native_build_commands': len(copied),
    'observed_returncodes': dict(Counter(str(row['returncode']) for row in commands)),
    'returncode_scope': 'Expected nested fault/refusal exits remain retained and are evaluated by the unchanged scenario validators.',
    'output_files': len(selected), 'output_bytes': sum(p.stat().st_size for p in selected),
    'upload_patterns': patterns, 'current_workflow_sha256': sha(workflow),
    'gate_elapsed_seconds': launch['elapsed_seconds'], 'timeout_seconds': launch['timeout_seconds'],
    'component_timeout_seconds': 900, 'release_claim_eligible': False, 'publication_performed': False,
    'not_claimed': ['Hosted CI completion', 'Android host JNI or Android device/emulator qualification',
                    'GNU/Linux runtime', 'Physical power loss', 'Current candidate complete native suite',
                    'Formal Continuity product ABI admission', 'External review', 'Formal release']}
files['READBACK.json'] = encode(readback)


def archive_for(name):
    if name.startswith('output/') and name.endswith('.zip'): return 'PACKAGES.zip'
    if name.startswith('output/'):
        tokens = set(re.split(r'[-/._]+', name.lower()))
        profile = next((p for p in ['debug', 'release'] if p in tokens), None)
        collector = next((g for g in ['serial', 'g1'] if g in tokens), None)
        if profile and collector: return profile.upper() + '_' + collector.upper() + '.zip'
        if profile: return profile.upper() + '.zip'
    return 'CAPTURE.zip'


manifest = {name: {'archive': archive_for(name), 'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
groups = {}
for name, body in files.items(): groups.setdefault(archive_for(name), {})[name] = body
assert {'DEBUG_SERIAL.zip', 'DEBUG_G1.zip', 'RELEASE_SERIAL.zip', 'RELEASE_G1.zip'} <= groups.keys()
assert sum(len(entries) for entries in groups.values()) == len(files)
payloads = {}
for archive_name, entries in sorted(groups.items()):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
            info.create_system = 3; info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    data = buffer.getvalue()
    assert len(data) < 100 * 1024**2, f'Split {archive_name}; the repository blob bound is unchanged.'
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert len(archive.infolist()) == len(set(archive.namelist())) == len(entries)
        assert set(archive.namelist()) == set(entries)
        assert all(archive.read(name) == body for name, body in entries.items())
    payloads[archive_name] = data
    print(json.dumps({'archive': archive_name, 'bytes': len(data), 'members': len(entries), 'readback': True}), flush=True)
DEST.mkdir(parents=True, exist_ok=False)
for name, body in {**payloads, 'FILES.json': files['FILES.json'], 'READBACK.json': files['READBACK.json']}.items():
    with (DEST / name).open('xb') as stream: stream.write(body)
summary = {name: {'bytes': len(data), 'members': len(groups[name]), 'sha256': sha(data)} for name, data in sorted(payloads.items())}
with (DEST / 'SHA256.json').open('xb') as stream: stream.write(encode(summary))
print(json.dumps(summary), flush=True)
