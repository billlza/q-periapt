"""Preserve an expired full original store and continue it after the budget fix."""
from pathlib import Path
import hashlib, json, sys, time

root = Path.cwd(); out = Path(__file__).resolve().parent
sys.path.append(str(root / 'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root / 'target/independent-bootstrap-01/provider')
from types import SimpleNamespace
from local_credential_fixture import Fixture
from peer.traffic_codec import encode_traffic
from peer.wire import require
from traffic_checks import application

args = SimpleNamespace(output=out / 'original-process', provider_root=root / 'target/independent-bootstrap-01/provider',
                       native=root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart')
args.output.mkdir()
f = Fixture(args, 'full-after-expiry'); owner = coordinator = None
try:
    owner = f.open_session(); plaintext = bytes(range(256)) * 64
    original_id = owner.next_id(170); original_wire = owner.send(original_id, plaintext, b'', 170)
    for _ in range(63): owner.send(owner.next_id(170), plaintext, b'', 170)
    offer = owner.prepare_rekey_offer(f.signer, 170)
    response = f.call('full-rekey-response', 14, offer)
    final = owner.accept_rekey_response(response, f.signer, 170)
    receipt = f.call('full-rekey-receipt', 15, final)
    require(owner.accept_rekey_receipt(receipt, 170) == 1, 'capacity epoch')
    def traffic_bytes():
        with owner._state(operational=False) as (_snapshot, state):
            return 2 + sum(len(encode_traffic(t)) for t in state.traffic.epochs.values())
    cap = 2 * 1024**2 - 65536; rows = 64
    while traffic_bytes() < cap:
        before = traffic_bytes(); remaining = cap - before
        require(remaining >= 153 and rows < 128, 'full row capacity')
        size = min(16384, remaining - 153)
        if 0 < remaining - 153 - size < 153: size -= 153
        last_id = owner.next_id(170); last_wire = owner.send(last_id, b'f' * size, b'', 170); rows += 1
        require(traffic_bytes() - before == 153 + size, 'exact traffic row')
    require(traffic_bytes() == cap, 'exact full business allowance')
    owner.close(); owner = None
    first = f.materials(1); original_head = (f.path / 'head').read_bytes()
    f.worker('expired-normal-output', 'resume', (last_id,), now=210, refusal='expired or premature authority')
    coordinator = f.coordinator(first[0])
    f.refuses('original-full-renewal-refusal', lambda: coordinator.stage(first[1], first[2], 210), 'traffic capacity reserves control completion')
    coordinator.close(); coordinator = None
    require((f.path / 'head').read_bytes() == original_head and not (f.path / 'intent').exists(), 'failed admission changed state')
    before = {'head_sha256': hashlib.sha256(original_head).hexdigest(), 'head_bytes': len(original_head),
              'traffic_bytes': cap, 'rows': rows, 'original_id': original_id.hex(), 'last_id': last_id.hex(),
              'original_ciphertext_sha256': hashlib.sha256(original_wire).hexdigest(), 'last_ciphertext_sha256': hashlib.sha256(last_wire).hexdigest(),
              'renewal_failure': f.refusals[-1], 'private_fixture': str(f.private),
              'baseline_head': '73b97e7730d1e3ee19b2872e82b24484fd5b0874'}
    (out / 'BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
    print('READY: original full expired store retained; awaiting explicit continuation marker', flush=True)
    deadline = time.monotonic() + 1200
    while not (out / 'continue').exists():
        if time.monotonic() >= deadline: raise TimeoutError('continuation marker not supplied; original state retained')
        time.sleep(1)
    # Each operation below runs in a new process importing the repaired source;
    # the original native endpoint and both original stores remain alive.
    f.worker('full-stage-cut', 'local_credential_stage', first, now=210, cut='committed:intent')
    stage_intent = (f.path / 'intent').read_bytes()
    pending = f.worker('full-stage-recovery', 'local_credential_status', (first[0],), now=210)
    require(pending['status'] == 'Pending' and hashlib.sha256((f.path / 'head').read_bytes()).digest() == hashlib.sha256(stage_intent[52:-32]).digest(), 'exact new pending target')
    f.worker('full-commit-cut', 'local_credential_commit', (first[0],), now=210, cut='committed:head')
    committed = f.worker('full-commit-recovery', 'local_credential_status', (first[0],), now=210)
    require(committed['status'] == 'Committed', 'full renewal recovery')
    require(f.value('full-original-replayed', 'resume', (original_id,), now=210) == original_wire, 'original full outbox changed')
    require(f.value('full-last-replayed', 'resume', (last_id,), now=210) == last_wire, 'last full outbox changed')
    f.call('receive-original-full', 7, application(b'', original_wire), plaintext)
    f.call('receive-last-full', 7, application(b'', last_wire), b'f' * size)
    second = f.materials(2)
    f.worker('full-second-stage', 'local_credential_stage', second, now=250)
    large_head_bytes = (f.path / 'head').stat().st_size
    require(large_head_bytes > 2 * 1024**2 + 128, 'second pending did not cross old physical image cap')
    f.worker('full-second-commit-cut', 'local_credential_commit', (second[0],), now=310, cut='removed:intent')
    require(f.worker('full-second-recovered', 'local_credential_status', (second[0],), now=310)['status'] == 'Committed', 'second original grant')
    require(f.worker('full-format', 'storage_format', now=310) == 8, 'explicit version eight')
    require(f.value('full-last-after-second', 'resume', (last_id,), now=310) == last_wire, 'second grant changed outbox')
    f.worker('full-expired-policy-output', 'resume', (last_id,), now=401, refusal='expired or premature authority')
    result = {'before': before, 'larger_pending_head_bytes': large_head_bytes,
              'same_private_store': str(f.private), 'original_native_process_preserved': True,
              'host_cleanup_performed': False, 'final_format': 8,
              'native_commands': f.native.commands, 'worker_operations': f.driver.operations}
    (out / 'AFTER.json').write_text(json.dumps(result, indent=2) + '\n');print('PASS: original full expired store renewed without deleting or accounting any outbox', flush=True)
finally:
    if owner is not None: owner.close()
    if coordinator is not None: coordinator.close()
    f.close()
