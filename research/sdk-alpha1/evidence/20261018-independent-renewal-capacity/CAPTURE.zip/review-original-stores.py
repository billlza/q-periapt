"""Public readback of original failed-store continuation; no private images."""
from pathlib import Path
import ast, hashlib, json, re, sys

root = Path.cwd(); out = Path(__file__).resolve().parent; peer = root / 'research/continuity-openssl-peer'
sys.path.append(str(peer))
from provider import load_provider
load_provider(root / 'target/independent-bootstrap-01/provider')
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load
from peer.bootstrap import digest
from peer.renewal import verify
from peer.rekey import RekeyScope, genesis

def check(value, reason):
    if not value: raise ValueError(reason)
def read(path): return parse_strict_json_bytes(path.read_bytes(), label=str(path))
def sha(data): return hashlib.sha256(data).hexdigest()

sources = read(out / 'BASELINE_SOURCES.json'); check(len(sources) == 76, 'actual pre-edit closure')
for name, expected in sources.items():
    data = (out / 'baseline-source' / name).read_bytes(); check(sha(data) == expected, 'original executed source')
    if name.endswith('.py'): ast.parse(data, name)
def worker_records(folder, rows):
    requests = {}; kills = 0
    for row in rows:
        name = row['case']; check(re.fullmatch('[A-Za-z0-9_-]{1,160}', name) and name not in requests, 'worker identity')
        request = read(folder / (name + '.request.json')); raw = (folder / (name + '.stdout')).read_bytes()
        error = (folder / (name + '.stderr')).read_text(); check(request['action'] == row['action'], 'original request')
        requests[name] = request
        if 'signal' in row:
            kills += 1; check(row['signal'] == 'SIGKILL' and read(folder / (name + '.stdout')) == {'pid': row['worker_pid'], 'stage': row['cut']} and not error, 'actual PID cut')
        elif 'refused' in row: check(not raw and row['refused'] in error, 'original output refusal')
        else: check(not error and sha(raw) == row['stdout_sha256'], 'original result bytes')
    return requests, kills

before = read(out / 'BEFORE.json'); after = read(out / 'AFTER.json')
folder = out / 'original-process/full-after-expiry'; public = folder / 'native/public'
check(after['before'] == before and after['same_private_store'] == before['private_fixture'] == (folder / 'private-fixture-path').read_text().strip(), 'same retained fixture')
check(before['renewal_failure']['error'] == 'traffic capacity reserves control completion'
      and before['traffic_bytes'] == 2031616 and before['rows'] == 123, 'original observed full-store refusal')
check(not after['host_cleanup_performed'] and after['original_native_process_preserved'] and after['final_format'] == 8, 'original continuation scope')
check(before['head_bytes'] == 2059272 and after['larger_pending_head_bytes'] == 2117244 > 2097152 + 128, 'actual file-size observations')
check(not (out / 'same-store-probe.stderr').read_bytes(), 'probe diagnostics')
requests, kills = worker_records(folder, after['worker_operations'])
check(len(requests) == 16 and kills == 3, 'same-store process workload')
native = {}
for row in after['native_commands']:
    name = row['case']; check(re.fullmatch('[A-Za-z0-9_-]{1,160}', name) and name not in native, 'native identity')
    source = (folder / 'native/cases' / (name + '.input')).read_bytes(); result = (folder / 'native/cases' / (name + '.output')).read_bytes()
    check(sha(source) == row['input_sha256'] and sha(result[1:]) == row['output_sha256'] and result[0] == row['status'], 'actual native bytes')
    native[name] = (source, result)
check(len(native) == 7 and not (folder / 'native/native.stderr').read_bytes(), 'same endpoint command trace')
def result(name): return read(folder / (name + '.stdout'))['result']
def wire(name): return bytes.fromhex(result(name))
_, _, ctx = load(public, 150)
initial = wire('initial'); reply = native['bootstrap-reply'][1][1:]; final = wire('finish')
check(ctx.initiator.open(initial, 5, 2440)[:40] == b'QPBSI001' + ctx.digest, 'original initial signature')
check(ctx.responder.open(reply, 6, 1256)[:72] == b'QPBSR001' + ctx.digest + digest(b'initial-wire', initial), 'original reply signature')
check(final[:104] == b'QPBSF001' + ctx.digest + digest(b'initial-wire', initial) + digest(b'reply-wire', reply), 'original transcript')
session = digest(b'session-id', final[:104]); check(native['complete'] == (final, b'\1' + session) and result('activate') == session.hex(), 'one original session')
grants = []
for index, stage, now in [(1, 'full-stage-cut', 210), (2, 'full-second-stage', 250)]:
    prefix = 'local-renewal-' + str(index)
    grant = verify((public / prefix).read_bytes(), ctx.devices[0], ctx.family, ctx.policy_digest, (public / ('pin-' + prefix + '-target')).read_bytes(), now=now)
    check(requests[stage]['now'] == now and requests[stage]['arguments'] == [grant.operation.hex(), grant.wire.hex(), grant.successor_roster.checkpoint().hex()], 'original root grant/operation/target')
    grants.append(grant)
check(grants[1].previous.digest == grants[0].successor.digest and ctx.devices[0].validity.end == 200, 'chained grants after original expiry')
for name, grant, status in [('full-stage-recovery', grants[0], 'Pending'), ('full-commit-recovery', grants[0], 'Committed'), ('full-second-recovered', grants[1], 'Committed')]:
    value = result(name)
    check(value['operation'] == grant.operation.hex() and value['statement'] == grant.statement.hex()
          and value['target'] == grant.successor_roster.checkpoint().hex() and value['status'] == status, 'original renewed outcome')
for name, replay, expected_hash, expected in [('receive-original-full', 'full-original-replayed', before['original_ciphertext_sha256'], bytes(range(256))*64),
                                             ('receive-last-full', 'full-last-replayed', before['last_ciphertext_sha256'], None)]:
    frame = wire(replay)
    check(sha(frame) == expected_hash and native[name][0] == b'\0\0' + frame, 'original ciphertext persisted')
    check(native[name][1] == b'\1' + (expected if expected is not None else b'f' * (len(frame)-109)), 'original native plaintext')
check(wire('full-last-after-second') == wire('full-last-replayed') and result('full-format') == 8, 'second grant preserves original outbox')
RekeyScope(ctx, session, 0, genesis(session, ctx.digest)).public_completed(native['full-rekey-response'][0], native['full-rekey-response'][1][1:], native['full-rekey-receipt'][0], native['full-rekey-receipt'][1][1:])

legacy = out / 'qualified-local-credential-capacity/legacy-seven'; continuation = read(legacy / 'ORIGINAL_CONTINUATION.json')
check('renewal key/original credential differs' in (out / 'qualified-local-credential-capacity.stderr').read_text(), 'preserved harness failure')
check(not (out / 'continue-original-legacy.stderr').read_bytes() and continuation['original_private_fixture'] == (legacy / 'private-fixture-path').read_text().strip(), 'original failed legacy fixture')
recovered, legacy_kills = worker_records(legacy, continuation['workers'])
check(len(recovered) == 8 and legacy_kills == 1, 'original legacy continuation workers')
old_wire = read(legacy / 'legacy-original-send.stdout')['result']; replay = read(legacy / 'original-repair-ciphertext.stdout')['result']
check(old_wire == replay and sha(bytes.fromhex(replay)) == continuation['original_ciphertext_sha256'], 'original failed fixture ciphertext')
check(read(legacy / 'original-repair-format-seven.stdout')['result'] == 7 and read(legacy / 'original-repair-format-eight.stdout')['result'] == 8, 'original legacy then explicit new stage')
summary = {'baseline_head': before['baseline_head'], 'baseline_sources': sources, 'original_full': {'workers': 16, 'kills': 3, 'native_commands': 7, 'rows': 123, 'traffic_bytes': 2031616, 'large_pending_image_bytes': 2117244},
           'original_failed_legacy': {'workers': 8, 'kills': 1, 'ciphertext_preserved': True, 'native_endpoint_already_stopped': True},
           'scope': 'Public signed grants, bootstrap/rekey and raw worker/native bytes checked. Exact private-store identity, admission failure, file lengths and absence of cleanup are runtime observations; no private MAC/AEAD rederivation. Full-store probe retained its original native endpoint; later failed legacy fixture continuation did not. Neither is full native process restart or power-loss/PCS qualification.'}
(out / 'ORIGINAL_STORES_READBACK.json').write_text(json.dumps(summary, indent=2) + '\n'); print(json.dumps({k:v for k,v in summary.items() if k != 'baseline_sources'}))
