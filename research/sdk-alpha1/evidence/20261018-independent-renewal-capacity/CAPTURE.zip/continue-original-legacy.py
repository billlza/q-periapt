"""Continue the original type-mismatch fixture without replacing its store."""
from pathlib import Path
import hashlib, importlib, importlib.util, json, sys

root = Path.cwd(); out = Path(__file__).resolve().parent
peer = root / 'research/continuity-openssl-peer'; sys.path.append(str(peer))
from provider import load_provider
load_provider(root / 'target/independent-bootstrap-01/provider')
from peer.journal import Scope
from peer.wire import require
from local_budget_controls import authenticate_archived
from session_driver import SessionDriver

folder = out / 'qualified-local-credential-capacity/legacy-seven'
private = Path((folder / 'private-fixture-path').read_text().strip())
public = folder / 'native/public'; path = private / 'session'
raw = (private / 'configuration').read_bytes(); require(len(raw) == 128, 'original configuration')
key = raw[:32]; scope = Scope(raw[32:64], raw[64:96], raw[96:128])
checks = json.loads((root / 'research/sdk-alpha1/evidence/20261018-independent-local-credential/CHECKS.json').read_text())
sources = checks['readbacks']['LOCAL_CREDENTIAL']['source_files']; saved = private / 'archived-peer'
for name, expected in sources.items():
    if name.startswith('peer/') and name.endswith('.py'):
        require(hashlib.sha256((saved / Path(name).name).read_bytes()).hexdigest() == expected, 'original archived source')
name = 'original_archived_legacy'; spec = importlib.util.spec_from_file_location(name, saved / '__init__.py', submodule_search_locations=[str(saved)])
require(spec is not None and spec.loader is not None, 'archived module loader')
package = importlib.util.module_from_spec(spec); sys.modules[name] = package; spec.loader.exec_module(package)
old = importlib.import_module(name + '.state_codec'); old_coordinator = importlib.import_module(name + '.local_credential')
context = authenticate_archived(public, old)
operation = (public / 'local-renewal-1-operation').read_bytes(); grant = (public / 'local-renewal-1').read_bytes(); target = (public / 'pin-local-renewal-1-target').read_bytes()
before = hashlib.sha256((path / 'head').read_bytes()).hexdigest()
owner = old_coordinator.LocalCredentialRenewal.open(path, scope, key, context, operation)
try: require(owner.stage(grant, target, 210)['status'] == 'Pending', 'original archived stage')
finally: owner.close()
driver = SessionDriver(folder, root / 'target/independent-bootstrap-01/provider', public, private / 'configuration', path, private / 'signer')
driver.run('original-repair-commit-cut', 'local_credential_commit', (operation,), now=210, cut='committed:head')
require(driver.run('original-repair-committed', 'local_credential_status', (operation,), now=210)['status'] == 'Committed', 'original commit')
require(driver.run('original-repair-format-seven', 'storage_format', now=210) == 7, 'original format retained')
second = tuple((public / name).read_bytes() for name in ['local-renewal-2-operation', 'local-renewal-2', 'pin-local-renewal-2-target'])
driver.run('original-repair-new-stage', 'local_credential_stage', second, now=250)
driver.run('original-repair-new-commit', 'local_credential_commit', (second[0],), now=310)
require(driver.run('original-repair-format-eight', 'storage_format', now=310) == 8, 'new explicit transition')
identity = bytes.fromhex(json.loads((folder / 'legacy-original-id.stdout').read_text())['result'])
original = json.loads((folder / 'legacy-original-send.stdout').read_text())['result']
require(driver.run('original-repair-ciphertext', 'resume', (identity,), now=310) == original, 'original ciphertext changed')
driver.run('original-repair-expired-refusal', 'resume', (identity,), now=401, refusal='expired or premature authority')
result = {'original_private_fixture': str(private), 'initial_head_sha256': before,
          'final_head_sha256': hashlib.sha256((path / 'head').read_bytes()).hexdigest(),
          'original_ciphertext_sha256': hashlib.sha256(bytes.fromhex(original)).hexdigest(),
          'workers': driver.operations,
          'scope': 'Original failed private store continued through archived v7 Pending, current v7 commit and explicit v8 stage. No reset/replacement. The initial harness had already stopped its native endpoint; this verifies store/ciphertext continuation, not continued native decryption or whole-native restart.'}
(folder / 'ORIGINAL_CONTINUATION.json').write_text(json.dumps(result, indent=2) + '\n')
print('PASS original failed legacy store continued through7->8 with original ciphertext')
