"""Seal the bounded lifecycle allocation, source provenance and original failures."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd(); out = Path(__file__).resolve().parent; peer = root / 'research/continuity-openssl-peer'
folder = root / 'research/sdk-alpha1/evidence/20261018-independent-renewal-capacity'
def sha(data): return hashlib.sha256(data).hexdigest()
labels = ['REGRESSION', 'CONTROL', 'RESOLUTION', 'WITNESS', 'PEER_LIFECYCLE', 'LOCAL_RENEWAL', 'REPLY_RELEASE', 'LOCAL_CREDENTIAL', 'ORIGINAL_STORES']
reports = {n: json.loads((out / (n + '_READBACK.json')).read_text()) for n in labels}
sources = reports['LOCAL_CREDENTIAL']['source_files']; assert len(sources) == 78
audit = json.loads((out / 'SOURCE_CONTINUITY.json').read_text())
for name, report in reports.items():
    if name in ('REPLY_RELEASE', 'ORIGINAL_STORES'): continue
    assert report['source_files'] == sources and report['native_sha256'] == reports['LOCAL_CREDENTIAL']['native_sha256']
    assert set(report['source_continuity']['test_harness_only_changes']) <= {'local_budget_controls.py'}
    for change in report['source_continuity']['test_harness_only_changes'].values(): assert change['audit'] == audit
runs = json.loads((out / 'FINAL_RUNS.json').read_text()); original_runs = json.loads((out / 'QUALIFIED_RUNS.json').read_text())
assert len(runs) == 16 and all(r['exit'] == 0 for r in runs)
assert [r['lane'] for r in original_runs if r['exit']] == ['local-credential-capacity']
entries = {}
def add(name, data):
    assert name not in entries
    assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFW01', b'QPRFLC01', b'QPRFLI01',
                               *(('QPREFS0' + str(i)).encode() for i in range(1, 9))))
    entries[name] = data
def tree(name):
    for path in sorted((out / name).rglob('*')):
        if not path.is_file(): continue
        assert not path.is_symlink() and path.name not in {'head', 'intent', 'authority', 'configuration', 'signer', 'key', 'wrong-signer'} and not path.name.startswith('.stage-')
        add(name + '/' + str(path.relative_to(out / name)), path.read_bytes())
for run in runs:
    name = run['output']; tree(name)
    for ext in ['stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
    assert not entries[name + '.stderr']
for name in ['qualified-local-credential-capacity', 'original-process', 'baseline-source']: tree(name)
for name in ['qualified-local-credential-capacity', 'same-store-probe', 'continue-original-legacy']:
    for ext in ['stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
assert b'renewal key/original credential differs' in entries['qualified-local-credential-capacity.stderr']
assert not entries['same-store-probe.stderr'] and not entries['continue-original-legacy.stderr']
readers = ['qualified-review-final-regressions', 'qualified-review-final-control', 'qualified-review-resolution',
           'qualified-review-witness', 'qualified-review-peer-lifecycle', 'review-local-renewal',
           'review-reply-release', 'review-local-credential', 'review-original-stores']
for name in readers:
    for ext in ['py', 'stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
    assert not entries[name + '.stderr']
for name in labels: add(name + '_READBACK.json', (out / (name + '_READBACK.json')).read_bytes())
for name in ['source_readback.py', 'run-qualified.py', 'QUALIFIED_RUNS.json', 'FINAL_RUNS.json', 'VALIDATION.json',
             'SOURCE_CONTINUITY.json', 'before-archived-context-repair.py.txt', 'seal.py', 'same-store-probe.py',
             'BEFORE.json', 'AFTER.json', 'BASELINE_SOURCES.json', 'continue-original-legacy.py']:
    add(name, (out / name).read_bytes())
for name, expected in sources.items():
    data = (peer / name).read_bytes()
    assert sha(data) == expected and subprocess.check_output(['git', 'show', ':research/continuity-openssl-peer/' + name]) == data
    add('source/' + name, data)
for name in ['README.md', 'STORAGE.md', 'LOCAL_RENEWAL.md', 'LOCAL_CREDENTIAL.md']: add('source/' + name, (peer / name).read_bytes())
add('counterpart', (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes())
assert sha(entries['counterpart']) == reports['LOCAL_CREDENTIAL']['native_sha256']
prior = root / 'research/sdk-alpha1/evidence/20261018-independent-local-credential/CHECKS.json'
add('PRIOR_NATIVE_QUALIFICATION.json', (json.dumps({'path': str(prior.relative_to(root)), 'sha256': sha(prior.read_bytes()),
    'scope': 'Exact unchanged native/provider/workflow sources; prior strict native build/Clippy/fmt/actionlint receipts retained in the committed73b capture. No unchanged native rerun.'}, indent=2) + '\n').encode())
scope = {'base_head': '73b97e7730d1e3ee19b2872e82b24484fd5b0874',
         'change': 'Explicit original-local-only schema8 gives identity coordination a separate213291B allocation. Base2MiB and business2031616B/control65536B remain; total2310443B. Raw/witness/oldschemas retain original limits. Same Journal transaction engine and crypto domains; only LocalSessionJournal selects extended file bound.',
         'qualification': 'Final16entrypoints,9publicreaders. First15passed; capacityfirst invocation failed only in archived test context construction after its full-capacity profile passed. Only affected capacityentrypoint rerun after repair; SOURCE_CONTINUITY binds exact change to archived verification types, while other77files and inventory/bound checks remained identical. Original failure preserved.',
         'original_full': 'Same failed full store and same native endpoint:123outboxes2031616Bbusiness,expiredC0,twoGrants,3realcuts,unchangedfirst/lastciphertext,nocleanup; secondPending2117244Bimagecrossesoldcap. Finalcapacityregression separately comparesallencodedepochhashes acrossbothgrants anddeniesadditionalbusiness.3cuts,13workers,7native,9directcontrols.',
         'legacy': 'Actual archived73b writer persistsv7Pending; currentcommit stays7,nextstage selects8,oldreaderrefuses8.14workers2cuts4native1directcontrol. Original failed legacy fixture separatelycontinued8workers1cutwithciphertextunchanged; nativeendpointalreadyexitedso notfullnativerecovery.',
         'limits': 'Privateimages/keys excluded. Inventoryhashes,unchangedhead,size/cancellation assertions areproducer runtime observations,notpublicMAC/AEADrederivation. Nativeclock170. Notphysicaldiskexhaustion,sameaccount/fullregistration/policy/witness/devicereplacement,fullinstalled/deployedlifecycle,erasures,powerloss,resources/energy orfullPCS/refinement admission.'}
add('SCOPE.json', (json.dumps(scope, indent=2) + '\n').encode())
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(entries.items())}
add('MANIFEST.json', (json.dumps(manifest, indent=2) + '\n').encode())
folder.mkdir(exist_ok=False); archive = folder / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        item = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0)); item.compress_type = zipfile.ZIP_DEFLATED; item.external_attr = 0o100644 << 16
        z.writestr(item, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(entries) and z.testzip() is None
    for name, value in manifest.items(): assert len(z.read(name)) == value['bytes'] and sha(z.read(name)) == value['sha256']
capture = {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())}
result = {'readbacks': reports, 'validation': json.loads(entries['VALIDATION.json']), 'capture': capture, 'scope': scope}
(folder / 'CHECKS.json').write_text(json.dumps(result, indent=2) + '\n'); print(json.dumps(capture))
