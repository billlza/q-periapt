"""Exact source readback with one audited test construction repair."""
from pathlib import Path
import hashlib, json

PEER = Path.cwd() / 'research/continuity-openssl-peer'
OUT = Path(__file__).resolve().parent
AUDIT = json.loads((OUT / 'SOURCE_CONTINUITY.json').read_text())

def source_bytes(name, expected):
    data = (PEER / name).read_bytes(); current = hashlib.sha256(data).hexdigest()
    if current == expected: return data
    if not (name == AUDIT['changed_file'] and expected == AUDIT['before_sha256'] and current == AUDIT['after_sha256']):
        raise ValueError('unqualified source changed: ' + name)
    original = (OUT / 'before-archived-context-repair.py.txt').read_bytes()
    if hashlib.sha256(original).hexdigest() != expected: raise ValueError('original harness changed')
    return original

def normalized(sources):
    for name, expected in sources.items(): source_bytes(name, expected)
    return {name: hashlib.sha256((PEER / name).read_bytes()).hexdigest() for name in sources}

def continuity(sources):
    current = normalized(sources)
    changes = {name: {'executed': expected, 'current': current[name], 'audit': AUDIT}
               for name, expected in sources.items() if expected != current[name]}
    return {'executed_source_files': sources, 'current_source_files': current,
            'test_harness_only_changes': changes, 'runtime_sources_identical': True}
