from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE=Path(__file__).resolve().parents[2]
REPO=SOURCE.parents[2]
ROOT=REPO/'target/continuity-resource-repeats-20261106'
DEST=REPO/'research/sdk-alpha1/evidence/20261106-resource-repeats'
completion=json.loads((ROOT/'RESULT.json').read_bytes())
analysis=json.loads((ROOT/'analysis-01/SUMMARY.json').read_bytes())
assert completion['completed'] is True and completion['completed_cohorts']==analysis['completed_cohorts']==16
files={}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def add(name,path):
    assert name not in files and path.is_file() and not path.is_symlink(),name
    files[name]=path

def tree(prefix,directory):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            add(prefix+'/'+path.relative_to(directory).as_posix(),path)

for name in ('PROTOCOL.json','PROGRESS.json','READER_ADAPTATION.json','FAILURE.json','RESUME.json','RESULT.json'):
    add('experiment/'+name,ROOT/name)
for index,record in enumerate(completion['cohorts']):
    directory=Path(record['directory'])
    assert record['completed'] is True
    for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
        assert sha((directory/name).read_bytes())==record[key]
    tree(f'cohorts/{index+1:02d}',directory)
    tree(f'experiment/step-{index+1:02d}',ROOT/f'step-{index+1:02d}')
tree('analysis',ROOT/'analysis-01')
builds={}
for kind,folder,attempt in [('lifecycle','continuity-operation-resources-20261105','build-02'),
    ('fanout','continuity-fanout-resources-20261106','build-01')]:
    stage=REPO/'target'/folder
    build=json.loads((stage/attempt/'OBSERVER_BUILD.json').read_bytes())
    assert build['completed'] is True and build['sources_unchanged'] is True
    builds[kind]=build
    add('observers/'+kind+'/OBSERVER_BUILD.json',stage/attempt/'OBSERVER_BUILD.json')
    outside=Path(json.loads((stage/attempt/'LOCATION.json').read_bytes())['path'])
    for name,digest in build['observer_source'].items():
        path=outside/'observer'/name
        assert sha(path.read_bytes())==digest
        add('observers/'+kind+'/source/'+name,path)
    binary=Path(build['binary'])
    assert sha(binary.read_bytes())==build['binary_sha256']
    add('binaries/'+kind,binary)
assert builds['lifecycle']['archives']==builds['fanout']['archives']
for name,record in builds['fanout']['archives'].items():
    version='0.0.0' if name=='q-periapt-continuity-identity-candidate' else '0.2.0'
    folder=SOURCE/('target/continuity-installed-rust-current' if version=='0.0.0' else 'target/sdk-020/crates')
    path=folder/(name+'-'+version+'.crate')
    assert path.stat().st_size==record['bytes'] and sha(path.read_bytes())==record['sha256']
    add('inputs/'+path.name,path)
for name,relative in [('RUST_SDK_PACKAGE.json','target/sdk-020/RUST_SDK_PACKAGE.json'),
    ('CONTINUITY_PACKAGE.json','target/continuity-installed-rust-current/CONTINUITY_PACKAGE.json')]:
    add('inputs/'+name,SOURCE/relative)
for name in ('run-resource-repeat-campaign.py','resume-resource-repeat-campaign.py','analyze-resource-repeats.py',
    'readback-operation-repeat.py','readback-fanout.py','run-operation-smoke.py','run-fanout-smoke.py',
    'capture-resource-repeats.py','validate-resource-repeat-capsule.py'):
    add('controller/'+name,SOURCE/'target/current-rust-readback'/name)
for prefix in ('resource-repeat-controller','resource-repeat-resume'):
    for suffix in ('stdout','stderr'):
        add('controller/'+prefix+'.'+suffix,SOURCE.parent/(prefix+'.'+suffix))
for suffix in ('stdout','stderr'):
    add('controller/analysis.'+suffix,ROOT/('analysis.'+suffix))
readers={}
for name in ('python-run.sh','python-env.sh','python_bootstrap.py','evidence_io.py'):
    path=SOURCE/'artifact'/name
    original=subprocess.run(['git','show',analysis['source_commit']+':artifact/'+name],cwd=SOURCE,
        check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    assert original.stderr==b'' and original.stdout==path.read_bytes()
    add('reader-source/artifact/'+name,path)
    readers['artifact/'+name]=sha(path.read_bytes())
add('diagnostic/rust_sdk_profile.py',SOURCE/'artifact/rust_sdk_profile.py')
DEST.mkdir()
manifest={}
with zipfile.ZipFile(DEST/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        manifest[name]={'bytes':len(data),'sha256':sha(data)}
        archive.writestr(name,data)
with zipfile.ZipFile(DEST/'CAPTURE.zip') as archive:
    assert len(archive.namelist())==len(manifest) and set(archive.namelist())==set(manifest)
    for name,expected in manifest.items():
        data=archive.read(name)
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
for name in ('SUMMARY.json','OPERATION_SUMMARY.json','MEMORY_SUMMARY.json'):
    (DEST/name).write_bytes((ROOT/'analysis-01'/name).read_bytes())
(DEST/'PROTOCOL.json').write_bytes((ROOT/'PROTOCOL.json').read_bytes())
(DEST/'FILES.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(DEST/'READER_SOURCE.json').write_text(json.dumps({'source_commit':analysis['source_commit'],'files':readers},indent=2,sort_keys=True)+'\n')
summary={'source_commit':analysis['source_commit'],'sha256':sha((DEST/'CAPTURE.zip').read_bytes()),
    'bytes':(DEST/'CAPTURE.zip').stat().st_size,'members':len(manifest),
    'cohorts':16,'spans':1560,'business_effect_files':600,'negative_control_receipts':432,
    'all_original_samples_retained':True,'controller_failure_and_resume_retained':True,
    'performance_qualified':False,'release_claim_eligible':False}
(DEST/'CAPTURE.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary))
