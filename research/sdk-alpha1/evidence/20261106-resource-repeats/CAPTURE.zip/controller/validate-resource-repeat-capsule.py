from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import runpy
import sys
import zipfile
from evidence_io import parse_strict_json_bytes

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
archive_path, manifest_path, output_path = map(Path,sys.argv[1:])
HERE = Path(__file__).resolve().parent
saved = sys.argv
try:
    sys.argv = [str(HERE/'readback-operation-repeat.py'),str(HERE)]
    lifecycle = runpy.run_path(str(HERE/'readback-operation-repeat.py'),run_name='lifecycle_validation')
    fanout = runpy.run_path(str(HERE/'readback-fanout.py'),run_name='fanout_validation')
finally:
    sys.argv = saved
manifest = parse_strict_json_bytes(manifest_path.read_bytes(),label='capsule manifest')
observed = {}
groups = defaultdict(list)
memory = defaultdict(list)
spans = effects_count = controls = witness_exchanges = 0

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check_stats(summary,values):
    ordered=sorted(values)
    n=len(ordered)
    assert n>0 and summary['samples']==n
    assert summary['minimum']==ordered[0] and summary['maximum']==ordered[-1]
    assert summary['median']==(ordered[(n-1)//2]+ordered[n//2])/2
    expected=ordered[(95*n+99)//100-1] if n>=20 else None
    assert summary['empirical_p95_nearest_rank']==expected

with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist())==len(manifest) and set(archive.namelist())==set(manifest)
    for name,expected in manifest.items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
    def read(name):
        return parse_strict_json_bytes(archive.read(name),label=name)
    protocol=read('experiment/PROTOCOL.json')
    completion=read('experiment/RESULT.json')
    assert protocol['planned_before_execution'] is True and completion['completed'] is True
    assert len(protocol['plan'])==len(completion['cohorts'])==completion['completed_cohorts']==16
    for index,(planned,record) in enumerate(zip(protocol['plan'],completion['cohorts'],strict=True)):
        assert all(record[k]==v for k,v in planned.items()) and record['completed'] is True
        prefix=f'cohorts/{index+1:02d}/'
        for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
            assert sha(archive.read(prefix+name))==record[key]
        run,value,original=[read(prefix+name) for name in ('RUN.json','RESULT.json','READBACK.json')]
        assert run['completed'] is True and run['performance_qualified'] is False and run['concurrent_task_processes']==[]
        assert run['source_commit']==protocol['source_commit']=='5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
        assert run['binary_sha256']==protocol['binary_sha256'][record['kind']]
        assert read(prefix+'runtime.json')['returncode']==0 and archive.read(prefix+'runtime.stderr')==b''
        for boundary in ('host-before','host-after'):
            assert read(f'experiment/step-{index+1:02d}/{boundary}.json')['concurrent_qualification_processes']==[]
        stdout=archive.read(prefix+'runtime.stdout')
        assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;',stdout,re.M)
        trace=[parse_strict_json_bytes(row,label='raw emitted span') for row in re.findall(rb'OPERATION_RESOURCE_SPAN (.+)$',stdout,re.M)]
        effect_prefix=prefix+'public-effects/'
        effects={name.removeprefix(effect_prefix):archive.read(name) for name in manifest if name.startswith(effect_prefix)}
        actual=(lifecycle['validate'](value,trace,effects) if record['kind']=='lifecycle'
            else fanout['validate'](value,trace,effects,read(prefix+'PUBLIC_CONTEXT.json')))
        assert actual==original['validation']
        observed[f'{index+1:02d}']={'kind':record['kind'],'profile':record['profile'],'label':record['label'],
            'spans':actual['spans'],'effects':actual['effects'],'witness_exchanges':actual['witness_exchanges'],
            'result_sha256':record['result_sha256']}
        spans+=actual['spans'];effects_count+=actual['effects'];witness_exchanges+=actual['witness_exchanges']
        controls+=len(original['altered_observation_controls'])
        for row in value['spans']:
            out=row['outcome'];ordinary=row['operation'] in ('send_confirmed','deliver_account_member')
            key=(record['kind'],record['profile'],row['operation'],
                out['epoch'] if ordinary else None,out['payload_bytes'] if ordinary else None,
                out['associated_data_bytes'] if ordinary else None,
                out['member_order'] if row['operation']=='deliver_account_member' else None)
            groups[key].append({'round':record['round'],'elapsed_ns':row['elapsed_ns'],
                'cpu_user_us':row['cpu_user_us'],'cpu_system_us':row['cpu_system_us'],
                'witness_exchanges':row['witness_after']['requests']-row['witness_before']['requests'],
                'witness_framed_bytes':row['witness_after']['framed_bytes']-row['witness_before']['framed_bytes']})
        for row in value['resources']:
            item=dict(row)
            if record['kind']=='lifecycle':
                item['journal_database_bytes']=[item.pop('initiator_database_bytes'),item.pop('responder_database_bytes')]
            memory[(record['kind'],record['profile'],row['stage'])].append({'round':record['round'],**item})
    operations=read('analysis/OPERATION_SUMMARY.json')
    assert len(operations)==len(groups)
    for summary in operations:
        key=tuple(summary[k] for k in ('kind','profile','operation','epoch','payload_bytes','associated_data_bytes','member_order'))
        rows=groups.pop(key)
        assert summary['all_samples']==rows
        for field in ('elapsed_ns','cpu_user_us','cpu_system_us'):
            check_stats(summary[field],[row[field] for row in rows])
        for field in ('witness_exchanges','witness_framed_bytes','round'):
            key={'witness_exchanges':'witness_exchange_distribution','witness_framed_bytes':'witness_framed_byte_distribution','round':'round_sample_counts'}[field]
            expected={str(k):v for k,v in Counter(row[field] for row in rows).items()}
            assert summary[key]==expected
    assert not groups
    memories=read('analysis/MEMORY_SUMMARY.json')
    assert len(memories)==len(memory)
    for summary in memories:
        rows=memory.pop((summary['kind'],summary['profile'],summary['stage']))
        assert summary['all_samples']==rows
        expected={field:max(row[field] for row in rows) for field in
            ('resident_bytes','physical_footprint_bytes','malloc_size_in_use_bytes','malloc_size_allocated_bytes')}
        expected['journal_database_bytes']=[max(row['journal_database_bytes'][i] for row in rows)
            for i in range(2 if summary['kind']=='lifecycle' else 3)]
        assert summary['observed_stage_maximums']==expected
    assert not memory
    summary=read('analysis/SUMMARY.json')
    assert spans==summary['spans']==1560 and effects_count==summary['business_effects']==600
    assert controls==summary['altered_input_controls']==432 and witness_exchanges==summary['witness_exchanges']==10452
    assert summary['performance_qualified'] is False and summary['release_claim_eligible'] is False
record={'archive_sha256':sha(archive_path.read_bytes()),'members_verified':len(manifest),'cohorts':observed,
    'spans':spans,'business_files_verified':effects_count,'negative_control_receipts_verified':controls,
    'negative_controls_reexecuted':False,'witness_exchanges':witness_exchanges,
    'operation_groups_recomputed':len(operations),'memory_groups_recomputed':len(memories),'all_samples_retained':True,
    'private_runtime_accessed':False,'native_workload_rerun':False,
    'performance_qualified':False,'release_claim_eligible':False}
with output_path.open('x') as stream:
    stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='cohorts'}))
