from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import time

import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
STAGE = REPO / 'target/continuity-operation-resources-20261105'
label, profile = sys.argv[1:]
assert re.fullmatch(r'validation-(?:local|witness)-[0-9]{2}', label) and profile in {'local', 'witness'}
build_file = STAGE / 'build-02/OBSERVER_BUILD.json'
build = json.loads(build_file.read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (build['source_commit'], False)
outside = Path(json.loads((STAGE / 'build-02/LOCATION.json').read_bytes())['path'])
consumer = outside / 'observer'
binary = Path(build['binary'])
assert sdk.snapshot(binary, maximum=256 * 1024**2).sha256 == build['binary_sha256']
for name, digest in build['observer_source'].items():
    assert sdk.snapshot(consumer / name).sha256 == digest
OUT = STAGE / label
OUT.mkdir(mode=0o700)
private = outside / (label + '-private')
private.mkdir(mode=0o700)
env = {k: v for k, v in os.environ.items() if not k.startswith(('DYLD_', 'LD_', 'QPC_', 'QPERIAPT_'))}
env.update(QPC_JOURNAL_PROFILE=profile, QPC_JOURNAL_OUTPUT=str(OUT / 'RESULT.json'),
    QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(private / 'installation'), RUST_BACKTRACE='1')
processes = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pcpu,pmem,etime,comm'], check=True,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
assert processes.stderr == b''
concurrent = [line for line in processes.stdout.decode().splitlines()
    if re.search(r'qperiapt-continuity-package-|/(?:rustc|cargo|java)$', line)]
record = {'completed': False, 'source_commit': build['source_commit'], 'profile': profile,
    'binary_sha256': build['binary_sha256'], 'build_report_sha256': sdk.snapshot(build_file).sha256,
    'observer_source': build['observer_source'], 'private_runtime': str(private),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'platform': platform.platform(), 'machine': platform.machine(), 'load_before': os.getloadavg(),
    'allocator_environment': {k: v for k, v in os.environ.items() if k.startswith('Malloc')},
    'concurrent_task_processes': concurrent,
    'host_controls': 'Functional observer validation only. Other qualification processes may overlap; no power, thermal, allocator or other application controls were changed.',
    'performance_qualified': False, 'release_claim_eligible': False,
    'scope': 'Validate the installed lifecycle observer and retain all raw numbers without treating this smoke run as a resource budget or a controlled performance comparison.'}
started = time.monotonic()
try:
    hardware = sdk.command(['/usr/sbin/sysctl', 'hw.model', 'hw.ncpu', 'hw.memsize', 'machdep.cpu.brand_string'],
        OUT / 'hardware', SOURCE, environment=env)
    record['hardware'] = hardware.decode()
    stdout = sdk.command(['/usr/bin/time', '-l', '-o', str(OUT / 'time.txt'), str(binary),
        '--exact', 'measure_installed_lifecycle', '--nocapture', '--test-threads=1'],
        OUT / 'runtime', consumer, environment=env)
    assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out;', stdout, re.M)
    assert ('OPERATION_RESOURCE_COMPLETE profile=' + profile + ' ordinary=48 effects=49').encode() in stdout
    result = json.loads((OUT / 'RESULT.json').read_bytes())
    assert result['completed'] is True and result['profile'] == profile and result['ordinary_sends'] == 48
    assert len(result['effects']) == result['server']['effects'] == 49 and result['server']['calls'] == 50
    assert len(result['spans']) == 106
    for name, digest in build['observer_source'].items():
        assert sdk.snapshot(consumer / name).sha256 == digest
    assert sdk.snapshot(binary, maximum=256 * 1024**2).sha256 == build['binary_sha256']
    record.update(completed=True, result_sha256=sdk.snapshot(OUT / 'RESULT.json', maximum=32 * 1024**2).sha256)
except BaseException as error:
    record['failure'] = str(error)
    raise
finally:
    record.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        seconds=time.monotonic() - started, load_after=os.getloadavg(), private_runtime_preserved=True)
    sdk.write_json(OUT / 'RUN.json', record)
print(json.dumps({'completed': record['completed'], 'profile': profile, 'performance_qualified': False}), flush=True)
