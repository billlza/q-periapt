from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = sdk.ROOT
REPO = SOURCE.parents[2]
DRIVERS = SOURCE/'target/current-rust-readback'
OUT = REPO/'target/continuity-resource-repeats-20261106'
STAGES = {
    'lifecycle':REPO/'target/continuity-operation-resources-20261105',
    'fanout':REPO/'target/continuity-fanout-resources-20261106',
}
assert sdk.inspect_package_source(SOURCE,allow_dirty=False) == ('5678d1019861fa1b04f3a219ba3fde7e0ddaaba8',False)
OUT.mkdir()
original = (STAGES['lifecycle']/'readback.py').read_bytes()
old = b'ROOT = Path(__file__).resolve().parent'
assert original.count(old) == 1
adapted = original.replace(old,b'ROOT = Path(sys.argv[1]).resolve()\nsys.argv.pop(1)')
reader = DRIVERS/'readback-operation-repeat.py'
with reader.open('xb') as stream:
    stream.write(adapted)
sdk.write_json(OUT/'READER_ADAPTATION.json',{
    'original_sha256':hashlib.sha256(original).hexdigest(),
    'adapted_sha256':hashlib.sha256(adapted).hexdigest(),
    'change':'Only select the original stage from one explicit absolute argument; preserve all validation and altered-input controls.'})
cases = [('lifecycle','local'),('lifecycle','witness'),('fanout','local'),('fanout','witness')]
orders = [(0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1)]
plan = []
for round_index,order in enumerate(orders):
    for position,case_index in enumerate(order):
        kind,profile = cases[case_index]
        label = 'validation-'+profile+('-peer' if kind=='fanout' else '')+f'-{round_index+2:02d}'
        assert not (STAGES[kind]/label).exists()
        plan.append({'round':round_index+1,'position':position+1,'kind':kind,'profile':profile,
            'label':label,'directory':str(STAGES[kind]/label)})
builds = {kind:json.loads((stage/('build-02' if kind=='lifecycle' else 'build-01')/'OBSERVER_BUILD.json').read_bytes())
    for kind,stage in STAGES.items()}
protocol = {'planned_before_execution':True,'source_commit':'5678d1019861fa1b04f3a219ba3fde7e0ddaaba8',
    'rounds':4,'order':'Four predeclared balanced orders; each case occupies each position once.',
    'plan':plan,'binary_sha256':{kind:value['binary_sha256'] for kind,value in builds.items()},
    'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'protocol':'Run the unchanged installed observers sequentially, retain every cohort, validate every result with the existing independent reader, record load and power/thermal reports at both boundaries, stop on any failure or concurrent qualification process.',
    'scope':'Repeated Apple Silicon baseline after JNI completion. No power/allocator settings changed, desktop applications remain uncontrolled. Empirical distributions are scoped to these workloads; no production p99, mobile energy, frozen product budget or release qualification.',
    'performance_qualified':False,'release_claim_eligible':False}
sdk.write_json(OUT/'PROTOCOL.json',protocol)
records = []
started = datetime.datetime.now(datetime.timezone.utc).isoformat()

def host_snapshot(prefix):
    result = subprocess.run(['/bin/ps','-axo','pid,ppid,pcpu,pmem,etime,comm'],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=30)
    assert result.stderr == b''
    concurrent = [line for line in result.stdout.decode().splitlines()
        if re.search(r'qperiapt-continuity-package-|qperiapt-(?:operation|fanout)-resources-.*/build/|/(?:rustc|cargo|java)$',line)]
    snapshot = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),
        'concurrent_qualification_processes':concurrent}
    for option,name in [('batt','power'),('therm','thermal')]:
        raw = subprocess.run(['/usr/bin/pmset','-g',option],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            check=True,timeout=30)
        assert raw.stderr == b''
        snapshot[name+'_report'] = raw.stdout.decode()
    sdk.write_json(prefix.with_suffix('.json'),snapshot)
    assert not concurrent, 'another qualification process overlaps this baseline'
    return snapshot

def execute(argv,prefix):
    with prefix.with_suffix('.stdout').open('xb') as stdout,prefix.with_suffix('.stderr').open('xb') as stderr:
        run = subprocess.run(argv,cwd=SOURCE,env=os.environ.copy(),stdout=stdout,stderr=stderr)
    sdk.write_json(prefix.with_suffix('.json'),{'argv':argv,'cwd':str(SOURCE),'returncode':run.returncode})
    assert run.returncode == 0, str(prefix)+': command failed'
    assert prefix.with_suffix('.stderr').read_bytes() == b'', str(prefix)+': unexpected diagnostics'

try:
    for index,case in enumerate(plan):
        step = OUT/f'step-{index+1:02d}'
        step.mkdir()
        before = host_snapshot(step/'host-before')
        kind,profile,label = case['kind'],case['profile'],case['label']
        runner = 'run-operation-smoke.py' if kind=='lifecycle' else 'run-fanout-smoke.py'
        argv = ['sh',str(SOURCE/'artifact/python-run.sh'),str(DRIVERS/runner),label,profile]
        if kind=='fanout':
            argv.append('peer')
        begin = time.monotonic()
        execute(argv,step/'run')
        after = host_snapshot(step/'host-after')
        selected_reader = reader if kind=='lifecycle' else DRIVERS/'readback-fanout.py'
        execute(['sh',str(SOURCE/'artifact/python-run.sh'),str(selected_reader),str(STAGES[kind]),label],step/'readback')
        directory = Path(case['directory'])
        run = json.loads((directory/'RUN.json').read_bytes())
        actual = json.loads((directory/'READBACK.json').read_bytes())
        assert run['completed'] is True and run['concurrent_task_processes'] == []
        assert run['binary_sha256'] == protocol['binary_sha256'][kind]
        record = {**case,'completed':True,'controller_seconds':time.monotonic()-begin,
            'run_sha256':hashlib.sha256((directory/'RUN.json').read_bytes()).hexdigest(),
            'result_sha256':run['result_sha256'],
            'readback_sha256':hashlib.sha256((directory/'READBACK.json').read_bytes()).hexdigest(),
            'spans':actual['validation']['spans'],'effects':actual['validation']['effects'],
            'witness_exchanges':actual['validation']['witness_exchanges']}
        records.append(record)
        sdk.write_json(OUT/'PROGRESS.json',{'started_utc':started,'completed_cohorts':len(records),'planned_cohorts':16,
            'completed':False,'cohorts':records})
        print(json.dumps(record),flush=True)
    sdk.write_json(OUT/'RESULT.json',{'completed':True,'started_utc':started,
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'completed_cohorts':16,'cohorts':records,'performance_qualified':False,'release_claim_eligible':False})
except BaseException as error:
    sdk.write_json(OUT/'FAILURE.json',{'completed':False,'failure':str(error),'completed_cohorts':len(records),
        'cohorts':records,'failed_or_partial_evidence_preserved':True})
    raise
