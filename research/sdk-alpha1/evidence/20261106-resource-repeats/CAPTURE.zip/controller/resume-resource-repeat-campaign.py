from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = sdk.ROOT
REPO = SOURCE.parents[2]
DRIVERS = SOURCE/'target/current-rust-readback'
OUT = REPO/'target/continuity-resource-repeats-20261106'
STAGES = {
    'lifecycle':REPO/'target/continuity-operation-resources-20261105',
    'fanout':REPO/'target/continuity-fanout-resources-20261106',
}
assert sdk.inspect_package_source(SOURCE,allow_dirty=False) == ('5678d1019861fa1b04f3a219ba3fde7e0ddaaba8',False)
protocol = json.loads((OUT/'PROTOCOL.json').read_bytes())
failure = json.loads((OUT/'FAILURE.json').read_bytes())
assert protocol['driver_sha256'] == hashlib.sha256((DRIVERS/'run-resource-repeat-campaign.py').read_bytes()).hexdigest()
assert failure['completed_cohorts'] == 2 and len(failure['cohorts']) == 2
assert "File exists" in failure['failure'] and "PROGRESS.json" in failure['failure']
plan = protocol['plan']
assert len(plan) == 16
records = failure['cohorts'].copy()
started = json.loads((OUT/'PROGRESS.json').read_bytes())['started_utc']
reader = DRIVERS/'readback-operation-repeat.py'
adaptation = json.loads((OUT/'READER_ADAPTATION.json').read_bytes())
assert hashlib.sha256(reader.read_bytes()).hexdigest() == adaptation['adapted_sha256']
for index,record in enumerate(records):
    assert all(record[key] == value for key,value in plan[index].items())
    directory = Path(record['directory'])
    for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
        assert hashlib.sha256((directory/name).read_bytes()).hexdigest() == record[key]
    run = json.loads((directory/'RUN.json').read_bytes())
    assert run['completed'] is True and run['concurrent_task_processes'] == []
    assert run['binary_sha256'] == protocol['binary_sha256'][record['kind']]
    for label in ('host-before','host-after'):
        assert json.loads((OUT/f'step-{index+1:02d}'/(label+'.json')).read_bytes())['concurrent_qualification_processes'] == []
for case in plan[len(records):]:
    assert not Path(case['directory']).exists()
sdk.write_json(OUT/'RESUME.json',{'resumed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_driver_sha256':protocol['driver_sha256'],
    'resume_driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'existing_verified_cohorts':2,'remaining_predeclared_cohorts':14,
    'reason':'The exclusive JSON writer rejected the second shared PROGRESS path after the second native run and independent readback succeeded. Keep both cohorts and the failure; use a fresh step-local progress path for each remaining step. No workload, gate, timeout, sample or order changes.'})

def host_snapshot(prefix):
    result = subprocess.run(['/bin/ps','-axo','pid,ppid,pcpu,pmem,etime,comm'],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=30)
    assert result.stderr == b''
    concurrent = [line for line in result.stdout.decode().splitlines()
        if re.search(r'qperiapt-continuity-package-|qperiapt-(?:operation|fanout)-resources-.*/build/|/(?:rustc|cargo|java)$',line)]
    snapshot = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),
        'concurrent_qualification_processes':concurrent}
    for option,name in [('batt','power'),('therm','thermal')]:
        raw = subprocess.run(['/usr/bin/pmset','-g',option],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            check=True,timeout=30)
        assert raw.stderr == b''
        snapshot[name+'_report'] = raw.stdout.decode()
    sdk.write_json(prefix.with_suffix('.json'),snapshot)
    assert not concurrent, 'another qualification process overlaps this baseline'
    return snapshot

def execute(argv,prefix):
    with prefix.with_suffix('.stdout').open('xb') as stdout,prefix.with_suffix('.stderr').open('xb') as stderr:
        run = subprocess.run(argv,cwd=SOURCE,env=os.environ.copy(),stdout=stdout,stderr=stderr)
    sdk.write_json(prefix.with_suffix('.json'),{'argv':argv,'cwd':str(SOURCE),'returncode':run.returncode})
    assert run.returncode == 0, str(prefix)+': command failed'
    assert prefix.with_suffix('.stderr').read_bytes() == b'', str(prefix)+': unexpected diagnostics'

try:
    for index,case in enumerate(plan[2:], start=2):
        step = OUT/f'step-{index+1:02d}'
        step.mkdir()
        before = host_snapshot(step/'host-before')
        kind,profile,label = case['kind'],case['profile'],case['label']
        runner = 'run-operation-smoke.py' if kind=='lifecycle' else 'run-fanout-smoke.py'
        argv = ['sh',str(SOURCE/'artifact/python-run.sh'),str(DRIVERS/runner),label,profile]
        if kind=='fanout':
            argv.append('peer')
        begin = time.monotonic()
        execute(argv,step/'run')
        after = host_snapshot(step/'host-after')
        selected_reader = reader if kind=='lifecycle' else DRIVERS/'readback-fanout.py'
        execute(['sh',str(SOURCE/'artifact/python-run.sh'),str(selected_reader),str(STAGES[kind]),label],step/'readback')
        directory = Path(case['directory'])
        run = json.loads((directory/'RUN.json').read_bytes())
        actual = json.loads((directory/'READBACK.json').read_bytes())
        assert run['completed'] is True and run['concurrent_task_processes'] == []
        assert run['binary_sha256'] == protocol['binary_sha256'][kind]
        record = {**case,'completed':True,'controller_seconds':time.monotonic()-begin,
            'run_sha256':hashlib.sha256((directory/'RUN.json').read_bytes()).hexdigest(),
            'result_sha256':run['result_sha256'],
            'readback_sha256':hashlib.sha256((directory/'READBACK.json').read_bytes()).hexdigest(),
            'spans':actual['validation']['spans'],'effects':actual['validation']['effects'],
            'witness_exchanges':actual['validation']['witness_exchanges']}
        records.append(record)
        sdk.write_json(step/'PROGRESS.json',{'started_utc':started,'completed_cohorts':len(records),'planned_cohorts':16,
            'completed':False,'cohorts':records})
        print(json.dumps(record),flush=True)
    sdk.write_json(OUT/'RESULT.json',{'completed':True,'started_utc':started,
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'completed_cohorts':16,'cohorts':records,'performance_qualified':False,'release_claim_eligible':False})
except BaseException as error:
    sdk.write_json(OUT/'RESUME_FAILURE.json',{'completed':False,'failure':str(error),'completed_cohorts':len(records),
        'cohorts':records,'failed_or_partial_evidence_preserved':True})
    raise
