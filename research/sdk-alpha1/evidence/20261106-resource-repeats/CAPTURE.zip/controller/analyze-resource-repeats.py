from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math
import statistics
import sys
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = sdk.ROOT
REPO = SOURCE.parents[2]
ROOT = REPO/'target/continuity-resource-repeats-20261106'
protocol = json.loads((ROOT/'PROTOCOL.json').read_bytes())
completion = json.loads((ROOT/'RESULT.json').read_bytes())
assert protocol['planned_before_execution'] is True and completion['completed'] is True
assert len(protocol['plan']) == completion['completed_cohorts'] == len(completion['cohorts']) == 16
OUT = ROOT/'analysis-01'
OUT.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    from evidence_io import parse_strict_json_bytes
    return parse_strict_json_bytes(path.read_bytes(),label=str(path))

def stats(values):
    assert values and all(type(n) is int and n >= 0 for n in values)
    ordered = sorted(values)
    count = len(ordered)
    return {'samples':count,'minimum':ordered[0],'median':statistics.median(ordered),
        'empirical_p95_nearest_rank':ordered[math.ceil(.95*count)-1] if count>=20 else None,
        'maximum':ordered[-1],
        'tail_scope':'Empirical nearest-rank p95 only when n>=20; not a production quantile guarantee. All samples retained.'}

groups = defaultdict(list)
cohorts = []
memory = defaultdict(list)
files = {}
source_ids = set()
total_spans = total_effects = total_controls = total_witness = 0
for index,(planned,record) in enumerate(zip(protocol['plan'],completion['cohorts'],strict=True)):
    assert all(record[key] == value for key,value in planned.items())
    assert record['completed'] is True
    directory = Path(record['directory'])
    for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
        raw = (directory/name).read_bytes()
        assert sha(raw) == record[key]
        files[f'cohorts/{index+1:02d}/{name}'] = {'bytes':len(raw),'sha256':sha(raw)}
    run,result,readback = [load(directory/name) for name in ('RUN.json','RESULT.json','READBACK.json')]
    assert run['completed'] is True and result['completed'] is True and run['performance_qualified'] is False
    assert run['concurrent_task_processes'] == []
    assert run['binary_sha256'] == protocol['binary_sha256'][record['kind']]
    source_ids.add(run['source_commit'])
    assert readback['result_sha256'] == record['result_sha256']
    assert readback['validation']['spans'] == record['spans'] == len(result['spans'])
    assert readback['validation']['effects'] == record['effects'] == len(result['effects'])
    assert load(directory/'runtime.json')['returncode'] == 0 and (directory/'runtime.stderr').read_bytes() == b''
    host = [load(ROOT/f'step-{index+1:02d}'/(boundary+'.json')) for boundary in ('host-before','host-after')]
    assert all(row['concurrent_qualification_processes'] == [] for row in host)
    total_spans += len(result['spans'])
    total_effects += len(result['effects'])
    total_controls += len(readback['altered_observation_controls'])
    total_witness += readback['validation']['witness_exchanges']
    cohorts.append({**planned,'run_seconds':run['seconds'],'load_before':host[0]['load'],'load_after':host[1]['load'],
        'utc_before':host[0]['utc'],'utc_after':host[1]['utc'],'power_before':host[0]['power_report'],
        'power_after':host[1]['power_report'],'thermal_before':host[0]['thermal_report'],
        'thermal_after':host[1]['thermal_report'],'allocator_environment':run['allocator_environment'],
        'hardware':run['hardware'],'spans':len(result['spans']),'effects':len(result['effects']),
        'witness_exchanges':readback['validation']['witness_exchanges'],
        'outside_measured_spans':readback['validation']['outside_measured_spans']})
    for row in result['spans']:
        outcome = row['outcome']
        ordinary = row['operation'] in ('send_confirmed','deliver_account_member')
        key = (record['kind'],record['profile'],row['operation'],
            outcome['epoch'] if ordinary else None,
            outcome['payload_bytes'] if ordinary else None,
            outcome['associated_data_bytes'] if ordinary else None,
            outcome['member_order'] if row['operation']=='deliver_account_member' else None)
        exchanges = row['witness_after']['requests']-row['witness_before']['requests']
        framed = row['witness_after']['framed_bytes']-row['witness_before']['framed_bytes']
        assert exchanges>=0 and framed==exchanges*7341
        groups[key].append({'round':record['round'],'elapsed_ns':row['elapsed_ns'],
            'cpu_user_us':row['cpu_user_us'],'cpu_system_us':row['cpu_system_us'],
            'witness_exchanges':exchanges,'witness_framed_bytes':framed})
    for row in result['resources']:
        item = dict(row)
        if record['kind']=='lifecycle':
            item['journal_database_bytes'] = [item.pop('initiator_database_bytes'),item.pop('responder_database_bytes')]
        memory[(record['kind'],record['profile'],row['stage'])].append({'round':record['round'],**item})
assert source_ids == {protocol['source_commit']}
assert total_spans == 1560 and total_effects == 600 and total_controls == 432
summaries = []
for key,rows in groups.items():
    kind,profile,operation,epoch,payload,ad,order = key
    summaries.append({'kind':kind,'profile':profile,'operation':operation,'epoch':epoch,
        'payload_bytes':payload,'associated_data_bytes':ad,'member_order':order,
        'elapsed_ns':stats([row['elapsed_ns'] for row in rows]),
        'cpu_user_us':stats([row['cpu_user_us'] for row in rows]),
        'cpu_system_us':stats([row['cpu_system_us'] for row in rows]),
        'witness_exchange_distribution':dict(sorted(Counter(row['witness_exchanges'] for row in rows).items())),
        'witness_framed_byte_distribution':dict(sorted(Counter(row['witness_framed_bytes'] for row in rows).items())),
        'round_sample_counts':dict(sorted(Counter(row['round'] for row in rows).items())),
        'all_samples':rows})
memory_summaries = []
for (kind,profile,stage),rows in memory.items():
    maximums = {field:max(row[field] for row in rows) for field in
        ('resident_bytes','physical_footprint_bytes','malloc_size_in_use_bytes','malloc_size_allocated_bytes')}
    widths = {len(row['journal_database_bytes']) for row in rows}
    assert widths == {2 if kind=='lifecycle' else 3}
    maximums['journal_database_bytes'] = [max(row['journal_database_bytes'][i] for row in rows)
        for i in range(next(iter(widths)))]
    memory_summaries.append({'kind':kind,'profile':profile,'stage':stage,'observed_stage_maximums':maximums,'all_samples':rows})
sdk.write_json(OUT/'INPUTS.json',files)
sdk.write_json(OUT/'OPERATION_SUMMARY.json',summaries)
sdk.write_json(OUT/'MEMORY_SUMMARY.json',memory_summaries)
sdk.write_json(OUT/'SUMMARY.json',{'source_commit':protocol['source_commit'],'completed_cohorts':16,
    'spans':total_spans,'business_effects':total_effects,'altered_input_controls':total_controls,
    'witness_exchanges':total_witness,'cohorts':cohorts,
    'all_samples_retained':True,'no_other_qualification_processes_at_boundaries':True,
    'background_desktop_applications_controlled':False,'performance_qualified':False,'release_claim_eligible':False,
    'controller_failure_retained':'Initial recorder failed only on a second exclusive PROGRESS write; resume kept its two successful native cohorts and continued the remaining original order.',
    'scope':'Observed repeated baseline for the recorded M4 Max host and existing installed workloads; four independent setups per case. No production-tail, per-client memory, mobile-energy, maximum-capacity or frozen resource-budget claim.'})
print(json.dumps({'cohorts':16,'spans':total_spans,'effects':total_effects,'controls':total_controls,
    'witness_exchanges':total_witness,'operation_groups':len(summaries),'memory_groups':len(memory_summaries)}))
