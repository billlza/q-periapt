"""Reuse the inspected parser/trace checks in a fresh standalone witness verifier."""
from pathlib import Path
import rust_sdk_profile as sdk
stage = Path(__file__).resolve().parent
negative = (stage / "verify-witness-12.py").read_text()
prelude = negative[:negative.index("canonical = parsed(")].replace("-parse-12", "-parse-17")
term_helpers = negative[negative.index("def tree(term):"):negative.index('_, target = one("SessionStorage"')]
causal_helpers = negative[negative.index("edges = {}\n"):negative.index('for first, last in (("#c"')]
body = '''canonical = parsed("canonical", stage / "shared-storage-01.spthy")
before = parsed("input", stage / "active-use-14.spthy")
after = parsed("certificate", stage / "active-replay-16-proof.spthy")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
lemma = "recovery_with_shared_storage_is_executable"
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after), "model changed")
sdk.require(queries(before) == queries(after), "full witness declarations changed")
sdk.require(queries(canonical)[main] == queries(after)[main], "main theorem changed")
earlier = after[:after.index("lemma " + lemma)]
sdk.require(not any("reuse" in value or "sources" in value for value in re.findall(r"(?s)lemma\\s+\\w+\\s+\\[([^\\]]+)\\]", earlier)), "witness has reusable premises")
search = json.loads((stage / "active-use-15-TERMINAL.json").read_text())
replay = json.loads((stage / "active-replay-16-TERMINAL.json").read_text())
sdk.require(search["accepted"] and replay["accepted"] and not any(arg.startswith("--prove") for arg in replay["argv"]), "witness not independently replayed")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "active-use-15-proof.spthy").sha256, "input certificate changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "active-replay-16-proof.spthy").sha256, "output certificate changed")
snapshot = read_regular_snapshot(stage / "active-replay-16-traces.json", maximum=160*1024**2, label="symbolic trace")
graphs = json.loads(snapshot.data)["graphs"]
sdk.require(len(graphs) == 1, "unexpected trace inventory")
graph = graphs[0]
actions = [(node, act) for node in graph["jgNodes"] for act in node.get("jgnMetadata", {}).get("jgnActs", [])]
'''
body += term_helpers
body += '''_, target = one("SessionStorage", "#target")
_, sibling = one("SessionStorage", "#sibling")
sdk.require(target[0] != sibling[0] and target[1] == sibling[2] and len({target[1], target[2], sibling[1]}) == 3, "shared-key ownership differs")
for event, node in (("Cut", "#c"), ("KeyReserved", "#g"), ("EncapReserved", "#e")):
    sdk.require(one(event, node)[1] == (target[0],), "wrong target event")
sdk.require(one("OfferCommitted", "#offer")[1] == (sibling[0],), "wrong sibling offer")
reserved, reservation = one("EncapReserved", "#reserved")
sdk.require(reservation == (sibling[0],) and reserved["jgnLabel"] == "Response_Reservation_4", "sibling did not use responder storage")
wrap = [tuple(map(tree, fact["jgnFactTerms"])) for fact in reserved["jgnMetadata"]["jgnPrems"] if fact["jgnFactName"] == "Wrap"]
sdk.require(wrap == [(sibling[0], ("constant", "'B'"), target[1])], "sibling reservation did not use shared key")
stored = [tuple(map(tree, fact["jgnFactTerms"])) for fact in reserved["jgnMetadata"]["jgnConcs"] if fact["jgnFactName"] == "Stored"]
sdk.require(len(stored) == 1 and stored[0][:3] == (sibling[0], ("constant", "'B'"), ("constant", "'4'")), "sibling stored state missing")
_, message = one("Message", "#m")
sdk.require(message[:2] == (target[0], ("constant", "'A'")), "wrong target message")
for node, role in (("#a", "'A'"), ("#b", "'B'")):
    sdk.require(one("Confirmed", node)[1] == (target[0], ("constant", role)), "target confirmation missing")
sdk.require(not any(act["jgnFactName"] in ("IdentityLeak", "IdentityKeyLeak", "EntropyLeak", "Snapshot") for _, act in actions), "unexpected disclosure")
'''
body += causal_helpers
body += '''for first, last in (("#c", "#g"), ("#c", "#e"), ("#offer", "#reserved"), ("#reserved", "#m"), ("#a", "#m"), ("#b", "#m")):
    sdk.require(precedes(first, last), "missing causal path: " + first + " < " + last)
sdk.write_json(stage / "EXECUTION_17.json", {
    "completed": True, "search_steps": search["results"][lemma]["steps"],
    "replay_steps": replay["results"][lemma]["steps"], "certificate_sha256": replay["output_sha256"],
    "trace_sha256": snapshot.sha256, "trace_bytes": snapshot.size,
    "complete_model_and_queries_unchanged": True, "main_formula_unchanged": True,
    "both_target_confirmations_before_message": True,
    "shared_key_used_for_target_initiator_and_sibling_responder_storage": True,
    "three_distinct_wrapping_keys_with_one_cross_role_overlap": True,
    "no_identity_entropy_or_snapshot_disclosure": True, "causal_paths_verified": True,
    "existence_of_normal_execution_is_not_secrecy_proof": True, "release_claim_eligible": False,
})
print("Normal execution verified with both confirmations and actual cross-session shared-key storage use")
'''
with (stage / "verify-positive-17.py").open("x") as stream:
    stream.write(prelude + body)
sdk.write_json(stage / "POSITIVE_VERIFIER_17.json", {"negative_verifier_sha256": sdk.snapshot(stage / "verify-witness-12.py").sha256,
               "output_sha256": sdk.snapshot(stage / "verify-positive-17.py").sha256})
