"""Check that the allocation control changed only Setup and retained every query."""
from pathlib import Path
stage = Path(__file__).resolve().parent
prelude = (stage / "verify-witness-12.py").read_text().split("canonical = parsed(", 1)[0].replace("-parse-12", "-parse-18")
body = '''base = (stage / "witnesses-01.spthy").read_text()
control_path = stage / "independent-control-09.spthy"
control = control_path.read_text()
source_receipt = json.loads((stage / "CONTROL_INPUT_09.json").read_text())
sdk.require(sdk.snapshot(stage / "witnesses-01.spthy").sha256 == source_receipt["input_sha256"], "base changed")
sdk.require(sdk.snapshot(control_path).sha256 == source_receipt["output_sha256"], "control changed")
def setup_span(text):
    start = text.index("rule Setup:")
    return start, text.index("\\nrule Cut:", start)
a, b = setup_span(base)
c, d = setup_span(control)
sdk.require(control[:c] + base[a:b] + control[d:] == base, "control changed more than Setup")
sdk.require("Fr(~wa), Fr(~wb)" in control[c:d] and "!StorageKey" not in control[c:d], "independent allocation missing")
before = parsed("control-input", control_path)
after = parsed("control-certificate", stage / "independent-replay-11-proof.spthy")
sdk.require(operational_model(before) == operational_model(after) and queries(before) == queries(after), "control certificate changed model or queries")
sdk.require(base.split("\\nlemma ", 1)[1] == control.split("\\nlemma ", 1)[1], "attack query changed")
stale = json.loads((stage / "replay-03-TERMINAL.json").read_text())
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(stale["returncode"] == 0 and not stale["accepted"] and stale["results"][main]["status"] == "verified", "conditional replay control missing")
sdk.require(any(stale["results"][name]["status"] != "verified" for name in stale["required_verified_lemmas"]), "missing dependency control changed")
sdk.write_json(stage / "CONTROLS_18.json", {
    "completed": True,
    "independent_control_changes_only_setup_allocation": True,
    "same_full_attack_query": True,
    "independent_control_full_model_and_queries_replayed": True,
    "exit_zero_verified_main_with_incomplete_dependencies_rejected": True,
    "release_claim_eligible": False,
})
print("Independent-allocation and missing-dependency controls verified")
'''
with (stage / "controls-18.py").open("x") as stream:
    stream.write(prelude + body)
