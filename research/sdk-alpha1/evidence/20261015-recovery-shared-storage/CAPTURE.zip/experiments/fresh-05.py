"""Preserve every full query while replacing stale proof bodies with open goals."""
from pathlib import Path
import re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
source = stage / "replay-01.spthy"
text = source.read_text()
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
marks = list(pattern.finditer(text))
sdk.require(len(marks) == 24, "query inventory changed")
fresh = text[:marks[0].start()] + "\n\n".join(match.group() + "\nby sorry\n" for match in marks) + "\nend\n"
sdk.require([match.group() for match in pattern.finditer(fresh)] == [match.group() for match in marks], "query declarations changed")
with (stage / "fresh-05.spthy").open("x") as stream:
    stream.write(fresh)
sdk.write_json(stage / "FRESH_05.json", {
    "input_sha256": sdk.snapshot(source).sha256,
    "output_sha256": sdk.snapshot(stage / "fresh-05.spthy").sha256,
    "operational_model_and_all_queries_unchanged": True,
    "stale_replay_receipt": "replay-03-TERMINAL.json",
    "conditional_main_not_accepted": True,
    "release_claim_eligible": False,
})
print("Fresh proof goals prepared without changing rules, restrictions or query declarations")
