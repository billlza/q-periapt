"""Commit the scoped research result and validate its exact clean source identity."""
from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
base = "c6db533ec93062b2a9efaf43aa302aecc9f455cd"
public = "research/sdk-alpha1/evidence/20261015-recovery-shared-storage"
allowed = {
    "docs/SDK_0_2_RELEASE_READINESS.md", "docs/continuity/RECOVERY_DEPENDENCIES_V1.md",
    "research/continuity-recovery-symbolic/README.md", "research/continuity-recovery-symbolic/shared-storage.spthy",
    *(public + "/" + name for name in ("CAPTURE.json", "CAPTURE.zip", "READBACK.json", "README.md")),
}
def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd, text=True, timeout=60).strip()
sdk.require(git("rev-parse", "HEAD") == base and git("branch", "--show-current") == "lza/continuity-policy-roster", "source changed")
status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], text=True, timeout=60)
sdk.require({line[3:] for line in status.splitlines()} == allowed and not git("diff", "--cached", "--name-only"), "unrelated or staged changes")
capture = json.loads((root / public / "CAPTURE.json").read_text())
readback = json.loads((root / public / "READBACK.json").read_text())
sdk.require(readback["completed"] and readback["all_members_rehashed"] and capture["positive_shared_storage_recovery_unproved"], "evidence scope differs")
sdk.require(capture["capture_sha256"] == readback["capture_sha256"] == sdk.snapshot(root / public / "CAPTURE.zip", maximum=64*1024**2).sha256, "archive changed")
sdk.require(capture["model_sha256"] == sdk.snapshot(root / "research/continuity-recovery-symbolic/shared-storage.spthy").sha256, "model changed")
clone = root / "target/continuity-browser-publication/source"
sdk.require((clone / ".git").is_dir() and git("rev-parse", "HEAD", cwd=clone) == base
            and not git("status", "--porcelain", cwd=clone), "validation clone changed")
sdk.command(["git", "diff", "--check"], stage / "diff-25", root)
sdk.command(["git", "add", "--", *sorted(allowed)], stage / "stage-25", root)
sdk.command(["git", "diff", "--cached", "--check"], stage / "staged-25", root)
sdk.command(["git", "commit", "-m", "Model shared wrapping-key disclosure across sessions"], stage / "commit-25", root)
head = git("rev-parse", "HEAD")
sdk.require(not git("status", "--porcelain"), "main not clean")
sdk.command(["git", "fetch", str(root), head], stage / "fetch-25", clone)
sdk.command(["git", "merge", "--ff-only", head], stage / "merge-25", clone)
sdk.command([sys.executable, "-B", str(clone / "artifact/python_bootstrap.py"),
             str(clone / "artifact/source_results_assembler.py"), "ci-source-gate",
             "9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda",
             head, "--profile", "sdk-020"], stage / "source-gate-25", clone)
sdk.require(not git("status", "--porcelain", cwd=clone), "validation clone not clean")
sdk.write_json(stage / "CHECKPOINT_25.json", {
    "head": head, "main_and_validation_clone_clean": True, "source_gate": True,
    "positive_shared_storage_recovery_unproved": True, "archive_sha256": capture["capture_sha256"],
    "private_device_cohorts_remain_sealed": True, "pushed": False, "release_claim_eligible": False,
})
print(json.dumps({"head": head, "source_gate": True, "pushed": False}))
