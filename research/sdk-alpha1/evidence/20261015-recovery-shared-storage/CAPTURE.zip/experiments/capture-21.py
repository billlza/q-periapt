"""Archive only public symbolic evidence after every owned prover has terminated."""
from pathlib import Path
import hashlib
import json
import os
import zipfile
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
negative = json.loads((stage / "WITNESS_12.json").read_text())
normal = json.loads((stage / "EXECUTION_19.json").read_text())
controls = json.loads((stage / "CONTROLS_18.json").read_text())
sdk.require(negative["completed"] and normal["completed"] and controls["completed"], "missing witness/control evidence")
timeout = json.loads((stage / "fresh-06-TERMINAL.json").read_text())
sdk.require(timeout["timed_out"] and not timeout["accepted"] and timeout["returncode"] == -9,
            "whole-group search outcome changed")
helper = json.loads((stage / "traffic-20-TERMINAL.json").read_text())
helper_replay = json.loads((stage / "HELPER_23.json").read_text())
sdk.require(helper_replay["completed"] and helper_replay["main_recovery_theorem_unproved"], "helper replay incomplete")
dead_groups = []
for path in sorted(stage.glob("*-STARTED.json")):
    receipt = json.loads(path.read_text())
    try:
        os.killpg(receipt["pid"], 0)
    except ProcessLookupError:
        dead_groups.append(receipt["pid"])
    else:
        raise ValueError("owned prover process group remains live: " + str(receipt["pid"]))
sdk.write_json(stage / "CLEANUP_21.json", {"completed": True, "all_owned_prover_groups_absent": dead_groups,
               "no_process_killed_by_cleanup": True})
model = root / "research/continuity-recovery-symbolic/shared-storage.spthy"
sdk.require(sdk.snapshot(model).sha256 == sdk.snapshot(stage / "shared-storage-01.spthy").sha256, "public model differs")
public = root / "research/sdk-alpha1/evidence/20261015-recovery-shared-storage"
files = {"experiments/" + path.name: path for path in stage.iterdir()
         if path.is_file() and path.suffix in (".py", ".spthy", ".json", ".stdout", ".stderr", ".log")}
for relative in ("research/continuity-recovery-symbolic/key-scoped.spthy",
                 "research/continuity-recovery-symbolic/shared-storage.spthy",
                 "research/continuity-identity-candidate/src/durable.rs",
                 "research/continuity-identity-candidate/src/crypto/persistence.rs"):
    files["source/" + relative] = root / relative
files["source/key-scoped-positive-certificate.spthy"] = root / "target/continuity-recovery-key-scope-20261015/final-37-proof.spthy"
files["tools/TOOLS_08.json"] = root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json"
digests = {}
total = 0
archive = public / "CAPTURE.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(files.items()):
        maximum = 160 * 1024**2 if name.endswith("-traces.json") else 32 * 1024**2
        snapshot = read_regular_snapshot(path, maximum=maximum, label="public symbolic evidence")
        total += snapshot.size
        # Six public trace graphs account for about 626 MB before compression.
        sdk.require(total <= 768 * 1024**2, "symbolic evidence exceeds measured total bound")
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(info, snapshot.data)
        digests[name] = snapshot.sha256
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(digests) and set(zipped.namelist()) == set(digests), "archive inventory differs")
    for name, digest in digests.items():
        value = hashlib.sha256()
        with zipped.open(name) as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        sdk.require(value.hexdigest() == digest, "archive readback differs")
archive_digest = sdk.snapshot(archive, maximum=64 * 1024**2).sha256
sdk.write_json(public / "CAPTURE.json", {
    "capture_sha256": archive_digest, "members": digests, "expanded_bytes": total,
    "model_sha256": sdk.snapshot(model).sha256,
    "negative_witness": negative, "normal_witness": normal, "controls": controls,
    "whole_group_search": timeout, "isolated_causal_helper_search": helper,
    "isolated_causal_helper_replay": helper_replay,
    "positive_shared_storage_recovery_unproved": True, "release_claim_eligible": False,
})
sdk.write_json(public / "READBACK.json", {
    "completed": True, "capture_sha256": archive_digest, "members": len(digests),
    "expanded_bytes": total, "all_members_rehashed": True,
    "independently_replayed_witnesses": 2, "independent_allocation_control": True,
    "positive_shared_storage_recovery_unproved": True,
    "private_sdk_runtime_data_selected": False, "release_claim_eligible": False,
})
print(json.dumps({"members": len(digests), "expanded_bytes": total, "archive_bytes": archive.stat().st_size,
                  "archive_sha256": archive_digest, "model_sha256": sdk.snapshot(model).sha256}))
