"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-23"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

search = json.loads((stage / "traffic-20-TERMINAL.json").read_text())
replay = json.loads((stage / "traffic-replay-22-TERMINAL.json").read_text())
lemma = "traffic_key_derivation_requires_prior_root"
sdk.require(search["accepted"] and replay["accepted"] and replay["required_verified_lemmas"] == [lemma], "causal helper not accepted")
sdk.require(not any(arg.startswith("--prove") for arg in replay["argv"]), "helper replay used search")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "traffic-20-proof.spthy").sha256, "helper input changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "traffic-replay-22-proof.spthy").sha256, "helper output changed")
before = parsed("input", stage / "fresh-05.spthy")
after = parsed("certificate", stage / "traffic-replay-22-proof.spthy")
canonical = parsed("canonical", stage / "shared-storage-01.spthy")
sdk.require(operational_model(before) == operational_model(after) == operational_model(canonical), "helper model changed")
sdk.require(queries(before) == queries(after) and next(iter(queries(after))) == lemma, "helper queries or ordering changed")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(queries(canonical)[main] == queries(after)[main], "main formula changed")
sdk.require(replay["results"][main]["status"] == "analysis incomplete", "unexpected main result")
sdk.write_json(stage / "HELPER_23.json", {
    "completed": True, "lemma": lemma,
    "search_steps": search["results"][lemma]["steps"], "replay_steps": replay["results"][lemma]["steps"],
    "certificate_sha256": replay["output_sha256"], "same_complete_model_and_queries": True,
    "no_prior_reusable_premise": True, "main_recovery_theorem_unproved": True,
    "release_claim_eligible": False,
})
print("Causal traffic-key helper independently replayed; full recovery theorem remains unproved")
