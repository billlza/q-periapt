"""Bounded current-model search/replay; incomplete dependencies never pass."""
from pathlib import Path
import json
import os
import re
import signal
import subprocess
import sys
import time
import continuity_recovery_profiles as profiles
from continuity_recovery_proof import prover_environment
from formal_toolchain_contract import verify_installed
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
filename, label, mode, deadline, heap, graphs, *selected = sys.argv[1:]
sdk.require(re.fullmatch(r"[a-z0-9-]+\.spthy", filename) is not None and
            re.fullmatch(r"[a-z0-9-]+", label) is not None, "invalid input/output identity")
sdk.require(mode in ("search", "replay") and graphs in ("graph", "no-graph"), "invalid execution mode")
limit = int(deadline)
heap_gib = int(heap)
sdk.require(1 <= limit <= 900 and heap_gib in (6, 12), "invalid resource bound")
if selected == ["all-properties"]:
    selected = list(profiles.KEY_SCOPED_PROPERTIES)
source = stage / filename
snapshot = sdk.snapshot(source)
text = snapshot.data.decode()
declarations = list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)?', text))
inventory = [match.group(1) for match in declarations]
sdk.require(selected and set(selected) <= set(inventory) and len(set(inventory)) == len(inventory), "invalid lemma inventory")
required = set(selected)
for match in declarations:
    attrs = {item.strip() for item in (match.group(2) or "").split(",")}
    if "sources" in attrs or ("reuse" in attrs and any(inventory.index(match.group(1)) < inventory.index(name) for name in selected)):
        required.add(match.group(1))
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
environment = prover_environment()
environment["PATH"] = os.pathsep.join((str(Path(tools["tamarin"]).parent), str(Path(tools["maude"]).parent), environment["PATH"]))
verify_installed("tamarin", path_environment=environment["PATH"])
output = stage / (label + "-proof.spthy")
trace = stage / (label + "-traces.json")
sdk.require(not output.exists() and not trace.exists(), "output is not fresh")
argv = [tools["tamarin"], "--with-maude=" + tools["maude"], str(source), "--heuristic=s",
        "--derivcheck-timeout=60", "--quit-on-warning", "--output=" + str(output)]
if graphs == "graph":
    argv.append("--output-json=" + str(trace))
if mode == "search":
    argv.extend("--prove=" + name for name in selected)
argv.extend(("+RTS", "-N1", f"-M{heap_gib}G", "-s", "-RTS"))
started = time.monotonic()
timed_out = exceeded = False
with (stage / (label + ".stdout")).open("xb") as stdout, (stage / (label + ".stderr")).open("xb") as stderr:
    process = subprocess.Popen(argv, cwd=root, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
    sdk.write_json(stage / (label + "-STARTED.json"), {
        "pid": process.pid, "argv": argv, "maximum_seconds": limit,
        "required_verified_lemmas": sorted(required), "input_sha256": snapshot.sha256,
    })
    while process.poll() is None:
        timed_out = time.monotonic() - started >= limit
        exceeded = max(stdout.tell(), stderr.tell()) > 4 * 1024**2 or (trace.exists() and trace.stat().st_size > 160 * 1024**2)
        if timed_out or exceeded:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            break
        time.sleep(0.2)
    code = process.wait(timeout=5)
stdout = (stage / (label + ".stdout")).read_text()
stderr = (stage / (label + ".stderr")).read_text()
summary = stdout.rsplit("summary of summaries:", 1)[-1]
rows = re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \(([1-9][0-9]*) steps\)', summary, re.M)
results = {name: {"mode": quantifier, "status": status, "steps": int(count)} for name, quantifier, status, count in rows}
expected_modes = {match.group(1): match.group(3) or "all-traces" for match in declarations}
accepted = (code == 0 and not timed_out and not exceeded and len(rows) == len(inventory)
            and set(results) == set(inventory) and all(results[name]["status"] == "verified" for name in required)
            and all(results[name]["mode"] == expected_modes[name] for name in inventory)
            and re.search(r"(?im)^\s*(?:warning|error|fatal)\b", stderr) is None
            and output.is_file() and sdk.snapshot(source).sha256 == snapshot.sha256)
sdk.write_json(stage / (label + "-TERMINAL.json"), {
    "argv": argv, "returncode": code, "timed_out": timed_out, "output_exceeded": exceeded,
    "elapsed_seconds": time.monotonic() - started, "results": results,
    "required_verified_lemmas": sorted(required), "accepted": accepted,
    "input_sha256": snapshot.sha256, "output_sha256": sdk.snapshot(output).sha256 if output.is_file() else None,
    "release_claim_eligible": False,
})
print(json.dumps({"label": label, "results": results, "accepted": accepted, "returncode": code, "timed_out": timed_out}), flush=True)
