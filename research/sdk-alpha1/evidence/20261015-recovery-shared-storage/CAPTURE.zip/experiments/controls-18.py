"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-18"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

base = (stage / "witnesses-01.spthy").read_text()
control_path = stage / "independent-control-09.spthy"
control = control_path.read_text()
source_receipt = json.loads((stage / "CONTROL_INPUT_09.json").read_text())
sdk.require(sdk.snapshot(stage / "witnesses-01.spthy").sha256 == source_receipt["input_sha256"], "base changed")
sdk.require(sdk.snapshot(control_path).sha256 == source_receipt["output_sha256"], "control changed")
def setup_span(text):
    start = text.index("rule Setup:")
    return start, text.index("\nrule Cut:", start)
a, b = setup_span(base)
c, d = setup_span(control)
sdk.require(control[:c] + base[a:b] + control[d:] == base, "control changed more than Setup")
sdk.require("Fr(~wa), Fr(~wb)" in control[c:d] and "!StorageKey" not in control[c:d], "independent allocation missing")
before = parsed("control-input", control_path)
after = parsed("control-certificate", stage / "independent-replay-11-proof.spthy")
sdk.require(operational_model(before) == operational_model(after) and queries(before) == queries(after), "control certificate changed model or queries")
sdk.require(base.split("\nlemma ", 1)[1] == control.split("\nlemma ", 1)[1], "attack query changed")
stale = json.loads((stage / "replay-03-TERMINAL.json").read_text())
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(stale["returncode"] == 0 and not stale["accepted"] and stale["results"][main]["status"] == "verified", "conditional replay control missing")
sdk.require(any(stale["results"][name]["status"] != "verified" for name in stale["required_verified_lemmas"]), "missing dependency control changed")
sdk.write_json(stage / "CONTROLS_18.json", {
    "completed": True,
    "independent_control_changes_only_setup_allocation": True,
    "same_full_attack_query": True,
    "independent_control_full_model_and_queries_replayed": True,
    "exit_zero_verified_main_with_incomplete_dependencies_rejected": True,
    "release_claim_eligible": False,
})
print("Independent-allocation and missing-dependency controls verified")
