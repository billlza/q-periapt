"""Extend the disclosure projection to reusable wrapping keys and explicit ciphertexts."""
from pathlib import Path
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = root / "research/continuity-recovery-symbolic/key-scoped.spthy"
sdk.require(sdk.snapshot(source).sha256 == "4f425a97517302603b18e4cb007677614c13b0e341b7619c485a6345af04fd04", "model changed")
base = source.read_text()
prefix, queries = base.split("\nlemma ", 1)
prefix = prefix.replace("ContinuityKeyScopedRecoveryTransition", "ContinuitySharedStorageRecoveryTransition", 1)
prefix = prefix.replace("rule Setup:", "rule Storage_Key:\n [ Fr(~wrapping) ] --> [ !StorageKey(~wrapping) ]\n\nrule Setup:", 1)
changes = (
    ("Fr(~sid), Fr(~old), Fr(~wa), Fr(~wb)", "Fr(~sid), Fr(~old), !StorageKey(wa), !StorageKey(wb)"),
    ("Setup(~sid), SessionKeys(~sid,sa,sb)", "Setup(~sid), SessionKeys(~sid,sa,sb), SessionStorage(~sid,wa,wb)"),
    ("!Wrap(~sid,'A',~wa), !Wrap(~sid,'B',~wb)", "!Wrap(~sid,'A',wa), !Wrap(~sid,'B',wb)"),
    ("--[ Cut(s) ]-> [ !WrappingExposed(s), Out(<wa,wb>) ]",
     "--[ Cut(s), WrappingKeyLeak(wa), WrappingKeyLeak(wb) ]-> [ Out(<wa,wb>) ]"),
)
for old, new in changes:
    sdk.require(prefix.count(old) == 1, "ambiguous replacement: " + old)
    prefix = prefix.replace(old, new)
start = prefix.index("/* Captured ciphertext")
stop = prefix.index("\nrule Reveal_Identity:", start)
prefix = prefix[:start] + """/* Retained record ciphertexts may be obtained at any time. Wrapping-key
   knowledge follows the actual key, even when revealed through another session.
   This is a perfect-encryption disclosure projection, not a full journal image
   encoding or a model of state restoration, integrity, nonce or crash behavior. */
rule Snapshot:
 [ !Stored(s,role,phase,revision,plaintext)[no_precomp], !Wrap(s,role,wrapping) ]
 --[ Snapshot(s,revision), CapturedPhase(s,role,phase), StorageCaptured(s,role,wrapping,revision) ]->
 [ Out(senc(<'record',s,role,phase,revision,plaintext>,wrapping)) ]
""" + prefix[stop:]
start = prefix.index("/* Real signer persistence")
stop = prefix.index("\nrule Reveal_Entropy:", start)
prefix = prefix[:start] + """/* The implementation derives a purpose-separated signer-file key from the
   journal key. Hashing below abstracts that KDF, not its computational proof.
   IdentityKeyLeak still conservatively counts file capture before decryption. */
rule Snapshot_Signer_File:
 [ !SignerFile(s,role,key), !Wrap(s,role,wrapping) ]
 --[ IdentityLeak(s,role), IdentityKeyLeak(key), SignerFileCaptured(s,role) ]->
 [ Out(senc(<'signer',s,role,key>,h(<'signing-owner',wrapping>))) ]
""" + prefix[stop:]
sdk.require("WrappingExposed" not in prefix and "Unseal_Captured" not in prefix, "old ideal unsealing retained")
main = prefix + "\nlemma " + queries
with (stage / "shared-storage-01.spthy").open("x") as stream:
    stream.write(main)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
old_queries = {m.group(1): m.group() for m in declaration.finditer(base)}
sdk.require(old_queries == {m.group(1): m.group() for m in declaration.finditer(main)}, "complete original queries changed")
bank_path = root / "target/continuity-recovery-key-scope-20261015/final-37-proof.spthy"
sdk.require(sdk.snapshot(bank_path).sha256 == "39f17d2cc5eed8697d0022a35fff2e8d32fea3f9787aad84afc850f496d2a7f7", "certificate changed")
bank = bank_path.read_text()
tail = bank[declaration.search(bank).start():]
with (stage / "replay-01.spthy").open("x") as stream:
    stream.write(prefix + "\n" + tail)

witnesses = '''lemma sibling_wrapping_key_unseals_target_record:
 exists-trace
 "Ex s other wa wb wc revision key payload #target #sibling #c #g #e #snap #m #known.
    SessionStorage(s,wa,wb)@target & SessionStorage(other,wc,wa)@sibling
  & not (s = other) & not (wa = wb) & not (wa = wc) & not (wb = wc)
  & Cut(other)@c & KeyReserved(s)@g & EncapReserved(s)@e & c < g & c < e
  & StorageCaptured(s,'A',wa,revision)@snap & CapturedPhase(s,'A','8')@snap
  & Message(s,'A',key,payload)@m & K(payload)@known
  & (All any_session #x. Cut(any_session)@x ==> any_session = other & #x = #c)
  & (All any_session any_revision #x. Snapshot(any_session,any_revision)@x
       ==> any_session = s & any_revision = revision & #x = #snap)
  & not (Ex any_session role #x. IdentityLeak(any_session,role)@x)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)"

lemma recovery_with_shared_storage_is_executable:
 exists-trace
 "Ex s other wa wb wc key payload #target #sibling #offer #c #g #e #a #b #m.
    SessionStorage(s,wa,wb)@target & SessionStorage(other,wc,wa)@sibling
  & not (s = other) & not (wa = wb) & not (wa = wc) & not (wb = wc)
  & OfferCommitted(other)@offer & offer < m
  & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Confirmed(s,'A')@a & Confirmed(s,'B')@b & Message(s,'A',key,payload)@m
  & c < g & c < e & a < m & b < m
  & not (Ex any_session role #x. IdentityLeak(any_session,role)@x)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)
  & not (Ex any_session revision #x. Snapshot(any_session,revision)@x)"

'''
with (stage / "witnesses-01.spthy").open("x") as stream:
    stream.write(prefix + "\n" + witnesses + "lemma " + queries)
sdk.write_json(stage / "PREPARED_01.json", {
    "base_commit": "c6db533ec93062b2a9efaf43aa302aecc9f455cd",
    "canonical_base_sha256": sdk.snapshot(source).sha256,
    "inputs": {name: sdk.snapshot(stage / name).sha256 for name in
               ("shared-storage-01.spthy", "replay-01.spthy", "witnesses-01.spthy")},
    "full_original_query_declarations_unchanged": True,
    "changes": ["independently allocated reusable wrapping keys",
                "explicit symmetric-encryption ciphertexts for captured records and signer files",
                "purpose-separated signer-file key abstraction", "storage-key observer actions"],
    "new_restrictions": False,
    "scope": "single-exchange perfect-encryption disclosure projection; per-record captures, not whole-image persistence refinement",
    "unproved": ["positive shared-storage recovery", "witnesses", "whole-image correspondence", "multi-epoch", "computational security"],
    "release_claim_eligible": False,
})
print("Shared-storage projection and two falsifiable witnesses prepared; no theorem accepted")
