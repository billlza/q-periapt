"""Require a sibling responder reservation actually stored under the shared key."""
from pathlib import Path
import rust_sdk_profile as sdk
stage = Path(__file__).resolve().parent
source = stage / "witnesses-01.spthy"
text = source.read_text()
old = "#target #sibling #offer #c #g #e #a #b #m."
new = "#target #sibling #offer #reserved #c #g #e #a #b #m."
sdk.require(text.count(old) == 1, "ambiguous normal query binding")
text = text.replace(old, new)
old = "  & OfferCommitted(other)@offer & offer < m"
new = "  & OfferCommitted(other)@offer & offer < reserved\n  & EncapReserved(other)@reserved & reserved < m"
sdk.require(text.count(old) == 1, "ambiguous normal query event")
text = text.replace(old, new)
sdk.require(text.split("lemma recovery_with_shared_storage_is_executable:", 1)[0] ==
            source.read_text().split("lemma recovery_with_shared_storage_is_executable:", 1)[0], "model or attack query changed")
sdk.require(text.split("lemma signing_secret_derivation_origin", 1)[1] ==
            source.read_text().split("lemma signing_secret_derivation_origin", 1)[1], "main or original helpers changed")
with (stage / "active-use-14.spthy").open("x") as stream:
    stream.write(text)
sdk.write_json(stage / "ACTIVE_USE_14.json", {
    "input_sha256": sdk.snapshot(source).sha256,
    "output_sha256": sdk.snapshot(stage / "active-use-14.spthy").sha256,
    "change": "normal witness additionally requires the sibling responder to reserve state under its shared B-role wrapping key",
    "original_execution_witness_retained_but_only_exercised_sibling_A_storage": True,
    "main_query_and_operational_model_unchanged": True, "result_unverified": True,
})
print("Normal witness now requires actual shared-key storage use in both sessions")
