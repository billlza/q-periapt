"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-12"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

canonical = parsed("canonical", stage / "shared-storage-01.spthy")
before = parsed("input", stage / "witnesses-01.spthy")
after = parsed("certificate", stage / "sibling-replay-07-proof.spthy")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
attack = "sibling_wrapping_key_unseals_target_record"
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after), "model changed")
sdk.require(queries(before) == queries(after) and next(iter(queries(after))) == attack, "full witness queries changed")
sdk.require(queries(canonical)[main] == queries(after)[main], "main theorem changed")
search = json.loads((stage / "sibling-04-TERMINAL.json").read_text())
replay = json.loads((stage / "sibling-replay-07-TERMINAL.json").read_text())
sdk.require(search["accepted"] and replay["accepted"] and not any(arg.startswith("--prove") for arg in replay["argv"]), "witness not independently replayed")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "sibling-04-proof.spthy").sha256, "input certificate changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "sibling-replay-07-proof.spthy").sha256, "output certificate changed")

snapshot = read_regular_snapshot(stage / "sibling-replay-07-traces.json", maximum=160*1024**2, label="symbolic trace")
graphs = json.loads(snapshot.data)["graphs"]
sdk.require(len(graphs) == 1, "unexpected trace inventory")
graph = graphs[0]
actions = [(node, act) for node in graph["jgNodes"] for act in node.get("jgnMetadata", {}).get("jgnActs", [])]
def tree(term):
    if "jgnConst" in term:
        return ("constant", term["jgnConst"])
    sdk.require("jgnFunct" in term and "jgnParams" in term, "invalid symbolic term")
    return (term["jgnFunct"], tuple(tree(child) for child in term["jgnParams"]))
def one(name, node=None):
    found = [(n, act) for n, act in actions if act["jgnFactName"] == name and (node is None or n["jgnId"] == node)]
    sdk.require(len(found) == 1, "unexpected event count: " + name)
    return found[0][0], tuple(map(tree, found[0][1]["jgnFactTerms"]))

_, target = one("SessionStorage", "#target")
_, sibling = one("SessionStorage", "#sibling")
sdk.require(target[0] != sibling[0] and target[1] == sibling[2] and len({target[1], target[2], sibling[1]}) == 3,
            "storage overlap is not exactly one cross-role key")
sdk.require(one("Cut")[1] == (sibling[0],), "target or additional Cut occurred")
leaked = [tuple(map(tree, act["jgnFactTerms"])) for node, act in actions if act["jgnFactName"] == "WrappingKeyLeak"]
sdk.require(len(leaked) == 2 and set(leaked) == {(sibling[1],), (sibling[2],)}, "leaked wrapping keys differ")
_, captured = one("StorageCaptured")
sdk.require(captured[:3] == (target[0], ("constant", "'A'"), target[1]), "wrong captured key or session")
sdk.require(one("Snapshot")[1] == (target[0], captured[3]), "additional or wrong snapshot")
sdk.require(one("CapturedPhase")[1] == (target[0], ("constant", "'A'"), ("constant", "'8'")), "wrong phase")
_, message = one("Message", "#m")
sdk.require(message[:2] == (target[0], ("constant", "'A'")), "wrong target message")
sdk.require(one("K", "#known")[1] == (message[-1],), "attacker knows a different payload")
for event, node in (("KeyReserved", "#g"), ("EncapReserved", "#e")):
    sdk.require(one(event, node)[1] == (target[0],), "wrong reservation")
sdk.require(not any(act["jgnFactName"] in ("IdentityLeak", "IdentityKeyLeak", "EntropyLeak") for _, act in actions), "extra disclosure")
edges = {}
for edge in graph["jgEdges"]:
    edges.setdefault(edge["jgeSource"].split(":", 1)[0], set()).add(edge["jgeTarget"].split(":", 1)[0])
def precedes(first, last):
    pending = list(edges.get(first, ()))
    seen = set()
    while pending:
        node = pending.pop()
        if node == last:
            return True
        if node not in seen:
            seen.add(node)
            pending.extend(edges.get(node, ()))
    return False
for first, last in (("#c", "#g"), ("#c", "#e"), ("#c", "#known"), ("#snap", "#known"), ("#m", "#known")):
    sdk.require(precedes(first, last), "missing causal path: " + first + " < " + last)

control_search = json.loads((stage / "independent-control-10-TERMINAL.json").read_text())
control_replay = json.loads((stage / "independent-replay-11-TERMINAL.json").read_text())
sdk.require(control_search["output_sha256"] == control_replay["input_sha256"], "control certificate changed")
for label, receipt in (("independent-control-10", control_search), ("independent-replay-11", control_replay)):
    sdk.require(receipt["returncode"] == 0 and not receipt["accepted"] and not receipt["timed_out"], "control not terminal")
    result = (stage / (label + ".stdout")).read_text().rsplit("summary of summaries:", 1)[-1]
    sdk.require(result.count("  " + attack + " (exists-trace): falsified - no trace found (1 steps)") == 1, "independent control did not refute witness")
sdk.require(not any(arg.startswith("--prove") for arg in control_replay["argv"]), "control replay used search")
sdk.write_json(stage / "WITNESS_12.json", {
    "completed": True, "search_steps": search["results"][attack]["steps"],
    "replay_steps": replay["results"][attack]["steps"], "certificate_sha256": replay["output_sha256"],
    "trace_sha256": snapshot.sha256, "trace_bytes": snapshot.size,
    "complete_model_and_queries_unchanged": True, "exact_target_plaintext_known": True,
    "single_sibling_cut_and_single_target_phase8_capture": True,
    "three_distinct_wrapping_keys_with_one_cross_role_overlap": True,
    "no_identity_or_entropy_leak": True, "causal_paths_verified": True,
    "independent_allocation_control": "same attack query falsified in search and independent replay",
    "positive_recovery_theorem_not_established_by_this_witness": True,
    "release_claim_eligible": False,
})
print("Cross-session storage disclosure verified with exact message, key ownership and independent-allocation control")
