"""Change only allocation independence; keep the attack query and encryption rules."""
from pathlib import Path
import re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
source = stage / "witnesses-01.spthy"
text = source.read_text()
start = text.index("rule Setup:")
stop = text.index("\nrule Cut:", start)
original = text[start:stop]
changed = original.replace("!StorageKey(wa), !StorageKey(wb)", "Fr(~wa), Fr(~wb)")
for old, new in (("SessionStorage(~sid,wa,wb)", "SessionStorage(~sid,~wa,~wb)"),
                 ("!Wrap(~sid,'A',wa), !Wrap(~sid,'B',wb)", "!Wrap(~sid,'A',~wa), !Wrap(~sid,'B',~wb)")):
    sdk.require(changed.count(old) == 1, "ambiguous independent-allocation control")
    changed = changed.replace(old, new)
sdk.require(changed != original and "!StorageKey" not in changed, "allocation unchanged")
control = text[:start] + changed + text[stop:]
sdk.require(control.split("\nlemma ", 1)[1] == text.split("\nlemma ", 1)[1], "queries changed")
with (stage / "independent-control-09.spthy").open("x") as stream:
    stream.write(control)
sdk.write_json(stage / "CONTROL_INPUT_09.json", {"only_setup_allocation_changed": True,
               "input_sha256": sdk.snapshot(source).sha256,
               "output_sha256": sdk.snapshot(stage / "independent-control-09.spthy").sha256,
               "result_unverified": True})
print("Independent allocation control prepared with unchanged ciphertext rules and attack query")
