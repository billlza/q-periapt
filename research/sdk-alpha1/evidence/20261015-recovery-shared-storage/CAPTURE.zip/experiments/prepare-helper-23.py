"""Verify a standalone causal helper without promoting it to full recovery."""
from pathlib import Path
stage = Path(__file__).resolve().parent
prelude = (stage / "verify-witness-12.py").read_text().split("canonical = parsed(", 1)[0].replace("-parse-12", "-parse-23")
body = '''search = json.loads((stage / "traffic-20-TERMINAL.json").read_text())
replay = json.loads((stage / "traffic-replay-22-TERMINAL.json").read_text())
lemma = "traffic_key_derivation_requires_prior_root"
sdk.require(search["accepted"] and replay["accepted"] and replay["required_verified_lemmas"] == [lemma], "causal helper not accepted")
sdk.require(not any(arg.startswith("--prove") for arg in replay["argv"]), "helper replay used search")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "traffic-20-proof.spthy").sha256, "helper input changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "traffic-replay-22-proof.spthy").sha256, "helper output changed")
before = parsed("input", stage / "fresh-05.spthy")
after = parsed("certificate", stage / "traffic-replay-22-proof.spthy")
canonical = parsed("canonical", stage / "shared-storage-01.spthy")
sdk.require(operational_model(before) == operational_model(after) == operational_model(canonical), "helper model changed")
sdk.require(queries(before) == queries(after) and next(iter(queries(after))) == lemma, "helper queries or ordering changed")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(queries(canonical)[main] == queries(after)[main], "main formula changed")
sdk.require(replay["results"][main]["status"] == "analysis incomplete", "unexpected main result")
sdk.write_json(stage / "HELPER_23.json", {
    "completed": True, "lemma": lemma,
    "search_steps": search["results"][lemma]["steps"], "replay_steps": replay["results"][lemma]["steps"],
    "certificate_sha256": replay["output_sha256"], "same_complete_model_and_queries": True,
    "no_prior_reusable_premise": True, "main_recovery_theorem_unproved": True,
    "release_claim_eligible": False,
})
print("Causal traffic-key helper independently replayed; full recovery theorem remains unproved")
'''
with (stage / "verify-helper-23.py").open("x") as stream:
    stream.write(prelude + body)
