"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-19"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

canonical = parsed("canonical", stage / "shared-storage-01.spthy")
before = parsed("input", stage / "active-use-14.spthy")
after = parsed("certificate", stage / "active-replay-16-proof.spthy")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
lemma = "recovery_with_shared_storage_is_executable"
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after), "model changed")
sdk.require(queries(before) == queries(after), "full witness declarations changed")
sdk.require(queries(canonical)[main] == queries(after)[main], "main theorem changed")
earlier = after[:after.index("lemma " + lemma)]
sdk.require(not any("reuse" in value or "sources" in value for value in re.findall(r"(?s)lemma\s+\w+\s+\[([^\]]+)\]", earlier)), "witness has reusable premises")
search = json.loads((stage / "active-use-15-TERMINAL.json").read_text())
replay = json.loads((stage / "active-replay-16-TERMINAL.json").read_text())
sdk.require(search["accepted"] and replay["accepted"] and not any(arg.startswith("--prove") for arg in replay["argv"]), "witness not independently replayed")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "active-use-15-proof.spthy").sha256, "input certificate changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "active-replay-16-proof.spthy").sha256, "output certificate changed")
snapshot = read_regular_snapshot(stage / "active-replay-16-traces.json", maximum=160*1024**2, label="symbolic trace")
graphs = json.loads(snapshot.data)["graphs"]
sdk.require(len(graphs) == 1, "unexpected trace inventory")
graph = graphs[0]
actions = [(node, act) for node in graph["jgNodes"] for act in node.get("jgnMetadata", {}).get("jgnActs", [])]
def tree(term):
    if "jgnConst" in term:
        return ("constant", term["jgnConst"])
    sdk.require("jgnFunct" in term and "jgnParams" in term, "invalid symbolic term")
    return (term["jgnFunct"], tuple(tree(child) for child in term["jgnParams"]))
def one(name, node=None):
    found = [(n, act) for n, act in actions if act["jgnFactName"] == name and (node is None or n["jgnId"] == node)]
    sdk.require(len(found) == 1, "unexpected event count: " + name)
    return found[0][0], tuple(map(tree, found[0][1]["jgnFactTerms"]))

_, target = one("SessionStorage", "#target")
_, sibling = one("SessionStorage", "#sibling")
sdk.require(target[0] != sibling[0] and target[1] == sibling[2] and len({target[1], target[2], sibling[1]}) == 3, "shared-key ownership differs")
for event, node in (("Cut", "#c"), ("KeyReserved", "#g"), ("EncapReserved", "#e")):
    sdk.require(one(event, node)[1] == (target[0],), "wrong target event")
sdk.require(one("OfferCommitted", "#offer")[1] == (sibling[0],), "wrong sibling offer")
reserved, reservation = one("EncapReserved", "#reserved")
sdk.require(reservation == (sibling[0],) and reserved["jgnLabel"] == "Response_Reservation_4", "sibling did not use responder storage")
wrap = [tuple(map(tree, fact["jgnFactTerms"])) for fact in reserved["jgnMetadata"]["jgnPrems"] if fact["jgnFactName"] == "!Wrap"]
sdk.require(wrap == [(sibling[0], ("constant", "'B'"), target[1])], "sibling reservation did not use shared key")
stored = [tuple(map(tree, fact["jgnFactTerms"])) for fact in reserved["jgnMetadata"]["jgnConcs"] if fact["jgnFactName"] == "!Stored"]
sdk.require(len(stored) == 1 and stored[0][:3] == (sibling[0], ("constant", "'B'"), ("constant", "'4'")), "sibling stored state missing")
_, message = one("Message", "#m")
sdk.require(message[:2] == (target[0], ("constant", "'A'")), "wrong target message")
for node, role in (("#a", "'A'"), ("#b", "'B'")):
    sdk.require(one("Confirmed", node)[1] == (target[0], ("constant", role)), "target confirmation missing")
sdk.require(not any(act["jgnFactName"] in ("IdentityLeak", "IdentityKeyLeak", "EntropyLeak", "Snapshot") for _, act in actions), "unexpected disclosure")
edges = {}
for edge in graph["jgEdges"]:
    edges.setdefault(edge["jgeSource"].split(":", 1)[0], set()).add(edge["jgeTarget"].split(":", 1)[0])
def precedes(first, last):
    pending = list(edges.get(first, ()))
    seen = set()
    while pending:
        node = pending.pop()
        if node == last:
            return True
        if node not in seen:
            seen.add(node)
            pending.extend(edges.get(node, ()))
    return False
for first, last in (("#c", "#g"), ("#c", "#e"), ("#offer", "#reserved"), ("#reserved", "#m"), ("#a", "#m"), ("#b", "#m")):
    sdk.require(precedes(first, last), "missing causal path: " + first + " < " + last)
sdk.write_json(stage / "EXECUTION_19.json", {
    "completed": True, "search_steps": search["results"][lemma]["steps"],
    "replay_steps": replay["results"][lemma]["steps"], "certificate_sha256": replay["output_sha256"],
    "trace_sha256": snapshot.sha256, "trace_bytes": snapshot.size,
    "complete_model_and_queries_unchanged": True, "main_formula_unchanged": True,
    "both_target_confirmations_before_message": True,
    "shared_key_used_for_target_initiator_and_sibling_responder_storage": True,
    "three_distinct_wrapping_keys_with_one_cross_role_overlap": True,
    "no_identity_entropy_or_snapshot_disclosure": True, "causal_paths_verified": True,
    "existence_of_normal_execution_is_not_secrecy_proof": True, "release_claim_eligible": False,
})
print("Normal execution verified with both confirmations and actual cross-session shared-key storage use")
