from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile

import continuity_contract as contract
from evidence_io import parse_strict_json_bytes

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
root = Path.cwd()
stage = Path(__file__).resolve().parent
validation = stage / 'validation-02'
dest = root / 'research/sdk-alpha1/evidence/20261106-fanout-capacity-contract'
def load(path):
    return parse_strict_json_bytes(path.read_bytes(), label=str(path))
def sha(data):
    return hashlib.sha256(data).hexdigest()
result = load(validation / 'RESULT.json')
assert result['completed'] is True and result['source_inputs_unchanged'] is True
assert len(result['commands']) == 10 and all(row['completed'] and row['returncode'] == row['expected_returncode'] for row in result['commands'])
assert (stage / 'red-recorded.exit').read_text().strip() == '1'
assert b'AssertionError: ValueError not raised' in (stage / 'red-recorded.stderr').read_bytes()
assert b'Ran 8 tests' in (validation / 'python.stderr').read_bytes() and (validation / 'python.stderr').read_bytes().rstrip().endswith(b'OK')
parent = subprocess.run(['git', 'rev-parse', 'HEAD'], check=True, stdout=subprocess.PIPE).stdout.decode().strip()
assert parent == '107b17ccb6ef45d016932ffceb9d731a9f00235c'
changed = [
    'artifact/continuity_contract.py', 'artifact/test_continuity_contract.py',
    'docs/continuity/BUDGETS_V1.json', 'docs/continuity/STORAGE_RECOVERY_V1.md', 'docs/continuity/WIRE_V1.md',
    'research/continuity-identity-candidate/examples/contract_report.rs',
    'research/continuity-identity-candidate/src/contract.rs',
    'research/continuity-identity-candidate/src/durable/messages/fanout.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/fanout.rs',
]
actual_changes = subprocess.run(['git', 'diff', '--name-only'], check=True, stdout=subprocess.PIPE).stdout.decode().splitlines()
assert set(actual_changes) == set(changed)
before = {name: subprocess.run(['git', 'show', parent + ':' + name], check=True, stdout=subprocess.PIPE).stdout for name in changed}
after = {name: (root / name).read_bytes() for name in changed}
runtime = 'research/continuity-identity-candidate/src/durable/messages/fanout.rs'
assert before[runtime].replace(b'const MAX_FANOUTS: usize = 16;\n', b'') == after[runtime].replace(b'use crate::contract::MAX_RETAINED_FANOUT_RECORDS as MAX_FANOUTS;\n', b'')
shared = 'research/continuity-identity-candidate/src/contract.rs'
addition = b'/// Largest retained fanout record count, also charged to the operation quota.\n/// Only explicit terminal retirement releases a slot; admission never evicts one.\npub const MAX_RETAINED_FANOUT_RECORDS: usize = 16;\n'
assert after[shared].replace(addition, b'') == before[shared]
budgets = load(root / 'docs/continuity/BUDGETS_V1.json')
compiled = load(validation / 'compiled-contract/CONTRACT.json')
assert compiled['completed'] is True and contract.compare(budgets, compiled['contract']) == budgets
old_pass = load(stage / 'old-contract-accepted/CONTRACT.json')
old_fail = load(validation / 'old-descriptor-rejected/CONTRACT.json')
assert old_pass['completed'] is True and old_fail['completed'] is False
assert old_pass['contract'] == json.loads(before['docs/continuity/BUDGETS_V1.json'])
assert old_fail['failure'] == 'contract schema differs'
assert old_pass['consumer_sha256'] == old_fail['consumer_sha256'] == result['old_binary_sha256']
assert load(root / 'target/contract-purpose-admission/new/ORIGIN.json')['source_commit'] == '21e00e9c3cfd193b9f51491888347f583620dfe0'
assert all(sha((root / name).read_bytes()) == digest for name, digest in load(validation / 'INPUTS.json').items())
native = {}
for profile in result['build_profiles']:
    rows = []
    for name in result['selected_tests']:
        label = profile + '-' + name
        stdout, stderr = [(validation / (label + '.' + suffix)).read_bytes() for suffix in ('stdout', 'stderr')]
        assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored;', stdout, re.M)
        matches = re.findall(rb'Running unittests src/lib.rs \(([^)]+)\)', stderr)
        assert len(matches) == 1
        binary = (root / matches[0].decode()).resolve(strict=True)
        assert binary.is_relative_to(stage / 'build' / profile) and binary.is_file()
        rows.append({'test': name, 'executable': str(binary), 'bytes': binary.stat().st_size,
                     'sha256_after_execution': sha(binary.read_bytes())})
    assert rows[0]['sha256_after_execution'] == rows[1]['sha256_after_execution']
    native[profile] = rows
files = {}
def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            files[prefix + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
tree('validation', validation)
tree('prechange-accepted', stage / 'old-contract-accepted')
tree('initial-format-failure', stage / 'validation-01')
for name in ('red.stdout', 'red.stderr', 'red-recorded.stdout', 'red-recorded.stderr', 'red-recorded.exit',
             'validate.py', 'validate02.py', 'retain.py', 'validation.stdout', 'validation.stderr',
             'validation02.stdout', 'validation02.stderr'):
    files['controller/' + name] = (stage / name).read_bytes()
files['old-native-origin.json'] = (root / 'target/contract-purpose-admission/new/ORIGIN.json').read_bytes()
files.update({'source-before/' + name: value for name, value in before.items()})
files.update({'source-after/' + name: value for name, value in after.items()})
dest.mkdir()
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()}
with zipfile.ZipFile(dest / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(dest / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
record = {'completed': True, 'parent_commit': parent, 'descriptor_schema': 3, 'runtime_limit': 16,
    'old_native_origin_commit': '21e00e9c3cfd193b9f51491888347f583620dfe0',
    'old_descriptor_accepted_before_and_rejected_after': True,
    'new_compiled_descriptor_matches': True, 'python_regression_red_then_green': True,
    'python_tests': 8, 'native_test_executions': 4, 'native_executables': native,
    'rustfmt_and_strict_clippy_passed': True, 'runtime_limit_value_unchanged': True,
    'sources': {name: {'before': sha(before[name]), 'after': sha(after[name])} for name in changed},
    'validation_result_sha256': sha((validation / 'RESULT.json').read_bytes()),
    'archive': {'bytes': (dest / 'CAPTURE.zip').stat().st_size, 'sha256': sha((dest / 'CAPTURE.zip').read_bytes()), 'members': len(files)},
    'native_binaries_included': False, 'private_runtime_included': False,
    'installed_package_qualification': False, 'resource_budget_qualified': False, 'release_claim_eligible': False}
for name, value in [('CHECKS.json', record), ('FILES.json', manifest), ('VALIDATION.json', result)]:
    (dest / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in record.items() if key not in ('native_executables', 'sources')}, indent=2))
