from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import time

from bounded_process import capture_output

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
root = Path.cwd()
out = Path(__file__).resolve().parent / 'validation-01'
out.mkdir()
toolchain = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
assert not any((cache / name).exists() for name in ('config', 'config.toml', 'credentials', 'credentials.toml'))
build = out.parent / 'build'
assert not build.exists()
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_'))}
env.update(CARGO_HOME=str(cache), CARGO_TARGET_DIR=str(build), CARGO_NET_OFFLINE='true',
    CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never', RUSTC=str(toolchain / 'bin/rustc'),
    RUSTDOC=str(toolchain / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
    RUSTUP_AUTO_INSTALL='0', DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'),
    PATH=str(toolchain / 'bin') + os.pathsep + env.get('PATH', os.defpath),
    OPENSSL_DIR='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed',
    OPENSSL_STATIC='0', QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.run(['git', 'ls-files', 'research/continuity-identity-candidate', 'crates', 'Cargo.lock',
    'artifact/continuity_contract.py', 'artifact/test_continuity_contract.py', 'docs/continuity/BUDGETS_V1.json'],
    cwd=root, check=True, stdout=subprocess.PIPE).stdout.decode().splitlines()
inputs = {name: sha(root / name) for name in paths}
(out / 'INPUTS.json').write_text(json.dumps(inputs, indent=2) + '\n')
commands = []
def run(argv, label, expected=0):
    print(label, flush=True)
    row = {'argv': argv, 'expected_returncode': expected, 'started_utc': datetime.now(timezone.utc).isoformat(),
           'completed': False, 'timeout_seconds': 900}
    started = time.monotonic()
    try:
        with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
            result = capture_output(argv, timeout_seconds=900, maximum_stdout_bytes=16*1024**2,
                maximum_stderr_bytes=16*1024**2, environment=env,
                stdout_sink=stdout.write, stderr_sink=stderr.write)
        row.update(completed=True, returncode=result.returncode)
        assert result.returncode == expected, label
        return result
    finally:
        row['seconds'] = time.monotonic() - started
        (out / (label + '.json')).write_text(json.dumps(row, indent=2) + '\n')
        commands.append(row)
cargo = str(toolchain / 'bin/cargo')
manifest = 'research/continuity-identity-candidate/Cargo.toml'
common = ['--manifest-path', manifest, '--locked', '--offline', '--features', 'anchor-tls,control-tls,connection-tls', '-j', '2']
result = {'completed': False, 'scope': 'Source-level contract descriptor and native fanout capacity/retirement regression; not installed package, performance or release qualification.'}
try:
    run([cargo, 'fmt', '--manifest-path', manifest, '--all', '--check'], 'fmt')
    run(['sh', 'artifact/python-run.sh', '-m', 'unittest', 'artifact.test_continuity_contract'], 'python')
    old = root / 'target/contract-purpose-admission/new/contract_report'
    origin = json.loads((old.parent / 'ORIGIN.json').read_bytes())
    assert sha(old) == origin['binary_sha256']
    failed = run(['sh', 'artifact/python-run.sh', 'artifact/continuity_contract.py', '--consumer', str(old),
                 '--output', str(out / 'old-descriptor-rejected')], 'old-gate', expected=1)
    assert b'contract schema differs' in failed.stderr
    old_result = json.loads((out / 'old-descriptor-rejected/CONTRACT.json').read_bytes())
    assert old_result['completed'] is False and old_result['failure'] == 'contract schema differs'
    result['old_binary_sha256'] = sha(old)
    run([cargo, 'build', *common, '--release', '--example', 'contract_report'], 'example-build')
    binary = build / 'release/examples/contract_report'
    run(['sh', 'artifact/python-run.sh', 'artifact/continuity_contract.py', '--consumer', str(binary),
         '--output', str(out / 'compiled-contract')], 'compiled-gate')
    result['new_binary_sha256'] = sha(binary)
    selected = [
        'account_fanout_capacity_and_id_scope_preserve_earlier_committed_work',
        'account_fanout_abandonment_does_not_need_an_extra_batch_slot_at_capacity',
    ]
    for profile in ('debug', 'release'):
        for name in selected:
            observed = run([cargo, 'test', *common, '--lib', *(['--release'] if profile == 'release' else []),
                            name, '--', '--nocapture'], profile + '-' + name)
            assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored;', observed.stdout, re.M)
            assert re.search(rb'^test [a-z_:]*' + name.encode() + rb' \.\.\. ok$', observed.stdout, re.M)
    run([str(toolchain / 'bin/cargo-clippy'), 'clippy', *common, '--all-targets', '--', '-D', 'warnings'], 'clippy')
    assert {name: sha(root / name) for name in paths} == inputs
    result.update(completed=True, source_inputs_unchanged=True, selected_tests=selected,
                  build_profiles=['debug', 'release'])
finally:
    result.update(commands=commands, finished_utc=datetime.now(timezone.utc).isoformat())
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
