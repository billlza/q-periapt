from pathlib import Path
import json,hashlib,zipfile,tempfile
import continuity_apple_package as apple
from continuity_apple_consumer import MARKER,verify_linkage
r=Path.cwd();o=r/'target/continuity-apple-package-stable';dest=r/'research/sdk-alpha1/evidence/20261012-apple-package-producer'
state=json.loads((o/'STATE.json').read_text());assert state['completed'] and not state['live_producer']
result=json.loads((o/'CONTINUITY_APPLE_PACKAGE.json').read_text());assert result['completed'] and result['sources_unchanged'] and result['installed_members_verified'] and not result['release_claim_eligible'] and not result['publication_performed']
assert set(result['native'])==set(apple.TARGETS) and all(x['owner_exports']==152 for x in result['native'].values())
for name,h in state['inputs'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h
stability=json.loads((o/'STABILITY.json').read_text());assert stability['completed'] and stability['expected_stable_archive_sha256']==result['archive']['sha256']
archive=o/apple.ARCHIVE;assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['archive']['sha256']
prepared=json.loads((o/'PREPARATION.json').read_text());outside=Path(prepared['outside']);work=outside/'apple-package';installed=work/'installed/QPeriaptContinuity';contents=json.loads((installed/apple.CONTENTS).read_text());header=(r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes();apple.verify_package(installed,contents,result['native'],header)
evidence=o/'apple-package';assert (evidence/'consumer-macos-run.stdout').read_bytes()==MARKER and (evidence/'consumer-macos-run.stderr').read_bytes()==b''
link_maps={}
for name,target in [('macos','aarch64-apple-darwin'),('ios','aarch64-apple-ios'),('simulator','aarch64-apple-ios-sim')]:
 row=result['consumer'][name];assert row['selected_archive_sha256']==result['native'][target]['sha256'] and row['linkage']['status']=='pass'
 if name=='macos':
  products=Path((evidence/'consumer-macos-bin.stdout').read_text().strip());executable=products/'ContinuityBinaryConsumer';link_map=work/'macos-LinkMap.txt'
 else:
  sdk='iphoneos' if name=='ios' else 'iphonesimulator';products=work/('build-'+name)/'Build/Products'/('Release-'+sdk);executable=products/'ContinuityBinaryConsumer.app/ContinuityBinaryConsumer';link_map=work/(name+'-ContinuityBinaryConsumer-LinkMap.txt')
 assert hashlib.sha256(executable.read_bytes()).hexdigest()==row['executable_sha256'];assert verify_linkage(link_map,products/apple.LIBRARY,executable)==row['linkage'];link_maps[name]=link_map
 for suffix in ['stdout','stderr']:
  data=(evidence/('consumer-'+name+'-build.'+suffix)).read_bytes();assert b'warning:' not in data and b'error:' not in data
 if name!='macos':assert b'** BUILD SUCCEEDED **' in (evidence/('consumer-'+name+'-build.stdout')).read_bytes()
sim=json.loads((o/'SIMULATOR_RUNTIME.json').read_text());assert sim['completed'] and not sim['live_producer'] and sim['created_simulator_removed'] and sim['package_sha256']==result['archive']['sha256'] and sim['app_sha256']==result['consumer']['simulator']['executable_sha256']
assert (o/'simulator-runtime/launch.stdout').read_bytes().splitlines().count(MARKER.rstrip(b'\n'))==1
members={}
def add(name,path):
 if path.is_dir():
  for p in path.rglob('*'):
   if p.is_file() and not p.is_symlink():members[name+'/'+str(p.relative_to(path))]=p.read_bytes()
 else:members[name]=path.read_bytes()
for n in ['CONTINUITY_APPLE_PACKAGE.json','STATE.json','PREPARATION.json','RESOLVED_DEPS.json','resolution.stdout','resolution.stderr','resolution.json','source-gate.stdout','source-gate.stderr','SIMULATOR_RUNTIME.json','STABILITY.json','simulator-runtime','apple-package']:add('execution/'+n,o/n)
for n,p in link_maps.items():add('execution/link-maps/'+n+'.txt',p)
for n in ['run.py','run_simulator.py','capture.py','check_repeatability.py']:add('qualification/'+n,o/n)
for n in ['continuity_apple_package.py','continuity_apple_consumer.py','test_continuity_apple_package.py','apple_sdk_profile.py','continuity_package.py','deterministic_archive.py','third_party_licenses.py']:add('source/artifact/'+n,r/'artifact'/n)
for n in ['bindings/swift/ContinuityBinaryConsumer','bindings/swift/ContinuityPackageConsumer/ApplePackageREADME.md','.github/workflows/ci.yml']:add('source/'+n,r/n)
add('package/'+apple.CONTENTS,installed/apple.CONTENTS)
assert not any(Path(n).name in {'PRIVATE_ENVIRONMENT.json','SIGNING.json','tls-key','wrap.key','signer.key'} or n.endswith('.redb') for n in members)
dest.mkdir();capture=dest/'CAPTURE.zip'
with zipfile.ZipFile(capture,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},indent=2)+'\n')
with zipfile.ZipFile(capture) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items())
 reread=json.loads(z.read('execution/CONTINUITY_APPLE_PACKAGE.json'));assert reread==result
checks={'completed':True,'source_commit':prepared['source_commit'],'current_compilable_sources_compared':prepared['current_compilable_sources_equal'],'C_manifest_and_dependency_resolution_verified':True,'archive':result['archive'],'native':result['native'],'consumer':result['consumer'],'simulator_probe':sim,'physical_device_execution_of_this_archive':False,'parent_Rust_C_full_cohort_reexecuted_locally':False,'local_unit_checks_passed':60,'full_producer_invocation_passed':True,'repeatability':stability,'package_members_reverified':len(contents['files']),'capture_members':len(members),'capture_sha256':hashlib.sha256(capture.read_bytes()).hexdigest(),'all_capture_hashes_verified':True,'publication_performed':False,'release_claim_eligible':False}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({k:checks[k] for k in ['completed','archive','package_members_reverified','capture_members','capture_sha256']},indent=2))
