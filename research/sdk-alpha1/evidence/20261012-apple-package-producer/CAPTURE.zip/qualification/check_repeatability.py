from pathlib import Path
import json,tempfile,hashlib
import continuity_apple_package as apple
r=Path.cwd();output=r/'target/continuity-apple-package-stable';work=Path(tempfile.mkdtemp(prefix='qperiapt-apple-metadata-repetition-')).resolve();rows=[];header=(r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes()
for index,name in enumerate(['continuity-apple-package-integration','continuity-apple-package-qualified']):
 source=r/'target'/name;archive=source/apple.ARCHIVE;original_hash=hashlib.sha256(archive.read_bytes()).hexdigest();folder=work/str(index)
 apple.extract_zip(archive,folder,root_name=apple.NAME,mtime=apple.MTIME,expected_sha256=original_hash,limits=apple.LIMITS)
 root=folder/apple.NAME;original=apple.file_hashes(root);info=root/'CQPCOwner.xcframework/Info.plist';info.write_bytes(apple.canonical_xcframework_info(info.read_bytes()));contents=json.loads((root/apple.CONTENTS).read_text());contents['files']['CQPCOwner.xcframework/Info.plist']=hashlib.sha256(info.read_bytes()).hexdigest();(root/apple.CONTENTS).write_text(json.dumps(contents,indent=2,sort_keys=True)+'\n')
 modified=apple.file_hashes(root);changed=sorted(n for n in original if original[n]!=modified[n]);assert changed==['CQPCOwner.xcframework/Info.plist',apple.CONTENTS]
 native=json.loads((source/'CONTINUITY_APPLE_PACKAGE.json').read_text())['native'];apple.verify_package(root,contents,native,header)
 audit=apple.create_zip(root,work/(str(index)+'.zip'),root_name=apple.NAME,mtime=apple.MTIME,limits=apple.LIMITS)
 rows.append({'source':name,'original_archive_sha256':original_hash,'canonical_archive_sha256':audit.archive_sha256,'changed_members':changed,'native':native})
assert rows[0]['canonical_archive_sha256']==rows[1]['canonical_archive_sha256'] and rows[0]['native']==rows[1]['native']
result={'completed':True,'two_distinct_native_builds':True,'native_archives_equal':True,'canonicalized_archives_equal':True,'expected_stable_archive_sha256':rows[0]['canonical_archive_sha256'],'only_metadata_inventory_order_normalized':True,'sources':rows}
(output/'STABILITY.json').write_text(json.dumps(result,indent=2)+'\n');print('Two native builds produce the same canonical archive:',result['expected_stable_archive_sha256'])
