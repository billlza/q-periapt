from pathlib import Path
import json,hashlib
import continuity_apple_package as apple
import continuity_package as package
import continuity_c_consumer as c
import rust_sdk_profile as sdk
from evidence_io import parse_strict_json_bytes
r=Path.cwd();o=r/'target/continuity-apple-package-stable';prepared=json.loads((o/'PREPARATION.json').read_text());outside=Path(prepared['outside']);env=json.loads((o/'PRIVATE_ENVIRONMENT.json').read_text());tool=Path(env['RUSTC']).parent
inputs=[r/'artifact'/n for n in ['continuity_apple_package.py','continuity_apple_consumer.py','apple_sdk_profile.py','deterministic_archive.py']]+[p for root in [r/'bindings/swift/ContinuityBinaryConsumer',r/'bindings/swift/ContinuityPackageConsumer'] for p in root.rglob('*') if p.is_file()]
state={'completed':False,'live_producer':True,'inputs':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
(o/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 metadata=parse_strict_json_bytes(sdk.command([str(tool/'cargo'),'metadata','--locked','--offline','--format-version','1'],o/'resolution',outside/'c-consumer',environment=env),label='Apple installed resolution')
 resolved=package.verify_resolution(metadata,outside/'c-consumer',(outside/'c-consumer/Cargo.lock').read_bytes(),(package.CANDIDATE/'Cargo.lock').read_bytes(),consumer_name=c.NAME,required_features=c.FEATURES)
 sdk.write_json(o/'RESOLVED_DEPS.json',resolved)
 result=apple.qualify_apple(outside,o,env)
 for name,h in state['inputs'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
 state['completed']=True
 print(json.dumps({k:result[k] for k in ['completed','archive','consumer','physical_device_execution','simulator_execution']},indent=2))
finally:
 state['live_producer']=False;(o/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
