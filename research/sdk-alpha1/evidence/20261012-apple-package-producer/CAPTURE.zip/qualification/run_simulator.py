from pathlib import Path
import json,hashlib,secrets,re
from bounded_process import capture_output
from continuity_apple_consumer import MARKER
r=Path.cwd();out=r/'target/continuity-apple-package-stable';report=json.loads((out/'CONTINUITY_APPLE_PACKAGE.json').read_text());assert report['completed']
setup=json.loads((out/'PREPARATION.json').read_text());app=Path(setup['outside'])/'apple-package/build-simulator/Build/Products/Release-iphonesimulator/ContinuityBinaryConsumer.app';binary=app/'ContinuityBinaryConsumer';expected=report['consumer']['simulator']['executable_sha256'];assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
logs=out/'simulator-runtime';logs.mkdir();selected=None;state={'completed':False,'live_producer':True,'created_simulator_removed':False,'package_sha256':report['archive']['sha256'],'app_sha256':expected}
def save(): (out/'SIMULATOR_RUNTIME.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,label,timeout=60,*,required=True):
 result=capture_output(['xcrun','simctl',*args],timeout_seconds=timeout,maximum_stdout_bytes=4*1024**2,maximum_stderr_bytes=4*1024**2)
 for name,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  if selected:data=data.replace(selected.encode(),b'<owned-simulator>')
  (logs/(label+'.'+name)).write_bytes(data)
 (logs/(label+'.status.json')).write_text(json.dumps({'returncode':result.returncode,'timeout_seconds':timeout},indent=2)+'\n')
 if required and result.returncode:raise RuntimeError(label+' failed: '+str(result.returncode))
 return result
save()
try:
 # Inventory is retained only as the selected public runtime and device type,
 # never as identifiers for the user's existing simulators.
 runtime_result=capture_output(['xcrun','simctl','list','runtimes','--json'],timeout_seconds=30,maximum_stdout_bytes=1024**2,maximum_stderr_bytes=1024**2)
 assert runtime_result.returncode==0
 runtimes=[x for x in json.loads(runtime_result.stdout)['runtimes'] if x.get('isAvailable') and x.get('platform')=='iOS' and 'arm64' in x.get('supportedArchitectures',[])]
 assert runtimes
 runtime=max(runtimes,key=lambda x:tuple(map(int,x['version'].split('.'))));models=[x for x in runtime['supportedDeviceTypes'] if x['name'].startswith('iPhone')];assert models
 model=models[0];state.update(runtime=runtime['name'],runtime_build=runtime['buildversion'],device_type=model['name'])
 created=capture_output(['xcrun','simctl','create','QPeriaptPackage-'+secrets.token_hex(8),model['identifier'],runtime['identifier']],timeout_seconds=60,maximum_stdout_bytes=4096,maximum_stderr_bytes=65536)
 selected=created.stdout.decode().strip();assert re.fullmatch(r'[0-9A-Fa-f-]{36}',selected)
 assert created.returncode==0 and not created.stderr
 state['created_simulator_sha256']=hashlib.sha256(selected.encode()).hexdigest();save()
 run(['boot',selected],'boot');run(['bootstatus',selected,'-b'],'boot-status',timeout=180)
 run(['install',selected,str(app)],'install')
 launched=run(['launch','--arch=arm64','--console',selected,'dev.qperiapt.binaryconsumer'],'launch',timeout=90)
 assert launched.stdout.splitlines().count(MARKER.rstrip(b'\n'))==1 and b'CONTINUITY_BINARY_CONSUMER_FAIL' not in launched.stdout+launched.stderr
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
 state['completed']=True
except Exception as error:
 state['failure']=str(error).replace(selected or '<no-simulator>', '<owned-simulator>');raise
finally:
 state['live_producer']=False
 try:
  if selected:
   status=capture_output(['xcrun','simctl','list','devices','--json'],timeout_seconds=30,maximum_stdout_bytes=4*1024**2,maximum_stderr_bytes=1024**2)
   assert status.returncode==0
   rows=[x for group in json.loads(status.stdout)['devices'].values() for x in group if x['udid']==selected];assert len(rows)==1
   if rows[0]['state']!='Shutdown':run(['shutdown',selected],'shutdown')
   run(['delete',selected],'delete')
   result=capture_output(['xcrun','simctl','list','devices','--json'],timeout_seconds=30,maximum_stdout_bytes=4*1024**2,maximum_stderr_bytes=1024**2)
   assert result.returncode==0 and all(x['udid']!=selected for rows in json.loads(result.stdout)['devices'].values() for x in rows)
   state['created_simulator_removed']=True
 finally:save()
print(json.dumps({k:v for k,v in state.items() if k!='created_simulator_sha256'},indent=2))
