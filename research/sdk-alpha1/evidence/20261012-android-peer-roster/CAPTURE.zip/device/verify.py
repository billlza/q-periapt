from pathlib import Path
import hashlib,json,re,subprocess
import continuity_android_roster as roster
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent;records=roster.verify_local((out/'execution.stdout').read_bytes(),out/'cases',remote=True)
for trust,record in records.items():
 base=out/'cases'/trust;s=json.loads((out/('device-'+trust)/'STATE.json').read_text());assert s['completed'] and s['cleanup'] and not s.get('owned_reverse_ports') and len(s['cases'])==23
 assert len({c['pid'] for c in s['cases']})==23
 for c in s['cases']:assert c['process_absent_after_stop'] and c['installed_apk_sha256']==s['apk_sha256'] and c['result_sha256']==hashlib.sha256((base/c['label']).read_bytes()).hexdigest()
 record.update(installation_retired=True,apk_sha256=s['apk_sha256'],aar_sha256=s['aar_sha256'],retained_member_stays_authorized=True,removed_member_denied=True)
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
def call(args):
 r=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,check=True,timeout=20);assert not r.stderr;return r.stdout
assert not call(['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.peerroster20261012']).strip();active={row.split()[1] for row in call(['reverse','--list']).splitlines() if len(row.split())==3}
for p in out.glob('device-*/*-reverse-create-*.json'):
 d=json.loads(p.read_text())
 if d['exit_code']==0:assert d['command'][-2] not in active
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':records,'art_processes':46,'same_phone_accepted':True,'additional_api36_hardware_required':False,'scope':'Local original sessions survive same-member peer R2 adoption; later empty R3 denies retained sends and peer reopen. No forced new session or replacement handshake.'});print('46 ART calls, retained-member continuity, real revocation and owned cleanup verified',flush=True)
