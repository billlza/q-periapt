from pathlib import Path
import hashlib,json,re,subprocess,shutil
import rust_sdk_profile as sdk
root=Path.cwd();out=Path(__file__).resolve().parent;native=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text());saved=json.loads((root/'target/continuity-android-peer-roster/build-v2/EXECUTABLE.json').read_text());source=Path(saved['source']);env=native['environment'];binary=out/'android-harness';shutil.copy2(saved['binary'],binary);assert hashlib.sha256(binary.read_bytes()).hexdigest()==saved['sha256'];assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==digest for name,digest in saved['sources'].items())
h={'copied_sha256':saved['sha256'],'test_sources':saved['sources'],'receiver':native['native']['execution']['debug']['binaries']['C_client']['path']};sdk.write_json(out/'EXECUTABLE.json',h)
package=json.loads((out/'PACKAGE.json').read_text())
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest
def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.peerroster20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(path.read_text())
  if not state.get('installation_attempted') or (state.get('cleanup') and not state.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
  def call(args):
   result=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(state.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);state['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;path.write_text(json.dumps(state,indent=2)+'\n')
try:
 cases=out/'cases';runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=h['receiver'])
 stdout=sdk.command([str(binary),'--exact','android_roster_local::remote_roster_advance','--nocapture'],out/'execution',source,environment=runtime)
 assert stdout.count(b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 23 filtered out;')==1
 results={}
 for trust in ['fixed','recoverable']:
  assert stdout.count(('qualified local roster adapter '+trust+': 23 Java processes; original identity journal session message and one effect across local R2 advancement').encode())==1
  results[trust]={'foreign_processes':23,'case':str(cases/trust),'device_label':trust}
 sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('remote roster qualification and owned cleanup failed',[original,failure])
 raise
print('46 ART peer roster advancement, original retry and revocation calls passed',flush=True)
