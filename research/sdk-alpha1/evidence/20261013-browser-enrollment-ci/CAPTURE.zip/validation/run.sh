#!/bin/sh
set -eu
export RUSTUP_HOME=/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup
export RUSTUP_TOOLCHAIN=1.98.1-aarch64-apple-darwin
export CARGO_HOME=/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e
export CC_wasm32_unknown_unknown=/opt/homebrew/opt/llvm/bin/clang
export RUSTFLAGS='-D warnings'
export PATH="/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/browser-policy-tools/node_modules/.bin:/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/browser-policy-tools/wasm-bindgen/bin:/Users/bill/.cargo/bin:/opt/homebrew/bin:$PATH"
export QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14
export PYTHONPATH=artifact
exec sh artifact/python-run.sh artifact/continuity_browser_creation.py --output "$1" --node /opt/homebrew/bin/node --cli /Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js
