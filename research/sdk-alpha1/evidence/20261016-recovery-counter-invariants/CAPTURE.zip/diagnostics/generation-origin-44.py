"""Add an epoch-scoped disclosure-origin obligation without changing the protocol."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-08.spthy"
sdk.require(sdk.snapshot(source).sha256 == "a617cc76cdcb579127b7ef38ded92a2a2112b998bb5683597ea0949467cd7db1", "source changed")
before = source.read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
queries = list(decl.finditer(before))
sdk.require(len(queries) == 4, "original query inventory differs")
addition = '''lemma epoch_generation_secret_derivation_origin [use_induction]:
 "All s epoch key #created #known.
    GenerationSecret(s,epoch,key)@created & KU(key)@known
    ==> (Ex #leaked. EntropyLeak(s,epoch,'generation')@leaked)
      | (Ex role #captured. CapturedPhase(s,role,epoch,'1')@captured)
      | (Ex role #captured. CapturedPhase(s,role,epoch,'2')@captured)
      | (Ex role #captured. CapturedPhase(s,role,epoch,'3')@captured)"

'''
position = queries[0].start()
after = before[:position] + addition + before[position:]
new = list(decl.finditer(after))
sdk.require(after[:position] == before[:position] and [m.group() for m in new[1:]] == [m.group() for m in queries], "original rules or complete queries changed")
output = stage / "generation-origin-44.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-44", root)
sdk.write_json(stage / "GENERATION_ORIGIN_44.json", {
    "source_sha256": sdk.snapshot(source).sha256, "output_sha256": sdk.snapshot(output).sha256,
    "all_original_rules_and_four_queries_unchanged": True,
    "new_restrictions_or_axioms": False, "operational_round_bound_added": False,
    "new_query": "epoch_generation_secret_derivation_origin",
    "induction_is_a_proof_method_not_an_assumption": True,
    "unproved_until_terminal_inventory_and_independent_replay": True,
})
print("Epoch-scoped derivation-origin query parsed; protocol and original queries unchanged")
