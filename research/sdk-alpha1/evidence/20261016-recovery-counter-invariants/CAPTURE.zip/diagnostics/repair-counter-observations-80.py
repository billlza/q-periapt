"""Include the responder's preserved counter; the exact production census found it."""
from pathlib import Path
import rust_sdk_profile as sdk
stage = Path(__file__).resolve().parent
before = (stage / "prepare-counter-state-79.py").read_text()
needle = '    ("TrafficInput(s,epoch,role,root,key) ]->",'
sdk.require(before.count(needle) == 1, "observation generator changed")
addition = '''    ("Saved(s,r,succ(n),~rev,'9') ]->", "Saved(s,r,succ(n),~rev,'9'), CounterState(s,r,n,closing) ]->"),
'''
after = before.replace(needle, addition + needle)
after = after.replace('== 6, "observation census differs"', '== 7, "observation census differs"')
after = after.replace('counter-state-79', 'counter-state-81').replace('COUNTER_STATE_PREPARED_79', 'COUNTER_STATE_PREPARED_81')
after = after.replace('Six counter-production', 'Seven counter-production').replace('six_new_action', 'seven_new_action').replace('six added observations', 'seven added observations')
with (stage / "prepare-counter-state-81.py").open("x") as stream: stream.write(after)
sdk.write_json(stage / "OBSERVATION_REPAIR_80.json", {
    "failed_check": "The exact output census found Receipt_Reservation_9 also preserves SendState(s,r,n,old,...,closing).",
    "change": "Add the corresponding deterministic CounterState(s,r,n,closing) observation; require all seven outputs.",
    "previous_generator_sha256": sdk.snapshot(stage / "prepare-counter-state-79.py").sha256,
    "corrected_generator_sha256": sdk.snapshot(stage / "prepare-counter-state-81.py").sha256,
    "no_protocol_restriction_or_input_output_change": True,
})
