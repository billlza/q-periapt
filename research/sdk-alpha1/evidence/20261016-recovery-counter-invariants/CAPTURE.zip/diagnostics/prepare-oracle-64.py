"""Admit the upstream oracle API's legitimate empty input without dropping goals."""
from pathlib import Path
import hashlib
import shlex
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
before = (stage / "oracle-59.py").read_text()
needle = 'if not goals or len({number for number, _ in goals}) != len(goals):'
sdk.require(before.count(needle) == 1, "prior oracle differs")
after = before.replace(needle, 'if len({number for number, _ in goals}) != len(goals):')
after = after.replace('"empty or duplicate goal inventory"', '"duplicate goal inventory"').replace('oracle-59', 'oracle-64')
with (stage / "oracle-64.py").open("x") as stream:
    stream.write(after)
launcher = stage / "oracle-64.sh"
with launcher.open("x") as stream:
    stream.write("#!/bin/sh\nexec /opt/homebrew/opt/python@3.14/bin/python3.14 -I -S -B " +
                 shlex.quote(str(root / "artifact/python_bootstrap.py")) + " " +
                 shlex.quote(str(stage / "oracle-64.py")) + ' "$@"\n')
launcher.chmod(0o700)
runner = (stage / "oracle-run-59.py").read_text().replace('oracle-59', 'oracle-64')
with (stage / "oracle-run-64.py").open("x") as stream:
    stream.write(runner)
sdk.write_json(stage / "ORACLE_PREPARED_64.json", {
    "input_sha256": sdk.snapshot(stage / "generation-origin-44.spthy").sha256,
    "runner_sha256": sdk.snapshot(stage / "oracle-run-64.py").sha256,
    "oracle_sha256": sdk.snapshot(stage / "oracle-64.py").sha256,
    "predecessor": "generation-oracle-60 rejected empty oracle input and failed before proof search",
    "source": "https://github.com/tamarin-prover/tamarin-prover/blob/82780bbaf3328a45f624ddb41e51bf75425f851c/lib/theory/src/Theory/Constraint/Solver/ProofMethod.hs#L605",
    "source_sha256": sdk.snapshot(stage / "upstream-proof-method-63.hs").sha256,
    "contract": "The oracle is called on openGoals, including the empty list. Empty input has the unique empty permutation; duplicate or malformed indices still fail.",
    "rank_algorithm_and_complete_model_unchanged": True,
    "security_property_not_yet_established": True,
})
print("Empty-input oracle contract corrected in a fresh, separately recorded experiment")
