"""Expose counter-state production for induction, preserving operational traces."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "counter-constructor-77.spthy"
prepared = json.loads((stage / "COUNTER_PREPARED_77.json").read_text())
sdk.require(sdk.snapshot(source).sha256 == prepared["output_sha256"], "counter model changed")
before = source.read_text()
sdk.require("CounterState(" not in before, "observation name already used")
changes = (
    ("ReadyState(~sid,'B','zero',~old,parent) ]->", "ReadyState(~sid,'B','zero',~old,parent)\n   , CounterState(~sid,'A','zero','zero'), CounterState(~sid,'B','zero','zero') ]->"),
    ("AcceptedRoot(s,succ(n),p,old,root), Saved(s,p,succ(n),~rev,'7') ]->", "AcceptedRoot(s,succ(n),p,old,root), Saved(s,p,succ(n),~rev,'7')\n   , CounterState(s,p,n,closing) ]->"),
    ("Saved(s,p,succ(n),~rev,'8') ]->", "Saved(s,p,succ(n),~rev,'8'), CounterState(s,p,succ(n),'zero') ]->"),
    ("ReadyState(s,r,epoch,root,next_parent), Saved(s,r,epoch,~rev,'0') ]->", "ReadyState(s,r,epoch,root,next_parent), Saved(s,r,epoch,~rev,'0')\n   , CounterState(s,r,epoch,'zero') ]->"),
    ("Saved(s,r,succ(n),~rev,'9') ]->", "Saved(s,r,succ(n),~rev,'9'), CounterState(s,r,n,closing) ]->"),
    ("TrafficInput(s,epoch,role,root,key) ]->", "TrafficInput(s,epoch,role,root,key), CounterState(s,role,epoch,succ(counter)) ]->"),
)
after = before
for old, new in changes:
    sdk.require(after.count(old) == 1, "observation insertion anchor differs")
    after = after.replace(old, new, 1)
erased = after
for old, new in changes:
    sdk.require(erased.count(new) == 1, "observation erasure anchor differs")
    erased = erased.replace(new, old, 1)
sdk.require(erased == before, "non-observational model change")

def facts(text, name):
    matches = []
    for match in re.finditer(r"\b" + name + r"\(", text):
        start = match.end(); depth = 1; cursor = start
        while depth:
            sdk.require(cursor < len(text), "unclosed fact")
            depth += (text[cursor] == "(") - (text[cursor] == ")")
            cursor += 1
        body = text[start:cursor-1]
        args=[]; begin=0; nesting=0
        for i,char in enumerate(body):
            if char in "(<": nesting+=1
            elif char in ")>": nesting-=1
            elif char=="," and nesting==0:
                args.append(re.sub(r"\s+", "", body[begin:i])); begin=i+1
        args.append(re.sub(r"\s+", "", body[begin:]))
        matches.append(args)
    return matches

rules = list(re.finditer(r"(?ms)^rule\s+(\w+):.*?(?=^rule\s|^restriction\s)", after))
observed = {}
for match in rules:
    rule = match.group()
    if "--[" not in rule: continue
    _, action_and_output = rule.split("--[", 1)
    actions, outputs = action_and_output.split("]->", 1)
    counters = facts(actions, "CounterState")
    send_states = facts(outputs, "SendState")
    sdk.require(all(len(args) == 7 for args in send_states), "SendState arity differs")
    expected = [[args[0], args[1], args[2], args[6]] for args in send_states]
    sdk.require(counters == expected, "counter observations do not exactly match produced states")
    if counters: observed[match.group(1)] = counters
sdk.require(sum(map(len, observed.values())) == 7, "observation census differs")

addition = '''lemma produced_counter_has_public_constructor [use_induction]:
 "All s role epoch counter #produced.
    CounterState(s,role,epoch,counter)@produced
    ==> counter = 'zero' | (Ex previous. counter = succ(previous))"

'''
position = after.index("\nlemma ") + 1
after = after[:position] + addition + after[position:]
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
old = list(decl.finditer(before)); new = list(decl.finditer(after))
sdk.require(len(old) == 6 and [m.group() for m in new[1:]] == [m.group() for m in old], "existing complete queries changed")
output = stage / "counter-state-81.spthy"
with output.open("x") as stream: stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-counter-state-81", root)
sdk.write_json(stage / "COUNTER_STATE_PREPARED_81.json", {
    "source_sha256": sdk.snapshot(source).sha256, "output_sha256": sdk.snapshot(output).sha256,
    "observed_productions": observed,
    "erasing_only_seven_new_action_facts_recovers_exact_previous_model": True,
    "all_existing_queries_restrictions_and_rule_inputs_outputs_unchanged": True,
    "new_observations_do_not_occur_in_any_restriction": True,
    "new_reuse_or_sources_premises": False,
    "trace_correspondence": "Every old rule instance has the same premises, outputs and old actions. The seven added observations are deterministic terms already in produced SendState facts. Erasing only those labels maps traces back to the original, while adding them maps each old execution forward.",
    "unproved_until_terminal_and_independent_replay": True,
})
print("Seven counter-production observations checked against exact SendState outputs; old execution semantics preserved")
