"""Test a finite-source ranking on the exact existing origin conjecture."""
from pathlib import Path
import json
import shlex
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "generation-origin-44.spthy"
sdk.require(sdk.snapshot(source).sha256 == "3aaf03a3768418ac3a2f1ff8265f3d8a6b97b07db40f4f4f3a21a329df19d3ba", "origin source changed")
launcher = stage / "oracle-59.sh"
with launcher.open("x") as stream:
    stream.write("#!/bin/sh\nexec /opt/homebrew/opt/python@3.14/bin/python3.14 -I -S -B " +
                 shlex.quote(str(root / "artifact/python_bootstrap.py")) + " " +
                 shlex.quote(str(stage / "oracle-59.py")) + ' "$@"\n')
launcher.chmod(0o700)
runner = (stage / "run-20.py").read_text()
sdk.require(runner.count('"--heuristic=s"') == 1, "runner heuristic differs")
runner = runner.replace('"--heuristic=s"', '"--heuristic=o", "--oraclename=" + str(stage / "oracle-59.sh")')
runner = runner.replace('if timed_out or exceeded:', 'if timed_out or exceeded or (stage / "oracle-59.failed").exists():')
runner = runner.replace('accepted = (code == 0', 'accepted = (not (stage / "oracle-59.failed").exists() and code == 0')
with (stage / "oracle-run-59.py").open("x") as stream:
    stream.write(runner)
sdk.write_json(stage / "ORACLE_PREPARED_59.json", {
    "input_sha256": sdk.snapshot(source).sha256,
    "runner_sha256": sdk.snapshot(stage / "oracle-run-59.py").sha256,
    "oracle_sha256": sdk.snapshot(stage / "oracle-59.py").sha256,
    "hypothesis": "Finite-source facts may close public-header type branches before recursively expanding Ready or SendState ancestry.",
    "protocol_and_all_queries_unchanged": True,
    "oracle_only_reorders_complete_goal_inventory": True,
    "new_assumptions_or_round_bounds": False,
    "manual": "https://tamarin-prover.com/manual/master/book/011_advanced-features.html#using-an-oracle",
    "unproved_until_independent_replay": True,
})
print("Exact existing origin query prepared with a logged goal-order permutation")
