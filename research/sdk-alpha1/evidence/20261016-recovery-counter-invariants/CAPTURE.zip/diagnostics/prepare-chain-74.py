"""Resolve the remaining intruder derivation chain before unrelated state ancestry."""
from pathlib import Path
import shlex
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
before = (stage / "oracle-64.py").read_text()
needle = '        _, goal = item\n'
sdk.require(before.count(needle) == 1, "oracle score differs")
after = before.replace(needle, needle + '        if "~~>" in goal:\n            return 0\n')
after = after.replace('oracle-64', 'oracle-74')
with (stage / "oracle-74.py").open("x") as stream: stream.write(after)
launcher = stage / "oracle-74.sh"
with launcher.open("x") as stream:
    stream.write("#!/bin/sh\nexec /opt/homebrew/opt/python@3.14/bin/python3.14 -I -S -B " +
                 shlex.quote(str(root / "artifact/python_bootstrap.py")) + " " +
                 shlex.quote(str(stage / "oracle-74.py")) + ' "$@"\n')
launcher.chmod(0o700)
with (stage / "oracle-run-74.py").open("x") as stream:
    stream.write((stage / "oracle-run-64.py").read_text().replace('oracle-64', 'oracle-74'))
sdk.write_json(stage / "CHAIN_PREPARED_74.json", {
    "input_sha256": sdk.snapshot(stage / "generation-origin-44.spthy").sha256,
    "oracle_sha256": sdk.snapshot(stage / "oracle-74.py").sha256,
    "runner_sha256": sdk.snapshot(stage / "oracle-run-74.py").sha256,
    "evidence": "interactive-application-66 and interactive-graph-67 preserve an unresolved intruder derivation chain; oracle-64 repeatedly selects binding facts ahead of that chain.",
    "only_ranking_change": "Prioritize ~~> derivation-chain goals before finite-source facts; retain every original goal.",
    "model_and_complete_queries_unchanged": True,
    "new_assumptions_or_operational_bounds": False,
    "security_property_unproved": True,
})
print("A chain-first comparison is prepared against the exact same origin query")
