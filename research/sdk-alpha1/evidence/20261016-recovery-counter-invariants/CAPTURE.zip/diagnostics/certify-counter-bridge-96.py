"""Discharge the counter dependency and verify the real missing-proof control."""
from pathlib import Path
import importlib.util
import json
import re
import subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('counter_model_check',stage/'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None,'missing model checker')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
qualified=json.loads((stage/'COUNTER_CERTIFIED_90.json').read_text())
sdk.require(qualified['completed'],'dependency not independently qualified')
expected=(stage/'parse-counter-bridge-91.stdout').read_text()
queries=model.queries(expected)
base_queries=model.queries((stage/'observed-parse-89.stdout').read_text())
helper='produced_counter_has_public_constructor';target='application_counter_has_public_constructor'
sdk.require(len(queries)==7 and set(queries)==set(base_queries),'query inventory differs')
for name,value in queries.items():
    if name==helper:
        sdk.require(value.count('[use_induction, reuse]')==1,'unexpected dependency attributes')
        value=value.replace('[use_induction, reuse]','[use_induction]')
    sdk.require(value==base_queries[name],'complete query changed')
sdk.require(model.operational(expected)[0]==model.operational((stage/'observed-parse-89.stdout').read_text())[0],'operational model changed')
control=json.loads((stage/'COUNTER_CONTROL_PREPARED_93.json').read_text())
search=json.loads((stage/'counter-bridge-92-TERMINAL.json').read_text())
records={}
for label,input_name,input_digest,accepted,helper_result in (
    ('counter-bridge-replay-94','counter-bridge-92-proof.spthy',search['output_sha256'],True,('verified',35)),
    ('counter-control-95','counter-missing-helper-93.spthy',control['output_sha256'],False,('analysis incomplete',1)),
):
    receipt=json.loads((stage/(label+'-TERMINAL.json')).read_text())
    started=json.loads((stage/(label+'-STARTED.json')).read_text())
    sdk.require(receipt['accepted']==accepted and receipt['returncode']==0 and not receipt['timed_out'] and not receipt['output_exceeded'],'unexpected terminal outcome')
    sdk.require(set(receipt['required_verified_lemmas'])=={helper,target},'dependency was not required')
    sdk.require(not any(arg.startswith('--prove') for arg in receipt['argv']),'replay used search')
    sdk.require(receipt['input_sha256']==input_digest==sdk.snapshot(stage/input_name).sha256,'wrong replay input')
    output=stage/(label+'-proof.spthy')
    sdk.require(sdk.snapshot(output).sha256==receipt['output_sha256'],'output certificate changed')
    stdout=(stage/(label+'.stdout')).read_text().rsplit('summary of summaries:',1)[-1]
    rows=re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \(([1-9][0-9]*) steps\)',stdout,re.M)
    sdk.require(len(rows)==7 and {r[0] for r in rows}==set(queries),'incomplete raw verdict inventory')
    for name,mode,status,steps in rows:
        expected_result=helper_result if name==helper else ('verified',17) if name==target else ('analysis incomplete',1)
        sdk.require((status,int(steps))==expected_result,'wrong raw verdict')
        sdk.require(mode==('exists-trace' if 'exists-trace' in queries[name].split('"',1)[0] else 'all-traces'),'wrong raw quantifier')
    sdk.require(re.search(r'(?im)^\s*(?:warning|error|fatal)\b',(stage/(label+'.stderr')).read_text()) is None,'replay diagnostic failure')
    parsed=model.parsed(label,output)
    sdk.require(model.queries(parsed)==queries and model.operational(parsed)[0]==model.operational(expected)[0],'replay changed the complete theory')
    process=subprocess.run(['/bin/ps','-p',str(started['pid']),'-o','pid='],capture_output=True,text=True)
    sdk.require(process.returncode==1 and not process.stdout.strip(),'replay process remains live')
    records[label]=receipt
sdk.write_json(stage/'COUNTER_BRIDGE_CERTIFIED_96.json',{
    'completed':True,'verified_properties':{helper:35,target:17},'independent_replays':records,
    'dependency_graph':{helper:[],target:[helper]},
    'all_original_complete_queries_and_operational_traces_preserved':True,
    'actual_missing_dependency_control_rejected':True,
    'control_target_still_verified_conditionally':True,
    'no_unproved_reuse_premise_in_accepted_conjunction':True,
    'counter_model_receipt_sha256':sdk.snapshot(stage/'COUNTER_CERTIFIED_90.json').sha256,
    'not_established':['generation-secret derivation origin','two-round witness','delayed-receipt witness','multi-epoch secrecy','SDK correspondence','computational security'],
    'release_claim_eligible':False,
})
print('Both counter properties independently replayed; the real incomplete-dependency control is rejected')
