"""Integrate only the counter-observed model after complete proof qualification."""
from pathlib import Path
import importlib.util
import json
import subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='52977f1a2ef90289b78b50244bf1a5fae619cd76','unexpected integration base')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'integration source is dirty')
qualified=json.loads((stage/'COUNTER_BRIDGE_CERTIFIED_96.json').read_text())
sdk.require(qualified['completed'] and qualified['actual_missing_dependency_control_rejected'],'proof qualification incomplete')
source=stage/'counter-priority-84.spthy'
identity=json.loads((stage/'COUNTER_MODEL_VERIFIED_89.json').read_text())
sdk.require(sdk.snapshot(source).sha256==identity['source_files'][source.name],'qualified model changed')
canonical=root/'research/continuity-recovery-symbolic/multi-epoch.spthy'
old=sdk.snapshot(canonical)
sdk.require(old.sha256=='1be3e576722af22586edf62eff1cacb913b981e162f3942e133fac613aaf4977','original model changed')
with (stage/'canonical-before-97.spthy').open('xb') as stream:stream.write(old.data)
text=source.read_text()
text=text.replace('rule Setup:', '''/* CounterState observes the counter of every produced SendState. Removing
   these seven action facts preserves all original executions and queries. */
rule Setup:''',1)
text=text.replace('lemma produced_counter_has_public_constructor', '''/* The two counter-constructor properties have complete checked proofs.
   The bare declarations carry no reusable assumptions; the captured joint
   certificate retains and checks the full dependency proof explicitly. */
lemma produced_counter_has_public_constructor''',1)
text=text.replace('lemma epoch_generation_secret_derivation_origin', '''/* Additional derivation-origin obligation; this remains unproved. */
lemma epoch_generation_secret_derivation_origin''',1)
canonical.write_text(text)
spec=importlib.util.spec_from_file_location('counter_model_check',stage/'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None,'identity checker missing')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
parsed=model.parsed('integrated-counter',canonical)
expected=(stage/'priority-parse-89.stdout').read_text()
sdk.require(model.operational(parsed)[0]==model.operational(expected)[0] and model.queries(parsed)==model.queries(expected),'integration changed the qualified complete theory')
sdk.command(['git','diff','--check'],stage/'integrated-diff-97',root)
sdk.write_json(stage/'COUNTER_INTEGRATED_97.json',{
 'completed':True,'previous_model_sha256':old.sha256,'integrated_model_sha256':sdk.snapshot(canonical).sha256,
 'all_seven_complete_declarations_and_operational_model_match_qualified_input':True,
 'only_additional_changes_are_explanatory_comments':True,
 'no_reusable_lemma_assumption_in_bare_model':True,
 'qualified_receipt_sha256':sdk.snapshot(stage/'COUNTER_BRIDGE_CERTIFIED_96.json').sha256,
 'release_claim_eligible':False,
})
print('Qualified counter-observed model integrated; generation-origin and recovery-secrecy obligations remain open')
