"""Prioritize the state edge relevant to the counter induction hypothesis."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root=Path.cwd()
stage=Path(__file__).resolve().parent
source=stage/'counter-state-81.spthy'
prepared=json.loads((stage/'COUNTER_STATE_PREPARED_81.json').read_text())
sdk.require(sdk.snapshot(source).sha256==prepared['output_sha256'],'observational model changed')
before=source.read_text()
after,count=re.subn(r'(\bSendState\([^()]*\))\[no_precomp\]',r'\1[+,no_precomp]',before)
sdk.require(count==5,'send-state premise census differs')
sdk.require(after.replace('[+,no_precomp]','[no_precomp]')==before,'non-priority change')
output=stage/'counter-priority-84.spthy'
with output.open('x') as stream:stream.write(after)
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-counter-priority-84',root)
sdk.write_json(stage/'COUNTER_PRIORITY_84.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'changed_premise_annotations':count,'only_change':'Prioritize all five SendState premises; retain no_precomp.',
 'operational_model_all_observations_and_seven_queries_unchanged':True,
 'evidence':'counter-state-82.stderr selects Offer3 and Response6 before the counter-carrying SendState edge.',
 'manual':'https://tamarin-prover.com/manual/master/book/011_advanced-features.html#fact-annotations',
 'unproved_until_terminal_and_independent_replay':True,
})
print('Only five SendState proof-priority annotations changed')
