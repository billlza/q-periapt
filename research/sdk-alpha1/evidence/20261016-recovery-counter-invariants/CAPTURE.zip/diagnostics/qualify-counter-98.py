"""Qualify the clean standalone source commit carrying the checked model."""
from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sdk.require(len(sys.argv)==2 and head==sys.argv[1],'unexpected source commit')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'source checkout is dirty')
integration=json.loads((stage/'COUNTER_INTEGRATED_97.json').read_text())
sdk.require(integration['completed'],'model not integrated')
model=root/'research/continuity-recovery-symbolic/multi-epoch.spthy'
sdk.require(sdk.snapshot(model).sha256==integration['integrated_model_sha256'],'integrated model differs')
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(root/'artifact/source_results_assembler.py'),
             'ci-source-gate',sdk.snapshot(root/'artifact/results.json').sha256,head,'--profile','sdk-020'],stage/'source-gate-98',root)
sdk.command(['git','diff','--check'],stage/'diff-98',root)
sdk.write_json(stage/'COUNTER_QUALIFIED_98.json',{
 'completed':True,'head':head,'source_gate_passed':True,'model_sha256':sdk.snapshot(model).sha256,
 'counter_conjunction_receipt_sha256':sdk.snapshot(stage/'COUNTER_BRIDGE_CERTIFIED_96.json').sha256,
 'checked_model_and_all_seven_complete_queries_preserved':True,
 'sdk_runtime_source_changed':False,'release_claim_eligible':False,
})
print('Checked counter model source gate passed: '+head)
