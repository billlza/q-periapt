"""Rank existing proof goals; retain the exact input and permutation for review."""
from pathlib import Path
import json
import re
import sys

stage = Path(__file__).resolve().parent
log = stage / "oracle-64.jsonl"
failure = stage / "oracle-64.failed"
try:
    raw = sys.stdin.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        raise ValueError("oracle input exceeds diagnostic bound")
    goals = []
    for line in raw.splitlines():
        match = re.match(r"^([0-9]+):\s*(.*)$", line)
        if not match:
            raise ValueError("unexpected goal encoding")
        goals.append((int(match[1]), match[2]))
    if len({number for number, _ in goals}) != len(goals):
        raise ValueError("duplicate goal inventory")

    def score(item):
        _, goal = item
        if re.search(r"!?KU\(\s*~key\s*\)\s*@\s*#known", goal):
            return 0
        if re.match(r"!?(?:Context|Wrap|Pinned|Signer|SignerFile|Peers|IdentityKey|StorageKey|ApplicationEpoch)\(", goal):
            return 1
        if re.match(r"!?(?:Entropy|Stored)\(", goal):
            return 2
        if re.match(r"SendState\(", goal) and "~key" in goal:
            return 3
        if re.match(r"Ready\(", goal):
            return 8
        if re.match(r"SendState\(", goal):
            return 7
        return 4

    ranked = sorted(goals, key=score)
    entry = json.dumps({"lemma": sys.argv[1:], "goals": goals,
                        "ranking": [number for number, _ in ranked]}, ensure_ascii=False) + "\n"
    if (log.stat().st_size if log.exists() else 0) + len(entry.encode()) > 4 * 1024**2:
        raise ValueError("oracle log exceeds diagnostic bound")
    with log.open("a") as stream:
        stream.write(entry)
    for number, _ in ranked:
        print(number)
except Exception as exc:
    failure.write_text(type(exc).__name__ + ": " + str(exc))
    raise
