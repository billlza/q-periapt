"""Read terminal experiments without promoting search progress to a theorem."""
from pathlib import Path
from collections import Counter
import json
import re
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "generation-origin-44.spthy"
source_digest = "3aaf03a3768418ac3a2f1ff8265f3d8a6b97b07db40f4f4f3a21a329df19d3ba"
sdk.require(sdk.snapshot(source).sha256 == source_digest, "origin query changed")
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
original = (stage / "multi-epoch-08.spthy").read_text()
current = source.read_text()
old_queries = list(decl.finditer(original))
new_queries = list(decl.finditer(current))
sdk.require(len(old_queries) == 4 and len(new_queries) == 5, "query inventory differs")
sdk.require([m.group() for m in new_queries[1:]] == [m.group() for m in old_queries], "original complete queries differ")
sdk.require(current[:new_queries[0].start()] == original[:old_queries[0].start()], "operational model differs")

receipts = {}
for label in ("idle-witness-53", "generation-first-branch-55", "generation-oracle-60", "generation-oracle-65", "generation-chain-75"):
    record = json.loads((stage / (label + "-TERMINAL.json")).read_text())
    started = json.loads((stage / (label + "-STARTED.json")).read_text())
    process = subprocess.run(["/bin/ps", "-p", str(started["pid"]), "-o", "pid="], capture_output=True, text=True)
    sdk.require(process.returncode == 1 and not process.stdout.strip(), "owned prover still present")
    if label.startswith("generation-oracle") or label == "generation-chain-75":
        sdk.require(record["input_sha256"] == source_digest, "different origin conjecture used")
    if record["accepted"]:
        sdk.require(record["returncode"] == 0 and not record["timed_out"] and not record["output_exceeded"], "inconsistent success")
        sdk.require(sdk.snapshot(stage / (label + "-proof.spthy")).sha256 == record["output_sha256"], "certificate changed")
    receipts[label] = record

oracle_reviews = {}
for name in ("oracle-64", "oracle-74"):
    path = stage / (name + ".jsonl")
    snapshot = sdk.snapshot(path)
    sdk.require(len(snapshot.data) <= 4 * 1024**2, "oracle log exceeded bound")
    rows = [json.loads(line) for line in snapshot.data.decode().splitlines()]
    counts = Counter()
    for row in rows:
        numbers = [number for number, _ in row["goals"]]
        sdk.require(len(set(numbers)) == len(numbers) and sorted(numbers) == sorted(row["ranking"]), "oracle dropped or duplicated a goal")
        sdk.require(row["lemma"] == ["epoch_generation_secret_derivation_origin"], "unexpected oracle lemma")
        if row["ranking"]:
            goal = dict(row["goals"])[row["ranking"][0]]
            counts["derivation-chain" if "~~>" in goal else goal.split("(", 1)[0] or "disjunction"] += 1
    failure = stage / (name + ".failed")
    oracle_reviews[name] = {"sha256": snapshot.sha256, "bytes": len(snapshot.data), "calls": len(rows),
                            "every_ranking_is_a_complete_permutation": True, "first_choices": dict(counts),
                            "failure": failure.read_text() if failure.exists() else None}

viewer = json.loads((stage / "INTERACTIVE_TERMINAL_56.json").read_text())
sdk.require(viewer["reason"] == "owned-stop-marker", "viewer did not use requested shutdown")
readback = json.loads((stage / "VIEWER_READBACK_72.json").read_text())
sdk.require(readback["completed"], "viewer responses were not checked")
files = ["generation-origin-44.spthy", "multi-epoch-08.spthy", "oracle-59.py", "oracle-59.failed",
         "oracle-64.py", "oracle-74.py", "oracle-run-59.py", "oracle-run-64.py", "oracle-run-74.py",
         "upstream-proof-method-63.hs", "upstream-web-handler-73.hs", "VIEWER_READBACK_72.json"]
report = {
    "completed": True, "operational_model_and_four_original_queries_unchanged": True,
    "source_sha256": source_digest, "terminal_runs": receipts, "oracle_reviews": oracle_reviews,
    "viewer": viewer, "readback": readback,
    "files": {name: sdk.snapshot(stage / name).sha256 for name in files},
    "limits": ["No new theorem is admitted without independent replay and original-theory identity checks.",
               "The existing multi-epoch secrecy and reachability obligations remain open.",
               "These public symbolic experiments do not reopen any private SDK/device cohort."],
    "release_claim_eligible": False,
}
with (stage / "DIAGNOSTIC_REVIEW_76.json").open("x") as stream:
    json.dump(report, stream, indent=2)
print(json.dumps({"completed": True, "search_accepted": {label: r["accepted"] for label, r in receipts.items()},
                  "new_theorem_admitted": False}))
