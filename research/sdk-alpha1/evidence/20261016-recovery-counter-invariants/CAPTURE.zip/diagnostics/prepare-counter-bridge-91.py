"""Reuse only the independently replayed counter invariant, retaining its proof."""
from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
certified=json.loads((stage/'COUNTER_CERTIFIED_90.json').read_text())
sdk.require(certified['completed'],'counter invariant not independently certified')
source=stage/'counter-priority-replay-88-proof.spthy'
receipt=certified['independent_replays']['counter-priority-replay-88']
sdk.require(sdk.snapshot(source).sha256==receipt['output_sha256'],'certified counter proof changed')
before=source.read_text()
old='lemma produced_counter_has_public_constructor [use_induction]:'
new='lemma produced_counter_has_public_constructor [use_induction, reuse]:'
sdk.require(before.count(old)==1 and '[reuse' not in before,'counter declaration differs')
after=before.replace(old,new,1)
sdk.require(after.replace(new,old,1)==before,'non-reuse change')
output=stage/'counter-bridge-91.spthy'
with output.open('x') as stream:stream.write(after)
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-counter-bridge-91',root)
sdk.write_json(stage/'COUNTER_BRIDGE_PREPARED_91.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'qualified_premise_receipt_sha256':sdk.snapshot(stage/'COUNTER_CERTIFIED_90.json').sha256,
 'only_change':'Mark the independently replayed produced-counter lemma reusable; retain its entire 35-step proof and all original declarations.',
 'required_verified_lemmas':['produced_counter_has_public_constructor','application_counter_has_public_constructor'],
 'no_axiom_restriction_or_operational_change':True,
 'incomplete_premise_must_reject_the_whole_result':True,
})
print('Certified counter invariant prepared as an explicit proof dependency')
