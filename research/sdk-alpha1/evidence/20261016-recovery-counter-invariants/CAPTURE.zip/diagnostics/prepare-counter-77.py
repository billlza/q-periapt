"""Add a counter-constructor proof obligation, with no operational restriction."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "generation-origin-44.spthy"
sdk.require(sdk.snapshot(source).sha256 == "3aaf03a3768418ac3a2f1ff8265f3d8a6b97b07db40f4f4f3a21a329df19d3ba", "origin source changed")
before = source.read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
old = list(decl.finditer(before))
sdk.require(len(old) == 5, "source query inventory differs")
addition = '''lemma application_counter_has_public_constructor [use_induction]:
 "All s epoch role root counter context offer response payload #sent.
    Message(s,epoch,role,
      h(<'message-key',
         h(<'traffic',s,context,epoch,role,root,h(<'traffic-transcript',offer,response>)>),
         counter>),payload)@sent
    ==> counter = 'zero' | (Ex previous. counter = succ(previous))"

'''
position = old[0].start()
after = before[:position] + addition + before[position:]
new = list(decl.finditer(after))
sdk.require(after[:position] == before[:position] and [m.group() for m in new[1:]] == [m.group() for m in old], "original model or complete query changed")
output = stage / "counter-constructor-77.spthy"
with output.open("x") as stream: stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-counter-77", root)
sdk.write_json(stage / "COUNTER_PREPARED_77.json", {
    "source_sha256": sdk.snapshot(source).sha256, "output_sha256": sdk.snapshot(output).sha256,
    "all_original_rules_and_five_queries_unchanged": True,
    "new_restrictions_or_axioms": False, "new_reuse_or_sources_premises": False,
    "unbounded_rounds_and_all_existing_disclosure_rules_retained": True,
    "new_query": "application_counter_has_public_constructor",
    "purpose": "Discharge one public-field shape obligation independently, rather than assume typing while proving secret derivation origin.",
    "unproved_until_terminal_and_independent_replay": True,
})
print("Counter constructor obligation parsed; all previous rules and complete queries retained")
