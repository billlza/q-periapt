"""Independently reread both complete counter proofs and link the original theory."""
from pathlib import Path
import importlib.util
import json
import re
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('counter_model_check',stage/'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None,'missing identity checker')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
identity=json.loads((stage/'COUNTER_MODEL_VERIFIED_89.json').read_text())
sdk.require(identity['completed'],'source identity not established')
for name,digest in identity['source_files'].items():
    sdk.require(sdk.snapshot(stage/name).sha256==digest,'reviewed input changed: '+name)
for name,digest in identity['parsed_files'].items():
    sdk.require(sdk.snapshot(stage/(name+'-parse-89.stdout')).sha256==digest,'reviewed parse changed: '+name)
expected=(stage/'observed-parse-89.stdout').read_text()
queries=model.queries(expected);operational=model.operational(expected)[0]
theorem='produced_counter_has_public_constructor'
records={}
for search_label,replay_label,steps in (
    ('counter-state-82','counter-state-replay-87',90),
    ('counter-priority-85','counter-priority-replay-88',35),
):
    search=json.loads((stage/(search_label+'-TERMINAL.json')).read_text())
    replay=json.loads((stage/(replay_label+'-TERMINAL.json')).read_text())
    started=json.loads((stage/(replay_label+'-STARTED.json')).read_text())
    sdk.require(replay['accepted'] and replay['returncode']==0 and not replay['timed_out'] and not replay['output_exceeded'],'replay did not complete')
    sdk.require(replay['required_verified_lemmas']==[theorem] and not any(arg.startswith('--prove') for arg in replay['argv']),'replay performed search or changed scope')
    sdk.require(replay['input_sha256']==search['output_sha256']==sdk.snapshot(stage/(search_label+'-proof.spthy')).sha256,'wrong replay input')
    output=stage/(replay_label+'-proof.spthy')
    sdk.require(sdk.snapshot(output).sha256==replay['output_sha256'],'replay certificate changed')
    stdout=(stage/(replay_label+'.stdout')).read_text()
    summary=stdout.rsplit('summary of summaries:',1)[-1]
    rows=re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \(([1-9][0-9]*) steps\)',summary,re.M)
    sdk.require(len(rows)==7 and {row[0] for row in rows}==set(queries),'incomplete raw verdict inventory')
    for name,mode,status,count in rows:
        sdk.require(mode==('exists-trace' if 'exists-trace' in queries[name].split('"',1)[0] else 'all-traces'),'verdict quantifier differs')
        sdk.require((status,int(count))==(('verified',steps) if name==theorem else ('analysis incomplete',1)),'unexpected raw verdict')
    stderr=(stage/(replay_label+'.stderr')).read_text()
    sdk.require(re.search(r'(?im)^\s*(?:warning|error|fatal)\b',stderr) is None,'replay diagnostics contain an error')
    check=model.parsed(replay_label,output)
    sdk.require(model.operational(check)[0]==operational and model.queries(check)==queries,'replayed operational model or complete queries changed')
    process=subprocess.run(['/bin/ps','-p',str(started['pid']),'-o','pid='],capture_output=True,text=True)
    sdk.require(process.returncode==1 and not process.stdout.strip(),'replay still running')
    records[replay_label]=replay

canonical=root/'research/continuity-recovery-symbolic/multi-epoch.spthy'
sdk.require(sdk.snapshot(canonical).sha256=='1be3e576722af22586edf62eff1cacb913b981e162f3942e133fac613aaf4977','canonical model changed during qualification')
parsed_canonical=model.parsed('canonical-counter-link',canonical)
old=(stage/'old-parse-89.stdout').read_text()
sdk.require(model.operational(parsed_canonical)[0]==model.operational(old)[0],'unobserved model differs from original canonical model')
original_queries=model.queries(parsed_canonical)
sdk.require(len(original_queries)==4 and all(queries[name]==query for name,query in original_queries.items()),'original four complete queries changed')
sdk.write_json(stage/'COUNTER_CERTIFIED_90.json',{
    'completed':True,'verified_obligation':theorem,'independent_replays':records,
    'all_seven_complete_queries_and_observed_execution_model_unchanged':True,
    'original_four_queries_and_execution_model_preserved_under_observation_erasure':True,
    'original_model_sha256':sdk.snapshot(canonical).sha256,
    'no_new_protocol_restriction_or_reuse_assumption':True,
    'scope':'Every produced SendState counter is zero or a succ term in the unbounded symbolic model.',
    'not_established':['application-counter query','generation-secret derivation origin','normal two-round witness','delayed-receipt witness','multi-epoch message secrecy','computational security','SDK refinement'],
    'release_claim_eligible':False,
})
print('Both independent counter proof replays verified; original four queries and operational traces preserved')
