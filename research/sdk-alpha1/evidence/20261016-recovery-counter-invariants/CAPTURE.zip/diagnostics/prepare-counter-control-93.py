"""Remove only the dependency proof, retaining the complete conditional target."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
source=stage/'counter-bridge-92-proof.spthy'
receipt=json.loads((stage/'counter-bridge-92-TERMINAL.json').read_text())
sdk.require(receipt['accepted'] and receipt['output_sha256']==sdk.snapshot(source).sha256,'bridge search incomplete or changed')
text=source.read_text()
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
matches=list(decl.finditer(text))
sdk.require(len(matches)==7 and matches[0].group(1)=='produced_counter_has_public_constructor' and matches[1].group(1)=='application_counter_has_public_constructor','dependency order differs')
mutant=text[:matches[0].end()]+'\nby sorry\n\n'+text[matches[1].start():]
sdk.require([m.group() for m in decl.finditer(mutant)]==[m.group() for m in matches],'control changed a declaration')
output=stage/'counter-missing-helper-93.spthy'
with output.open('x') as stream:stream.write(mutant)
sdk.write_json(stage/'COUNTER_CONTROL_PREPARED_93.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'only_change':'Replace the produced-counter dependency proof body with by sorry; retain its full reusable formula and the entire 17-step application proof.',
 'expected_gate_acceptance':False,
 'conditional_application_success_alone_is_insufficient':True,
})
print('Missing-dependency proof control prepared without changing the model or any formula')
