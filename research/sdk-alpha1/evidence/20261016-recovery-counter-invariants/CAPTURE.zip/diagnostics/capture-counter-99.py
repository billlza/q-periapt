"""Seal the complete counter proof pair, failed searches and dependency control."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
qualified=json.loads((stage/'COUNTER_QUALIFIED_98.json').read_text())
proof=json.loads((stage/'COUNTER_BRIDGE_CERTIFIED_96.json').read_text())
diagnostics=json.loads((stage/'DIAGNOSTIC_REVIEW_76.json').read_text())
sdk.require(qualified['completed'] and qualified['source_gate_passed'] and proof['completed'] and diagnostics['completed'],'qualification incomplete')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sdk.require(head==qualified['head'] and not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'source identity changed')
patterns=[
 'multi-epoch-08.spthy','generation-origin-44*','GENERATION_ORIGIN_44.json',
 'idle-witness-52*','idle-witness-53*','IDLE_WITNESS_52.json','confirmed-41.spthy',
 'generation-first-branch-55*','first-branch-run-54.py','FIRST_BRANCH_PREPARED_54.json',
 'read-interactive-57.py','interactive-56.*','INTERACTIVE_*_56.json',
 'interactive-index-57.*','interactive-application-58.*','interactive-application-61.*','interactive-application-62.*',
 'interactive-application-66.*','interactive-graph-67.*','interactive-graph-68.*','interactive-graph-69.*','interactive-leaf-70.*','VIEWER_READBACK_72.json',
 'oracle-*','prepare-oracle-59.py','prepare-oracle-64.py','ORACLE_PREPARED_*.json',
 'generation-oracle-60*','generation-oracle-65*','generation-chain-75*','prepare-chain-74.py','CHAIN_PREPARED_74.json',
 'review-diagnostics-76.py','DIAGNOSTIC_REVIEW_76.json','run-20.py',
 'counter-*','*counter*.py','COUNTER_*.json','parse-counter*','*-parse-89.*','OBSERVATION_REPAIR_80.json',
 'canonical-before-97.spthy','tool-help-83.*','codeql-status-86.*',
 'integrated-diff-97.*','stage-model-97.*','commit-model-97.*','clone-model-97.*','fetch-model-97.*','clone-model-97b.*',
 'source-gate-98.*','diff-98.*',
]
files={'diagnostics/'+path.name:path for pattern in patterns for path in stage.glob(pattern) if path.is_file()}
for name in ('research/continuity-recovery-symbolic/multi-epoch.spthy','artifact/python_bootstrap.py',
             'artifact/rust_sdk_profile.py','artifact/continuity_recovery_proof.py',
             'artifact/continuity_recovery_profiles.py','artifact/formal_toolchain_contract.py'):
    files['source/'+name]=root/name
files['tools/TOOLS_08.json']=root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json'
public=root/'research/sdk-alpha1/evidence/20261016-recovery-counter-invariants'
public.mkdir()
archive=public/'CAPTURE.zip';members={};expanded=0
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as zipped:
    for name,path in sorted(files.items()):
        sdk.require(not path.is_symlink(),'capture contains symlink')
        data=sdk.snapshot(path,maximum=16*1024**2).data
        expanded+=len(data);sdk.require(expanded<=64*1024**2,'capture exceeds bound')
        entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
        zipped.writestr(entry,data);members[name]=hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist())==len(members),'archive inventory changed')
    for name,digest in members.items():sdk.require(hashlib.sha256(zipped.read(name)).hexdigest()==digest,'archive member changed')
digest=sdk.snapshot(archive,maximum=16*1024**2).sha256
sdk.write_json(public/'CAPTURE.json',{
 'source_commit':head,'model_sha256':qualified['model_sha256'],'archive_sha256':digest,
 'members':members,'expanded_bytes':expanded,'source_gate_passed':True,
 'verified_properties':proof['verified_properties'],'dependency_graph':proof['dependency_graph'],
 'actual_missing_dependency_control_rejected':True,'all_seven_complete_queries_retained':True,
 'original_executions_preserved_under_observation_erasure':True,
 'private_sdk_device_state_included':False,'sdk_runtime_source_changed':False,
 'counter_uniqueness_or_nonce_safety_proved':False,'multi_epoch_secrecy_proved':False,
 'hosted_replay_qualified':False,'release_claim_eligible':False,
})
sdk.write_json(public/'READBACK.json',{
 'completed':True,'archive_sha256':digest,'members':len(members),'expanded_bytes':expanded,
 'all_members_rehashed':True,'complete_counter_dependency_pair_checked':True,
 'conditional_target_alone_rejected':True,'release_claim_eligible':False,
})
print(json.dumps({'archive_bytes':archive.stat().st_size,'expanded_bytes':expanded,'members':len(members),'sha256':digest}))
