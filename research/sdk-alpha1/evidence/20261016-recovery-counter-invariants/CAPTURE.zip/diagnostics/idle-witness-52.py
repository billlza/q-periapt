"""Choose an idle honest witness without restricting the protocol trace space."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "confirmed-41.spthy"
sdk.require(sdk.snapshot(source).sha256 == "ac4cb1d79646cf0a224e4e00760d5b53c8ca8d4fc02cc2f7db03f5161214902a", "confirmed schedule changed")
before = source.read_text()
declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
queries = list(declaration.finditer(before))
sdk.require(len(queries) == 5 and queries[0].group(1) == "ordered_confirmed_roles_with_exposed_ancestor_is_executable", "unexpected witness inventory")
header, body = queries[0].group(3).split(".", 1)
constraint = """
  & (All any_session any_epoch any_role any_key any_payload #sent.
       Message(any_session,any_epoch,any_role,any_key,any_payload)@sent ==> #sent = #m)
"""
formula = header + ".\n  (" + body + ")" + constraint
name = "idle_confirmed_rounds_with_exposed_ancestor_is_executable"
new_query = 'lemma ' + name + ':\n exists-trace\n "' + formula + '"'
after = before[:queries[0].start()] + new_query + before[queries[0].end():]
updated = list(declaration.finditer(after))
sdk.require(after[:queries[0].start()] == before[:queries[0].start()], "operational theory changed")
sdk.require([m.group() for m in updated[1:]] == [m.group() for m in queries[1:]], "original four queries changed")
sdk.require(updated[0].group(3) == formula and "(" + body + ")" in formula, "previous witness was not retained as a complete conjunct")
path = stage / "idle-witness-52.spthy"
with path.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only", "--quit-on-warning"], stage / "parse-52", root)
sdk.write_json(stage / "IDLE_WITNESS_52.json", {
    "input_sha256": sdk.snapshot(path).sha256, "source_sha256": sdk.snapshot(source).sha256,
    "operational_model_and_original_four_queries_unchanged": True,
    "original_confirmed_witness_retained_as_complete_conjunct": True,
    "additional_witness_condition": "Exactly the target epoch-two business message is emitted in the selected witness trace.",
    "logical_relation": "Any satisfying trace implies the prior confirmed/ordered witness and the full original normal two-round witness by dropping the additional conjuncts.",
    "no_protocol_round_cap_or_new_trace_restriction": True,
    "not_a_universal_secrecy_proof": True,
})
print("Idle witness parsed with the complete original witness retained")
