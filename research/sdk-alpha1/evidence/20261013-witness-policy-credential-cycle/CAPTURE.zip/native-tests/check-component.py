from pathlib import Path
import hashlib,json,subprocess,datetime
import rust_sdk_profile as sdk
root=Path.cwd(); stage=root/'target/continuity-witness-policy-credential-cycle'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines()
    return {n:sha(root/n) for n in sorted(set(names)) if (n.startswith(('crates/','research/continuity-identity-candidate/')) and (n.endswith('.rs') or Path(n).name in ('Cargo.toml','Cargo.lock'))) or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml')}
before=sources()
raw=sdk.command(['sh','target/continuity-browser-credential-renewal/cargo.sh','test','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--locked','--offline','--lib','--target-dir',str(stage/'native-target'),'--no-run','--message-format=json'],stage/'component-compile',root)
executables=[]
for line in raw.decode().splitlines():
    v=json.loads(line)
    if v.get('reason')=='compiler-artifact' and v.get('profile',{}).get('test') and v.get('executable'):executables.append(Path(v['executable']))
sdk.require(len(executables)==1,'ambiguous test executable');exe=executables[0];digest=sha(exe)
sdk.require(sources()==before,'inputs changed during compile')
out=sdk.command([str(exe),'retained_policy_credential_'],stage/'component-tests',root).decode()
sdk.require('7 passed; 0 failed; 0 ignored' in out,'unexpected component test result')
sdk.require(sources()==before and sha(exe)==digest,'inputs changed during test execution')
record={'completed':True,'full_goal_complete':False,'scope':'witness component only; original enrollment P-to-G staging regression remains unresolved','source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_inputs':before,'executable':str(exe),'executable_sha256':digest,'test_count':7,'actual_kill_cuts':4,'validity_clock':'explicit fixture logical timestamps; no wall-clock expiry claim','source_and_executable_unchanged':True,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
sdk.write_json(stage/'WITNESS_COMPONENT_RESULT.json',record)
print(json.dumps({k:record[k] for k in ['completed','full_goal_complete','test_count','actual_kill_cuts','source_and_executable_unchanged']}))
