from pathlib import Path
b=Path('research/continuity-identity-candidate/src')
def rep(f,a,c,n=1):
 p=b/f;s=p.read_text();assert s.count(a)==n,(f,s.count(a),a[:80]);p.write_text(s.replace(a,c))
f='enrollment/renewal.rs'
rep(f,'''        self.witness.is_none()
            && self
                .pending
                .as_ref()
                .is_none_or(|p| !policy_pending && p.continuation.is_none())''','''        !policy_pending && !self.joint()''')
rep(f,'''            if policy.anchor_requirement().binding().is_some() {
                return Err(DurableError::AnchorRequired);
            }
            approval.check_target(policy)?;''','''            if policy.anchor_requirement().binding().is_some()
                && (!image.policy_coordination_retired() || image.policy_witness.is_none()) {
                return Err(DurableError::Suspended);
            }
            approval.check_target(policy)?;''')
rep(f,'''    pub(super) fn decode(
        d: &mut Decoder<'_>,
        extended: bool,
        witnessed: bool,
        cancellation: bool,
        joint: bool,
        policy_coordination: bool,
        policy_cancellation: bool,
    ) -> Result<Self, DurableError> {
        let (extended, witnessed, cancellation)''','''    pub(super) fn decode(d: &mut Decoder<'_>, format: RenewalEncoding) -> Result<Self, DurableError> {
        let RenewalEncoding { extended, witnessed, cancellation, joint, policy_coordination, policy_cancellation, independent_policy } = format;
        let (extended, witnessed, cancellation)''')
rep(f,'''                    policy_cancellation,
                )?)''','''                    policy_cancellation,
                    independent_policy,
                )?)''')
rep(f,'pub(super) struct LocalRenewal {','''pub(super) struct RenewalEncoding {
    pub(super) extended: bool,
    pub(super) witnessed: bool,
    pub(super) cancellation: bool,
    pub(super) joint: bool,
    pub(super) policy_coordination: bool,
    pub(super) policy_cancellation: bool,
    pub(super) independent_policy: bool,
}
pub(super) struct LocalRenewal {''')
f='enrollment.rs'
rep(f,'    fn require_no_policy_renewal(&self) -> Result<(), DurableError> {','''    fn witnessed_credential_after_policy(&self) -> bool {
        self.policy_device_binding == PolicyDeviceBinding::CredentialRenewal
            && self.policy_witness.is_some() && self.renewal.as_ref().is_some_and(LocalRenewal::witnessed)
    }
    fn require_no_policy_renewal(&self) -> Result<(), DurableError> {''')
# Separate admission boundary, do not loosen other call sites of require_no_policy_renewal.
rep(f,'    fn validate_policy_phase(&self) -> Result<(), DurableError> {','''    fn require_credential_policy_retired(&self) -> Result<(), DurableError> {
        self.require_roster_retired()?;
        if self.policy_completed.is_none() { return self.require_no_policy_renewal(); }
        if self.policy_pending.is_some() || self.policy_witness.is_none() || !self.policy_coordination_retired() {
            return Err(DurableError::Suspended);
        }
        Ok(())
    }
    fn validate_policy_phase(&self) -> Result<(), DurableError> {''')
rep(f,'''        if self.policy_device_binding == PolicyDeviceBinding::CredentialRenewal
            && self.renewal.is_none()''','''        if self.policy_device_binding == PolicyDeviceBinding::CredentialRenewal
            && (self.renewal.is_none() || (self.renewal.as_ref().is_some_and(LocalRenewal::witnessed)
                && self.policy_witness.is_none()))''')
rep(f,'    bytes.extend_from_slice(&binding);\n    bytes.extend_from_slice(image.identity.as_bytes());','''    if image.witnessed_credential_after_policy() {
        let mut wrapper = b"QPENST18".to_vec(); wrapper.extend_from_slice(&bytes); bytes = wrapper;
    }
    bytes.extend_from_slice(&binding);
    bytes.extend_from_slice(image.identity.as_bytes());''')
rep(f,'    let tag = d.array::<8>()?;\n    let has_roster_witness', '''    let tag = d.array::<8>()?;
    let credential_after_policy = tag == *b"QPENST18";
    let tag = if credential_after_policy { d.array::<8>()? } else { tag };
    let has_roster_witness''')
rep(f,'''            tag != *b"QPENST02",
            tag == *b"QPENST04" || tag == *b"QPENST05",
            tag == *b"QPENST05",
            [*b"QPENST06", *b"QPENST07", *b"QPENST08"].contains(&tag),
            tag == *b"QPENST07" || tag == *b"QPENST08",
            tag == *b"QPENST08",
        )?)''','''            renewal::RenewalEncoding {
                extended: tag != *b"QPENST02",
                witnessed: tag == *b"QPENST04" || tag == *b"QPENST05",
                cancellation: tag == *b"QPENST05",
                joint: [*b"QPENST06", *b"QPENST07", *b"QPENST08"].contains(&tag),
                policy_coordination: tag == *b"QPENST07" || tag == *b"QPENST08",
                policy_cancellation: tag == *b"QPENST08",
                independent_policy: credential_after_policy,
            },
        )?)''')
rep(f,'    image.validate_policy_phase()?;\n    Ok(image)','''    image.validate_policy_phase()?;
    if image.witnessed_credential_after_policy() != credential_after_policy { return Err(DurableError::Corrupt); }
    Ok(image)''')
f='enrollment/policy_renewal/witness.rs'
rep(f,'''            .is_some_and(|r| !r.permits_witness_policy())
            || image.policy_resolution.is_some()''','''            .is_some_and(|r| !r.permits_witness_policy()
                && !(image.witnessed_credential_after_policy() && self.completed.is_some()
                    && image.policy_coordination_retired() && r.permits_policy_credential(image.policy_pending.is_some())))
            || image.policy_resolution.is_some()''')
rep(f,'            || image.policy_device_binding == PolicyDeviceBinding::CredentialRenewal\n', '',2)
rep(f,'''            .is_some_and(|r| !r.permits_witness_policy())
            || admission.policy''','''            .is_some_and(|r| !r.permits_witness_policy()
                && !(image.witnessed_credential_after_policy() && image.policy_coordination_retired()
                    && r.permits_policy_credential(image.policy_pending.is_some())))
            || admission.policy''')
f='enrollment/policy_renewal/witness/operational.rs'
rep(f,'        approval.check_credential_lineage(&original, &current)?;', '        self.check_completed_policy_identity(image, &approval, &original, &current)?;')
rep(f,'''        if image.policy_pending.is_some()
            || image''','''        if image.policy_pending.is_some()
            || image.renewal.as_ref().is_some_and(|r| !r.permits_policy_pending())
            || image''')
f='enrollment/renewal/witness.rs'
rep(f,'self.image_without_policy_renewal()?','self.image_for_witnessed_credential()?',13)
rep(f,'impl DeviceEnrollment {\n    /// Build a historical renewal carrier','''impl DeviceEnrollment {
    fn image_for_witnessed_credential(&self) -> Result<Image, DurableError> {
        let image = self.image()?; image.require_credential_policy_retired()?; Ok(image)
    }
    /// Build a historical renewal carrier''')
rep(f,'''out.push(if p.policy_continuation().is_some() {''','''out.push(if p.policy_renewal().is_some() { 5 } else if p.policy_continuation().is_some() {''')
rep(f,'''out.push(if c.policy_continuation().is_some() {''','''out.push(if c.policy_renewal().is_some() { 6 } else if c.policy_continuation().is_some() {''')
rep(f,'        policy_cancellation: bool,\n    ) -> Result<Self, DurableError> {','        policy_cancellation: bool,\n        independent_policy: bool,\n    ) -> Result<Self, DurableError> {')
rep(f,'[kind @ 1..=4]', '[kind @ 1..=6]')
rep(f,'                    || (kind == 4 && policy_cancellation) =>','                    || (kind == 4 && policy_cancellation)\n                    || ((kind == 5 || kind == 6) && independent_policy) =>')
rep(f,'intent: if kind == 1 || kind == 3 {','intent: if kind == 1 || kind == 3 || kind == 5 {')
rep(f,'d.take(if kind == 3 { 329 } else { 296 })?', 'd.take(if kind == 1 { 296 } else { 329 })?')
rep(f,'d.take(if kind == 4 { 281 } else { 248 })?', 'd.take(if kind == 2 { 248 } else { 281 })?')
# Cross-kind metadata cannot be smuggled under the old enrollment container.
rep(f,'        if cancellation\n            != coordination','''        if coordination.is_some_and(|c| match c.intent {
            WitnessedCredentialIntent::Proposal(p) => p.policy_renewal().is_some() && !independent_policy,
            WitnessedCredentialIntent::Cancellation(c) => c.policy_renewal().is_some() && !independent_policy,
        }) { return Err(DurableError::Corrupt); }
        if cancellation
            != coordination''')
# Require the independent P digest on every original G intent, in addition to any T.
rep(f,'        match intent {\n            WitnessedCredentialIntent::Proposal(p)','''        let independent = self.completed_policy_approval(image)?.map(|p| p.statement_digest());
        match intent {
            WitnessedCredentialIntent::Proposal(p)''')
rep(f,'                    && p.adopts_policy() == pending.continuation.is_some() =>','                    && p.policy_renewal() == independent\n                    && p.adopts_policy() == pending.continuation.is_some() =>')
rep(f,'                    && c.adopts_policy() == pending.continuation.is_some() =>','                    && c.policy_renewal() == independent\n                    && c.adopts_policy() == pending.continuation.is_some() =>')
# Prepare with private original-enrollment completion attached to the same journal.
rep(f,'''                journal
                    .prepare_enrollment_renewal(''','''                let independent = self.completed_policy_approval(&image)?;
                if let Some(completion) = if independent.is_some() {
                    self.policy_enrollment_completion(&image, original_policy)?
                } else { None } { journal.retain_enrollment_policy_completion(completion).await?; }
                journal
                    .prepare_enrollment_renewal(''')
rep(f,'''                            policy_renewal: None,
                            grant: &grant,''','''                            policy_renewal: independent.as_ref().map(|p| (p, &original)),
                            grant: &grant,''')
rep(f,'''                    } else if policy.checkpoint() != current.checkpoint() {''','''                    } else if let Some(p) = self.completed_policy_approval(&image)? {
                        p.check_context_policy(policy, current)?;
                        p.check_renewed_identity(&original, &grant)?;
                    } else if policy.checkpoint() != current.checkpoint() {''')
