from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-witness-policy-credential-cycle';target=stage/'native-target'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True).splitlines()
 return {n:sha(root/n) for n in sorted(set(names)) if ((n.startswith(('crates/','research/continuity-identity-candidate/')) and (n.endswith('.rs') or Path(n).name in ['Cargo.toml','Cargo.lock'])) or n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'])}
before=sources()
raw=sdk.command(['sh','target/continuity-browser-credential-renewal/cargo.sh','test','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--target-dir',str(target),'--lib','--no-run','--message-format=json','-j2'],stage/'device-qualified-compile',root)
executables=[]
for line in raw.decode().splitlines():
 v=json.loads(line)
 if v.get('reason')=='compiler-artifact' and v.get('profile',{}).get('test') and v.get('executable'):executables.append(Path(v['executable']).resolve())
sdk.require(len(executables)==1,'ambiguous unit-test executable');executable=executables[0]
sdk.require(executable.is_relative_to(target.resolve()),'test executable escaped dedicated target')
sdk.require(sources()==before,'source changed during compilation');digest=sha(executable)
record={'completed':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executable':str(executable),'executable_sha256':digest,'source_inputs':before,'argv':[str(executable)],'timeout_seconds':900,'qualification':'entire candidate lib test binary; no fixture/alternate source builds may use this target'}
with (stage/'device-all-lib-qualified.log').open('xb') as out:
 process=subprocess.Popen([str(executable)],cwd=root,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 record['pid']=process.pid;sdk.write_json(stage/'DEVICE_QUALIFIED_NATIVE_RUNNING.json',record)
 print(json.dumps({'pid':process.pid,'executable':str(executable),'sha256':digest}),flush=True)
 deadline=time.monotonic()+900
 try:
  while True:
   try:status=process.wait(timeout=min(10,max(0.1,deadline-time.monotonic())));break
   except subprocess.TimeoutExpired:
    if time.monotonic()>=deadline:
     os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10);record['timed_out']=True;status=124;break
 finally:
  if process.poll() is None:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10)
record['exit_status']=status;record['source_unchanged']=sources()==before;record['executable_unchanged']=sha(executable)==digest
record['completed']=status==0 and record['source_unchanged'] and record['executable_unchanged'];record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();sdk.write_json(stage/'DEVICE_QUALIFIED_NATIVE_RESULT.json',record)
print(json.dumps({k:record[k] for k in ['completed','exit_status','source_unchanged','executable_unchanged']}),flush=True)
raise SystemExit(0 if record['completed'] else 1)
