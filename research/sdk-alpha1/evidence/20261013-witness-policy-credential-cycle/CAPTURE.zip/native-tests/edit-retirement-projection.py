from pathlib import Path
b=Path('research/continuity-identity-candidate/src')
def rep(f,a,c,n=1):
 p=b/f;s=p.read_text();assert s.count(a)==n,(f,s.count(a),a[:80]);p.write_text(s.replace(a,c))
rep('enrollment/renewal.rs','        !policy_pending && !self.joint()', '''        !self.joint() && self.pending.as_ref().is_none_or(|p| !policy_pending && p.continuation.is_none())''')
f='durable/retired_report.rs'
rep(f,'    /// Independent policy-only renewal.\n    Policy {','''    /// Credential renewal retaining an already adopted independent policy.
    CredentialUnderPolicy {
        /// Original credential operation identity.
        operation: [u8; 32],
        /// Signed credential authorization statement.
        statement: [u8; 32],
        /// Exact retained independent policy statement, never a new adoption.
        policy: [u8; 32],
    },
    /// Independent policy-only renewal.
    Policy {''')
rep(f,'tag == b"QPRDMD01" || tag == b"QPRDMD02"','tag == b"QPRDMD01" || tag == b"QPRDMD02" || tag == b"QPRDMD03"')
rep(f,'    let mut out = Encoder(\n        if publication {','''    let independent = matches!(intent, Intent::Write { transaction: Transaction::CredentialUnderPolicy { .. }, .. })
        || matches!(intent, Intent::Cancellation(wire) if wire.starts_with(b"QPCRNC03"));
    let mut out = Encoder(
        if independent { b"QPRDMD03" } else if publication {''')
rep(f,'                Transaction::Policy {\n                    operation,','''                Transaction::CredentialUnderPolicy { operation, statement, policy } => {
                    out.byte(4); out.raw(operation); out.raw(statement); out.raw(policy);
                }
                Transaction::Policy {
                    operation,''')
f='durable/write_intent/retired_cleanup.rs'
rep(f,'                    Some(BoundTransaction::Credential(binding)) => Transaction::Credential {','''                    Some(BoundTransaction::Credential(RenewalBinding { operation, credential, policy: Some(PolicyIntent::RetainIndependent(policy)) })) => Transaction::CredentialUnderPolicy {
                        operation: *operation.as_bytes(), statement: credential, policy,
                    },
                    Some(BoundTransaction::Credential(binding)) => Transaction::Credential {''')
# These validators retain opaque report bytes, check the inventory and compare original digests.
for name in ['continuity_android_retirement.py','continuity_android_root.py','continuity_device_retirement.py','test_continuity_device_retirement.py']:
 p=Path('artifact')/name;s=p.read_text()
 if name=='test_continuity_device_retirement.py':s=s.replace("b'QPRDMD03' + body", "b'QPRDMD04' + body")
 s=s.replace("b'QPRDMD01', b'QPRDMD02'", "b'QPRDMD01', b'QPRDMD02', b'QPRDMD03'")
 s=s.replace('b"QPRDMD01", b"QPRDMD02"', 'b"QPRDMD01", b"QPRDMD02", b"QPRDMD03"')
 p.write_text(s)
