from pathlib import Path
p=Path('research/continuity-identity-candidate/src/anchor/store/renewal.rs')
s=p.read_text()
def rep(a,b,n=1):
 global s
 assert s.count(a)==n,(s.count(a),a[:90])
 s=s.replace(a,b)
rep('self.close_unprepared_renewal(cancellation, grant, policy, None)', 'self.close_unprepared_renewal(cancellation, grant, policy, None, None)')
rep('            Some((&checked, materials.target)),\n        )', '            Some((&checked, materials.target)),\n            None,\n        )')
rep('            Some((retained, policy)),\n        )', '            Some((retained, policy)),\n            None,\n        )')
rep('''        )>,
    ) -> Result<AnchorCredentialCancellationState, DurableError> {
        if cancellation.policy_renewal().is_some() {
            return Err(DurableError::Conflict);
        }''', '''        )>,
        retained_policy: Option<&HistoricalSessionPolicy>,
    ) -> Result<AnchorCredentialCancellationState, DurableError> {''')
rep('''        if entry.independent_policy.is_some() || entry.independent_roster.is_some() {
            return Err(DurableError::Conflict);
        }
        let target = match continuation {''', '''        if entry.independent_roster.is_some() {
            return Err(DurableError::Conflict);
        }
        let target = if let Some(policy) = retained_policy {
            if continuation.is_some() || cancellation.adopts_policy() {
                return Err(DurableError::Conflict);
            }
            Some(entry.retained_independent_policy(
                cancellation.policy_renewal().ok_or(DurableError::Conflict)?, policy,
            )?)
        } else {
            if entry.independent_policy.is_some() || cancellation.policy_renewal().is_some() {
                return Err(DurableError::Conflict);
            }
        match continuation {''')
rep('''        if let Some(record) = &entry.renewal {
            return if matches!(record, CredentialRenewalRecord::GrantClosed''','''        };
        if let Some(record) = &entry.renewal {
            return if matches!(record, CredentialRenewalRecord::GrantClosed''')
# End match returns a value rather than unit.
rep('''            _ => return Err(DurableError::Conflict),
        };
        };
        if let Some(record)''', '''            _ => return Err(DurableError::Conflict),
        }
        };
        if let Some(record)''')
rep('''        entry.renewal = Some(CredentialRenewalRecord::GrantClosed {''', '''        if retained_policy.is_some() {
            entry.independent_policy.as_mut().ok_or(DurableError::Conflict)?.credential_after = true;
        }
        entry.renewal = Some(CredentialRenewalRecord::GrantClosed {''')
p.write_text(s)
