from pathlib import Path
b=Path('research/continuity-identity-candidate/src')
def rep(f,a,c,n=1):
 p=b/f;s=p.read_text();assert s.count(a)==n,(f,s.count(a),a[:80]);p.write_text(s.replace(a,c))
f='durable/write_intent/credential_cancellation.rs'
rep(f,'    pub(crate) fn proposal(self) -> Result<Proposal, DurableError> {','''    pub(crate) fn policy_renewal(self) -> Option<[u8; 32]> {
        match self { Self::Proposal(p) => p.policy_renewal(), Self::Cancellation(c) => c.policy_renewal() }
    }
    pub(crate) fn proposal(self) -> Result<Proposal, DurableError> {''')
rep(f,"    pub(crate) completed: Option<&'a LocalRenewalCommit>,", "    pub(crate) completed: Option<&'a LocalRenewalCommit>,\n    pub(crate) independent: Option<&'a crate::enrollment::EnrollmentPolicyCompletion>,")
rep(f,'        let mut wire = if cancellation.policy_continuation().is_some() {','        let mut wire = if cancellation.policy_renewal().is_some() { b"QPWINT09" } else if cancellation.policy_continuation().is_some() {')
rep(f,'if (tag != *b"QPWINT03" || wire.len() != 320) && (tag != *b"QPWINT05" || wire.len() != 353)','if (tag != *b"QPWINT03" || wire.len() != 320) && (!matches!(&tag, b"QPWINT05" | b"QPWINT09") || wire.len() != 353)')
rep(f,'d.take(if tag == *b"QPWINT05" {','d.take(if tag != *b"QPWINT03" {')
rep(f,'        d.finish()?;\n        Ok(Self {','''        d.finish()?;
        if cancellation.policy_renewal().is_some() != (tag == *b"QPWINT09")
            || cancellation.policy_continuation().is_some() != (tag == *b"QPWINT05") {
            return Err(DurableError::Corrupt);
        }
        Ok(Self {''')
rep(f,'        Ok(())\n    }\n}\n\npub(super) fn check_scope','''        rosters::check_credential_policy_binding(image, self.cancellation.policy_renewal())?;
        Ok(())
    }
}

pub(super) fn check_scope''')
rep(f,'                completed,\n            },','                completed,\n                independent: None,\n            },')
rep(f,'        rosters::check_policy_cancellation(&image, grant, target.continuation, target.adopts)?;','''        rosters::check_policy_cancellation(&image, grant, target.continuation, target.adopts)?;
        let independent = target.independent;
        if let Some(completion) = independent {
            if target.continuation.is_some() || target.adopts { return Err(DurableError::Conflict); }
            rosters::check_enrollment_policy_completion(&image, completion)?;
        }
        rosters::check_credential_policy_binding(&image, independent.map(|p| p.approval().statement_digest()))?;''')
rep(f,'            None => base,\n        };','''            None => match independent {
                Some(p) => base.with_retained_policy_renewal(p.approval())?,
                None => base,
            },
        };''')
f='durable/rosters.rs'
rep(f,'pub(super) fn check_policy_cancellation(','''pub(super) fn check_credential_policy_binding(image: &Image, expected: Option<[u8; 32]>) -> Result<(), DurableError> {
    let saved = get(image, &image.local_account)?;
    if saved.policy_renewal.as_ref().map(|p| p.policy_binding().1) != expected {
        return Err(DurableError::Conflict);
    }
    Ok(())
}
pub(super) fn check_policy_cancellation(''')
f='durable/rosters/policy_renewal.rs'
rep(f,'            policy == s.original_policy.digest()\n                && saved.policy_continuation.is_none()', '            policy == s.original_policy.digest()\n                && current.phase == ReceiptPhase::AwaitingEnrollment\n                && saved.policy_continuation.is_none()')
f='enrollment/renewal.rs'
rep(f,'    adopted_policy: Option<[u8; 32]>,','    adopted_policy: Option<[u8; 32]>,\n    independent_policy: Option<[u8; 32]>,')
rep(f,'impl PersistedRenewalTerminal {','impl PersistedRenewalTerminal {\n    pub(crate) fn policy_renewal(&self) -> Option<[u8; 32]> { self.independent_policy }')
f='enrollment/renewal/witness.rs'
rep(f,'            intent: proposal,\n            state: coord.terminal', '            intent: proposal,\n            independent_policy: self.completed_policy_approval(&image)?.map(|p| p.statement_digest()),\n            state: coord.terminal')
rep(f,'                if p.policy_continuation() != adopted.as_ref().map(|t| t.statement_digest()) {','''                if p.policy_continuation() != adopted.as_ref().map(|t| t.statement_digest())
                    || p.policy_renewal() != self.completed_policy_approval(image)?.map(|p| p.statement_digest()) {''')
rep(f,'''        let cancellation = self
            .reserve_original_credential_cancellation(''','''        let independent = if image.policy_completed.is_some() {
            self.policy_enrollment_completion(&image, policy)?
        } else { None };
        let cancellation = self
            .reserve_original_credential_cancellation(''')
rep(f,'                    completed: renewal.completed.as_ref(),\n                },','                    completed: renewal.completed.as_ref(),\n                    independent: independent.as_deref(),\n                },')
f='enrollment/renewal/storage.rs'
rep(f,'        if target.continuation.is_some() {','        if target.continuation.is_some() || target.independent.is_some() {')
f='anchor/store/retired_cleanup_tests.rs'
rep(f,'                completed: None,\n            },','                completed: None,\n                independent: None,\n            },')
f='durable/write_intent.rs'
rep(f,'        rosters::check_terminal_completion(&image, adopted_policy, terminal.completed())?;','''        rosters::check_terminal_completion(&image, adopted_policy, terminal.completed())?;
        if proposal.policy_renewal() != terminal.policy_renewal() { return Err(DurableError::Conflict); }
        rosters::check_credential_policy_binding(&image, terminal.policy_renewal())?;''')
