from pathlib import Path
base = Path('research/continuity-identity-candidate/src/anchor')
def edit(path, old, new, count=1):
    p=base/path; s=p.read_text(); n=s.count(old)
    if n != count: raise RuntimeError((str(path), n, old[:100]))
    p.write_text(s.replace(old,new))
edit(Path('store/image_version.rs'), '    V18,', '    V18,\n    V19,')
edit(Path('store/image_version.rs'), '            b"QPANC018" => Ok(Self::V18),', '            b"QPANC018" => Ok(Self::V18),\n            b"QPANC019" => Ok(Self::V19),')
edit(Path('store/policy_renewal.rs'), '    pub(super) current: Option<PolicyAuthority>,', '    pub(super) current: Option<PolicyAuthority>,\n    // Sticky format discriminator: later G must never erase independently adopted P.\n    pub(super) credential_after: bool,')
edit(Path('store/policy_renewal.rs'), '                out.push(1);\n                p.encode(out);', '                out.push(if self.credential_after { 2 } else { 1 });\n                p.encode(out);')
edit(Path('store/policy_renewal.rs'), "    pub(super) fn decode(d: &mut Decoder<'_>) -> Result<Self, DurableError> {", "    pub(super) fn decode(d: &mut Decoder<'_>, credential_format: bool) -> Result<Self, DurableError> {")
edit(Path('store/policy_renewal.rs'), '''        let current = match d.array::<1>()? {
            [0] => None,
            [1] => Some(PolicyAuthority::decode(d)?),
            _ => return Err(DurableError::Corrupt),
        };''', '''        let (current, credential_after) = match d.array::<1>()? {
            [0] => (None, false),
            [1] => (Some(PolicyAuthority::decode(d)?), false),
            [2] if credential_format => (Some(PolicyAuthority::decode(d)?), true),
            _ => return Err(DurableError::Corrupt),
        };''')
edit(Path('store/policy_renewal.rs'), '            current,\n            floor,', '            current,\n            credential_after,\n            floor,')
edit(Path('store/policy_renewal.rs'), '''        // A retired plain G may precede P; live G/T coordination remains excluded.
        if self.renewal.is_some()
            || self.credential_authorization.is_some()''', '''        // Only an exact retained-P G may coexist with an acknowledged P.
        if (self.renewal.is_some()
            && (!s.credential_after || s.record.is_some()
                || self.renewal.as_ref().and_then(CredentialRenewalRecord::independent_policy)
                    != s.current.map(|p| p.statement)))
            || (s.credential_after && (s.current.is_none()
                || (self.renewal_floor == 0 && self.renewal.is_none())))
            || self.credential_authorization.is_some()''')
edit(Path('store.rs'), '    let closure_format = credential_policy_format || !image.account_closures.is_empty();', '''    let policy_credential_format = image.entries.values().any(|e| {
        e.independent_policy.as_ref().is_some_and(|p| p.credential_after)
    });
    let closure_format = credential_policy_format || !image.account_closures.is_empty();''')
edit(Path('store.rs'), '    let mut bytes = if credential_policy_format {', '    let mut bytes = if policy_credential_format {\n        b"QPANC019".to_vec()\n    } else if credential_policy_format {')
edit(Path('store.rs'), '                    [1] => Some(PolicyRenewal::decode(&mut d)?),', '                    [1] => Some(PolicyRenewal::decode(&mut d, version >= ImageVersion::V19)?),')
edit(Path('store/renewal.rs'), 'impl CredentialRenewalRecord {', '''impl CredentialRenewalRecord {
    pub(super) fn independent_policy(&self) -> Option<[u8; 32]> {
        match self {
            Self::Joint(r) => r.proposal.policy_renewal(),
            Self::GrantClosed { cancellation, .. } => cancellation.policy_renewal(),
        }
    }''')
edit(Path('store/renewal.rs'), '''            if cancellation.policy_continuation() != policy.map(|p| p.statement) {''', '''            if cancellation.policy_continuation().or(cancellation.policy_renewal())
                != policy.map(|p| p.statement) {''')
edit(Path('store/renewal.rs'), '''            match policy {
                None if self.policy_authorization.is_none()''', '''            match policy {
                Some(p) if cancellation.policy_renewal() == Some(p.statement)
                    && self.independent_policy.as_ref().and_then(|s| s.current) == Some(*p)
                    && !cancellation.adopts_policy() => {}
                None if self.policy_authorization.is_none()''')
edit(Path('store/renewal.rs'), '            if proposal.policy_continuation() != record.policy.map(|p| p.statement)', '            if proposal.policy_continuation().or(proposal.policy_renewal()) != record.policy.map(|p| p.statement)')
edit(Path('store/renewal.rs'), '                let valid = match record.phase {', '''                let valid = if proposal.policy_renewal().is_some() {
                    !proposal.adopts_policy()
                        && self.independent_policy.as_ref().and_then(|s| s.current) == Some(policy)
                } else { match record.phase {''')
edit(Path('store/renewal.rs'), '''                    Phase::Prepared | Phase::Closed => self.policy_authorization == Some(policy),
                };''', '''                    Phase::Prepared | Phase::Closed => self.policy_authorization == Some(policy),
                }};''')
edit(Path('store/renewal.rs'), '                    if let Some(policy) = record.policy {', '                    if let Some(policy) = record.policy.filter(|_| record.proposal.policy_renewal().is_none()) {')
edit(Path('store/renewal.rs'), '''        if entry.independent_policy.is_some()
            || entry.independent_roster.is_some()''', '''        if entry.independent_policy.as_ref().is_some_and(|s| s.pending())
            || entry.independent_roster.is_some()''')
edit(Path('store/renewal.rs'), '''                    entry
                        .policy_authorization
                        .map_or(policy.validity(), |p| p.validity),''', '''                    entry.independent_policy.as_ref().and_then(|s| s.current)
                        .or(entry.policy_authorization)
                        .map_or(policy.validity(), |p| p.validity),''')
# Only the proposal path here; cancellation is extended separately.
edit(Path('store/renewal.rs'), '''        if entry.independent_policy.is_some() || entry.independent_roster.is_some() {
            return Err(DurableError::Conflict);
        }
        match proposal.policy_continuation() {''', '''        if entry.independent_roster.is_some() {
            return Err(DurableError::Conflict);
        }
        if let Some(statement) = proposal.policy_renewal() {
            if continuation.is_some() || proposal.adopts_policy() {
                return Err(DurableError::Conflict);
            }
            record.policy = Some(entry.retained_independent_policy(statement, target_policy)?);
        } else {
            if entry.independent_policy.is_some() {
                return Err(DurableError::Conflict);
            }
        match proposal.policy_continuation() {''')
edit(Path('store/renewal.rs'), '''        if let Some(saved) = &entry.renewal {''', '''        }
        if let Some(saved) = &entry.renewal {''')
edit(Path('store/renewal.rs'), '''        entry.renewal = Some(CredentialRenewalRecord::Joint(record));''', '''        if proposal.policy_renewal().is_some() {
            entry.independent_policy.as_mut().ok_or(DurableError::Conflict)?.credential_after = true;
        }
        entry.renewal = Some(CredentialRenewalRecord::Joint(record));''')
# Keep unsupported cancellation from accidentally accepting independent P as plain G.
edit(Path('store/renewal.rs'), '''        let scope = RenewalScope::from(&cancellation);
        self.check_renewal_scope''', '''        if cancellation.policy_renewal().is_some() {
            return Err(DurableError::Conflict);
        }
        let scope = RenewalScope::from(&cancellation);
        self.check_renewal_scope''')
edit(Path('store/renewal.rs'), '// Authenticated witness control-plane metadata', 'mod independent_policy;\n\n// Authenticated witness control-plane metadata')
