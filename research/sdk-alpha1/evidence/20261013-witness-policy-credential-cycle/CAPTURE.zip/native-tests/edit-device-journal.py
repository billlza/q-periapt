from pathlib import Path
b=Path('research/continuity-identity-candidate/src')
def rep(f,a,c,n=1):
 p=b/f;s=p.read_text();assert s.count(a)==n,(f,s.count(a),a[:80]);p.write_text(s.replace(a,c))
f='durable/write_intent.rs'
rep(f,'    Retain([u8; 32]),','    Retain([u8; 32]),\n    RetainIndependent([u8; 32]),')
rep(f,'Self::Adopt(s) | Self::Retain(s) => s,','Self::Adopt(s) | Self::Retain(s) | Self::RetainIndependent(s) => s,')
rep(f,'    pub(super) fn adopts(self) -> bool {','    pub(super) fn independent(self) -> bool { matches!(self, Self::RetainIndependent(_)) }\n    pub(super) fn adopts(self) -> bool {')
rep(f,'            Some(BoundTransaction::Credential(r)) if r.policy.is_some() => b"QPWINT04".to_vec(),','''            Some(BoundTransaction::Credential(r)) if r.policy.is_some_and(PolicyIntent::independent) => b"QPWINT08".to_vec(),
            Some(BoundTransaction::Credential(r)) if r.policy.is_some() => b"QPWINT04".to_vec(),''')
rep(f,'tag if tag == *b"QPWINT02" || tag == *b"QPWINT04" => {','tag if matches!(&tag, b"QPWINT02" | b"QPWINT04" | b"QPWINT08") => {')
rep(f,'let policy = if tag == *b"QPWINT04" {','let policy = if tag != *b"QPWINT02" {')
rep(f,'                        0 => PolicyIntent::Retain(statement),\n                        1 => PolicyIntent::Adopt(statement),','''                        0 if tag == *b"QPWINT08" => PolicyIntent::RetainIndependent(statement),
                        0 => PolicyIntent::Retain(statement),
                        1 if tag == *b"QPWINT04" => PolicyIntent::Adopt(statement),''')
rep(f,'        Ok(match binding.policy {\n            Some(policy) => {','''        Ok(match binding.policy {
            Some(PolicyIntent::RetainIndependent(statement)) => proposal.bind_independent_policy_expectation(statement)?,
            Some(policy) => {''')
rep(f,'if bytes.value().starts_with(b"QPWINT03") || bytes.value().starts_with(b"QPWINT05") {','if bytes.value().starts_with(b"QPWINT03") || bytes.value().starts_with(b"QPWINT05") || bytes.value().starts_with(b"QPWINT09") {')
f='durable/rosters/local_renewal.rs'
rep(f,'if self.continuation.is_some() || image.protection != Protection::Local {','if self.continuation.is_some() {')
rep(f,'        let policy_intent = updated.policy_continuation.as_ref().map(|t| {','''        let policy_intent = if let Some((approval, _)) = target.policy_renewal {
            Some(write_intent::PolicyIntent::RetainIndependent(approval.statement_digest()))
        } else { updated.policy_continuation.as_ref().map(|t| {''')
rep(f,'                write_intent::PolicyIntent::Retain(t.statement_digest())\n            }\n        });','                write_intent::PolicyIntent::Retain(t.statement_digest())\n            }\n        }) };')
f='durable/rosters/policy_renewal.rs'
rep(f,'                Ok(b"QPRHST06")\n            }','''                Ok(b"QPRHST06")
            }
            Some(grant) if grant.successor_device().credential_digest() != self.approval.scope().current_credential
                && self.phase == ReceiptPhase::AwaitingEnrollment => Ok(b"QPRHST09"),''')
rep(f,'b"QPRHST06" | b"QPRHST08"','b"QPRHST06" | b"QPRHST08" | b"QPRHST09"')
rep(f,'            && !credential_precedes_policy(image, saved, &retained.approval))','''            && !credential_precedes_policy(image, saved, &retained.approval)
            && !credential_follows_policy(image, saved, retained))''')
# Required protection carries a cryptographically checked original-root G independently of P ordering.
rep(f,'''                    || current.carried_grant.as_ref().is_some_and(|g| {
                        g.successor_device().credential_digest() == s.current_credential
                    }))''','''                    || current.carried_grant.is_some())''')
rep(f,'''        if (current.phase != ReceiptPhase::Acknowledged
            && device.credential_digest() != s.current_credential)
            || grant.original_storage_owner() != image.owner''','''        if grant.original_storage_owner() != image.owner''')
rep(f,'''        || retained.phase != ReceiptPhase::Acknowledged''','''        || !completion_acknowledged(image, retained)?''')
rep(f,'''    let current = credential(image, &saved, original, approval)?;
    approval.check_credential_lineage(original, current)?;''','''    // credential() checks exact P lineage, or the original-root G retained after P.
    credential(image, &saved, original, approval)?;''')
# A retained completed G may carry P, while its exact receipt remains pending for enrollment.
rep(f,"pub(super) fn adopted<'a>(",'''fn credential_follows_policy(image: &Image, saved: &Stored, retained: &StoredPolicyRenewal) -> bool {
    matches!(image.protection, Protection::Required { .. })
        && retained.carried_grant.as_ref().is_some_and(|g| {
            g.successor_device().credential_digest() != retained.approval.scope().current_credential
                && saved.local_commit.as_ref() == Some(&LocalRenewalCommit::for_grant(g))
        })
}

pub(super) fn adopted<'a>(''')
f='durable/rosters.rs'
rep(f,'b"QPRHST05" | b"QPRHST06" | b"QPRHST08"','b"QPRHST05" | b"QPRHST06" | b"QPRHST08" | b"QPRHST09"')
rep(f,'        (None, None) => None,','''        (Some(write_intent::PolicyIntent::RetainIndependent(statement)), None) => {
            let retained = saved.policy_renewal.as_ref().ok_or(DurableError::Conflict)?;
            if retained.policy_binding().1 != statement || retained.carried_grant.as_ref().is_none_or(|g|
                g.operation() != binding.operation || g.statement_digest() != binding.credential) {
                return Err(DurableError::Conflict);
            }
            None
        }
        (None, None) if saved.policy_renewal.is_none() => None,''')
rep(f,'(Some(intent), Some(t)) if intent.statement() == t.statement_digest() => {','(Some(intent), Some(t)) if !intent.independent() && saved.policy_renewal.is_none() && intent.statement() == t.statement_digest() => {')
# A same-P target still has the ordinary G receipt; no need to fake a T receipt.
