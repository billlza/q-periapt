#[path = "../../trust.rs"]
mod trust;
use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json,Value};
use std::{fs,io::Read,path::Path,time::{SystemTime,UNIX_EPOCH}};
type Result<T> = std::result::Result<T,Box<dyn std::error::Error>>;
fn now()->Result<u64>{Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs())}
fn load(path:&Path)->Result<Value>{let mut b=Vec::new();fs::File::open(path)?.take(1048577).read_to_end(&mut b)?;if b.len()>1048576{return Err("oversize issuer input".into())}Ok(serde_json::from_slice(&b)?)}
fn bytes(v:&Value,k:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(k).ok_or("missing bytes")?.clone())?)}
fn array(v:&Value,k:&str)->Result<[u8;32]>{Ok(bytes(v,k)?.as_slice().try_into()?)}
fn number(v:&Value,k:&str)->Result<u64>{v[k].as_u64().ok_or_else(||"missing number".into())}
fn decimal(v:&Value,k:&str)->Result<u64>{Ok(v[k].as_str().ok_or("missing decimal string")?.parse()?)}
fn main()->Result<()>{
 let args=std::env::args().collect::<Vec<_>>();if args.len()!=6 && args.len()!=7{return Err("directory original-grant request output profile [witness-proposal]".into())}
 let dir=Path::new(&args[1]);let cfg=load(&dir.join("PUBLIC.json"))?;let original=load(Path::new(&args[2]))?;let request=load(Path::new(&args[3]))?;let profile=&args[5];if !["local","required"].contains(&profile.as_str()){return Err("profile".into())}
 let policy=&cfg["policies"][profile];
 let policies=trust::policies(dir,&cfg,&original,profile)?;
 let registered=trust::current_credential(dir,&cfg,&original,&policies)?;
 if bytes(&request,"original_credential")?!=bytes(&original,"certificate")?||bytes(&request,"current_credential")?!=bytes(&registered,"certificate")?||bytes(&request,"original_roster")?!=bytes(&original,"roster")?||bytes(&request,"current_roster")?!=bytes(&registered,"roster")?||decimal(&request,"current_roster_version")?!=number(&registered,"version")?||array(&request,"current_roster_digest")?!=array(&registered,"digest")?||array(&request,"original_policy_digest")?!=array(policy,"digest")?||decimal(&request,"original_policy_version")?!=number(policy,"version")?||decimal(&request,"previous_policy_version")?!=policies.current.checkpoint().version()||array(&request,"previous_policy_digest")?!=policies.current.checkpoint().digest()||(if request["previous_policy_authorization"].is_null(){None}else{Some(array(&request,"previous_policy_authorization")?)})!=policies.statement{return Err("request differs from independently retained registration/policy".into())}
 let pin=p::AccountPin::new(array(&cfg,"account")?,p::PublicKey::decode(&bytes(&cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&original,"version")?,array(&original,"digest")?)?,array(&cfg,"family")?)?;
 let device=pin.verify_historical_device(&bytes(&original,"certificate")?,&bytes(&original,"roster")?)?;
 let current_pin=p::AccountPin::new(array(&cfg,"account")?,p::PublicKey::decode(&bytes(&cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&registered,"version")?,array(&registered,"digest")?)?,array(&cfg,"family")?)?;
 let current=current_pin.verify_device(&bytes(&registered,"certificate")?,&bytes(&registered,"roster")?,now()?)?;
 if array(&request,"original_credential_digest")?!=device.credential_digest()||array(&request,"current_credential_digest")?!=current.credential_digest(){return Err("credential digest".into())}
 if let Some(scope)=&policies.scope {if scope.journal.as_bytes()!=&array(&request,"journal")? || scope.original_owner!=array(&request,"original_owner")? {return Err("request moved registered policy scope".into())}}
 let wrap=p::JournalKey::open(&dir.join("private-wrap.key"))?;let root=p::RootSigningKey::open(&dir.join("private-root.key"),&wrap,p::SigningKeyId::from_trusted_state(fs::read(dir.join("root-id.bin"))?.as_slice().try_into()?)?)?;
 let issuer=p::PolicySigningKey::open(&dir.join("private-policy.key"),&wrap,p::SigningKeyId::from_trusted_state(fs::read(dir.join("policy-id.bin"))?.as_slice().try_into()?)?)?;
 if issuer.public_key()?.encode()!=bytes(&cfg,"policy_root")?||root.public_key()?.encode()!=bytes(&cfg,"root")?{return Err("independent root drift".into())}
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(&cfg,"sdk_policy")?,&bytes(&cfg,"sdk_signature")?,&bytes(&cfg,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
 let policy_pin=p::PolicyPin::new(array(&cfg,"family")?,issuer.public_key()?,p::PolicyCheckpoint::from_trusted_state(number(policy,"version")?,array(policy,"digest")?)?)?;
 let original_policy=policy_pin.verify_historical(&bytes(policy,"wire")?)?;
 let previous=policies.current;
 let at=now()?;
 let (policy_bytes,checkpoint)=if args.len()==7 {
  let v=load(Path::new(&args[4]))?;
  (bytes(&v,"policy")?,p::PolicyCheckpoint::from_trusted_state(number(&v,"version")?,array(&v,"digest")?)?)
 }else{
 let next=issuer.issue_session_policy(&runtime,p::SessionPolicyParameters::new(previous.checkpoint().version().checked_add(1).ok_or("policy version overflow")?,p::Validity::new(previous.validity().from(),previous.validity().until().checked_add(600).ok_or("policy validity overflow")?)?,previous.allowed_modes(),previous.anchor_requirement(),previous.application_send_budget())?)?;
  (next.as_bytes().to_vec(),next.checkpoint())
 };
 let next_pin=p::PolicyPin::new(array(&cfg,"family")?,issuer.public_key()?,checkpoint)?;
 let target=next_pin.verify(&policy_bytes,std::sync::Arc::new(runtime),at)?;
 let scope=p::PolicyRenewalScope{operation:p::PolicyRenewalId::from_trusted_state(array(&request,"operation")?)?,journal:p::JournalIdentity::from_trusted_state(array(&request,"journal")?)?,original_owner:array(&request,"original_owner")?,original_credential:array(&request,"original_credential_digest")?,current_credential:array(&request,"current_credential_digest")?,current_roster:current.roster().checkpoint(),original_policy:original_policy.checkpoint(),previous_policy:previous.checkpoint(),previous_authorization:policies.statement};
 let materials=p::PolicyRenewalMaterials{original:&original_policy,previous:&previous,target:&target,original_device:&device,current_device:&current};
 if args.len()==7 {
  let approved=load(Path::new(&args[4]))?;
  let a=p::PolicyRenewalApproval::from_bytes(&bytes(&approved,"account_approval")?)?;
  let b=p::PolicyRenewalApproval::from_bytes(&bytes(&approved,"policy_approval")?)?;
  let proof=p::VerifiedPolicyRenewal::verify(&a,&b,&scope,&materials,at)?;
  let raw=fs::read(&args[6])?;if raw.len()>1024{return Err("oversize proposal".into())}
  let proposal=p::AnchorPolicyRenewalProposal::from_trusted_state(&raw)?;
  let key=p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
  let signer=p::AnchorSigningKey::open(&dir.join("private-witness.key"),&key,p::SigningKeyId::from_trusted_state(array(&cfg,"witness_signer_id")?)?)?;
  let mut store=p::AnchorStore::open(&dir.join("private-witness.redb"),key,signer,p::AnchorIdentity::from_trusted_state(array(&cfg,"witness_id")?)?)?;
  if store.pin()?.public_key().encode()!=bytes(&cfg,"witness_public")? {return Err("wrong witness".into())}
  if store.prepare_policy_renewal(proposal,&proof,&materials,at)?!=p::AnchorPolicyRenewalState::Prepared{return Err("not Prepared".into())}
  store.close();println!("{}",json!({"prepared":true,"operation":scope.operation.as_bytes(),"binding":proposal.binding()}));return Ok(())
 }
 let statement=p::PolicyRenewalStatement::new(&scope,&materials,at)?;let a=root.approve_policy_renewal(&statement)?;let b=issuer.approve_policy_renewal(&statement)?;let proof=p::VerifiedPolicyRenewal::verify(&a,&b,&scope,&materials,at)?;
 let mut wrong=scope.clone();wrong.operation=p::PolicyRenewalId::generate()?;
 if p::VerifiedPolicyRenewal::verify(&a,&b,&wrong,&materials,at).is_ok()||p::VerifiedPolicyRenewal::verify(&a,&a,&scope,&materials,at).is_ok(){return Err("issuer negative controls accepted".into())}
 publish_private_bytes(Path::new(&args[4]),&serde_json::to_vec_pretty(&json!({"previous":{ "wire":policies.descriptor["wire"],"version":policies.descriptor["version"],"digest":policies.descriptor["digest"] },"approval":proof.historical().as_bytes(),"account_approval":a.as_bytes(),"policy_approval":b.as_bytes(),"statement":proof.statement_digest(),"policy":policy_bytes,"version":checkpoint.version(),"digest":checkpoint.digest()}))?)?;
 println!("{}",json!({"issued_and_verified":true,"operation":scope.operation.as_bytes(),"previous_policy_expired":at>=previous.validity().until(),"registered_credential_verified":true,"negative_controls":2,"target_version":target.checkpoint().version()}));Ok(())
}
