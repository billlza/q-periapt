//! Trusted fixture registration, independently selected before accepting a request.
use q_periapt_continuity_identity_candidate as p;
use serde_json::Value;
use std::{io::Read,path::Path};
pub type Result<T> = std::result::Result<T,Box<dyn std::error::Error>>;
pub fn load(path:&Path)->Result<Value>{let mut b=Vec::new();std::fs::File::open(path)?.take(1048577).read_to_end(&mut b)?;if b.len()>1048576{return Err("oversize trusted input".into())}Ok(serde_json::from_slice(&b)?)}
pub fn bytes(v:&Value,k:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(k).ok_or("missing bytes")?.clone())?)}
pub fn array(v:&Value,k:&str)->Result<[u8;32]>{Ok(bytes(v,k)?.as_slice().try_into()?)}
pub fn number(v:&Value,k:&str)->Result<u64>{v[k].as_u64().ok_or_else(||"missing number".into())}
pub fn decimal(v:&Value,k:&str)->Result<u64>{Ok(v[k].as_str().ok_or("missing decimal")?.parse()?)}
pub fn descriptor(cfg:&Value,v:&Value)->Result<p::HistoricalSessionPolicy>{
 let pin=p::PolicyPin::new(array(cfg,"family")?,p::PublicKey::decode(&bytes(cfg,"policy_root")?)?,p::PolicyCheckpoint::from_trusted_state(number(v,"version")?,array(v,"digest")?)?)?;
 Ok(pin.verify_historical(&bytes(v,"wire")?)?)
}
pub fn account(cfg:&Value,v:&Value)->Result<p::AccountPin>{Ok(p::AccountPin::new(array(cfg,"account")?,p::PublicKey::decode(&bytes(cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(v,"version")?,array(v,"digest")?)?,array(cfg,"family")?)?)}
pub fn credential(cfg:&Value,v:&Value)->Result<p::VerifiedDevice>{Ok(account(cfg,v)?.verify_historical_device(&bytes(v,"certificate")?,&bytes(v,"roster")?)?)}
pub struct Policies {
 pub original:p::HistoricalSessionPolicy,
 pub current:p::HistoricalSessionPolicy,
 pub statement:Option<[u8;32]>,
 pub scope:Option<p::PolicyRenewalScope>,
 pub descriptor:Value,
}
pub fn policies(dir:&Path,cfg:&Value,original:&Value,profile:&str)->Result<Policies>{
 let initial=&cfg["policies"][profile];let origin=descriptor(cfg,initial)?;
 let registered=load(&dir.join("CURRENT_P.json"))?;let current=descriptor(cfg,&registered)?;
 let (statement,scope)=match registered["kind"].as_str(){
  Some("initial")=>{
   if current.checkpoint()!=origin.checkpoint() || bytes(&registered,"wire")?!=bytes(initial,"wire")? || !registered["authorization"].is_null(){return Err("initial policy differs from independent registration".into())}
   (None,None)
  },
  Some("independent")=>{
   let request=&registered["request"];let old=descriptor(cfg,&registered["previous"])?;
   let original_device=credential(cfg,original)?;
   let roster=p::RosterCheckpoint::from_trusted_state(decimal(request,"current_roster_version")?,array(request,"current_roster_digest")?)?;
   let pin=p::AccountPin::new(array(cfg,"account")?,p::PublicKey::decode(&bytes(cfg,"root")?)?,roster,array(cfg,"family")?)?;
   let device=pin.verify_historical_device(&bytes(request,"current_credential")?,&bytes(request,"current_roster")?)?;
   if bytes(request,"original_credential")?!=bytes(original,"certificate")? || bytes(request,"original_roster")?!=bytes(original,"roster")? {return Err("registered P moved original identity".into())}
   let scope=p::PolicyRenewalScope {operation:p::PolicyRenewalId::from_trusted_state(array(request,"operation")?)?,journal:p::JournalIdentity::from_trusted_state(array(request,"journal")?)?,original_owner:array(request,"original_owner")?,original_credential:array(request,"original_credential_digest")?,current_credential:array(request,"current_credential_digest")?,current_roster:roster,original_policy:origin.checkpoint(),previous_policy:old.checkpoint(),previous_authorization:if request["previous_policy_authorization"].is_null(){None}else{Some(array(request,"previous_policy_authorization")?)}};
   if decimal(request,"original_policy_version")?!=origin.checkpoint().version() || array(request,"original_policy_digest")?!=origin.checkpoint().digest() || decimal(request,"previous_policy_version")?!=old.checkpoint().version() || array(request,"previous_policy_digest")?!=old.checkpoint().digest(){return Err("registered P pins differ".into())}
   let materials=p::HistoricalPolicyRenewalMaterials {original:&origin,previous:&old,target:&current,original_device:&original_device,current_device:&device};
   let proof=p::HistoricalPolicyRenewal::from_bytes(&bytes(&registered,"approval")?,&scope,&materials)?;
   let expected=array(&registered,"authorization")?;
   if proof.statement_digest()!=expected {return Err("registered P proof differs".into())}
   (Some(expected),Some(scope))
  },
  _=>return Err("missing explicit policy registration kind".into())
 };
 Ok(Policies {original:origin,current,statement,scope,descriptor:registered})
}
pub fn current_credential(dir:&Path,cfg:&Value,original:&Value,policies:&Policies)->Result<Value>{
 let current=load(&dir.join("CURRENT_C.json"))?;let device=credential(cfg,&current)?;
 match current["kind"].as_str(){
  Some("initial")=>{if bytes(&current,"certificate")?!=bytes(original,"certificate")? || bytes(&current,"roster")?!=bytes(original,"roster")? {return Err("initial credential differs from registration".into())}},
  Some("grant")=>{
   let grant=p::HistoricalCredentialRenewal::verify(&bytes(&current,"grant")?,&account(cfg,&current)?,policies.original.checkpoint().digest())?;
   let original_device=credential(cfg,original)?;
   let scope=policies.scope.as_ref().ok_or("registered G requires an independently registered P in this fixture")?;
   // The root-signed successor roster has one member per device ID. Matching its
   // checkpoint and the original identity pins this independently verified C.
   if grant.successor_checkpoint()!=device.roster().checkpoint() || grant.original_storage_owner()!=scope.original_owner || device.device_id()!=original_device.device_id() || device.generation()!=original_device.generation(){return Err("registered G differs from original lineage".into())}
  },
  _=>return Err("missing explicit credential registration kind".into())
 }
 Ok(current)
}
