from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-policy-credential-sessions';package=root/'target/continuity-browser-publication/source/target/policy-credential-session-package-01'
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/('controller-kill.js' if name=='controller.js' else name),web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Session continuity across original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-policy-credential-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
tools=stage/'tools-target/debug';authority=stage/'witness-target/debug/examples/browser_activation_authority';provisioner=tools/'q-periapt-browser-policy-session-authority';roster=tools/'q-periapt-browser-credential-policy-issuer';credential=tools/'q-periapt-browser-credential-policy-g-issuer';peer=tools/'q-periapt-browser-policy-session-peer-v2'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
state={'completed':False,'scope':'Actual installed browser independent P then G with independently registered current policy and credential, original pending ciphertext/control replay, recovery and bidirectional traffic; same Rust implementation and loopback, not independent implementation/PCS/release','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,provisioner,roster,credential,peer]},'cases':[],'observations':[]}
allowed={'live','loss','loss-before','loss-ack','kill-commit','kill-ack','cancel','expired-chain','successive'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster session result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'observations':value['result'].get('observations',[])});return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def native_trace(case,name):
 trace=out/'native'/case/name;trace.mkdir(mode=0o700,parents=True);return trace
def peer_result(args,label):return parse_strict_json_bytes(native(peer,args,label),label=label)
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_session_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_session_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(provisioner,['prepare-expiring-policy' if case=='expired-chain' else 'prepare',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    if case=='expired-chain':
     cfg['peer_until']=cfg['until'];cfg['until']=int(time.time())+120
     cfg['description'][64:72]=list(cfg['until'].to_bytes(8,'big'))
     (directory/'PUBLIC.json').write_text(json.dumps(cfg))
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(provisioner,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    sdk.write_json(directory/'ORIGINAL_C.json',grant_data)
    sdk.write_json(directory/'CURRENT_C.json',{**grant_data,'kind':'initial','next_version':grant_data['version']+1})
    sdk.write_json(directory/'CURRENT_P.json',{**cfg['policies']['required'],'kind':'initial','authorization':None})
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace(case,'prepare')],case+'-peer-prepare')
    peer_data=json.loads((inputs/(key+'-peer.json')).read_text())
    args['requestId']=success({**args,'action':'session','sessionAction':'new-request'})['requestId']
    established=success({**args,'action':'session','sessionAction':'establish'});args['session']=established['session'];row['session']=args['session'];row['requestId']=args['requestId'];(directory/'peer/session.json').write_text(json.dumps(args['session']))
    args['message']=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['message']=args['message']
    row['pending_delivery']=rejected({**args,'action':'session','sessionAction':'send','peerMode':'drop-ack'},'PeerTransport')
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'lost application ACK not retained')
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    reverse_prepared=peer_result(['send-prepare',directory,session_file,reverse,native_trace(case,'reverse-prepare')],case+'-reverse-prepare');sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'],'native pending outcome');row['reverse_prepared']=reverse_prepared;args['reverseMessage']=reverse_prepared['message']
    row['pending_rekey']=rejected({**args,'action':'session','sessionAction':'drive-rekey','target':1,'peerMode':'control-drop-first'},'PeerTransport')
    pending=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(pending['confirmed']=='0' and pending['pending']=='1','original pending control absent');row['progress_before']=pending
    row['policies']=[];row['credentials']=[]
    def register(path,value):
     # Trusted fixture registry is distinct from untrusted SDK requests. Retain every predecessor.
     history=path.with_name(path.stem+'-'+str(len(list(directory.glob(path.stem+'-*.json'))))+'.json')
     if path.exists():shutil.copyfile(path,history)
     path.write_text(json.dumps(value))
    def reject_native(binary,argv,label,message,outfile):
     result=capture_output([str(binary),*map(str,argv)],timeout_seconds=30,maximum_stdout_bytes=65536,maximum_stderr_bytes=65536,environment=dict(os.environ))
     (logs/(label+'.stdout')).write_bytes(result.stdout);(logs/(label+'.stderr')).write_bytes(result.stderr)
     sdk.require(result.returncode!=0 and message.encode() in result.stderr and not outfile.exists(),'native authority accepted substituted request')
    def renew_policy(label):
     op=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']
     requested=success({**args,'action':'policy-request','operationId':op,'historicalOnly':True})
     request_file=out/(case+'-'+label+'-request.json');sdk.write_json(request_file,requested['requestValue'])
     output=inputs/(key+'-'+label+'-approval.json');entry={'operation':op,'request':requested}
     if label!='p1':
      stale=dict(requested['requestValue']);stale.update(current_credential=grant_data['certificate'],current_roster=grant_data['roster'],current_credential_digest=requested['requestValue']['original_credential_digest'],current_roster_version=str(grant_data['version']),current_roster_digest=grant_data['digest'])
      stale_file=out/(case+'-'+label+'-stale.json');sdk.write_json(stale_file,stale);refused=out/(case+'-'+label+'-refused.json')
      reject_native(roster,[directory,grant,stale_file,refused,'required'],case+'-'+label+'-stale','request differs from independently retained registration/policy',refused);entry['stale_credential_refused']=True
     entry['issued']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,output,'required'],case+'-'+label+'-issuer'),label='policy issuer')
     issued=json.loads(output.read_text());previous=args.get('currentPolicyFile');pargs={**args,'operationId':op,'policyFile':output.name,'historicalOnly':True}
     if previous:pargs['previousPolicyFile']=previous
     entry['staged']=success({**pargs,'action':'p-stage'});p=success({**pargs,'action':'p-prepare'});entry['prepared']=p
     proposal_file=out/(case+'-'+label+'-proposal.bin');proposal_file.write_bytes(bytes(p['proposal']))
     entry['witness_approved']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,output,'required',proposal_file],case+'-'+label+'-witness'),label='independent P approval')
     entry['committed']=success({**pargs,'action':'p-commit','proposal':p['proposal']});sdk.require(entry['committed']['remote']==2 and entry['committed']['progress']['retired'],'P not durably retired')
     entry['active']=success({**pargs,'action':'p-activate'});sdk.require(entry['active']['journal']==original['journal'],'P replaced journal')
     register(directory/'CURRENT_P.json',{'kind':'independent','wire':issued['policy'],'version':issued['version'],'digest':issued['digest'],'authorization':issued['statement'],'approval':issued['approval'],'request':requested['requestValue'],'previous':issued['previous']})
     args.update(currentPolicyFile=output.name,continued=True)
     row['policies'].append(entry);return output
    p1=renew_policy('p1')
    row['native_policy']=peer_result(['renew-policy',directory,p1,native_trace(case,'native-policy')],case+'-native-policy')
    sdk.require(row['native_policy']['same_original_journal'] and row['native_policy']['session']==args['session'],'peer P changed original session')
    if case=='expired-chain':
     deadline=max(cfg['until'],cfg['policy_until']);row['real_expiry']={'credential_until':cfg['until'],'policy_until':cfg['policy_until'],'policy_adopted_at':int(time.time())}
     sdk.require(time.time()<cfg['until'],'P was not completed before original C expired')
     print(json.dumps({'case':case,'waiting_until':deadline+1}),flush=True)
     while time.time()<=deadline:time.sleep(min(10,max(0.1,deadline+1-time.time())))
     row['real_expiry']['credential_renew_at']=int(time.time())
    def renew_credential(label,fault=None,cancel=False):
     op=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation'];requested=success({**args,'action':'credential-request','operationId':op,'historicalOnly':True})
     request_file=out/(case+'-'+label+'-request.json');sdk.write_json(request_file,requested['requestValue'])
     output=inputs/(key+'-'+label+'-renewal.json');entry={'operation':op,'request':requested}
     stale=dict(requested['requestValue']);stale.update(current_policy_version=str(cfg['policies']['required']['version']),current_policy_digest=cfg['policies']['required']['digest'],current_policy_authorization=None)
     stale_file=out/(case+'-'+label+'-stale.json');sdk.write_json(stale_file,stale);refused=out/(case+'-'+label+'-refused.json')
     reject_native(credential,[directory,grant,stale_file,refused,'required'],case+'-'+label+'-stale','request differs from independently retained registration/policy',refused);entry['stale_policy_refused']=True
     entry['issued']=parse_strict_json_bytes(native(credential,[directory,grant,request_file,output,'required'],case+'-'+label+'-issuer'),label='G issuer')
     issued=json.loads(output.read_text());gargs={**args,'operationId':op,'statement':issued['statement'],'credentialFile':output.name,'historicalOnly':False}
     entry['staged']=success({**gargs,'action':'stage-credential'})
     if cancel:
      prepared=success({**gargs,'action':'prepare-cancellation','historicalOnly':True});entry['prepared']=prepared
      metadata=out/(case+'-'+label+'-cancellation.bin');metadata.write_bytes(bytes(prepared['cancellation']))
      sdk.require(metadata.read_bytes().startswith(b'QPCRNC03'),'wrong independent P cancellation grammar')
      native(credential,['--witness',directory,output,metadata,'cancel'],case+'-'+label+'-cancel-approval')
      final=success({**gargs,'action':'reconcile-credential','historicalOnly':True});sdk.require(final['phase']==5,'target-free cancellation not Closed')
     else:
      prepared=success({**gargs,'action':'prepare-credential'});entry['prepared']=prepared;gargs['credentialProposal']=prepared['proposal']
      metadata=out/(case+'-'+label+'-proposal.bin');metadata.write_bytes(bytes(prepared['proposal']));sdk.require(metadata.read_bytes().startswith(b'QPCRNP03'),'wrong independent P proposal grammar')
      native(credential,['--witness',directory,output,metadata,'prepare'],case+'-'+label+'-witness')
      if fault=='before':
       arm=logs/(case+'-'+label+'-arm.js');arm.write_text('async page=>await page.evaluate(async()=>{const r=await fetch('+json.dumps('/arm/'+key)+',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:"before"})});if(!r.ok)throw Error("arm failed");return true;})');browser(['run-code','--filename',str(arm)],case+'-'+label+'-arm')
       entry['lost']=rejected({**gargs,'action':'commit-credential'},'WitnessTransport')
       final=success({**gargs,'action':'close-credential','historicalOnly':True});sdk.require(final['phase']==5,'pre-dispatch close not Closed')
      elif fault in ['commit','ack']:
       entry['lost']=rejected({**gargs,'action':'commit-credential','mode':'drop-after-advance' if fault=='commit' else 'drop-ack'},'WitnessTransport')
       entry['interrupted']=success({**gargs,'action':'recover-credential','historicalOnly':True})
       final=success({**gargs,'action':'reconcile-credential','historicalOnly':True})
      elif fault in ['kill-commit','kill-ack']:
       entry['killed']=invoke({**gargs,'action':'commit-credential','mode':'hold-after-advance' if fault=='kill-commit' else 'hold-ack','killOnFault':True});sdk.require(entry['killed'].get('killed') is True,'actual Worker not terminated')
       entry['interrupted']=success({**gargs,'action':'recover-credential','historicalOnly':True});final=success({**gargs,'action':'reconcile-credential','historicalOnly':True})
      else:final=success({**gargs,'action':'commit-credential'})
      sdk.require(final['phase']==(5 if fault=='before' else 4),'wrong exact G outcome')
     entry['final']=final
     retired=success({**gargs,'action':'recover-credential','historicalOnly':True});sdk.require(retired['proposal'] is None and retired['status']==final,'G not fully retired')
     current=json.loads((directory/'CURRENT_C.json').read_text())
     if final['phase']==4:
      register(directory/'CURRENT_C.json',{**issued,'kind':'grant','next_version':issued['version']+1})
      entry['peer_admission']=peer_result(['admit-browser',directory,output,native_trace(case,label+'-peer')],case+'-'+label+'-peer')
      sdk.require(entry['peer_admission']['same_original_journal'] and entry['peer_admission']['session']==args['session'],'peer G did not retain original session')
     else:register(directory/'CURRENT_C.json',{**current,'next_version':issued['version']+1})
     entry['active']=success({**args,'action':'p-activate','historicalOnly':True});sdk.require(entry['active']['journal']==original['journal'],'G changed original owner')
     row['credentials'].append(entry);return final
    final=renew_credential('g1',fault={'loss':'commit','loss-ack':'ack','loss-before':'before','kill-commit':'kill-commit','kill-ack':'kill-ack'}.get(case),cancel=case=='cancel')
    if final['phase']==5:renew_credential('g2')
    if case=='successive':
     previous=row['credentials'][-1]['final'];renew_policy('p2')
     sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==previous,'next P erased preceding G')
     renew_credential('g2')
    args.update(continued=True,historicalOnly=True)
    row['legacy_refused']=rejected({**args,'action':'session','sessionAction':'rekey-progress','legacyReopen':True},'Conflict')
    after=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(after==pending,'P changed original rekey');row['progress_after']=after
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'G lost original application outbox')
    completed=success({**args,'action':'session','sessionAction':'drive-rekey','target':1});sdk.require(completed['epoch']=='1','original rekey incomplete');row['rekey']=completed
    control_frames=[r for r in peer_records[key] if r['kind']==4];sdk.require(len(control_frames)>=2 and control_frames[0]['trigger'] and control_frames[0]['request_sha256']==control_frames[1]['request_sha256'],'P changed first control replay')
    delivery=success({**args,'action':'session','sessionAction':'send'});sdk.require(delivery=={'consumption':1,'status':3},'original application not acknowledged');row['delivery']=delivery
    message_frames=[r['request_sha256'] for r in peer_records[key] if r['kind']==3];sdk.require(len(message_frames)==2 and len(set(message_frames))==1,'P changed original ciphertext')
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(args['session'])+bytes(args['message'])+b'browser to native','native effect duplicated/changed')
    received=success({**args,'action':'session','sessionAction':'receive'});sdk.require(received['application']['calls']==1 and received['application']['effects']==1,'browser original effect');row['received']=received
    duplicate=success({**args,'action':'session','sessionAction':'receive'});sdk.require(not duplicate['callbackInvoked'] and duplicate['reply']==received['reply'] and duplicate['application']==received['application'],'duplicate released plaintext or changed ACK');row['duplicate']=duplicate
    ack=out/(case+'-reverse-ack.bin');ack.write_bytes(bytes(received['reply']));row['reverse_finished']=peer_result(['send-finish',directory,reverse,ack,native_trace(case,'reverse-finish')],case+'-reverse-finish')
    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;sdk.require(success({**args,'action':'session','sessionAction':'send','message':fresh,'plaintext':'after P and G'})=={'consumption':1,'status':3},'fresh post-P message failed')
    sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==row['credentials'][-1]['final'],'maintenance erased current G outcome')
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records']),'peer_requests':len(row['peer_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
