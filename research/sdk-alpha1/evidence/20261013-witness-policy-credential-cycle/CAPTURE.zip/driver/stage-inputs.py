from pathlib import Path
import hashlib,json,shutil,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-credential-sessions';clone=root/'target/continuity-browser-publication/source'
sdk.require((clone/'.git').is_dir(),'real clone required')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head,'clone base differs')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'clone has unexpected changes')
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
(stage/'source.patch').write_bytes(patch)
subprocess.run(['git','apply','--check',str(stage/'source.patch')],cwd=clone,check=True)
subprocess.run(['git','apply',str(stage/'source.patch')],cwd=clone,check=True)
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
for name in new:
    sdk.require(name.startswith('research/continuity-identity-candidate/src/') and name.endswith('.rs'),'unexpected untracked product file')
    sdk.copy(root/name,clone/name)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()+new
for name in changed:sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256,'clone drift: '+name)
old=root/'target/continuity-browser-credential-policy-sessions'
for name in ['worker.js','controller-kill.js','session-checks.js','server.py']:sdk.copy(old/name,stage/name)
for source,destination in [(old/'credential-issuer',stage/'credential-issuer'),(old/'policy-issuer',stage/'policy-issuer'),(root/'target/continuity-browser-policy-sessions/native-peer-v2',stage/'native-peer'),(root/'target/continuity-browser-policy-sessions/authority',stage/'authority')]:
    shutil.copytree(source,destination,ignore=shutil.ignore_patterns('target'))
    p=destination/'Cargo.toml';p.write_text(p.read_text().replace(str(root/'research'),str(clone/'research')).replace(str(root/'crates'),str(clone/'crates')))
engine=clone/'research/continuity-identity-candidate';isolated=stage/'witness-source'
shutil.copytree(engine,isolated,ignore=shutil.ignore_patterns('target','.git'))
p=isolated/'Cargo.toml';s=p.read_text().replace('path = "../../crates/',f'path = "{clone}/crates/')
if '\nserde_json = ' not in s:s=s.replace('[dev-dependencies]\n','[dev-dependencies]\nserde_json = "=1.0.151"\n')
p.write_text(s)
old_probe=(old/'witness-source/src/anchor/store.rs').read_text();marker='// Isolated native readback for the real witness acceptance harness.'
sdk.require(old_probe.count(marker)==1,'probe marker ambiguity');p=isolated/'src/anchor/store.rs';p.write_text(p.read_text()+'\n'+old_probe[old_probe.index(marker):])
example='examples/browser_activation_authority.rs';p=isolated/example
sdk.require(not p.exists(),'unexpected product example collision');sdk.copy(old/'witness-source'/example,p)
sdk.write_json(stage/'STAGED_INPUTS.json',{'main_head':head,'main_unchanged':True,'clone':str(clone),'patch_sha256':hashlib.sha256(patch).hexdigest(),'changed_files':{n:sdk.snapshot(root/n).sha256 for n in changed},'isolated_probe_only':'browser_probe_head and browser_probe_command copied from previously reviewed read-only harness; product candidate source otherwise copied exactly','native_build_rule':'Every helper build must use this stage/tools-target or this stage/witness-target. Never use main full-test native-target or wrapper default target.'})
print(json.dumps({'clone_changed_files':len(changed),'stage':str(stage),'main_head':head}))
