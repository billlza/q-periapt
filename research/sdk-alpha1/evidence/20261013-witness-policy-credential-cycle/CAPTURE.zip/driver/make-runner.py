from pathlib import Path
old=Path('target/continuity-browser-credential-policy-sessions/run.py').read_text();stage=Path('target/continuity-browser-policy-credential-sessions')
header=old[:old.index('try:\n with serving')]
header=header.replace("stage=root/'target/continuity-browser-credential-policy-sessions';package=root/'target/continuity-browser-publication/source/target/policy-session-package-01'", "stage=root/'target/continuity-browser-policy-credential-sessions';package=root/'target/continuity-browser-publication/source/target/policy-credential-session-package-01'")
a="binary=root/'target/continuity-browser-creation/rust-target/debug';authority="
start=header.index(a);end=header.index('\nstatic=',start)
header=header[:start]+"tools=stage/'tools-target/debug';authority=stage/'witness-target/debug/examples/browser_activation_authority';provisioner=tools/'q-periapt-browser-policy-session-authority';roster=tools/'q-periapt-browser-credential-policy-issuer';credential=tools/'q-periapt-browser-credential-policy-g-issuer';peer=tools/'q-periapt-browser-policy-session-peer-v2'"+header[end:]
header=header.replace('qpc-roster-session-', 'qpc-policy-credential-session-').replace("allowed={'live','loss','kill-ack','expired-chain'}", "allowed={'live','loss','loss-before','loss-ack','kill-commit','kill-ack','cancel','expired-chain','successive'}")
header=header.replace('Actual installed browser G then independent P with independently registered C1', 'Actual installed browser independent P then G with independently registered current policy and credential')
# Retain existing bounded CLI and transport infrastructure, but every cohort is fresh.
opening=old[old.index('try:\n with serving'):old.index("    args['operationId']=success({**args,'action':'new-credential-operation'")]
opening=opening.replace("    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))", "    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))")
needle="    success({**args,'action':'accept'});"
insert="""    sdk.write_json(directory/'ORIGINAL_C.json',grant_data)
    sdk.write_json(directory/'CURRENT_C.json',{**grant_data,'kind':'initial','next_version':grant_data['version']+1})
    sdk.write_json(directory/'CURRENT_P.json',{**cfg['policies']['required'],'kind':'initial','authorization':None})
"""
assert needle in opening;opening=opening.replace(needle,insert+needle)
footer=old[old.index("    row['legacy_refused']=rejected("):]
footer=footer.replace("    sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==row['credential_final'],'P erased original G outcome')", "    sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==row['credentials'][-1]['final'],'maintenance erased current G outcome')")
footer=footer.replace("'plaintext':'after P'", "'plaintext':'after P and G'")
body='''    row['policies']=[];row['credentials']=[]
    def register(path,value):
     # Trusted fixture registry is distinct from untrusted SDK requests. Retain every predecessor.
     history=path.with_name(path.stem+'-'+str(len(list(directory.glob(path.stem+'-*.json'))))+'.json')
     if path.exists():shutil.copyfile(path,history)
     path.write_text(json.dumps(value))
    def reject_native(binary,argv,label,message,outfile):
     result=capture_output([str(binary),*map(str,argv)],timeout_seconds=30,maximum_stdout_bytes=65536,maximum_stderr_bytes=65536,environment=dict(os.environ))
     (logs/(label+'.stdout')).write_bytes(result.stdout);(logs/(label+'.stderr')).write_bytes(result.stderr)
     sdk.require(result.returncode!=0 and message.encode() in result.stderr and not outfile.exists(),'native authority accepted substituted request')
    def renew_policy(label):
     op=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']
     requested=success({**args,'action':'policy-request','operationId':op,'historicalOnly':True})
     request_file=out/(case+'-'+label+'-request.json');sdk.write_json(request_file,requested['requestValue'])
     output=inputs/(key+'-'+label+'-approval.json');entry={'operation':op,'request':requested}
     if label!='p1':
      stale=dict(requested['requestValue']);stale.update(current_credential=grant_data['certificate'],current_roster=grant_data['roster'],current_credential_digest=requested['requestValue']['original_credential_digest'],current_roster_version=str(grant_data['version']),current_roster_digest=grant_data['digest'])
      stale_file=out/(case+'-'+label+'-stale.json');sdk.write_json(stale_file,stale);refused=out/(case+'-'+label+'-refused.json')
      reject_native(roster,[directory,grant,stale_file,refused,'required'],case+'-'+label+'-stale','request differs from independently retained registration/policy',refused);entry['stale_credential_refused']=True
     entry['issued']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,output,'required'],case+'-'+label+'-issuer'),label='policy issuer')
     issued=json.loads(output.read_text());previous=args.get('currentPolicyFile');pargs={**args,'operationId':op,'policyFile':output.name,'historicalOnly':True}
     if previous:pargs['previousPolicyFile']=previous
     entry['staged']=success({**pargs,'action':'p-stage'});p=success({**pargs,'action':'p-prepare'});entry['prepared']=p
     proposal_file=out/(case+'-'+label+'-proposal.bin');proposal_file.write_bytes(bytes(p['proposal']))
     entry['witness_approved']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,output,'required',proposal_file],case+'-'+label+'-witness'),label='independent P approval')
     entry['committed']=success({**pargs,'action':'p-commit','proposal':p['proposal']});sdk.require(entry['committed']['remote']==2 and entry['committed']['progress']['retired'],'P not durably retired')
     entry['active']=success({**pargs,'action':'p-activate'});sdk.require(entry['active']['journal']==original['journal'],'P replaced journal')
     register(directory/'CURRENT_P.json',{'kind':'independent','wire':issued['policy'],'version':issued['version'],'digest':issued['digest'],'authorization':issued['statement'],'approval':issued['approval'],'request':requested['requestValue'],'previous':issued['previous']})
     args.update(currentPolicyFile=output.name,continued=True)
     row['policies'].append(entry);return output
    p1=renew_policy('p1')
    row['native_policy']=peer_result(['renew-policy',directory,p1,native_trace(case,'native-policy')],case+'-native-policy')
    sdk.require(row['native_policy']['same_original_journal'] and row['native_policy']['session']==args['session'],'peer P changed original session')
    if case=='expired-chain':
     deadline=max(cfg['until'],cfg['policy_until']);row['real_expiry']={'credential_until':cfg['until'],'policy_until':cfg['policy_until'],'policy_adopted_at':int(time.time())}
     sdk.require(time.time()<cfg['until'],'P was not completed before original C expired')
     print(json.dumps({'case':case,'waiting_until':deadline+1}),flush=True)
     while time.time()<=deadline:time.sleep(min(10,max(0.1,deadline+1-time.time())))
     row['real_expiry']['credential_renew_at']=int(time.time())
    def renew_credential(label,fault=None,cancel=False):
     op=success({**args,'action':'new-credential-operation','historicalOnly':True})['operation'];requested=success({**args,'action':'credential-request','operationId':op,'historicalOnly':True})
     request_file=out/(case+'-'+label+'-request.json');sdk.write_json(request_file,requested['requestValue'])
     output=inputs/(key+'-'+label+'-renewal.json');entry={'operation':op,'request':requested}
     stale=dict(requested['requestValue']);stale.update(current_policy_version=str(cfg['policies']['required']['version']),current_policy_digest=cfg['policies']['required']['digest'],current_policy_authorization=None)
     stale_file=out/(case+'-'+label+'-stale.json');sdk.write_json(stale_file,stale);refused=out/(case+'-'+label+'-refused.json')
     reject_native(credential,[directory,grant,stale_file,refused,'required'],case+'-'+label+'-stale','request differs from independently retained registration/policy',refused);entry['stale_policy_refused']=True
     entry['issued']=parse_strict_json_bytes(native(credential,[directory,grant,request_file,output,'required'],case+'-'+label+'-issuer'),label='G issuer')
     issued=json.loads(output.read_text());gargs={**args,'operationId':op,'statement':issued['statement'],'credentialFile':output.name,'historicalOnly':False}
     entry['staged']=success({**gargs,'action':'stage-credential'})
     if cancel:
      prepared=success({**gargs,'action':'prepare-cancellation','historicalOnly':True});entry['prepared']=prepared
      metadata=out/(case+'-'+label+'-cancellation.bin');metadata.write_bytes(bytes(prepared['cancellation']))
      sdk.require(metadata.read_bytes().startswith(b'QPCRNC03'),'wrong independent P cancellation grammar')
      native(credential,['--witness',directory,output,metadata,'cancel'],case+'-'+label+'-cancel-approval')
      final=success({**gargs,'action':'reconcile-credential','historicalOnly':True});sdk.require(final['phase']==5,'target-free cancellation not Closed')
     else:
      prepared=success({**gargs,'action':'prepare-credential'});entry['prepared']=prepared;gargs['credentialProposal']=prepared['proposal']
      metadata=out/(case+'-'+label+'-proposal.bin');metadata.write_bytes(bytes(prepared['proposal']));sdk.require(metadata.read_bytes().startswith(b'QPCRNP03'),'wrong independent P proposal grammar')
      native(credential,['--witness',directory,output,metadata,'prepare'],case+'-'+label+'-witness')
      if fault=='before':
       arm=logs/(case+'-'+label+'-arm.js');arm.write_text('async page=>await page.evaluate(async()=>{const r=await fetch('+json.dumps('/arm/'+key)+',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:"before"})});if(!r.ok)throw Error("arm failed");return true;})');browser(['run-code','--filename',str(arm)],case+'-'+label+'-arm')
       entry['lost']=rejected({**gargs,'action':'commit-credential'},'WitnessTransport')
       final=success({**gargs,'action':'close-credential','historicalOnly':True});sdk.require(final['phase']==5,'pre-dispatch close not Closed')
      elif fault in ['commit','ack']:
       entry['lost']=rejected({**gargs,'action':'commit-credential','mode':'drop-after-advance' if fault=='commit' else 'drop-ack'},'WitnessTransport')
       entry['interrupted']=success({**gargs,'action':'recover-credential','historicalOnly':True})
       final=success({**gargs,'action':'reconcile-credential','historicalOnly':True})
      elif fault in ['kill-commit','kill-ack']:
       entry['killed']=invoke({**gargs,'action':'commit-credential','mode':'hold-after-advance' if fault=='kill-commit' else 'hold-ack','killOnFault':True});sdk.require(entry['killed'].get('killed') is True,'actual Worker not terminated')
       entry['interrupted']=success({**gargs,'action':'recover-credential','historicalOnly':True});final=success({**gargs,'action':'reconcile-credential','historicalOnly':True})
      else:final=success({**gargs,'action':'commit-credential'})
      sdk.require(final['phase']==(5 if fault=='before' else 4),'wrong exact G outcome')
     entry['final']=final
     retired=success({**gargs,'action':'recover-credential','historicalOnly':True});sdk.require(retired['proposal'] is None and retired['status']==final,'G not fully retired')
     current=json.loads((directory/'CURRENT_C.json').read_text())
     if final['phase']==4:
      register(directory/'CURRENT_C.json',{**issued,'kind':'grant','next_version':issued['version']+1})
      entry['peer_admission']=peer_result(['admit-browser',directory,output,native_trace(case,label+'-peer')],case+'-'+label+'-peer')
      sdk.require(entry['peer_admission']['same_original_journal'] and entry['peer_admission']['session']==args['session'],'peer G did not retain original session')
     else:register(directory/'CURRENT_C.json',{**current,'next_version':issued['version']+1})
     entry['active']=success({**args,'action':'p-activate','historicalOnly':True});sdk.require(entry['active']['journal']==original['journal'],'G changed original owner')
     row['credentials'].append(entry);return final
    final=renew_credential('g1',fault={'loss':'commit','loss-ack':'ack','loss-before':'before','kill-commit':'kill-commit','kill-ack':'kill-ack'}.get(case),cancel=case=='cancel')
    if final['phase']==5:renew_credential('g2')
    if case=='successive':
     previous=row['credentials'][-1]['final'];renew_policy('p2')
     sdk.require(success({**args,'action':'credential-status','historicalOnly':True})==previous,'next P erased preceding G')
     renew_credential('g2')
    args.update(continued=True,historicalOnly=True)
'''
(stage/'run.py').write_text(header+opening+body+footer)
