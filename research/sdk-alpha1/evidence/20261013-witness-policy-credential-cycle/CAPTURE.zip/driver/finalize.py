from pathlib import Path
import json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-credential-sessions';clone=root/'target/continuity-browser-publication/source'
dest='research/sdk-alpha1/evidence/20261013-witness-policy-credential-cycle';checks=json.loads((root/dest/'CHECKS.json').read_text());sdk.require(checks['completed'] and checks['case_count']==9,'unqualified cycle')
source=checks['source_overlay'];paths=sorted(source)+[dest+'/'+n for n in ['CAPTURE.zip','CHECKS.json','README.md']]
for n,d in source.items():sdk.require(sdk.snapshot(root/n).sha256==d,'source changed before commit: '+n)
def changed(where,label):
 tracked=sdk.command(['git','diff','--name-only','HEAD'],stage/(label+'-tracked'),where).decode().splitlines()
 new=sdk.command(['git','ls-files','--others','--exclude-standard'],stage/(label+'-new'),where).decode().splitlines()
 return set(tracked+new)
sdk.require(changed(root,'precommit-main')==set(paths),'unrelated main change')
sdk.require(changed(clone,'precommit-clone')==set(source),'unexpected clone change')
for n,d in source.items():sdk.require(sdk.snapshot(clone/n).sha256==d,'clone source changed')
sdk.command(['git','add','--',*paths],stage/'commit-stage',root)
sdk.command(['git','diff','--cached','--check'],stage/'commit-check',root)
staged=sdk.command(['git','diff','--cached','--name-only'],stage/'commit-paths',root).decode().splitlines();sdk.require(set(staged)==set(paths),'unexpected staged paths')
sdk.command(['git','commit','-m','Preserve independent policy through witnessed credential renewal'],stage/'commit',root)
head=sdk.command(['git','rev-parse','HEAD'],stage/'head',root).decode().strip();sdk.require(not sdk.command(['git','status','--porcelain'],stage/'main-status',root),'main not clean')
# The real clone already holds the byte-identical tested overlay. Stage only
# those verified files so Git can carry them into their identical committed tree.
sdk.command(['git','add','--',*sorted(source)],stage/'clone-stage-tested-overlay',clone)
sdk.command(['git','fetch',str(root),'HEAD'],stage/'clone-fetch',clone)
sdk.command(['git','checkout','--detach',head],stage/'clone-checkout',clone)
sdk.require(not sdk.command(['git','status','--porcelain'],stage/'clone-status',clone),'clone not clean')
env=dict(os.environ);env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';env['PYTHONPATH']='artifact'
sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',sdk.snapshot(clone/'artifact/results.json').sha256,head],stage/'source-gate',clone,environment=env)
sdk.write_json(stage/'FINALIZED.json',{'head':head,'main_clean':True,'clone_clean':True,'source_gate':'passed','release_claim_eligible':False,'pushed':False});print(head)
