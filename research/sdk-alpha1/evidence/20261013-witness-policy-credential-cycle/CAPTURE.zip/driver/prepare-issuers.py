from pathlib import Path
stage=Path(__file__).parent
p=stage/'credential-issuer/src/main.rs';s=p.read_text();s='#[path = "../../trust.rs"]\nmod trust;\n'+s
s=s.replace(' let policy=&cfg["policies"][profile];',''' let policy=&cfg["policies"][profile];
 let policies=trust::policies(dir,&cfg,&original,profile)?;
 let registered=trust::current_credential(dir,&cfg,&original,&policies.original)?;''')
s=s.replace('bytes(&request,"previous_credential")?!=bytes(&original,"certificate")?', 'bytes(&request,"previous_credential")?!=bytes(&registered,"certificate")?').replace('bytes(&request,"previous_roster")?!=bytes(&original,"roster")?', 'bytes(&request,"previous_roster")?!=bytes(&registered,"roster")?').replace('decimal(&request,"previous_roster_version")?!=number(&original,"version")?', 'decimal(&request,"previous_roster_version")?!=number(&registered,"version")?').replace('array(&request,"previous_roster_digest")?!=array(&original,"digest")?', 'array(&request,"previous_roster_digest")?!=array(&registered,"digest")?')
s=s.replace('decimal(&request,"current_policy_version")?!=number(policy,"version")?||array(&request,"current_policy_digest")?!=array(policy,"digest")?||!request["current_policy_authorization"].is_null()', 'decimal(&request,"current_policy_version")?!=policies.current.checkpoint().version()||array(&request,"current_policy_digest")?!=policies.current.checkpoint().digest()||(if request["current_policy_authorization"].is_null(){None}else{Some(array(&request,"current_policy_authorization")?)})!=policies.statement')
s=s.replace('let pin=p::AccountPin::new(array(&cfg,"account")?,p::PublicKey::decode(&bytes(&cfg,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(&original,"version")?,array(&original,"digest")?)?,array(&cfg,"family")?)?;','let pin=trust::account(&cfg,&registered)?;')
s=s.replace('pin.verify_historical_device(&bytes(&original,"certificate")?,&bytes(&original,"roster")?)?', 'pin.verify_historical_device(&bytes(&registered,"certificate")?,&bytes(&registered,"roster")?)?')
s=s.replace('let at=now()?;let until=number(&cfg,"until")?.checked_add(600)', 'let at=now()?;let until=decimal(&request,"previous_valid_until")?.checked_add(600)')
s=s.replace('root.issue_roster(number(&original,"version")?.checked_add(1)', 'root.issue_roster(number(&registered,"version")?.checked_add(1)')
s=s.replace(' let wrap=p::JournalKey::open', ' if let Some(scope)=&policies.scope {if scope.journal.as_bytes()!=&array(&request,"journal")? || scope.original_owner!=array(&request,"original_owner")?{return Err("request moved independently registered P scope".into())}}\n let wrap=p::JournalKey::open',1)
# The witness parses the independently selected current policy from registration, never from G metadata.
s=s.replace(' let policy=policy_pin.verify_historical(&bytes(v,"wire")?)?;', ''' let policy=policy_pin.verify_historical(&bytes(v,"wire")?)?;
 let original=load(&dir.join("ORIGINAL_C.json"))?;
 let policies=trust::policies(dir,&cfg,&original,"required")?;
 let current_pin=p::PolicyPin::new(array(&cfg,"family")?,p::PublicKey::decode(&bytes(&cfg,"policy_root")?)?,policies.current.checkpoint())?;''')
s=s.replace('let current=policy_pin.verify(&bytes(v,"wire")?,std::sync::Arc::new(runtime),at)?;', 'let current=current_pin.verify(&bytes(&policies.descriptor,"wire")?,std::sync::Arc::new(runtime),at)?;')
s=s.replace('let state=store.prepare_credential_renewal(proposal,&grant,&current,at)?;', 'let state=store.prepare_policy_renewed_credential_renewal(proposal,&grant,&policy,&current,at)?;')
s=s.replace('let state=store.close_unprepared_credential_renewal(cancellation,&grant,&policy)?;', 'let state=store.close_unprepared_policy_renewed_credential_renewal(cancellation,&grant,&policy,&policies.current)?;')
p.write_text(s)
p=stage/'policy-issuer/src/main.rs';s=p.read_text();s='#[path = "../../trust.rs"]\nmod trust;\n'+s
s=s.replace(' let registered=load(&dir.join("REGISTERED_G.json"))?;', ' let policies=trust::policies(dir,&cfg,&original,profile)?;\n let registered=trust::current_credential(dir,&cfg,&original,&policies.original)?;')
s=s.replace('decimal(&request,"previous_policy_version")?!=number(policy,"version")?||array(&request,"previous_policy_digest")?!=array(policy,"digest")?||!request["previous_policy_authorization"].is_null()', 'decimal(&request,"previous_policy_version")?!=policies.current.checkpoint().version()||array(&request,"previous_policy_digest")?!=policies.current.checkpoint().digest()||(if request["previous_policy_authorization"].is_null(){None}else{Some(array(&request,"previous_policy_authorization")?)})!=policies.statement')
a=' let grant=p::VerifiedCredentialRenewal::verify(&bytes(&registered,"grant")?,&current_pin,array(policy,"digest")?,now()?)?;\n';assert a in s;s=s.replace(a,'')
a=' if grant.original_credential_digest()!=device.credential_digest() || grant.original_storage_owner()!=array(&request,"original_owner")? || grant.successor_device().credential_digest()!=current.credential_digest() || grant.successor_device().roster().checkpoint()!=current.roster().checkpoint() {return Err("independently registered G differs".into())}\n';assert a in s;s=s.replace(a,'')
s=s.replace(' let previous=policy_pin.verify_historical(&bytes(policy,"wire")?)?;', ' let original_policy=policy_pin.verify_historical(&bytes(policy,"wire")?)?;\n let previous=policies.current;')
s=s.replace('original_policy:previous.checkpoint(),previous_policy:previous.checkpoint(),previous_authorization:None', 'original_policy:original_policy.checkpoint(),previous_policy:previous.checkpoint(),previous_authorization:policies.statement')
s=s.replace('let materials=p::PolicyRenewalMaterials{original:&previous,previous:&previous,', 'let materials=p::PolicyRenewalMaterials{original:&original_policy,previous:&previous,')
s=s.replace('"account_approval":a.as_bytes(),', '"approval":proof.historical().as_bytes(),"account_approval":a.as_bytes(),')
s=s.replace('"registered_successor_verified":true', '"registered_credential_verified":true')
p.write_text(s)
