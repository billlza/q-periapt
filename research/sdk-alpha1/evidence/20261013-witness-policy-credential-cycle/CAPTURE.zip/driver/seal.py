from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-credential-sessions';native=root/'target/continuity-witness-policy-credential-cycle';package=root/'target/continuity-browser-publication/source/target/policy-credential-session-package-01'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'live','loss','loss-before','loss-ack','kill-commit','kill-ack','cancel','expired-chain','successive'}
runs={p.parent.name:load(p) for p in sorted(stage.glob('run*/RESULT.json'))};cases={};excluded={}
for run,r in runs.items():
 if not r['completed']:
  excluded[run]=r.get('failure','incomplete');continue
 for c in r['cases']:
  name=c['case'];sdk.require(name not in cases,'duplicate qualification case');cases[name]=c
  sdk.require(c['progress_before']==c['progress_after'] and c['rekey']['epoch']=='1','pending PQ changed')
  sdk.require(c['legacy_refused']['code']=='Conflict','legacy policy bypass')
  for p in c['policies']:
   sdk.require(p['committed']['remote']==2 and p['committed']['progress']['retired'] and p['active']['journal']==c['original']['journal'],'P not retained')
  for g in c['credentials']:
   sdk.require(g['stale_policy_refused'] and g['issued']['issued_and_verified'],'unregistered current P accepted')
   sdk.require(g['active']['journal']==c['original']['journal'] and g['final']['operation']==g['operation'],'G replaced original owner/operation')
   request=g['request']['requestValue'];sdk.require(request['current_policy_authorization'] is not None and request['current_policy_digest']!=request['original_policy_digest'],'P not independent')
  sdk.require(c['credentials'][-1]['final']['phase']==4,'final G not committed')
  controls=[x for x in c['peer_records'] if x['kind']==4];messages=[x for x in c['peer_records'] if x['kind']==3]
  sdk.require(len(controls)>=2 and controls[0]['trigger'] and controls[0]['request_sha256']==controls[1]['request_sha256'],'control replay changed')
  sdk.require(len(messages)==3 and messages[0]['trigger'] and messages[0]['request_sha256']==messages[1]['request_sha256']!=messages[2]['request_sha256'],'original ciphertext/fresh work changed')
  sdk.require(c['delivery']=={'consumption':1,'status':3} and c['received']['application']['effects']==1 and not c['duplicate']['callbackInvoked'] and c['duplicate']['reply']==c['received']['reply'],'delivery/dedup failure')
  sdk.require(c['reverse_finished']['authenticated_browser_consumption'] and c['reverse_finished']['same_original_wire'],'reverse message changed')
  if name in ['loss-before','cancel']:sdk.require(len(c['credentials'])==2 and c['credentials'][0]['final']['phase']==5,'Closed G not followed by fresh G')
  if name in ['kill-commit','kill-ack']:sdk.require(c['credentials'][0]['killed']['killed'],'Worker not actually terminated')
  if name in ['loss','loss-ack']:sdk.require(c['credentials'][0]['lost']['ownerClosed'],'fault owner survived')
  if name=='successive':
   sdk.require(len(c['policies'])==len(c['credentials'])==2,'no second cycle')
   a,b=c['credentials'];sdk.require(int(b['request']['requestValue']['previous_roster_version'])==a['issued']['target_version'],'G2 ignored C1')
 for n,d in r['native'].items():sdk.require(sha(Path(n))==d,'native binary drift')
 for n,d in r['static_web'].items():sdk.require(sha(stage/(run+'-web')/n)==d,'static input drift')
sdk.require(set(cases)==expected,'case coverage missing: '+str(expected-set(cases)))
e=cases['expired-chain']['real_expiry'];sdk.require(e['policy_adopted_at']<e['credential_until']<=e['credential_renew_at'] and e['policy_until']<=e['credential_renew_at'] and cases['expired-chain']['credentials'][0]['issued']['previous_expired'],'not real expired C0/P0')
source=load(stage/'STAGED_INPUTS.json');qualified=load(native/'DEVICE_QUALIFIED_NATIVE_V3_RESULT.json')
sdk.require(qualified['completed'] and qualified['exit_status']==0 and qualified['source_unchanged'] and qualified['executable_unchanged'],'native not qualified')
for n,d in qualified['source_inputs'].items():sdk.require(sha(root/n)==d,'native qualified source drift: '+n)
for n,d in source['changed_files'].items():sdk.require(sha(root/n)==d,'source overlay changed: '+n)
sdk.require(sha(Path(qualified['executable']))==qualified['executable_sha256'],'qualified executable drift')
sdk.require('951 passed; 0 failed; 0 ignored' in (native/'device-all-lib-qualified-v3.log').read_text(),'native test inventory')
base=load(stage/'base01/RESULT.json');sdk.require(base['completed'] and len(base['report']['cases'])==10,'base browser not passed')
sdk.require('Ran 60 tests' in (stage/'controls-01.log').read_text() and (stage/'controls-01.log').read_text().rstrip().endswith('OK'),'package controls')
receipt=load(package/'INSTALLED_CONSUMER.json');sdk.require(receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz'),'package receipt mismatch')
for n,d in load(package/'sources-before.json')['inputs'].items():sdk.require(sha(root/n)==d,'packaged source drift: '+n)
members={};raw={}
def add(p,n):
 sdk.require(p.is_file() and not p.is_symlink() and n not in members,'bad archive entry '+n)
 sdk.require(not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),'private file prohibited');members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.sh','.rs','.patch','.lock'] and p.name not in ['seal.log','HANDOFF.json']:add(p,'driver/'+p.name)
for p in sorted(native.iterdir()):
 if p.is_file() and not p.name.startswith('HANDOFF'):add(p,'native-tests/'+p.name)
for part in ['authority','native-peer','credential-issuer','policy-issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/part/n,'native-helpers/'+part+'/'+n)
for n in ['Cargo.toml','Cargo.lock','src/anchor/store.rs','examples/browser_activation_authority.rs']:add(stage/'witness-source'/n,'witness-source/'+n)
for n in source['changed_files']:add(root/n,'tested-source/'+n)
for run in runs:
 folder=stage/run
 for p in sorted(folder.iterdir()):
  if p.is_file():add(p,run+'/'+p.name)
 for part in ['logs','captures']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for part in ['witness','native','peer']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted((folder/'witness').rglob('RECORDS.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for row in load(p):
   if row['trigger']:
    for q in sorted(p.parent.glob(f"{row['number']:03}.*")):
     if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((folder/'peer').rglob('RECORD.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for n in ['request.bin','reply.bin','native.stdout','native.stderr']:
   q=p.parent/n
   if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((stage/(run+'-web')/'inputs').glob('*')):
  if p.is_file():add(p,run+'/public-inputs/'+p.name)
for p in sorted((stage/'base01').iterdir()):
 if p.is_file():add(p,'base01/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/n,'package/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-witness-policy-credential-cycle';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 sdk.require(z.testzip() is None,'corrupt archive')
 for n,m in manifest.items():sdk.require(hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes'],'member digest')
checks={'completed':True,'release_claim_eligible':False,'base_commit':source['main_head'],'source_overlay':source['changed_files'],'native_source_inputs':qualified['source_inputs'],'case_count':len(cases),'cases':sorted(cases),'real_expiry':e,'validation':{'native_full_suite':951,'retirement_controls':21,'package_controls':60,'base_browser':10,'worker_termination_cuts':2,'enrollment_process_kills':8,'witness_process_kills':4,'strict_native_clippy':'passed','wasm_msrv':'Rust 1.90 passed','successive_browser_policy_credential_cycles':2},'excluded_browser_runs':excluded,'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Required independent P then G, native and installed browser; original journal, pending ciphertext and PQ controls. Browser P1 bilateral, P2 browser-only while native P1 remains live. Same Rust implementation and loopback. No new physical-device, deployed migration, independent implementation, performance, PCS or release claim.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
