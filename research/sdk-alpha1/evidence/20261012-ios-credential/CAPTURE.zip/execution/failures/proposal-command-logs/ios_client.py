#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import sys,json,hashlib,secrets,shutil
from device_support import OUT,BUNDLE,selected,command

def main():
 args=sys.argv[1:];managed=False
 if len(args)>=2 and args[0]=='--registry':managed=True;args=args[2:]
 if len(args) not in (5,6):raise RuntimeError('configuration argument count')
 mode,profile,src,target,output=args[:5];carrier=args[5] if len(args)==6 else 'none'
 if carrier not in {'none','signed','tls'}:raise RuntimeError('carrier')
 source=Path(src);destination=Path(output)
 if mode not in {'arc-capacity','cancel-create','create','reconcile','resume','enroll-local','connect','uncertain-send','retry-send','authority-create','wrong-witness','cancel','prepare','activate-missing','activate-bad-receipt','activate','activate-unmanaged','activate-closed-registry','activate-released-registry','credential-identity','credential-expired-request','credential-expired','credential-activation-unmanaged','credential-activate','credential-prepare','credential-stage','credential-stage-refused','credential-commit','credential-commit-closed','credential-commit-unmanaged','credential-commit-unknown','credential-reconcile','retry-credential'} or profile not in {'fixed','recoverable'}:raise RuntimeError('unexpected mode/profile')
 if not source.is_dir() or source.is_symlink() or not destination.is_absolute() or destination.exists():raise RuntimeError('input/output paths')
 case=hashlib.sha256(target.encode()).hexdigest()[:32];run=secrets.token_hex(16);capture=OUT/'device-execution'/run;capture.mkdir(parents=True)
 allowed={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope','recovery-root','recovery-enrollment','grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest','connection-address','connection-initiation','connection-session','connection-message','witness-id','witness-public','witness-address','witness-subject','witness-tls-cert','witness-tls-key','witness-tls-peer','witness-tls-name','tamper-witness-cache','credential-renewal','credential-operation','credential-statement','renewal-version','renewal-digest','renewed-certificate','renewed-roster','credential-proposal'}
 files=list(source.iterdir())
 for x in files:
  if x.name=='registry-public' and x.is_dir() and not x.is_symlink():
   names={'registry-id','family','witness-id','witness-public','application','account','revision','peer-application','peer-account','peer-root','peer-roster-version','peer-roster-digest','peer-certificate','peer-roster'}
   if any(not f.is_file() or f.is_symlink() or f.name not in names or f.stat().st_size>65536 for f in x.iterdir()):raise RuntimeError('registry public metadata')
  elif x.name=='peer' and x.is_dir() and not x.is_symlink():
   peer_names={'family','directory','bootstrap.bundle','tls-peer','tls-peer-name'}|{p+s for p in ('initiator','responder') for s in ('-account','-root','-roster-version','-roster-digest','-device','-generation')}
   if any(not f.is_file() or f.is_symlink() or f.name not in peer_names or f.stat().st_size>65536 for f in x.iterdir()):raise RuntimeError('unapproved peer input')
  elif not x.is_file() or x.is_symlink() or x.name not in allowed or x.stat().st_size>65536:raise RuntimeError('unapproved or oversized provisioning input')
 device=selected();domain=['--domain-type','appDataContainer','--domain-identifier',BUNDLE]
 # Only provisioning inputs are transferred. Native identity and journals remain on the iPhone.
 command(device,['device','copy','to','--source',str(source),'--destination','Documents/inputs-'+case,*domain],capture/'inputs')
 if carrier!='none' or mode in {'connect','uncertain-send','retry-send','retry-credential'}:
  import usb_transport
  result=usb_transport.launch(device,BUNDLE,mode,profile,case,run,capture,{route:(source/name).read_text() for route,name in [('peer','connection-address'),('witness','witness-address')] if (source/name).exists()},carrier,managed)
 else:
  result,_=command(device,['device','process','launch','--console',BUNDLE,mode,profile,case,run,carrier,'managed' if managed else 'unmanaged'],capture/'launch',timeout=60)
 expected=f'QPC_IOS_CONFIGURATION_PASS mode={mode} profile={profile} run={run}\n'.encode()
 if result.stdout.splitlines().count(expected.rstrip(b'\n'))!=1 or result.stdout.splitlines().count(b'The app terminated with the exit code 0.')!=1 or b'QPC_IOS_CONFIGURATION_FAIL' in result.stdout+result.stderr:raise RuntimeError('missing terminal iOS operation proof')
 command(device,['device','copy','from','--source','Documents/receipt-'+run+'.txt','--destination',str(capture/'receipt.txt'),*domain],capture/'receipt-copy')
 if (capture/'receipt.txt').read_bytes()!=expected:raise RuntimeError('container receipt differs')
 if mode=='resume' and result.stdout.splitlines().count(b'QPC_IOS_STORAGE_BOUNDARY_PASS symlink=203 mode=203')!=1:raise RuntimeError('storage boundary negatives missing')
 markers={'arc-capacity':'ARC_PASS','cancel-create':'CREATE_CANCELLED','enroll-local':'LOCAL_ACTIVE','connect':'CONNECTION_PASS','uncertain-send':'UNKNOWN_COMMITTED','retry-send':'ORIGINAL_ACKNOWLEDGED','authority-create':'AUTHORITY_CREATED','wrong-witness':'WITNESS_SCOPE_REFUSED','cancel':'CANCELLED','prepare':'GENESIS_PASS','activate-missing':'WITNESS_REQUIRED','activate-bad-receipt':'WITNESS_RECEIPT_REFUSED','activate':'ACTIVATION_PASS','activate-unmanaged':'REGISTRY_REQUIRED','activate-closed-registry':'REGISTRY_CLOSED','activate-released-registry':'REGISTRY_RELEASED'}
 if mode not in {'arc-capacity','cancel-create','wrong-witness','cancel'}:
  command(device,['device','copy','from','--source','Documents/result-'+run+'.bin','--destination',str(capture/'public-result.bin'),*domain],capture/'result-copy')
  data=(capture/'public-result.bin').read_bytes()
  if not 1<=len(data)<=65536:raise RuntimeError('public result width')
  with destination.open('xb') as f:f.write(data)
 (capture/'RESULT.json').write_text(json.dumps({'completed':True,'mode':mode,'profile':profile,'carrier':carrier,'managed':managed,'case':case,'run':run,'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'public_result_sha256':hashlib.sha256(data).hexdigest() if mode not in {'arc-capacity','cancel-create','wrong-witness','cancel'} else None},indent=2)+'\n')
 print('QPC_CONFIGURATION_'+('CREDENTIAL_OPERATION' if mode.startswith('credential-') else 'ORIGINAL_ACKNOWLEDGED' if mode=='retry-credential' else markers.get(mode,'REQUEST_PASS')))
if __name__=='__main__':
 try:main()
 except Exception as error:
  print(str(error),file=sys.stderr);sys.exit(1)
