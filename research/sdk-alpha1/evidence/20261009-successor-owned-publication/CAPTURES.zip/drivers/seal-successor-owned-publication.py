from pathlib import Path
import hashlib, json, zipfile, datetime, subprocess
import continuity_device_retirement as retirement

b = Path(__file__).resolve().parent
root = b.parents[1]
out = root/'research/sdk-alpha1/evidence/20261009-successor-owned-publication'
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
files = {}; profiles = {}; checked = {}
fixture = root/'research/continuity-identity-candidate/tests'
compiled = b/'publication-consumer/packages/q-periapt-continuity-identity-candidate-0.0.0/tests'
sources = {str(p.relative_to(root)):sha(p) for p in (fixture/'owned_connection').glob('*.rs')}
sources[str((fixture/'owned_connection.rs').relative_to(root))] = sha(fixture/'owned_connection.rs')
for name,digest in sources.items():
    assert sha(compiled/Path(name).relative_to('research/continuity-identity-candidate/tests')) == digest
name='bindings/c/ContinuityPackageConsumer/tests/enrollment.rs'
sources[name]=sha(root/name); assert sha(b/'publication-consumer/tests/enrollment.rs') == sources[name]
cbuild = json.loads((b/'successor-publication-c-client-build-04/RESULT.json').read_text())
assert all(sha(root/'bindings/c/ContinuityPackageConsumer'/name) == digest for name,digest in cbuild['source'].items())
def capture_run(label):
    for path in (b/label).iterdir():
        if path.is_file(): files['runs/'+label+'/'+path.name] = path
def public_files(label, directory, prefix):
    for path in (b/label/directory).rglob('*'):
        if path.is_file(): files[prefix+'/'+str(path.relative_to(b/label/directory))] = path
for profile in ('debug','release'):
    for language,collector in [('c',''),('swift',''),('kotlin','serial'),('kotlin','g1')]:
        suffix = '-'+collector if collector else ''
        label = 'successor-publication-'+language+'-'+profile+suffix+('-04' if language=='c' else '-03')
        r=json.loads((b/label/'RESULT.json').read_text()); q=json.loads((b/label/'VERIFIED.json').read_text())
        assert r['returncode']==0 and r['binaries_unchanged'] and all(sha(Path(path))==digest for path,digest in r['binaries_before'].items())
        latest=retirement.export_foreign((b/label/'stdout.log').read_bytes(), b/label/'exported-public', b/label/'sealed-readback',language=r['language'])
        assert q==latest and q['completed'] and q['owned_publication_used_for_traffic']
        assert [len(q[k]) for k in ('recovery_process_ids','successor_process_ids','publication_process_ids','traffic_process_ids')] == [8,10,3,2]
        assert len(q['public_readbacks'])==37
        profiles[language+'-'+profile+suffix]={'run':r,'readback':q}
        capture_run(label); public_files(label,'exported-public','public/'+language+'-'+profile+suffix)
    label='successor-publication-registration-'+profile+'-04'
    r=json.loads((b/label/'RESULT.json').read_text());q=json.loads((b/label/'VERIFIED.json').read_text());assert r['returncode']==0 and q['completed'] and r['binaries_unchanged']
    checked['registration-'+profile]={'run':r,'readback':q};capture_run(label);public_files(label,'exported-public','registration/'+profile)
for label in ('successor-publication-native-debug-03','successor-publication-clippy-02','successor-publication-msrv-01',
              'successor-publication-build-debug-03','successor-publication-build-release-03'):
    r=json.loads((b/label/'RESULT.json').read_text());assert r['returncode']==0;checked[label]=r;capture_run(label)
native=json.loads((b/'successor-publication-native-debug-03/VERIFIED.json').read_text())
assert native['retirement']['completed'] and native['retirement']['owned_publication_used_for_traffic'] and native['replacement']['completed']
for directory in ('retirement-public','replacement-public'):
    public_files('successor-publication-native-debug-03',directory,'native/'+directory)
for label in ('publication-gcc-portability-01','successor-publication-clippy-01','successor-publication-c-client-build-04'):
    capture_run(label)
for name in ('CI_B100_c-compile-debug.json','CI_B100_c-compile-debug.stderr','CI_B100_c-compile-debug.stdout','CI_B100_INSTALLED_RUST_ARTIFACT.json',
             'successor-publication-readers-02.stdout','successor-publication-readers-02.stderr'):
    files['inspection/'+name]=b/name
assert 'Ran 24 tests' in (b/'successor-publication-readers-02.stderr').read_text() and (b/'successor-publication-readers-02.stderr').read_text().endswith('OK\n')
for name in ('run-successor-publication-runtime.py','run-successor-publication-native.py','run-successor-publication-registration-regression.py','run-publication-c.py','run-publication-c-msrv.py','seal-successor-owned-publication.py'):
    files['drivers/'+name]=b/name
out.mkdir()
with zipfile.ZipFile(out/'CAPTURES.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()): archive.write(path,name)
with zipfile.ZipFile(out/'CAPTURES.zip') as archive:
    assert archive.testzip() is None and all(hashlib.sha256(archive.read(name)).hexdigest()==sha(path) for name,path in files.items())
record=dict(schema_version=1,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    parent_commit='b1006eb3ce3082f13a785c283b18f9b23a1b0f5f', native_library_source='a71195ec72e83a270a6af096e38d50f92ca3f08c',
    harness_inputs=sources,c_client_build=cbuild,profiles=profiles,checks=checked,reader_tests=24,
    captures=dict(file='CAPTURES.zip',sha256=sha(out/'CAPTURES.zip'),bytes=(out/'CAPTURES.zip').stat().st_size,members=len(files)),
    scope='Eight source-component/private-Maven profiles. Each has 23 actual foreign processes: 10 successor enrollment, 3 original publication, 8 retired cleanup and 2 successor TLS/application processes. Both connection bundles use the exact retained advertisement. Shared native protocol engine and native account/witness controller; no independent implementation, physical platform or complete installed-archive claim.',
    ci_repair=dict(source_job=113746359801,source_run=37907280524,artifact_id=11605562652,artifact_sha256='fdfb8836b98ee6622bb0cce0e1d4863e7b3c6d32a36023517a2e3d6e04c3cccc',
        defect='GCC15 -Werror=misleading-indentation rejected a same-line if/decode in publication_client.c.',
        validation='Local macOS arm64 GCC15 syntax red/green, then strict Clang Debug/Release build and both actual C lifecycle and registration regressions. Linux CI rerun pending.'),
    remaining=['Current-source full installed archives','Linux CI confirmation of GCC repair','Current-head CI and all security/recovery/independent-platform release gates'],
    release_claim_eligible=False,remote_registry_publication=False)
(out/'QUALIFICATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['captures']))
