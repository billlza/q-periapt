from pathlib import Path
import hashlib,json,subprocess,sys,os,time
base=Path(__file__).resolve().parent;root=base.parents[1];tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.90.0-aarch64-apple-darwin')
label,*args=sys.argv[1:];out=base/label;out.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPC','QPERIAPT','PYTHON','DYLD','LD_'))}
env.update(RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(base/'successor-traffic-build-msrv'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
inputs={str(p.relative_to(base/'publication-consumer')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/'publication-consumer').rglob('*') if p.is_file()}
cmd=[str(tc/'bin/cargo'),*args];start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,cwd=base/'publication-consumer',env=env,stdout=so,stderr=se)
result={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'inputs':inputs}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='inputs'}));print((out/'stderr.log').read_text()[-5000:]);p.check_returncode()
