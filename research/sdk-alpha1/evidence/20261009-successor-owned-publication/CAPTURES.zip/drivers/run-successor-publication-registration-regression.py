from pathlib import Path
import hashlib, json, os, subprocess, sys, time
from continuity_c_enrollment import PUBLICATION_TEST as FOREIGN_TEST, export

base = Path(__file__).resolve().parent
root = base.parents[1]
label, profile, language, *rest = sys.argv[1:]
assert profile in ('debug', 'release') and language in ('C', 'Swift', 'Kotlin')
output = base / label
output.mkdir(mode=0o700)
build_label = f'successor-publication-build-{profile}-03'
builds = [json.loads(line) for line in (base / build_label / 'stdout.log').read_text().splitlines()]
executables = [Path(row['executable']) for row in builds if row.get('reason') == 'compiler-artifact'
               and row.get('target', {}).get('name') == 'enrollment' and row.get('executable')]
assert len(executables) == 1
harness = executables[0]
extra = []
if language == 'C':
    client = base / 'successor-publication-c-client-build-04' / profile / 'qpc-c-client'
    library = base / ('swift-publication-installed-native-'+profile) / 'libq_periapt_continuity_c_consumer.dylib'
elif language == 'Swift':
    client = base / ('swift-publication-build-'+profile) / profile / 'ContinuityClient'
    library = base / ('swift-publication-installed-native-'+profile) / 'libq_periapt_continuity_c_consumer.dylib'
else:
    assert len(rest) == 1 and rest[0] in ('serial','g1')
    outside = Path(json.loads((base/'KOTLIN_PUBLICATION_OUTSIDE.json').read_text())['path'])
    client = outside / f'publication-client-{profile}-{rest[0]}'
    library = base / ('swift-publication-installed-native-'+profile) / 'libq_periapt_continuity_c_consumer.dylib'
    extra = sorted((outside/'consumer-qualified/build/install/continuity-installed-consumer/lib').glob('*.jar'))

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

before = {str(path): sha(path) for path in [harness, client, library, *extra]}
env = {k: v for k, v in os.environ.items() if not k.startswith(
    ('JAVA', 'JDK', 'GRADLE', 'KOTLIN', 'SWIFT', 'CARGO', 'RUST', 'QPERIAPT', 'QPC', 'DYLD', 'LD_', 'PYTHON'))
    and k not in ('_JAVA_OPTIONS', 'CLASSPATH')}
env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
           QPERIAPT_C_OWNER_CLIENT=str(client), QPERIAPT_INSTALLED_CLIENT_LANGUAGE=language,
           QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(library),
           QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(output / 'evidence'))
command = [str(harness), '--exact', FOREIGN_TEST, '--nocapture']
start = time.monotonic()
with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
    process = subprocess.run(command, cwd=base / 'publication-consumer', env=env,
                             stdout=stdout, stderr=stderr, timeout=300)
result = dict(command=command, returncode=process.returncode, seconds=time.monotonic()-start,
              language=language, profile=profile, collector=rest[0] if rest else None,
              binaries_before=before, binaries_unchanged=all(sha(Path(p)) == digest for p, digest in before.items()),
              native_source_commit='a71195ec72e83a270a6af096e38d50f92ca3f08c',
              scope='Registration/publication regression after sharing the public-only decoder with successor qualification; source-built component, not full installed archive qualification.')
(output / 'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'binaries_before'}), flush=True)
print((output / 'stdout.log').read_text()[-2500:], flush=True)
print((output / 'stderr.log').read_text()[-5000:], flush=True)
assert result['binaries_unchanged']
process.check_returncode()
checked = export((output / 'stdout.log').read_bytes(), output / 'evidence',
                 output / 'exported-public', language=language, publication=True)
(output / 'VERIFIED.json').write_text(json.dumps(checked, indent=2)+'\n')
