from pathlib import Path
import hashlib, json, os, subprocess, time
import continuity_device_retirement as retirement
import continuity_device_replacement as replacement

base=Path(__file__).resolve().parent
output=base/'successor-publication-native-debug-03'
output.mkdir(mode=0o700)
rows=[json.loads(line) for line in (base/'successor-publication-build-debug-03/stdout.log').read_text().splitlines()]
paths=[Path(row['executable']) for row in rows if row.get('reason')=='compiler-artifact'
       and row.get('target',{}).get('name')=='retirement' and row.get('executable')]
assert len(paths)==1
binary=paths[0]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(binary)
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))}
env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(output/'evidence'))
command=[str(binary),'--exact','fixture::owned_services_connect_restart_rekey_and_reconcile_unknown_delivery','--nocapture']
started=time.monotonic()
with (output/'stdout.log').open('wb') as so,(output/'stderr.log').open('wb') as se:
    process=subprocess.run(command,cwd=base/'publication-consumer',env=env,stdout=so,stderr=se,timeout=600)
result=dict(command=command,returncode=process.returncode,seconds=time.monotonic()-started,binary_sha256=before,binary_unchanged=sha(binary)==before)
(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print((output/'stdout.log').read_text()[-2000:],flush=True)
print((output/'stderr.log').read_text()[-5000:],flush=True)
assert result['binary_unchanged'];process.check_returncode()
stdout=(output/'stdout.log').read_text()
assert 'test fixture::owned_services_connect_restart_rekey_and_reconcile_unknown_delivery ... ok' in stdout
assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 3 filtered out;' in stdout
checked=retirement.export(output/'evidence-device-retirement/public',output/'retirement-public')
assert checked['successor_process_ids']==[]
replaced=replacement.export(output/'evidence-device-replacement/public',output/'replacement-public')
(output/'VERIFIED.json').write_text(json.dumps(dict(retirement=checked,replacement=replaced),indent=2)+'\n')
