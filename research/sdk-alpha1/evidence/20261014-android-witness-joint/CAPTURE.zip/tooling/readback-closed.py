from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
import continuity_android_witness_joint as q
r=Path.cwd();s=r/'target/continuity-android-witness-joint';out=s/'host-tls-recoverable-closed-01';record=json.loads((out/'RESULT.json').read_text());sdk.require(not record['completed'],'preserve original controller failure')
inputs=json.loads((s/'RUNTIME_INPUTS_01.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,digest in inputs['files'].items():sdk.require(sha(name)==digest,'native or JNI input drift: '+name)
sdk.require(sha(record['executable'])==record['executable_sha256'],'native executable drift')
result=q.verify_execution((out/'execution.stdout').read_bytes(),out/'cases','tls','recoverable',False)
for name in q.public('tls',False):sdk.copy(out/'cases/tls-recoverable'/name,out/'public/tls-recoverable'/name)
sdk.require(q.verify_execution((out/'execution.stdout').read_bytes(),out/'public','tls','recoverable',False)==result,'public export changed')
sdk.write_json(out/'READBACK.json',dict(record,completed=True,result=result,inputs_unchanged=True,native_execution_repeated=False,original_controller_remains_failed=True,
 correction='Readback used subject offset8 instead of40; AnchorProposal serialization prefixes32byte witness binding before96byte subject',reader_sha256=sha(r/'artifact/continuity_android_witness_joint.py')))
print(result)
