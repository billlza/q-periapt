from pathlib import Path
import hashlib,json,os,sys
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_contract as contract
import continuity_android_witness_joint as qualification
r=Path.cwd();s=r/'target/continuity-android-witness-joint';label=sys.argv[1];attempt=sys.argv[2];sdk.require(label in qualification.TESTS,'route');out=s/('host-'+label+'-'+attempt);out.mkdir()
inputs=json.loads((s/'RUNTIME_INPUTS_02.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in inputs['files'].items():sdk.require(sha(Path(name))==digest,'runtime input drift: '+name)
consumer=s/'c-consumer-02';binary=c.built_artifact((s/'build-harness-02.stdout').read_bytes(),consumer,s/'host-target-02/debug',library=False,test_name='android')
identity=sha(binary);
for name in ['continuity_android_witness_joint.py','continuity_android_joint_policy.py','continuity_android_contract.py','continuity_android_policy_renewal.py','rust_sdk_profile.py']:
 p=r/'artifact'/name;inputs['files'][str(p)]=sha(p)
carrier,profile,outcome=label.split('-');committed=outcome=='applied';installed=s/'jni01/installed'
env={k:v for k,v in os.environ.items() if not k.startswith(('QPC_','QPERIAPT_','LD_','DYLD_'))}
env.update(QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=inputs['driver'],QPC_CONFIGURATION_RECEIVER=str(installed/'qpc-c-client'),QPC_CONFIGURATION_TARGET_CLIENT=str(installed/'qpc-configuration-client'))
record={'completed':False,'release_claim_eligible':False,'source_linked':True,'route':label,'executable':str(binary),'executable_sha256':identity,'scope':'Current source-linked C engine and real host Java/JNI; actual independent issuer and witness, original traffic; not physical or installed-archive qualification'}
try:
 catalog=sdk.command([str(binary),'--list'],out/'catalog',consumer,environment=env);contract.verify_catalog(catalog)
 stdout=sdk.command([str(binary),'--exact',qualification.TESTS[label],'--nocapture'],out/'execution',consumer,environment=env)
 result=qualification.verify_execution(stdout,out/'cases',carrier,profile,committed)
 for name in qualification.public(carrier,committed):sdk.copy(out/'cases'/(carrier+'-'+profile)/name,out/'public'/(carrier+'-'+profile)/name)
 sdk.require(qualification.verify_execution(stdout,out/'public',carrier,profile,committed)==result,'public readback differs')
 for name,digest in inputs['files'].items():sdk.require(sha(Path(name))==digest,'runtime input drift: '+name)
 sdk.require(sha(binary)==identity,'harness changed during execution')
 record.update(completed=True,result=result,inputs_unchanged=True)
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',record)
print(json.dumps(record))
