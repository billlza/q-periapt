from pathlib import Path
import hashlib,json,os,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;build=json.loads((out/'agp-prepared/STATE.json').read_text());package=json.loads((out/'PACKAGE.json').read_text());assert build['completed'] and package['completed'];project=Path(build['project'])
compiled=(project/'app/compile-inputs.txt').read_text().splitlines()
expected=['AuthorityProbe','CancellationProbe','ConfigurationInstrumentation','ConfigurationProbe','CredentialLocalProbe','CredentialPolicyExpiryProbe','CredentialProbe','CredentialTerminalProbe','EnrollmentProbe','PeerInputs','PeerProbe','PeerRenewalProbe','PolicyInputs','PolicyProbe','PolicyProbeRecords','PolicyCredentialProbe','JointPolicyProbe','JointWitnessProbe','WitnessInputs','WitnessProbe','RosterInputs','RosterProbe','RosterProbeRecords','RosterWitnessProbe','RosterPeerProbe','RetiredOwnedProbe','RetirementInputs','RootInputs','RootOwnedProbe','RootRecovery','RootControls']
assert sorted(Path(p).stem for p in compiled)==sorted(expected)
assert all(Path(p).is_relative_to(project/'app/src/main/java') for p in compiled)
assert 'dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:' in (project/'app/build/outputs/mapping/release/mapping.txt').read_text()
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest,name
with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(build['unsigned_apk']) as apk:
 for name in ['libqperiapt_continuity_jni.so','libq_periapt_continuity_c_consumer.so']:assert aar.read('jni/arm64-v8a/'+name)==apk.read('lib/arm64-v8a/'+name)
jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home');bt=Path('/Users/bill/Library/Android/sdk/build-tools/36.0.0');env=dict(os.environ,JAVA_HOME=str(jdk),PATH=str(jdk/'bin')+':/usr/bin:/bin')
def local(name,cmd):
 r=subprocess.run([str(x) for x in cmd],env=env,capture_output=True,text=True,timeout=60);(out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);assert r.returncode==0,(name,r.stderr)
assert not (out/'qualification.p12').exists() and not (out/'consumer.apk').exists()
local('keytool',[jdk/'bin/keytool','-genkeypair','-keystore',out/'qualification.p12','-storepass','qualification-only','-alias','qualification','-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Local Continuity Qualification','-noprompt']);(out/'qualification.p12').chmod(0o600)
local('sign',[bt/'apksigner','sign','--ks',out/'qualification.p12','--ks-pass','pass:qualification-only','--out',out/'consumer.apk',build['unsigned_apk']]);local('signature',[bt/'apksigner','verify','--verbose',out/'consumer.apk'])
record={'completed':True,'apk_sha256':hashlib.sha256((out/'consumer.apk').read_bytes()).hexdigest(),'aar_sha256':package['aar_sha256'],'compiled_sources':expected,'native_members_equal':True,'signed':True}
(out/'PREPARED_APK.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
