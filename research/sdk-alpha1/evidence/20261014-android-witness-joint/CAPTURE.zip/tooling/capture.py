from pathlib import Path
import hashlib,json,subprocess,zipfile
import rust_sdk_profile as sdk
import continuity_android_witness_joint as q
import continuity_android_joint_policy as local
r=Path.cwd();s=r/'target/continuity-android-witness-joint';e=r/'research/sdk-alpha1/evidence/20261014-android-witness-joint'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
items={};results={}
def add(path,name):
 sdk.require(name not in items and path.is_file() and not path.is_symlink(),'capture member '+name);items[name]=path.read_bytes()
for surface,labels in [('host',list(q.TESTS)),('device',['signed-recoverable-closed','tls-recoverable-applied'])]:
 for label in labels:
  carrier,profile,outcome=label.split('-');committed=outcome=='applied'
  root=s/('host-'+label+'-02') if surface=='host' else s/'device-01'/('run-'+label)
  record=json.loads((root/'RESULT.json').read_text());sdk.require(record['completed'] and record['inputs_unchanged'],'nonterminal capture')
  result=q.verify_execution((root/'execution.stdout').read_bytes(),root/'public',carrier,profile,committed);sdk.require(result==record['result'],'readback changed')
  prefix=surface+'/'+label+'/';results[surface+'/'+label]=record
  for name in ['RESULT.json','execution.stdout','execution.stderr','catalog.stdout','catalog.stderr']:add(root/name,prefix+name)
  for name in q.public(carrier,committed):add(root/'public'/(carrier+'-'+profile)/name,prefix+'public/'+carrier+'-'+profile+'/'+name)
  if surface=='device':
   device=s/'device-01'/('device-'+label);state=json.loads((device/'STATE.json').read_text())
   sdk.require(state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports') and len(state['cases'])==result['foreign_processes'],'device cleanup/census')
   add(device/'STATE.json',prefix+'device-state.json')
   for name in ['final.identity-uninstall.stdout','final.identity-uninstalled.stdout','final.identity-uninstalled.stderr']:add(device/name,prefix+name)
   rows=[]
   for call in state['cases']:
    path=device/(call['label']+'-instrument.json');entry=json.loads(path.read_text());sdk.require(entry['exit_code']==0,'instrumentation return')
    rows.append({'label':call['label'],'command_record_sha256':sha(path),'recorded_argument_bytes':sum(len(x.encode())+1 for x in entry['command'])})
   sdk.require(max(x['recorded_argument_bytes'] for x in rows)<60000,'argument budget')
   items[prefix+'argument-lengths.json']=(json.dumps(rows,indent=2)+'\n').encode()
root=s/'host-fixed-applied-02';record=json.loads((root/'RESULT.json').read_text());sdk.require(record['completed'] and record['inputs_unchanged'],'local regression terminal')
result=local.verify_execution((root/'execution.stdout').read_bytes(),root/'public','fixed',True);sdk.require(result==record['result'],'local regression readback')
results['local-regression/fixed-applied']=record
for name in ['RESULT.json','execution.stdout','execution.stderr']:add(root/name,'local-regression/'+name)
for name in local.public(True):add(root/'public/local-fixed'/name,'local-regression/public/local-fixed/'+name)
for old in ['host-signed-fixed-applied-01','host-tls-recoverable-closed-01']:
 for name in ['RESULT.json','execution.stdout','execution.stderr']:add(s/old/name,'failures/'+old+'/'+name)
add(s/'host-tls-recoverable-closed-01/READBACK.json','failures/host-tls-recoverable-closed-01/READBACK.json')
for name in ['build-harness-01.stdout','build-harness-01.stderr','build-harness-02.stdout','build-harness-02.stderr']:add(s/name,'checks/'+name)
for name in ['RESULT.json','main-compile.stdout','main-compile.stderr','test-compile.stdout','test-compile.stderr','jni-compile.stdout','jni-compile.stderr','boundary.stdout','boundary.stderr']:add(s/'jni01'/name,'checks/jni/'+name)
for name in ['PACKAGE.json','PREPARED_APK.json','agp-prepared/STATE.json','agp-prepared/build.stdout','agp-prepared/build.stderr','signature.stdout','signature.stderr']:add(s/'device-01'/name,'package/'+name)
for name in ['run-host-02.py','run-local-regression.py','prepare-runtime.py','build-harness-02.py','boundary.py','readback-closed.py','capture.py']:add(s/name,'tooling/'+name)
for name in ['build-aar.py','build-consumer.py','prepare-apk.py','device-driver.py','run-device.py']:add(s/'device-01'/name,'tooling/device/'+name)
source=r/'bindings/android/ContinuityPackageConsumer';device=s/'device-01/source';host=s/'jni01/source'
for directory in ['src/main','jni']:
 for p in (source/directory).rglob('*'):
  if p.is_file():
   relative=p.relative_to(source);sdk.require(p.read_bytes()==(device/relative).read_bytes()==(host/relative).read_bytes(),'runtime source drift '+str(relative))
for p in (device/'src').rglob('*'):
 if p.is_file():sdk.require(p.read_bytes()==(source/p.relative_to(device)).read_bytes(),'APK fixture source drift')
with zipfile.ZipFile(s/'device-01/q-periapt-continuity-android-0.0.0.aar') as z:sdk.require(z.read('classes.jar')==(s/'jni01/qperiapt-continuity-android.jar').read_bytes(),'AAR/JNI Java mismatch')
changed=subprocess.run(['git','ls-files','--modified','--others','--exclude-standard','--','.github/workflows/ci.yml','artifact','bindings'],check=True,capture_output=True,text=True).stdout.splitlines()
for name in sorted(set(changed)):add(r/name,'source/'+name)
items['SOURCE_SHA256.json']=(json.dumps({name:hashlib.sha256(value).hexdigest() for name,value in items.items() if name.startswith('source/')},indent=2)+'\n').encode()
e.mkdir(parents=True,exist_ok=True);archive=e/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name,value in sorted(items.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,value)
sdk.write_json(e/'CAPTURE.json',{'completed':True,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(items),
 'scope':'Eight signed/TLS witness G/T host routes and two accepted physical API37 ART routes; same-engine C counterparty; plus local journal regression',
 'host_processes':sum(v['result']['foreign_processes'] for k,v in results.items() if k.startswith('host/')),
 'physical_processes':sum(v['physical_processes'] for k,v in results.items() if k.startswith('device/')),
 'local_regression_processes':result['foreign_processes'],'aar_sha256':sha(s/'device-01/q-periapt-continuity-android-0.0.0.aar'),
 'apk_sha256':sha(s/'device-01/consumer.apk'),'java_sha256':sha(s/'jni01/qperiapt-continuity-android.jar'),'release_claim_eligible':False,'routes':results})
print('CAPTURE',sha(archive),archive.stat().st_size,len(items))
