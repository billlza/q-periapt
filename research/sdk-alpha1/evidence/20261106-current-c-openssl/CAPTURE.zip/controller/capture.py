from pathlib import Path
import ast
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
DEST = REPO / 'research/sdk-alpha1/evidence/20261106-current-c-openssl'
DEST.mkdir()
files = {name: Path(path) for name, path in json.loads((ROOT / 'attempt-04/SELECTED_FILES.json').read_bytes()).items()}
result = json.loads((ROOT / 'attempt-04/READBACK.json').read_bytes())
assert result['completed'] is True
files['READBACK.json'] = ROOT / 'attempt-04/READBACK.json'

def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            name = prefix + '/' + path.relative_to(directory).as_posix()
            assert name not in files
            files[name] = path

for attempt in ['attempt-01', 'attempt-02', 'attempt-03']:
    tree('diagnostic-failures/' + attempt, ROOT / attempt)
for number in ['', '02', '03', '04']:
    path = SOURCE / 'target/current-rust-readback' / ('readback-c-openssl' + number + '.py')
    files['controller/' + path.name] = path
    for extension in ['stdout', 'stderr']:
        files['controller/c-openssl-readback' + number + '.' + extension] = SOURCE.parent / ('c-openssl-readback' + number + '.' + extension)
files['controller/capture.py'] = ROOT / 'capture.py'
files['controller/replay.py'] = ROOT / 'replay.py'
tree('source/bindings/c/ContinuityPackageConsumer', SOURCE / 'bindings/c/ContinuityPackageConsumer')
queue = [SOURCE / 'target/current-rust-readback/readback-c-openssl04.py', ROOT / 'replay.py']
seen = set()
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.is_relative_to(SOURCE / 'artifact'):
        files['source/' + path.relative_to(SOURCE).as_posix()] = path
    for node in ast.walk(ast.parse(path.read_bytes())):
        modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
        for module in modules:
            dependency = SOURCE / 'artifact' / (module.replace('.', '/') + '.py')
            if dependency.is_file():
                queue.append(dependency)
for name in ['python-run.sh', 'python-env.sh', 'python_bootstrap.py']:
    files['source/artifact/' + name] = SOURCE / 'artifact' / name
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.writestr(name, data)
data = (DEST / 'CAPTURE.zip').read_bytes()
assert len(data) < 95 * 1024**2
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(DEST / 'READBACK.json').write_bytes((ROOT / 'attempt-04/READBACK.json').read_bytes())
(DEST / 'replay.py').write_bytes((ROOT / 'replay.py').read_bytes())
summary = {'source_commit': result['source_commit'], 'members': len(manifest), 'bytes': len(data),
    'sha256': hashlib.sha256(data).hexdigest(), 'sdk_report_sha256': result['sdk_report_sha256'],
    'candidate_archive_sha256': result['candidate_archive_sha256'], 'native_components': 8,
    'altered_evidence_controls_per_profile': 14, 'whole_jni_qualification': False,
    'release_claim_eligible': False, 'scope': result['scope']}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
