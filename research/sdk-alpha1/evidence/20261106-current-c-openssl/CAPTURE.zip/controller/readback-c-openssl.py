from pathlib import Path
import datetime
import hashlib
import json
import shutil
import sys
import tempfile

import continuity_c_witness_openssl as interop
import continuity_c_witness_tls as native_tls
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
OUT = REPO / 'target/continuity-current-c-openssl-5678'
OUT.mkdir()
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == ('5678d1019861fa1b04f3a219ba3fde7e0ddaaba8', False)
current_inputs = package.source_inputs()
producer = SOURCE / 'target/sdk-020'
producer_input = sdk.snapshot(producer / 'RUST_SDK_PACKAGE.json')
producer_report = validate_report(producer_input.data,
    '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d',
    producer_input.sha256, current_inputs['rust_workspace_sha256'])
rust_root = SOURCE / 'target/continuity-installed-rust-current'
rust_report = json.loads((rust_root / 'CONTINUITY_PACKAGE.json').read_bytes())
candidate = rust_report['archive']
assert rust_report['completed'] is True and rust_report['source_inputs'] == current_inputs
package.verify_candidate_archive(rust_root, candidate)
candidate_files = package.validate_candidate(sdk.snapshot(rust_root / candidate['file']).data, set(candidate['files']))
files = {}

def retain(name, path):
    assert name not in files and not path.is_symlink() and path.is_file()
    files[name] = str(path)

def tree(prefix, path):
    for entry in sorted(path.rglob('*')):
        assert not entry.is_symlink()
        if entry.is_file():
            retain(prefix + '/' + entry.relative_to(path).as_posix(), entry)

profiles = {}
for profile in ['debug', 'release']:
    root = SOURCE / f'target/continuity-installed-jni-{profile}-current'
    report = json.loads((root / 'C_CONSUMER.json').read_bytes())
    assert report['partition_completed'] is True and report['build_profiles'] == [profile]
    execution = report['execution'][profile]
    assert execution['completed'] is True
    assert json.loads((root / 'sources-before.json').read_bytes()) == current_inputs
    outside = Path(json.loads((root / 'location.json').read_bytes())['path'])
    assert not outside.is_relative_to(SOURCE)
    consumer = outside / 'c-consumer'
    package.verify_candidate_files(consumer / 'packages' / f'{package.NAME}-{package.VERSION}', candidate_files)
    sdk.verify_consumed_sources(consumer, producer, producer_report['crates'])
    assert sdk.snapshot(root / candidate['file']).sha256 == candidate['sha256']
    witness = execution['witness_openssl']
    assert witness['completed'] is True
    interop.verify_dependencies(witness['peer']['dependency_files'])
    observed_scenes = {}
    for kind in ['server', 'client', 'rejections']:
        stdout = (root / f'c-witness-openssl-{kind}-{profile}.stdout').read_bytes()
        public = root / f'c-witness-openssl-public/{profile}/{kind}'
        observed = interop.verify_execution(kind, stdout, public)
        expected = dict(witness['execution'][kind])
        exported = expected.pop('exported_public_files')
        assert observed == expected
        actual = {p.relative_to(public).as_posix(): sdk.snapshot(p).sha256 for p in public.rglob('*') if p.is_file()}
        assert actual == exported
        observed_scenes[kind] = observed
        tree(profile + '/public/' + kind, public)
    tls_public = root / 'c-witness-tls-public' / profile
    tls_stdout = root / f'c-witness-tls-{profile}.stdout'
    observed_tls = native_tls.verify_execution(tls_stdout.read_bytes(), tls_public)
    expected_tls = dict(execution['witness_tls'])
    exported_tls = expected_tls.pop('exported_public_files')
    assert observed_tls == expected_tls
    assert {p.relative_to(tls_public).as_posix(): sdk.snapshot(p).sha256 for p in tls_public.rglob('*') if p.is_file()} == exported_tls
    tree(profile + '/public/native-tls', tls_public)
    binary_records = {}
    for label in ['C_client', 'C_library']:
        row = execution['binaries'][label]
        snap = sdk.snapshot(Path(row['path']), maximum=256 * 1024**2)
        assert snap.sha256 == row['sha256'] and snap.size == row['bytes']
        retain(profile + '/binaries/' + Path(row['path']).name, Path(row['path']))
        binary_records[label] = row
    peer = witness['peer']
    retain(profile + '/binaries/witness-tls-peer', Path(peer['path']))
    helper_receipt = json.loads((root / f'c-witness-openssl-server-{profile}.json').read_bytes())
    assert helper_receipt['returncode'] == 0 and helper_receipt['argv'][1:] == ['--exact', interop.TESTS['server'], '--nocapture']
    helper = Path(helper_receipt['argv'][0])
    assert helper.is_relative_to(outside / 'build' / profile)
    helper_snapshot = sdk.snapshot(helper, maximum=256 * 1024**2)
    binary_records['Rust_witness'] = {'path': str(helper), 'sha256': helper_snapshot.sha256, 'bytes': helper_snapshot.size}
    retain(profile + '/binaries/' + helper.name, helper)
    for stem in ['c-witness-openssl-' + kind + '-' + profile for kind in ['server', 'client', 'rejections', 'compile', 'version', 'identity', 'linked']]+['c-witness-tls-' + profile, 'c-witness-build-' + profile]:
        for extension in ['json', 'stdout', 'stderr']:
            retain(profile + '/commands/' + stem + '.' + extension, root / (stem + '.' + extension))
    for name in ['C_CONSUMER.json', 'sources-before.json', 'c-consumer-Cargo.lock']:
        retain(profile + '/' + name, root / name)
    for name in ['JNI_' + profile.upper() + '_REQUEST.json', 'JNI_' + profile.upper() + '_PREFLIGHT.json']:
        retain(profile + '/controller/' + name, SOURCE.parent / name)
    refusals = []
    baseline = root / f'c-witness-openssl-public/{profile}/server'
    server_stdout = (root / f'c-witness-openssl-server-{profile}.stdout').read_bytes()
    with tempfile.TemporaryDirectory(prefix='qperiapt-openssl-controls-') as temporary:
        altered = Path(temporary) / 'server'
        shutil.copytree(baseline, altered)
        report_path = altered / interop.REPORTS['server']
        original_report = report_path.read_bytes()
        trace_path = altered / 'openssl-witness-server.stderr'
        original_trace = trace_path.read_bytes()
        def refuse(label):
            try:
                interop.verify_execution('server', server_stdout, altered)
            except ValueError as error:
                refusals.append({'label': label, 'error_type': type(error).__name__, 'diagnostic': str(error)})
            else:
                raise AssertionError('altered runtime evidence was admitted: ' + label)
        for count in [142, 145, 147]:
            changed = json.loads(original_report)
            changed['witness_exchanges'] = count
            report_path.write_text(json.dumps(changed))
            refuse('report-' + str(count))
            report_path.write_bytes(original_report)
            trace = b''.join(original_trace.splitlines(keepends=True)[:count]) if count < 146 else original_trace + original_trace.splitlines(keepends=True)[-1].replace(b'exchange=146', b'exchange=147')
            trace_path.write_bytes(trace)
            refuse('trace-' + str(count))
            report_path.write_text(json.dumps(changed))
            refuse('report-and-trace-' + str(count))
            report_path.write_bytes(original_report)
            trace_path.write_bytes(original_trace)
        for old, new in [(b'role=server', b'role=client'), (b'tls=1.3', b'tls=1.2'),
                         (b'group=X25519MLKEM768', b'group=X25519'), (b'alpn=q-periapt-anchor/1', b'alpn=q-periapt-anchor/2'),
                         (b'exchange=146\n', b'exchange=145\n')]:
            assert old in original_trace
            trace_path.write_bytes(original_trace.replace(old, new, 1))
            refuse(old.decode().strip())
            trace_path.write_bytes(original_trace)
        assert interop.verify_execution('server', server_stdout, altered) == observed_scenes['server']
    assert len(refusals) == 14
    profiles[profile] = {'scenes': observed_scenes, 'native_tls': observed_tls, 'altered_evidence_refusals': refusals,
        'binaries': binary_records, 'openssl_peer': peer,
        'installed_candidate_tree_verified': True, 'installed_sdk_trees_verified': len(sdk.CONSUMER_CRATES),
        'component_partition_completed': True, 'whole_jni_completion_claimed': False}
    print(profile, 'server=146 client=2 native_tls=146 controls=14', flush=True)
retain('inputs/RUST_SDK_PACKAGE.json', producer / 'RUST_SDK_PACKAGE.json')
retain('inputs/CONTINUITY_RUST_PACKAGE.json', rust_root / 'CONTINUITY_PACKAGE.json')
retain('inputs/' + candidate['file'], rust_root / candidate['file'])
for name in sdk.CONSUMER_CRATES:
    row = producer_report['crates'][name]
    path = producer / row['file']
    assert sdk.snapshot(path).sha256 == row['sha256']
    retain('inputs/' + row['file'], path)
assert package.source_inputs() == current_inputs
result = {'completed': True, 'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8', 'source_inputs_verified': len(current_inputs['files']),
    'sdk_report_sha256': producer_input.sha256, 'candidate_archive_sha256': candidate['sha256'], 'profiles': profiles,
    'full_jni_qualification': False, 'cross_host_qualified': False, 'release_claim_eligible': False,
    'scope': 'Independent public replay of completed current installed C/OpenSSL Debug and Release components, matching native TLS and altered-evidence controls. No new native workload execution or whole JNI/device/release qualification.'}
sdk.write_json(OUT / 'READBACK.json', result)
sdk.write_json(OUT / 'SELECTED_FILES.json', files)
print(json.dumps({k:result[k] for k in ['completed', 'source_commit', 'source_inputs_verified', 'candidate_archive_sha256']}))
