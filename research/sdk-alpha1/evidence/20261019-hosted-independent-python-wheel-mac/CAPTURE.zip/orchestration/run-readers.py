"""Run only trusted frozen-source readers of a completed hosted artifact."""
from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
platform = sys.argv[1]
assert platform in {"linux", "mac"}
out = base / platform
assert json.loads((out / "JOB.json").read_text())["conclusion"] == "success"
assert not (out / "download.stderr").read_bytes()
labels = ["regressions", "control", "resolution", "witness", "peer-lifecycle",
          "reply-release", "local-renewal", "local-credential", "pending",
          "public-inputs", "registration", "installation", "python-registration", "python-installation"]
rows = []
for label in labels:
    script = (base if label in {"installation", "python-installation"} else out) / ("review-" + label + ".py")
    command = ["sh", "artifact/python-run.sh", str(script)]
    if label in {"installation", "python-installation"}:
        command.append(platform)
    with (out / (label + ".stdout")).open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
        result = subprocess.run(command, cwd=root, env=dict(os.environ, QPERIAPT_PYTHON=sys.executable),
                                stdout=stdout, stderr=stderr, timeout=300)
    rows.append({"reader": label, "exit": result.returncode})
    (out / "READERS.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows[-1]), flush=True)
    if result.returncode == 0:
        report_name = "REGRESSION" if label == "regressions" else label.replace("-", "_").upper()
        assert (out / (report_name + "_READBACK.json")).is_file(), "reader did not write this cohort's report"
    if result.returncode:
        sys.exit(result.returncode)
