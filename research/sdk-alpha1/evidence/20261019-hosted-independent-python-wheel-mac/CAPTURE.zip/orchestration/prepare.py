"""Freeze exact Git inputs and adapt the already-qualified public readers."""
from pathlib import Path
import ast, hashlib, json, subprocess
root=Path.cwd(); base=Path(__file__).resolve().parent
old=root/'target/independent-python-namespace-hosted-115f-01'
head='8d2fcbd1d7582e4b2e147aa6742be828f30d60a9'; previous='115fb323c9082f4db573ff2fdbb17c75c4c3f372'
sha=lambda data:hashlib.sha256(data).hexdigest()
def git(name):return subprocess.check_output(['git','show',head+':'+name])
keys=set(json.loads((old/'READER_SOURCE_FILES.json').read_text()))
keys.update(json.loads((root/'target/independent-python-ci-01/INSTALLATION_READBACK.json').read_text())['source_files'])
manifest={}
for name in sorted(keys):
 data=git(name); path=base/'reader-source'/name; path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(data)
 manifest[name]=sha(data)
(base/'READER_SOURCE_FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
for platform,job in [('linux',117852832177),('mac',117852832006)]:
 out=base/platform; out.mkdir()
 source=json.loads((old/platform/'SOURCE_FILES.json').read_text()); frozen={}
 for name in source:
  data=git('research/continuity-openssl-peer/'+name); path=out/'source'/name; path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as stream:stream.write(data)
  frozen[name]=sha(data)
 (out/'SOURCE_FILES.json').write_text(json.dumps(frozen,indent=2)+'\n')
 for p in (old/platform).glob('*.py'):
  if p.name=='download.py':
   text=p.read_text().replace(previous,head).replace('39184186420','39187474595').replace('117843019701' if platform=='linux' else '117843019529',str(job)).replace('-115f.zip','-8d2f.zip')
  else:text=p.read_text().replace(previous,head)
  ast.parse(text); (out/p.name).write_text(text)
 p=out/'review-registration.py'; text=p.read_text()
 assert text.count("base=out/'public/registration'")==1
 text=text.replace("base=out/'public/registration'","base=out/'public/python-installed/registration'")
 text=text.replace("out/'public/registration.stderr'","out/'public/python-installed/registration.stderr'")
 text=text.replace("out/'REGISTRATION_READBACK.json'","out/'PYTHON_REGISTRATION_READBACK.json'")
 (out/'review-python-registration.py').write_text(text)
for name in ['review-installation.py','run-readers.py']:
 text=(old/name).read_text().replace(previous,head)
 if name=='run-readers.py':
  text=text.replace('"public-inputs", "registration", "installation"]','"public-inputs", "registration", "installation", "python-registration", "python-installation"]')
  text=text.replace('label == "installation"','label in {"installation", "python-installation"}')
 ast.parse(text);(base/name).write_text(text)
(base/'PREPARED.json').write_text(json.dumps({'head':head,'runtime_source_files':len(frozen),'reader_source_files':len(manifest),'readers':14,'scope':'Twelve existing readers plus installed Python registration and wheel provenance. No uploaded code is executed.'},indent=2)+'\n')
print(json.dumps({'head':head,'runtime':len(frozen),'reader_sources':len(manifest)}))
