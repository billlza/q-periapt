"""Seal completed installed-reference CI readbacks and preserved reader failures."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

root = Path.cwd()
base = Path(__file__).resolve().parent
platform = sys.argv[1]
assert platform in {"linux", "mac"}
out = base / platform
head = "8d2fcbd1d7582e4b2e147aa6742be828f30d60a9"
def read(path):
    return json.loads(path.read_text())
def sha(data):
    return hashlib.sha256(data).hexdigest()

labels = ["REGRESSION", "CONTROL", "RESOLUTION", "WITNESS", "PEER_LIFECYCLE",
          "REPLY_RELEASE", "LOCAL_RENEWAL", "LOCAL_CREDENTIAL", "PENDING",
          "PUBLIC_INPUTS", "REGISTRATION", "INSTALLATION", "PYTHON_REGISTRATION", "PYTHON_INSTALLATION"]
reports = {label: read(out / (label + "_READBACK.json")) for label in labels}
readers = read(out / "READERS.json")
assert len(readers) == 14 and all(row["exit"] == 0 for row in readers)
for row in readers:
    assert not (out / (row["reader"] + ".stderr")).read_bytes()
sources = read(out / "SOURCE_FILES.json")
assert len(sources) == 99
for label, report in reports.items():
    if label not in {"REPLY_RELEASE", "INSTALLATION", "PYTHON_INSTALLATION"}:
        assert report["head"] == head and report["source_files"] == sources
        assert report["native_sha256"] == reports["INSTALLATION"]["native_sha256"]
job = read(out / "JOB.json")
artifact = read(out / "ARTIFACT.json")
assert job["head_sha"] == head and job["run_id"] == 39187474595
assert job["status"] == "completed" and job["conclusion"] == "success"
archive = out / (platform + "-8d2f.zip")
body = archive.read_bytes()
assert len(body) == artifact["size_in_bytes"] and "sha256:" + sha(body) == artifact["digest"]
# Preserve the exact upstream artifact without exceeding the per-file archive
# limit. The original ZIP is reconstructed from two ordered, hashed byte parts.
parts = {f"upstream/{archive.name}.part-{index:02d}": body[offset:offset + 32 * 1024**2]
         for index, offset in enumerate(range(0, len(body), 32 * 1024**2))}
assert b"".join(parts.values()) == body
entries = dict(parts)
reassembly = {"filename": archive.name, "bytes": len(body), "sha256": sha(body),
              "parts": [{"member": name, "bytes": len(data), "sha256": sha(data)} for name, data in parts.items()]}
entries["UPSTREAM.json"] = (json.dumps(reassembly, indent=2) + "\n").encode()
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {".py", ".json", ".txt", ".stdout", ".stderr"}:
        entries[path.name] = path.read_bytes()
for path in sorted((out / "wrong-cohort-attempt").iterdir()):
    assert path.is_file()
    entries["wrong-cohort-attempt/" + path.name] = path.read_bytes()
for name in ["INPUTS.json", "PREPARED.json", "run-readers.py", "READER_REPAIR.json", "repair-readers.py", "rerun-readers.py",
             "review-installation.py", "review-python-installation.py", "EXPECTED_PYTHON_SOURCES.json", "prepare.py", "seal.py", "ARCHIVE_LAYOUT.json", "seal-before-split.py.txt", "READER_SOURCE_FILES.json"]:
    entries["orchestration/" + name] = (base / name).read_bytes()
for name, expected in sources.items():
    data = (out / "source" / name).read_bytes()
    assert sha(data) == expected
    entries["peer-source/" + name] = data
for name, expected in read(base / "READER_SOURCE_FILES.json").items():
    data = (base / "reader-source" / name).read_bytes()
    assert sha(data) == expected
    entries["build-reader-source/" + name] = data
for name in ["SDK_ARTIFACT.json", "sdk/sdk-rust-package/RUST_SDK_PACKAGE.json"]:
    entries["sdk/" + Path(name).name] = (root / "target/independent-installed-01" / name).read_bytes()
manifest = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(entries.items())}
entries["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
folder = root / "research/sdk-alpha1/evidence" / ("20261019-hosted-independent-python-wheel-" + platform)
folder.mkdir()
groups = {
    "CAPTURE.zip": {n: b for n, b in entries.items() if not n.startswith(("build-reader-source/", "upstream/"))},
    "SOURCE.zip": {n: b for n, b in entries.items() if n.startswith("build-reader-source/")},
}
for index, (name, data) in enumerate(parts.items()):
    groups[f"ARTIFACT-{index:02d}.zip"] = {name: data}
assert sum(len(group) for group in groups.values()) == len(entries)
assert set().union(*(set(group) for group in groups.values())) == set(entries)
captures = {}
for filename, selected in groups.items():
    capture = folder / filename
    with zipfile.ZipFile(capture, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(selected.items()):
            item = zipfile.ZipInfo(name, (2026, 10, 19, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            z.writestr(item, data)
    with zipfile.ZipFile(capture) as z:
        assert z.testzip() is None and len(z.namelist()) == len(selected) == len(set(z.namelist()))
        for name in selected:
            assert z.read(name) == selected[name]
    assert capture.stat().st_size < 50 * 1024**2
    captures[filename] = {"bytes": capture.stat().st_size, "members": len(selected), "sha256": sha(capture.read_bytes())}
result = {
    "head": head, "run": job["run_id"], "job": job["id"], "job_conclusion": job["conclusion"],
    "artifact": {"id": artifact["id"], "bytes": artifact["size_in_bytes"], "digest": artifact["digest"]},
    "capture": captures["CAPTURE.zip"], "source_capture": captures["SOURCE.zip"],
    "capture_layout": "Disjoint CAPTURE.zip, SOURCE.zip and ARTIFACT-NN.zip. MANIFEST.json covers all members; UPSTREAM.json orders hashed byte parts that reconstruct the exact downloaded GitHub artifact.",
    "upstream_capture": {name: value for name, value in captures.items() if name.startswith("ARTIFACT-")},
    "upstream_reassembly": reassembly,
    "readbacks": reports,
    "scope": "Nineteen existing reference lanes plus registration from the actual pip-installed Python wheel. Fourteen readbacks bind exact sources, installed Rust graph, binaries, wheel bytes, recorded Python origins and public original-operation/signature records. Remote private-state, filesystem and installed RECORD/direct_url byte checks remain producer observations. Same-host reference issuer, not deployed account authentication, cross-host carrier, full multidevice lifecycle, PCS, energy or release admission.",
    "reader_repair": "Seven inherited readers per platform initially used previous115f public paths. Those exits were excluded as current-cohort evidence. Wrong-attempt scripts/output and accidentally overwritten derived reports are retained; previous reports restored exactly from published archives. Paths now bind to script location and only the seven affected readers were rerun successfully. All14 final reports bind current8d2f. No runtime rerun.",
    "reader_source_boundary": "Frozen Git sources at the exact tested head; no uploaded executable or Python file is executed during artifact readback. The source Python and installed Python registration records are separate executions.",
    "sdk_archives": "Report and artifact identity retained here; exact upstream SDK archive bytes are also retained in 20261019-independent-installed-counterpart."
}
(folder / "CHECKS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(captures))
