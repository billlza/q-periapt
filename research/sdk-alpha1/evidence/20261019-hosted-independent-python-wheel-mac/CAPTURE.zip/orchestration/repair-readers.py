"""Preserve the mistaken-template attempt; restore original prior public reports.

No protocol/runtime output or private state is changed. Only derived local
readback JSONs accidentally overwritten by the seven templates are restored
from their already-published exact capture bytes.
"""
from pathlib import Path
import ast,hashlib,json,zipfile
root=Path.cwd();base=Path(__file__).resolve().parent
labels={'regressions':'REGRESSION','control':'CONTROL','resolution':'RESOLUTION','witness':'WITNESS','peer-lifecycle':'PEER_LIFECYCLE','reply-release':'REPLY_RELEASE','local-renewal':'LOCAL_RENEWAL'}
rows=[]
for platform in ('linux','mac'):
 out=base/platform; saved=out/'wrong-cohort-attempt';saved.mkdir()
 (out/'READERS.json').rename(saved/'READERS.json')
 for label,report in labels.items():
  p=out/('review-'+label+'.py');before=p.read_text()
  old=f"target/independent-python-namespace-hosted-115f-01/{platform}/public"
  assert before.count(old)==1
  (saved/p.name).write_text(before)
  for previous,new in [(f"root/'{old}'","Path(__file__).resolve().parent/'public'"),(f"root / '{old}'","Path(__file__).resolve().parent / 'public'")]:
   before=before.replace(previous,new)
  assert old not in before;ast.parse(before);p.write_text(before)
  for suffix in ('stdout','stderr'):(out/(label+'.'+suffix)).rename(saved/(label+'.'+suffix))
  prior=root/'target/independent-python-namespace-hosted-115f-01'/platform/(report+'_READBACK.json')
  overwritten=prior.read_bytes();(saved/('prior-overwritten-'+prior.name)).write_bytes(overwritten)
  capture=root/'research/sdk-alpha1/evidence'/('20261019-hosted-independent-python-namespace-'+platform)/'CAPTURE.zip'
  with zipfile.ZipFile(capture)as z:
   original=z.read(prior.name);manifest=json.loads(z.read('MANIFEST.json'))
   assert hashlib.sha256(original).hexdigest()==manifest[prior.name]['sha256']
  prior.write_bytes(original)
  rows.append({'platform':platform,'reader':label,'wrong_prior_path':str(prior.relative_to(root)),
   'overwritten_sha256':hashlib.sha256(overwritten).hexdigest(),'restored_original_sha256':hashlib.sha256(original).hexdigest(),
   'original_capture':str(capture.relative_to(root))})
 if (out/'seal.stderr').exists():
  (out/'seal.stderr').rename(saved/'seal.stderr');(out/'seal.stdout').rename(saved/'seal.stdout')
(base/'READER_REPAIR.json').write_text(json.dumps({'cause':'Seven templates per platform still read previous115f public directory and wrote derived reports there. Initial zero exits are not newcohort evidence. Seven other readers correctly used8d2f.','scope':'Only7 affected public readers will rerun, no CI/runtime rerun. Prior derived reports restored exactly from their published capture; mistaken outputs preserved.','files':rows},indent=2)+'\n')
# Make a future full orchestrated run fail if expected reports are not produced.
p=base/'run-readers.py';s=p.read_text();s=s.replace('    if result.returncode:', '''    if result.returncode == 0:
        report_name = "REGRESSION" if label == "regressions" else label.replace("-", "_").upper()
        assert (out / (report_name + "_READBACK.json")).is_file(), "reader did not write this cohort's report"
    if result.returncode:''');p.write_text(s)
print(json.dumps({'repaired_readers':len(rows),'prior_reports_restored':len(rows),'runtime_changed':False}))
