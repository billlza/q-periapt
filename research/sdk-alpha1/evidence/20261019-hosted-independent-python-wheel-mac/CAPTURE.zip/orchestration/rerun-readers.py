"""Re-run only the readers whose data directory was incorrectly inherited."""
from pathlib import Path
import json,os,subprocess,sys
root=Path.cwd();base=Path(__file__).resolve().parent;platform=sys.argv[1]
assert platform in {'linux','mac'};out=base/platform
labels=['regressions','control','resolution','witness','peer-lifecycle','reply-release','local-renewal']
original=json.loads((out/'wrong-cohort-attempt/READERS.json').read_text());rows=[]
for label in labels:
 with (out/(label+'.stdout')).open('xb')as stdout,(out/(label+'.stderr')).open('xb')as stderr:
  r=subprocess.run(['sh','artifact/python-run.sh',str(out/('review-'+label+'.py'))],cwd=root,env=dict(os.environ,QPERIAPT_PYTHON=sys.executable),stdout=stdout,stderr=stderr,timeout=300)
 rows.append({'reader':label,'exit':r.returncode,'attempt':2,'scope':'Current8d2f public artifacts after explicit path repair'})
 (out/'READERS_REPAIR.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if r.returncode:sys.exit(r.returncode)
 name='REGRESSION' if label=='regressions'else label.replace('-','_').upper()
 assert (out/(name+'_READBACK.json')).is_file()
updated={r['reader']:r for r in rows}
result=[updated.get(row['reader'],row|{'attempt':1,'scope':'Correct8d2f path on first execution'})for row in original]
assert len(result)==14 and all(row['exit']==0 for row in result)
(out/'READERS.json').write_text(json.dumps(result,indent=2)+'\n')
