"""Recheck shipped wheel bytes and bind them to installed runtime receipts.

The hosted consumer directory is not exported. Its final filesystem and
installed RECORD/direct_url assertions remain producer observations.
"""
from pathlib import Path, PurePosixPath
from urllib.parse import quote
import hashlib, json, re, subprocess, sys

repo=Path.cwd(); base=Path(__file__).resolve().parent; source=base/'reader-source'
head='8d2fcbd1d7582e4b2e147aa6742be828f30d60a9'
platform=sys.argv[1]; assert platform in {'linux','mac'}
out=base/platform; public=out/'public'; built=public/'python-installed'
sys.path.insert(0,str(source/'artifact'))
import continuity_independent_python as package
import continuity_independent_python_run as consumer
sha=lambda data:hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_text())
def git(name):return subprocess.check_output(['git','show',head+':'+name])
def remote(value):
 p=PurePosixPath(value)
 assert p.is_absolute() and '..' not in p.parts and str(p)==value
 return p

report=read(built/'PYTHON_INSTALLATION.json')
assert report['kind']=='qperiapt.independent_python_installation' and report['schema_version']==1
assert report['source_commit']==head and report['completed'] is True and report['sources_unchanged'] is True
assert report['release_claim_eligible'] is False and 'failure' not in report
expected_paths=set(read(base/'EXPECTED_PYTHON_SOURCES.json'))
assert len(report['source_inputs'])==111 and set(report['source_inputs'])==expected_paths
for name,digest in report['source_inputs'].items():
 assert sha(git(name))==digest==sha((source/name).read_bytes()),name
reference=source/'research/continuity-openssl-peer'
modules={p.name:p.read_bytes() for p in (reference/package.PACKAGE).glob('*.py')}
wheel=(built/consumer.WHEEL).read_bytes()
assert sha(wheel)==report['wheel_sha256'] and wheel==(public/'python-wheel'/consumer.WHEEL).read_bytes()
files=package.inspect_wheel(wheel,modules,{n:(reference/n).read_bytes() for n in ('LICENSE-APACHE','LICENSE-MIT')},(reference/'README.md').read_bytes())
assert len(files)==52 and len(modules)==47
installed=read(built/'INSTALLED_FILES.json'); info=package.PACKAGE+'-0.0.0.dist-info/'
assert len(installed)==55 and set(installed)==set(files)|{info+n for n in ('INSTALLER','REQUESTED','direct_url.json')}
assert all(re.fullmatch('[0-9a-f]{64}',value) for value in installed.values())
for name,body in files.items():
 if name!=info+'RECORD': assert installed[name]==sha(body),name
assert installed[info+'INSTALLER']==sha(b'pip\n') and installed[info+'REQUESTED']==sha(b'')
# pip rewrites RECORD and adds direct_url.json; only their producer hashes are
# exported. Do not pretend these bytes or the remote consumer are present here.
location=remote(read(built/'LOCATION.json')['path']); application=location/'research/continuity-openssl-peer'
probe=read(built/'PROVENANCE.json'); expected={n:sha(b) for n,b in modules.items()}
assert expected==report['modules']==probe['modules']==read(built/'EXPECTED_MODULES.json')
assert probe['package_root']==str(application/package.PACKAGE)
assert probe['pycache_prefix']==str(location/'private-cache')
assert all(probe[n]==1 for n in ('isolated','no_site','dont_write_bytecode'))
assert probe['python'].startswith('3.14.7 ') and probe['cryptography']=='48.0.1'
commands={n:read(built/(n+'.json')) for n in ('install','probe','registration')}
for name,row in commands.items():
 assert row['exit']==0 and remote(row['cwd'])==location
 assert not (built/(name+'.stderr')).read_bytes()
 args=row['argv']; assert args[1]=='-I'
 if name!='install':
  assert args[1:5]==['-I','-S','-B','-X'] and args[5]=='pycache_prefix='+str(location/'private-cache')
  assert args[6]==str(location/'artifact/python_bootstrap.py')
install=commands['install']['argv']
assert {'--no-index','--no-deps','--no-compile','--require-hashes','--isolated'}<=set(install)
assert install[install.index('--target')+1]==str(application)
requirements=remote(install[install.index('-r')+1]); captured=requirements.parent/consumer.WHEEL
assert (built/'wheel-requirements.txt').read_text()=='file://'+quote(str(captured))+' --hash=sha256:'+sha(wheel)+'\n'
probe_args=commands['probe']['argv']; checked_app,provider,checkout,expected_path,provenance_path=probe_args[-5:]
assert checked_app==str(application) and remote(provider)!=application
checkout=remote(checkout); assert not location.is_relative_to(checkout)
assert all(not remote(p).is_relative_to(checkout) for p in probe['sys_path'])
assert {str(application),str(location),str(location/'artifact'),provider}<=set(probe['sys_path'])
assert remote(expected_path)==requirements.parent/'EXPECTED_MODULES.json'
assert remote(provenance_path)==requirements.parent/'PROVENANCE.json'
registration=commands['registration']['argv']
assert registration[7]==str(application/'registration_checks.py')
assert registration[registration.index('--provider-root')+1]==provider
assert remote(registration[registration.index('--output')+1])==requirements.parent/'registration'
assert sha((public/'counterpart').read_bytes())==report['native_sha256']==read(out/'INSTALLATION_READBACK.json')['native_sha256']
records=read(out/'PYTHON_REGISTRATION_READBACK.json'); assert records['head']==head and records['native_sha256']==report['native_sha256']
runtime=read(built/'registration/RESULT.json')
assert runtime['provider']==report['provider'] and runtime['source_files']==read(out/'SOURCE_FILES.json')
for label in ('local','witness'):
 assert report['registration'][label]==runtime[label]
 assert records['profiles'][label]['workers']==runtime[label]['workers']
 assert records['profiles'][label]['actual_SIGKILL']==runtime[label]['process_kills']
 assert records['profiles'][label]['native_commands']==runtime[label]['native_commands']
assert not (public/'python-installed.stderr').read_bytes()
for name in ('backend','build'):
 assert not re.search(rb'(?mi)^\s*(warning:|error:)',(public/'python-wheel'/(name+'.stderr')).read_bytes())
result={'head':head,'platform':platform,'wheel_sha256':sha(wheel),'wheel_members':len(files),'source_inputs':report['source_inputs'],
 'module_files':len(modules),'reported_installed_files':len(installed),'locally_checked_installed_hashes':53,
 'native_sha256':report['native_sha256'],'registration':records['profiles'],
 'scope':'Source-bound wheel bytes, all47 module hashes, recorded isolated paths/command exits, and installed runtime public signatures/original operations rechecked. Remote final filesystem and installed RECORD/direct_url byte checks remain producer observations. Same-host reference issuer; not deployed account authentication, cross-host transport, physical erasure, PCS or release admission.'}
(out/'PYTHON_INSTALLATION_READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('head','platform','wheel_sha256','module_files','reported_installed_files')}))
