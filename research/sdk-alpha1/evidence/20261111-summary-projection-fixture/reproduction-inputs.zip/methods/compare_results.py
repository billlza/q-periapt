#!/usr/bin/env python3
"""Read the complete fixture results and verify the executed source identities."""
import gzip
import hashlib
import json
from pathlib import Path

from prepare_arms import ROOT, LIBRARY_PATH, PLAN_PATH, identity, inventory, write_json


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def read_json(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def main():
    inputs = read_json(ROOT / "evidence/ARM_INPUTS.json")
    initial_db = json.loads(gzip.decompress((ROOT / "evidence/INITIAL_DATABASE_FILES.json.gz").read_bytes()))
    original_dependencies = inventory(ROOT / "original-pack/.codeql/libraries")
    result = {
        "kind": "qperiapt.nonempty_rust_fixture_full_summary_comparison",
        "fixture": "github/codeql rust/ql/test/library-tests/dataflow/sources/env at codeql-cli/v2.27.2",
        "status": "complete_equal_nonempty_results",
        "plan_order": ["all", "projection"],
        "budget": {"threads": 1, "heap_mib": 1536, "native_mib": 512, "supervisor_seconds": 300},
        "comparison_method": "Complete decoded JSON equality, including every result set, ordered column descriptors, all tuples and their multiplicity; no row filtering or result normalization.",
        "timing_interpretation": "One sequential pair on a shared local host with a separate large-database analysis running concurrently. Elapsed times are observed completion records, not an isolated performance estimate.",
        "arms": {},
    }
    decoded = {}
    for mode in ("all", "projection"):
        arm = ROOT / "arms" / mode
        pack = arm / "query-pack"
        before = inputs[mode]
        for name, expected in before["capsule_members"].items():
            assert identity(pack / name) == expected, name
        for name, expected in before["source_files"].items():
            assert identity(pack / name) == expected, name
        for name, expected in before["other_qlx"].items():
            assert identity(pack / name) == expected, name
        dependencies = inventory(pack / ".codeql/libraries")
        expected_dependencies = dict(original_dependencies)
        for name, change in before["dependency_changes"].items():
            expected_dependencies[name] = change["after"]
        assert dependencies == expected_dependencies
        database_differences = []
        for name, expected in initial_db.items():
            actual = identity(arm / "database" / name)
            if actual != expected:
                database_differences.append(name)
        assert all(name.startswith("db-rust/default/cache/") for name in database_differences)
        immutable_count = sum(not name.startswith("db-rust/default/cache/") for name in initial_db)
        evaluation = read_json(ROOT / "evidence" / ("evaluate-" + mode) / "RESULT.json")
        decode = read_json(ROOT / "evidence" / ("decode-" + mode) / "RESULT.json")
        assert evaluation["status"] == decode["status"] == "completed"
        assert evaluation["exit_code"] == decode["exit_code"] == 0
        assert evaluation["wall_seconds"] < 300
        output = ROOT / "evidence" / ("decode-" + mode) / "stdout.log"
        decoded[mode] = read_json(output)
        logs = list((arm / "logs").glob("*.log"))
        assert len(logs) == 1
        loads, compiles, read_relations, selected_lines = [], [], [], []
        with logs[0].open() as stream:
            for line in stream:
                if "[PROGRESS] execute queries> [1/1] Loaded " in line:
                    loads.append(line.rstrip())
                if "Compiling query plan" in line:
                    compiles.append(line.rstrip())
                if ("Stage4::fwdFlowRead" in line and " >>> Created relation " in line and
                        " with " in line and " rows and digest " in line):
                    tail = line.split(" with ", 1)[1]
                    rows, digest = tail.split(" rows and digest ", 1)
                    read_relations.append({"rows": int(rows), "digest": digest.strip().removesuffix("."), "line": line.rstrip()})
                    selected_lines.append(line.rstrip())
                elif "[PROGRESS] execute queries> [1/1] Loaded " in line or "Evaluation done; writing results" in line or "Query done" in line:
                    selected_lines.append(line.rstrip())
        assert len(loads) == 1 and str(pack / PLAN_PATH) in loads[0]
        assert not compiles
        full_read = [entry for entry in read_relations if "Stage4::fwdFlowRead/11#" in entry["line"]]
        assert len(full_read) == 1 and full_read[0]["rows"] > 0
        target = [entry for entry in read_relations if "Stage4::fwdFlowReadTarget/6#" in entry["line"]]
        if mode == "projection":
            assert len(target) == 1 and target[0]["rows"] > 0
        else:
            assert not target
        result["arms"][mode] = {
            "exit_code": evaluation["exit_code"], "wall_seconds": evaluation["wall_seconds"],
            "bqrs": identity(arm / "results/codeql/rust-queries/queries/summary/SummaryStats.bqrs"),
            "decoded": identity(output), "evaluator_log": identity(logs[0]),
            "loaded_plan_count": len(loads), "implicit_compilation_count": len(compiles),
            "loaded_plan_line": loads[0], "compiler_inputs_digest": before["compiler_inputs_digest"],
            "plan_sha256": identity(pack / PLAN_PATH)["sha256"],
            "capsule_16_members_unchanged_after_execution": True,
            "all_39_root_sources_unchanged_after_execution": True,
            "other_38_qlx_unchanged_after_execution": True,
            "all_1175_dependencies_match_declared_state_after_execution": True,
            "initial_database_files": len(initial_db),
            "immutable_database_files_unchanged": immutable_count,
            "modified_initial_database_files_only_evaluator_cache": database_differences,
            "full_read_relation": full_read[0], "target_relation": target,
        }
        (ROOT / "evidence" / (mode + "-EVALUATOR_EXCERPTS.txt")).write_text("\n".join(selected_lines) + "\n")
    assert decoded["all"] == decoded["projection"]
    full_a = result["arms"]["all"]["full_read_relation"]
    full_b = result["arms"]["projection"]["full_read_relation"]
    assert (full_a["rows"], full_a["digest"]) == (full_b["rows"], full_b["digest"])
    complete = decoded["all"]
    canonical = json.dumps(complete, sort_keys=True, separators=(",", ":")).encode()
    tuples = complete["#select"]["tuples"]
    assert len({row[0] for row in tuples}) == len(tuples)
    values = dict(tuples)
    assert values["Taint sources - active"] > 0 and values["Taint reach - nodes tainted"] > 0
    result.update(
        complete_decoded_results_equal=True,
        semantic_sha256=hashlib.sha256(canonical).hexdigest(),
        result_sets={key: {"columns": value["columns"], "row_count": len(value["tuples"])} for key, value in complete.items()},
        summary_values=values,
        full_read_rows_and_digest_equal=True,
        query_executions_total=2,
        nonadmitted_extraction_attempt="extract: successful process exit, missing sysroot sources and three fixture macro warnings; retained for diagnosis, never evaluated or used as either comparison input",
        accepted_extraction="extract-with-sysroot: explicit installed Rust 1.98.1 and authenticated matching rust-src; all extraction and inconsistency counts in the full result are zero",
    )
    write_json(ROOT / "evidence/COMPARISON.json", result)
    print(json.dumps({"status": result["status"], "rows": len(tuples), "semantic_sha256": result["semantic_sha256"], "source_count": values["Taint sources - active"], "tainted_count": values["Taint reach - nodes tainted"]}, indent=2))


if __name__ == "__main__":
    main()
