#!/usr/bin/env python3
"""Collect completed fixture evidence; no extraction or query execution."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent.parent
PACKET = ROOT.parent / "20261111-summary-projection-fixture"


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def copy(source, relative):
    target = PACKET / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def compressed(source, relative):
    target = PACKET / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as incoming, target.open("wb") as outgoing:
        with gzip.GzipFile(filename="", fileobj=outgoing, mode="wb", mtime=0) as zipped:
            shutil.copyfileobj(incoming, zipped, 1024 * 1024)
    return {"raw": identity(source), "gzip": identity(target)}


def main():
    PACKET.mkdir(exist_ok=False)
    for name in ("COMPARISON.json", "ARM_INPUTS.json", "INITIAL_DATABASE_FILES.json.gz", "TOOLCHAIN_IDENTITY.json", "FIXTURE_SOURCE.json", "all-EVALUATOR_EXCERPTS.txt", "projection-EVALUATOR_EXCERPTS.txt"):
        copy(ROOT / "evidence" / name, name)
    for step in ("extract", "extract-with-sysroot", "evaluate-all", "evaluate-projection", "decode-all", "decode-projection"):
        for name in ("STARTED.json", "RESULT.json", "stdout.log", "stderr.log"):
            copy(ROOT / "evidence" / step / name, "steps/" + step + "/" + name)
    for name in ("test.rs", "Cargo.lock", "options.yml", "Cargo.toml", "lib.rs"):
        copy(ROOT / "fixture-pack/env" / name, "fixture/env/" + name)
    for name in ("qlpack.yml", "default-threat-models.model.yml"):
        copy(ROOT / "fixture-pack" / name, "fixture/" + name)
    for mode in ("all", "projection"):
        copy(ROOT / "arms" / mode / "results/codeql/rust-queries/queries/summary/SummaryStats.bqrs", "results/" + mode + "/SummaryStats.bqrs")
        copy(ROOT / "arms" / mode / "INPUTS.json", "results/" + mode + "/INPUTS.json")
    for name in ("bounded_process.py", "run_bounded.py", "prepare_arms.py", "compare_results.py", "build_packet.py"):
        copy(ROOT / "commands" / name, "methods/" + name)
    raw_logs = {}
    for mode in ("all", "projection"):
        logs = list((ROOT / "arms" / mode / "logs").glob("*.log"))
        assert len(logs) == 1
        raw_logs[mode] = compressed(logs[0], "logs/" + mode + "-evaluator.log.gz")
    for name, database in (("extract-not-admitted", "database-original"), ("extract-admitted", "database-complete")):
        raw_logs[name] = compressed(ROOT / database / "log/qltest.log", "logs/" + name + "-qltest.log.gz")
    for name, directory in (("extract-not-admitted-command", "extract-logs"), ("extract-admitted-command", "extract-complete-logs")):
        logs = list((ROOT / directory).glob("*.log"))
        assert len(logs) == 1
        raw_logs[name] = compressed(logs[0], "logs/" + name + ".log.gz")
    (PACKET / "LOG_IDENTITIES.json").write_text(json.dumps(raw_logs, indent=2, sort_keys=True) + "\n")
    print(str(PACKET))


if __name__ == "__main__":
    main()
