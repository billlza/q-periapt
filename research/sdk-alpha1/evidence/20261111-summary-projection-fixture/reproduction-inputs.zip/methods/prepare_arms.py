#!/usr/bin/env python3
"""Prepare isolated inputs for a declared local, full-summary comparison."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT.parent
PROTOTYPE = BASE / "summary-plan-feasibility"
PLAN_PATH = "queries/summary/SummaryStats.qlx"
SOURCE_SHA = "7278d53373afb4f8069122e287c9c036a959ba0d167c152d67cd0de885881d67"
LIBRARY_PATH = ".codeql/libraries/codeql/dataflow/2.1.15/codeql/dataflow/internal/DataFlowImpl.qll"


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def inventory(path):
    return {str(p.relative_to(path)): identity(p) for p in sorted(path.rglob("*")) if p.is_file()}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    original = ROOT / "original-pack"
    assert identity(original / PLAN_PATH)["sha256"] == "bc65daf746a13e0d162f0853b3a21eda41ff2d573774e6862983a916c06244a6"
    assert identity(original / PLAN_PATH.replace(".qlx", ".ql"))["sha256"] == SOURCE_SHA
    manifests = {
        "all": json.loads((BASE / "q-periapt/artifact/codeql_summary_dynamic_plan.json").read_text()),
        "projection": json.loads((PROTOTYPE / "review-packet/CANDIDATE_CAPSULE.json").read_text()),
    }
    capsules = {
        "all": BASE / "q-periapt/artifact/codeql-summary-dynamic-plan.zip",
        "projection": PROTOTYPE / "review-packet/codeql-stage4-projected-read.zip",
    }
    expected_capsules = {
        "all": "ce21381b3bec721aab246b26b84c00834959871235e1e82354addca8a40dcef7",
        "projection": "1fe6db109a540d6063fca24e25e9d6c56a88f972a5c248d74fd95f7248fb6132",
    }
    expected_keys = {"all": "209f28c6b9e8d5465a3f8417573e42d6", "projection": "70fcc50b9809b694b26b77a11722cdbb"}
    original_dependencies = inventory(original / ".codeql/libraries")
    assert len(original_dependencies) == 1175
    database_before = inventory(ROOT / "database-complete")
    assert not (ROOT / "database-complete/db-rust/lock").exists()
    all_receipts = {}
    for mode in ("all", "projection"):
        arm = ROOT / "arms" / mode
        arm.mkdir(parents=True)
        pack = arm / "query-pack"
        shutil.copytree(original, pack)
        if mode == "projection":
            replacement = PROTOTYPE / "candidate-query-pack" / LIBRARY_PATH
            assert identity(replacement)["sha256"] == "c2578c2642d0e382ca5438c7d72f69415ca115b5b248778eb0b8b1398526ca06"
            shutil.copy2(replacement, pack / LIBRARY_PATH)
        capsule = capsules[mode]
        assert identity(capsule)["sha256"] == expected_capsules[mode]
        manifest = manifests[mode]
        with zipfile.ZipFile(capsule) as archive:
            assert len(archive.infolist()) == len(set(archive.namelist())) == 16
            assert set(archive.namelist()) == set(manifest["files"])
            for member in archive.infolist():
                name = PurePosixPath(member.filename)
                assert not name.is_absolute() and ".." not in name.parts
                assert stat.S_ISREG(member.external_attr >> 16)
                data = archive.read(member)
                assert {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} == manifest["files"][str(name)]
                target = pack / name
                if str(name) != PLAN_PATH:
                    assert not target.exists()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        header = (pack / PLAN_PATH).read_bytes().split(b"\n\n", 1)[0].decode()
        assert re.findall(r"^inputsDigest: (\w+)$", header, re.MULTILINE) == [expected_keys[mode]]
        loaded_dependencies = inventory(pack / ".codeql/libraries")
        changed = {name: {"before": original_dependencies[name], "after": actual}
                   for name, actual in loaded_dependencies.items()
                   if original_dependencies[name] != actual}
        assert set(loaded_dependencies) == set(original_dependencies)
        assert set(changed) == ({LIBRARY_PATH.removeprefix(".codeql/libraries/")} if mode == "projection" else set())
        query_set = json.loads((PROTOTYPE / "QUERY_SET_IDENTITY.json").read_text())
        other_query_paths = query_set["unchanged_other_query_paths"]
        source_paths = [name.removesuffix("x") for name in other_query_paths] + [PLAN_PATH.removesuffix("x")]
        source_files = {name: identity(original / name) for name in source_paths}
        assert len(source_files) == 39
        assert all(identity(pack / name) == record for name, record in source_files.items())
        assert all(identity(pack / p.relative_to(original)) == identity(p) for p in original.rglob("*.ql"))
        other_qlx = {name: identity(original / name) for name in other_query_paths}
        assert len(other_qlx) == 38
        assert all(identity(pack / name) == record for name, record in other_qlx.items())
        shutil.copytree(ROOT / "database-complete", arm / "database")
        copied_database = inventory(arm / "database")
        assert copied_database == database_before
        suite = arm / "full-summary.qls"
        suite.write_text("- query: " + str(pack / PLAN_PATH.replace(".qlx", ".ql")) + "\n")
        for name in ("common-cache", "logs", "results"):
            (arm / name).mkdir()
        receipt = {
            "mode": mode, "compiler_inputs_digest": expected_keys[mode],
            "plan": identity(pack / PLAN_PATH), "capsule": identity(capsule),
            "capsule_members": manifest["files"], "source_files": source_files,
            "other_qlx": other_qlx, "dependency_file_count": len(loaded_dependencies),
            "dependency_changes": changed, "fixture_source_modified": False,
            "database_files_identical_to_extracted": True,
            "database_file_count": len(copied_database),
            "initial_results_count": len(list((arm / "results").iterdir())),
            "initial_common_cache_count": len(list((arm / "common-cache").iterdir())),
            "threads": 1, "heap_mib": 1536, "native_mib": 512,
            "supervisor_timeout_seconds": 300,
        }
        write_json(arm / "INPUTS.json", receipt)
        all_receipts[mode] = receipt
    with gzip.GzipFile(filename="", mode="wb", fileobj=(ROOT / "evidence/INITIAL_DATABASE_FILES.json.gz").open("wb"), mtime=0) as out:
        out.write((json.dumps(database_before, sort_keys=True, separators=(",", ":")) + "\n").encode())
    write_json(ROOT / "evidence/ARM_INPUTS.json", all_receipts)
    print(json.dumps({mode: {k: v for k, v in receipt.items() if k not in ("capsule_members", "source_files", "other_qlx")} for mode, receipt in all_receipts.items()}, indent=2))


if __name__ == "__main__":
    main()
