"""Retain terminal bounded experiments without treating timeout as a verdict."""
from pathlib import Path
import hashlib
import json
import os
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
labels = ("execution-03", "inheritance-04", "inheritance-06", "inheritance-09", "inheritance-12", "inheritance-14")
receipts = {}
for label in labels:
    started = json.loads((stage / (label + "-STARTED.json")).read_text())
    receipt = json.loads((stage / (label + "-TERMINAL.json")).read_text())
    try:
        os.killpg(started["pid"], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError("owned prover remains live")
    sdk.require(not receipt["accepted"] and not receipt["results"], "new verdict needs independent review/replay before this capture")
    sdk.require(receipt["timed_out"] and not receipt["output_exceeded"], "unexpected failure classification")
    receipt["saturation_completed"] = "[Saturating Sources] Done" in (stage / (label + ".stderr")).read_text()
    receipts[label] = receipt

original = stage / "multi-epoch-01.spthy"
sdk.require(sdk.snapshot(original).sha256 == "1be3e576722af22586edf62eff1cacb913b981e162f3942e133fac613aaf4977", "model changed")
erase = lambda text: text.replace("[+,no_precomp]", "").replace("[no_precomp]", "")
for number in (5, 8, 10, 13):
    sdk.require(erase((stage / f"multi-epoch-{number:02}.spthy").read_text()) == erase(original.read_text()), "annotation variant changed semantics")
    sdk.require(json.loads((stage / f"parse-{number:02}.json").read_text())["returncode"] == 0, "variant parse did not pass")
sdk.require(json.loads((stage / "parse-07.json").read_text())["returncode"] != 0, "missing failed annotation control")
sdk.write_json(stage / "OBSERVED_15.json", {
    "completed": True, "base_commit": "436cdd49aab36003137b3df6ae8e93f1ec88eafd",
    "model_sha256": sdk.snapshot(original).sha256, "queries": 4,
    "accepted_properties_or_witnesses": 0, "terminal_attempts": receipts,
    "parser_valid_annotation_variants": [5, 8, 10, 13],
    "failed_annotation_generator": {"number": 7, "cause": "Matched let-term applications as well as premises; parser rejected before proof; fresh variant 8 confines annotations to rule premises."},
    "all_owned_prover_groups_absent": True, "release_claim_eligible": False,
})
canonical = root / "research/continuity-recovery-symbolic/multi-epoch.spthy"
with canonical.open("xb") as stream:
    stream.write(sdk.snapshot(original).data)
public = root / "research/sdk-alpha1/evidence/20261015-recovery-multi-epoch-model"
public.mkdir()
with (public / "MODEL_MAP.md").open("xb") as stream:
    stream.write(sdk.snapshot(stage / "MODEL_MAP_11.md").data)
files = {"experiments/" + path.name: path for path in stage.iterdir()
         if path.is_file() and path.suffix in (".py", ".spthy", ".json", ".stdout", ".stderr", ".md")}
files["source/multi-epoch.spthy"] = canonical
files["tools/TOOLS_08.json"] = root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json"
for relative in json.loads((stage / "PREPARED_02.json").read_text())["source_sha256"]:
    files["source/" + relative] = root / relative
digests = {}
total = 0
archive = public / "CAPTURE.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(files.items()):
        data = sdk.snapshot(path).data
        total += len(data)
        sdk.require(total <= 16 * 1024**2, "capture too large")
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(info, data)
        digests[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(set(zipped.namelist()) == set(digests) and len(zipped.namelist()) == len(digests), "archive inventory differs")
    for name, digest in digests.items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, "archive member differs")
capture_sha = sdk.snapshot(archive).sha256
sdk.write_json(public / "CAPTURE.json", {
    "capture_sha256": capture_sha, "members": digests, "expanded_bytes": total,
    "observations": json.loads((stage / "OBSERVED_15.json").read_text()),
    "private_sdk_device_data_included": False, "release_claim_eligible": False,
})
sdk.write_json(public / "READBACK.json", {
    "completed": True, "capture_sha256": capture_sha, "members": len(digests),
    "expanded_bytes": total, "all_members_rehashed": True,
    "accepted_properties_or_witnesses": 0, "release_claim_eligible": False,
})
print(json.dumps({"members": len(digests), "expanded_bytes": total,
                  "archive_bytes": archive.stat().st_size, "archive_sha256": capture_sha}))
