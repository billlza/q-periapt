"""Also defer the five network-input sources, without changing the theory."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-08.spthy"
before = source.read_text()
after, count = re.subn(r"\bIn\([^()]*\)(?!\[)", lambda match: match.group(0) + "[no_precomp]", before)
sdk.require(count == 5, "unexpected network premise inventory")
original = (stage / "multi-epoch-01.spthy").read_text()
sdk.require(after.replace("[no_precomp]", "") == original.replace("[no_precomp]", ""), "theory changed")
output = stage / "multi-epoch-10.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-10", root)
sdk.write_json(stage / "ANNOTATIONS_10.json", {
    "source_sha256": sdk.snapshot(source).sha256,
    "annotated_sha256": sdk.snapshot(output).sha256,
    "additional_network_premises": count,
    "identical_to_original_after_removing_search_annotations": True,
    "proof_claim": False,
})
print("Five network-input annotations; unchanged theory and parser passed")
