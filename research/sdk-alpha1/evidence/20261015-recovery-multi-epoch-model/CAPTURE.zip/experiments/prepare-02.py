"""Record the source-grounded multi-round projection and validate its syntax."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
archive = root / "research/sdk-alpha1/evidence/20261015-recovery-shared-storage-positive/CAPTURE.zip"
sdk.require(sdk.snapshot(archive).sha256 == "9655446a492219424eee05614fd2b4589072e07c07293dc92323bbefb170c0be", "runner archive changed")
with zipfile.ZipFile(archive) as zipped:
    runner = zipped.read("experiments/run-01.py")
with (stage / "run-02.py").open("xb") as stream:
    stream.write(runner)
model = stage / "multi-epoch-01.spthy"
text = model.read_text()
prefix = text.split("\nlemma ", 1)[0]
sdk.require(re.findall(r"(?m)^restriction\s+(\w+):", prefix) == ["Equality"], "unexpected trace restriction")
sdk.require("succ(succ(" not in prefix and prefix.count("Fr(~old)") == 1, "bounded rounds or new roots per round")
sdk.require("Ready(s,r,epoch,next_parent,root,r)" in prefix and "Ready(s,p,epoch,next_parent,root,r)" in prefix, "root/parent inheritance or role alternation missing")
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(model), "--parse-only", "--quit-on-warning"], stage / "parse-02", root)
sources = ["research/continuity-identity-candidate/src/durable/messages/rekey.rs",
           "research/continuity-identity-candidate/src/durable/messages/rekey/response.rs",
           "research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs"]
sdk.write_json(stage / "PREPARED_02.json", {
    "base_commit": "436cdd49aab36003137b3df6ae8e93f1ec88eafd",
    "model_sha256": sdk.snapshot(model).sha256,
    "source_sha256": {name: sdk.snapshot(root / name).sha256 for name in sources},
    "parser_passed_with_quit_on_warning": True,
    "rounds_unbounded_in_operational_model": True,
    "only_initial_root_fresh_and_public": True,
    "later_roots_and_completed_transcript_parents_inherited": True,
    "permanent_device_roles_and_alternating_proposer_preserved": True,
    "next_offer_can_precede_peer_receipt_acceptance": True,
    "message_send_epoch_updates_before_proposer_confirmation": True,
    "closing_signature_send_fences_and_public_counts_modeled": True,
    "limitations": ["perfect primitives", "per-record rather than whole-image capture",
                    "unbounded successor counters abstract the finite integer limit",
                    "initial traffic omitted", "message keys abstract concrete chains and nonces",
                    "receive-chain/retirement/policy/witness/IO/crash refinement absent"],
    "all_queries_unproved": True, "release_claim_eligible": False,
})
print("Unbounded inherited-root model parsed; no theorem or witness admitted yet")
