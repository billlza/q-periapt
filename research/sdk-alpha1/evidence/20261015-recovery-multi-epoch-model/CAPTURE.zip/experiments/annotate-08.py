"""Exclude all honest protocol premise sources from eager precomputation."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-05.spthy"
text = source.read_text()
changes = []
def annotate(match):
    rule, body = match.groups()
    arrow = " --[" if " --[" in body else " -->"
    lhs, rhs = body.split(arrow, 1)
    def fact(found):
        if found.group(1) in {"Fr", "In"} or found.group(3):
            return found.group(0)
        changes.append({"rule": rule, "premise": found.group(0)})
        return found.group(0) + "[no_precomp]"
    prefix, premises = lhs.split("\n [ ", 1)
    premises = re.sub(r"!?\b(\w+)(\([^()]*\))(\[no_precomp\])?", fact, premises)
    lhs = prefix + "\n [ " + premises
    return "rule " + rule + ":" + lhs + arrow + rhs
after = re.sub(r"rule (\w+):([\s\S]*?)(?=\nrule |\nrestriction )", annotate, text)
original = (stage / "multi-epoch-01.spthy").read_text()
sdk.require(after.replace("[no_precomp]", "") == original.replace("[no_precomp]", ""), "rules or formulas changed")
sdk.require(changes and all(item["premise"].split("(",1)[0] not in {"Fr","In"} for item in changes), "invalid annotation")
output = stage / "multi-epoch-08.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-08", root)
sdk.write_json(stage / "ANNOTATIONS_08.json", {
    "source_sha256": sdk.snapshot(source).sha256, "annotated_sha256": sdk.snapshot(output).sha256,
    "changes": changes, "identical_to_original_after_removing_search_annotations": True,
    "only_honest_protocol_premises_annotated": True,
    "derivation_checks_unchanged": True, "proof_claim": False,
})
print(f"Annotated {len(changes)} further honest protocol premises; rule/query erasure and parser passed")
