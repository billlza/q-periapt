"""Prioritize the Ready premises that directly establish root inheritance."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-08.spthy"
before = source.read_text()
after, count = re.subn(r"(\bReady\([^()]*\))\[no_precomp\]", r"\1[+,no_precomp]", before)
sdk.require(count == 2, "unexpected Ready premise inventory")
erase = lambda text: text.replace("[+,no_precomp]", "").replace("[no_precomp]", "")
sdk.require(erase(after) == erase((stage / "multi-epoch-01.spthy").read_text()), "theory changed")
output = stage / "multi-epoch-13.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-13", root)
sdk.write_json(stage / "ANNOTATIONS_13.json", {
    "source_sha256": sdk.snapshot(source).sha256,
    "annotated_sha256": sdk.snapshot(output).sha256,
    "priority_premises": count,
    "identical_to_original_after_removing_search_annotations": True,
    "purpose": "Prefer Ready provenance over unrelated cryptographic input obligations for the structural inheritance lemma.",
    "proof_claim": False,
})
print("Two Ready premises prioritized; unchanged theory and parser passed")
