"""Add only premise search annotations; retain every original rule and query."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / "multi-epoch-01.spthy"
before = sdk.snapshot(source)
sdk.require(before.sha256 == "1be3e576722af22586edf62eff1cacb913b981e162f3942e133fac613aaf4977", "source changed")
text = before.data.decode()
changes = []
def annotate(match):
    rule = match.group(1)
    body = match.group(2)
    lhs, rhs = body.split(" --[", 1) if " --[" in body else body.split(" -->", 1)
    arrow = " --[" if " --[" in body else " -->"
    def fact(found):
        changes.append({"rule": rule, "premise": found.group(0)})
        return found.group(0) + "[no_precomp]"
    lhs = re.sub(r"\b(?:SendState|SendPermit)\([^()]*\)(?!\[)", fact, lhs)
    return "rule " + rule + ":" + lhs + arrow + rhs
after = re.sub(r"rule (\w+):([\s\S]*?)(?=\nrule |\nrestriction )", annotate, text)
sdk.require(len(changes) == 8, "unexpected premise count")
sdk.require(after.replace("[no_precomp]", "") == text.replace("[no_precomp]", ""), "operational model or query changed")
output = stage / "multi-epoch-05.spthy"
with output.open("x") as stream:
    stream.write(after)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "parse-05", root)
sdk.write_json(stage / "ANNOTATIONS_05.json", {
    "source_sha256": before.sha256, "annotated_sha256": sdk.snapshot(output).sha256,
    "changes": changes, "identical_after_removing_search_annotations": True,
    "manual_url": "https://tamarin-prover.com/manual/master/book/011_advanced-features.html#fact-annotations",
    "manual_interpretation": "Premise no_precomp excludes source precomputation and loop-breaker selection, without changing unification or rule semantics.",
    "proof_claim": False,
})
print("Only eight SendState/SendPermit premise annotations changed; parser passed")
