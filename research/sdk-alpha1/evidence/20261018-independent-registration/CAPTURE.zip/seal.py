"""Seal original registration evidence, exact executed sources and retained failures."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile,sys
root=Path.cwd();out=Path(__file__).resolve().parent;peer=root/'research/continuity-openssl-peer'
sys.path.insert(0,str(out))
from source_readback import normalized
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
sources=read('SOURCE_FILES.json');assert len(sources)==99
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE','LOCAL_RENEWAL','LOCAL_CREDENTIAL','PENDING','PUBLIC_INPUTS','REGISTRATION']
reports={n:read(n+'_READBACK.json')for n in labels}
for n,r in reports.items():
 if n!='REPLY_RELEASE':
  assert normalized(r['source_files'])==sources and r['native_sha256']==reports['REGISTRATION']['native_sha256']
assert reports['REGISTRATION']['source_files']==sources
runs=read('FINAL_RUNS.json');readers=read('READERS.json')
assert len(runs)==19 and all(r['exit']==0 for r in runs)
assert len(readers)==11 and all(r['exit']==0 for r in readers)
assert read('CLEANUP_FAULT_RED.json')['owner_still_operational_after_close_error'] is True
assert read('CLEANUP_FAULT_GREEN.json')['owner_still_operational_after_close_error'] is False
assert read('CLEANUP_FAULT_RED.json')['heads']==read('CLEANUP_FAULT_GREEN.json')['heads']
assert all(r['exit']==0 for r in read('QUALITY.json')['checks'])
assert not any((out/(r['output']+'.stderr')).read_bytes() for r in runs)
assert not (out/'review-local-credential.stderr').read_bytes()
assert not (out/'review-public-inputs.stderr').read_bytes()
entries={}
private_magic=(b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPRFLC01',b'QPRFLI01',b'QPREGS01',*(('QPREFS0'+str(i)).encode()for i in range(1,9)))
private_names={'head','intent','authority','configuration','signer','key','wrong-signer'}
def add(name,body):
 assert name not in entries and not body.startswith(private_magic),name
 entries[name]=body

def tree(name):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink()and p.name not in private_names and not p.name.startswith('.stage-'),str(p)
  add(name+'/'+str(p.relative_to(out/name)),p.read_bytes())
for row in runs:tree(row['output'])
for name in ['prototype-01','prototype-02','process-01','process-02','before','before-cleanup-fix']:tree(name)
for p in sorted(out.iterdir()):
 if p.is_file()and p.suffix in {'.py','.json','.txt','.stdout','.stderr'}:add(p.name,p.read_bytes())
for name,expected in sources.items():
 b=(peer/name).read_bytes();assert sha(b)==expected and b==(out/'source'/name).read_bytes();add('source/'+name,b)
for name in ['README.md','REGISTRATION.md']:add('source/'+name,(peer/name).read_bytes())
for name in ['counterpart','importer','native-before']:add(name,(out/name).read_bytes())
assert sha(entries['counterpart'])==reports['REGISTRATION']['native_sha256']
assert sha(entries['importer'])==reports['PUBLIC_INPUTS']['importer_sha256']
add('integration/independent-continuity.yml',(root/'.github/workflows/independent-continuity.yml').read_bytes())
add('SOURCE_DIFF.patch',subprocess.check_output(['git','diff','--','.github/workflows/independent-continuity.yml','research/continuity-openssl-peer']))
# Only public output trees are selected. Also reject the actual wrapping values
# from registration configurations if any appeared in a selected transcript.
keys=[]
for name,body in entries.items():
 if name.endswith('/private-fixture-path') and name.split('/')[0]in {'prototype-01','prototype-02','process-01','process-02','process-03'}:
  config=Path(body.decode().strip())/'configuration'
  if config.exists():
   value=config.read_bytes()
   if len(value)==2121:keys.append(value[:32])
for name,body in entries.items():assert not any(key in body for key in keys),name
scope={
 'base_head':'d6d434e5c928ef2d9c31c651cf2aeaa09e3de555',
 'change':'Protected original signing owner, native enrollment proof/issuance, separately pinned acceptance, retained public inputs and original child session. Existing session/renewal/pending-write recovery borrowed under parent lifetime. Parent revokes before cleanup; errors propagate.',
 'qualification':'19 entrypoints and 11 public readers; 99 sources,89 Python AST,726 Rust files. Registered process03: local42 workers/15 native commands/10 SIGKILL; witness50 workers/232 native commands/11 SIGKILL. Ten direct controls each. Exact enrollment request, original child IDs, rekey, G1, lost reservation, expiry and pending-write reconciliation. Shared source changes covered by18 existing lanes.',
 'source_cohorts':'The18 existing lanes ran before the2-file registration cleanup repair. Audited import closure shows those lanes do not invoke either changed module. Process03 runs the final99 source closure. Both actual cohorts, exact earlier bytes and audit are retained; older registration runs do not qualify the repair.',
 'failures':'Preserved mixed-target build01 E0308, Clippy02 argument-count failure, prototype01 wrong imported class plus original-state continuation, AST-caught file-helper extraction, process01 wrong epoch-ACK expectation plus read-only original-state verification, cleanup red/green on same private state, and copied reader01 numeric constant failure. No failed private state reset or silently replaced.',
 'native':'Actual b33c3197 ARM64 counterpart built release offline/locked and Clippied with -Dwarnings in isolated target. Policy verification factored without weakening. Test issuer uses real VerifiedEnrollmentRequest and issue_enrollment APIs; it is not a deployed authentication endpoint.',
 'limits':'One original pairwise child, local registration configuration outside session backups; no whole-configuration rollback guarantee. Python secret erasure/hostile-process isolation not promised. Private-image MAC/nonmutation and cleanup faults are runtime assertions; synthetic close fault runs real child cleanup before raising. Native traffic retains fixture170. Installed/deployed independent lifecycle, same-account/multidevice coordination, policy/witness/device/root replacement, resources/energy, retained-statePCS/refinement, final ABI/integration, user-owned external review and release remain open.'}
add('SCOPE.json',(json.dumps(scope,indent=2)+'\n').encode())
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};add('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode())
folder=root/'research/sdk-alpha1/evidence/20261018-independent-registration';folder.mkdir()
archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,body in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,body)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for name,item in manifest.items():assert len(z.read(name))==item['bytes']and sha(z.read(name))==item['sha256']
result={'readbacks':reports,'quality':read('QUALITY.json'),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':scope}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']),flush=True)
