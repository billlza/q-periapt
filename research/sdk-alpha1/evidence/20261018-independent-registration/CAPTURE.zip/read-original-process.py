from pathlib import Path
import hashlib,json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;folder=out/'process-01/local';sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from peer.registration import Registration
from peer.registration_protocol import Intent
from peer.wire import require
private=Path((folder/'private-fixture-path').read_text().strip());config=(private/'configuration').read_bytes();require(len(config)==2121,'original configuration')
before={name:hashlib.sha256((private/name/'head').read_bytes()).hexdigest()for name in ['enrollment','session']}
owner=Registration.open(private/'enrollment',config[32:64],config[:32],Intent.from_trusted(config[64:]))
try:
 status=owner.status();observed={}
 with owner.session(210)as child:
  for label,id_file,wire_file in [('original','original-id','original-reserved-resume'),('callback','callback-message-id','closed-callback-original-recovered')]:
   identity=bytes.fromhex(json.loads((folder/(id_file+'.stdout')).read_text())['result']);original=bytes.fromhex(json.loads((folder/(wire_file+'.stdout')).read_text())['result'])
   value=child.resume(identity,now=210);require(value==original,'original outbox after current-epoch ACK');observed[label]=hashlib.sha256(value).hexdigest()
 after={name:hashlib.sha256((private/name/'head').read_bytes()).hexdigest()for name in before};require(before==after,'read-only continuation changed original state')
 result={'phase':status['phase'],'signing_id':status['signing_id'].hex(),'journal':status['journal'].hex(),'heads':before,'outboxes':observed,'scope':'Original failed local profile reopened at210; both original epoch0 ciphertexts retained and neither head changed. Native endpoint already closed; no receiver restart/decryption claim.'}
 (out/'ORIGINAL_PROCESS_READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:owner.close()
