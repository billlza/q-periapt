from pathlib import Path
import hashlib,json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;folder=out/'process-02/local';sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from peer.registration import Registration
from peer.registration_protocol import Intent
from peer.wire import require
private=Path((folder/'private-fixture-path').read_text().strip());config=(private/'configuration').read_bytes()
before={name:hashlib.sha256((private/name/'head').read_bytes()).hexdigest()for name in ['enrollment','session']}
owner=Registration.open(private/'enrollment',config[32:64],config[:32],Intent.from_trusted(config[64:]));child=owner.session(210)
actual_close=child._owner.close
def fail_after_real_close():
 actual_close();raise OSError('injected error after real child cleanup')
child._owner.close=fail_after_real_close
try:
 try:owner.close()
 except OSError as error:require(str(error)=='injected error after real child cleanup','wrong cleanup fault')
 else:raise ValueError('cleanup error was hidden')
 live=False
 try:
  with owner.session(210)as reopened:reopened.next_id(now=210);live=True
 except ValueError as error:require('closed registration owner'in str(error),'wrong post-close refusal')
 after={name:hashlib.sha256((private/name/'head').read_bytes()).hexdigest()for name in before};require(after==before,'cleanup fault probe mutated stored state')
 result={'owner_still_operational_after_close_error':live,'private_heads_unchanged':True,'heads':before,
         'fault':'Real child close executed, then a test-injected OSError. This is not an observed operating-system fault.'}
 (out/'CLEANUP_FAULT_RED.json').write_text(json.dumps(result,indent=2)+'\n');require(not live,'registration remained operational after child cleanup error')
finally:owner.close()
