"""Keep current evidence and development failures in separate bounded Git assets."""
from pathlib import Path
import hashlib,json,zipfile
out=Path(__file__).resolve().parent;folder=Path.cwd()/'research/sdk-alpha1/evidence/20261018-independent-registration'
sha=lambda b:hashlib.sha256(b).hexdigest()
original=folder/'CAPTURE.zip';checks=json.loads((folder/'CHECKS.json').read_text())
assert sha(original.read_bytes())==checks['capture']['sha256']
entries={}
with zipfile.ZipFile(original)as z:
 manifest=json.loads(z.read('MANIFEST.json'))
 for name,item in manifest.items():
  data=z.read(name);assert len(data)==item['bytes']and sha(data)==item['sha256'];entries[name]=data
entries['split-capture.py']=Path(__file__).read_bytes()
def development(name):
 first=name.split('/')[0]
 return first.startswith(('prototype','process-01','process-02','before','reader-attempt-01','build-01','clippy-02','fmt-01'))or first=='native-before'
assets={}
for label,predicate in [('CAPTURE',lambda n:not development(n)),('DEVELOPMENT',development)]:
 selected={n:b for n,b in entries.items()if predicate(n)}
 manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(selected.items())}
 selected['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
 path=out/(label.lower()+'-split.zip')
 with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,body in sorted(selected.items()):
   item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,body)
 with zipfile.ZipFile(path)as z:
  assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(selected)
  for name,item in manifest.items():assert sha(z.read(name))==item['sha256']and len(z.read(name))==item['bytes']
 assert path.stat().st_size<50*1024**2
 assets[label]={'bytes':path.stat().st_size,'members':len(selected),'sha256':sha(path.read_bytes())}
original.rename(out/'aggregate-capture.zip');(folder/'CHECKS.json').rename(out/'AGGREGATE_CHECKS.json')
for label in assets:(out/(label.lower()+'-split.zip')).rename(folder/(label+'.zip'))
checks['aggregate_original']=checks['capture'];checks['capture']=assets['CAPTURE'];checks['development']=assets['DEVELOPMENT'];checks['partition']='All original manifest entries preserved exactly once across CAPTURE.zip and DEVELOPMENT.zip. The original aggregate remains locally retained. Readers and final runtime evidence are in CAPTURE; prior prototypes/formal attempts, older source bytes and their diagnostics are in DEVELOPMENT.'
(folder/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(assets))
