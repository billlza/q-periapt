from pathlib import Path
import json,sys,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;folder=out/'prototype-01/local';sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from peer.registration_protocol import Intent
from peer.registration import Registration
from peer.traffic import message_id
from peer.wire import require
from traffic_checks import application
private=Path((folder/'private-fixture-path').read_text().strip());config=(private/'configuration').read_bytes();require(len(config)==2121,'original private configuration')
key,identity,intent=config[:32],config[32:64],Intent.from_trusted(config[64:])
owner=Registration.open(private/'enrollment',identity,key,intent)
try:
 status=owner.status();require(status['phase']=='Active','original active registration retained')
 old_request=(folder/'registration-request.bin').read_bytes();signed_id,public=intent.verify_request(old_request,150)
 require(status['signing_id']==signed_id and status['public_key']==public.raw,'original identity after failure')
 directory=folder/'native/public';operation=(directory/'local-renewal-1-operation').read_bytes()
 before=hashlib.sha256((private/'session/head').read_bytes()).hexdigest()
 with owner.credential_renewal(operation,210)as renewal:
  renewal.stage((directory/'local-renewal-1').read_bytes(),(directory/'pin-local-renewal-1-target').read_bytes(),now=210)
  result=renewal.commit(now=210);require(result['status']=='Committed','original registered local renewal')
 sid=(folder/'native/cases/complete.output').read_bytes()[1:];mid=message_id(sid,1,0,0)
 with owner.session(210)as child:
  replay=child.resume(mid,now=210)
  require(application(b'enrolled',replay)==(folder/'native/cases/receive.input').read_bytes(),'original ciphertext after renewal')
 report={'status':result,'signing_id':signed_id.hex(),'public_sha256':hashlib.sha256(public.raw).hexdigest(),'session':sid.hex(),'original_message':mid.hex(),'original_ciphertext_sha256':hashlib.sha256(replay).hexdigest(),'before_head_sha256':before,'after_head_sha256':hashlib.sha256((private/'session/head').read_bytes()).hexdigest(),'scope':'Original failed encrypted enrollment and child continued, no reset or key replacement. Original native endpoint already terminated; no native restart or fresh native decryption claim.'}
 (out/'ORIGINAL_CONTINUATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
finally:owner.close()
