"""Exact executed bytes plus an audited non-invoked registration-only repair."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
PEER=Path.cwd()/'research/continuity-openssl-peer'
EXPECTED=json.loads((OUT/'SOURCE_FILES.json').read_text())
AUDIT=json.loads((OUT/'CLEANUP_REPAIR.json').read_text())
def source_bytes(name,expected):
 current=(PEER/name).read_bytes()
 if hashlib.sha256(current).hexdigest()!=EXPECTED.get(name) or (OUT/'source'/name).read_bytes()!=current:
  raise ValueError('changed final source: '+name)
 if expected==EXPECTED[name]:return current
 change=AUDIT['files'].get(name)
 if change is None or expected!=change['before'] or EXPECTED[name]!=change['after']:
  raise ValueError('unqualified source difference: '+name)
 original=(OUT/'before-cleanup-fix'/name).read_bytes()
 if hashlib.sha256(original).hexdigest()!=expected:raise ValueError('changed executed original: '+name)
 return original
def normalized(sources):
 if set(sources)!=set(EXPECTED):raise ValueError('different source inventory')
 for name,expected in sources.items():source_bytes(name,expected)
 return EXPECTED
def continuity(sources):
 normalized(sources)
 return {'executed_source_files':sources,'current_source_files':EXPECTED,
         'registration_only_changes':{n:AUDIT['files'][n]for n in sources if sources[n]!=EXPECTED[n]},
         'applicability':'The18 entrypoints listed in IMPORT_ISOLATION.json do not import the two changed modules. Registered-owner qualification uses final sources. This is not a claim that older registration executions exercised the repair.'}
