from pathlib import Path
import hashlib,json,os,sys,tempfile,time
root=Path.cwd();out=Path(__file__).resolve().parent/'prototype-02';out.mkdir()
sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from run import Counterpart
from fixture_inputs import load,load_witness_pin
from witness_fixture import Bridge
from peer.registration_protocol import Intent
from peer.registration_inputs import Inputs
from peer.registration import Registration
from peer.witness import TcpTransport
from peer.wire import require
from traffic_checks import application
native_path=root/'target/independent-registration-01/native-target/release/q-periapt-independent-peer-counterpart'
for label in ['local','witness']:
 folder=out/label;folder.mkdir();(folder/'native').mkdir();native=Counterpart(native_path,folder/'native',local_lifecycle=True,required_witness=label=='witness',registration=True)
 bridge=None;owner=None
 try:
  deadline=time.monotonic()+30;size=int.from_bytes(native.read(4,deadline),'big');require(size==2058,'native independent intent size');prelude=native.read(size,deadline);require(prelude[0]==1,'native intent status')
  intent=Intent.from_trusted(prelude[1:]);(folder/'registration-trust.bin').write_bytes(prelude[1:])
  private=Path(tempfile.mkdtemp(prefix='qperiapt-registration-')).resolve();private.chmod(0o700)
  (folder/'private-fixture-path').write_text(str(private)+'\n')
  configuration=private/'enrollment';configuration.mkdir(mode=0o700);session=private/'session';session.mkdir(mode=0o700)
  key=os.urandom(32);identity=os.urandom(32)
  config=private/'configuration';config.write_bytes(key+identity+intent.wire());config.chmod(0o600)
  owner=Registration.provision(configuration,identity,key,intent);request=owner.request(150);status=owner.status();owner.close()
  owner=Registration.open(configuration,identity,key,intent);require(owner.request(150)==request,'same original registration request')
  (folder/'registration-request.bin').write_bytes(request)
  require(native.transfer(request)==b'\1ready','actual native registration acceptance')
  public=folder/'native/public';pin=load_witness_pin(public)if label=='witness'else None
  pins,materials,context=load(public,150,witness_pin=pin)
  future=owner.accept(materials.initiator_credential,materials.initiator_roster,pins.initiator,pins,materials,150,witness_pin=pin)
  require(owner.accept(materials.initiator_credential,materials.initiator_roster,pins.initiator,pins,materials,150,witness_pin=pin)==future,'original accepted journal')
  genesis=owner.prepare(session,Inputs(pins,materials,pin),150)
  require(owner.prepare(session,Inputs(pins,materials,pin),150)==genesis,'same original prepared child')
  transport=None
  if pin is not None:
   bridge=Bridge(native,folder);bridge.call('enroll-original',30,genesis,b'enrolled');transport=TcpTransport(bridge.address)
  def call(name,command,data=b'',expected=None):return bridge.call(name,command,data,expected)if bridge else native.command(name,command,data,1,expected)
  with owner.session(150,transport=transport)as child:
   initial=child.initial(now=150);reply=call('reply',4,initial);final=child.finish(reply,now=150);sid=call('complete',5,final);require(child.activate(now=170)==sid,'same original session');call('native-activate',6,b'',sid)
   mid=child.next_id(now=170);wire=child.send(mid,b'original enrolled message',b'enrolled',now=170);call('receive',7,application(b'enrolled',wire),b'original enrolled message')
  owner.close();owner=Registration.open(configuration,identity,key,intent)
  with owner.session(170,transport=transport)as child:
   require(child.resume(mid,now=170)==wire,'original enrolled outbox')
   offer=child.prepare_rekey_offer(now=170);response=call('response',14,offer);final=child.accept_rekey_response(response,now=170);receipt=call('receipt',15,final);require(child.accept_rekey_receipt(receipt,now=170)==1,'owned same-session rekey')
  if bridge:bridge.call('clock',33,(210).to_bytes(8,'big'),b'witness clock set')
  operation=(public/'local-renewal-1-operation').read_bytes();grant=(public/'local-renewal-1').read_bytes();target=(public/'pin-local-renewal-1-target').read_bytes()
  with owner.credential_renewal(operation,210,transport=transport)as renewal:
   if pin is None:renewal.stage(grant,target,now=210);require(renewal.commit(now=210)['status']=='Committed','registered local renewal')
   else:
    proposal=renewal.prepare(grant,target,now=210);call('independent-renewal',34,proposal,b'Prepared');require(renewal.commit(now=210)=='Applied','registered joint renewal')
  with owner.session(210,transport=transport)as child:
   require(child.resume(mid,now=210)==wire,'registered original outbox after expiry/renewal')
   owner.close()
   try:child.next_id(now=210)
   except ValueError as e:require('closed registration'in str(e),'stale registered owner')
   else:raise ValueError('registration close did not revoke child')
  result={'signing_id':status['signing_id'].hex(),'public_sha256':hashlib.sha256(status['public_key']).hexdigest(),'request_sha256':hashlib.sha256(request).hexdigest(),'journal':future.hex(),'session':sid.hex(),'original_ciphertext_sha256':hashlib.sha256(wire).hexdigest(),'native_commands':native.commands}
  (folder/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(label,'pass',flush=True)
 finally:
  if owner:owner.close()
  if bridge:bridge.close()
  native.close()
