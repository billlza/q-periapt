use socket2::SockRef;
use std::{io::{self, Read}, net::{TcpListener, TcpStream}, thread, time::{Duration, Instant}};

fn main() -> io::Result<()> {
    let listener = TcpListener::bind("127.0.0.1:0")?;
    listener.set_nonblocking(true)?;
    let client = TcpStream::connect(listener.local_addr()?)?;
    let (mut accepted, _) = listener.accept()?;
    let inherited = SockRef::from(&accepted).nonblocking()?;
    accepted.set_read_timeout(Some(Duration::from_secs(1)))?;
    let at = Instant::now();
    let old = accepted.read(&mut [0; 1]);
    println!("inherited_nonblocking={inherited}; read_with_timeout_only={old:?}; elapsed={:?}", at.elapsed());
    assert!(inherited, "this diagnostic is specific to observed Darwin inheritance");
    assert_eq!(old.expect_err("open silent peer cannot produce EOF").kind(), io::ErrorKind::WouldBlock);
    assert!(at.elapsed() < Duration::from_millis(500));
    accepted.set_nonblocking(false)?;
    assert!(!SockRef::from(&accepted).nonblocking()?);
    let closer = thread::spawn(move || { thread::sleep(Duration::from_millis(100)); drop(client); });
    let at = Instant::now();
    let after = accepted.read(&mut [0; 1])?;
    closer.join().map_err(|_| io::Error::other("closer panicked"))?;
    println!("explicit_blocking_read={after}; elapsed={:?}", at.elapsed());
    assert_eq!(after, 0, "no application data may escape");
    assert!(at.elapsed() >= Duration::from_millis(100) && at.elapsed() < Duration::from_secs(1));
    Ok(())
}
