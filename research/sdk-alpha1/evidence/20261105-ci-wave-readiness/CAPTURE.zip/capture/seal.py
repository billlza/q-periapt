from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-wave-readiness'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-wave-readiness'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
obj = lambda name: json.loads((BASE / name).read_bytes())
current = obj('CURRENT_HEAD_TERMINAL.json')
jobs = {j['id']: (r['run_id'], j) for r in current['results'] for j in r['jobs']}
assert len(current['results']) == 12 and len(jobs) == 336
assert all(j['status'] == 'completed' for _, j in jobs.values())
assert current['counts'] == {'success': 298, 'failure': 35, 'skipped': 2, 'cancelled': 1}
last = obj('LAST_CURRENT_HEAD_RUN.json')
assert last['id'] == 41791519877 and last['status'] == 'completed' and last['conclusion'] == 'failure'
historical = obj('HISTORICAL_RUN_JOBS_0905.json')
live = []
for run in historical['runs']:
    assert run['total_count'] == len(run['jobs'])
    live.extend({'run_id': run['run_id'], 'job_id': j['id'], 'name': j['name'],
                 'status': j['status'], 'runner_id': j['runner_id'], 'started_at': j['started_at']}
                for j in run['jobs'] if j['status'] != 'completed')
assert {j['job_id'] for j in live} == {126266162426, 126266162501, 126268252580}
assert all(j['status'] == 'in_progress' and j['runner_id'] > 0 for j in live)
annotations = obj('cancelled-annotations.json')
assert len(annotations) == 1 and annotations[0]['annotation_level'] == 'failure'
assert annotations[0]['message'] == 'The job has exceeded the maximum execution time while awaiting a runner for 24h0m0s'
plan = obj('NEXT_WAVE_PREPARATION.json'); dry = obj('DRY_RUN_OBSERVATION.json')
assert not plan['ready_to_push'] and not plan['remote_mutation_performed'] and not plan['force_push_allowed']
assert dry['exit_code'] == 0 and '--dry-run' in dry['argv'] and '--atomic' in dry['argv']
assert not any(arg.startswith('--force') for arg in dry['argv'])
for row in plan['planned_atomic_refs']:
    assert row['candidate'] + ':refs/heads/' + row['branch'] in dry['argv']
    observed = next(p for p in plan['remote_pr_observations'] if p['head_sha'] == row['expected'])
    assert observed['state'] == 'open'
p0_ids = [126456506096, 126449258020, 126449258037, 126456506122]
records = {}
for job_id in p0_ids:
    run_id, job = jobs[job_id]
    assert job['conclusion'] == 'failure'
    text = (BASE / f'job-{job_id}.log').read_text()
    match = re.search(r'git log -1 --format=%H\n\S+Z ([0-9a-f]{40})\s*\n', text); assert match
    commit = match[1]
    assert commit == ('9aa535b48b464ec4d4a8b5a4b20221049a6067b9' if run_id == 41791519877 else '475cd23923e45819b01b6041c91c44540ec056ec')
    assert 'report["witness_exchanges"] == 142' in text and 'ValueError: OpenSSL server exchange census differs' in text
    assert 'result["c_consumer"] = qualify_c(' in text
    artifacts = re.findall(r'Artifact (.+?) has been successfully uploaded! Final size is ([0-9]+) bytes\. Artifact ID is ([0-9]+)', text)
    digests = re.findall(r'SHA256 digest of uploaded artifact is ([0-9a-f]{64})', text)
    assert len(artifacts) == len(digests) == 1
    name, size, identifier = artifacts[0]
    records[str(job_id)] = {'run_id': run_id, 'name': job['name'], 'actual_checkout': commit,
        'classification': 'Old exact 142 C/OpenSSL prerequisite', 'foreign_consumer_execution_established': False,
        'hosted_numeric_server_count_disclosed': False,
        'reported_artifact': {'id': int(identifier), 'name': name, 'bytes': int(size), 'sha256': digests[0]},
        'artifact_downloaded_locally': False}
validators = [(BASE / ('continuity_profiles-' + short + '.py')).read_bytes() for short in ['475cd239', '9aa535b4']]
assert validators[0] == validators[1]
source = validators[0].decode()
assert 'PROFILES = ("debug", "release")' in source
assert source.index('"swift":') < source.index('"kotlin":') < source.index('"android":')
joins = {}
expected = {f'continuity-installed-{consumer}-{profile}' for consumer in ['swift', 'kotlin', 'android'] for profile in ['debug', 'release']}
for job_id, count, error in [(127122411070, 6, 'partition is unfinished or makes a complete-package claim'),
                              (127146720219, 5, 'installed consumer partition set is missing, duplicated, or unexpected')]:
    run_id, job = jobs[job_id]; assert job['conclusion'] == 'failure'
    text = (BASE / f'job-{job_id}.log').read_text()
    listed = re.findall(r'^\S+Z - (continuity-installed-[^ ]+) \(ID: (\d+), Size: (\d+), Expected Digest: sha256:([0-9a-f]{64})\)$', text, re.M)
    assert len(listed) == count and f'Total of {count} artifact(s) downloaded' in text
    assert 'ValueError: ' + error in text
    names = {row[0] for row in listed}
    assert names == (expected if count == 6 else expected - {'continuity-installed-kotlin-release'})
    assert not any(step['conclusion'] == 'success' and 'upload-artifact' in step['name'] for step in job['steps'])
    joins[str(job_id)] = {'run_id': run_id, 'error': error, 'reported_downloads': count,
        'downloaded_artifact_names': sorted(names), 'missing_named_artifacts': sorted(expected - names),
        'output_upload_succeeded': False,
        'first_input_inferred_from_pinned_iteration_order': 'swift/debug' if count == 6 else None,
        'specific_failed_compound_conjunct_established': False}
classification = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'current_head_observed_at': current['observed_at'], 'current_head_run_count': 12,
    'current_head_jobs': len(jobs), 'current_head_counts': current['counts'], 'current_head_jobs_all_terminal': True,
    'observed_p0_failure_count': 27, 'later_p0_jobs': records, 'later_coverage_joins': joins,
    'coverage_validator_sha256': sha(validators[0]),
    'cancelled_job_cause_followup': {'job_id': 126456506355,
        'previous_capture': '20261105-ci-queued-cancellation-readback',
        'read_transport': 'Existing authenticated GitHub CLI, GET only; connector check-run endpoint was unsupported',
        'annotation': annotations[0]['message'], 'annotation_sha256': sha((BASE / 'cancelled-annotations.json').read_bytes()),
        'queue_wait_limit_established': True, 'consumer_execution_established': False,
        'claimed_consumption_of_330_minute_runtime_budget': False},
    'historical_queue_observed_at': historical['observed_utc'], 'historical_runs_checked': [r['run_id'] for r in historical['runs']],
    'older_same_branch_jobs_still_running': live,
    'scope': 'Current-head terminal qualification results and older same-branch queue occupancy are separate. Older metadata is not substituted for current-source qualification.',
    'dry_run_passed': True, 'dry_run_receipt_kind': dry['kind'], 'planned_atomic_refs': plan['planned_atomic_refs'],
    'effective_queue_ready_for_next_wave': False, 'remote_push_performed': False,
    'rerun_performed': False, 'cancellation_performed': False, 'release_claim_eligible': False}
files = {'capture/' + p.name: p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
