import sys,os,subprocess
from environment import ROOT,STAGE,TOOLCHAIN,environment
sys.path.insert(0,str(ROOT/'artifact'))
import wasm_sdk_package
os.environ.update(environment())
subprocess.run([str(TOOLCHAIN/'lib/rustlib/aarch64-apple-darwin/bin/rust-lld'),'-flavor','wasm','--version'],check=True)
wasm_sdk_package.build(STAGE/'package')
print('Current source installed WASM package completed',flush=True)
