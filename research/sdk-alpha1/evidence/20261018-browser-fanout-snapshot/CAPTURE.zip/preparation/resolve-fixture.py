import hashlib,json,subprocess,sys
from environment import ROOT,STAGE,environment
sys.path.insert(0,str(ROOT/'artifact'))
from installed_rust_graph import external_lock
work=STAGE/'group-fixture';original=(work/'Cargo.lock').read_bytes()
(STAGE/'fixture-original-Cargo.lock').write_bytes(original)
args=['cargo','metadata','--offline','--format-version','1']
with (STAGE/'fixture-metadata.stdout').open('xb') as stdout,(STAGE/'fixture-metadata.stderr').open('xb') as stderr:
 proc=subprocess.run(args,cwd=work,env=environment(),stdout=stdout,stderr=stderr,timeout=120,check=False)
assert proc.returncode==0
old=external_lock(original);new=external_lock((work/'Cargo.lock').read_bytes())
root=external_lock((ROOT/'Cargo.lock').read_bytes());candidate=external_lock((ROOT/'research/continuity-identity-candidate/Cargo.lock').read_bytes())
unknown={k:v for k,v in new.items() if root.get(k)!=v and candidate.get(k)!=v}
assert not unknown,unknown
report={'previous_external_packages':len(old),'current_external_packages':len(new),'removed':sorted(str(k) for k in old.keys()-new.keys()),'added':sorted(str(k) for k in new.keys()-old.keys()),'changed_common':sorted(str(k) for k in old.keys()&new.keys() if old[k]!=new[k]),'all_current_external_entries_match_current_root_or_candidate_lock':True,'lock_sha256':hashlib.sha256((work/'Cargo.lock').read_bytes()).hexdigest()}
(STAGE/'FIXTURE_LOCK_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
