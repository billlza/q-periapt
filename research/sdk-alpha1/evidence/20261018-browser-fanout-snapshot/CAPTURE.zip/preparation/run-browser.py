import json,os,runpy,sys
from pathlib import Path
from environment import ROOT,STAGE,environment
sys.path.insert(0,str(ROOT/'artifact'))
import wasm_sdk_package as package
os.environ.update(environment())
for key in ('NODE_OPTIONS','NODE_PATH'):os.environ.pop(key,None)
assert json.loads((STAGE/'consume-02/INSTALLED_CONSUMER.json').read_text())['installed_node_tests']=='passed'
assert json.loads((STAGE/'FIXTURE_BUILD.json').read_text())['source_head']=='ca7e13fac927218e20b231804c1e93054117edfa'
meta=json.loads(Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/package.json').read_text())
assert meta['name']=='@playwright/cli' and meta['version']=='0.1.22'
sys.argv=[str(STAGE/'run-current.py'),'run01','local','required','effect','worker-cut']
runpy.run_path(str(STAGE/'run-current.py'),run_name='__main__')
