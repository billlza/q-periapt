from pathlib import Path
import hashlib,json,re,sys
from environment import ROOT,STAGE
sys.path.insert(0,str(ROOT/'artifact'))
from evidence_io import parse_strict_json_bytes as parsed
import wasm_sdk_package as package
from c_package_manifest import rust_workspace_source_digest
out=STAGE/'output/playwright/run01'; logs=out/'logs'
state=parsed((out/'RESULT.json').read_bytes(),label='browser result')
assert state['completed'] and state['producer_unchanged'] and state['startup_console_clean']
assert not state['release_claim_eligible']
assert [row['case'] for row in state['cases']]==['local','required','effect','worker-cut']
assert all(row['completed'] and len(row['calls'])==53 for row in state['cases'])
flat=[call for row in state['cases'] for call in row['calls']]
assert len(flat)==212
for index,call in enumerate(flat,1):
 prefix=logs/f'step-{index:03}'
 assert not prefix.with_suffix('.stderr').read_bytes()
 command=parsed(prefix.with_suffix('.json').read_bytes(),label='browser command')
 assert command['returncode']==0 and command['argv']==['run-code','--filename',str(prefix.with_suffix('.js'))]
 script=prefix.with_suffix('.js').read_text()
 split='globalThis.invoke(args), ';end='); return {result, diagnostics:'
 assert script.count(split)==script.count(end)==1
 args=parsed(script.split(split)[1].split(end)[0].encode(),label='browser arguments')
 assert args['action']==call['action'] and args['case']=='run01-'+state['cases'][(index-1)//53]['case']
 raw=prefix.with_suffix('.stdout').read_text()
 assert raw.count('### Result\n')==1 and '### Error' not in raw
 value=parsed(raw.split('### Result\n')[1].split('\n### ')[0].encode(),label='browser public response')
 assert value['diagnostics']==[] and value['result']==call['result']
for path,digest in state['producer'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
for name,digest in state['static_web'].items():assert hashlib.sha256((out.with_name('run01-web')/name).read_bytes()).hexdigest()==digest,name
installed=parsed((STAGE/'consume-02/INSTALLED_CONSUMER.json').read_bytes(),label='installed consumer')
manifest=package.verify(Path(installed['installed']),installed['manifest_sha256'])
package.validate_consumer_source(manifest)
assert installed['browser_runtime']=='not-run' and installed['source_bound'] and installed['sources_unchanged']
assert hashlib.sha256(Path(installed['archive']).read_bytes()).hexdigest()==installed['sha256']
fixture=parsed((STAGE/'FIXTURE_BUILD.json').read_bytes(),label='native fixture')
assert fixture['source_digest']==rust_workspace_source_digest(ROOT)
for name,digest in fixture['binaries'].items():assert hashlib.sha256((STAGE/'group-target/debug'/('qpc-fanout-'+name)).read_bytes()).hexdigest()==digest
identities=parsed((out/'BROWSER_PROCESS.json').read_bytes(),label='browser process')
assert hashlib.sha256(Path(identities['executable']).read_bytes()).hexdigest()==identities['executable_sha256']
peer_count=witness_count=0
for case,records in state['peer_records'].items():
 for row in records:
  path=out/'peer'/case/f"{row['number']:03}"
  assert parsed((path/'RECORD.json').read_bytes(),label='peer record')==row
  request=(path/'request.bin').read_bytes();assert hashlib.sha256(request).hexdigest()==row['request_sha256'] and request[:8]==b'QPCXCH01' and request[8]==row['kind']
  if row['returncode']==0:
   assert hashlib.sha256((path/'reply.bin').read_bytes()).hexdigest()==row['reply_sha256']
  else:assert case=='run01-effect' and row['application_unconfirmed'] and row['trigger'] and row['mode']=='after-effect'
  peer_count+=1
for case,records in state['witness_records'].items():
 for row in records:
  prefix=out/'witness'/case/f"{row['number']:03}"
  request=prefix.with_suffix('.request').read_bytes();reply=prefix.with_suffix('.reply').read_bytes()
  assert len(request)==3674 and len(reply)==3659
  assert hashlib.sha256(request).hexdigest()==row['request_sha256'] and hashlib.sha256(reply).hexdigest()==row['reply_sha256']
  witness_count+=1
assert set(state['peer_records'])=={'run01-'+c for c in ('local','required','effect','worker-cut')}
assert set(state['witness_records'])=={'run01-'+c for c in ('required','effect','worker-cut')}
effects=[]
for row in state['cases']:
 assert row['effect_before']==row['effect_after'] and row['sessions'][0]!=row['sessions'][1]
 for slot in (0,1):
  directory=STAGE/'run01-private'/('run01-'+row['case'])/'recipients'/str(slot)/'peer/effects'
  files=list(directory.iterdir());assert len(files)==1
  content=files[0].read_bytes();assert content==bytes(row['sessions'][slot])+bytes(row['original_messages'][slot])+b'all account devices'
  stat=files[0].stat()
  if slot==0:assert [stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]==row['effect_before']
  effects.append({'case':row['case'],'slot':slot,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
assert parsed((logs/'close.json').read_bytes(),label='owned browser close')['returncode']==0
report={'source_head':'ca7e13fac927218e20b231804c1e93054117edfa','completed':True,'cases':4,'browser_invocations':212,'browser_version':identities['version'],'archive_sha256':installed['sha256'],'manifest_sha256':installed['manifest_sha256'],'native_peer_records':peer_count,'witness_records':witness_count,'effects':effects,'source_and_producer_unchanged':True,'scope':'Actual installed browser package and current native fixtures on one macOS host; two-recipient original account delivery, exact retry, application failure, real Worker termination and original aggregate retirement. Same protocol implementation. No browser allocation/latency/energy, reserve/commit cut census, independent implementation, other OS or release qualification.'}
with (STAGE/'BROWSER_REVIEW.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='effects'}))
