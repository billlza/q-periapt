from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[2]
STAGE=Path(__file__).resolve().parent
TOOLCHAIN=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
TOOLS=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/browser-policy-tools')
def environment():
 env=dict(os.environ)
 env.update(PATH=':'.join([str(TOOLCHAIN/'bin'),str(TOOLS/'node_modules/.bin'),str(TOOLS/'wasm-bindgen/bin'),'/opt/homebrew/bin','/Users/bill/.cargo/bin',env['PATH']]),RUSTUP_HOME=str(TOOLCHAIN.parents[1]),RUSTUP_TOOLCHAIN='1.98.1-aarch64-apple-darwin',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang',DYLD_FALLBACK_LIBRARY_PATH=str(TOOLCHAIN/'lib'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never')
 return env
