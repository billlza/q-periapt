globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', { type: 'module' });
  let stopped = false;
  const finish = (error, result) => {
    if (stopped) return;
    stopped = true; clearTimeout(timer); worker.terminate();
    if (error) reject(error); else resolve(result);
  };
  const timer = setTimeout(() => finish(Error('joint worker deadline')), 45000);
  worker.onerror = event => finish(Error(event.message));
  worker.onmessage = async ({ data }) => {
    try {
      if (data.ready) {
        worker.postMessage(args);
        if (args.killAfterPeerResult) {
          while (!stopped) {
            const response = await fetch('/peer-status/' + args.case, { credentials: 'omit', cache: 'no-store' });
            if (!response.ok) throw Error('witness observation failed');
            const records = await response.json();
            if (records.some(row => row.trigger && row.kind === 3 && row.slot === args.selected && row.returncode === 0)) {
              finish(undefined, { done: true, workerTerminatedAfterPeerResult: true }); break;
            }
            await new Promise(resolve => setTimeout(resolve, 20));
          }
        }
      } else if (data.done) {
        if (data.value?.request) {
          const response = await fetch('/capture/' + args.case + '.bin', { method: 'POST', body: new Uint8Array(data.value.request) });
          if (!response.ok) throw Error('enrollment capture failed');
          delete data.value.request;
        }
        if (data.value?.phase === 'requires-witness-enrollment') {
          const response = await fetch('/capture/' + args.case + '-genesis.json', { method: 'POST', body: JSON.stringify(data.value) });
          if (!response.ok) throw Error('genesis capture failed');
        }
        finish(undefined, data);
      }
    } catch (error) { finish(error); }
  };
});
