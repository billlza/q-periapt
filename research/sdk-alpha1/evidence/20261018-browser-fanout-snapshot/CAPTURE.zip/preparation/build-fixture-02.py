from pathlib import Path
import json,hashlib,re,subprocess,time,sys
from environment import ROOT,STAGE,environment
sys.path.insert(0,str(ROOT/'artifact'))
from c_package_manifest import rust_workspace_source_digest
work=STAGE/'group-fixture';env=environment();target=STAGE/'group-target'
inputs={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
source=rust_workspace_source_digest(ROOT)
args=['cargo','build','--locked','--offline','--bins','--target-dir',str(target),'-j','2']
start=time.monotonic()
with (STAGE/'fixture-build-02.stdout').open('xb') as stdout,(STAGE/'fixture-build-02.stderr').open('xb') as stderr:
 proc=subprocess.run(args,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=900,check=False)
(STAGE/'FIXTURE_COMMAND_02.json').write_text(json.dumps({'argv':args,'cwd':str(work),'returncode':proc.returncode,'seconds':time.monotonic()-start,'source_digest':source,'inputs':inputs},indent=2)+'\n')
assert proc.returncode==0
assert not re.search(r'(?mi)^\s*(warning:|error:)',(STAGE/'fixture-build-02.stdout').read_text()+(STAGE/'fixture-build-02.stderr').read_text())
assert rust_workspace_source_digest(ROOT)==source
for name,digest in inputs.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest
binaries={name:hashlib.sha256((target/'debug'/('qpc-fanout-'+name)).read_bytes()).hexdigest() for name in ('seed','peer','witness')}
(STAGE/'FIXTURE_BUILD.json').write_text(json.dumps({'source_head':'ca7e13fac927218e20b231804c1e93054117edfa','source_digest':source,'binaries':binaries,'inputs_unchanged':True},indent=2)+'\n')
print('Current-source complete-account native fixtures built',flush=True)
