from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server_timed import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'local', 'required', 'effect', 'worker-cut'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-fanout-package-02'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for source, name in (('worker-timed.js','worker.js'), ('controller.js','controller.js')): shutil.copyfile(stage / source, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Complete account delivery</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
browser_session = 'qpc-fanout-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage / ('group-target/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker-timed.js', stage / 'controller.js', stage / 'server_timed.py']}
state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Installed browser complete-account fanout to two native receivers, one independently signed three-device roster and one witness authority; same shared implementation on one host', 'cases': []}
sequence = 0

def browser(args, name):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', browser_session, *args], timeout_seconds=80,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

def assert_status(value, issued, phase):
    status = value['status']
    sdk.require(status['phase'] == phase and status['operation'] == issued['operation'] and status['statement'] == issued['transaction'], 'wrong joint status')

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="fanout_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("fanout_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            console = browser(['console', 'warning'], 'startup-console').decode()
            sdk.require(console == '### Result\nTotal messages: 0 (Errors: 0, Warnings: 0)\n\n', 'startup console error')
            state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case':case, 'calls':[], 'completed':False}; state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare',directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text()); cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json',inputs / (key + '.json'))
                args = {'case':key,'name':key+'-'+uuid.uuid4().hex[:8], 'id':uuid.uuid4().hex+uuid.uuid4().hex, 'profile':profile}
                success(dict(args,action='create'))
                grant_path = inputs / (key + '-grant.json')
                trace = output / (case + '-native-prepare'); trace.mkdir(mode=0o700)
                native('peer',['prepare-group',directory,output/'captures'/(key+'.bin'),grant_path,inputs,trace],case+'-group-prepare')
                grant = json.loads(grant_path.read_text())
                for slot in range(2):
                    peer = json.loads((inputs / (key + f'-peer-{slot}.json')).read_text())
                    sdk.require(peer['account'] == cfg['account'] and peer['root'] == cfg['root'] and peer['roster'] == grant['roster'] and peer['digest'] == grant['digest'], 'independent group roster mismatch')
                accepted = success(dict(args,action='accept')); prepared = success(dict(args,action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness',['enroll',directory,grant_path,output/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
                active = success(dict(args,action='activate')); sdk.require(active['journal'] == prepared['journal'], 'activation identity')
                row['journal'] = active['journal']
                sessions = []
                for slot in range(2):
                    established = success(dict(args,action='establish',slot=slot,requestId=list(os.urandom(32))))
                    sdk.require(established['journal'] == row['journal'], 'per-peer owner replaced original journal')
                    sessions.append(established['session'])
                    sdk.write_json(directory/'recipients'/str(slot)/'peer/session.json',established['session'])
                sdk.require(sessions[0] != sessions[1], 'different members share a session')
                args['sessions'] = sessions; row['sessions'] = sessions
                operation = success(dict(args,action='account-next'))['operation']; args['operation'] = operation; row['operation'] = operation
                original_slots = success(dict(args,action='session-slots'))['messages']; row['original_messages'] = original_slots
                before = len(peers.get(key,[]))
                negatives = [('omitted',{'targetSlots':[0]},'PolicyDenied',True),
                    ('duplicate',{'targetSlots':[0,0]},'Scope',False),
                    ('empty',{'targetSlots':[]},'Capacity',True),
                    ('selection',{'selected':2},'Scope',True),
                    ('closed-input',{'closeInput':True},'Closed',False),
                    ('closed-policy',{'closePolicy':True},'Closed',True)]
                negatives.extend((name, {'invalidIndex':name}, 'InvalidInput', False)
                    for name in ('negative','fraction','nan','infinity','string','boolean','null','undefined','wrapped','unsafe'))
                for name, extra, code, closed in negatives:
                    selected = dict(args,action='account-deliver',selected=0); selected.update(extra)
                    result = invoke(selected)
                    sdk.require(result.get('code') == code and result.get('ownerClosed') is closed, 'wrong refusal: '+name+' '+json.dumps(result))
                    current = success(dict(args,action='account-status'))['status']
                    sdk.require(current['phase'] == 0 and current['operation'] == operation, 'invalid input reserved aggregate')
                sdk.require(len(peers.get(key,[])) == before, 'invalid input dispatched peer data')
                sdk.require(success(dict(args,action='session-slots'))['messages'] == original_slots, 'invalid target set consumed a slot')
                mode = 'after-effect' if case == 'effect' else 'hold-peer' if case == 'worker-cut' else 'drop-ack'
                lost = invoke(dict(args,action='account-deliver',selected=0,mode=mode,killAfterPeerResult=case=='worker-cut'))
                if case == 'worker-cut': sdk.require(lost.get('workerTerminatedAfterPeerResult') is True, 'no actual Worker cut after peer result')
                else: sdk.require(lost.get('code') == 'PeerTransport' and lost.get('ownerClosed') is True, 'lost result did not close owner')
                frames = [record for record in peers[key] if record['kind'] == 3]
                sdk.require(len(frames) == 1 and frames[0]['trigger'] and frames[0]['slot'] == 0, 'wrong first dispatch')
                if case == 'effect': sdk.require(frames[0]['application_unconfirmed'] and frames[0]['returncode'] != 0, 'receiver did not fail after effect')
                rows = success(dict(args,action='account-reconcile'))
                sdk.require(rows['status']['phase'] == 2 and rows['operation'] == operation and len(rows['members']) == 2, 'whole batch not committed')
                sdk.require(rows['rejectedIndices'] == 10, 'metadata numeric boundary not exercised')
                sdk.require([m['message'] for m in rows['members']] == original_slots and [m['phase'] for m in rows['members']] == [1,1], 'not all original outboxes committed before dispatch')
                effects = list((directory/'recipients/0/peer/effects').iterdir())
                sdk.require(len(effects) == 1 and effects[0].read_bytes() == bytes(sessions[0])+bytes(original_slots[0])+b'all account devices', 'first receiver effect')
                stat = effects[0].stat(); effect_before = [stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]; row['effect_before'] = effect_before
                rejected = invoke(dict(args,action='account-deliver',selected=0,plaintext='changed original input'))
                sdk.require(rejected.get('code') == 'Conflict' and rejected.get('ownerClosed') is True, 'aggregate input changed')
                delivered = success(dict(args,action='account-deliver',selected=0))
                sdk.require(delivered['outcome'] == 1 and delivered['exchanges'] == 1 and delivered['message'] == original_slots[0] and not delivered['ownerClosed'], 'original first member unconfirmed')
                frames = [record for record in peers[key] if record['kind'] == 3]
                sdk.require(len(frames) == 2 and frames[0]['request_sha256'] == frames[1]['request_sha256'], 'retry changed original wire')
                stat = effects[0].stat(); sdk.require([stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns] == effect_before, 'effect rewritten on retry')
                row['effect_after'] = effect_before
                retained = success(dict(args,action='account-deliver',selected=0))
                sdk.require(retained['outcome'] == 1 and retained['exchanges'] == 0 and not retained['ownerClosed'] and len([r for r in peers[key] if r['kind']==3]) == 2, 'retained ACK dispatched or closed owner')
                refused = invoke(dict(args,action='unary',selected=0,message=original_slots[0]))
                sdk.require(refused.get('code') == 'Suspended', 'unary send bypassed aggregate release')
                refused = invoke(dict(args,action='account-retire'))
                sdk.require(refused.get('code') == 'Suspended', 'pending required member retired')
                rows = success(dict(args,action='account-reconcile'))
                sdk.require([m['phase'] for m in rows['members']] == [2,1], 'partial remote outcomes lost')
                delivered = success(dict(args,action='account-deliver',selected=1))
                sdk.require(delivered['outcome'] == 1 and delivered['message'] == original_slots[1], 'second member identity or consumption')
                for slot in range(2):
                    files = list((directory/'recipients'/str(slot)/'peer/effects').iterdir())
                    sdk.require(len(files) == 1 and files[0].read_bytes() == bytes(sessions[slot])+bytes(original_slots[slot])+b'all account devices', 'receiver effect count or identity')
                rows = success(dict(args,action='account-reconcile'))
                sdk.require([m['phase'] for m in rows['members']] == [2,2], 'full consumption not retained')
                sdk.require(success(dict(args,action='account-retire'))['status']['phase'] == 5, 'aggregate retirement')
                sdk.require(success(dict(args,action='account-next'))['operation'] != operation, 'aggregate ID reused')
                sdk.require(not failures, 'native fixture errors: '+json.dumps(failures))
                row['completed'] = True
                print(json.dumps({'case':case,'completed':True,'two_receivers':True,'same_original_operation':True}),flush=True)
            state['witness_records'] = records; state['peer_records'] = peers
        finally:
            browser(['close'],'close')
    for name,digest in producer.items(): sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'installed web drift')
    state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    state['failure'] = repr(error); raise
finally:
    sdk.write_json(output/'RESULT.json',state)
print(json.dumps({'completed':True,'cases':cases,'scope':state['scope']}))
