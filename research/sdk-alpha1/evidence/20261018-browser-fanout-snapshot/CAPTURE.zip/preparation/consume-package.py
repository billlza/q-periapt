import hashlib,json,os,sys
from pathlib import Path
from environment import ROOT,STAGE,environment
sys.path.insert(0,str(ROOT/'artifact'))
import wasm_sdk_package as package
os.environ.update(environment())
original=STAGE/'package';output=STAGE/'consume-02';output.mkdir()
archive=original/'q-periapt-sdk-wasm-0.2.0.tgz'
archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
manifest_sha=hashlib.sha256((original/'package/PACKAGE_CONTENTS.json').read_bytes()).hexdigest()
assert archive_sha=='8137791850b629203521f7961b66677c1c5a3149b4952aa81e11ca7f2c89a332'
assert manifest_sha=='fadb0f6d4a1a51644c07019f5e16377fc70cde2f861a3b594b4d93a4bf5521cc'
assert package.sources()==json.loads((original/'sources-before.json').read_text())
report=package.consume(archive,archive_sha,manifest_sha,output,node=Path('/opt/homebrew/bin/node'),npm_cli=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/browser-policy-tools/node_modules/npm/bin/npm-cli.js'),expected_node_version='v26.3.0')
package.write_json(output/'INSTALLED_CONSUMER.json',report)
package.write_json(output/'PACKAGE_REVIEW.json',{'source_head':'ca7e13fac927218e20b231804c1e93054117edfa','original_build_source_unchanged':True,'archive_sha256':archive_sha,'manifest_sha256':manifest_sha,'original_failure':'Missing preinstalled TypeScript7.0.2 offline tool cache. Original failed receipt retained; same archive consumed through unchanged original consumer after exact compiler cache preparation. No package rebuild or check bypass.','browser_runtime':'not-run'})
print('Current archive installed Node/TypeScript consumer passed',flush=True)
