"""Public-only decoder for the executed single-session metadata profile."""
from peer.wire import Reader,require,digest,ldh
from peer.witness import Head
from peer.identity_state import IdentityState
from peer.traffic import DOMAIN

def inspect(data,ctx):
 r=Reader(data)
 def num():return r.integer(8)
 def bit():
  n=r.integer(1);require(n in (0,1),'canonical option');return n
 def optional(parse):return parse() if bit() else None
 def rows(parse,limit=128):
  n=num();require(n<=limit,'bounded public rows');return [parse() for _ in range(n)]
 def fixed():return r.take(32)
 head=Head.read(r);account=fixed();ordinal=num();require(account==ctx.devices[0].pin.account and ordinal==0,'original account/no fanout')
 def epoch():
  counts=tuple(num()for _ in range(5));limit=optional(num);phase=r.integer(1);require(phase in (0,1,2),'resolution phase')
  resolution=fixed()if phase else None
  unknown=rows(lambda:(fixed(),fixed()));deliveries=rows(lambda:(fixed(),num(),num()));skipped=rows(num);holes=rows(lambda:(fixed(),num()))
  reservation=optional(lambda:(fixed(),num(),num(),optional(fixed)));closed=bit()
  return {'counts':counts,'limit':limit,'resolution':(phase,resolution),'unknown':unknown,'deliveries':deliveries,'skipped':skipped,'holes':holes,'reservation':reservation,'closed':closed}
 def record():
  identity,context,phase=fixed(),fixed(),r.integer(1);authorities=rows(fixed);claims=rows(fixed);inventory=rows(fixed)
  require(context==ctx.digest and not claims and not inventory,'context/unsupported one-time inventory')
  tag=r.integer(1)
  if tag==1:
   source,context,role,status=fixed(),fixed(),r.integer(1),r.integer(1);request=optional(fixed);flights=[optional(fixed)for _ in range(4)]
   require(bit()==0 and role==0 and status==phase==19 and context==ctx.digest,'active bootstrap projection')
   require(identity==source==ldh(b'Q-PERIAPT-CONTINUITY-VAULT-INITIATION-CANDIDATE/v1',request),'stable original operation projection')
   body={'source':source,'request':request,'flights':flights}
  elif tag==3:
   source,session,role=fixed(),fixed(),r.integer(1);account,device,generation=fixed(),r.take(16),num();progress=tuple(num()for _ in range(3));pending=optional(num)
   kind=r.integer(1);prior=optional(fixed)
   require(phase==19 and role==1 and kind==1 and prior is None,'live session projection '+repr((phase,role,kind,prior)))
   require((account,device,generation)==(ctx.devices[1].pin.account,ctx.devices[1].pin.device,ctx.devices[1].pin.generation),'original remote binding')
   require(identity==ldh(DOMAIN+b'record',session),'session projection identity')
   body={'source':source,'session':session,'progress':progress,'pending':pending,'epochs':rows(epoch,4)}
  elif tag==4:
   account,checkpoint=fixed(),r.take(40);history=r.take(num());h=Reader(history)
   require(phase==20 and h.take(8)==b'QPIRHS01','reference history tag')
   role=h.integer(1);require(role in (0,1),'history role');original=ctx.devices[role]
   credential,current=h.take(32),h.take(32);key=h.take(len(original.key.raw));validity=(h.integer(8),h.integer(8));state=IdentityState.read(h,ctx,role);h.finish()
   require((credential,key,current,validity,checkpoint,account)==(original.credential,original.key.raw,state.current.digest,(state.current.validity.start,state.current.validity.end),state.listing.checkpoint(),original.pin.account),'genuine retained public identity')
   require(identity==ldh(b'Q-PERIAPT-CONTINUITY-JOURNAL-ROSTER/v1',account),'roster projection identity')
   body={'role':role,'state':state}
  else:raise ValueError('unexecuted public record kind')
  return {'identity':identity,'authorities':authorities,'tag':tag,'body':body}
 records=rows(record,4);r.finish();require(len(records)==4 and sorted(x['tag']for x in records)==[1,3,4,4],'complete profile records')
 ids=[x['identity']for x in records];require(ids==sorted(set(ids)),'strict record ordering')
 states={x['body']['role']:x['body']['state']for x in records if x['tag']==4}
 authorities=[digest(b'AUTHORITY',states[i].original.pin.account+states[i].listing.checkpoint()+ctx.family)for i in (0,1)]
 for entry in records:
  require(entry['authorities']==([authorities[entry['body']['role']]]if entry['tag']==4 else authorities),'exact current authority projection')
 return head,records,states
