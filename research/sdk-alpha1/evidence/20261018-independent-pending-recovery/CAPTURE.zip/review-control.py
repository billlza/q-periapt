"""Verify public control outputs; never open a private session image or key."""
from pathlib import Path
import ast
import hashlib
import json
import sys

root = Path.cwd()
peer = root / 'research/continuity-openssl-peer'
out = root / 'target/independent-pending-recovery-01'
folder = out / 'qualified-control'
sys.path.append(str(peer))
sys.path.append(str(out))
from source_readback import source_bytes, normalized, continuity
from provider import load_provider
load_provider(root / 'target/independent-bootstrap-01/provider')
from fixture_inputs import load
from peer.rekey import RekeyScope, genesis
from peer.traffic import message_id

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(value, message):
    if not value:
        raise ValueError(message)

def read(name):
    return json.loads((folder / name).read_text())

def worker(name):
    return read(name + '.stdout')['result']

r = read('RESULT.json')
check(r['sources_unchanged'] and len(r['source_files']) == 85, 'source count/identity')
check(not (out / 'qualified-control.stderr').read_bytes(), 'control run diagnostics')
for name, expected in r['source_files'].items():
    data = source_bytes(name, expected)
    check(sha(data) == expected, 'source changed: ' + name)
    if name.endswith('.py'):
        ast.parse(data, name)
binary = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
check(sha(binary) == r['native_sha256'] and binary[:4] == b'\xcf\xfa\xed\xfe'
      and int.from_bytes(binary[4:8], 'little') == 0x100000c, 'native ARM64 identity')
for row in r['native_commands']:
    name = row['case']
    before = (folder / 'native/cases' / (name + '.input')).read_bytes()
    after = (folder / 'native/cases' / (name + '.output')).read_bytes()
    check(sha(before) == row['input_sha256'] and sha(after[1:]) == row['output_sha256']
          and after[0] == row['status'], 'native command bytes')
    if row['status'] == 2:
        check(after[1:].decode() == row['error'], 'native refusal bytes')
for row in r['worker_operations']:
    name = row['case']
    request = read(name + '.request.json')
    data = (folder / (name + '.stdout')).read_bytes()
    error = (folder / (name + '.stderr')).read_text()
    check(request['action'] == row['action'], 'worker request action')
    if 'signal' in row:
        check(row['signal'] == 'SIGKILL' and json.loads(data) == {'pid': row['worker_pid'], 'stage': row['cut']}
              and not error, 'worker PID/interruption')
    elif 'refused' in row:
        check(not data and row['refused'] in error, 'worker refusal output')
    else:
        check(sha(data) == row['stdout_sha256'] and not error, 'worker successful output')
check(r['epochs'] == 7 and len(r['worker_operations']) == 111 and len(r['native_commands']) == 80
      and r['process_kills'] == 13 and len(r['control_steps']) == 101 and r['codec_refusals'] == 13, 'actual workload')
check(worker('original-format') == 2 and worker('upgrade-reconciled') == 5, 'explicit upgrade')
check(worker('prepared-status') == 'BodyPrepared' and worker('committed-status') == 'Committed'
      and worker('request-cleared') == 'Absent', 'request dispositions')
check(worker('expired-progress') == [7, 7, 7, 0], 'completed status after expiry')
check(worker('request-recovered') == worker('request-exact-replay'), 'committed request replay')
check(worker('receipt-delivery-recovered') == worker('receipt-exact-replay'), 'lost receipt delivery')
check(worker('local-confirmation-2') == [2, None], 'local confirmation is not receipt output')
check(worker('old-offer') == worker('request-1-offer')[1] == worker('request-during-final')[1]
      == worker('completed-request-replay')[1], 'original offer retained across upgrade and completion')
check(worker('old-send-resumed') == worker('old-send-still-retained'), 'original unacknowledged ciphertext')
session = (folder / 'native/cases/bootstrap-complete.output').read_bytes()[1:]
check(bytes.fromhex(worker('original-send-id')) == message_id(session, 1, 0, 0), 'original message identity')
check((folder / 'native/cases/old-send-received.output').read_bytes() == b'\1original version-two operation', 'actual original plaintext')
_, _, context = load(folder / 'native/public', 150)
check(context.send_budget == 4, 'actual signed budget')
by_target = {}
for row in r['control_steps']:
    wire = None if row['confirmed'] else (folder / (row['case'] + '.wire')).read_bytes()
    if row['side'] == 'python':
        value = worker(row['case'])
        check(value == [row['target'], None if wire is None else wire.hex()], 'Python step output')
    else:
        value = (folder / 'native/cases' / (row['case'] + '.output')).read_bytes()
        check(value == b'\1' + bytes([wire is not None]) + row['target'].to_bytes(8, 'big')
              + (b'' if wire is None else wire), 'native step output')
    if wire is not None:
        check(sha(wire) == row['wire_sha256'], 'control wire identity')
        key = (row['target'], wire[4:12])
        if key in by_target:
            check(by_target[key] == wire, 'repeated control replaced bytes')
        by_target[key] = wire
check(len(by_target) == 33, 'unique signed flights and requests')
parent = genesis(session, context.digest)
tags = [b'QPRKOF01', b'QPRKRP01', b'QPRKFN01', b'QPRKRC01']
for target in range(1, 8):
    scope = RekeyScope(context, session, target - 1, parent)
    if (target, b'QPRKRQ01') in by_target:
        scope.open_request(by_target[(target, b'QPRKRQ01')])
    parent = scope.public_completed(*(by_target[(target, tag)] for tag in tags))
check([(x['target'], x['active_role'], x['lost_flights'], x['duplicated_flights'], x['dummy_application_messages']) for x in r['schedules']]
      == [(4, 1, 5, 5, 0), (5, 1, 4, 4, 0), (6, 2, 4, 4, 0), (7, 2, 5, 5, 0)], 'bounded loss schedule coverage')
for row in r['schedules']:
    target = row['target']
    check(1 <= row['attempts'] <= 32, 'host attempt limit')
    for side in ('python', 'rust'):
        check(any(s['target'] == target and s['side'] == side and s['confirmed'] for s in r['control_steps']), 'both peers confirmed')
archive = root / 'research/sdk-alpha1/evidence/20261018-independent-durable-rekey/CAPTURE.zip'
check(sha(archive.read_bytes()) == r['archived_version_two_capture_sha256'], 'archived writer closure')
result = {'base_head': 'b987dde49b57e6c0948061ecb05c14be16e083b0', 'source_files': normalized(r['source_files']), 'source_continuity': continuity(r['source_files']),
          'native_sha256': r['native_sha256'], 'native_architecture': 'MachO64 ARM64', 'provider': r['provider'],
          'epochs': 7, 'worker_operations': 111, 'native_commands': 80, 'process_kills': 13,
          'control_steps': 101, 'unique_identity_signed_controls': 33, 'codec_refusals': 13,
          'schedules': r['schedules'], 'archived_writer_capture': r['archived_version_two_capture_sha256'],
          'scope': 'Public output/signature/transcript/PID/identity readback; actual runtimes check secret KEM/MAC/AEAD. Codec refusal and no-dummy-message checks remain runtime assertions because private images are not exported. The pipe schedule is not a network transport or performance claim.'}
(out / 'CONTROL_READBACK.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ['source_files', 'scope']}))
