"""Seal exact independent pending-write recovery and its regressions."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;peer=root/'research/continuity-openssl-peer';folder=root/'research/sdk-alpha1/evidence/20261018-independent-pending-recovery'
sha=lambda b:hashlib.sha256(b).hexdigest()
sources=json.loads((out/'SOURCE_FILES.json').read_text());assert len(sources)==85
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE','LOCAL_RENEWAL','LOCAL_CREDENTIAL','PENDING']
reports={n:json.loads((out/(n+'_READBACK.json')).read_text())for n in labels}
for name,r in reports.items():
 if name!='REPLY_RELEASE':assert r['source_files']==sources and r['native_sha256']==reports['PENDING']['native_sha256']
runs=json.loads((out/'FINAL_RUNS.json').read_text());assert len(runs)==17 and all(r['exit']==0 for r in runs)
assert all(r['exit']==0 for r in json.loads((out/'READERS.json').read_text()))
entries={}
def add(name,data):
 assert name not in entries
 assert not data.startswith((b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPRFLC01',b'QPRFLI01',*(('QPREFS0'+str(i)).encode()for i in range(1,9))))
 entries[name]=data
def tree(name):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink()and p.name not in {'head','intent','authority','configuration','signer','key','wrong-signer'}and not p.name.startswith('.stage-')
  add(name+'/'+str(p.relative_to(out/name)),p.read_bytes())
for row in runs:
 name=row['output'];tree(name)
 for ext in ['stdout','stderr']:add(name+'.'+ext,(out/(name+'.'+ext)).read_bytes())
 assert not entries[name+'.stderr']
# Retain the failure and all its already produced public/native/worker outputs.
tree('process-03')
for name in ['process-01','process-02','process-03']:
 for ext in ['stdout','stderr']:add(name+'.'+ext,(out/(name+'.'+ext)).read_bytes())
for p in [out/'process-02/RESULT.json',out/'process-02/INPUTS.json',*sorted((out/'process-02').glob('*/RESULT.json'))]:add(str(p.relative_to(out)),p.read_bytes())
assert b"ModuleNotFoundError: No module named 'cryptography'"in entries['process-01.stderr']
assert b'already-applied recovery requested new approval'in entries['process-03.stderr']
for p in sorted(out.glob('*')):
 if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name!='seal.py':add(p.name,p.read_bytes())
add('seal.py',Path(__file__).read_bytes())
for name in ['fmt-01','build-01','clippy-01','quality-0','quality-1','quality-2',
             'review-regressions','review-control','review-resolution','review-witness','review-peer-lifecycle','review-reply-release','review-local-renewal','review-local-credential','review-pending','readers','qualified']:
 for ext in ['stdout','stderr']:add(name+'.'+ext,(out/(name+'.'+ext)).read_bytes())
 if name not in ['build-01','clippy-01']:assert not entries[name+'.stderr']
for name,expected in sources.items():
 b=(peer/name).read_bytes();assert sha(b)==expected and b==(out/'source'/name).read_bytes();add('source/'+name,b)
for name in ['README.md','STORAGE.md','PENDING_WRITE_RECOVERY.md']:add('source/'+name,(peer/name).read_bytes())
for name in ['.github/workflows/independent-continuity.yml','research/continuity-identity-candidate/CREDENTIAL_RENEWAL.md']:add('integration/'+name,(root/name).read_bytes())
binary=(out/'counterpart').read_bytes();assert sha(binary)==reports['PENDING']['native_sha256'];add('counterpart',binary)
rs=subprocess.check_output(['git','ls-files','*.rs']).decode().splitlines();native_sources={n:sha((root/n).read_bytes())for n in rs};assert len(native_sources)==725
add('NATIVE_SOURCES.json',(json.dumps(native_sources,indent=2)+'\n').encode())
add('SOURCE_DIFF.patch',subprocess.check_output(['git','diff','--','.github/workflows/independent-continuity.yml','research/continuity-openssl-peer','research/continuity-identity-candidate/CREDENTIAL_RENEWAL.md']))
scope={'base_head':'b987dde49b57e6c0948061ecb05c14be16e083b0','implemented':'Independent reference request/public-view/confirm owner plus separate native fixture controller. Ordinary pending write only; no permission extension. Original target and original Advance history required, always fresh Query.',
 'qualification':'17 entrypoints / 9 public readers, exact85 sources, native ARM64 2806fae5, strict build/Clippy/fmt/actionlint/AST/diff checks. New lane164workers,858nativecommands,747signedreplies,26SIGKILL; metadata25574 and79986bytes.',
 'failures':'Initial entrypoint import order failure and rejected-approval counting assertion retained; runtime protocol unchanged by those harness repairs. Public reader initially used incorrect32-byte device field; corrected to wire16 with both diagnostics retained. Failed private stores retained, never reset.',
 'prototypes':'Successful earlier prototype02 raw files retained in the local target folder; only its result/input summaries are duplicated in this final capture. Final accepted process04 includes all public raw files.',
 'limits':'Runtime private MAC/AEAD/exact sealed-target assertions are not public rederivation. Projected reference IDs/history are not native DB rows. Controller independent authentication is a privileged fixture, not deployed account auth. Native traffic clock170. Full same-account lifecycle, installed network composition, erasure/powerloss, resources/energy, retained-state PCS/refinement, ABI/release integration and user-owned external review remain open.'}
add('SCOPE.json',(json.dumps(scope,indent=2)+'\n').encode())
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};add('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode())
folder.mkdir();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,data)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for name,item in manifest.items():assert len(z.read(name))==item['bytes']and sha(z.read(name))==item['sha256']
result={'readbacks':reports,'quality':json.loads(entries['QUALITY.json']),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':scope}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
