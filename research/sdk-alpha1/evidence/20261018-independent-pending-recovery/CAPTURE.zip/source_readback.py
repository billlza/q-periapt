"""Exact frozen and live source readback; no repair normalization."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
PEER=Path.cwd()/'research/continuity-openssl-peer'
EXPECTED=json.loads((OUT/'SOURCE_FILES.json').read_text())
def source_bytes(name,expected):
 if EXPECTED.get(name)!=expected:raise ValueError('different source identity: '+name)
 data=(OUT/'source'/name).read_bytes()
 if hashlib.sha256(data).hexdigest()!=expected or (PEER/name).read_bytes()!=data:raise ValueError('changed source: '+name)
 return data
def normalized(sources):
 if sources!=EXPECTED:raise ValueError('different complete source closure')
 for name,expected in sources.items():source_bytes(name,expected)
 return sources
def continuity(sources):
 normalized(sources)
 return {'executed_source_files':sources,'current_source_files':sources,'test_harness_only_changes':{},'runtime_sources_identical':True}
