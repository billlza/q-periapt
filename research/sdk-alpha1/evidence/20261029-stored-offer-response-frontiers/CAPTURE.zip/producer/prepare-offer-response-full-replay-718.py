"""Apply observed goals and restore every unselected Snapshot subtree before replay."""
from pathlib import Path
import hashlib,json,re,shutil

root=Path.cwd();capture=root/'target/p0-origin-offer-response-frontiers-718'
sha=lambda data:hashlib.sha256(data).hexdigest()
terminal=json.loads((capture/'offer-response-frontiers-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
value=(capture/'offer-response-frontiers-proof.spthy').read_text()
assert sha(value.encode())==terminal['output_sha256']=='0f6e9ff8537fec727c185279a54f9f122e7559cae40dcb7568f17026c3828df9'
parent=(root/'target/p0-origin-snapshot-producers-replay-716/snapshot-producers-replay-proof.spthy').read_text()
assert sha(parent.encode())=='b0cffe0a3c3568d39dce0a4418fe9f251dbc146dad164870c70ac24fa6c17085'
a=value.index('lemma epoch_generation_secret_derivation_origin ');b=value.index('\nlemma ',a);main=value[a:b]
inventory=json.loads((capture/'FRONTIER_INVENTORY.json').read_text())['rows']
leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',main));assert len(leaves)==len(inventory)==17
selected={'Offer_Commit_3','Response_Compute_5','Response_Commit_6'}
changes=[];methods=[]
for leaf,row in zip(leaves,inventory,strict=True):
    if row['child'] not in selected:continue
    raw=(capture/'initial-send-oracle-frames'/row['frame']).read_text()
    chains=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',raw)
    phases=re.findall(r'(?m)^\d+: (PositionedPhaseState\([^\n]+▶₀ #vr(?:\.[0-9]+)?)$',raw)
    if chains:
        assert len(chains)==1
        method=chains[0];kind='knowledge_chain'
    else:
        assert len(phases)==1
        method=phases[0];kind='phase_producer'
    changes.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
    methods.append({'child':row['child'],'frame':row['frame'],'frame_sha256':sha(raw.encode()),'kind':kind,'method':method})
assert len(methods)==12 and sum(row['kind']=='knowledge_chain' for row in methods)==9
for left,right,replacement in reversed(changes):main=main[:left]+replacement+main[right:]
root_pattern=r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)'
roots={match[1]:match for match in re.finditer(root_pattern,main)}
assert len(roots)==18
snapshot_match=roots['Snapshot_case_5'];snapshot=snapshot_match[0]
retained=json.loads((capture/'retained-full-siblings.json').read_text())
for name,original in retained.items():
    matches=list(re.finditer(r'(?ms)^      case '+re.escape(name)+r'\n(.*?)(?=^    next|^    qed)',snapshot))
    assert len(matches)==1
    assert matches[0][0].count('by sorry')==1 and 'Oracle ranked no proof methods' in matches[0][0]
    snapshot=snapshot[:matches[0].start()]+original+snapshot[matches[0].end():]
main=main[:snapshot_match.start()]+snapshot+main[snapshot_match.end():]
candidate=value[:a]+main+value[b:]
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,parent)
assert candidate[:candidate.index('lemma ')]==parent[:parent.index('lemma ')]
old_main=parent.split('lemma epoch_generation_secret_derivation_origin ',1)[1].split('\nlemma ',1)[0]
old_roots={match[1]:match[0] for match in re.finditer(root_pattern,old_main)}
new_roots={match[1]:match[0] for match in re.finditer(root_pattern,main)}
assert old_roots.keys()==new_roots.keys()
assert all(new_roots[name]==block for name,block in old_roots.items() if name!='Snapshot_case_5')
for name in ('Key_Reservation_1','Offer_Signing_2','Response_Reservation_4'):
    pattern=r'(?ms)^      case '+re.escape(name)+r'\n(.*?)(?=^    next|^    qed)'
    old=re.search(pattern,old_roots['Snapshot_case_5'])[0];new=re.search(pattern,snapshot)[0]
    assert old==new and 'by sorry' not in new
assert all(block in snapshot for block in retained.values()) and main.count('by sorry')==20
stage=root/'target/p0-origin-offer-response-full-replay-718';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'full_parent_sha256':sha(parent.encode()),'capture_sha256':terminal['output_sha256'],'input_sha256':sha(candidate.encode()),
 'actual_selected_methods':methods,'all_29_queries_and_operational_prefix_unchanged':True,
 'all_five_full_siblings_restored_byte_equal':True,'three_closed_stored_subtrees_retained_byte_equal':True,
 'other_seventeen_source_roots_byte_equal':True,'remaining_explicit_original_sibling_leaves':20,
 'independent_replay_no_search_or_oracle':True,'total_depth_limit':16,
 'input_is_not_completion':'The independent checker may expand further children. Full multi-epoch secrecy remains open.',
 'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'selected_methods':len(methods),'chains':9,'phase_producers':3,'full_siblings_restored':5}))
