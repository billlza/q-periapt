from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import runpy

root = Path.cwd()
stage = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline = (root / 'target/p0-checked-origin-resume-702/model.spthy').read_text()
assert sha(baseline.encode()) == 'ad82ad10bc84864209cf5019b7c23210ed73859e47c825515dc3e0fd69ef1a27'
prefix = lambda s: s[:re.search(r'^lemma ', s, re.M).start()]
pattern = r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)\s*"([^"]*)"'
def queries(text):
    return [(name, ' '.join(attributes.split()), mode, formula) for name, attributes, mode, formula in re.findall(pattern, text)]
assert len(queries(baseline)) == 27
experiments = []
histories = []
for name, label, count, stops in [
    ('p0-checked-origin-resume-703', 'checked-origin-resume', 17, 0),
    ('p0-static-key-source-resume-703', 'static-key-source', 140, 12),
]:
    folder = root / 'target' / name
    model = (folder / 'model.spthy').read_text()
    assert model == baseline
    terminal = json.loads((folder / (label + '-TERMINAL.json')).read_text())
    outer = json.loads((folder / 'DRIVER_TERMINAL.json').read_text())
    assert not terminal['accepted'] and outer['terminal_exit'] == 1
    assert '--bound=14' in terminal['argv'] and '-M12G' in terminal['argv'] and '-N1' in terminal['argv']
    frames = [json.loads(p.read_text()) for p in sorted((folder / 'initial-send-oracle-frames').glob('*.json'))]
    raw_parts = (folder / (label + '.stderr')).read_text().split('>>>>>>>>>>>>>>>>>>>>>>>> START INPUT\n')[1:]
    assert len(frames) == len(raw_parts) == count
    assert sum(row['diagnostic_stop'] for row in frames) == stops
    rank = runpy.run_path(str(folder / 'initial-send-oracle.py'))['rank']
    checked = []
    for index, (frame, part) in enumerate(zip(frames, raw_parts, strict=True)):
        section, output = part.split('>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT\n', 1)
        candidates = [raw for raw in {section, section.removesuffix('\n')} if sha(raw.encode()) == frame['input_sha256']]
        assert len(candidates) == 1
        raw = candidates[0]
        goals, ranked = rank(raw)
        observed = [int(s) for s in output.split('>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call', 1)[0].split()]
        assert len(raw) == frame['input_characters'] and len(raw.encode()) == frame['input_bytes']
        assert observed == frame['ranking'] and [n for n, _ in goals] == frame['goal_numbers']
        if frame['diagnostic_stop']:
            assert stops and index >= 128 and not observed and frame['stop_reason'] == 'callback-budget'
            assert (folder / 'initial-send-oracle-frames' / frame['captured_input']).read_text() == raw
        else:
            assert observed == ranked and sorted(observed) == sorted(frame['goal_numbers'])
        checked.append({'index': index, 'input_sha256': frame['input_sha256'], 'diagnostic_stop': frame['diagnostic_stop'], 'ranking': observed})
    if stops:
        assert not terminal['timed_out'] and terminal['returncode'] == 0
        assert terminal['results']['epoch_generation_secret_derivation_origin'] == {'mode': 'all-traces', 'status': 'analysis incomplete', 'steps': 197}
    else:
        assert terminal['timed_out'] and terminal['returncode'] == -2
        assert terminal['output_sha256'] is None and terminal['results'] == {}
    experiments.append({'stage': name, 'terminal': terminal, 'outer': outer, 'oracle_frames': checked})
    histories.append(frames)
assert histories[0][0]['input_sha256'] == histories[1][0]['input_sha256']
assert histories[0][0]['ranking'][0] == histories[1][0]['ranking'][0]
assert histories[0][1]['input_sha256'] == histories[1][1]['input_sha256']
assert histories[0][1]['ranking'][0] != histories[1][1]['ranking'][0]

proofs = []
for folder, label in [('p0-static-key-source-resume-703', 'static-key-source'), ('p0-static-key-source-replay-703', 'static-key-replay')]:
    directory = root / 'target' / folder
    terminal = json.loads((directory / (label + '-TERMINAL.json')).read_text())
    proof = (directory / (label + '-proof.spthy')).read_text()
    assert sha(proof.encode()) == terminal['output_sha256']
    assert prefix(proof) == prefix(baseline) and queries(proof) == queries(baseline)
    assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
    assert len(terminal['results']) == 27
    assert sum(row['mode'] == 'all-traces' and row['status'] == 'verified' for row in terminal['results'].values()) == 11
    assert terminal['results']['initial_epoch_traffic_advances_counter_is_executable'] == {'mode': 'exists-trace', 'status': 'verified', 'steps': 414}
    main = proof.split('lemma epoch_generation_secret_derivation_origin ', 1)[1].split('\nlemma ', 1)[0]
    cases = dict(re.findall(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)', main))
    assert len(cases) == 18
    closed = [name for name, body in cases.items() if not re.search(r'\b(sorry|invalid)\b', body)]
    assert closed == ['Application_Message', 'Cut_case_1', 'Cut_case_2', 'Offer_Commit_3_case_2']
    assert not re.search(r'invalid proof|unhandled case', main, re.I)
    stack, unfinished = [], []
    for line in main.splitlines():
        case = re.match(r'^(\s*)case (\S+)', line)
        if case:
            depth = len(case[1])
            stack = [(level, name) for level, name in stack if level < depth] + [(depth, case[2])]
        if 'by sorry' in line:
            unfinished.append({'path': [name for _, name in stack], 'reason': line.strip()})
    assert max(len(item['path']) for item in unfinished) == 16
    if label == 'static-key-replay':
        assert not any(arg.startswith(('--prove', '--oracle', '--oraclename')) for arg in terminal['argv'])
    proofs.append({'stage': folder, 'terminal': terminal, 'closed_source_cases': closed, 'unfinished': unfinished,
                   'normalized_main': re.sub(r'\s+', ' ', re.sub(r'/\*.*?\*/', '', main, flags=re.S)).strip()})
assert proofs[0]['normalized_main'] == proofs[1]['normalized_main']
for record in proofs:
    record.pop('normalized_main')
result = {
    'verified': True, 'operational_prefix_sha256': sha(prefix(baseline).encode()), 'queries_and_attributes_preserved': 27,
    'continuation_input_sha256': sha(baseline.encode()), 'experiments': experiments, 'proofs': proofs,
    'source_cases_closed_after_independent_replay': proofs[1]['closed_source_cases'],
    'whole_origin_complete': False, 'release_claim_eligible': False,
    'budget_interpretation': 'Existing open source leaves have two preceding proof nodes; automatic subproof bound14 therefore retains target cutoff16. New frontier nodes already reach depth16. Do not resume them with another full14 or16 levels and claim the same bound.',
    'interpretation': 'Resolving already-present wrapping-key bindings before recursive Ready state closes both Cut source cases and one Offer source case, retaining the checked Application_Message case. The same first two inputs isolate the changed selection at callback1. The result is a197-step partial proof with depth-cut and explicitly latched callback-budget stops; independent no-search replay confirms only the existing closed subtrees and helpers. It is not a completed origin/security proof or overall speed comparison.',
}
destination = stage / 'EXPERIMENTS.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'sha256': sha(destination.read_bytes()), 'closed_cases': result['source_cases_closed_after_independent_replay'], 'whole_origin_complete': False}))
