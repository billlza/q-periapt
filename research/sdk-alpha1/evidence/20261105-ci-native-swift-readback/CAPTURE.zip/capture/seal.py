from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-ci-readback-20'
DEST=ROOT/'research/sdk-alpha1/evidence/20261105-ci-native-swift-readback'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
jobs={j['id']:j for j in json.loads((BASE/'JOBS.json').read_bytes())}
snapshot=json.loads((BASE/'CI_STATUS.json').read_bytes())
raw={j:(BASE/f'job-{j}.log').read_bytes() for j in jobs}
logs={j:b.decode() for j,b in raw.items()}
pr117='475cd23923e45819b01b6041c91c44540ec056ec'
pr118merge='59bde0fd1a268de4d0e183c33bf3fc5e09c9be97'
checkouts={126445737664:pr117,126445737915:pr117,126446853524:pr118merge,
           126489776973:pr118merge,127060936059:pr118merge}
for j,head in checkouts.items():
    assert re.search(r'git log -1 --format=%H\n\S+Z '+head+r'\s*\n',logs[j])
native={}
for j,library in [(126445737664,1451),(126445737915,1450),(126446853524,1456)]:
    assert jobs[j]['conclusion']=='success'
    summaries=re.findall(r'^\S+Z test result: (ok\..+)$',logs[j],re.M)
    counts=[int(re.match(r'ok\. ([0-9]+) passed;',s)[1]) for s in summaries]
    assert counts==[library,4,2,4,3,19,27,4],counts
    assert all('; 0 failed; 0 ignored;' in s for s in summaries)
    steps={s['number']:s for s in jobs[j]['steps']}
    if j==126445737915:
        assert '; 1 filtered out;' in summaries[0]
        assert all(steps[n]['conclusion']=='success' for n in [14,15,16,17,18])
        assert 'CANDIDATE_PUBLIC_VECTORS_PASS envelopes=20 proofs=30 selections=9 signature_negative_controls=100 bootstrap=passed rekey=verified' in logs[j]
        assert 'ANCHOR_PUBLIC_VECTORS_PASS envelopes=57 signature_negative_controls=285 requests=26' in logs[j]
    else:
        assert '; 0 filtered out;' in summaries[0]
        assert all(steps[n]['conclusion']=='success' for n in [9,13,15])
        assert all(steps[n]['conclusion']=='skipped' for n in [16,17,18])
    native[str(j)]={'actual_checkout':checkouts[j],'candidate_library_cases':library,
        'candidate_other_cases':32,'sdk_cases':31,'test_summaries':summaries,
        'independent_public_verification_executed':j==126445737915,
        'current_local_source_qualified':False}
swift=126489776973
assert jobs[swift]['conclusion']=='failure'
assert 'report["witness_exchanges"] == 142' in logs[swift]
assert 'ValueError: OpenSSL server exchange census differs' in logs[swift]
assert 'result["c_consumer"] = qualify_c(' in logs[swift]
coverage=127060936059
assert jobs[coverage]['conclusion']=='failure'
assert 'Total of 6 artifact(s) downloaded' in logs[coverage]
assert 'ValueError: partition is unfinished or makes a complete-package claim' in logs[coverage]
steps={s['number']:s for s in jobs[coverage]['steps']}
assert steps[4]['conclusion']=='success' and steps[5]['conclusion']=='failure' and steps[6]['conclusion']=='skipped'
assert (BASE/'continuity_profiles-59bde0fd.py').read_bytes()==(ROOT/'target/continuity-ci-late-swift-coverage/continuity_profiles-6084f3bf.py').read_bytes()
artifacts={}
for j,text in logs.items():
    rows=re.findall(r'Artifact (.+?) has been successfully uploaded! Final size is ([0-9]+) bytes\. Artifact ID is ([0-9]+)',text)
    digests=re.findall(r'SHA256 digest of uploaded artifact is ([0-9a-f]{64})',text)
    assert len(rows)==len(digests)
    artifacts[str(j)]=[{'name':n,'bytes':int(size),'id':int(i),'sha256':h}
        for (n,size,i),h in zip(rows,digests)]
assert sum(map(len,artifacts.values()))==5
classification={'captured_utc':datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at':snapshot['observed_at'],'wave_counts':snapshot['counts'],
    'job_total':sum(snapshot['counts'].values()),'native_successes':native,
    'swift_release':{'job_id':swift,'actual_checkout':pr118merge,
        'failure':'Old exact 142 C/OpenSSL prerequisite; stops in qualify_c.',
        'observed_p0_failure_ordinal':16,'hosted_server_count_disclosed':False,
        'swift_execution_established':False},
    'installed_coverage':{'job_id':coverage,'actual_checkout':pr118merge,
        'failure':'First parsed partition fails the compound completion/claim predicate.',
        'classification':'Second observed dependent coverage gate; not another runtime P0 occurrence.',
        'hosted_artifact_downloads':6,'first_partition_from_pinned_source':'continuity-installed-swift-debug',
        'exact_failed_conjunct_established':False,'coverage_report_written':False,
        'coverage_upload_skipped':True,'strict_join_changed':False},
    'reported_artifacts':artifacts,'artifacts_downloaded_locally':False,
    'logs':{str(j):{'bytes':len(b),'sha256':sha(b),'url':jobs[j]['html_url']} for j,b in raw.items()},
    'original_debug_upload_failure_reclassified':False,'corrected_step_order_hosted_execution_claimed':False,
    'effective_wave_open':True,'push_performed':False,'rerun_performed':False,
    'workflow_cancelled':False,'release_claim_eligible':False}
files={'capture/'+p.name:p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json']=encode(classification)
files['FILES.json']=encode({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,b in sorted(files.items()):
        info=zipfile.ZipInfo(n,(2026,11,5,0,0,0));info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,b)
payload=buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist())==len(files) and set(archive.namelist())==set(files)
    for n,b in files.items():assert archive.read(n)==b
summary={'bytes':len(payload),'members':len(files),'sha256':sha(payload),'all_members_read_back':True}
DEST.mkdir(exist_ok=False)
for n,b in [('CAPTURE.zip',payload),('CLASSIFICATION.json',files['CLASSIFICATION.json']),
            ('FILES.json',files['FILES.json']),('SHA256.json',encode(summary))]:
    with (DEST/n).open('xb') as f:f.write(b)
print(json.dumps(summary,indent=2),flush=True)
