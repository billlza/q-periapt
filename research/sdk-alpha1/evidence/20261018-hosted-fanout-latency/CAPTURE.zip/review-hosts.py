"""Independently replay both completed hosted measurements and cloud readbacks."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'artifact'))
from evidence_io import parse_strict_json_bytes, read_regular_snapshot
from fanout_latency_review import review
from rust_sdk_profile import write_json

HEAD = 'aa7ef3b13c2af60849fc9cbfe1d4ea4c47bdf795'
ARTIFACTS = {
    'ubuntu-24.04': (12132841040, 4182510, 'f8eec25b148732748e71ca5aa5832a5b4ae7cb0fac72ac4a368efbc6c347034b'),
    'macos-15': (12132692365, 4184940, '6f030f39b094a475c38796f516993d8d7bea503b57cc439b025ee0f1934d476f'),
    'readback-ubuntu-24.04': (12132484497, 120344, 'ae3dbbd9812d8974043a2f665ccd836578bcaf81f5eefcd372568ef2be2df763'),
    'readback-macos-15': (12133231449, 119911, '69f5e653db2c2727a170d4fbe3a9b56d1cb1e74d6d19b391b13ff64486f1f64e'),
}


def data(path):
    return read_regular_snapshot(path, maximum=16 * 1024**2, label='hosted latency record').data


def document(path):
    return parse_strict_json_bytes(data(path), label=str(path))


def archive(name):
    raw = data(OUT / (name + '.zip'))
    _, size, digest = ARTIFACTS[name]
    assert len(raw) == size and hashlib.sha256(raw).hexdigest() == digest
    with zipfile.ZipFile(io.BytesIO(raw)) as zipped:
        entries = zipped.infolist()
        assert len(entries) == len({e.filename for e in entries}) <= 4096
        assert sum(e.file_size for e in entries) <= 128 * 1024**2
        files = {}
        for entry in entries:
            path = PurePosixPath(entry.filename)
            assert len(path.parts) == 1 and not path.is_absolute() and path.name not in ('.', '..')
            assert str(path) == entry.filename and '\\' not in entry.filename
            assert stat.S_ISREG(entry.external_attr >> 16) and not entry.flag_bits & 1
            assert entry.file_size <= 16 * 1024**2
            files[entry.filename] = zipped.read(entry)
        return files


def check_builds(folder, run):
    records = {}
    for variant in ('baseline', 'candidate'):
        command = document(folder / f'build-{variant}.json')
        assert command['returncode'] == 0 and command['argv'] == [
            'cargo', 'test', '--locked', '--release', '--all-features', '--lib',
            '--no-run', '--message-format=json']
        blob = data(folder / f'build-{variant}.stdout')
        events = [parse_strict_json_bytes(line, label=f'{variant} Cargo event') for line in blob.splitlines()]
        assert all(isinstance(row, dict) for row in events)
        assert [row['success'] for row in events if row['reason'] == 'build-finished'] == [True]
        selected = [row for row in events if row['reason'] == 'compiler-artifact'
                    and row['profile']['test'] and row.get('executable')]
        assert len(selected) == 1
        row = selected[0]
        assert row['target']['src_path'] == command['cwd'] + '/src/lib.rs'
        assert row['executable'] == run['binaries'][variant]
        source = PurePosixPath(command['cwd']); binary = PurePosixPath(row['executable'])
        assert source.is_absolute() and '..' not in source.parts and source.name == 'source'
        assert source.parent.name == variant and binary.is_relative_to(source.parent / 'build')
        assert all(e['message']['level'] not in ('error', 'warning') for e in events
                   if e['reason'] == 'compiler-message')
        records[variant] = dict(strict_events=len(events), build_stdout_sha256=hashlib.sha256(blob).hexdigest(),
                                selected_test=row['executable'], recorded_binary_sha256=run['binary_sha256'][variant])
    return records


records = {}
for name, host, machine, local_name in (
        ('ubuntu-24.04', 'x86_64-unknown-linux-gnu', 'x86_64', 'ubuntu-readback'),
        ('macos-15', 'aarch64-apple-darwin', 'arm64', 'macos-readback')):
    files = archive(name); folder = OUT / name
    if not folder.exists():
        folder.mkdir(mode=0o700)
        for filename, blob in files.items():
            with (folder / filename).open('xb') as stream: stream.write(blob)
    else:
        assert {p.name for p in folder.iterdir()} == set(files)
        assert all(data(folder / filename) == blob for filename, blob in files.items())
    run = document(folder / 'EXECUTION.json'); environment = document(folder / 'ENVIRONMENT.json')
    assert run['source']['candidate'] == HEAD and run['completed']
    assert environment['source'] == run['source'] and environment['binary_sha256'] == run['binary_sha256']
    assert environment['host'] == run['host'] == host and environment['machine'] == machine
    assert environment['compiler'].splitlines()[0] == 'rustc 1.98.1 (48a229cea 2026-09-01)'
    builds = check_builds(folder, run)
    local = OUT / local_name
    if not local.exists():
        local.mkdir(mode=0o700)
        review(folder, local / 'REVIEW.json', HEAD)
    cloud = archive('readback-' + name)
    assert set(cloud) == {'REVIEW.json', 'REVIEW.csv'}
    for filename, blob in cloud.items():
        assert data(local / filename) == files[filename] == blob
    checked = document(local / 'REVIEW.json')
    assert checked['blocks'] == 200 and checked['timed_operations'] == 4800
    loads = [document(folder / f'block-{block:03}-{variant}.json')['load_before'][0]
             for block in range(200) for variant in ('baseline', 'candidate')]
    records[name] = dict(host=host, machine=machine, cpu_count=environment['cpu_count'],
        producer_and_cloud_and_local_reports_identical=True, strict_builds=builds,
        samples=checked['timed_operations'], p95_increased_positions=checked['p95_increased_positions'],
        paired_median_change_percent_range=[min(row['paired_median_change_percent'] for row in checked['samples']),
                                           max(row['paired_median_change_percent'] for row in checked['samples'])],
        load1_range=[min(loads), max(loads)], primary_samples=checked['samples'])
    print(name, records[name]['paired_median_change_percent_range'], 'p95 increased',
          records[name]['p95_increased_positions'], '/12', flush=True)
output = OUT / 'HOSTED_READBACK.json'
assert not output.exists()
write_json(output, dict(head=HEAD, run=39115501316, artifacts=ARTIFACTS, hosts=records,
    scope='Full independent source/command/raw-sample and cloud report replay, with strict Cargo-event parsing. '
          'Binary hashes remain producer observations. Per-host observed quantiles only; no causal, confidence, '
          'latency improvement, power-loss, energy or release claim.'))
