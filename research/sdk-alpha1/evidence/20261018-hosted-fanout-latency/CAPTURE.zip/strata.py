"""Describe order/time strata of a previously verified complete hosted dataset."""
import argparse
import csv
import hashlib
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'artifact'))
from evidence_io import parse_strict_json_bytes, read_regular_snapshot
from rust_sdk_profile import write_json


def read(path):
    return read_regular_snapshot(path, maximum=16 * 1024**2, label='latency strata').data


def document(path):
    return parse_strict_json_bytes(read(path), label=str(path))


def review(folder, output):
    primary = document(folder / 'REVIEW.json')
    raw = read(folder / 'REVIEW.csv')
    assert hashlib.sha256(raw).hexdigest() == primary['raw_csv_sha256']
    samples = {}
    for row in csv.DictReader(raw.decode().splitlines()):
        key = (row['variant'], row['same_account'], int(row['position']), int(row['block']))
        assert key not in samples
        samples[key] = int(row['elapsed_ns'])
    expected = {(variant, same, position, block) for variant in ('baseline', 'candidate')
                for same in ('False', 'True') for position in range(6) for block in range(200)}
    assert set(samples) == expected and all(value > 0 for value in samples.values())
    loads = {(variant, block): document(folder / f'block-{block:03}-{variant}.json')['load_before'][0]
             for variant in ('baseline', 'candidate') for block in range(200)}
    partitions = {'baseline-first': list(range(0, 200, 2)),
                  'candidate-first': list(range(1, 200, 2))}
    partitions.update({f'blocks-{start:03}-{start + 49:03}': list(range(start, start + 50))
                       for start in range(0, 200, 50)})
    assert sorted(partitions['baseline-first'] + partitions['candidate-first']) == list(range(200))
    assert [block for name, blocks in partitions.items() if name.startswith('blocks-')
            for block in blocks] == list(range(200))
    rows = []
    for same in ('False', 'True'):
        for position in range(6):
            strata = {}
            for name, blocks in partitions.items():
                b = [samples[('baseline', same, position, block)] for block in blocks]
                c = [samples[('candidate', same, position, block)] for block in blocks]
                n = len(blocks)
                strata[name] = dict(n=n, paired_median_change_percent=100 *
                    (statistics.median(y / x for x, y in zip(b, c)) - 1),
                    baseline_p95_ms=sorted(b)[math.ceil(.95 * n) - 1] / 10**6,
                    candidate_p95_ms=sorted(c)[math.ceil(.95 * n) - 1] / 10**6,
                    baseline_load_median=statistics.median(loads['baseline', block] for block in blocks),
                    candidate_load_median=statistics.median(loads['candidate', block] for block in blocks))
            rows.append(dict(same_account=same == 'True', position=position, strata=strata))
    result = dict(source=primary['source']['candidate'], host=primary['host'],
                  raw_csv_sha256=primary['raw_csv_sha256'], rows=rows,
                  scope='Post hoc descriptive order/time strata of all 200 paired blocks. '
                  'Each partition retains every sample. No exclusion, causal inference, confidence '
                  'interval or new acceptance threshold. n50 p95 observations are sparse.')
    assert not output.exists()
    write_json(output, result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = review(args.input, args.output)
    for name in result['rows'][0]['strata']:
        count = sum(row['strata'][name]['candidate_p95_ms'] >
                    row['strata'][name]['baseline_p95_ms'] for row in result['rows'])
        print(f'{name}: observed p95 increased at {count}/12 positions')
