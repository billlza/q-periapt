from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
inputs = json.loads((stage / 'PLATFORM_INPUTS_02.json').read_text())
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None); env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
cargo = Path(env['RUSTC']).parent / 'cargo'
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift before regression')
for label, selected in [('portable', 'session_exchange::tests'), ('fanout', 'fanout'), ('tls', 'connection_transport::tests')]:
    sdk.command([str(cargo), 'test', '--locked', '--offline', '--manifest-path', 'research/continuity-identity-candidate/Cargo.toml',
        '--all-features', '--lib', selected, '--target-dir', str(stage / 'native-target'), '-j', '2', '--', '--nocapture'],
        stage / ('regression-' + label), root, environment=env)
    print(label + ' regression passed', flush=True)
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift after regression')
sdk.write_json(stage / 'NATIVE_REGRESSIONS.json', {'completed': True, 'inputs_unchanged': True, 'filters': ['session_exchange::tests', 'fanout', 'connection_transport::tests']})
