from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
env['CC_wasm32_unknown_unknown'] = '/opt/homebrew/opt/llvm/bin/clang'
inputs = json.loads((stage / 'PLATFORM_INPUTS_02.json').read_text())
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'pre-check input drift')
cargo = Path(env['RUSTC']).parent / 'cargo'
sdk.command([str(cargo), 'clippy', '--locked', '--offline', '-p', 'q-periapt-sdk-wasm', '--features',
    'browser-continuity', '--lib', '--target', 'wasm32-unknown-unknown', '--target-dir', str(stage / 'wasm-target'),
    '-j', '2', '--', '-D', 'warnings'], stage / 'wasm-clippy-02', root, environment=env)
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'post-check input drift')
print('WASM account API strict Clippy passed')
