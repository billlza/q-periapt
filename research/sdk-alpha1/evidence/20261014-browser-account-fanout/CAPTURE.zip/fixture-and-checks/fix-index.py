from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
clone = root / 'target/continuity-browser-publication/source'
prior = json.loads((stage / 'SOURCE_OVERLAY.json').read_text())
for name, digest in prior['overlay'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'main source drift')
    sdk.require(sdk.snapshot(clone / name).sha256 == digest, 'clone source drift')
backup = stage / 'failed-index-01'
backup.mkdir()
paths = ['crates/q-periapt-sdk-wasm/src/continuity/account.rs',
         'crates/q-periapt-sdk-wasm/src/continuity/account/types.rs']
for name in paths:
    target = backup / name
    target.parent.mkdir(parents=True, exist_ok=True)
    sdk.copy(root / name, target)
path = root / paths[0]
source = path.read_text()
marker = '/// Bounded original session descriptors; adding one never creates a session.'
sdk.require(source.count(marker) == 1, 'index helper insertion')
helper = '''// Member positions are zero based; capacity/time limits deliberately reject zero.
fn read_index(value: &JsValue) -> Result<usize, JsValue> {
    let invalid = || {
        engine::browser::input_failure(
            js_sys::Error::new("expected integer account member index").into(),
        )
    };
    let number = value.as_f64().ok_or_else(invalid)?;
    if !number.is_finite()
        || number.fract() != 0.0
        || !(0.0..engine::MAX_DEVICES as f64).contains(&number)
    {
        return Err(invalid());
    }
    Ok(number as usize)
}

'''
source = source.replace(marker, helper + marker)
sdk.require(source.count('read_limit(&selected, engine::MAX_DEVICES - 1)?') == 1, 'selected index call')
path.write_text(source.replace('read_limit(&selected, engine::MAX_DEVICES - 1)?', 'read_index(&selected)?'))
path = root / paths[1]
source = path.read_text()
sdk.require(source.count('read_limit(&index, engine::MAX_DEVICES - 1)?') == 1, 'metadata index call')
path.write_text(source.replace('read_limit(&index, engine::MAX_DEVICES - 1)?', 'read_index(&index)?'))
rustfmt = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin/bin/rustfmt'
sdk.command([str(rustfmt), '--edition', '2021', *[str(root / name) for name in paths]], stage / 'format-index-01', root)
overlay = {name: sdk.snapshot(root / name).sha256 for name in prior['overlay']}
for name in paths:
    (clone / name).write_bytes(sdk.snapshot(root / name).data)
subprocess.run(['git', 'add', '--', *paths], cwd=clone, check=True)
sdk.write_json(stage / 'PLATFORM_INPUTS_03.json', overlay)
sdk.write_json(stage / 'SOURCE_OVERLAY_02.json', {**prior, 'overlay': overlay})
script = (stage / 'build-package.sh').read_text().replace('browser-fanout-package-01', 'browser-fanout-package-02')
(stage / 'build-package-02.sh').write_text(script)
for old, new in [('check-wasm-02.py', 'check-wasm-03.py')]:
    script = (stage / old).read_text().replace('PLATFORM_INPUTS_02', 'PLATFORM_INPUTS_03').replace('wasm-clippy-02', 'wasm-clippy-03')
    (stage / new).write_text(script)
result = json.loads((stage / 'run02/RESULT.json').read_text())
sdk.write_json(stage / 'INDEX_CAUSE.json', {
    'failed_run': 'run02', 'completed': result['completed'], 'failure': result['failure'],
    'cause': 'New account selected/member indices reused the positive-only capacity validator; valid position zero failed before owner dispatch.',
    'repair': 'Account-local zero-based bounded integer validator; positive-only capacity and timeout contracts unchanged.',
    'package_before': 'browser-fanout-package-01', 'package_after': 'browser-fanout-package-02',
    'verification_pending': 'actual installed browser runtime, both selected/member zero indices and invalid JS numeric inputs'} )
print('Preserved failing account index source; repaired zero-based indices and staged exact package overlay')
