from pathlib import Path
import json
import re
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
overlay = json.loads((stage / 'SOURCE_OVERLAY_02.json').read_text())
for name, digest in overlay['overlay'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift: ' + name)
    sdk.require(sdk.snapshot(Path(overlay['source']) / name).sha256 == digest, 'package source drift: ' + name)
expected = {'run03': ['local', 'required'], 'run05': ['worker-cut', 'effect']}
results = {}
for name, cases in expected.items():
    result = json.loads((stage / name / 'RESULT.json').read_text())
    sdk.require(result['completed'] and result['producer_unchanged'] and result['startup_console_clean'], 'run incomplete: ' + name)
    sdk.require([row['case'] for row in result['cases']] == cases and all(row['completed'] for row in result['cases']), 'scenario mismatch')
    for path, digest in result['producer'].items():
        sdk.require(sdk.snapshot(Path(path), maximum=256*1024**2).sha256 == digest, 'producer drift: ' + path)
    for path, digest in result['static_web'].items():
        sdk.require(sdk.snapshot(stage / (name + '-web') / path).sha256 == digest, 'web drift: ' + path)
    results[name] = result
failed_index = json.loads((stage / 'run02/RESULT.json').read_text())
sdk.require(not failed_index['completed'] and 'InvalidInput' in failed_index['failure'], 'index counterexample missing')
native = json.loads((stage / 'NATIVE_REGRESSIONS_VERIFIED.json').read_text())
sdk.require(native['completed'] and native['counts'] == {'portable': 13, 'fanout': 61, 'owned': 3}, 'native regression counts')
for prefix in ('native-clippy-02', 'wasm-clippy-03', 'msrv-check-02', 'group-build-01'):
    sdk.require(json.loads((stage / (prefix + '.json')).read_text())['returncode'] == 0, 'failed check: ' + prefix)
package = Path(overlay['source']) / 'target/browser-fanout-package-02'
installed = json.loads((package / 'INSTALLED_CONSUMER.json').read_text())
sdk.require(installed['source_bound'] and installed['installed_node_tests'] == 'passed', 'package checks')
sdk.require(installed['browser_runtime'] == 'not-run', 'producer receipt rewritten')
sdk.require(sdk.snapshot(Path(installed['archive'])).sha256 == installed['sha256'], 'package bytes drift')
sdk.require(installed['sources_unchanged'] and sdk.snapshot(package / 'package/PACKAGE_CONTENTS.json').sha256 == installed['manifest_sha256'], 'package manifest/source drift')

members = {}
def include(path, name):
    sdk.require(name not in members and path.is_file() and not path.is_symlink(), 'capture member: ' + name)
    members[name] = sdk.snapshot(path, maximum=64*1024**2).data

# Public run outputs only. The neighboring -private directories and browser
# profiles contain signing/wrapping material and are never traversed here.
for name in ('run01', 'run02', 'run04', *expected):
    for path in (stage / name).rglob('*'):
        relative = path.relative_to(stage / name)
        if path.is_file() and (not any(part.startswith('.') for part in relative.parts)
                              or (relative.parts[0] == '.playwright-cli' and path.suffix == '.log')):
            include(path, name + '/' + relative.as_posix())
    for folder in ('inputs', 'creation'):
        for path in (stage / (name + '-web') / folder).rglob('*'):
            if path.is_file():
                include(path, name + '-web/' + path.relative_to(stage / (name + '-web')).as_posix())
for path in stage.iterdir():
    if path.is_file() and path.suffix in ('.py', '.js', '.sh', '.json', '.stdout', '.stderr') and path.name != 'HANDOFF_CURRENT.json':
        include(path, 'fixture-and-checks/' + path.name)
for name in ('failed-01', 'failed-02', 'failed-03', 'failed-lints-01', 'failed-index-01'):
    for path in (stage / name).rglob('*'):
        if path.is_file(): include(path, name + '/' + path.relative_to(stage / name).as_posix())
for path in (stage / 'group-fixture/src').rglob('*.rs'):
    include(path, 'fixture/group/' + path.relative_to(stage / 'group-fixture').as_posix())
for name in ('Cargo.toml', 'Cargo.lock'):
    include(stage / 'group-fixture' / name, 'fixture/group/' + name)
for path in package.iterdir():
    if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr'):
        include(path, 'package/' + path.name)
for name in ('package.json', 'PACKAGE_CONTENTS.json'):
    include(package / 'package' / name, 'package/' + name)
for name in overlay['overlay']:
    include(root / name, 'source/' + name)
documentation = {'docs/continuity/PRODUCT_ADMISSION.md': sdk.snapshot(root / 'docs/continuity/PRODUCT_ADMISSION.md').sha256}
for name in documentation:
    include(root / name, 'source/' + name)
destination = root / 'research/sdk-alpha1/evidence/20261014-browser-account-fanout'
destination.mkdir(parents=True)
archive = destination / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 14, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100600 << 16
        output.writestr(info, data)
with zipfile.ZipFile(archive) as output:
    sdk.require(output.testzip() is None and len(output.namelist()) == len(members), 'archive validation')
    for name, data in members.items(): sdk.require(output.read(name) == data, 'capture payload drift')
cases = [{'run': name, 'case': row['case'], 'calls': len(row['calls']),
          'two_receivers': True, 'effect_identity_unchanged': row['effect_before'] == row['effect_after']}
         for name, result in results.items() for row in result['cases']]
checks = {
    'schema': 1, 'completed': True, 'release_claim_eligible': False, 'product_code_changed': True,
    'source_base': overlay['base_commit'], 'source_overlay': overlay['overlay'], 'documentation': documentation,
    'package_sha256': installed['sha256'], 'manifest_sha256': installed['manifest_sha256'],
    'cases': cases, 'browser_calls': sum(row['calls'] for row in cases),
    'native_regressions': native['counts'], 'invalid_js_index_values': 10,
    'archive': {'path': archive.name, 'sha256': sdk.snapshot(archive).sha256, 'bytes': archive.stat().st_size, 'members': len(members)},
    'scope': 'Actual installed browser package and current-source native receivers, same engine on one macOS arm64 host; each fresh cohort has one complete three-device signed roster and a single witness authority.',
    'counterexamples': ['New native retained-ACK success escaped operation finish after the sync transform; direct owner-open assertion reproduced and fixed.',
        'New WASM account indices used the positive-only limit validator; position zero failed before dispatch in run02, corrected and verified by run03/run04.',
        'run01 driver shadowed the browser session name; failed result and owned close recovery retained.',
        'The original TLS library filter ran zero tests; excluded and replaced by the explicit owned_connection integration target.'],
    'deadline_attempt': {'run': 'run04', 'completed': False, 'action': 'establish', 'code': 'Deadline',
        'timeout_ms': 10000, 'native_bootstrap_replies_completed': True,
        'disposition': 'Preserved failed run; fresh run05 adds monotonic timing and retains the same timeout and assertions. No bounded-latency SLO is established.'},
    'remaining': ['Restricted inactive/expired/retired aggregate recovery and abandonment in the browser',
        'Additional authority races, reservation/commit interruption and cancellation boundaries',
        'Independent implementation and host interoperability, broader platform lifecycle, PCS, performance, current CI and final release admission'],
    'private_material_archived': False,
}
sdk.write_json(destination / 'CHECKS.json', checks)
print(json.dumps({'captured': True, 'archive': checks['archive'], 'cases': len(cases), 'browser_calls': checks['browser_calls']}))
