from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
source = (root / 'target/continuity-browser-joint-session/run-clean-v2.py').read_text().split('\ntry:\n    with serving',1)[0]
source = source.replace("stage = root / 'target/continuity-browser-joint-session'", "stage = root / 'target/continuity-browser-fanout'")
source = source.replace("allowed = {'local', 'required', 'commit-loss', 'worker-cut'}", "allowed = {'local', 'required', 'effect', 'worker-cut'}")
source = source.replace('browser-joint-package-03', 'browser-fanout-package-01')
source = source.replace("('worker.js', 'controller.js', 'session-checks.js')", "('worker.js', 'controller.js')")
start = source.index('binaries = '); end = source.index('\nstatic = ', start)
source = source[:start] + "binaries = {name: stage / ('group-target/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}" + source[end:]
source = source.replace(", stage / 'session-checks.js'", '')
source = source.replace('Original application and pending rekey across two browser G/T updates; independently approved peer G, native peer keeps live P0; same shared implementation on one host',
    'Installed browser complete-account fanout to two native receivers, one independently signed three-device roster and one witness authority; same shared implementation on one host')
source += (stage / 'run-body.py').read_text()
sdk.require(not (stage / 'run.py').exists(), 'driver exists')
(stage / 'run.py').write_text(source)
print('Fresh complete-account browser runner prepared')
