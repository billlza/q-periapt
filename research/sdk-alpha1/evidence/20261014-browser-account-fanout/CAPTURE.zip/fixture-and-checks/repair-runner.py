from pathlib import Path
import re
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
opened = (stage / 'run01/logs/open.stdout').read_text()
match = re.search(r'^### Browser `([a-z0-9-]+)` opened with pid (\d+)\.', opened, re.MULTILINE)
sdk.require(match is not None, 'original owned browser session')
sdk.command(['/opt/homebrew/bin/node', '/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js',
    '--session', match[1], 'close'], stage / 'run01/logs/recovered-close', stage / 'run01')
for name in ('run.py','run-body.py','make-run.py'):
    sdk.copy(stage / name, stage / ('failed-run01-' + name))
body = (stage / 'run-body.py').read_text()
body = body.replace("session = success(dict(args,action='establish'", "established = success(dict(args,action='establish'")
body = body.replace("session['journal']", "established['journal']").replace("session['session']", "established['session']")
(stage / 'run-body.py').write_text(body)
source = (stage / 'run.py').read_text()
source = source.split('\ntry:\n    with serving', 1)[0] + body
source = source.replace("session = 'qpc-joint-'", "browser_session = 'qpc-fanout-'")
source = source.replace("'--session', session,", "'--session', browser_session,")
sdk.require(not (stage / 'run-02.py').exists(), 'replacement driver exists')
(stage / 'run-02.py').write_text(source)
print('Original browser explicitly closed; session/result name collision fixed in fresh runner')
