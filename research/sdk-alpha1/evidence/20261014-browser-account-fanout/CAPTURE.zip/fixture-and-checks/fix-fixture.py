from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
for name, digest in json.loads((stage / 'NATIVE_INPUTS_01.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'failed source changed')
    target = stage / 'failed-01' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    sdk.copy(root / name, target)
path = root / 'research/continuity-identity-candidate/src/session_exchange/tests.rs'
source = path.read_text().replace('    pin: AccountPin,\n', '    pin: AccountPin,\n    account: [u8; 32],\n')
start = source.index('        let pin = AccountPin::new(', source.index('fn account('))
end = source.index('        staged\n', start)
pin = source[start:end].replace('        let pin =', '                let pin =')
source = source[:start] + source[end:]
needle = '.map(|(dir, paths, intent, certificate, mut pending)| {\n'
sdk.require(source.count(needle) == 1, 'enrollment fixture mapping')
source = source.replace(needle, needle + pin)
source = source.replace('                    pin: pin.clone(),', '                    pin,\n                    account: root.account_id().expect("account"),')
path.write_text(source)
path = root / 'research/continuity-identity-candidate/src/session_exchange/tests/account.rs'
source = path.read_text().replace('self.recipients[0].pin.account_id()', 'self.recipients[0].account').replace('group.recipients[0].pin.account_id()', 'group.recipients[0].account')
source = source.replace('    effects: Vec<Effects>,', '    effects: Vec<Effects>,\n    wires: Vec<Vec<Vec<u8>>>,')
source = source.replace('            effects: vec![Effects::default(), Effects::default()],', '            effects: vec![Effects::default(), Effects::default()],\n            wires: vec![vec![], vec![]],')
source = source.replace('        result.map(|value| (value, carrier.requests))', '        self.wires[selected].extend(carrier.requests.iter().cloned());\n        result.map(|value| (value, carrier.requests))')
needle = '    assert_eq!(delivered.message, original_messages[0]);'
sdk.require(source.count(needle) == 1, 'replay assertion insertion')
source = source.replace(needle, needle + '\n    assert_eq!(group.wires[0].len(), 2);\n    assert_eq!(group.wires[0][0], group.wires[0][1], "exact original ciphertext replay");')
path.write_text(source)
driver = (stage / 'check-native.py').read_text().replace('format-01', 'format-02').replace('NATIVE_INPUTS_01', 'NATIVE_INPUTS_02').replace('native-tests-01', 'native-tests-02')
sdk.require(not (stage / 'check-native-02.py').exists(), 'next driver exists')
(stage / 'check-native-02.py').write_text(driver)
print('Fixture creates each independent pin from public root inputs; original failed source preserved')
