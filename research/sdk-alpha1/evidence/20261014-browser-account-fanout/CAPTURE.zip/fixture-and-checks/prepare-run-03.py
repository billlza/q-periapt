from pathlib import Path
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
sdk.copy(stage / 'worker.js', stage / 'failed-index-01-worker.js')
path = stage / 'worker.js'
source = path.read_text()
marker = 'onmessage = async ({data}) => {'
helper = '''const invalidIndices = new Map([
  ['negative', -1], ['fraction', 0.5], ['nan', NaN], ['infinity', Infinity],
  ['string', '0'], ['boolean', false], ['null', null], ['undefined', undefined],
  ['wrapped', 4294967296], ['unsafe', Number.MAX_SAFE_INTEGER + 1]
]);
'''
sdk.require(source.count(marker) == 1, 'worker entry')
source = source.replace(marker, helper + marker)
source = source.replace('targets,input,data.selected,endpoint(data.selected)', "targets,input,data.invalidIndex ? invalidIndices.get(data.invalidIndex) : data.selected,endpoint(data.selected)")
marker = '              const rows = [];'
sdk.require(source.count(marker) == 1, 'member query')
source = source.replace(marker, '''              let rejectedIndices = 0;
              for (const index of invalidIndices.values()) {
                let refusal;
                try { const unexpected = members.member(index); unexpected.free(); }
                catch (error) { refusal = error; }
                if (refusal?.code !== 'InvalidInput') throw Error('metadata index accepted invalid JS value');
                rejectedIndices += 1;
              }
              const rows = [];''')
source = source.replace('members:rows,status:await status(id)', 'members:rows,rejectedIndices,status:await status(id)')
path.write_text(source)
source = (stage / 'run-02.py').read_text().replace('browser-fanout-package-01', 'browser-fanout-package-02')
marker = '                for name, extra, code, closed in negatives:'
sdk.require(source.count(marker) == 1, 'negative loop')
source = source.replace(marker, '''                negatives.extend((name, {'invalidIndex':name}, 'InvalidInput', False)
                    for name in ('negative','fraction','nan','infinity','string','boolean','null','undefined','wrapped','unsafe'))
''' + marker)
source = source.replace("'whole batch not committed')", "'whole batch not committed')\n                sdk.require(rows['rejectedIndices'] == 10, 'metadata numeric boundary not exercised')")
source = source.replace('<title>Joint policy maintenance</title>', '<title>Complete account delivery</title>')
(stage / 'run-03.py').write_text(source)
print('Fresh run03 uses package02; zero-based selected/member operations and ten invalid JS values are checked')
