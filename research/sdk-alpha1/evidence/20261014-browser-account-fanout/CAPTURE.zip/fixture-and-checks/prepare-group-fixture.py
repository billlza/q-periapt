from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
work = stage / 'group-fixture'; (work / 'src/bin').mkdir(parents=True)
prior = root / 'target/continuity-browser-joint'
for name in ('Cargo.toml', 'Cargo.lock'):
    content = (prior / 'authority' / name).read_text()
    sdk.require(content.count('q-periapt-browser-joint-authority') == 1, 'fixture package identity')
    (work / name).write_text(content.replace('q-periapt-browser-joint-authority', 'q-periapt-browser-fanout-fixture'))
for name in ('seed', 'witness'):
    sdk.copy(prior / ('authority/src/bin/qpc-joint-' + name + '.rs'), work / ('src/bin/qpc-fanout-' + name + '.rs'))
old = (root / 'target/continuity-browser-joint-session/native-peer/src/main.rs').read_text()
prefix = old[:old.index('fn prepare(')]
start = prefix.index('fn activate('); end = prefix.index("fn requirements<'a>", start)
prefix = prefix[:start] + '''fn activate(mut pending:p::DeviceEnrollment,dir:&Path,config:&Value,policy:&p::VerifiedSessionPolicy,trace:&Path)->Result<p::EnrolledDevice>{
 if config["profile"]=="local" {return Ok(pending.activate(policy,now()?,None)?)}
 if config["profile"]!="required" {return Err("explicit protection profile required".into())}
 let pin=p::AnchorPin::new(p::AnchorIdentity::from_trusted_state(array(config,"witness_id")?)?,p::PublicKey::decode(&bytes(config,"witness_public")?)?);
 let carrier=Box::new(Witness{dir:dir.to_owned(),config:config.clone(),trace:trace.to_owned(),sequence:0});
 let anchor=pending.anchor_client(policy,now()?,pin,carrier,Duration::from_secs(5))?;
 Ok(pending.activate(policy,now()?,Some(anchor))?)
}
''' + prefix[end:]
prefix = prefix.replace('fn witness(dir: &Path, v: &Value)', 'fn witness(_dir: &Path, v: &Value)')
marker = 'fn witness(_dir: &Path, v: &Value) -> Result<p::AnchorStore> {\n'
sdk.require(prefix.count(marker) == 1, 'shared witness boundary')
prefix = prefix.replace(marker, marker + '    let dir = Path::new(v["authority_directory"].as_str().ok_or("independent authority directory")?);\n')
prefix = prefix.replace('    b: &\'a p::AccountPin,\n', '    b: &\'a p::AccountPin,\n    device: [u8;16],\n')
prefix = prefix.replace('p::ExpectedDevice::new(b, [82; 16], 1)?', 'p::ExpectedDevice::new(b, device, 1)?')
prepare = old[old.index('fn prepare('):old.index('struct Effects')]
tail = prepare[prepare.index('    let mut owner = activate('):]
tail = tail.replace('    let validity = p::Validity::new(', '    let validity = p::Validity::new(', 1)
finish = '''fn finish_prepare(dir:&Path,mut peer:Value,config:Value,browser_grant:&Value,policy:Arc<p::VerifiedSessionPolicy>,pending:p::DeviceEnrollment,output:&Path,trace:&Path)->Result<()> {
 let base=dir.join("peer");
 let validity=p::Validity::new(number(&peer,"from")?,number(&peer,"until")?)?;
 let device=pin(&peer)?.verify_device(&bytes(&peer,"certificate")?,&bytes(&peer,"roster")?,now()?)?;
''' + tail
carrier = old[old.index('struct Effects'):old.index('struct Capture')]
start = carrier.index('fn existing_session(')
carrier = carrier[:start] + '''fn existing_session(dir:&Path,id:[u8;32],trace:&Path)->Result<(p::EnrolledDevice,p::session_exchange::Session)>{
 let config=load(&dir.join("PUBLIC.json"))?;let base=dir.join("peer");let peer=load(&base.join("PUBLIC.json"))?;let browser=load(&base.join("BROWSER.json"))?;
 let policy=policy(&config)?;
 let mut owner=activate(p::DeviceEnrollment::open(paths(&base)?,intent(&peer)?)?,dir,&config,&policy,trace)?;
 let a=pin(&browser)?;let b=pin(&peer)?;let bundle=p::BootstrapBundle::from_bytes(&bytes(&peer,"bundle")?)?;
 let reopened=owner.parts()?.0.reopen_peer_bundle(&bundle,policy,requirements(&a,&b,bytes(&peer,"device")?.as_slice().try_into()?)?,p::BootstrapRole::Responder,id,now()?)?;
 Ok((owner,p::session_exchange::Session::from_reopened(&reopened)))
}
'''
carrier = carrier.replace('requirements(&a, &b)?', 'requirements(&a, &b, bytes(&peer,"device")?.as_slice().try_into()?)?')
handler = old[old.index('fn handle_existing_message('):old.index('fn admit_browser_renewal(')]
group = (stage / 'group-provision.rs').read_text()
main = '''fn main()->Result<()> {
 let args=std::env::args().collect::<Vec<_>>();let mode=args.get(1).ok_or("mode")?;let dir=Path::new(args.get(2).ok_or("directory")?);
 match mode.as_str(){
  "prepare-group" if args.len()==7=>prepare_group(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]),Path::new(&args[6]))?,
  "handle" if args.len()==7=>{if !["normal","reject-effect","after-effect"].contains(&args[6].as_str()){return Err("mode".into())}handle(dir,Path::new(&args[3]),Path::new(&args[4]),Path::new(&args[5]),&args[6])?},
  _=>return Err("arguments".into()),
 }Ok(())
}
'''
(work / 'src/bin/qpc-fanout-peer.rs').write_text(prefix + finish + carrier + handler + group + main)
print('Fresh two-recipient fixture source prepared with one complete roster and shared witness')
