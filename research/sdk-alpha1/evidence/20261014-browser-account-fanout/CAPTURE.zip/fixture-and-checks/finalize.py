from pathlib import Path
import json
import os
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
overlay = json.loads((stage / 'SOURCE_OVERLAY_02.json').read_text())
clone = Path(overlay['source'])
destination = 'research/sdk-alpha1/evidence/20261014-browser-account-fanout'
checks = json.loads((root / destination / 'CHECKS.json').read_text())
sdk.require(checks['completed'] and not checks['release_claim_eligible'], 'acceptance incomplete')
sdk.require(sdk.snapshot(root / destination / 'CAPTURE.zip', maximum=64*1024**2).sha256 == checks['archive']['sha256'], 'capture drift')
sdk.require(sdk.command(['git', 'rev-parse', 'HEAD'], stage / 'source-head-before', root).decode().strip() == overlay['base_commit'], 'source base moved')
sdk.require(not sdk.command(['git', 'diff', '--cached', '--name-only'], stage / 'main-index-before', root), 'unexpected main staging')
for name, digest in overlay['overlay'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest and sdk.snapshot(clone / name).sha256 == digest, 'overlay drift: ' + name)
for name, digest in checks['documentation'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'documentation drift')
clone_paths = sdk.command(['git', 'diff', '--cached', '--name-only'], stage / 'clone-index-before', clone).decode().splitlines()
sdk.require(set(clone_paths) == set(overlay['overlay']), 'unexpected clone staging')
sdk.require(not sdk.command(['git', 'diff', '--name-only'], stage / 'clone-unstaged-before', clone), 'clone unstaged changes')
sdk.require(not sdk.command(['git', 'ls-files', '--others', '--exclude-standard'], stage / 'clone-untracked-before', clone), 'clone untracked changes')
sdk.command(['git', 'diff', '--cached', '--binary'], stage / 'clone-overlay-backup', clone)
paths = sorted(overlay['overlay']) + sorted(checks['documentation']) + [destination + '/' + name for name in ('CAPTURE.zip', 'CHECKS.json', 'README.md')]
sdk.command(['git', 'add', '--', *paths], stage / 'commit-stage', root)
sdk.command(['git', 'diff', '--cached', '--check'], stage / 'commit-check', root)
actual = sdk.command(['git', 'diff', '--cached', '--name-only'], stage / 'commit-paths', root).decode().splitlines()
sdk.require(set(actual) == set(paths), 'unexpected commit scope')
sdk.command(['git', 'commit', '-m', 'Add browser complete-account delivery and original-operation recovery'], stage / 'commit', root)
head = sdk.command(['git', 'rev-parse', 'HEAD'], stage / 'head', root).decode().strip()
sdk.require(not sdk.command(['git', 'status', '--porcelain'], stage / 'main-status', root), 'main not clean')
# Only the exact byte-verified overlay, saved above, is restored in the owned clone.
sdk.command(['git', 'restore', '--source=HEAD', '--staged', '--worktree', '--', *sorted(overlay['overlay'])], stage / 'clone-restore-overlay', clone)
sdk.require(not sdk.command(['git', 'status', '--porcelain'], stage / 'clone-restored-status', clone), 'clone restore not clean')
sdk.command(['git', 'fetch', str(root), 'HEAD'], stage / 'clone-fetch', clone)
sdk.command(['git', 'checkout', '--detach', head], stage / 'clone-checkout', clone)
sdk.require(not sdk.command(['git', 'status', '--porcelain'], stage / 'clone-status', clone), 'clone checkout not clean')
for name, digest in overlay['overlay'].items():
    sdk.require(sdk.snapshot(clone / name).sha256 == digest, 'final source differs from tested overlay')
env = dict(os.environ)
env['QPERIAPT_PYTHON'] = '/opt/homebrew/opt/python@3.14/bin/python3.14'
env['PYTHONPATH'] = 'artifact'
historical = sdk.snapshot(clone / 'artifact/results.json').sha256
sdk.require(historical == '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda', 'historical results changed')
sdk.command(['sh', 'artifact/python-run.sh', 'artifact/source_results_assembler.py', 'ci-source-gate', historical, head, '--profile', 'sdk-020'], stage / 'source-gate', clone, environment=env)
sdk.write_json(stage / 'FINALIZED.json', {'head': head, 'main_clean': True, 'clone_clean': True,
    'source_gate': 'passed', 'browser_cases': len(checks['cases']), 'browser_calls': checks['browser_calls'],
    'release_claim_eligible': False, 'pushed': False})
print(json.dumps({'head': head, 'source_gate': 'passed', 'pushed': False}))
