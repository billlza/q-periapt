from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
for name, digest in json.loads((stage / 'NATIVE_INPUTS_03.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'red source changed')
    target = stage / 'failed-03' / name; target.parent.mkdir(parents=True, exist_ok=True); sdk.copy(root / name, target)
path = root / 'research/continuity-identity-candidate/src/session_exchange/account.rs'
source = path.read_text(); method = source.index('    pub async fn deliver_account_member(')
start = source.index('        let op = Operation::new(self);\n        let result = async {\n', method)
end = source.index('\n        }\n        .await;\n        op.finish(result)\n    }', start)
body = source[start + len('        let op = Operation::new(self);\n        let result = async {\n'):end]
body = '\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines()).replace('op.owner.parts()', 'self.parts()')
header = source[method:start].replace('mut clock: impl', 'clock: impl')
wrapper = '''        let op = Operation::new(self);
        // Keep successful early returns inside the attempt function. The native
        // sync transform removes async-block scope, but cannot bypass this finish.
        let result = op.owner.deliver_account_member_attempt(input, selected, transport, run, clock).await;
        op.finish(result)
    }
    async fn deliver_account_member_attempt(
        &mut self,
        input: AccountSubmission<'_>,
        selected: usize,
        transport: &mut impl Transport,
        run: &Run<'_>,
        mut clock: impl FnMut() -> io::Result<u64>,
    ) -> Result<AccountDelivered, Error> {
'''
source = source[:method] + header + wrapper + body + '\n    }' + source[end + len('\n        }\n        .await;\n        op.finish(result)\n    }'):]
path.write_text(source)
driver = (stage / 'check-native-02.py').read_text().replace('format-02','format-04').replace('NATIVE_INPUTS_02','NATIVE_INPUTS_04').replace('native-tests-02','native-tests-04')
(stage / 'check-native-04.py').write_text(driver)
print('Separate attempt preserves success cleanup in both native sync and browser async paths')
