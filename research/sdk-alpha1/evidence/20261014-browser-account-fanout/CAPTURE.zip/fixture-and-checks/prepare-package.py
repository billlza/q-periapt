from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'; clone = root / 'target/continuity-browser-publication/source'
def git(path, *arguments): return subprocess.run(['git', *arguments], cwd=path, check=True, capture_output=True).stdout
base = '978e405f64b92999677e34be6ea3a36bd3471956'
sdk.require(git(clone, 'rev-parse', 'HEAD').decode().strip() == base and not git(clone, 'status', '--porcelain'), 'clone not expected clean base')
inputs = json.loads((stage / 'PLATFORM_INPUTS_02.json').read_text())
actual = set(git(root, 'diff', '--name-only').decode().splitlines()) | set(git(root, 'ls-files', '--others', '--exclude-standard').decode().splitlines())
sdk.require(actual == set(inputs), 'unexpected source scope')
for name, digest in inputs.items():
    source = sdk.snapshot(root / name); sdk.require(source.sha256 == digest, 'source drift')
    target = clone / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(source.data)
git(clone, 'add', '--', *sorted(inputs))
sdk.write_json(stage / 'SOURCE_OVERLAY.json', {'base_commit': base, 'source': str(clone), 'overlay': inputs})
driver = clone / 'target/browser-fanout-build.py'
sdk.copy(clone / 'target/browser-joint-build.py', driver)
script = (root / 'target/continuity-browser-joint/build-package-03.sh').read_text().replace('target/browser-joint-build.py --output target/browser-joint-package-03', 'target/browser-fanout-build.py --output target/browser-fanout-package-01')
(stage / 'build-package.sh').write_text(script)
msrv = (root / 'target/continuity-browser-joint/msrv.py').read_text().replace("'target/continuity-browser-joint'", "'target/continuity-browser-fanout'").replace('Browser joint API', 'Browser account API')
(stage / 'msrv.py').write_text(msrv)
print('Exact653-source overlay staged; isolated package and minimum-version drivers prepared')
