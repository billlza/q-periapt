from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
env['CC_wasm32_unknown_unknown'] = '/opt/homebrew/opt/llvm/bin/clang'
binary = Path(env['RUSTC']).parent
tracked = subprocess.run(['git', 'diff', '--name-only'], cwd=root, check=True, capture_output=True).stdout.decode().splitlines()
paths = sorted(set(tracked + json.loads((stage / 'NEW_RUST_FILES.json').read_text())))
sdk.command([str(binary / 'rustfmt'), '--edition', '2021', '--config', 'skip_children=true', *[p for p in paths if p.endswith('.rs')]], stage / 'format-06', root, environment=env)
sdk.write_json(stage / 'PLATFORM_INPUTS_02.json', {name: sdk.snapshot(root / name).sha256 for name in paths})
mode = __import__('sys').argv[1]
if mode == 'native':
    sdk.command([str(binary / 'cargo'), 'clippy', '--locked', '--offline', '--manifest-path', 'research/continuity-identity-candidate/Cargo.toml', '--all-features', '--all-targets', '--target-dir', str(stage / 'native-target'), '-j', '2', '--', '-D', 'warnings'], stage / 'native-clippy-02', root, environment=env)
elif mode == 'wasm':
    sdk.command([str(binary / 'cargo'), 'clippy', '--locked', '--offline', '-p', 'q-periapt-sdk-wasm', '--features', 'browser-continuity', '--lib', '--target', 'wasm32-unknown-unknown', '--target-dir', str(stage / 'wasm-target'), '-j', '2', '--', '-D', 'warnings'], stage / 'wasm-clippy-01', root, environment=env)
else:
    raise ValueError('check selection')
for name, digest in json.loads((stage / 'PLATFORM_INPUTS_02.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'platform source drift')
print(mode + ' strict Clippy passed')
