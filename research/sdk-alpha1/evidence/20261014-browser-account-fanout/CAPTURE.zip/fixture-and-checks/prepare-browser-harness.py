from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
prior = root / 'target/continuity-browser-joint'
controller = (prior / 'controller.js').read_text()
controller = controller.replace('if (args.killAfterApplied)', 'if (args.killAfterPeerResult)')
controller = controller.replace("'/status/' + args.case", "'/peer-status/' + args.case")
controller = controller.replace('row.trigger && row.commit_applied_reply && row.cut === String(args.generation)', 'row.trigger && row.kind === 3 && row.slot === args.selected && row.returncode === 0')
controller = controller.replace('workerTerminatedAfterApplied', 'workerTerminatedAfterPeerResult')
(stage / 'controller.js').write_text(controller)
server = (prior / 'server.py').read_text()
server = server.replace('def serving(web, output, private, binary):', 'def serving(web, output, private, binary, peer_binary):')
server = server.replace('    failures, faulted = [], set()', '''    failures, faulted = [], set()
    peers, peer_faulted = {}, set()
    peer_traces = output / 'peer'; peer_traces.mkdir(mode=0o700)''')
server = server.replace('        def do_GET(self):\n', '''        def do_GET(self):
            peer = re.fullmatch(r'/peer-status/([a-z0-9-]+)', self.path)
            if peer:
                self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers()
                self.wfile.write(json.dumps(peers.get(peer[1], [])).encode()); return
''')
peer = (stage / 'peer-handler.py').read_text()
server = server.replace('        def do_POST(self):', peer + '\n        def do_POST(self):')
server = server.replace('            if capture:\n', '''            peer = re.fullmatch(r'/peer/([a-z0-9-]+)/([01])', target.path)
            if peer:
                modes = parse_qs(target.query)
                if set(modes) != {'mode'} or len(modes['mode']) != 1: self.send_error(400); return
                self.peer(peer[1], int(peer[2]), modes['mode'][0], data); return
            if capture:
''')
server = server.replace('yield origin, records, failures', 'yield origin, records, peers, failures')
(stage / 'server.py').write_text(server)
print('Same-origin complete-account server and Worker interruption controller prepared')
