from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
rustup = root / 'target/continuity-browser-connection/msrv-tools/rustup'
toolchain = rustup / 'toolchains/1.90.0-aarch64-apple-darwin'
env.update(RUSTC=str(toolchain / 'bin/rustc'), RUSTDOC=str(toolchain / 'bin/rustdoc'),
    RUSTUP_HOME=str(rustup), RUSTUP_TOOLCHAIN='1.90.0-aarch64-apple-darwin',
    DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'), CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang')
sdk.command([str(toolchain / 'bin/rustc'), '--version'], stage / 'msrv-version', root, environment=env)
sdk.command([str(toolchain / 'bin/cargo'), 'check', '--locked', '--offline', '-p', 'q-periapt-sdk-wasm',
    '--features', 'browser-continuity', '--lib', '--target', 'wasm32-unknown-unknown',
    '--target-dir', str(stage / 'msrv-check-target'), '-j', '2'], stage / 'msrv-check', root, environment=env)
print('Browser account API Rust 1.90 wasm check passed')
