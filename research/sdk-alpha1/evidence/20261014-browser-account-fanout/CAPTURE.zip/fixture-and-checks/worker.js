import initialize, * as sdk from '../node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const bytes = value => new Uint8Array(value);
const get = async name => {
  const response = await fetch('../inputs/' + name, { credentials: 'omit', cache: 'no-store' });
  if (!response.ok) throw Error('public input response ' + response.status);
  return response.json();
};
const invalidIndices = new Map([
  ['negative', -1], ['fraction', 0.5], ['nan', NaN], ['infinity', Infinity],
  ['string', '0'], ['boolean', false], ['null', null], ['undefined', undefined],
  ['wrapped', 4294967296], ['unsafe', Number.MAX_SAFE_INTEGER + 1]
]);
onmessage = async ({data}) => {
  const owned = [], own = value => { owned.push(value); return value; };
  let owner, value, failure, ownerClosed;
  const cleanupErrors = [];
  try {
    const cfg = await get(data.case + '.json'), at = () => BigInt(Math.floor(Date.now()/1000));
    const intent = own(new sdk.QPeriaptContinuityEnrollment(bytes(cfg.root), bytes(cfg.description).slice(0,16), 1n, bytes(cfg.family), BigInt(cfg.from), BigInt(cfg.until)));
    const storage = bytes(data.id.match(/../g).map(v => parseInt(v,16)));
    if (data.action === 'create') {
      owner = await sdk.QPeriaptContinuityDevice.create(data.name, storage, intent);
      value = {request: [...await owner.request(at())]};
    } else {
      const grant = await get(data.case + '-grant.json');
      const runtime = own(new sdk.QPeriaptRuntime(bytes(cfg.sdk_policy),bytes(cfg.sdk_signature),bytes(cfg.sdk_root),bytes(cfg.sdk_state),32,4));
      const p = cfg.policies[data.profile];
      const policy = own(new sdk.QPeriaptContinuityPolicy(runtime,bytes(cfg.policy_root),bytes(cfg.family),BigInt(p.version),bytes(p.digest),bytes(p.wire),at()));
      const account = g => own(new sdk.QPeriaptContinuityAccountTrust(bytes(cfg.account),bytes(cfg.root),BigInt(g.version),bytes(g.digest),bytes(cfg.family)));
      const witness = own(sdk.QPeriaptContinuityWitness.for_loopback(bytes(cfg.witness_id),bytes(cfg.witness_public),new URL('/witness/'+data.case+'?mode=normal&cut=0',location.origin).href,5000));
      owner = await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);
      if (data.action === 'accept') {
        value = {journal: [...await owner.accept(bytes(grant.certificate),bytes(grant.roster),account(grant),policy,at())]};
      } else if (data.action === 'prepare') {
        const prepared = own(await owner.prepare(policy,at())), status = own(await owner.status());
        value = {phase: prepared.requires_witness() ? 'requires-witness-enrollment' : 'prepared-local', journal: [...status.journal()]};
        if (prepared.requires_witness()) Object.assign(value,{subject:[...prepared.subject()],genesis:[...prepared.image_digest()]});
      } else {
        const journal = data.profile === 'local' ? await owner.activate_local(policy,at()) : await owner.activate(policy,witness,at());
        const context = async slot => {
          const peer = await get(data.case + '-peer-' + slot + '.json');
          const a = own(new sdk.QPeriaptContinuityParticipant(account(grant),bytes(cfg.description).slice(0,16),1n));
          const b = own(new sdk.QPeriaptContinuityParticipant(account(peer),bytes(peer.device),1n));
          const required = own(new sdk.QPeriaptContinuityPeerTrust(a,b,sdk.QPeriaptContinuityQuality.OneTimeBoth,new Uint8Array(32).fill(77)));
          return {bundle: bytes(peer.bundle), required};
        };
        const endpoint = slot => own(sdk.QPeriaptContinuityEndpoint.for_loopback(new URL('/peer/'+data.case+'/'+slot+'?mode='+(data.mode ?? 'normal'),location.origin).href));
        const reopen = async slot => {
          const ctx = await context(slot), id = bytes(data.sessions[slot]);
          if (data.wrongSession && slot === 1) id[0] ^= 1;
          return own(await owner.reopen_session(ctx.bundle,policy,ctx.required,sdk.QPeriaptContinuityRole.Initiator,id,at()));
        };
        const status = async id => {
          const s = own(await owner.account_message_status(id));
          return {phase:s.phase(),operation:[...s.operation_id()],abandonment:s.abandonment_id() === undefined ? null : [...s.abandonment_id()]};
        };
        if (data.action === 'activate') value = {journal:[...journal]};
        else if (data.action === 'establish') {
          const ctx = await context(data.slot), peer = own(await owner.admit_peer(ctx.bundle,policy,ctx.required,sdk.QPeriaptContinuityRole.Initiator,at()));
          const session = own(await owner.establish_session(peer,bytes(data.requestId),endpoint(data.slot),10000,at));
          value = {session:[...session.id()],journal:[...journal]};
        } else if (data.action === 'account-next') value = {operation:[...await owner.next_account_message_id()]};
        else if (data.action === 'account-status') value = {status:await status(bytes(data.operation))};
        else {
          const sessions = [await reopen(0),await reopen(1)];
          if (data.action === 'session-slots') {
            value = {messages: [ [...await owner.next_session_message_id(sessions[0],at())], [...await owner.next_session_message_id(sessions[1],at())] ]};
          } else {
            const targets = own(new sdk.QPeriaptContinuityAccountTargets());
            for (const slot of (data.targetSlots ?? [0,1])) targets.add(sessions[slot]);
            const id = bytes(data.operation);
            const input = own(new sdk.QPeriaptContinuityAccountMessage(id,bytes(cfg.account),new TextEncoder().encode(data.plaintext ?? 'all account devices'),new TextEncoder().encode('account/v1')));
            if (data.closePolicy) policy.close();
            if (data.closeInput) input.close();
            if (data.action === 'account-deliver') {
              const result = own(await owner.deliver_account_member(targets,input,data.invalidIndex ? invalidIndices.get(data.invalidIndex) : data.selected,endpoint(data.selected),10000,at));
              value = {device:[...result.device()],session:[...result.session()],message:[...result.message()],outcome:result.outcome(),exchanges:result.exchanges(),ownerClosed:owner.is_closed(),status:await status(id)};
            } else if (data.action === 'account-reconcile') {
              const members = own(await owner.reconcile_account_message(id,targets));
              let rejectedIndices = 0;
              for (const index of invalidIndices.values()) {
                let refusal;
                try { const unexpected = members.member(index); unexpected.free(); }
                catch (error) { refusal = error; }
                if (refusal?.code !== 'InvalidInput') throw Error('metadata index accepted invalid JS value');
                rejectedIndices += 1;
              }
              const rows = [];
              for (let index = 0; index < members.len(); ++index) {
                const member = own(members.member(index));
                rows.push({device:[...member.device()],session:[...member.session()],message:[...member.message()],phase:member.phase()});
              }
              value = {operation:[...members.operation_id()],members:rows,rejectedIndices,status:await status(id)};
            } else if (data.action === 'account-retire') {
              await owner.retire_account_message(id,targets); value = {status:await status(id)};
            } else if (data.action === 'unary') {
              const message = own(new sdk.QPeriaptContinuityMessage(bytes(data.message),new TextEncoder().encode('all account devices'),new TextEncoder().encode('account/v1')));
              const consumption = await owner.deliver_session_message(sessions[data.selected],message,endpoint(data.selected),10000,at);
              value = {consumption};
            } else throw Error('unknown account action');
          }
        }
      }
    }
  } catch (error) { failure = error; ownerClosed = owner?.is_closed(); }
  finally {
    if (owner) {
      try { await owner.close(); } catch (error) { cleanupErrors.push(String(error)); }
      try { owner.free(); } catch (error) { cleanupErrors.push(String(error)); }
    }
    for (const object of owned.reverse()) {
      try { if (typeof object.close === 'function') await object.close(); } catch (error) { cleanupErrors.push(String(error)); }
      try { object.free(); } catch (error) { cleanupErrors.push(String(error)); }
    }
  }
  if (failure || cleanupErrors.length) postMessage({done:true,error:String(failure ?? 'cleanup failure'),code:failure?.code,ownerClosed,cleanupErrors});
  else postMessage({done:true,value,cleanupErrors});
};
postMessage({ready:true});
