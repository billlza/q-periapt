from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
inputs = json.loads((stage / 'PLATFORM_INPUTS_03.json').read_text())
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'precheck source drift')
source = (stage / 'msrv.py').read_text().replace("stage / 'msrv-version'", "stage / 'msrv-version-02'").replace("stage / 'msrv-check'", "stage / 'msrv-check-02'")
exec(compile(source, str(stage / 'msrv.py'), 'exec'))
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'postcheck source drift')
