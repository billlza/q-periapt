from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
for name, digest in json.loads((stage / 'NATIVE_INPUTS_02.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'failed source changed')
    target = stage / 'failed-02' / name; target.parent.mkdir(parents=True, exist_ok=True); sdk.copy(root / name, target)
path = root / 'research/continuity-identity-candidate/src/session_exchange/tests/account.rs'
source = path.read_text()
needle = '    assert_eq!(repeat.message, original_messages[0]);'
sdk.require(source.count(needle) == 1, 'success guard assertion')
source = source.replace(needle, needle + '\n    assert!(group.sender.owner.parts().is_ok(), "retained successful outcome must keep owner active");')
path.write_text(source)
driver = (stage / 'check-native-02.py').read_text().replace('format-02','format-03').replace('NATIVE_INPUTS_02','NATIVE_INPUTS_03').replace('native-tests-02','native-tests-03').replace("'session_exchange::tests',", "'portable_account_commits_all_members_and_recovers_original_after_lost_reply',")
(stage / 'check-native-03.py').write_text(driver)
print('Precise retained-success owner assertion added; prior failure preserved')
