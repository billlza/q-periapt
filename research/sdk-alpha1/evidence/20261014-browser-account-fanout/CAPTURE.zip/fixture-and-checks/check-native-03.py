from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
binary = Path(env['RUSTC']).parent
tracked = subprocess.run(['git', 'diff', '--name-only'], cwd=root, check=True, capture_output=True).stdout.decode().splitlines()
new = ['research/continuity-identity-candidate/src/session_exchange/account.rs',
       'research/continuity-identity-candidate/src/session_exchange/tests/account.rs']
paths = sorted(set(name for name in tracked + new if name.endswith('.rs')))
sdk.command([str(binary / 'rustfmt'), '--edition', '2021', '--config', 'skip_children=true', *paths], stage / 'format-03', root, environment=env)
sdk.write_json(stage / 'NATIVE_INPUTS_03.json', {name: sdk.snapshot(root / name).sha256 for name in paths})
sdk.command([str(binary / 'cargo'), 'test', '--locked', '--offline', '--manifest-path',
    'research/continuity-identity-candidate/Cargo.toml', '--all-features', '--lib', 'portable_account_commits_all_members_and_recovers_original_after_lost_reply',
    '--target-dir', str(stage / 'native-target'), '-j', '2', '--', '--nocapture'], stage / 'native-tests-03', root, environment=env)
for name, digest in json.loads((stage / 'NATIVE_INPUTS_03.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'native test source drift')
print('Portable session and account transport regression suite passed')
