from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd()
base = root / 'research/continuity-identity-candidate/src'
path = base / 'connection_transport.rs'
source = path.read_text()
start = source.index('/// Authenticated cumulative consumption outcome for the original message ID.')
end = source.index('/// Client result after accepting a real session/epoch-specific consumption proof.', start)
source = source[:start] + 'pub use crate::session_exchange::{AccountDelivered, AccountDeliveryOutcome, Consumption};\n' + source[end:]
start = source.index("/// One member's exact outcome; no variant asserts remote atomic account delivery.")
end = source.index('/// The host owns its external transaction', start)
source = source[:start] + source[end:]
path.write_text(source)
path = base / 'connection_transport/client.rs'
source = path.read_text()
start = source.index('fn retained_outcome(')
end = source.index("struct Invocation<'a>", start)
source = source[:start] + 'use crate::session_exchange::account::retained_outcome;\n\n' + source[end:]
path.write_text(source)
path = base / 'durable/messages/fanout/archive.rs'
source = path.read_text()
start = source.index('        if !matches!(\n            batch.state,\n            BatchState::Committed(_) | BatchState::Abandoned(_)\n        ) {', source.index('pub async fn reconcile_members'))
end = source.index('    /// Irreversibly freeze every member', start)
block = source[start:end]
sdk.require(block.endswith('    }\n'), 'reconciliation boundary')
function = block[:-6].replace('        self.journal.check_release(&image).await?;\n', '')
function = '\n'.join(line[8:] if line.startswith('        ') else line for line in function.splitlines())
replacement = '''        let result = reconciliation(&image, &batch)?;
        self.journal.check_release(&image).await?;
        Ok(result)
    }
'''
source = source[:start] + replacement + source[end:]
source += '\n/// Metadata only; callers authenticate original bindings and check release.\npub(super) fn reconciliation(image: &Image, batch: &Batch) -> Result<FanoutReconciliation, DurableError> {\n' + function + '\n}\n'
path.write_text(source)
path = base / 'durable/messages/fanout.rs'
source = path.read_text()
position = source.index('    /// Read the next aggregate ID.')
source = source[:position] + '''    /// Read all original committed/accounted members without releasing bytes or
    /// committing a reservation. Original complete target bindings remain mandatory.
    pub async fn reconcile_fanout(
        &mut self,
        id: FanoutId,
        targets: &[FanoutTarget<'_>],
    ) -> Result<FanoutReconciliation, DurableError> {
        let image = self.image().await?;
        let batch = codec::get(&image, id)?;
        self.check_fanout_bindings(&image, &batch, targets)?;
        let result = archive::reconciliation(&image, &batch)?;
        self.check_release(&image).await?;
        Ok(result)
    }
''' + source[position:]
path.write_text(source)
print('Portable account delivery shares native outcomes and authenticated member reconciliation')
