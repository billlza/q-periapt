from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
files = {
    'browser-account.rs': 'research/continuity-identity-candidate/src/browser/connections/account.rs',
    'wasm-account.rs': 'crates/q-periapt-sdk-wasm/src/continuity/account.rs',
    'wasm-account-types.rs': 'crates/q-periapt-sdk-wasm/src/continuity/account/types.rs',
}
for original, destination in files.items():
    path = root / destination; path.parent.mkdir(parents=True, exist_ok=True)
    sdk.copy(stage / 'draft' / original, path)
for name, marker in (
    ('research/continuity-identity-candidate/src/browser/connections.rs', 'mod receiver;'),
    ('crates/q-periapt-sdk-wasm/src/continuity.rs', 'mod connections;'),
):
    path = root / name; source = path.read_text(); sdk.require(source.count(marker) == 1, 'module marker')
    path.write_text(source.replace(marker, 'mod account;\n' + marker))
exports = ['AccountTargets', 'AccountMessage', 'AccountPhase', 'AccountStatus', 'AccountOutcome', 'AccountDelivery', 'AccountMemberPhase', 'AccountMember', 'AccountMembers']
for name in ('index.js', 'index.d.ts'):
    path = root / 'crates/q-periapt-sdk-wasm/package/web' / name
    path.write_text(path.read_text() + '\nexport {\n  ' + ',\n  '.join('QPeriaptContinuity' + name for name in exports) + "\n} from './q_periapt_sdk_wasm.js';\n")
paths = ['research/continuity-identity-candidate/src/session_exchange/account.rs',
         'research/continuity-identity-candidate/src/session_exchange/tests/account.rs', *files.values()]
path = root / 'artifact/codeql_rust_quality.py'; source = path.read_text()
sdk.require(source.count('EXPECTED_TRACKED_RUST_SOURCE_COUNT = 648') == 1, 'Rust source baseline')
path.write_text(source.replace('EXPECTED_TRACKED_RUST_SOURCE_COUNT = 648', 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 653'))
path = root / 'ARTIFACT.md'; source = path.read_text(); sdk.require(source.count('648 tracked `.rs`') == 1, 'inventory documentation')
path.write_text(source.replace('648 tracked `.rs`', '653 tracked `.rs`'))
path = root / 'artifact/test_codeql_rust_quality.py'; source = path.read_text()
marker = '            "research/continuity-identity-candidate/src/browser/credentials/continuation.rs",'
sdk.require(source.count(marker) == 2, 'positive and missing sentinels')
source = source.replace(marker, marker + ''.join('\n            "' + name + '",' for name in paths))
path.write_text(source)
sdk.write_json(stage / 'NEW_RUST_FILES.json', paths)
print('Browser facade and typed WASM account API promoted; exact Rust inventory653')
