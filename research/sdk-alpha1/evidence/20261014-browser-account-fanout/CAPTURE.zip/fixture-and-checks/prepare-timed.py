from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
failed = json.loads((stage / 'run04/RESULT.json').read_text())
sdk.require(not failed['completed'] and 'Deadline' in failed['failure'], 'unexpected failed trace')
for path, digest in failed['producer'].items():
    sdk.require(sdk.snapshot(Path(path), maximum=256*1024**2).sha256 == digest, 'failed producer drift')
timeline = []
for path in sorted((stage / 'run04/peer/run04-worker-cut').glob('*')):
    if path.is_dir():
        row = json.loads((path / 'RECORD.json').read_text())
        row['request_mtime_ns'] = (path / 'request.bin').stat().st_mtime_ns
        row['reply_mtime_ns'] = (path / 'reply.bin').stat().st_mtime_ns
        row['request_to_reply_ms'] = (row['reply_mtime_ns'] - row['request_mtime_ns']) / 1e6
        timeline.append(row)
sdk.write_json(stage / 'DEADLINE_OBSERVATION.json', {
    'failed_run': 'run04', 'failure': failed['failure'], 'original_timeout_ms': 10000,
    'failed_action': failed['cases'][-1]['calls'][-1]['action'],
    'native_peer_records': timeline,
    'interpretation': 'Native receiver completed both bootstrap requests; browser invocation failed its overall deadline. Existing trace has no per-stage browser duration; current file mtimes are supporting observations, not monotonic execution measurements.',
    'next': 'Fresh cohort with original 10000ms bounds, browser/fixture monotonic durations and unchanged assertions.'})
worker = (stage / 'worker.js').read_text()
worker = worker.replace('let owner, value, failure, ownerClosed;', "let owner, value, failure, ownerClosed;\n  let phase = 'inputs'; const start = performance.now(); const phases = [];\n  const mark = name => { phases.push({phase:name,elapsedMs:performance.now()-start}); phase=name; };")
worker = worker.replace('owner = await sdk.QPeriaptContinuityDevice.open', "mark('open'); owner = await sdk.QPeriaptContinuityDevice.open")
worker = worker.replace("const journal = data.profile === 'local'", "mark('activate'); const journal = data.profile === 'local'")
worker = worker.replace('const session = own(await owner.establish_session', "mark('establish'); const session = own(await owner.establish_session")
worker = worker.replace("value = {session:[...session.id()]", "mark('established'); value = {session:[...session.id()]")
worker = worker.replace('const result = own(await owner.deliver_account_member', "mark('account-deliver'); const result = own(await owner.deliver_account_member")
worker = worker.replace('} catch (error) { failure = error;', "} catch (error) { mark('failed:' + phase); failure = error;")
worker = worker.replace('ownerClosed,cleanupErrors});', 'ownerClosed,cleanupErrors,timing:{phases,elapsedMs:performance.now()-start}});')
worker = worker.replace('value,cleanupErrors});', 'value,cleanupErrors,timing:{phases,elapsedMs:performance.now()-start}});')
(stage / 'worker-timed.js').write_text(worker)
server = (stage / 'server.py').read_text()
server = server.replace("with (folder / 'native.stdout').open('xb')", "started_ns = time.monotonic_ns()\n                with (folder / 'native.stdout').open('xb')")
server = server.replace("record = {'number': number, 'slot': slot", "record = {'native_elapsed_ms': (time.monotonic_ns() - started_ns) / 1e6, 'number': number, 'slot': slot")
(stage / 'server_timed.py').write_text(server)
driver = (stage / 'run-03.py').read_text()
driver = driver.replace('from server import serving', 'from server_timed import serving')
driver = driver.replace("for name in ('worker.js', 'controller.js'): shutil.copyfile(stage / name, web / 'creation' / name)", "for source, name in (('worker-timed.js','worker.js'), ('controller.js','controller.js')): shutil.copyfile(stage / source, web / 'creation' / name)")
driver = driver.replace("stage / 'worker.js', stage / 'controller.js', stage / 'server.py'", "stage / 'worker-timed.js', stage / 'controller.js', stage / 'server_timed.py'")
driver = driver.replace("'result': result})", "'result': result})")
(stage / 'run-05.py').write_text(driver)
print(json.dumps({'fresh_timed_driver': 'run-05.py', 'native_peer_durations_ms': [row['request_to_reply_ms'] for row in timeline]}))
