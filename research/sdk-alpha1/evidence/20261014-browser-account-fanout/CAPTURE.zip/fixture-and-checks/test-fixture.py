from pathlib import Path
import rust_sdk_profile as sdk
path = Path.cwd() / 'research/continuity-identity-candidate/src/session_exchange/tests.rs'
source = path.read_text().replace('mod control;', 'mod control;\nmod account;')
start = source.index('    fn new(policy: &VerifiedSessionPolicy) -> Self {')
end = source.index('    fn reopen(&mut self, policy:', start)
source = source[:start] + '''    fn new(policy: &VerifiedSessionPolicy) -> Self {
        Self::account(policy, 1).pop().expect("one registered device")
    }
    fn account(policy: &VerifiedSessionPolicy, count: u8) -> Vec<Self> {
        let root = RootSigningKey::generate().expect("account root");
        let mut staged = Vec::new();
        for index in 0..count {
            let dir = crate::durable::tests::directory();
            let base = dir.path().canonicalize().expect("path");
            let paths = paths(&base);
            drop(JournalKey::provision(&base.join("key")).expect("wrapping key"));
            let intent = EnrollmentIntent::new(
                root.public_key().expect("public root"),
                DeviceDescription::new([7 + index; 16], 1, policy.family(), crate::tests::interval()).expect("intent"),
            );
            let mut pending = DeviceEnrollment::provision(paths.clone(), intent.clone()).expect("provision");
            let request = pending.request(150).expect("request");
            let request = VerifiedEnrollmentRequest::verify(&request, &intent, 150).expect("verify request");
            let certificate = root.issue_enrollment(&request, 150).expect("issue");
            staged.push((dir, paths, intent, certificate, pending));
        }
        let entries = staged.iter().map(|(_, _, _, certificate, _)| root.roster_entry(certificate).expect("entry")).collect::<Vec<_>>();
        let roster = root.issue_roster(1, crate::tests::interval(), &entries).expect("complete roster");
        let pin = AccountPin::new(root.account_id().expect("account"), root.public_key().expect("root"), roster.checkpoint(), policy.family()).expect("pin");
        staged.into_iter().map(|(dir, paths, intent, certificate, mut pending)| {
            pending.accept(&certificate, roster.as_bytes(), &pin, policy, 150).expect("accept");
            pending.prepare(policy, 150).expect("prepare");
            let owner = pending.activate(policy, 150, None).expect("activate");
            Self { _dir: dir, paths, intent, certificate, roster: roster.as_bytes().to_vec(), pin: pin.clone(), owner }
        }).collect()
    }
''' + source[end:]
start = source.index('        let plan = PrekeyPublicationPlan::new(', source.index('impl Pair'))
end = source.index('        Self {\n            a,', start)
body = source[start:end]
sdk.require(body.rstrip().endswith('.expect("bundle");'), 'bundle fixture boundary')
source = source[:start] + '        let bundle = bundle(&a, &mut b, &policy);\n' + source[end:]
source += '\nfn bundle(a: &Device, b: &mut Device, policy: &Arc<VerifiedSessionPolicy>) -> BootstrapBundle {\n' + body.replace('&policy,', 'policy,') + '\n    bundle\n}\n'
path.write_text(source)
print('Shared enrollment and bundle fixtures support complete two-device accounts')
