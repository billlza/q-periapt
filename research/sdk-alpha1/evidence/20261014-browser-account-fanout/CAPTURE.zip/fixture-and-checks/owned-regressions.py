from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
inputs = json.loads((stage / 'PLATFORM_INPUTS_02.json').read_text())
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'regression source drift')
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None); env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
cargo = Path(env['RUSTC']).parent / 'cargo'
sdk.command([str(cargo), 'test', '--locked', '--offline', '--manifest-path', 'research/continuity-identity-candidate/Cargo.toml',
    '--all-features', '--test', 'owned_connection', '--target-dir', str(stage / 'native-target'), '-j', '2', '--', '--nocapture'],
    stage / 'regression-owned', root, environment=env)
counts = {}
for label in ('portable', 'fanout', 'owned'):
    log = (stage / ('regression-' + label + '.stdout')).read_text()
    values = re.findall(r'^test result: ok\. (\d+) passed; 0 failed;', log, re.MULTILINE)
    sdk.require(len(values) == 1 and int(values[0]) > 0, 'empty or unsuccessful suite: ' + label)
    counts[label] = int(values[0])
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'regression source drift')
sdk.write_json(stage / 'NATIVE_REGRESSIONS_VERIFIED.json', {'completed': True, 'counts': counts, 'inputs_unchanged': True,
    'excluded_attempt': {'log': 'regression-tls.stdout', 'tests': 0, 'reason': 'Incorrect library filter, not TLS validation; replaced by explicit owned_connection integration target'}})
print(json.dumps({'verified': True, 'tests': counts}))
