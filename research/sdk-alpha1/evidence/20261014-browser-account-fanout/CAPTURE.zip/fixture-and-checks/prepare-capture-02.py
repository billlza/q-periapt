from pathlib import Path
import json
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-fanout'
destination = root / 'research/sdk-alpha1/evidence/20261014-browser-account-fanout'
archive = destination / 'CAPTURE.zip'
sdk.require(not (destination / 'CHECKS.json').exists(), 'capture already finalized')
sdk.require(32*1024**2 < archive.stat().st_size < 64*1024**2, 'unexpected archive size')
with zipfile.ZipFile(archive) as content:
    sdk.require(content.testzip() is None, 'partial capture corrupt')
    count = len(content.namelist())
receipt = {'completed': False, 'phase': 'post-archive digest', 'archive_valid': True,
    'bytes': archive.stat().st_size, 'members': count,
    'cause': 'Capture exceeded the generic snapshot default of 32MiB; complete ZIP had already passed payload validation, but CHECKS was not written.',
    'repair': 'Use an explicit bounded 64MiB read for this capture; preserve the original archive and driver.'}
sdk.copy(stage / 'capture.py', stage / 'failed-capture-01.py')
destination.rename(stage / 'failed-capture-01')
sdk.write_json(stage / 'CAPTURE_FAILURE_01.json', receipt)
path = stage / 'capture.py'
path.write_text(path.read_text().replace('sdk.snapshot(archive).sha256', 'sdk.snapshot(archive, maximum=64*1024**2).sha256'))
path = stage / 'finalize.py'
path.write_text(path.read_text().replace("sdk.snapshot(root / destination / 'CAPTURE.zip').sha256", "sdk.snapshot(root / destination / 'CAPTURE.zip', maximum=64*1024**2).sha256"))
print(json.dumps(receipt))
