        def peer(self, case, slot, mode, data):
            if mode not in ('normal', 'drop-ack', 'after-effect', 'reject-effect', 'hold-peer') or not 10 <= len(data) <= 32768 or data[:8] != b'QPCXCH01':
                self.send_error(400); return
            if self.headers.get('Cookie') or self.headers.get('Authorization'):
                self.send_error(400); return
            directory = private / case / 'recipients' / str(slot)
            if not (directory / 'peer/PUBLIC.json').is_file(): self.send_error(404); return
            lock = locks.setdefault(case, threading.Lock())
            if not lock.acquire(blocking=False): self.send_error(503); return
            try:
                number = len(peers.get(case, [])) + 1
                folder = peer_traces / case / f'{number:03}'
                folder.mkdir(mode=0o700, parents=True)
                request = folder / 'request.bin'; reply = folder / 'reply.bin'
                with request.open('xb') as stream: stream.write(data)
                kind = data[8]; key = (case, slot, mode)
                trigger = kind == 3 and mode != 'normal' and key not in peer_faulted
                if trigger: peer_faulted.add(key)
                effect = mode if trigger and mode in ('after-effect', 'reject-effect') else 'normal'
                with (folder / 'native.stdout').open('xb') as out, (folder / 'native.stderr').open('xb') as err:
                    result = subprocess.run([str(peer_binary), 'handle', str(directory), str(request), str(reply), str(folder), effect],
                        stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=30, check=False)
                record = {'number': number, 'slot': slot, 'kind': kind, 'mode': mode, 'trigger': trigger,
                          'returncode': result.returncode, 'request_sha256': hashlib.sha256(data).hexdigest()}
                if result.returncode:
                    if effect not in ('after-effect', 'reject-effect') or 'Application' not in (folder / 'native.stderr').read_text():
                        raise ValueError('unexpected native peer failure: ' + case + '/' + str(number))
                    record['application_unconfirmed'] = True
                    peers.setdefault(case, []).append(record)
                    (folder / 'RECORD.json').write_text(json.dumps(record, indent=2) + '\n')
                    self.send_error(503); return
                body = reply.read_bytes()
                record.update(json.loads((folder / 'native.stdout').read_text()))
                record['reply_sha256'] = hashlib.sha256(body).hexdigest()
                peers.setdefault(case, []).append(record)
                (folder / 'RECORD.json').write_text(json.dumps(record, indent=2) + '\n')
            except Exception as error:
                failures.append(str(error)); self.send_error(500); return
            finally: lock.release()
            if trigger and mode in ('drop-ack', 'hold-peer'):
                if mode == 'hold-peer': time.sleep(7)
                self.close_connection = True; return
            self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.send_header('Content-Length', str(len(body))); self.end_headers()
            try: self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError) as error:
                failures.append('unexpected peer disconnect: ' + case + '/' + str(number) + ': ' + type(error).__name__)
