from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-fanout'
for name, digest in json.loads((stage / 'PLATFORM_INPUTS_01.json').read_text()).items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'lint source changed')
    target = stage / 'failed-lints-01' / name; target.parent.mkdir(parents=True, exist_ok=True); sdk.copy(root / name, target)
path = root / 'research/continuity-identity-candidate/src/session_exchange/tests/account.rs'
source = path.read_text()
replacements = {
    'self.recipients[0]': 'self.recipients.first().expect("first recipient")',
    '&mut self.recipients[selected].owner': '&mut self.recipients.get_mut(selected).expect("selected recipient").owner',
    '&self.remote[selected]': 'self.remote.get(selected).expect("selected remote session")',
    '&mut self.effects[selected]': 'self.effects.get_mut(selected).expect("selected effects")',
    'self.wires[selected]': 'self.wires.get_mut(selected).expect("selected wire history")',
    'group.effects[0]': 'group.effects.first().expect("first effects")',
    'group.recipients[0]': 'group.recipients.first().expect("first recipient")',
    'group.sessions[0]': 'group.sessions.first().expect("first session")',
    'original_messages[0]': '*original_messages.first().expect("first original message")',
    'original_messages[1]': '*original_messages.get(1).expect("second original message")',
    'group.wires[0][0]': 'group.wires.first().expect("first wire history").first().expect("original wire")',
    'group.wires[0][1]': 'group.wires.first().expect("first wire history").get(1).expect("replayed wire")',
    'group.wires[0]': 'group.wires.first().expect("first wire history")',
}
for before, after in replacements.items():
    sdk.require(before in source, 'expected indexed fixture expression: ' + before)
    source = source.replace(before, after)
source = source.replace('struct NoDispatch;', '#[derive(Default)]\nstruct NoDispatch { calls: usize }')
source = source.replace('panic!("invalid or already acknowledged aggregate must not dispatch")', 'self.calls += 1;\n        Err(io::Error::other("unexpected aggregate dispatch"))')
source = source.replace('    let repeat = group', '    let mut no_dispatch = NoDispatch::default();\n    let repeat = group')
source = source.replace('        let result = group.sender.owner.deliver_account_member(', '        let mut no_dispatch = NoDispatch::default();\n        let result = group.sender.owner.deliver_account_member(')
source = source.replace('&mut NoDispatch,', '&mut no_dispatch,')
source = source.replace('    assert_eq!(repeat.exchanges, 0);', '    assert_eq!(no_dispatch.calls, 0);\n    assert_eq!(repeat.exchanges, 0);')
source = source.replace('        assert!(result.is_err());', '        assert!(result.is_err());\n        assert_eq!(no_dispatch.calls, 0, "invalid target set dispatched");')
path.write_text(source)
path = root / 'research/continuity-identity-candidate/src/browser/connections/account.rs'
source = path.read_text()
for name, description in {
    'next_account_message_id': 'Observe the next journal-bound ID without reserving input or permission.',
    'account_message_status': 'Read original aggregate progress without releasing ciphertext.',
    'reconcile_account_message': 'Read every original committed/accounted member; reserved work stays suspended.',
    'retire_account_message': 'Retire only after all original members have authenticated or accounted outcomes.',
    'deliver_account_member': 'Commit the complete roster before one selected dispatch; retain the original input after failure.',
}.items():
    source = source.replace('    pub async fn ' + name, '    /// ' + description + '\n    pub async fn ' + name)
path.write_text(source)
source = (stage / 'check-platforms.py').read_text().replace('format-05','format-06').replace('PLATFORM_INPUTS_01','PLATFORM_INPUTS_02').replace('native-clippy-01','native-clippy-02')
(stage / 'check-platforms-02.py').write_text(source)
source = (stage / 'check-wasm.py').read_text().replace('PLATFORM_INPUTS_01','PLATFORM_INPUTS_02').replace('wasm-clippy-01','wasm-clippy-02')
(stage / 'check-wasm-02.py').write_text(source)
print('Fixture indexes checked explicitly; no-dispatch transport counts calls; public methods documented')
