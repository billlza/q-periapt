"""Public outcome, application-decision and disclosure readback; no private keys."""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys

root = Path.cwd()
out = root / 'target/independent-witness-01'
peer = root / 'research/continuity-openssl-peer'
sys.path.append(str(peer))
from provider import load_provider
from evidence_io import parse_strict_json_bytes
load_provider(root / 'target/independent-bootstrap-01/provider')
from fixture_inputs import load
from peer.rekey import RekeyScope, genesis
from peer.resolution import ciphertext_digest
from peer.traffic import message_id
from peer.wire import Reader

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(value, message):
    if not value:
        raise ValueError(message)

def parsed(path):
    return parse_strict_json_bytes(path.read_bytes(), label=str(path))

def worker(folder, name):
    return parsed(folder / (name + '.stdout'))['result']

def native_report_bytes(folder, name):
    raw = (folder / 'native/cases' / (name + '.output')).read_bytes()
    check(raw[0] == 1 and len(raw) <= 32768, 'native report frame')
    reader = Reader(raw[1:]); value = {'id': reader.take(32).hex()}
    for field in ('epoch', 'acknowledged_before', 'sent', 'consumed_before', 'received', 'peer_sent'):
        value[field] = reader.integer(8)
    count = reader.integer(2); check(count <= 64, 'outgoing count')
    value['outgoing'] = [{'id': reader.take(32).hex(), 'ciphertext_digest': reader.take(32).hex()} for _ in range(count)]
    count = reader.integer(2); check(count <= 64, 'incoming count'); value['incoming'] = []
    for _ in range(count):
        identity, index, length = reader.take(32), reader.integer(8), reader.integer(4)
        check(length <= 16384, 'plaintext bound')
        value['incoming'].append({'id': identity.hex(), 'index': index, 'plaintext': reader.take(length).hex()})
    count = reader.integer(2); check(count <= 128, 'skipped count')
    value['skipped'] = [reader.integer(8) for _ in range(count)]; reader.finish()
    return value

lanes = ['resolution', 'maximum', 'disclosure', 'capacity']
reports = {n: parsed(out / ('final-' + n) / 'RESULT.json') for n in lanes}
sources = reports['resolution']['source_files']
check(len(sources) == 55, 'source closure size')
expected_paths = [*sorted((peer / 'peer').glob('*.py')), *sorted(peer.glob('*.py')),
                  *sorted((peer / 'native/src').glob('*.rs')), peer / 'native/Cargo.toml',
                  peer / 'native/Cargo.lock', peer / 'requirements.txt']
check(set(sources) == {str(p.relative_to(peer)) for p in expected_paths}, 'source inventory differs')
for name, expected in sources.items():
    data = (peer / name).read_bytes()
    check(sha(data) == expected, 'source changed: ' + name)
    if name.endswith('.py'):
        ast.parse(data, name)
binary = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
check(binary[:4] == b'\xcf\xfa\xed\xfe' and int.from_bytes(binary[4:8], 'little') == 0x100000c, 'native ARM64')
for name, report in reports.items():
    folder = out / ('final-' + name)
    check(not (out / ('final-' + name + '.stderr')).read_bytes(), 'runtime diagnostics')
    check(report['source_files'] == sources, 'run source closure differs')
    if 'native_sha256' in report:
        check(sha(binary) == report['native_sha256'], 'native binary differs')
    for row in report['native_commands']:
        check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', row['case']), 'native case name')
        prefix = folder / 'native/cases' / row['case']
        before, after = prefix.with_suffix('.input').read_bytes(), prefix.with_suffix('.output').read_bytes()
        check(sha(before) == row['input_sha256'] and sha(after[1:]) == row['output_sha256']
              and after[0] == row['status'], 'native case integrity')
        if row['status'] == 2:
            check(after[1:].decode() == row['error'], 'native refusal bytes')
    for row in report.get('worker_operations', []):
        check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', row['case']), 'worker case name')
        request = parsed(folder / (row['case'] + '.request.json'))
        data = (folder / (row['case'] + '.stdout')).read_bytes()
        error = (folder / (row['case'] + '.stderr')).read_text()
        check(request['action'] == row['action'], 'worker operation binding')
        if 'signal' in row:
            check(row['signal'] == 'SIGKILL' and parse_strict_json_bytes(data, label=row['case']) == {'pid': row['worker_pid'], 'stage': row['cut']}
                  and not error, 'actual worker cut identity')
        elif 'refused' in row:
            check(not data and row['refused'] in error, 'worker refusal')
        else:
            check(sha(data) == row['stdout_sha256'] and not error, 'worker output')
    for decision in report.get('application_decisions', []):
        check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', decision['name']), 'application record name')
        artifact = parsed(folder / (decision['name'] + '.json'))
        canonical = (json.dumps(artifact['decision'], sort_keys=True, separators=(',', ':')) + '\n').encode()
        check(sha(canonical) == artifact['sha256'] == decision['sha256'] and len(canonical) == artifact['bytes'], 'application record identity')
        check(artifact['decision']['report_id'] == decision['report_id'], 'application report mapping')
        check(all(x['decision'] == 'delivery_unknown' for x in artifact['decision']['outgoing']), 'application invented delivery')
        check(all(x['decision'] == 'quarantined_without_application_effect' for x in artifact['decision']['incoming']), 'application manufactured old authenticity')
        if name == 'maximum':
            selected = parsed(folder / 'REPORT.json') if decision['role'] == 1 else native_report_bytes(folder, 'maximum-native-report')
        elif decision['role'] == 1:
            selected = report['resolution']
        else:
            selected = native_report_bytes(folder, 'native-report')
        check(artifact['decision']['outgoing'] == [dict(row, decision='delivery_unknown') for row in selected['outgoing']]
              and artifact['decision']['incoming'] == [dict(row, decision='quarantined_without_application_effect') for row in selected['incoming']]
              and artifact['decision']['skipped'] == selected['skipped'], 'application accounting lost report data')

folder = out / 'final-resolution'; r = reports['resolution']; result = r['resolution']
check(r['epochs'] == 6 and len(r['worker_operations']) == 99 and len(r['native_commands']) == 59
      and r['process_kills'] == 6 and r['codec_refusals'] == 10, 'resolution workload')
check(worker(folder, 'old-format') == 3 and worker(folder, 'upgrade-reconciled') == 4, 'explicit old format upgrade')
check(worker(folder, 'report-recovered') == worker(folder, 'report-replayed')
      == worker(folder, 'report-during-control') == worker(folder, 'application-decision-pending-report') == result,
      'immutable report across interruptions and control work')
check(worker(folder, 'uncommitted-freeze-status') == ['Unrequested', None], 'staging orphan became authority')
check(worker(folder, 'expired-report-status') == ['Pending', result['id']], 'expired status')
check(worker(folder, 'frozen-status') == 'ResolutionPending' and worker(folder, 'unknown-send') == 'DeliveryUnknown'
      and worker(folder, 'previously-acknowledged-send') == 'Acknowledged'
      and worker(folder, 'collected-old-send') == 'Retired', 'distinct outcome states')
check((folder / 'native/cases/native-unknown-send.output').read_bytes() == b'\1DeliveryUnknown'
      and (folder / 'native/cases/native-old-floor.output').read_bytes() == b'\1Acknowledged', 'native original floors/outcomes')
check([result[k] for k in ['epoch', 'acknowledged_before', 'sent', 'consumed_before', 'received', 'peer_sent']]
      == [0, 1, 4, 1, 4, 4] and result['skipped'] == [1], 'original report counters/holes')
session = (folder / 'native/cases/bootstrap-complete.output').read_bytes()[1:]
check(result['outgoing'] == [{'id': worker(folder, 'send-id-' + str(i)),
                              'ciphertext_digest': ciphertext_digest(bytes.fromhex(worker(folder, 'send-' + str(i)))).hex()} for i in (1, 2, 3)], 'actual outgoing frame digests')
check(result['incoming'] == [{'id': message_id(session, 2, 2).hex(), 'index': 2, 'plaintext': (bytes(range(256)) * 64).hex()}], 'retained old plaintext')
native_report = parsed(folder / 'native-report.report.json')
check(native_report == native_report_bytes(folder, 'native-report'), 'native report export differs')
check(native_report['outgoing'] == [{'id': (folder / ('native/cases/native-id-' + str(i) + '.output')).read_bytes()[1:].hex(),
    'ciphertext_digest': ciphertext_digest((folder / ('native/cases/native-send-' + str(i) + '.output')).read_bytes()[1:]).hex()} for i in (1, 2, 3)], 'native outgoing digests')
check(native_report['incoming'] == [{'id': worker(folder, 'send-id-2'), 'index': 2, 'plaintext': b'retained native plaintext'.hex()}], 'native retained plaintext')

signed = 0
for lane in ('resolution', 'disclosure'):
    folder = out / ('final-' + lane); r = reports[lane]
    _, _, context = load(folder / 'native/public', 150)
    session = (folder / 'native/cases/bootstrap-complete.output').read_bytes()[1:]
    flights = {}
    for step in r['control_steps']:
        check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', step['case']), 'control case name')
        if step['confirmed']:
            if step['side'] == 'python':
                check(worker(folder, step['case']) == [step['target'], None], 'local completion result')
            else:
                check((folder / 'native/cases' / (step['case'] + '.output')).read_bytes()
                      == b'\1\0' + step['target'].to_bytes(8, 'big'), 'native completion result')
            continue
        wire = (folder / (step['case'] + '.wire')).read_bytes()
        check(sha(wire) == step['wire_sha256'], 'control flight hash')
        if step['side'] == 'python':
            check(worker(folder, step['case']) == [step['target'], wire.hex()], 'control worker output')
        else:
            check((folder / 'native/cases' / (step['case'] + '.output')).read_bytes()
                  == b'\1\1' + step['target'].to_bytes(8, 'big') + wire, 'native control output')
        key = (step['target'], wire[4:12])
        check(key not in flights or flights[key] == wire, 'control replay replaced output')
        flights[key] = wire
    if lane == 'disclosure':
        for tag, wire in [(b'QPRKOF01', (folder / 'native/cases/original-offer-4.output').read_bytes()[1:]),
            (b'QPRKRP01', bytes.fromhex(worker(folder, 'same-offer-4-response'))),
            (b'QPRKFN01', (folder / 'native/cases/same-offer-4-final.output').read_bytes()[1:]),
            (b'QPRKRC01', bytes.fromhex(worker(folder, 'same-offer-4-receipt')))]:
            flights[(4, tag)] = wire
    parent = genesis(session, context.digest)
    for target in range(1, 7):
        scope = RekeyScope(context, session, target - 1, parent)
        if (target, b'QPRKRQ01') in flights:
            scope.open_request(flights[(target, b'QPRKRQ01')]); signed += 1
        parent = scope.public_completed(*(flights[(target, tag)] for tag in (b'QPRKOF01', b'QPRKRP01', b'QPRKFN01', b'QPRKRC01')))
        signed += 4

folder = out / 'final-maximum'; r = reports['maximum']; maximum = parsed(folder / 'REPORT.json')
check(r['incoming_messages'] == r['native_unknown_outgoing'] == 64 and r['retained_plaintext_bytes'] == 1048576
      and len(r['native_commands']) == 138 and len(r['worker_operations']) == 4, 'maximum workload')
check(len(maximum['incoming']) == 64 and not maximum['outgoing'] and not maximum['skipped']
      and maximum['consumed_before'] == 0 and maximum['received'] == maximum['peer_sent'] == 64, 'maximum report shape')
session = (folder / 'native/cases/bootstrap-complete.output').read_bytes()[1:]
for i, row in enumerate(maximum['incoming']):
    check(row == {'id': message_id(session, 2, i).hex(), 'index': i, 'plaintext': (bytes([i]) * 16384).hex()}, 'maximum plaintext bytes')
native_report = parsed(folder / 'maximum-native-report.report.json')
check(native_report == native_report_bytes(folder, 'maximum-native-report'), 'maximum native export differs')
check(len(native_report['outgoing']) == 64, 'maximum native inventory')
for i, row in enumerate(native_report['outgoing']):
    wire = (folder / ('native/cases/native-send-' + str(i) + '.output')).read_bytes()[1:]
    check(row == {'id': message_id(session, 2, i).hex(), 'ciphertext_digest': ciphertext_digest(wire).hex()}, 'maximum native frame commitment')

folder = out / 'final-disclosure'; r = reports['disclosure']; result = r['resolution']
check(r['epochs'] == 6 and len(r['worker_operations']) == 51 and len(r['native_commands']) == 42, 'disclosure workload')
check(r['disclosed'] == ['epoch-zero send chain after original message zero'] and r['forged_indices'] == [1, 2], 'finite disclosure scope')
check((folder / 'native/cases/forged-consume-2.output').read_bytes()[-40:-32] == (3).to_bytes(8, 'big'), 'actual poisoned ACK floor')
check(result['sent'] == 1 and result['acknowledged_before'] == 0 and len(result['outgoing']) == 1, 'honest unresolved range')
wire = bytes.fromhex(worker(folder, 'genuine-send-send'))
check(result['outgoing'] == [{'id': worker(folder, 'genuine-send-id'), 'ciphertext_digest': ciphertext_digest(wire).hex()}], 'original honest outbox')
check(worker(folder, 'original-outbox-retained') == wire.hex() and worker(folder, 'honest-unknown-status') == 'DeliveryUnknown', 'no forged success')
check((folder / 'native/cases/original-offer-4.output').read_bytes() == (folder / 'native/cases/native-replay-original-offer.output').read_bytes(), 'native original offer persistence')
request = parsed(folder / 'same-offer-4-response.request.json')
check(bytes.fromhex(request['arguments'][0]) == (folder / 'native/cases/original-offer-4.output').read_bytes()[1:], 'resumed same offer')
check(worker(folder, 'independent-4-confirmed') == [4, 4, 4, 0] and worker(folder, 'collected-unknown-status') == 'Retired', 'bounded history progress')

r = reports['capacity']; folder = out / 'final-capacity'; resolution = parsed(folder / 'RESOLUTION.json')
check(r['full_capacity_resolution_messages'] == 64 and r['resolution_callbacks_close_without_release']
      and r['resolution_original_floor'] == 0 and r['resolution_preserves_current_outbox'], 'full business-capacity resolution')
check(len(resolution['outgoing']) == 64 and resolution['sent'] == 64 and resolution['acknowledged_before'] == 0, 'capacity original counts')
decision = parsed(folder / 'APPLICATION_DECISION.json')
canonical = (json.dumps(decision['decision'], sort_keys=True, separators=(',', ':')) + '\n').encode()
check(sha(canonical) == decision['sha256'] and len(canonical) == decision['bytes']
      and decision['decision']['report_id'] == resolution['id']
      and decision['decision']['outgoing'] == [dict(row, decision='delivery_unknown') for row in resolution['outgoing']], 'full-capacity application decision')
summary = {'base_head': '01ac1354f3de65fe9651ef67af2c71597d849085', 'source_files': sources,
           'native_sha256': sha(binary), 'native_architecture': 'MachO64 ARM64',
           'resolution': {'epochs': 6, 'workers': 99, 'native_commands': 59, 'kills': 6, 'codec_refusals': 10},
           'maximum': {'messages': 64, 'plaintext_bytes': 1048576, 'native_commands': 138},
           'disclosure': {'epochs': 6, 'workers': 51, 'native_commands': 42, 'honest_sent': 1, 'poisoned_ACK_floor': 3},
           'signed_controls_rechecked': signed, 'full_capacity_outbox_resolution': 64,
           'scope': 'Public bytes, signatures, counters, original IDs, application-record hashes and PID cuts. Secret report MACs/AEAD, direct-host cleanup/input refusals and full-capacity ciphertext digests remain runtime assertions. No private keys/images loaded; no physical erasure, hardware power-loss, global application atomicity or PCS proof.'}
(out / 'RESOLUTION_READBACK.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k not in ('source_files', 'scope')}))
