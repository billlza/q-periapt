"""Verify public input bytes, native importer receipts and fixed source identities."""
from pathlib import Path
import hashlib,json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;peer=out/'source';base=out/'public/public-inputs'
sys.path.extend([str(peer),str(out)])
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from source_readback import normalized
from fixture_inputs import load,load_witness_pin
from peer.wire import Reader,require
from peer.bootstrap_bundle import BootstrapBundle
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):return json.loads(path.read_text())
top=read(base/'RESULT.json');normalized(top['source_files']);require(len(top['source_files'])==99,'source closure')
for name,field in [('counterpart','native_sha256'),('importer','importer_sha256')]:
 b=(out/'public'/name).read_bytes();require(sha(b)==top[field]and b[:6]==b'\x7fELF\x02\x01'and int.from_bytes(b[18:20],'little')==62,'exact x86_64 ELF executable')
require(not (out/'public/public-inputs.stderr').read_bytes(),'runtime diagnostics');profiles={}
for label in ['local','witness']:
 folder=base/label;r=read(folder/'RESULT.json');public=folder/'native/public'
 pin=load_witness_pin(public)if label=='witness'else None
 pins,materials,expected=load(public,150,witness_pin=pin);bundle=(folder/'bundle.bin').read_bytes()
 require(len(bundle)==r['bundle_bytes']==r['every_truncation_refused']==22980 and sha(bundle)==r['bundle_sha256'],'exact public bundle identity')
 decoder=Reader(bundle);require(decoder.take(9)==b'QPBNDL01\2','reusable exact header')
 for name in ['i-credential','i-roster','r-credential','r-roster','manifest','proof-1','proof-3']:
  size=decoder.integer(2);require(0<size<=8192 and decoder.take(size)==(public/name).read_bytes(),'original exact signed field '+name)
 require(decoder.take(4)==bytes(4),'absent optional proofs');decoder.finish()
 snapshot=BootstrapBundle(bundle).verify_original(pins,materials.sdk_document,materials.sdk_signature,materials.policy,401,original_context=expected.digest,required_quality=2,witness_pin=pin)
 require(snapshot==expected and expected.digest.hex()==r['context']==top[label]['context'],'exact original signed snapshot')
 require((public/'expected-context').read_bytes()==expected.digest,'native/independent context agreement')
 cases={}
 for row in r['native_imports']:
  name=row['case'];require(name not in cases,'duplicate importer case');cases[name]=row
  b=(folder/(name+'.bundle')).read_bytes();stdout=(folder/(name+'.stdout')).read_bytes();stderr=(folder/(name+'.stderr')).read_bytes()
  require(sha(b)==row['input_sha256']and sha(stdout)==row['stdout_sha256']and sha(stderr)==row['stderr_sha256'],'raw importer receipt')
  require(Path(row['command'][0]).name=='importer'and Path(row['command'][2]).name==name+'.bundle','actual input command')
  if name=='native-valid':require(row['exit']==0 and not stderr and stdout.strip().decode()==r['context'],'actual native successful context')
  else:
   expected_error='Scope'if name=='native-wrong-quality'else('Validity'if name=='native-expired-advertisement'else'Authentication')
   require(row['exit']==1 and not stdout and stderr==('Error: '+expected_error+'\n').encode(),'native exact typed error withholds result')
 require(set(cases)=={'native-valid','native-wrong-quality','native-expired-advertisement',*('native-tampered-'+str(i)for i in range(7))},'native import coverage')
 names={row['case']for row in r['refusals']};require(len(names)==len(r['refusals']),'unique Python refusals')
 required={'future-original','wrong-original-context','wrong-directory','current-advertisement-expiry','expired-historical-snapshot-not-new-bootstrap',*('historical-tampered-'+str(i)for i in range(7))}
 require(required<=names,'historical/current split controls')
 require(('expired-original-cannot-create-session'in names and 'missing-active-state-is-not-first-use'in names)if label=='local'else 'expired-original-cannot-provision'in names,'actual store creation refusals')
 require(not (folder/'native/native.stderr').read_bytes(),'native fixture diagnostics')
 profiles[label]={'bundle_bytes':len(bundle),'native_imports':len(cases),'current_native_success':1,'native_refusals':9,'independent_refusals':len(names),'all_truncation_count_observed':r['every_truncation_refused'],'context':r['context']}
report={'head':'f7a79e80b0e76f797072d76b3b659768d7628ef8','source_files':top['source_files'],'native_sha256':top['native_sha256'],'importer_sha256':top['importer_sha256'],'profiles':profiles,
 'scope':'Exact frozen Python/public bytes/native ARM64 executable and actual native import command results. Historical signature/pin/scope reconstructed; operational permission refusals and unchanged empty private directories remain runtime observations. No live native runtime owner, account enrollment, installed network service or full lifecycle claim.'}
(out/'PUBLIC_INPUTS_READBACK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(profiles))
