"""Resolve the observed encapsulation producer and restore the full snapshot tree."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root=Path.cwd()
parent=root/'target/p0-origin-wire-role-chains-712'
terminal=json.loads((parent/'wire-role-chains-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out'] and not terminal['accepted']
assert not (parent/'initial-send-oracle.failed').exists()
source=parent/'wire-role-chains-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest()==terminal['output_sha256']
value=source.read_text()
start=value.index('lemma epoch_generation_secret_derivation_origin ')
stop=value.index('\nlemma ',start)
main=value[start:stop]
pattern=re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks={m[1]:m[0] for m in pattern.finditer(main)}
assert len(blocks)==18 and main.count('by sorry')==2
assert {n for n,b in blocks.items() if 'by sorry' in b}=={'Response_Commit_6','Snapshot_case_5'}
row=json.loads((parent/'initial-send-oracle-frames/0015.json').read_text())
raw=(parent/'initial-send-oracle-frames'/row['captured_input']).read_bytes()
assert not row['ranking'] and hashlib.sha256(raw).hexdigest()==row['input_sha256']
goals=re.findall(r"(?m)^\d+: (PositionedPhaseState\( .*?'Response4'.*?\)\[no_precomp\] ▶₀ #vr\.3)$",raw.decode())
assert len(goals)==1 and 'kempk(x), coins' in goals[0]
marker='by sorry /* Oracle ranked no proof methods */'
assert blocks['Response_Commit_6'].count(marker)==1
main=main.replace(blocks['Response_Commit_6'],blocks['Response_Commit_6'].replace(marker,'by solve( '+goals[0]+' )',1),1)
full=root/'target/p0-origin-field-producers-712/field-producers-proof.spthy'
assert hashlib.sha256(full.read_bytes()).hexdigest()=='f330bf0345a334cddc965c6783bc16e3f88639d9ec2e040cc19b539557f265f6'
full_text=full.read_text()
full_main=full_text.split('lemma epoch_generation_secret_derivation_origin ',1)[1].split('\nlemma ',1)[0]
snapshot=next(m[0] for m in pattern.finditer(full_main) if m[1]=='Snapshot_case_5')
preserved=json.loads((root/'target/p0-origin-wire-producers-712/PREPARATION.json').read_text())
assert snapshot.count('by sorry')==36 and hashlib.sha256(snapshot.encode()).hexdigest()==preserved['full_snapshot_subtree_sha256']
main=main.replace(blocks['Snapshot_case_5'],snapshot,1)
candidate=value[:start]+main+value[stop:]
candidate=candidate.replace(marker,'by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',full_text)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-restored-replay-712'
stage.mkdir()
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'response_frame':row['captured_input'],'response_frame_sha256':row['input_sha256'],
    'response_phase_producer_method':goals[0],
    'all29_queries_and_operational_prefix_unchanged':True,'all18_sources_retained':True,
    'full_snapshot_subtree_restored_byte_identical':True,'snapshot_subtree_sha256':hashlib.sha256(snapshot.encode()).hexdigest(),
    'snapshot_open_leaves_restored':36,'independent_no_search_replay':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'snapshot_open_leaves_restored':36,'response_goal_observed':True}))
