"""Capture only the remaining leaves of the checked 175-step origin tree."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

root = Path.cwd()
source = root / 'target/p0-origin-payload-wire-chain-replay-711/payload-wire-chain-proof.spthy'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b0bea9b7e94e2f9da23f4cd9cd2ba58ec95f5fc0e3d109532c7cc9b71d0729f8'
checkpoint = root / 'research/sdk-alpha1/evidence/20261028-storage-revision-payload'
manifest = json.loads((checkpoint / 'CAPTURE.json').read_text())
assert hashlib.sha256((checkpoint / 'CAPTURE.zip').read_bytes()).hexdigest() == '00e01eefdd10f2d96bd98d136513a136834c8be61f1dc5505342952e1395395b'
with zipfile.ZipFile(checkpoint / 'CAPTURE.zip') as bundle:
    assert bundle.read(manifest['entry']) == data
text = data.decode()
main = text.split('lemma epoch_generation_secret_derivation_origin ', 1)[1].split('\nlemma ', 1)[0]
cases = dict(re.findall(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)', main))
assert len(cases) == 18 and sum('by sorry' not in v for v in cases.values()) == 14
assert main.count('by sorry') == 32 and 'invalid proof step' not in text
assert hashlib.sha256(text[:text.index('lemma ')].encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage = root / 'target/p0-origin-open-fields-712'
stage.mkdir()
(stage / 'model.spthy').write_bytes(data)
base = root / 'target/p0-origin-source-frontiers-705'
for name in ('run.py', 'initial-send-oracle.py', 'initial-send-oracle.sh'):
    shutil.copy2(base / name, stage / name)
driver = stage / 'run.py'
assert driver.read_text().count('--bound=13') == 1
driver.write_text(driver.read_text().replace('--bound=13', '--bound=11'))
shell = stage / 'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(base), str(stage)))
(stage / 'initial-send-oracle-frames').mkdir()
record = {'input_sha256': hashlib.sha256(data).hexdigest(),
    'input_byte_identical_to_checked_entry': True, 'all18_sources_and29_queries_retained': True,
    'closed_sources': 14, 'initial_open_leaves': 32, 'existing_prefix_maximum': 5,
    'remaining_search_bound': 11, 'total_depth_limit': 16, 'oracle_callback_limit': 32,
    'oracle_selects_no_search_step': True, 'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
