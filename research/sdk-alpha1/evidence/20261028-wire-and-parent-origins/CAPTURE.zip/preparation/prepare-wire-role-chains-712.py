"""Resolve only recorded role frontiers; retain all unvisited siblings."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root=Path.cwd()
parent=root/'target/p0-origin-wire-shape-chains-712'
terminal=json.loads((parent/'wire-shape-chains-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out'] and not terminal['accepted']
source=parent/'wire-shape-chains-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest()==terminal['output_sha256']
value=source.read_text()
start=value.index('lemma epoch_generation_secret_derivation_origin ')
stop=value.index('\nlemma ',start)
main=value[start:stop]
pattern=re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks={m[1]:m[0] for m in pattern.finditer(main)}
marker='by sorry /* Oracle ranked no proof methods */'
assert len(blocks)==18 and main.count('by sorry')==12 and main.count(marker)==4
frames=[]
for f in sorted((parent/'initial-send-oracle-frames').glob('*.json')):
    row=json.loads(f.read_text());raw=(f.parent/row['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha256']
    if not row['ranking']:frames.append((row,raw.decode()))
assert len(frames)==4
records=[]
for index,name in enumerate(('Final_Commit_8','Receipt_Commit_0','Response_Commit_6')):
    row,text=frames[index]
    if index<2:
        goals=re.findall(r"(?m)^\d+:\s+(\(([a-zA-Z0-9.]+) = 'A'\)\s+∥ \(\2 = 'B'\))$",text)
        assert len(goals)==1,(name,goals)
        method=goals[0][0]
    else:
        goals=re.findall(r'(?m)^\d+: (!Wrap\( ~sid, r, wrapping\.3 \)\[no_precomp\] ▶₂ #vr)$',text)
        assert len(goals)==1,(name,goals)
        method=goals[0]
    assert blocks[name].count(marker)==1
    updated=blocks[name].replace(marker,'by solve( '+method+' )',1)
    assert updated.count('by sorry')==blocks[name].count('by sorry')-1
    main=main.replace(blocks[name],updated,1)
    records.append({'source':name,'frame':row['captured_input'],'sha256':row['input_sha256'],'method':method})
main=main.replace(marker,'by sorry')
assert main.count('by sorry')==9
candidate=value[:start]+main+value[stop:]
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-wire-role-chains-712'
stage.mkdir()
(stage/'model.spthy').write_text(candidate)
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):
    shutil.copy2(parent/name,stage/name)
driver=stage/'run.py'
assert driver.read_text().count('--bound=12')==1
driver.write_text(driver.read_text().replace('--bound=12','--bound=7'))
shell=stage/'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(parent),str(stage)))
(stage/'initial-send-oracle-frames').mkdir()
record={'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'actual_role_methods':records,'unvisited_sibling_leaves_retained':8,
    'snapshot_obligation_explicitly_open_and_full_subtree_preserved':True,
    'all29_queries_and_operational_prefix_unchanged':True,'all18_source_cases_retained':True,
    'existing_open_prefix_upper_bound':9,'remaining_bound':7,'total_depth_limit':16,'oracle_callback_limit':32,
    'oracle_policy_unchanged':'Only unique observed knowledge-chain goals; otherwise retain the frontier.',
    'restore_full_snapshot_subtree_before_final_replay':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'methods':len(records),'unvisited_siblings_retained':8}))
