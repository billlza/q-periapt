"""Use actual wire producers instead of generic optional-tag decompositions.

The unclosed snapshot proof is retained in the checked parent. This diagnostic
keeps that same obligation explicitly open, so capture remains within32calls.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-field-producers-712'
terminal = json.loads((parent / 'field-producers-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
source = parent / 'field-producers-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
pattern = re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks = {match[1]: match[0] for match in pattern.finditer(main)}
assert len(blocks) == 18 and sum('by sorry' not in b for b in blocks.values()) == 14
assert blocks['Snapshot_case_5'].count('by sorry') == 36
frames = root / 'target/p0-origin-storage-frontiers-711/initial-send-oracle-frames'
methods = []
for index, name in [(0, 'Final_Commit_8'), (2, 'Receipt_Commit_0'), (3, 'Response_Commit_6')]:
    row = json.loads((frames / f'{index:04}.json').read_text())
    raw = (frames / row['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['input_sha256']
    observed = re.findall(r'(?m)^\d+: (PositionedPhaseState\( .*?\)\[no_precomp\] ▶₀ #vr)$', raw.decode())
    assert len(observed) == 1, (name, observed)
    main = main.replace(blocks[name], f'    case {name}\n    by solve( {observed[0]} )\n', 1)
    methods.append({'case': name, 'frame': row['captured_input'], 'sha256': row['input_sha256'], 'method': observed[0]})
main = main.replace(blocks['Snapshot_case_5'], '    case Snapshot_case_5\n    by sorry\n', 1)
candidate = value[:start] + main + value[stop:]
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', candidate) == re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage = root / 'target/p0-origin-wire-producers-712'
stage.mkdir()
(stage / 'model.spthy').write_text(candidate)
base = root / 'target/p0-origin-source-frontiers-705'
for name in ('run.py', 'initial-send-oracle.py', 'initial-send-oracle.sh'):
    shutil.copy2(base / name, stage / name)
shell = stage / 'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(base), str(stage)))
(stage / 'initial-send-oracle-frames').mkdir()
record = {'parent_sha256': terminal['output_sha256'], 'input_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'observed_wire_producer_methods': methods, 'all29_queries_and_operational_prefix_unchanged': True,
    'all18_source_cases_retained': True, 'all14_closed_sources_retained': True,
    'snapshot_obligation_remains_open': True,
    'full_snapshot_subtree_preserved_in_parent': str(source),
    'full_snapshot_subtree_sha256': hashlib.sha256(blocks['Snapshot_case_5'].encode()).hexdigest(),
    'snapshot_subtree_must_be_restored_before_final_full_tree_replay': True,
    'purpose': 'Avoid repeated generic optional-tag splits; trace the actual producers of final/receipt/response outputs.',
    'existing_open_prefix_maximum': 3, 'remaining_search_bound': 13, 'total_depth_limit': 16,
    'oracle_capture_limit': 32, 'capture_selects_no_search_step': True, 'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'input_sha256': record['input_sha256'], 'parent_sha256': record['parent_sha256'], 'wire_methods': len(methods)}))
