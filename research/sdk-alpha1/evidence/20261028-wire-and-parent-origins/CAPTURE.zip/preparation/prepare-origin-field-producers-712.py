"""Check observed projection chains and the actual parent/tag phase producers."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-open-fields-712'
terminal = json.loads((parent / 'open-fields-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
assert not (parent / 'initial-send-oracle.failed').exists()
source = parent / 'open-fields-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
assert 'invalid proof step' not in value
frames = sorted((parent / 'initial-send-oracle-frames').glob('*.json'))
assert len(frames) == main.count('by sorry') == 29
methods, records = [], []
for frame in frames:
    row = json.loads(frame.read_text())
    raw = (frame.parent / row['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['input_sha256']
    text = raw.decode()
    chains = re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$', text)
    assert len(chains) <= 1
    if chains:
        method = chains[0]
        reason = 'Continue the unique observed projection chain to the claimed knowledge event.'
    else:
        phase = re.findall(r'(?m)^\d+: (PositionedPhaseState\( .*?\)\[no_precomp\] ▶₀ #vr(?:\.[0-9]+)?)$', text)
        assert len(phase) == 1, (frame.name, phase)
        method = phase[0]
        reason = 'Inspect the actual producer of the saved parent or outgoing confirmation tag; leave the generation event premise untouched.'
    methods.append(method)
    records.append({'frame': row['captured_input'], 'sha256': row['input_sha256'], 'method': method, 'reason': reason})
iterator = iter(methods)
main, count = re.subn(r'by sorry(?: /\* Oracle ranked no proof methods \*/)?',
                      lambda _: 'by solve( ' + next(iterator) + ' )', main)
assert count == len(methods) and next(iterator, None) is None
candidate = value[:start] + main + value[stop:]
candidate = candidate.replace('by sorry /* Oracle ranked no proof methods */', 'by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', candidate) == re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage = root / 'target/p0-origin-field-producers-712'
stage.mkdir()
(stage / 'model.spthy').write_text(candidate)
shutil.copy2(root / 'target/p0-wire-scope-replay-704/run.py', stage / 'run.py')
record = {'parent_sha256': terminal['output_sha256'], 'input_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'all29_queries_and_operational_prefix_unchanged': True,
    'methods_in_callback_and_generated_leaf_order': records,
    'phase_methods': sum('PositionedPhaseState' in m for m in methods),
    'chain_methods': sum('~~>' in m for m in methods),
    'mapping_must_be_checked_by_independent_replay': True,
    'no_search_or_oracle_in_replay': True, 'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key:record[key] for key in ('input_sha256','phase_methods','chain_methods')}))
