"""Bind actual wire producers to the proved wire shape, then follow unique chains."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-wire-producers-712'
terminal = json.loads((parent / 'wire-producers-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
source = parent / 'wire-producers-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
blocks = {m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)', main)}
assert len(blocks) == 18 and main.count('by sorry') == 4
frames = parent / 'initial-send-oracle-frames'
records = []
for index, name in enumerate(('Final_Commit_8','Receipt_Commit_0','Response_Commit_6')):
    row = json.loads((frames / f'{index:04}.json').read_text())
    raw = (frames / row['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['input_sha256']
    goals = [line.split(': ',1)[1].strip() for line in raw.decode().splitlines()]
    shapes = [g for g in goals if g.startswith('(∃ context') and 'h(material)' in g and 'sign(' in g]
    assert len(shapes) == 1 and blocks[name].count('by sorry') == 1
    replacement, count = re.subn(r'by sorry(?: /\* Oracle ranked no proof methods \*/)?', 'by solve( ' + shapes[0] + ' )', blocks[name])
    assert count == 1
    main = main.replace(blocks[name], replacement,1)
    records.append({'case':name,'frame':row['captured_input'],'sha256':row['input_sha256'],'method':shapes[0]})
candidate = value[:start] + main + value[stop:]
candidate = candidate.replace('by sorry /* Oracle ranked no proof methods */','by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-wire-shape-chains-712'
stage.mkdir()
(stage/'model.spthy').write_text(candidate)
base=root/'target/p0-origin-source-frontiers-705'
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):
    shutil.copy2(base/name,stage/name)
driver=stage/'run.py'
driver.write_text(driver.read_text().replace('--bound=13','--bound=12'))
shell=stage/'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(base),str(stage)))
oracle=stage/'initial-send-oracle.py'
old=oracle.read_text()
old=old.replace('Capture bounded open proof frontiers; deliberately select no search step.', 'Rank only a unique actual knowledge-chain goal; otherwise stop and retain the frontier.')
anchor="    with (stage / 'initial-send-oracle.lock').open('a') as lock:"
assert old.count(anchor)==1
old=old.replace(anchor,"    chain_goals = [int(match[1]) for match in matches if re.fullmatch(r'\\(#[a-zA-Z0-9.]+, 0\\) ~~> \\(#known, 0\\)', match[2])]\n    ranking = chain_goals if len(chain_goals) == 1 else []\n"+anchor)
old=old.replace("'ranking': [], 'diagnostic_stop': True,", "'ranking': ranking, 'diagnostic_stop': not ranking,")
old=old.replace("'stop_reason': 'frontier-capture-no-search'", "'stop_reason': 'unique-observed-chain' if ranking else 'no-unique-chain'")
line="        (stage / 'initial-send-oracle.diagnostic-stop').write_text('frontier-capture-no-search\\n')"
assert old.count(line)==1
old=old.replace(line,"        if ranking:\n            print(ranking[0])\n        else:\n            (stage / 'initial-send-oracle.diagnostic-stop').write_text('no-unique-chain\\n')")
oracle.write_text(old)
compile(old,str(oracle),'exec')
(stage/'initial-send-oracle-frames').mkdir()
record={'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
        'recorded_wire_shape_methods':records,'all29_queries_and_operational_prefix_unchanged':True,
        'oracle_policy':'At most one ranked method, only the unique actual chain to #known. Every callback and selected index retained. No chain means an explicit partial leaf;32callback ceiling unchanged.',
        'oracle_sha256':hashlib.sha256(old.encode()).hexdigest(),'existing_open_prefix_maximum':4,'remaining_bound':12,'total_depth_limit':16,
        'snapshot_full_subtree_remains_in_checked223step_parent':True,'must_restore_snapshot_before_independent_final_replay':True,
        'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'oracle_sha256':record['oracle_sha256'],'shape_steps':len(records)}))
