"""Check remaining public-role goals and restore the complete stored subtree."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root=Path.cwd()
parent=root/'target/p0-origin-wire-shape-chains-712'
terminal=json.loads((parent/'wire-shape-chains-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out'] and not terminal['accepted']
assert not (parent/'initial-send-oracle.failed').exists()
source=parent/'wire-shape-chains-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest()==terminal['output_sha256']
value=source.read_text()
start=value.index('lemma epoch_generation_secret_derivation_origin ')
stop=value.index('\nlemma ',start)
main=value[start:stop]
blocks={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(blocks)==18 and main.count('by sorry')==4
frames=[]
for f in sorted((parent/'initial-send-oracle-frames').glob('*.json')):
    row=json.loads(f.read_text());raw=(f.parent/row['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha256']
    if not row['ranking']:frames.append((row,raw.decode()))
assert len(frames)==4
records=[]
for index,name in enumerate(('Final_Commit_8','Receipt_Commit_0','Response_Commit_6')):
    row,text=frames[index]
    if index<2:
        goals=re.findall(r"(?m)^\d+:\s+(\(([a-zA-Z0-9.]+) = 'A'\)\s+∥ \(\2 = 'B'\))$",text)
        assert len(goals)==1,(name,goals)
        method=goals[0][0]
        reason='Use the observed public A/B role disjunction.'
    else:
        goals=re.findall(r'(?m)^\d+: (!Wrap\( ~sid, r, wrapping\.3 \)\[no_precomp\] ▶₂ #vr)$',text)
        assert len(goals)==1,(name,goals)
        method=goals[0]
        reason='Resolve the observed original Wrap premise to constrain the response sender role.'
    assert blocks[name].count('by sorry')==1
    updated,count=re.subn(r'by sorry(?: /\* Oracle ranked no proof methods \*/)?', 'by solve( '+method+' )',blocks[name])
    assert count==1
    main=main.replace(blocks[name],updated,1)
    records.append({'source':name,'frame':row['captured_input'],'sha256':row['input_sha256'],'method':method,'reason':reason})
full=root/'target/p0-origin-field-producers-712/field-producers-proof.spthy'
full_text=full.read_text()
assert hashlib.sha256(full.read_bytes()).hexdigest()=='f330bf0345a334cddc965c6783bc16e3f88639d9ec2e040cc19b539557f265f6'
full_main=full_text.split('lemma epoch_generation_secret_derivation_origin ',1)[1].split('\nlemma ',1)[0]
full_blocks={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',full_main)}
snapshot=full_blocks['Snapshot_case_5']
assert snapshot.count('by sorry')==36 and blocks['Snapshot_case_5'].count('by sorry')==1
preserved=json.loads((root/'target/p0-origin-wire-producers-712/PREPARATION.json').read_text())
assert hashlib.sha256(snapshot.encode()).hexdigest()==preserved['full_snapshot_subtree_sha256']
main=main.replace(blocks['Snapshot_case_5'],snapshot,1)
candidate=value[:start]+main+value[stop:]
candidate=candidate.replace('by sorry /* Oracle ranked no proof methods */','by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',full_text)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-restored-replay-712'
stage.mkdir()
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'actual_remaining_wire_methods':records,'all29_queries_and_operational_prefix_unchanged':True,
    'all18_sources_retained':True,'full_snapshot_subtree_restored_byte_identical':True,
    'snapshot_subtree_sha256':hashlib.sha256(snapshot.encode()).hexdigest(),
    'snapshot_open_leaves_restored':36,'independent_replay_no_search_or_oracle':True,
    'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'snapshot_open_leaves_restored':36,'wire_methods':len(records)}))
