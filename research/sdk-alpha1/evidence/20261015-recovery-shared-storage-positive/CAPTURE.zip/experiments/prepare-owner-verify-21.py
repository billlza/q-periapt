"""Bind the combined-owner witness to its exact formula and unchanged model."""
from pathlib import Path
stage = Path(__file__).resolve().parent
prelude = (stage / "certify-13.py").read_text().split("import continuity_recovery_profiles as profiles", 1)[0].replace("-parse-13", "-parse-21")
body = '''lemma = "shared_device_identity_and_storage_recovery_is_executable"
search = json.loads((stage / "owner-witness-18-TERMINAL.json").read_text())
replay = json.loads((stage / "owner-replay-19-TERMINAL.json").read_text())
sdk.require(search["accepted"] and replay["accepted"] and replay["required_verified_lemmas"] == [lemma], "owner witness not accepted")
sdk.require(not any(arg.startswith("--prove") or arg.startswith("--output-json") for arg in replay["argv"]), "owner replay mode changed")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "owner-witness-18-proof.spthy").sha256, "witness input certificate changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "owner-replay-19-proof.spthy").sha256, "witness output certificate changed")
canonical = parsed("canonical", root / "research/continuity-recovery-symbolic/shared-storage.spthy")
before = parsed("owner-input", stage / "owner-witness-17.spthy")
after = parsed("owner-certificate", stage / "owner-replay-19-proof.spthy")
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after), "owner witness model differs")
sdk.require(queries(before) == queries(after) and next(iter(queries(after))) == lemma, "full witness declarations or premise ordering changed")
for name, declaration_text in queries(canonical).items():
    sdk.require(queries(after)[name] == declaration_text, "original query changed")
sdk.write_json(stage / "OWNER_VERIFIED_21.json", {
    "completed": True, "lemma": lemma,
    "search_steps": search["results"][lemma]["steps"], "replay_steps": replay["results"][lemma]["steps"],
    "input_sha256": replay["input_sha256"], "certificate_sha256": replay["output_sha256"],
    "same_complete_model_and_queries": True, "no_prior_reusable_premise": True,
    "same_cross_role_signing_key_and_wrapping_key_required": True,
    "three_distinct_identity_keys_and_three_distinct_wrapping_keys_required": True,
    "sibling_response_commit_and_both_target_confirmations_required_before_target_message": True,
    "no_identity_entropy_or_snapshot_disclosure": True,
    "validation": "machine-checked existential formula and independent certificate replay; no diagnostic graph exported",
    "existence_is_not_a_secrecy_proof": True, "release_claim_eligible": False,
})
print("Combined device identity/storage witness independently replayed with its exact full formula")
'''
with (stage / "verify-owner-21.py").open("x") as stream:
    stream.write(prelude + body)
