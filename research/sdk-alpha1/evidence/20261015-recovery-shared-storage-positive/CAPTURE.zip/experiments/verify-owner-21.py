"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-21"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

lemma = "shared_device_identity_and_storage_recovery_is_executable"
search = json.loads((stage / "owner-witness-18-TERMINAL.json").read_text())
replay = json.loads((stage / "owner-replay-19-TERMINAL.json").read_text())
sdk.require(search["accepted"] and replay["accepted"] and replay["required_verified_lemmas"] == [lemma], "owner witness not accepted")
sdk.require(not any(arg.startswith("--prove") or arg.startswith("--output-json") for arg in replay["argv"]), "owner replay mode changed")
sdk.require(search["output_sha256"] == replay["input_sha256"] == sdk.snapshot(stage / "owner-witness-18-proof.spthy").sha256, "witness input certificate changed")
sdk.require(replay["output_sha256"] == sdk.snapshot(stage / "owner-replay-19-proof.spthy").sha256, "witness output certificate changed")
canonical = parsed("canonical", root / "research/continuity-recovery-symbolic/shared-storage.spthy")
before = parsed("owner-input", stage / "owner-witness-17.spthy")
after = parsed("owner-certificate", stage / "owner-replay-19-proof.spthy")
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after), "owner witness model differs")
sdk.require(queries(before) == queries(after) and next(iter(queries(after))) == lemma, "full witness declarations or premise ordering changed")
for name, declaration_text in queries(canonical).items():
    sdk.require(queries(after)[name] == declaration_text, "original query changed")
sdk.write_json(stage / "OWNER_VERIFIED_21.json", {
    "completed": True, "lemma": lemma,
    "search_steps": search["results"][lemma]["steps"], "replay_steps": replay["results"][lemma]["steps"],
    "input_sha256": replay["input_sha256"], "certificate_sha256": replay["output_sha256"],
    "same_complete_model_and_queries": True, "no_prior_reusable_premise": True,
    "same_cross_role_signing_key_and_wrapping_key_required": True,
    "three_distinct_identity_keys_and_three_distinct_wrapping_keys_required": True,
    "sibling_response_commit_and_both_target_confirmations_required_before_target_message": True,
    "no_identity_entropy_or_snapshot_disclosure": True,
    "validation": "machine-checked existential formula and independent certificate replay; no diagnostic graph exported",
    "existence_is_not_a_secrecy_proof": True, "release_claim_eligible": False,
})
print("Combined device identity/storage witness independently replayed with its exact full formula")
