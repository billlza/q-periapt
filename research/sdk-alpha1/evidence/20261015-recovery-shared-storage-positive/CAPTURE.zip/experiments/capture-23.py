"""Retain the checked shared-storage proof, controls and public witness certificate."""
from pathlib import Path
import hashlib
import io
import json
import os
import zipfile
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
certified = json.loads((stage / "CERTIFIED_13.json").read_text())
controls = json.loads((stage / "CONTROLS_16.json").read_text())
witness = json.loads((stage / "OWNER_VERIFIED_21.json").read_text())
resources = json.loads((stage / "RESOURCE_OBSERVATION_22.json").read_text())
sdk.require(certified["completed"] and controls["completed"] and witness["completed"], "missing admission evidence")
dead = []
for path in sorted(stage.glob("*-STARTED.json")):
    pid = json.loads(path.read_text())["pid"]
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        dead.append(pid)
    else:
        raise ValueError("owned prover group remains live: " + str(pid))
sdk.write_json(stage / "CLEANUP_23.json", {"completed": True, "owned_prover_groups_absent": dead,
               "no_process_killed_by_cleanup": True})
model = root / "research/continuity-recovery-symbolic/shared-storage.spthy"
sdk.require(sdk.snapshot(model).sha256 == certified["bare_model_sha256"], "canonical model changed")
prior_path = root / "research/sdk-alpha1/evidence/20261015-recovery-shared-storage/CAPTURE.zip"
prior = read_regular_snapshot(prior_path, maximum=16*1024**2, label="prior public symbolic archive")
sdk.require(prior.sha256 == "a1deb755ce8176e7683d12f9be614ccee36abb82680087f5abbd8b6872b4597c", "prior archive changed")
carried = {}
with zipfile.ZipFile(io.BytesIO(prior.data)) as zipped:
    for leaf in ("sibling-replay-07-proof.spthy", "sibling-replay-07.stdout", "sibling-replay-07.stderr",
                 "sibling-replay-07-TERMINAL.json", "WITNESS_12.json"):
        member = "experiments/" + leaf
        sdk.require(zipped.getinfo(member).file_size <= 4*1024**2, "oversized carried certificate")
        carried["prior/" + leaf] = zipped.read(member)
sdk.require(hashlib.sha256(carried["prior/sibling-replay-07-proof.spthy"]).hexdigest() ==
            json.loads(carried["prior/WITNESS_12.json"])["certificate_sha256"], "carried attack certificate differs")
public = root / "research/sdk-alpha1/evidence/20261015-recovery-shared-storage-positive"
public.mkdir()
files = {"experiments/" + path.name: path for path in stage.iterdir()
         if path.is_file() and path.suffix in (".py", ".spthy", ".json", ".stdout", ".stderr", ".txt")}
for relative in ("research/continuity-recovery-symbolic/shared-storage.spthy",
                 "artifact/continuity_recovery_proof.py", "artifact/continuity_recovery_profiles.py"):
    files["source/" + relative] = root / relative
files["tools/TOOLS_08.json"] = root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json"
digests = {}
total = 0
archive = public / "CAPTURE.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name in sorted(set(files) | set(carried)):
        if name in carried:
            data = carried[name]
        else:
            data = read_regular_snapshot(files[name], maximum=32*1024**2, label="public symbolic evidence").data
        total += len(data)
        sdk.require(total <= 64*1024**2, "evidence exceeds bounded total")
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(info, data)
        digests[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(digests) and set(zipped.namelist()) == set(digests), "archive inventory differs")
    for name, digest in digests.items():
        value = hashlib.sha256()
        with zipped.open(name) as stream:
            for chunk in iter(lambda: stream.read(1024*1024), b""):
                value.update(chunk)
        sdk.require(value.hexdigest() == digest, "archive readback differs")
archive_digest = sdk.snapshot(archive).sha256
sdk.write_json(public / "CAPTURE.json", {
    "capture_sha256": archive_digest, "members": digests, "expanded_bytes": total,
    "positive_shared_storage_certificate": certified, "combined_owner_witness": witness,
    "admission_controls": controls, "prover_resource_observation": resources,
    "prior_archive_sha256": prior.sha256,
    "carried_attack_certificate_sha256": digests["prior/sibling-replay-07-proof.spthy"],
    "carried_attack_not_rerun_this_turn": True, "release_claim_eligible": False,
})
sdk.write_json(public / "READBACK.json", {
    "completed": True, "capture_sha256": archive_digest, "members": len(digests),
    "expanded_bytes": total, "all_members_rehashed": True, "positive_group_count": 20,
    "combined_owner_witness_replayed": True, "carried_attack_certificate_matches_prior": True,
    "private_sdk_runtime_data_selected": False, "release_claim_eligible": False,
})
print(json.dumps({"members": len(digests), "expanded_bytes": total, "archive_bytes": archive.stat().st_size,
                  "archive_sha256": archive_digest}))
