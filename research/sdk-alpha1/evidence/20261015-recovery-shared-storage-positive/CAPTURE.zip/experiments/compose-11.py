"""Assemble the unchanged 20 formulas from closed components; require a full replay."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
previous = root / "target/continuity-recovery-shared-storage-20261015"
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def parts(text):
    matches = list(pattern.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query declaration")
    blocks = {}
    for index, match in enumerate(matches):
        stop = matches[index + 1].start() if index + 1 < len(matches) else text.rindex("\nend")
        body = re.sub(r"/\*.*?\*/", "", text[match.end():stop], flags=re.S).strip()
        blocks[match.group(1)] = (match.group(), body)
    return text[:matches[0].start()], blocks

prefix, bank = parts((stage / "traffic-01.spthy").read_text())
groups = {
    "causal-07": ("traffic_key_derivation_requires_prior_root", "message_derivation_requires_prior_traffic_key",
                  "response_confirmation_has_origin_or_prior_root", "computed_root_identifies_session",
                  "accepted_root_has_origin_or_prior_derivation"),
    "root-auth-10": ("signing_secret_derivation_origin", "generation_secret_derivation_origin", "signing_secret_origin",
                     "generation_secret_origin", "encapsulation_uses_authenticated_generation",
                     "encapsulation_derivation_requires_key_or_session_leak",
                     "accepted_root_has_authenticated_origin", "message_root_has_authenticated_origin"),
    "constructor-08": ("root_constructor_requires_prior_coins_or_snapshot",),
    "timing-replay-06": ("retained_record_has_saved_origin", "stored_records_follow_fresh_reservations"),
}
proofs = {}
for label, names in groups.items():
    receipt = json.loads((stage / (label + "-TERMINAL.json")).read_text())
    certificate = stage / (label + "-proof.spthy")
    sdk.require(receipt["accepted"] and sdk.snapshot(certificate).sha256 == receipt["output_sha256"], "component not accepted: " + label)
    sdk.require(all(receipt["results"][name]["status"] == "verified" for name in names), "component group incomplete: " + label)
    _, blocks = parts(certificate.read_text())
    for name in names:
        sdk.require(name not in proofs, "duplicate component")
        proofs[name] = blocks[name][1]

# These four scripts displayed verified in the earlier current-model replay,
# but their incomplete dependencies made that entire replay inadmissible. They
# are only candidate scripts here until all 20 obligations replay together.
conditional_receipt = json.loads((previous / "replay-03-TERMINAL.json").read_text())
sdk.require(conditional_receipt["returncode"] == 0 and not conditional_receipt["accepted"], "conditional replay scope changed")
_, conditional = parts((previous / "replay-03-proof.spthy").read_text())
conditional_names = ("computed_root_derivation_requires_key_or_session_leak", "message_derivation_requires_key_or_session_leak",
                     "encapsulation_secret_requires_key_or_session_leak", "key_scoped_reservations_recover_symbolic_message_secrecy")
for name in conditional_names:
    sdk.require(conditional_receipt["results"][name]["status"] == "verified", "conditional script incomplete")
    proofs[name] = conditional[name][1]
ordered = (*groups["causal-07"], *groups["root-auth-10"], *groups["constructor-08"],
           *conditional_names[:2], *groups["timing-replay-06"], *conditional_names[2:])
sdk.require(len(ordered) == len(set(ordered)) == len(proofs) == 20, "full dependency inventory changed")
unused = [name for name in bank if name not in ordered]
sdk.require(len(unused) == 4 and all("exists-trace" in bank[name][0] for name in unused), "unexpected remaining query")
full = prefix + "\n\n" + "\n\n".join(bank[name][0] + "\n" + proofs[name] for name in ordered)
full += "\n\n" + "\n\n".join(bank[name][0] + "\nby sorry" for name in unused) + "\n\nend\n"
sdk.require({match.group(1): match.group() for match in pattern.finditer(full)} ==
            {name: declaration for name, (declaration, _) in bank.items()}, "full query declarations changed")
with (stage / "composed-11.spthy").open("x") as stream:
    stream.write(full)
sdk.write_json(stage / "COMPOSED_11.json", {
    "input_sha256": sdk.snapshot(stage / "composed-11.spthy").sha256,
    "required_properties": ordered, "component_groups": groups,
    "conditional_scripts_require_complete_replay": conditional_names,
    "full_query_declarations_unchanged_from_traffic_01": True,
    "order_change": "encapsulation derivation precedes the two root-authentication lemmas, matching their closed component scope",
    "operational_prefix_unchanged_from_traffic_01": True,
    "main_recovery_theorem_unproved": True, "release_claim_eligible": False,
})
print("Twenty-property certificate assembled; main theorem still requires complete no-search replay")
