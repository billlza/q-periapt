"""Continue the exact shared-storage projection from its independently replayed helper."""
from pathlib import Path
import json
import re
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
previous = root / "target/continuity-recovery-shared-storage-20261015"
model = root / "research/continuity-recovery-symbolic/shared-storage.spthy"
sdk.require(sdk.snapshot(model).sha256 == "146f0db14ce78d5d54bae1a8265584f471a8637e31aa3a19264151c571dc2046", "model changed")
archive = root / "research/sdk-alpha1/evidence/20261015-recovery-shared-storage/CAPTURE.zip"
sdk.require(sdk.snapshot(archive).sha256 == "a1deb755ce8176e7683d12f9be614ccee36abb82680087f5abbd8b6872b4597c", "archive changed")
with zipfile.ZipFile(archive) as zipped:
    certificate = zipped.read("experiments/traffic-replay-22-proof.spthy")
    runner = zipped.read("experiments/run-02.py")
with (stage / "traffic-01.spthy").open("xb") as stream:
    stream.write(certificate)
sdk.require(sdk.snapshot(stage / "traffic-01.spthy").sha256 == "eca628604acb35eadcc0782cef8da3c7a3ecf25f60aca15c4f6e61c0d6106494", "helper certificate changed")
with (stage / "run-01.py").open("xb") as stream:
    stream.write(runner)
with (stage / "crypto-01.spthy").open("xb") as stream:
    stream.write(model.read_bytes())
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
queries = [match.group(1) for match in pattern.finditer(model.read_text())]
sdk.require(queries[:6] == ["signing_secret_derivation_origin", "generation_secret_derivation_origin",
    "signing_secret_origin", "generation_secret_origin", "encapsulation_uses_authenticated_generation",
    "encapsulation_derivation_requires_key_or_session_leak"], "crypto group changed")
sdk.write_json(stage / "PREPARED_01.json", {
    "base_commit": "45e9f387412f63e987e7e2e64cc50ad8bff6a13a",
    "model_sha256": sdk.snapshot(model).sha256, "previous_archive_sha256": sdk.snapshot(archive).sha256,
    "inputs": {name: sdk.snapshot(stage / name).sha256 for name in ("traffic-01.spthy", "crypto-01.spthy", "run-01.py")},
    "crypto_group": queries[:6], "model_or_query_formula_changes": False,
    "main_recovery_theorem_unproved": True, "release_claim_eligible": False,
})
print("Exact archived causal proof and unchanged six-property provenance model prepared")
