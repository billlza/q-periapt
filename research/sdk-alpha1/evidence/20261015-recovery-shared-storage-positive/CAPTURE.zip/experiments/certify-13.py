"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-13"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

import continuity_recovery_profiles as profiles
receipt = json.loads((stage / "final-12-TERMINAL.json").read_text())
composition = json.loads((stage / "COMPOSED_11.json").read_text())
required = set(composition["required_properties"])
sdk.require(required == set(profiles.KEY_SCOPED_PROPERTIES) and len(required) == 20, "required inventory changed")
sdk.require(receipt["accepted"] and receipt["returncode"] == 0 and not receipt["timed_out"], "complete replay not accepted")
sdk.require(set(receipt["required_verified_lemmas"]) == required and not any(arg.startswith("--prove") for arg in receipt["argv"]), "replay scope or mode changed")
sdk.require(composition["input_sha256"] == receipt["input_sha256"] == sdk.snapshot(stage / "composed-11.spthy").sha256, "replay input changed")
sdk.require(receipt["output_sha256"] == sdk.snapshot(stage / "final-12-proof.spthy").sha256, "replay output changed")
sdk.require({name for name, result in receipt["results"].items() if result["status"] == "verified"} == required, "verified inventory changed")
for name in required:
    sdk.require(receipt["results"][name]["mode"] == "all-traces", "wrong trace quantifier")
model_path = root / "research/continuity-recovery-symbolic/shared-storage.spthy"
sdk.require(sdk.snapshot(model_path).sha256 == "146f0db14ce78d5d54bae1a8265584f471a8637e31aa3a19264151c571dc2046", "canonical model changed")
canonical = parsed("canonical", model_path)
before = parsed("input", stage / "composed-11.spthy")
after = parsed("certificate", stage / "final-12-proof.spthy")
bank = parsed("query-bank", stage / "traffic-01.spthy")
sdk.require(operational_model(canonical) == operational_model(before) == operational_model(after) == operational_model(bank), "operational model changed")
sdk.require(queries(before) == queries(after) == queries(bank), "full 24 query declarations changed")
main = "key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(queries(canonical)[main] == queries(after)[main], "main formula changed")
for name, declaration_text in queries(canonical).items():
    formula = declaration_text[declaration_text.index('"'):]
    found = queries(after)[name]
    sdk.require(formula == found[found.index('"'):], "original complete formula changed: " + name)
sdk.write_json(stage / "CERTIFIED_13.json", {
    "completed": True, "required_property_count": 20,
    "verified": {name: receipt["results"][name]["steps"] for name in sorted(required)},
    "input_sha256": receipt["input_sha256"], "certificate_sha256": receipt["output_sha256"],
    "bare_model_sha256": sdk.snapshot(model_path).sha256,
    "elapsed_seconds": receipt["elapsed_seconds"], "heap_gib": 12, "threads": 1,
    "no_search_replay": True, "all_full_query_declarations_unchanged": True,
    "main_formula_unchanged_from_shared_storage_checkpoint": True,
    "no_late_operational_declarations": True,
    "scope": "one exchange per session, arbitrary reused honest identity and wrapping keys, fresh publicly revealed old roots, perfect primitives and per-record ciphertext disclosure",
    "identity_exclusion": "no target-key reveal or signer-file capture anywhere in the trace; file capture is conservatively counted before decryption",
    "unproved": ["whole-journal image and restore correspondence", "inherited-root correlation", "multi-epoch recovery", "concrete HKDF/AEAD/hybrid/signing-coins security", "SDK refinement", "hosted Linux replay of this model"],
    "release_claim_eligible": False,
})
print("All 20 shared-storage recovery properties independently replayed with the unchanged model and full queries")
