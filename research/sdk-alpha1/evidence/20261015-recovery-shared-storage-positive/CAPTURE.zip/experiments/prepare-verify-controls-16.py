"""Validate semantic rejection separately from parser failure or timeout."""
from pathlib import Path
stage = Path(__file__).resolve().parent
text = (stage / "certify-13.py").read_text()
prelude = text.split("import continuity_recovery_profiles as profiles", 1)[0].replace("-parse-13", "-parse-16")
body = '''expected = parsed("expected", stage / "composed-11.spthy")
expected_model = operational_model(expected)
expected_queries = queries(expected)
inputs = json.loads((stage / "CONTROL_INPUTS_14.json").read_text())
outcomes = {}
for label, digest in inputs["semantic_controls"].items():
    path = stage / (label + ".spthy")
    sdk.require(sdk.snapshot(path).sha256 == digest, "control input changed")
    changed = parsed(label, path)
    stderr = (stage / (label + "-parse-16.stderr")).read_text()
    sdk.require(re.search(r"(?im)^\\s*(?:warning|error|fatal)\\b", stderr) is None, "control is not warning-free parser-valid input")
    try:
        same_model = operational_model(changed) == expected_model
    except ValueError as exc:
        sdk.require("late operational declaration" in str(exc), "unexpected model checker failure")
        same_model = False
    same_queries = queries(changed) == expected_queries
    sdk.require(not (same_model and same_queries), "changed scope was admitted")
    outcomes[label] = {"parser_valid": True, "same_model": same_model, "same_full_queries": same_queries, "rejected": True}
receipt = json.loads((stage / "missing-dependency-15-TERMINAL.json").read_text())
sdk.require(receipt["returncode"] == 0 and not receipt["timed_out"] and not receipt["accepted"], "missing-dependency control not rejected")
sdk.require(receipt["results"]["retained_record_has_saved_origin"]["status"] == "analysis incomplete", "removed dependency unexpectedly proved")
sdk.require(receipt["results"]["stored_records_follow_fresh_reservations"]["status"] == "verified", "dependent property did not display conditional success")
before = parsed("timing-original", stage / "timing-replay-06-proof.spthy")
after = parsed("timing-missing-proof", stage / "missing-dependency-15-proof.spthy")
sdk.require(operational_model(before) == operational_model(after) == expected_model and queries(before) == queries(after), "dependency control changed its model or complete formulas")
sdk.write_json(stage / "CONTROLS_16.json", {
    "completed": True, "scope_mutations": outcomes,
    "exit_zero_conditional_property_with_missing_helper_rejected": True,
    "missing_dependency_control_same_model_and_full_query_declarations": True,
    "release_claim_eligible": False,
})
print("Four parser-valid scope mutations and conditional success with a missing dependency were rejected")
'''
with (stage / "verify-controls-16.py").open("x") as stream:
    stream.write(prelude + body)
