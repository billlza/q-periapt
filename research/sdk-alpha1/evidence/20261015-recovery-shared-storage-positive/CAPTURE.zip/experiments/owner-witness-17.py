"""Exercise simultaneous device-identity and journal-key reuse across roles."""
from pathlib import Path
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = root / "research/continuity-recovery-symbolic/shared-storage.spthy"
base = source.read_text()
prefix, original = base.split("\nlemma ", 1)
witness = '''lemma shared_device_identity_and_storage_recovery_is_executable:
 exists-trace
 "Ex s other sa sb sc wa wb wc key payload #target #sibling #c #g #e #response #a #b #m.
    SessionKeys(s,sa,sb)@target & SessionKeys(other,sc,sa)@sibling
  & SessionStorage(s,wa,wb)@target & SessionStorage(other,wc,wa)@sibling
  & not (s = other)
  & not (sa = sb) & not (sa = sc) & not (sb = sc)
  & not (wa = wb) & not (wa = wc) & not (wb = wc)
  & ResponseCommitted(other)@response & response < m
  & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Confirmed(s,'A')@a & Confirmed(s,'B')@b & Message(s,'A',key,payload)@m
  & c < g & c < e & a < m & b < m
  & not (Ex any_session role #x. IdentityLeak(any_session,role)@x)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)
  & not (Ex any_session revision #x. Snapshot(any_session,revision)@x)"

'''
full = prefix + "\n\n" + witness + "lemma " + original
with (stage / "owner-witness-17.spthy").open("x") as stream:
    stream.write(full)
sdk.write_json(stage / "OWNER_WITNESS_17.json", {
    "canonical_model_sha256": sdk.snapshot(source).sha256,
    "input_sha256": sdk.snapshot(stage / "owner-witness-17.spthy").sha256,
    "same_operational_model_and_original_queries": True,
    "new_witness_is_first_without_reusable_premises": True,
    "forces_shared_identity_and_wrapping_key_in_the_same_cross_role_owner": True,
    "requires_actual_sibling_response_commit_and_both_target_confirmations": True,
    "diagnostic_graph_export": False,
    "result_unverified": True,
})
print("Combined identity/storage owner witness prepared without changing the recovery formula")
