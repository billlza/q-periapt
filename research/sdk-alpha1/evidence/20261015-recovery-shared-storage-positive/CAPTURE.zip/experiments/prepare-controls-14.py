"""Create parser-valid scope mutations and a dependency-removal replay control."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / "composed-11.spthy").read_text()
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
marks = list(pattern.finditer(text))
main = next(match for match in marks if match.group(1) == "key_scoped_reservations_recover_symbolic_message_secrecy")
index = marks.index(main)
stop = marks[index + 1].start()
mutations = {"missing-main-14": text[:main.start()] + text[stop:]}
old = "∃ #x. IdentityKeyLeak( sa )"
new = "∃ any_key #x. IdentityKeyLeak( any_key )"
sdk.require(main.group().count(old) == 1, "main identity condition differs")
mutations["stronger-identity-14"] = text[:main.start()] + main.group().replace(old, new) + text[main.end():]
sdk.require(text.count("\nend") == 1, "end placement ambiguous")
mutations["late-restriction-14"] = text.replace("\nend", '\nrestriction NoSnapshots:\n "not (Ex s revision #x. Snapshot(s,revision)@x)"\n\nend')
start = text.index("rule (modulo E) Setup:")
end = text.index("\nrule (modulo E) Cut:", start)
setup = text[start:end]
sdk.require(setup.count("!StorageKey( wa )") == setup.count("!StorageKey( wb )") == 1, "wrapping-key allocation differs")
independent = re.sub(r"\b(wa|wb)\b", r"~\1", setup)
for name in ("wa", "wb"):
    independent = independent.replace("!StorageKey( ~" + name + " )", "Fr( ~" + name + " )")
mutations["independent-allocation-14"] = text[:start] + independent + text[end:]
for label, changed in mutations.items():
    sdk.require(changed != text, "mutation did not change input")
    with (stage / (label + ".spthy")).open("x") as stream:
        stream.write(changed)

timing = (stage / "timing-replay-06-proof.spthy").read_text()
timing_marks = list(pattern.finditer(timing))
sdk.require(timing_marks[0].group(1) == "retained_record_has_saved_origin", "timing helper order differs")
removed = timing[:timing_marks[0].end()] + "\nby sorry\n\n" + timing[timing_marks[1].start():]
sdk.require([match.group() for match in pattern.finditer(removed)] == [match.group() for match in timing_marks], "timing declarations changed")
with (stage / "missing-dependency-14.spthy").open("x") as stream:
    stream.write(removed)
sdk.write_json(stage / "CONTROL_INPUTS_14.json", {
    "semantic_controls": {label: sdk.snapshot(stage / (label + ".spthy")).sha256 for label in mutations},
    "dependency_control_sha256": sdk.snapshot(stage / "missing-dependency-14.spthy").sha256,
    "dependency_formulae_unchanged": True,
    "result_unverified": True,
})
print("Four scope mutations and an unchanged-formula missing-dependency control prepared")
