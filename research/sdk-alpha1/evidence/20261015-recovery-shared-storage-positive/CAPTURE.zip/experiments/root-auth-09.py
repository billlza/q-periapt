"""Add authenticated root provenance after the already closed six-property group."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
receipt = json.loads((stage / "crypto-03-TERMINAL.json").read_text())
base_path = stage / "crypto-03-proof.spthy"
sdk.require(receipt["accepted"] and sdk.snapshot(base_path).sha256 == receipt["output_sha256"], "crypto certificate not accepted")
sdk.require(sum(result["status"] == "verified" for result in receipt["results"].values()) == 6, "crypto group incomplete")
base = base_path.read_text()
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
bank = {match.group(1): match.group() for match in pattern.finditer((stage / "traffic-01.spthy").read_text())}
names = ("accepted_root_has_authenticated_origin", "message_root_has_authenticated_origin")
additions = []
for name in names:
    old = bank[name]
    header = re.match(r"lemma\s+\w+\s+\[([^\]]+)\]:", old)
    sdk.require(header is not None, "proof attributes missing")
    attributes = [value.strip() for value in header.group(1).split(",") if not value.strip().startswith("hide_lemma=")]
    fresh = "lemma " + name + " [" + ",".join(attributes) + "]:" + old[header.end():]
    sdk.require(fresh[fresh.index(':'):] == old[old.index(':'):], "complete formula changed")
    additions.append(fresh + "\nby sorry\n")
marker = "lemma key_scoped_reservations_recover_symbolic_message_secrecy"
sdk.require(base.count(marker) == 1, "main placement ambiguous")
full = base.replace(marker, "\n\n".join(additions) + "\n" + marker)
with (stage / "root-auth-09.spthy").open("x") as stream:
    stream.write(full)
sdk.write_json(stage / "ROOT_AUTH_09.json", {
    "crypto_certificate_sha256": sdk.snapshot(base_path).sha256,
    "output_sha256": sdk.snapshot(stage / "root-auth-09.spthy").sha256,
    "new_properties": names, "existing_rules_queries_and_proof_bodies_unchanged": True,
    "two_formulas_unchanged_from_traffic_01": True,
    "irrelevant_hide_attributes_removed_because_those_lemmas_are_absent": True,
    "main_recovery_theorem_unproved": True, "release_claim_eligible": False,
})
print("Authenticated root queries prepared after six verified provenance properties")
