"""Place logically independent timing/constructor queries before reusable helpers."""
from pathlib import Path
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
base = (stage / "crypto-01.spthy").read_text()
prefix, original = base.split("\nlemma ", 1)
pattern = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
bank = {match.group(1): match.group() for match in pattern.finditer((stage / "traffic-01.spthy").read_text())}
groups = {
    "timing-04": ("retained_record_has_saved_origin", "stored_records_follow_fresh_reservations"),
    "constructor-04": ("root_constructor_requires_prior_coins_or_snapshot",),
}
for label, names in groups.items():
    declarations = []
    for name in names:
        old = bank[name]
        fresh = re.sub(r"\[[^\]]+\]", "[use_induction,reuse]", old, count=1)
        sdk.require(fresh[fresh.index(':'):] == old[old.index(':'):], "complete query changed")
        declarations.append(fresh)
    text = prefix + "\n\n" + "\n\n".join(declarations) + "\n\nlemma " + original
    sdk.require(text.split("\nlemma signing_secret_derivation_origin", 1)[1] ==
                base.split("\nlemma signing_secret_derivation_origin", 1)[1], "original queries changed")
    with (stage / (label + ".spthy")).open("x") as stream:
        stream.write(text)
sdk.write_json(stage / "INDEPENDENT_GROUPS_04.json", {
    "same_operational_model_and_original_queries": True,
    "new_group_full_formulas_unchanged_from_traffic_01": True,
    "hide_annotations_removed_only_because_the_hidden_lemmas_are_absent_before_each_group": True,
    "groups": groups, "main_recovery_theorem_unproved": True, "release_claim_eligible": False,
})
print("Independent timing and root-constructor proof groups prepared")
