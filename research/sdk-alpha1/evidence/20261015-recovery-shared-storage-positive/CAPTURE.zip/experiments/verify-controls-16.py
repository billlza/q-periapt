"""Validate the replayed attack's model, full queries, key aliases and causal trace."""
from pathlib import Path
import json
import re
from evidence_io import read_regular_snapshot
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
def parsed(label, path):
    return sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(path), "--parse-only"],
                       stage / (label + "-parse-16"), root).decode()

def without_comments(text):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", text, flags=re.S))

def operational_model(text):
    head, tail = text.split("\nlemma ", 1)
    tail = without_comments(tail)
    sdk.require(not re.search(r"(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b", tail),
                "late operational declaration")
    head = without_comments(head)
    signature = re.search(r"(?s)functions:\s*(.*?)\nequations:", head)
    sdk.require(signature is not None, "expanded signature missing")
    functions = {name: int(arity) for name, arity in re.findall(r"(\w+)/(\d+)", signature.group(1))}
    info = re.findall(r"(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$", head)
    for name, args, result in info:
        types = [value.strip() for value in args.split(",") if value.strip()]
        sdk.require(name in functions and functions[name] == len(types)
                    and set(types) <= {"Any"} and result == "Any", "informational signature changed")
    sdk.require({name for name, _, _ in info} in ({"kempk", "kemct", "decap"}, set(functions)), "unexpected function inventory")
    sdk.require(set(re.findall(r"(?m)^builtin\s+(\S+)\s*$", head)) in
                (set(), {"hashing", "signing", "symmetric-encryption"}), "unexpected builtin summary")
    head = re.sub(r"(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$", "", head)
    head = re.sub(r"(?m)^builtin\s+\S+\s*$", "", head)
    return re.sub(r"\s+", "", head)

declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
def queries(text):
    matches = list(declaration.finditer(text))
    sdk.require(len(matches) == len({match.group(1) for match in matches}), "duplicate query")
    return {match.group(1): match.group() for match in matches}

expected = parsed("expected", stage / "composed-11.spthy")
expected_model = operational_model(expected)
expected_queries = queries(expected)
inputs = json.loads((stage / "CONTROL_INPUTS_14.json").read_text())
outcomes = {}
for label, digest in inputs["semantic_controls"].items():
    path = stage / (label + ".spthy")
    sdk.require(sdk.snapshot(path).sha256 == digest, "control input changed")
    changed = parsed(label, path)
    stderr = (stage / (label + "-parse-16.stderr")).read_text()
    sdk.require(re.search(r"(?im)^\s*(?:warning|error|fatal)\b", stderr) is None, "control is not warning-free parser-valid input")
    try:
        same_model = operational_model(changed) == expected_model
    except ValueError as exc:
        sdk.require("late operational declaration" in str(exc), "unexpected model checker failure")
        same_model = False
    same_queries = queries(changed) == expected_queries
    sdk.require(not (same_model and same_queries), "changed scope was admitted")
    outcomes[label] = {"parser_valid": True, "same_model": same_model, "same_full_queries": same_queries, "rejected": True}
receipt = json.loads((stage / "missing-dependency-15-TERMINAL.json").read_text())
sdk.require(receipt["returncode"] == 0 and not receipt["timed_out"] and not receipt["accepted"], "missing-dependency control not rejected")
sdk.require(receipt["results"]["retained_record_has_saved_origin"]["status"] == "analysis incomplete", "removed dependency unexpectedly proved")
sdk.require(receipt["results"]["stored_records_follow_fresh_reservations"]["status"] == "verified", "dependent property did not display conditional success")
before = parsed("timing-original", stage / "timing-replay-06-proof.spthy")
after = parsed("timing-missing-proof", stage / "missing-dependency-15-proof.spthy")
sdk.require(operational_model(before) == operational_model(after) == expected_model and queries(before) == queries(after), "dependency control changed its model or complete formulas")
sdk.write_json(stage / "CONTROLS_16.json", {
    "completed": True, "scope_mutations": outcomes,
    "exit_zero_conditional_property_with_missing_helper_rejected": True,
    "missing_dependency_control_same_model_and_full_query_declarations": True,
    "release_claim_eligible": False,
})
print("Four parser-valid scope mutations and conditional success with a missing dependency were rejected")
