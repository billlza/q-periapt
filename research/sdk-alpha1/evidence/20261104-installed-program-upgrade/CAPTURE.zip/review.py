"""Re-read captured original messages, process cuts and installed identities."""
import hashlib
import json
from pathlib import Path
import sys

CUTS=['approved','reply','final','active','receive','outbox','ack','rekey-response','rekey-receipt','new-epoch']
CASES=[('run-02/single-program','peer',328,219,False),('run-02/two-program','peer',328,219,True),
       ('run-03/peer-before','peer-before',345,230,True),('run-03/peer-after','peer-after',346,230,True)]

def require(ok,message):
    if not ok: raise ValueError(message)
def sha(body): return hashlib.sha256(body).hexdigest()

def review(read, selected=CASES):
    def obj(name): return json.loads(read(name))
    results=[]
    for prefix,mode,count,witness_count,replacement in selected:
        d=obj(prefix+'/RESULT.json'); profile=d['profiles'][0]; peer=profile['successor']['peer']
        require(d['completed'] is True and len(d['profiles'])==1 and profile['profile']=='witness','profile completion')
        require(peer['completed'] is True and peer['mode']==mode and peer['directions']==2 and peer['rekey_epoch']==1
                and peer['native_original_journal_retained'] is True and peer['peer_confirmation_retained'] is True,'original lifecycle')
        commands=obj(prefix+'/witness/NATIVE.json'); by_name={r['case']:r for r in commands}
        require(len(commands)==count==len(by_name)==profile['native_commands'],'native command census')
        def wire(case,suffix): return read(prefix+'/witness/native/cases/'+case+suffix)
        for row in commands:
            output=wire(row['case'],'.output')
            require(sha(wire(row['case'],'.input'))==row['input_sha256'] and len(output)>0
                    and output[0]==row['status'] and sha(output[1:])==row['output_sha256'],'native raw transcript')
        cuts=CUTS if mode=='peer' else CUTS[:4]+['unknown-send']+CUTS[4:]
        rows=peer['native_process_restarts']
        require(rows==obj(prefix+'/witness/native/PROCESS_RESTARTS.json') and [r['case'] for r in rows]==cuts,'restart census')
        require(len(rows[0]['preserved_files'])==58,'preserved original input census')
        pids=[rows[0]['old_pid']]; switches=[]; current='before'
        if replacement:
            plan=obj(prefix.rsplit('/',1)[0]+('/PLAN.json' if mode=='peer' else '/'+mode+'-PLAN.json'))
            programs=d['native_program_replacement']['programs']
            require(d['native_program_replacement']['completed'] is True,'program plan completion')
            for name in ('before','after'):
                report_path=prefix.rsplit('/',1)[0]+'/programs/'+name+'-INSTALLED_COUNTERPART.json'
                report=obj(report_path); binary=read(prefix.rsplit('/',1)[0]+'/programs/'+name+'-counterpart')
                require(sha(read(report_path))==programs[name]['installation_report_sha256']==plan['programs'][name]['installation_report_sha256'], 'installed report identity')
                require(sha(binary)==report['native_sha256']==programs[name]['sha256'],'installed binary identity')
                require(report['completed'] is True and report['sources_unchanged'] is True and report['source_commit']==programs[name]['source_commit'],'installed source identity')
            require(programs['before']['source_commit']=='6ce866b31088b3215bcc24bcfef84b4075ff5907'
                    and programs['after']['source_commit']=='21e00e9c3cfd193b9f51491888347f583620dfe0','qualified version edge')
        for i,row in enumerate(rows):
            require(row['completed'] is True and row['old_returncode']==-9 and row['signal']=='SIGKILL'
                    and row['old_pid']==pids[-1] and row['new_pid'] not in pids and row['root_revision']==2,'actual process chain')
            require(row['preserved_files']==rows[0]['preserved_files'],'original inputs retained')
            pids.append(row['new_pid']); tag='process-restart-'+row['case']+'-'
            for refused in ('old-controller','unselected-controller','wrong-target'):
                require(by_name[tag+refused]['pid']==row['new_pid'] and by_name[tag+refused]['status']==2,'new process authority refusal')
            require(by_name[tag+'select']['pid']==row['new_pid'] and by_name[tag+'select']['status']==1,'explicit original selection')
            for name,original in [('original-reply','successor-peer-initial'),('original-session','successor-peer-finish'),('original-activation','successor-peer-activate')]:
                if name=='original-reply' and i<1 or name=='original-session' and i<2 or name=='original-activation' and i<3: continue
                require(by_name[tag+name]['pid']==row['new_pid'] and wire(tag+name,'.output')==wire(original,'.output'),'exact original after process change')
            if replacement:
                change=row['program_replacement']; expected=plan['restarts'][i]
                require(change['index']==i and expected['case']==row['case'] and change['from']==current and change['to']==expected['program']
                        and change['old']==programs[current] and change['new']==programs[change['to']]
                        and change['plan_sha256']==d['native_program_replacement']['plan_sha256'],'program selection receipt')
                if change['to']!=current: switches.append([current,change['to']])
                current=change['to']
            else: require('program_replacement' not in row,'baseline executable selection')
            require(not read(prefix+'/witness/native/restart-'+str(i+1)+'.stderr'),'restart stderr')
        pairs=[('initial','initial-replay'),('receive','receive-duplicate'),('send','send-replay'),
               ('rekey-response','rekey-response-replay'),('rekey-receipt','rekey-receipt-replay'),
               ('receive-new-epoch','receive-new-epoch-replay')]
        for original,replay in pairs:
            for suffix in ('.input','.output'):
                require(wire('successor-peer-'+original,suffix)==wire('successor-peer-'+replay,suffix),'original request/result replay')
        witnesses=obj(prefix+'/witness/WITNESS.json')
        require(len(witnesses)==witness_count==profile['witness_requests'],'witness census')
        for row in witnesses:
            raw=read(prefix+'/witness/'+row['case']+'.request')
            require(len(raw)==3674 and sha(raw)==row['request_sha256'] and raw[140:172].hex()==row['command_id']
                    and raw[172:204].hex()==row['challenge'] and raw[204]==row['kind'],'witness raw request')
            if 'signed_reply_sha256' in row:
                require(sha(read(prefix+'/witness/'+row['case']+'.reply'))==row['signed_reply_sha256'],'witness raw reply')
        faults=[r for r in witnesses if r['fault'] is not None]
        if mode=='peer': require(not faults and peer['unknown_send_reservation_sha256'] is None,'ordinary scenario')
        else:
            require(len(faults)==1,'unknown outcome fault census'); fault=faults[0]
            require(fault['kind']==2 and fault['fault']==mode.removeprefix('peer-'),'fault side')
            delivery='not_dispatched_by_fixture' if mode=='peer-before' else 'signed_reply_withheld_by_fixture'
            require(fault['delivery']==delivery,'actual fault delivery')
            retries=[r for r in witnesses[witnesses.index(fault)+1:] if r['command_id']==fault['command_id'] and r['kind']==2]
            require(len(retries)==1 and retries[0]['delivery']=='sent' and retries[0]['native_status']==1,'original command retry')
            original=read(prefix+'/witness/'+fault['case']+'.request'); retried=read(prefix+'/witness/'+retries[0]['case']+'.request')
            require(original[:172]==retried[:172] and original[204:301]==retried[204:301]
                    and original[172:204]!=retried[172:204],'original operation with fresh challenge')
            require(original[269:301].hex()==peer['unknown_send_reservation_sha256']
                    and peer['completed_send_head_sha256']!=peer['unknown_send_reservation_sha256'],'exact retained reservation')
            cut=rows[4]
            require(by_name[retries[0]['case']]['pid']==cut['new_pid'],'retry reached replacement process')
            if mode=='peer-before': require(fault['case'] not in by_name,'pre-commit not dispatched')
            else: require(fault['native_status']==1 and by_name[fault['case']]['pid']==cut['old_pid'],'post-commit original process')
        results.append({'scenario':prefix,'native_commands':count,'witness_attempts':witness_count,'process_cuts':len(rows),
                        'program_switches':len(switches),'forward':switches.count(['before','after']),'backward':switches.count(['after','before']),
                        'exact_replay_pairs':len(pairs),'preserved_inputs_per_cut':58})
    return {'completed':True,'scenarios':results}

if __name__=='__main__':
    root=Path(sys.argv[1] if len(sys.argv)>1 else __file__).resolve()
    if root.is_file(): root=root.parent
    result=review(lambda name:(root/name).read_bytes())
    print(json.dumps(result,indent=2))
