"""Negative controls over the actual captured experiment, without rewriting it."""
from pathlib import Path
import copy
import importlib.util
import json

root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('upgrade_review',root/'review.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
controls=[]
for case in module.CASES:
    prefix=case[0]; result_name=prefix+'/RESULT.json'
    original=json.loads((root/result_name).read_text())
    mutations=[('partial-native-census',lambda d:d['profiles'][0].update(native_commands=1)),
        ('wrong-session-epoch',lambda d:d['profiles'][0]['successor']['peer'].update(rekey_epoch=0)),
        ('lost-original-journal',lambda d:d['profiles'][0]['successor']['peer'].update(native_original_journal_retained=False)),
        ('missing-process-cut',lambda d:d['profiles'][0]['successor']['peer']['native_process_restarts'].pop())]
    for name, mutate in mutations:
        changed=copy.deepcopy(original);mutate(changed)
        def read(path): return json.dumps(changed).encode() if path==result_name else (root/path).read_bytes()
        try: module.review(read,[case])
        except ValueError as e: controls.append({'scenario':prefix,'control':name,'rejection':str(e)})
        else: raise ValueError('accepted changed result: '+name)
    for name,path in [('changed-original-response',prefix+'/witness/native/cases/successor-peer-send-replay.output'),
                      ('changed-witness-request',prefix+'/witness/witness-attempt-1.request')]:
        body=(root/path).read_bytes(); altered=body[:-1]+bytes([body[-1]^1])
        def read(candidate): return altered if candidate==path else (root/candidate).read_bytes()
        try: module.review(read,[case])
        except ValueError as e: controls.append({'scenario':prefix,'control':name,'rejection':str(e)})
        else: raise ValueError('accepted changed transcript: '+name)
print(json.dumps({'completed':True,'rejected_controls':len(controls),'controls':controls},indent=2))
