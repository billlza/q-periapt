from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
OUT = ROOT/'target/continuity-installed-program-upgrade'
sys.path.append(str(ROOT/'artifact'))
from bounded_process import capture_output
from continuity_independent_python import PACKAGE, inspect_wheel, verify_installation
from continuity_independent_python_run import installed_files
from evidence_io import read_regular_snapshot
SOURCE = ROOT/'research/continuity-openssl-peer'

def sha(data): return hashlib.sha256(data).hexdigest()
def write(path, value):
    with path.open('x') as f: f.write(json.dumps(value,indent=2)+'\n')
def data(path, limit=32*1024**2): return read_regular_snapshot(path,maximum=limit,label='program upgrade input').data

def run(argv, label, *, cwd, timeout=900):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
    result=capture_output(argv,timeout_seconds=timeout,maximum_stdout_bytes=4*1024**2,
        maximum_stderr_bytes=1024**2,environment=environment,working_directory=cwd) if False else None
    # The capture helper uses the current directory; restore it on every outcome.
    previous=Path.cwd()
    try:
        os.chdir(cwd)
        result=capture_output(argv,timeout_seconds=timeout,maximum_stdout_bytes=4*1024**2,
            maximum_stderr_bytes=1024**2,environment=environment)
    finally: os.chdir(previous)
    (OUT/(label+'.stdout')).write_bytes(result.stdout); (OUT/(label+'.stderr')).write_bytes(result.stderr)
    write(OUT/(label+'.json'),{'argv':argv,'cwd':str(cwd),'started_at':start,
          'elapsed_seconds':time.monotonic()-tick,'exit':result.returncode})
    if result.returncode != 0 or result.stderr: raise ValueError('command failed: '+label)

commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
outside=Path(tempfile.mkdtemp(prefix='qperiapt-program-upgrade-')).resolve()
write(OUT/'LOCATION.json',{'path':str(outside),'controller_commit':commit})
application=outside/'research/continuity-openssl-peer'; application.parent.mkdir(parents=True)
environment={k:v for k,v in os.environ.items() if not k.startswith(('PYTHON','PIP_','DYLD_','LD_'))}
helpers=list(SOURCE.glob('*.py'))+[ROOT/'artifact'/n for n in ('python_bootstrap.py','evidence_io.py','continuity_independent_python_probe.py')]
inputs={}
for path in helpers:
    body=data(path); rel=path.relative_to(ROOT)
    if body != subprocess.check_output(['git','show',commit+':'+rel.as_posix()],cwd=ROOT):
        raise ValueError('controller differs from commit: '+str(rel))
    inputs[rel.as_posix()]=sha(body)
write(OUT/'CONTROLLER_INPUTS.json',{'commit':commit,'files':inputs})
old_output=ROOT/'target/installed-independent-qualification/source/target/independent-installed-current-02'
new_output=ROOT/'target/contract-purpose-admission/source-current/target/contract-purpose-installed'
programs={}; relocations={}
(outside/'programs').mkdir(); (OUT/'programs').mkdir()
for name,built in [('before',old_output),('after',new_output)]:
    report_data=data(built/'INSTALLED_COUNTERPART.json'); report=json.loads(report_data)
    origin=Path(json.loads((built/'LOCATION.json').read_text())['path'])/'consumer-build/release/q-periapt-independent-peer-counterpart'
    binary=data(origin); target=outside/'programs'/name
    if sha(binary)!=report['native_sha256']: raise ValueError('original installed binary changed')
    target.write_bytes(binary); target.chmod(0o700)
    captured=OUT/'programs'/(name+'-INSTALLED_COUNTERPART.json'); captured.write_bytes(report_data)
    (OUT/'programs'/(name+'-counterpart')).write_bytes(binary)
    archive=data(built/report['candidate_archive']['file'])
    if sha(archive)!=report['candidate_archive']['sha256']: raise ValueError('installed candidate archive changed')
    (OUT/'programs'/(name+'.crate')).write_bytes(archive)
    programs[name]={'executable':str(target),'installation_report':str(captured),'installation_report_sha256':sha(report_data)}
    relocations[name]={'origin':str(origin),'destination':str(target),'sha256':sha(binary)}
write(OUT/'PROGRAM_RELOCATION.json',relocations)
prior=ROOT/'target/installed-independent-qualification/source/target/independent-installed-lifecycle-01'
wheel=prior/(PACKAGE+'-0.0.0-py3-none-any.whl'); wheel_data=data(wheel)
if sha(wheel_data)!='596bba62781296558a64d768a12ed618043b8cf3e14070cdf81c2ed423d3a094': raise ValueError('wheel identity changed')
modules={p.name:data(p) for p in sorted((SOURCE/PACKAGE).glob('*.py'))}
expected={n:sha(b) for n,b in modules.items()}
files=inspect_wheel(wheel_data,modules,{n:data(SOURCE/n) for n in ('LICENSE-APACHE','LICENSE-MIT')},data(SOURCE/'README.md'))
captured=OUT/wheel.name; captured.write_bytes(wheel_data)
requirements=OUT/'wheel-requirements.txt'; requirements.write_text(captured.as_uri()+' --hash=sha256:'+sha(wheel_data)+'\n')
run([sys.executable,'-I','-m','pip','install','--isolated','--disable-pip-version-check','--no-index','--no-deps','--no-compile','--require-hashes','--target',str(application),'-r',str(requirements)],'install',cwd=outside)
installed=installed_files(application)
verify_installation(installed,files,wheel_url=captured.as_uri(),digest=sha(wheel_data))
write(OUT/'INSTALLED_FILES.json',{n:sha(b) for n,b in installed.items()})
write(OUT/'EXPECTED_MODULES.json',expected)
for path in helpers:
    target=outside/path.relative_to(ROOT); target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data(path))
provider=Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
interpreter=[sys.executable,'-I','-S','-B',str(outside/'artifact/python_bootstrap.py')]
probe=[*interpreter,str(outside/'artifact/continuity_independent_python_probe.py'),str(application),str(provider),str(ROOT),str(OUT/'EXPECTED_MODULES.json')]
run([*probe,str(OUT/'PROVENANCE_BEFORE.json')],'probe-before',cwd=outside)
base=[*interpreter,str(application/'enrollment_session_checks.py'),'--implementation-root',str(application),'--provider-root',str(provider),'--native',programs['before']['executable'],'--root-successor-process-restart','peer']
run([*base,'--output',str(OUT/'single-program')],'single-program',cwd=outside)
cuts=['approved','reply','final','active','receive','outbox','ack','rekey-response','rekey-receipt','new-epoch']
plan={'schema_version':1,'programs':programs,'restarts':[{'case':cut,'program':'before' if i%2==0 else 'after'} for i,cut in enumerate(cuts)]}
write(OUT/'PLAN.json',plan)
run([*base,'--native-restart-program-plan',str(OUT/'PLAN.json'),'--output',str(OUT/'two-program')],'two-program',cwd=outside)
run([*probe,str(OUT/'PROVENANCE_AFTER.json')],'probe-after',cwd=outside)
for rel,digest in inputs.items():
    if sha(data(outside/rel)) != digest or sha(data(ROOT/rel)) != digest: raise ValueError('controller changed')
if {p.name:sha(data(p)) for p in (application/PACKAGE).glob('*.py')} != expected: raise ValueError('installed modules changed')
for name,program in programs.items():
    if sha(data(Path(program['executable']))) != relocations[name]['sha256']: raise ValueError('binary changed')
write(OUT/'EXECUTION.json',{'completed':True,'controller_commit':commit,'installed_modules':len(expected),'wheel_sha256':sha(wheel_data),
    'programs':relocations,'scenario_results':['single-program/RESULT.json','two-program/RESULT.json'],'sources_unchanged':True,
    'scope':'Two installed candidate program builds and a freshly installed independent wheel on Apple Silicon; same-format state, synthetic fixture clocks, no product-version or power-loss qualification.'})
print(json.dumps({'completed':True,'outside':str(outside),'controller_commit':commit}))
