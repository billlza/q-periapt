from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-hidden-record-commitments'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-hidden-record-commitments'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
audit = json.loads((BASE / 'AUDIT.json').read_bytes())
for kind in ['source_inputs', 'document_inputs']:
    for name, item in audit[kind].items():
        data = (ROOT / name).read_bytes()
        assert len(data) == item['bytes'] and sha(data) == item['sha256'], name
files = {}
for p in BASE.rglob('*'):
    assert not p.is_symlink()
    if p.is_file(): files['capture/' + p.relative_to(BASE).as_posix()] = p.read_bytes()
for name in audit['document_inputs']: files['documents/' + name] = (ROOT / name).read_bytes()
files['FILES.json'] = encode({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())})
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
payload = buf.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(files) and set(archive.namelist()) == set(files)
    for name, data in files.items(): assert archive.read(name) == data
summary = {'created_utc': datetime.now(timezone.utc).isoformat(), 'bytes': len(payload),
    'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True,
    'source_files': len(audit['source_inputs']), 'document_files': len(audit['document_inputs']),
    'source_inputs_unchanged': True, 'release_claim_eligible': False}
for name, data in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']),
                   ('AUDIT.json', encode(audit)), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as f: f.write(data)
print(json.dumps(summary, indent=2), flush=True)
