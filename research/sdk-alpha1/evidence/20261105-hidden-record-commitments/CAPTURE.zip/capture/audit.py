from pathlib import Path
from datetime import datetime, timezone
from itertools import combinations
import hashlib
import json
import re
import subprocess

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-hidden-record-commitments'
SOURCE = ROOT / 'research/continuity-identity-candidate'
PIN = 'eb08f978d4fa6a3fc1970ab0194007d21ade7355'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == PIN
paths = {p for p in (SOURCE / 'src/durable/write_intent').rglob('*.rs')
         if 'tests' not in p.parts and not p.name.endswith('tests.rs')}
paths.update(SOURCE / p for p in [
    'src/crypto.rs', 'src/durable.rs', 'src/durable/write_intent.rs',
    'src/anchor/roster_refresh.rs', 'src/anchor/pending_recovery.rs',
    'src/anchor/store/retired_cleanup.rs', 'src/durable/pending_recovery.rs',
    'src/durable/retired_report.rs', 'src/durable/messages/retired.rs',
    'src/enrollment/managed_root/transferred.rs', 'src/enrollment/retirement.rs',
    'src/enrollment/retirement/codec.rs', 'src/enrollment/retirement/transferred.rs',
])
source = {}
inventory = {}
for p in sorted(paths):
    name = p.relative_to(ROOT).as_posix()
    body = p.read_bytes()
    original = subprocess.check_output(['git', 'show', PIN + ':' + name])
    assert body == original, name
    source[p.relative_to(SOURCE).as_posix()] = body.decode()
    inventory[name] = {'bytes': len(body), 'sha256': sha(body)}
    dest = BASE / 'source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('xb') as f: f.write(body)

crypto = source['src/crypto.rs']
assert 'hash.update((domain.len() as u64).to_be_bytes());' in crypto
assert 'hash.update(domain);' in crypto
assert 'hash.update((length as u64).to_be_bytes());' in crypto
image = source['src/durable.rs']
assert 'const HEADER: usize = 8 + 32 + 32 + 8 + 24;' in image
assert image.index('let mut plaintext = crate::codec::encode_secret', image.index('fn seal(')) < image.index('let mut nonce = [0; 24]', image.index('fn seal('))
assert 'wire.extend_from_slice(&nonce);' in image
image_struct = image.split('struct Image {', 1)[1].split('\n}', 1)[0]
assert 'nonce' not in image_struct and 'wire:' not in image_struct
assert 'digest: image_hash(wire),' in image
intent = source['src/durable/write_intent.rs']
assert 'const INTENT_HEADER: usize = 8 + 32 + 32 + 8 + 32 + 8 + 32 + 4;' in intent
body = intent.split('    fn new_bound(', 1)[1].split('    fn decode(', 1)[0]
assert 'wire.extend_from_slice(&image_hash(target));' in body
assert 'wire.extend_from_slice(target);' in body
assert 'auth.update(&wire);' in body
bindings = {'QPWINT01': 0, 'QPWINT02': 64, 'QPWINT04': 97, 'QPWINT08': 97,
            'QPWINT06': 64, 'QPWINT07': 185, 'QPWINT10': 185, 'QPWINT11': 185}
assert set(re.findall(r'b"(QPWINT[0-9]{2})"', body)) == set(bindings)
assert 'pub(crate) const ENCODED_BYTES: usize = 185;' in source['src/anchor/roster_refresh.rs']
assert 32 + 3 * (8 + 32) + 1 + 32 == 185
cancellation = source['src/durable/write_intent/credential_cancellation.rs']
cancel_new = cancellation.split('    fn new(', 1)[1].split('    pub(super) fn decode(', 1)[0]
assert set(re.findall(r'b"(QPWINT[0-9]{2})"', cancel_new)) == {'QPWINT03', 'QPWINT05', 'QPWINT09'}
assert 'wire.extend_from_slice(&cancellation.to_bytes());' in cancel_new
assert 'wire.extend_from_slice(target)' not in cancel_new
assert 'pending.binding.is_none()' in source['src/durable/write_intent/pending_recovery.rs']

spec = [
    ('Q-PERIAPT-CONTINUITY-VAULT-IMAGE-CANDIDATE/v2', 'src/durable.rs'),
    ('Q-PERIAPT-CONTINUITY-PENDING-WRITE-INTENT/v1', 'src/durable/write_intent/pending_recovery.rs'),
    ('Q-PERIAPT-CONTINUITY-RETIRED-LOCAL-INTENT/v1', 'src/durable/write_intent/retired_cleanup.rs'),
    ('Q-PERIAPT-CONTINUITY-ACCOUNT-ROOT-LOCAL-INTENT/v1', 'src/durable/write_intent/account_root.rs'),
    ('Q-PERIAPT-CONTINUITY-WITNESS-HANDOFF-PENDING/v1', 'src/durable/write_intent/witness_handoff/codec.rs'),
    ('Q-PERIAPT-MANAGED-ROOT-ORIGINAL-RECORD/v1', 'src/durable/write_intent/account_root/witness/preparation.rs'),
]
domains = []
for i, (domain, name) in enumerate(spec):
    assert ('b"' + domain + '"') in source[name]
    lines = [n for n, line in enumerate(source[name].splitlines(), 1) if ('b"' + domain + '"') in line]
    prefix = len(domain).to_bytes(8, 'big') + domain.encode()
    domains.append({'index': i, 'domain': domain, 'domain_bytes': len(domain),
        'domain_prefix_hex': prefix.hex(), 'source': name, 'lines': lines})
assert [d['domain_bytes'] for d in domains] == [45, 44, 44, 49, 47, 41]
pairs = []
for a, b in combinations(domains, 2):
    x = bytes.fromhex(a['domain_prefix_hex'])
    y = bytes.fromhex(b['domain_prefix_hex'])
    n = next(i for i, (u, v) in enumerate(zip(x, y)) if u != v)
    pairs.append({'types': [a['index'], b['index']], 'first_distinct_prefix_byte': n})
assert len(pairs) == 15
layouts = []
for tag, binding in bindings.items():
    start = 156 + binding + 80
    layouts.append({'tag': tag, 'binding_bytes': binding, 'target_offset': 156 + binding,
        'nonce_in_intent': [start, start + 24],
        'nonce_in_hash_input': {str(d['index']): [16 + d['domain_bytes'] + start, 16 + d['domain_bytes'] + start + 24] for d in domains[1:]},
        'ordinary_pending_recovery_admitted_by_source': tag == 'QPWINT01'})

uses = []
pattern = re.compile(r'p\.wire\(\)|pending\.wire|pending\.target|original_child_checkpoint|fn pending_digest')
for name, text in sorted(source.items()):
    for n, line in enumerate(text.splitlines(), 1):
        if pattern.search(line): uses.append({'source': name, 'line': n, 'text': line.strip()})

docs = ['docs/continuity/HIDDEN_RECORD_COMMITMENTS_V1.md',
        'docs/continuity/COMPUTATIONAL_RECOVERY_V1.md', 'docs/continuity/EXTERNAL_REVIEW_BRIEF.md',
        'research/sdk-alpha1/evidence/20261105-hidden-record-commitments/README.md']
doc_inputs = {}
local_links = 0
for name in docs:
    p = ROOT / name
    data = p.read_bytes()
    for link in re.findall(r'\]\(([^)]+)\)', data.decode()):
        if '://' not in link and not link.startswith('#'):
            assert (p.parent / link.split('#', 1)[0]).resolve().is_file(), (name, link)
            local_links += 1
    doc_inputs[name] = {'bytes': len(data), 'sha256': sha(data)}
for name, record in inventory.items(): assert sha((ROOT / name).read_bytes()) == record['sha256']
result = {'completed_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': PIN,
    'source_inputs': inventory, 'document_inputs': doc_inputs, 'source_inputs_unchanged': True,
    'domains': domains, 'distinct_domain_prefix_pairs': pairs, 'write_layouts': layouts,
    'image_nonce_offset': [80, 104], 'image_nonce_hash_input_offset': [141, 165],
    'cancellation_tags_without_target': ['QPWINT03', 'QPWINT05', 'QPWINT09'],
    'raw_record_use_search': uses, 'local_document_links_checked': local_links,
    'scope': 'Source identity, explicit encoding arithmetic, domain-prefix comparisons, search inventory, and local document link checks only.',
    'native_execution_performed': False, 'proof_checker_performed': False,
    'whole_program_nonce_closure_established': False, 'accepted_prefix_simulator_complete': False,
    'release_claim_eligible': False,
    'primary_reference': {'url': 'https://arxiv.org/pdf/2206.08132',
        'version': '2206.08132v3', 'theorem': 'Theorem 2, equations (6)-(7)',
        'consulted_utc_date': '2026-11-05'}}
with (BASE / 'AUDIT.json').open('xb') as f: f.write(encode(result))
print(json.dumps({'source_files': len(inventory), 'domains': len(domains),
    'prefix_pairs': len(pairs), 'write_tags': len(layouts), 'raw_record_use_hits': len(uses),
    'local_document_links': local_links, 'completed': True}, indent=2), flush=True)
