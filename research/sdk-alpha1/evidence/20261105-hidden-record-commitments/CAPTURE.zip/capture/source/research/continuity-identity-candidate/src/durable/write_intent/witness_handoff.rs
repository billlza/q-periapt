// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Adopt witness authority without resealing the original image or pending work.
use super::*;
use crate::{
    AnchorHandoffAdoptionMaterials, AnchorHandoffClientAuthorizationReceipt, AnchorHandoffHistory,
    HistoricalAnchorHandoffAdoption,
};
mod cancellation;
mod codec;
mod guard;
mod lineage;
mod reconciliation;
mod successor;
mod transaction;
use codec::Fence;
pub(super) use guard::{Guard, Selection};
pub(crate) use lineage::WitnessAdoptionLineage;
use successor::Predecessor;
#[cfg(all(test, unix))]
pub(super) fn test_boundary(stage: &str, after: bool) {
    tests::boundary(stage, after);
}
pub use reconciliation::WitnessPendingRecovery;
#[cfg(all(test, unix))]
pub(in crate::durable::write_intent) mod tests;

pub(super) const ROW: &str = "witness-handoff";

pub(super) fn check_account_root_selection(
    key: &JournalKey,
    image: &Image,
    pending: Option<&PendingIntent>,
    wire: &[u8],
    plan: &WitnessJournalAdoptionPlan,
) -> Result<WitnessSelectionProgress, DurableError> {
    let fence = Fence::decode(key, wire)?;
    fence.check(image, pending)?;
    plan.check_image(image)?;
    plan.check_selection(
        &fence.request,
        fence.prepared_at,
        fence.receipt.as_deref(),
        &fence.lineage,
    )?;
    Ok(WitnessSelectionProgress {
        prepared_at: fence.prepared_at,
        receipt: fence.receipt,
        lineage: fence.lineage,
    })
}

/// Independently verified exact approval and history for one original journal.
/// Retain these original inputs in the host's authenticated controller before
/// starting. Neither incoming storage nor a peer may select a replacement plan.
#[derive(Clone)]
pub struct WitnessJournalAdoptionPlan {
    request: Vec<u8>,
    approved: HistoricalAnchorHandoffAdoption,
    history: AnchorHandoffHistory,
    account: [u8; 32],
    device: crate::PublicKey,
    predecessor: Option<Box<Predecessor>>,
}
impl WitnessJournalAdoptionPlan {
    pub(super) fn check_account_root_history(
        &self,
        logical: &crate::AnchorPin,
        history: &AnchorHandoffHistory,
    ) -> Result<(), DurableError> {
        if self.scope().logical != logical.binding() {
            return Err(Error::Scope.into());
        }
        if history.checkpoint() != self.history.checkpoint() {
            history.require_extension_of(&self.history)?;
        }
        Ok(())
    }
    /// Revalidate both root approvals against independent identity, policy and
    /// activation material. Expired material is historical, not renewed traffic
    /// permission. New local preparation separately checks the admission window.
    pub fn new(
        approved: &HistoricalAnchorHandoffAdoption,
        materials: &AnchorHandoffAdoptionMaterials<'_>,
    ) -> Result<Self, Error> {
        Ok(Self {
            request: approved.prepare_witness_authorization(materials)?,
            approved: approved.clone(),
            history: materials.history.clone(),
            account: materials.original_device.account,
            device: materials.original_device.key.clone(),
            predecessor: None,
        })
    }
    /// Exact public request to use for the target authorization transaction.
    pub fn authorization_request(&self) -> &[u8] {
        &self.request
    }
    /// Independently approved original statement, not a persisted-adoption claim.
    pub fn scope(&self) -> &crate::AnchorHandoffAdoptionScope {
        self.approved.scope()
    }
    pub(crate) fn check_original_enrollment(
        &self,
        device: &crate::VerifiedDevice,
        policy: &crate::HistoricalSessionPolicy,
        identity: JournalIdentity,
    ) -> Result<(), DurableError> {
        self.check_original_enrollment_binding(
            device,
            identity,
            policy.checkpoint().digest(),
            policy.anchor_requirement().binding().ok_or(Error::Scope)?,
        )
    }
    pub(crate) fn check_original_enrollment_binding(
        &self,
        device: &crate::VerifiedDevice,
        identity: JournalIdentity,
        policy: [u8; 32],
        logical: [u8; 32],
    ) -> Result<(), DurableError> {
        let scope = self.scope();
        if self.account != device.account_id()
            || self.device != device.key
            || scope.subject.journal_parts()
                != (
                    *identity.as_bytes(),
                    bootstrap::storage_owner(device),
                    policy,
                )
            || logical != scope.logical
        {
            return Err(Error::Scope.into());
        }
        Ok(())
    }
    fn check_image(&self, image: &Image) -> Result<(), DurableError> {
        let Protection::Required {
            policy, witness, ..
        } = image.protection
        else {
            return Err(DurableError::AnchorRequired);
        };
        let scope = self.scope();
        if scope.subject.journal_parts() != (image.id, image.owner, policy)
            || scope.logical != witness
            || self.account != image.local_account
        {
            return Err(Error::Scope.into());
        }
        Ok(())
    }
    fn verify_receipt(
        &self,
        wire: &[u8],
    ) -> Result<AnchorHandoffClientAuthorizationReceipt, Error> {
        AnchorHandoffClientAuthorizationReceipt::verify(wire, &self.approved, &self.history)
    }
}

/// Durable control-plane progress. Neither state asserts current credential or
/// policy permission, or successful reconciliation of an original G/P/R.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WitnessJournalAdoptionState {
    /// Original local snapshot and exact issuer decision are fenced; the target
    /// may already have committed an authorization whose response was lost.
    Prepared,
    /// The exact target authorization is durably selected for this journal.
    /// Original pending operations still require transfer-aware reconciliation.
    Adopted,
}
struct Owners {
    client: Option<crate::AnchorClient>,
    db: Database,
    key: JournalKey,
    plan: WitnessJournalAdoptionPlan,
}
#[derive(Clone)]
pub(crate) struct WitnessSelectionProgress {
    pub(crate) prepared_at: u64,
    pub(crate) receipt: Option<Vec<u8>>,
    pub(crate) lineage: WitnessAdoptionLineage,
}
impl Owners {
    fn snapshot(&self) -> Result<(Image, Option<PendingIntent>), DurableError> {
        let owner = self.plan.scope().subject.journal_parts().1;
        let snapshot = load_pending_snapshot(
            &self.db,
            &self.key,
            owner,
            SnapshotAdmission::WitnessHandoff,
        )?;
        self.plan.check_image(&snapshot.0)?;
        Ok(snapshot)
    }
    fn stored_selection(&self) -> Result<Fence, DurableError> {
        let (image, pending) = self.snapshot()?;
        let read = self.db.begin_read().map_err(storage)?;
        let table = image_table(&read)?;
        let saved = table
            .get(ROW)
            .map_err(storage)?
            .ok_or(DurableError::Absent)?;
        let fence = Fence::decode(&self.key, saved.value())?;
        fence.check(&image, pending.as_ref())?;
        Ok(fence)
    }
    fn read(&self) -> Result<Fence, DurableError> {
        let fence = self.stored_selection()?;
        self.plan.check_selection(
            &fence.request,
            fence.prepared_at,
            fence.receipt.as_deref(),
            &fence.lineage,
        )?;
        Ok(fence)
    }
}

/// Exclusive owner of the original journal's durable witness selection. Its
/// current client can be transferred to the original coordinator; the journal
/// and installation still enforce all pending-work and traffic admission checks.
/// Keep the independently approved plan when reopening; missing state never
/// authorizes fallback to the old witness or provisioning another journal.
/// ```compile_fail
/// use q_periapt_continuity_identity_candidate::{DeviceJournal, WitnessJournalAdoption};
/// fn traffic(owner: WitnessJournalAdoption) -> DeviceJournal { owner }
/// ```
pub struct WitnessJournalAdoption {
    active: Option<Owners>,
}
impl WitnessJournalAdoption {
    /// Consume this prepared/adopted selection into an independently approved
    /// account-root recovery. The selection and original pending work remain
    /// byte-for-byte retained; this does not release a traffic-capable owner.
    pub fn begin_account_root_replacement(
        mut self,
        plan: crate::TransferredAccountRootJournalPlan,
    ) -> Result<crate::AccountRootJournalRecovery, DurableError> {
        let owner = self.active.take().ok_or(DurableError::Closed)?;
        owner.read()?;
        let (identity, original_owner, _) = owner.plan.scope().subject.journal_parts();
        crate::AccountRootJournalRecovery::prepare_transferred_database(
            owner.db,
            owner.key,
            original_owner,
            JournalIdentity(identity),
            plan,
        )
    }
    /// Prepare on existing original storage or reconcile this exact preparation.
    /// An explicitly approved `continue_from` plan can advance only its exact
    /// durably adopted predecessor. Other existing decisions are never replaced;
    /// missing state is admissible only for a first selection. New decisions
    /// require fresh admission, while exact retained retries are historical.
    pub fn prepare_original(
        path: &Path,
        key: JournalKey,
        plan: WitnessJournalAdoptionPlan,
        trusted_time: impl FnMut() -> Result<u64, DurableError>,
    ) -> Result<Self, DurableError> {
        Self::prepare_in_database(open_private_database(path)?, key, plan, trusted_time)
    }
    pub(crate) fn prepare_in_database(
        db: Database,
        key: JournalKey,
        plan: WitnessJournalAdoptionPlan,
        trusted_time: impl FnMut() -> Result<u64, DurableError>,
    ) -> Result<Self, DurableError> {
        Owners {
            client: None,
            db,
            key,
            plan,
        }
        .prepare(trusted_time)
    }
    /// Open only an already prepared original. Missing/damaged control state is
    /// an error, even if the old encrypted image alone still parses. The host's
    /// independently retained plan/checkpoint is required after process restart.
    pub fn resume_original(
        path: &Path,
        key: JournalKey,
        plan: WitnessJournalAdoptionPlan,
    ) -> Result<Self, DurableError> {
        Self::resume_in_database(open_private_database(path)?, key, plan)
    }
    pub(crate) fn resume_in_database(
        db: Database,
        key: JournalKey,
        plan: WitnessJournalAdoptionPlan,
    ) -> Result<Self, DurableError> {
        let owner = Owners {
            client: None,
            db,
            key,
            plan,
        };
        owner.read()?;
        Ok(Self {
            active: Some(owner),
        })
    }
    pub(crate) fn enrollment_selection(&self) -> Result<WitnessSelectionProgress, DurableError> {
        let fence = self.active.as_ref().ok_or(DurableError::Closed)?.read()?;
        Ok(WitnessSelectionProgress {
            prepared_at: fence.prepared_at,
            receipt: fence.receipt,
            lineage: fence.lineage,
        })
    }
    /// Observe authenticated local progress without contacting either witness.
    pub fn status(&mut self) -> Result<WitnessJournalAdoptionState, DurableError> {
        let result = self
            .active
            .as_ref()
            .ok_or(DurableError::Closed)
            .and_then(Owners::read)
            .map(|f| {
                if f.receipt.is_some() {
                    WitnessJournalAdoptionState::Adopted
                } else {
                    WitnessJournalAdoptionState::Prepared
                }
            });
        if result.is_err() {
            self.close();
        }
        result
    }
    /// Recover the exact committed target receipt without a signing key. This
    /// does not classify original pending operations or renew their permissions.
    pub fn authorization_receipt(
        &mut self,
    ) -> Result<AnchorHandoffClientAuthorizationReceipt, DurableError> {
        let result = (|| {
            let owner = self.active.as_ref().ok_or(DurableError::Closed)?;
            let receipt = owner.read()?.receipt.ok_or(DurableError::Absent)?;
            Ok(owner.plan.verify_receipt(&receipt)?)
        })();
        if result.is_err() {
            self.close();
        }
        result
    }
    /// Release this lease and key; preserve all original data and control state.
    pub fn close(&mut self) {
        self.active = None;
    }
}
impl DeviceJournal {
    /// Consume this owner and fence its original image and pending intent. Any
    /// error consumes the handle and may follow commit; reconcile the same plan
    /// on the same original path/key. No encrypted state is resealed or advanced.
    pub fn begin_witness_handoff(
        &mut self,
        plan: WitnessJournalAdoptionPlan,
        trusted_time: impl FnMut() -> Result<u64, DurableError>,
    ) -> Result<WitnessJournalAdoption, DurableError> {
        let active = self.active.take().ok_or(DurableError::Closed)?;
        Owners {
            client: None,
            db: active.db,
            key: active.key,
            plan,
        }
        .prepare(trusted_time)
    }
}
pub(super) fn validate_snapshot(
    key: &JournalKey,
    image: &Image,
    pending: Option<&PendingIntent>,
    wire: &[u8],
    client: Option<&crate::AnchorClient>,
) -> Result<(), DurableError> {
    let fence = Fence::decode(key, wire)?;
    fence.check(image, pending)?;
    if let Some(client) = client {
        client.check_journal_selection(
            &fence.request,
            fence.receipt.as_deref().ok_or(DurableError::Suspended)?,
            fence.lineage.checkpoint(fence.prepared_at)?,
        )?;
    }
    Ok(())
}
