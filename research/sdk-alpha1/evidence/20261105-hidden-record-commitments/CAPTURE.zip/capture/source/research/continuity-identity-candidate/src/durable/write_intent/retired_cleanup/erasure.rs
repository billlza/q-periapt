// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Atomic logical retirement of the exact independently acknowledged journal inventory.
use super::*;
use crate::{
    durable::retired_report::transferred::authority::ReceiptAuthority,
    retired_device::JournalErasureState, AnchorRetiredReportProposal,
    AnchorTransferredCleanupReceipt,
};

const TAG: &[u8; 8] = b"QPRJER01";
const TRANSFERRED_TAG: &[u8; 8] = b"QPRJER02";
const RECEIPT_BYTES: usize = 3730;

struct Scope<'a> {
    key: &'a JournalKey,
    identity: JournalIdentity,
    retired: AnchorRetiredSubject,
    authority: ReceiptAuthority<'a>,
    report: &'a AnchorRetiredReportProposal,
}
impl<'a> Scope<'a> {
    fn new(
        key: &'a JournalKey,
        identity: JournalIdentity,
        retired: AnchorRetiredSubject,
        authority: ReceiptAuthority<'a>,
        report: &'a AnchorRetiredReportProposal,
    ) -> Result<Self, DurableError> {
        report.inventory().check_retirement(retired)?;
        authority.check_scope(retired)?;
        if *identity.as_bytes() != report.inventory().subject().journal_parts().0 {
            return Err(DurableError::Conflict);
        }
        Ok(Self {
            key,
            identity,
            retired,
            authority,
            report,
        })
    }
    fn authenticator(&self) -> Result<Hmac<Sha256>, DurableError> {
        let mut derived = ZeroizingBytes::<32>::zeroed();
        hkdf::Hkdf::<Sha256>::new(None, self.key.0.as_bytes())
            .expand(
                b"Q-PERIAPT-CONTINUITY-RETIRED-JOURNAL-TERMINAL-KEY/v1",
                derived.as_mut_bytes(),
            )
            .map_err(|_| Error::Provider)?;
        <Hmac<Sha256> as hmac::KeyInit>::new_from_slice(derived.as_bytes())
            .map_err(|_| Error::Provider.into())
    }
    fn verify_receipt(&self, wire: &[u8]) -> Result<(), DurableError> {
        self.authority.verify_ack(self.retired, self.report, wire)?;
        Ok(())
    }
    fn read_terminal(&self, db: &Database) -> Result<bool, DurableError> {
        let read = db.begin_read().map_err(storage)?;
        let table = image_table(&read)?;
        let Some(row) = table.get("retired").map_err(storage)? else {
            return Ok(false);
        };
        let bytes = row.value();
        let (tag, offset, receipt_bytes) = if self.authority.context().is_some() {
            (TRANSFERRED_TAG, 40, AnchorTransferredCleanupReceipt::BYTES)
        } else {
            (TAG, 8, RECEIPT_BYTES)
        };
        let body_bytes = offset + receipt_bytes;
        if table.len().map_err(storage)? != 1
            || bytes.len() != body_bytes + 32
            || bytes.get(..8) != Some(tag.as_slice())
        {
            return Err(DurableError::Corrupt);
        }
        let body = bytes.get(..body_bytes).ok_or(DurableError::Corrupt)?;
        let mut mac = self.authenticator()?;
        mac.update(body);
        mac.verify_slice(bytes.get(body_bytes..).ok_or(DurableError::Corrupt)?)
            .map_err(|_| DurableError::Corrupt)?;
        if let Some(context) = self.authority.context() {
            if body.get(8..40) != Some(context.binding().as_slice()) {
                return Err(DurableError::Conflict);
            }
        }
        self.verify_receipt(body.get(offset..).ok_or(DurableError::Corrupt)?)?;
        Ok(true)
    }
    fn check_inventory(
        &self,
        db: &Database,
    ) -> Result<(Image, Option<PendingIntent>), DurableError> {
        let (image, pending, actual) = snapshot(
            db,
            self.key,
            self.identity,
            self.retired,
            self.authority.context(),
        )?;
        if &actual != self.report.inventory() {
            return Err(DurableError::Conflict);
        }
        Ok((image, pending))
    }
    fn erase(&self, db: &Database, receipt: &[u8]) -> Result<(), DurableError> {
        // The caller verifies this receipt before database admission. A saved terminal
        // authenticates its own receipt; equivalent fresh signatures need not be equal.
        if self.read_terminal(db)? {
            return Ok(());
        }
        let (original_image, original_pending) = self.check_inventory(db)?;
        let mut terminal = if let Some(context) = self.authority.context() {
            let mut body = TRANSFERRED_TAG.to_vec();
            body.extend_from_slice(&context.binding());
            body
        } else {
            TAG.to_vec()
        };
        terminal.extend_from_slice(receipt);
        let mut mac = self.authenticator()?;
        mac.update(&terminal);
        terminal.extend_from_slice(&mac.finalize().into_bytes());
        let tx = transaction(db)?;
        {
            let mut table = tx.open_table(TABLE).map_err(storage)?;
            let inventory = self.report.inventory();
            // Bind the destructive transaction to the exact bytes just authenticated,
            // including genuine absence of a pending intent. No basename replacement.
            let image = table
                .get("image")
                .map_err(storage)?
                .ok_or(DurableError::Corrupt)?;
            let pending = table.get("pending").map_err(storage)?;
            let root_fence = table.get("account-root-fence").map_err(storage)?;
            let selection = table.get(witness_handoff::ROW).map_err(storage)?;
            if let Some(context) = self.authority.context() {
                account_root::validate_transferred_retired_snapshot(
                    self.key,
                    &original_image,
                    original_pending.as_ref(),
                    root_fence.as_ref().ok_or(DurableError::Conflict)?.value(),
                    selection.as_ref().map(|row| row.value()),
                    context,
                )?;
            } else {
                if selection.is_some() {
                    return Err(DurableError::Suspended);
                }
                if let Some(fence) = &root_fence {
                    account_root::validate_retired_fence(self.key, fence.value(), self.retired)?;
                }
            }
            let pending_hash = pending
                .as_ref()
                .map(|p| digest(b"Q-PERIAPT-CONTINUITY-RETIRED-LOCAL-INTENT/v1", p.value()));
            if image_hash(image.value()) != inventory.stored_image_digest()
                || pending_hash != inventory.pending_intent_digest()
                || table.len().map_err(storage)?
                    != 1 + u64::from(pending.is_some())
                        + u64::from(root_fence.is_some())
                        + u64::from(selection.is_some())
            {
                return Err(DurableError::Conflict);
            }
            drop(image);
            drop(pending);
            drop(root_fence);
            drop(selection);
            table.remove(witness_handoff::ROW).map_err(storage)?;
            table.remove("account-root-fence").map_err(storage)?;
            table.remove("image").map_err(storage)?;
            table.remove("pending").map_err(storage)?;
            table
                .insert("retired", terminal.as_slice())
                .map_err(storage)?;
        }
        #[cfg(all(test, unix))]
        at_boundary("before-commit");
        tx.commit().map_err(DurableError::CommitUncertain)?;
        #[cfg(all(test, unix))]
        at_boundary("after-commit");
        Ok(())
    }
}

impl DeviceJournal {
    pub(crate) fn retired_journal_has_terminal(
        db: &Database,
        key: &JournalKey,
        identity: JournalIdentity,
        retired: AnchorRetiredSubject,
        authority: ReceiptAuthority<'_>,
        report: &AnchorRetiredReportProposal,
    ) -> Result<bool, DurableError> {
        let scope = Scope::new(key, identity, retired, authority, report)?;
        scope.read_terminal(db)
    }
    pub(crate) fn retired_journal_state(
        db: &Database,
        key: &JournalKey,
        identity: JournalIdentity,
        retired: AnchorRetiredSubject,
        authority: ReceiptAuthority<'_>,
        report: &AnchorRetiredReportProposal,
    ) -> Result<JournalErasureState, DurableError> {
        let scope = Scope::new(key, identity, retired, authority, report)?;
        if scope.read_terminal(db)? {
            return Ok(JournalErasureState::Erased);
        }
        scope.check_inventory(db)?;
        Ok(JournalErasureState::Retained)
    }
    pub(crate) fn erase_retired_journal_in_database(
        db: &Database,
        key: &JournalKey,
        identity: JournalIdentity,
        retired: AnchorRetiredSubject,
        authority: ReceiptAuthority<'_>,
        report: &AnchorRetiredReportProposal,
        receipt: &[u8],
    ) -> Result<(), DurableError> {
        let scope = Scope::new(key, identity, retired, authority, report)?;
        scope.verify_receipt(receipt)?;
        scope.erase(db, receipt)
    }
}

#[cfg(all(test, unix))]
fn at_boundary(stage: &str) {
    if std::env::var("QPERIAPT_RETIRED_ERASURE_STAGE")
        .ok()
        .as_deref()
        != Some(stage)
    {
        return;
    }
    let root = std::env::var_os("QPERIAPT_RETIRED_ERASURE_CHILD").expect("owned child root");
    let root = Path::new(&root);
    use std::io::Write;
    let mut ready = std::fs::File::create_new(root.join("erasure-ready.pending")).expect("ready");
    ready.write_all(stage.as_bytes()).expect("stage");
    ready.sync_all().expect("ready durable");
    std::fs::rename(
        root.join("erasure-ready.pending"),
        root.join("erasure-ready"),
    )
    .expect("ready name");
    loop {
        std::thread::park();
    }
}
