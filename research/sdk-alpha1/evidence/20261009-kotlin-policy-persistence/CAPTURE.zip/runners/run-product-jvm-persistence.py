from pathlib import Path
import hashlib, json, os, subprocess, time

b = Path(__file__).resolve().parent
root = b.parents[1]
out = b / 'kotlin-persistence-product-package-01'
out.mkdir()
tc = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
jvm = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed')
jdk = jvm / 'jdk-25.0.4.1+1/Contents/Home'
native = root / 'target/policy-recovery-ffi-current/source/target/policy-enrollment-c-package-01'
archive = native / 'q-periapt-c-abi2-0.2.0-aarch64-apple-darwin.tar.gz'
manifest = native / 'q-periapt-c-abi2-0.2.0-aarch64-apple-darwin/MANIFEST.json'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'bb8729cd27019bcd9dc2ef470481ee48215c82333e261ac567fa9f71478da40b'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == 'b300e3537ab891106f003e6429cfd1c73ebe417f86c1a4edbf3cfe8d875d7023'
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO', 'RUST', 'JAVA', 'JDK', 'GRADLE', 'QPERIAPT', 'DYLD', 'LD_', 'PYTHON', 'KOTLIN')) and k not in ('_JAVA_OPTIONS', 'CLASSPATH')}
env.update(JAVA_HOME=str(jdk), GRADLE_USER_HOME=str(b / 'kotlin-gradle-home'),
           PATH=f'{jdk}/bin:{tc}/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
           QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',
           DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cmd = ['sh', 'artifact/python-run.sh', 'artifact/jvm_sdk_package.py', '--offline',
       '--gradle', str(jvm / 'gradle-9.8.0/bin/gradle'), '--output', str(out / 'package'),
       '--native-archive', str(archive),
       '--native-sha256', 'bb8729cd27019bcd9dc2ef470481ee48215c82333e261ac567fa9f71478da40b',
       '--native-manifest-sha256', 'b300e3537ab891106f003e6429cfd1c73ebe417f86c1a4edbf3cfe8d875d7023']
record = dict(command=cmd, source=str(root), scope='Product JVM archive and outside-checkout Maven/native consumers')
(out / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    p = subprocess.run(cmd, cwd=root, env=env, stdout=stdout, stderr=stderr)
record.update(returncode=p.returncode, seconds=time.monotonic() - start)
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print((out / 'stderr.log').read_text()[-6000:])
p.check_returncode()
