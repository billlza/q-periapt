from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
label, profile, *selection = sys.argv[1:]
out = base / label
out.mkdir()
source = base / 'kotlin-persistent-runtime-source/bindings/kotlin'
tools = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed')
library = base / f'purpose-review-build/{profile}/libq_periapt_ffi_abi2.dylib'
env = {k: v for k, v in os.environ.items() if not k.startswith(('JAVA', 'JDK', 'GRADLE', 'QPERIAPT', 'DYLD', 'LD_'))}
env.update(JAVA_HOME=str(tools / 'jdk-25.0.4.1+1/Contents/Home'),
           GRADLE_USER_HOME=str(base / 'kotlin-gradle-home'))
cmd = [str(tools / 'gradle-9.8.0/bin/gradle'), '--offline', '--no-daemon', '--no-watch-fs',
       '--max-workers=2', '--console=plain', '--warning-mode=fail', '--dependency-verification=strict',
       f'-Pqperiapt.lib={library}', 'test', '--rerun-tasks', *selection]
gc = 'UseSerialGC' if '--serial-gc' in selection else 'UseG1GC'
if '--serial-gc' in cmd:
    cmd.remove('--serial-gc')
init = out / 'collector.gradle'
init.write_text("allprojects { tasks.withType(Test).configureEach { jvmArgs('-XX:+" + gc + "') } }\n")
cmd.extend(['--init-script', str(init)])
inputs = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(source.rglob('*')) if p.is_file() and
          str(p.relative_to(source)).startswith(('src/', 'gradle/'))}
for p in source.glob('*.kts'):
    inputs[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
record = dict(command=cmd, source=str(source), inputs=inputs, native_library=str(library),
              native_sha256=hashlib.sha256(library.read_bytes()).hexdigest(), gc=gc,
              gc_script_sha256=hashlib.sha256(init.read_bytes()).hexdigest())
(out / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    process = subprocess.run(cmd, cwd=source, env=env, stdout=so, stderr=se)
record.update(returncode=process.returncode, seconds=time.monotonic() - start)
results = source / 'build/test-results/test'
if results.exists():
    shutil.copytree(results, out / 'test-results')
    counts = dict(tests=0, failures=0, errors=0, skipped=0)
    for path in results.glob('TEST-*.xml'):
        suite = ET.parse(path).getroot()
        for key in counts:
            counts[key] += int(suite.attrib[key])
    record['tests'] = counts
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'inputs'}))
print((out / 'stdout.log').read_text()[-4000:])
print((out / 'stderr.log').read_text()[-2500:])
process.check_returncode()
