from pathlib import Path
import json, os, subprocess, time

b = Path(__file__).resolve().parent
root = b.parents[1]
out = b / 'kotlin-persistence-native-package-01'
out.mkdir()
source = b / 'kotlin-native-package-source'
subprocess.run(['git', 'clone', '--shared', '--no-checkout', str(root), str(source)], check=True)
head = 'a671719eec6d48139075e1a9ff2e309cf2b19f9e'
subprocess.run(['git', 'checkout', '--detach', head], cwd=source, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source).strip()
tc = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','DYLD','LD_','PYTHON'))}
env.update(PATH=f'{tc}/bin:/Users/bill/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
           RUSTC=str(tc/'bin/rustc'), RUSTDOC=str(tc/'bin/rustdoc'), RUSTFLAGS='-D warnings',
           CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',
           CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2',
           QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',
           QPERIAPT_EXPECTED_GIT_COMMIT=head,
           DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cmd = ['sh', 'artifact/c-package.sh', '--profile', 'sdk-020']
record = dict(source=str(source), head=head, command=cmd)
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (out/'stdout.log').open('wb') as so, (out/'stderr.log').open('wb') as se:
    p=subprocess.run(cmd,cwd=source,env=env,stdout=so,stderr=se)
record.update(returncode=p.returncode,seconds=time.monotonic()-start,
              source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip(),
              head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head)
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record)); print((out/'stderr.log').read_text()[-3500:])
assert record['source_clean'] and record['head_unchanged']
p.check_returncode()
