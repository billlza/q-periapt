from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-wasm-input';package=root/'target/continuity-browser-publication/source/target/input-package-02'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for source,target in [('session-worker.js','worker.js'),('session-checks.js','session-checks.js'),('controller.js','controller.js')]:shutil.copyfile(stage/source,web/'creation'/target)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Owned session exchange qualification</title><script type="module" src="./controller.js"></script>')
session='qpc-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
authority=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority';peer=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-rekey-peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'installed browser/native owned exchange with required real witness; local loopback diagnostics, same protocol engine, not deployment or independent implementation','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,peer]},'cases':[],'observations':[]}
allowed={'happy','control-drop-first','control-drop-final','control-empty','control-corrupt','control-old','control-limit'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or duplicate scenario')
sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode})
 sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='session result');sdk.require(value['diagnostics']==[],'browser diagnostics')
 result=value['result'];state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args.get('phase',args['operation'])),'observations':result.get('observations',[])})
 return result
def success(args):
 result=invoke(args);sdk.require('value' in result and 'error' not in result,'operation failed: '+json.dumps(result));return result['value']
def rejected(args,code):
 result=invoke(args);sdk.require('error' in result and result.get('code')==code and result.get('ownerClosed') is True,'wrong rejection: '+json.dumps(result));return result
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="transport_probe=fixture; path=/; SameSite=Strict";if(!document.cookie.includes("transport_probe=fixture"))throw Error("cookie fixture unavailable");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(authority,['prepare',directory],case+'-authorities');shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'operation':'activation'}
    success({**args,'operation':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    success({**args,'phase':'accept'});success({**args,'phase':'prepare'});native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
    native_trace=out/'native'/case/'prepare';native_trace.mkdir(mode=0o700,parents=True)
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace],case+'-peer-prepare')
    args.update(phase='activate');request=success({**args,'sessionAction':'new-request'})['requestId'];args['requestId']=request
    if case in ['drop-final','corrupt-ready','timeout-peer','hold-peer']:
     options={'peerMode':case}
     if case in ['timeout-peer','hold-peer']:options['sessionTimeout']=10000
     if case=='hold-peer':options['cancelOnPeer']=True
     row['rejected']=rejected({**args,'sessionAction':'establish',**options},{'drop-final':'PeerTransport','corrupt-ready':'Authentication','timeout-peer':'Deadline','hold-peer':'Cancelled'}[case])
    elif case in ['closed-policy','closed-runtime','wrong-directory','bad-bundle']:
     options={'closed-policy':{'closeAfterAdmission':'policy'},'closed-runtime':{'closeAfterAdmission':'runtime'},'wrong-directory':{'wrongDirectory':True},'bad-bundle':{'badBundle':True}}[case]
     row['rejected']=rejected({**args,'sessionAction':'establish',**options},{'closed-policy':'Closed','closed-runtime':'Closed','wrong-directory':'Scope','bad-bundle':'Authentication'}[case])
     sdk.require(not peer_records.get(key),'rejected admission dispatched')
    established=success({**args,'sessionAction':'establish'});args['session']=established['session'];row['session']=established['session'];row['requestId']=request
    if case=='drop-final':
     finals=[r['request_sha256'] for r in peer_records[key] if r['kind']==2];sdk.require(len(finals)==2 and len(set(finals))==1,'final recovery changed original')
    if case=='happy':sdk.require(success({**args,'sessionAction':'establish'})==established,'establishment replay changed original')
    row['input_boundary']=success({**args,'sessionAction':'input-boundary'})
    (directory/'peer/session.json').write_text(json.dumps(args['session']))
    row['rekeys']=[]
    for target in [1,2]:
     if (case in ['control-drop-first','control-drop-final','control-empty','control-corrupt','control-limit'] and target==1) or (case=='control-old' and target==2):
      options={'exchanges':1} if case=='control-limit' else {'peerMode':case}
      expected={'control-drop-first':'PeerTransport','control-drop-final':'PeerTransport','control-empty':'Authentication','control-corrupt':'Authentication','control-old':'Scope','control-limit':'ExchangeLimit'}[case]
      row['control_rejected']=rejected({**args,'sessionAction':'drive-rekey','target':target,**options},expected)
      observed=success({**args,'sessionAction':'rekey-progress'});sdk.require(observed['confirmed']==str(target-1),'failure fabricated target completion')
     completed=success({**args,'sessionAction':'drive-rekey','target':target});sdk.require(completed['epoch']==str(target),'wrong completed target');row['rekeys'].append(completed)
     sdk.require(success({**args,'sessionAction':'rekey-progress'})=={'confirmed':str(target),'sending':str(target),'receiving':str(target),'pending':None},'wrong local rekey progress')
    # The native non-proposer initiates target three through the same high-level
    # API; every captured request deliberately loses its carrier result and the
    # next call must reconcile the identical original bytes.
    previous=None
    for step in range(4):
     frame=inputs/(key+f'-control-{step}.bin');trace=out/'native'/case/f'control-{step}';trace.mkdir(mode=0o700)
     command=['control-start',directory,3,frame,trace] if previous is None else ['control-step',directory,3,previous[0],previous[1],frame,trace]
     native_result=parse_strict_json_bytes(native(peer,command,case+f'-native-control-{step}'),label='native control')
     row.setdefault('native_control',[]).append(native_result)
     if native_result['done']:
      sdk.require(native_result['epoch']==3,'wrong native target');break
     sdk.require(native_result['original_dispatched'] and native_result['owner_closed'],'native unknown control outcome')
     control=success({**args,'sessionAction':'receive-control','controlFile':frame.name})
     reply=out/(case+f'-control-{step}-reply.bin');reply.write_bytes(bytes(control['controlWire']));previous=(frame,reply)
    else:raise AssertionError('native control exceeded four steps')
    sdk.require(success({**args,'sessionAction':'rekey-progress'})=={'confirmed':'3','sending':'3','receiving':'3','pending':None},'browser target three incomplete')
    message=success({**args,'sessionAction':'new-message'})['message'];args['message']=message;row['message']=message
    if case in ['drop-ack','after-effect','reject-effect']:
     row['send_rejected']=rejected({**args,'sessionAction':'send','peerMode':case},'PeerTransport')
     sdk.require(success({**args,'sessionAction':'status'})=={'status':2},'unknown send lost original outbox')
    elif case=='old-prefix':
     pending=success({**args,'sessionAction':'send','peerMode':case});sdk.require(pending=={'consumption':2,'status':2},'old prefix fabricated consumption');row['pending']=pending
    delivery=success({**args,'sessionAction':'send'});sdk.require(delivery=={'consumption':1,'status':3},'forward unconfirmed');row['delivery']=delivery
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(args['session'])+bytes(message)+b'browser to native','native host effect/readback differs')
    message_frames=[r['request_sha256'] for r in peer_records[key] if r['kind']==3];sdk.require(len(set(message_frames))==1,'recovery changed message frame')
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']))
    reverse=inputs/(key+'-reverse.bin');trace=out/'native'/case/'send-prepare';trace.mkdir(mode=0o700)
    original=parse_strict_json_bytes(native(peer,['send-prepare',directory,session_file,reverse,trace],case+'-reverse-prepare'),label='native dispatch')
    sdk.require(original['original_dispatched'] and not original['consumption_confirmed'] and original['owner_closed'],'native unknown result')
    args['reverseMessage']=original['message']
    if case in ['application-after-effect','application-hostile','application-coded','application-deadline']:
     mode='late' if case=='application-deadline' else case.removeprefix('application-');row['application_rejected']=rejected({**args,'sessionAction':'receive','applicationMode':mode},'Deadline' if case=='application-deadline' else 'Application')
    received=success({**args,'sessionAction':'receive'});sdk.require(received['application']['calls']==(2 if case.startswith('application-') else 1),'application boundary was not exercised');sdk.require(received['application']['effects']==1,'browser effect missing');row['received']=received
    duplicate=success({**args,'sessionAction':'receive','replyLabel':'duplicate'});sdk.require(duplicate['application']==received['application'] and not duplicate['callbackInvoked'],'consumed duplicate reentered host');row['duplicate']=duplicate
    first_ack=out/'captures'/(key+'-reverse-ack.bin');sdk.require(first_ack.read_bytes()==(out/'captures'/(key+'-reverse-ack-duplicate.bin')).read_bytes(),'duplicate acknowledgement changed')
    trace=out/'native'/case/'send-finish';trace.mkdir(mode=0o700)
    final=parse_strict_json_bytes(native(peer,['send-finish',directory,reverse,first_ack,trace],case+'-reverse-finish'),label='native consumption')
    sdk.require(final['same_original_wire'] and final['authenticated_browser_consumption'],'browser effect not authenticated by native sender');row['reverse']=final
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'server failures: '+json.dumps(failures))
    print(json.dumps({'case':case,'passed':True,'browser_witness_requests':len(witness_records[key]),'peer_requests':len(peer_records[key])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'server failures')
 for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web input drift')
 for name,digest in state['native'].items():sdk.require(sdk.snapshot(Path(name),maximum=256*1024*1024).sha256==digest,'native input drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
