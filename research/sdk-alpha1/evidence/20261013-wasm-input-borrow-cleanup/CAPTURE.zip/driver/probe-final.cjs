const fs = require('node:fs');
const path = require('node:path');
const consumer=JSON.parse(fs.readFileSync(process.argv[2],'utf8')).path;
const sdk=require(path.join(consumer,'node_modules/q-periapt-sdk-wasm'));
const fixture=JSON.parse(fs.readFileSync(path.join(consumer,'fixtures/signed-policy-vectors.json'),'utf8'));
const bytes=h=>new Uint8Array(Buffer.from(h,'hex'));
const policy=new TextEncoder().encode(fixture.policy_toml), signature=bytes(fixture.signature),root=bytes(fixture.verification_key);
const results=[];
for(const kind of ['plain','proxy','own-length-getter','false-length']){
 const runtime=new sdk.QPeriaptRuntime(policy,signature,root,new Uint8Array(),2,1);
 const marker=new Error('input getter failure');let input=policy.slice(),reads=0;
 if(kind==='proxy')input=new Proxy(input,{});
 if(kind==='own-length-getter')Object.defineProperty(input,'length',{get(){reads++;throw marker}});
 if(kind==='false-length')Object.defineProperty(input,'length',{value:1});
 const row={kind};
 try{const update=runtime.prepare_policy_update(input,signature);row.operation='returned';update.free();}
 catch(e){row.operation=String(e);row.originalCause=e===marker;}
 try{row.enabled=runtime.is_enabled();}catch(e){row.enabled=String(e)}
 try{runtime.close();row.closed=true;}catch(e){row.closed=String(e)}
 try{runtime.free();row.freed=true;}catch(e){row.freed=String(e)}
 row.inputGetterReads=reads;results.push(row);
}
console.log(JSON.stringify(results,null,2));
