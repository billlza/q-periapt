from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-wasm-input';package=root/'target/continuity-browser-publication/source/target/input-package-03'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
overlay=json.loads((stage/'SOURCE_OVERLAY_03.json').read_text())
for name,digest in overlay['overlay'].items():assert sha(root/name)==digest,name
old=json.loads((stage/'probe-node-01.json').read_text());new=json.loads((stage/'probe-node-final.json').read_text())
assert old[0]['freed'] is True and all(isinstance(row['freed'],str) and 'borrowed' in row['freed'] for row in old[1:])
assert all(row['freed'] is True and row['inputGetterReads']==0 for row in new)
assert json.loads((stage/'red-final.json').read_text())['returncode']==1 and 'owner cleanup failed' in (stage/'red-final.stderr').read_text()
assert json.loads((stage/'green-final.json').read_text())['returncode']==0
browser=json.loads((stage/'base-02/RESULT.json').read_text());owned=json.loads((stage/'owned-02/RESULT.json').read_text())
assert browser['completed'] and len(browser['report']['cases'])==10 and owned['completed']
assert [(c['realm'],c['assertions']) for c in browser['report']['cases'] if c['mode']=='roundtrip']==[('window',243),('worker',236)]
case=owned['cases'][0];assert case['input_boundary']['getterReads']==0 and case['input_boundary']['rejections']==4
assert case['native_control'][-1]['done'] and case['native_control'][-1]['epoch']==3 and case['reverse']['authenticated_browser_consumption']
receipt=json.loads((package/'INSTALLED_CONSUMER.json').read_text());minimum=json.loads((stage/'node24-final/INSTALLED_CONSUMER.json').read_text())
assert receipt['sha256']==minimum['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz')
assert minimum['runtime']['version']=='v24.0.0' and minimum['npm_version']=='11.3.0' and minimum['installed_node_tests']=='passed'
for p in (stage/'node24-final').glob('*.stderr'):assert not any(v in p.read_text().lower() for v in ['warn','error'])
members={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in members
 assert not any(v.endswith('-private') or v.startswith('private-') for v in p.parts),p
 members[name]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.name!='stage-paths' and not p.name.startswith('seal.') and p.suffix in ['.py','.cjs','.mjs','.json','.stdout','.stderr','.log','.sh']:add(p,'driver/'+p.name)
add(stage/'seal.py','driver/seal.py')
add(stage/'node24-tools/VERIFIED.json','node24-distribution/VERIFIED.json')
for directory in ['base-01','base-02','node24-consumer','node24-final']:
 for p in sorted((stage/directory).iterdir()):
  if p.is_file():add(p,directory+'/'+p.name)
for directory in ['owned-01','owned-02']:
 add(stage/directory/'RESULT.json',directory+'/RESULT.json')
 for p in sorted((stage/directory/'logs').iterdir()):
  if p.is_file():add(p,directory+'/logs/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json','build-nodejs.json','build-web.json','typescript.json','consumer-installed.json','consumer-installed.stderr','consumer-product.json']:
 add(package/name,'package/'+name)
for name in overlay['overlay']:add(root/name,'source/'+name)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-wasm-input-borrow-cleanup';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in members.items():assert sha(p)==hashlib.sha256(z.read(n)).hexdigest()==manifest[n]['sha256']
checks={'completed':True,'release_claim_eligible':False,'source':overlay,'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},
 'old_package_sha256':json.loads((root/'target/continuity-browser-publication/source/target/rekey-package-01/INSTALLED_CONSUMER.json').read_text())['sha256'],
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged','typescript']},'original_probe':old,'corrected_probe':new,
 'red_green':{'same_regression_source':sha(root/'crates/q-periapt-sdk-wasm/tests/input-acceptance.mjs'),'old_exit':1,'new_exit':0,'new_checks':json.loads((stage/'green-final.stdout').read_text())['checks']},
 'browser':{'version':browser['report']['browser'],'cases':len(browser['report']['cases']),'roundtrip_assertions':{'window':243,'worker':236},'owned_invalid_inputs':case['input_boundary']['rejections'],'foreign_getters_invoked':0,'rekey_epochs':[1,2,3],'bidirectional_consumption':True},
 'minimum_node':{k:minimum[k] for k in ['runtime','runtime_inputs','npm_version','expected_node_version','typescript']},
 'validation':{'artifact_controls':53,'wasm_clippy':'-D warnings passed','native_clippy':'all targets -D warnings passed','wasm_msrv':'Rust1.90.0 passed','format':'passed'},
 'cause':'Uncaught foreign length/getter/copy exceptions skipped wasm-bindgen Rust owner-borrow guard destruction. Genuine typed-array internal slots plus catch imports now avoid caller hooks and return copy exceptions through Rust cleanup; failed temporary copies are wipeable.',
 'scope':'Real installed SDK packages on Node26/Node24.0.0 and Chrome window/Worker; fresh browser Continuity owner with required witness. Same-realm JS is not an isolation/security boundary; no release, memory-inspection or wider browser/device claim.',
 'non_admitted_attempts':['Regression harness first had a relative import path error; retained and corrected before red/green.','Package01 encountered an invalid control-character protocol label in the new test; replaced with the existing valid input/v1 label, no SDK validation change.','Base01 completed its new window checks but failed the old178-count sentinel. Raised exact required totals to243window/236worker and reran all10scenarios on package03.','First Node24 consumer selected producer npm12.1.0, which emits an unsupported-engine warning. Final consumer uses Node24.0.0 bundled npm11.3.0; no warning/error diagnostics remain.']}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
