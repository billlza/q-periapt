from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
canonical=root/'research/continuity-recovery-symbolic/protected-state.spthy'
sdk.require(sdk.snapshot(canonical).sha256=='7802d0a937cd3f1afd75cb256c4cadc17b714f042f4894f4d471b3ea3d7bf902','canonical changed')
base=canonical.read_text();prefix=base.split('\nlemma ',1)[0]
start=prefix.index('rule Setup:');end=prefix.index('\nrule Cut:',start)
setup='''rule Identity_Key:
 [ Fr(~signer) ]
 --[ SigningSecret(~signer) ]-> [ !IdentityKey(~signer), Out(pk(~signer)) ]

rule Setup:
 [ !IdentityKey(sa), !IdentityKey(sb), Fr(~sid), Fr(~old), Fr(~wa), Fr(~wb) ]
 --[ Setup(~sid), SessionKeys(~sid,sa,sb) ]->
 [ !Signer(~sid,'A',sa), !Signer(~sid,'B',sb)
 , !Pinned(~sid,'A',pk(sa)), !Pinned(~sid,'B',pk(sb))
 , !Wrap(~sid,'A',~wa), !Wrap(~sid,'B',~wb)
 , !SignerFile(~sid,'A',sa), !SignerFile(~sid,'B',sb)
 , OfferStart(~sid,~old), ResponseStart(~sid,~old), CutPermit(~sid)
 , Out(<~sid,~old,pk(sa),pk(sb)>) ]
'''
prefix=prefix[:start]+setup+prefix[end:]
prefix=prefix.replace('theory ContinuityRecoveryTransition','theory ContinuityKeyScopedRecoveryTransition',1)
changes=[('--[ IdentityLeak(s,role) ]->','--[ IdentityLeak(s,role), IdentityKeyLeak(key) ]->'),
 ('--[ IdentityLeak(s,role), SignerFileCaptured(s,role) ]->','--[ IdentityLeak(s,role), IdentityKeyLeak(key), SignerFileCaptured(s,role) ]->'),
 ("Eq(verify(sig,offer,vk),true), EncapReserved(s), Saved(s,~rev,'4')","Eq(verify(sig,offer,vk),true), EncapReserved(s), EncapsulationSecret(s,peer,~coins), Saved(s,~rev,'4')"),
 ("--[ Saved(s,~rev,'5') ]->","--[ Saved(s,~rev,'5'), ResponseRoot(s,root) ]->"),
 ("Saved(s,~rev,'7') ]->","Saved(s,~rev,'7'), AcceptedRoot(s,root) ]->"),
 ('--[ Message(s,role,key,~payload) ]->','--[ Message(s,role,key,~payload), TrafficInput(s,role,root,key) ]->')]
for old,new in changes:
 sdk.require(prefix.count(old)==1,'ambiguous observation '+old);prefix=prefix.replace(old,new)
old_cert=(root/'target/continuity-recovery-root-isolation-20261015/final-positive-49.spthy').read_text()
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
old={m.group(1):m.group() for m in decl.finditer(old_cert)}
lemmas=['''lemma signing_secret_derivation_origin [use_induction,reuse]:
 "All key #created #known.
    SigningSecret(key)@created & KU(key)@known
    ==> (Ex #leaked. IdentityKeyLeak(key)@leaked)"''',
 old['generation_secret_derivation_origin'],
 '''lemma signing_secret_origin [use_induction,reuse]:
 "All key #created #known.
    SigningSecret(key)@created & K(key)@known
    ==> (Ex #leaked. IdentityKeyLeak(key)@leaked)"''',
 old['generation_secret_origin'],
 '''lemma encapsulation_uses_authenticated_generation [use_induction,reuse]:
 "All s sa sb peer coins #setup #reserved.
    SessionKeys(s,sa,sb)@setup & EncapsulationSecret(s,peer,coins)@reserved
  & not (Ex #leaked. IdentityKeyLeak(sa)@leaked)
  ==> (Ex key #generated.
        GenerationSecret(s,key)@generated & peer = kempk(key) & generated < reserved)"''',
 '''lemma encapsulation_derivation_requires_key_or_session_leak [use_induction,reuse]:
 "All s sa sb peer coins #setup #reserved #known.
    SessionKeys(s,sa,sb)@setup & EncapsulationSecret(s,peer,coins)@reserved & KU(coins)@known
    ==> (Ex #leaked. IdentityKeyLeak(sa)@leaked)
      | (Ex kind #leaked. EntropyLeak(s,kind)@leaked)
      | (Ex revision #captured. Snapshot(s,revision)@captured)"''',
 '''lemma key_scoped_reservations_recover_symbolic_message_secrecy:
 "All s sa sb role key payload #setup #c #g #e #m.
    SessionKeys(s,sa,sb)@setup & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Message(s,role,key,payload)@m & c < g & c < e
  & not (Ex #x. IdentityKeyLeak(sa)@x)
  & not (Ex #x. IdentityKeyLeak(sb)@x)
  & not (Ex kind #x. EntropyLeak(s,kind)@x)
  & not (Ex revision phase #saved #seen.
           Saved(s,revision,phase)@saved & Snapshot(s,revision)@seen & c < saved)
  ==> not (Ex #x. K(payload)@x)"''',
 '''lemma cross_role_sibling_disclosure_exposes_target_message:
 exists-trace
 "Ex s other sa sb sc key payload #target #sibling #leak #c #g #e #m #known.
    SessionKeys(s,sa,sb)@target & SessionKeys(other,sb,sc)@sibling
  & not (s = other) & not (sa = sb) & not (sa = sc) & not (sb = sc)
  & IdentityLeak(other,'A')@leak
  & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Message(s,'A',key,payload)@m & K(payload)@known
  & c < g & c < e & leak < m
  & (All any_session role #extra. IdentityLeak(any_session,role)@extra
       ==> any_session = other & role = 'A' & #extra = #leak)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)
  & not (Ex any_session revision #x. Snapshot(any_session,revision)@x)"''',
 old['recovery_is_executable'],old['pre_cut_generation_reservation_remains_exposed'],old['later_storage_access_defeats_fresh_reservations']]
full=prefix+'\n\n'+'\n\n'.join(lemmas)+'\n\nend\n'
with (stage/'key-scope-01.spthy').open('x') as out:out.write(full)
sdk.write_json(stage/'PREPARED_01.json',{'base_commit':'83cfba1e6261f05b3ee01fc1deccb9a167adef19','canonical_model_sha256':sdk.snapshot(canonical).sha256,'input_sha256':sdk.snapshot(stage/'key-scope-01.spthy').sha256,'scope':'arbitrary independent identity keys reusable in either role across unbounded sessions; one exchange per session; wrapping keys remain per session','new_operational_change':'replace fresh signing keys inside Setup with two persistent independently allocated identity-key premises','new_observations':['SigningSecret(key)','SessionKeys(s,sa,sb)','IdentityKeyLeak(key)','EncapsulationSecret','ResponseRoot','AcceptedRoot','TrafficInput'],'new_identity_exclusions_apply_only_to_actual_target_keys':True,'new_restrictions_or_leak_rule_removals':False,'main_recovery_theorem_unverified':True,'release_claim_eligible':False})
print('General key-scoped recovery model prepared; no positive theorem admitted')
