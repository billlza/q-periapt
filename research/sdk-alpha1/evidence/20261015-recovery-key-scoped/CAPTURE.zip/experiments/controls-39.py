from pathlib import Path
import json,re
import rust_sdk_profile as sdk

def prefix(text):
    text = text.split('\nlemma ', 1)[0]
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    signature = re.search(r'(?s)functions:\s*(.*?)\nequations:', text)
    sdk.require(signature is not None, 'expanded function signature missing')
    functions = dict((name, int(arity)) for name, arity in re.findall(r'(\w+)/(\d+)', signature.group(1)))
    info = re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$', text)
    for name, args, result in info:
        types = [arg.strip() for arg in args.split(',') if arg.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {'Any'} and result == 'Any', 'informational function declaration differs')
    sdk.require({name for name, _, _ in info} in ({'kempk', 'kemct', 'decap'}, set(functions)), 'unexpected informational inventory')
    builtins = re.findall(r'(?m)^builtin\s+(\S+)\s*$', text)
    sdk.require(set(builtins) in (set(), {'hashing', 'signing', 'symmetric-encryption'}), 'unexpected builtin summary')
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$', '', text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$', '', text)
    return re.sub(r'\s+', '', text)

def model(text):
 tail=text.split('\nlemma ',1)[1]
 tail=re.sub(r'/\*.*?\*/','',tail,flags=re.S)
 sdk.require(not re.search(r'(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b',tail),'operational declaration after first lemma')
 return prefix(text)

def queries(text):
 found=list(p.finditer(text));sdk.require(len(found)==len({m.group(1) for m in found}),'duplicate declarations')
 return {m.group(1):m.group() for m in found}

root=Path.cwd();stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
def parse(name,path):return sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(path),'--parse-only'],stage/(name+'-parse-39'),root).decode()
source=(stage/'final-36.spthy').read_text();base=parse('controls-base',stage/'final-36.spthy');expected_queries=queries(base);expected_model=model(base)
marks=list(p.finditer(source));main='key_scoped_reservations_recover_symbolic_message_secrecy';index=next(i for i,m in enumerate(marks) if m.group(1)==main);entry=marks[index]
changed,count=re.subn(r'∃\s+#x\.\s*IdentityKeyLeak\(\s*sa\s*\)\s*@\s*#x','∃ any_key #x. IdentityKeyLeak( any_key ) @ #x',entry.group())
sdk.require(count==1,'key-scope condition selector differs')
rule=re.search(r'(?ms)^rule \(modulo E\) Reveal_Identity:.*?(?=^rule)',source);sdk.require(rule is not None,'reveal rule missing')
removed,count=re.subn(r',\s*IdentityKeyLeak\(\s*key\s*\)','',rule.group());sdk.require(count==1,'leak observation selector differs')
mutations={
 'missing-main':source[:entry.start()]+source[marks[index+1].start():],
 'forbid-unrelated-key-disclosure':source[:entry.start()]+changed+source[entry.end():],
 'late-forbid-all-identity-leaks':source[:source.rindex('\nend')]+'\nrestriction DisableIdentityLeaks:\n "not (Ex key #i. IdentityKeyLeak(key)@i)"\n'+source[source.rindex('\nend'):],
 'untracked-key-disclosure':source[:rule.start()]+removed+source[rule.end():],
}
results={}
for name,changed in mutations.items():
 path=stage/(name+'-39.spthy')
 with path.open('x') as out:out.write(changed)
 parsed=parse(name,path);same_queries=queries(parsed)==expected_queries;late=False
 try:same_model=model(parsed)==expected_model
 except ValueError as error:
  sdk.require('operational declaration after first lemma' in str(error),'unexpected model rejection')
  same_model=False;late=True
 sdk.require(not (same_model and same_queries),'mutation incorrectly admitted')
 results[name]={'pinned_parser_succeeded':True,'same_complete_declarations':same_queries,'same_operational_model':same_model,'late_operational_declaration_rejected':late,'accepted':False,'input_sha256':sdk.snapshot(path).sha256}
conditional=json.loads((stage/'main-conditional-33-TERMINAL.json').read_text());sdk.require(conditional['returncode']==0 and conditional['results'][main]['status']=='verified' and not conditional['accepted'],'missing-dependency control differs')
initial=parse('initial-main',stage/'key-scope-01.spthy');sdk.require(queries(initial)[main]==expected_queries[main],'original key-scoped main declaration changed')
sdk.write_json(stage/'CONTROLS_39.json',{'completed':True,'model_and_declaration_mutations':results,'conditional_main_verified_but_rejected_despite_exit_zero':True,'initial_key_scoped_main_full_declaration_unchanged':True,'full_input_sha256':sdk.snapshot(stage/'final-36.spthy').sha256,'release_claim_eligible':False})
print(json.dumps({'mutations_rejected':len(results),'conditional_main_rejected':True}))
