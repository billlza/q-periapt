from pathlib import Path
import json
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
failed=json.loads((stage/'contribution-10-TERMINAL.json').read_text())
sdk.require(failed['returncode']==-6 and not failed['accepted'] and not failed['timed_out'],'failure not terminal')
sdk.require('eval_thunk_selector: strange selectee' in (stage/'contribution-10.stderr').read_text(),'unexpected failure')
source=(stage/'run-03.py').read_text();sdk.require(source.count("'-N2'")==1,'thread selector differs')
with (stage/'run-single-13.py').open('x') as out:out.write(source.replace("'-N2'","'-N1'"))
sdk.write_json(stage/'SINGLE_THREAD_13.json',{'same_model_sha256':failed['input_sha256'],'prior_terminal_returncode':-6,'observed_failure':'GHC 9.6.7 aarch64_apple_darwin internal eval_thunk_selector error','hypothesis':'runtime parallelism contributes to the crash; not yet established','only_requested_change':'N2 to N1, with fresh output paths','attempt_limit':1,'deadline_seconds':600,'proof_query_and_dependency_inventory_unchanged':True})
