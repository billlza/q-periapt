from pathlib import Path
import json,os,re,signal,subprocess,sys,time
import rust_sdk_profile as sdk
from continuity_recovery_proof import prover_environment
root=Path.cwd();stage=Path(__file__).resolve().parent
filename,label,mode,seconds,*selected=sys.argv[1:]
sdk.require(re.fullmatch(r'[a-z0-9-]+\.spthy',filename) and re.fullmatch(r'[a-z0-9-]+',label),'invalid identity')
sdk.require(mode in ('search','replay') and selected and all(re.fullmatch(r'[a-z_]+',n) for n in selected),'invalid mode/query')
limit=int(seconds);sdk.require(1<=limit<=900,'invalid deadline')
source=stage/filename;content=source.read_text();declarations=list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:',content));inventory=[m.group(1) for m in declarations]
sdk.require(set(selected)<=set(inventory) and len(set(inventory))==len(inventory),'query inventory differs')
required=set(selected)
for m in declarations:
 attrs={x.strip() for x in (m.group(2) or '').split(',')}
 if 'sources' in attrs or ('reuse' in attrs and any(inventory.index(m.group(1))<inventory.index(n) for n in selected)):required.add(m.group(1))
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
output=stage/(label+'-proof.spthy');sdk.require(not output.exists(),'existing proof output')
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(output),'--output-json='+str(stage/(label+'-traces.json'))]
if mode=='search':argv+=['--prove='+n for n in selected]
argv+=['+RTS','-N2','-M12G','-s','-RTS']
env=prover_environment();env['PATH']=str(Path(t['maude']).parent)+os.pathsep+env['PATH']
start=time.monotonic();timed_out=False;exceeded=False
with (stage/(label+'.stdout')).open('xb') as out,(stage/(label+'.stderr')).open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True,env=env)
 sdk.write_json(stage/(label+'-STARTED.json'),{'pid':p.pid,'argv':argv,'maximum_seconds':limit,'required_verified_lemmas':sorted(required),'input_sha256':sdk.snapshot(source).sha256})
 while p.poll() is None:
  timed_out=time.monotonic()-start>=limit;exceeded=max(out.tell(),err.tell())>32*1024**2
  if timed_out or exceeded:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   break
  time.sleep(.2)
 code=p.wait(timeout=5)
summary=(stage/(label+'.stdout')).read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'mode':m,'status':s,'steps':int(k)} for n,m,s,k in parsed}
accepted=code==0 and not timed_out and not exceeded and len(parsed)==len(inventory) and set(results)==set(inventory) and all(results[n]['status']=='verified' for n in required) and output.is_file()
receipt={'argv':argv,'returncode':code,'timed_out':timed_out,'output_exceeded':exceeded,'elapsed_seconds':time.monotonic()-start,'results':results,'required_verified_lemmas':sorted(required),'accepted':accepted,'input_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256 if output.is_file() else None,'release_claim_eligible':False}
sdk.write_json(stage/(label+'-TERMINAL.json'),receipt)
print(json.dumps({'label':label,'results':results,'accepted':accepted,'returncode':code,'timed_out':timed_out}),flush=True)
