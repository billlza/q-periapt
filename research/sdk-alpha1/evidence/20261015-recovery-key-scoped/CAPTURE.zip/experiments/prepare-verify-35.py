from pathlib import Path
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
old=(stage/'verify-witnesses-34.py').read_text();prior=(root/'target/continuity-recovery-root-isolation-20261015/semantics-25.py').read_text()
normalizer=prior[prior.index('def prefix(text):'):prior.index('\nexpected_observers')]
start=old.index('# The same pinned parser');end=old.index('def model(text):')
updated=old[:start]+normalizer+'\n'+old[end:]
updated=updated.replace("namespace['prefix'](text)",'prefix(text)')
needle="for event in ('Cut','KeyReserved','EncapReserved'):sdk.require(one(event)[1]==(target[0],),'wrong target reservation/cut')"
replacement="for event,node in (('Cut','#c'),('KeyReserved','#g'),('EncapReserved','#e')):sdk.require(one(event,node)[1]==(target[0],),'wrong target reservation/cut')"
sdk.require(updated.count(needle)==1,'target selector differs');updated=updated.replace(needle,replacement)
old_line=next(line for line in updated.splitlines() if line.startswith(' results[label]='))
new_line=" results[label]={'search_steps':search_steps,'replay_steps':replay_steps,'certificate_sha256':sdk.snapshot(stage/(replay+'-proof.spthy')).sha256,'trace_sha256':sdk.snapshot(stage/(replay+'-traces.json')).sha256,'identity_leak_rule':leaknode['jgnLabel'],'key_and_session_links_checked':True,'causal_edges_checked':True}"
updated=updated.replace(old_line,new_line)
needle=" sdk.require(a['accepted'] and b['accepted'] and not any(arg.startswith('--prove') for arg in b['argv']),'witness not independently replayed')"
sdk.require(updated.count(needle)==1,'receipt marker differs');updated=updated.replace(needle,needle+"\n search_steps=a['results'][lemma]['steps'];replay_steps=b['results'][lemma]['steps']")
updated=updated.replace('-parse-34','-parse-35').replace('WITNESSES_34.json','WITNESSES_35.json')
with (stage/'verify-witnesses-35.py').open('x') as out:out.write(updated)
sdk.write_json(stage/'VERIFIER_CORRECTION_35.json',{'old_verifier_rejected_positive_trace':'It required one KeyReserved globally, but the required sibling OfferCommitted necessarily has its own legitimate reservation.','correction':'Bind Cut, KeyReserved and EncapReserved to the explicit target query timepoints; retain target-session and freshness checks.','proof_inputs_and_queries_unchanged':True,'receipt_variable_shadowing_removed':True,'normalizer_embedded_for_reproducibility':True})
