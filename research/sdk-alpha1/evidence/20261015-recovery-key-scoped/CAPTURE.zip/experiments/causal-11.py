from pathlib import Path
import re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
pattern=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def parts(text):
 marks=list(pattern.finditer(text));blocks={}
 for i,m in enumerate(marks):
  stop=marks[i+1].start() if i+1<len(marks) else text.rindex('\nend')
  body=re.sub(r'/\*.*?\*/','',text[m.end():stop],flags=re.S).strip()
  blocks[m.group(1)]=(m.group(),body)
 return text[:marks[0].start()],blocks
prefix,base=parts((stage/'key-scope-01.spthy').read_text())
_,old=parts((root/'target/continuity-recovery-root-isolation-20261015/final-positive-53-proof.spthy').read_text())
names=['traffic_key_derivation_requires_prior_root','message_derivation_requires_prior_traffic_key','response_confirmation_has_origin_or_prior_root','computed_root_identifies_session','accepted_root_has_origin_or_prior_derivation','root_constructor_requires_prior_coins_or_snapshot']
selected={name:old[name] for name in names}
name=names[-1];decl,body=selected[name]
attrs='[use_induction,reuse,'+','.join('hide_lemma='+n for n in names[:-1])+']'
selected[name]=(re.sub(r'\[[^\]]+\]',lambda _:attrs,decl,count=1),body)
with (stage/'causal-11.spthy').open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(d+'\n'+b for d,b in list(selected.values())+list(base.values()))+'\n\nend\n')
runner=(stage/'run-03.py').read_text();sdk.require(runner.count("'-M6G'")==1,'heap selector differs')
with (stage/'run-causal-11.py').open('x') as out:out.write(runner.replace("'-M6G'","'-M12G'"))
sdk.write_json(stage/'CAUSAL_11.json',{'input_sha256':sdk.snapshot(stage/'causal-11.spthy').sha256,'required_properties':names,'old_proof_methods_are_only_candidates_until_current_model_replay':True,'same_operational_prefix_as_key_scoped_model':True,'constructor_independent_premise_scope_preserved':True,'release_claim_eligible':False})
print('Six causal proof scripts prepared for current-model replay')
