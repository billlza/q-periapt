from pathlib import Path
import json,re
import rust_sdk_profile as sdk

def prefix(text):
    text = text.split('\nlemma ', 1)[0]
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    signature = re.search(r'(?s)functions:\s*(.*?)\nequations:', text)
    sdk.require(signature is not None, 'expanded function signature missing')
    functions = dict((name, int(arity)) for name, arity in re.findall(r'(\w+)/(\d+)', signature.group(1)))
    info = re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$', text)
    for name, args, result in info:
        types = [arg.strip() for arg in args.split(',') if arg.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {'Any'} and result == 'Any', 'informational function declaration differs')
    sdk.require({name for name, _, _ in info} in ({'kempk', 'kemct', 'decap'}, set(functions)), 'unexpected informational inventory')
    builtins = re.findall(r'(?m)^builtin\s+(\S+)\s*$', text)
    sdk.require(set(builtins) in (set(), {'hashing', 'signing', 'symmetric-encryption'}), 'unexpected builtin summary')
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$', '', text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$', '', text)
    return re.sub(r'\s+', '', text)

def model(text):
 tail=text.split('\nlemma ',1)[1]
 tail=re.sub(r'/\*.*?\*/','',tail,flags=re.S)
 sdk.require(not re.search(r'(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b',tail),'operational declaration after first lemma')
 return prefix(text)

def queries(text):
 found=list(p.finditer(text));sdk.require(len(found)==len({m.group(1) for m in found}),'duplicate declarations')
 return {m.group(1):m.group() for m in found}

root=Path.cwd();stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
result=json.loads((stage/'final-37-TERMINAL.json').read_text());inputs=json.loads((stage/'FINAL_INPUT_36.json').read_text());controls=json.loads((stage/'CONTROLS_39.json').read_text());witnesses=json.loads((stage/'WITNESSES_38.json').read_text())
required=set(inputs['required_properties']);sdk.require(len(required)==20 and result['accepted'] and result['returncode']==0 and not result['timed_out'] and not result['output_exceeded'],'full replay incomplete')
sdk.require(not any(arg.startswith('--prove') for arg in result['argv']) and '-N1' in result['argv'] and '-M12G' in result['argv'],'final replay settings differ')
sdk.require(set(result['required_verified_lemmas'])==required and {n for n,row in result['results'].items() if row['mode']=='all-traces'}==required,'required group differs')
sdk.require({n for n,row in result['results'].items() if row['status']=='verified'}==required,'verified inventory differs')
sdk.require(all(row['status']=='analysis incomplete' for n,row in result['results'].items() if n not in required),'separate witness status differs')
sdk.require(result['input_sha256']==inputs['input_sha256']==controls['full_input_sha256']==sdk.snapshot(stage/'final-36.spthy').sha256,'full input identity differs')
sdk.require(result['output_sha256']==sdk.snapshot(stage/'final-37-proof.spthy').sha256,'certificate differs')
sdk.require(controls['completed'] and witnesses['completed'],'controls/witnesses incomplete')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
def parse(name,path):return sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(path),'--parse-only'],stage/(name+'-parse-40'),root).decode()
initial=parse('initial',stage/'key-scope-01.spthy');before=parse('input',stage/'final-36.spthy');after=parse('certificate',stage/'final-37-proof.spthy')
sdk.require(model(initial)==model(before)==model(after),'operational model differs')
sdk.require(queries(before)==queries(after),'full certificate declarations differ')
main='key_scoped_reservations_recover_symbolic_message_secrecy'
sdk.require(queries(initial)[main]==queries(after)[main],'initial main query changed')
# Validate the scope of the bounded runtime control; do not infer a root cause from one success.
a=json.loads((stage/'contribution-10-TERMINAL.json').read_text());b=json.loads((stage/'contribution-single-14-TERMINAL.json').read_text())
fixed=lambda argv:[s for s in argv if not s.startswith(('-N','--output=','--output-json='))]
sdk.require(a['input_sha256']==b['input_sha256'] and fixed(a['argv'])==fixed(b['argv']) and a['returncode']==-6 and b['accepted'],'runtime control changed more than thread count/output paths')
sdk.write_json(stage/'CERTIFIED_40.json',{'completed':True,'main_theorem':main,'main_verified_steps':result['results'][main]['steps'],'verified_group':{n:result['results'][n]['steps'] for n in inputs['required_properties']},'required_property_count':20,'certificate_sha256':result['output_sha256'],'input_sha256':result['input_sha256'],'bare_model_sha256':sdk.snapshot(stage/'key-scope-01.spthy').sha256,'independent_no_search_replay_seconds':result['elapsed_seconds'],'threads':1,'heap_gib':12,'two_separate_witnesses_independently_replayed':True,'all_full_declarations_and_operational_model_checked':True,'initial_key_scoped_main_formula_unchanged':True,'mutations_and_missing_dependencies_rejected':True,'parallel_runtime_abort_retained_and_root_cause_unconfirmed':True,'identity_exclusion':'No direct reveal or signer-file capture naming either target key anywhere in the trace. Capture is conservatively counted before unsealing.','scope':'Arbitrary honestly generated signing keys reused in either role across unbounded sessions; one exchange per session, fresh publicly revealed old root and per-session wrapping keys, perfect primitives and ideal protected storage.','unproved':['multi-epoch root ancestry','shared journals/wrapping owners','computational hybrid/HKDF/signing-coins security','SDK refinement','hosted Linux replay of this new model'],'release_claim_eligible':False})
print(json.dumps({'properties':20,'main_steps':result['results'][main]['steps'],'certificate_sha256':result['output_sha256'],'main_formula_unchanged':True}))
