from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
from evidence_io import read_regular_snapshot
root=Path.cwd();stage=Path(__file__).resolve().parent
certified=json.loads((stage/'CERTIFIED_40.json').read_text());controls=json.loads((stage/'CONTROLS_39.json').read_text());witnesses=json.loads((stage/'WITNESSES_38.json').read_text());cleanup=json.loads((stage/'CLEANUP_41.json').read_text())
sdk.require(certified['completed'] and controls['completed'] and witnesses['completed'] and cleanup['completed'],'missing admission evidence')
model=root/'research/continuity-recovery-symbolic/key-scoped.spthy'
with model.open('xb') as out:out.write((stage/'key-scope-01.spthy').read_bytes())
sdk.require(sdk.snapshot(model).sha256==certified['bare_model_sha256'],'public model differs')
public=root/'research/sdk-alpha1/evidence/20261015-recovery-key-scoped';public.mkdir()
files={}
for path in stage.iterdir():
 if path.is_file() and path.suffix in ('.py','.spthy','.json','.stdout','.stderr','.log'):
  files['experiments/'+path.name]=path
for relative in ('research/continuity-recovery-symbolic/protected-state.spthy','research/continuity-recovery-symbolic/shared-identity.spthy','research/continuity-recovery-symbolic/key-scoped.spthy','artifact/continuity_recovery_proof.py','artifact/test_continuity_recovery_proof.py'):
 files['source/'+relative]=root/relative
files['tools/TOOLS_08.json']=root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json'
digests={};total=0;archive=public/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for name,path in sorted(files.items()):
  maximum=160*1024**2 if name.endswith('-traces.json') else 32*1024**2
  snapshot=read_regular_snapshot(path,maximum=maximum,label='public symbolic evidence')
  total+=snapshot.size;sdk.require(total<=512*1024**2,'public evidence exceeds total bound')
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  out.writestr(info,snapshot.data);digests[name]=snapshot.sha256
with zipfile.ZipFile(archive) as zipped:
 sdk.require(len(zipped.namelist())==len(digests) and set(zipped.namelist())==set(digests),'archive inventory differs')
 for name,digest in digests.items():
  value=hashlib.sha256()
  with zipped.open(name) as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b''):value.update(chunk)
  sdk.require(value.hexdigest()==digest,'archive readback differs')
archive_digest=sdk.snapshot(archive,maximum=64*1024**2).sha256
sdk.write_json(public/'CAPTURE.json',{'capture_sha256':archive_digest,'members':digests,'expanded_bytes':total,'positive_key_scoped_certificate':certified,'separate_witnesses':witnesses,'admission_controls':controls,'release_claim_eligible':False})
sdk.write_json(public/'READBACK.json',{'completed':True,'capture_sha256':archive_digest,'members':len(digests),'expanded_bytes':total,'all_members_rehashed':True,'positive_group_count':20,'separate_witness_count':2,'private_sdk_runtime_data_selected':False,'release_claim_eligible':False})
print(json.dumps({'members':len(digests),'expanded_bytes':total,'archive_bytes':archive.stat().st_size,'archive_sha256':archive_digest,'model_sha256':certified['bare_model_sha256']}))
