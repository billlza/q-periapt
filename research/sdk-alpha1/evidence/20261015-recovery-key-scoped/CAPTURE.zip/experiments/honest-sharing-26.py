from pathlib import Path
import re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
source=(stage/'composed-24.spthy').read_text();p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"');matches=list(p.finditer(source));prefix=source[:matches[0].start()]
query='''lemma recovery_premises_allow_unrelated_identity_disclosure:
 exists-trace
 "Ex s other sa sb sc key payload #setup #sibling #offer #leak #learn_identity #c #g #e #a #b #m.
    SessionKeys(s,sa,sb)@setup & SessionKeys(other,sb,sc)@sibling
  & not (s = other) & not (sa = sb) & not (sa = sc) & not (sb = sc)
  & OfferCommitted(other)@offer & IdentityLeak(other,'B')@leak & K(sc)@learn_identity
  & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Confirmed(s,'A')@a & Confirmed(s,'B')@b & Message(s,'A',key,payload)@m
  & c < g & c < e & a < m & b < m & offer < m & learn_identity < m
  & not (Ex #x. IdentityKeyLeak(sa)@x)
  & not (Ex #x. IdentityKeyLeak(sb)@x)
  & (All any_session role #extra. IdentityLeak(any_session,role)@extra
       ==> any_session = other & role = 'B' & #extra = #leak)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)
  & not (Ex any_session revision #x. Snapshot(any_session,revision)@x)"

'''
with (stage/'honest-sharing-26.spthy').open('x') as out:out.write(prefix+'\n\n'+query+'\n\n'.join(m.group() for m in matches)+'\n\nend\n')
sdk.write_json(stage/'HONEST_SHARING_26.json',{'input_sha256':sdk.snapshot(stage/'honest-sharing-26.spthy').sha256,'witness_goal':'target recovery premises and both honest confirmations coexist with a shared key actively signing in the other role and actual knowledge of a third independent identity key','no_reused_premise_before_witness':True,'same_model_and_positive_formula':True,'not_a_secrecy_proof':True})
