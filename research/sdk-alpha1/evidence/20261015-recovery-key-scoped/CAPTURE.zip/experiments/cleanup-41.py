from pathlib import Path
import json,subprocess
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
started={json.loads(p.read_text())['pid']:p.name for p in stage.glob('*-STARTED.json')}
rows=subprocess.check_output(['ps','-axo','pid=,pgid=,args='],text=True).splitlines()
live=[]
for line in rows:
 fields=line.strip().split(None,2)
 if len(fields)==3 and int(fields[1]) in started:live.append({'pid':int(fields[0]),'pgid':int(fields[1]),'command':fields[2]})
sdk.require(not live,'an experiment process group is still live: '+str(live))
sdk.write_json(stage/'CLEANUP_41.json',{'completed':True,'owned_process_groups_checked':len(started),'live_owned_processes':[],'terminated_any_process':False,'parallel_abort_and_timeout_receipts_retained':True})
print('All owned prover process groups are terminal')
