from pathlib import Path
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
base=(stage/'authentication-08-proof.spthy').read_text()
marker='lemma encapsulation_derivation_requires_key_or_session_leak'
sdk.require(base.count(marker)==1,'placement ambiguous')
queries='''lemma accepted_root_has_authenticated_origin [use_induction,reuse]:
 "All s sa sb root #setup #accepted.
    SessionKeys(s,sa,sb)@setup & AcceptedRoot(s,root)@accepted
  & not (Ex #leaked. IdentityKeyLeak(sb)@leaked)
  ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < accepted)"
by sorry

lemma message_root_has_authenticated_origin [reuse]:
 "All s sa sb role root key #setup #message.
    SessionKeys(s,sa,sb)@setup & TrafficInput(s,role,root,key)@message
  & not (Ex #leaked. IdentityKeyLeak(sb)@leaked)
  ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < message)"
by sorry

'''
with (stage/'root-auth-15.spthy').open('x') as out:out.write(base.replace(marker,queries+marker))
sdk.write_json(stage/'ROOT_AUTH_15.json',{'input_sha256':sdk.snapshot(stage/'root-auth-15.spthy').sha256,'new_properties':['accepted_root_has_authenticated_origin','message_root_has_authenticated_origin'],'same_rules_equations_restrictions':True,'only_target_responder_key_disclosure_excluded':True,'main_recovery_theorem_unverified':True})
