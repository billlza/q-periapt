from pathlib import Path
import re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
text=(stage/'causal-11.spthy').read_text();p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"');matches=list(p.finditer(text));prefix=text[:matches[0].start()];declarations={m.group(1):m.group() for m in matches}
with (stage/'causal-fresh-17.spthy').open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(declarations.values())+'\n\nend\n')
first='root_constructor_requires_prior_coins_or_snapshot'
declarations[first]=re.sub(r'\[[^\]]+\]','[use_induction,reuse]',declarations[first],count=1)
ordered=[first]+[n for n in declarations if n!=first]
with (stage/'constructor-first-17.spthy').open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(declarations[n] for n in ordered)+'\n\nend\n')
sdk.write_json(stage/'CAUSAL_FRESH_17.json',{'reason':'Four old proof scripts fail at stored-record node references in the changed Setup model; exit zero is not a verified group','original_failed_replay':'causal-12-TERMINAL.json','fresh_search_changes_no_formulas_rules_or_restrictions':True,'constructor_query_moved_first_without_any_reusable_premise':True})
