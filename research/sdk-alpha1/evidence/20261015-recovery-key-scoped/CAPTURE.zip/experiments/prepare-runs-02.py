from pathlib import Path
import re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
base=(stage/'key-scope-01.spthy').read_text();marks=list(re.finditer(r'(?m)^lemma\s+(\w+)',base));prefix=base[:marks[0].start()]
blocks={m.group(1):base[m.start():(marks[i+1].start() if i+1<len(marks) else base.rindex('\nend'))].strip() for i,m in enumerate(marks)}
for label,first in [('generation-first-02','generation_secret_derivation_origin'),('witness-first-02','cross_role_sibling_disclosure_exposes_target_message')]:
 ordered=[first]+[n for n in blocks if n!=first]
 with (stage/(label+'.spthy')).open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(blocks[n] for n in ordered)+'\n\nend\n')
print('Independent searches prepared with no preceding reusable premise')
