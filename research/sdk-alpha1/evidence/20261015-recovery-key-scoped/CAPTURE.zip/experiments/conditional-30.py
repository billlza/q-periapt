from pathlib import Path
import json,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
receipt=json.loads((stage/'root-derive-25-TERMINAL.json').read_text());sdk.require(receipt['accepted'],'composed prefix not verified')
source=(stage/'root-derive-25-proof.spthy').read_text();p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"');matches=list(p.finditer(source));sdk.require(len(matches)==24,'declaration inventory differs')
conditional=source[:matches[0].start()]+'\n\n'+'\n\n'.join(m.group()+'\nby sorry' for m in matches)+'\n\nend\n'
with (stage/'conditional-30.spthy').open('x') as out:out.write(conditional)
sdk.write_json(stage/'CONDITIONAL_30.json',{'verified_component_bank':sdk.snapshot(stage/'root-derive-25-proof.spthy').sha256,'input_sha256':sdk.snapshot(stage/'conditional-30.spthy').sha256,'verified_bank_count':sum(r['status']=='verified' for r in receipt['results'].values()),'purpose':'search the remaining short proof scripts without repeatedly replaying the 17 already checked components','conditional_results_not_admitted_until_all_twenty_dependencies_replayed':True,'all_full_declarations_and_operational_prefix_unchanged':True,'release_claim_eligible':False})
print('Conditional search input prepared; missing-premise gate remains mandatory')
