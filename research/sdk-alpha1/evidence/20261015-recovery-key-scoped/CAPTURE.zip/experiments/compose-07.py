from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
base=(stage/'key-scope-01.spthy').read_text();pattern=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def parts(text):
 marks=list(pattern.finditer(text));blocks={}
 for i,m in enumerate(marks):
  stop=marks[i+1].start() if i+1<len(marks) else text.rindex('\nend')
  body=re.sub(r'/\*.*?\*/','',text[m.end():stop],flags=re.S).strip()
  blocks[m.group(1)]=(m.group(),body)
 return text[:marks[0].start()],blocks
prefix,blocks=parts(base)
for label,name in [('signer-04','signing_secret_derivation_origin'),('generation-05','generation_secret_derivation_origin')]:
 receipt=json.loads((stage/(label+'-TERMINAL.json')).read_text());sdk.require(receipt['accepted'],'unverified leaf')
 _,proof=parts((stage/(label+'-proof.spthy')).read_text());decl,body=blocks[name]
 sdk.require(body=='','base contains proof')
 blocks[name]=(decl,proof[name][1])
_,old=parts((root/'target/continuity-recovery-root-isolation-20261015/final-positive-53-proof.spthy').read_text())
for name in ('signing_secret_origin','generation_secret_origin'):
 blocks[name]=(blocks[name][0],old[name][1])
# Keep the independently derived generation proof in its original empty premise context.
name='generation_secret_derivation_origin';decl,body=blocks[name]
blocks[name]=(decl.replace('[use_induction, reuse]','[use_induction, reuse, hide_lemma=signing_secret_derivation_origin]'),body)
with (stage/'authentication-07.spthy').open('x') as out:
 out.write(prefix+'\n\n'+'\n\n'.join(d+'\n'+b for d,b in blocks.values())+'\n\nend\n')
sdk.write_json(stage/'COMPOSED_07.json',{'input_sha256':sdk.snapshot(stage/'authentication-07.spthy').sha256,'independent_leafs':['signer-04','generation-05'],'public_knowledge_proof_methods_reused_but_require_current_model_replay':True,'new_model_rules_or_query_conditions':False,'main_recovery_theorem_unverified':True})
print('Independent provenance proofs composed; public bridge proof methods and authentication require current replay')
