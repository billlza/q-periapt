from pathlib import Path
import json,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def parts(text):
 marks=list(p.finditer(text));blocks={}
 for i,m in enumerate(marks):
  stop=marks[i+1].start() if i+1<len(marks) else text.rindex('\nend')
  blocks[m.group(1)]=(m.group(),re.sub(r'/\*.*?\*/','',text[m.end():stop],flags=re.S).strip())
 return text[:marks[0].start()],blocks
bank=json.loads((stage/'root-derive-25-TERMINAL.json').read_text());sdk.require(bank['accepted'] and sum(r['status']=='verified' for r in bank['results'].values())==17,'bank incomplete')
prefix,blocks=parts((stage/'root-derive-25-proof.spthy').read_text())
for label,name in [('message-link-31','message_derivation_requires_key_or_session_leak'),('contribution-public-32','encapsulation_secret_requires_key_or_session_leak'),('main-conditional-33','key_scoped_reservations_recover_symbolic_message_secrecy')]:
 result=json.loads((stage/(label+'-TERMINAL.json')).read_text())
 sdk.require(result['returncode']==0 and not result['accepted'] and result['results'][name]['status']=='verified','conditional gate or proof differs')
 _,candidate=parts((stage/(label+'-proof.spthy')).read_text());sdk.require(candidate[name][0]==blocks[name][0],'full conditional declaration changed')
 blocks[name]=candidate[name]
full=prefix+'\n\n'+'\n\n'.join(d+'\n'+b for d,b in blocks.values())+'\n\nend\n'
with (stage/'final-36.spthy').open('x') as out:out.write(full)
required=json.loads((stage/'COMPOSED_24.json').read_text())['required_properties'];sdk.require(len(required)==20,'required group differs')
sdk.write_json(stage/'FINAL_INPUT_36.json',{'input_sha256':sdk.snapshot(stage/'final-36.spthy').sha256,'required_properties':required,'all_full_declarations_unchanged_from_composed_24':True,'conditional_main_rejected_until_this_full_group_replays':True,'main_recovery_theorem_unverified':True,'release_claim_eligible':False})
print('All 20 proof bodies assembled; final no-search replay required')
