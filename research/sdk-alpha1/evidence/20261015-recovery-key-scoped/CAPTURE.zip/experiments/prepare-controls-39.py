from pathlib import Path
import ast
stage=Path(__file__).resolve().parent
source=(stage/'verify-witnesses-38.py').read_text();tree=ast.parse(source)
functions='\n\n'.join(ast.get_source_segment(source,node) for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('prefix','model','queries'))
body=r'''
root=Path.cwd();stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
def parse(name,path):return sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(path),'--parse-only'],stage/(name+'-parse-39'),root).decode()
source=(stage/'final-36.spthy').read_text();base=parse('controls-base',stage/'final-36.spthy');expected_queries=queries(base);expected_model=model(base)
marks=list(p.finditer(source));main='key_scoped_reservations_recover_symbolic_message_secrecy';index=next(i for i,m in enumerate(marks) if m.group(1)==main);entry=marks[index]
changed,count=re.subn(r'∃\s+#x\.\s*IdentityKeyLeak\(\s*sa\s*\)\s*@\s*#x','∃ any_key #x. IdentityKeyLeak( any_key ) @ #x',entry.group())
sdk.require(count==1,'key-scope condition selector differs')
rule=re.search(r'(?ms)^rule \(modulo E\) Reveal_Identity:.*?(?=^rule)',source);sdk.require(rule is not None,'reveal rule missing')
removed,count=re.subn(r',\s*IdentityKeyLeak\(\s*key\s*\)','',rule.group());sdk.require(count==1,'leak observation selector differs')
mutations={
 'missing-main':source[:entry.start()]+source[marks[index+1].start():],
 'forbid-unrelated-key-disclosure':source[:entry.start()]+changed+source[entry.end():],
 'late-forbid-all-identity-leaks':source[:source.rindex('\nend')]+'\nrestriction DisableIdentityLeaks:\n "not (Ex key #i. IdentityKeyLeak(key)@i)"\n'+source[source.rindex('\nend'):],
 'untracked-key-disclosure':source[:rule.start()]+removed+source[rule.end():],
}
results={}
for name,changed in mutations.items():
 path=stage/(name+'-39.spthy')
 with path.open('x') as out:out.write(changed)
 parsed=parse(name,path);same_queries=queries(parsed)==expected_queries;late=False
 try:same_model=model(parsed)==expected_model
 except ValueError as error:
  sdk.require('operational declaration after first lemma' in str(error),'unexpected model rejection')
  same_model=False;late=True
 sdk.require(not (same_model and same_queries),'mutation incorrectly admitted')
 results[name]={'pinned_parser_succeeded':True,'same_complete_declarations':same_queries,'same_operational_model':same_model,'late_operational_declaration_rejected':late,'accepted':False,'input_sha256':sdk.snapshot(path).sha256}
conditional=json.loads((stage/'main-conditional-33-TERMINAL.json').read_text());sdk.require(conditional['returncode']==0 and conditional['results'][main]['status']=='verified' and not conditional['accepted'],'missing-dependency control differs')
initial=parse('initial-main',stage/'key-scope-01.spthy');sdk.require(queries(initial)[main]==expected_queries[main],'original key-scoped main declaration changed')
sdk.write_json(stage/'CONTROLS_39.json',{'completed':True,'model_and_declaration_mutations':results,'conditional_main_verified_but_rejected_despite_exit_zero':True,'initial_key_scoped_main_full_declaration_unchanged':True,'full_input_sha256':sdk.snapshot(stage/'final-36.spthy').sha256,'release_claim_eligible':False})
print(json.dumps({'mutations_rejected':len(results),'conditional_main_rejected':True}))
'''
with (stage/'controls-39.py').open('x') as out:out.write('from pathlib import Path\nimport json,re\nimport rust_sdk_profile as sdk\n\n'+functions+'\n'+body)
