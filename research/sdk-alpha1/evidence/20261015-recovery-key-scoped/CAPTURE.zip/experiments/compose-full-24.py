from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def parts(text):
 marks=list(p.finditer(text));blocks={}
 for i,m in enumerate(marks):
  stop=marks[i+1].start() if i+1<len(marks) else text.rindex('\nend')
  blocks[m.group(1)]=(m.group(),re.sub(r'/\*.*?\*/','',text[m.end():stop],flags=re.S).strip())
 return text[:marks[0].start()],blocks
proofs={}
for label in ('message-root-21','payload-22','confirmation-23','constructor-19'):
 receipt=json.loads((stage/(label+'-TERMINAL.json')).read_text());sdk.require(receipt['accepted'],'missing certified component '+label)
 _,proofs[label]=parts((stage/(label+'-proof.spthy')).read_text())
prefix,initial=parts((stage/'key-scope-01.spthy').read_text())
_,conditional=parts((stage/'causal-12-proof.spthy').read_text())
_,old=parts((root/'target/continuity-recovery-root-isolation-20261015/final-positive-53-proof.spthy').read_text())
def hide(block,names):
 decl,body=block;header=re.match(r'^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:',decl);sdk.require(header is not None,'missing header')
 attrs=[a.strip() for a in (header.group(2) or '').split(',') if a.strip()]
 attrs.extend('hide_lemma='+name for name in names if 'hide_lemma='+name not in attrs)
 return ('lemma '+header.group(1)+' ['+','.join(attrs)+']:'+decl[header.end():],body)
causal=['traffic_key_derivation_requires_prior_root','message_derivation_requires_prior_traffic_key','response_confirmation_has_origin_or_prior_root','computed_root_identifies_session','accepted_root_has_origin_or_prior_derivation']
blocks={n:proofs['payload-22'][n] for n in causal[:2]}
blocks[causal[2]]=hide(proofs['confirmation-23'][causal[2]],causal[:2])
for n in causal[3:]:blocks[n]=conditional[n]
crypto=['signing_secret_derivation_origin','generation_secret_derivation_origin','signing_secret_origin','generation_secret_origin','encapsulation_uses_authenticated_generation','accepted_root_has_authenticated_origin','message_root_has_authenticated_origin','encapsulation_derivation_requires_key_or_session_leak']
for n in crypto:blocks[n]=hide(proofs['message-root-21'][n],causal)
constructor='root_constructor_requires_prior_coins_or_snapshot'
blocks[constructor]=hide(proofs['constructor-19'][constructor],list(blocks))
root_query='''lemma computed_root_derivation_requires_key_or_session_leak [use_induction,reuse]:
 "All s sa sb root #setup #computed #known.
    SessionKeys(s,sa,sb)@setup & ResponseRoot(s,root)@computed & KU(root)@known
    ==> (Ex #leaked. IdentityKeyLeak(sa)@leaked)
      | (Ex kind #leaked. EntropyLeak(s,kind)@leaked)
      | (Ex revision #captured. Snapshot(s,revision)@captured)"'''
root_name='computed_root_derivation_requires_key_or_session_leak'
keep={'encapsulation_derivation_requires_key_or_session_leak',constructor}
blocks[root_name]=hide((root_query,''),[n for n in blocks if n not in keep])
message_query='''lemma message_derivation_requires_key_or_session_leak [use_induction,reuse]:
 "All s sa sb role key payload #setup #sent #known.
    SessionKeys(s,sa,sb)@setup & Message(s,role,key,payload)@sent & KU(payload)@known
    ==> (Ex #leaked. IdentityKeyLeak(sa)@leaked)
      | (Ex #leaked. IdentityKeyLeak(sb)@leaked)
      | (Ex kind #leaked. EntropyLeak(s,kind)@leaked)
      | (Ex revision #captured. Snapshot(s,revision)@captured)"'''
keep=set(causal[:2])|{'message_root_has_authenticated_origin',root_name}
blocks['message_derivation_requires_key_or_session_leak']=hide((message_query,''),[n for n in blocks if n not in keep])
for n in ('retained_record_has_saved_origin','stored_records_follow_fresh_reservations'):
 keep=set() if n=='retained_record_has_saved_origin' else {'retained_record_has_saved_origin'}
 # Do not carry stale hide annotations from the different source ordering.
 decl,body=old[n];decl=re.sub(r'\[[^\]]+\]','[use_induction,reuse]',decl,count=1)
 blocks[n]=hide((decl,body),[name for name in blocks if name not in keep])
public_query='''lemma encapsulation_secret_requires_key_or_session_leak [use_induction,reuse]:
 "All s sa sb peer coins #setup #reserved #known.
    SessionKeys(s,sa,sb)@setup & EncapsulationSecret(s,peer,coins)@reserved & K(coins)@known
    ==> (Ex #leaked. IdentityKeyLeak(sa)@leaked)
      | (Ex kind #leaked. EntropyLeak(s,kind)@leaked)
      | (Ex revision #captured. Snapshot(s,revision)@captured)"'''
blocks['encapsulation_secret_requires_key_or_session_leak']=hide((public_query,''),[n for n in blocks if n!='encapsulation_derivation_requires_key_or_session_leak'])
main='key_scoped_reservations_recover_symbolic_message_secrecy';blocks[main]=initial[main]
required=list(blocks)
for n in ('cross_role_sibling_disclosure_exposes_target_message','recovery_is_executable','pre_cut_generation_reservation_remains_exposed','later_storage_access_defeats_fresh_reservations'):blocks[n]=initial[n]
sdk.require(len(required)==20 and len(blocks)==24,'inventory differs')
with (stage/'composed-24.spthy').open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(d+'\n'+b for d,b in blocks.values())+'\n\nend\n')
sdk.write_json(stage/'COMPOSED_24.json',{'input_sha256':sdk.snapshot(stage/'composed-24.spthy').sha256,'required_properties':required,'main_formula_unchanged_from_initial_key_scoped_candidate':True,'operational_prefix_unchanged':True,'component_premise_scopes_preserved':True,'old_timing_proof_scripts_and_conditional_origin_script_require_current_replay':True,'main_recovery_theorem_unverified':True,'release_claim_eligible':False})
print('Twenty-property composition prepared; complete current-model replay remains required')
