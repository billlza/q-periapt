from pathlib import Path
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
source=(stage/'verify-witnesses-35.py').read_text()
source=source.replace('import rust_sdk_profile as sdk','import rust_sdk_profile as sdk\nfrom evidence_io import read_regular_snapshot',1)
needle=" graphs=json.loads((stage/(replay+'-traces.json')).read_text())['graphs'];"
sdk.require(source.count(needle)==1,'trace reader differs')
replacement=" trace_snapshot=read_regular_snapshot(stage/(replay+'-traces.json'),maximum=160*1024**2,label='symbolic witness trace')\n trace_sha=trace_snapshot.sha256;trace_size=trace_snapshot.size\n graphs=json.loads(trace_snapshot.data)['graphs'];"
source=source.replace(needle,replacement)
needle="'trace_sha256':sdk.snapshot(stage/(replay+'-traces.json')).sha256"
sdk.require(source.count(needle)==1,'trace digest selector differs');source=source.replace(needle,"'trace_sha256':trace_sha,'trace_bytes':trace_size")
source=source.replace('-parse-35','-parse-38').replace('WITNESSES_35.json','WITNESSES_38.json')
with (stage/'verify-witnesses-38.py').open('x') as out:out.write(source)
sdk.write_json(stage/'TRACE_BOUND_38.json',{'previous_failure':'The SDK helper defaults to 32 MiB; the exported honest witness graph contains 139281741 bytes of expanded symbolic terms and formatting.','observed_honest_trace_bytes':(stage/'honest-sharing-replay-28-traces.json').stat().st_size,'trace_specific_maximum_bytes':160*1024**2,'bounded_snapshot_precedes_json_decode':True,'digest_and_parsed_bytes_from_same_snapshot':True,'model_queries_and_asserted_trace_relationships_unchanged':True,'product_sdk_input_bound_unchanged':True})
