from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
def prefix(text):
    text = text.split('\nlemma ', 1)[0]
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    signature = re.search(r'(?s)functions:\s*(.*?)\nequations:', text)
    sdk.require(signature is not None, 'expanded function signature missing')
    functions = dict((name, int(arity)) for name, arity in re.findall(r'(\w+)/(\d+)', signature.group(1)))
    info = re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$', text)
    for name, args, result in info:
        types = [arg.strip() for arg in args.split(',') if arg.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {'Any'} and result == 'Any', 'informational function declaration differs')
    sdk.require({name for name, _, _ in info} in ({'kempk', 'kemct', 'decap'}, set(functions)), 'unexpected informational inventory')
    builtins = re.findall(r'(?m)^builtin\s+(\S+)\s*$', text)
    sdk.require(set(builtins) in (set(), {'hashing', 'signing', 'symmetric-encryption'}), 'unexpected builtin summary')
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$', '', text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$', '', text)
    return re.sub(r'\s+', '', text)

def model(text):
 tail=text.split('\nlemma ',1)[1]
 tail=re.sub(r'/\*.*?\*/','',tail,flags=re.S)
 sdk.require(not re.search(r'(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b',tail),'operational declaration after first lemma')
 return prefix(text)
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def queries(text):
 found=list(p.finditer(text));sdk.require(len(found)==len({m.group(1) for m in found}),'duplicate declarations')
 return {m.group(1):m.group() for m in found}
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
def parse(name,path):return sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(path),'--parse-only'],stage/(name+'-parse-35'),root).decode()
canonical=parse('key-scope',stage/'key-scope-01.spthy');main='key_scoped_reservations_recover_symbolic_message_secrecy'
results={}
for label,source,search,replay,lemma,target_id,sibling_id,leaked_role in (
 ('negative','witness-first-02.spthy','cross-role-witness-06','cross-role-replay-09','cross_role_sibling_disclosure_exposes_target_message','#target','#sibling',"'A'"),
 ('positive','honest-sharing-26.spthy','honest-sharing-27','honest-sharing-replay-28','recovery_premises_allow_unrelated_identity_disclosure','#setup','#sibling',"'B'")):
 a=json.loads((stage/(search+'-TERMINAL.json')).read_text());b=json.loads((stage/(replay+'-TERMINAL.json')).read_text())
 sdk.require(a['accepted'] and b['accepted'] and not any(arg.startswith('--prove') for arg in b['argv']),'witness not independently replayed')
 search_steps=a['results'][lemma]['steps'];replay_steps=b['results'][lemma]['steps']
 sdk.require(a['output_sha256']==b['input_sha256']==sdk.snapshot(stage/(search+'-proof.spthy')).sha256,'input certificate changed')
 sdk.require(b['output_sha256']==sdk.snapshot(stage/(replay+'-proof.spthy')).sha256,'output certificate changed')
 before=parse(label+'-input',stage/source);after=parse(label+'-certificate',stage/(replay+'-proof.spthy'))
 sdk.require(queries(before)==queries(after) and next(iter(queries(before)))==lemma,'witness declarations or first-premise position differs')
 sdk.require(model(before)==model(after)==model(canonical),'witness model differs')
 sdk.require(queries(after)[main]==queries(canonical)[main],'positive theorem declaration changed')
 graphs=json.loads((stage/(replay+'-traces.json')).read_text())['graphs'];sdk.require(len(graphs)==1,'unexpected trace inventory');g=graphs[0]
 acts=[(n,a) for n in g['jgNodes'] for a in n.get('jgnMetadata',{}).get('jgnActs',[])]
 def tree(term):
  if 'jgnConst' in term:return ('constant',term['jgnConst'])
  sdk.require('jgnFunct' in term and 'jgnParams' in term,'malformed term')
  return (term['jgnFunct'],tuple(tree(v) for v in term['jgnParams']))
 def one(name,node=None):
  found=[(n,a) for n,a in acts if a['jgnFactName']==name and (node is None or n['jgnId']==node)]
  sdk.require(len(found)==1,'unexpected '+name+' event count')
  n,a=found[0];return n,tuple(map(tree,a['jgnFactTerms']))
 _,target=one('SessionKeys',target_id);_,sibling=one('SessionKeys',sibling_id)
 sdk.require(target[0]!=sibling[0] and target[2]==sibling[1] and len({target[1],target[2],sibling[2]})==3,'identity overlap is not exactly one key across roles')
 leaknode,leak=one('IdentityLeak');_,keyleak=one('IdentityKeyLeak')
 expected_key=target[2] if label=='negative' else sibling[2]
 sdk.require(leak==(sibling[0],('constant',leaked_role)) and keyleak==(expected_key,),'leaked identity/key differs')
 _,message=one('Message','#m');sdk.require(message[:2]==(target[0],('constant',"'A'")),'wrong target message')
 for event,node in (('Cut','#c'),('KeyReserved','#g'),('EncapReserved','#e')):sdk.require(one(event,node)[1]==(target[0],),'wrong target reservation/cut')
 sdk.require(not any(a['jgnFactName'] in ('EntropyLeak','Snapshot') for n,a in acts),'unexpected disclosure')
 edges={}
 for edge in g['jgEdges']:edges.setdefault(edge['jgeSource'].split(':',1)[0],set()).add(edge['jgeTarget'].split(':',1)[0])
 def precedes(a,b):
  pending=list(edges.get(a,()));seen=set()
  while pending:
   item=pending.pop()
   if item==b:return True
   if item not in seen:seen.add(item);pending.extend(edges.get(item,()))
  return False
 pairs=[('#c','#g'),('#c','#e')]
 if label=='negative':
  sdk.require(one('K','#known')[1]==(message[-1],),'attacker plaintext differs')
  pairs.extend([('#leak','#m'),('#m','#known')])
 else:
  sdk.require(one('K','#learn_identity')[1]==(sibling[2],),'unrelated identity knowledge differs')
  sdk.require(one('OfferCommitted','#offer')[1]==(sibling[0],),'shared signer not actively used in sibling role')
  for node,role in (('#a',"'A'"),('#b',"'B'")):sdk.require(one('Confirmed',node)[1]==(target[0],('constant',role)),'target confirmation differs')
  pairs.extend([('#a','#m'),('#b','#m'),('#offer','#m'),('#learn_identity','#m')])
 for a,b in pairs:sdk.require(precedes(a,b),'missing causal path '+a+' < '+b)
 results[label]={'search_steps':search_steps,'replay_steps':replay_steps,'certificate_sha256':sdk.snapshot(stage/(replay+'-proof.spthy')).sha256,'trace_sha256':sdk.snapshot(stage/(replay+'-traces.json')).sha256,'identity_leak_rule':leaknode['jgnLabel'],'key_and_session_links_checked':True,'causal_edges_checked':True}
sdk.write_json(stage/'WITNESSES_35.json',{'completed':True,'witnesses':results,'negative_trace_exposes_exact_target_payload':True,'positive_trace_satisfies_recovery_premises_while_an_unrelated_identity_key_is_known':True,'positive_trace_is_not_a_secrecy_proof':True,'original_key_scoped_main_formula_unchanged':True,'no_helper_before_either_witness':True,'same_operational_model':True,'release_claim_eligible':False})
print(json.dumps(results))
