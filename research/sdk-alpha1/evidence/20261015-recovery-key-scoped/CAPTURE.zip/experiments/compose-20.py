from pathlib import Path
import json,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
p=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def parts(text):
 marks=list(p.finditer(text));blocks={}
 for i,m in enumerate(marks):
  stop=marks[i+1].start() if i+1<len(marks) else text.rindex('\nend')
  blocks[m.group(1)]=(m.group(),re.sub(r'/\*.*?\*/','',text[m.end():stop],flags=re.S).strip())
 return text[:marks[0].start()],blocks
prefix,base=parts((stage/'root-auth-16-proof.spthy').read_text())
receipt=json.loads((stage/'contribution-single-14-TERMINAL.json').read_text());sdk.require(receipt['accepted'],'contribution proof incomplete')
_,contribution=parts((stage/'contribution-single-14-proof.spthy').read_text())
name='encapsulation_derivation_requires_key_or_session_leak';decl,body=contribution[name]
attrs='[use_induction,reuse,hide_lemma=accepted_root_has_authenticated_origin,hide_lemma=message_root_has_authenticated_origin]'
base[name]=(re.sub(r'\[[^\]]+\]',lambda _:attrs,decl,count=1),body)
with (stage/'composed-auth-20.spthy').open('x') as out:out.write(prefix+'\n\n'+'\n\n'.join(d+'\n'+b for d,b in base.values())+'\n\nend\n')
fresh=(stage/'causal-fresh-17.spthy').read_text();pre,decls=parts(fresh);first='response_confirmation_has_origin_or_prior_root'
ordered=[first]+[n for n in decls if n!=first]
with (stage/'confirmation-first-20.spthy').open('x') as out:out.write(pre+'\n\n'+'\n\n'.join(decls[n][0] for n in ordered)+'\n\nend\n')
runner=(stage/'run-single-13.py').read_text();sdk.require(runner.count("'-M6G'")==1,'heap selector differs')
with (stage/'run-composed-20.py').open('x') as out:out.write(runner.replace("'-M6G'","'-M12G'"))
sdk.write_json(stage/'COMPOSED_AUTH_20.json',{'input_sha256':sdk.snapshot(stage/'composed-auth-20.spthy').sha256,'original_contribution_premise_scope_preserved':True,'public_and_root_properties_require_combined_replay':True,'model_or_main_formula_changed':False,'release_claim_eligible':False})
