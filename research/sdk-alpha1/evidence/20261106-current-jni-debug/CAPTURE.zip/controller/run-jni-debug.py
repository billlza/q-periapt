from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

import continuity_package as package
from continuity_kotlin_consumer import tool_identity

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
source = Path.cwd()
control = source.parent
previous = json.loads((control / 'JNI_RELEASE_PREFLIGHT.json').read_text())
commit, dirty = package.sdk.inspect_package_source(source, allow_dirty=False)
assert commit == previous['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert dirty is False
java_home = Path(previous['java_home'])
identity = tool_identity(java_home)
assert identity == previous['java_tool_identity']
openssl = Path(previous['openssl_prefix'])
java_version = subprocess.run([str(java_home / 'bin/java'), '--version'], check=True,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
openssl_version = subprocess.run([str(openssl / 'bin/openssl'), 'version'], check=True,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
assert java_version.stdout.decode() == previous['java_version'] and java_version.stderr == b''
assert openssl_version.stdout.decode() == previous['openssl_version'] and openssl_version.stderr == b''
report = source / 'target/sdk-020/RUST_SDK_PACKAGE.json'
digest = hashlib.sha256(report.read_bytes()).hexdigest()
assert digest == '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d'
assert not (source / 'target/continuity-installed-jni-debug-current').exists()
preflight = dict(previous, verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=commit, git_dirty=dirty, scope='Fresh original-source/JDK/OpenSSL preflight for current Rust/C/host-JNI Debug partition.')
with (control / 'JNI_DEBUG_PREFLIGHT.json').open('x') as stream:
    json.dump(preflight, stream, indent=2)
    stream.write('\n')
argv = ['sh', 'artifact/python-run.sh', 'artifact/continuity_package.py',
    '--report', str(report), '--report-sha256', digest,
    '--toolchain-root', '/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin',
    '--output', 'target/continuity-installed-jni-debug-current',
    '--build-profile', 'debug', '--with-c-consumer', '--with-android-jni-consumer',
    '--android-java-home', str(java_home), '--witness-openssl-prefix', str(openssl)]
env = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3')
request = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'argv': argv, 'cwd': str(source), 'source_commit': commit, 'sdk_report_sha256': digest,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'Original current-source installed Rust/C/host-JNI Debug partition. No custom filtering, outer deadline, component-limit change, Android ART/device claim or full six-partition acceptance. The separate Release process remains running; earlier ff072 failures remain retained.'}
with (control / 'JNI_DEBUG_REQUEST.json').open('x') as stream:
    json.dump(request, stream, indent=2)
    stream.write('\n')
started = time.monotonic()
with (control / 'jni-debug.stdout').open('xb') as stdout, (control / 'jni-debug.stderr').open('xb') as stderr:
    result = subprocess.run(argv, cwd=source, env=env, stdout=stdout, stderr=stderr)
record = {'returncode': result.returncode, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'seconds': time.monotonic() - started,
    'stdout_sha256': hashlib.sha256((control / 'jni-debug.stdout').read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256((control / 'jni-debug.stderr').read_bytes()).hexdigest()}
with (control / 'JNI_DEBUG_RESULT.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
