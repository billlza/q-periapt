from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-sessions';package=root/'target/continuity-browser-publication/source/target/policy-session-package-01'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={n:load(stage/n/'RESULT.json') for n in ['run01','run03','run04','run06']}
sdk.require(all(r['completed'] for r in reports.values()),'incomplete session run')
cases={c['case']:c for r in reports.values() for c in r['cases']}
sdk.require(set(cases)=={'live','drop-commit','drop-ack','cancel','kill-commit','kill-ack','bilateral','expired-bilateral'},'wrong cases')
for name,c in cases.items():
 sdk.require(c['active']['journal']==c['original']['journal'] and c['active']['status']['phase']==3,'not original P activation')
 sdk.require(c['legacy_refused']['code']=='Conflict' and c['legacy_refused']['ownerClosed'],'legacy binding changed')
 sdk.require(c['progress_before']==c['progress_after'] and c['progress_before']['pending']=='1' and c['progress_before']['confirmed']=='0','pending PQ state changed')
 sdk.require(c['rekey']['epoch']=='1' and c['delivery']=={'consumption':1,'status':3},'old control/message incomplete')
 controls=[x for x in c['peer_records'] if x['kind']==4];sdk.require(len(controls)>=2 and controls[0]['trigger'] and controls[0]['request_sha256']==controls[1]['request_sha256'],'original control bytes changed')
 messages=[x for x in c['peer_records'] if x['kind']==3];sdk.require(len(messages)==3 and messages[0]['trigger'] and messages[0]['request_sha256']==messages[1]['request_sha256'] and messages[2]['request_sha256']!=messages[1]['request_sha256'],'original message replay/fresh message')
 sdk.require(c['received']['application']['effects']==1 and c['received']['application']['calls']==1 and not c['duplicate']['callbackInvoked'] and c['duplicate']['reply']==c['received']['reply'],'application duplicate')
 sdk.require(c['reverse_finished']['authenticated_browser_consumption'] and c['reverse_finished']['same_original_wire'],'reverse message not confirmed')
 if name in ['bilateral','expired-bilateral']:
  sdk.require(c['native_policy']['policy_renewed'] and c['native_policy']['same_original_journal'] and c['native_policy']['session']==c['session'],'native original P/session')
 if name in ['kill-commit','kill-ack']:sdk.require(c['terminated']['killed'],'no actual worker termination')
 if name=='cancel':sdk.require(c['policy_loss']['cancellationRequested'],'no actual cancellation')
 if name in ['kill-ack','drop-ack']:sdk.require(c['interrupted']['progress']['stage']==2 and not c['interrupted']['progress']['retired'],'terminal not persisted before ACK')
e=cases['expired-bilateral']['real_expiry'];sdk.require(e['pending_at']<e['policy_until']<e['renew_at']<e['credentials_until'] and cases['expired-bilateral']['native_policy']['original_policy_expired'],'not real bilateral P0 expiry')
red=load(stage/'red01/RESULT.json');sdk.require(red['completed'] and red['cases'][0]['legacy_reopen_refusal']['code']=='Conflict','missing old API counterexample')
base=load(stage/'base10/RESULT.json');sdk.require(base['completed'] and len(base['report']['cases'])==10,'base browser')
sdk.require('11 passed; 0 failed' in (stage/'native-bundle-tests.log').read_text(),'bundle tests')
sdk.require('Ran 53 tests' in (stage/'controls.log').read_text() and (stage/'controls.log').read_text().rstrip().endswith('OK'),'controls')
for n in ['native-clippy.log','wasm-clippy.log','wasm-msrv.log']:
 t=(stage/n).read_text();sdk.require('Finished' in t and 'error:' not in t and 'warning:' not in t,n)
sdk.require(not (stage/'format.log').read_text(),'format')
source=load(stage/'SOURCE_OVERLAY.json')
for n,d in source['overlay'].items():sdk.require(sha(root/n)==d,'source drift '+n)
receipt=load(package/'INSTALLED_CONSUMER.json');sdk.require(receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz'),'package binding')
installed=Path(load(package/'consumer-location.json')['path'])
for run,r in reports.items():
 for n,d in r['native'].items():sdk.require(sha(Path(n))==d,'fixture binary changed')
 for n,d in r['source']['inputs'].items():sdk.require(sha(root/n)==d,'package source changed')
 for n,d in r['static_web'].items():
  sdk.require(sha(stage/(run+'-web')/n)==d,'driver static copy changed')
  if not n.startswith('creation/'):sdk.require(sha(installed/n)==d,'installed bytes changed')
members={};raw={}
def add(p,n):
 sdk.require(p.is_file() and not p.is_symlink() and n not in members,'bad member '+n)
 sdk.require(not any(x.endswith('-private') or x.startswith('private-') for x in p.parts),'private member')
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.sh'] and p.name not in ['seal.log','finalize.log','HANDOFF.json']:add(p,'driver/'+p.name)
for part in ['native-peer','native-peer-v2','authority']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/part/n,'native/'+part+'/'+n)
for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/'target/continuity-browser-policy-adoption/issuer'/n,'native/policy-issuer/'+n)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','native/witness.rs')
for run in ['red01','run01','run02','run03','run04','run05','run06','base10']:
 folder=stage/run
 for p in sorted(folder.iterdir()):
  if p.is_file():add(p,run+'/'+p.name)
 for part in ['logs','captures']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for part in ['witness','native','peer']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted((folder/'witness').rglob('RECORDS.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for row in load(p):
   if row['trigger']:
    for q in sorted(p.parent.glob(f"{row['number']:03}.*")):
     if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((folder/'peer').rglob('RECORD.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for name in ['request.bin','reply.bin','native.stdout','native.stderr']:
   q=p.parent/name
   if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((stage/(run+'-web')/'inputs').glob('*')):
  if p.is_file():add(p,'public-inputs/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/n,'package/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-policy-session-continuity';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 sdk.require(z.testzip() is None,'archive')
 for n,m in manifest.items():sdk.require(hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes'],'member hash')
checks={'completed':True,'release_claim_eligible':False,'source':source,'cases':sorted(cases),'case_count':len(cases),'real_policy_expiry':e,'validation':{'native_bundle_tests':11,'controls':53,'base_browser':10,'actual_worker_termination_cuts':2,'clippy_native_wasm':'strict passed','wasm_msrv':'1.90 passed','format':'passed','browser':base['report']['browser']},'counterexample':'red01: original journal activates P1; legacy session reopen returns Conflict while original message and epoch-1 control remain pending. New API preserves that legacy refusal.','diagnostics':{'run02':'Fixture child trace directories were 0755; private publisher refused. Separate v2 helper uses 0700; original source/binary remain frozen.','run05':'Initial session establishment hit caller-specified 10-second deadline during concurrent builds/cohorts. Both native replies returned successfully. Contention is a hypothesis, not proven cause. Fresh serial run06 retains identical source and timeout bounds. No performance/SLA claim.'},'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Current installed browser original session/PQ/control/ciphertext continuity through unilateral and bilateral independent P, real P0 expiry and original recovery. Shared Rust engine and loopback; not independent implementation, browser G/P/T full composition, OS crash, deployed migration, device, performance, PCS or release qualification.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
