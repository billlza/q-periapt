from pathlib import Path
r=Path.cwd()
p=r/'research/continuity-identity-candidate/src/bootstrap_bundle/reopen.rs';t=p.read_text();a='pub struct SessionReopenRequest {';assert t.count(a)==1;p.write_text(t.replace(a,'#[derive(Clone)]\n'+a))
p=r/'research/continuity-identity-candidate/src/browser/connections.rs';t=p.read_text();needle='    /// Establish/reconcile the exact original request through an authenticated peer proof.'
insert="""    /// Admit authenticated original history only through the current policy
    /// continuation already completed in this exact installation. The descriptor
    /// cannot bootstrap a session or supply its own policy authorization.
    pub async fn reopen_continued_session(
        &self,
        request: &crate::SessionReopenRequest,
        policy: Arc<VerifiedSessionPolicy>,
        now: u64,
    ) -> Result<exchange::Session, JsValue> {
        let mut op = self.operation()?;
        let result = async {
            let peer = op.active()?.parts()?.0
                .reopen_continued_peer(request.clone(), policy, now).await?;
            Ok(exchange::Session::from_reopened(&peer))
        }.await;
        op.finish(result).await
    }
"""
assert needle in t;p.write_text(t.replace(needle,insert+needle))
p=r/'crates/q-periapt-sdk-wasm/src/continuity/connections.rs';t=p.read_text();needle='fn message_id(';assert needle in t;p.write_text(t.replace(needle,'mod continuation;\n\n'+needle,1))
d=r/'crates/q-periapt-sdk-wasm/src/continuity/connections';d.mkdir(exist_ok=True)
(d/'continuation.rs').write_text("""// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Historical session input remains separate from current operational authority.
use super::super::history::HistoricalPolicy;
use super::*;

/// Independently authenticated original public session history. This immutable
/// descriptor owns no runtime, signer, journal or traffic permission. It can be
/// reused after an error; the original installation rechecks current authority.
#[wasm_bindgen(js_name = QPeriaptContinuitySessionReopenRequest)]
pub struct ReopenRequest {
    inner: engine::SessionReopenRequest,
}
#[wasm_bindgen(js_class = QPeriaptContinuitySessionReopenRequest)]
impl ReopenRequest {
    #[wasm_bindgen(constructor)]
    pub fn new(
        wire: &Uint8Array,
        original: &HistoricalPolicy,
        trust: &Trust,
        #[wasm_bindgen(unchecked_param_type = "QPeriaptContinuityRole")] local_role: JsValue,
        session: &Uint8Array,
        #[wasm_bindgen(unchecked_param_type = "bigint")] now: JsValue,
    ) -> Result<ReopenRequest, JsValue> {
        Ok(Self {
            inner: peers::bundle(wire)?.request_historical_reopen(
                Arc::new(original.inner.clone()),
                trust.required()?,
                peers::role(&local_role)?,
                array(session)?,
                read_time(now)?,
            ).map_err(protocol)?,
        })
    }
}
#[wasm_bindgen(js_class = QPeriaptContinuityDevice)]
impl Device {
    /// Reopen only the selected original session after policy activation. Its
    /// durable current authorization, archive, identity and witness must match;
    /// historical metadata or a live target policy alone cannot grant access.
    pub async fn reopen_continued_session(
        &self,
        request: &ReopenRequest,
        target: &SessionPolicy,
        #[wasm_bindgen(unchecked_param_type = "bigint")] now: JsValue,
    ) -> Result<Session, JsValue> {
        Ok(Session {
            inner: self.inner.reopen_continued_session(
                &request.inner, Arc::clone(&target.inner), read_time(now)?,
            ).await?,
        })
    }
}
""")
for n in ['index.js','index.d.ts']:
 p=r/'crates/q-periapt-sdk-wasm/package/web'/n;t=p.read_text();needle='  QPeriaptContinuitySession,';assert needle in t;p.write_text(t.replace(needle,needle+'\n  QPeriaptContinuitySessionReopenRequest,'))
p=r/'crates/q-periapt-sdk-wasm/tests/browser-suite.mjs';t=p.read_text();needle='      "QPeriaptContinuitySession",';assert needle in t;p.write_text(t.replace(needle,needle+'\n      "QPeriaptContinuitySessionReopenRequest",'))
for n in ['ARTIFACT.md','artifact/codeql_rust_quality.py']:
 p=r/n;t=p.read_text();assert '629' in t;p.write_text(t.replace('629','630'))
p=r/'crates/q-periapt-sdk-wasm/PackageREADME.md';t=p.read_text();needle='These entries share the native state machine. Browser lifecycle qualification';insert="""For an already established session after policy activation, construct
`QPeriaptContinuitySessionReopenRequest` from its original bundle, independently
pinned historical P0 and peer expectations, original session ID and role. Pass
that descriptor and the live target policy to `reopen_continued_session`.
The original journal must already contain the exact current authorization;
historical metadata alone cannot create a session or bypass current membership,
archive or witness checks. This does not grant new bootstrap permission.

""";assert needle in t;p.write_text(t.replace(needle,insert+needle))
