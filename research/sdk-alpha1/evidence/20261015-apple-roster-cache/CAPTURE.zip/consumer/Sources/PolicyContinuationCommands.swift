// SPDX-License-Identifier: Apache-2.0 OR MIT
import Foundation
import QPeriaptContinuity

enum PolicyContinuationCommands {
    static func target(_ input: ReplacementInputs) throws -> ReplacementInputs {
        let source = input.source.appendingPathComponent("policy-target")
        let version = try counter(exact(source, "policy-version", 8)[...])
        return ReplacementInputs(source: source, path: input.path + ".policy-target-\(version)")
    }

    static func createTarget(_ input: ReplacementInputs, recoverable: Bool) throws -> [UInt8] {
        let selected = try target(input)
        let configuration = try ContinuityConfiguration.prepareCreate(path: selected.path, input: initial(selected.source, recoverable))
        let result = Result { try configuration.finishOpen() }
        do { try configuration.close() } catch { throw ClientError("target close: \(error); operation: \(result)") }
        try result.get()
        return [1]
    }

    private static func selectTarget(_ input: ReplacementInputs, enrollment: ContinuityEnrollment, recoverable: Bool) throws {
        let selected = try target(input)
        let configuration = try ContinuityConfiguration.prepareOpen(path: selected.path,
            trust: trust(selected.source, recoverable), protocolPolicy: policy(selected.source))
        let result = Result { try configuration.finishOpen(); try configuration.selectContinuationTarget(for: enrollment) }
        do { try configuration.close() } catch { throw ClientError("target close: \(error); selection: \(result)") }
        try result.get()
    }

    private static func identity(_ enrollment: ContinuityEnrollment) throws -> [UInt8] {
        let status = try enrollment.status()
        guard let journal = status.journal else { throw ClientError("original journal absent") }
        return status.signingID.bytes + journal.bytes
    }

    private static func stage(_ mode: String, input: ReplacementInputs, enrollment: ContinuityEnrollment) throws -> [UInt8] {
        var request = try PortablePolicyRequest.read(input.fixed("renewal-request", 33176))
        var approvals = try input.fixed("renewal-approvals", 7618)
        if mode == "policy-stage-refused" { approvals[approvals.count - 1] ^= 1 }
        if mode == "policy-stage-scope" {
            let old = request.scope
            var operation = old.operation.bytes
            operation[0] ^= 1
            let scope = try PolicyRenewalScope(operation: PolicyRenewalID(bytes: operation), journal: old.journal,
                originalOwner: old.originalOwner, originalCredential: old.originalCredential,
                currentCredential: old.currentCredential, currentRoster: old.currentRoster,
                originalPolicy: old.originalPolicy, previousPolicy: old.previousPolicy,
                previousAuthorization: old.previousAuthorization)
            request = try PolicyRenewalRequest(scope: scope, account: request.account,
                originalRosterCheckpoint: request.originalRosterCheckpoint, originalCredential: request.originalCredential,
                originalRoster: request.originalRoster, currentCredential: request.currentCredential, currentRoster: request.currentRoster)
        }
        let code: Int32 = mode == "policy-stage-refused" ? 102 : mode == "policy-stage-scope" ? 103 : mode == "policy-stage-cancelled" ? 302 : 0
        if code == 302 { try enrollment.cancel() }
        let pin = try input.account(), previous = try policy(input.source)
        let operation = { try enrollment.stagePolicyRenewal(request: request, originalPin: pin, currentPin: pin, approvals: approvals, previous: previous) }
        if code != 0 { try expect(code) { _ = try operation() }; return bigNumber(UInt32(code)) }
        return statusBytes(try operation())
    }

    static func execute(_ mode: String, input: ReplacementInputs, enrollment: ContinuityEnrollment, recoverable: Bool) throws -> [UInt8] {
        let selecting = ["policy-reconcile", "policy-witness-prepare", "policy-witness-commit-unknown",
            "policy-witness-commit-replay", "policy-activate-renewed", "policy-activate-unmanaged",
            "policy-peer-retry", "policy-peer-rekey", "policy-peer-send"]
        if mode.hasPrefix("policy-stage") || selecting.contains(mode) {
            try selectTarget(input, enrollment: enrollment, recoverable: recoverable)
        }
        if mode.hasPrefix("policy-stage") { return try stage(mode, input: input, enrollment: enrollment) }
        if mode.hasPrefix("policy-peer-") {
            let device = try enrollment.activatePolicyRenewal()
            let result = Result { try ContinuedTraffic.run(device, input: input, mode: mode) }
            do { try device.close() } catch { throw ClientError("continued device close: \(error); operation: \(result)") }
            return try result.get()
        }
        switch mode {
        case "policy-identity": return try identity(enrollment)
        case "policy-activate-expired", "policy-activate-unmanaged", "policy-activate-unselected":
            let code: Int32 = mode == "policy-activate-expired" ? 104 : mode == "policy-activate-unmanaged" ? 211 : 1
            try expect(code) {
                let device = mode == "policy-activate-expired" ? try enrollment.activate() : try enrollment.activatePolicyRenewal()
                try device.close()
            }
            return bigNumber(UInt32(code))
        case "policy-request":
            let operation = try PolicyRenewalID(bytes: input.fixed("renewal-operation", 32))
            return try PortablePolicyRequest.write(enrollment.witnessedPolicyRenewalRequest(operation: operation))
        case "policy-status": return statusBytes(try enrollment.policyRenewalStatus())
        case "policy-approval":
            return try enrollment.pendingPolicyRenewalApproval(operation: PolicyRenewalID(bytes: input.fixed("renewal-operation", 32)))
        case "policy-reconcile": return statusBytes(try enrollment.reconcilePolicyRenewal())
        case "policy-resolve":
            try expect(216) {
                _ = try enrollment.resolvePolicyRenewal(operation: PolicyRenewalID(bytes: input.fixed("renewal-operation", 32)),
                    statement: PolicyRenewalStatementID(bytes: input.fixed("renewal-statement", 32)),
                    target: policy(input.source.appendingPathComponent("policy-target")))
            }
            return bigNumber(UInt32(216))
        case "policy-witness-prepare": return try enrollment.prepareWitnessedPolicyRenewal(previous: policy(input.source)).bytes
        case "policy-witness-recover":
            guard let proposal = try enrollment.recoverWitnessedPolicyRenewalPreparation() else { throw ClientError("retained proposal absent") }
            return proposal.bytes
        case "policy-progress": return progressBytes(try enrollment.witnessedPolicyRenewalProgress())
        case "policy-witness-commit-unknown", "policy-witness-commit-replay", "policy-witness-reconcile", "policy-witness-close":
            let proposal = try IndependentPolicyProposal(retainedBytes: input.fixed("renewal-proposal", 296))
            if mode == "policy-witness-commit-unknown" {
                try expect(218) { _ = try enrollment.commitWitnessedPolicyRenewal(proposal) }
                return bigNumber(UInt32(218))
            }
            let state = mode == "policy-witness-close" ? try enrollment.closeWitnessedPolicyRenewal(proposal) :
                mode == "policy-witness-commit-replay" ? try enrollment.commitWitnessedPolicyRenewal(proposal) :
                try enrollment.reconcileWitnessedPolicyRenewal(proposal)
            return bigNumber(state.rawValue)
        case "policy-activate-renewed":
            let original = try identity(enrollment), device = try enrollment.activatePolicyRenewal()
            let result = Result { try device.cancel() }
            do { try device.close() } catch { throw ClientError("activated device close: \(error); operation: \(result)") }
            try result.get()
            return original
        default: throw ClientError("unknown policy continuation operation")
        }
    }

    private static func statusBytes(_ value: PolicyRenewalStatus) -> [UInt8] {
        func row(_ phase: UInt32, _ operation: PolicyRenewalID, _ statement: PolicyRenewalStatementID,
                 _ target: PolicyCheckpoint, reason: UInt32 = 0, roster: RosterCheckpoint? = nil, at: UInt64 = 0) -> [UInt8] {
            var result = bigNumber(phase) + bigNumber(reason) + operation.bytes + statement.bytes
            result += bigNumber(target.version) + target.digest
            result += bigNumber(roster?.version ?? 0) + (roster?.digest ?? [UInt8](repeating: 0, count: 32)) + bigNumber(at)
            return result
        }
        switch value {
        case .absent: return [UInt8](repeating: 0, count: 160)
        case let .pending(operation, statement, target): return row(1, operation, statement, target)
        case let .committed(operation, statement, target): return row(2, operation, statement, target)
        case let .abandonedUncommitted(operation, statement, target, reason, roster, at):
            return row(3, operation, statement, target, reason: reason.rawValue, roster: roster, at: at)
        }
    }

    private static func progressBytes(_ value: IndependentPolicyProgress) -> [UInt8] {
        func row(_ phase: UInt32, _ proposal: IndependentPolicyProposal, _ target: PolicyCheckpoint, _ retired: Bool) -> [UInt8] {
            bigNumber(phase) + bigNumber(UInt32(retired ? 1 : 0)) + proposal.bytes + bigNumber(target.version) + target.digest
        }
        switch value {
        case .absent: return [UInt8](repeating: 0, count: 344)
        case let .reserved(proposal, target): return row(1, proposal, target, false)
        case let .applied(proposal, target, retired): return row(2, proposal, target, retired)
        case let .closed(proposal, target, retired): return row(3, proposal, target, retired)
        }
    }
}
