// SPDX-License-Identifier: Apache-2.0 OR MIT
import Foundation
import QPeriaptContinuity

enum ContinuedTraffic {
    static func run(_ device: ContinuityDevice, input: ReplacementInputs, mode: String) throws -> [UInt8] {
        if mode == "policy-peer-retry" { return try traffic(device, source: input.source, mode: "retry-send") }
        try requireIOS(["policy-peer-rekey", "policy-peer-send"].contains(mode), "continued peer operation")
        guard let address = String(bytes: try input.read("connection-address", 128), encoding: .ascii) else { throw ClientError("peer address") }
        let session = try SessionID(bytes: input.fixed("connection-session", 32))
        let peer = try device.preparePeerReopen(configuration: peerInput(input.source), quality: .oneTimeBoth, role: .initiator, session: session)
        let result = Result { () throws -> [UInt8] in
            try peer.finishOpen()
            if mode == "policy-peer-rekey" {
                try requireIOS(peer.rekey(peer: address, session: session, target: 1) == 1, "rekey epoch")
                return [1]
            }
            let original = try MessageID(bytes: input.fixed("connection-message", 32))
            try requireIOS(peer.status(session: session, message: original) == .acknowledged, "original message not acknowledged")
            let fresh = try peer.nextMessage(session: session)
            try requireIOS(fresh != original, "fresh message reused original identity")
            let sent = try peer.send(peer: address, session: session, message: fresh,
                plaintext: Array("continued after pending recovery".utf8), associatedData: Array("configuration-v1".utf8))
            try requireIOS(sent.consumption == .confirmed, "fresh message consumption not confirmed")
            try requireIOS(peer.status(session: session, message: fresh) == .acknowledged, "fresh acknowledgement not durable")
            return session.bytes + fresh.bytes
        }
        do { try peer.close() } catch { throw ClientError("continued peer close: \(error); operation: \(result)") }
        return try result.get()
    }
}
