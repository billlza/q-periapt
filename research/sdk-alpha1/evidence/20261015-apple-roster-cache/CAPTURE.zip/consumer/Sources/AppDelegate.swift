import UIKit
import Foundation

@main
@MainActor
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE didFinish protected=\(application.isProtectedDataAvailable)\n".utf8)) }
        catch { exit(76) }
        return true
    }
    func application(_ application: UIApplication, configurationForConnecting session: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        let configuration = UISceneConfiguration(name:"Validation",sessionRole:session.role)
        configuration.delegateClass = SceneDelegate.self
        return configuration
    }
}

@MainActor
final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    private var started = false
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options: UIScene.ConnectionOptions) {
        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE sceneConnect\n".utf8)) }
        catch { exit(76) }
        guard let windowScene = scene as? UIWindowScene else {
            fputs("QPC_IOS_STARTUP_FAIL unexpected scene type\n",stderr)
            exit(1)
        }
        let view = UIViewController()
        view.view.backgroundColor = .systemBackground
        let label = UILabel()
        label.text = "Continuity validation in progress"
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.view.addSubview(label)
        NSLayoutConstraint.activate([label.centerXAnchor.constraint(equalTo:view.view.centerXAnchor),label.centerYAnchor.constraint(equalTo:view.view.centerYAnchor)])
        let window = UIWindow(windowScene:windowScene)
        window.frame = windowScene.coordinateSpace.bounds
        window.rootViewController = view
        window.makeKeyAndVisible()
        self.window = window
    }
    func sceneDidBecomeActive(_ scene: UIScene) {
        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE sceneActive\n".utf8)) }
        catch { exit(76) }
        guard !started else { return }
        started = true
        Task { await ContinuityIOSRunner.execute() }
    }
}

func awaitHostAdmission(directory: URL, run: String) async throws {
    try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_READY run=\(run)\n".utf8))
    let path = directory.appendingPathComponent("admission-"+run+".txt")
    let clock = ContinuousClock(), deadline = clock.now.advanced(by:.seconds(20))
    while clock.now < deadline {
        if FileManager.default.fileExists(atPath:path.path) {
            let receipt = try Data(contentsOf:path)
            guard receipt == Data((run+"\n").utf8) else { throw ClientError("wrong host startup admission") }
            return
        }
        try await Task.sleep(for:.milliseconds(20))
    }
    throw ClientError("host startup admission timed out before SDK operation")
}
