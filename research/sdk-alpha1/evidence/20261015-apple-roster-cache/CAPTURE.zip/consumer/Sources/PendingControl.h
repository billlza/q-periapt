// SPDX-License-Identifier: Apache-2.0 OR MIT
#ifndef QPC_PENDING_CONTROL_H
#define QPC_PENDING_CONTROL_H
#include <stddef.h>
#include <stdint.h>
int32_t qpc_pending_control_open(uint16_t port);
int32_t qpc_pending_control_send(int32_t descriptor, const uint8_t *bytes, size_t length);
/* 0..255 is a byte, 256 is EOF, a negative value is -errno. */
int32_t qpc_pending_control_read(int32_t descriptor);
int32_t qpc_pending_control_close(int32_t descriptor);
#endif
