#include <stdint.h>
/* Qualification-only opaque stream relay. All descriptors have explicit owners. */
int qpc_test_relay_prepare(int descriptors[4], uint16_t ports[2]);
int qpc_test_relay_run(int transport_listener, int local_listener, int cancellation,
    uint16_t transport_port, const char *route, const char *run);
int qpc_test_relay_stop(int cancellation);

#include "PendingControl.h"

/* Wait until the owned control stream's 72-byte identity and cut byte have
 * been forwarded upstream. This is a local relay barrier, not a witness reply. */
int qpc_test_relay_control_forwarded(int cancellation);
