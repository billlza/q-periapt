// SPDX-License-Identifier: Apache-2.0 OR MIT
#include "PendingControl.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

int32_t qpc_pending_control_open(uint16_t port) {
    if (port == 0) return -EINVAL;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -errno;
    int failure = 0;
    struct sockaddr_in address = {0};
    address.sin_len = sizeof(address);
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (fcntl(fd, F_SETFD, FD_CLOEXEC) != 0 || fcntl(fd, F_SETFL, O_NONBLOCK) != 0) {
        failure = errno;
        goto failed;
    }
    if (connect(fd, (const struct sockaddr *)&address, sizeof(address)) != 0) {
        if (errno != EINPROGRESS) { failure = errno; goto failed; }
        struct pollfd pending = {.fd = fd, .events = POLLOUT};
        int ready = poll(&pending, 1, 3000);
        if (ready <= 0) { failure = ready == 0 ? ETIMEDOUT : errno; goto failed; }
        socklen_t size = sizeof(failure);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &failure, &size) != 0) failure = errno;
        if (failure != 0) goto failed;
    }
    struct timeval timeout = {.tv_sec = 3, .tv_usec = 0};
    int no_sigpipe = 1;
    if (fcntl(fd, F_SETFL, 0) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &no_sigpipe, sizeof(no_sigpipe)) != 0) {
        failure = errno;
        goto failed;
    }
    return fd;
failed:
    if (close(fd) != 0) return -errno;
    return -failure;
}

int32_t qpc_pending_control_send(int32_t descriptor, const uint8_t *bytes, size_t length) {
    if (bytes == NULL || (length != 1 && length != 72)) return EINVAL;
    size_t written = 0;
    while (written < length) {
        ssize_t count = send(descriptor, bytes + written, length - written, 0);
        if (count < 0) return errno;
        if (count == 0) return EPIPE;
        written += (size_t)count;
    }
    return 0;
}

int32_t qpc_pending_control_read(int32_t descriptor) {
    uint8_t byte = 0;
    ssize_t count = recv(descriptor, &byte, 1, 0);
    if (count < 0) return -errno;
    return count == 0 ? 256 : byte;
}

int32_t qpc_pending_control_close(int32_t descriptor) {
    return close(descriptor) == 0 ? 0 : errno;
}
