from pathlib import Path
import json,hashlib
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;run=stage/'ipad-07'
state=json.loads((run/'RESULT_06.json').read_text());sdk.require(not state['completed'] and state['cleanup'] and not state['live_producer'],'failed producer not terminal/cleaned')
sdk.require(not list((run/'device-execution').glob('*/RESULT.json')),'successful SDK operation unexpectedly present')
folders=list((run/'device-execution').iterdir());sdk.require(len(folders)==1,'unexpected launch count')
folder=folders[0];transport=json.loads((folder/'USB_TRANSPORT.json').read_text());console=(folder/'launch.stdout').read_bytes()
sdk.require(not transport['startup_admitted'] and not transport['exchanges'],'SDK startup was admitted')
sdk.require(b'QPC_IOS_LIFECYCLE sceneConnect' in console and b'QPC_IOS_LIFECYCLE sceneActive' not in console and b'QPC_IOS_READY ' not in console,'startup boundary differs')
app=json.loads((run/'APP.json').read_text())
sdk.write_json(stage/'FAILED_IPAD_21.json',{'completed':True,'qualification_passed':False,'runtime_sealed':True,
 'source_commit':state['source_commit'],'package_sha256':state['package_sha256'],'app_sha256':state['app_sha256'],
 'public_run':str(run),'successful_sdk_operation_count':0,'launch_attempts':1,'startup_admitted':False,
 'observed_lifecycle':['didFinish protected=true','sceneConnect'],'scene_active_observed':False,
 'deadline_seconds':80,'test_finished_seconds':84.09,'owned_app_removed':True,
 'lock_observation':{k:v for k,v in json.loads((stage/'LOCK_STATE_18.json').read_text()).items() if k!='deviceIdentifier'},
 'root_cause':'Not established; no scene-active or host-admission marker. Lock query does not independently establish a usable foreground scene.',
 'evidence':{str(p.relative_to(run)):sdk.snapshot(p).sha256 for p in [run/'RESULT_06.json',run/'device-06-signed-fixed-unapplied.stdout',run/'device-06-signed-fixed-unapplied.stderr',folder/'launch.stdout',folder/'launch.stderr',folder/'USB_TRANSPORT.json']},
 'reopen_allowed':False})
print('Failed iPad startup sealed: zero SDK admissions, one launch, verified owned app removal')
