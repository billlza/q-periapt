from pathlib import Path
import ast
import json
import secrets
import subprocess
import tempfile
import rust_sdk_profile as sdk
import continuity_apple_package as apple

root=Path.cwd();stage=Path(__file__).resolve().parent
prior=root/'target/continuity-apple-pending-continuation/attempt-12'
old=json.loads((prior/'APP.json').read_text())
old_prepared=json.loads((prior/'PREPARED_01.json').read_text())
prepared=json.loads((stage/'PREPARED_03.json').read_text())
record=stage/'package-04/CONTINUITY_APPLE_PACKAGE.json'
package=json.loads(record.read_text())
sdk.require(package['completed'],'new Apple package incomplete')
current_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sdk.require(current_head=='5a03bbdb6ccd90824b7adfc3a54ee687c4cd2944','unexpected ready-source head')
changed=subprocess.check_output(['git','diff','--name-only',prepared['source_commit'],current_head],text=True).splitlines()
sdk.require(all(name in {'docs/SDK_0_2_RELEASE_READINESS.md','docs/SDK_INTERNAL_REVIEW.md'} or
 name.startswith(('research/sdk-alpha1/evidence/20261015-apple-roster-cache-package/',
                  'research/sdk-alpha1/evidence/20261015-sdk-policy-codeql-review/')) for name in changed),
 'runtime, binding or qualification implementation differs from built package')
sdk.require(not subprocess.check_output(['git','status','--porcelain']), 'source dirty')
installed=Path(prepared['outside'])/'apple-package/installed'/apple.NAME
apple.verify_package(installed,json.loads((installed/apple.CONTENTS).read_text()),package['native'],
                     (root/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes())
sdk.require(sdk.snapshot(record.parent/package['archive']['file'],maximum=256*1024**2).sha256==package['archive']['sha256'], 'archive identity changed')
run=stage/'ipad-27';run.mkdir(mode=0o700)
outside=Path(tempfile.mkdtemp(prefix='qpc-apple-cache-ipad-')).resolve();consumer=outside/'consumer'
for name,digest in old['source_files'].items():
    source=Path(old['consumer'])/name
    sdk.require(sdk.snapshot(source).sha256==digest,'prior test consumer changed')
    sdk.copy(source,consumer/name)
project=json.loads((consumer/'project.json').read_text())
bundle='dev.qperiapt.RosterCache.r'+secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER']=bundle
project['packages']['Continuity']['path']=str(installed)
(consumer/'project.json').write_text(json.dumps(project,indent=2)+'\n')
for name in ('device_support.py','ios_client.py','usb_transport.py','relay_forward.py','run-cases-06.py','census_review.py'):
    sdk.require(sdk.snapshot(prior/name).sha256==old['driver_files'][name],'prior driver changed: '+name)
    sdk.copy(prior/name,run/name)
(run/'ios_client.py').chmod(0o700)
sdk.copy(prior/'build-app-05.py',run/'build-app-05.py')
for name in ('test_census_review.py','public_capture_check.py'):
    sdk.copy(prior/name,run/name)
path=run/'run-cases-06.py';text=path.read_text()
start=text.index("    sdk.require(not subprocess.check_output(['git', 'diff', '610234b0b684e4e39bad97a953f5c66e74df2e91'")
end=text.index('\n\n\ndef readback_cuts',start)
text=text[:start]+'''    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == prepared['source_commit'], 'qualification head changed')
    sdk.require(not subprocess.check_output(['git', 'diff', prepared['source_commit'], '--',
        'research/continuity-identity-candidate', 'bindings', 'artifact']), 'qualification sources changed')
    expected = {
        'research/continuity-identity-candidate/src/durable.rs',
        'research/continuity-identity-candidate/src/durable/rosters.rs',
        'research/continuity-identity-candidate/src/durable/rosters/decode_cache.rs',
        'research/continuity-identity-candidate/src/durable/rosters/decode_cache/tests.rs',
        'research/continuity-identity-candidate/src/durable/rosters/policy_continuation_tests.rs',
    }
    changed = subprocess.check_output(['git', 'diff', '--name-only',
        '610234b0b684e4e39bad97a953f5c66e74df2e91', prepared['source_commit'], '--',
        'research/continuity-identity-candidate/src', 'research/continuity-identity-candidate/Cargo.toml',
        'research/continuity-identity-candidate/Cargo.lock', 'bindings/c/ContinuityPackageConsumer/src',
        'bindings/c/ContinuityPackageConsumer/Cargo.toml'], text=True).splitlines()
    sdk.require(set(changed) == expected, 'unexplained host/device engine difference')
'''+text[end:]
ast.parse(text);path.write_text(text)
for row in old_prepared['host_files'].values():
    sdk.require(sdk.snapshot(Path(row['path']),maximum=256*1024**2).sha256==row['sha256'],'host fixture changed')
sdk.write_json(run/'APP_SOURCE_01.json',{'consumer':str(consumer),'bundle':bundle,
    'source_files':{p.relative_to(consumer).as_posix():sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}})
sdk.write_json(run/'PREPARED_01.json',{'source_commit':current_head,'sdk_source_commit':prepared['source_commit'],
    'outside':str(outside),'consumer':str(consumer),'installed':str(installed),
    'package_record':str(record),'package_sha256':package['archive']['sha256'],
    'host_files':old_prepared['host_files'],'environment':prepared['environment'],
    'reference_engine_source_commit':'610234b0b684e4e39bad97a953f5c66e74df2e91',
    'scope':'Fresh physical iPad states, current Apple package and unchanged prior native reference engine; shared protocol implementation, cross-version integration, not independent implementation.'})
print('Fresh physical iPad cohort prepared against current Apple archive; no runtime reopened')
