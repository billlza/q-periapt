from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parent
out=root/'codeql-control-09';out.mkdir(mode=0o700)
artifacts=[('baseline',11953660326,16292711,'015fc0bf5a62d28e349c89d55151fe00a3e2b5711def36022b4b47f2ec3ae7e5'),
('single-thread',11953017245,14788659,'2e5f4e514d16dbbff3e7750c91b3fe1d6a5e9e66e21b83521a898d2d17291a57')]
result={}
for label,ident,size,digest in artifacts:
 path=out/(label+'.zip')
 with path.open('xb') as stream:
  subprocess.run(['gh','api',f'repos/billlza/q-periapt/actions/artifacts/{ident}/zip'],stdout=stream,stderr=subprocess.PIPE,check=True,timeout=120)
 assert path.stat().st_size==size and hashlib.sha256(path.read_bytes()).hexdigest()==digest
 with zipfile.ZipFile(path) as archive:
  names=archive.namelist();assert len(names)==len(set(names))
  assert len(names)<1000 and sum(x.file_size for x in archive.infolist())<1024**3
  summary={'artifact_id':ident,'archive_sha256':digest,'files':[{'path':i.filename,'bytes':i.file_size} for i in archive.infolist()]}
  for suffix in ('RESULT.json','query.json'):
   matches=[n for n in names if n==suffix or n.endswith('/'+suffix)];assert len(matches)==1
   assert archive.getinfo(matches[0]).file_size<65536
   summary[suffix]=json.loads(archive.read(matches[0]))
  console=[n for n in names if n=='query.console' or n.endswith('/query.console')];assert len(console)==1
  completed=[];tail=[];summary_lines=[]
  with archive.open(console[0]) as stream:
   for raw in stream:
    assert len(raw)<1024**2
    line=raw.decode('utf-8',errors='replace').rstrip()
    if 'Writing results to ' in line or ('[' in line and '/39' in line and ('eval' in line or 'cache' in line)):completed.append(line)
    if 'SummaryStats' in line:summary_lines.append(line)
    tail.append(line)
    if len(tail)>12:tail.pop(0)
  summary.update(completed_queries=completed,summary_lines=summary_lines[-12:],console_tail=tail)
  result[label]=summary
(out/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
for label,row in result.items():
 print(label,json.dumps({k:row[k] for k in ['query.json','completed_queries','summary_lines','console_tail']}))
