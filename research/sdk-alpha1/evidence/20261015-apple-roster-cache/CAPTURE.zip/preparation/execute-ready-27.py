from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(stage/'prepare-ready-27.py')],
            stage/'device-prepare-27',root)
run=stage/'ipad-27'
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(run/'build-app-05.py')],
            run/'build-driver-14',root)
print('Current-package physical app built and signed; starting fresh iPad cohort',flush=True)
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(run/'run-cases-06.py')],
            run/'device-driver-04',root)
sdk.command([sys.executable,'-B',str(run/'test_census_review.py')],run/'census-controls-15',root)
state=json.loads((run/'RESULT_06.json').read_text())
sdk.require(state['completed'] and state['cleanup'] and not state['live_producer'],'device qualification incomplete')
sdk.write_json(stage/'DEVICE_COMPLETE_27.json',{'completed':True,'run':str(run),'physical_swift_processes':state['physical_swift_processes'],
 'actual_process_cuts':state['actual_process_cuts'],'package_sha256':state['package_sha256'],'app_sha256':state['app_sha256'],
 'device_model':state['device_model'],'device_os':state['device_os'],'cleanup':True})
print('Fresh iPad continued recovery passed; process census controls passed; owned app removed',flush=True)
