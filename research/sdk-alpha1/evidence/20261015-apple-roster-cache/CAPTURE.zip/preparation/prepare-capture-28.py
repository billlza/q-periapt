from pathlib import Path
import ast
root=Path.cwd();stage=Path(__file__).resolve().parent;run=stage/'ipad-27'
text=(root/'target/continuity-apple-pending-continuation/attempt-12/capture-08.py').read_text()
start=text.index('parent = stage.parent\nfailed = ')
end=text.index('sdk.require(all(not name.endswith',start)
text=text[:start]+'''parent = stage.parent
for path in parent.iterdir():
    if path.is_file() and path.suffix in {'.py', '.md'}:
        add(path, 'preparation/' + path.name)
for name in ['PREPARING_03.json','RESOLUTION_03.json','DEVICE_COMPLETE_27.json','CODEQL_CONTROL_11.json']:
    add(parent/name,'preparation/'+name)
for path in (parent/'package-04/apple-package').iterdir():
    if path.is_file() and path.suffix in {'.json','.stdout','.stderr'}:
        add(path,'package/qualification/'+path.name)
for name in ['candidate-list-03','candidate-package-03','resolution-03','device-prepare-27']:
    for suffix in ['.json','.stdout','.stderr']:
        add(parent/(name+suffix),'preparation/'+name+suffix)
for name in ['src/durable.rs','src/durable/rosters.rs','src/durable/rosters/decode_cache.rs',
             'src/durable/rosters/decode_cache/tests.rs','src/durable/rosters/policy_continuation_tests.rs']:
    add(root/'research/continuity-identity-candidate'/name,'source/candidate/'+name)
'''+text[end:]
text=text.replace("redactions[failed['device_sha256']] = '<SELECTED_DEVICE_SHA256>'\n",'')
text=text.replace("[* (stage / 'device-execution').glob('*/PROCESS_RESULT.json'), * (parent / 'device-execution').glob('*/PROCESS_RESULT.json')]", "(stage / 'device-execution').glob('*/PROCESS_RESULT.json')")
text=text.replace("'research/sdk-alpha1/evidence/20261015-apple-pending-continuation'", "'research/sdk-alpha1/evidence/20261015-apple-roster-cache'")
text=text.replace("'sdk_implementation_changed': False", "'sdk_implementation_changed': True")
text=text.replace("'bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/continuation.rs',", "'bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/continuation.rs',\n             'bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/traffic.rs',\n             'research/continuity-identity-candidate/tests/owned_connection.rs',")
text=text.replace("    'phase_census': census,", "    'business_effect_verification': 'Native harness reads actual responder application files, checks original bytes and exact count two; independent archive reader checks exported copies, message identities and receiver terminal outputs.',\n    'prior_startup_evidence': '../20261015-apple-roster-cache-package/README.md',\n    'phase_census': census,")

start=text.index("    'failed_original_cohort_retained': True,")
end=text.index("    'connection_resets':",start)
text=text[:start]+"    'scope': prepared['scope'],\n    'reference_engine_source_commit': prepared['reference_engine_source_commit'],\n"+text[end:]
assert "failed[" not in text and "old_app[" not in text
ast.parse(text)
with (run/'capture-28.py').open('x') as stream:stream.write(text)
print('Fresh source/package/device archive reader prepared; only public outputs selected')
