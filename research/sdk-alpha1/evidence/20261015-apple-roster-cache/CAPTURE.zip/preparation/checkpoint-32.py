from pathlib import Path
import json,subprocess,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
expected='5a03bbdb6ccd90824b7adfc3a54ee687c4cd2944'
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected,'unexpected source head')
evidence=root/'research/sdk-alpha1/evidence/20261015-apple-roster-cache'
manifest=json.loads((evidence/'CAPTURE.json').read_text());readback=json.loads((evidence/'READBACK.json').read_text())
sdk.require(readback['completed'] and readback['capture_sha256']==manifest['capture_sha256'] and sdk.snapshot(evidence/'CAPTURE.zip',maximum=64*1024**2).sha256==manifest['capture_sha256'],'capture identity differs')
state=json.loads((stage/'ipad-27/RESULT_06.json').read_text())
sdk.require(state['completed'] and state['cleanup'] and not state['live_producer'] and state['physical_swift_processes']==121 and state['actual_process_cuts']==4,'physical cohort incomplete')
sdk.require(json.loads((stage/'ipad-27/PUBLIC_CONTROLS_29.json').read_text())['rejected_substitutions']==16,'reader controls incomplete')
sdk.require(json.loads((stage/'ipad-27/census-controls-15.json').read_text())['returncode']==0,'census controls incomplete')
allowed={'docs/SDK_0_2_RELEASE_READINESS.md'}|{p.relative_to(root).as_posix() for p in evidence.iterdir() if p.is_file()}
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True).splitlines()
sdk.require({row[3:] for row in status}==allowed and not subprocess.check_output(['git','diff','--cached','--name-only']),'unexpected source/staged changes')
sdk.command(['git','diff','--check'],stage/'diff-32',root)
sdk.command(['git','add','--',*sorted(allowed)],stage/'stage-32',root)
sdk.command(['git','diff','--cached','--check'],stage/'staged-check-32',root)
sdk.command(['git','commit','-m','Qualify current Apple package through physical continued recovery'],stage/'commit-32',root)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();sdk.require(not subprocess.check_output(['git','status','--porcelain']),'main not clean')
clone=root/'target/continuity-browser-publication/source'
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'clone changed')
sdk.command(['git','fetch',str(root),head],stage/'clone-fetch-32',clone)
sdk.command(['git','merge','--ff-only',head],stage/'clone-ff-32',clone)
sdk.command([sys.executable,'-B',str(clone/'artifact/python_bootstrap.py'),str(clone/'artifact/source_results_assembler.py'),
 'ci-source-gate','9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],stage/'source-gate-32',clone)
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'source gate changed clone')
sdk.write_json(stage/'CHECKPOINT_32.json',{'completed':True,'source_commit':expected,'sdk_source_commit':manifest['sdk_source_commit'],
 'checkpoint_commit':head,'source_clean':True,'source_gate':True,'physical_sdk_recovery_passed':True,'physical_swift_processes':121,
 'actual_process_cuts':4,'public_reader_substitution_controls':16,'business_effects_per_route':2,'owned_app_removed':True,
 'capture_sha256':manifest['capture_sha256'],'capture_members':len(manifest['members']),'product_code_changed':False,
 'pushed':False,'release_claim_eligible':False})
print(json.dumps({'checkpoint_commit':head,'source_gate':True,'physical_sdk_recovery_passed':True,'pushed':False}))
