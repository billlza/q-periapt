# Bounded evaluator comparison on the retained Rust database

Run 38692135312 used experiment commit 9d396755c3f872d3a59932c6fe106b2b5e1b2e59.
The database is the previously frozen 3b654771 source/49a76aa0 merge database,
not the current-source database. Both profiles retained all 39 exact query and
compiled-plan hashes, a 5,788 MiB JVM heap, 6,898 MiB native evaluator allocation,
and a 900-second bound. Only execution threads differed: four versus one.

Both evaluations timed out and reported unambiguous child cleanup. The baseline
logged 38 completed results; single-thread logged 35. Neither logged a completed
full SummaryStats result. The retained evaluator logs contain 2,856 and 844
memory-eviction pauses respectively, with 2,139 and 189 events mentioning VITAL
data. These are whole-evaluation event counts, not elapsed-time measurements,
unique allocations, a controlled RAM comparison, or proof of the sole cause.
Single-thread serialization also leaves later queries unexecuted when the full
summary query has not completed. This comparison does not establish a fix.

The first local reader assumed query.console would be included and stopped with
an assertion. The producer's bounded capture omits that console on timeout; its
separate evaluator log and terminal query.json remain. A fresh streaming reader
used those logs, verified each downloaded ZIP against GitHub's artifact digest,
and retained the original reader failure. Loaded-query markers are not counted
as completed results in CODEQL_CONTROL_11.json. Both raw archives remain locally
retained; artifact IDs and exact digests are in that receipt.

No query, security check, source inventory, timeout or supported target was
changed. The independent current-source CodeQL run 38692152632 remains a
separate qualification requirement.
