from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_apple_package as apple

stage=Path(__file__).resolve().parent
prepared=json.loads((stage/'PREPARED_03.json').read_text())
out=stage/'package-04';out.mkdir(mode=0o700)
result=apple.qualify_apple(Path(prepared['outside']),out,prepared['environment'])
sdk.require(result['completed'],'Apple package did not complete')
print('Current arm64 Apple package and consumer builds passed; physical recovery remains separate')
