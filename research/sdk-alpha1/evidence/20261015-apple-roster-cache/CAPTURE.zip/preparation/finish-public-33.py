"""Complete public-only controls after the device producer terminated successfully."""
from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;run=stage/'ipad-27'
state=json.loads((run/'RESULT_06.json').read_text())
sdk.require(state['completed'] and state['cleanup'] and not state['live_producer'],'device producer not terminal')
sdk.require(json.loads((run/'device-driver-04.json').read_text())['returncode']==0,'device producer failed')
old=json.loads((run/'census-controls-15.json').read_text())
sdk.require(old['returncode']==1 and "ModuleNotFoundError: No module named 'continuity_android_pending'" in (run/'census-controls-15.stderr').read_text(),'unexpected original control failure')
# Bootstrap supplies repository imports; the explicit source-only helper directory
# supplies the unchanged census_review module used by the original test file.
code='import sys,runpy; sys.path.insert(0, '+repr(str(run))+'); runpy.run_path('+repr(str(run/'test_census_review.py'))+',run_name="__main__")'
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),'-c',code],run/'census-controls-33',root)
sdk.write_json(stage/'DEVICE_COMPLETE_33.json',{'completed':True,'run':str(run),'physical_swift_processes':state['physical_swift_processes'],
 'actual_process_cuts':state['actual_process_cuts'],'package_sha256':state['package_sha256'],'app_sha256':state['app_sha256'],
 'device_model':state['device_model'],'device_os':state['device_os'],'cleanup':True,
 'original_outer_failure':'Public census tests were launched without the repository bootstrap and failed import before running tests.',
 'public_controls_receipt':'ipad-27/census-controls-33.json','private_runtime_reopened':False})
print('Unchanged four census tests passed using explicit source imports; physical state remains closed')
