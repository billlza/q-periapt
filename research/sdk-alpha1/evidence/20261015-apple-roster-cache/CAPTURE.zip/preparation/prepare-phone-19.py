from pathlib import Path
import ast,json,secrets,tempfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
prior=stage/'ipad-07';run=stage/'iphone-startup-19';run.mkdir(mode=0o700)
old=json.loads((prior/'APP.json').read_text());prepared=json.loads((prior/'PREPARED_01.json').read_text())
sdk.require(json.loads((prior/'RESULT_06.json').read_text())['cleanup'],'previous owned app cleanup unresolved')
outside=Path(tempfile.mkdtemp(prefix='qpc-apple-cache-startup-')).resolve();consumer=outside/'consumer'
for name,digest in old['source_files'].items():
 p=Path(old['consumer'])/name;sdk.require(sdk.snapshot(p).sha256==digest,'consumer source changed');sdk.copy(p,consumer/name)
project=json.loads((consumer/'project.json').read_text());bundle='dev.qperiapt.StartupControl.r'+secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER']=bundle
(consumer/'project.json').write_text(json.dumps(project,indent=2)+'\n')
for name in ['device_support.py','ios_client.py','usb_transport.py','relay_forward.py','run-cases-06.py','census_review.py']:
 sdk.require(sdk.snapshot(prior/name).sha256==old['driver_files'][name],'driver changed');sdk.copy(prior/name,run/name)
sdk.copy(prior/'build-app-05.py',run/'build-app-05.py')
path=run/'device_support.py';text=path.read_text()
a="x.get('connectionProperties',{}).get('transportType')=='wired' and x.get('hardwareProperties',{}).get('deviceType')=='iPad'"
b="x.get('connectionProperties',{}).get('transportType')=='localNetwork' and x.get('connectionProperties',{}).get('tunnelState')=='connected' and x.get('hardwareProperties',{}).get('deviceType')=='iPhone'"
sdk.require(text.count(a)==1,'device selection shape');text=text.replace(a,b).replace('exactly one explicitly offered wired iPad is required','exactly one offered connected physical network iPhone is required')
ast.parse(text);path.write_text(text)
prepared.update(outside=str(outside),consumer=str(consumer),scope='Current Apple package; pre-SDK cold startup control on explicitly offered network iPhone; no SDK protocol work or USB streams.')
sdk.write_json(run/'PREPARED_01.json',prepared)
sdk.write_json(run/'APP_SOURCE_01.json',{'consumer':str(consumer),'bundle':bundle,
 'source_files':{p.relative_to(consumer).as_posix():sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}})
script=(root/'target/continuity-apple-pending-recovery/startup-diagnostic-15.py').read_text()
script=script.replace("parent=Path(__file__).resolve().parent;stage=parent/'attempt-14';sys.path.insert(0,str(stage))", "stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))")
script=script.replace("out=stage/'startup-only-15'", "out=stage/'startup-only-20'")
script=script.replace('for index in [1,2]:\n        if index==2:time.sleep(190)', 'for index in [1]:')
script=script.replace("print('Both pre-SDK startups passed across 190 seconds idle; no recovery result is implied')", "print('Cold network iPhone startup passed; SDK protocol was not invoked')")
ast.parse(script)
with (run/'startup-20.py').open('x') as stream:stream.write(script)
print('Fresh iPhone pre-SDK startup control prepared; previous iPad cohort remains sealed')
