from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;run=stage/'ipad-27'
complete=json.loads((stage/'DEVICE_COMPLETE_27.json').read_text())
sdk.require(complete['completed'] and complete['cleanup'],'device qualification incomplete')
for name,prefix in [('public-controls-29.py','public-controls-29'),('capture-28.py','capture-31')]:
 sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(run/name)],run/prefix,root)
evidence=root/'research/sdk-alpha1/evidence/20261015-apple-roster-cache'
manifest=json.loads((evidence/'CAPTURE.json').read_text())
text=(stage/'device-report-30.draft.txt').read_text().replace('CAPTURE_DIGEST',manifest['capture_sha256']).replace('CAPTURE_MEMBERS',str(len(manifest['members']))).replace('RESET_COUNT',str(len(manifest['connection_resets'])))
with (evidence/'README.md').open('x') as stream:stream.write(text)
print(json.dumps({'capture_sha256':manifest['capture_sha256'],'members':len(manifest['members']),'resets':len(manifest['connection_resets'])}))
