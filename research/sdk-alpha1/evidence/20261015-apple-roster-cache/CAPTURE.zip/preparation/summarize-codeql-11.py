from collections import Counter
from pathlib import Path
import hashlib,json,re,zipfile
stage=Path(__file__).resolve().parent
source=json.loads((stage/'codeql-control-10/SUMMARY.json').read_text())
results={}
for label,row in source.items():
 archive=stage/('codeql-control-09/baseline.zip' if label=='baseline' else 'codeql-control-10/single-thread.zip')
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==row['archive_sha256']
 complete=[line for line in row['completed_queries'] if 'Evaluation done; writing results to ' in line]
 names=[line.split('writing results to ',1)[1].rstrip('.') for line in complete]
 assert len(names)==len(set(names))
 counts=Counter();iterations={};samples=[];last_evaluation=None;has_summary_result=False;lines=0;digest=hashlib.sha256()
 with zipfile.ZipFile(archive) as z,z.open(row['log_source']) as stream:
  for raw in stream:
   lines+=1;digest.update(raw)
   assert len(raw)<1024**2
   line=raw.decode(errors='replace').rstrip()
   if '[PROGRESS]' in line and 'Starting evaluation of ' in line:last_evaluation=line
   if 'Pausing evaluation to evict ' in line:counts['memory_eviction_pauses']+=1
   if 'SummaryStats.bqrs' in line:has_summary_result=True
   m=re.search(r'TaintReach::.*\(iteration ([0-9]+)\)',line)
   if m:
    iterations['TaintReach']=max(iterations.get('TaintReach',0),int(m[1]))
   if 'Unpausing evaluation:' in line and 'VITAL' in line:
    counts['evictions_including_vital_data']+=1
    samples.append({'line':lines,'text':line})
    if len(samples)>3:samples.pop(0)
 report=row['RESULT.json'];query=row['query.json']
 results[label]={'artifact_id':row['artifact_id'],'archive_sha256':row['archive_sha256'],
  'database_zip_sha256':report['database_zip_sha256'],'experiment_commit':report['experiment_commit'],
  'query_count':39,'completed_query_count':len(complete),'completed_result_paths':names,
  'full_summary_result_observed':has_summary_result,'stopped':query['stopped'],
  'seconds':query['seconds'],'cleanup_ambiguous':query['cleanup_ambiguous'],
  'threads':report['threads'],'heap_MB':report['heap_MB'],'off_heap_MB':report['off_heap_MB'],
  'log_sha256':digest.hexdigest(),'log_lines':lines,'counts':dict(counts),
  'max_observed_iterations':iterations,'last_started_query':last_evaluation,'last_vital_evictions':samples,
  'console_receipt_absent':row['console_missing'],'current_source_security_qualification':False}
(stage/'CODEQL_CONTROL_11.json').write_text(json.dumps(results,indent=2)+'\n')
for label,row in results.items(): print(label,{k:row[k] for k in ['completed_query_count','full_summary_result_observed','stopped','seconds','counts','max_observed_iterations']})
