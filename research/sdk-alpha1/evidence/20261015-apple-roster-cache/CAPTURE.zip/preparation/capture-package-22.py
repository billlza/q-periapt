from pathlib import Path
import hashlib,json,sys,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(stage/'ipad-07'))
from public_capture_check import contains_private_pem
package_path=stage/'package-04/CONTINUITY_APPLE_PACKAGE.json'
package=json.loads(package_path.read_text());prepared=json.loads((stage/'PREPARED_03.json').read_text())
sdk.require(package['completed'] and package['installed_members_verified'] and package['sources_unchanged'],'Apple package incomplete')
archive=sdk.snapshot(package_path.parent/package['archive']['file'],maximum=256*1024**2)
sdk.require(archive.sha256==package['archive']['sha256'],'package archive changed')
failed=json.loads((stage/'FAILED_IPAD_21.json').read_text());sdk.require(failed['completed'] and failed['runtime_sealed'] and failed['owned_app_removed'],'failed startup not sealed')
phone=stage/'iphone-startup-19';startup=json.loads((phone/'startup-only-20/RESULT.json').read_text())
sdk.require(startup['completed'] and startup['cleanup'] and not startup['sdk_called'] and len(startup['attempts'])==1,'phone startup result differs')
apps={name:json.loads((stage/name/'APP.json').read_text()) for name in ['ipad-07','iphone-startup-19']}
for name,app in apps.items():
 sdk.require(sdk.snapshot(Path(app['app'])/'ContinuityIOSRunner',maximum=128*1024**2).sha256==app['executable_sha256'],'app binary changed')
 sdk.require(app['package_sha256']==archive.sha256 and app['native_slice_sha256']==package['native']['aarch64-apple-ios']['sha256'],'linked slice differs')
 for path,digest in app['source_files'].items():sdk.require(sdk.snapshot(Path(app['consumer'])/path).sha256==digest,'app source changed')
sdk.require({n:d for n,d in apps['ipad-07']['source_files'].items() if n!='project.json'}=={n:d for n,d in apps['iphone-startup-19']['source_files'].items() if n!='project.json'},'startup control source differs')
files={}
def add(path,name):
 sdk.require(name not in files and not path.is_symlink(),'duplicate/symlink input')
 files[name]=sdk.snapshot(path,maximum=32*1024**2).data
for path in stage.iterdir():
 if path.is_file() and path.suffix in {'.py','.md','.json'}:
  if path.name in {'PREPARED_03.json','LOCK_STATE_18.json'}:
   obj=json.loads(path.read_text());obj.pop('environment',None);obj.pop('deviceIdentifier',None)
   files['preparation/'+path.name]=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
  else:add(path,'preparation/'+path.name)
for name in ['candidate-list-03','candidate-package-03','resolution-03','device-prepare-13','lock-state-18']:
 for ext in ['.json','.status.json','.stdout','.stderr']:
  path=stage/(name+ext)
  if path.exists():add(path,'preparation/'+path.name)
add(package_path,'package/CONTINUITY_APPLE_PACKAGE.json')
for path in (stage/'package-04/apple-package').iterdir():
 if path.is_file() and path.suffix in {'.json','.stdout','.stderr'}:add(path,'package/commands/'+path.name)
for label,app in apps.items():
 run=stage/label
 for path in run.iterdir():
  if path.is_file() and path.suffix in {'.py','.json','.stdout','.stderr'}:
   if path.name=='PREPARED_01.json':
    obj=json.loads(path.read_text());obj.pop('environment',None)
    files[label+'/PREPARED_01.json']=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
   else:add(path,label+'/'+path.name)
 for directory in ['device-control-06','device-execution','startup-only-20']:
  for path in (run/directory).rglob('*'):
   if path.is_file():
    sdk.require(path.suffix in {'.json','.stdout','.stderr','.txt','.bin'},'unexpected device evidence')
    add(path,label+'/'+path.relative_to(run).as_posix())
 for name in app['source_files']:add(Path(app['consumer'])/name,label+'/consumer/'+name)
for path in ['artifact/continuity_apple_package.py','artifact/continuity_apple_consumer.py','artifact/codeql_memory_control.py','artifact/codeql_memory_queries.json']:
 add(root/path,'source/'+path)
for path in ['src/durable.rs','src/durable/rosters.rs','src/durable/rosters/decode_cache.rs','src/durable/rosters/decode_cache/tests.rs']:
 add(root/'research/continuity-identity-candidate'/path,'source/candidate/'+path)
signing=json.loads((root/'target/continuity-ios-device-preparation/SIGNING.json').read_text())
redactions={signing['identity']:'<EXISTING_SIGNING_IDENTITY>',signing['team']:'<EXISTING_SIGNING_TEAM>',signing['profile_uuid']:'<EXISTING_PROFILE_UUID>',failed.get('device_sha256',''):'<SELECTED_DEVICE_SHA256>'}
lock=json.loads((stage/'LOCK_STATE_18.json').read_text());redactions[lock['deviceIdentifier']]='<SELECTED_IPAD>'
for label in apps:
 for path in (stage/label).rglob('launch-raw.json'):
  obj=json.loads(path.read_text())
  for part in [obj.get('info',{}),obj.get('result',{})]:
   value=part.get('deviceIdentifier')
   if value:redactions[value]='<SELECTED_DEVICE>'
for name,data in list(files.items()):
 sdk.require(not name.endswith(('.redb','.mobileprovision','/tls-key','/witness-tls-key')),'private input selected')
 if not name.endswith(('.py','.swift','.rs','.c','.h')):sdk.require(not contains_private_pem(name,data),'private PEM selected')
 if name.endswith(('.json','.stdout','.stderr','.txt','.py','.md')):
  for value,replacement in redactions.items():
   if value:data=data.replace(value.encode(),replacement.encode())
 files[name]=data
out=root/'research/sdk-alpha1/evidence/20261015-apple-roster-cache-package';out.mkdir()
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
manifest={'source_commit':prepared['source_commit'],'apple_package_sha256':archive.sha256,'apple_package_bytes':archive.size,
 'ios_staticlib_sha256':package['native']['aarch64-apple-ios']['sha256'],
 'capture_sha256':sdk.snapshot(out/'CAPTURE.zip',maximum=64*1024**2).sha256,
 'members':{n:hashlib.sha256(d).hexdigest() for n,d in sorted(files.items())},
 'apple_targets':list(package['native']),'package_qualification_completed':True,
 'physical_sdk_recovery_passed':False,'ipad_startup_failed_before_admission':True,'ipad_owned_app_removed':True,
 'iphone_startup_only_passed':True,'iphone_sdk_called':False,'iphone_owned_app_removed':True,
 'current_source_hosted_codeql_passed':False,'release_claim_eligible':False}
sdk.write_json(out/'CAPTURE.json',manifest)
with zipfile.ZipFile(out/'CAPTURE.zip') as z:
 sdk.require(len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(files),'archive inventory differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'member digest differs')
 p=json.loads(z.read('package/CONTINUITY_APPLE_PACKAGE.json'));sdk.require(p['completed'] and p['archive']['sha256']==archive.sha256,'package readback differs')
 f=json.loads(z.read('ipad-07/RESULT_06.json'));sdk.require(not f['completed'] and f['cleanup'] and not f['live_producer'],'failed producer readback differs')
 r=json.loads(z.read('iphone-startup-19/startup-only-20/RESULT.json'));sdk.require(r['completed'] and r['cleanup'] and not r['sdk_called'],'startup control readback differs')
 arg=r['attempts'][0]['run'];console=z.read('iphone-startup-19/startup-only-20/1/launch.stdout')
 marker=('QPC_IOS_STARTUP_ONLY_PASS run='+arg).encode();sdk.require(console.splitlines().count(marker)==1 and b'The app terminated with the exit code 0.' in console,'startup console differs')
 sdk.require(z.read('iphone-startup-19/startup-only-20/1/receipt.txt')==marker+b'\n','startup container receipt differs')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'capture_sha256':manifest['capture_sha256'],'package_completed':True,'sdk_device_recovery_passed':False,'failed_ipad_preserved':True,'iphone_startup_receipt_verified':True})
print('Apple package checkpoint captured with failed iPad startup and successful pre-SDK iPhone control:',len(files),'members')
