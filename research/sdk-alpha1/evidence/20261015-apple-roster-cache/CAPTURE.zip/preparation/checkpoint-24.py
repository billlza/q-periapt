from pathlib import Path
import hashlib,json,subprocess,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
expected='9d396755c3f872d3a59932c6fe106b2b5e1b2e59'
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected,'unexpected source head')
evidence=root/'research/sdk-alpha1/evidence/20261015-apple-roster-cache-package'
manifest=json.loads((evidence/'CAPTURE.json').read_text());readback=json.loads((evidence/'READBACK.json').read_text())
sdk.require(readback['completed'] and readback['capture_sha256']==manifest['capture_sha256'] and sdk.snapshot(evidence/'CAPTURE.zip',maximum=64*1024**2).sha256==manifest['capture_sha256'],'capture identity differs')
allowed={'docs/SDK_0_2_RELEASE_READINESS.md'}|{p.relative_to(root).as_posix() for p in evidence.iterdir() if p.is_file()}
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True).splitlines()
sdk.require({row[3:] for row in status}==allowed,'unexpected source changes')
sdk.require(not subprocess.check_output(['git','diff','--cached','--name-only']),'existing staged changes')
sdk.command(['git','diff','--check'],stage/'diff-24',root)
sdk.command(['git','add','--',*sorted(allowed)],stage/'stage-24',root)
sdk.command(['git','diff','--cached','--check'],stage/'staged-check-24',root)
sdk.command(['git','commit','-m','Qualify current Apple package and preserve device startup evidence'],stage/'commit-24',root)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'main left dirty')
clone=root/'target/continuity-browser-publication/source'
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'validation clone changed')
sdk.command(['git','fetch',str(root),head],stage/'clone-fetch-24',clone)
sdk.command(['git','merge','--ff-only',head],stage/'clone-ff-24',clone)
sdk.command([sys.executable,'-B',str(clone/'artifact/python_bootstrap.py'),str(clone/'artifact/source_results_assembler.py'),
 'ci-source-gate','9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],stage/'source-gate-24',clone)
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'source gate changed clone')
sdk.write_json(stage/'CHECKPOINT_24.json',{'completed':True,'source_commit':expected,'checkpoint_commit':head,'source_clean':True,
 'final_source_gate':True,'package_qualified':True,'physical_sdk_recovery_passed':False,'iphone_pre_sdk_startup_passed':True,
 'owned_apps_removed':True,'capture_sha256':manifest['capture_sha256'],'capture_members':len(manifest['members']),
 'codeql_thread_control_passed':False,'hosted_ci_current_head_passed':False,'remote_push_performed':False,'release_claim_eligible':False})
print(json.dumps({'checkpoint_commit':head,'source_gate':True,'package_qualified':True,'physical_sdk_recovery_passed':False,'pushed':False}))
