from collections import Counter
from pathlib import Path
import hashlib
import json
import plistlib
import subprocess
import sys
import rust_sdk_profile as sdk
import continuity_android_contract as contract
import continuity_android_pending as pending
import continuity_android_continuation as continued

root = Path.cwd()
stage = Path(__file__).resolve().parent
sys.path.insert(0, str(stage))
from device_support import APP, BUNDLE, selected, command, installed
import census_review

prepared = json.loads((stage / 'PREPARED_01.json').read_text())
binary = Path(APP['app']) / 'ContinuityIOSRunner'
ROUTES = ('signed-fixed-unapplied', 'tls-recoverable-applied')


def frozen_inputs():
    sdk.require(APP['completed'], 'app build incomplete')
    sdk.require(sdk.snapshot(binary, maximum=128*1024**2).sha256 == APP['executable_sha256'], 'app identity changed')
    for name, digest in APP['driver_files'].items():
        sdk.require(sdk.snapshot(stage / name).sha256 == digest, 'driver changed: ' + name)
    for name, digest in APP['source_files'].items():
        sdk.require(sdk.snapshot(Path(APP['consumer']) / name).sha256 == digest, 'app source changed: ' + name)
    for record in prepared['host_files'].values():
        sdk.require(sdk.snapshot(Path(record['path']), maximum=256*1024**2).sha256 == record['sha256'], 'host runtime changed')
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == prepared['source_commit'], 'qualification head changed')
    sdk.require(not subprocess.check_output(['git', 'diff', prepared['source_commit'], '--',
        'research/continuity-identity-candidate', 'bindings', 'artifact']), 'qualification sources changed')
    expected = {
        'research/continuity-identity-candidate/src/durable.rs',
        'research/continuity-identity-candidate/src/durable/rosters.rs',
        'research/continuity-identity-candidate/src/durable/rosters/decode_cache.rs',
        'research/continuity-identity-candidate/src/durable/rosters/decode_cache/tests.rs',
        'research/continuity-identity-candidate/src/durable/rosters/policy_continuation_tests.rs',
    }
    changed = subprocess.check_output(['git', 'diff', '--name-only',
        '610234b0b684e4e39bad97a953f5c66e74df2e91', prepared['source_commit'], '--',
        'research/continuity-identity-candidate/src', 'research/continuity-identity-candidate/Cargo.toml',
        'research/continuity-identity-candidate/Cargo.lock', 'bindings/c/ContinuityPackageConsumer/src',
        'bindings/c/ContinuityPackageConsumer/Cargo.toml'], text=True).splitlines()
    sdk.require(set(changed) == expected, 'unexplained host/device engine difference')



def readback_cuts(device):
    domain = ['--domain-type', 'appDataContainer', '--domain-identifier', BUNDLE]
    for record in sorted((stage / 'device-execution').glob('*/RESULT.json')):
        row = json.loads(record.read_text())
        folder = record.parent
        if not row['container_readback_deferred'] or (folder / 'CONTAINER_READBACK.json').exists():
            continue
        sdk.require(row['app_exit'] == 77 and row['completed'], 'deferred result is not an actual cut')
        for source, destination, prefix in [
            ('receipt-' + row['run'] + '.txt', 'receipt.txt', 'receipt-copy'),
            ('result-' + row['run'] + '.bin', 'container-public-result.bin', 'result-copy'),
        ]:
            sdk.require(not (folder / destination).exists(), 'readback would overwrite evidence')
            command(device, ['device', 'copy', 'from', '--source', 'Documents/' + source,
                '--destination', str(folder / destination), *domain], folder / prefix)
        sdk.require((folder / 'receipt.txt').read_bytes() == (folder / 'expected-receipt.txt').read_bytes(), 'cut receipt differs')
        sdk.require((folder / 'container-public-result.bin').read_bytes() == (folder / 'public-result.bin').read_bytes(), 'cut container/console record differs')
        sdk.write_json(folder / 'CONTAINER_READBACK.json', {'completed': True, 'run': row['run'],
            'public_result_sha256': sdk.snapshot(folder / 'container-public-result.bin').sha256})


def verify_processes(results):
    launch_arguments = []
    pids = set()
    cuts = 0
    for folder in (stage / 'device-execution').iterdir():
        sdk.require(folder.is_dir() and not folder.is_symlink(), 'unexpected execution entry')
        row = json.loads((folder / 'RESULT.json').read_text())
        usb = json.loads((folder / 'USB_TRANSPORT.json').read_text())
        sdk.require(row['completed'] and row['run'] == folder.name, 'operation not complete')
        sdk.require(usb['completed'] and usb['startup_admitted'], 'missing transport completion or startup admission')
        cut = row['mode'] in {'pending-confirm-process-cut', 'pending-confirm-result-cut'}
        expected_exit = 77 if cut else 0
        sdk.require(row['app_exit'] == expected_exit and row['container_readback_deferred'] == cut, 'unexpected cut classification')
        marker = f"QPC_IOS_REPLACEMENT_{'CUT' if cut else 'PASS'} mode={row['mode']} profile={row['profile']} run={row['run']}\n".encode()
        lines = (folder / 'launch.stdout').read_bytes().splitlines()
        sdk.require(lines.count(marker.strip()) == 1 and lines.count(f'The app terminated with the exit code {expected_exit}.'.encode()) == 1, 'missing exact termination')
        sdk.require((folder / 'launch.stderr').read_bytes() == b'' and (folder / 'receipt.txt').read_bytes() == marker, 'physical diagnostic or receipt mismatch')
        sdk.require(sdk.snapshot(folder / 'public-result.bin').sha256 == row['public_result_sha256'], 'public result changed')
        if cut:
            readback = json.loads((folder / 'CONTAINER_READBACK.json').read_text())
            sdk.require(readback['completed'] and readback['run'] == row['run'] and readback['public_result_sha256'] == row['public_result_sha256'], 'cut container readback missing')
            cuts += 1
        process = json.loads((folder / 'PROCESS_RESULT.json').read_text())
        sdk.require(process['terminationResult'] == {'exitCode': expected_exit, 'wasCoreDumpCreated': False}, 'structured termination differs')
        args = process['launchOptions']['arguments']
        launch_arguments.append(args)
        sdk.require(len(args) == 6 and args[:4] == [row['mode'], row['profile'], row['case'], row['run']]
                    and args[4] in {'signed', 'tls'} and args[5] == 'managed', 'structured invocation differs')
        sdk.require(process['launchOptions']['terminateExistingInstances'] is True, 'fresh-process flag absent')
        pid = process['process']['processIdentifier']
        sdk.require(isinstance(pid, int) and pid > 0 and pid not in pids, 'physical process identity repeated')
        pids.add(pid)
        before = json.loads((folder / 'PRELAUNCH_PROCESSES.json').read_text())
        sdk.require(pid not in {item['processIdentifier'] for item in before}, 'existing process reused')
    census_review.verify(launch_arguments, cases)
    sdk.require(len(pids) == sum(record['foreign_processes'] for record in results.values()) == 121 and cuts == 4, 'physical continuation process/cut census differs')
    return {'physical_swift_processes': len(pids), 'actual_process_cuts': cuts, 'startup_admissions': len(pids)}


frozen_inputs()
device = selected()
profile = plistlib.loads(subprocess.check_output(['/usr/bin/security', 'cms', '-D', '-i',
    str(Path(APP['app']) / 'embedded.mobileprovision')], stderr=subprocess.PIPE, timeout=20))
sdk.require(device['hardwareProperties']['udid'] in profile['ProvisionedDevices'], 'offered device is not provisioned')
control = stage / 'device-control-06'
control.mkdir(mode=0o700)
sdk.require(not installed(device, control / 'before'), 'fresh bundle already installed')
cases = stage / 'device-cases-04'
cases.mkdir(mode=0o700)
public = stage / 'public-06'
public.mkdir(mode=0o700)
state = {'completed': False, 'live_producer': True, 'cleanup': False, 'owned_install_attempted': False,
    'device_model': device['hardwareProperties']['marketingName'], 'device_os': device['deviceProperties']['osVersionNumber'],
    'device_sha256': hashlib.sha256(device['identifier'].encode()).hexdigest(), 'source_commit': prepared['source_commit'],
    'sdk_source_commit': prepared['sdk_source_commit'], 'package_sha256': APP['package_sha256'],
    'app_sha256': APP['executable_sha256'], 'completed_routes': []}


def progress():
    (stage / 'DEVICE_STATE_06.json').write_text(json.dumps(state, indent=2) + '\n')


progress()
results = {}
try:
    state['owned_install_attempted'] = True
    progress()
    command(device, ['device', 'install', 'app', APP['app']], control / 'install', timeout=60)
    sdk.require(installed(device, control / 'installed'), 'owned installation not observed')
    env = dict(prepared['environment'], QPC_ANDROID_DRIVER=str(stage / 'ios_client.py'), QPC_ANDROID_CASES=str(cases),
               QPC_CONFIGURATION_RECEIVER=prepared['host_files']['receiver']['path'],
               QPC_CONFIGURATION_TARGET_CLIENT=prepared['host_files']['target_client']['path'])
    harness = prepared['host_files']['harness']['path']
    contract.verify_catalog(sdk.command([harness, '--list'], stage / 'catalog-06', root, environment=env))
    for label in ROUTES:
        stdout = sdk.command([harness, '--exact', continued.TESTS[label], '--nocapture'], stage / ('device-06-' + label), root, environment=env)
        readback_cuts(device)
        result = continued.verify_execution(stdout, cases, label)
        result_label = label + '-continuation'
        for name in continued.public(label):
            sdk.copy(cases / result_label / name, public / result_label / name)
        sdk.require(continued.verify_execution(stdout, public, label) == result, 'continued public copy differs')
        results.update(result)
        state['completed_routes'].append(result_label)
        progress()
        print('Physical Swift recovered continuation passed: ' + result_label, flush=True)
    census = verify_processes(results)
    frozen_inputs()
    state.update(completed=True, cases=results, **census)
except BaseException as error:
    state['failure'] = repr(error)
    raise
finally:
    state['live_producer'] = False
    try:
        if state['owned_install_attempted']:
            if installed(device, control / 'cleanup-before'):
                command(device, ['device', 'uninstall', 'app', BUNDLE], control / 'uninstall', timeout=60)
            state['cleanup'] = not installed(device, control / 'cleanup-after')
            sdk.require(state['cleanup'], 'owned app cleanup unresolved')
    except BaseException as error:
        state['cleanup_failure'] = repr(error)
        raise
    finally:
        progress()
        sdk.write_json(stage / 'RESULT_06.json', state)
print('Physical Swift recovered renewal/rekey/fresh traffic passed: 121 processes, 4 cuts; owned app removed')
