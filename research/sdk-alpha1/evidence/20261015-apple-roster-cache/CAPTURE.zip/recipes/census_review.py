"""Exact public launch census for composed pending recovery and continuation."""
from collections import Counter
from pathlib import Path
import hashlib
import continuity_android_pending as pending
import continuity_android_continuation as continued
import rust_sdk_profile as sdk

ROUTES = ('signed-fixed-unapplied', 'tls-recoverable-applied')


def expected(cases: Path) -> Counter:
    result = Counter()
    for label in ROUTES:
        carrier, profile, outcome = label.split('-')
        case = hashlib.sha256(str(cases / (label + '-continuation') / 'installation').encode()).hexdigest()[:32]
        recovery = pending.cases(outcome == 'applied', process_loss=True)
        sdk.require(tuple(mode for _, mode in recovery[:3]) ==
                    ('managed-witness-create', 'authority-create', 'managed-witness-prepare'), 'setup phase changed')
        for index, (_, mode) in enumerate(recovery):
            result[(case, profile, 'signed' if index < 3 else carrier, mode)] += 1
        for _, mode in continued.cases(carrier):
            result[(case, profile, carrier, mode)] += 1
    return result


def verify(arguments: list[list[str]], cases: Path) -> dict:
    observed = Counter()
    runs = set()
    for args in arguments:
        sdk.require(len(args) == 6 and args[5] == 'managed', 'launch framing')
        mode, profile, case, run, carrier, _ = args
        sdk.require(run not in runs, 'duplicate launch identity')
        runs.add(run)
        observed[(case, profile, carrier, mode)] += 1
    sdk.require(observed == expected(cases), 'exact continuation phase/carrier/mode census differs')
    sdk.require(len(arguments) == 121, 'continuation process count')
    return {'physical_processes': 121, 'routes': 2, 'setup_invocations': 6,
            'tls_after_registration_invocations': 57, 'policy_renewal_and_traffic_invocations': 74}
