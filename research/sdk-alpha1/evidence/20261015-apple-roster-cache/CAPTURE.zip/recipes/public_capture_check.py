"""PEM framing checks for selected public data, including decoded JSON values."""
import json
import re

HEADER = re.compile(rb'^-----BEGIN (?:EC |RSA |ENCRYPTED |OPENSSH )?PRIVATE KEY-----\r?$', re.MULTILINE)


def contains_private_pem(name, payload):
    if HEADER.search(payload):
        return True
    if not name.endswith('.json'):
        return False
    def walk(value):
        if isinstance(value, str):
            return bool(HEADER.search(value.encode()))
        if isinstance(value, list):
            return any(walk(child) for child in value)
        if isinstance(value, dict):
            return any(walk(key) or walk(child) for key, child in value.items())
        return False
    return walk(json.loads(payload))
