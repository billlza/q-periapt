from pathlib import Path
import hashlib,json,subprocess,tempfile,os
OUT=Path(__file__).resolve().parent
APP=json.loads((OUT/'APP.json').read_text())
BUNDLE=APP['bundle']
def selected():
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp)/'devices.json';subprocess.run(['xcrun','devicectl','list','devices','--json-output',str(p)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=30)
  rows=[x for x in json.loads(p.read_text())['result']['devices'] if x.get('connectionProperties',{}).get('transportType')=='wired' and x.get('hardwareProperties',{}).get('deviceType')=='iPad']
  if len(rows)!=1:raise RuntimeError('exactly one explicitly offered wired iPad is required')
  return rows[0]
def command(device,args,label,*,timeout=45,allow_failure=False):
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp)/'result.json'
  r=subprocess.run(['xcrun','devicectl',*args[:3],'--device',device['identifier'],'--timeout',str(timeout),'--json-output',str(p),*args[3:]],capture_output=True,timeout=timeout+10)
  raw=json.loads(p.read_text()) if p.exists() else None
  label.parent.mkdir(parents=True,exist_ok=True)
  for ext,data in [('stdout',r.stdout),('stderr',r.stderr)]:
   for value in (device['identifier'],device['hardwareProperties'].get('udid','')):
    if value:data=data.replace(value.encode(),b'<selected-device>')
   label.with_suffix('.'+ext).write_bytes(data)
  label.with_suffix('.status.json').write_text(json.dumps({'returncode':r.returncode,'command':args[:3]},indent=2)+'\n')
  if not allow_failure and r.returncode:raise RuntimeError(f'{label.name} failed with {r.returncode}; see retained logs')
  return r,raw
def installed(device,label):
 _,raw=command(device,['device','info','apps','--bundle-id',BUNDLE],label)
 apps=raw['result']['apps']
 if len(apps)>1:raise RuntimeError('ambiguous app inventory')
 return len(apps)==1
