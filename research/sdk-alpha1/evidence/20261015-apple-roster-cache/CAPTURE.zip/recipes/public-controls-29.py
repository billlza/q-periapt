"""Reject tampered copies of current public receipts; never reopen device state."""
from pathlib import Path
import json
import shutil
import tempfile
import continuity_android_continuation as continued
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
state = json.loads((stage / 'RESULT_06.json').read_text())
sdk.require(state['completed'] and state['cleanup'] and not state['live_producer'], 'producer not terminal')
checks = []
for label in continued.TESTS:
    full = label + '-continuation'
    stdout = (stage / ('device-06-' + label + '.stdout')).read_bytes()
    expected = state['cases'][full]
    sdk.require(continued.verify_execution(stdout, stage / 'public-06', label)[full] == expected, 'baseline differs')
    for name, replacement in [
        ('continued-policy-fresh-effect', b'substituted application effect'),
        ('continued-policy-effect-after', b'duplicate or changed original effect'),
        ('continued-policy-effect-count', (1).to_bytes(4, 'big')),
        ('continued-policy-rekeyed', b'\0'),
        ('continued-final.identity', b'unrelated device'),
        ('continued-expired-activation', bytes(4)),
        ('traffic-continued-policy-fresh-message.stdout', b'listening:44333\nserved:2:0:1:0\n'),
        ('traffic-continued-policy-rekey.stderr', b'failed'),
    ]:
        with tempfile.TemporaryDirectory(prefix='qpc-public-control-') as temporary:
            directory = Path(temporary)
            shutil.copytree(stage / 'public-06' / full, directory / full)
            (directory / full / name).write_bytes(replacement)
            try:
                continued.verify_execution(stdout, directory, label)
            except ValueError:
                checks.append({'route': label, 'field': name, 'rejected': True})
            else:
                raise ValueError('tampered public record accepted: ' + label + '/' + name)
sdk.write_json(stage / 'PUBLIC_CONTROLS_29.json', {
    'completed': True, 'baseline_routes': 2, 'rejected_substitutions': len(checks), 'checks': checks,
    'scope': 'Copies of current public receipts only. These rejection controls do not execute cryptography or inspect private state.'})
print('Two current public baselines accepted; all 16 substituted records rejected')
