"""Bounded qualification-only forwarding; TLS and protocol bytes remain opaque.

The local usbmuxd v1 plist framing is documented by libimobiledevice/libusbmuxd.
This code does not read pairing records or alter device trust/settings.
"""
import socket,struct,plistlib,subprocess,threading,queue,time,select,tempfile,json,re,errno
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from device_support import command

def _read(sock,n):
 data=b''
 while len(data)<n:
  block=sock.recv(n-len(data))
  if not block:raise RuntimeError('USB multiplexer truncated response')
  data+=block
 return data

def _request(sock,message):
 wire=plistlib.dumps(dict(message,ProgName='qperiapt',ClientVersionString='Continuity qualification',kLibUSBMuxVersion=3))
 sock.sendall(struct.pack('<IIII',len(wire)+16,1,8,1)+wire)
 length,version,kind,tag=struct.unpack('<IIII',_read(sock,16))
 if not 16<=length<=1024*1024 or (version,kind,tag)!=(1,8,1):raise RuntimeError('USB multiplexer response framing')
 return plistlib.loads(_read(sock,length-16))

def _mux():
 sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(5)
 try:sock.connect('/var/run/usbmuxd');return sock
 except BaseException:sock.close();raise

def _device_socket(device,port):
 with _mux() as sock:rows=_request(sock,{'MessageType':'ListDevices'})['DeviceList']
 identity=device['hardwareProperties']['udid'].replace('-','').lower()
 rows=[r for r in rows if r['Properties'].get('ConnectionType')=='USB' and r['Properties'].get('SerialNumber','').replace('-','').lower()==identity]
 if len(rows)!=1:raise RuntimeError('offered iPhone not uniquely available over USB')
 sock=_mux()
 try:
  reply=_request(sock,{'MessageType':'Connect','DeviceID':rows[0]['DeviceID'],'PortNumber':socket.htons(port)})
  if reply.get('MessageType')!='Result' or reply.get('Number')!=0:raise RuntimeError('USB port connection refused')
  return sock
 except BaseException:sock.close();raise

from relay_forward import forward as _forward

def launch(device,bundle,mode,profile,case,run,capture,addresses,carrier,managed):
 endpoints={}
 for route,address in addresses.items():
  host,port=address.rsplit(':',1)
  if route not in {'peer','witness','control'} or host!='127.0.0.1' or not port.isdecimal() or not 1<=int(port)<=65535:raise RuntimeError('USB endpoint must be the owned loopback server')
  endpoints[route]=(host,int(port))
 _,before=command(device,['device','info','processes','--search','ContinuityIOSRunner'],capture/'prelaunch')
 prior=before['result']['runningProcesses']
 prior_pids={row['processIdentifier'] for row in prior}
 (capture/'PRELAUNCH_PROCESSES.json').write_text(json.dumps(prior,indent=2)+'\n')
 args=['xcrun','devicectl','device','process','launch','--device',device['identifier'],'--timeout','90','--json-output',str(capture/'launch-raw.json'),'--console','--terminate-existing',bundle,mode,profile,case,run,carrier,'managed' if managed else 'unmanaged']
 messages=queue.Queue();observed=[];reader_errors=[];exchanges=[];resets=[]
 def sanitize(data):
  for value in (device['identifier'],device['hardwareProperties']['udid']):data=data.replace(value.encode(),b'<selected-device>')
  return data
 def exchange(route,port,index):
  with _device_socket(device,port) as usb:
   try:peer=socket.create_connection(endpoints[route],timeout=5)
   except ConnectionRefusedError as error:
    # Closing this USB stream passes the observed remote failure back to the SDK.
    # Only the explicit receiver-exit scenario admits this result; the native
    # fixture still requires server exit 77, committed state and exact recovery.
    if mode not in {'roster-witness-peer-uncertain','root-peer-uncertain'} or route!='peer':raise
    return {'route':route,'index':index,'completed':False,'remote_failure':'connection_refused','errno':error.errno,'bytes_by_direction':[0,0]}
   allow_cut=mode=='pending-confirm-process-cut' and route in {'witness','control'}
   with peer:counts,cut=_forward(usb,peer,allow_cut)
  return {'route':route,'index':index,'completed':cut is None,'expected_device_disconnect':cut,'bytes_by_direction':counts}
 with tempfile.TemporaryDirectory() as tmp,open(Path(tmp)/'stderr','w+b') as err:
  process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=err)
  def read_console():
   try:
    size=0
    with (capture/'launch.stdout').open('xb') as log:
     for line in process.stdout:
      size+=len(line)
      if size>1024*1024:raise RuntimeError('device console exceeded bound')
      line=sanitize(line);observed.append(line);log.write(line);log.flush()
      match=re.fullmatch(rb'QPC_IOS_RELAY_NEXT run='+run.encode()+rb' route=(peer|witness|control) port=([0-9]+) index=([0-9]+)\r?\n',line)
      if match:messages.put((match[1].decode(),int(match[2]),int(match[3])))
      reset=re.fullmatch(rb'QPC_IOS_RELAY_RESET run='+run.encode()+rb' route=(peer|witness|control) index=([0-9]+) side=(upstream|local) errno=54\r?\n',line)
      if line.startswith(b'QPC_IOS_RELAY_RESET ') and not reset:raise RuntimeError('malformed relay reset observation')
      if reset:resets.append({'route':reset[1].decode(),'index':int(reset[2]),'side':reset[3].decode(),'errno':54})
      if re.fullmatch(rb'QPC_IOS_READY run='+run.encode()+rb'\r?\n',line):messages.put(('ready',0,0))
    messages.put(None)
   except BaseException as error:reader_errors.append(error);messages.put(None)
  reader=threading.Thread(target=read_console);reader.start();outcome={'completed':False};pending={};counts={};admitted=False;deadline=time.monotonic()+80
  try:
   with ThreadPoolExecutor(max_workers=3) as executor:
    while True:
     if time.monotonic()>=deadline:raise TimeoutError('USB operation deadline')
     try:message=messages.get(timeout=1)
     except queue.Empty:
      if process.poll() is not None and not reader.is_alive():break
      continue
     if message is None:break
     route,port,index=message
     if route=='ready':
      if admitted:raise RuntimeError('duplicate app startup admission')
      with tempfile.TemporaryDirectory(prefix='qperiapt-app-admission-') as temporary:
       ack=Path(temporary)/'admission';ack.write_bytes(run.encode()+b'\n')
       command(device,['device','copy','to','--source',str(ack),'--destination','Documents/admission-'+run+'.txt','--domain-type','appDataContainer','--domain-identifier',bundle],capture/'admission',timeout=15)
      admitted=True;continue
     if route not in endpoints or not 1<=port<=65535 or index!=counts.get(route,0)+1 or index>64:raise RuntimeError('USB stream route or sequence')
     if route in pending:exchanges.append(pending.pop(route).result(timeout=5))
     counts[route]=index;pending[route]=executor.submit(exchange,route,port,index)
    code=process.wait(timeout=10);reader.join(timeout=5)
    for future in pending.values():exchanges.append(future.result(timeout=10))
   if reader.is_alive() or reader_errors:raise RuntimeError('device console collection failed')
   from ios_client import CUT
   if (capture/'launch-raw.json').exists():
    raw=json.loads((capture/'launch-raw.json').read_text());(capture/'PROCESS_RESULT.json').write_text(json.dumps(raw.get('result',{}),indent=2)+'\n')
   if code!=(77 if mode in CUT else 0):raise RuntimeError('device launch command failed')
   terminal=raw['result'];pid=terminal['process']['processIdentifier']
   if terminal['launchOptions']['terminateExistingInstances'] is not True or pid in prior_pids:raise RuntimeError('launch did not establish a fresh process')
   if terminal['terminationResult']!={'exitCode':(77 if mode in CUT else 0),'wasCoreDumpCreated':False}:raise RuntimeError('structured termination differs')
   _,after=command(device,['device','info','processes','--filter',f'processIdentifier = {pid}'],capture/'postlaunch')
   if after['result']['runningProcesses']:raise RuntimeError('reported terminated app process remains visible')
   if not admitted:raise RuntimeError('SDK operation lacked host startup admission')
   reset_keys=[(row['route'],row['index']) for row in resets]
   if len(set(reset_keys))!=len(reset_keys) or any(route not in counts or not 1<=index<=counts[route] for route,index in reset_keys):raise RuntimeError('unbound relay reset record')
   outcome['completed']=True
  finally:
   if process.poll() is None:
    process.terminate();process.wait(timeout=10)
   reader.join(timeout=5);err.flush();err.seek(0);stderr=sanitize(err.read());(capture/'launch.stderr').write_bytes(stderr)
   outcome['startup_admitted']=admitted
   outcome['connection_resets']=resets
   outcome['exchanges']=sorted(exchanges,key=lambda x:(x['route'],x['index']))
   (capture/'USB_TRANSPORT.json').write_text(json.dumps(outcome,indent=2)+'\n')
   (capture/'launch.status.json').write_text(json.dumps({'returncode':process.returncode,'transport':'USB','bounded_seconds':90},indent=2)+'\n')
  return subprocess.CompletedProcess(args,code,b''.join(observed),stderr)
