"""Opaque test transport; cut acceptance also requires exact app exit and native proof."""
import errno
import select
import socket
import time

def forward(left,right,allow_device_cut=False):
 live={left:right,right:left};counts=[0,0];deadline=time.monotonic()+35
 while live:
  if time.monotonic()>=deadline:raise TimeoutError('USB relay deadline')
  ready,_,_=select.select(list(live),[],[],1)
  for src in ready:
   try:data=src.recv(16384)
   except OSError as error:
    if allow_device_cut and src is left and error.errno==errno.ECONNRESET:return counts,'device-reset'
    raise
   dest=live[src]
   if not data:
    try:dest.shutdown(socket.SHUT_WR)
    except OSError as error:
     if error.errno!=errno.ENOTCONN:raise
    if allow_device_cut and src is left:return counts,'device-eof'
    del live[src]
   else:
    try:dest.sendall(data)
    except OSError as error:
     if allow_device_cut and dest is left and error.errno in {errno.EPIPE,errno.ECONNRESET,errno.ENOTCONN}:return counts,'device-write-closed'
     raise
    counts[0 if src is left else 1]+=len(data)
 return counts,None
