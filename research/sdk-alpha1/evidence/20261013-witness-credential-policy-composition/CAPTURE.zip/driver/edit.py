from pathlib import Path
base=Path('research/continuity-identity-candidate/src')
p=base/'enrollment/policy_renewal/witness.rs';s=p.read_text()
# A completed plain G is retained as evidence; pending G and joint T stay excluded.
s=s.replace('if image.renewal.is_some()\n', 'if image.renewal.as_ref().is_some_and(|r| !r.witnessed() || !r.permits_policy_pending() || r.joint() || r.completed.is_none())\n')
needle='        let original = self.original_device_metadata(image)?;\n';assert s.count(needle)==1
s=s.replace(needle,needle+'        let current = self.policy_witness_current_device(image)?;\n')
s=s.replace('approval.check_credential_lineage(&original, &original)?;', 'approval.check_credential_lineage(&original, &current)?;').replace('approval.check_devices(&original, &original)?;', 'approval.check_devices(&original, &current)?;')
needle='    pub(in crate::enrollment) fn policy_witness_scope('
helper='''    pub(in crate::enrollment) fn policy_witness_current_device(
        &self,
        image: &Image,
    ) -> Result<VerifiedDevice, DurableError> {
        let Phase::Accepted { admission, .. } = &image.phase else {
            return Err(DurableError::Corrupt);
        };
        self.historical_device_metadata(&admission.certificate, &admission.roster, admission.checkpoint)
    }
''';assert s.count(needle)==1;s=s.replace(needle,helper+needle)
start=s.index('        let lease = self.witness_lease(&original, original_policy, id).await?;',s.index('    async fn witnessed_policy_renewal_request_attempt'))
end=s.index('\n    fn retain_policy_proposal(',start)
s=s[:start]+'''        let prepared = self.prepare_renewal_request_with_anchor(original_policy, Some(client)).await?;
        prepared.policy_request(operation, original_policy).await
    }
'''+s[end:]
s=s.replace('let (original, id) = self.policy_witness_scope(&image, original_policy)?;\n        if image.policy_pending.is_some()', 'self.policy_witness_scope(&image, original_policy)?;\n        if image.policy_pending.is_some()')
needle='        let pending = image\n            .policy_pending\n            .as_ref()\n            .ok_or(DurableError::Conflict)?;\n        let retained = self.authenticated_policy_record(pending)?;';assert s.count(needle)==1
s=s.replace(needle,'        let current = self.policy_witness_current_device(&image)?;\n'+needle).replace('current_device: &original,','current_device: &current,')
s=s.replace('                    admit(&original, target, now)?;', '                    let current = self.policy_witness_current_device(&image)?;\n                    admit(&current, target, now)?;')
p.write_text(s)
p=base/'enrollment/policy_renewal/witness/operational.rs';s=p.read_text();s=s.replace('        approval.check_credential_lineage(&original, &original)?;', '        let current = self.policy_witness_current_device(image)?;\n        approval.check_credential_lineage(&original, &current)?;')
needle='        let mut service = self\n            .reconcile_installation(&original, original_policy, Some(client))';assert s.count(needle)==1;s=s.replace(needle,'        let retained = self.policy_witness_current_device(&image)?;\n'+needle)
s=s.replace('                &original,\n                policy,','                &retained,\n                policy,');p.write_text(s)
p=base/'enrollment/renewal/request.rs';s=p.read_text().replace('    async fn prepare_renewal_request_with_anchor(', '    pub(in crate::enrollment) async fn prepare_renewal_request_with_anchor(')
needle='                self.joint.as_ref(),\n            )';assert s.count(needle)==1
s=s.replace(needle,'                self.joint.as_ref(),\n                self.image.renewal.as_ref().filter(|r| r.witnessed()).and_then(|r| r.completed.as_ref()),\n            )');p.write_text(s)
p=base/'durable/rosters/policy_renewal.rs';s=p.read_text();needle='''        joint: Option<&crate::HistoricalPolicyContinuation>,
    ) -> Result<crate::PolicyRenewalScope, DurableError> {''';assert s.count(needle)==1;s=s.replace(needle,'''        joint: Option<&crate::HistoricalPolicyContinuation>,
        witnessed_completion: Option<&LocalRenewalCommit>,
    ) -> Result<crate::PolicyRenewalScope, DurableError> {''');s=s.replace('                RequestRoster::Configured,\n                None,','                RequestRoster::Configured,\n                witnessed_completion,');p.write_text(s)
p=base/'durable/rosters/policy_renewal_tests.rs';s=p.read_text();import re
s=re.sub(r'policy_renewal_request_scope\(([^\n]+), None\)',r'policy_renewal_request_scope(\1, None, None)',s);p.write_text(s)
