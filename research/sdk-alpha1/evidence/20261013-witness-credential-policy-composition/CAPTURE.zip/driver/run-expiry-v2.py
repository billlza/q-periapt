from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-witness-credential-policy-composition';package=root/'target/continuity-browser-publication/source/target/credential-policy-package-02'
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js']:shutil.copyfile(stage/('worker-expiry.js' if name=='worker.js' else name),web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
authority=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-policy-request-authority';roster=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-policy-request-issuer'
witness_authority=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
state={'completed':False,'scope':'installed browser public policy renewal requests and independently held native issuer pins; same Rust engine and loopback, not policy adoption or independent protocol implementation','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,roster,witness_authority]},'cases':[],'observations':[]}
allowed={'local','required','expired-required','no-local-fallback','wrong-witness','read-loss','cancel'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0

def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args['action'],'observations':value['result'].get('observations',[])});return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value

def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

def unchanged(original,current):sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'roster changed original identity/key')
try:
 with serving(web,out,private,witness_authority) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    profile='local' if case=='local' else 'required'
    native(authority,['prepare-expiring-policy' if case=='expired-required' else 'prepare',directory],case+'-authority')
    cfg=json.loads((directory/'PUBLIC.json').read_text())
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':profile}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'})
    if profile=='required':
     sdk.require(prepared['phase']=='requires-witness-enrollment','missing required witness');native(witness_authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    else:sdk.require(prepared['phase']=='prepared-local','wrong local preparation')
    original=success({**args,'action':'activate'});row['original']=original
    args['operationId']=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']
    before=len(records.get(key,[]))
    if case in ['no-local-fallback','wrong-witness']:
     row['rejection']=rejected({**args,'action':'policy-request','historicalOnly':True,**({'forceLocal':True} if case=='no-local-fallback' else {'wrongWitness':True})},'AnchorRequired' if case=='no-local-fallback' else 'Conflict')
     sdk.require(len(records.get(key,[]))==before,'invalid request dispatched')
    elif case in ['read-loss','cancel']:
     mode='drop-read' if case=='read-loss' else 'hold-read'
     row['rejection']=rejected({**args,'action':'policy-request','historicalOnly':True,'mode':mode,'cancelOnAdvance':case=='cancel'},'WitnessTransport' if case=='read-loss' else 'Cancelled')
     fault=records[key][before:];sdk.require(len(fault)==1 and fault[0]['trigger'] and not fault[0]['changed'],'fault must affect first unchanged witness read')
     if case=='cancel':sdk.require(row['rejection']['cancellationRequested'],'no actual pending cancellation')
    elif case=='expired-required':
     row['real_expiry']={'valid_until':cfg['policy_until'],'activated_at':int(time.time())}
     sdk.require(time.time()<cfg['policy_until'],'expired before baseline activation')
     print(json.dumps({'case':case,'waiting_until':cfg['policy_until']+1}),flush=True)
     while time.time()<=cfg['policy_until']:time.sleep(min(10,max(0.1,cfg['policy_until']+1-time.time())))
     row['expired_activation']=invoke({**args,'action':'activate'});sdk.require(row['expired_activation'].get('code')=='Validity' and 'ownerClosed' not in row['expired_activation'] and row['expired_activation']['observations']==[],'expired current policy must fail before opening a device owner')
     row['real_expiry']['request_at']=int(time.time())
    request=success({**args,'action':'policy-request','historicalOnly':True});row['request']=request
    sdk.require(not request['runtimeCreated'] and request['requestValue']['journal']==original['journal'] and request['status']==original['status'],'request created runtime or changed original state')
    sdk.require(success({**args,'action':'policy-request','historicalOnly':True})==request,'exact request retry changed materials')
    request_file=out/(case+'-request.json');sdk.write_json(request_file,request['requestValue'])
    renewal=out/(case+'-approval.json');issued=parse_strict_json_bytes(native(roster,[directory,grant,request_file,renewal,profile],case+'-renewal-authority'),label='issuer result');row['issuer']=issued
    sdk.require(issued['issued_and_verified'] and issued['unchanged_credential_and_roster'] and issued['operation']==args['operationId'] and issued['previous_policy_expired']==(case=='expired-required'),'issuer scope/expiry mismatch')
    if case!='expired-required':unchanged(original,success({**args,'action':'activate'}))
    row['witness_records']=records.get(key,[]);sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
