from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-witness-credential-policy-composition';clone=root/'target/continuity-browser-publication/source';old=root/'target/continuity-browser-policy-requests'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay-paths',root).decode().splitlines();overlay={}
for n in paths:
 p=root/n;overlay[n]=sdk.snapshot(p).sha256;dest=clone/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'8fc35d6c8d2b400a36fb23032302e54dbc647b43','overlay':overlay,'source':str(clone)})
for n in ['worker.js','worker-expiry.js','worker-g.js','controller.js','server.py']:shutil.copyfile(old/n,stage/n)
for n in ['build-package.sh','base-browser.py','run.py','run-expiry-02.py','run-g.py']:
 s=(old/n).read_text().replace("stage=root/'target/continuity-browser-policy-requests'", "stage=root/'target/continuity-witness-credential-policy-composition'").replace('policy-request-package-01','credential-policy-package-01')
 if n=='run-g.py':
  start=s.index("    if case=='applied':\n     row['policy_request_refusal']");end=s.index("    unchanged(original,success({**args,'action':'activate'}))",start)
  s=s[:start]+'''    row['policy_request_after_g']=success({**args,'action':'policy-request','historicalOnly':True})
    p=row['policy_request_after_g']['requestValue'];sdk.require(not row['policy_request_after_g']['runtimeCreated'] and p['original_credential']==grant_data['certificate'] and p['current_credential']==renewal_data['certificate'] and p['current_roster']==renewal_data['roster'] and p['journal']==original['journal'],'P after G lost actual predecessor')
    sdk.require(success({**args,'action':'policy-request','historicalOnly':True})==row['policy_request_after_g'],'P after G exact retry changed')
'''+s[end:]
  s=s.replace('required route explicitly refuses, not full sequential policy maintenance qualification','both routes return actual successor metadata; not browser policy adoption/activation qualification')
 (stage/n).write_text(s)
