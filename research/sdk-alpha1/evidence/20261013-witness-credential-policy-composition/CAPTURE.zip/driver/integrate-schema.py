from pathlib import Path
import hashlib,json,shutil
root=Path.cwd();stage=root/'target/continuity-witness-credential-policy-composition';main=root/'research/continuity-identity-candidate';proto=stage/'schema-candidate';record=json.loads((stage/'SCHEMA_PROTOTYPE_SOURCE.json').read_text())
for name,digest in record['main_inputs'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
changed=['src/anchor/store.rs','src/anchor/store/image_version.rs','src/anchor/store/policy_renewal.rs','src/anchor/store/account_replacement/closure.rs','src/durable/rosters.rs','src/durable/rosters/policy_renewal.rs']
for name in changed:shutil.copyfile(proto/name,main/name)
p=main/'src/account_authority/tests.rs';s=p.read_text();old='''    std::fs::write(Path::new(&path).join("registry-committed"), phase)
        .expect("owned child commit marker");''';assert old in s;s=s.replace(old,'''    // The parent reads immediately after observing the final name. Publish the
    // complete marker atomically; create-then-write exposes an empty cut marker.
    q_periapt_host_store::filesystem::publish_private_bytes(
        &Path::new(&path).join("registry-committed"), phase.as_bytes(),
    ).expect("owned child commit marker");''');p.write_text(s)
p=main/'src/session_policy/renewal/tests.rs';s=p.read_text();needle='    pub(crate) fn approvals(&self)';i=s.index(needle);s=s[:i]+'''    pub(crate) fn approve_current(&self, scope: &PolicyRenewalScope, current: &VerifiedDevice, now: u64) -> VerifiedPolicyRenewal {
        let materials = PolicyRenewalMaterials { original: &self.old, previous: &self.old, target: &self.target, original_device: &self.device, current_device: current };
        let statement = PolicyRenewalStatement::new(scope, &materials, now).expect("exact current identity");
        VerifiedPolicyRenewal::verify(
            &self.account.approve_policy_renewal(&statement).expect("account root"),
            &self.issuer.approve_policy_renewal(&statement).expect("policy root"),
            scope, &materials, now,
        ).expect("two independent approvals")
    }
'''+s[i:];p.write_text(s)
p=main/'src/durable/rosters/policy_renewal_tests.rs';p.write_text(p.read_text()+'''
#[test]
fn credential_policy_history_tags_do_not_alias_opposite_operation_order() {
    let c = PolicyRenewalTestCase::new(240, 240);
    let original = c.account.issue_device(c.device.description.clone(), c.device.key.clone()).expect("original certificate");
    let grant = crate::durable::tests::grant(&c.account, &original, &c.device, 280, 2, [93;32], c.old.checkpoint().digest());
    let mut scope = c.scope.clone();
    scope.current_credential = grant.successor_device().credential_digest();
    scope.current_roster = grant.successor_device().roster().checkpoint();
    let before = c.approve_current(&scope, grant.successor_device(), 175).historical();
    for (approval, phase, expected, wrong) in [(before, ReceiptPhase::AwaitingEnrollment, *b"QPRHST08", *b"QPRHST06"), (approval(&c), ReceiptPhase::Acknowledged, *b"QPRHST06", *b"QPRHST08")] {
        let record = StoredPolicyRenewal { approval, phase, carried_grant: Some(crate::VerifiedCredentialRenewal::from_journal(grant.as_bytes(), grant.successor_device().roster()).expect("retained signed G")) };
        assert_eq!(record.format_tag().expect("one canonical order"), &expected);
        let mut wire = Vec::new(); record.encode(&mut wire).expect("actual signed history");
        let mut decoder = Decoder::new(&wire);
        let restored = StoredPolicyRenewal::decode(&mut decoder, grant.successor_device().roster(), expected).expect("matching format");
        decoder.finish().expect("exact bytes");
        assert_eq!(restored.format_tag().expect("canonical roundtrip"), &expected);
        assert!(StoredPolicyRenewal::decode(&mut Decoder::new(&wire), grant.successor_device().roster(), wrong).is_err(), "authenticated history cannot be relabelled as the opposite operation order");
    }
}
''')
p=main/'src/anchor/store/policy_renewal/tests.rs';p.write_text(p.read_text()+'''
#[test]
fn credential_policy_composition_requires_explicit_witness_format() {
    let mut c = Case::new();
    let a = c.approval(&c.original, None, &c.target);
    let p = c.proposal(&a, c.initial, 71);
    c.prepare(p, &a).expect("real independent approval");
    let mut image = c.store.image().expect("authenticated P state");
    // A retired Closed G has no credential change, but its historical floor and
    // acknowledgement still require the new composition-capable container.
    let entry = image.entries.get_mut(&c.subject.id(&c.pin.binding())).expect("subject");
    entry.renewal_floor = 2; entry.renewal_ack = Some([43;32]);
    let key = &c.store.active.as_ref().expect("active witness").wrapping;
    let bytes = super::super::encode(key, &c.pin, &image).expect("new image");
    assert_eq!(&bytes[..8], b"QPANC018");
    super::super::decode(key, &c.pin, &bytes).expect("new container roundtrip");
    let mut downgraded = bytes[..bytes.len()-32].to_vec();
    downgraded[..8].copy_from_slice(b"QPANC017");
    let mut mac = super::super::authenticator(key).expect("owned test authenticator");
    mac.update(&downgraded); downgraded.extend_from_slice(&mac.finalize().into_bytes());
    assert!(matches!(super::super::decode(key, &c.pin, &downgraded), Err(DurableError::Conflict)), "valid authentication must not reinterpret an old container as new authority composition");
    assert!(super::super::account_replacement::closure::decode_records(&mut Decoder::new(&[0,0]), false).is_err());
    assert!(super::super::account_replacement::closure::decode_records(&mut Decoder::new(&[0,0]), true).expect("new container allows an absent closure section").is_empty());
}
''')
(stage/'SCHEMA_INTEGRATED.json').write_text(json.dumps({'base_commit':'8fc35d6c8d2b400a36fb23032302e54dbc647b43','files':changed,'formats':['QPANC018','QPRHST08'],'full_first_suite':'not admissible: isolated prototype rebuilt the same fixed native test executable; original account-preparation marker failure was observed before that collision','marker_fix':'atomic publication, unchanged parent complete-byte assertion','dedicated_target_required':str(stage/'qualified-native-target')},indent=2)+'\n')
