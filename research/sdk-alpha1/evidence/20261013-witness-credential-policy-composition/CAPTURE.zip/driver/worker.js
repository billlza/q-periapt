import initialize, * as sdk from '/node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const b=v=>new Uint8Array(v), check=(v,m)=>{if(!v)throw Error(m)};
let owner,closePending;
self.onmessage=async({data})=>{
 if(data.cancel){check(owner,'cancel owner');closePending=owner.close();postMessage({cancellation_requested:true});return;}
 const owned=[],own=v=>{owned.push(v);return v};let value,failure;const observations=[];
 const get=async name=>{const r=await fetch('/inputs/'+name);if(!r.ok)throw Error('missing public input');return r.json()};
 const snapshot=async()=>{const s=own(await owner.status()),r=ownOptional(s.roster_refresh());return {phase:s.phase(),journal:s.journal()?[...s.journal()]:null,refresh:r?{previous:String(own(r.previous()).version()),target:String(own(r.target()).version()),outcome:r.outcome()??null,observedAt:r.observed_at()===undefined?null:String(r.observed_at())}:null}};
 const ownOptional=v=>v===undefined?undefined:own(v);
 const rosterProgress=async()=>{const p=ownOptional(await owner.witnessed_roster_refresh_progress());if(!p)return null;const previous=own(p.previous()),target=own(p.target()),proposal=ownOptional(p.proposal());return {stage:p.stage(),retired:p.retired(),operation:[...p.operation_id()],previous:String(previous.version()),target:String(target.version()),proposal:proposal?[...proposal.bytes()]:null}};
 try {
  const cfg=await get(data.case+'.json'),description=b(cfg.description),at=BigInt(data.at??Math.floor(Date.now()/1000));
  const intent=own(new sdk.QPeriaptContinuityEnrollment(b(cfg.root),description.slice(0,16),1n,b(cfg.family),BigInt(cfg.from),BigInt(cfg.until)));
  const storage=b(data.id.match(/../g).map(v=>parseInt(v,16)));
  if(data.action==='create'){
   owner=await sdk.QPeriaptContinuityDevice.create(data.name,storage,intent);value={request:[...await owner.request(at)]};
  }else{
   const grant=await get(data.case+'-grant.json'),statement=cfg.policies[data.profile??'required'];
   const history=own(new sdk.QPeriaptContinuityHistoricalPolicy(b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire)));
   let runtime,policy;
   if(!data.historicalOnly){runtime=own(new sdk.QPeriaptRuntime(b(cfg.sdk_policy),b(cfg.sdk_signature),b(cfg.sdk_root),b(cfg.sdk_state),32,4));policy=own(new sdk.QPeriaptContinuityPolicy(runtime,b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire),at));}
   const account=(v)=>own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),BigInt(v.version),b(v.digest),b(cfg.family)));
   owner=await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);observations.push(await snapshot());
   const witness=own(sdk.QPeriaptContinuityWitness.for_loopback(b(cfg.witness_id),b(data.wrongWitness?cfg.root:cfg.witness_public),new URL('/witness/'+data.case+'?mode='+(data.mode??'normal'),location.origin).href,data.timeout??5000));
   const target=async()=>{const v=await get(data.targetFile??data.case+'-target.json');return own(new sdk.QPeriaptContinuityRosterTarget(account(v),b(v.certificate),b(v.roster),at))};
   const proposal=()=>own(new sdk.QPeriaptContinuityRosterProposal(b(data.proposal)));
   if(data.closePolicy)policy.close();if(data.closeRuntime)runtime.close();
   if(data.action==='accept'){value={journal:[...await owner.accept(b(grant.certificate),b(grant.roster),account(grant),policy,at)]};}
   else if(data.action==='prepare'){
    const p=own(await owner.prepare(policy,at)),s=await snapshot();value=p.requires_witness()?{phase:'requires-witness-enrollment',journal:s.journal,genesis:[...p.image_digest()],subject:[...p.subject()]}:{phase:'prepared-local',journal:s.journal};
   }else if(data.action==='activate'){
    const id=data.profile==='local'?await owner.activate_local(policy,at):await owner.activate(policy,witness,at);
    observations.push({activatedJournal:[...id]});
    const key=await owner.generate_prekey(policy,new Uint8Array(32).fill(55),sdk.QPeriaptContinuityPrekeyKind.OneTimePq,BigInt(cfg.from),BigInt(cfg.until),at);
    value={journal:[...id],prekey:[...key],status:await snapshot(),progress:await rosterProgress()};
   }else if(data.action==='scalar'){
    let hooks=0;const coercible={valueOf(){hooks++;return 1n}};
    const rejected=[];
    for(const bad of [(1n<<64n)+1n,1n-(1n<<64n),'1',true,coercible]){
     let error;try{own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),bad,b(grant.digest),b(cfg.family)))}catch(e){error=e}
     check(error?.code==='InvalidInput','account version wrapped/coerced');rejected.push(String(typeof bad));
    }
    for(const bad of [(1n<<64n)+at,at-(1n<<64n),String(at),true,coercible]){
     let error;try{await owner.request(bad)}catch(e){error=e}
     check(error?.code==='InvalidInput','request time wrapped/coerced');
    }
    check(hooks===0,'scalar coercion hook executed');value={rejected:10,hooks,status:await snapshot()};
   }else if(data.action==='new-policy-operation')value={operation:[...sdk.QPeriaptContinuityPolicyRequest.new_operation_id()]};
   else if(data.action==='policy-request'){
    const request=own(data.profile==='local'||data.forceLocal?await owner.policy_renewal_request(b(data.operationId),history):await owner.witnessed_policy_renewal_request(b(data.operationId),history,witness));
    const requestValue={operation:[...request.operation_id()]};
    for(const k of ['journal','original_owner','original_credential_digest','current_credential_digest','current_roster_digest','original_policy_digest','previous_policy_digest','original_credential','original_roster','current_credential','current_roster'])requestValue[k]=[...request[k]()];
    for(const k of ['current_roster_version','original_policy_version','previous_policy_version'])requestValue[k]=String(request[k]());
    const authorization=request.previous_policy_authorization();requestValue.previous_policy_authorization=authorization===undefined?null:[...authorization];
    value={requestValue,status:await snapshot(),runtimeCreated:runtime!==undefined};
   }else if(data.action==='new-operation')value={operation:[...sdk.QPeriaptContinuityRosterProposal.new_operation_id()]};
   else if(data.action==='prepare-roster'){
    const p=own(await owner.prepare_witnessed_roster_refresh(b(data.operationId),history,policy,await target(),witness,at));
    value={proposal:[...p.bytes()],binding:[...p.binding()],progress:await rosterProgress()};
   }else if(data.action==='recover-preparation'){
    const p=ownOptional(await owner.recover_witnessed_roster_refresh_preparation(history));value={proposal:p?[...p.bytes()]:null,progress:await rosterProgress()};
   }else if(data.action==='progress')value={progress:await rosterProgress()};
   else if(data.action==='commit')value={state:await owner.commit_witnessed_roster_refresh(proposal(),history,policy,witness,at),progress:await rosterProgress()};
   else if(data.action==='reconcile')value={state:await owner.reconcile_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='close-roster')value={state:await owner.close_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='abandon')value={progress:(own(await owner.abandon_unprepared_roster_refresh(b(data.operationId),history)),await rosterProgress())};
   else if(data.action==='local-refresh'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest)));
    own(await owner.refresh_local_roster(previous,b(t.roster),account(t),policy,at));value={status:await snapshot()};
   }else if(data.action==='local-resolve'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest))),targetCp=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(t.version),b(t.digest)));
    const result=own(await owner.resolve_local_roster_refresh(previous,targetCp,history,at));value={outcome:result.outcome(),observed:own(result.observed()).version().toString(),status:await snapshot()};
   }else throw Error('unknown action');
  }
 }catch(error){failure=error;if(error.ownerClosed!==undefined)check(owner?.is_closed()===error.ownerClosed,'owner closure mismatch');}
 try{if(closePending)await closePending;if(owner)await owner.close();}catch(error){failure=new AggregateError(failure?[failure,error]:[error],'operation/cleanup failed')}
 if(owner){check(owner.is_closed(),'owner close missing');owner.free();owner=undefined}closePending=undefined;
 for(const object of owned.reverse()){if(typeof object.close==='function')object.close();object.free()}
 postMessage(failure?{done:true,error:String(failure),code:failure.code,ownerClosed:failure.ownerClosed,observations}:{done:true,value,observations});
};
postMessage({ready:true});
