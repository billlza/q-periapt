from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-witness-credential-policy-composition';package=root/'target/continuity-browser-publication/source/target/credential-policy-package-02'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={n:load(stage/n/'RESULT.json') for n in ['run04','run05','run06']};assert all(r['completed'] for r in reports.values())
cases={c['case']:c for n in ['run04','run06'] for c in reports[n]['cases']};assert set(cases)=={'local','required','expired-required','no-local-fallback','wrong-witness','read-loss','cancel'}
for name,c in cases.items():
 r=c['request'];i=c['issuer'];v=r['requestValue'];assert not r['runtimeCreated'] and r['status']==c['original']['status'] and v['journal']==c['original']['journal']
 assert i['issued_and_verified'] and i['unchanged_credential_and_roster'] and i['negative_controls']==2 and i['operation']==v['operation'] and i['previous_policy_expired']==(name=='expired-required')
 assert v['original_credential']==v['current_credential'] and v['original_roster']==v['current_roster'] and v['original_credential_digest']==v['current_credential_digest'] and v['previous_policy_authorization'] is None
 assert v['original_policy_digest']==v['previous_policy_digest'] and v['original_policy_version']==v['previous_policy_version']
 if name=='local':assert not c['witness_records']
 if name in ['read-loss','cancel']:
  assert c['rejection']['code']==('WitnessTransport' if name=='read-loss' else 'Cancelled') and c['rejection']['ownerClosed']
  fault=[x for x in c['witness_records'] if x['trigger']];assert len(fault)==1 and not fault[0]['changed']
 if name=='cancel':assert c['rejection']['cancellationRequested']
 if name=='no-local-fallback':assert c['rejection']['code']=='AnchorRequired' and c['rejection']['ownerClosed']
 if name=='wrong-witness':assert c['rejection']['code']=='Conflict' and c['rejection']['ownerClosed']
e=cases['expired-required'];assert e['real_expiry']['activated_at']<e['real_expiry']['valid_until']<e['real_expiry']['request_at'] and e['expired_activation']['code']=='Validity'
g={c['case']:c for c in reports['run05']['cases']};assert set(g)=={'local','applied'}
for c in g.values():assert c['final']['phase']==4 and c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
p=g['local']['policy_request_after_g'];v=p['requestValue'];assert not p['runtimeCreated'] and v['original_credential']!=v['current_credential'] and v['current_credential']==g['local']['actual_predecessor']['previous_credential'] and v['current_roster']==g['local']['actual_predecessor']['previous_roster']
p=g['applied']['policy_request_after_g'];v=p['requestValue'];assert not p['runtimeCreated'] and v['original_credential']!=v['current_credential'] and v['current_credential']==g['applied']['actual_predecessor']['previous_credential'] and v['current_roster']==g['applied']['actual_predecessor']['previous_roster']
qualified=load(stage/'QUALIFIED_NATIVE_RESULT.json');assert qualified['completed'] and qualified['exit_status']==0 and qualified['source_unchanged'] and qualified['executable_unchanged']
assert '934 passed; 0 failed; 0 ignored' in (stage/'all-lib-qualified.log').read_text()
assert sha(Path(qualified['executable']))==qualified['executable_sha256']
for n,d in qualified['source_inputs'].items():assert sha(root/n)==d,n
for i in range(1,4):
 t=(stage/f'marker-process-{i}.log').read_text();assert '1 passed; 0 failed' in t and 'cuts=3 signal=SIGKILL' in t
assert '3 passed; 0 failed' in (stage/'schema-native-tests.log').read_text()
assert '931 passed; 1 failed' in (stage/'all-lib.log').read_text()
assert 'left: []' in (stage/'all-lib.log').read_text()
assert 'Ran 53 tests' in (stage/'controls-02.log').read_text() and (stage/'controls-02.log').read_text().rstrip().endswith('OK')
for n in ['native-clippy-03.log','wasm-clippy-03.log','wasm-msrv-03.log']:
 t=(stage/n).read_text();assert 'Finished' in t and 'error:' not in t and 'warning:' not in t
assert not (stage/'format-final.log').read_text()
base=load(stage/'base10-02/RESULT.json');assert base['completed'] and len(base['report']['cases'])==10
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz')
source=load(stage/'SOURCE_OVERLAY_V2.json')
for n,d in source['overlay'].items():assert sha(root/n)==d,n
installed=Path(load(package/'consumer-location.json')['path'])
for run,r in reports.items():
 for n,d in r['native'].items():assert sha(Path(n))==d,n
 for n,d in r['source']['inputs'].items():assert sha(root/n)==d,n
 for n,d in r['static_web'].items():
  assert sha(stage/(run+'-web')/n)==d,n
  if not n.startswith('creation/'):assert sha(installed/n)==d,n
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts)
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.txt','.sh'] and p.name not in ['seal.log','finalize.log','HANDOFF.json']:add(p,'driver/'+p.name)
for d in ['authority','issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/'target/continuity-browser-policy-requests'/d/n,'native-fixtures/'+d+'/'+n)
for n in ['src/anchor/store.rs','src/anchor/store/image_version.rs','src/anchor/store/policy_renewal.rs','src/anchor/store/account_replacement/closure.rs','src/durable/rosters.rs','src/durable/rosters/policy_renewal.rs']:
 add(stage/'schema-candidate'/n,'schema-prototype/'+n)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','witness/authority.rs')
add(root/'target/continuity-browser-credential-commit/authority/src/main.rs','credential-issuer/main.rs')
for run in ['run04','run05','run06','base10-02']:
 folder=stage/run
 for p in sorted(folder.iterdir()):
  if p.is_file():add(p,run+'/'+p.name)
 for part in ['logs','captures']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for p in sorted((folder/'witness').rglob('*')):
  if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted((folder/'witness').rglob('RECORDS.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for r in load(p):
   if r['trigger']:
    for q in sorted(p.parent.glob(f"{r['number']:03}.*")):
     if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((stage/(run+'-web')/'inputs').glob('*')):
  if p.is_file():add(p,'public-inputs/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/n,'package/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-witness-credential-policy-composition';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes']
checks={'completed':True,'release_claim_eligible':False,'source':source,'formats':{'witness':'QPANC018','roster_preceding_credential':'QPRHST08','roster_subsequent_credential':'QPRHST06'},'case_count':9,'issuer_cases':sorted(cases),'post_g_cases':{'local':'actual successor metadata','required':'actual successor metadata; original G remains active'},'validation':{'qualified_native_lib':934,'source_and_executable_unchanged':True,'qualified_executable_sha256':qualified['executable_sha256'],'preliminary_schema_filter':3,'atomic_marker_runs':3,'atomic_marker_actual_kills':9,'base_browser':10,'artifact_controls':53,'native_clippy':'all targets -D warnings passed','wasm_clippy':'-D warnings passed','wasm_msrv':'1.90 passed','format':'passed','browser':base['report']['browser']},'excluded_results':{'all-lib.log':'931 passed/1 failed diagnostic only; schema prototype replaced shared executable while full suite was live. Failed marker race observed before collision. Not used for qualification.','package01_browser':'Historical pre-format cohorts remain closed; not current qualification.'},'real_policy_expiry':e['real_expiry'],'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Shared required plain G then independent P: original ownership, current C1, exact receipt, lost Commit/ACK, closed targets, revoked membership, eight actual cross-store process kills and bilateral pending message/PQ continuity. Installed browser issuer requests after G. Same Rust engine and loopback; not G after P/joint T integration, browser P adoption, independent implementation, deployed old/new upgrade, devices/performance/PCS or full release.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
