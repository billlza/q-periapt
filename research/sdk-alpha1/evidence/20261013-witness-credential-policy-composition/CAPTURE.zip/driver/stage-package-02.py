from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-witness-credential-policy-composition';clone=root/'target/continuity-browser-publication/source'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],s/'overlay-paths-02',root).decode().splitlines();overlay={}
for n in paths:
 p=root/n;overlay[n]=sdk.snapshot(p).sha256;q=clone/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
sdk.command(['git','add','--',*paths],s/'overlay-stage-02',clone)
sdk.write_json(s/'SOURCE_OVERLAY_V2.json',{'base_commit':'8fc35d6c8d2b400a36fb23032302e54dbc647b43','overlay':overlay,'source':str(clone),'formats':['QPANC018','QPRHST08']})
for old,new in [('build-package.sh','build-package-02.sh'),('base-browser.py','base-browser-02.py'),('run.py','run-v2.py'),('run-g.py','run-g-v2.py'),('run-expiry-02.py','run-expiry-v2.py')]:
 (s/new).write_text((s/old).read_text().replace('credential-policy-package-01','credential-policy-package-02'))
