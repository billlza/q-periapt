from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path.cwd();stage=root/'target/continuity-witness-credential-policy-composition';original=root/'research/continuity-identity-candidate';dest=stage/'schema-candidate';dest.mkdir()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','research/continuity-identity-candidate'],text=True).splitlines();before={}
for name in paths:
 p=root/name;q=dest/p.relative_to(original);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);before[name]=hashlib.sha256(p.read_bytes()).hexdigest()
p=dest/'Cargo.toml';p.write_text(p.read_text().replace('path = "../../crates/','path = "'+str(root/'crates')+'/'))
p=dest/'src/anchor/store/image_version.rs';s=p.read_text().replace('    V17,','    V17,\n    V18,').replace('            b"QPANC017" => Ok(Self::V17),','            b"QPANC017" => Ok(Self::V17),\n            b"QPANC018" => Ok(Self::V18),');p.write_text(s)
p=dest/'src/anchor/store.rs';s=p.read_text();s=s.replace('    let closure_format = !image.account_closures.is_empty();','    let credential_policy_format = image.entries.values().any(Entry::has_credential_policy_composition);\n    let closure_format = credential_policy_format || !image.account_closures.is_empty();');s=s.replace('    let mut bytes = if closure_format {','    let mut bytes = if credential_policy_format {\n        b"QPANC018".to_vec()\n    } else if closure_format {');needle='            entry.check_renewal_state(pin)?;';assert s.count(needle)==1;s=s.replace(needle,'''            if version < ImageVersion::V18 && entry.has_credential_policy_composition() {
                return Err(DurableError::Conflict);
            }
'''+needle);p.write_text(s)
p=dest/'src/anchor/store/policy_renewal.rs';s=p.read_text();needle='impl Entry {\n';assert s.count(needle)==1;s=s.replace(needle,needle+'''    pub(super) fn has_credential_policy_composition(&self) -> bool {
        self.independent_policy.is_some()
            && (self.renewal_floor != 0 || self.renewal.is_some() || self.renewal_ack.is_some()
                || self.credential_owner != self.subject.owner)
    }
''');p.write_text(s)
p=dest/'src/durable/rosters/policy_renewal.rs';s=p.read_text();needle='impl StoredPolicyRenewal {\n';assert s.count(needle)==1;s=s.replace(needle,needle+'''    pub(super) fn format_tag(&self) -> Result<&'static [u8; 8], DurableError> {
        match self.carried_grant.as_ref() {
            None => Ok(b"QPRHST05"),
            Some(grant) if grant.successor_device().credential_digest() == self.approval.scope().current_credential
                && self.phase == ReceiptPhase::AwaitingEnrollment => Ok(b"QPRHST08"),
            Some(grant) if grant.successor_device().credential_digest() != self.approval.scope().current_credential
                && self.phase == ReceiptPhase::Acknowledged => Ok(b"QPRHST06"),
            _ => Err(DurableError::Corrupt),
        }
    }
''');s=s.replace('        credential_renewed: bool,\n','        format_tag: [u8; 8],\n');s=s.replace('        let carried_grant = if credential_renewed {','        let carried_grant = if matches!(&format_tag, b"QPRHST06" | b"QPRHST08") {');start=s.index('        if phase == ReceiptPhase::AwaitingEnrollment\n');end=s.index('\n    fn receipt(',start);s=s[:start]+'''        let value = Self { approval, phase, carried_grant };
        if value.format_tag()? != &format_tag { return Err(DurableError::Corrupt); }
        Ok(value)
    }
'''+s[end:];p.write_text(s)
p=dest/'src/durable/rosters.rs';s=p.read_text();old='''            let mut prefix = if policy.carried_grant.is_some() {
                b"QPRHST06"
            } else {
                b"QPRHST05"
            }
            .to_vec();''';assert old in s;s=s.replace(old,'            let mut prefix = policy.format_tag()?.to_vec();');s=s.replace('    let credential_renewed = tag == *b"QPRHST06";\n    let policy_only = tag == *b"QPRHST05" || credential_renewed;','    let policy_format_tag = tag;\n    let policy_only = matches!(&tag, b"QPRHST05" | b"QPRHST06" | b"QPRHST08");');s=s.replace('            credential_renewed,','            policy_format_tag,');p.write_text(s)
for n,d in before.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==d,n
(stage/'SCHEMA_PROTOTYPE_SOURCE.json').write_text(json.dumps({'source':str(dest),'main_inputs':before,'main_sources_unchanged':True,'scope':'Isolated explicit QPANC018 and QPRHST08 candidate; not integrated or release qualified'},sort_keys=True,indent=2)+'\n')
