from pathlib import Path
p=Path('research/continuity-identity-candidate/src/durable/rosters/policy_renewal.rs');s=p.read_text()
# Retained G evidence before P is distinct from an unacknowledged G after P.
needle='pub(super) fn adopted<'
idx=s.index(needle)
helper='''fn credential_precedes_policy(
    image: &Image,
    saved: &Stored,
    approval: &HistoricalPolicyRenewal,
) -> bool {
    let scope = approval.scope();
    matches!(image.protection, Protection::Required { policy, .. } if policy == scope.original_policy.digest())
        && saved.local_commit.as_ref().is_some_and(|receipt| {
            saved.renewals.values().any(|grant| {
                receipt == &LocalRenewalCommit::for_grant(grant)
                    && grant.original_storage_owner() == image.owner
                    && grant.original_credential_digest() == scope.original_credential
                    && grant.policy_digest() == scope.original_policy.digest()
                    && grant.successor_device().credential_digest() == scope.current_credential
                    && grant.successor_device().roster().checkpoint().version() <= scope.current_roster.version()
                    && (grant.successor_device().roster().checkpoint().version() != scope.current_roster.version()
                        || grant.successor_device().roster().checkpoint() == scope.current_roster)
            })
        })
}

''';s=s[:idx]+helper+s[idx:]
s=s.replace('if credential_renewed && phase != ReceiptPhase::Acknowledged {\n            return Err(DurableError::Corrupt);\n        }\n','')
needle='''        Ok(Self {
            approval,
            phase,
            carried_grant,
        })''';assert s.count(needle)==1
s=s.replace(needle,'''        if phase == ReceiptPhase::AwaitingEnrollment && carried_grant.as_ref().is_some_and(|g| g.successor_device().credential_digest() != approval.scope().current_credential) {
            return Err(DurableError::Corrupt);
        }
'''+needle)
s=s.replace('if !completion_acknowledged(image, retained)? || saved.local_commit.is_some() {','if !completion_acknowledged(image, retained)? || (saved.local_commit.is_some() && !credential_precedes_policy(image, saved, &retained.approval)) {')
s=s.replace('    if let Some(grant) = carried {\n        approval.check_renewed_identity(original, grant)?;', '    if let Some(grant) = carried.filter(|g| g.successor_device().credential_digest() != approval.scope().current_credential) {\n        approval.check_renewed_identity(original, grant)?;')
old='''            policy == s.original_policy.digest()
                && s.current_credential == s.original_credential
                && current.carried_grant.is_none()
                && saved.policy_continuation.is_none()
                && saved
                    .renewals
                    .values()
                    .all(|g| g.original_storage_owner() != image.owner)''';assert old in s
s=s.replace(old,'''            policy == s.original_policy.digest()
                && saved.policy_continuation.is_none()
                && (s.current_credential == s.original_credential
                    || current.carried_grant.as_ref().is_some_and(|g| g.successor_device().credential_digest() == s.current_credential))''')
s=s.replace('        if current.phase != ReceiptPhase::Acknowledged\n', '        if (current.phase != ReceiptPhase::Acknowledged && device.credential_digest() != s.current_credential)\n')
# Scope-specific allowance only for a journal-verified predecessor G receipt.
s=s.replace('''    fn check_predecessor(
        &self,
        saved: &Stored,''','''    fn check_predecessor(
        &self,
        image: &Image,
        saved: &Stored,''')
s=s.replace('        if saved.local_commit.is_some() {\n            return Err(DurableError::Suspended);\n        }','        if saved.local_commit.is_some() && !credential_precedes_policy(image, saved, self.approval) {\n            return Err(DurableError::Suspended);\n        }')
s=s.replace('target.check_predecessor(&saved, completed.as_ref())?', 'target.check_predecessor(&image, &saved, completed.as_ref())?').replace('target.check_predecessor(&saved, completed)?','target.check_predecessor(&image, &saved, completed)?')
# Original enrollment terminal still gates acknowledgement/owner release.
s=s.replace('        || scope.current_credential != scope.original_credential\n','')
s=s.replace('    approval.check_credential_lineage(original, original)?;','    let current = credential(image, &saved, original, approval)?;\n    approval.check_credential_lineage(original, current)?;')
s=s.replace('let current = saved.roster.refresh_device(completion.original(), now)?;', 'let retained = credential(image, saved, completion.original(), approval)?;\n    let current = saved.roster.refresh_device(retained, now)?;')
s=s.replace('        || actual.carried_grant.is_some()\n        || saved.local_commit.is_some()', '        || (saved.local_commit.is_some() && !credential_precedes_policy(image, &saved, &actual.approval))')
old='''        if saved.policy_continuation.is_some()
            || saved.local_commit.is_some()
            || saved
                .renewals
                .values()
                .any(|g| g.original_storage_owner() == image.owner)
            || history.scope().current_credential != history.scope().original_credential
        {''';assert old in s
s=s.replace(old,'''        if saved.policy_continuation.is_some()
            || (history.scope().current_credential != history.scope().original_credential
                && !credential_precedes_policy(&image, &saved, &history))
        {''')
# Keep the existing signed G in the P target for historical reads after revocation.
start=s.index('    async fn prepare_policy_renewal_attempt(');idx=s.index('        saved.policy_renewal = Some(StoredPolicyRenewal {',start)
s=s[:idx]+'''        let carried_grant = saved.renewals.get(&materials.original_device.device_id()).cloned();
'''+s[idx:]
idx=s.index('            carried_grant: None,',idx);s=s[:idx]+s[idx:].replace('            carried_grant: None,','            carried_grant,',1)
s=s.replace('        || saved.local_commit.is_some()\n        || saved.policy_continuation.is_some()', '        || (saved.local_commit.is_some() && !credential_precedes_policy(image, &saved, approval))\n        || saved.policy_continuation.is_some()')
s=s.replace('                || actual.carried_grant.is_some()\n','')
s=s.replace('''                    if actual.carried_grant.is_none()
                        && actual.approval.journal_bytes()''','''                    if actual.approval.journal_bytes()''')
p.write_text(s)
p=Path('research/continuity-identity-candidate/src/anchor/store/policy_renewal.rs');s=p.read_text()
s=s.replace('        // G/T composition needs its own later integration; this path never aliases it.','        // A retired plain G may precede P; live G/T coordination remains excluded.')
s=s.replace('            || self.renewal_floor != 0\n            || self.renewal_ack.is_some()\n','').replace('            || self.credential_owner != self.subject.owner\n','')
s=s.replace('            || scope.current_credential != scope.original_credential\n','')
s=s.replace('            || entry.renewal_floor != 0\n            || entry.renewal_ack.is_some()\n','')
s=s.replace('    /// Current scope excludes a subject that has adopted a credential/joint renewal.','    /// An already retired plain credential renewal is retained; joint continuation\n    /// and unfinished credential coordination remain separate.')
p.write_text(s)
