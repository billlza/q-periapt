"""Seal selected public lanes; private fixture path references are not followed."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
out = root / 'target/independent-control-01'
peer = root / 'research/continuity-openssl-peer'
folder = root / 'research/sdk-alpha1/evidence/20261018-independent-control'
folder.mkdir(exist_ok=False)
control = json.loads((out / 'CONTROL_READBACK.json').read_text())
regressions = json.loads((out / 'REGRESSION_READBACK.json').read_text())
assert control['source_files'] == regressions['source_files']
def sha(data):
    return hashlib.sha256(data).hexdigest()

entries = {}
for lane in ['qualified', 'owner', 'capacity', 'storage', 'base', 'rekey', 'exchange', 'run-01', 'run-02']:
    for path in sorted((out / lane).rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink() and path.name not in {'head', 'intent', '.stage-head', 'configuration', 'signer', 'wrong-signer'}
        data = path.read_bytes()
        assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02', b'QPREFS03'))
        entries[str(path.relative_to(out))] = data
    for suffix in ['stdout', 'stderr']:
        entries[lane + '.' + suffix] = (out / (lane + '.' + suffix)).read_bytes()
for name in ['CONTROL_READBACK.json', 'REGRESSION_READBACK.json', 'review-control.py', 'review-control.stdout',
             'review-control.stderr', 'review-regressions.py', 'review-regressions.stdout', 'review-regressions.stderr',
             'review-regressions-first.py', 'review-regressions-first.stderr', 'seal.py']:
    entries[name] = (out / name).read_bytes()
for command in ['build', 'clippy', 'fmt', 'actionlint']:
    for suffix in ['stdout', 'stderr']:
        entries[command + '.' + suffix] = (out / (command + '.' + suffix)).read_bytes()
for name, expected in control['source_files'].items():
    data = (peer / name).read_bytes()
    assert sha(data) == expected
    entries['source/' + name] = data
for name in ['README.md', 'STORAGE.md']:
    entries['source/' + name] = (peer / name).read_bytes()
entries['source/independent-continuity.yml'] = (root / '.github/workflows/independent-continuity.yml').read_bytes()
entries['counterpart'] = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
assert sha(entries['counterpart']) == control['native_sha256']
changed = subprocess.check_output(['git', 'diff', '23280124', '--name-only'], text=True).splitlines()
assert all(n.startswith(('research/continuity-openssl-peer/', 'research/sdk-alpha1/evidence/')) or n in
           ['docs/SDK_0_2_RELEASE_READINESS.md', '.github/workflows/independent-continuity.yml'] for n in changed)
entries['SOURCE_CONTINUITY.json'] = (json.dumps({'from_head': '23280124efd2f0f3003d4ce85e3db665f6ec8a25',
    'working_base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'changed_tracked_paths': changed, 'product_candidate_bindings_toolchain_unchanged': True}, indent=2) + '\n').encode()
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(entries.items())}
entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = folder / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        item = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        z.writestr(item, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(entries) and z.testzip() is None
    for name, item in manifest.items():
        data = z.read(name)
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
report = {'control': control, 'regressions': regressions,
          'validation': {'strict_release_build': True, 'strict_all_target_clippy': True, 'rustfmt': True,
                         'actionlint': True, 'Python_AST': True, 'tracked_Rust_files': 722},
          'capture': {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())},
          'failed_attempts': ['run-01: test helper method name conflicted with output directory attribute',
                              'run-02: expected budget-error wording differed from actual unchanged refusal',
                              'first regression reader expected old upgrade version2; corrected to explicit new version3'],
          'hosted_qualification': 'Pending; this is the completed local ARM64 checkpoint.',
          'private_state': 'Original private fixtures including failed attempts remain local; only path references are captured.'}
(folder / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['capture']))
