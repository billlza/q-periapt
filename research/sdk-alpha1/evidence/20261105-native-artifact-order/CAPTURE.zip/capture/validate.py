from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import os
import re
import sys

from bounded_process import capture_output

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-native-artifact-order'
def digest(data): return hashlib.sha256(data).hexdigest()
before = (BASE / 'baseline-source/.github/workflows/ci.yml').read_bytes()
after = (ROOT / '.github/workflows/ci.yml').read_bytes()
def sections(body):
    first, rest = body.decode().split('  continuity-identity-candidate:\n', 1)
    native, last = rest.split('\n  # Cross-target', 1)
    header, steps = native.split('    steps:\n', 1)
    return first, header, [s.strip() for s in re.split(r'(?m)(?=^      - )', steps) if s.strip()], last
a, b = sections(before), sections(after)
assert a[0] == b[0] and a[1] == b[1] and a[3] == b[3]
assert Counter(a[2]) == Counter(b[2]) and a[2] != b[2]
assert 'FAILED (errors=2)' in (BASE / 'red.stderr').read_text()
assert (BASE / 'green.stderr').read_text().endswith('\nOK\n')
proxy = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo/bin')
rustup = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/rustup')
assert (proxy / 'rustup').is_file() and (rustup / 'toolchains/1.98.1-aarch64-apple-darwin/bin/rustc').is_file()
env = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3',
           RUSTUP_HOME=str(rustup), PATH=str(proxy) + os.pathsep + os.environ.get('PATH', os.defpath))
argv = ['/bin/sh', 'artifact/python-run.sh', '-m', 'unittest', 'artifact.test_continuity_workflow_partitions', '-v']
state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 600,
         'workflow_before_sha256': digest(before), 'workflow_after_sha256': digest(after),
         'test_source_sha256': digest((ROOT / 'artifact/test_continuity_workflow_partitions.py').read_bytes()),
         'only_step_order_changed': True, 'all_step_bodies_unchanged': True,
         'hosted_rerun_performed': False, 'artifact_transport_repaired_claimed': False}
try:
    result = capture_output(argv, timeout_seconds=600, maximum_stdout_bytes=16*1024**2,
                            maximum_stderr_bytes=16*1024**2, environment=env)
    for suffix in ['stdout', 'stderr']:
        with (BASE / ('suite.' + suffix)).open('xb') as f: f.write(getattr(result, suffix))
        state[suffix + '_sha256'] = digest(getattr(result, suffix))
    state['returncode'] = result.returncode
    assert result.returncode == 0 and result.stderr.endswith(b'\nOK\n'), result.stderr.decode()[-2500:]
    count = re.search(rb'Ran ([0-9]+) tests', result.stderr)
    assert count is not None; state['tests'] = int(count[1])
    assert (ROOT / '.github/workflows/ci.yml').read_bytes() == after
    state.update(completed=True, inputs_unchanged=True)
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    with (BASE / 'VALIDATION.json').open('x') as f: json.dump(state, f, indent=2); f.write('\n')
    print(json.dumps({k: state.get(k) for k in ['completed', 'tests', 'returncode', 'error_type', 'error']}, indent=2), flush=True)
