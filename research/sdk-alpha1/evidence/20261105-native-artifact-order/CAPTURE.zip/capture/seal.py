from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-native-artifact-order'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-native-artifact-order'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode()
job = json.loads((BASE / 'JOB.json').read_bytes())
status = json.loads((BASE / 'CI_STATUS.json').read_bytes())
validation = json.loads((BASE / 'VALIDATION.json').read_bytes())
log = (BASE / 'job-126445763003.log').read_bytes()
text = log.decode()
assert job['id'] == 126445763003 and job['conclusion'] == 'failure'
steps = {s['number']: s for s in job['steps']}
for n in [7, 12, 14]: assert steps[n]['conclusion'] == 'success'
for n in [15, 18]: assert steps[n]['conclusion'] == 'failure'
for n in [16, 17]: assert steps[n]['conclusion'] == 'skipped'
assert re.search(r'^\S+Z 9aa535b48b464ec4d4a8b5a4b20221049a6067b9$', text, re.M)
assert 'Failed to CreateArtifact: Unable to make request: ENOTFOUND' in text
assert 'No files were found with the provided path: target/continuity-public-vectors' in text
summaries = re.findall(r'^\S+Z test result: (ok\..+)$', text, re.M)
counts = [int(re.match(r'ok\. ([0-9]+) passed;', s)[1]) for s in summaries]
assert counts == [1450, 4, 2, 4, 3, 19, 27, 4], counts
assert all('; 0 failed; 0 ignored;' in s for s in summaries)
assert validation['completed'] and validation['tests'] == 15 and validation['returncode'] == 0
assert validation['only_step_order_changed'] and validation['all_step_bodies_unchanged']
assert sha((ROOT / '.github/workflows/ci.yml').read_bytes()) == validation['workflow_after_sha256']
assert sha((ROOT / 'artifact/test_continuity_workflow_partitions.py').read_bytes()) == validation['test_source_sha256']
classification = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'job_id': job['id'], 'run_id': job['run_id'], 'job_url': job['html_url'],
    'actual_checkout': '9aa535b48b464ec4d4a8b5a4b20221049a6067b9',
    'log_bytes': len(log), 'log_sha256': sha(log),
    'primary_failure': 'Native-results artifact creation returned ENOTFOUND.',
    'consequence': 'Default success condition skipped Python setup and independent public verification; the final always-run public upload then found no files.',
    'candidate_test_summaries': summaries[:6], 'sdk_test_summaries': summaries[6:],
    'candidate_scope': 'Debug suite on the named PR merge: 1450 library tests plus 32 other tests, excluding the separate capacity case.',
    'independent_public_verification_executed': False, 'job_pass_claimed': False,
    'artifact_uploaded_claimed': False, 'dns_root_cause_established': False,
    'local_fix': 'Move the unchanged native artifact upload after the independent checks and public artifact upload. Both uploads remain required and strict.',
    'completion_condition': 'Corrected-source hosted job must run the independent verifier and preserve the required artifacts successfully.',
    'validation': validation, 'wave_counts': status['counts'], 'effective_wave_open': True,
    'push_performed': False, 'rerun_performed': False, 'workflow_cancelled': False,
    'release_claim_eligible': False}
files = {}
for p in BASE.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and p.name not in ['seal.stdout', 'seal.stderr']:
        files['capture/' + p.relative_to(BASE).as_posix()] = p.read_bytes()
for name in ['.github/workflows/ci.yml', 'artifact/test_continuity_workflow_partitions.py']:
    files['corrected-source/' + name] = (ROOT / name).read_bytes()
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    for name, body in files.items(): assert archive.read(name) == body
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as f: f.write(body)
print(json.dumps(summary, indent=2), flush=True)
