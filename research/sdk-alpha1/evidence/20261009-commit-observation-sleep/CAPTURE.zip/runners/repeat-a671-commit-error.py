from pathlib import Path
import hashlib, json, os, signal, subprocess, tempfile, time

b=Path(__file__).resolve().parent
out=b/'a671-commit-error-repeat-01';out.mkdir()
installed=Path('/private/tmp/qperiapt-continuity-package-erw0bz2b')
binary=installed/'build/release/deps/enrollment_witness-4c46bc593400dcb0'
client=installed/'c-installed-release/qpc-c-client'
identities={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [binary,client,installed/'c-installed-release/libq_periapt_continuity_c_consumer.dylib']}
private=Path(tempfile.mkdtemp(prefix='qperiapt-commit-error-repeat-')).resolve()
evidence=private/'evidence'
env={k:v for k,v in os.environ.items() if not k.startswith(('QPC','QPERIAPT','CARGO','RUST','DYLD','LD_'))}
env.update(QPERIAPT_C_OWNER_CLIENT=str(client),QPERIAPT_WITNESSED_COMMIT_ERROR_EVIDENCE=str(evidence))
cmd=[str(binary),'--exact','witness_commit_error::foreign_commit_transport_error_closes_and_reopens_original_owner','--nocapture']
record=dict(command=cmd,cwd=str(installed/'c-consumer'),evidence=str(evidence),inputs=identities)
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
samples=[];timed_out=False;t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
    p=subprocess.Popen(cmd,cwd=installed/'c-consumer',env=env,stdout=so,stderr=se,start_new_session=True)
    while p.poll() is None:
        samples.append(dict(monotonic=time.monotonic(),wall=time.time()))
        if time.monotonic()-t>300:
            timed_out=True;os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            break
        time.sleep(0.25)
samples.append(dict(monotonic=time.monotonic(),wall=time.time()))
(out/'CLOCK_SAMPLES.json').write_text(json.dumps(samples,indent=2)+'\n')
record.update(returncode=p.returncode,seconds=time.monotonic()-t,timed_out=timed_out,
              inputs_unchanged=all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==v for k,v in identities.items()),
              max_wall_monotonic_delta=max(abs((v['wall']-u['wall'])-(v['monotonic']-u['monotonic'])) for u,v in zip(samples,samples[1:])))
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert not timed_out and record['inputs_unchanged']
if p.returncode != 0:
    raise subprocess.CalledProcessError(p.returncode, cmd)
