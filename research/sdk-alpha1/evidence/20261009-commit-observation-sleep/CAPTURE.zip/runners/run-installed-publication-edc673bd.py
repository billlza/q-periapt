from pathlib import Path
import subprocess, os, json, time, hashlib

b=Path(__file__).resolve().parent
root=b.parents[1]
source=b/'kotlin-persistence-review-source'
head='edc673bd31079283431ec359f4dfcaf58a5a3b5b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
assert (source/'.git').is_dir()
preflight=json.loads((b/'preflight-kotlin-persistence-edc673bd-02/RESULT.json').read_text())
assert preflight['head']==head and len(preflight['runs'])==3 and all(run['returncode']==0 for run in preflight['runs'])
assert preflight['source_clean'] and preflight['head_unchanged']
out=b/'installed-publication-edc673bd';out.mkdir(mode=0o700)
package_output=source/'target/continuity-publication-edc673bd'
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
report=root/'target/policy-recovery-ffi-current/source/target/registry-alias-rust-package-01/RUST_SDK_PACKAGE.json'
report_sha='0b829385401232b2c33ede818bf3dd55e29ce1e288856ba0b33f61e7ca59b58b'
assert hashlib.sha256(report.read_bytes()).hexdigest()==report_sha
base=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON','JAVA','JDK','GRADLE','KOTLIN','SWIFT')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
env.update(PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',TMPDIR='/private/tmp')
cmd=['/usr/bin/caffeinate','-i','sh','artifact/python-run.sh','artifact/continuity_package.py','--report',str(report),'--report-sha256',report_sha,
     '--toolchain-root',str(tc),'--with-c-consumer','--with-swift-consumer','--with-kotlin-consumer',
     '--witness-openssl-prefix','/opt/homebrew/opt/openssl@3',
     '--kotlin-java-home',str(base/'jdk-25.0.4.1+1/Contents/Home'),
     '--kotlin-gradle-home',str(base/'gradle-9.8.0'),'--output',str(package_output)]
(out/'START.json').write_text(json.dumps({'head':head,'source':str(source),'output':str(package_output),'command':cmd,'sleep_guard':'Process-scoped caffeinate -i; no global power preference or display assertion','scope':'Full current-source Rust/C/Swift/Kotlin package and installed-consumer qualification; reusable product SDK archives are accepted only by the standard workspace-equivalence and archive checks.'},indent=2)+'\n')
print(json.dumps({'head':head,'output':str(package_output),'consumers':['Rust','C','Swift','Kotlin']}),flush=True)
start=time.monotonic()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    process=subprocess.run(cmd,cwd=source,env=env,stdout=stdout,stderr=stderr)
result=dict(command=cmd,returncode=process.returncode,seconds=time.monotonic()-start,head=head,
            source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip(),
            head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head)
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
if process.returncode: print((out/'stderr.log').read_text()[-7000:],flush=True)
assert result['source_clean'] and result['head_unchanged']
process.check_returncode()
