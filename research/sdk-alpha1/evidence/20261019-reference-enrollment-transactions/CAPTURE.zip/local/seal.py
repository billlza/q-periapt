"""Publish only source and nonsecret diagnostics for the native host transaction."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='697e15a83265fd4061d9187221b49256bb495b2b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
test=(out/'tests-06.stdout').read_text()
assert '15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in test
assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in test
for name in ['clippy-03.stderr','build-04.stderr']:
    text=(out/name).read_text()
    assert 'Finished ' in text and not re.search(r'^(warning|error)(?:\[|:)',text,re.M)
assert 'one missing root key must not disable unrelated account authentication' in (out/'isolation-red.stdout').read_text()
assert 'test result: FAILED.' in (out/'isolation-red.stdout').read_text()
cli=json.loads((out/'CLI_STRICT_REOPEN.json').read_text())
binary=repo/'target/continuity-reference-app/release/q-periapt-continuity-reference-app'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==cli['binary_sha256']
saved=out/'release-strict-final'
assert not saved.exists()
shutil.copy2(binary,saved)
failed=(out/'tests-01.stdout').read_text()
left=json.loads(bytes(json.loads(re.search(r'^\s*left: (\[.*\])$',failed,re.M).group(1))).decode())
right=json.loads(bytes(json.loads(re.search(r'^\s*right: (\[.*\])$',failed,re.M).group(1))).decode())
changes=[]
def compare(a,b,path=''):
    if type(a)!=type(b):changes.append(path);return
    if isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:compare(a[k],b[k],path+'.'+k)
    elif isinstance(a,list):
        assert len(a)==len(b)
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'.'+str(i))
    elif a!=b:changes.append(path)
compare(left,right)
assert changes==['.passkeys.0.cred.counter']
(out/'FAILURES.json').write_text(json.dumps({
    'tests01':'Snapshot compared before login to after schema upgrade; actual difference was only the legitimate login counter increment0to1. Moved snapshot to after login, retaining byte-exact comparison across upgrade. Product storage admission unchanged.',
    'isolation_red':'New implementation incorrectly classified issuer-key failure as global store failure; red regression proves an unrelated account became unusable. Final IssuerUnavailable remains an error and never recreates keys, but does not poison other accounts. Database Internal/commit uncertainty still poisons the store. Exact red source and logs retained.',
    'release01_02':'Builds exited0 but emitted rust-objcopy loader warnings. Their diagnostics and original unstripped binary remain local. Same pinned toolchain already contained libLLVM22.1.8 at its root lib directory. Per-command DYLD_LIBRARY_PATH restored that existing library; strict -Dwarnings builds03/04 succeeded without warnings. No toolchain files or global settings changed.',
    'lock_review':'Initial all-prior-versions-unchanged assertion failed; source inspection found candidate exact mio1.2.3 pin replacing optional host1.2.4. LOCK_REVIEW records the change and the separate Windows named-pipe review requirement.'},indent=2)+'\n')
entries={}
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {'.stdout','.stderr','.json','.txt','.py'}:
        entries['local/'+path.name]=path.read_bytes()
for path in sorted((out/'isolation-red-source').rglob('*.rs')):
    entries['local/'+path.relative_to(out).as_posix()]=path.read_bytes()
source=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
for name in source:
    data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
    assert data==(repo/name).read_bytes()
    entries['source/'+name]=data
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-reference-enrollment-transactions'
dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,item in manifest.items():
        data=z.read(name)
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
data=archive.read_bytes()
checks={'head':head,'source_files':len(source),'capture':{'bytes':len(data),'members':len(entries),'sha256':hashlib.sha256(data).hexdigest()},
    'tests':{'passed':18,'child_dispatcher_included':1,'behavioral_tests':17,'sigkill_boundaries':10,'log':'local/tests-06.stdout','actual_tcp':True,'host':'macOS arm64'},
    'strict_clippy':'local/clippy-03.stderr','strict_release':'local/build-04.stderr','release_flags':'-D warnings; same-toolchain root/lib in per-command DYLD_LIBRARY_PATH',
    'release_execution':cli,'workflow':'actionlint passed','format':'cargo fmt check passed','failure_record':'local/FAILURES.json','dependency_review':'local/LOCK_REVIEW.json',
    'scope':'Optional native reference-host Rust API and explicit schema CLI. Actual SDK-generated requests, controlled signers and complete rosters; software host authentication. Not enrollment over HTTP/browser, installed independent clients, deployed HTTPS, device revocation/full root replacement, filesystem sync fault injection, hardware power-loss or full0.2.0 qualification. SDK source/wire/ABI unchanged; SDK dependency source is identified by Git head, not duplicated in this capture.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text('''# Durable host-authorized enrollment transactions

At `697e15a83265fd4061d9187221b49256bb495b2b`, the optional reference host
implements explicit schema admission, recoverable root preparation, host-approved
original requests, atomic complete-roster/result publication, exact result
recovery, cancellation and an enrollment suspension fence. The invitation's
caller-retained correlation ID also recovers a lost initial host operation ID.
No Q-Periapt account registration is required to use the SDK.

Local checks passed 18 test entrypoints (17 behavioral tests plus one child
dispatcher), including ten actual SIGKILL boundaries, two-device signature/roster
verification and actual loopback TCP. Strict all-target Clippy, formatting,
workflow lint and the final `-D warnings` release build passed. The final binary
reopened the original CLI test database, served an anonymous401 and stopped
cleanly without init, upgrade or reset. The real user's account store was untouched.

The capture preserves the initial snapshot-test error, the reproduced overly
broad issuer-failure shutdown and its repair, release-tool loader warnings and
their task-local correction, and the mio dependency resolution review. The
Windows named-pipe upstream delta remains a separate SDK dependency review item.
No warning suppression or weakened check was used.

Authentication here uses a software authenticator; native enrollment uses real
SDK-generated requests and controlled signing owners at current host time.
HTTP/browser enrollment controls, installed independent clients, deployed HTTPS,
revocation/full root replacement, sync-fault injection, power-loss durability and
the rest of the full lifecycle remain open. This is component progress, not
release admission. `CAPTURE.zip` contains source and nonsecret diagnostics only;
private database/key files and executables stay local.
''')
print(json.dumps(checks['capture']))
