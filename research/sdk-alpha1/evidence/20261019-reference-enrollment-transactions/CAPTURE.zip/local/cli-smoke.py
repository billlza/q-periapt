from pathlib import Path
import base64, hashlib, json, signal, socket, subprocess, time, urllib.error, urllib.request

out = Path(__file__).resolve().parent
repo = out.parent.parent
binary = repo / 'target/continuity-reference-app/release/q-periapt-continuity-reference-app'
private = out / 'cli-private-01'
private.mkdir(mode=0o700)
with socket.socket() as probe:
    probe.bind(('127.0.0.1', 0))
    port = probe.getsockname()[1]
origin = f'http://localhost:{port}'
database = private / 'accounts.redb'
family = base64.urlsafe_b64encode(bytes([42]) * 32).decode().rstrip('=')
commands = []
def command(name, mode, path, extra=(), success=True):
    args = [str(binary), mode, str(path), origin, *extra]
    with (out / (name+'.stdout')).open('wb') as stdout, (out / (name+'.stderr')).open('wb') as stderr:
        result = subprocess.run(args, stdout=stdout, stderr=stderr, timeout=30)
    commands.append({'name':name, 'mode':mode, 'exit_code':result.returncode, 'expected_success':success})
    assert (result.returncode == 0) == success, name

command('cli-missing', 'enable-enrollment', private/'missing.redb', [family], success=False)
assert not (private/'missing.redb').exists()
command('cli-init', 'init', database)
identity = database.stat().st_ino
command('cli-enable', 'enable-enrollment', database, [family])
command('cli-enable-retry', 'enable-enrollment', database, [family])
other = base64.urlsafe_b64encode(bytes([43])*32).decode().rstrip('=')
command('cli-family-conflict', 'enable-enrollment', database, [other], success=False)

servers = []
for attempt in [1, 2]:
    with (out / f'cli-serve-{attempt}.stdout').open('wb') as stdout, (out / f'cli-serve-{attempt}.stderr').open('wb') as stderr:
        process = subprocess.Popen([str(binary), 'serve', str(database), origin], stdout=stdout, stderr=stderr)
        observation = None
        try:
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError(f'owned server exited before readiness: {process.returncode}')
                try:
                    with urllib.request.urlopen(origin+'/api/me', timeout=2) as response:
                        raise AssertionError(f'anonymous request unexpectedly succeeded: {response.status}')
                except urllib.error.HTTPError as response:
                    body = response.read()
                    assert response.code == 401
                    assert response.headers['cache-control'] == 'no-store'
                    assert json.loads(body) == {'error':'Authentication required or ceremony invalid'}
                    observation = {'status':response.code, 'cache_control':response.headers['cache-control']}
                    break
                except urllib.error.URLError as error:
                    if not isinstance(error.reason, ConnectionRefusedError):
                        raise
                    time.sleep(0.05)
            assert observation is not None, 'owned server did not become ready'
        finally:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
            try:
                status = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
                raise
        assert status == 0
        assert database.stat().st_ino == identity
        servers.append({'attempt':attempt, 'exit_code':status, 'same_database_inode':True, **observation})

report = {'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(), 'commands':commands, 'servers':servers,
    'scope':'Actual release CLI on an isolated empty test database: missing-state refusal, explicit schema upgrade, exact-family retry, family-conflict refusal, two real localhost TCP serves with anonymous401, clean SIGINT and original database inode. Real user account database untouched. No enrollment HTTP handlers or installed-client claim.'}
(out/'CLI_SMOKE.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
