"""Execute the final strict-build binary against the original CLI test database."""
from pathlib import Path
import hashlib,json,re,signal,subprocess,time,urllib.error,urllib.request
out=Path(__file__).resolve().parent
binary=out.parent/'continuity-reference-app/release/q-periapt-continuity-reference-app'
database=out/'cli-private-01/accounts.redb'
assert database.is_file()
origin,=re.findall(r'Reference account application: (http://localhost:\d+)',(out/'cli-serve-1.stdout').read_text())
inode=database.stat().st_ino
with (out/'cli-strict-serve.stdout').open('wb') as stdout,(out/'cli-strict-serve.stderr').open('wb') as stderr:
    proc=subprocess.Popen([str(binary),'serve',str(database),origin],stdout=stdout,stderr=stderr)
    result=None
    try:
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            assert proc.poll() is None,'owned server exited before observation'
            try:
                with urllib.request.urlopen(origin+'/api/me',timeout=2) as response:
                    raise AssertionError(f'unexpected anonymous success {response.status}')
            except urllib.error.HTTPError as response:
                assert response.code==401
                assert response.headers['cache-control']=='no-store'
                assert json.loads(response.read())=={'error':'Authentication required or ceremony invalid'}
                result={'status':401,'cache_control':'no-store'}
                break
            except urllib.error.URLError as error:
                if not isinstance(error.reason,ConnectionRefusedError):raise
                time.sleep(.05)
        assert result is not None
    finally:
        if proc.poll() is None:proc.send_signal(signal.SIGINT)
        try:status=proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill();proc.wait(timeout=5);raise
assert status==0 and database.stat().st_ino==inode
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'binary_bytes':binary.stat().st_size,'same_original_database_inode':True,'init_or_upgrade_executed':False,'exit_code':status,'observation':result,'scope':'Final -Dwarnings release binary, original schema2 CLI fixture reopened without init/upgrade/reset, actual loopback TCP anonymous401, clean SIGINT. No real-user database, enrollment HTTP or installed-client qualification.'}
(out/'CLI_STRICT_REOPEN.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
