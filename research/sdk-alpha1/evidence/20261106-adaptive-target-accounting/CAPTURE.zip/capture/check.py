from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import sys

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT=Path.cwd()
OUT=Path(__file__).resolve().parent
PIN='01ed008334a4aa0aee720ee7cbeec9b5394dc816'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==PIN
names=[
    'crates/q-periapt-sdk/src/expert/replay.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-recovery-symbolic/multi-epoch.spthy',
    'docs/continuity/KEM_CHALLENGE_ADAPTER_V1.md',
]
sources={};inventory={}
def sha(data):
    return hashlib.sha256(data).hexdigest()
def write(name,value):
    with (OUT/name).open('x') as stream:
        stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
for name in names:
    data=(ROOT/name).read_bytes()
    assert data==subprocess.check_output(['git','show',PIN+':'+name]),name
    sources[name]=data.decode()
    inventory[name]={'bytes':len(data),'sha256':sha(data)}
    path=OUT/'source'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

def sequence(name,start,parts):
    source=sources[name];cursor=source.index(start);result=[]
    for label,needle in parts:
        index=source.index(needle,cursor)
        result.append({'step':label,'line':source.count('\n',0,index)+1,'literal':needle})
        cursor=index+len(needle)
    return {'source':name,'ordered_locations':result}

sdk=names[0];base='research/continuity-identity-candidate/src/durable/messages/'
locations={
    'fresh_reservation':sequence(sdk,'    fn reserve(',[
        ('runtime-admission','let _admission = runtime.state.begin()?;'),
        ('wrapping-owner','let cipher = self.cipher()?;'),
        ('binding','let mut wire = binding('),
        ('entropy-draw','getrandom::fill(&mut entropy)'),
        ('nonce-draw','getrandom::fill(&mut nonce)'),
        ('seal','.encrypt_inout_detached('),
        ('return-token','Ok(SealedOperation(wire))')]),
    'generation':sequence(base+'rekey.rs','pub async fn prepare_rekey_offer(',[
        ('only-if-no-plan','if state.control.plan.is_none() {'),
        ('fresh-generation','.reserve_key('),
        ('retain-plan','state.control.plan = Some(Plan::Key(key));'),
        ('persist','self.store_message_state(&mut image, &state).await?;'),
        ('compute-retained','let key = match recovery.generate_key(')]),
    'response':sequence(base+'rekey/response.rs','pub async fn respond_rekey_offer(',[
        ('authenticate-first','verify_offer(&state, context, offer)?;'),
        ('retained-response','if let Some(super::Plan::Response(saved))'),
        ('exact-offer','if saved.offer != offer {'),
        ('only-if-no-plan','if state.control.plan.is_none() {'),
        ('fresh-encapsulation','.reserve_encapsulation('),
        ('retain-plan','state.control.plan = Some(super::Plan::Response(Plan {'),
        ('persist','self.store_message_state(&mut image, &state).await?;'),
        ('compute-retained','let result = match recovery.encapsulate(')]),
    'acceptance':sequence(base+'rekey/completion.rs','pub async fn accept_rekey_response(',[
        ('original-offer','if let Some(super::Plan::Ready {'),
        ('verify-offer','self.check_cached_wire(context, target, RekeyFlight::Offer, offer)?;'),
        ('verify-response','verify_wire(context, target, RekeyFlight::Response, reply)?;'),
        ('check-prefix','if body.len() != response::RESPONSE_BODY_LEN || !body.starts_with(&prefix)'),
        ('replay-generation','let owner = match recovery.generate_key('),
        ('check-public-key','if owner\n                .public_key()'),
        ('decapsulate','.decapsulate(&ciphertext, &response::kem_context(offer))')]),
}
for start,end in [('    pub fn generate_key(','    /// Reserve an encapsulation'),
    ('    pub fn encapsulate(','    fn cipher(')]:
    segment=sources[sdk].split(start,1)[1].split(end,1)[0]
    assert 'getrandom::fill' not in segment and 'self.open(' in segment and 'take(&mut remaining' in segment
model=(ROOT/'target/multi-epoch-replay/replay-01/original.spthy').read_bytes()
assert sha(model)=='dde5d06a071b1560da0d4c28c3f1fd81a3c39708f9fd8564ee391ddc362bcf7f'
text=model.decode();query='multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
start=text.index('lemma '+query+' ');quote=text.index('"',text.index('all-traces',start))
formula=text[quote+1:text.index('"',quote+1)].encode()
assert sha(formula)=='0b92ee18d7731c7c83fa05329e486fd6813f8ea13d64ed92215346f10cdf8faa'
with (OUT/'MAIN.formula.txt').open('xb') as stream:stream.write(formula)
with (OUT/'original.spthy').open('xb') as stream:stream.write(model)
write('SOURCE_AUDIT.json',{'source_commit':PIN,'source_inputs':inventory,'locations':locations,
    'main_model_sha256':sha(model),'main_formula_sha256':sha(formula),
    'source_inputs_unchanged':all(sha((ROOT/name).read_bytes())==row['sha256'] for name,row in inventory.items()),
    'scope':'Selected source-byte identities and ordered source locations. Not a control-flow proof or complete native origin/acquisition refinement.',
    'new_native_execution':False,'new_tamarin_execution':False,'proof_checker':False,
    'full_native_prefix_complete':False,'release_claim_eligible':False})

epsilon=Fraction(1,8)
real=[{'eligible':True,'bit':True,'mass':epsilon},
    {'eligible':False,'bit':False,'mass':1-epsilon}]
other=[{'eligible':True,'bit':False,'mass':epsilon},
    {'eligible':False,'bit':False,'mass':1-epsilon}]
def probability(rows,predicate):
    return sum((row['mass'] for row in rows if predicate(row)),Fraction())
def rational(value):
    return {'numerator':value.numerator,'denominator':value.denominator}
raw=[];conditional=[]
for rows in (real,other):
    assert sum(row['mass'] for row in rows)==1
    e=probability(rows,lambda r:r['eligible'])
    success=probability(rows,lambda r:r['eligible'] and r['bit'])
    raw.append(success);conditional.append(success/e)
assert raw==[epsilon,Fraction()] and conditional==[Fraction(1),Fraction()]
real_target={1:Fraction(1,2),2:Fraction(1,2)}
override_targets={1:{1:Fraction(1),2:Fraction()},2:{1:Fraction(),2:Fraction(1)}}
real_mass=sum(real_target.values())
different_world_mass=sum(override_targets[j][j] for j in (1,2))
assert real_mass==1 and different_world_mass==2
write('EXACT_EXAMPLES.json',{'conditioning':{
    'epsilon':rational(epsilon),'unconditioned_probabilities':list(map(rational,raw)),
    'conditional_probabilities':list(map(rational,conditional)),
    'unconditioned_difference':rational(abs(raw[0]-raw[1])),
    'conditional_difference':rational(abs(conditional[0]-conditional[1]))},
    'different_override_worlds':{'real_matching_mass':rational(real_mass),
        'sum_of_separate_override_matching_masses':rational(different_world_mass)},
    'scope':'Exact rational arithmetic for two elementary invalid-proof-shortcut examples. Not protocol executions, a primitive attack, a proof of the reduction, or exhaustive verification.',
    'release_claim_eligible':False})
print(json.dumps({'source_files':len(inventory),'ordered_paths':len(locations),
    'main_formula_unchanged':True,'exact_arithmetic_examples':2,'proof_checker':False}))
