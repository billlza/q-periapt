from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT=Path.cwd()
BASE=Path(__file__).resolve().parent
DEST=ROOT/'research/sdk-alpha1/evidence/20261106-adaptive-target-accounting'
audit=json.loads((BASE/'SOURCE_AUDIT.json').read_bytes())
assert audit['source_commit']=='01ed008334a4aa0aee720ee7cbeec9b5394dc816'
assert audit['source_inputs_unchanged'] is True and audit['proof_checker'] is False
assert (BASE/'check.stderr').read_bytes()==b''
files={}
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(name,path):
    assert name not in files and path.is_file() and not path.is_symlink()
    files[name]=path
for name,record in audit['source_inputs'].items():
    path=BASE/'source'/name
    raw=path.read_bytes()
    assert len(raw)==record['bytes'] and sha(raw)==record['sha256']
    add('source/'+name,path)
for name in ('SOURCE_AUDIT.json','EXACT_EXAMPLES.json','MAIN.formula.txt','original.spthy',
    'check.py','check.stdout','check.stderr','seal.py'):
    add('capture/'+name,BASE/name)
for name in ('docs/continuity/ADAPTIVE_TARGET_ACCOUNTING_V1.md',
    'docs/continuity/KEM_CHALLENGE_ADAPTER_V1.md','docs/continuity/EXTERNAL_REVIEW_BRIEF.md',
    'research/sdk-alpha1/evidence/20261106-adaptive-target-accounting/README.md'):
    path=ROOT/name
    for link in re.findall(r'\]\(([^)]+)\)',path.read_text()):
        if '://' not in link and not link.startswith('#'):
            target=(path.parent/link.split('#',1)[0]).resolve()
            if target.parent==DEST and target.name in ('FILES.json','CAPTURE.json','SOURCE_AUDIT.json','EXACT_EXAMPLES.json'):
                continue
            assert target.is_file(),(name,link)
    add('documents/'+name,path)
assert sha((BASE/'original.spthy').read_bytes())==audit['main_model_sha256']
assert sha((BASE/'MAIN.formula.txt').read_bytes())==audit['main_formula_sha256']
manifest={}
with zipfile.ZipFile(DEST/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        manifest[name]={'bytes':len(data),'sha256':sha(data)}
        archive.writestr(name,data)
with zipfile.ZipFile(DEST/'CAPTURE.zip') as archive:
    assert len(archive.namelist())==len(manifest) and set(archive.namelist())==set(manifest)
    for name,expected in manifest.items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
    captured=json.loads(archive.read('capture/SOURCE_AUDIT.json'))
    for name,expected in captured['source_inputs'].items():
        assert sha(archive.read('source/'+name))==expected['sha256']
    assert sha(archive.read('capture/MAIN.formula.txt'))==captured['main_formula_sha256']
    assert sha(archive.read('capture/original.spthy'))==captured['main_model_sha256']
for name in ('SOURCE_AUDIT.json','EXACT_EXAMPLES.json'):
    (DEST/name).write_bytes((BASE/name).read_bytes())
with (DEST/'FILES.json').open('x') as stream:
    stream.write(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
summary={'source_commit':audit['source_commit'],'bytes':(DEST/'CAPTURE.zip').stat().st_size,
    'sha256':sha((DEST/'CAPTURE.zip').read_bytes()),'members':len(manifest),
    'all_members_reread':True,'source_inputs_verified':6,'exact_arithmetic_examples':2,
    'main_formula_unchanged':True,'proof_checker':False,'new_native_execution':False,
    'new_tamarin_execution':False,'full_native_adaptive_target_security_complete':False,
    'release_claim_eligible':False}
with (DEST/'CAPTURE.json').open('x') as stream:
    stream.write(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary))
