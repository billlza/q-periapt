from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path(__file__).resolve().parent;root=out.parents[1]
source=json.loads((out/'SOURCE.json').read_text());identities=json.loads((out/'BINARIES.json').read_text())
for name,digest in identities.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
assert identities['modified.bin']==source['candidate_binary_sha256']
plain=root/'target/fanout-snapshot-uninstrumented-01/source'
for name in ['Cargo.toml','Cargo.lock']:assert (plain/name).read_bytes()==(out/'baseline'/name).read_bytes()
changed=[]
for path in (out/'baseline').rglob('*.rs'):
 rel=path.relative_to(out/'baseline')
 if path.read_bytes()!=(plain/rel).read_bytes():changed.append(rel.as_posix())
assert changed==['src/durable/messages/fanout.rs']
assert not re.search(r'(?mi)^\s*(warning:|error:)',(out/'build.stderr').read_text())
test='durable::messages::tests::fanout::account_fanout_payload_boundaries_match_individual_traffic_and_restart'
pattern=re.compile(r'^fanout_path_sample same_account=(false|true) sample=(\d+) plaintext=(\d+) ad=(\d+) recipients=(\d+) elapsed_ns=(\d+)$',re.M)
plan={'blocks':200,'warmup_blocks':2,'order':'alternating AB/BA; no concurrent benchmark processes','samples_per_variant':2400,'samples_per_workload_position_per_variant':200,'test':test,'scope':'Uninstrumented native journal send latency for12fixed workload positions. Fresh original fixture per process. No controlled-tail SLO, whole-connection, foreign/network/device or energy claim.','binary_sha256':identities}
(out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
sequence=[];start=time.monotonic()
def run(block,variant,warmup=False):
 label=('warmup' if warmup else 'block')+f'-{block:03}-{variant}'
 args=[str(out/(variant+'.bin')),'--exact',test,'--nocapture','--test-threads=1']
 before_load=os.getloadavg();started=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
  proc=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr,timeout=90,check=False)
 command={'block':block,'variant':variant,'warmup':warmup,'argv':args,'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-started,'load_before':before_load,'load_after':os.getloadavg()}
 (out/(label+'.json')).write_text(json.dumps(command,indent=2)+'\n')
 assert proc.returncode==0,label
 stdout=(out/(label+'.stdout')).read_text();stderr=(out/(label+'.stderr')).read_text()
 assert stdout.count('1 passed; 0 failed; 0 ignored; 0 measured; 1036 filtered out;')==1
 found=pattern.findall(stderr);assert len(found)==12
 for index,row in enumerate(found):
  same,sample,length,ad,recipients,elapsed=row
  assert same==('false' if index<6 else 'true') and int(sample)==index%6
  assert (int(length),int(ad))==[(0,0),(1024,32),(16384,1024)][index%3] and int(recipients)==2 and int(elapsed)>0
 if not warmup:sequence.append(command)
for block in range(2):
 for variant in (('baseline','modified') if block%2==0 else ('modified','baseline')):run(block,variant,True)
for block in range(200):
 for variant in (('baseline','modified') if block%2==0 else ('modified','baseline')):run(block,variant)
 if (block+1)%10==0:print(json.dumps({'completed_blocks':block+1,'planned_blocks':200,'elapsed_seconds':round(time.monotonic()-start,2)}),flush=True)
for name,digest in identities.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
(out/'PAIRED_EXECUTION.json').write_text(json.dumps({'plan':plan,'sequence':sequence,'seconds':time.monotonic()-start,'original_assertions_passed':True,'binary_identities_unchanged':True},indent=2)+'\n')
print('Paired native latency execution complete',flush=True)
