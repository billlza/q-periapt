from pathlib import Path
import csv,hashlib,json,math,re,statistics
out=Path(__file__).resolve().parent
record=json.loads((out/'PAIRED_EXECUTION.json').read_text());plan=record['plan']
assert plan['blocks']==200 and plan['warmup_blocks']==2 and record['original_assertions_passed'] and record['binary_identities_unchanged']
assert len(record['sequence'])==400
for name,digest in plan['binary_sha256'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
pattern=re.compile(r'^fanout_path_sample same_account=(false|true) sample=(\d+) plaintext=(\d+) ad=(\d+) recipients=(\d+) elapsed_ns=(\d+)$',re.M)
rows=[]
for index,item in enumerate(record['sequence']):
 block=index//2;order=('baseline','modified') if block%2==0 else ('modified','baseline');variant=order[index%2]
 assert item['block']==block and item['variant']==variant and not item['warmup'] and item['returncode']==0
 prefix=out/f'block-{block:03}-{variant}'
 assert json.loads(prefix.with_suffix('.json').read_text())==item
 stdout=prefix.with_suffix('.stdout').read_text();stderr=prefix.with_suffix('.stderr').read_text()
 assert stdout.count('1 passed; 0 failed; 0 ignored; 0 measured; 1036 filtered out;')==1
 found=pattern.findall(stderr);assert len(found)==12
 for position,value in enumerate(found):
  same,sample,length,ad,recipients,elapsed=value
  assert same==('false' if position<6 else 'true') and int(sample)==position%6
  assert (int(length),int(ad))==[(0,0),(1024,32),(16384,1024)][position%3] and int(recipients)==2 and int(elapsed)>0
  rows.append({'block':block,'variant':variant,'same_account':same=='true','sample':int(sample),'plaintext':int(length),'ad':int(ad),'elapsed_ns':int(elapsed),'command_seconds':item['elapsed_seconds'],'load1_before':item['load_before'][0],'load1_after':item['load_after'][0]})
assert len(rows)==4800
with (out/'SAMPLES.csv').open('x',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def quantile(values,q):return sorted(values)[math.ceil(q*len(values))-1]/1e6
summary=[]
for same in [False,True]:
 for sample in range(6):
  base=[r for r in rows if r['same_account']==same and r['sample']==sample and r['variant']=='baseline']
  new=[r for r in rows if r['same_account']==same and r['sample']==sample and r['variant']=='modified']
  assert len(base)==len(new)==200 and all(l['block']==r['block'] for l,r in zip(base,new))
  b=[r['elapsed_ns'] for r in base];n=[r['elapsed_ns'] for r in new]
  summary.append({'same_account':same,'sample':sample,'plaintext':base[0]['plaintext'],'ad':base[0]['ad'],'samples_per_variant':200,'baseline_median_ms':statistics.median(b)/1e6,'modified_median_ms':statistics.median(n)/1e6,'paired_median_change_percent':100*(statistics.median(r/l for l,r in zip(b,n))-1),'baseline_p95_ms':quantile(b,.95),'modified_p95_ms':quantile(n,.95),'baseline_p99_ms':quantile(b,.99),'modified_p99_ms':quantile(n,.99),'baseline_max_ms':max(b)/1e6,'modified_max_ms':max(n)/1e6})
result={'source':json.loads((out/'SOURCE.json').read_text()),'plan':plan,'seconds':record['seconds'],'timed_operations':4800,'percentile_definition':'Observed nearest-rank quantiles per workload position, n=200 per variant; warmups excluded. No pooling of different journal positions.','scope':'Exploratory paired native durable-send timings on one desktop host; unchanged correctness assertions. No statistical confidence, latency SLO, independent network/foreign/device/energy qualification.','host_load1_observation_range':[min(r['load1_before'] for r in rows),max(r['load1_after'] for r in rows)],'samples':summary}
(out/'REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'timed_operations':len(rows),'per_position_samples_per_variant':200,'paired_median_change_percent_range':[min(r['paired_median_change_percent'] for r in summary),max(r['paired_median_change_percent'] for r in summary)]}))
