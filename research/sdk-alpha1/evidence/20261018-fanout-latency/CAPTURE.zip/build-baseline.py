from pathlib import Path
import hashlib,json,os,re,subprocess,shutil,time
out=Path(__file__).resolve().parent;root=out.parents[1];source=out/'baseline'
toolchain=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env=dict(os.environ);env.update(PATH=str(toolchain/'bin')+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'),CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_TARGET_DIR=str(out/'build-baseline'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never')
args=['cargo','test','--offline','--locked','--release','--all-features','--lib','--no-run'];start=time.monotonic()
with (out/'build.stdout').open('xb') as stdout,(out/'build.stderr').open('xb') as stderr:
 proc=subprocess.run(args,cwd=source,env=env,stdout=stdout,stderr=stderr,timeout=900,check=False)
(out/'BUILD_COMMAND.json').write_text(json.dumps({'argv':args,'cwd':str(source),'returncode':proc.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
assert proc.returncode==0
log=(out/'build.stdout').read_text()+(out/'build.stderr').read_text();assert not re.search(r'(?mi)^\s*(warning:|error:)',log)
binary=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]+)\)',log).group(1))
if not binary.is_absolute():binary=source/binary
shutil.copyfile(binary,out/'baseline.bin');(out/'baseline.bin').chmod(0o755)
hashes={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['baseline.bin','modified.bin']};assert len(set(hashes.values()))==2
(out/'BINARIES.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Uninstrumented Release baseline built; distinct binary identities retained',flush=True)
