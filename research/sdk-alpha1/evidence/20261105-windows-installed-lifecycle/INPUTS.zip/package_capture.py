import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'capsules'
OUT.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

inputs = {'13406143783.zip', '13410832833.zip'}
downloads = json.loads((ROOT/'DOWNLOADS.json').read_text())
input_files = set(inputs)
result_files = {str(row['id'])+'.zip' for row in downloads} - inputs
input_files.update(str(row['id'])+'.json' for row in downloads)
input_files.update(p.relative_to(ROOT).as_posix() for folder in ('source-93aa','producer-source-93aa')
                   for p in (ROOT/folder).rglob('*') if p.is_file())
input_files.update(p.name for p in ROOT.glob('*.py'))
input_files.update({'DOWNLOADS.json','READER_SOURCE.json','PRODUCER_SOURCE.json'})
result_files.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'api').rglob('*') if p.is_file())
result_files.update(p.name for p in ROOT.glob('windows-*.json'))
result_files.update(p.name for p in ROOT.glob('windows-*.stdout'))
result_files.update(p.name for p in ROOT.glob('windows-*.stderr'))
result_files.update({'IDENTITY.json','IDENTITY_COMMAND.json','identity.stdout','identity.stderr'})

catalogue = {}
summary = {}
for capsule,names in (('INPUTS.zip',input_files),('RESULTS.zip',result_files)):
    inventory = {}
    with zipfile.ZipFile(OUT/capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name in sorted(names):
            data=(ROOT/name).read_bytes()
            inventory[name]={'bytes':len(data),'sha256':sha(data)}
            archive.writestr(name,data)
    with zipfile.ZipFile(OUT/capsule) as archive:
        if set(archive.namelist()) != names or archive.testzip() is not None:
            raise ValueError('capsule inventory/CRC mismatch')
        for name,row in inventory.items():
            data=archive.read(name)
            if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
                raise ValueError('capsule full-member readback mismatch')
    catalogue[capsule]=inventory
    data=(OUT/capsule).read_bytes()
    summary[capsule]={'bytes':len(data),'sha256':sha(data),'members':len(inventory)}
    print(json.dumps({'capsule':capsule,**summary[capsule]}),flush=True)
(OUT/'FILES.json').write_text(json.dumps(catalogue,indent=2,sort_keys=True)+'\n')
(OUT/'CAPTURE.json').write_text(json.dumps({'capsules':summary,'original_artifacts':downloads,
    'scope':'Eight original GitHub artifacts, full public readback, exact pinned readers, producer/package identities and original job logs. No newly executed native Windows workload.'},indent=2)+'\n')
