import ast
import hashlib
import json
import pathlib
import stat
import subprocess
import unicodedata
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[1]
COMMIT = '93aa0582362bf91040e55f5ac3b8ee0e568d1e62'

def digest(data):
    return hashlib.sha256(data).hexdigest()

files = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', COMMIT, 'artifact'], cwd=REPO, text=True).splitlines())
sources = {}
queue = ['artifact/continuity_windows_network_review.py']
while queue:
    name = queue.pop()
    if name in sources:
        continue
    data = subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=REPO)
    sources[name] = digest(data)
    target = ROOT / 'source-93aa' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as output:
        output.write(data)
    for node in ast.walk(ast.parse(data)):
        modules = ([a.name for a in node.names] if isinstance(node, ast.Import)
                   else [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
        for module in modules:
            dependency = 'artifact/' + module.replace('.', '/') + '.py'
            if dependency in files:
                queue.append(dependency)
(ROOT / 'READER_SOURCE.json').write_text(json.dumps({'commit': COMMIT, 'files': dict(sorted(sources.items()))}, indent=2) + '\n')

downloads = json.loads((ROOT / 'DOWNLOADS.json').read_text())
for item in downloads:
    path = ROOT / (str(item['id']) + '.zip')
    if path.stat().st_size != item['bytes'] or digest(path.read_bytes()) != item['sha256']:
        raise ValueError('download identity changed')
    destination = ROOT / 'expanded' / item['name']
    destination.mkdir(parents=True)
    with zipfile.ZipFile(path) as archive:
        portable_names = set()
        for member in archive.infolist():
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode) or member.is_dir():
                raise ValueError('only ordinary file members expected')
            parts = pathlib.PurePosixPath(member.filename)
            if parts.is_absolute() or '..' in parts.parts or '\\' in member.filename:
                raise ValueError('unsafe archive member')
            portable = unicodedata.normalize('NFC', member.filename).casefold()
            if portable in portable_names:
                raise ValueError('portable path collision')
            portable_names.add(portable)
        for member in archive.infolist():
            target = destination / member.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as output:
                output.write(archive.read(member))
    print(json.dumps({'expanded': item['name'], 'members': len(portable_names)}), flush=True)
print(json.dumps({'reader_modules': len(sources), 'commit': COMMIT}), flush=True)
