import hashlib
import json
import pathlib
import re
import struct
import subprocess
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[1]
EXPANDED = ROOT / 'expanded'
COMMIT = '93aa0582362bf91040e55f5ac3b8ee0e568d1e62'
sys.path.insert(0, str(ROOT / 'source-93aa' / 'artifact'))
import rust_sdk_profile as sdk
from installed_rust_graph import external_lock
from evidence_io import parse_strict_json_bytes
from c_package_manifest import rust_workspace_source_digest

def require(condition, label):
    if not condition:
        raise ValueError(label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return parse_strict_json_bytes(path.read_bytes(), label=str(path.relative_to(ROOT)))

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def git_hashes(names, commit):
    ordered = sorted(names)
    require(all('\n' not in n for n in ordered), 'noncanonical Git source name')
    payload = ''.join(f'{commit}:{n}\n' for n in ordered).encode()
    data = subprocess.run(['git', 'cat-file', '--batch'], input=payload, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, cwd=REPO, check=True).stdout
    cursor = 0
    result = {}
    for name in ordered:
        end = data.index(b'\n', cursor)
        header = data[cursor:end].split()
        require(len(header) == 3 and header[1] == b'blob', 'source is not a Git blob')
        length = int(header[2])
        start = end + 1
        result[name] = sha(data[start:start + length])
        cursor = start + length
        require(data[cursor:cursor + 1] == b'\n', 'Git batch framing mismatch')
        cursor += 1
    require(cursor == len(data), 'unparsed Git batch suffix')
    return result

def zip_files(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'duplicate zip name')
        require(all(not x.is_dir() for x in archive.infolist()), 'unexpected directory entry')
        return {name: archive.read(name) for name in names}

run, jobs, commit = (load(ROOT / 'api' / name) for name in ('run.json', 'jobs.json', 'commit.json'))
require(run['id'] == 42009005451 and run['status'] == 'completed' and run['conclusion'] == 'success', 'workflow did not succeed')
require(commit['sha'] == COMMIT and [x['sha'] for x in commit['parents']] ==
        ['ed257e10c75af6798838ee6a95e0ccc6930cf388', run['head_sha']], 'PR merge ancestry differs')
require(len(jobs['jobs']) == 8 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs']), 'workflow job inventory differs')
downloads = {row['id']: row for row in load(ROOT / 'DOWNLOADS.json')}
artifacts = load(ROOT / 'api/artifacts.json')['artifacts']
require(len(artifacts) == len(downloads) == 8, 'workflow artifact inventory differs')
for row in artifacts:
    saved = downloads[row['id']]
    require(row['workflow_run']['id'] == run['id'] and row['workflow_run']['head_sha'] == run['head_sha'] and
            row['name'] == saved['name'] and row['size_in_bytes'] == saved['bytes'] and
            row['digest'] == 'sha256:' + saved['sha256'], 'GitHub artifact provenance/digest differs')
    archive = ROOT / (str(row['id']) + '.zip')
    require(archive.stat().st_size == saved['bytes'] and sha(archive.read_bytes()) == saved['sha256'], 'retained original artifact changed')

producer = EXPANDED / 'windows-installed-input'
sdk_root = EXPANDED / 'windows-sdk-package'
input_bytes = (producer / 'INPUT.json').read_bytes()
receipt = parse_strict_json_bytes(input_bytes, label='producer input')
sdk_report_bytes = (sdk_root / 'RUST_SDK_PACKAGE.json').read_bytes()
sdk_report = parse_strict_json_bytes(sdk_report_bytes, label='SDK report')
require(receipt['source_commit'] == receipt['sdk_commit'] == sdk_report['base_commit'] == COMMIT, 'producer commit mismatch')
require(sha(sdk_report_bytes) == receipt['sdk_report_sha256'], 'SDK receipt identity mismatch')
require(sdk_report['git_dirty'] is False and sdk_report['sources_unchanged'] is True and
        sdk_report['publication_performed'] is False and sdk_report['release_claim_eligible'] is False, 'SDK producer scope mismatch')
for name, inventory in (('facade', receipt['source_files']), ('sdk', sdk_report['source_inputs']['files'])):
    require(git_hashes(inventory, COMMIT) == inventory, name + ' source differs from actual merge commit')

workspace_names = git('ls-tree', '-r', '--name-only', COMMIT, '--', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates').decode().splitlines()
workspace_hashes = git_hashes(workspace_names, COMMIT)
workspace_digest = hashlib.sha256()
for name, value in sorted(workspace_hashes.items()):
    workspace_digest.update(name.encode() + b'\0' + bytes.fromhex(value) + b'\0')
require(workspace_digest.hexdigest() == sdk_report['source_inputs']['rust_workspace_sha256'], 'SDK workspace identity mismatch')

consumer_path = producer / 'consumer.zip'
require(sha(consumer_path.read_bytes()) == receipt['zip_sha256'], 'consumer archive identity mismatch')
consumer = zip_files(consumer_path)
require({n: sha(b) for n, b in consumer.items()} == receipt['files'], 'installed consumer file inventory differs')
all_crates = {}
for name, row in sdk_report['crates'].items():
    data = (sdk_root / 'crates' / row['file']).read_bytes()
    require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'SDK crate bytes differ')
    members = sdk.archive_files(data, name)
    require(set(members) == set(row['files']) and len(members) == row['members'], 'SDK crate inventory differs')
    all_crates[name] = {'bytes': len(data), 'sha256': sha(data), 'members': len(members)}
    if name in receipt['versions']:
        require(receipt['archives'][name] == {'bytes': len(data), 'sha256': sha(data)}, 'installed SDK crate selection differs')
        prefix = f"packages/{name}-{receipt['versions'][name]}/"
        require({n[len(prefix):]: b for n,b in consumer.items() if n.startswith(prefix)} == members, 'installed SDK source differs from crate')
name = 'q-periapt-continuity-identity-candidate'
data = (producer / (name + '-0.0.0.crate')).read_bytes()
require(receipt['archives'][name] == {'bytes': len(data), 'sha256': sha(data)}, 'candidate archive identity mismatch')
members = sdk.archive_files(data, name, version='0.0.0')
prefix = f'packages/{name}-0.0.0/'
require({n[len(prefix):]: b for n,b in consumer.items() if n.startswith(prefix)} == members, 'installed candidate differs from archive')
candidate_source = {'research/continuity-identity-candidate/' + n: sha(b)
                    for n,b in members.items() if n.startswith(('src/', 'tests/'))}
require(git_hashes(candidate_source, COMMIT) == candidate_source, 'candidate Rust source differs from merge commit')
all_crates[name] = {'bytes': len(data), 'sha256': sha(data), 'members': len(members)}

native = {}
for platform in ('windows-2022', 'windows-2025'):
    for profile in ('debug', 'release'):
        path = EXPANDED / ('windows-installed-c-' + platform + '-' + profile)
        result = load(path / 'RESULT.json')
        require(result['input'] == receipt and result['input_sha256'] == sha(input_bytes), 'native input identity mismatch')
        require(set(result['profiles']) == {profile}, 'native result profile mismatch')
        metadata = load(path / 'metadata.stdout')
        product_rows = [p for p in metadata['packages'] if p['name'].startswith('q-periapt')]
        packages = {p['name']: p for p in product_rows}
        require(len(packages) == len(product_rows) and set(packages) == set(receipt['versions']) | {receipt['consumer']}, 'native product graph differs')
        root_manifest = pathlib.PureWindowsPath(packages[receipt['consumer']]['manifest_path'])
        root = root_manifest.parent
        require(root_manifest.is_absolute() and root.name == 'consumer' and root.parent.name.startswith('qpc-installed-windows-'), 'consumer is not the external installed directory')
        require(packages[receipt['consumer']]['source'] is None, 'facade source differs')
        require(pathlib.PureWindowsPath(load(path / 'metadata.json')['cwd']) == root, 'native Cargo metadata command has different cwd')
        for name, version in receipt['versions'].items():
            row = packages[name]
            require(row['source'] is None and row['version'] == version and
                    pathlib.PureWindowsPath(row['manifest_path']) == root / 'packages' / f'{name}-{version}' / 'Cargo.toml', 'native crate was not resolved from installed archive')
        require(all(p['source'] == 'registry+https://github.com/rust-lang/crates.io-index' for p in metadata['packages'] if not p['name'].startswith('q-periapt')), 'native external source differs')
        node = next(n for n in metadata['resolve']['nodes'] if n['id'] == packages['q-periapt-continuity-identity-candidate']['id'])
        require({'connection-tls','control-tls','anchor-tls'} <= set(node['features']), 'native candidate feature closure differs')
        resolved = external_lock((path / 'Cargo.lock').read_bytes())
        original = external_lock(consumer['original-Cargo.lock'])
        require(all(original.get(k) == v for k,v in resolved.items()), 'resolved dependency lock changed')
        require(result['resolution'] == {'product_crates': len(receipt['versions']), 'external_packages': len(resolved), 'lockfile_sha256': sha((path / 'Cargo.lock').read_bytes())}, 'native graph receipt differs')
        row = result['profiles'][profile]
        binary_zip = path / (profile + '-c-input.zip')
        require(sha(binary_zip.read_bytes()) == row['zip_sha256'], 'installed DLL package changed')
        binary_files = zip_files(binary_zip)
        require({n:sha(b) for n,b in binary_files.items()} == row['files'], 'DLL package inventory changed')
        require(binary_files['qpc_owner.h'] == consumer['qpc_owner.h'], 'installed C header differs')
        dll = binary_files['q_periapt_continuity_c_consumer.dll']
        require(dll[:2] == b'MZ', 'DLL DOS header mismatch')
        pe = struct.unpack_from('<I', dll, 60)[0]
        require(dll[pe:pe+4] == b'PE\0\0' and struct.unpack_from('<H', dll, pe+4)[0] == 0x8664, 'DLL is not x86_64 PE')
        commands = {}
        for file in path.glob('*.json'):
            command = load(file)
            if isinstance(command,dict) and 'returncode' in command:
                require(command['returncode'] == 0 and isinstance(command['argv'],list), 'native command failed')
                commands[file.name] = sha(file.read_bytes())
        for suffix in ('owned-runtime','owner-runtime','configuration-paths'):
            require(profile + '-' + suffix + '.json' in commands, 'required native execution absent')
        native[platform + '/' + profile] = {'result_sha256': sha((path/'RESULT.json').read_bytes()),
            'commands': commands, 'files': row['files'], 'binary_zip_sha256': row['zip_sha256'],
            'resolved_product_crates': len(receipt['versions']), 'resolved_external_packages': len(resolved),
            'original_public_readback_reproduced': True}

current_changes = []
for name, expected in {**workspace_hashes, **candidate_source, **receipt['source_files']}.items():
    path = REPO / name
    if not path.is_file() or sha(path.read_bytes()) != expected:
        current_changes.append(name)
record = {'source_commit': COMMIT, 'workflow_head_commit': run['head_sha'], 'merge_parents': [x['sha'] for x in commit['parents']],
    'current_head': git('rev-parse','HEAD').decode().strip(), 'current_sdk_workspace_sha256': rust_workspace_source_digest(REPO),
    'input_sha256': sha(input_bytes), 'sdk_report_sha256': sha(sdk_report_bytes),
    'sdk_workspace_sha256': workspace_digest.hexdigest(), 'sdk_workspace_files': len(workspace_hashes),
    'sdk_explicit_source_files': len(sdk_report['source_inputs']['files']), 'facade_source_files': len(receipt['source_files']),
    'candidate_rust_source_files': len(candidate_source), 'consumer_files': len(consumer), 'crates': all_crates,
    'native': native, 'different_current_source_inputs': sorted(set(current_changes)),
    'installed_lineage_readback_passed': True, 'local_native_execution': False, 'release_claim_eligible': False,
    'scope': 'Readback of original Windows installed-archive evidence and actual retained DLLs; original public readers reproduced. No local Windows execution or qualification transfer to later source.'}
(ROOT / 'IDENTITY.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k: record[k] for k in ('source_commit','sdk_workspace_sha256','sdk_workspace_files','facade_source_files','candidate_rust_source_files','consumer_files','different_current_source_inputs','installed_lineage_readback_passed')}))
