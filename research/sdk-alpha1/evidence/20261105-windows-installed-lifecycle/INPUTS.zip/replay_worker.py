import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
source = ROOT / 'source-93aa' / 'artifact'
sys.path.insert(0, str(source))
import continuity_windows_network_review as reviewer

platform = sys.argv[1]
if platform not in ('windows-2022', 'windows-2025'):
    raise ValueError('unsupported observed platform')
expected = json.loads((ROOT / 'READER_SOURCE.json').read_text())
output = ROOT / (platform + '-REPLAY.json')
observed = reviewer.review_split(
    ROOT / 'expanded' / ('windows-installed-c-' + platform + '-debug'),
    ROOT / 'expanded' / ('windows-installed-c-' + platform + '-release'),
    output, expected['commit'])
original = json.loads((ROOT / 'expanded' / ('windows-lifecycle-readback-' + platform) / 'NETWORK_REVIEW.json').read_text())
if observed != original:
    raise ValueError('replayed reader differs from original hosted result')
loaded = {}
for module in list(sys.modules.values()):
    name = getattr(module, '__file__', None)
    if name is None:
        continue
    path = pathlib.Path(name).resolve()
    if path.is_relative_to(source):
        relative = path.relative_to(source.parent).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected['files'].get(relative) != digest:
            raise ValueError('loaded source differs from pinned merge commit')
        loaded[relative] = digest
(ROOT / (platform + '-READER_MODULES.json')).write_text(json.dumps(dict(sorted(loaded.items())), indent=2) + '\n')
print(json.dumps({'platform': platform, 'hosted_report_reproduced': True, 'reader_modules_loaded': len(loaded), 'source_commit': expected['commit']}))
