import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent

def replay(platform):
    command = [sys.executable, '-I', '-B', str(ROOT / 'replay_worker.py'), platform]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.monotonic()
    with (ROOT / (platform + '.stdout')).open('xb') as out, (ROOT / (platform + '.stderr')).open('xb') as err:
        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, timeout=60)
    receipt = {'command': command, 'started_utc': started, 'elapsed_seconds': time.monotonic() - before,
               'returncode': result.returncode,
               'stdout_sha256': hashlib.sha256((ROOT / (platform + '.stdout')).read_bytes()).hexdigest(),
               'stderr_sha256': hashlib.sha256((ROOT / (platform + '.stderr')).read_bytes()).hexdigest()}
    (ROOT / (platform + '-COMMAND.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'platform': platform, **receipt}), flush=True)
    if result.returncode:
        raise RuntimeError('original public reader failed; streams retained')
    return receipt

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    results = list(executor.map(replay, ('windows-2022', 'windows-2025')))
print(json.dumps({'both_original_readers_passed': len(results) == 2}), flush=True)
