from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path.cwd();s=r/'target/continuity-policy-credential-bindings';label=sys.argv[1];package=r/'bindings/swift/ContinuityPackageConsumer';library=s/'native-target/debug/libq_periapt_continuity_c_consumer.dylib'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {str(p.relative_to(r)):sha(p) for part in ['Sources','Tests'] for p in (package/part).rglob('*') if p.is_file()}
before=sources();binary=sha(library);env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPERIAPT_','QPC_TEST_','SWIFT_'))}
argv=['/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/swift','test','--package-path',str(package),'--scratch-path',str(s/'swift-build'),'--configuration','debug','-j','2','-Xswiftc','-warnings-as-errors','-Xcc','-I'+str(r/'bindings/c/ContinuityPackageConsumer'),'-Xlinker','-L'+str(library.parent),'-Xlinker','-rpath','-Xlinker',str(library.parent)]
if len(sys.argv)>2:argv+=['--filter',sys.argv[2]]
start=time.time()
with (s/(label+'.stdout')).open('xb') as out,(s/(label+'.stderr')).open('xb') as err:
 p=subprocess.run(argv,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=600)
receipt={'argv':argv,'exit_status':p.returncode,'elapsed_seconds':time.time()-start,'source_inputs':before,'sources_unchanged':sources()==before,'native_sha256':binary,'native_unchanged':sha(library)==binary,'scope':'source-linked Swift regression, not installed package/platform qualification'}
with (s/(label+'.json')).open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k!='source_inputs'}));raise SystemExit(p.returncode)
