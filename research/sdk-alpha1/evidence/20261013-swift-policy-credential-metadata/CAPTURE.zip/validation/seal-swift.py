from pathlib import Path
import hashlib,json,subprocess,zipfile,os
import rust_sdk_profile as sdk
r=Path.cwd();s=r/'target/continuity-policy-credential-bindings';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();sdk.require(base=='986ef66c13624e4b8203d1523ed4c350669ec6e2','base drift')
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();sdk.require(len(paths)==6 and all(n.startswith('bindings/swift/ContinuityPackageConsumer/') or n in ['artifact/continuity_swift_consumer.py','artifact/test_continuity_swift_consumer.py'] for n in paths),'unexpected changes')
red=load(s/'swift-red-01.json');green=load(s/'swift-green-all-01.json')
sdk.require(red['exit_status']==1 and 'malformedOutput' in (s/'swift-red-01.stdout').read_text(),'red absent')
sdk.require(green['exit_status']==0 and green['sources_unchanged'] and green['native_unchanged'],'green absent')
for n,d in green['source_inputs'].items():sdk.require(sha(r/n)==d,'Swift source drift')
for n,d in load(r/'target/continuity-witness-policy-credential-cycle/DEVICE_QUALIFIED_NATIVE_V3_RESULT.json')['source_inputs'].items():sdk.require(sha(r/n)==d,'core source drift')
for p in (s/'c-consumer').rglob('*'):
 if p.is_file() and 'target' not in p.relative_to(s/'c-consumer').parts and p.name not in ['Cargo.toml','Cargo.lock']:
  sdk.require(sha(p)==sha(r/'bindings/c/ContinuityPackageConsumer'/p.relative_to(s/'c-consumer')),'native fixture drift')
members={}
for p in s.iterdir():
 if p.is_file() and p.name!='seal-swift.log':members['validation/'+p.name]=p
for n in paths:members['source/'+n]=r/n
for n in ['Cargo.toml','Cargo.lock']:members['isolated-native/'+n]=s/'c-consumer'/n
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())}
dest=r/'research/sdk-alpha1/evidence/20261013-swift-policy-credential-metadata';dest.mkdir()
with zipfile.ZipFile(dest/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(dest/'CAPTURE.zip') as z:
 sdk.require(z.testzip() is None,'archive invalid')
 for n,v in manifest.items():sdk.require(hashlib.sha256(z.read(n)).hexdigest()==v['sha256'],'archive digest')
sdk.write_json(dest/'CHECKS.json',{'completed':True,'base_commit':base,'source_overlay':{n:sha(r/n) for n in paths},'red_failure':'valid retained-P metadata rejected as malformedOutput','swift_tests':71,'inventory_controls':7,'native_sha256':green['native_sha256'],'scope':'source-linked Swift canonical metadata and owner regression; not installed package lifecycle or physical-device qualification','release_claim_eligible':False,'capture_sha256':sha(dest/'CAPTURE.zip')})
(dest/'README.md').write_text('''# Swift retained independent policy metadata

The extended Swift renewal reader previously accepted joint-T format 02 only. A source-linked regression using the current native C library reproduced malformedOutput for a valid QPCRNP03 proposal. The reader now distinguishes plain G, joint T and retained independent P. Proposals and target-free cancellations expose independentPolicyStatement as PolicyRenewalStatementID; policyStatement retains its joint-T meaning. Format 03 requires carry mode zero and a nonzero statement, never an adopting transaction. Metadata still supplies no approval or current authority.

All 71 Swift owner tests passed with warnings treated as errors, including the new positive case and malformed-length, missing-statement, invalid-mode and unknown-version cases. Existing plain/joint forms and fixed-size readers retain their domains. Seven exact-inventory controls passed. The red and green receipts bind unchanged source and the same native library. The isolated native build first failed because this unpublished consumer requires installed or explicit source dependencies; a diagnostic build then exposed five unused source patches. Those unused entries were removed, and locked offline native rebuild and metadata resolution completed without warnings. No product manifest or lockfile was changed.

CAPTURE.zip contains source overlays, source-linked build inputs, red/green logs and receipts, with per-member hashes. No native binary, private key or device state is included. This qualifies the Swift metadata repair, not an installed Swift P/G session workflow, Android, physical-device behavior or full release. Those lifecycle gates remain open.
''')
files=paths+[str((dest/n).relative_to(r)) for n in ['CAPTURE.zip','CHECKS.json','README.md']]
sdk.command(['git','add','--',*files],s/'swift-commit-stage',r);sdk.command(['git','diff','--cached','--check'],s/'swift-commit-check',r)
staged=sdk.command(['git','diff','--cached','--name-only'],s/'swift-commit-paths',r).decode().splitlines();sdk.require(set(staged)==set(files),'unexpected staged input')
sdk.command(['git','commit','-m','Distinguish retained independent policy metadata in Swift'],s/'swift-commit',r)
head=sdk.command(['git','rev-parse','HEAD'],s/'swift-head',r).decode().strip();sdk.require(not sdk.command(['git','status','--porcelain'],s/'swift-main-status',r),'main not clean')
clone=r/'target/continuity-browser-publication/source';sdk.require(not sdk.command(['git','status','--porcelain'],s/'swift-clone-before',clone),'clone not clean')
sdk.command(['git','fetch',str(r),'HEAD'],s/'swift-clone-fetch',clone);sdk.command(['git','checkout','--detach',head],s/'swift-clone-checkout',clone)
env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PYTHONPATH='artifact')
sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',sdk.snapshot(clone/'artifact/results.json').sha256,head],s/'swift-source-gate',clone,environment=env)
sdk.write_json(s/'SWIFT_FINALIZED.json',{'head':head,'source_gate':'passed','pushed':False,'installed_lifecycle_qualified':False});print(head)
