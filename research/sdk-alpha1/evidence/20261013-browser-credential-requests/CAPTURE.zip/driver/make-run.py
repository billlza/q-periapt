from pathlib import Path
root=Path.cwd();stage=root/'target/continuity-browser-credential-renewal'
text=(root/'target/continuity-browser-roster/run.py').read_text()
text=text.replace('continuity-browser-roster','continuity-browser-credential-renewal').replace('roster-package-02','credential-request-package-01').replace('q-periapt-browser-roster-authority','q-periapt-browser-credential-authority').replace('import contextlib,json,os,sys,uuid,shutil','import contextlib,json,os,sys,uuid,shutil,time')
start=text.index('allowed=');end=text.index('\n\ndef browser',start)
text=text[:start]+"allowed={'local','required','expired-required','no-local-fallback','wrong-witness','read-loss','cancel'}\nsdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0"+text[end:]
text=text.replace('installed browser original enrollment roster workflows, same native signed witness implementation and loopback; no independent implementation/deployment/release claim','installed browser public credential renewal requests and independently held native issuer pins; same Rust engine and loopback, not renewal commit or independent protocol implementation')
start=text.index('   for case in sys.argv[2:]:');end=text.index("  finally:browser(['close'],'close')",start)
text=text[:start]+(stage/'body.py.txt').read_text()+text[end:]
(stage/'run.py').write_text(text)
