from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-credential-renewal';clone=root/'target/continuity-browser-publication/source'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay-paths',root).decode().splitlines();overlay={}
for name in paths:
 p=root/name;overlay[name]=sdk.snapshot(p).sha256;dest=clone/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'cdb847cc6352c791b06b49c2f4a3f2fbf74311a7','overlay':overlay,'source':str(clone)})
script=(root/'target/continuity-browser-roster/build-package.sh').read_text().replace('roster-package-01','credential-request-package-01').replace('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup',str(stage/'rustup'))
(stage/'build-package.sh').write_text(script)
old=root/'target/continuity-browser-roster'
for name in ['worker.js','controller.js','server.py']:shutil.copyfile(old/name,stage/name)
(stage/'base-browser.py').write_text((old/'base-browser.py').read_text().replace('continuity-browser-roster','continuity-browser-credential-renewal').replace('roster-package-02','credential-request-package-01'))
authority=stage/'authority';(authority/'src').mkdir(parents=True)
for name in ['Cargo.toml','Cargo.lock']:
 (authority/name).write_text((old/'authority'/name).read_text().replace('q-periapt-browser-roster-authority','q-periapt-browser-credential-authority'))
