"""Bounded loopback harness; each request reopens the independent native witness."""
from contextlib import contextmanager
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import hashlib,json,re,subprocess,threading,time
from urllib.parse import urlsplit,parse_qs

@contextmanager
def serving(web:Path, output:Path, private:Path, binary:Path):
    captures=output/'captures';captures.mkdir(mode=0o700)
    traces=output/'witness';traces.mkdir(mode=0o700)
    records={};locks={};faulted=set();failures=[];counter={};mode_counts={}
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self,*args,**kw):super().__init__(*args,directory=str(web),**kw)
        def setup(self):self.request.settimeout(10);super().setup()
        def log_message(self,*args):pass  # Protocol records below, not raw URL/credential logs.
        def end_headers(self):
            self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp');self.send_header('Cache-Control','no-store');super().end_headers()
        def do_GET(self):
            match=re.fullmatch(r'/status/([a-z0-9-]+)',self.path)
            if match:
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(records.get(match[1],[])).encode());return
            super().do_GET()
        def do_POST(self):
            target=urlsplit(self.path);capture=re.fullmatch(r'/capture/([a-z0-9-]+)\.(bin|json)',target.path)
            witness=re.fullmatch(r'/witness/([a-z0-9-]+)',target.path)
            length=self.headers.get('Content-Length','')
            if self.headers.get('Origin')!=origin or not length.isdecimal() or not 0<int(length)<=131072:
                self.send_error(400);return
            data=self.rfile.read(int(length))
            if len(data)!=int(length):self.send_error(400);return
            if target.path.startswith('/carrier/'):
                name=target.path.removeprefix('/carrier/')
                if self.headers.get('Cookie') or self.headers.get('Authorization'):self.send_error(401);return
                if name=='status':self.send_response(503);self.end_headers();return
                if name=='redirect':self.send_response(302);self.send_header('Location','/carrier/unexpected');self.end_headers();return
                if name not in ['short','overflow','slow']:self.send_error(400);return
                if name=='slow':time.sleep(1)
                self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.end_headers()
                try:self.wfile.write(bytes(3658 if name=='short' else 3660 if name=='overflow' else 3659))
                except (BrokenPipeError,ConnectionResetError):
                    if name!='slow':raise
                return
            if capture:
                path=captures/(capture[1]+'.'+capture[2])
                try:
                    with path.open('xb') as f:f.write(data)
                except FileExistsError:self.send_error(409);return
                self.send_response(201);self.end_headers();self.wfile.write(b'captured');return
            if not witness or len(data)!=3674:self.send_error(400);return
            case=witness[1];directory=private/case;genesis=captures/(case+'-genesis.json')
            mode=parse_qs(target.query).get('mode',['normal'])
            if len(mode)!=1 or mode[0] not in ['normal','drop-after-advance','timeout-after-advance','hold-after-advance','corrupt','oversized','drop-ack','drop-read','hold-read'] or not directory.is_dir() or not genesis.is_file():self.send_error(400);return
            mode=mode[0]
            lock=locks.setdefault(case,threading.Lock())
            if not lock.acquire(blocking=False):self.send_error(503);return
            try:
                number=counter.get(case,0)+1;counter[case]=number
                folder=traces/case;folder.mkdir(mode=0o700,exist_ok=True)
                prefix=folder/f'{number:03}'
                request=prefix.with_suffix('.request');request.write_bytes(data)
                reply=prefix.with_suffix('.reply');trace=prefix.with_suffix('.json')
                if self.headers.get('Cookie') or self.headers.get('Authorization'):raise ValueError('ambient credentials sent')
                argv=[str(binary),'handle',str(directory),str(genesis),str(request),str(reply),str(trace)]
                with prefix.with_suffix('.stdout').open('xb') as out,prefix.with_suffix('.stderr').open('xb') as err:
                    completed=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=10,check=False)
                if completed.returncode:raise ValueError('native witness failed: '+case+'/'+str(number))
                body=reply.read_bytes()
                if len(body)!=3659:raise ValueError('native reply width')
                record=json.loads(trace.read_text());record.update(number=number,mode=mode,request_sha256=hashlib.sha256(data).hexdigest(),reply_sha256=hashlib.sha256(body).hexdigest())
                records.setdefault(case,[]).append(record)
                mode_counts[(case,mode)]=mode_counts.get((case,mode),0)+1
                trigger=case not in faulted and (mode_counts[(case,mode)]==3 if mode=='drop-ack' else record['changed'] if 'advance' in mode else mode!='normal')
                record['trigger']=trigger
                if trigger:faulted.add(case)
                (folder/'RECORDS.json').write_text(json.dumps(records[case],indent=2)+'\n')
            except Exception as error:
                failures.append(str(error));self.send_error(500);return
            finally:lock.release()
            if trigger and mode in ['drop-after-advance','drop-ack','drop-read']:self.close_connection=True;return
            if trigger and mode in ['timeout-after-advance','hold-after-advance','hold-read']:
                time.sleep(7);self.close_connection=True;return
            if trigger and mode=='corrupt':body=body[:-1]+bytes([body[-1]^1])
            if trigger and mode=='oversized':body+=b'\0'
            self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(len(body)));self.end_headers()
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError) as error:
                failures.append('unexpected client disconnect: '+case+'/'+str(number)+': '+type(error).__name__)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=False
    origin=f'http://127.0.0.1:{server.server_port}';thread=threading.Thread(target=server.serve_forever);thread.start()
    try:yield origin,records,failures
    finally:
        server.shutdown();server.server_close();thread.join(timeout=5)
        if thread.is_alive():raise RuntimeError('fixture server did not stop')
