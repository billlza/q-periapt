import Foundation
import Darwin
import QPeriaptContinuity

@main
struct ContinuityIOSRunner {
    static func main() async {
        do {
            let argv = Array(CommandLine.arguments.dropFirst())
            guard argv.count == 4, argv.allSatisfy({ !$0.isEmpty && $0.utf8.count < 128 }),
                  ["fixed", "recoverable"].contains(argv[1]),
                  argv[2].count == 32, argv[2].allSatisfy({ "0123456789abcdef".contains($0) }),
                  argv[3].count == 32, argv[3].allSatisfy({ "0123456789abcdef".contains($0) }) else {
                throw ClientError("explicit operation/profile/case/run required")
            }
            let mode = argv[0], profile = argv[1], scenario = argv[2], run = argv[3]
            let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let input = documents.appendingPathComponent("inputs-" + scenario, isDirectory: true)
            let privateRoot = documents.appendingPathComponent("private-continuity", isDirectory: true)
            if !FileManager.default.fileExists(atPath: privateRoot.path) {
                try FileManager.default.createDirectory(at: privateRoot, withIntermediateDirectories: false,
                    attributes: [.posixPermissions: 0o700])
            }
            guard let resolved = realpath(privateRoot.path, nil) else {
                throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
            }
            let canonicalRoot = String(cString: resolved)
            free(resolved)
            let base = canonicalRoot + "/installation-" + scenario
            let target = URL(fileURLWithPath: base, isDirectory: true)
            let output = documents.appendingPathComponent("result-" + run + ".bin")
            if mode == "resume" {
                try storageBoundary(input: input.path, target: base, profile: profile, output: output.path + ".refused", run: run)
            }
            try ConfigurationCommands.run(["ContinuityIOSRunner", mode, profile, input.path,
                mode == "cancel-create" || mode == "arc-capacity" ? base + "." + run : base, output.path])
            if ["create", "resume", "reconcile", "enroll-local"].contains(mode) {
                let required = ["wrap.key", "signer.key", "enrollment.redb"] + (mode == "enroll-local" ? ["installation.redb"] : [])
                guard required.allSatisfy({ FileManager.default.fileExists(atPath: target.appendingPathComponent($0).path) }) else {
                    throw ClientError("missing original private storage")
                }
            }
            let marker = "QPC_IOS_CONFIGURATION_PASS mode=\(mode) profile=\(profile) run=\(run)\n"
            let receipt = documents.appendingPathComponent("receipt-" + run + ".txt")
            try Data(marker.utf8).write(to: receipt, options: .withoutOverwriting)
            try FileHandle.standardOutput.write(contentsOf: Data(marker.utf8))
            exit(0)
        } catch {
            do { try FileHandle.standardError.write(contentsOf: Data("QPC_IOS_CONFIGURATION_FAIL \(error)\n".utf8)) }
            catch { exit(74) }
            exit(1)
        }
    }
}

private func storageBoundary(input: String, target: String, profile: String, output: String, run: String) throws {
    let alias = target + ".alias-" + run
    guard symlink(target, alias) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let linkOutcome = Result { try expect(203) {
        try ConfigurationCommands.run(["ContinuityIOSRunner", "resume", profile, input, alias, output])
    } }
    guard unlink(alias) == 0 else { throw ClientError("test alias cleanup failed") }
    try linkOutcome.get()
    let permissions = try FileManager.default.attributesOfItem(atPath: target)[.posixPermissions] as? NSNumber
    guard permissions?.intValue == 0o700 else { throw ClientError("unexpected private target permissions") }
    guard chmod(target, 0o755) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let modeOutcome = Result { try expect(203) {
        try ConfigurationCommands.run(["ContinuityIOSRunner", "resume", profile, input, target, output])
    } }
    guard chmod(target, 0o700) == 0 else { throw ClientError("private permissions restoration failed") }
    try modeOutcome.get()
    guard !FileManager.default.fileExists(atPath: output) else { throw ClientError("refused path produced output") }
    print("QPC_IOS_STORAGE_BOUNDARY_PASS symlink=203 mode=203")
}
