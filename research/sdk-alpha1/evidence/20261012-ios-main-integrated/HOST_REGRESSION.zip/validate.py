from pathlib import Path
import json,hashlib
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-ios-main-integration';prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text());env=dict(prior['environment'],CARGO_TARGET_DIR=str(out/'rust-build'));tool=Path(env['RUSTC']).parent
files=['lib.rs','macos_acl.rs','filesystem.rs','filesystem/publication.rs','filesystem/directory_publication.rs'];inputs={n:hashlib.sha256((root/'crates/q-periapt-host-store/src'/n).read_bytes()).hexdigest() for n in files};state={'completed':False,'live_producer':True,'inputs':inputs};(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 sdk.command([str(tool/'cargo'),'test','-p','q-periapt-host-store','--lib','--offline','--locked','-j','2'],out/'host-store-tests',root,environment=env)
 sdk.command([str(tool/'cargo'),'clippy','-p','q-periapt-host-store','--all-targets','--offline','--locked','-j','2','--','-D','warnings'],out/'host-store-clippy',root,environment=env)
 assert all(hashlib.sha256((root/'crates/q-periapt-host-store/src'/n).read_bytes()).hexdigest()==h for n,h in inputs.items());state['completed']=True
finally:
 state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Main iOS storage integration: host-store tests and clippy passed',flush=True)
