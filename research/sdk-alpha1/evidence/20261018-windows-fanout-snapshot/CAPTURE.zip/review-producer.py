import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'artifact'))
from evidence_io import parse_strict_json_bytes as parsed
import continuity_package_archive as bundle
import continuity_package as candidate
from continuity_c_consumer import EXPORTS

HEAD = '6b97539412d81569563cb0bbb3d579ec00acaaaf'
RUN = 39113443714
ARTIFACT = 12132045289
raw = (OUT / 'producer.zip').read_bytes()
assert len(raw) == 8704257
assert hashlib.sha256(raw).hexdigest() == '5d949a1f8d5ae3e3e0d5606cc0acd1ae1bdb5258432930ae7c87ed37eacaed3b'
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
with zipfile.ZipFile(io.BytesIO(raw)) as outer:
    assert len(outer.namelist()) == len(set(outer.namelist()))
    receipt = parsed(outer.read('INPUT.json'), label='producer receipt')
    assert receipt['source_commit'] == HEAD
    assert receipt['sdk_commit'] == 'a2b819728032d44c350859fdd3ed4a4fee9e6341'
    assert receipt['exports'] == sorted(EXPORTS) and len(EXPORTS) == 157
    assert outer.read('source-head.stdout').decode().strip() == HEAD
    assert not outer.read('source-status.stdout')
    payload = outer.read('consumer.zip')
    assert hashlib.sha256(payload).hexdigest() == receipt['zip_sha256']
    bundle.unpack(payload, receipt['files'], OUT / 'input')
    prefix = 'bindings/c/ContinuityPackageConsumer/'
    tracked = git('ls-tree', '-r', '--name-only', HEAD, '--', prefix).decode().splitlines()
    configuration_inputs = {'tests/common/' + name + '.rs' for name in (
        'recovery_inputs', 'credential_request', 'first_account', 'first_connection',
        'first_credential', 'first_expiry', 'first_policy', 'first_policy_credential',
        'peer_bundle', 'policy_request', 'receiver_policy', 'receiver_process',
        'witness', 'witness_tls', 'witness_tls_faults', 'witness_tls_relay')}
    expected = {p for p in tracked if p[len(prefix):].startswith('src/') or
                p[len(prefix):] in ('Cargo.toml', 'tests/c_owner.rs', 'tests/root.rs', 'tests/first_configuration.rs') or p[len(prefix):] in configuration_inputs or
                p[len(prefix):].startswith('tests/root/') or
                '/' not in p[len(prefix):] and p.endswith(('.c', '.h'))}
    assert set(receipt['source_files']) == expected
    with zipfile.ZipFile(io.BytesIO(payload)) as content:
        for name in expected:
            source = git('show', f'{HEAD}:{name}')
            assert hashlib.sha256(source).hexdigest() == receipt['source_files'][name], name
            if name != prefix + 'Cargo.toml':
                assert content.read(name[len(prefix):]) == source, name
        original_manifest = git('show', f'{HEAD}:{prefix}Cargo.toml').decode()
        for target in ('configuration_paths', 'owned_connection'):
            original_manifest += f'\n[[test]]\nname = "{target}"\npath = "packages/q-periapt-continuity-identity-candidate-0.0.0/tests/{target}.rs"\n'
        original_manifest += '\n[patch.crates-io]\n'
        # The producer inserts nine SDK crates followed by the candidate.
        import rust_sdk_profile as sdk
        names = [*sdk.CONSUMER_CRATES, candidate.NAME]
        original_manifest += ''.join(f'{name} = {{ path = "packages/{name}-{receipt["versions"][name]}" }}\n' for name in names)
        assert content.read('Cargo.toml') == original_manifest.encode()
        source_root = 'research/continuity-identity-candidate/'
        source_names = git('ls-tree', '-r', '--name-only', HEAD, '--', source_root).decode().splitlines()
        rust_names = {p for p in source_names if p.endswith('.rs')}
        shipped_rust = {source_root + p.split('/', 2)[2] for p in content.namelist()
                        if p.startswith(f'packages/{candidate.NAME}-{candidate.VERSION}/') and p.endswith('.rs')}
        assert shipped_rust == rust_names
        for name in rust_names:
            packaged = f'packages/{candidate.NAME}-{candidate.VERSION}/' + name[len(source_root):]
            assert content.read(packaged) == git('show', f'{HEAD}:{name}'), name
        old_raw = (ROOT / 'target/windows-root-7d-01/producer.zip').read_bytes()
        assert hashlib.sha256(old_raw).hexdigest() == '7c02272d3fba4d89a77d80a32e08c57480f7ae21167684b45198bae42825202c'
        with zipfile.ZipFile(io.BytesIO(old_raw)) as old:
            old_receipt = parsed(old.read('INPUT.json'), label='prior admitted source closure')
            sdk_archives = set(receipt['archives']) - {candidate.NAME}
            assert len(sdk_archives) == 9 and set(receipt['archives']) == set(old_receipt['archives'])
            for name in sdk_archives:
                assert receipt['archives'][name] == old_receipt['archives'][name]
            assert receipt['archives'][candidate.NAME] != old_receipt['archives'][candidate.NAME]
            with zipfile.ZipFile(io.BytesIO(old.read('consumer.zip'))) as old_content:
                package_names = {p for p in content.namelist() if p.startswith('packages/')}
                assert package_names == {p for p in old_content.namelist() if p.startswith('packages/')}
                changed_members = {name for name in package_names if content.read(name) != old_content.read(name)}
                candidate_prefix = f'packages/{candidate.NAME}-{candidate.VERSION}/'
                assert changed_members == {candidate_prefix + name for name in (
                    'README.md', 'src/durable/messages/fanout.rs')}, sorted(changed_members)
                for name in changed_members:
                    assert content.read(name) == git('show', f'{HEAD}:{source_root}' + name.removeprefix(candidate_prefix)), name
        archive = outer.read(f'{candidate.NAME}-{candidate.VERSION}.crate')
        archive_record = receipt['archives'][candidate.NAME]
        assert archive_record == {'bytes': len(archive), 'sha256': hashlib.sha256(archive).hexdigest()}
        members = candidate.validate_candidate(archive, set(outer.read('package-list.stdout').decode().splitlines()))
        for name, data in members.items():
            assert data == content.read(f'packages/{candidate.NAME}-{candidate.VERSION}/{name}')
report = {'head': HEAD, 'run': RUN, 'artifact': ARTIFACT, 'artifact_bytes': len(raw),
          'artifact_sha256': hashlib.sha256(raw).hexdigest(), 'payload_members': len(receipt['files']),
          'facade_sources_verified': len(expected), 'candidate_Rust_sources_independently_verified': len(rust_names),
          'nine_sdk_archives_and_package_bytes_unchanged_from_7d': True,
          'candidate_changed_members_from_7d': sorted(changed_members), 'declared_exports': len(EXPORTS),
          'scope': 'Producer source closure only; native controls and installed lifecycle remain separate.'}
with (OUT / 'PRODUCER_REVIEW.json').open('x') as output:
    json.dump(report, output, indent=2)
    output.write('\n')
print(json.dumps(report))
