from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import subprocess
import zipfile
import tomllib

OUT = Path(__file__).resolve().parent
RUN = 39113443780
HEAD = '6b97539412d81569563cb0bbb3d579ec00acaaaf'

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def api(path):
    return subprocess.run(['gh', 'api', 'repos/billlza/q-periapt/' + path],
                          capture_output=True, check=True, timeout=60).stdout

run = json.loads(api(f'actions/runs/{RUN}'))
require(run['head_sha'] == HEAD and run['status'] == 'completed'
        and run['conclusion'] == 'success', 'native run is not successful at expected source')
(OUT / 'native-run.json').write_text(json.dumps(run, indent=2) + '\n')
metadata = json.loads(api(f'actions/runs/{RUN}/artifacts?per_page=100'))
(OUT / 'native-artifacts.json').write_text(json.dumps(metadata, indent=2) + '\n')
expected_names = {f'private-store-windows-{os}-{rust}' for os in (2022, 2025)
                  for rust in ('1.90.0', '1.98.1')}
require(metadata['total_count'] == 4
        and {x['name'] for x in metadata['artifacts']} == expected_names, 'artifact matrix differs')
records = []
for artifact in metadata['artifacts']:
    require(not artifact['expired'] and artifact['workflow_run']['head_sha'] == HEAD,
            'artifact source or retention differs')
    path = OUT / f"artifact-{artifact['id']}.zip"
    if not path.exists():
        with path.open('xb') as stream:
            stream.write(api(f"actions/artifacts/{artifact['id']}/zip"))
    data = path.read_bytes()
    require(len(data) == artifact['size_in_bytes']
            and 'sha256:' + hashlib.sha256(data).hexdigest() == artifact['digest'],
            'downloaded archive integrity differs')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) == 23 and all('/' not in n and '\\' not in n for n in names),
                'unexpected archive members')
        contents = {n: archive.read(n) for n in names}
    text = {n: re.sub(r'\x1b\[[0-9;]*m', '', b.decode('utf-8-sig')) for n, b in contents.items()}
    compiler = artifact['name'].rsplit('-', 1)[1]
    require(text['commit.txt'].strip() == HEAD and 'release: ' + compiler in text['rustc.txt']
            and 'host: x86_64-pc-windows-msvc' in text['rustc.txt'], 'compiled provenance differs')
    for name in ('clippy.log', 'client-clippy.log', 'consumer-clippy.log', 'consumer-release.log', 'first-use-clippy.log'):
        require('Finished' in text[name] and not re.search(r'(?m)^(?:error|warning)\b', text[name]),
                'strict compile diagnostics')
    for name, log in text.items():
        if name.endswith('.log'):
            require(not re.search(r'(?m)^\s*(?:error|warning)(?:\[|:)', log),
                    'unexpected diagnostic in ' + name)
    profiles = {}
    for name in ('path-tests.log', 'path-release-tests.log'):
        log = text[name].replace('\r', '')
        cases = re.findall(r'(?m)^test (\w+) \.\.\. ok$', log)
        expected = {'local_absolute_paths_are_admitted',
                    'noncanonical_or_nonlocal_paths_are_rejected_at_every_position',
                    'every_duplicate_pair_is_rejected', 'non_utf8_paths_are_rejected'}
        require(len(cases) == 4 and set(cases) == expected,
                'public path admission case census differs')
        require('test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log,
                'public path admission result differs')
        profiles[name] = {'tests_passed':4, 'cases':sorted(cases),
                          'scope':'Public lexical path constructors on real Windows, not filesystem or lifecycle admission'}
    for name in ('tests.log', 'release-tests.log'):
        log = text[name]
        require('test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log,
                'host-store test census differs')
        faults = re.findall(r'DATABASE_PUBLICATION_FAULT cut=(\w+) original_error_preserved=true owner_returned=false', log)
        require(set(faults) == {'BeforeFileSync','FileSynced','BeforeRename','Published','BeforeDirectorySync','DirectorySynced'}
                and len(faults) == 6, 'publication fault coverage differs')
        cuts = re.findall(r'DATABASE_PUBLICATION_PROCESS_CUT cut=([\w-]+) published=(true|false) original_owner_returned=false', log)
        require(dict(cuts) == {'before-commit':'false','after-commit':'false','FileSynced':'false',
                               'Published':'true','DirectorySynced':'true'} and len(cuts) == 5,
                'process-cut observations differ')
        require('DATABASE_INITIALIZATION_SYNC count=8 before_after_faults=16' in log,
                'actual database sync census differs')
        profiles[name] = {'tests_passed':30,'sync_faults':16,'publication_faults':6,'process_cuts':5}
    for name in ('client-tests.log', 'client-release-tests.log'):
        log = text[name]
        require(re.search(r'test result: ok\. 4 passed; 0 failed; 0 ignored; 0 measured;', log),
                'client reopen test census differs')
        faults = re.findall(r'WINDOWS_KEY_REOPEN_FAULT boundary=(\w+) after=(true|false) exact_error=true owner_returned=false bytes_preserved=true', log)
        require(set(faults) == {(b, a) for b in ('WrappingFile','WrappingDirectory','SigningFile','SigningDirectory')
                               for a in ('true','false')} and len(faults) == 8,
                'client sync failure boundaries differ')
        acl = re.findall(r'WINDOWS_KEY_REOPEN_ACL boundary=(\w+) actual_acl_changed=true owner_returned=false original_recovered=true', log)
        require(set(acl) == {'WrappingDirectory','SigningDirectory'} and len(acl) == 2,
                'actual ACL change cases differ')
        require('WINDOWS_KEY_REOPEN signing_roles=4 file_then_parent_sync=true' in log
                and 'WINDOWS_KEY_REOPEN wrapping=true file_then_parent_sync=true' in log,
                'positive reopen markers missing')
        profiles[name] = {'tests_passed':4,'sync_faults':8,'actual_acl_changes':2,'signing_roles':4}
    for name in ('retirement-tests.log', 'retirement-release-tests.log'):
        log = text[name]
        cases = re.findall(r'(?m)^test crypto::persistence::retirement::tests::(\w+) \.\.\. ok$', log.replace('\r', ''))
        expected = {
            'signer_retirement_roundtrip_is_terminal_and_platform_separated',
            'signer_retirement_refuses_substituted_file_even_with_identical_ciphertext',
            'signer_retirement_refuses_modified_ciphertext_and_unrelated_report',
            'signer_retirement_metadata_checks_keep_exclusive_lock',
            'signer_retirement_partial_headers_and_io_boundaries_never_return_success',
        }
        require(set(cases) == expected and len(cases) == 5, 'retirement case census differs')
        require('test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured;' in log,
                'retirement result differs')
        require(log.count('NATIVE_SIGNER_RETIREMENT partial_headers=9 io_boundaries=10 exact_retry=true authenticated_ack=true') == 1,
                'retirement fault coverage differs')
        profiles[name] = {'tests_passed':5,'partial_headers':9,'io_boundaries':10,
                          'authenticated_host_ACK':True,'substitution_refused':True,
                          'metadata_preserves_lock':True}
    for name in ('tests.log', 'release-tests.log'):
        for case in ('configuration_reads_are_bounded_read_only_and_never_create',
                     'configuration_refuses_links_nested_paths_and_changed_file_acl',
                     'configuration_keeps_pinned_parent_and_rechecks_its_acl'):
            require(f'test filesystem::windows::configuration_tests::{case} ... ok' in text[name],
                    'configuration read case absent')
    consumer = json.loads(text['consumer-library.json'])
    require(consumer['source'] == HEAD and type(consumer['bytes']) is int and consumer['bytes'] > 0
            and re.fullmatch('[0-9a-f]{64}', consumer['sha256'])
            and consumer['scope'] == 'Windows source facade compilation only; no installed-package or runtime qualification',
            'consumer source build receipt differs')
    # The binary digest is a CI producer observation; the DLL is not downloaded here.
    # Archive integrity checks apply to the retained logs/metadata/receipt above.
    consumer_metadata = json.loads(text['consumer-metadata.json'])
    packages = consumer_metadata['packages']
    target_package = [p for p in packages if p['name'] == 'q-periapt-continuity-c-consumer']
    require(len(target_package) == 1 and target_package[0]['source'] is None, 'consumer package identity')
    roots = set(consumer_metadata['workspace_members'])
    require(roots == {target_package[0]['id']}, 'source consumer must be its own workspace')
    locked = tomllib.loads(text['consumer-Cargo.lock'])['package']
    baseline_text = subprocess.check_output(['git', '-C', str(OUT.parents[1]), 'show', HEAD + ':research/continuity-identity-candidate/Cargo.lock'], text=True)
    baseline = tomllib.loads(baseline_text)['package']
    def package_identity(p):
        return (p['name'], p['version'], p.get('source'), p.get('checksum'))
    original = {package_identity(p) for p in baseline}
    extra = {package_identity(p) for p in locked} - original
    require(extra == {('q-periapt-continuity-c-consumer', '0.0.0', None, None)},
            f'unexpected dependency identity changes: {extra}')
    expected_local = {p['name'] for p in baseline if 'source' not in p}
    local = {p['name']:p for p in packages if p['source'] is None and p['name'] != 'q-periapt-continuity-c-consumer'}
    require(set(local) == expected_local, 'local source closure differs')
    candidate_suffix = 'research/continuity-identity-candidate/Cargo.toml'
    candidate_path = local['q-periapt-continuity-identity-candidate']['manifest_path'].replace('\\', '/')
    require(candidate_path.endswith('/' + candidate_suffix), 'candidate source path differs')
    source_root = candidate_path[:-len(candidate_suffix)]
    template = subprocess.check_output(['git', '-C', str(OUT.parents[1]), 'show', HEAD + ':bindings/c/ContinuityPackageConsumer/Cargo.toml'], text=True)
    assembled = tomllib.loads(text['consumer-Cargo.toml'])
    patches = assembled.pop('patch')['crates-io']
    require(assembled == tomllib.loads(template) and set(patches) == expected_local,
            'consumer manifest changed beyond declared source patches')
    for name, item in local.items():
        suffix = ('research/continuity-identity-candidate/Cargo.toml' if name == 'q-periapt-continuity-identity-candidate'
                  else 'crates/' + name + '/Cargo.toml')
        require(item['manifest_path'].replace('\\', '/') == source_root + suffix, 'dependency did not resolve to same source checkout')
        require(patches[name] == {'path': source_root + suffix.removesuffix('/Cargo.toml')}, 'manifest source patch differs')
    node = next(n for n in consumer_metadata['resolve']['nodes'] if n['id'] == local['q-periapt-continuity-identity-candidate']['id'])
    require({'connection-tls', 'control-tls', 'anchor-tls'} <= set(node['features']), 'native TLS features missing')
    profiles['configuration'] = {'tests_passed':3,'read_only':True,'pinned_parent':True,'actual_acl_changes':2}
    profiles['C_facade'] = {'source_build':True,'strict_clippy':True,'release_link':True,
                          'runtime_qualified':False,'package_qualified':False,
                          'observed_DLL_bytes':consumer['bytes'],'producer_DLL_sha256':consumer['sha256']}
    directory_stages = {'Created','Initialized','BeforeStagingSync','StagingSynced','BeforeRename','Published','BeforeParentSync','ParentSynced'}
    process_stages = {'Initialized':'false','BeforeRename':'false','Published':'true','ParentSynced':'true'}
    access_results = {}
    for name in ('tests.log', 'release-tests.log'):
        log = text[name]
        faults = re.findall(r'WINDOWS_DIRECTORY_FAULT cut=(\w+) published=(true|false) original_error=true no_returned_value=true', log)
        require(len(faults) == 8 and {a for a,b in faults} == directory_stages, 'directory fault boundaries differ')
        require(all(b == ('true' if a in {'Published','BeforeParentSync','ParentSynced'} else 'false') for a,b in faults), 'directory publication classification differs')
        cuts = re.findall(r'WINDOWS_DIRECTORY_PROCESS cut=(\w+) published=(true|false) no_returned_value=true', log)
        require(len(cuts) == 4 and dict(cuts) == process_stages, 'directory process cuts differ')
        require(log.count('WINDOWS_DIRECTORY_LIVE_CHILD lock_retained_until_rename=true publication_refused=true original_image_preserved=true') == 1, 'live child lease was not checked')
        access = re.findall(r'WINDOWS_DIRECTORY_ACCESS early_delete=(sharing_violation|permitted) no_delete_preparation=passed original_pin_retained=true late_rename=passed', log)
        require(len(access) == 1, 'delete access control missing')
        if 'windows-2022-' in artifact['name']:
            require(access == ['sharing_violation'], 'Windows2022 early-delete counterexample not reproduced')
        access_results[name] = access[0]
        profiles[name]['directory_faults'] = 8
        profiles[name]['directory_process_cuts'] = 4
        profiles[name]['early_delete_control'] = access[0]
    for name in ('first-use-tests.log', 'first-use-release-tests.log'):
        log = text[name]
        require('test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured;' in log, 'first-use test census differs')
        require('first_install::windows_tests::windows_first_use_recoverable_trust_remains_independent_on_reopen ... ok' in log,
                'recoverable first-use case missing')
        require('first_install::windows_tests::windows_first_use_publishes_then_admits_the_exact_original_state ... ok' in log,
                'fixed first-use case missing')
        faults = re.findall(r'WINDOWS_FIRST_USE_FAULT stage=(\w+) published=(true|false) owner_returned=false original_error=true', log)
        expected = {'Prepared':'false','Closed':'false','Published':'true','Admitted':'true'}
        require(len(faults) == 4 and dict(faults) == expected, 'first-use fault boundaries differ')
        cuts = re.findall(r'WINDOWS_FIRST_USE_PROCESS stage=(\w+) published=(true|false) owner_returned=false original_state_preserved=true', log)
        require(len(cuts) == 4 and dict(cuts) == expected, 'first-use process cuts differ')
        races = re.findall(r'WINDOWS_FIRST_USE_CONCURRENT outcome=(\w+) fresh_admission_refused=true original_state_preserved=true', log)
        require(len(races) == 3 and set(races) == {'busy','changed','missing'}, 'competing first-use outcomes differ')
        profiles[name] = {'tests_passed':7,'child_entrypoints_included':1,'fault_boundaries':4,'actual_process_cuts':4,
                          'actual_competing_process_outcomes':['busy','changed','missing'],
                          'fixed_and_recoverable_trust':True,'scope':'Rust entry of source reference first-use coordinator, not C ABI or installed-package admission'}
    require('test result: ok. 0 passed; 0 failed; 0 ignored;' in text['doc-tests.log'],
            'doc-test command failed')
    records.append({'artifact_id':artifact['id'],'name':artifact['name'],'sha256':artifact['digest'],
                    'bytes':len(data),'compiler':compiler,'profiles':profiles,
                    'members_sha256':{n:hashlib.sha256(b).hexdigest() for n,b in contents.items()}})
receipt = {'schema':1,'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source_commit':HEAD,'run':RUN,'url':run['html_url'],'review_completed':True,
           'artifacts':records,'scope':'Windows public path constructors plus native directory publication and first-use source coordinator fixed/recoverable admission, fault and actual process-cut/competition checks, plus prior storage/key/retirement matrix and C facade source compilation/link. No C ABI execution, installed-package, full session/device lifecycle or power-loss qualification.'}
with (OUT/'NATIVE_REVIEW.json').open('x') as stream:
    stream.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'run':RUN,'source_commit':HEAD,'native_jobs':4,'profiles':8,'review_completed':True}))
