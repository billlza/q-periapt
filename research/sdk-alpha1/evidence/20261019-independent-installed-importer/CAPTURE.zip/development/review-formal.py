"""Execute the final installed importer and verify the exact installed inputs."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent
built = root / "target/independent-installed-01/source-checkout/target/installed-counterpart-03"
head = "b89eb724f4f40388ab7546dab9b7d07c80bf607b"
sys.path.insert(0, str(root / "artifact"))
import continuity_independent_package as installed
import continuity_package as package
import rust_sdk_profile as sdk

def read(path):
    return json.loads(path.read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert read(out / "FORMAL_EXIT.json") == {"exit": 0}
report = read(built / "INSTALLED_COUNTERPART.json")
assert report["completed"] is True and report["sources_unchanged"] is True
assert report["runtime_qualified"] is False and report["source_commit"] == head
assert not report["release_claim_eligible"] and "failure" not in report
for name, expected in report["source_inputs"].items():
    data = subprocess.check_output(["git", "show", head + ":" + name])
    assert sha(data) == expected == sha((root / name).read_bytes()), name
consumer = Path(read(built / "LOCATION.json")["path"]) / "counterpart"
lock = (built / "consumer-Cargo.lock").read_bytes()
original = subprocess.check_output(["git", "show", head + ":research/continuity-openssl-peer/native/Cargo.lock"])
assert installed.verify_graph(read(built / "consumer-metadata.stdout"), consumer, lock, original) == report["resolution"]
assert lock == (consumer / "Cargo.lock").read_bytes()
sdk_report = root / "target/independent-installed-01/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json"
assert sha(sdk_report.read_bytes()) == report["sdk_report_sha256"]
cohort = read(sdk_report)
sdk.verify_consumed_sources(consumer, sdk_report.parent, cohort["crates"], names=installed.PRODUCTS)
candidate = report["candidate_archive"]
body = (built / candidate["file"]).read_bytes()
assert len(body) == candidate["bytes"] and sha(body) == candidate["sha256"]
files = package.validate_candidate(body, set(candidate["files"]))
package.verify_candidate_files(consumer / "packages" / (package.NAME + "-" + package.VERSION), files)
for name in ["consumer-build", "consumer-clippy", "importer-build", "importer-clippy"]:
    receipt = read(built / (name + ".json"))
    assert receipt["returncode"] == 0 and Path(receipt["cwd"]) == consumer
    assert {"--release", "--locked", "--offline"} <= set(receipt["argv"])
    sdk.validate_cargo_output(name, [(built / (name + "." + suffix)).read_text() for suffix in ["stdout", "stderr"]])
for tool in report["tools"].values():
    assert sha(Path(tool["path"]).read_bytes()) == tool["sha256"]
binary = built / "importer"
assert sha(binary.read_bytes()) == report["importer_sha256"]
assert sha((built / "counterpart").read_bytes()) == report["native_sha256"]
prior = read(root / "target/independent-installed-01/REGISTRATION_READBACK.json")
assert report["native_sha256"] == prior["native_sha256"]

base = root / "target/independent-registration-hosted-f7a7-mac-01/public/public-inputs"
records = {}
runtime = out / "final-importer"
runtime.mkdir()
for profile in ["local", "witness"]:
    source = base / profile
    producer = read(source / "RESULT.json")
    target = runtime / profile
    target.mkdir()
    trust = target / "trust"
    trust.mkdir()
    for path in (source / "native-import-trust").iterdir():
        assert path.is_file() and not path.is_symlink()
        (trust / path.name).write_bytes(path.read_bytes())
    operations = []
    for row in producer["native_imports"]:
        case = row["case"]
        wire = (source / (case + ".bundle")).read_bytes()
        assert sha(wire) == row["input_sha256"]
        input_path = target / (case + ".bundle")
        input_path.write_bytes(wire)
        command = [str(binary), str(trust), str(input_path), *row["command"][-2:]]
        process = subprocess.run(command, capture_output=True, timeout=30)
        (target / (case + ".stdout")).write_bytes(process.stdout)
        (target / (case + ".stderr")).write_bytes(process.stderr)
        observed = {"case": case, "argv": command, "exit": process.returncode,
                    "input_sha256": sha(wire), "stdout_sha256": sha(process.stdout),
                    "stderr_sha256": sha(process.stderr)}
        operations.append(observed)
        (target / "OPERATIONS.json").write_text(json.dumps(operations, indent=2) + "\n")
        assert all(observed[k] == row[k] for k in ["exit", "input_sha256", "stdout_sha256", "stderr_sha256"]), case
    records[profile] = {"cases": len(operations), "successful": sum(r["exit"] == 0 for r in operations),
                        "typed_refusals": sum(r["exit"] == 1 for r in operations), "context": producer["context"]}
assert sha(binary.read_bytes()) == report["importer_sha256"]
result = {"head": head, "importer_sha256": report["importer_sha256"],
          "native_sha256": report["native_sha256"], "resolution": report["resolution"],
          "profiles": records, "sdk_report_sha256": report["sdk_report_sha256"],
          "candidate_archive": {k: candidate[k] for k in ["file", "bytes", "sha256"]},
          "registration_link": {"source": "target/independent-installed-01/REGISTRATION_READBACK.json",
                                "same_binary_bytes": True, "new_registration_execution": False},
          "scope": "Clean ordinary-checkout CLI built and linted native/importer from the same installed graph. This exact importer executed20 public-input cases. Native bytes equal the previously executed92-worker21-kill registration binary; registration was not rerun. Fixture trust, not deployed account authentication or a released Python distribution; no full release claim."}
(out / "FORMAL_READBACK.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["head", "importer_sha256", "resolution", "profiles"]}))
