from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time
from bounded_process import capture_output, TimeoutPolicy

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-windows-test-imports'
PRIOR = ROOT / 'target/windows-typecheck-1.98.1-hn2792f5'
TOOLS = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
LLVM = PRIOR / 'gnu-extracted/llvm-mingw-20261104-ucrt-macos-universal'
TARGET = 'x86_64-pc-windows-gnu'
label, mode = sys.argv[1:]
assert label in ['red', 'green', 'clippy', 'format'] and mode in ['check', 'clippy', 'fmt']
stem = BASE / label


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def sources():
    names = subprocess.check_output(['rg', '--files', 'crates', '-g', '*.rs', '-g', '*.toml', '-g', '*.c', '-g', '*.h', '-g', '*.S'], text=True).splitlines()
    names += ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
    return {n: sha(ROOT / n) for n in sorted(set(names))}


assert (LLVM / 'bin/x86_64-w64-mingw32-clang').is_file()
assert (PRIOR / 'sysroot/lib/rustlib' / TARGET / 'lib').is_dir()
overrides = {
    'CARGO_HOME': '/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
    'CARGO_TARGET_DIR': str(PRIOR / 'build-gnu'), 'CARGO_INCREMENTAL': '0',
    'CARGO_NET_OFFLINE': 'true', 'CARGO_TERM_COLOR': 'never',
    'RUSTC': str(TOOLS / 'bin/rustc'), 'RUSTDOC': str(TOOLS / 'bin/rustdoc'),
    'CARGO_TARGET_X86_64_PC_WINDOWS_GNU_RUSTFLAGS': '--sysroot ' + str(PRIOR / 'sysroot') + ' -Dwarnings',
    'CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER': str(LLVM / 'bin/x86_64-w64-mingw32-clang'),
    'CC_x86_64_pc_windows_gnu': str(LLVM / 'bin/x86_64-w64-mingw32-clang'),
    'AR_x86_64_pc_windows_gnu': str(LLVM / 'bin/llvm-ar'),
    'PATH': str(TOOLS / 'bin') + os.pathsep + str(LLVM / 'bin') + os.pathsep + os.environ.get('PATH', os.defpath),
}
environment = {k: v for k, v in os.environ.items()
               if not k.startswith(('CARGO_', 'RUST', 'CC_', 'AR_', 'CFLAGS_', 'CXX_', 'DYLD_', 'LD_'))
               and k not in {'CC', 'AR', 'CFLAGS', 'CXX', 'CPPFLAGS', 'LDFLAGS'}}
environment.update(overrides)
argv = [str(TOOLS / 'bin/cargo'), mode]
if mode == 'fmt':
    argv += ['-p', 'q-periapt-host-store', '--', '--check']
else:
    argv += ['--locked', '--offline', '-p', 'q-periapt-host-store', '--tests', '--target', TARGET, '-j', '2']
    if mode == 'clippy':
        argv += ['--', '-D', 'warnings']
before = sources()
manifest = TOOLS / 'lib/rustlib/multirust-channel-manifest.toml'
state = {'argv': argv, 'environment_overrides': overrides, 'started_utc': datetime.now(timezone.utc).isoformat(),
    'source_before': before, 'global_toolchain_manifest_before': sha(manifest),
    'tool_binaries': {str(p): sha(p) for p in [TOOLS / 'bin/cargo', TOOLS / 'bin/rustc', LLVM / 'bin/x86_64-w64-mingw32-clang', LLVM / 'bin/llvm-ar']},
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'driver_sha256': sha(Path(__file__)), 'timeout_seconds': 900, 'stream_limit_bytes': 16 * 1024**2,
    'scope': 'Actual Windows GNU target type-check of all host-store tests, or strict Clippy/format. No Windows execution, MSVC link or NTFS qualification.'}
write(stem.with_suffix('.inputs.json'), state)
with stem.with_suffix('.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--', 'crates/q-periapt-host-store']))
started = time.monotonic()
try:
    with stem.with_suffix('.stdout').open('xb', buffering=0) as out, stem.with_suffix('.stderr').open('xb', buffering=0) as err:
        result = capture_output(argv, timeout_seconds=900, timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
            maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2,
            environment=environment, stdout_sink=out.write, stderr_sink=err.write)
    state['returncode'] = result.returncode
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started,
        source_after=sources(), global_toolchain_manifest_after=sha(manifest))
    state['sources_unchanged_during_command'] = state['source_before'] == state['source_after']
    for suffix in ['stdout', 'stderr']:
        state[suffix + '_sha256'] = sha(stem.with_suffix('.' + suffix))
    write(stem.with_suffix('.result.json'), state)
    print(json.dumps({k: v for k, v in state.items() if k not in ['source_before', 'source_after', 'environment_overrides', 'tool_binaries']}, indent=2), flush=True)
assert state['sources_unchanged_during_command']
assert state['global_toolchain_manifest_before'] == state['global_toolchain_manifest_after']
sys.exit(state['returncode'])
