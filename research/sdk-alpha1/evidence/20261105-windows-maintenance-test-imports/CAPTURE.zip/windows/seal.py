from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-windows-test-imports'
SDK = ROOT / 'target/continuity-hosted-sdk-ff072'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-windows-maintenance-test-imports'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
read = lambda path: json.loads(path.read_bytes())
delta = read(BASE / 'SOURCE_DELTA.json')
results = {name: read(BASE / (name + '.result.json')) for name in ['red', 'format', 'green', 'clippy']}
assert results['red']['returncode'] == 101
assert all(results[name]['returncode'] == 0 for name in ['format', 'green', 'clippy'])
for label, row in results.items():
    assert row['sources_unchanged_during_command'] and row['timeout_seconds'] == 900
    assert row['global_toolchain_manifest_before'] == row['global_toolchain_manifest_after']
    assert row['driver_sha256'] == sha((BASE / 'run.py').read_bytes())
    for suffix in ['stdout', 'stderr']:
        assert row[suffix + '_sha256'] == sha((BASE / (label + '.' + suffix)).read_bytes())
for label in ['green', 'clippy']:
    assert '--tests' in results[label]['argv'] and 'x86_64-pc-windows-gnu' in results[label]['argv']
    assert not re.search(r'(?im)^(?:warning|error)(?:\[|:)', (BASE / (label + '.stderr')).read_text())
red = (BASE / 'red.stderr').read_text()
assert len(re.findall(r'^error\[E04(?:25|33)\]', red, re.M)) == 6
assert 'cannot find type `OwnedPrivateDirectory`' in red
assert 'cannot find type `OsStr`' in red and 'cannot find function `rename_directory`' in red
old = (BASE / 'windows_tests.before.rs').read_bytes()
new = (BASE / 'windows_tests.after.rs').read_bytes()
assert sha(old) == delta['old_test_sha256'] and sha(new) == delta['new_test_sha256']
path = 'crates/q-periapt-host-store/src/filesystem/directory_publication/windows_tests.rs'
assert (ROOT / path).read_bytes() == new
assert subprocess.check_output(['git', 'show', 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20:' + path]) == old
assert delta['changed_workspace_files'] == delta['changed_selected_build_inputs'] == [path]
expected = old.decode().replace('test_directory::directory, PrivateDatabaseError,',
    'test_directory::directory, OwnedPrivateDirectory, PrivateDatabaseError,').replace(
    'use std::{fs, sync::mpsc, time::Duration};', 'use std::{ffi::OsStr, fs, sync::mpsc, time::Duration};').replace(
    'ops::rename_directory(&parent, name, OsStr::new("published"), &original)?;',
    'ops::rename_directory_to(&parent, name, &parent, OsStr::new("published"), &original)?;')
assert new.decode() == expected
sdk = read(SDK / 'READBACK.json')
assert sdk['completed'] and sdk['next_fixed_source_requires_new_sdk_producer']
assert sdk['qualified_workspace_sha256'] == delta['qualified_workspace_sha256']
assert sdk['current_workspace_sha256'] == delta['fixed_workspace_sha256']
assert sdk['current_workspace_rejection']['message'] == 'Rust cohort does not identify current workspace inputs'
files = {}
for prefix, directory in [('windows', BASE), ('hosted-sdk', SDK)]:
    for p in sorted(directory.rglob('*')):
        if p.is_file():
            files[prefix + '/' + p.relative_to(directory).as_posix()] = p.read_bytes()
patch = subprocess.check_output(['git', 'diff', '--', path])
files['fix.patch'] = patch
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'base_commit': 'df4bd149b230a1130919be3e3012facbcc16118e', 'hosted_failure_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
    'hosted_failure_run': 42008993679, 'hosted_failure_job': 127182901069,
    'root_cause_commit': 'f560d803c43a24fff222daa5e5e5bd623bfdf874',
    'root_cause': 'Maintenance refactor removed parent-scope OwnedPrivateDirectory/OsStr imports and replaced same-parent rename_directory with rename_directory_to; Windows tests retained stale imports/call.',
    'source_delta': delta, 'changed_assertions': False, 'production_code_changed': False,
    'checks': {name: {'argv': row['argv'], 'returncode': row['returncode'], 'elapsed_seconds': row['elapsed_seconds'],
        'sources_unchanged_during_command': row['sources_unchanged_during_command']} for name, row in results.items()},
    'genuine_windows_target_used': 'x86_64-pc-windows-gnu', 'global_toolchain_changed': False,
    'local_red_green_compile_observed': True, 'windows_execution_observed_after_fix': False,
    'msvc_compilation_observed_after_fix': False, 'windows_ntfs_runtime_qualification_complete': False,
    'hosted_sdk_report_sha256': sdk['report_sha256'], 'hosted_sdk_artifact_id': sdk['artifact_id'],
    'hosted_archive_crates_read_back': len(sdk['crates']), 'old_producer_rejected_for_fixed_source': True,
    'focused_android_pin_changed': False, 'remote_fix_uploaded': False,
    'next_sequence': 'Finish current CI wave; create a clean producer on fixed workspace input, then pin that verified new report for the focused Android lane.',
    'release_claim_eligible': False}
files['READBACK.json'] = encode(summary)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(n) == b for n, b in files.items())
checksums = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, data in [('CAPTURE.zip', payload), ('READBACK.json', files['READBACK.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(checksums))]:
    with (DEST / name).open('xb') as stream:
        stream.write(data)
print(json.dumps(checksums, indent=2), flush=True)
