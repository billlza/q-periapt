from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-hosted-sdk-ff072'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = BASE / 'artifact-13406782037.zip'
assert sha(archive.read_bytes()) == 'a8e626e0fb27d849727e25b725d9d171ff8a4da2bdf069df20fe6a29cc76f845'
old_workspace = sdk.rust_workspace_source_digest(SOURCE)
current_workspace = sdk.rust_workspace_source_digest(ROOT)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 115
    assert z.testzip() is None
    data = z.read('sdk-rust-package/RUST_SDK_PACKAGE.json')
    report_hash = sha(data)
    assert report_hash == 'b79a596f3f011bc547bbbf21a88763ef887b6a506cfcf8dfad3b5c9bd28bca56'
    report = validate_report(data, report_hash, report_hash, old_workspace)
    assert report['base_commit'] == 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
    assert report['git_dirty'] is False and report['sources_unchanged'] is True
    assert report['publication_performed'] is False and report['release_claim_eligible'] is False
    assert report['cargo_home_isolated'] is True
    assert set(report['consumer']['tests']) == sdk.CONSUMER_TESTS
    for name, expected in report['source_inputs']['files'].items():
        assert sha((SOURCE / name).read_bytes()) == expected
    records = {}
    for name, row in report['crates'].items():
        assert row['file'] == name + '-0.2.0.crate'
        body = z.read('sdk-rust-package/crates/' + row['file'])
        assert len(body) == row['bytes'] and sha(body) == row['sha256']
        members = sdk.archive_files(body, name)
        assert len(members) == row['members'] and sorted(members) == row['files']
        vcs = json.loads(members['.cargo_vcs_info.json'])
        assert vcs['git']['sha1'] == report['base_commit'] and not vcs['git']['dirty']
        records[name] = {'bytes': len(body), 'sha256': sha(body), 'members': len(members), 'vcs_commit': vcs['git']['sha1']}
        if name == 'q-periapt-host-store':
            test = members['src/filesystem/directory_publication/windows_tests.rs']
            assert test == (SOURCE / 'crates/q-periapt-host-store/src/filesystem/directory_publication/windows_tests.rs').read_bytes()
            assert test != (ROOT / 'crates/q-periapt-host-store/src/filesystem/directory_publication/windows_tests.rs').read_bytes()
            with (BASE / 'packaged-windows_tests.rs').open('xb') as stream:
                stream.write(test)
    assert len(records) == 12
    try:
        validate_report(data, report_hash, report_hash, current_workspace)
    except ValueError as error:
        assert str(error) == 'Rust cohort does not identify current workspace inputs'
        rejection = {'error_type': type(error).__name__, 'message': str(error)}
    else:
        raise AssertionError('Old producer unexpectedly accepted for the repaired workspace')
result = {'completed': True, 'observed_utc': datetime.now(timezone.utc).isoformat(),
    'hosted_run': 42008993679, 'hosted_job': 127182900240, 'artifact_id': 13406782037,
    'artifact_bytes': archive.stat().st_size, 'artifact_sha256': sha(archive.read_bytes()),
    'artifact_members': 115, 'report_sha256': report_hash, 'base_commit': report['base_commit'],
    'qualified_workspace_sha256': old_workspace, 'current_workspace_sha256': current_workspace,
    'crates': records, 'recorded_consumer_tests': report['consumer']['tests'],
    'current_workspace_rejection': rejection, 'old_windows_test_is_in_host_store_archive': True,
    'new_native_execution': False, 'focused_android_pin_changed': False,
    'next_fixed_source_requires_new_sdk_producer': True, 'release_claim_eligible': False}
with (BASE / 'READBACK.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: result[k] for k in ['completed', 'base_commit', 'report_sha256',
    'qualified_workspace_sha256', 'current_workspace_sha256', 'current_workspace_rejection']}, indent=2))
