from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import continuity_android_credential as credential
import continuity_android_remote_credential as remote
PUBLIC=credential.PUBLIC+remote.PUBLIC
import continuity_android_jni as android
import rust_sdk_profile as sdk
root=Path.cwd();phone=root/'target/continuity-android-remote-credential-device';host=root/'target/continuity-android-remote-credential-host';aar=root/'target/continuity-android-remote-credential-aar';out=root/'research/sdk-alpha1/evidence/20261011-android-remote-credential'
accepted=json.loads((phone/'VERIFIED.json').read_text());assert accepted['completed']
h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert h['completed'] and a['completed']
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==digest and a['source_sha256'][name]==digest
host_cases={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];library=Path(next(a.split('=',1)[1] for a in argv if a.startswith('-Djava.library.path=')))
 cases=library/'credential-cases';fresh=remote.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),cases)
 assert fresh==h['profiles'][profile]['credential_outcomes'];host_cases[profile]=cases
 assert sdk.snapshot(library/'qpc-c-client',maximum=512*1024*1024).sha256==h['profiles'][profile]['receiver_sha256']
secrets=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
for line in rows:
 if ' device ' in line:secrets.append(line.split()[0].encode())
for path in (phone/'cases').glob('*/inputs/witness-tls-key'):
 value=path.read_bytes();secrets.extend([value,base64.b64encode(value),value.hex().encode()])
out.mkdir()
def archive(filename,files):
 with zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED) as packed:
  for name,path in sorted(files.items()):
   data=path.read_bytes();assert not any(secret and secret in data for secret in secrets),'private value in capture '+name
   info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;packed.writestr(info,data)
 return hashlib.sha256((out/filename).read_bytes()).hexdigest()
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for folder in ['device-*','agp-*']:
 for p in phone.glob(folder+'/*'):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for label in accepted['profiles']:
 for name in PUBLIC:files['cases/'+label+'/'+name]=phone/'cases'/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
files['ANDROID_JNI_CONSUMER.json']=host/'ANDROID_JNI_CONSUMER.json'
for name in ['clippy.stderr','clippy.stdout','clippy.json','artifact-tests.stdout','artifact-tests.stderr','qualify.py','clippy.py']:files[name]=host/name
for profile,cases in host_cases.items():
 for label in h['profiles'][profile]['credential_outcomes']:
  for name in PUBLIC:files['cases/'+profile+'/'+label+'/'+name]=cases/label/name
host_hash=archive('HOST_CAPTURE.zip',files)
a_hash=archive('AAR_BUILD_CAPTURE.zip',{p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}})
code={('bindings/android/ContinuityPackageConsumer/'+name):hashlib.sha256(data).hexdigest() for name,data in android.source_files().items()}
for name in ['artifact/continuity_android_credential.py','artifact/continuity_android_remote_credential.py','artifact/continuity_android_jni.py','artifact/continuity_android_witness.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_witness.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential_traffic.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_remote_credential.rs','research/continuity-identity-candidate/tests/owned_connection.rs']:
 code[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
record={'kind':'qperiapt.android_remote_credential_qualification','completed':True,'base_commit':'b641b14616ac5f9c5a07a68dfffa3618017ef36a','code_commit':'b415a57b3e022947899f19e457b4af9e3bf4f9a5','art_harness':json.loads((phone/'HARNESS.json').read_text()),'code_sha256':code,'device_scope':{'accepted':True,'device_count':1,'api':37,'abi':'arm64-v8a','additional_api36_hardware_required':False},'art_processes':150,'native_credential_counterparty_processes_per_run':40,'profiles':accepted['profiles'],'host_jni':{'completed':True,'qualified_java_processes':510,'credential_java_processes':300,'boundary_processes':2,'local_lifecycle_processes':48,'managed_registry_processes':100,'witness_processes':60,'profiles':['debug','release'],'receiver_sha256':{p:h['profiles'][p]['receiver_sha256'] for p in ['debug','release']}},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'AAR_BUILD_CAPTURE.zip':a_hash},'scope':['Actual minified AAR exposes remote credential admission on the original managed device.','Installed C counterparty renews its original enrollment through independent signed-grant staging, witness preparation/commit and reconciliation.','Bad target checkpoint, wrong operation and local-identity misuse are refused. The superseded peer object fails; explicit reopening retains the original pending message and next message slot.','Across a fresh ART process, the original remote grant replays and the pending message is retried in the same session. Two distinct messages retain exactly two unchanged application effects.'],'limitations':['Both local and remote routes execute before original credential expiry.','Expiry cleanup and independently approved cancellation remain separate Android scenarios.','Counterparty is an installed native C consumer on the Mac host. This does not qualify an independent protocol implementation or native Linux endpoint.'],'release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',record);print('Captured Android remote credential admission and original-message continuation',flush=True)
