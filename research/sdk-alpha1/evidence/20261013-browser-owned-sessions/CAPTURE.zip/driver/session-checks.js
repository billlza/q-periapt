import {QPeriaptContinuityAccountTrust as Account,QPeriaptContinuityParticipant as Participant,
 QPeriaptContinuityPeerTrust as Trust,QPeriaptContinuityQuality as Quality,QPeriaptContinuityRole as Role,
 QPeriaptContinuityPeer as Peer,QPeriaptContinuityEndpoint as Endpoint,QPeriaptContinuityMessage as Message,
 QPeriaptContinuityConsumption as Consumption,QPeriaptContinuityMessageStatus as Status}
 from '/node_modules/q-periapt-sdk-wasm/web/index.js';
const bytes=value=>new Uint8Array(value),now=()=>BigInt(Math.floor(Date.now()/1000));
const check=(value,message)=>{if(!value)throw Error(message)};
const hex=value=>[...value].map(v=>v.toString(16).padStart(2,'0')).join('');
async function database(name) {
 return new Promise((resolve,reject)=>{const request=indexedDB.open(name,1);request.onupgradeneeded=()=>request.result.createObjectStore('effects');request.onerror=()=>reject(request.error);request.onsuccess=()=>resolve(request.result);});
}
async function effect(name,session,message,plaintext) {
 const db=await database(name);const key=hex(session)+':'+hex(message);
 try{return await new Promise((resolve,reject)=>{
   const tx=db.transaction('effects','readwrite',{durability:'strict'});let value,failure;
   tx.onabort=()=>reject(failure??tx.error??Error('application transaction aborted'));
   tx.oncomplete=()=>resolve(value);const store=tx.objectStore('effects'),read=store.get(key);
   read.onsuccess=()=>{try{
     if(read.result!==undefined){value=read.result;check(value.plaintext.toString()===[...plaintext].toString(),'host input changed');value={...value,calls:value.calls+1};}
     else value={plaintext:[...plaintext],calls:1,effects:1};
     store.put(value,key);
   }catch(error){failure=error;tx.abort();}};
 });}finally{db.close();}
}
async function readEffect(name,session,message) {
 const db=await database(name);try{return await new Promise((resolve,reject)=>{const tx=db.transaction('effects','readonly');let value;tx.onabort=()=>reject(tx.error??Error('read abort'));tx.oncomplete=()=>resolve(value);const get=tx.objectStore('effects').get(hex(session)+':'+hex(message));get.onsuccess=()=>{value=get.result;};});}finally{db.close();}
}
export async function sessionAction(owner,policy,runtime,config,grant,data) {
 const owned=[];const own=value=>{owned.push(value);return value;};
 try {
  const response=await fetch('/inputs/'+data.case+'-peer.json');if(!response.ok)throw Error('peer public configuration');const peerConfig=await response.json();
  const init=own(new Account(bytes(config.account),bytes(config.root),BigInt(grant.version),bytes(grant.digest),bytes(config.family)));
  const resp=own(new Account(bytes(peerConfig.account),bytes(peerConfig.root),BigInt(peerConfig.version),bytes(peerConfig.digest),bytes(config.family)));
  const a=own(new Participant(init,bytes(config.description).slice(0,16),1n)),b=own(new Participant(resp,bytes(peerConfig.device),1n));
  const expected=own(new Trust(a,b,Quality.OneTimeBoth,new Uint8Array(32).fill(data.wrongDirectory?78:77)));
  const bundle=bytes(peerConfig.bundle);if(data.badBundle)bundle[bundle.length-1]^=1;
  if(data.sessionClosedPolicy)policy.close();if(data.sessionClosedRuntime)runtime.close();
  const action=data.sessionAction;
  if(action==='new-request')return {requestId:[...Peer.new_request_id()]};
  const endpoint=own(Endpoint.for_loopback(new URL('/peer/'+data.case+'?mode='+(data.peerMode??'normal'),location.origin).href));
  if(action==='establish') {
   const peer=own(await owner.admit_peer(bundle,policy,expected,Role.Initiator,now()));check(peer.role()===Role.Initiator,'peer role');
   if(data.closeAfterAdmission==='policy')policy.close();if(data.closeAfterAdmission==='runtime')runtime.close();
   const session=own(await owner.establish_session(peer,bytes(data.requestId),endpoint,data.sessionTimeout??10000,now));
   check(session.role()===Role.Initiator&&session.id().length===32,'session identity');return {session:[...session.id()]};
  }
  const session=own(await owner.reopen_session(bundle,policy,expected,Role.Initiator,bytes(data.session),now()));
  if(action==='new-message')return {message:[...await owner.next_session_message_id(session,now())]};
  if(action==='status')return {status:await owner.session_message_status(session,bytes(data.message))};
  if(action==='send') {
   const raw=new TextEncoder().encode(data.plaintext??'browser to native');
   const input=own(new Message(bytes(data.message),raw,new TextEncoder().encode('forward/v1')));raw.fill(0);
   const consumption=await owner.deliver_session_message(session,input,endpoint,data.sessionTimeout??10000,now);
   check([Consumption.Confirmed,Consumption.PrefixPending].includes(consumption),'consumption shape');
   const status=await owner.session_message_status(session,bytes(data.message));
   check(status===(consumption===Consumption.Confirmed?Status.Acknowledged:Status.Committed),'consumption did not match local status');
   input.close();check(input.is_closed(),'input closure');return {consumption,status};
  }
  if(action==='receive') {
   const response=await fetch('/inputs/'+data.case+'-reverse.bin');if(!response.ok)throw Error('reverse frame');
   const wire=new Uint8Array(await response.arrayBuffer());let delivered,marker;
   if(data.applicationMode==='hostile')marker=new Proxy({}, {get(){throw Error('original cause was inspected')}});
   if(data.applicationMode==='coded')marker=Object.assign(new Error('original application failure'),{code:'Busy'});
   const callback=async(s,m,p)=>{
    check(s.toString()===data.session.toString(),'callback session changed');check(new TextDecoder().decode(p)==='native to browser','callback plaintext');
    delivered=await effect(data.name+'-application',s,m,p);
    if(data.applicationMode==='after-effect'&&delivered.calls===1)throw Error('effect committed; report unavailable');
    if(data.applicationMode==='hostile'||data.applicationMode==='coded')throw marker;
    if(data.applicationMode==='late'){await new Promise(resolve=>setTimeout(resolve,20000));}
   };
   try {
    const reply=await owner.serve_session_message(session,wire,callback,data.sessionTimeout??10000,now);
    const saved=await readEffect(data.name+'-application',bytes(data.session),bytes(data.reverseMessage));
    check(saved?.effects===1,'host effect missing');return {reply:[...reply],application:saved,callbackInvoked:delivered!==undefined};
   }catch(error){
    if(marker){check(error.code==='Application'&&error.ownerClosed===true&&error.cause.cause===marker,'original application cause/closure changed');}
    throw error;
   }
  }
  throw Error('unknown session action');
 } finally {for(const value of owned.reverse()){if(typeof value.close==='function')value.close();value.free();}}
}
