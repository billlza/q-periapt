import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
Object.defineProperty(globalThis,'isSecureContext',{value:true});
const {HttpExchange,httpEndpoint}=await import(pathToFileURL(resolve(process.argv[2],'bounded-fetch.js')));
const {ApplicationExchange}=await import(pathToFileURL(resolve(process.argv[2],'application.js')));
let requests=0;const timers=new Set();const seen=[];
const server=createServer(async(req,res)=>{
  requests++;let length=0;for await(const bytes of req)length+=bytes.length;
  seen.push({path:req.url,length,credentials:Boolean(req.headers.cookie||req.headers.authorization)});
  const mode=req.url.slice(1);if(mode==='redirect'){res.writeHead(307,{Location:'/witness'});res.end();return;}
  if(mode==='status'){res.writeHead(503);res.end();return;}
  const size=mode==='witness'?3659:mode==='witness-short'?3658:mode==='large'?32769:mode==='tiny'?9:32;
  const reply=()=>{res.writeHead(200,{'Content-Type':mode==='wrong-type'?'text/plain':'application/octet-stream',...(mode==='no-length'?{}:{'Content-Length':String(size)})});res.end(Buffer.alloc(size,19));};
  if(mode==='slow'){const timer=setTimeout(()=>{timers.delete(timer);reply();},250);timers.add(timer);}else reply();
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;let checks=0;
const check=(value,message)=>{assert.ok(value,message);checks++;};
const call=async(mode,profile=2,timeout=1000,cancelled=()=>false)=>{
  const request=new Uint8Array(profile===1?3674:32).fill(7);
  const attempt=HttpExchange.start(httpEndpoint(origin+'/'+mode,true),request,timeout,cancelled,profile);
  request.fill(0);try{return await attempt.reply();}finally{attempt.cancel();}
};
try {
  for(const [mode,profile,length] of [['witness',1,3659],['session',2,32],['no-length',2,32]])check((await call(mode,profile)).length===length,'bounded success');
  for(const [mode,profile,code] of [['witness-short',1,'InvalidResponse'],['large',2,'InvalidResponse'],['tiny',2,'InvalidResponse'],['wrong-type',2,'InvalidResponse'],['redirect',2,'Network'],['status',2,'HttpStatus'],['slow',2,'Timeout']]){
    await assert.rejects(call(mode,profile,mode==='slow'?5:1000),e=>e.code===code);checks++;
  }
  const before=requests;await assert.rejects(call('session',2,1000,()=>true),e=>e.code==='Cancelled');check(requests===before,'pre-cancel dispatched');
  for(const profile of [0,3,'1',null]){assert.throws(()=>HttpExchange.start(origin+'/session',new Uint8Array(32),1000,()=>false,profile));checks++;}
  for(const value of ['http://example.test','http://localhost','https://user:pass@example.test','https://example.test/#token']){assert.throws(()=>httpEndpoint(value,true));checks++;}
  check(seen.every(row=>!row.credentials),'ambient credentials');
  const session=new Uint8Array(32),message=new Uint8Array(32),plain=new Uint8Array([1,2,3]);
  let calls=0;const ok=ApplicationExchange.start(async(s,m,p)=>{calls++;assert.notEqual(p,plain);assert.deepEqual([...p],[1,2,3]);},session,message,plain,1000,()=>false);
  await ok.reply();check(ok.code()===0&&calls===1,'application success');ok.cancel();
  for(const marker of [undefined,null,new Proxy({}, {get(){throw Error('must not inspect cause')}})]){
    const a=ApplicationExchange.start(()=>{throw marker},session,message,plain,1000,()=>false);
    let rejected=false;try{await a.reply();}catch(e){rejected=true;assert.equal(e,marker);}
    check(rejected&&a.code()===1,'application cause changed');a.cancel();
  }
  const malformed=ApplicationExchange.start(async()=>true,session,message,plain,1000,()=>false);
  await assert.rejects(malformed.reply(),TypeError);check(malformed.code()===1,'nonvoid admitted');malformed.cancel();
  let completed=false;
  const late=ApplicationExchange.start(async()=>{await new Promise(r=>setTimeout(r,30));completed=true;throw Error('late original failure');},session,message,plain,5,()=>false);
  await assert.rejects(late.reply(),e=>e.applicationPending===true);check(late.code()===3&&!completed,'deadline hidden');late.cancel();
  await new Promise(r=>setTimeout(r,40));check(completed,'test lost external pending callback');
  const pre=ApplicationExchange.start(()=>{calls++;},session,message,plain,1000,()=>true);
  await assert.rejects(pre.reply());check(pre.code()===2&&calls===1,'cancelled application dispatched');pre.cancel();
  console.log(JSON.stringify({completed:true,scope:'Node host-helper checks with real loopback HTTP; not browser/runtime qualification',checks,requests,observed:seen}));
} finally {for(const timer of timers)clearTimeout(timer);server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
