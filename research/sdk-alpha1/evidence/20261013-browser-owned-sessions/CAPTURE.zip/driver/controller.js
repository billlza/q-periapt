globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', { type: 'module' });
  let polling = false, cancellationRequested = false, stopped = false;
  const finish = (error, value) => { stopped = true; clearTimeout(timer); worker.terminate(); if (error) reject(error); else resolve({ ...value, cancellationRequested }); };
  const timer = setTimeout(() => finish(Error('worker deadline')), 45000);
  worker.onerror = event => finish(Error(event.message));
  worker.onmessage = async ({ data }) => {
    try {
      if (data.ready) {
        worker.postMessage(args);
        if ((args.cancelOnAdvance||args.cancelOnPeer) && !polling) {
          polling = true;
          while (!stopped) {
            const response = await fetch((args.cancelOnPeer?'/peer-status/':'/status/') + args.case, { credentials: 'omit', cache: 'no-store' });
            if (!response.ok) throw Error('witness status');
            if ((await response.json()).some(row => args.cancelOnPeer?row.trigger:row.changed)) { worker.postMessage({ cancel: true }); break; }
            await new Promise(resolve => setTimeout(resolve, 20));
          }
        }
      } else if (data.cancellation_requested) cancellationRequested = true;
      else if (data.done) {
        if (data.value?.request) {
          const response = await fetch('/capture/' + args.case + '.bin', { method: 'POST', body: new Uint8Array(data.value.request) });
          if (!response.ok) throw Error('request capture'); delete data.value.request;
        }
        if (data.value?.phase === 'requires-witness-enrollment') {
          const response = await fetch('/capture/' + args.case + '-genesis.json', { method: 'POST', body: JSON.stringify(data.value) });
          if (!response.ok) throw Error('genesis capture');
        }
        if(data.value?.reply){const response=await fetch('/capture/'+args.case+'-reverse-ack'+(args.replyLabel?'-'+args.replyLabel:'')+'.bin',{method:'POST',body:new Uint8Array(data.value.reply)});if(!response.ok)throw Error('reply capture');delete data.value.reply;}
        finish(undefined, data);
      }
    } catch (error) { finish(error); }
  };
});
