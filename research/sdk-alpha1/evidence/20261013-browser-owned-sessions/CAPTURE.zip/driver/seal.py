from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-api';package=root/'target/continuity-browser-publication/source/target/session-api-package-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
overlay=json.loads((stage/'PACKAGE_SOURCE_01.json').read_text())
for name,digest in overlay['overlay'].items():assert sha(root/name)==digest,name
for name in overlay.get('deleted',[]):assert not (root/name).exists(),name
reports={n:json.loads((stage/n/'RESULT.json').read_text()) for n in ['sessions-03','sessions-04','lifecycle-01']}
for n,r in reports.items():assert r['completed'],n
assert [len(reports[n]['cases']) for n in reports]==[1,16,9]
assert json.loads((package/'sources-before.json').read_text())==json.loads((package/'sources-after.json').read_text())
for r in [reports['sessions-03'],reports['sessions-04']]:
 for name,digest in r['native'].items():assert sha(Path(name))==digest,name
members={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in members,name
 assert not any(part.endswith('-private') or part.startswith('private-') for part in p.parts),p
 members[name]=p
for name in ['PACKAGE_SOURCE_01.json','LIFECYCLE_PACKAGE_COPY.json','NATIVE_PROFILE_BEFORE.json','check-hosts.mjs','run-sessions.py','run-lifecycle.py','server.py','controller.js','session-worker.js','session-checks.js','build-package-01.sh','seal.py']:
 add(stage/name,'driver/'+name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/name,'native-peer/'+name)
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.log','.stdout','.stderr'] and not p.name.startswith('seal'):add(p,'commands/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json','build-web.json','build-nodejs.json','consumer-installed.json','consumer-product.json','typescript.json']:
 add(package/name,'package/'+name)
add(stage/'base-01/RESULT.json','base-01/RESULT.json')
for name in ['run-lifecycle-04.py']:add(root/'target/continuity-browser-publication'/name,'previous-driver/'+name)
for name in ['server.py','lifecycle-worker.js','controller.js']:add(root/'target/continuity-browser-recovery'/name,'lifecycle-driver/'+name)
for n in ['sessions-01','sessions-02','sessions-03','sessions-04','lifecycle-01']:
 add(stage/n/'RESULT.json',n+'/RESULT.json')
 for p in sorted((stage/n/'logs').iterdir()):
  if p.is_file():add(p,n+'/logs/'+p.name)
# Preserve full happy-path public protocol bytes. Fault runs retain every receipt
# and hash in RESULT; complete raw local traces remain in the original run folders.
for folder in ['captures','peer','native','witness']:
 for p in sorted((stage/'sessions-03'/folder).rglob('*')):
  if p.is_file():add(p,'sessions-03/'+p.relative_to(stage/'sessions-03').as_posix())
for name in overlay['overlay']:add(root/name,'source/'+name)
dest=root/'research/sdk-alpha1/evidence/20261013-browser-owned-sessions';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
checks={'completed':True,'release_claim_eligible':False,'source':overlay,
 'package':{'file':'q-periapt-sdk-wasm-0.2.0.tgz','sha256':sha(package/'q-periapt-sdk-wasm-0.2.0.tgz'),'bytes':(package/'q-periapt-sdk-wasm-0.2.0.tgz').stat().st_size,'installed_consumer_report_sha256':sha(package/'INSTALLED_CONSUMER.json')},
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{name:sha(p) for name,p in members.items()}},
 'cases':{n:[{'case':c['case'],'witness_requests':len(c['witness_records']),'peer_requests':len(c.get('peer_records',[]))} for c in r['cases']] for n,r in reports.items()},
 'scope':'Actual installed npm web entry in Chrome dedicated Workers with persistent OPFS/IndexedDB, signed native witness, and bidirectional native/browser owned session exchange; same shared protocol implementation and local loopback diagnostics.',
 'fixture_authority':{'evidence':'research/sdk-alpha1/evidence/20261013-browser-required-witness','source':'target/continuity-browser-witness/source','binary_hashes':reports['sessions-04']['native'],'note':'Existing isolated diagnostic authority fixture; this is not a new implementation or deployed witness.'},
 'failures_retained':['sessions-01: fixture effect directory used mode 0755; private publication correctly rejected it. New fixtures use 0700.','sessions-02: unoptimized dependencies in standalone fixture exceeded unchanged 10-second client deadline. Fixture profile now matches native debug consumers, with debug and overflow assertions retained. These process times are not a performance benchmark.'],
 'excluded':['private keys, wrapping keys, private authority/journal databases, browser profiles','package release or public publication','HTTPS/CORS deployment or complete browser/version matrix','independent implementation, cross-host qualification, PCS recovery proof','browser rekey, root/roster transitions and migration'],
 'validation':{'base_browser_scenarios':10,'host_helper_checks':28,'package_controls':9,'browser_storage_creation_controls':13,'source_inventory_controls':44,'tracked_rust_sources':608,'wasm_msrv':'1.90.0 passed','wasm_clippy':'-D warnings passed','native_clippy':'connection-tls lib/tests -D warnings passed','format':'passed'}}
sdk.write_json(dest/'CHECKS.json',checks)
print(json.dumps({k:checks[k] for k in ['completed','package']}))
print('capture bytes',archive.stat().st_size,'members',len(members))
