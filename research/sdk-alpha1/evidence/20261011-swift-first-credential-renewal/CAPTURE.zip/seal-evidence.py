from pathlib import Path
import hashlib,json,re,subprocess,zipfile
base=Path(__file__).resolve().parent
main=base.parent.parent
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=main,text=True).strip()
assert head=="c9de42b30ca6e7ac7f2ae869282d95a56b73871c"
labels=("prepared-01","swift-credential-debug-01","swift-credential-release-01","swift-policy-debug-01","swift-policy-release-01","swift-ordinary-debug-01","swift-ordinary-release-01","clippy-current","clippy-msrv")
runs={name:json.loads((base/name/"RESULT.json").read_text()) for name in labels}
assert all(r["completed"] for r in runs.values())
for name,run in runs.items():
    assert run.get("inputs_unchanged",run.get("source_unchanged",False))
    for relative,digest in run["source_sha256"].items():
        local=main/"bindings/c/ContinuityPackageConsumer"/relative
        if relative.startswith(("src/","tests/")):
            assert hashlib.sha256(local.read_bytes()).hexdigest()==digest,(name,relative)
for profile,row in runs["prepared-01"]["profiles"].items():
    for relative,digest in row["source_sha256"].items():
        if relative.startswith(("Sources/","Tests/")) or relative=="Package.swift":
            local=main/"bindings/swift/ContinuityPackageConsumer"/relative
            assert hashlib.sha256(local.read_bytes()).hexdigest()==digest,(profile,relative)
reader=(base/"readers-full-git.stderr").read_text()
assert re.search(r"Ran 88 tests in .+\n\nOK\n",reader)
assert head in (base/"source-gate-current.stdout").read_text()
public_runs=[n for n in labels if n.startswith("swift-")]
files=[]
for name in labels:
    for path in (base/name).rglob("*"):
        if not path.is_file(): continue
        assert not path.is_symlink() and path.suffix not in (".key",".redb",".dylib",".jar")
        files.append((path,name+"/"+path.relative_to(base/name).as_posix()))
for name in ("prepare.py","run.py","run-clippy.py","seal-evidence.py","readers.stdout","readers.stderr","readers-full-git.stdout","readers-full-git.stderr","source-gate.stdout","source-gate.stderr","ci-before-upload.json","MAINTENANCE_REVIEW.json","source-gate-current.stdout","source-gate-current.stderr","actionlint-before.json","actionlint-current.json","WORKFLOW_CHECK.json"):
    files.append((base/name,name))
output=main/"research/sdk-alpha1/evidence/20261011-swift-first-credential-renewal"
output.mkdir()
archive=output/"CAPTURE.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED) as z:
    for path,name in sorted(files,key=lambda pair:pair[1]): z.write(path,name)
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
profiles={}
for profile in ("debug","release"):
    profiles[profile]={"installed":runs["prepared-01"]["profiles"][profile],
        "credential":runs["swift-credential-"+profile+"-01"]["profiles"][profile],
        "policy_regression":runs["swift-policy-"+profile+"-01"]["profiles"][profile],
        "ordinary_regression":runs["swift-ordinary-"+profile+"-01"]["profiles"][profile]}
checks={"source_commit":head,"implementation_commit":"85c6583bf00fbaf4b870a2060e50970f9cb019c0","completed":True,"release_claim_eligible":False,
"scope":"Installed Swift first-use managed credential renewal to a C peer on macOS arm64; same host and shared native engine.",
"identity":"Swift package sources and Rust/C harness match the code commit; Debug/Release native libraries are unchanged from the frozen 6d70c614 candidate archive. This composition is not a full new distribution qualification.",
"candidate_archive":runs["prepared-01"]["candidate_archive"],
"validation":{"Swift_package_tests_per_profile":66,"credential_scenarios":8,"managed_policy_regression_scenarios":8,"ordinary_regression_scenarios":12,"readers_and_inventory_tests":88,"Clippy":["1.90.0","1.98.1"],"warnings_as_errors":True,"source_gate":"passed"},
"profiles":profiles,
"invariants":["Fresh requests and old activation still refuse after actual credential expiry (104)","The same original signer, journal, session and message survive credential renewal","Bad grants retire the failing owner (102 then 2)","Missing or closed registry refuses new Commit (211 or 202); refusal transcripts contain no Commit","Exactly one witness Commit is applied; its reply is lost (218)","Historical reconcile and terminal replay use signed exchanges without another Commit or a selected registry","Recovered history still cannot activate without a current registry (211)","Peer separately admits the signed grant and original message reaches acknowledged with one host effect","Explicit registry close and ARC release continue to invalidate selected authority"],
"maintenance":json.loads((base/"MAINTENANCE_REVIEW.json").read_text()),
"parser_fixture":{"path":"artifact/fixtures/first-credential-swift-public-v1.zip","sha256":hashlib.sha256((main/"artifact/fixtures/first-credential-swift-public-v1.zip").read_bytes()).hexdigest(),"scope":"Actual Swift Debug public records; mutation tests validate linkage and grammar, not independent signature verification"},
"limits":["Kotlin first-use credential integration remains pending","No independent engine, physical-device, cross-platform or full release qualification","No throughput, RSS or energy improvement measured"],
"workflow_check":json.loads((base/"WORKFLOW_CHECK.json").read_text()),
"CI_job_budgets_minutes":{"native":105,"Swift":210,"Kotlin":300,"command_timeout_unchanged":True},
"prior_CI":json.loads((base/"ci-before-upload.json").read_text()),
"capture":{"file":"CAPTURE.zip","sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"bytes":archive.stat().st_size,"members":len(files)}}
(output/"CHECKS.json").write_text(json.dumps(checks,indent=2)+"\n")
print(json.dumps({"completed":True,"capture":checks["capture"]}))
