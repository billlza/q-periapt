from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main
sys.path.insert(0,str(src/"artifact"))
import continuity_c_consumer as c
import continuity_c_authority as authority
base=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=root/"c-consumer-swift-first-credential-01"
run_dir=out/sys.argv[1];run_dir.mkdir()
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build-swift-first-credential-01"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"),DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer")
shutil.copytree(root/"c-consumer-first-credential-05",consumer)
shutil.copy2(main/"bindings/c/ContinuityPackageConsumer/tests/first_configuration.rs",consumer/"tests/first_configuration.rs")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
record={"source_sha256":files,"consumer":str(consumer),"candidate_archive":base["candidate_archive"],"runs":[],"profiles":{},"completed":False,"release_claim_eligible":False}
(run_dir/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(argv,label,cwd=consumer,*,runtime=None):
    start=time.monotonic()
    with (run_dir/(label+".stdout")).open("wb") as so,(run_dir/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(argv,cwd=cwd,env=env if runtime is None else runtime,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":argv,"returncode":code,"seconds":time.monotonic()-start})
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; retained stderr")
    return (run_dir/(label+".stdout")).read_bytes()

import continuity_first_configuration as configuration
import continuity_swift_consumer as swift_contract
swift=run(["xcrun","--find","swift"],"swift-path").decode().strip()
filename="libq_periapt_continuity_c_consumer.dylib"
for profile in ("debug","release"):
    extra=["--release"] if profile=="release" else []
    built=run([str(tc/"bin/cargo"),"test","--locked","--offline","--test","first_configuration","--no-run","--message-format=json","-j","2",*extra],"helper-build-"+profile)
    helper=c.built_artifact(built,consumer,root/"build-swift-first-credential-01"/profile,library=False,test_name="first_configuration")
    installed=root/("swift-first-credential-01-"+profile)
    shutil.copytree(root/("swift-authority-"+profile),installed,ignore=shutil.ignore_patterns(".build",".swiftpm"))
    for name in ("Sources","Tests"):
        shutil.copytree(main/"bindings/swift/ContinuityPackageConsumer"/name,installed/name,dirs_exist_ok=True)
    shutil.copy2(main/"bindings/swift/ContinuityPackageConsumer/Package.swift",installed/"Package.swift")
    native=installed/"native/lib"
    source_hashes={str(p.relative_to(installed)):hashlib.sha256(p.read_bytes()).hexdigest() for p in installed.rglob("*") if p.is_file()}
    expected={"debug":"e323b3f77f45a18862bd5bb43b169e9505d9ce8f87604dc66fd5bd13e8f8360d","release":"e22c4b7b1533916800f059032b31f740538d0bd6979d78a17577ede58a1e0b8b"}
    assert hashlib.sha256((native/filename).read_bytes()).hexdigest()==expected[profile]
    tested=run([swift,"test","--package-path",str(installed),"--configuration",profile,"-j","2","-Xswiftc","-warnings-as-errors","-Xcc","-I"+str(installed/"native/include"),"-Xlinker","-L"+str(native),"-Xlinker","-rpath","-Xlinker",str(native)],"swift-tests-"+profile)
    swift_contract.verify_tests(tested,(run_dir/("swift-tests-"+profile+".stderr")).read_bytes())
    binary_dir=Path(run([swift,"build","--package-path",str(installed),"--configuration",profile,"--show-bin-path"],"swift-bin-"+profile).decode().strip())
    client=binary_dir/"FirstConfigurationClient"
    dependencies=run(["/usr/bin/otool","-L",str(client)],"dependencies-"+profile).decode()
    loader=run(["/usr/bin/otool","-l",str(client)],"loader-"+profile).decode()
    swift_contract.verify_linkage(dependencies,loader,native)
    assert all(hashlib.sha256((installed/f).read_bytes()).hexdigest()==h for f,h in source_hashes.items())
    record["profiles"][profile]={"helper":str(helper),"helper_sha256":hashlib.sha256(helper.read_bytes()).hexdigest(),"installed":str(installed),"client":str(client),"client_sha256":hashlib.sha256(client.read_bytes()).hexdigest(),"native_sha256":expected[profile],"source_sha256":source_hashes}
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
record["inputs_unchanged"]=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
record["completed"]=record["inputs_unchanged"]
(run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"completed":record["completed"],"profiles":list(record["profiles"])}),flush=True)
