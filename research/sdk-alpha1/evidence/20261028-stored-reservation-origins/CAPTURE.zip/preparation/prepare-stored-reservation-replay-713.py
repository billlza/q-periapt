"""Add actual reservation goals, restoring every unselected checked subtree."""
from pathlib import Path
import hashlib,json,re,shutil

root=Path.cwd();stage_parent=root/'target/p0-origin-stored-reservations-713'
sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((stage_parent/'stored-reservations-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
assert not (stage_parent/'initial-send-oracle.failed').exists()
raw=(stage_parent/'stored-reservations-proof.spthy').read_bytes()
assert sha(raw)==terminal['output_sha256']=='236e87ece2913c55627a1b119541723ab9a32921212498bcab9a2df3d87ee608'
value=raw.decode();full_path=root/'target/p0-origin-response-restored-713/response-restored-proof.spthy'
full=full_path.read_text();assert sha(full.encode())=='17388a2c9dee3d9c3ca497b6bf3f08bdb1f3b070a06f11117dfe89bf8e9843ac'
def region(text):
    a=text.index('lemma epoch_generation_secret_derivation_origin ');b=text.index('\nlemma ',a)
    return a,b,text[a:b]
def sources(main):return {m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
def producers(body):return {m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',body)}
a,b,main=region(value);_,_,full_main=region(full)
roots,full_roots=sources(main),sources(full_main)
assert len(roots)==len(full_roots)==18 and set(roots)==set(full_roots)
assert all(roots[n]==block for n,block in full_roots.items() if n!='Snapshot_case_5')
focused,original=producers(roots['Snapshot_case_5']),producers(full_roots['Snapshot_case_5'])
assert len(focused)==len(original)==11 and set(focused)==set(original)
frames=[]
for path in sorted((stage_parent/'initial-send-oracle-frames').glob('*.json')):
    row=json.loads(path.read_text());text=(path.parent/row['captured_input']).read_text()
    assert sha(text.encode())==row['input_sha256'] and not row['ranking']
    frames.append((row,text))
assert len(frames)==20 and main.count('by sorry /* Oracle ranked no proof methods */')==20 and main.count('by sorry')==20
selected={'Key_Reservation_1':5,'Response_Reservation_4':6};index=0;changes=[];restored=[]
snapshot=roots['Snapshot_case_5']
for name,block in focused.items():
    leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',block))
    if name not in selected:
        assert len(leaves)==1
        snapshot=snapshot.replace(block,original[name],1)
        restored.append({'producer':name,'sha256':sha(original[name].encode()),'open_leaves':original[name].count('by sorry')})
        index+=1;continue
    assert len(leaves)==selected[name]
    replacements=[]
    for leaf in leaves:
        row,text=frames[index]
        chains=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',text)
        if chains:
            assert len(chains)==1;method=chains[0];kind='actual unique knowledge chain'
        else:
            ready=re.findall(r'(?m)^\d+: (PositionedPhaseState\([^\n]+▶₀ #vr\.8)$',text)
            assert len(ready)==1 and "'Ready'" in ready[0]
            method=ready[0];kind='actual old-root Ready producer premise'
        replacements.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
        changes.append({'producer':name,'frame_index':index,'frame':row['captured_input'],'frame_sha256':row['input_sha256'],'method':method,'reason':kind})
        index+=1
    updated=block
    for left,right,replacement in reversed(replacements):updated=updated[:left]+replacement+updated[right:]
    snapshot=snapshot.replace(block,updated,1)
assert index==20 and len(changes)==11 and sum(r['reason']=='actual unique knowledge chain' for r in changes)==9 and len(restored)==9
main=main.replace(roots['Snapshot_case_5'],snapshot,1)
candidate=value[:a]+main+value[b:]
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,full)
assert candidate[:candidate.index('lemma ')]==full[:full.index('lemma ')]
assert main.count('by sorry')==25 and 'Oracle ranked no proof methods' not in main
output=root/'target/p0-origin-stored-reservation-replay-713';output.mkdir()
(output/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',output/'run.py')
record={'full_parent_sha256':sha(full.encode()),'capture_sha256':sha(raw),'input_sha256':sha(candidate.encode()),
    'actual_selected_methods':changes,'restored_unselected_producers':restored,
    'all18_sources_11stored_producers_29queries_retained':True,'all17_closed_sources_retained_byte_equal':True,
    'operational_prefix_unchanged':True,'independent_replay_no_search_or_oracle':True,
    'maximum_explicit_prefix':7,'total_depth_limit':16,'release_claim_eligible':False}
(output/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'actual_methods':len(changes),'restored_producers':len(restored)}))
