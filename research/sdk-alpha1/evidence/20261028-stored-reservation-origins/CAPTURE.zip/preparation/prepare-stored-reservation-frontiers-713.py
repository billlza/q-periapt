"""Inspect two actual Stored producers with all other obligations retained."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

root=Path.cwd();parent=root/'target/p0-origin-response-restored-713/response-restored-proof.spthy'
sha=lambda b:hashlib.sha256(b).hexdigest()
data=parent.read_bytes();assert sha(data)=='17388a2c9dee3d9c3ca497b6bf3f08bdb1f3b070a06f11117dfe89bf8e9843ac'
archive=root/'research/sdk-alpha1/evidence/20261028-response-source-origin/CAPTURE.zip'
assert sha(archive.read_bytes())=='3c8f8c0548a33f4a845980b147f03782e117b4c448cdc19d6716133f0fc8c442'
with zipfile.ZipFile(archive) as bundle:
    assert bundle.read('experiments/p0-origin-response-restored-713/response-restored-proof.spthy')==data
value=data.decode();start=value.index('lemma epoch_generation_secret_derivation_origin ');stop=value.index('\nlemma ',start)
main=value[start:stop]
sources={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(sources)==18 and sum('by sorry' not in b for b in sources.values())==17
stored=sources['Snapshot_case_5'];assert stored.count('by sorry')==36
producers={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',stored)}
assert len(producers)==11
selected={'Key_Reservation_1':5,'Response_Reservation_4':6}
assert all(producers[n].count('by sorry')==count for n,count in selected.items())
focused=stored
preserved={}
for name,block in producers.items():
    if name not in selected:
        focused=focused.replace(block,'      case '+name+'\n      by sorry\n',1)
        preserved[name]={'sha256':sha(block.encode()),'open_leaves':block.count('by sorry')}
candidate_main=main.replace(stored,focused,1)
candidate=value[:start]+candidate_main+value[stop:]
new_sources={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',candidate_main)}
assert set(new_sources)==set(sources) and all(new_sources[n]==b for n,b in sources.items() if n!='Snapshot_case_5')
assert candidate_main.count('by sorry')==20
assert max(len(m[1]) for m in re.finditer(r'(?m)^( +)by sorry',candidate_main))==12
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,value)
assert sha(candidate[:candidate.index('lemma ')].encode())=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-stored-reservations-713';stage.mkdir()
(stage/'model.spthy').write_text(candidate)
base=root/'target/p0-origin-source-frontiers-705'
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):
    shutil.copy2(base/name,stage/name)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1
driver.write_text(driver.read_text().replace('--bound=13','--bound=10'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)))
(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(parent),'full_parent_sha256':sha(data),'input_sha256':sha(candidate.encode()),
    'selected_producers':selected,'all18_sources_and11_stored_producers_and29_queries_retained':True,
    'all17_closed_sources_retained_byte_equal':True,'full_snapshot_subtree_sha256':sha(stored.encode()),
    'unselected_subtrees_preserved_in_parent':preserved,'must_restore_all_subtrees_before_final_replay':True,
    'focused_open_leaves':20,'existing_open_prefix_maximum':6,'remaining_search_bound':10,'total_depth_limit':16,
    'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
