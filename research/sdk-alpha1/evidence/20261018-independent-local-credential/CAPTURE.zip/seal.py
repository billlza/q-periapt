"""Seal public local-only renewal qualification and retained diagnostic failures."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd(); out = Path(__file__).resolve().parent
peer = root / 'research/continuity-openssl-peer'
folder = root / 'research/sdk-alpha1/evidence/20261018-independent-local-credential'
def sha(data): return hashlib.sha256(data).hexdigest()
labels = ['REGRESSION', 'CONTROL', 'RESOLUTION', 'WITNESS', 'PEER_LIFECYCLE', 'LOCAL_RENEWAL', 'REPLY_RELEASE', 'LOCAL_CREDENTIAL']
reports = {n: json.loads((out / (n + '_READBACK.json')).read_text()) for n in labels}
sources = reports['LOCAL_CREDENTIAL']['source_files']; assert len(sources) == 76
for name, report in reports.items():
    if name != 'REPLY_RELEASE':
        assert report['source_files'] == sources and not report['source_continuity']['test_harness_only_changes']
        assert report['native_sha256'] == reports['LOCAL_CREDENTIAL']['native_sha256']
runs = json.loads((out / 'QUALIFIED_RUNS.json').read_text())
assert len(runs) == 16 and all(row['exit'] == 0 for row in runs)
entries = {}
def add(name, data):
    assert name not in entries
    assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFW01', b'QPRFLC01', b'QPRFLI01',
                               *(('QPREFS0' + str(i)).encode() for i in range(1, 8))))
    entries[name] = data
def tree(name):
    for path in sorted((out / name).rglob('*')):
        if not path.is_file(): continue
        assert not path.is_symlink() and path.name not in {'head', 'intent', 'authority', 'configuration', 'signer', 'key', 'wrong-signer'} and not path.name.startswith('.stage-')
        add(name + '/' + str(path.relative_to(out / name)), path.read_bytes())
for name in ['qualified-' + row['lane'] for row in runs]:
    tree(name)
    for ext in ['stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
    assert not entries[name + '.stderr']
for name in ['creation-before', 'creation-after', 'process-01', 'reader-launch-path-error']:
    tree(name)
for name in ['creation-before', 'creation-after', 'process-01', 'recover-original-prototype', 'build', 'clippy']:
    for ext in ['stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
readers = ['qualified-review-final-regressions', 'qualified-review-final-control', 'qualified-review-resolution',
           'qualified-review-witness', 'qualified-review-peer-lifecycle', 'review-local-renewal',
           'review-reply-release', 'review-local-credential']
for name in readers:
    for ext in ['py', 'stdout', 'stderr']: add(name + '.' + ext, (out / (name + '.' + ext)).read_bytes())
    assert not entries[name + '.stderr']
for name in labels: add(name + '_READBACK.json', (out / (name + '_READBACK.json')).read_bytes())
for name in ['source_readback.py', 'run-qualified.py', 'QUALIFIED_RUNS.json', 'VALIDATION.json', 'seal.py',
             'creation-boundary.py', 'recover-original-prototype.py', 'before-resume-order.py.txt',
             'before-creation-guard-journal.py.txt', 'before-creation-guard-witness_journal.py.txt']:
    add(name, (out / name).read_bytes())
for i in range(3):
    for ext in ['stdout', 'stderr']: add(f'quality-{i}.{ext}', (out / f'quality-{i}.{ext}').read_bytes())
for name, expected in sources.items():
    data = (peer / name).read_bytes()
    assert sha(data) == expected and subprocess.check_output(['git', 'show', ':research/continuity-openssl-peer/' + name]) == data
    add('source/' + name, data)
for name in ['README.md', 'STORAGE.md', 'LOCAL_RENEWAL.md', 'LOCAL_CREDENTIAL.md']: add('source/' + name, (peer / name).read_bytes())
add('repository/.github/workflows/independent-continuity.yml', (root / '.github/workflows/independent-continuity.yml').read_bytes())
add('counterpart', (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes())
assert sha(entries['counterpart']) == reports['LOCAL_CREDENTIAL']['native_sha256']
scope = {'base_head': '73760183d28fd1c1f97c92a268f26376febc4144',
         'change': 'Independent original-local-policy credential coordinator; conditional schema7 retains pending/root identity/abandonment/time floor atomically with original session. Required witness does not fall back. Native changes are genuine fixture grants only.',
         'qualification': '16 actual runtime lanes,8 public readers,76 identical staged/executed sources. New local profiles148workers29kills plus capacity3workers. Strict native release build/all-target Clippy, format, actionlint, AST and diff checks.',
         'capacity': '122outbox rows; Pending27241B vs completed30742B,3501B difference. Stage refuses before mutation;64explicitly-accounted DeliveryUnknown rows freed while original authority current; same grant later commits. Combined88703Bmetadata is a tested workload, not every possible signed-input maximum.',
         'actual_repair': 'Retained authority creation previously wrote head then refused; now both journal initializers reject before publication. Before/after records and original failed private store retained.',
         'diagnostics': 'process-01 harness incorrectly replayed another operation while a send remained Reserved. Contract refusal preserved; corrected sequence expects refusal and resumes original Reserved first. Original failed private state continued with4freshworkers, without resetting. Native process had exited during harness cleanup; this continuation is not whole-native restart. Earlier smoke/process02/process03/capacity01 remain local diagnostic cohorts. Reader launch path error retained; it occurred before any reader executed.',
         'limits': 'Private journal/keys excluded; unchanged target, capacity, cancellation and creation effects are runtime assertions, not independent private-MAC proof. Native traffic clock170; independent supplied times cross root validity. Full store after expiry, same-account/publicregistration/policy/witness/device replacement, installed/cross-host lifecycle, physical erasure,powerloss,full retained-state PCS/refinement and resource qualification remain open.'}
add('SCOPE.json', (json.dumps(scope, indent=2) + '\n').encode())
manifest = {n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(entries.items())}
add('MANIFEST.json', (json.dumps(manifest, indent=2) + '\n').encode())
folder.mkdir(exist_ok=False); archive = folder / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        item = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0)); item.compress_type = zipfile.ZIP_DEFLATED; item.external_attr = 0o100644 << 16
        z.writestr(item, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(entries) and z.testzip() is None
    for name, value in manifest.items(): assert len(z.read(name)) == value['bytes'] and sha(z.read(name)) == value['sha256']
capture = {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())}
result = {'readbacks': reports, 'validation': json.loads(entries['VALIDATION.json']), 'capture': capture, 'scope': scope}
(folder / 'CHECKS.json').write_text(json.dumps(result, indent=2) + '\n'); print(json.dumps(capture))
