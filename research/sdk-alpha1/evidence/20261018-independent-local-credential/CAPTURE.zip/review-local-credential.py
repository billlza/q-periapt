"""Read public local renewal evidence without any private journal or key."""
from pathlib import Path
import ast, hashlib, json, re, sys

root = Path.cwd(); out = Path(__file__).resolve().parent
peer = root / 'research/continuity-openssl-peer'
sys.path.extend([str(peer), str(out)])
from provider import load_provider
load_provider(root / 'target/independent-bootstrap-01/provider')
from source_readback import source_bytes, continuity
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load
from peer.bootstrap import digest
from peer.renewal import verify
from peer.rekey import RekeyScope, genesis
from peer.traffic import message_id
from peer.identity_state import IdentityState
from peer.local_renewal_record import Record

def check(value, reason):
    if not value: raise ValueError(reason)
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return parse_strict_json_bytes(path.read_bytes(), label=str(path))

sources = None; profiles = {}
binary = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
check(binary[:4] == b'\xcf\xfa\xed\xfe' and int.from_bytes(binary[4:8], 'little') == 0x100000c, 'actual ARM64 binary')
for lane, labels in [('local-credential', ['committed', 'expired-credential', 'expired-roster', 'combined']),
                     ('local-credential-capacity', ['capacity'])]:
    base = out / ('qualified-' + lane); top = read(base / 'RESULT.json')
    check(not (out / ('qualified-' + lane + '.stderr')).read_bytes(), 'runtime diagnostics')
    check(len(top['source_files']) == 76 and sha(binary) == top['native_sha256'], 'source and native identity')
    if sources is None:
        sources = top['source_files']
        for name, expected in sources.items():
            data = source_bytes(name, expected); check(sha(data) == expected, 'source hash')
            if name.endswith('.py'): ast.parse(data, name)
    else: check(top['source_files'] == sources, 'same executed closure')
    for label in labels:
        folder = base / label; r = read(folder / 'RESULT.json'); native = {}; workers = {}; kills = 0
        check(not (folder / 'native/native.stderr').read_bytes(), 'native diagnostics')
        for row in r['native_commands']:
            name = row['case']; check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', name) and name not in native, 'native case identity')
            before = (folder / 'native/cases' / (name + '.input')).read_bytes()
            after = (folder / 'native/cases' / (name + '.output')).read_bytes()
            check(sha(before) == row['input_sha256'] and sha(after[1:]) == row['output_sha256'] and after[0] == row['status'], 'native raw bytes')
            if after[0] == 2: check(after[1:].decode() == row['error'], 'native refusal')
            native[name] = (before, after, row['command'])
        for row in r['worker_operations']:
            name = row['case']; check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', name) and name not in workers, 'worker identity')
            request = read(folder / (name + '.request.json')); raw = (folder / (name + '.stdout')).read_bytes()
            error = (folder / (name + '.stderr')).read_text()
            check(request['action'] == row['action'], 'worker action'); workers[name] = request
            if 'signal' in row:
                kills += 1
                check(row['signal'] == 'SIGKILL' and read(folder / (name + '.stdout')) == {'pid': row['worker_pid'], 'stage': row['cut']} and not error, 'actual process cut')
            elif 'refused' in row: check(not raw and row['refused'] in error, 'refusal withholds output')
            else: check(not error and sha(raw) == row['stdout_sha256'], 'worker result bytes')
        expected = {'committed': (34, 8, 9, 18), 'expired-credential': (39, 7, 9, 16),
                    'expired-roster': (39, 7, 9, 16), 'combined': (36, 7, 10, 16), 'capacity': (3, 0, 6, 2)}[label]
        check((len(workers), kills, len(native), len(r['refusals'])) == expected and kills == r['process_kills'], 'exact profile workload')
        def result(name): return read(folder / (name + '.stdout'))['result']
        def wire(name): return bytes.fromhex(result(name))
        public = folder / 'native/public'; _, _, ctx = load(public, 150)
        check(ctx.witness is None, 'original signed local-only policy')
        initial = wire('initial'); reply = native['bootstrap-reply'][1][1:]; final = wire('finish')
        check(ctx.initiator.open(initial, 5, 2440)[:40] == b'QPBSI001' + ctx.digest, 'initial signature')
        check(native['bootstrap-reply'][0] == initial and ctx.responder.open(reply, 6, 1256)[:72] == b'QPBSR001' + ctx.digest + digest(b'initial-wire', initial), 'reply signature and exact initial')
        check(final[:104] == b'QPBSF001' + ctx.digest + digest(b'initial-wire', initial) + digest(b'reply-wire', reply), 'original transcript')
        session = digest(b'session-id', final[:104])
        check(result('activate') == r['session'] == session.hex() and native['complete'][:2] == (final, b'\1' + session), 'original session identity')
        def grant(prefix, now, role=0):
            g = verify((public / prefix).read_bytes(), ctx.devices[role], ctx.family, ctx.policy_digest,
                       (public / ('pin-' + prefix + '-target')).read_bytes(), now=now)
            check(g.operation == (public / (prefix + '-operation')).read_bytes() and g.statement == (public / (prefix + '-statement')).read_bytes(), 'native independent root grant agreement')
            return g
        first = grant('local-renewal-1', 170 if label in ('expired-roster', 'capacity') else 210)
        def status(name, g, kind, floor=0):
            value = result(name)
            check(set(value) == {'status', 'operation', 'statement', 'target', 'time_floor', 'expired_observation'}, 'structured outcome fields')
            check((value['status'], value['operation'], value['statement'], value['target'], value['time_floor']) ==
                  (kind, g.operation.hex(), g.statement.hex(), g.successor_roster.checkpoint().hex(), floor), 'original outcome binding')
            if kind != 'ExpiredUncommitted': check(value['expired_observation'] is None, 'completion is not abandonment')
            return value
        if label == 'capacity':
            identity = IdentityState.initial(ctx, role=0)
            completed = identity.renew(ctx, first.wire, first.operation, first.successor_roster.checkpoint(), 170)
            pending_size = len(Record(pending=first).encode()) + 1
            complete_size = len(completed.encode()) + len(Record().encode()) + 1
            check((pending_size, complete_size) == (r['pending_metadata_bytes'], r['completed_metadata_bytes']) == (27241, 30742), 'metadata size from actual signed grant')
            check(r['traffic_bytes'] + pending_size == r['traffic_cap_without_metadata'] == 2 * 1024**2 - 65536 and complete_size - pending_size == r['completed_metadata_excess'] == 3501, 'exact final capacity difference')
            check(r['rows'] == 122 and r['pending_encoding_fits'] and r['stage_refusal_preserved_head'] and r['final_format'] == 7, 'runtime capacity assertions')
            report = read(folder / 'RESOLUTION.json'); receipt = read(folder / 'APPLICATION_DECISION.json'); decision = receipt['decision']
            canonical = (json.dumps(decision, sort_keys=True, separators=(',', ':')) + '\n').encode()
            check(sha(canonical) == receipt['sha256'] and len(canonical) == receipt['bytes'], 'actual host accounting receipt')
            check(decision['session'] == session.hex() and decision['role'] == 1 and decision['report_id'] == report['id'] and decision['epoch'] == report['epoch'] == 0, 'host report binding')
            check(decision['outgoing'] == [dict(row, decision='delivery_unknown') for row in report['outgoing']] and len(report['outgoing']) == r['host_accounted_unknown_outboxes'] == 64, 'unknown outcomes are not ACKs')
            check(decision['incoming'] == report['incoming'] == [] and decision['skipped'] == report['skipped'] == [] and report['acknowledged_before'] == 0, 'complete accounting')
            payload, plaintext, command = native['receive-surviving-outbox']
            check(command == 7 and payload[:2] == b'\0\0' and sha(payload[2:]) == r['surviving_ciphertext_sha256'] and payload[2+57:2+89].hex() == r['surviving_id'] and plaintext[0] == 1, 'native surviving ciphertext acceptance')
            prefix = 'capacity-rekey-'
            offer = native[prefix + 'response'][0]; response = native[prefix + 'response'][1][1:]
            final_rekey = native[prefix + 'receipt'][0]; ack = native[prefix + 'receipt'][1][1:]
            RekeyScope(ctx, session, 0, genesis(session, ctx.digest)).public_completed(offer, response, final_rekey, ack)
        else:
            status('recover-original-stage', first, 'Pending'); status('resigned-stage-retry', first, 'Pending')
            resigned = verify((public / 'local-renewal-1-resigned').read_bytes(), ctx.devices[0], ctx.family, ctx.policy_digest, first.successor_roster.checkpoint())
            check(resigned.operation == first.operation and resigned.statement == first.statement and resigned.wire != first.wire, 'genuine semantic resigning')
            request = workers['stage-intent-kill']
            check(request['arguments'] == [first.operation.hex(), first.wire.hex(), first.successor_roster.checkpoint().hex()], 'original stage bytes')
            check(result('original-id') == r['original_id'] and result('reserved-id') == r['reserved_id'] and sha(wire('original-send')) == r['original_ciphertext_sha256'], 'original operation identities')
            check(wire('original-replayed') == wire('original-send') and wire('reserved-replayed') == wire('reserved-resumed') and sha(wire('reserved-resumed')) == r['reserved_ciphertext_sha256'], 'retained original ciphertexts')
            for tag, expected_text, count in [('original', b'original local message', 1), ('reserved', b'reserved before local expiry', 2)]:
                frame = wire('original-send' if tag == 'original' else 'reserved-resumed')
                check(native['receive-' + tag][:2] == (b'\0\5local' + frame, b'\1' + expected_text), 'native original plaintext')
                check(frame[:41] == b'QPCMSG03' + session + b'\1' and frame[57:89] == message_id(session, 1, count - 1, 0), 'original frame coordinates')
                check(workers['accept-' + tag + '-ACK']['arguments'] == [native['consume-' + tag][1][1:].hex()] and result('accept-' + tag + '-ACK') == count, 'actual consumed prefix')
            flights = [wire('renewed-rekey-offer'), native['renewed-rekey-response'][1][1:], wire('renewed-rekey-final'), native['renewed-rekey-receipt'][1][1:]]
            RekeyScope(ctx, session, 0, genesis(session, ctx.digest)).public_completed(*flights)
            check(native['renewed-rekey-response'][0] == flights[0] and native['renewed-rekey-receipt'][0] == flights[2] and result('renewed-rekey-confirm') == 1, 'same session rekey')
            if label in ('committed', 'combined'):
                status('committed-readback', first, 'Committed'); check(result('format-seven') == 7, 'conditional format seven')
                second = grant('local-renewal-2', 310)
                check(second.previous.digest == first.successor.digest and second.predecessor_roster.checkpoint() == first.successor_roster.checkpoint(), 'chained root grants')
                if label == 'committed':
                    status('second-stage-after-close', second, 'Pending'); status('second-expired-recovery', second, 'Committed'); status('second-historical-commit', second, 'Committed')
                    check(workers['second-expired-recovery']['now'] == 401, 'actual expired metadata recovery')
                else:
                    status('stage-second-with-peer-metadata', second, 'Pending'); status('commit-second-with-peer', second, 'Committed')
                    remote = grant('peer-renewal-1', 210, role=1); grant('peer-renewal-2', 310, role=1)
                    local_identity = IdentityState.initial(ctx, role=0).renew(ctx, first.wire, first.operation, first.successor_roster.checkpoint(), 210)
                    remote_identity = IdentityState.initial(ctx).renew(ctx, remote.wire, remote.operation, remote.successor_roster.checkpoint(), 210)
                    metadata = len(local_identity.encode()) + len(remote_identity.encode()) + len(Record(pending=second).encode()) + 1
                    check(metadata == r['combined_metadata_bytes'] == 88703 and metadata > 73728, 'combined metadata from real grants')
                    check(native['receive-both-current'][:2] == (b'\0\5local' + wire('combined-new-send'), b'\1both current identities'), 'new combined traffic')
            else:
                observed = 190 if label == 'expired-roster' else 310
                terminal = status('expiry-terminal-recovery', first, 'ExpiredUncommitted', observed)
                check(terminal == r['expiry_terminal'] and terminal['expired_observation']['at'] == observed and terminal['expired_observation']['digest'] == r['original_stage_target_sha256'], 'retained original expiry observation')
                check(first.successor.validity.end <= observed or first.successor_roster.validity.end <= observed, 'actual signed expiry boundary')
                if label == 'expired-roster':
                    ctx.check_established(observed); check(first.successor.validity.end > observed and r['original_authority_still_live'], 'roster-only expiry while original authority live')
                status('same-expired-stage-is-historical', first, 'ExpiredUncommitted', observed)
                status('prior-expiry-survives-new-pending', first, 'ExpiredUncommitted', observed)
                alternate = grant('local-renewal-alternate', observed)
                check(alternate.previous.digest == ctx.devices[0].credential and alternate.previous.digest != first.successor.digest, 'replacement uses actual uncommitted predecessor')
                status('alternate-completed', alternate, 'Committed', observed)
                check(workers['backdated-new-grant-refused']['now'] == workers['business-time-floor-retained']['now'] == observed - 1, 'explicit backdate refusals')
        profiles[label] = {'workers': len(workers), 'native_commands': len(native), 'actual_SIGKILL': kills, 'direct_refusals': len(r['refusals'])}

before = read(out / 'creation-before/RESULT.json'); after = read(out / 'creation-after/RESULT.json')
check(before['head_created'] and not after['head_created'], 'observed creation side effect removed')
summary = {'base_head': '73760183d28fd1c1f97c92a268f26376febc4144', 'source_files': sources,
           'source_continuity': continuity(sources), 'native_sha256': sha(binary), 'native_architecture': 'MachO64 ARM64',
           'profiles': profiles, 'creation_before': before, 'creation_after': after,
           'scope': 'Exact source/native bytes, root signatures, original operations, traffic/rekey, status records and process cut markers. Private target preservation, metadata/image capacity, close cancellation and no-write creation assertions remain runtime observations, not independently rederived MAC/AEAD. Native traffic clock remains170. No installed/cross-host/full identity lifecycle, witness rollback, power-loss, physical erasure or PCS claim.'}
(out / 'LOCAL_CREDENTIAL_READBACK.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(profiles))
