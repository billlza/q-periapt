from pathlib import Path
import hashlib,json,sys
root=Path.cwd();sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from session_driver import SessionDriver
from peer.wire import require
out=root/'target/independent-local-credential-01/process-01/committed';private=Path((out/'private-fixture-path').read_text().strip())
def result(name):return json.loads((out/(name+'.stdout')).read_text())['result']
original=bytes.fromhex(result('original-id'));reserved=bytes.fromhex(result('reserved-id'));expected=bytes.fromhex(result('original-send'))
driver=SessionDriver(out,root/'target/independent-bootstrap-01/provider',out/'native/public',private/'configuration',private/'session',private/'signer')
wire=driver.run('continued-original-reservation','resume',(reserved,),now=210)
require(driver.run('continued-reservation-replay','resume',(reserved,),now=210)==wire,'original reserved identity changed')
require(bytes.fromhex(driver.run('continued-old-outbox','resume',(original,),now=210))==expected,'original ciphertext changed')
require(driver.run('continued-format','storage_format',now=210)==7,'original store format')
(out/'ORIGINAL_CONTINUATION.json').write_text(json.dumps({'worker_operations':driver.operations,'original_ciphertext_sha256':hashlib.sha256(expected).hexdigest(),'reserved_ciphertext_sha256':hashlib.sha256(bytes.fromhex(wire)).hexdigest(),'scope':'Original interrupted private store reopened directly without reset or replacement. Complete its actual reserved send first, then replay the old exact ciphertext. Original native endpoint had already exited in failed harness cleanup; this is independent-store continuation, not native service restart or new interoperability.'},indent=2)+'\n')
print('Original private store resumed; reserved and old outbox identities preserved without replacement.')
