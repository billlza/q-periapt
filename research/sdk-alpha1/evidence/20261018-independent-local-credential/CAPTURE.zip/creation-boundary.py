from pathlib import Path
import argparse,hashlib,json,os,sys,tempfile
root=Path.cwd();sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from fixture_inputs import load
from signing_fixture import read
from peer.journal import Scope
from peer.durable import Session,owner_binding
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args();out=args.output;out.mkdir()
original=root/'target/independent-local-credential-01/process-02/committed';private=Path((original/'private-fixture-path').read_text().strip())
_,_,ctx=load(original/'native/public',150);signer=read(private/'signer')
path=Path(tempfile.mkdtemp(prefix='qperiapt-retained-authority-create-')).resolve();(out/'private-fixture-path').write_text(str(path)+'\n')
marker=b'original coordination marker'
with os.fdopen(os.open(path/'authority',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as f:f.write(marker);f.flush();os.fsync(f.fileno())
error=None
try:
 owner=Session.create(path,Scope(os.urandom(32),owner_binding(ctx),ctx.digest),os.urandom(32),ctx,signer,150);owner.close()
except ValueError as e:error=str(e)
report={'error':error,'head_created':(path/'head').exists(),'intent_created':(path/'intent').exists(),'original_marker_unchanged':(path/'authority').read_bytes()==marker,'sources':{n:hashlib.sha256((root/'research/continuity-openssl-peer'/n).read_bytes()).hexdigest() for n in ['peer/journal.py','peer/durable.py','peer/local_authority_control.py']}}
(out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
