from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk
import continuity_android_continuation as continued

root=Path.cwd();stage=Path(__file__).resolve().parent;old=root/'target/continuity-android-pending-process'
def replace(text,old,new):
    sdk.require(text.count(old)==1,'recipe shape: '+old[:80]);return text.replace(old,new)
def template(name):
    return (old/name).read_text().replace('continuity-android-pending-process','continuity-android-pending-continuation').replace('dev.qperiapt.continuity.pendingprocess20261015','dev.qperiapt.continuity.pendingcontinuation20261015')
commit=template('commit-03.py').replace('Qualify process loss during pending recovery confirmation','Qualify continued traffic after pending recovery and policy renewal')
commit=commit.replace("'artifact.test_continuity_android_joint_cycle'","'artifact.test_continuity_android_joint_cycle','artifact.test_continuity_android_continuation','artifact.test_continuity_android_policy_renewal'")
host=template('run-installed-04.py').replace('import continuity_android_pending as pending','import continuity_android_continuation as continued')
host=host.replace("'jar','bridge']","'jar','bridge','target_client']").replace("QPC_CONFIGURATION_RECEIVER=cfg['receiver'])","QPC_CONFIGURATION_RECEIVER=cfg['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=cfg['target_client'])")
host=host.replace('android_pending_process::','android_pending_continuation::').replace('pending.PROCESS_TESTS','continued.TESTS').replace('pending.verify_execution','continued.verify_execution').replace(',process_loss=True','').replace('-process-loss','-continuation').replace('pending.public(label.endswith(\'-applied\'))','continued.public(label)')
host=host.replace('pending confirmation process loss','pending recovery, independent renewal and post-rekey traffic')
apk=template('apk-07.py')
driver=template('device-driver-07.py').replace('tls-recoverable-applied-process-loss','tls-recoverable-applied-continuation')
driver=replace(driver,'assert mode in allowed','allowed.update('+repr(sorted({mode for _,mode in continued.cases('tls')}))+')\nassert mode in allowed')
driver=replace(driver,"peer_mode=mode.removeprefix('roster-witness-') if mode.startswith('roster-witness-peer-') else None",
 "peer_mode=mode.removeprefix('roster-witness-') if mode.startswith('roster-witness-peer-') else mode.removeprefix('policy-') if mode.startswith('policy-peer-') else None")
driver=replace(driver,"    if mode=='pending-roster-unknown':", """    if peer_mode in ['peer-retry','peer-send']:names+=['connection-message']
    if mode=='policy-target-create':names+=['target-policy-version','target-policy-digest','target-protocol-policy']
    if mode=='policy-request':names+=['renewal-operation']
    if mode.startswith('policy-stage'):names+=['renewal-request','renewal-approvals','renewal-statement']
    if mode.startswith('policy-witness-') and mode not in ['policy-witness-prepare','policy-witness-recover']:names+=['renewal-proposal']
    if mode=='pending-roster-unknown':""")
driver=replace(driver,"path=inputs/'peer'/name[5:] if name.startswith('peer-') else inputs/name",
 "path=inputs/'peer'/name[5:] if name.startswith('peer-') else inputs/'policy-target'/name[7:] if name.startswith('target-') else inputs/name")
driver=replace(driver,"65536 if mode.startswith('pending-') else 8192","65536 if mode.startswith(('pending-','policy-')) else 8192")
driver=replace(driver,"if mode=='pending-identity' and label=='original-identity-after':cleanup();state['completed']=True",
 "if mode=='policy-identity' and label=='continued-final.identity':cleanup();state['completed']=True")
run=template('run-device-07.py').replace('import continuity_android_pending as pending','import continuity_android_continuation as continued')
run=run.replace('-process-loss','-continuation').replace('pending.PROCESS_TESTS','continued.TESTS').replace('pending.verify_execution','continued.verify_execution').replace(',process_loss=True','')
run=run.replace('pending.cases(True)','continued.cases(\'tls\')').replace('pending.public(True)','continued.public(label)')
# The phone executes both the original recovery calls and the continued calls.
run=replace(run,"label='tls-recoverable-applied';case_label=label+'-continuation'", "label='tls-recoverable-applied';case_label=label+'-continuation'\nimport continuity_android_pending as pending\nexpected_calls=len(pending.cases(True,process_loss=True))+len(continued.cases('tls'))")
run=run.replace("len(continued.cases('tls')),'ART process census'","expected_calls,'ART process census'")
run=run.replace("len(state['cases'])==len(continued.cases('tls'))", "len(state['cases'])==expected_calls")
run=run.replace("['harness','receiver','library']","['harness','receiver','library','target_client']").replace("QPC_CONFIGURATION_RECEIVER=cfg['receiver'])","QPC_CONFIGURATION_RECEIVER=cfg['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=cfg['target_client'])")
run=run.replace('held Query process loss and confirmation result loss','recovery, independent policy renewal, rekey and fresh traffic').replace('all 23 original pending recovery calls with two actual process cuts','all 60 continued lifecycle calls with two actual process cuts')
package=json.loads((old/'physical-06/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
out=stage/'physical-06';out.mkdir()
sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');sdk.write_json(out/'PACKAGE.json',package)
recipes={'commit-03.py':commit,'run-installed-04.py':host,'apk-07.py':apk,'device-driver-07.py':driver,'run-device-07.py':run}
for name,value in recipes.items():
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
sdk.write_json(stage/'RECIPES_03.json',{name:sdk.snapshot(stage/name).sha256 for name in recipes})
print('Continued lifecycle recipes prepared; reused exact AAR; target client and policy transport explicit')
