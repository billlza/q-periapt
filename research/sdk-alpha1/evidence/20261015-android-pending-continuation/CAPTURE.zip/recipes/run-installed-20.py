from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
import continuity_android_continuation as continued

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'BUILD_18.json').read_text())
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'probe source changed')
for name in ['harness','driver','receiver','library','jar','bridge','target_client']:
    sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'baseline runtime changed')
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'source not clean')
cases=stage/'host-cases-20';sdk.require(not cases.exists(),'output already exists')
record={'completed':False,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'candidate_sha256':cfg['candidate_sha256'],'scope':'Actual unchanged installed engine; public pending recovery, independent renewal and post-rekey traffic; not full release acceptance',
 'physical_ART':False,'release_claim_eligible':False}
sdk.write_json(stage/'RUN_STATE_20.json',record)
env=dict(cfg['environment'],QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=cfg['driver'],QPC_CONFIGURATION_RECEIVER=cfg['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=cfg['target_client'])
try:
    stdout=sdk.command([cfg['harness'],'android_pending_continuation::','--test-threads=2','--nocapture'],stage/'host-run-20',Path(cfg['consumer']),environment=env)
    results={}
    for label in continued.TESTS:results.update(continued.verify_execution(stdout,cases,label,batch=True))
    for label in continued.TESTS:
        case_label=label+'-continuation'
        for name in continued.public(label):sdk.copy(cases/case_label/name,stage/'public-20'/case_label/name)
        sdk.require(continued.verify_execution(stdout,stage/'public-20',label,batch=True)[case_label]==results[case_label],'public readback differs')
    record.update(completed=True,cases=results,foreign_processes=sum(value['foreign_processes'] for value in results.values()))
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(stage/'RUN_RESULT_20.json',record)
print('Both actual installed public pending recovery, independent renewal and post-rekey traffic routes passed')
