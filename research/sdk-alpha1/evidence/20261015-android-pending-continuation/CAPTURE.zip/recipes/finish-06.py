from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_c_witness_openssl as openssl

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'INPUTS_05.json').read_text())
outside=Path(cfg['outside']);consumer=Path(cfg['consumer']);builder=Path(cfg['android_source'])
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());old=cfg['installed_base'];runtime=outside/'runtime';classes=outside/'tests'
sdk.require(classes.is_dir() and not list(classes.iterdir()),'failed Java start unexpectedly produced classes')
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
for name in ['receiver','library','jar','bridge']:
    sdk.require(sdk.snapshot(runtime/Path(old[name]).name,maximum=256*1024**2).sha256==old[name+'_sha256'],'runtime copy changed')
rows=[json.loads(line) for line in (stage/'harness-05.stdout').read_bytes().splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'harness count')
java=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
jar=runtime/Path(old['jar']).name
sdk.command([str(java/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),
 *map(str,sorted((builder/'src/test/java').glob('*.java')))],stage/'java-06',outside,environment=env)
driver=android._driver(runtime,java/'bin/java',jar,classes,runtime)
clang=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],stage/'clang-06',outside).decode().strip()
platform=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],stage/'platform-06',outside).decode().strip()
def run(argv,label):return sdk.command(argv,stage/(label+'-06'),outside,environment=env)
peer,peer_record=openssl.build_peer(Path('/opt/homebrew/opt/openssl@3'),Path(clang),['-isysroot',platform],consumer,runtime,run,darwin=True,profile='debug')
target_client=runtime/'qpc-configuration-client'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
 str(consumer/'first_configuration_client.c'),'-I'+str(consumer),'-L'+str(runtime),
 '-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(target_client)],stage/'target-client-06',outside,environment=env)
files={'target_client':target_client,'harness':Path(tests[0]),'driver':driver,'receiver':runtime/Path(old['receiver']).name,
       'library':runtime/Path(old['library']).name,'jar':jar,'bridge':runtime/Path(old['bridge']).name}
cfg.update({name:str(path) for name,path in files.items()});cfg.update({name+'_sha256':sdk.snapshot(path,maximum=256*1024**2).sha256 for name,path in files.items()})
cfg['openssl']=peer_record;cfg['test_classes']={str(path.relative_to(classes)):sdk.snapshot(path).sha256 for path in classes.rglob('*.class')}
cfg['environment']=old['environment'];cfg['built']=True;sdk.write_json(stage/'BUILD_06.json',cfg)
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'matrix source changed')
print('Actual archived engine, full matrix harness, strict checks and independent OpenSSL peer ready')
