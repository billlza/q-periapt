from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(json.loads((stage/'clippy-02.json').read_text())['returncode']==101,'original strict failure missing')
cfg=json.loads((stage/'INPUTS_01.json').read_text());env=json.loads((stage/'ENVIRONMENT_01.json').read_text())
name='bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/flow.rs'
path=Path(cfg['consumer'])/'tests/common/android_pending_write/flow.rs'
sdk.require(sdk.snapshot(path).sha256==cfg['source_files'][name],'original compiled source changed')
sdk.copy(path,stage/'failed-flow-02.rs')
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',name],stage/'format-05',root,environment=env)
path.write_bytes(sdk.snapshot(root/name).data);cfg['source_files'][name]=sdk.snapshot(root/name).sha256
sdk.write_json(stage/'INPUTS_05.json',cfg)
recipe=(stage/'build-02.py').read_text().replace('INPUTS_01.json','INPUTS_05.json').replace('-02','-05').replace('BUILD_02.json','BUILD_05.json')
ast.parse(recipe)
with (stage/'build-05.py').open('x') as stream:stream.write(recipe)
for name in ['commit-03.py','run-installed-04.py','run-device-07.py']:
    p=stage/name;text=p.read_text();sdk.require(text.count('BUILD_02.json')==1,'unconsumed recipe shape')
    text=text.replace('BUILD_02.json','BUILD_05.json')
    if name=='commit-03.py':
        for label in ['readers','harness','catalog','clippy']:text=text.replace(label+'-02',label+'-05')
    ast.parse(text);p.write_text(text)
sdk.write_json(stage/'RECIPES_05.json',{name:sdk.snapshot(stage/name).sha256 for name in
 ['build-05.py','commit-03.py','run-installed-04.py','apk-07.py','device-driver-07.py','run-device-07.py']})
print('Strict failure retained; continuation context consumed without an artificial drop; no lint suppression')
