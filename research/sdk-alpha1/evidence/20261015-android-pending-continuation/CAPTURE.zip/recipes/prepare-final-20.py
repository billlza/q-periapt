from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
commit=(stage/'commit-09.py').read_text().replace('BUILD_09.json','BUILD_18.json')
for label in ['harness','catalog','clippy']:commit=commit.replace("'"+label+"-09'","'"+label+"-18'")
commit=commit.replace("'readers-05'","'readers-18'")
for label in ['diff','stage','commit','clone-fetch','clone-checkout','source-gate','clone-controls']:
    commit=commit.replace("'"+label+"-09'","'"+label+"-19'")
commit=commit.replace('SOURCE_09.json','SOURCE_19.json').replace('SOURCE_COMMIT_09.json','SOURCE_COMMIT_19.json')
commit=commit.replace('Fix original session selection for continued rekey','Support exact fresh-message effects in reference consumers')
host=(stage/'run-installed-11.py').read_text().replace('BUILD_09.json','BUILD_18.json')
for label in ['host-cases','host-run','public']:host=host.replace(label+'-11',label+'-20')
host=host.replace('RUN_STATE_11.json','RUN_STATE_20.json').replace('RUN_RESULT_11.json','RUN_RESULT_20.json')
def physical(name):
    text=(stage/name).read_text().replace('physical-12','physical-22').replace('BUILD_09.json','BUILD_18.json')
    for label in ['agp','qualification','consumer','run','device','device-driver']:text=text.replace(label+'-13',label+'-23')
    return text.replace('PREPARED_APK_13.json','PREPARED_APK_23.json').replace('dev.qperiapt.continuity.pendingcontinued20261015','dev.qperiapt.continuity.pendingresumed20261015')
apk=physical('apk-13.py');driver=physical('device-driver-13.py');run=physical('run-device-13.py')
key="        state=json.loads(state_path.read_text())\n        if state.get('installation_attempted')"
sdk.require(run.count(key)==1,'final cleanup state branch')
run=run.replace(key,"        state=json.loads(state_path.read_text())\n        record['cleanup']=state['cleanup']\n        if state.get('installation_attempted')")
package=json.loads((stage/'physical-12/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
out=stage/'physical-22';out.mkdir()
sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');sdk.write_json(out/'PACKAGE.json',package)
recipes={'commit-19.py':commit,'run-installed-20.py':host,'apk-23.py':apk,'device-driver-23.py':driver,'run-device-23.py':run}
for name,value in recipes.items():
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
sdk.write_json(stage/'RECIPES_20.json',{name:sdk.snapshot(stage/name).sha256 for name in recipes})
print('Fresh full-chain cohorts prepared with explicit receiver application contract and accurate cleanup status')
