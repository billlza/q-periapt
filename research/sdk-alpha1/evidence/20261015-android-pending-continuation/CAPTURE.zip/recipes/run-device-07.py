from pathlib import Path
import hashlib
import json
import shlex
import sys
import rust_sdk_profile as sdk
import continuity_android_contract as contract
import continuity_android_continuation as continued

root=Path.cwd();stage=root/'target/continuity-android-pending-continuation';device=stage/'physical-06'
cfg=json.loads((stage/'BUILD_06.json').read_text())
prepared=json.loads((device/'PREPARED_APK_07.json').read_text());sdk.require(prepared['completed'],'APK incomplete')
out=device/'run-07';out.mkdir();cases=out/'cases';driver=out/'driver'
driver.write_text('#!/bin/sh\nset -eu\nexport QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14\nexec /bin/sh '+
    shlex.quote(str(root/'artifact/python-run.sh'))+' '+shlex.quote(str(stage/'device-driver-07.py'))+' "$@"\n')
driver.chmod(0o700)
label='tls-recoverable-applied';case_label=label+'-continuation'
import continuity_android_pending as pending
expected_calls=len(pending.cases(True,process_loss=True))+len(continued.cases('tls'))
files={name:Path(cfg[name]) for name in ['harness','receiver','library','target_client']}
files.update(driver=driver,controller=stage/'device-driver-07.py',apk=Path(prepared['apk']))
digests={name:sdk.snapshot(path,maximum=256*1024**2).sha256 for name,path in files.items()}
for name in ['harness','receiver','library','target_client']:sdk.require(digests[name]==cfg[name+'_sha256'],'installed binary changed')
sdk.require(digests['apk']==prepared['apk_sha256'],'APK changed')
env=dict(cfg['environment'],QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(driver),QPC_CONFIGURATION_RECEIVER=cfg['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=cfg['target_client'])
record={'completed':False,'cleanup':False,'source_commit':prepared['source_commit'],'engine_source_commit':cfg['installed_base']['source_commit'],
 'candidate_sha256':cfg['candidate_sha256'],'aar_sha256':prepared['aar_sha256'],'apk_sha256':prepared['apk_sha256'],
 'input_sha256':digests,'release_claim_eligible':False,'scope':'One accepted API37 arm64 phone; TLS/recoverable/applied pending recovery with recovery, independent policy renewal, rekey and fresh traffic, actual R8 APK/AAR, independent controller, same protocol implementation'}
state_path=device/'device-07/STATE.json'
try:
    contract.verify_catalog(sdk.command([cfg['harness'],'--list'],out/'catalog',Path(cfg['consumer']),environment=env))
    stdout=sdk.command([cfg['harness'],'--exact',continued.TESTS[label],'--nocapture'],out/'execution',Path(cfg['consumer']),environment=env)
    result=continued.verify_execution(stdout,cases,label)
    state=json.loads(state_path.read_text())
    sdk.require(state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports'),'ART completion or cleanup missing')
    sdk.require(len(state['cases'])==expected_calls and len({row['pid'] for row in state['cases']})==expected_calls,'ART process census')
    sdk.require(sum(row['actual_cut_observed'] for row in state['cases'])==2,'actual process-cut census')
    for row in state['cases']:
        sdk.require(sdk.snapshot(cases/case_label/row['label']).sha256==row['result_sha256']
            and row['installed_apk_sha256']==prepared['apk_sha256'] and row['process_absent_after_operation'],'ART result provenance')
    for name in continued.public(label):sdk.copy(cases/case_label/name,out/'public'/case_label/name)
    sdk.require(continued.verify_execution(stdout,out/'public',label)==result,'public readback differs')
    for name,path in files.items():sdk.require(sdk.snapshot(path,maximum=256*1024**2).sha256==digests[name],'producer changed')
    record.update(completed=True,cleanup=True,result=result,physical_processes=len(state['cases']),actual_process_cuts=2)
except BaseException as error:
    record['failure']=repr(error);raise
finally:
    if state_path.exists():
        state=json.loads(state_path.read_text())
        if state.get('installation_attempted') and not state.get('cleanup'):
            try:
                sdk.require(state.get('apk_sha256')==prepared['apk_sha256'],'cleanup ownership')
                adb=['/Users/bill/Library/Android/sdk/platform-tools/adb','-P','15037','-s','<SELECTED_ANDROID_DEVICE>']
                for port in list(state.get('owned_reverse_ports',[])):
                    sdk.command(adb+['reverse','--remove','tcp:'+str(port)],out/('cleanup-reverse-'+str(port)),root)
                    state['owned_reverse_ports'].remove(port);sdk.write_json(state_path,state)
                package='dev.qperiapt.continuity.pendingcontinuation20261015'
                present=sdk.command(adb+['shell','pm','list','packages','--user','0',package],out/'cleanup-present',root)
                if present.strip():
                    sdk.require(present.strip()==('package:'+package).encode(),'cleanup package differs')
                    sdk.command(adb+['shell','am','force-stop',package],out/'cleanup-stop',root)
                    sdk.require(sdk.command(adb+['uninstall',package],out/'cleanup-uninstall',root).strip()==b'Success','cleanup uninstall')
                sdk.require(not sdk.command(adb+['shell','pm','list','packages','--user','0',package],out/'cleanup-absent',root).strip(),'residual package')
                state['cleanup']=True;record['cleanup']=True;sdk.write_json(state_path,state)
            except BaseException as error:record['cleanup_failure']=repr(error)
    sdk.write_json(out/'RESULT.json',record)
print('Actual API37 phone completed all 60 continued lifecycle calls with two actual process cuts and owned-resource cleanup')
