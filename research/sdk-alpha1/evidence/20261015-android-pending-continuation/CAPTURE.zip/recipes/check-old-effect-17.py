from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;out=stage/'old-effect-17';out.mkdir(mode=0o700)
sdk.copy(root/'bindings/c/ContinuityPackageConsumer/application_effect.h',out/'application_effect.h')
sdk.copy(stage/'effect-contract.c',out/'effect-contract.c')
clang=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],stage/'effect-clang-17',root).decode().strip()
platform=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],stage/'effect-platform-17',root).decode().strip()
program=out/'effect-contract'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
 str(out/'effect-contract.c'),'-I'+str(out),'-o',str(program)],stage/'effect-old-compile-17',root)
case=out/'state';case.mkdir(mode=0o700)
try:sdk.command([str(program),str(case)],stage/'effect-old-run-17',root)
except ValueError:
    sdk.require(json.loads((stage/'effect-old-run-17.json').read_text())['returncode']==23
        and (stage/'effect-old-run-17.stderr').read_bytes()==b'fresh effect refused: -1\n','unexpected old application failure')
else:raise ValueError('old application unexpectedly accepted the new explicit operation')
print('Original callback limitation reproduced: exact old effect succeeds, new payload is refused before filesystem publication')
