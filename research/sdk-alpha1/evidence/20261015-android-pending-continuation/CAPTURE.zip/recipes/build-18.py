from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk
import continuity_android_contract as contract
import continuity_c_consumer as c

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'INPUTS_18.json').read_text())
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());cargo=str(Path(env['RUSTC']).parent/'cargo')
consumer=Path(cfg['consumer']);outside=Path(cfg['outside']);target=outside/'build';runtime=outside/'runtime'
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
for name in ['driver','library','jar','bridge']:
    sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'unchanged actual runtime differs')
clang=(stage/'clang-06.stdout').read_text().strip();platform=(stage/'platform-06.stdout').read_text().strip()
program=runtime/'application-effect-test-18'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
 str(consumer/'application_effect_test.c'),'-I'+str(consumer),'-o',str(program)],stage/'effect-new-compile-18',outside,environment=env)
effect=outside/'application-effect-state-18';effect.mkdir(mode=0o700)
observed=sdk.command([str(program),str(effect)],stage/'effect-new-run-18',outside,environment=env)
sdk.require(observed==b'effect-contract: two exact effects, duplicate idempotence, wrong payload and conflicting replay refused\n','effect contract outcome')
receiver=runtime/'qpc-c-client-18'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread','-O0','-g','-isysroot',platform,
 *[str(consumer/name) for name in ['client.c','recovery_client.c','opening_client.c']],'-I',str(consumer),'-L',str(runtime),
 '-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(receiver)],stage/'receiver-compile-18',outside,environment=env)
dependencies=sdk.command(['/usr/bin/otool','-L',str(receiver)],stage/'receiver-dependencies-18',outside).decode()
loader=sdk.command(['/usr/bin/otool','-l',str(receiver)],stage/'receiver-loader-18',outside).decode()
c.verify_linkage(dependencies,loader,Path(cfg['library']).name,darwin=True)
target_client=runtime/'qpc-configuration-client-18'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
 str(consumer/'first_configuration_client.c'),'-I'+str(consumer),'-L'+str(runtime),
 '-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(target_client)],stage/'target-client-18',outside,environment=env)
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),'-m','unittest',
 'artifact.test_continuity_android_continuation','artifact.test_continuity_android_policy_renewal',
 'artifact.test_continuity_android_pending','artifact.test_continuity_android_jni','artifact.test_continuity_package'],stage/'readers-18',root)
output=sdk.command([cargo,'test','--locked','--offline','--test','android','--no-run','--message-format=json',
 '--target-dir',str(target),'-j','2'],stage/'harness-18',consumer,environment=env)
rows=[json.loads(line) for line in output.splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'harness count')
contract.verify_catalog(sdk.command([tests[0],'--list'],stage/'catalog-18',consumer,environment=env))
sdk.command([cargo,'clippy','--locked','--offline','--tests','--target-dir',str(target),'-j','2','--','-D','warnings'],stage/'clippy-18',consumer,environment=env)
for name,path in [('harness',Path(tests[0])),('receiver',receiver),('target_client',target_client)]:
    cfg[name]=str(path);cfg[name+'_sha256']=sdk.snapshot(path,maximum=256*1024**2).sha256
cfg['application_effect_contract']={'completed':True,'binary_sha256':sdk.snapshot(program).sha256,'effects':2}
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
sdk.write_json(stage/'BUILD_18.json',cfg)
print('Explicit fresh-message receiver, exact effect contract and strict full harness checks passed')
