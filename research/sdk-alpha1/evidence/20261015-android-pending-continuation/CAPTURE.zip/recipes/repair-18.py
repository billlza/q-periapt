from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'BUILD_09.json').read_text())
sdk.require(not json.loads((stage/'RUN_RESULT_11.json').read_text())['completed'],'second host failure missing')
phone=stage/'physical-12';state=json.loads((phone/'device-13/STATE.json').read_text())
sdk.require(not state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports'),'second phone cleanup missing')
sdk.require(not sdk.command(['/Users/bill/Library/Android/sdk/platform-tools/adb','-P','15037','-s','<SELECTED_ANDROID_DEVICE>',
 'shell','pm','list','packages','--user','0','dev.qperiapt.continuity.pendingcontinued20261015'],phone/'run-13/cleanup-verified-18',root).strip(),'failed app remains')
sdk.write_json(phone/'run-13/CLEANUP_VERIFIED_18.json',{'completed_run':False,'app_absent':True,'owned_reverse_ports':[],
 'driver_cleanup':True,'original_result_preserved':True,'apk_sha256':state['apk_sha256']})
consumer=Path(cfg['consumer']);env=json.loads((stage/'ENVIRONMENT_01.json').read_text())
names={'application_effect.h':'failed-application-effect-09.h','client.c':'failed-client-09.c',
 'tests/common/android_policy_renewal/traffic.rs':'failed-traffic-09.rs'}
for relative,saved in names.items():
    path=consumer/relative;name='bindings/c/ContinuityPackageConsumer/'+relative
    sdk.require(sdk.snapshot(path).sha256==cfg['source_files'][name],'failed source preimage differs');sdk.copy(path,stage/saved)
for name,saved in [('harness','failed-harness-09'),('receiver','failed-receiver-09')]:
    sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'failed binary changed')
    sdk.copy(Path(cfg[name]),stage/saved,maximum=256*1024**2)
rust='bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/traffic.rs'
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',rust],stage/'format-18',root,environment=env)
for relative in [*names,'application_effect_test.c']:
    source=root/'bindings/c/ContinuityPackageConsumer'/relative;target=consumer/relative
    target.write_bytes(sdk.snapshot(source).data);cfg['source_files'][str(source.relative_to(root))]=sdk.snapshot(source).sha256
sdk.write_json(stage/'INPUTS_18.json',cfg)
print('Callback mismatch isolated; failed cohorts and binaries preserved; explicit application operation and bounded records updated')
