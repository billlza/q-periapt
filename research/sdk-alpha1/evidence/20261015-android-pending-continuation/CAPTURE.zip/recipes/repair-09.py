from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;failed=stage/'physical-06/run-07'
sdk.require(not json.loads((stage/'RUN_RESULT_04.json').read_text())['completed'],'host failure missing')
phone=json.loads((failed/'RESULT.json').read_text());sdk.require(not phone['completed'] and phone['cleanup'],'phone not terminal/cleaned')
state=json.loads((stage/'physical-06/device-07/STATE.json').read_text())
sdk.require(not state.get('owned_reverse_ports'),'failed phone retained owned reverse ports')
adb=['/Users/bill/Library/Android/sdk/platform-tools/adb','-P','15037','-s','<SELECTED_ANDROID_DEVICE>']
sdk.require(not sdk.command(adb+['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.pendingcontinuation20261015'],failed/'cleanup-verified-09',root).strip(),'failed app remains')
sdk.write_json(failed/'CLEANUP_VERIFIED_09.json',{'original_run_completed':False,'app_absent':True,'owned_reverse_ports':[],
 'apk_sha256':state['apk_sha256'],'original_state_preserved':True,'state_update_failure':phone.get('cleanup_failure')})
cfg=json.loads((stage/'BUILD_06.json').read_text());env=json.loads((stage/'ENVIRONMENT_01.json').read_text())
name='bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/traffic.rs'
path=Path(cfg['consumer'])/'tests/common/android_policy_renewal/traffic.rs'
sdk.require(sdk.snapshot(path).sha256==cfg['source_files'][name],'failed fixture source changed')
sdk.copy(path,stage/'failed-traffic-06.rs')
sdk.require(sdk.snapshot(Path(cfg['harness']),maximum=256*1024**2).sha256==cfg['harness_sha256'],'failed executable changed')
sdk.copy(Path(cfg['harness']),stage/'failed-harness-06',maximum=256*1024**2)
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',name],stage/'format-09',root,environment=env)
path.write_bytes(sdk.snapshot(root/name).data);cfg['source_files'][name]=sdk.snapshot(root/name).sha256
sdk.write_json(stage/'INPUTS_09.json',cfg)
print('Both failed cohorts retained and sealed; missing serve-rekey session argument fixed; original harness preserved')
