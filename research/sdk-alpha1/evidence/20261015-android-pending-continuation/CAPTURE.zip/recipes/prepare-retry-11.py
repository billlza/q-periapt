from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
def replace(text,old,new):
    sdk.require(text.count(old)==1,'retry recipe shape: '+old[:80]);return text.replace(old,new)
commit=(stage/'commit-03.py').read_text().replace('BUILD_06.json','BUILD_09.json')
for label in ['harness','catalog','clippy']:commit=commit.replace("'"+label+"-05'","'"+label+"-09'")
for label in ['diff','stage','commit','clone-fetch','clone-checkout','source-gate','clone-controls']:
    commit=commit.replace("'"+label+"-03'","'"+label+"-09'")
commit=commit.replace('SOURCE_03.json','SOURCE_09.json').replace('SOURCE_COMMIT_03.json','SOURCE_COMMIT_09.json')
commit=commit.replace('Qualify continued traffic after pending recovery and policy renewal','Fix original session selection for continued rekey')
host=(stage/'run-installed-04.py').read_text().replace('BUILD_06.json','BUILD_09.json')
for label in ['host-cases','host-run','public']:host=host.replace(label+'-04',label+'-11')
host=host.replace('RUN_STATE_04.json','RUN_STATE_11.json').replace('RUN_RESULT_04.json','RUN_RESULT_11.json')
def physical(name):
    text=(stage/name).read_text().replace('physical-06','physical-12').replace('BUILD_06.json','BUILD_09.json')
    for label in ['agp','qualification','consumer','run','device','device-driver']:
        text=text.replace(label+'-07',label+'-13')
    return text.replace('PREPARED_APK_07.json','PREPARED_APK_13.json').replace('dev.qperiapt.continuity.pendingcontinuation20261015','dev.qperiapt.continuity.pendingcontinued20261015')
apk=physical('apk-07.py');driver=physical('device-driver-07.py');run=physical('run-device-07.py')
sdk.require(run.count('sdk.write_json(state_path,state)')==2,'mutable progress writes')
run=run.replace('sdk.write_json(state_path,state)',"state_path.write_text(json.dumps(state,indent=2)+'\\n')")
package=json.loads((stage/'physical-06/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
out=stage/'physical-12';out.mkdir()
sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');sdk.write_json(out/'PACKAGE.json',package)
recipes={'commit-09.py':commit,'run-installed-11.py':host,'apk-13.py':apk,'device-driver-13.py':driver,'run-device-13.py':run}
for name,value in recipes.items():
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
sdk.write_json(stage/'RECIPES_11.json',{name:sdk.snapshot(stage/name).sha256 for name in recipes})
print('Fresh host/phone cohorts and new APK identity prepared; old failed evidence untouched')
