from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_continuation as continued

root=Path.cwd();stage=Path(__file__).resolve().parent;device=stage/'physical-22'
host=json.loads((stage/'RUN_RESULT_20.json').read_text());physical=json.loads((device/'run-23/RESULT.json').read_text())
state=json.loads((device/'device-23/STATE.json').read_text());source=json.loads((stage/'SOURCE_COMMIT_19.json').read_text())
sdk.require(host['completed'] and physical['completed'] and physical['cleanup'] and state['completed'] and state['cleanup']
 and not state.get('owned_reverse_ports'),'producer not terminal')
sdk.require(host['foreign_processes']==121 and physical['physical_processes']==60 and physical['actual_process_cuts']==2
 and sum(row['actual_cut_observed'] for row in state['cases'])==2,'execution census')
sdk.require(source['source_commit']==host['source_commit']==physical['source_commit'],'source differs')
out=root/'research/sdk-alpha1/evidence/20261015-android-pending-continuation';out.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'capture duplicate');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(base,prefix,label):
    for suffix in ['json','stdout','stderr']:add(base/(prefix+'.'+suffix),label+'.'+suffix)
for name in ['readers-18','harness-18','catalog-18','clippy-18','java-06','target-client-18','source-gate-19','clone-controls-19','host-run-20']:
    logs(stage,name,'host/'+name)
for name in ['BUILD_18.json','RUN_RESULT_20.json','SOURCE_19.json','SOURCE_COMMIT_19.json']:add(stage/name,'host/'+name)
for label in continued.TESTS:
    for name in continued.public(label):add(stage/'public-20'/(label+'-continuation')/name,'host/public/'+label+'-continuation/'+name)
original_source=json.loads((stage/'SOURCE_COMMIT_03.json').read_text())
for name in sorted(set(source['source_paths']) | set(original_source['source_paths'])):add(root/name,'source/'+name)
for name in ['RUN_RESULT_04.json','BUILD_06.json','SOURCE_COMMIT_03.json','SOURCE_03.json','failed-traffic-06.rs']:
    add(stage/name,'failed/'+name)
for name in ['RUN_RESULT_11.json','BUILD_09.json','SOURCE_COMMIT_09.json','SOURCE_09.json',
 'failed-traffic-09.rs','failed-client-09.c','failed-application-effect-09.h']:
    add(stage/name,'failed/second/'+name)
second_build=json.loads((stage/'BUILD_09.json').read_text())
for name,saved in [('harness','failed-harness-09'),('receiver','failed-receiver-09')]:
    sdk.require(sdk.snapshot(stage/saved,maximum=256*1024**2).sha256==second_build[name+'_sha256'],'second failed executable identity')
logs(stage,'host-run-11','failed/second/host-run-11')
for route in continued.TESTS:
    for mode in ['message','rekey','fresh-message']:
        for suffix in ['stdout','stderr']:
            name='traffic-continued-policy-'+mode+'.'+suffix
            add(stage/'host-cases-11'/(route+'-continuation')/name,'failed/second/host/'+route+'/'+name)
failed_second=stage/'physical-12'
for name in ['PACKAGE.json','PREPARED_APK_13.json']:add(failed_second/name,'failed/second/phone/'+name)
for name in ['RESULT.json','CLEANUP_VERIFIED_18.json']:add(failed_second/'run-13'/name,'failed/second/phone/'+name)
for name in ['execution','cleanup-verified-18']:logs(failed_second/'run-13',name,'failed/second/phone/'+name)
add(failed_second/'device-13/STATE.json','failed/second/phone/STATE.json')
logs(failed_second/'device-13','continued-policy-fresh-message-instrument','failed/second/phone/fresh-message')
for name in ['effect-old-compile-17','effect-old-run-17','effect-new-compile-18','effect-new-run-18',
 'receiver-compile-18','receiver-dependencies-18','receiver-loader-18']:
    logs(stage,name,'application/'+name)
for name in ['application_effect.h','effect-contract.c']:add(stage/'old-effect-17'/name,'application/old/'+name)
old_build=json.loads((stage/'BUILD_06.json').read_text())
sdk.require(sdk.snapshot(stage/'failed-harness-06',maximum=256*1024**2).sha256==old_build['harness_sha256'],'failed executable identity')
logs(stage,'host-run-04','failed/host-run-04')
for route in continued.TESTS:
    for mode in ['message','rekey']:
        for suffix in ['stdout','stderr']:
            name='traffic-continued-policy-'+mode+'.'+suffix
            add(stage/'host-cases-04'/(route+'-continuation')/name,'failed/host/'+route+'/'+name)
failed=stage/'physical-06'
for name in ['PACKAGE.json','PREPARED_APK_07.json']:add(failed/name,'failed/phone/'+name)
for name in ['RESULT.json','CLEANUP_VERIFIED_09.json']:add(failed/'run-07'/name,'failed/phone/'+name)
for name in ['execution','cleanup-present','cleanup-stop','cleanup-uninstall','cleanup-absent','cleanup-verified-09']:
    logs(failed/'run-07',name,'failed/phone/'+name)
add(failed/'device-07/STATE.json','failed/phone/STATE.json')
logs(failed/'device-07','continued-policy-message-acknowledged-instrument','failed/phone/original-message-acknowledged')

for name in ['PREFLIGHT.md','failed-reader-fixture-01.py','failed-prepare-01.py','failed-flow-02.rs']:add(stage/name,'preflight/'+name)
logs(stage,'clippy-02','preflight/clippy-02')
for name in ['PACKAGE.json','PREPARED_APK_23.json']:add(device/name,'android/'+name)
for name in ['build','keytool','sign','signature']:logs(device/'agp-23',name,'android/'+name)
add(device/'agp-23/STATE.json','android/STATE.json')
logs(device/'run-23','catalog','device/catalog');logs(device/'run-23','execution','device/execution')
add(device/'run-23/RESULT.json','device/RESULT.json')
for path in sorted((device/'device-23').iterdir()):
    sdk.require(path.is_file() and path.suffix in ['.json','.stdout','.stderr'],'device receipt type');add(path,'device/commands/'+path.name)
label='tls-recoverable-applied';case_label=label+'-continuation'
for name in continued.public(label):add(device/'run-23/public'/case_label/name,'device/public/'+case_label+'/'+name)
for name in ['prepare-01.py','build-02.py','repair-05.py','build-05.py','prepare-finish-06.py','finish-06.py',
 'prepare-runs-03.py','commit-03.py','run-installed-04.py','apk-07.py','device-driver-07.py','run-device-07.py',
 'repair-09.py','build-09.py','prepare-retry-11.py','commit-09.py','run-installed-11.py','apk-13.py','device-driver-13.py',
 'run-device-13.py','effect-contract.c','check-old-effect-17.py','repair-18.py','build-18.py','prepare-final-20.py',
 'commit-19.py','run-installed-20.py','apk-23.py','device-driver-23.py','run-device-23.py','capture-24.py']:add(stage/name,'recipes/'+name)
cohorts=[stage/'host-cases-20'/(r+'-continuation') for r in continued.TESTS]+[device/'run-23/cases'/case_label]
cohorts += [stage/'host-cases-04'/(r+'-continuation') for r in continued.TESTS]+[stage/'physical-06/run-07/cases'/case_label]
cohorts += [stage/'host-cases-11'/(r+'-continuation') for r in continued.TESTS]+[stage/'physical-12/run-13/cases'/case_label]
for cohort in cohorts:
    for key in ['tls-key','witness-tls-key']:
        path=cohort/'inputs'/key
        if not path.exists():
            sdk.require(key=='witness-tls-key' and cohort.name.startswith('signed-'),'missing expected test key');continue
        secret=path.read_bytes()
        for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'test private key included')
for name,payload in list(files.items()):
    if name.endswith(('.py','.json','.stdout','.stderr')):
        files[name]=payload.replace(b'<SELECTED_ANDROID_DEVICE>',b'<SELECTED_ANDROID_DEVICE>').replace(
            b'<SELECTED_ANDROID_DEVICE_SHA256>',b'<SELECTED_ANDROID_DEVICE_SHA256>')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,data)
accepted_build=json.loads((stage/'BUILD_18.json').read_text())
for name in ['harness','receiver','library','jar','bridge','target_client']:
    sdk.require(sdk.snapshot(Path(accepted_build[name]),maximum=256*1024**2).sha256==accepted_build[name+'_sha256'],'accepted runtime changed')
manifest={'format':1,'source_commit':host['source_commit'],'engine_source_commit':physical['engine_source_commit'],
 'candidate_sha256':host['candidate_sha256'],'aar_sha256':physical['aar_sha256'],'apk_sha256':physical['apk_sha256'],
 'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'host_routes':2,'host_foreign_processes':121,'host_actual_process_cuts':4,'physical_ART_processes':60,
 'physical_actual_process_cuts':2,'physical_API':37,'business_effects_per_route':2,'rekey_epoch':1,
 'release_claim_eligible':False,'recipe_hardware_selectors_redacted':True,'sdk_implementation_changed':False,
 'reference_application_changed':True,'receiver_sha256':accepted_build['receiver_sha256'],'c_library_sha256':accepted_build['library_sha256'],
 'runtime_failure_retained':True,'failed_harness_sha256':old_build['harness_sha256'],'application_contract_red_green':True}
sdk.write_json(out/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-continuation-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'capture inventory')
        for name,digest in manifest['members'].items():
            data=bundle.read(name);sdk.require(hashlib.sha256(data).hexdigest()==digest,'capture hash')
            if '/public/' in name:
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        results={}
        for route in continued.TESTS:results.update(continued.verify_execution(bundle.read('host/host-run-20.stdout'),extracted/'host/public',route,batch=True))
        sdk.require(results==host['cases'],'host readback')
        sdk.require(continued.verify_execution(bundle.read('device/execution.stdout'),extracted/'device/public',label)==physical['result'],'phone readback')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256'],
 'all_host_and_device_public_readers':True,'private_test_keys_excluded':True})
print(json.dumps({'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256']}))
