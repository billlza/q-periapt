from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_android_contract as contract

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'INPUTS_09.json').read_text())
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());cargo=str(Path(env['RUSTC']).parent/'cargo')
consumer=Path(cfg['consumer']);target=Path(cfg['outside'])/'build'
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
for name in ['driver','receiver','library','jar','bridge','target_client']:
    sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'actual runtime changed')
output=sdk.command([cargo,'test','--locked','--offline','--test','android','--no-run','--message-format=json',
 '--target-dir',str(target),'-j','2'],stage/'harness-09',consumer,environment=env)
rows=[json.loads(line) for line in output.splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'harness count')
contract.verify_catalog(sdk.command([tests[0],'--list'],stage/'catalog-09',consumer,environment=env))
sdk.command([cargo,'clippy','--locked','--offline','--tests','--target-dir',str(target),'-j','2','--','-D','warnings'],stage/'clippy-09',consumer,environment=env)
cfg['harness']=tests[0];cfg['harness_sha256']=sdk.snapshot(Path(tests[0]),maximum=256*1024**2).sha256
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
sdk.write_json(stage/'BUILD_09.json',cfg)
print('Corrected installed C rekey invocation compiled; complete strict test checks and runtime identities verified')
