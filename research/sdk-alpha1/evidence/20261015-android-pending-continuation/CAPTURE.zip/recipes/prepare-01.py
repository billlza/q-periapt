from pathlib import Path
import ast
import json
import shutil
import subprocess
import tempfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;oldstage=root/'target/continuity-android-pending-process'
new=['bindings/c/ContinuityPackageConsumer/tests/common/android_pending_continuation.rs',
     'bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/continuation.rs']
for name,old_text,new_text in [('ARTIFACT.md','689 tracked `.rs`','691 tracked `.rs`'),
    ('artifact/codeql_rust_quality.py','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 689','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 691')]:
    path=root/name;text=path.read_text();sdk.require(text.count(old_text)==1,'Rust inventory shape');path.write_text(text.replace(old_text,new_text))
path=root/'artifact/test_codeql_rust_quality.py';text=path.read_text();key='            "bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write.rs",\n'
sdk.require(text.count(key)==2,'Rust inventory controls');path.write_text(text.replace(key,key+''.join('            '+json.dumps(name)+',\n' for name in new)))
subprocess.run(['git','add','--',*new],check=True)
env=json.loads((oldstage/'ENVIRONMENT_01.json').read_text())
rust=[name for name in subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines() if name.endswith('.rs')]
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',*rust],stage/'format-01',root,environment=env)
for name in subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines():
    if name.endswith('.py'):ast.parse((root/name).read_text())
for name in ['artifact/continuity_android_continuation.py','artifact/test_continuity_android_continuation.py']:ast.parse((root/name).read_text())
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
 'bindings/c/ContinuityPackageConsumer/src','bindings/c/ContinuityPackageConsumer/Cargo.toml','bindings/android/ContinuityPackageConsumer/src/main',
 'bindings/android/ContinuityPackageConsumer/jni']),'installed implementation changed')
old=json.loads((oldstage/'BUILD_02.json').read_text())['installed_base']
outside=Path(tempfile.mkdtemp(prefix='qpc-pending-continuation-')).resolve();consumer=outside/'c-consumer'
shutil.copytree(Path(old['consumer']),consumer)
fixture=root/'bindings/c/ContinuityPackageConsumer';hashes={}
for path in fixture.rglob('*'):
    if path.is_file() and path.name!='Cargo.toml':
        target=consumer/path.relative_to(fixture);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(sdk.snapshot(path).data);hashes[str(path.relative_to(root))]=sdk.snapshot(path).sha256
builder=outside/'android-source';shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',builder)
hashes.update({str(path.relative_to(root)):sdk.snapshot(path).sha256 for path in (root/'bindings/android/ContinuityPackageConsumer').rglob('*') if path.is_file()})
sdk.write_json(stage/'INPUTS_01.json',{'outside':str(outside),'consumer':str(consumer),'android_source':str(builder),
 'source_files':hashes,'installed_base':old,'candidate_sha256':old['candidate_sha256'],
 'scope':'Actual archives; original pending recovery -> independent policy renewal -> original retry -> rekey -> fresh traffic'})
sdk.write_json(stage/'ENVIRONMENT_01.json',env)
recipe=(oldstage/'build-02.py').read_text()
recipe=recipe.replace("'artifact.test_continuity_package'","'artifact.test_continuity_package','artifact.test_continuity_android_continuation','artifact.test_continuity_android_policy_renewal'")
key="files={'harness':Path(tests[0])";sdk.require(recipe.count(key)==1,'build recipe shape')
addition='''target_client=runtime/'qpc-configuration-client'
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
 str(consumer/'first_configuration_client.c'),'-I'+str(consumer),'-L'+str(runtime),
 '-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(target_client)],stage/'target-client-02',outside,environment=env)
'''
recipe=recipe.replace(key,addition+"files={'target_client':target_client,'harness':Path(tests[0])")
ast.parse(recipe)
with (stage/'build-02.py').open('x') as stream:stream.write(recipe)
print('Fresh actual archives and continued lifecycle consumers prepared; Rust inventory691')
