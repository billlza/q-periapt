from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent
for label in ['readers','harness','catalog','clippy']:
    sdk.require(json.loads((stage/(label+'-05.json')).read_text())['returncode']==0,'Rust/check producer incomplete')
header='''from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_c_witness_openssl as openssl

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'INPUTS_05.json').read_text())
outside=Path(cfg['outside']);consumer=Path(cfg['consumer']);builder=Path(cfg['android_source'])
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());old=cfg['installed_base'];runtime=outside/'runtime';classes=outside/'tests'
sdk.require(classes.is_dir() and not list(classes.iterdir()),'failed Java start unexpectedly produced classes')
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
for name in ['receiver','library','jar','bridge']:
    sdk.require(sdk.snapshot(runtime/Path(old[name]).name,maximum=256*1024**2).sha256==old[name+'_sha256'],'runtime copy changed')
rows=[json.loads(line) for line in (stage/'harness-05.stdout').read_bytes().splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'harness count')
'''
original=(stage/'build-02.py').read_text();tail=original[original.index('java=Path('):]
for label in ['java','clang','platform','target-client']:tail=tail.replace("'"+label+"-02'","'"+label+"-06'")
tail=tail.replace("label+'-02'","label+'-06'").replace('BUILD_02.json','BUILD_06.json')
value=header+tail;ast.parse(value)
with (stage/'finish-06.py').open('x') as stream:stream.write(value)
for name in ['commit-03.py','run-installed-04.py','run-device-07.py']:
    p=stage/name;text=p.read_text();sdk.require(text.count('BUILD_05.json')==1,'recipe source identity')
    p.write_text(text.replace('BUILD_05.json','BUILD_06.json'))
sdk.write_json(stage/'RECIPES_06.json',{name:sdk.snapshot(stage/name).sha256 for name in
 ['finish-06.py','commit-03.py','run-installed-04.py','apk-07.py','device-driver-07.py','run-device-07.py']})
print('Resume Java/native helper packaging only; completed strict Rust checks retained; tool paths preserved literally')
