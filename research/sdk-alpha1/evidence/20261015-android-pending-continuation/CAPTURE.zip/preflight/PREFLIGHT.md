Initial canonical unittest command for test_continuity_android_continuation and
test_continuity_android_policy_renewal terminated exit1:7tests, two subtest
failures in the new positive fixture's export-inventory check. The missing file
was authority-created (both routes). No runtime or cryptographic test ran in that
command. Source preimage is failed-reader-fixture-01.py.

The old pending synthetic fixture did not populate every setup payload because
its reader did not consume them. The new export check requires all files. Added
explicit synthetic72byte authority/peer association records; retained the full
inventory assertion. This is fixture repair, not relaxation of product checks.

prepare01's count guard also stopped before any inventory edits: ARTIFACT.md
contains the historical memory measurement6898 as well as the tracked source
count689. The generic substring guard correctly refused replacement. The saved
failed-prepare-01.py is retained; the recipe now targets the exact tracked-count
sentence and named Python constant, preserving the memory measurement.

Build02 compiled the harness and catalog70, with49reader controls passing, but
strict all-C-test Clippy terminated101 on drop_non_drop: the borrowed Case context
was explicitly dropped even though it owns no destructor. The original flow
source and terminal diagnostics are retained. The continuation branch now
consumes the Option and borrows its Case only for resume; no warning is suppressed.
No runtime or phone cohort had started before this repair.

Build05 passed reader49/harness/catalog70/strict Clippy, then could not start
javac. Its broad receipt-suffix replacement also changed sdk-020-recovery in
the JDK path to sdk-050-recovery. No Java process started and the class directory
was empty. Build05 is retained. finish06 resumes only the remaining Java/native
helper packaging using the original verified JDK path and new receipt names;
successful Rust checks are reused without changing any source or assertion.

Runtime04 host2routes and phone07 failed at C receiver rekey startup after
successful independent policy renewal and original-message confirmation. Native
client.c requires both --session for owner reopen and a trailing session argument
for serve rekey; the new shared test caller omitted the latter. No rekey ran in
those failed cohorts. Phone57calls completed before the harness failure. Its app
and owned maps were removed, but an outer controller used exclusive write_json
for mutable STATE.json and recorded FileExistsError. Original STATE/RESULT remain
unchanged; independent cleanup verification is retained separately. New run
recipes use the same mutable state writer as the device controller. The actual
SDK/storage implementation is unchanged. All retries use fresh cohorts.

Runtime11/phone13 then completed rekey but failed on fresh-message delivery.
The client retries reported connection refusal/EOF after the C receiver exited;
the receiver's primary failure was callback31. application_effect.h accepted only
the original fixed payload. An isolated old-header C test reproduced fresh
payload refusal (exit23) after original effect success. The application now has
an explicit fresh-message mode with an exact second payload, bounded variable
record length, unchanged duplicate/conflict checks and a permanent standalone
effect-contract gate. The listener and caller select that mode explicitly.
No SDK/network error was relabeled success and no encryption check was relaxed.
The driver removed phone13's failed application; immutable RESULT retained its
initial cleanup=false while STATE records cleanup=true, so a separate verified
cleanup receipt retains the distinction. Future runners synchronize that field.
