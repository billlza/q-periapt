from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-peer-credential';package=root/'target/continuity-browser-publication/source/target/peer-credential-package-01'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Session continuity across original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug';authority=binary/'examples/browser_activation_authority';roster=binary/'q-periapt-browser-roster-authority';peer=binary/'q-periapt-browser-peer-credential-peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed browser peer G admission and original session/message/rekey continuity; independently retained native root/witness, same Rust implementation and loopback, not independent implementation/PCS/release','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,roster,peer]},'cases':[],'observations':[]}
allowed={'live','expired','before','after','cancel'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster session result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'observations':value['result'].get('observations',[])});return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def native_trace(case,name):
 trace=out/'native'/case/name;trace.mkdir(mode=0o700,parents=True);return trace
def peer_result(args,label):return parse_strict_json_bytes(native(peer,args,label),label=label)
try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_session_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_session_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(authority,['prepare',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    if case=='expired':cfg['peer_until']=int(time.time())+180;(directory/'PUBLIC.json').write_text(json.dumps(cfg))
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace(case,'prepare')],case+'-peer-prepare')
    peer_data=json.loads((inputs/(key+'-peer.json')).read_text())
    args['requestId']=success({**args,'action':'session','sessionAction':'new-request'})['requestId']
    established=success({**args,'action':'session','sessionAction':'establish'});args['session']=established['session'];row['session']=args['session'];row['requestId']=args['requestId'];(directory/'peer/session.json').write_text(json.dumps(args['session']))
    args['message']=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['message']=args['message']
    row['pending_delivery']=rejected({**args,'action':'session','sessionAction':'send','peerMode':'drop-ack'},'PeerTransport')
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'lost application ACK not retained')
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    reverse_prepared=peer_result(['send-prepare',directory,session_file,reverse,native_trace(case,'reverse-prepare')],case+'-reverse-prepare');sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'],'native pending outcome');row['reverse_prepared']=reverse_prepared;args['reverseMessage']=reverse_prepared['message']
    row['pending_rekey']=rejected({**args,'action':'session','sessionAction':'drive-rekey','target':1,'peerMode':'control-drop-first'},'PeerTransport')
    pending=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(pending['confirmed']=='0' and pending['pending']=='1','original pending control absent');row['progress_before']=pending
    if case=='expired':
     row['real_expiry']={'previous_until':peer_data['until'],'pending_at':int(time.time())};sdk.require(time.time()<peer_data['until'],'peer expired before original session/pending work')
     print(json.dumps({'case':case,'waiting_until':peer_data['until']+1}),flush=True)
     while time.time()<=peer_data['until']:time.sleep(min(10,max(0.1,peer_data['until']+1-time.time())))
     row['expired_before_grant']=rejected({**args,'action':'session','sessionAction':'status'},'Validity');row['real_expiry']['renew_at']=int(time.time())
    target=inputs/(key+'-peer-renewal.json');row['native_renewal']=peer_result(['renew-peer',directory,target,native_trace(case,'renew')],case+'-native-renewal')
    renewal=json.loads(target.read_text());args['peerOperation']=renewal['operation'];sdk.require(row['native_renewal']['committed'] and row['native_renewal']['activated'] and row['native_renewal']['same_original_journal'] and renewal['previous_expired']==(case=='expired'),'native original G scope')
    row['negative']={}
    for field,code in [('wrongOperation','Conflict'),('closedPeerPolicy','Closed'),('closedPeerRuntime','Closed')]:
     row['negative'][field]=rejected({**args,'action':'peer-credential',field:True},code)
    if case in ['before','after','cancel']:
     mode={'before':'before','after':'after','cancel':'hold'}[case]
     row['admission_loss']=rejected({**args,'action':'peer-credential','armFault':mode,'cancelOnAdvance':case=='cancel'},'Cancelled' if case=='cancel' else 'WitnessTransport')
     if case=='cancel':sdk.require(row['admission_loss']['cancellationRequested'],'no pending cancellation')
    admitted=success({**args,'action':'peer-credential'});row['admitted']=admitted;sdk.require(admitted['version']=='2' and admitted['digest']==renewal['digest'],'wrong G head')
    sdk.require(success({**args,'action':'peer-credential'})==admitted,'exact G readback changed')
    if case=='expired':
     before=len(peer_records.get(key,[]));row['expired_fresh_bootstrap']=rejected({**args,'action':'session','sessionAction':'establish'},'Validity');sdk.require(len(peer_records.get(key,[]))==before,'expired old bundle released new bootstrap')
    current=success({**args,'action':'activate'});sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'peer G changed local identity/key');row['current']=current
    after=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(after==pending,'G changed original rekey');row['progress_after']=after
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'G lost original application outbox')
    completed=success({**args,'action':'session','sessionAction':'drive-rekey','target':1});sdk.require(completed['epoch']=='1','original rekey incomplete');row['rekey']=completed
    control_frames=[r for r in peer_records[key] if r['kind']==4];sdk.require(len(control_frames)>=2 and control_frames[0]['trigger'] and control_frames[0]['request_sha256']==control_frames[1]['request_sha256'],'G changed first control replay')
    delivery=success({**args,'action':'session','sessionAction':'send'});sdk.require(delivery=={'consumption':1,'status':3},'original application not acknowledged');row['delivery']=delivery
    message_frames=[r['request_sha256'] for r in peer_records[key] if r['kind']==3];sdk.require(len(message_frames)==2 and len(set(message_frames))==1,'G changed original ciphertext')
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(args['session'])+bytes(args['message'])+b'browser to native','native effect duplicated/changed')
    received=success({**args,'action':'session','sessionAction':'receive'});sdk.require(received['application']['calls']==1 and received['application']['effects']==1,'browser original effect');row['received']=received
    duplicate=success({**args,'action':'session','sessionAction':'receive'});sdk.require(not duplicate['callbackInvoked'] and duplicate['reply']==received['reply'] and duplicate['application']==received['application'],'duplicate released plaintext or changed ACK');row['duplicate']=duplicate
    ack=out/(case+'-reverse-ack.bin');ack.write_bytes(bytes(received['reply']));row['reverse_finished']=peer_result(['send-finish',directory,reverse,ack,native_trace(case,'reverse-finish')],case+'-reverse-finish')
    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;sdk.require(success({**args,'action':'session','sessionAction':'send','message':fresh,'plaintext':'after G'})=={'consumption':1,'status':3},'fresh post-G message failed')
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records']),'peer_requests':len(row['peer_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
