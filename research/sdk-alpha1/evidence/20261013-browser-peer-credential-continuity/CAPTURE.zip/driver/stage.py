from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-credential';clone=root/'target/continuity-browser-publication/source';old=root/'target/continuity-browser-credential-commit'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay-paths',root).decode().splitlines();overlay={}
for n in paths:
 p=root/n;overlay[n]=sdk.snapshot(p).sha256;dest=clone/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'bae7f318a8c0fdacedd6dc4e147c776b8477beec','overlay':overlay,'source':str(clone)})
(stage/'build-package.sh').write_text((old/'build-package-02.sh').read_text().replace('credential-commit-package-02','peer-credential-package-01'))
(stage/'base-browser.py').write_text((old/'base-browser-02.py').read_text().replace('continuity-browser-credential-commit','continuity-browser-peer-credential').replace('credential-commit-package-02','peer-credential-package-01'))
for n in ['server.py','controller.js']:shutil.copyfile(root/'target/continuity-browser-peer-roster'/n,stage/n)
shutil.copyfile(root/'target/continuity-browser-roster-sessions/session-checks.js',stage/'session-checks.js')
s=(old/'worker.js').read_text();s="import {sessionAction} from './session-checks.js';\n"+s
needle="   if(data.action==='accept'){";assert s.count(needle)==1;s=s.replace(needle,(stage/'worker-actions.js.txt').read_text())
(stage/'worker.js').write_text(s)
source=root/'target/continuity-browser-receive-revocation/native-peer';dest=stage/'native-peer';(dest/'src').mkdir(parents=True,exist_ok=True)
for n in ['Cargo.toml','Cargo.lock']:(dest/n).write_text((source/n).read_text().replace('q-periapt-browser-receive-revocation-peer','q-periapt-browser-peer-credential-peer'))
s=(source/'src/main.rs').read_text();needle='let validity=p::Validity::new(number(&config,"from")?,number(&config,"until")?)?;';assert s[:s.index('struct Effects')].count(needle)==1
s=s.replace(needle,'let peer_until=match config.get("peer_until"){Some(v)=>v.as_u64().ok_or("peer_until must be unsigned integer")?,None=>number(&config,"until")?};let validity=p::Validity::new(number(&config,"from")?,peer_until)?;',1)
needle='fn handle(dir:&Path,request:&Path,reply:&Path,trace:&Path,mode:&str)->Result<()>{';assert s.count(needle)==1
s=s.replace(needle,needle+'\n let wire=read(request,32768)?;if wire.get(8)==Some(&3){return handle_existing_message(dir,&wire,reply,trace,mode)}')
needle=' match mode.as_str(){';assert s.count(needle)==1
s=s.replace(needle,needle+'\n  "renew-peer" if args.len()==5=>renew_peer(dir,Path::new(&args[3]),Path::new(&args[4]))?,')
(dest/'src/main.rs').write_text(s+'\n'+(stage/'native-renew.rs.txt').read_text())
s=(root/'target/continuity-browser-roster-sessions/run.py').read_text().replace('continuity-browser-roster-sessions','continuity-browser-peer-credential').replace('roster-package-02','peer-credential-package-01').replace('q-periapt-browser-roster-session-peer','q-periapt-browser-peer-credential-peer')
s=s.replace('import contextlib,json,os,sys,uuid,shutil','import contextlib,json,os,sys,uuid,shutil,time')
start=s.index('allowed=');end=s.index('\ndef browser',start)
s=s[:start]+"allowed={'live','expired','before','after','cancel'}\nsdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0"+s[end:]
start=s.index('   for case in sys.argv[2:]:');end=s.index("  finally:browser(['close'],'close')",start)
s=s[:start]+(stage/'body.py.txt').read_text()+s[end:]
s=s.replace('actual installed browser session continuity across R; same Rust native counterpart and loopback signed witness, not independent implementation/deployment/PCS/release evidence','actual installed browser peer G admission and original session/message/rekey continuity; independently retained native root/witness, same Rust implementation and loopback, not independent implementation/PCS/release')
(stage/'run.py').write_text(s)
