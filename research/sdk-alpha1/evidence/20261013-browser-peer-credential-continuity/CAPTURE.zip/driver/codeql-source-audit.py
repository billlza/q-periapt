from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-credential'
frozen=json.loads((root/'artifact/codeql_memory_queries.json').read_text())
query=stage/'codeql-SummaryStats.ql';expected=frozen['query_hashes']['qlpacks/codeql/rust-queries/0.1.43/queries/summary/SummaryStats.ql']
sdk.require(hashlib.sha256(query.read_bytes()).hexdigest()==expected,'query differs from frozen linked bundle')
entries=json.loads((stage/'codeql-src-stats-tree.json').read_text());sdk.require(entries['truncated'] is False,'truncated upstream tree')
blobs={v['path'].rsplit('/',1)[1]:v['sha'] for v in entries['entries']}
files={}
for name in ['SummaryStats.ql','Stats.qll','TaintReach.qll']:
 data=(stage/('codeql-'+name)).read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 sdk.require(blob==blobs[name],'upstream blob identity differs')
 files[name]={'git_blob':blob,'sha256':hashlib.sha256(data).hexdigest(),'url':'https://github.com/github/codeql/blob/codeql-cli/v2.27.1/rust/ql/src/queries/summary/'+name}
sdk.write_json(stage/'CODEQL_SOURCE_AUDIT.json',{'files':files,'summary_matches_frozen_linked_query':True,'observed':'Full SummaryStats includes taintStats. TaintReach config selects active modeled sources and every dataflow node as a sink, then counts reachable non-summary nodes. This matches the unfinished TaintReach evaluator predicates in the retained current log. It is a telemetry computation, not by itself a security finding or proof of missing product authorization.','limits':'No optimization or complete query execution performed. The matching entry query and pinned upstream blobs do not prove an alternate query equivalent. Keep all existing security queries, extraction/quality assertions and required original analysis; do not infer a safe flag from an experimental dynamic-join option.','next':'Investigate the exact all-sinks reach computation and retained dataset with a bounded controlled experiment before changing production analysis. Original full SummaryStats is still incomplete.'})
print('pinned SummaryStats source and imported telemetry blobs verified; no CI fix claimed')
