from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-peer-credential';package=root/'target/continuity-browser-publication/source/target/peer-credential-package-01'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports=[load(stage/n/'RESULT.json') for n in ['run02','run03']];assert all(r['completed'] for r in reports)
cases={c['case']:c for r in reports for c in r['cases']};assert set(cases)=={'live','before','after','cancel','expired'} and sum(len(r['cases']) for r in reports)==5
for name,c in cases.items():
 assert c['native_renewal']['committed'] and c['native_renewal']['activated'] and c['native_renewal']['same_original_journal']
 assert c['native_renewal']['previous_expired']==(name=='expired') and c['admitted']['version']=='2'
 assert c['progress_before']==c['progress_after'] and c['progress_before']['pending']=='1' and c['progress_before']['confirmed']=='0' and c['rekey']['epoch']=='1'
 assert c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
 assert c['delivery']=={'consumption':1,'status':3} and c['reverse_finished']['same_original_wire'] and c['reverse_finished']['authenticated_browser_consumption']
 assert c['received']['application']['effects']==c['received']['application']['calls']==1
 assert not c['duplicate']['callbackInvoked'] and c['duplicate']['reply']==c['received']['reply'] and c['duplicate']['application']==c['received']['application']
 assert c['fresh_message']!=c['message']
 for field,code in [('wrongOperation','Conflict'),('closedPeerPolicy','Closed'),('closedPeerRuntime','Closed')]:assert c['negative'][field]['code']==code and c['negative'][field]['ownerClosed']
 frames=c['peer_records'];assert len([r for r in frames if r['kind']==1])==len([r for r in frames if r['kind']==2])==1
 control=[r for r in frames if r['kind']==4];messages=[r for r in frames if r['kind']==3]
 assert len(control)>=2 and control[0]['trigger'] and control[0]['request_sha256']==control[1]['request_sha256']
 assert len(messages)==3 and messages[0]['request_sha256']==messages[1]['request_sha256']!=messages[2]['request_sha256']
 if name in ['before','after','cancel']:
  selected=[r for r in c['witness_records'] if r.get('armedMode') and r['trigger']];assert len(selected)==1
  assert c['admission_loss']['code']==('Cancelled' if name=='cancel' else 'WitnessTransport') and c['admission_loss']['ownerClosed']
  assert selected[0]['native_dispatched']==(name!='before') and selected[0]['changed']==(name!='before')
  if name=='cancel':assert c['admission_loss']['cancellationRequested']
expired=cases['expired'];assert expired['real_expiry']['pending_at']<expired['real_expiry']['previous_until']<expired['real_expiry']['renew_at']
assert expired['expired_before_grant']['code']==expired['expired_fresh_bootstrap']['code']=='Validity'
old=load(stage/'run01/RESULT.json');assert not old['completed'] and 'live-native-renewal.stderr' in old['failure']
assert 'private publication inode admission failed' in (stage/'run01/logs/live-native-renewal.stderr').read_text()
assert (stage/'run01/native/live/renew/request').stat().st_mode&0o777==0o755
assert '4 passed; 0 failed' in (stage/'native-peer-renewal-tests.log').read_text()
for n in ['native-scope-test.log','native-revocation-test.log']:assert '1 passed; 0 failed' in (stage/n).read_text()
for n in ['native-clippy.log','wasm-clippy.log','wasm-msrv.log']:
 s=(stage/n).read_text();assert 'Finished' in s and 'error:' not in s and 'warning:' not in s
assert not (stage/'format.log').read_text()
assert 'Ran 53 tests' in (stage/'controls.log').read_text() and (stage/'controls.log').read_text().rstrip().endswith('OK')
base=load(stage/'base10/RESULT.json');assert base['completed'] and len(base['report']['cases'])==10
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz')
source=load(stage/'SOURCE_OVERLAY.json')
for n,d in source['overlay'].items():assert sha(root/n)==d,n
for r in reports:
 for n,d in r['native'].items():assert sha(Path(n))==d,n
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(v.endswith('-private') or v.startswith('private-') for v in p.parts),p
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.name not in ['seal.log','finalize.log','HANDOFF.json'] and p.suffix in ['.py','.js','.json','.log','.txt','.sh']:add(p,'driver/'+p.name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/name,'native-peer/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','authority/witness.rs')
web=Path(load(package/'consumer-location.json')['path'])
for run in ['run01','run02','run03']:
 folder=stage/run;result=load(folder/'RESULT.json');add(folder/'RESULT.json',run+'/RESULT.json')
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.name!='RESULT.json':add(p,run+'/'+p.name)
 for part in ['logs','captures','peer']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for part in ['witness','native']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for c in result['cases']:
  key=run+'-'+c['case'];records=folder/'witness'/key/'RECORDS.json'
  if records.is_file():
   add(records,run+'/witness/'+key+'/RECORDS.json')
   for record in load(records):
    if record.get('armedMode') and record.get('trigger'):
     for p in sorted(records.parent.glob(f"{record['number']:03}.*")):
      if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
  for p in sorted((web/'inputs').glob(key+'*')):add(p,'public-inputs/'+p.name)
for p in sorted((stage/'base10').iterdir()):
 if p.is_file():add(p,'base10/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/name,'package/'+name)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-peer-credential-continuity';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes']
checks={'completed':True,'release_claim_eligible':False,'source':source,'case_count':5,'cases':sorted(cases),'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'validation':{'native_peer_renewal_cases':6,'base_browser_modes':10,'artifact_controls':53,'native_clippy':'all targets -D warnings passed','wasm_clippy':'-D warnings passed','wasm_msrv':'1.90.0 passed','format':'passed','browser':base['report']['browser']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'real_expiry':expired['real_expiry'],'scope':'Actual installed browser peer credential G admission through existing active owner; native peer renews through original enrollment/witness transaction. Original session/outboxes/control replay survive, including after actual peer credential/manifest expiry. Native shares Rust implementation and loopback; not independent protocol implementation, simultaneous both-peer renewal, browser process-kill qualification, cross-host/device/performance/PCS or full release.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Browser peer credential admission and original session continuity

`admit_peer_credential_renewal` now connects the browser active owner and typed independently verified grant to the existing owning-service transition. It preserves original operation, P0, current policy/runtime, known peer history, account authority and local-membership checks. A signed same-account update can be committed before refusing a revoked local member; a failed call must not be described as non-commit. It does not renew the local device or create a peer session.

Five fresh installed Chrome Worker/native cohorts cover normal admission, an unprocessed first witness request, a reply lost after the actual head advance, cancellation of a held post-advance reply, and actual peer credential/manifest expiry. Before renewal, each establishes one session, loses the browser message's consumption ACK, leaves a native reverse message dispatched without ACK, and loses the first PQ rekey reply. The native peer independently issues a real G with its retained root, stages/prepares/commits it through the original enrollment and required witness, and separately activates the same journal with its successor credential. The browser then explicitly admits the original peer G.

Across admission and exact retry, the original session and local journal/prekey remain unchanged. Pending rekey progress remains epoch0 with original epoch1 pending. The first control frame is replayed byte-for-byte and reaches epoch1. The pending browser ciphertext is replayed byte-for-byte and gets its original authenticated consumption result. The reverse message is consumed once; a duplicate returns the same ACK without invoking the application. A new post-G message also succeeds. Exactly one initial bootstrap remains in each trace; none is synthesized to hide renewal continuity failures.

The expiry cohort waits for real wall-clock expiry before native renewal. Reopening the original browser session first fails Validity. After actual native renewal and browser G admission, that same original bundle/session recovers all pending work. The expired original bundle is still refused for a new bootstrap before peer dispatch. No historical current-time value is fabricated. Wrong operation, closed policy and closed runtime are refused in all cohorts; caller-visible owner closure is checked.

The first fixture failed before writing its first renewal witness trace: the helper used the default0755 mode for a new diagnostic child directory. The private publisher correctly rejected it. The helper now creates new0700 directories; the failed cohort and source are retained, and no existing directory's permissions or SDK admission checks were weakened. Established native message frames now use `serve_session_message` on the original reopened session, rather than treating each message as a fresh peer admission; bootstrap frames retain their normal live checks.

Six relevant native regressions, including exact sync-cut recovery, local-identity/policy isolation and durable observation of same-account local revocation, passed. Ten installed base browser modes,53 package/inventory controls, strict native/WASM Clippy, WASM Rust1.90 and formatting passed. Public operation results, peer frames and selected actual witness-loss traces are archived. Complete repetitive raw native/witness traces remain in closed task-local cohorts with a full hash manifest. Private roots, wrapping keys, journal databases and browser profiles are excluded.

The ancillary CodeQL audit matches the fetched v2.27.1 SummaryStats entry query to the frozen linked-query SHA-256. Its imported TaintReach source counts reach from active modeled sources to all dataflow-node sinks, excluding summary nodes from the final count. This is consistent with the stalled evaluator trace. Pinned upstream blob identities and URLs are retained in CODEQL_SOURCE_AUDIT.json; no optimizer change, complete evaluation or CI fix is claimed. The existing required analysis remains open.

The endpoints share the Rust engine and loopback. This qualifies peer-G admission and original-session continuity, not independent protocol implementation, simultaneous renewal of both peers, actual browser process-kill recovery, performance, device coverage, PCS or release readiness.
''')
print(json.dumps(checks['capture']))
