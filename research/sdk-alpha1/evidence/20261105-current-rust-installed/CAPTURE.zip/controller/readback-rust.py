from pathlib import Path
import datetime
import hashlib
import json
import sys
import time

import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
assert sys.pycache_prefix
root = Path(__file__).resolve().parent
source = root / 'source'
output = source / 'target/continuity-installed-rust-current'
producer = source / 'target/sdk-020'
started = time.monotonic()
report = json.loads((output / 'CONTINUITY_PACKAGE.json').read_text())
producer_report = json.loads((producer / 'RUST_SDK_PACKAGE.json').read_text())
assert report['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert report['completed'] and report['partition_completed']
assert report['build_profiles'] == ['debug', 'release'] and report['requested_consumers'] == ['Rust']
assert report['publication_performed'] is False and report['release_claim_eligible'] is False
assert report['rust_report_sha256'] == sdk.snapshot(producer / 'RUST_SDK_PACKAGE.json').sha256
assert report['source_inputs'] == json.loads((output / 'sources-before.json').read_text())
assert report['source_inputs'] == json.loads((output / 'sources-after.json').read_text())
assert report['source_inputs'] == package.source_inputs()
outside = Path(json.loads((output / 'location.json').read_text())['path'])
assert outside.is_absolute() and not outside.is_relative_to(source)
consumer = outside / 'consumer'
package.verify_candidate_archive(output, report['archive'])
files = package.validate_candidate(sdk.snapshot(output / report['archive']['file']).data,
                                   set(report['archive']['files']))
package.verify_candidate_files(consumer / 'packages' / f'{package.NAME}-{package.VERSION}', files)
sdk.verify_consumed_sources(consumer, producer, producer_report['crates'])
commands = {}
for path in sorted(output.glob('*.json')):
    row = json.loads(path.read_text())
    if 'argv' in row:
        assert row['returncode'] == 0, path
        commands[path.name] = {'returncode': 0, 'receipt_sha256': sdk.snapshot(path).sha256}
profiles = {}
for profile in report['build_profiles']:
    observed = package.verify_execution(
        (output / f'consumer-{profile}.stdout').read_bytes(), outside / f'{profile}-runtime',
        outside / f'{profile}-runtime-session-reopen',
        outside / f'{profile}-runtime-roster-renewal/public',
        outside / f'{profile}-runtime-device-replacement/public',
        outside / f'{profile}-runtime-device-retirement/public')
    expected = dict(report['execution'][profile])
    binary = expected.pop('binary')
    assert observed == expected, profile
    # The gate intentionally retires completed build directories. Do not claim
    # a post-run binary-byte verification or export private runtime state.
    assert not Path(binary['path']).exists()
    profiles[profile] = {'full_public_readback_matches': True, 'tests_passed': 3,
        'tests_failed': 0, 'tests_ignored': 0, 'tests_filtered': 0,
        'retired_binary_receipt': binary, 'retired_binary_bytes_available': False,
        'result_sha256': hashlib.sha256(json.dumps(observed, sort_keys=True).encode()).hexdigest(),
        'scope': report['scope']}
for name in ('package-build-storage.json', 'rust-build-storage.json'):
    row = json.loads((output / name).read_text())
    assert row['completed'] and not Path(row['directory']).exists()
result = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'seconds': time.monotonic() - started, 'source_commit': report['source_commit'],
    'report_sha256': sdk.snapshot(output / 'CONTINUITY_PACKAGE.json').sha256,
    'sdk_report_sha256': report['rust_report_sha256'],
    'sdk_root': report['source_inputs']['rust_workspace_sha256'],
    'source_inputs': len(report['source_inputs']['files']), 'source_unchanged': True,
    'archive': {k: report['archive'][k] for k in ('file', 'bytes', 'sha256')},
    'candidate_archive_members': len(files), 'actual_candidate_tree_verified': True,
    'actual_sdk_trees_verified': len(sdk.CONSUMER_CRATES),
    'profiles': profiles, 'successful_commands': commands,
    'python': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
               'dont_write_bytecode': sys.dont_write_bytecode, 'private_cache_prefix': True},
    'scope': 'Independent reread of the original current-source installed Rust package run; no native workload rerun, foreign/device qualification or release acceptance.'}
with (root / 'RUST_CANDIDATE_READBACK.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({k: result[k] for k in ('report_sha256', 'source_inputs', 'candidate_archive_members',
    'actual_sdk_trees_verified', 'seconds')}))
