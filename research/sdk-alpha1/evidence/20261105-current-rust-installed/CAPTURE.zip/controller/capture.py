from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

import continuity_package as package

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = package.ROOT
control = source.parent
repo = control.parents[1]
output = source / 'target/continuity-installed-rust-current'
dest = repo / 'research/sdk-alpha1/evidence/20261105-current-rust-installed'
dest.mkdir()
report = json.loads((output / 'CONTINUITY_PACKAGE.json').read_text())
readback = json.loads((control / 'RUST_CANDIDATE_READBACK.json').read_text())
assert readback['report_sha256'] == hashlib.sha256((output / 'CONTINUITY_PACKAGE.json').read_bytes()).hexdigest()
files = {'run/' + p.relative_to(output).as_posix(): p for p in output.rglob('*') if p.is_file()}
assert all(not p.is_symlink() for p in output.rglob('*'))
for name in ('RUST_CANDIDATE_REQUEST.json', 'RUST_CANDIDATE_READBACK.json',
             'rust-candidate.stdout', 'rust-candidate.stderr', 'readback-rust.py',
             'rust-readback.stdout', 'rust-readback.stderr',
             'rust-readback-02.stdout', 'rust-readback-02.stderr'):
    files['controller/' + name] = control / name
files['controller/readback-02.py'] = Path(__file__).with_name('readback.py')
files['controller/capture.py'] = Path(__file__)
files['sdk/RUST_SDK_PACKAGE.json'] = source / 'target/sdk-020/RUST_SDK_PACKAGE.json'
for name, expected in report['source_inputs']['files'].items():
    path = source / name
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    assert data == subprocess.check_output(['git', 'show', report['source_commit'] + ':' + name], cwd=source)
    files['source/' + name] = path
manifest = {}
with zipfile.ZipFile(dest / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.writestr(name, data)
with zipfile.ZipFile(dest / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    assert archive.testzip() is None
    for name, row in manifest.items():
        data = archive.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
for name, value in [('FILES.json', manifest), ('READBACK.json', readback)]:
    with (dest / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
with (dest / 'CONTINUITY_PACKAGE.json').open('xb') as stream:
    stream.write((output / 'CONTINUITY_PACKAGE.json').read_bytes())
data = (dest / 'CAPTURE.zip').read_bytes()
summary = {'source_commit': report['source_commit'], 'bytes': len(data),
    'sha256': hashlib.sha256(data).hexdigest(), 'members': len(manifest),
    'sdk_report_sha256': report['rust_report_sha256'],
    'sdk_archive_capture': '../20261105-current-sdk-producer/CAPTURE.zip',
    'sdk_archive_capture_sha256': '2fac380b3ba4a24c9d96d52166c0bcc152dff37c1f9658d287cc0498b8aa9bd5',
    'scope': 'Current installed Rust Debug/Release evidence. Public exports only; private runtime trees and retired native test binaries are not exported. SDK archives retained in the linked exact producer capsule.'}
with (dest / 'CAPTURE.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary))
