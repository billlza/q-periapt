from pathlib import Path
import hashlib,json,os,signal,subprocess,time
out=Path(__file__).resolve().parent
source=json.loads((out/'SOURCE.json').read_text()); root=Path(source['source'])
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON','JAVA','KOTLIN','GRADLE'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(out.parent/'account-root-retirement-current/build'),RUSTC=str(rust/'bin/rustc'),RUSTDOC=str(rust/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(rust/'lib'))
command=[str(rust/'bin/cargo'),'test','--manifest-path',str(root/'research/continuity-identity-candidate/Cargo.toml'),'--all-features','--locked','--offline','-j','2','--lib','account_root_backup_boundary','--','--nocapture','--test-threads=1']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
record=dict(source,command=command,environment=env,completed=False)
# Retain only explicitly selected build environment; other host values may contain credentials.
record['environment']={k:env[k] for k in ['CARGO_HOME','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','CARGO_TARGET_DIR','RUSTC','RUSTDOC','RUSTFLAGS','RUSTDOCFLAGS','PATH','DYLD_FALLBACK_LIBRARY_PATH']}
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic(); timed_out=False
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 p=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try: code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try: code=p.wait(timeout=10)
  except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);code=p.wait()
record.update(returncode=code,timed_out=timed_out,seconds=time.monotonic()-start,source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source['experiment_head'])
record['completed']=code==0 and not timed_out and record['source_clean'] and record['head_unchanged']
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('environment','command')}),flush=True)
print((out/'stdout').read_text()[-2200:]);print((out/'stderr').read_text()[-1800:])
raise SystemExit(0 if record['completed'] else 1)
