from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-ci-readback-22'
DEST=ROOT/'research/sdk-alpha1/evidence/20261105-ci-debug-capacity-readback'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
jobs={j['id']:j for j in json.loads((BASE/'JOBS.json').read_bytes())}
status=json.loads((BASE/'CI_STATUS.json').read_bytes())
paths={'suite':ROOT/'target/continuity-ci-readback-20/job-126445737915.log',
       'release':ROOT/'target/continuity-ci-readback-20/job-126445737664.log',
       'capacity':BASE/'job-126445737820.log'}
blocks={}
for kind,path in paths.items():
    text=path.read_text();pending=[];rows=[]
    assert re.search(r'git log -1 --format=%H\n\S+Z 475cd23923e45819b01b6041c91c44540ec056ec\s*\n',text)
    for line in text.splitlines():
        m=re.fullmatch(r'\S+Z test (.+?) \.\.\. ok',line)
        if m:pending.append(m[1])
        m=re.fullmatch(r'\S+Z test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; (\d+) filtered out; finished in (.+)',line)
        if m:
            rows.append({'passed':int(m[1]),'filtered':int(m[2]),'names':pending,'summary':line})
            pending=[]
    blocks[kind]=rows
for kind,expected in [('suite',[1450,4,2,4,3,19,27,4]),('release',[1451,4,2,4,3,19,27,4])]:
    assert [b['passed'] for b in blocks[kind]]==expected
    assert all(len(b['names'])==len(set(b['names']))==b['passed'] for b in blocks[kind])
capacity=blocks['capacity']
assert len(capacity)==2 and capacity[0]['passed']==capacity[1]['passed']==1
assert capacity[0]['filtered']==capacity[1]['filtered']==1450
assert len(capacity[0]['names'])==1 and capacity[1]['names']==[]
cap_name=capacity[0]['names'][0]
assert cap_name=='enrollment::tests::witness_renewal::policy_transaction::sessions::fanout::account_roster::native_common_account_roster_capacity_fanout_and_removal'
suite=set(blocks['suite'][0]['names']);release=set(blocks['release'][0]['names'])
assert cap_name not in suite and suite|{cap_name}==release
for index in range(1,8):assert set(blocks['suite'][index]['names'])==set(blocks['release'][index]['names'])
union={'source_commit':'475cd23923e45819b01b6041c91c44540ec056ec',
    'suite_job_id':126445737915,'capacity_job_id':126445737820,'release_job_id':126445737664,
    'debug_suite_library_cases':1450,'capacity_cases':1,'capacity_case':cap_name,
    'suite_capacity_overlap':0,'library_union_cases':1451,'library_union_equals_release':True,
    'other_candidate_stages':[4,2,4,3,19],'sdk_stages':[27,4],
    'other_stage_case_sets_equal_release':True,
    'release_library_names_sha256':sha(encode(sorted(release))),
    'release_library_names':sorted(release),
    'capacity_summary_repeated_by_shell_grep':True,'capacity_test_executions_counted':1,
    'prior_logs':{k:{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())} for k,p in paths.items()},
    'prior_log_archive':'research/sdk-alpha1/evidence/20261105-ci-native-swift-readback/CAPTURE.zip',
    'scope':'Actual test-name set coverage at the named old hosted source; no current-source, complete platform or performance-budget qualification.'}
assert jobs[126445737820]['conclusion']=='success'
swift=(BASE/'job-126456506032.log').read_text()
assert jobs[126456506032]['conclusion']=='failure'
assert re.search(r'git log -1 --format=%H\n\S+Z 9aa535b48b464ec4d4a8b5a4b20221049a6067b9\s*\n',swift)
assert 'report["witness_exchanges"] == 142' in swift
assert 'ValueError: OpenSSL server exchange census differs' in swift
assert 'result["c_consumer"] = qualify_c(' in swift
artifacts={}
for j in jobs:
    text=(BASE/f'job-{j}.log').read_text()
    matches=re.findall(r'Artifact (.+?) has been successfully uploaded! Final size is ([0-9]+) bytes\. Artifact ID is ([0-9]+)',text)
    digests=re.findall(r'SHA256 digest of uploaded artifact is ([0-9a-f]{64})',text)
    assert len(matches)==len(digests)==1
    n,b,i=matches[0];artifacts[str(j)]={'name':n,'bytes':int(b),'id':int(i),'sha256':digests[0]}
classification={'captured_utc':datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at':status['observed_at'],'wave_counts':status['counts'],
    'swift_debug':{'job_id':126456506032,'actual_checkout':'9aa535b48b464ec4d4a8b5a4b20221049a6067b9',
        'failure':'Old exact 142 C/OpenSSL prerequisite.','observed_p0_failure_ordinal':17,
        'hosted_server_count_disclosed':False,'swift_execution_established':False},
    'debug_coverage':union,'reported_artifacts':artifacts,'artifacts_downloaded_locally':False,
    'effective_wave_open':True,'push_performed':False,'rerun_performed':False,
    'workflow_cancelled':False,'release_claim_eligible':False}
with (BASE/'DEBUG_COVERAGE.json').open('xb') as f:f.write(encode(union))
files={'capture/'+p.name:p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json']=encode(classification)
files['FILES.json']=encode({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,5,0,0,0));info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
payload=buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist())==len(files) and set(archive.namelist())==set(files)
    for name,data in files.items():assert archive.read(name)==data
summary={'bytes':len(payload),'members':len(files),'sha256':sha(payload),'all_members_read_back':True}
DEST.mkdir(exist_ok=False)
for name,data in [('CAPTURE.zip',payload),('CLASSIFICATION.json',files['CLASSIFICATION.json']),
                  ('FILES.json',files['FILES.json']),('DEBUG_COVERAGE.json',encode(union)),('SHA256.json',encode(summary))]:
    with (DEST/name).open('xb') as f:f.write(data)
print(json.dumps(summary,indent=2),flush=True)
