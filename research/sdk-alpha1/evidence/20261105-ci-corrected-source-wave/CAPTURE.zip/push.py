"""Execute the prepared normal atomic branch update only after a fresh read gate."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
from bounded_process import capture_output, TimeoutPolicy

ROOT = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
BASE = ROOT / 'target/continuity-next-wave-20261105'
REFS = [
    {'pr': 117, 'branch': 'feat/continuity-publication-verification',
     'expected': '475cd23923e45819b01b6041c91c44540ec056ec',
     'candidate': '232ace17915407596d66f3a5fd7c7765251a38cc'},
    {'pr': 118, 'branch': 'feat/accountable-prekey-directory',
     'expected': '6084f3bfb09333f6b66291b38809ed512296a27b',
     'candidate': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'},
]


def obj(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


assert Path.cwd() == ROOT
assert not (BASE / 'PUSH_RESULT.json').exists() and not (BASE / 'PUSH_START.json').exists()
gate = obj(BASE / 'GATE.json')
assert gate['ready_to_push'] is True and gate['planned_refs'] == REFS
assert gate['current_head_failures_classified'] is True
assert gate['necessary_local_fix_validation_complete'] is True
assert gate['workflow_trigger_review_complete'] is True
age = (datetime.now(timezone.utc) - datetime.fromisoformat(gate['observed_utc'])).total_seconds()
assert 0 <= age <= 120, 'Refresh the connector gate; no stale branch or queue acceptance.'
for status in ['in_progress', 'queued', 'waiting', 'pending', 'requested']:
    path = BASE / ('runs-' + status + '.json')
    assert digest(path) == gate['evidence_sha256'][path.name]
    data = obj(path)
    assert data['total_count'] == 0 and data['workflow_runs'] == []
terminal = BASE / 'last-historical-run.json'
assert digest(terminal) == gate['evidence_sha256'][terminal.name]
assert obj(terminal)['status'] == 'completed'
jobs = BASE / 'last-historical-jobs.json'
assert digest(jobs) == gate['evidence_sha256'][jobs.name]
data = obj(jobs)
assert len(data['jobs']) == data['total_count'] and all(j['status'] == 'completed' for j in data['jobs'])
for row in REFS:
    path = BASE / ('pr-' + str(row['pr']) + '.json')
    assert digest(path) == gate['evidence_sha256'][path.name]
    pr = obj(path)
    assert pr['state'] == 'open' and not pr['merged']
    assert pr['head'] == row['branch'] and pr['head_sha'] == row['expected']
    assert pr['head_repo_full_name'].lower() == 'billlza/q-periapt'
    expected_base = ('lza/windows-private-store', 'ed257e10c75af6798838ee6a95e0ccc6930cf388') if row['pr'] == 117 else ('feat/continuity-publication-verification', REFS[0]['expected'])
    assert (pr['base'], pr['base_sha']) == expected_base
    subprocess.run(['git', 'merge-base', '--is-ancestor', row['expected'], row['candidate']], cwd=ROOT, check=True)
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT) == b''
assert subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT) == b''
origin = subprocess.check_output(['git', 'remote', 'get-url', '--push', 'origin'], cwd=ROOT, text=True).strip()
assert origin == 'https://github.com/billlza/q-periapt.git'
for parent in ['continuity-c-managed-cohort', 'continuity-swift-managed-cohort', 'continuity-kotlin-managed-cohort']:
    assert obj(ROOT / 'target' / parent / 'LAUNCH_RESULT.json')['completed']
argv = ['git', 'push', '--porcelain', '--atomic', 'origin',
        *[row['candidate'] + ':refs/heads/' + row['branch'] for row in REFS]]
environment = {k: v for k, v in os.environ.items() if not k.startswith('GIT_TRACE') and k != 'GIT_CURL_VERBOSE'}
environment['GIT_TERMINAL_PROMPT'] = '0'
state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
    'argv': argv, 'cwd': str(ROOT), 'refs': REFS, 'gate_sha256': digest(BASE / 'GATE.json'),
    'driver_sha256': digest(Path(__file__)), 'timeout_seconds': 900, 'force_push': False,
    'release_or_tag_operation': False, 'local_android_terminal_receipt_present':
        (ROOT / 'target/continuity-android-managed-cohort/LAUNCH_RESULT.json').exists()}
write(BASE / 'PUSH_START.json', state)
started = time.monotonic()
try:
    with (BASE / 'push.stdout').open('xb', buffering=0) as out, (BASE / 'push.stderr').open('xb', buffering=0) as err:
        result = capture_output(argv, timeout_seconds=900, timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
            maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2,
            environment=environment, stdout_sink=out.write, stderr_sink=err.write)
    state['returncode'] = result.returncode
    assert result.returncode == 0, 'Branch update failed. Read receipt and recheck refs before any further action.'
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    for name in ['kind', 'cleanup_ambiguous', 'signal_number']:
        if hasattr(error, name):
            state[name] = getattr(error, name)
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    for suffix in ['stdout', 'stderr']:
        path = BASE / ('push.' + suffix)
        if path.exists():
            state[suffix + '_sha256'] = digest(path)
    write(BASE / 'PUSH_RESULT.json', state)
    print(json.dumps(state, indent=2), flush=True)
