from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-next-wave-20261105'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-corrected-source-wave'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda v: (json.dumps(v, indent=2, sort_keys=True) + '\n').encode()
obj = lambda n: json.loads((BASE / n).read_bytes())
gate = obj('GATE.json')
push = obj('PUSH_RESULT.json')
assert push['completed'] and push['returncode'] == 0 and not push['force_push']
assert push['gate_sha256'] == sha((BASE / 'GATE.json').read_bytes())
assert push['driver_sha256'] == sha((BASE / 'push.py').read_bytes())
for suffix in ['stdout', 'stderr']:
    assert push[suffix + '_sha256'] == sha((BASE / ('push.' + suffix)).read_bytes())
assert push['refs'] == gate['planned_refs']
for name, expected in gate['evidence_sha256'].items():
    assert sha((BASE / name).read_bytes()) == expected
for status in ['in_progress', 'queued', 'waiting', 'pending', 'requested']:
    row = obj('runs-' + status + '.json')
    assert row['total_count'] == 0 and row['workflow_runs'] == []
assert obj('last-historical-run.json')['status'] == 'completed'
last = obj('last-historical-jobs.json')
assert len(last['jobs']) == last['total_count'] == 71
assert all(row['status'] == 'completed' for row in last['jobs'])
for row in push['refs']:
    before = obj('pr-' + str(row['pr']) + '.json')
    after = obj('post-pr-' + str(row['pr']) + '.json')
    assert before['head_sha'] == row['expected'] and after['head_sha'] == row['candidate']
    assert after['state'] == 'open' and not after['merged']
assert obj('post-pr-118.json')['base_sha'] == push['refs'][0]['candidate']
initial = []
latest = []
for row in push['refs']:
    for suffix, target in [('', initial), ('-1020', latest)]:
        data = obj('new-runs-' + row['candidate'][:8] + suffix + '.json')
        assert len(data['workflow_runs']) == data['total_count']
        assert all(run['head_sha'] == row['candidate'] for run in data['workflow_runs'])
        target.extend(data['workflow_runs'])
assert len(initial) == len(latest) == 16
cancelled = {42009001578: 127182924236, 42009001846: 127182925551,
             42009001542: 127182925302, 42009001556: 127182923893}
cancel_rows = []
for run, check in cancelled.items():
    data = obj('cancelled-run-' + str(run) + '-jobs.json')
    assert len(data['jobs']) == data['total_count']
    assert all(j['conclusion'] == 'cancelled' and j['runner_id'] in (0, None) and not j['steps'] for j in data['jobs'])
    annotations = obj('cancel-' + str(check) + '.json')
    assert len(annotations) == 1 and annotations[0]['message'].startswith('Canceling since a higher priority waiting request for ')
    cancel_rows.append({'run': run, 'jobs': data['total_count'], 'representative_check': check,
        'annotation': annotations[0]['message'], 'runner_execution_observed': False})
assert sum(row['jobs'] for row in cancel_rows) == 76
for name in ['old-job-126266162501.log', 'old-job-127180430509.log']:
    assert (BASE / name).stat().st_size > 10000
assert 'ValueError: TLS account admitted exchange workload differs' in (BASE / 'old-job-126266162501.log').read_text()
coverage = (BASE / 'old-job-127180430509.log').read_text()
assert 'Total of 6 artifact(s) downloaded' in coverage
assert 'ValueError: partition is unfinished or makes a complete-package claim' in coverage
dependency = obj('DEPENDENCY_READBACK.json')
assert dependency['default_rustls_versions'] == ['0.23.43']
assert dependency['candidate_upgrade_needed_for_these_three_version_ranges'] is False
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'old_historical_run': 41724563802,
    'old_historical_counts': dict(Counter(j['conclusion'] for j in last['jobs'])),
    'old_last_android_artifact_downloaded': False,
    'old_last_android_artifact': {'id': 13406565024, 'upload_reported_bytes': 32121924,
        'upload_reported_sha256': '19c5938ae8866bfd3e406df5a8122a90535a217556568f8233f9b11ff2fb3247'},
    'push_completed': True, 'push_started_utc': push['started_utc'], 'push_finished_utc': push['finished_utc'],
    'push_elapsed_seconds': push['elapsed_seconds'], 'refs': push['refs'], 'atomic_normal_fast_forward': True,
    'prepush_all_checked_queue_states_empty': True, 'postpush_pr_refs_verified': True,
    'new_run_count': len(latest), 'superseded_runs': cancel_rows,
    'latest_run_counts': dict(Counter(r['conclusion'] or r['status'] for r in latest)),
    'surviving_runs': [{'id': r['id'], 'name': r['name'], 'event': r['event'], 'head_sha': r['head_sha'],
        'status': r['status'], 'conclusion': r['conclusion']} for r in latest if r['id'] not in cancelled],
    'dependency_alert_scope': 'Three default-main rustls 0.23.43 alerts; both candidate source locks and installed foundation locks use patched 0.23.46. Not a complete dependency audit.',
    'later_focused_android_pin_updated': False, 'local_android_complete_at_push': False,
    'release_or_tag_operation': False, 'release_claim_eligible': False,
    'next_sequence': 'Wait for this wave; validate the hosted SDK producer identity before updating the focused Android pin and uploading later retained fixes.'}
files = {p.relative_to(BASE).as_posix(): p.read_bytes() for p in sorted(BASE.rglob('*')) if p.is_file()}
files['READBACK.json'] = encode(summary)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(n) == b for n, b in files.items())
checksums = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, data in [('CAPTURE.zip', payload), ('READBACK.json', files['READBACK.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(checksums))]:
    with (DEST / name).open('xb') as stream:
        stream.write(data)
print(json.dumps(checksums, indent=2), flush=True)
