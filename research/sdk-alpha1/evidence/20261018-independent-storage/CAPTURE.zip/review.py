"""Read back public recovery transcripts; never load a wrapping key or journal."""
import ast
import hashlib
import json
from pathlib import Path
import sys

root = Path.cwd()
source = root / "research/continuity-openssl-peer"
evidence = root / "target/independent-storage-01"
sys.path.insert(0, str(source))
from provider import load_provider
load_provider(root / "target/independent-bootstrap-01/provider")
from fixture_inputs import load
from peer.bootstrap import digest
from peer.traffic import message_id

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(value, reason):
    if not value:
        raise ValueError(reason)

def native(folder, commands):
    for row in commands:
        before = (folder / "cases" / (row["case"] + ".input")).read_bytes()
        after = (folder / "cases" / (row["case"] + ".output")).read_bytes()
        check(sha(before) == row["input_sha256"] and sha(after[1:]) == row["output_sha256"]
              and after[0] == row["status"], "native transcript: " + row["case"])

session_dir = evidence / "session-qualified-02"
session = json.loads((session_dir / "RESULT.json").read_text())
volatile_dir = evidence / "volatile-qualified-02"
volatile = json.loads((volatile_dir / "RESULT.json").read_text())
store_dir = evidence / "store-qualified"
store = json.loads((store_dir / "RESULT.json").read_text())
check(session["source_files"] == volatile["peer_sources"], "different final sources")
for name, expected in session["source_files"].items():
    data = (source / name).read_bytes()
    check(sha(data) == expected, "source drift: " + name)
    if name.endswith(".py"):
        ast.parse(data, filename=name)
native(session_dir / "native", session["native_commands"])
native(volatile_dir, volatile["native_commands"])
for name, expected in volatile["case_files"].items():
    check(sha((volatile_dir / "cases" / name).read_bytes()) == expected, "volatile case hash")
for name, expected in volatile["public_files"].items():
    check(sha((volatile_dir / "public" / name).read_bytes()) == expected, "volatile public hash")
check(len(session["native_commands"]) == 9 and len(volatile["native_commands"]) == 41
      and len(volatile["python_refusals"]) == 51, "operation counts")
cuts = []
for row in session["worker_operations"]:
    name = row["case"]
    out = (session_dir / (name + ".stdout")).read_bytes()
    err = (session_dir / (name + ".stderr")).read_text()
    request = json.loads((session_dir / (name + ".request.json")).read_text())
    check(request["action"] == row["action"], "worker action")
    if "signal" in row:
        check(row["signal"] == "SIGKILL" and out.decode().strip() == row["cut"] and not err, "cut marker")
        cuts.append(row["cut"])
    elif "refused" in row:
        check(not out and row["refused"] in err, "refusal released output")
    else:
        check(sha(out) == row["stdout_sha256"] and not err, "worker result hash")
check(len(cuts) == session["process_kills"] == 6 and len(session["worker_operations"]) == 27
      and len(session["codec_refusals"]) == 6, "session counts")
check(store["process_kills"] == 16 and len(store["results"]) == 37, "storage counts")
for operation in ("creation", "update"):
    for index in range(8):
        check(bool((store_dir / f"{operation}-cut-{index}.stage").read_bytes())
              and not (store_dir / f"{operation}-cut-{index}.stderr").read_bytes(), "storage cut output")
_, _, context = load(session_dir / "native/public", 150)
cases = session_dir / "native/cases"
initial = (cases / "persisted-initial.input").read_bytes()
reply = (cases / "persisted-initial.output").read_bytes()[1:]
final = (cases / "persisted-final.input").read_bytes()
session_id = (cases / "persisted-final.output").read_bytes()[1:]
first = context.initiator.open(initial, 5, 2440)
second = context.responder.open(reply, 6, 1256)
check(first[:40] == b"QPBSI001" + context.digest, "initial context")
check(second[:72] == b"QPBSR001" + context.digest + digest(b"initial-wire", initial), "reply context")
check(final[:104] == b"QPBSF001" + context.digest + digest(b"initial-wire", initial)
      + digest(b"reply-wire", reply) and session_id == digest(b"session-id", final[:104]), "final/session")
def worker_result(name):
    return json.loads((session_dir / (name + ".stdout")).read_text())["result"]
wire = bytes.fromhex(worker_result("recover-ciphertext"))
identity = bytes.fromhex(worker_result("original-id"))
check(worker_result("repeat-ciphertext") == wire.hex() and wire[:41] == b"QPCMSG03" + session_id + b"\1"
      and identity == message_id(session_id, 1, 0) and wire[57:89] == identity, "original send replay")
check(worker_result("next-slot") == message_id(session_id, 1, 1).hex(), "next slot")
check(worker_result("recover-plaintext") == worker_result("duplicate-plaintext"), "receive replay")
check(worker_result("recover-ACK") == worker_result("duplicate-consumption"), "consumption replay")
check(worker_result("acknowledged-status") == "Acknowledged", "ACK reconciliation")
check("wrong session refusal: expired-final-refused" in (evidence / "session-expiry-red.stderr").read_text()
      and bool((evidence / "session-expiry-red/expired-final-refused.stdout").read_bytes()), "original red missing")
check(not (evidence / "session-expiry-red/RESULT.json").exists(), "red produced success report")
native_path = root / "target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart"
check(sha(native_path.read_bytes()) == volatile["native_sha256"], "binary mismatch")
report = {"base_head": "1183ad3c0709513b69d90c7744f36a9c22c5897f", "source_files": session["source_files"],
          "provider": session["provider"], "native_sha256": volatile["native_sha256"],
          "storage": {"process_kills": 16, "checks": 37},
          "session": {"process_kills": 6, "worker_operations": 27, "native_commands": 9, "codec_refusals": 6},
          "volatile_regression": {"native_commands": 41, "refusals": 51},
          "public_signatures_and_transcript_reverified": True, "bootstrap_expiry_red_green_retained": True,
          "limits": ["local-only fixed-authority pairwise bootstrap and epoch zero", "no rekey/witness/renewal/revocation/full installation lifecycle",
                     "independent workers restart; native process survives", "no hardware power loss, key erasure or rollback detection",
                     "public readback does not rederive secret MAC/AEAD keys", "new storage implementation has no hosted runtime result yet"]}
(evidence / "READBACK.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"source_files": len(session["source_files"]), "storage_checks": 37, "worker_operations": 27,
                  "process_kills": 22, "native_commands": 50, "public_readback": "passed"}))
