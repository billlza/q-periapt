"""Seal explicitly selected public checkpoints, excluding private fixture trees."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
base = root / "research/sdk-alpha1/evidence"
def sha(data):
    return hashlib.sha256(data).hexdigest()

def seal(name, files, checks):
    destination = base / name
    destination.mkdir()
    members = {}
    for label, path in files:
        if path.is_symlink() or not path.is_file() or label in members:
            raise ValueError("invalid capture member: " + label)
        members[label] = path.read_bytes()
    members["MANIFEST.json"] = (json.dumps({n: sha(b) for n,b in sorted(members.items())}, indent=2) + "\n").encode()
    output = destination / "CAPTURE.zip"
    with zipfile.ZipFile(output, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for label, data in sorted(members.items()):
            info = zipfile.ZipInfo(label, (2026, 10, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None or set(z.namelist()) != set(members):
            raise ValueError("capture readback failed")
        for n,b in members.items():
            if z.read(n) != b:
                raise ValueError("capture content changed")
    checks["capture"] = {"sha256": sha(output.read_bytes()), "bytes": output.stat().st_size,
                         "members": len(members), "complete_member_readback": True}
    (destination / "CHECKS.json").write_text(json.dumps(checks, indent=2) + "\n")
    print(name, checks["capture"])

hosted = root / "target/independent-traffic-hosted-1183-01"
reports = [json.loads((hosted/n).read_text()) for n in ("LINUX_REVIEW.json", "MACOS_REVIEW.json")]
for report, name in zip(reports, ("ubuntu.zip", "macos.zip"), strict=True):
    if sha((hosted/name).read_bytes()) != report["artifact_sha256"]:
        raise ValueError("hosted download changed")
seal("20261018-hosted-independent-traffic", [(p.name,p) for p in sorted(hosted.iterdir()) if p.is_file()],
     {"head": reports[0]["head"], "run": reports[0]["run"], "cohorts": reports,
      "scope": "Both original volatile traffic cohorts, separate from the later independent storage increment."})

local = root / "target/independent-storage-01"
files = []
for name in ("store-qualified", "session-qualified-02", "volatile-qualified-02", "session-expiry-red"):
    folder = local/name
    for p in sorted(folder.rglob("*")):
        if p.is_file():
            if p.name in ("head", "intent", "configuration") or p.name.startswith(".stage-"):
                raise ValueError("private state in public capture")
            files.append((str(p.relative_to(local)),p))
for name in ("store-qualified", "session-qualified-02", "volatile-qualified-02", "session-expiry-red",
             "session-qualified", "provider-origin", "actionlint", "review"):
    for suffix in ("stdout", "stderr"):
        p = local / (name + "." + suffix)
        if p.exists(): files.append((p.name,p))
for name in ("durable-expiry-old.py.txt", "review.py", "READBACK.json", "seal.py"):
    files.append((name,local/name))
checks = json.loads((local/"READBACK.json").read_text())
for name, expected in checks["source_files"].items():
    p = root / "research/continuity-openssl-peer" / name
    if sha(p.read_bytes()) != expected: raise ValueError("source drift before capture")
    files.append(("source/"+name,p))
seal("20261018-independent-storage", files, checks)

repair = root / "target/installed-final-archive-01"
files = [(str(p.relative_to(repair)),p) for p in sorted(repair.rglob("*")) if p.is_file()]
files.append(("original-job.log", root/"target/ci-fd42-installed-linux-terminal.log"))
files += [("superseded/"+p.name,p) for p in sorted((root/"target/ci-fd42-1183-superseded").iterdir()) if p.is_file()]
seal("20261018-installed-archive-final-check", files, json.loads((repair/"READBACK.json").read_text()))
