"""Upgrade the preserved original schema2 CLI fixture; never recreate it."""
from pathlib import Path
import hashlib,json,re,shutil,signal,subprocess,time,urllib.error,urllib.request
out=Path(__file__).resolve().parent
repo=out.parent.parent
prior=out.parent/'enrollment-issuer-01'
old=prior/'release-strict-final'
new=out.parent/'continuity-reference-app/release/q-periapt-continuity-reference-app'
database=prior/'cli-private-01/accounts.redb'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='7700cd40dc489783ae1b2722798a7c861b38bc64e8e4762ede8b04b9590d6fa6'
assert database.is_file()
origin,=re.findall(r'Reference account application: (http://localhost:\d+)',(prior/'cli-serve-1.stdout').read_text())
inode=database.stat().st_ino
observations=[]
def serve(binary,label):
    with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
        proc=subprocess.Popen([str(binary),'serve',str(database),origin],stdout=stdout,stderr=stderr)
        seen=False
        try:
            end=time.monotonic()+10
            while time.monotonic()<end:
                assert proc.poll() is None,'owned server exited before readiness'
                try:
                    with urllib.request.urlopen(origin+'/api/me',timeout=2) as response:
                        raise AssertionError(f'anonymous access succeeded: {response.status}')
                except urllib.error.HTTPError as response:
                    assert response.code==401 and response.headers['cache-control']=='no-store'
                    assert json.loads(response.read())=={'error':'Authentication required or ceremony invalid'}
                    seen=True;break
                except urllib.error.URLError as error:
                    if not isinstance(error.reason,ConnectionRefusedError):raise
                    time.sleep(.05)
            assert seen
        finally:
            if proc.poll() is None:proc.send_signal(signal.SIGINT)
            try:code=proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill();proc.wait(timeout=5);raise
    assert code==0 and database.stat().st_ino==inode
    observations.append({'step':label,'exit_code':code,'tcp_anonymous_status':401,'same_inode':True})
def command(binary,label,mode,success):
    with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
        result=subprocess.run([str(binary),mode,str(database),origin],stdout=stdout,stderr=stderr,timeout=30)
    assert (result.returncode==0)==success
    assert database.stat().st_ino==inode
    observations.append({'step':label,'exit_code':result.returncode,'same_inode':True})

serve(old,'cli-old-schema2')
backup=out/'private-before-upgrade';backup.mkdir(mode=0o700)
shutil.copy2(database,backup/'accounts.redb')
before_digest=hashlib.sha256(database.read_bytes()).hexdigest()
assert hashlib.sha256((backup/'accounts.redb').read_bytes()).hexdigest()==before_digest
command(new,'cli-schema3-upgrade','enable-reapproval',True)
command(new,'cli-schema3-retry','enable-reapproval',True)
command(old,'cli-old-schema3-refusal','serve',False)
assert 'Unsupported account schema' in (out/'cli-old-schema3-refusal.stderr').read_text()
serve(new,'cli-new-schema3')
assert hashlib.sha256((backup/'accounts.redb').read_bytes()).hexdigest()==before_digest
report={'old_binary_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_binary_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'new_binary_bytes':new.stat().st_size,'schema2_backup_sha256':before_digest,'observations':observations,'scope':'Actual old/new release binaries against the same original empty CLI fixture: old reader accepted schema2, explicit schema3 upgrade and retry, old reader refused schema3, new reader reopened it and served realTCP401. Original inode retained, pre-upgrade bytes preserved but never restored, noinit/recreation. Real user account database untouched; user-record preservation separately covered by software-authenticator tests.'}
(out/'CLI_UPGRADE.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
