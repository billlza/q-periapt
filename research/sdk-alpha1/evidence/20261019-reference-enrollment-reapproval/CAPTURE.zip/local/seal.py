from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='746d83f8468b0fb36b66b4e8e8eabe18d58a1145'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
for name in ['tests-02.stdout','release-tests-01.stdout']:
    text=(out/name).read_text()
    assert all(f'{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in text for count in [20,3])
for name in ['clippy-01.stderr','build-01.stderr','release-tests-01.stderr']:
    text=(out/name).read_text()
    assert 'Finished ' in text and not re.search(r'^(warning|error)(?:\[|:)',text,re.M)
assert 'ReadableTable' in (out/'tests-01.stderr').read_text()
cli=json.loads((out/'CLI_UPGRADE.json').read_text())
binary=out.parent/'continuity-reference-app/release/q-periapt-continuity-reference-app'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==cli['new_binary_sha256']
copy=out/'release-strict-final';assert not copy.exists();shutil.copy2(binary,copy)
source=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
assert len(source)==26
entries={}
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {'.stdout','.stderr','.json','.py'}:
        entries['local/'+path.name]=path.read_bytes()
for name in source:
    data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
    assert data==(repo/name).read_bytes()
    entries['source/'+name]=data
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-reference-enrollment-reapproval';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,item in manifest.items():
        data=z.read(name);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
data=archive.read_bytes()
checks={'head':head,'source_files':len(source),'capture':{'bytes':len(data),'members':len(entries),'sha256':hashlib.sha256(data).hexdigest()},
    'validation':{'debug':'20lib+3binary entries passed','release':'20lib+3binary entries passed with -Dwarnings','behavioral_tests_per_profile':22,'child_dispatcher_entries_per_profile':1,'distinct_sigkill_boundaries_per_profile':14,'strict_all_target_clippy':'passed','strict_release_build':'passed','fmt_and_actionlint':'passed'},
    'runtime':'Actual native SDK request and original client reopen; controlled original signing owner checks the successor credential. Original wrapping/signing file bytes unchanged. Conflict/new-approval paths preserve the original signed request rather than provision a replacement client.',
    'migration':cli,'initial_failure':'First test compilation omitted redb::ReadableTable for the historical fixture helper. Added the trait import; no product check weakened. This is a new API, not a claimed same-API red/green runtime repair.',
    'expiry_scope':'Historical authorization/credential metadata and a correctly signed request at an explicitly historical test time distinguish expiry scopes. The host checks its actual current clock. These are synthetic expiry fixtures, not elapsed-time or device-expiry measurements.',
    'scope':'Optional native reference host with explicit schema3 upgrade and independently authorized reapproval. No SDK source/wire/ABI/dependency changes. No enrollment HTTP/browser connection, installed client, deployed HTTPS, full root/device replacement or expired-unissued credential transition claim.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text('''# Enrollment reapproval with original device state

At `746d83f8468b0fb36b66b4e8e8eabe18d58a1145`, the optional native reference
host adds explicit schema-3 reapproval. A newly authenticated decision can select
the current roster while preserving the original device intent, signed request
and private signing owner. One transaction closes the previous decision, retains
its request/history, moves the signer reservation and publishes the successor.
Repeating the same correlation ID returns that original successor; it never
branches, retargets the root or silently follows a later transition. Explicitly
cancelled and issued operations stay terminal for reapproval.

Debug and release suites each passed 23 entries (22 behavioral tests and one
child dispatcher), including 14 distinct real SIGKILL boundaries. Tests reopen
the original SDK client, compare its request and signing files, and verify the
new credential with the original controlled signer. Negative cases cover wrong
accounts/requests/checkpoints, reused correlations, root suspension, terminal
grants and unchanged credential validity. Expiry fixtures use explicit historical
inputs; they are not real-time expiry measurements.

Strict all-target Clippy, formatting, workflow lint and the strict release build
passed. Actual old/new executables operated on the original preserved empty CLI
database: the old reader accepted schema2, explicit upgrade/retry retained its
inode, the old reader refused schema3, and the new reader reopened it over actual
TCP. Pre-upgrade bytes were saved but never restored. Account-record preservation
is separately tested with real signatures from a software authenticator. The
real user's account database was not upgraded.

The capture contains exact app/workflow source and nonsecret diagnostics,
including the initial test-helper trait-import compilation failure. Private
databases, key files and executables remain local. SDK dependency source is
identified by the Git head rather than duplicated here. Enrollment HTTP/browser
controls, installed independent clients, deployed HTTPS, full replacement and
the expired-unissued-credential transition remain open. This is component
progress, not full lifecycle or release admission.
''')
print(json.dumps(checks['capture']))
