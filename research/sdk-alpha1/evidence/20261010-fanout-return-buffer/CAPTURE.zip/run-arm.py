from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
b=Path(__file__).resolve().parent;arm=sys.argv[1];assert arm in ('baseline','candidate');source=b/(arm+'-source');out=b/(arm+'-01');out.mkdir(mode=0o700)
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin');home=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','JAVA','GRADLE','KOTLIN','PYTHON'))};env.update(CARGO_HOME=str(home),CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(b/(arm+'-build')),RUSTC=str(rust/'bin/rustc'),RUSTDOC=str(rust/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(rust/'lib'),QPC_EXPECT_BORROWED_OUTPUT=str(arm=='candidate').lower())
manifest=source/'research/continuity-identity-candidate/Cargo.toml';cmd=[str(rust/'bin/cargo'),'test','--manifest-path',str(manifest),'--locked','--offline','--release','--all-features','--lib','-j','2']
record={'arm':arm,'source':str(source),'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'toolchain':str(rust),'runs':[],'completed':False,'release_claim_eligible':False,'source_hashes':{n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in ('research/continuity-identity-candidate/src/durable/messages.rs','research/continuity-identity-candidate/src/durable/messages/traffic.rs','research/continuity-identity-candidate/src/durable/messages/fanout.rs','research/continuity-identity-candidate/src/durable/messages/tests/fanout.rs')}}
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
for label,test in [('buffer-observation','fanout_reserved_output_storage_observation'),('durable-boundaries','account_fanout_payload_boundaries_match_individual_traffic_and_restart')]:
 argv=cmd+[test,'--','--nocapture','--test-threads=1'];start=time.monotonic();timed_out=False
 with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:
  proc=subprocess.Popen(argv,cwd=source,env=env,stdout=so,stderr=se,start_new_session=True)
  try:rc=proc.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
   try:rc=proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
 result={'label':label,'command':argv,'returncode':rc,'timed_out':timed_out,'seconds':time.monotonic()-start};record['runs'].append(result);(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(result),flush=True)
 if rc or timed_out:raise SystemExit(1)
record['source_unchanged']=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==sha for n,sha in record['source_hashes'].items());assert record['source_unchanged'];record['completed']=True;(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(arm+' complete',flush=True)
