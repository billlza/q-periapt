from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
b=Path(__file__).resolve().parent;source=b/'candidate-source';out=b/'candidate-checks-01';out.mkdir(mode=0o700)
prior=json.loads((b/'candidate-01/RESULT.json').read_text());assert prior['completed'] and prior['source_unchanged'];before={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in prior['source_hashes']};assert before==prior['source_hashes']
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin');minimum=rust.with_name('1.90.0-aarch64-apple-darwin');home=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e');manifest=source/'research/continuity-identity-candidate/Cargo.toml'
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','JAVA','GRADLE','KOTLIN','PYTHON'))};env.update(CARGO_HOME=str(home),CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(b/'candidate-build'),RUSTC=str(rust/'bin/rustc'),RUSTDOC=str(rust/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(rust/'lib'),QPC_EXPECT_BORROWED_OUTPUT='true')
match=re.search(r'Running unittests src/lib.rs \(([^\n]+)\)',(b/'candidate-01/buffer-observation.stderr').read_text());assert match;binary=Path(match.group(1));assert binary.is_file()
record={'source':str(source),'source_hashes':before,'test_binary':str(binary),'test_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':[],'completed':False,'release_claim_eligible':False};(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
checks=[('native-all-features-release',[str(binary),'--test-threads=2','--nocapture'],env),('strict-clippy',[str(rust/'bin/cargo'),'clippy','--manifest-path',str(manifest),'--locked','--offline','--release','--all-features','--all-targets','-j','2','--','-D','warnings'],env),('changed-production-format',[str(rust/'bin/rustfmt'),'--check','--edition','2021','--config','skip_children=true',*[str(source/n) for n in before if '/tests/' not in n]],env),('minimum-compiler',[str(minimum/'bin/cargo'),'check','--manifest-path',str(manifest),'--locked','--offline','--all-features','--all-targets','-j','2'],dict(env,RUSTC=str(minimum/'bin/rustc'),RUSTDOC=str(minimum/'bin/rustdoc'),CARGO_TARGET_DIR=str(b/'minimum-build'),DYLD_FALLBACK_LIBRARY_PATH=str(minimum/'lib'),PATH=str(minimum/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'))]
for label,cmd,selected in checks:
 start=time.monotonic();timed_out=False
 with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:
  proc=subprocess.Popen(cmd,cwd=source,env=selected,stdout=so,stderr=se,start_new_session=True)
  try:rc=proc.wait(timeout=2400)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
   try:rc=proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
 row={'label':label,'command':cmd,'returncode':rc,'timed_out':timed_out,'seconds':time.monotonic()-start};record['runs'].append(row);(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:row[k] for k in ('label','returncode','timed_out','seconds')}),flush=True)
 if rc or timed_out:raise SystemExit(1)
record['source_unchanged']=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==sha for n,sha in before.items());assert record['source_unchanged'];record['completed']=True;(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print('candidate checks complete',flush=True)
