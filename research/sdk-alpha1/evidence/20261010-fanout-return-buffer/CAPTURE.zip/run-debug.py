from pathlib import Path
import hashlib,json,os,signal,subprocess,time
b=Path(__file__).resolve().parent;source=b/'candidate-source';out=b/'candidate-debug-01';out.mkdir(mode=0o700)
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin');home=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e')
prior=json.loads((b/'candidate-01/RESULT.json').read_text());assert prior['completed'];assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in prior['source_hashes'].items())
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','JAVA','GRADLE','KOTLIN','PYTHON'))};env.update(CARGO_HOME=str(home),CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(b/'candidate-debug-build'),RUSTC=str(rust/'bin/rustc'),RUSTDOC=str(rust/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(rust/'lib'),QPC_EXPECT_BORROWED_OUTPUT='true')
cmd=[str(rust/'bin/cargo'),'test','--manifest-path',str(source/'research/continuity-identity-candidate/Cargo.toml'),'--locked','--offline','--all-features','--lib','-j','2','--','--exact','durable::messages::tests::fanout::fanout_reserved_output_storage_observation','durable::messages::tests::fanout::account_fanout_payload_boundaries_match_individual_traffic_and_restart','--nocapture','--test-threads=2']
record={'command':cmd,'source':str(source),'source_hashes':prior['source_hashes'],'profile':'Debug','completed':False};(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic();timed_out=False
with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:
 p=subprocess.Popen(cmd,cwd=source,env=env,stdout=so,stderr=se,start_new_session=True)
 try:rc=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
record.update(returncode=rc,timed_out=timed_out,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in prior['source_hashes'].items()));record['completed']=rc==0 and not timed_out and record['source_unchanged'];(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ('completed','returncode','timed_out','seconds','source_unchanged')}));assert record['completed']
