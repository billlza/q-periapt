from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import runpy
import rust_sdk_profile as sdk
import continuity_package as package

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-combiner-input'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
MANIFEST = BASE / 'probe/Cargo.toml'
sha = lambda b: hashlib.sha256(b).hexdigest()

def write(p, value):
    with p.open('x') as f: json.dump(value, f, indent=2); f.write('\n')

def lp(value):
    return len(value).to_bytes(8, 'big') + value

def fields(wire):
    result = []
    offset = 0
    while offset < len(wire):
        assert offset + 8 <= len(wire)
        size = int.from_bytes(wire[offset:offset + 8], 'big')
        start = offset + 8
        assert start + size <= len(wire)
        result.append((start, wire[start:start + size]))
        offset = start + size
    return result

def main():
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    names = ['Cargo.toml', 'Cargo.lock', 'crates/q-periapt-core/Cargo.toml',
        'crates/q-periapt-core/src/lib.rs', 'crates/q-periapt-sdk/src/lib.rs',
        'crates/q-periapt-sdk/src/expert/replay.rs', 'crates/q-periapt-kem/src/lib.rs',
        'crates/q-periapt-backends/src/lib.rs', 'crates/q-periapt-backends/src/streaming_sha3.rs',
        'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
        'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
        'target/continuity-combiner-input/probe/Cargo.toml',
        'target/continuity-combiner-input/probe/src/main.rs']
    before = {n: sha((ROOT / n).read_bytes()) for n in names}
    compiler = package.compiler_identity(CHAIN)
    state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': sdk.command(['git', 'rev-parse', 'HEAD'], BASE / 'source-head', ROOT).decode().strip(),
        'source_inputs': before, 'tool_binaries': compiler,
        'scope': 'Instrument the actual core combine_policy_bound encoder with three public chosen-byte fixtures; calculate real SHA3-256 and independently parse/hash its emitted input. No ML-KEM execution or security proof is claimed.',
        'kem_executed': False, 'ind_cca_simulator_complete': False, 'release_claim_eligible': False,
        'driver_sha256': sha(Path(__file__).read_bytes()), 'helper_sha256': sha(helper.read_bytes())}
    assert state['source_commit'] == 'f6de14a347bbd9865077ce4a09d24164b41fe51e'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
        CARGO_TARGET_DIR=str(BASE / 'build'), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2',
        CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never', RUSTC=str(CHAIN / 'bin/rustc'),
        RUSTDOC=str(CHAIN / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
        DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'), PATH=str(CHAIN / 'bin') + os.pathsep + env.get('PATH', os.defpath))
    write(BASE / 'INPUTS.json', state)
    try:
        sdk.command([str(CHAIN / 'bin/cargo'), 'generate-lockfile', '--offline', '--manifest-path', str(MANIFEST)], BASE / 'resolve', ROOT, environment=env)
        lock = sha(MANIFEST.with_name('Cargo.lock').read_bytes())
        raw = sdk.command([str(CHAIN / 'bin/cargo'), 'run', '--manifest-path', str(MANIFEST), '--locked', '--offline', '--release'], BASE / 'probe-run', ROOT, environment=env).decode()
        rows = raw.splitlines()
        assert len(rows) == 9
        actual = {}
        for n in range(0, 9, 3):
            assert rows[n].startswith('fixture=') and rows[n+1].startswith('input=') and rows[n+2].startswith('digest=')
            name = rows[n].removeprefix('fixture=')
            assert name not in actual
            data = bytes.fromhex(rows[n+1].removeprefix('input='))
            digest = rows[n+2].removeprefix('digest=')
            assert len(data) == 2639 and hashlib.sha3_256(data).hexdigest() == digest
            actual[name] = data
        assert set(actual) == {'base', 'changed-pq', 'changed-context'}
        checks = {}
        for name, data in actual.items():
            pq = bytes([0x10 if name == 'changed-pq' else 0x11]) + bytes([0x11])*31
            ctx = bytes([0x89 if name == 'changed-context' else 0x88]) + bytes([0x88])*31
            context = lp(b'Q-PERIAPT-POLICY-CONTEXT/v1') + lp(bytes([0x77])*32) + lp(ctx)
            expected = [b'Q-PERIAPT-HYBRID-KEM/v1', b'ML-KEM-768+X25519', (7).to_bytes(4,'big'),
                        pq, bytes([0x22])*32, bytes([0x33])*1088, bytes([0x44])*1184,
                        bytes([0x55])*32, bytes([0x66])*32, context]
            decoded = fields(data)
            assert [x[1] for x in decoded] == expected
            assert data == b''.join(map(lp, expected))
            assert decoded[3][0] == 76 and data[76:108] == pq
            nested = fields(decoded[-1][1])
            assert [x[1] for x in nested] == [b'Q-PERIAPT-POLICY-CONTEXT/v1', bytes([0x77])*32, ctx]
            checks[name] = {'bytes': len(data), 'sha3_256': hashlib.sha3_256(data).hexdigest(),
                'field_offsets': [x[0] for x in decoded], 'field_lengths': [len(x[1]) for x in decoded],
                'nested_context_field_lengths': [len(x[1]) for x in nested]}
            with (BASE / (name + '.input')).open('xb') as f: f.write(data)
        assert [i for i,(a,b) in enumerate(zip(actual['base'],actual['changed-pq'])) if a != b] == [76]
        assert [i for i,(a,b) in enumerate(zip(actual['base'],actual['changed-context'])) if a != b] == [2607]
        sdk.command([str(CHAIN / 'bin/rustfmt'), '--edition', '2021', '--check', str(BASE/'probe/src/main.rs')], BASE/'rustfmt', ROOT, environment=env)
        assert sha(MANIFEST.with_name('Cargo.lock').read_bytes()) == lock
        assert {n: sha((ROOT / n).read_bytes()) for n in names} == before
        assert package.compiler_identity(CHAIN) == compiler
        state.update(completed=True, fixtures=checks, input_bytes=2639, pq_secret_offset=[76,108],
            independent_sha3_readback=True, source_inputs_unchanged=True, lock_unchanged=True,
            probe_lock_sha256=lock)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE/'RESULT.json',state)
        print(json.dumps({k:state.get(k) for k in ['completed','input_bytes','pq_secret_offset','error_type','error']},indent=2),flush=True)

if __name__ == '__main__': main()
