from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-combiner-input'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-contextbound-secret-hop'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
run = json.loads((BASE / 'RESULT.json').read_bytes())
launch = json.loads((BASE / 'LAUNCH_RESULT.json').read_bytes())
assert run['completed'] and run['source_inputs_unchanged'] and run['independent_sha3_readback']
assert launch['completed'] and launch['returncode'] == 0
assert launch['timeout_seconds'] == launch['component_timeout_seconds'] == 900
assert run['input_bytes'] == 2639 and run['pq_secret_offset'] == [76,108]
assert sha((BASE/'run.py').read_bytes()) == launch['driver_sha256'] == run['driver_sha256']
assert sha((BASE/'launch.py').read_bytes()) == launch['launcher_sha256']
assert sha((BASE/'probe/Cargo.lock').read_bytes()) == run['probe_lock_sha256']
files = {}
for p in BASE.iterdir():
    assert not p.is_symlink()
    if p.is_file(): files['capture/' + p.name] = p.read_bytes()
for p in (BASE/'probe').rglob('*'):
    assert not p.is_symlink()
    if p.is_file(): files['capture/probe/' + p.relative_to(BASE/'probe').as_posix()] = p.read_bytes()
for name, expected in run['source_inputs'].items():
    body = (ROOT/name).read_bytes()
    assert sha(body) == expected, name
    files['sources/'+name] = body
for name, expected in run['fixtures'].items():
    data = (BASE/(name+'.input')).read_bytes()
    assert len(data) == expected['bytes'] == 2639
    assert hashlib.sha3_256(data).hexdigest() == expected['sha3_256']
docs = ['docs/continuity/CONTEXTBOUND_SECRET_HOP_V1.md',
        'docs/continuity/COMPUTATIONAL_RECOVERY_V1.md', 'docs/continuity/EXTERNAL_REVIEW_BRIEF.md',
        'research/sdk-alpha1/evidence/20261105-contextbound-secret-hop/README.md']
for name in docs:
    p = ROOT/name
    data = p.read_bytes()
    for link in re.findall(r'\]\(([^)]+)\)',data.decode()):
        if '://' not in link and not link.startswith('#'):
            assert (p.parent/link.split('#',1)[0]).resolve().is_file(), (name,link)
    files['documents/'+name] = data
files['FILES.json'] = encode({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,5,0,0,0))
        info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16
        info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
payload=buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist())==len(files) and set(archive.namelist())==set(files)
    for name,data in files.items(): assert archive.read(name)==data
summary={'captured_utc':datetime.now(timezone.utc).isoformat(),'bytes':len(payload),
    'members':len(files),'sha256':sha(payload),'all_members_read_back':True,
    'source_commit':run['source_commit'],'public_encoding_fixtures':3,
    'input_bytes':2639,'pq_secret_offset':[76,108],'kem_executed':False,
    'ind_cca_simulator_complete':False,'release_claim_eligible':False}
for name,data in [('CAPTURE.zip',payload),('FILES.json',files['FILES.json']),('SHA256.json',encode(summary))]:
    with (DEST/name).open('xb') as f:f.write(data)
print(json.dumps(summary,indent=2),flush=True)
