from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import time
from bounded_process import capture_output, TimeoutPolicy

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-combiner-input'
argv = ['/bin/sh', 'artifact/python-run.sh', 'target/continuity-combiner-input/run.py']
state = {'completed': False, 'argv': argv, 'cwd': str(ROOT), 'started_utc': datetime.now(timezone.utc).isoformat(),
         'timeout_seconds': 900, 'component_timeout_seconds': 900, 'component_stream_limit_bytes': 16*1024**2,
         'budget_origin': 'Focused encoding readback is bounded to 900 seconds; each command retains the existing 900-second capture limit.',
         'driver_sha256': hashlib.sha256((BASE / 'run.py').read_bytes()).hexdigest(),
         'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (BASE / 'LAUNCH.json').open('x') as f: json.dump(state, f, indent=2); f.write('\n')
started = time.monotonic()
try:
    env = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/share/uv/python/cpython-3.14.10-macos-aarch64-none/bin/python3.14')
    with (BASE / 'driver.stdout').open('xb', buffering=0) as out, (BASE / 'driver.stderr').open('xb', buffering=0) as err:
        result = capture_output(argv, timeout_seconds=900, timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
            maximum_stdout_bytes=16*1024**2, maximum_stderr_bytes=16*1024**2,
            environment=env, stdout_sink=out.write, stderr_sink=err.write)
    state['returncode'] = result.returncode
    assert result.returncode == 0, 'Combiner encoding readback failed; original evidence retained.'
    assert json.loads((BASE / 'RESULT.json').read_bytes())['completed']
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    for name in ['kind', 'cleanup_ambiguous', 'signal_number']:
        if hasattr(error, name): state[name] = getattr(error, name)
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-started)
    for suffix in ['stdout', 'stderr']:
        state[suffix+'_sha256'] = hashlib.sha256((BASE / ('driver.'+suffix)).read_bytes()).hexdigest()
    with (BASE / 'LAUNCH_RESULT.json').open('x') as f: json.dump(state, f, indent=2); f.write('\n')
    print(json.dumps(state, indent=2), flush=True)
