//! Public chosen-byte fixtures only: capture the real core encoder's hash input.
use q_periapt_core::{combine_policy_bound, secure_wipe, CombineInput, Xof256};
use sha3::{Digest, Sha3_256};

struct Capture(Vec<u8>);
impl Drop for Capture {
    fn drop(&mut self) {
        secure_wipe(&mut self.0);
    }
}
fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}
impl Xof256 for Capture {
    fn new() -> Self {
        Self(Vec::new())
    }
    fn reserve(&mut self, bytes: usize) {
        self.0.reserve_exact(bytes);
    }
    fn absorb(&mut self, bytes: &[u8]) {
        assert!(self.0.len() + bytes.len() <= self.0.capacity());
        self.0.extend_from_slice(bytes);
    }
    fn squeeze32(self) -> [u8; 32] {
        println!("input={}", hex(&self.0));
        Sha3_256::digest(&self.0).into()
    }
}

fn main() {
    for name in ["base", "changed-pq", "changed-context"] {
        let mut pq = [0x11; 32];
        let mut context = [0x88; 32];
        if name == "changed-pq" {
            pq[0] ^= 1;
        }
        if name == "changed-context" {
            context[0] ^= 1;
        }
        let input = CombineInput {
            suite_id: b"ML-KEM-768+X25519",
            policy_version: 7,
            ss_pq: &pq,
            ss_trad: &[0x22; 32],
            ct_pq: &[0x33; 1088],
            pk_pq: &[0x44; 1184],
            ct_trad: &[0x55; 32],
            pk_trad: &[0x66; 32],
            context: &context,
        };
        println!("fixture={name}");
        let value = combine_policy_bound::<Capture>(&input, &[0x77; 32])
            .expect("the actual core encoder accepts the public shape");
        println!("digest={}", hex(value.as_bytes()));
    }
}
