"""Capture bounded open proof frontiers; deliberately select no search step."""
from pathlib import Path
import fcntl
import hashlib
import json
import re
import sys
import time

stage = Path(__file__).resolve().parent
folder = stage / 'initial-send-oracle-frames'
try:
    if sys.argv[1:] != ['epoch_generation_secret_derivation_origin_with_phase_roots']:
        raise ValueError('unexpected lemma')
    raw = sys.stdin.read(4 * 1024 * 1024 + 1)
    payload = raw.encode()
    if len(payload) > 4 * 1024 * 1024:
        raise ValueError('frontier input bound or empty input')
    matches = [re.fullmatch(r'([0-9]+):\s*(.+)', line) for line in raw.splitlines()]
    if not all(matches):
        raise ValueError('unexpected frontier encoding')
    goals = [int(match[1]) for match in matches]
    if len(goals) != len(set(goals)):
        raise ValueError('duplicate goal numbers')
    with (stage / 'initial-send-oracle.lock').open('a') as lock:
        deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('frontier capture lock exceeded five seconds')
                time.sleep(0.01)
        rows = [json.loads(path.read_text()) for path in folder.glob('*.json')]
        if len(rows) >= 32 or sum(row['input_bytes'] for row in rows) + len(payload) > 16 * 1024 * 1024:
            raise ValueError('frontier capture budget exceeded')
        stem = f'{len(rows):04}'
        with (folder / (stem + '.txt')).open('xb') as stream:
            stream.write(payload)
        with (folder / (stem + '.json')).open('x') as stream:
            json.dump({'input_sha256': hashlib.sha256(payload).hexdigest(), 'input_bytes': len(payload),
                'goal_numbers': goals, 'ranking': [], 'diagnostic_stop': True,
                'stop_reason': 'frontier-capture-no-search', 'captured_input': stem + '.txt'}, stream, indent=2)
            stream.write('\n')
        (stage / 'initial-send-oracle.diagnostic-stop').write_text('frontier-capture-no-search\n')
except Exception as error:
    (stage / 'initial-send-oracle.failed').write_text(type(error).__name__ + ': ' + str(error) + '\n')
    raise
