"""Replace stale proof methods with captured current goals and restore full siblings."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path.cwd();capture=root/'target/p0-origin-context-capture-720'
terminal=json.loads((capture/'origin-context-capture-TERMINAL.json').read_text())
parent=capture/'origin-context-capture-proof.spthy';data=parent.read_bytes()
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out']
assert hashlib.sha256(data).hexdigest()==terminal['output_sha256']
text=data.decode();assert 'invalid proof step encountered' not in text
name='epoch_generation_secret_derivation_origin_with_phase_roots';a=text.index('lemma '+name+' ')
end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start();body=text[a:b]
frontiers=json.loads((capture/'FRONTIERS.json').read_text())
leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',body));assert len(leaves)==len(frontiers)==18
changes=[];methods=[]
for leaf,row in zip(leaves,frontiers,strict=True):
 if row['target'] is None:continue
 raw=(capture/'initial-send-oracle-frames'/row['frame']).read_text()
 assert hashlib.sha256(raw.encode()).hexdigest()==row['input_sha256']
 choices=[re.fullmatch(r'(\d+): (PositionedPhaseState\(.*)',line) for line in raw.splitlines() if 'PositionedPhaseState(' in line and "'Response5'" in line]
 assert len(choices)==1 and choices[0]
 method=choices[0][2]
 assert re.search(r'\[no_precomp\] ▶₀ #vr(?:\.[0-9]+)?$',method)
 changes.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
 methods.append(row|{'method':method,'goal_index':int(choices[0][1])})
assert len(changes)==7
for left,right,replacement in reversed(changes):body=body[:left]+replacement+body[right:]
roots={m[1]:m for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
snapshot=roots['Snapshot_case_5'];part=snapshot[0]
retained=json.loads((capture/'RETAINED_WHOLE_SUBTREES.json').read_text());assert len(retained)==6
for name,value in retained.items():
 matches=list(re.finditer(r'(?ms)^      case '+re.escape(name)+r'\n(.*?)(?=^    next|^    qed)',part))
 assert len(matches)==1 and matches[0][0].count('by sorry')==1 and 'Oracle ranked no proof methods' in matches[0][0]
 part=part[:matches[0].start()]+value+part[matches[0].end():]
body=body[:snapshot.start()]+part+body[snapshot.end():]
candidate=text[:a]+body+text[b:]
assert candidate[:a]==text[:a] and candidate[a+len(body):]==text[b:]
assert candidate[a:].split('"',2)[1]==text[a:].split('"',2)[1]
for name,value in retained.items():
 assert value in body
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-context-repair-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate);shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent':str(parent),'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'actual_captured_methods':methods,'six_unselected_whole_subtrees_restored_byte_for_byte':True,
 'all_34_formulas_operational_rules_and_other_proofs_unchanged':True,'mode':'replay without search or oracle',
 'root_cause':'The response constructor lemma instantiates the old generic core and renames related variables. All7captured contexts have one current Response5 premise; stale generic-core solve strings no longer select it.',
 'expected_acceptance':'Inspect theorem statuses AND invalid-proof-step markers before classifying the whole frontier. An incomplete theorem remains incomplete.'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'repaired_methods':7,'restored_subtrees':6}))
