"""Expose the seven changed proof contexts while retaining every other subtree."""
from pathlib import Path
import hashlib,json,re,shlex,shutil
root=Path.cwd();parent=root/'target/p0-origin-closed-contexts-720/origin-closed-contexts-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='9750d5a64da976729f94f8c77b4ead572803bfb3f744fac36ba14e5cb2f6e4f8'
text=data.decode();name='epoch_generation_secret_derivation_origin_with_phase_roots'
a=text.index('lemma '+name+' ');end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start();body=text[a:b]
pattern=r'(?m)^(?P<indent> *)sorry /\* invalid proof step encountered \*/\n(?P=indent)by contradiction /\* unannotated \*/\n'
matches=list(re.finditer(pattern,body));assert len(matches)==7
for index,m in reversed(list(enumerate(matches))):
 body=body[:m.start()]+m['indent']+f'by sorry /* changed-context-{index} */\n'+body[m.end():]
full_holes=body
roots={m[1]:m for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
snapshot=roots['Snapshot_case_5'];part=snapshot[0]
children=list(re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',part));assert len(children)==11
assert {m[1] for m in children if 'changed-context-' in m[0]}=={'Receipt_Reservation_9','Response_Commit_6'}
names={m[1] for m in children if 'by sorry' in m[0] and 'changed-context-' not in m[0]}
assert names=={'Final_Commit_8','Final_Reservation_7','Offer_Commit_3','Receipt_Accept_0','Receipt_Commit_0','Response_Compute_5'}
retained={m[1]:m[0] for m in children if m[1] in names};assert set(retained)==names
for m in reversed(children):
 if m[1] in names:part=part[:m.start()]+'      case '+m[1]+'\n      by sorry /* retained-whole-subtree */\n'+part[m.end():]
body=body[:snapshot.start()]+part+body[snapshot.end():]
assert body.count('by sorry')==18 and body.count('changed-context-')==7
stack=[];targets=[]
for line in body.splitlines():
 m=re.fullmatch(r'( *)case (\S+)',line)
 if m:
  indent=len(m[1])
  while stack and stack[-1][0]>=indent:stack.pop()
  stack.append((indent,m[2]))
 if 'changed-context-' in line:targets.append({'ordinal':int(re.search(r'changed-context-(\d+)',line)[1]),'case_path':[x[1] for x in stack]})
assert len(targets)==7 and len({tuple(x['case_path']) for x in targets})==7
candidate=text[:a]+body+text[b:]
stage=root/'target/p0-origin-context-capture-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
(stage/'full-context-holes.txt').write_text(full_holes)
(stage/'RETAINED_WHOLE_SUBTREES.json').write_text(json.dumps(retained,indent=2)+'\n')
(stage/'TARGET_PATHS.json').write_text(json.dumps(targets,indent=2)+'\n')
driver=(root/'target/p0-wire-scope-replay-704/run.py').read_text()
driver=driver.replace('"--heuristic=s",','"--heuristic=O", "--oracle-only", "--oraclename=" + str(stage / "initial-send-oracle.sh"),')
driver=driver.replace('"--bound=16"','"--bound=1"')
(stage/'run.py').write_text(driver);(stage/'initial-send-oracle-frames').mkdir()
oracle=(root/'target/p0-origin-offer-response-frontiers-718/initial-send-oracle.py').read_text()
oracle=oracle.replace("['epoch_generation_secret_derivation_origin']",repr([name]))
oracle=oracle.replace('if len(payload) > 4 * 1024 * 1024 or not raw:', 'if len(payload) > 4 * 1024 * 1024:')
(stage/'initial-send-oracle.py').write_text(oracle)
(stage/'initial-send-oracle.sh').write_text('#!/bin/sh\nexec /usr/bin/env QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 /bin/sh '+shlex.quote(str(root/'artifact/python-run.sh'))+' '+shlex.quote(str(stage/'initial-send-oracle.py'))+' "$@"\n')
(stage/'initial-send-oracle.sh').chmod(0o755)
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'changed_contexts':7,'focused_holes':18,'unselected_whole_subtrees_retained':sorted(names),
 'no_lemma_or_operational_change':True,'oracle_ranks_no_method':True,'capture_only_not_proof':True,
 'restoration_required_before_whole_origin_claim':True,'callback_limit':32}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'holes':18,'target_paths':targets}))
