"""Preserve actual changed goals and the valid full-tree repair, without claiming secrecy."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
from deterministic_archive import create_zip
root=Path.cwd();sha=lambda value:hashlib.sha256(value).hexdigest()
capture=root/'target/p0-origin-context-capture-720';repair=root/'target/p0-origin-context-repair-720'
c=json.loads((capture/'origin-context-capture-TERMINAL.json').read_text())
r=json.loads((repair/'origin-context-repair-TERMINAL.json').read_text())
for record in (c,r):assert record['returncode']==0 and not record['accepted'] and not record['timed_out'] and not record['output_exceeded']
source=repair/'origin-context-repair-proof.spthy';text=source.read_text();assert sha(source.read_bytes())==r['output_sha256']
name='epoch_generation_secret_derivation_origin_with_phase_roots';start=text.index('lemma '+name+' ')
end=re.search(r'(?m)^/\* All wellformedness|^end$',text[start:]);body=text[start:start+end.start()]
assert 'invalid proof step encountered' not in text
assert body.count('by sorry')==41 and r['results'][name]['status']=='analysis incomplete'
roots={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
assert len(roots)==18
open_sources={k:v.count('by sorry') for k,v in roots.items() if 'by sorry' in v}
assert open_sources=={'Response_Commit_6':1,'Snapshot_case_5':40}
children={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',roots['Snapshot_case_5'])}
retained=json.loads((capture/'RETAINED_WHOLE_SUBTREES.json').read_text())
assert len(retained)==6 and all(children[k]==v for k,v in retained.items())
methods=json.loads((repair/'PREPARATION.json').read_text())['actual_captured_methods'];assert len(methods)==7
frames=sorted((capture/'initial-send-oracle-frames').glob('*.json'));assert len(frames)==18
for frame in frames:
 value=json.loads(frame.read_text());data=frame.with_suffix('.txt').read_bytes()
 assert sha(data)==value['input_sha256'] and len(data)==value['input_bytes'] and value['ranking']==[]
for name in ('phase_roots_are_initial_or_hashed','generation_and_initial_phase_roots_are_distinct',
             'signed_offer_payload_has_key_constructor','signed_response_payload_has_public_constructors'):
 assert r['results'][name]['status']=='verified'
analysis={'schema_version':1,'source_commit':'c1d329663158fb18b8fb4b7d5f8c7f7eb7fb438a',
 'capture_callbacks':18,'changed_contexts':7,'captured_goal_membership_checked':True,
 'repaired_goal_kind':'PositionedPhaseState Response5, with the constructor-instantiated core and current variable names',
 'restored_whole_subtrees':sorted(retained),'six_subtrees_byte_equal_in_final_output':True,
 'whole_tree_replay_steps':r['results']['epoch_generation_secret_derivation_origin_with_phase_roots']['steps'],
 'invalid_proof_steps':0,'valid_open_leaves':41,'open_source_branches':open_sources,
 'closed_source_branches':16,'stored_open_leaves':{k:v.count('by sorry') for k,v in children.items()},
 'all_trace_auxiliaries_verified':18,'initial_traffic_witness_steps':414,
 'tool_exit':0,'driver_exit':1,'accepted':False,'timed_out':False,
 'capture_seconds':c['elapsed_seconds'],'full_replay_seconds':r['elapsed_seconds'],
 'final_model_sha256':r['output_sha256'],
 'interpretation':'Seven incompatible proof methods are now repaired. The new tree is a valid partial proof, not a complete source-origin proof. One response-source branch and40Snapshot branches remain. Do not infer monotonic proof progress from42to41: previously closed proof tails were exposed for repair, and the old382step/42leaf baseline remains intact.',
 'next':'Inspect the single response-source leaf and the40Snapshot leaves in this valid current tree, using captured goals rather than stale generic-core methods; no further invariant is justified solely by leaf counts.',
 'release_claim_eligible':False}
stage=root/'target/p0-origin-repair-capsule-720';stage.mkdir(exist_ok=False);inputs=stage/'inputs';inputs.mkdir()
for label,folder in [('capture',capture),('full-repair',repair)]:
 target=inputs/label;target.mkdir()
 for path in sorted(folder.rglob('*')):
  if path.is_dir():continue
  assert path.is_file() and not path.is_symlink()
  dest=target/path.relative_to(folder);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
for name in ('prepare-origin-context-capture-720.py','prepare-origin-context-repair-720.py','package-origin-repair-720.py'):
 shutil.copy2(root/'target'/name,inputs/name)
(inputs/'ANALYSIS.json').write_text(json.dumps(analysis,indent=2)+'\n')
destination=root/'research/sdk-alpha1/evidence/20261029-phase-root-observations'
create_zip(inputs,destination/'REPAIR_CAPTURE.zip',root_name='origin-context-repair',mtime=315532800)
members={'origin-context-repair/'+str(p.relative_to(inputs)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
 for p in sorted(inputs.rglob('*')) if p.is_file()}
with zipfile.ZipFile(destination/'REPAIR_CAPTURE.zip') as z:
 assert {i.filename for i in z.infolist() if not i.is_dir()}==set(members) and z.testzip() is None
 for name,item in members.items():
  raw=z.read(name);assert item=={'bytes':len(raw),'sha256':sha(raw)}
archive=destination/'REPAIR_CAPTURE.zip'
manifest={'schema_version':1,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
 'members':members,'analysis':analysis}
(destination/'REPAIR_CAPTURE.json').write_text(json.dumps(manifest,indent=2)+'\n')
(destination/'REPAIR_READBACK.json').write_text(json.dumps({'archive_sha256':manifest['archive_sha256'],
 'manifest_sha256':sha((destination/'REPAIR_CAPTURE.json').read_bytes()),'file_members':len(members),
 'all_members_byte_compared':True,'invalid_proof_steps':0,'origin_proof_complete':False,
 'valid_open_leaves':41,'release_claim_eligible':False},indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'bytes':manifest['archive_bytes'],'files':len(members),'analysis':analysis}))
