"""Retain verified phase-root invariants and distinguish invalid proof copies."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
from deterministic_archive import create_zip
root=Path.cwd();sha=lambda value:hashlib.sha256(value).hexdigest()
stages={
 'initial':('p0-phase-root-observations-720','phase-root-observations',1),
 'guide01':('p0-phase-root-guided-720','phase-root-guided',1),
 'guide02':('p0-phase-root-guided02-720','phase-root-guided02',1),
 'verified':('p0-phase-root-guided03-720','phase-root-guided03',0),
 'combined-copy':('p0-origin-phase-root-replay-720','origin-phase-root-replay',1),
 'contradiction-probe':('p0-origin-closed-contexts-720','origin-closed-contexts',1),
}
terminals={}
for label,(folder,prefix,exit_code) in stages.items():
 path=root/'target'/folder
 r=json.loads((path/(prefix+'-TERMINAL.json')).read_text())
 assert r['accepted'] is (exit_code==0) and not r['timed_out'] and not r['output_exceeded']
 assert sha((path/'model.spthy').read_bytes())==r['input_sha256']
 if r['output_sha256'] is not None:assert sha((path/(prefix+'-proof.spthy')).read_bytes())==r['output_sha256']
 assert r['returncode']==(-2 if label in ('guide01','guide02') else 0)
 terminals[label]=r|{'observed_driver_exit':exit_code}
source=root/'target/p0-origin-offer-response-full-replay-718/offer-response-full-proof.spthy'
original=source.read_text();instrumented=(root/'target/p0-phase-root-observations-720/model.spthy').read_text()
prefix=instrumented[:instrumented.index('lemma ')]
erased,count=re.subn(r',\n  /\* phase-root-observation:[^*]+\*/\n.*?(?=\]->)','',prefix,flags=re.S)
assert count==12 and erased==original[:original.index('lemma ')]
assert prefix.count('ProducedPhaseRoot(')==17 and prefix.count('InitialPhaseRoot(')==1
verified=terminals['verified']
assert verified['results']['phase_roots_are_initial_or_hashed']=={'mode':'all-traces','status':'verified','steps':75}
assert verified['results']['generation_and_initial_phase_roots_are_distinct']=={'mode':'all-traces','status':'verified','steps':1}
frames=[]
for path in sorted((root/'target/p0-phase-root-guided03-720/initial-send-oracle-frames').glob('*.json')):
 row=json.loads(path.read_text());raw=path.with_suffix('.txt').read_bytes()
 assert sha(raw)==row['input_sha256'] and len(raw)==row['input_bytes']
 assert len(row['ranking'])==1 and set(row['ranking'])<=set(row['goal_numbers'])
 frames.append(row)
assert len(frames)==30 and sum(r['class']=='phase-premise' for r in frames)==13
assert sum(r['class']=='induction-order' for r in frames)==17
def frontier(text,name):
 start=text.index('lemma '+name+' ')
 end=re.search(r'(?m)^lemma |^/\* All wellformedness|^end$',text[start+6:])
 block=text[start:start+6+end.start()]
 explicit=len(re.findall(r'(?m)^\s*by sorry\b',block))
 invalid=len(re.findall(r'(?m)^\s*sorry /\* invalid proof step encountered \*/',block))
 return {'explicit_by_sorry_tokens':explicit,'invalid_proof_steps':invalid,
         'valid_comparable_frontier':invalid==0,'valid_frontier_leaves':explicit if invalid==0 else None}
old_name='epoch_generation_secret_derivation_origin';new_name=old_name+'_with_phase_roots'
baseline=frontier(original,old_name);assert baseline['valid_frontier_leaves']==42
comparison={}
for label in ('combined-copy','contradiction-probe'):
 folder,prefix,_=stages[label];text=(root/'target'/folder/(prefix+'-proof.spthy')).read_text()
 comparison[label]=frontier(text,new_name)|{'steps':terminals[label]['results'][new_name]['steps']}
 assert comparison[label]['invalid_proof_steps']==7 and not comparison[label]['valid_comparable_frontier']
analysis={'schema_version':1,'source_commit':'dea0d3715d30bd727b497468f7a7c6bfe6fa0671',
 'observation_erasure_exact':True,'original_operational_prefix_sha256':sha(erased.encode()),
 'instrumented_rules':12,'root_field_observations':17,'initial_root_observations':1,
 'added_actions_only':True,'changed_premises_conclusions_equations_restrictions':False,
 'root_is_existing_fresh_initial_material_or_hash_not_a_fixed_initial_constant':True,
 'phase_root_proof':verified['results']['phase_roots_are_initial_or_hashed'],
 'initial_root_separation_proof':verified['results']['generation_and_initial_phase_roots_are_distinct'],
 'new_root_properties_nonreuse_during_independent_proof':True,'old13reuse_hidden_for_independent_root_checks':True,
 'verified_oracle_callbacks':30,'callback_classes':{'phase-premise':13,'induction-order':17},
 'maximum_callbacks':32,'maximum_total_search_depth':16,'guide_remaining_depth':10,
 'baseline':baseline,'combined_attempts':comparison,
 'current_origin_and_multi_epoch_secrecy':'incomplete',
 'prior719_interpretation_corrected':'Seven invalid copied proof steps were omitted by a by-sorry-only counter. The42legacy tokens are not a valid new frontier; helper ineffectiveness was not established. The retained719rawcapture remains unchanged, with CORRECTION.json and corrected README.',
 'contradiction_hypothesis_rejected':'Replacing the7stale solve subtrees with contradiction still produces7invalid steps. Do not treat the34explicit open tokens or353recorded steps as proof progress.',
 'next':'Capture the exact current goals at all7changed contexts, retain and restore the six unselected full Stored subtrees, then validate actual replacement methods. Do not add more invariants based solely on unchanged token counts.',
 'limits':{'seconds_per_run':900,'heap_gib':12,'threads':1,'derivation_seconds':60,'strictwarnings':True},
 'runs':{label:{key:value[key] for key in ('elapsed_seconds','returncode','observed_driver_exit','accepted','timed_out','input_sha256','output_sha256')} for label,value in terminals.items()},
 'method_reference':'https://tamarin-prover.com/manual/master/book/011_advanced-features.html#using-an-oracle',
 'release_claim_eligible':False}
stage=root/'target/p0-phase-root-capsule-720';stage.mkdir(exist_ok=False);inputs=stage/'inputs';inputs.mkdir()
for label,(folder,_,_) in stages.items():
 source_dir=root/'target'/folder;target=inputs/label;target.mkdir()
 for p in sorted(source_dir.rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink()
  destination=target/p.relative_to(source_dir);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,destination)
context=inputs/'context';context.mkdir()
for path,name in [(source,'original-382-step-proof.spthy'),
 (root/'target/witness-renewal-01/P0_PINNED_PROVER_IDENTITY_01.json','PINNED_PROVER_IDENTITY.json'),
 (root/'research/sdk-alpha1/evidence/20261029-wire-payload-shapes/CORRECTION.json','CORRECTION_719.json')]:shutil.copy2(path,context/name)
for name in ('prepare-phase-root-observations-720.py','prepare-phase-root-guidance-720.py','prepare-phase-root-guidance-02-720.py',
             'prepare-origin-phase-root-replay-720.py','prepare-origin-closed-contexts-720.py','package-phase-root-evidence-720.py'):
 shutil.copy2(root/'target'/name,context/name)
(inputs/'ANALYSIS.json').write_text(json.dumps(analysis,indent=2)+'\n')
destination=root/'research/sdk-alpha1/evidence/20261029-phase-root-observations';destination.mkdir(exist_ok=False)
create_zip(inputs,destination/'CAPTURE.zip',root_name='phase-root-observations',mtime=315532800)
members={'phase-root-observations/'+str(p.relative_to(inputs)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
 for p in sorted(inputs.rglob('*')) if p.is_file()}
with zipfile.ZipFile(destination/'CAPTURE.zip') as z:
 assert {i.filename for i in z.infolist() if not i.is_dir()}==set(members) and z.testzip() is None
 for name,item in members.items():
  raw=z.read(name);assert item=={'bytes':len(raw),'sha256':sha(raw)}
archive=destination/'CAPTURE.zip'
manifest={'schema_version':1,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
 'members':members,'analysis':analysis}
(destination/'CAPTURE.json').write_text(json.dumps(manifest,indent=2)+'\n')
readback={'schema_version':1,'archive_sha256':manifest['archive_sha256'],
 'manifest_sha256':sha((destination/'CAPTURE.json').read_bytes()),'file_members':len(members),
 'expanded_bytes':sum(x['bytes'] for x in members.values()),'all_members_byte_compared':True,
 'phase_root_and_initial_root_separation_verified':True,'origin_main_proof_complete':False,
 'combined_frontier_comparison_admissible':False,'release_claim_eligible':False}
(destination/'READBACK.json').write_text(json.dumps(readback,indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'bytes':manifest['archive_bytes'],'files':len(members),'analysis':analysis['combined_attempts']}))
