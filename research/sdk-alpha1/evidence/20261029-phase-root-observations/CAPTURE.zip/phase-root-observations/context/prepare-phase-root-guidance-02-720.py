"""Preserve the checked induction split and guide only unresolved root sources."""
from pathlib import Path
import hashlib,json,re,shlex
root=Path.cwd();parent=root/'target/p0-phase-root-observations-720/phase-root-observations-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='c28d7bcd8692a27357c8889e351b6df880f1db4bc5afcd91277a873f6f7eefbb'
text=data.decode();a=text.index('lemma phase_roots_are_initial_or_hashed ');b=text.index('\nlemma ',a);body=text[a:b]
branches=list(re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',body))
inventory=json.loads((root/'target/p0-phase-root-observations-720/PREPARATION.json').read_text())
assert len(branches)==inventory['observed_phase_root_fields']==17
assert {m[1] for m in branches if 'by sorry' not in m[0]}=={'Final_Reservation_7_case_2','Response_Compute_5_case_2','Setup_case_1','Setup_case_2'}
changed=[]
for match in reversed(branches):
    if 'by sorry' not in match[0]:continue
    changed.append({'case':match[1],'retained_prior_branch_sha256':hashlib.sha256(match[0].encode()).hexdigest()})
    body=body[:match.start()]+'      case '+match[1]+'\n      by sorry\n'+body[match.end():]
assert len(changed)==13
candidate=text[:a]+body+text[b:]
assert candidate[:a]==text[:a] and candidate[a+len(body):]==text[b:]
stage=root/'target/p0-phase-root-guided02-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
driver=(root/'target/p0-phase-root-guided-720/run.py').read_text()
assert driver.count('"--bound=16"')==1;driver=driver.replace('"--bound=16"','"--bound=10"')
(stage/'run.py').write_text(driver);(stage/'initial-send-oracle-frames').mkdir()
oracle=(root/'target/p0-phase-root-guided-720/initial-send-oracle.py').read_text()
assert oracle.count('if not data or len(data)>4*1024*1024:')==1
oracle=oracle.replace('if not data or len(data)>4*1024*1024:','if len(data)>4*1024*1024:')
oracle=oracle.replace("selected=[];kind='unsupported-goal-class'","selected=[];kind='unsupported-goal-class' if data else 'empty-goal-set'")
oracle=oracle.replace("if not ranking:(stage/'initial-send-oracle.diagnostic-stop')","if not ranking and data:(stage/'initial-send-oracle.diagnostic-stop')")
(stage/'initial-send-oracle.py').write_text(oracle)
script='#!/bin/sh\nexec /usr/bin/env QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 /bin/sh '+shlex.quote(str(root/'artifact/python-run.sh'))+' '+shlex.quote(str(stage/'initial-send-oracle.py'))+' "$@"\n'
(stage/'initial-send-oracle.sh').write_text(script);(stage/'initial-send-oracle.sh').chmod(0o755)
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'unchanged_formulas_operational_rules_and_observations':True,'retained_induction_and_source_split':True,
 'four_closed_source_branches_retained':True,'replaced_open_subtrees':list(reversed(changed)),
 'remaining_search_depth':10,'maximum_total_depth':16,'maximum_callbacks':32,
 'empty_goal_input_contract':'An empty set has no indices to rank; return an empty ranking and let the prover determine the branch result. This is not theorem acceptance.',
 'first_attempt_failure':'Oracle01 wrongly rejected empty stdin before capturing a method. Driver stopped the prover with -2; no result or theorem claim. Original logs/driver retained.',
 'manual_reference':'https://tamarin-prover.com/manual/master/book/011_advanced-features.html#using-an-oracle'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'open_sources':len(changed),'remaining_depth':10}))
