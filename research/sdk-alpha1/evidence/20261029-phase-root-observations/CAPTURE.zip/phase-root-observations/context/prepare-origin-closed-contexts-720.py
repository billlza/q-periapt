"""Check whether seven stale solve steps already have contradictory contexts."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path.cwd();parent=root/'target/p0-origin-phase-root-replay-720/origin-phase-root-replay-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='f3a51aa54d66d8de2923a43484fe72dd243991ff6687a0bc4ff564a60cf2adb8'
text=data.decode();name='epoch_generation_secret_derivation_origin_with_phase_roots'
a=text.index('lemma '+name+' ');end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start()
body=text[a:b]
pattern=r'(?ms)^(?P<indent> *)sorry /\* invalid proof step encountered \*/\n(?P=indent)solve\(.*?^(?P=indent)qed\n'
matches=list(re.finditer(pattern,body))
assert len(matches)==body.count('invalid proof step encountered')==7
assert sum(m[0].count('invalid proof step encountered') for m in matches)==7
saved=[{'ordinal':i,'sha256':hashlib.sha256(m[0].encode()).hexdigest(),'complete_old_subtree':m[0]} for i,m in enumerate(matches)]
for m in reversed(matches):body=body[:m.start()]+m['indent']+'by contradiction\n'+body[m.end():]
candidate=text[:a]+body+text[b:]
assert candidate[:a]==text[:a] and candidate[a+len(body):]==text[b:]
assert candidate[a:].split('"',2)[1]==text[a:].split('"',2)[1]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-closed-contexts-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate);shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
(stage/'RETAINED_INVALID_SUBTREES.json').write_text(json.dumps(saved,indent=2)+'\n')
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'seven_stale_steps_preserved_in_full':True,'all_34_formulas_and_other_proofs_unchanged':True,
 'hypothesis':'The new response constructor invariant may make the old Response5 solve unnecessary. Attempt contradiction at exactly those seven checked contexts; this must itself be replayed, never assumed.',
 'explicit_open_leaves_after_unverified_replacement':body.count('by sorry'),
 'mode':'replay only','no_search_or_oracle':True,'maximum_seconds':900,'heap_gib':12,'threads':1,
 'correction_719':'Both719 and720 copied-tree replays have seven invalid proof steps. A count of by-sorry leaves alone is not a valid current frontier and cannot establish that the helpers are ineffective.'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'changed_proof_steps':7,'unverified_remaining_leaves':body.count('by sorry')}))
