"""Add erasable observations of existing phase roots, without changing rules."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path.cwd();parent=root/'target/p0-origin-offer-response-full-replay-718/offer-response-full-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='8dfd3d7f906a562d642bdbe0d1510ba03df53d9310baafb43dab9c7e44a66069'
text=data.decode();prefix=text[:text.index('lemma ')]
assert 'ProducedPhaseRoot' not in text and 'InitialPhaseRoot' not in text
clean=re.sub(r'/\*.*?\*/',lambda m:' '*len(m[0]),prefix,flags=re.S)
def terms(value):
    stack=[];rows=[];start=0;quoted=False
    for i,c in enumerate(value):
        if c=="'":quoted=not quoted
        if quoted:continue
        if c in '(<[':stack.append(c)
        elif c in ')>]':
            assert stack and dict(zip(')>]','(<['))[c]==stack.pop()
        elif c==',' and not stack:
            rows.append(re.sub(r'\s+',' ',value[start:i]).strip());start=i+1
    assert not stack and not quoted
    rows.append(re.sub(r'\s+',' ',value[start:]).strip())
    return rows
layout={'Ready':(3,[1]),'Offer1':(3,[1]),'Offer2':(3,[1]),'Offer3':(5,[1]),
        'Response4':(6,[2]),'Response5':(6,[2,5]),'Response6':(6,[2,5]),
        'Final7':(8,[2,5]),'Final8':(7,[4]),'Receipt9':(9,[2,5])}
rules=list(re.finditer(r'(?m)^rule \(modulo E\) (\w+):',clean));insertions=[];inventory=[]
for index,match in enumerate(rules):
    finish=rules[index+1].start() if index+1<len(rules) else len(clean)
    body=clean[match.end():finish]
    arrow=re.search(r'\]->|-->',body);assert arrow
    rhs=body[arrow.end():];observations=[]
    for fact in re.finditer(r'PositionedPhaseState\(',rhs):
        start=fact.end();depth=1;stop=start
        while depth:
            if rhs[stop]=='(':depth+=1
            elif rhs[stop]==')':depth-=1
            stop+=1
        args=terms(rhs[start:stop-1]);assert len(args)==7 and args[5].startswith('<') and args[5].endswith('>')
        payload=terms(args[5][1:-1]);phase=args[4].strip("'")
        width,positions=layout[phase];assert len(payload)==width
        for position in positions:
            term=payload[position]
            event='ProducedPhaseRoot( '+', '.join([args[1],args[2],args[3],args[4],term])+' )'
            observations.append(event)
            inventory.append({'rule':match[1],'phase':phase,'role':args[2],'epoch':args[3],
                              'payload_index':position,'existing_root_term':term,'event':event})
    if observations:
        assert arrow[0]==']->' and '--[' in body
        if match[1]=='Setup':
            assert len(observations)==2 and all(item['existing_root_term']=='~old' for item in inventory if item['rule']=='Setup')
            observations.append('InitialPhaseRoot( ~sid, ~old )')
        insertion=',\n  /* phase-root-observation:'+match[1]+' */\n  '+',\n  '.join(observations)+'\n  '
        insertions.append((match.end()+arrow.start(),insertion))
assert len(inventory)==17 and len(insertions)==12
candidate=text
for position,insertion in reversed(insertions):candidate=candidate[:position]+insertion+candidate[position:]
projected=candidate
for _,insertion in insertions:
    assert projected.count(insertion)==1
    projected=projected.replace(insertion,'',1)
assert projected==text
declarations=list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:',text))
reuse=[m[1] for m in declarations if 'reuse' in {v.strip() for v in (m[2] or '').split(',')}]
assert len(declarations)==29 and len(reuse)==13
hide=',\n  '.join('hide_lemma='+name for name in reuse)
new='''
lemma phase_roots_are_initial_or_hashed [use_induction, __HIDE__]:
  all-traces
  "All s role %epoch phase root #produced.
    ProducedPhaseRoot(s, role, %epoch, phase, root) @ #produced ==>
    ((Ex #initial. InitialPhaseRoot(s, root) @ #initial) |
     (Ex material. root = h(material)))"
by sorry

lemma generation_and_initial_phase_roots_are_distinct [__HIDE__]:
  all-traces
  "All s %epoch key other #generated #initial.
    GenerationSecret(s, %epoch, key) @ #generated & InitialPhaseRoot(other, key) @ #initial ==> F"
by sorry

'''.replace('__HIDE__',hide)
end=list(re.finditer(r'(?m)^end$',candidate));assert len(end)==1
candidate=candidate[:end[0].start()]+new+candidate[end[0].start():]
processes=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
assert not any(line.strip().endswith('/tamarin-prover') for line in processes.splitlines())
stage=root/'target/p0-phase-root-observations-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),
 'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'root_observations':inventory,
 'instrumented_rules':12,'observed_phase_root_fields':17,'initial_root_observations':1,
 'erasing_exact_added_observations_recovers_parent_byte_for_byte':True,
 'all_original_29_formulas_and_proofs_unchanged':True,
 'no_premise_conclusion_fact_function_equation_or_restriction_change':True,
 'new_observations_are_action_facts_only':True,
 'initial_root_is_existing_fresh_old_not_a_fixed_constant':True,
 'new_lemmas_not_reuse_and_hide_every_existing_reuse':reuse,
 'rationale':'Observe the existing old/root fields of every phase producer. Independent induction may constrain those fields at the immediate Stored producer, rather than repeatedly expanding whole phase histories.',
 'limits':{'seconds':900,'heap_gib':12,'threads':1,'search_depth':16,'derivation_seconds':60}}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'observations':18,'erasure_exact':True}))
