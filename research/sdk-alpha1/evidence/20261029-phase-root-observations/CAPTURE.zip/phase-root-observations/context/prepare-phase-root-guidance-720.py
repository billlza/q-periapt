from pathlib import Path
import hashlib,json,re,shlex,shutil
root=Path.cwd();parent=root/'target/p0-phase-root-observations-720/phase-root-observations-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='c28d7bcd8692a27357c8889e351b6df880f1db4bc5afcd91277a873f6f7eefbb'
text=data.decode();a=text.index('lemma phase_roots_are_initial_or_hashed ');b=text.index('\nlemma ',a)
body=text[a:b];last_quote=body.index('"',body.index('"')+1)
candidate=text[:a]+body[:last_quote+1]+'\nby sorry\n'+text[b:]
assert 'generation_and_initial_phase_roots_are_distinct' in candidate
stage=root/'target/p0-phase-root-guided-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
driver=(root/'target/p0-wire-scope-replay-704/run.py').read_text()
old='"--heuristic=s",';assert driver.count(old)==1
driver=driver.replace(old,'"--heuristic=O", "--oracle-only", "--oraclename=" + str(stage / "initial-send-oracle.sh"),')
(stage/'run.py').write_text(driver)
(stage/'initial-send-oracle-frames').mkdir()
script='#!/bin/sh\nexec /usr/bin/env QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 /bin/sh '+shlex.quote(str(root/'artifact/python-run.sh'))+' '+shlex.quote(str(stage/'initial-send-oracle.py'))+' "$@"\n'
(stage/'initial-send-oracle.sh').write_text(script);(stage/'initial-send-oracle.sh').chmod(0o755)
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'formulas_observations_rules_unchanged':True,'initial_root_distinctness_verified_proof_retained':True,
 'reason':'Observed automatic search expands unrelated SendState/Application_Message chains before the phase premise. Prefer the exact produced-root action and its phase producer; retain full callback inputs and stop on unknown goal classes.',
 'previous_partial_steps':108,'previous_open_leaves':85,'maximum_callbacks':32,'maximum_depth':16,'maximum_seconds':900,'heap_gib':12,'threads':1}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256']}))
