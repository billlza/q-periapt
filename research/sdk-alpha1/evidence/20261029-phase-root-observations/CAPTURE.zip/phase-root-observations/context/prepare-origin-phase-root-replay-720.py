"""Replay the complete original origin proposition after independently proved invariants."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path.cwd();parent=root/'target/p0-phase-root-guided03-720/phase-root-guided03-proof.spthy'
data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='921304b3c0efa6a25f30989b0fcffcd105f785367f8152350bd19a3e6c2618dc'
receipt=json.loads(parent.with_name('phase-root-guided03-TERMINAL.json').read_text());assert receipt['accepted'] and receipt['returncode']==0
roots=['phase_roots_are_initial_or_hashed','generation_and_initial_phase_roots_are_distinct']
assert all(receipt['results'][name]['status']=='verified' for name in roots)
text=data.decode()
def block(value,name):
 start=value.index('lemma '+name+' ');stop=re.search(r'(?m)^lemma |^/\* All wellformedness|^end$',value[start+6:])
 return value[start:start+6+stop.start()]
old_name='epoch_generation_secret_derivation_origin';new_name=old_name+'_with_phase_roots'
original=block(text,old_name);assert original.count('by sorry')==42
candidate=text
for name in roots:
 token='lemma '+name+' [';assert candidate.count(token)==1
 extra='reuse, '+('hide_lemma='+roots[0]+', ' if name==roots[1] else '')
 candidate=candidate.replace(token,token+extra,1)
wire=root/'target/p0-wire-payload-shapes-719/wire-payload-shapes-proof.spthy'
wire_data=wire.read_bytes();assert hashlib.sha256(wire_data).hexdigest()=='d3f8e9e18528ea873a22798bf824c3df593dced8714354ba18ce8bd978ad4cbc'
names=['signed_offer_payload_has_key_constructor','signed_response_payload_has_public_constructors'];additions=[]
for name in names:
 value=block(wire_data.decode(),name);token='lemma '+name+' ['
 extra='reuse, '+', '.join('hide_lemma='+r for r in roots)+', '
 if name==names[1]:extra+='hide_lemma='+names[0]+', '
 value=value.replace(token,token+extra,1);additions.append(value)
additions.append(original.replace('lemma '+old_name+' ','lemma '+new_name+' ',1))
end=list(re.finditer(r'(?m)^end$',candidate));assert len(end)==1
added='\n'+'\n'.join(additions)+'\n'
candidate=candidate[:end[0].start()]+added+candidate[end[0].start():]
assert candidate[:candidate.index('lemma ')]==text[:text.index('lemma ')]
assert len(re.findall(r'(?m)^lemma ',candidate))==34
assert block(candidate,new_name).split('"',2)[1]==original.split('"',2)[1]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-phase-root-replay-720';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate);shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'proved_root_properties':{n:receipt['results'][n] for n in roots},'wire_shape_proofs_imported':names,
 'all_new_helpers_hide_previous_new_helpers_for_independence':True,'helper_proofs_replayed_before_origin_acceptance':True,
 'original_origin_formula_and_382_step_complete_tree_preserved_except_name':True,
 'original_open_leaves':42,'same_operational_model_and_observation_actions':True,
 'mode':'replay without search or oracle','maximum_seconds':900,'heap_gib':12,'threads':1,
 'original_attack_and_leak_model_preserved_by_observation_erasure':True}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'queries':34}))
