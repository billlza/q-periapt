"""Prefer observed root and phase provenance; never alter the proposition."""
from pathlib import Path
import hashlib,json,re,sys
stage=Path(__file__).resolve().parent;folder=stage/'initial-send-oracle-frames'
try:
    if sys.argv[1:]!=['phase_roots_are_initial_or_hashed']:raise ValueError('unexpected lemma')
    raw=sys.stdin.read(4*1024*1024+1);data=raw.encode()
    if not data or len(data)>4*1024*1024:raise ValueError('oracle input bound')
    matches=[re.fullmatch(r'([0-9]+):\s*(.+)',line) for line in raw.splitlines()]
    if not all(matches):raise ValueError('unexpected goal encoding')
    numbers=[int(m[1]) for m in matches]
    if len(set(numbers))!=len(numbers):raise ValueError('duplicate goal identifiers')
    previous=sorted(folder.glob('*.json'))
    if len(previous)>=32 or sum(json.loads(p.read_text())['input_bytes'] for p in previous)+len(data)>16*1024*1024:
        raise ValueError('oracle callback/input budget exceeded')
    groups=[('produced-root',lambda s:'ProducedPhaseRoot(' in s and '▶' not in s),
            ('phase-premise',lambda s:'PositionedPhaseState(' in s and '▶' in s),
            ('induction-order',lambda s:'last(' in s),
            ('initial-root',lambda s:s.startswith('InitialPhaseRoot('))]
    selected=[];kind='unsupported-goal-class'
    for label,predicate in groups:
        selected=[int(m[1]) for m in matches if predicate(m[2])]
        if selected:kind=label;break
    ranking=selected[:1]
    stem=f'{len(previous):04}'
    (folder/(stem+'.txt')).write_bytes(data)
    (folder/(stem+'.json')).write_text(json.dumps({'input_sha256':hashlib.sha256(data).hexdigest(),
        'input_bytes':len(data),'goal_numbers':numbers,'ranking':ranking,'class':kind},indent=2)+'\n')
    if not ranking:(stage/'initial-send-oracle.diagnostic-stop').write_text(kind+'\n')
    for number in ranking:print(number)
except Exception as error:
    (stage/'initial-send-oracle.failed').write_text(type(error).__name__+': '+str(error)+'\n')
    raise
