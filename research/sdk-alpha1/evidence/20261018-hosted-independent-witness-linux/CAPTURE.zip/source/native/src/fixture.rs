// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Fresh public enrollment for the independent counterpart.
use q_periapt_continuity_identity_candidate::{
    bootstrap_suite_digest, AccountPin, AllowedPrekeyModes, AnchorRequirement,
    ApplicationSendBudget, BootstrapContext, ClassicalChoice, DeviceDescription, DeviceSigningKey,
    DirectoryExpectation, LeafKind, ManifestContext, PolicyPin, PolicySigningKey, PqChoice,
    PrekeyLeaf, PrekeyQuality, PublicKey, RootSigningKey, SessionPolicyParameters, Validity,
    VerifiedDevice,
};
use q_periapt_core::ZeroizingBytes;
use q_periapt_sdk::{Limits, Runtime};
use q_periapt_sig::Signer;
use std::{fs, io::Write, path::Path, sync::Arc};
use zeroize::Zeroize;

use crate::{Result, NOW};

pub(super) struct Fixture {
    pub context: Arc<BootstrapContext>,
    pub signer: DeviceSigningKey,
    pub prekey: q_periapt_sdk::HybridKey,
    pub responder: Arc<VerifiedDevice>,
    pub witness: Option<Arc<crate::witness::Witness>>,
}

fn save(directory: &Path, name: &str, bytes: &[u8]) -> Result<()> {
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(directory.join(name))?;
    file.write_all(bytes)?;
    Ok(())
}

fn runtime(directory: &Path) -> Result<Arc<Runtime>> {
    let document = b"schema_version=1\npolicy_version=1\nmin_nist_level=3\ndefault_profile=\"ContextBound\"\nallowed_kems=[\"ML-KEM-768\",\"X25519\"]\nallowed_sigs=[\"ML-DSA-65\"]\ndeprecated=[]\n";
    let mut seed = ZeroizingBytes::<32>::zeroed();
    getrandom::fill(seed.as_mut_bytes())?;
    let (mut secret, public) = q_periapt_backends::MlDsa65::generate(*seed.as_bytes());
    let mut signature = vec![0; q_periapt_backends::ML_DSA_65_SIG_LEN];
    getrandom::fill(seed.as_mut_bytes())?;
    let result = q_periapt_backends::MlDsa65.sign(
        &secret,
        &q_periapt_policy::policy_signature_message(document),
        seed.as_bytes(),
        &mut signature,
    );
    secret.zeroize();
    result.map_err(|error| format!("SDK policy sign: {error:?}"))?;
    let runtime = Arc::new(Runtime::from_signed_policy(
        document,
        &signature,
        &public,
        None,
        Limits::default(),
    )?);
    save(directory, "sdk-document", document)?;
    save(directory, "sdk-signature", &signature)?;
    save(directory, "pin-sdk-root", &public)?;
    save(
        directory,
        "pin-sdk-state",
        &runtime.trusted_state().encode(),
    )?;
    Ok(runtime)
}

pub(super) fn create(
    directory: &Path,
    peer_key: PublicKey,
    budget: u16,
    witness: Option<Arc<crate::witness::Witness>>,
) -> Result<Fixture> {
    let runtime = runtime(directory)?;
    let authority = PolicySigningKey::generate()?;
    let validity = Validity::new(100, 200)?;
    let family = authority.policy_family()?;
    let policy = authority.issue_session_policy(
        &runtime,
        SessionPolicyParameters::new(
            1,
            validity,
            AllowedPrekeyModes::new(&[PrekeyQuality::ReusableBoth])?,
            witness
                .as_ref()
                .map_or_else(AnchorRequirement::local_only, |w| {
                    AnchorRequirement::required(&w.pin)
                }),
            ApplicationSendBudget::new(budget)?,
        )?,
    )?;
    save(
        directory,
        "pin-policy-root",
        &authority.public_key()?.encode(),
    )?;
    let mut checkpoint = policy.checkpoint().version().to_be_bytes().to_vec();
    checkpoint.extend_from_slice(&policy.checkpoint().digest());
    save(directory, "pin-policy-head", &checkpoint)?;
    save(directory, "policy", policy.as_bytes())?;
    save(directory, "pin-directory", &[99; 32])?;
    let policy_pin = PolicyPin::new(family, authority.public_key()?, policy.checkpoint())?;
    let verified_policy =
        Arc::new(policy_pin.verify(policy.as_bytes(), Arc::clone(&runtime), NOW)?);
    let signer = match &witness {
        Some(w) => w.provision_device()?,
        None => DeviceSigningKey::generate()?,
    };
    let mut devices = Vec::new();
    for (role, id, public) in [("i", 1, peer_key), ("r", 2, signer.public_key()?)] {
        let root = RootSigningKey::generate()?;
        let certificate = root.issue_device(
            DeviceDescription::new([id; 16], 1, family, validity)?,
            public,
        )?;
        let roster = root.issue_roster(1, validity, &[root.roster_entry(&certificate)?])?;
        let pin = AccountPin::new(
            root.account_id()?,
            root.public_key()?,
            roster.checkpoint(),
            family,
        )?;
        devices.push(Arc::new(pin.verify_device(
            &certificate,
            roster.as_bytes(),
            NOW,
        )?));
        let mut expectation = root.account_id()?.to_vec();
        expectation.extend_from_slice(&roster.checkpoint().version().to_be_bytes());
        expectation.extend_from_slice(&roster.checkpoint().digest());
        expectation.extend_from_slice(&[id; 16]);
        expectation.extend_from_slice(&1u64.to_be_bytes());
        save(
            directory,
            &format!("pin-{role}-root"),
            &root.public_key()?.encode(),
        )?;
        save(directory, &format!("pin-{role}-head"), &expectation)?;
        save(directory, &format!("{role}-credential"), &certificate)?;
        save(directory, &format!("{role}-roster"), roster.as_bytes())?;
    }
    let initiator = devices.first().ok_or("missing initiator")?;
    let responder = devices.get(1).ok_or("missing responder")?;
    let key = runtime.generate_key()?;
    let public = key.public_key()?.to_bytes();
    let (pq, classical) = public.split_at(q_periapt_backends::ML_KEM_768_PK_LEN);
    let advertisement = Validity::new(100, 160)?;
    let manifest = signer.issue_manifest(
        responder,
        ManifestContext::new(
            1,
            runtime.trusted_state().digest(),
            bootstrap_suite_digest(),
            [99; 32],
            advertisement,
        )?,
        &[
            PrekeyLeaf::new(LeafKind::SignedClassical, classical, advertisement)?,
            PrekeyLeaf::new(LeafKind::LastResortPq, pq, advertisement)?,
        ],
    )?;
    let verified = responder.verify_manifest(manifest.as_bytes(), NOW)?;
    let mut proofs = std::collections::BTreeMap::new();
    for index in 0..2 {
        let proof = manifest.proof(index)?;
        let kind = verified.verify_leaf(&proof, NOW)?.kind() as u8;
        save(directory, &format!("proof-{kind}"), &proof.encode()?)?;
        proofs.insert(kind, proof);
    }
    save(directory, "manifest", manifest.as_bytes())?;
    let selection = Arc::new(verified.select_prekeys(
        proofs.get(&1).ok_or("missing classical proof")?,
        proofs.get(&3).ok_or("missing PQ proof")?,
        ClassicalChoice::SignedOnly,
        PqChoice::LastResort,
        NOW,
    )?);
    save(directory, "expected-selection", selection.as_bytes())?;
    let context = Arc::new(BootstrapContext::new(
        verified_policy,
        Arc::clone(initiator),
        Arc::clone(responder),
        selection,
        DirectoryExpectation::from_trusted_state([99; 32])?,
        NOW,
    )?);
    save(directory, "expected-context", &context.digest())?;
    Ok(Fixture {
        context,
        signer,
        prekey: key,
        responder: Arc::clone(responder),
        witness,
    })
}
