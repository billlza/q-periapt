import {QPeriaptContinuityPrekeyStatus as Status,QPeriaptContinuityPrekeyKind as Kind,
 QPeriaptContinuityPublicationPlan as Plan,QPeriaptContinuityPublicationPhase as Phase}
 from '/node_modules/q-periapt-sdk-wasm/web/index.js';
const require=(ok,message)=>{if(!ok)throw Error(message)};
export async function inventory(owner,policy,runtime,config,data){
 const id=new Uint8Array(data.keyId??new Array(32).fill(66));
 const from=BigInt(config.from),until=BigInt(config.until),now=()=>BigInt(Math.floor(Date.now()/1000));
 const query=async key=>await owner.prekey_status(policy,key);
 const failure=async operation=>{
  const result=await Promise.allSettled([operation()]);require(result[0].status==='rejected','operation unexpectedly succeeded');
  const error=result[0].reason;require(error.ownerClosed===true&&owner.is_closed()&&error.cause!==undefined,'failed operation did not close owner');
  return {code:error.code,ownerClosed:error.ownerClosed};
 };
 if(data.inventoryAction==='query')return {status:await query(id)};
 if(data.inventoryAction==='generate')return {public:[...await owner.generate_prekey(policy,id,data.kind??Kind.OneTimePq,from,until,now())],status:await query(id)};
 if(data.inventoryAction==='retire'){
  const state=await owner.retire_prekey(policy,id);const after=await query(id);const repeated=await owner.retire_prekey(policy,id);
  require(state===Status.Retired&&after===state&&repeated===state&&!owner.is_closed(),'retirement/idempotency');return {status:state,after,repeated};
 }
 if(data.inventoryAction==='missing-retirement')return failure(()=>owner.retire_prekey(policy,id));
 if(data.inventoryAction==='regenerate')return failure(()=>owner.generate_prekey(policy,id,data.kind??Kind.OneTimePq,from,until,now()));
 if(data.inventoryAction==='publication-status'){
  const status=await owner.publication_status(new Uint8Array(data.publicationId));const result={phase:status.phase(),intent:status.intent_digest()};status.free();return result;
 }
 if(data.inventoryAction==='closed-runtime'){
  await owner.generate_prekey(policy,id,Kind.OneTimePq,from,until,now());
  require(await query(id)===Status.Available,'prekey not available');runtime.close();
  require(await query(id)===Status.Available,'historical inventory unavailable after runtime close');
  require(await owner.retire_prekey(policy,id)===Status.Retired,'retirement needed fresh runtime authority');
  require(await query(id)===Status.Retired&&await owner.retire_prekey(policy,id)===Status.Retired,'retirement state lost');
  const denied=await failure(()=>owner.generate_prekey(policy,new Uint8Array(32).fill(67),Kind.OneTimePq,from,until,now()));
  require(denied.code==='Closed','maintenance restored fresh authority');return {status:Status.Retired,denied};
 }
 if(data.inventoryAction==='publication'){
  const directory=new Uint8Array(32).fill(77),plan=new Plan(directory,from,until);let prepared,reuse;
  try{
   plan.generate(Kind.SignedClassical,from,until);plan.generate(Kind.OneTimeClassical,from,until);plan.generate(Kind.LastResortPq,from,until);plan.reuse(new Uint8Array(32).fill(55),Kind.OneTimePq,from,until);
   const publicationId=await owner.next_publication_id();prepared=await owner.prepare_publication(publicationId,plan,policy,10000,now);
   const members=prepared.inventory_requests(),before=[];for(const key of members)before.push(await query(key));
   require(before.every(s=>s===Status.Available),'publication inventory state');
   const retired=await owner.retire_publication(publicationId,prepared.artifact_digest());require(retired.phase()===Phase.Retired,'history retirement');retired.free();
   const after=[];for(const key of members)after.push(await query(key));require(after.toString()===before.toString(),'history retirement revoked inventory');
   require(await owner.retire_prekey(policy,members[0])===Status.Retired,'member retirement');
   const remaining=[];for(const key of members)remaining.push(await query(key));require(remaining[0]===Status.Retired&&remaining.slice(1).every(s=>s===Status.Available),'member retirement changed siblings');
   const next=await owner.next_publication_id();reuse=new Plan(directory,from,until);
   reuse.reuse(members[0],Kind.SignedClassical,from,until);reuse.generate(Kind.OneTimeClassical,from,until);reuse.generate(Kind.LastResortPq,from,until);reuse.reuse(members[3],Kind.OneTimePq,from,until);
   const denied=await failure(()=>owner.prepare_publication(next,reuse,policy,10000,now));require(denied.code==='KeyRetired','retired member reused');
   return {members:members.map(key=>[...key]),before,after,remaining,publicationId:[...publicationId],next:[...next],denied,bytes:[...prepared.bytes()]};
  }finally{reuse?.free();prepared?.free();plan.free()}
 }
 throw Error('unknown inventory action');
}
