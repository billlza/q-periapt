from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(Path.cwd()/'target/continuity-browser-recovery'))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-inventory';package=root/'target/continuity-browser-publication/source/target/inventory-package-01';web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True)
(web/'creation').mkdir(exist_ok=True)
shutil.copyfile(stage/'inventory-worker.js',web/'creation/worker.js')
shutil.copyfile(stage/'inventory-checks.js',web/'creation/inventory-checks.js')
shutil.copyfile(root/'target/continuity-browser-recovery/controller.js',web/'creation/controller.js')
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Publication qualification</title><script type="module" src="./controller.js"></script>')
session='qpc-witness-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
source=json.loads((package/'sources-before.json').read_text())
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed npm web entry, shared owned device and required signed witness protocol; not HTTPS deployment qualification','source':source,'static_web':static,'native_binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'cases':[],'observations':[]}
sequence=0

def browser(args,label):
 with contextlib.chdir(out):
  result=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(result.stdout);(logs/(label+'.stderr')).write_bytes(result.stderr)
 sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':result.returncode})
 sdk.require(result.returncode==0 and not result.stderr,label+' CLI failure')
 return result.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}'
 script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode()
 sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution failed: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='witness')
 sdk.require(value['diagnostics']==[],'browser diagnostics')
 result=value['result'];state['observations'].append({'case':args['case'],'phase':args.get('phase',args['operation']),'result':result.get('observations',[])})
 return result

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def native(args,label):
 sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

verifier=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-publication-verifier'
state['native_verifier_sha256']=sdk.snapshot(verifier,maximum=256*1024*1024).sha256
try:
 with serving(web,out,private,binary) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];addEventListener("error",event=>diagnostics.push(event.message));addEventListener("unhandledrejection",event=>diagnostics.push(String(event.reason)));}); return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700)
    native(['prepare',directory],case+'-authorities');config=inputs/(key+'.json');shutil.copyfile(directory/'PUBLIC.json',config)
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:10],'id':uuid.uuid4().hex+uuid.uuid4().hex,'operation':'activation'}
    success({**args,'operation':'create'})
    grant=inputs/(key+'-grant.json');native(['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    success({**args,'phase':'accept'});success({**args,'phase':'prepare'});native(['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    args.update(phase='activate');row={'case':case};state['cases'].append(row)
    sdk.require(success({**args,'inventoryAction':'query'})=={'status':0},'initial inventory was not absent')
    if case=='ordinary':
     first=success({**args,'inventoryAction':'generate'});second=success({**args,'inventoryAction':'generate'})
     sdk.require(first==second and first['status']==2 and len(first['public'])==1184,'original key did not survive reopen');row.update(first=first,reopened=second)
     row['retired']=success({**args,'inventoryAction':'retire'});sdk.require(row['retired']=={'status':5,'after':5,'repeated':5},'retirement result')
    elif case=='closed-runtime':
     row['maintenance']=success({**args,'inventoryAction':'closed-runtime'});sdk.require(row['maintenance']['status']==5 and row['maintenance']['denied']=={'code':'Closed','ownerClosed':True},'closed runtime maintenance/fresh authority')
    elif case=='absent':
     rejected=success({**args,'inventoryAction':'missing-retirement'});sdk.require(rejected=={'code':'Absent','ownerClosed':True},'missing inventory retirement differs');row['absent_retirement']=rejected
     sdk.require(success({**args,'inventoryAction':'query'})=={'status':0},'absent retirement fabricated a record')
    elif case=='publication':
     result=success({**args,'inventoryAction':'publication'});row['publication']=result
     path=out/'publication.bin';path.write_bytes(bytes(result['bytes']))
     raw=sdk.command([str(verifier),str(config),str(grant),str(path)],logs/'publication-native',root,environment=dict(os.environ));verified=parse_strict_json_bytes(raw,label='native publication verification')
     sdk.require(verified['manifest_signature_verified'] and verified['all_leaf_proofs_verified'] and verified['policy_and_context_verified'],'signed public artifact verification');row['native_verification']=verified
     sdk.require(success({**args,'inventoryAction':'publication-status','publicationId':result['next']})=={'phase':0},'retired-key reuse reserved a new publication')
     for index,member in enumerate(result['members']):
      sdk.require(success({**args,'inventoryAction':'query','keyId':member})=={'status':5 if index==0 else 2},'reopened inventory differs')
     retired_again=success({**args,'inventoryAction':'retire','keyId':result['members'][0]});sdk.require(retired_again['status']==5,'repeat retirement lost tombstone')
    else:raise ValueError('unknown case')
    if case in ['ordinary','closed-runtime']:
     sdk.require(success({**args,'inventoryAction':'query'})=={'status':5},'retirement lost after reopen')
     denied=success({**args,'inventoryAction':'regenerate'});sdk.require(denied=={'code':'KeyRetired','ownerClosed':True},'retired key regenerated');row['regeneration_denied']=denied
    row['witness_records']=records[key];sdk.require(not failures,'server failures: '+json.dumps(failures))
    print(json.dumps({'case':case,'passed':True,'requests':len(records[key])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'server failures')
 for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web input changed')
 sdk.require(sdk.snapshot(binary,maximum=256*1024*1024).sha256==state['native_binary_sha256'],'authority changed')
 sdk.require(sdk.snapshot(verifier,maximum=256*1024*1024).sha256==state['native_verifier_sha256'],'verifier changed')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
