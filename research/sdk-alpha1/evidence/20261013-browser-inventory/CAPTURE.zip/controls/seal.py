from pathlib import Path
import hashlib,json,re,stat,zipfile

root=Path.cwd();stage=root/'target/continuity-browser-inventory'
output=root/'research/sdk-alpha1/evidence/20261013-browser-inventory'
package=root/'target/continuity-browser-publication/source/target/inventory-package-01'
consumer=Path(json.loads((package/'consumer-location.json').read_text())['path'])
source=json.loads((stage/'PACKAGE_SOURCE.json').read_text())
run=json.loads((stage/'inventory-01/RESULT.json').read_text())
base=json.loads((stage/'base-browser-01/RESULT.json').read_text())
assert run['completed'] and len(run['cases'])==4
assert {row['case'] for row in run['cases']}=={'ordinary','closed-runtime','publication','absent'}
assert base['completed'] and len(base['report']['cases'])==10
unit_log=(stage/'full-unit.log').read_text()
unit_results=list(re.finditer(r'^Ran (\d+) tests in ([\d.]+)s\n\nOK(?: \(skipped=(\d+)\))?$',unit_log,re.MULTILINE))
assert len(unit_results)==1
unit_result=unit_results[0]
assert json.loads((stage/'full-unit-process.json').read_text())['returncode']==0
unit_skips=[line for line in unit_log.splitlines() if ' ... skipped ' in line]
assert len(unit_skips)==int(unit_result.group(3) or 0)
for name,digest in source['overlay'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
contents={}
def add(path,name):
    assert path.is_file() and not path.is_symlink() and stat.S_ISREG(path.stat().st_mode),str(path)
    assert path.stat().st_size<32*1024**2 and name not in contents and '..' not in Path(name).parts,name
    contents[name]=path.read_bytes()
for run_name in ('inventory-01','base-browser-01'):
    for path in sorted((stage/run_name).rglob('*')):
        if path.is_file() and not any(part.startswith('.') for part in path.relative_to(stage/run_name).parts):
            add(path,'runs/'+run_name+'/'+path.relative_to(stage/run_name).as_posix())
for name in ('PACKAGE_SOURCE.json','build-package.sh','run-inventory.py','inventory-worker.js',
             'inventory-checks.js','base-browser.py','seal.py','clippy.log','clippy-02.log',
             'engine-clippy.log','format.log','unit.log','full-unit.log','full-unit-process.json','package.stdout','package.stderr',
             'inventory-01.stdout','inventory-01.stderr','base-browser-01.stdout','base-browser-01.stderr'):
    add(stage/name,'controls/'+name)
for name in source['overlay']:add(root/name,'source-overlay/'+name)
for name in ('server.py','controller.js','lifecycle-worker.js'):
    add(root/'target/continuity-browser-recovery'/name,'shared-fixtures/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs',
    'shared-fixtures/browser_activation_authority.rs')
for name in ('Cargo.toml','Cargo.lock','src/main.rs'):
    add(root/'target/continuity-browser-publication/native-verifier'/name,'native-verifier/'+name)
for path in sorted(package.iterdir()):
    if path.is_file() and path.suffix in {'.json','.stdout','.stderr','.tgz'}:add(path,'package/'+path.name)
for path in sorted((consumer/'inputs').glob('inventory-01-*.json')):
    value=json.loads(path.read_text())
    allowed={'certificate','roster','version','digest','identity'} if path.name.endswith('-grant.json') else {'root','account','description','family','from','until','sdk_policy','sdk_signature','sdk_root','sdk_state','policy_root','policies','witness_id','witness_public','witness_signer_id'}
    assert set(value)==allowed,(path,set(value)-allowed)
    add(path,'public-inputs/'+path.name)
manifest=consumer/'node_modules/q-periapt-sdk-wasm/PACKAGE_CONTENTS.json'
add(manifest,'package/PACKAGE_CONTENTS.json')
output.mkdir()
with zipfile.ZipFile(output/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(contents.items()):
        info=zipfile.ZipInfo(name,(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,data)
with zipfile.ZipFile(output/'CAPTURE.zip') as archive:assert archive.testzip() is None
checks={'completed':True,'release_claim_eligible':False,'base_commit':source['base_commit'],
    'source_overlay':source['overlay'],'inventory_cases':4,'base_browser_cases':10,
    'artifact_unit_tests':int(unit_result.group(1)),'artifact_unit_seconds':float(unit_result.group(2)),
    'platform_conditioned_skips':unit_skips,
    'witness_requests':sum(len(row['witness_records']) for row in run['cases']),
    'archive_sha256':hashlib.sha256((package/'q-periapt-sdk-wasm-0.2.0.tgz').read_bytes()).hexdigest(),
    'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'capture':{'sha256':hashlib.sha256((output/'CAPTURE.zip').read_bytes()).hexdigest(),
               'members':len(contents),'expanded_bytes':sum(map(len,contents.values()))},
    'limitations':['Local Chrome and Node installed-package checks, not minimum-browser/compiler or deployed HTTPS coverage.',
        'Native verification is a separate process using the same Rust engine, not an independent implementation.',
        'Consumed/Abandoned/Reserved mappings are exhaustive; this browser run exercised Absent/Available/Retired only.',
        'Logical retirement is not physical erasure, backup erasure or remote advertisement removal.',
        'Hosted CI, CodeQL, full installed native qualification and the complete 0.2.0 release remain separate.']}
(output/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'output':str(output),'capture':checks['capture'],'archive_sha256':checks['archive_sha256']}))
