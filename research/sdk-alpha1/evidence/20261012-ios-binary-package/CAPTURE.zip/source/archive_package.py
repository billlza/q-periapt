from pathlib import Path
import json,hashlib,zipfile,plistlib

def finish(out:Path):
 package=out/'package/QPeriaptContinuity';files={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
 (package/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n');archive=out/'QPeriaptContinuity-ios-candidate.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(package.rglob('*')):
   if f.is_file():
    entry=zipfile.ZipInfo(str(Path(package.name)/f.relative_to(package)),date_time=(1980,1,1,0,0,0))
    entry.create_system=3;entry.external_attr=0o100644<<16;entry.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(entry,f.read_bytes(),compresslevel=9)
 installed=out/'installed';installed.mkdir()
 with zipfile.ZipFile(archive) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(files)+1;z.extractall(installed)
 for n,h in files.items():assert hashlib.sha256((installed/package.name/n).read_bytes()).hexdigest()==h
 device=out/'native/libq_periapt_continuity_c_consumer.a';sim=out/'sim-build/aarch64-apple-ios-sim/release/libq_periapt_continuity_c_consumer.a'
 info=plistlib.loads((installed/package.name/'CQPCOwner.xcframework/Info.plist').read_bytes());assert len(info['AvailableLibraries'])==2
 for x in info['AvailableLibraries']:
  actual=installed/package.name/'CQPCOwner.xcframework'/x['LibraryIdentifier']/x['LibraryPath'];assert actual.read_bytes()==(sim if x.get('SupportedPlatformVariant')=='simulator' else device).read_bytes()
 licenses=json.loads((package/'THIRD_PARTY.json').read_text())
 receipt={'completed':True,'native_exports':152,'swift_source_files':len(list((package/'Sources/QPeriaptContinuity').glob('*.swift'))),'device_native_sha256':hashlib.sha256(device.read_bytes()).hexdigest(),'simulator_native_sha256':hashlib.sha256(sim.read_bytes()).hexdigest(),'third_party_packages':len(licenses),'members':len(files)+1,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'device_and_simulator_arm64_only':True,'installed_archive_hashes_verified':True,'runtime_qualified':False,'release_claim_eligible':False};(out/'PACKAGE_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':finish(Path(__file__).resolve().parent)
