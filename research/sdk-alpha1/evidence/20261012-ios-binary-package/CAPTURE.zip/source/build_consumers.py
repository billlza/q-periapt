from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent;consumer=out/'consumer';installed=out/'installed/QPeriaptContinuity';manifest=json.loads((installed/'MANIFEST.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((installed/n).read_bytes()).hexdigest()==h
state={'completed':False,'live_producer':True,'source_inputs':{str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [consumer/'project.json',consumer/'Info.plist',*(consumer/'Sources').rglob('*')] if p.is_file()}}
(out/'CONSUMER_STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 with (out/'consumer-project.log').open('wb') as log:subprocess.run(['xcodegen','generate','--spec','project.json'],cwd=consumer,stdout=log,stderr=subprocess.STDOUT,check=True)
 for name,sdk,destination in [('device','iphoneos','generic/platform=iOS'),('simulator','iphonesimulator','generic/platform=iOS Simulator')]:
  args=['xcodebuild','-project',str(consumer/'ContinuityIOS.xcodeproj'),'-scheme','ContinuityIOSRunner','-configuration','Release','-sdk',sdk,'-destination',destination,'-derivedDataPath',str(out/('build-'+name))]
  if name=='simulator':args+=['CODE_SIGNING_ALLOWED=NO','ARCHS=arm64']
  with (out/('consumer-'+name+'.log')).open('wb') as log:result=subprocess.run(args+['build'],stdout=log,stderr=subprocess.STDOUT)
  lines=(out/('consumer-'+name+'.log')).read_text().splitlines()
  diagnostics=[line for line in lines if 'warning:' in line or 'error:' in line]
  for line in diagnostics[:12]:print(line)
  if len(diagnostics)>12:print(f'{len(diagnostics)} diagnostics retained in consumer-{name}.log')
  result.check_returncode();assert '** BUILD SUCCEEDED **' in lines and not any('warning:' in line for line in lines)
  print('Installed archive '+name+' consumer built without custom SDK header/library paths',flush=True)
 for n,h in manifest.items():assert hashlib.sha256((installed/n).read_bytes()).hexdigest()==h
 for n,h in state['source_inputs'].items():assert hashlib.sha256((consumer/n).read_bytes()).hexdigest()==h
 state['completed']=True
finally:
 state['live_producer']=False;(out/'CONSUMER_STATE.json').write_text(json.dumps(state,indent=2)+'\n')
