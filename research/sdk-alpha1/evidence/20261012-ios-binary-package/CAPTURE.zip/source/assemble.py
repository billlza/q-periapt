from pathlib import Path
import json,hashlib,shutil,re,plistlib,subprocess,zipfile,tempfile
import rust_sdk_profile as sdk
from continuity_c_consumer import EXPORTS
r=Path.cwd();out=Path(__file__).resolve().parent;s=json.loads((out/'STATE.json').read_text());assert s['completed'] and not s['live_producer']
assert all(hashlib.sha256((out/'c-consumer'/n).read_bytes()).hexdigest()==h for n,h in s['source_sha256'].items())
device=out/'native/libq_periapt_continuity_c_consumer.a';sim=out/'sim-build/aarch64-apple-ios-sim/release/libq_periapt_continuity_c_consumer.a'
assert hashlib.sha256(device.read_bytes()).hexdigest()=='d80ed3f238630cce9fb0cae7f749a62b5943e0b40e970826ae720a8f6cb14c0b'
package=out/'package/QPeriaptContinuity';package.mkdir(parents=True)
headers=out/'headers';headers.mkdir();shutil.copy2(out/'c-consumer/qpc_owner.h',headers/'qpc_owner.h')
assert (headers/'qpc_owner.h').read_bytes()==(r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes()
(headers/'module.modulemap').write_text('module CQPCOwner [system] {\n    header "qpc_owner.h"\n    export *\n}\n')
for kind,lib in [('device',device),('simulator',sim)]:
 sdk.command(['xcrun','lipo','-archs',str(lib)],out/(kind+'-architectures'),r)
 assert (out/(kind+'-architectures.stdout')).read_text().strip()=='arm64'
 sdk.command([str(Path(s['environment']['RUSTC']).parent.parent/'lib/rustlib/aarch64-apple-darwin/bin/llvm-nm'),'--defined-only','--extern-only',str(lib)],out/(kind+'-exports'),r)
 found=set(re.findall(r'\b_((?:qpc_)[A-Za-z0-9_]+)$',(out/(kind+'-exports.stdout')).read_text(),re.M));assert found==EXPORTS,(kind,found^EXPORTS)
sdk.command(['xcodebuild','-create-xcframework','-library',str(device),'-headers',str(headers),'-library',str(sim),'-headers',str(headers),'-output',str(package/'CQPCOwner.xcframework')],out/'create-xcframework',r)
info=plistlib.loads((package/'CQPCOwner.xcframework/Info.plist').read_bytes());libs=info['AvailableLibraries'];assert len(libs)==2
assert {(tuple(x['SupportedArchitectures']),x['SupportedPlatform'],x.get('SupportedPlatformVariant')) for x in libs}=={(('arm64',),'ios',None),(('arm64',),'ios','simulator')}
for x in libs:
 lib=package/'CQPCOwner.xcframework'/x['LibraryIdentifier']/x['LibraryPath'];expected=sim if x.get('SupportedPlatformVariant')=='simulator' else device
 assert lib.read_bytes()==expected.read_bytes()
shutil.copytree(r/'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity',package/'Sources/QPeriaptContinuity')
(package/'Package.swift').write_text('''// swift-tools-version:6.0
// SPDX-License-Identifier: Apache-2.0 OR MIT
import PackageDescription
let package = Package(
    name: "QPeriaptContinuity",
    platforms: [.iOS(.v16)],
    products: [.library(name: "QPeriaptContinuity", targets: ["QPeriaptContinuity"])],
    targets: [
        .binaryTarget(name: "CQPCOwner", path: "CQPCOwner.xcframework"),
        .target(name: "QPeriaptContinuity", dependencies: ["CQPCOwner"],
                linkerSettings: [.linkedFramework("Security")]),
    ]
)
''')
for n in ['LICENSE','LICENSE-APACHE','LICENSE-MIT']:
 source=r/'crates/q-periapt-sdk'/n;shutil.copy2(source,package/n)
# Preserve license texts from the resolved runtime dependency closure. Do not
# substitute package-name assertions for actual third-party license files.
tool=Path(s['environment']['RUSTC']).parent
sdk.command([str(tool/'cargo'),'metadata','--offline','--locked','--format-version=1','--filter-platform','aarch64-apple-ios-sim'],out/'metadata',out/'c-consumer',environment=s['environment'])
metadata=json.loads((out/'metadata.stdout').read_text());packages={x['id']:x for x in metadata['packages']};nodes={x['id']:x for x in metadata['resolve']['nodes']};todo=[metadata['resolve']['root']];seen=set();licenses=[]
while todo:
 identifier=todo.pop()
 if identifier in seen:continue
 seen.add(identifier);node=nodes[identifier];todo.extend(d['pkg'] for d in node['deps'] if any(k['kind'] is None for k in d['dep_kinds']))
for identifier in sorted(seen):
 p=packages[identifier];base=Path(p['manifest_path']).parent
 candidates=[x for x in base.rglob('*') if x.is_file() and not x.is_symlink() and x.name.upper().startswith(('LICENSE','COPYING','NOTICE'))]
 if identifier==metadata['resolve']['root']:continue
 if not candidates:raise RuntimeError('missing license material: '+p['name'])
 retained=[]
 for f in sorted(candidates):
  relative=Path('ThirdParty')/(p['name']+'-'+p['version'])/f.relative_to(base);target=package/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
  retained.append({'path':str(relative),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 licenses.append({'name':p['name'],'version':p['version'],'license':p['license'],'files':retained})
docs=tool.parent/'share/doc/rust';target=package/'ThirdParty/rust-standard-library-1.98.1';target.mkdir()
shutil.copy2(docs/'COPYRIGHT-library.html',target/'COPYRIGHT-library.html');shutil.copytree(docs/'licenses',target/'licenses')
licenses.append({'name':'rust-standard-library','version':'1.98.1','license':'See COPYRIGHT-library.html and included license texts','files':[{'path':str(p.relative_to(package)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(target.rglob('*')) if p.is_file()]})
(package/'THIRD_PARTY.json').write_text(json.dumps(licenses,indent=2)+'\n')
(package/'README.md').write_text('''# Continuity iOS package candidate

Add this extracted directory as a local Swift package and link the QPeriaptContinuity product. Import QPeriaptContinuity. The package includes the current Swift owner library, C header and static XCFramework; it needs no external header/library search paths or Rust toolchain in the consuming app.

This unpublished qualification candidate contains arm64 iOS device and arm64 iOS simulator slices, with an iOS 16 source floor. It makes no Intel Mac support claim. The independent qpc-owner/1 interface remains a candidate, separate from the product SDK ABI 2. Product publication and full release admission are not established by packaging.
''')
from archive_package import finish
finish(out)
