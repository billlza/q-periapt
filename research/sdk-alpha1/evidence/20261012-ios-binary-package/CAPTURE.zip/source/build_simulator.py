from pathlib import Path
import json,hashlib
import rust_sdk_profile as sdk
r=Path.cwd();out=Path(__file__).resolve().parent;state=json.loads((out/'STATE.json').read_text());assert not state['live_producer'];state['live_producer']=True
state['source_sha256']={str(p.relative_to(out/'c-consumer')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'c-consumer').rglob('*') if p.is_file()}
(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 env=state['environment'];tool=Path(env['RUSTC']).parent
 sdk.command([str(tool/'cargo'),'build','--lib','--release','--offline','--locked','--target','aarch64-apple-ios-sim','-j','2'],out/'simulator-build',Path(state['source']),environment=env)
 assert all(hashlib.sha256((out/'c-consumer'/n).read_bytes()).hexdigest()==h for n,h in state['source_sha256'].items())
 state['completed']=True
finally:
 state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Apple Silicon iOS simulator static library built; device library retained unchanged',flush=True)
