# Continuity iOS package candidate

Add this extracted directory as a local Swift package and link the QPeriaptContinuity product. Import QPeriaptContinuity. The package includes the current Swift owner library, C header and static XCFramework; it needs no external header/library search paths or Rust toolchain in the consuming app.

This unpublished qualification candidate contains arm64 iOS device and arm64 iOS simulator slices, with an iOS 16 source floor. It makes no Intel Mac support claim. The independent qpc-owner/1 interface remains a candidate, separate from the product SDK ABI 2. Product publication and full release admission are not established by packaging.
