// swift-tools-version:6.0
// SPDX-License-Identifier: Apache-2.0 OR MIT
import PackageDescription
let package = Package(
    name: "QPeriaptContinuity",
    platforms: [.iOS(.v16)],
    products: [.library(name: "QPeriaptContinuity", targets: ["QPeriaptContinuity"])],
    targets: [
        .binaryTarget(name: "CQPCOwner", path: "CQPCOwner.xcframework"),
        .target(name: "QPeriaptContinuity", dependencies: ["CQPCOwner"],
                linkerSettings: [.linkedFramework("Security")]),
    ]
)
