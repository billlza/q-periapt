"""Append independently checked packet-shape candidates without changing the model."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path.cwd();parent=root/'target/p0-origin-offer-response-full-replay-718/offer-response-full-proof.spthy'
data=parent.read_bytes()
assert hashlib.sha256(data).hexdigest()=='8dfd3d7f906a562d642bdbe0d1510ba03df53d9310baafb43dab9c7e44a66069'
text=data.decode()
decl=list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:',text))
reuse=[match[1] for match in decl if 'reuse' in {entry.strip() for entry in (match[2] or '').split(',')}]
assert len(decl)==29 and len(reuse)==13
attrs=',\n  '.join('hide_lemma='+name for name in reuse)
offer=f'''lemma signed_offer_payload_has_key_constructor [{attrs}]:
  all-traces
  "All s %epoch role packet #sent.
    WireSent(s, %epoch, role, 'offer', packet) @ #sent ==>
    (Ex context %previous parent key signer.
      packet = <<'offer', scope(s, context, %previous, %epoch, role, parent), kempk(key)>,
        sign(<'offer', scope(s, context, %previous, %epoch, role, parent), kempk(key)>, signer)>
      & %epoch = %previous %+ %1)"
by sorry
'''
response=f'''lemma signed_response_payload_has_public_constructors [{attrs}]:
  all-traces
  "All s %epoch role packet #sent.
    WireSent(s, %epoch, role, 'response', packet) @ #sent ==>
    (Ex context %previous parent offer peer coins confirmation signer.
      packet = <<<'response', scope(s, context, %previous, %epoch, role, parent), h(offer), kemct(peer, coins)>, h(confirmation)>,
        sign(<<'response', scope(s, context, %previous, %epoch, role, parent), h(offer), kemct(peer, coins)>, h(confirmation)>, signer)>
      & %epoch = %previous %+ %1)"
by sorry
'''
end=list(re.finditer(r'(?m)^end$',text));assert len(end)==1
insertion='\n'+offer+'\n'+response+'\n'
candidate=text[:end[0].start()]+insertion+text[end[0].start():]
assert candidate.replace(insertion,'',1)==text
processes=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
assert not any(line.strip().endswith('/tamarin-prover') for line in processes.splitlines())
stage=root/'target/p0-wire-payload-shapes-719';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),
 'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'new_candidates':['signed_offer_payload_has_key_constructor','signed_response_payload_has_public_constructors'],
 'new_candidates_not_reuse':True,'all_previous_reuse_lemmas_hidden_for_each_candidate':reuse,
 'all_original_rules_restrictions_equations_29_queries_and_proofs_byte_equal':True,
 'candidate_rationale':'Existing WireSent events expose packets. Offer content has a KEM public-key constructor; response core has a hash and KEM ciphertext, with a hashed confirmation. Shape claims only, not secrecy.',
 'no_new_actions_or_state_instrumentation':True,
 'bounds':{'seconds':900,'heap_gib':12,'threads':1,'search_depth':16,'derivation_seconds':60},
 'method_reference':'https://tamarin-prover.com/manual/master/book/007_property-specification.html#reuse',
 'acceptance':'Both candidates must be independently verified under the full unchanged model before any reuse. Multi-epoch secrecy remains open.'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'previous_lemmas':29,'new_nonreuse_candidates':2,'hidden_reuse_count':len(reuse)}))
