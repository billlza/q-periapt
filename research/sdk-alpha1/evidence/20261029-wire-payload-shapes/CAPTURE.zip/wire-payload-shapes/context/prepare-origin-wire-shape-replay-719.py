"""Compare proven wire shapes using the complete retained origin proof tree."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

root = Path.cwd()
parent = root/'target/p0-origin-with-wire-shapes-719/model.spthy'
data = parent.read_bytes()
assert hashlib.sha256(data).hexdigest() == '7f22ba7a9af18722e8873cd69a2f67a4bdd835be9bde9f63872986f0fdfefdb8'
terminal = json.loads(parent.with_name('origin-with-wire-shapes-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['accepted'] and not terminal['timed_out']
assert all(terminal['results'][name]['status']=='verified' for name in ('signed_offer_payload_has_key_constructor','signed_response_payload_has_public_constructors'))
value = data.decode()
old_name = 'epoch_generation_secret_derivation_origin'
new_name = old_name + '_with_wire_shapes'
start = value.index('lemma ' + old_name + ' ')
stop = value.index('\nlemma ', start)
original = value[start:stop]
new_start = value.index('lemma ' + new_name + ' ')
new_stop = re.search(r'(?m)^end$', value[new_start:]).start() + new_start
replacement = original.replace('lemma '+old_name+' ', 'lemma '+new_name+' ', 1) + '\n\n'
candidate = value[:new_start] + replacement + value[new_stop:]
assert candidate[:new_start] == value[:new_start]
assert replacement.replace('lemma '+new_name+' ', 'lemma '+old_name+' ',1).rstrip() == original.rstrip()
assert original.count('by sorry') == 42
processes = subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
assert not any(line.strip().endswith('/tamarin-prover') for line in processes.splitlines())
stage = root/'target/p0-origin-wire-shape-full-replay-719'
stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record = {'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),
    'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'original_382_step_42_open_tree_copied_exactly_except_lemma_name':True,
    'all_31_previous_queries_proofs_and_operational_model_unchanged':True,
    'new_query':new_name,'fresh_search_diagnostic_steps':46,
    'fresh_search_steps_not_compared_to_retained_tree':True,
    'purpose':'Test whether independently proven wire-shape invariants close branches in the existing complete source proof without re-searching or changing resource limits.',
    'mode':'replay','limits':{'seconds':900,'heap_gib':12,'threads':1,'derivation_seconds':60}}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'input_sha256':record['input_sha256'],'retained_open_leaves':42}))
