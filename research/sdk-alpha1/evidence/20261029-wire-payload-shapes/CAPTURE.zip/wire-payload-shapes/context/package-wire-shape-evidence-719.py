"""Retain verified auxiliary shapes and the non-closing full-tree experiment."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile
from deterministic_archive import create_zip

root = Path.cwd()
sha = lambda data: hashlib.sha256(data).hexdigest()
stages = {
    'independent': ('p0-wire-payload-shapes-719','wire-payload-shapes',0),
    'fresh-search': ('p0-origin-with-wire-shapes-719','origin-with-wire-shapes',1),
    'full-replay': ('p0-origin-wire-shape-full-replay-719','origin-wire-shape-full-replay',1),
}
records = {}
for name,(directory,label,driver_exit) in stages.items():
    stage = root/'target'/directory
    terminal = json.loads((stage/(label+'-TERMINAL.json')).read_text())
    assert terminal['returncode']==0 and not terminal['timed_out'] and not terminal['output_exceeded']
    assert sha((stage/'model.spthy').read_bytes())==terminal['input_sha256']
    assert sha((stage/(label+'-proof.spthy')).read_bytes())==terminal['output_sha256']
    assert terminal['accepted'] is (driver_exit==0)
    assert not re.search(r'(?im)^\s*(?:warning|error|fatal)\b',(stage/(label+'.stderr')).read_text())
    records[name] = terminal | {'observed_driver_exit':driver_exit}
parent = root/'target/p0-origin-offer-response-full-replay-718/offer-response-full-proof.spthy'
parent_bytes = parent.read_bytes()
assert sha(parent_bytes)=='8dfd3d7f906a562d642bdbe0d1510ba03df53d9310baafb43dab9c7e44a66069'
full = root/'target/p0-origin-wire-shape-full-replay-719/origin-wire-shape-full-replay-proof.spthy'
text = full.read_text()
original_text = parent_bytes.decode()
query_pattern = r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
def queries(value):
    return {m[1]:(tuple(x.strip() for x in (m[2] or '').split(',')),m[3],re.sub(r'\s+','',m[4]))
            for m in re.finditer(query_pattern,value)}
old_queries = queries(original_text)
new_queries = queries(text)
assert len(old_queries)==29 and len(new_queries)==32
assert all(new_queries[name]==value for name,value in old_queries.items())
prefix = original_text[:original_text.index('lemma ')]
assert text[:text.index('lemma ')]==prefix
assert sha(prefix.encode())=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
old_name = 'epoch_generation_secret_derivation_origin'
new_name = old_name+'_with_wire_shapes'
assert new_queries[old_name][2]==new_queries[new_name][2]
def lemma_body(name):
    start = text.index('lemma '+name+' ')
    tail = text[start:]
    stop = re.search(r'(?m)^lemma |^/\* All wellformedness|^end$',tail[6:])
    return tail[:stop.start()+6]
def branches(body):
    sources = {m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
    assert len(sources)==18
    children = {m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',sources['Snapshot_case_5'])}
    assert len(children)==11
    return {'source_open_leaves':{name:value.count('by sorry') for name,value in sources.items()},
            'stored_open_leaves':{name:value.count('by sorry') for name,value in children.items()},
            'stored_proof_sha256':{name:sha(value.encode()) for name,value in children.items()}}
old = branches(lemma_body(old_name)); new = branches(lemma_body(new_name))
assert old['source_open_leaves']==new['source_open_leaves'] and old['stored_open_leaves']==new['stored_open_leaves']
assert sum(new['source_open_leaves'].values())==42
assert {name for name,count in new['stored_open_leaves'].items() if count==0}=={'Key_Reservation_1','Offer_Signing_2','Response_Reservation_4'}
shapes = ['signed_offer_payload_has_key_constructor','signed_response_payload_has_public_constructors']
assert [records['independent']['results'][name]['steps'] for name in shapes]==[3,4]
assert all(records[stage]['results'][name]['status']=='verified' for stage in stages for name in shapes)
independent_text=(root/'target/p0-wire-payload-shapes-719/model.spthy').read_text()
independent_queries=queries(independent_text)
reuse=[name for name,(attrs,_,_) in old_queries.items() if 'reuse' in attrs]
assert len(reuse)==13
for name in shapes:
    assert set(independent_queries[name][0])=={'hide_lemma='+item for item in reuse}
analysis = {'schema_version':1,'source_commit':'093555683948976f095c20e30e73e5d4ae87af12',
    'operational_prefix_sha256':sha(prefix.encode()),'original_29_queries_unchanged':True,
    'independent_shapes':{name:records['independent']['results'][name] for name in shapes},
    'existing_reuse_lemmas_hidden':reuse,'new_shapes_not_reuse_during_independent_proof':True,
    'original_origin':{'steps':382,'branches':old},
    'with_proven_shapes':{'steps':389,'branches':new},
    'additional_closed_source_or_stored_branches':0,
    'fresh_search_steps':46,'fresh_search_not_comparable_to_complete_retained_tree':True,
    'auxiliary_all_trace_verified':sum(v['mode']=='all-traces' and v['status']=='verified' for v in records['full-replay']['results'].values()),
    'initial_epoch_traffic_witness':records['full-replay']['results']['initial_epoch_traffic_advances_counter_is_executable'],
    'main_multi_epoch_secrecy':'analysis incomplete','release_claim_eligible':False,
    'observed_driver_exits':{name:r['observed_driver_exit'] for name,r in records.items()},
    'elapsed_seconds':{name:r['elapsed_seconds'] for name,r in records.items()},
    'interpretation':'The two public-packet shapes are proved, but they do not close any of the 42 retained Snapshot plaintext branches. Neither increased step count nor independently proved auxiliaries establish the generation-origin or multi-epoch secrecy statement.',
    'next_discriminating_step':'Trace retained root and payload components through phase producers. Existing phase markers do not carry the full payload. If an extra trace event is needed to express a structural invariant, require an exact erasure/projection check to the unchanged operational rules, no new restriction or adversary limitation, and independent proof before reuse. Do not repeat the same packet-shape search.',
    'method_reference':'https://tamarin-prover.com/manual/master/book/007_property-specification.html#reuse'}
stage=root/'target/p0-wire-shape-capsule-719'
stage.mkdir(exist_ok=False)
inputs=stage/'inputs';inputs.mkdir()
for name,(directory,label,_) in stages.items():
    destination=inputs/name;destination.mkdir()
    source=root/'target'/directory
    for path in sorted(source.iterdir()):
        assert path.is_file() and not path.is_symlink()
        shutil.copy2(path,destination/path.name)
context=inputs/'context';context.mkdir()
shutil.copy2(parent,context/'parent-382-step-proof.spthy')
shutil.copy2(root/'target/witness-renewal-01/P0_PINNED_PROVER_IDENTITY_01.json',context/'PINNED_PROVER_IDENTITY.json')
shutil.copy2(root/'target/p0-wire-payload-preparation-719/PREPARATION_FAILURE_01.json',context/'PREPARATION_FAILURE_01.json')
for name in ('prepare-wire-payload-shapes-719.py','prepare-origin-with-wire-shapes-719.py','prepare-origin-wire-shape-replay-719.py','package-wire-shape-evidence-719.py'):
    shutil.copy2(root/'target'/name,context/name)
(inputs/'ANALYSIS.json').write_text(json.dumps(analysis,indent=2)+'\n')
destination=root/'research/sdk-alpha1/evidence/20261029-wire-payload-shapes'
destination.mkdir(exist_ok=False)
create_zip(inputs,destination/'CAPTURE.zip',root_name='wire-payload-shapes',mtime=315532800)
archive=(destination/'CAPTURE.zip').read_bytes()
members={'wire-payload-shapes/'+str(p.relative_to(inputs)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
         for p in sorted(inputs.rglob('*')) if p.is_file()}
with zipfile.ZipFile(destination/'CAPTURE.zip') as z:
    files=[i for i in z.infolist() if not i.is_dir()]
    assert {i.filename for i in files}==set(members) and z.testzip() is None
    for info in files:
        data=z.read(info.filename)
        assert members[info.filename]=={'bytes':len(data),'sha256':sha(data)}
manifest={'schema_version':1,'kind':'independent-wire-payload-shapes-and-full-origin-replay',
    'archive_sha256':sha(archive),'archive_bytes':len(archive),'members':members,'analysis':analysis}
(destination/'CAPTURE.json').write_text(json.dumps(manifest,indent=2)+'\n')
readback={'schema_version':1,'archive_sha256':sha(archive),'manifest_sha256':sha((destination/'CAPTURE.json').read_bytes()),
    'file_members':len(members),'expanded_bytes':sum(r['bytes'] for r in members.values()),
    'all_members_read_back_and_byte_compared':True,'proofs':analysis,'entire_goal_complete':False}
(destination/'READBACK.json').write_text(json.dumps(readback,indent=2)+'\n')
print(json.dumps({'directory':str(destination),'archive_sha256':sha(archive),'archive_bytes':len(archive),'members':len(members),
    'elapsed':analysis['elapsed_seconds'],'additional_closed_branches':0}))
