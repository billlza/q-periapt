"""Use independently verified packet shapes in an unchanged origin proposition."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

root = Path.cwd()
parent = root / 'target/p0-wire-payload-shapes-719/wire-payload-shapes-proof.spthy'
data = parent.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'd3f8e9e18528ea873a22798bf824c3df593dced8714354ba18ce8bd978ad4cbc'
receipt = json.loads(parent.with_name('wire-payload-shapes-TERMINAL.json').read_text())
names = ['signed_offer_payload_has_key_constructor', 'signed_response_payload_has_public_constructors']
assert receipt['accepted'] and receipt['returncode'] == 0 and not receipt['timed_out']
assert all(receipt['results'][name]['status'] == 'verified' for name in names)
text = data.decode()
declarations = list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:', text))
assert len(declarations) == 31
original = next(match for match in declarations if match[1] == 'epoch_generation_secret_derivation_origin')
next_lemma = next(match.start() for match in declarations if match.start() > original.start())
formula = text[original.end():next_lemma].split('"', 2)[1]
candidate = text
for name in names:
    token = 'lemma ' + name + ' ['
    assert candidate.count(token) == 1
    extra = 'reuse, '
    if name == names[1]:
        extra += 'hide_lemma=' + names[0] + ', '
    candidate = candidate.replace(token, token + extra, 1)
new_name = 'epoch_generation_secret_derivation_origin_with_wire_shapes'
query = '\nlemma ' + new_name + ' [use_induction]:\n  all-traces\n  "' + formula + '"\nby sorry\n\n'
end = list(re.finditer(r'(?m)^end$', candidate))
assert len(end) == 1
candidate = candidate[:end[0].start()] + query + candidate[end[0].start():]
assert candidate[:declarations[29].start()] == text[:declarations[29].start()]
assert query.split('"', 2)[1] == formula
processes = subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True)
assert not any(line.strip().endswith('/tamarin-prover') for line in processes.splitlines())
stage = root / 'target/p0-origin-with-wire-shapes-719'
stage.mkdir(exist_ok=False)
(stage / 'model.spthy').write_text(candidate)
shutil.copy2(root / 'target/p0-wire-scope-replay-704/run.py', stage / 'run.py')
record = {
    'parent': str(parent), 'parent_sha256': hashlib.sha256(data).hexdigest(),
    'independent_shape_receipt_sha256': hashlib.sha256(parent.with_name('wire-payload-shapes-TERMINAL.json').read_bytes()).hexdigest(),
    'independently_verified_reuse_lemmas': names,
    'second_shape_hides_first_to_preserve_independent_proof': True,
    'original_29_formulas_attributes_and_proofs_byte_equal': True,
    'rules_restrictions_equations_unchanged': True,
    'origin_formula_exactly_equal': True,
    'new_query': new_name,
    'input_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'bounds': {'seconds': 900, 'heap_gib': 12, 'threads': 1, 'search_depth': 16, 'derivation_seconds': 60},
    'scope': 'Diagnostic copy of the same origin statement after two proven reusable shape lemmas; not a new secrecy claim or an assumed axiom.'
}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'stage': str(stage), 'input_sha256': record['input_sha256'], 'new_query': new_name}))
