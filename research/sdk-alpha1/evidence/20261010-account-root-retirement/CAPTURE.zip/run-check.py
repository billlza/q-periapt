from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
root = base.parent.parent
label, mode = sys.argv[1:]
assert mode in ('focused', 'clippy', 'msrv', 'release-focused', 'release-full', 'doc')
version = '1.90.0' if mode == 'msrv' else '1.98.1'
rust = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains') / (version + '-aarch64-apple-darwin')
out = base / label
out.mkdir(mode=0o700)
files = sorted(set(subprocess.check_output(['git', 'diff', '--name-only', '--', '*.rs'], cwd=root, text=True).splitlines() + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.rs'], cwd=root, text=True).splitlines()))
if mode == 'focused':
    subprocess.run([str(rust / 'bin/rustfmt'), '--edition', '2021', '--config', 'skip_children=true', *files], cwd=root, check=True)
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO', 'RUST', 'QPERIAPT', 'QPC', 'DYLD', 'LD_', 'PYTHON', 'JAVA', 'KOTLIN', 'GRADLE'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(base / ('build-msrv' if mode == 'msrv' else 'build')), RUSTC=str(rust / 'bin/rustc'), RUSTDOC=str(rust / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', PATH=str(rust / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', DYLD_FALLBACK_LIBRARY_PATH=str(rust / 'lib'))
command = 'clippy' if mode == 'clippy' else 'check' if mode == 'msrv' else 'test'
argv = [str(rust / 'bin/cargo'), command, '--manifest-path', str(root / 'research/continuity-identity-candidate/Cargo.toml'), '--all-features', '--locked', '--offline', '-j', '2']
if mode in ('clippy', 'msrv'):
    argv += ['--all-targets']
elif mode == 'doc':
    argv += ['--doc']
else:
    argv += ['--lib']
    if mode.startswith('release'):
        argv += ['--release']
    if mode != 'release-full':
        argv += ['account_root']
    argv += ['--', '--nocapture', '--test-threads=1']
record = {'command': argv, 'mode': mode, 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'source_sha256': {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files}, 'completed': False}
(out / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
timed_out = False
with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
    process = subprocess.Popen(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        result = process.wait(timeout=5400 if mode == 'release-full' else 900)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            result = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            result = process.wait()
record.update(returncode=result, timed_out=timed_out, seconds=time.monotonic() - started, source_unchanged=all(hashlib.sha256((root / f).read_bytes()).hexdigest() == h for f, h in record['source_sha256'].items()))
record['completed'] = result == 0 and not timed_out and record['source_unchanged']
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'source_sha256'}), flush=True)
print((out / 'stdout').read_text(errors='replace')[-5000:], flush=True)
print((out / 'stderr').read_text(errors='replace')[-2600:], flush=True)
raise SystemExit(0 if record['completed'] else 1)
