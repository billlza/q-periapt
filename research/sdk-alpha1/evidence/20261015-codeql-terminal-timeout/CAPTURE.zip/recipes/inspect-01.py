from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler,urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
import hashlib,json,re,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
items=[('job',['gh','api','repos/billlza/q-periapt/actions/jobs/116280305164']),('annotations',['gh','api','repos/billlza/q-periapt/check-runs/116280305164/annotations']),('artifacts',['gh','api','repos/billlza/q-periapt/actions/runs/38692152632/artifacts'])]
values={}
for label,argv in items:values[label]=json.loads(sdk.command(argv,stage/(label+'-01'),root))
sdk.require(values['job']['status']=='completed' and values['job']['conclusion']=='failure','job not a terminal failure')
sdk.require(any('timed out after 300 minutes' in x.get('message','') for x in values['annotations']),'timeout annotation missing')
class StopRedirect(HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
api='https://api.github.com/repos/billlza/q-periapt/actions/jobs/116280305164/logs'
token=subprocess.check_output(['gh','auth','token','--hostname','github.com'],text=True,stderr=subprocess.PIPE).strip()
sdk.require(bool(token),'missing GitHub credential')
try:
 response=build_opener(StopRedirect).open(Request(api,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'}),timeout=30)
 response.close();raise ValueError('expected a log-download redirect')
except HTTPError as exc:
 sdk.require(exc.code==302,'log endpoint did not return the expected redirect')
 destination=exc.headers.get('Location');exc.close();sdk.require(isinstance(destination,str),'log redirect missing')
finally:token=None
parts=urlsplit(destination)
sdk.require(parts.scheme=='https' and parts.username is None and parts.password is None and parts.port in (None,443) and parts.hostname is not None and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.githubusercontent.com')),'unexpected log download host')
with urlopen(Request(destination,headers={'Range':'bytes=-262144','Accept-Encoding':'identity'}),timeout=30) as response:
 sdk.require(response.status==206,'log service ignored bounded range request')
 content_range=response.headers.get('Content-Range','');match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',content_range);sdk.require(match is not None,'invalid range header')
 start,end,total=map(int,match.groups());sdk.require(end==total-1 and end-start+1<=262144,'unexpected range extent')
 body=response.read(262145);sdk.require(len(body)==end-start+1,'range body length differs')
with (stage/'job-tail-01.log').open('xb') as f:f.write(body)
lines=body.decode('utf-8',errors='replace').splitlines()
selected=[line for line in lines if re.search(r'FullSummary|SummaryStats|timed out|##\[error|Evaluat|failed|exceeded|38/39|39/39',line,re.I)]
selected=[re.sub(r'https?://\S+', '[url omitted]',line) for line in selected]
sdk.write_json(stage/'TERMINAL_DIAGNOSIS_01.json',{'completed':True,'run_id':38692152632,'job_id':116280305164,'source_head':'9d396755c3f872d3a59932c6fe106b2b5e1b2e59','job_conclusion':'failure','analyze_timeout_minutes':300,'range':{'start':start,'end':end,'total':total,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'download_host':parts.hostname,'credential_or_signed_url_recorded':False,'filtered_diagnostics':selected[-60:],'whole_log_downloaded':False})
print(json.dumps({'range_bytes':len(body),'total_log_bytes':total,'filtered_diagnostics':selected[-35:]},ensure_ascii=False))
