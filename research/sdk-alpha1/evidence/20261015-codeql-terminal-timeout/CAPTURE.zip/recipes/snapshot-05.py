"""Bind terminal CI state and bounded diagnostics to the current remote source."""
from pathlib import Path
from urllib.request import urlopen
import hashlib, json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = '9d396755c3f872d3a59932c6fe106b2b5e1b2e59'
runs = {}
for run_id in (38692152632, 38692135318, 38692152702):
    body = sdk.command(['gh', 'run', 'view', str(run_id), '--repo', 'billlza/q-periapt',
        '--json', 'status,conclusion,headSha,url,jobs'], stage / ('run-' + str(run_id) + '-05'), root)
    row = json.loads(body)
    sdk.require(row['headSha'] == source, 'CI source differs')
    runs[str(run_id)] = {'status': row['status'], 'conclusion': row['conclusion'],
                        'source_head': source, 'url': row['url'],
                        'jobs': [{k: job[k] for k in ('name', 'status', 'conclusion')}
                                 for job in row['jobs']]}
sdk.require(runs['38692152632']['conclusion'] == 'failure', 'Rust run no longer matches')
text = (stage / 'timeout-window-03.log').read_text()
done = re.findall(r'\[(\d+)/39 eval ([^\]]+)\] Evaluation done; writing results to ([^\r\n]+)\.', text)
started = re.findall(r'Starting evaluation of ([^\r\n]+)\.', text)
sdk.require([int(n) for n, _, _ in done] == list(range(1, 39)), 'incomplete progress sequence')
done_queries = {name.removesuffix('.bqrs') + '.ql' for _, _, name in done}
sdk.require(len(started) == len(set(started)) == 39, 'query start inventory differs')
unfinished = sorted(set(started) - done_queries)
sdk.require(unfinished == ['codeql/rust-queries/queries/summary/SummaryStats.ql'], 'unfinished query differs')
query_manifest = json.loads((root / 'artifact/codeql_memory_queries.json').read_text())
upstream = {}
for filename in ('SummaryStats.ql', 'SummaryStatsReduced.ql', 'Stats.qll', 'TaintReach.qll'):
    url = 'https://raw.githubusercontent.com/github/codeql/codeql-cli/v2.27.1/rust/ql/src/queries/summary/' + filename
    with urlopen(url, timeout=30) as response:
        sdk.require(response.status == 200, 'upstream retrieval failed')
        data = response.read(32769)
    sdk.require(len(data) <= 32768, 'upstream source exceeds bound')
    with (stage / ('upstream-' + filename)).open('xb') as output:
        output.write(data)
    digest = hashlib.sha256(data).hexdigest()
    if filename.endswith('.ql'):
        key = 'qlpacks/codeql/rust-queries/0.1.43/queries/summary/' + filename
        sdk.require(digest == query_manifest['query_hashes'][key], 'upstream query differs from pinned manifest')
    upstream[filename] = {'url': url, 'sha256': digest, 'bytes': len(data),
                          'matches_query_manifest': filename.endswith('.ql')}
selected = [re.sub(r'https?://\S+', '[url omitted]', line) for line in text.splitlines()
            if re.search(r'database run-queries |\[\d+/39 eval |Starting evaluation of .*SummaryStats|timed out after 300|cache directory is already locked', line)]
tail = (stage / 'job-tail-02.log').read_text()
evictions = [line for line in tail.splitlines() if 'Pausing evaluation to evict' in line]
sdk.require(evictions and any('[2026-10-15 11:36:' in line for line in evictions), 'post-timeout evaluator activity absent')
sdk.write_json(stage / 'DIAGNOSIS_05.json', {
    'completed': True, 'source_head': source, 'runs': runs,
    'query_count': 39, 'completed_query_progress': 38, 'unfinished_queries': unfinished,
    'analyze_timeout_minutes': 300, 'fresh_complete_bqrs_set_verified': False,
    'quality_gate_passed': False, 'rust_sarif_uploaded_by_this_run': False,
    'post_timeout_evaluator_activity_and_cache_lock_observed': True,
    'selected_progress': selected, 'tail_eviction_examples': evictions[-3:],
    'upstream_sources': upstream,
    'facts_not_inferred': ['partial database metadata was not inspected',
        'eviction logs alone do not prove a resource setting will fix completion',
        'completed query progress is not an accepted Rust analysis'],
    'workflow_modified': False, 'query_or_quality_gate_removed': False,
    'new_ci_run_started': False, 'release_claim_eligible': False,
})
print(json.dumps({'completed': True, 'unfinished_queries': unfinished,
                  'runs': {key: {'status': row['status'], 'conclusion': row['conclusion'],
                    'passed': sum(j['conclusion'] == 'success' for j in row['jobs']),
                    'total': len(row['jobs'])} for key, row in runs.items()}}))
