"""Publish bounded CI facts without publishing bulk logs or download credentials."""
from pathlib import Path
import hashlib, json, re, zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
diagnosis = json.loads((stage / 'DIAGNOSIS_05.json').read_text())
sdk.require(diagnosis['completed'] and not diagnosis['quality_gate_passed'], 'diagnosis changed')
range_rows = {}
for name in ('TERMINAL_DIAGNOSIS_02.json', 'TIMEOUT_WINDOW_03.json', 'EVALUATOR_WINDOWS_04.json'):
    row = json.loads((stage / name).read_text())
    if 'windows' in row:
        range_rows[name] = {**{k: v for k, v in row.items() if k != 'windows'},
            'windows': [{k: v for k, v in window.items() if k != 'filtered_diagnostics'}
                        for window in row['windows']]}
    else:
        range_rows[name] = {k: v for k, v in row.items() if k != 'filtered_diagnostics'}
sdk.write_json(stage / 'RANGES_06.json', {'completed': True,
    'log_ranges': range_rows, 'raw_ranges_retained_locally': True,
    'full_log_downloaded': False, 'raw_ranges_published': False,
    'first_suffix_range_attempt': 'HTTP 200 ignored the suffix request; stopped before reading the body. Explicit start-end ranges returned HTTP 206 and passed length/ETag checks.'})
files = {}
names = ['DIAGNOSIS_05.json', 'RANGES_06.json']
names += [p.name for p in stage.iterdir() if p.suffix == '.py']
names += [p.name for p in stage.iterdir() if p.name.startswith(('job-01.', 'annotations-01.', 'artifacts-01.', 'run-'))
          and p.suffix in ('.json', '.stdout', '.stderr')]
for name in sorted(set(names)):
    path = stage / name
    folder = 'recipes' if path.suffix == '.py' else 'receipts'
    files[folder + '/' + name] = sdk.snapshot(path, maximum=8 * 1024**2).data
for relative in ('.github/workflows/codeql.yml', '.github/workflows/codeql-memory-control.yml',
                 'artifact/codeql_memory_control.py', 'artifact/codeql_memory_queries.json',
                 'artifact/codeql_rust_quality.py'):
    files['source/' + relative] = sdk.snapshot(root / relative).data
# Reject accidental concrete credentials / signed query parameters. Recipes use
# credential variable names, but never embed their runtime values.
for name, data in files.items():
    sdk.require(not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|[?&](?:sig|token|access_token)=)', data), 'sensitive value selected: ' + name)
output = root / 'research/sdk-alpha1/evidence/20261015-codeql-terminal-timeout'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, data)
manifest = {'format': 1, 'base_commit': 'b5e38b7e345997804dd826003cd7520020967a7a',
    'source_head': diagnosis['source_head'],
    'capture_sha256': sdk.snapshot(archive, maximum=32 * 1024**2).sha256,
    'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'codeql_run': 38692152632, 'rust_job': 116280305164,
    'rust_conclusion': 'failure', 'analyze_timeout_minutes': 300,
    'completed_query_progress': 38, 'query_count': 39,
    'unfinished_queries': diagnosis['unfinished_queries'],
    'database_metadata_not_inspected': True, 'raw_log_ranges_retained_locally': True,
    'workflow_modified': False, 'new_ci_run_started': False,
    'quality_gate_passed': False, 'release_claim_eligible': False}
sdk.write_json(output / 'CAPTURE.json', manifest)
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(set(zipped.namelist())) == len(files), 'archive inventory differs')
    for name, digest in manifest['members'].items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, 'archive readback differs')
    sdk.require(json.loads(zipped.read('receipts/DIAGNOSIS_05.json')) == diagnosis, 'diagnosis readback differs')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'members': len(files),
    'capture_sha256': manifest['capture_sha256'], 'terminal_rust_failure_verified': True,
    'raw_logs_or_credentials_published': False, 'quality_gate_passed': False})
print(json.dumps({'members': len(files), 'capture_sha256': manifest['capture_sha256'],
                  'rust_conclusion': 'failure'}))
