from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler,urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
from datetime import datetime,timezone
import hashlib,json,re,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
class StopRedirect(HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
token=subprocess.check_output(['gh','auth','token','--hostname','github.com'],text=True,stderr=subprocess.PIPE).strip()
try:
 response=build_opener(StopRedirect).open(Request('https://api.github.com/repos/billlza/q-periapt/actions/jobs/116280305164/logs',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'}),timeout=30)
 response.close();raise ValueError('expected log redirect')
except HTTPError as exc:
 sdk.require(exc.code==302,'unexpected log redirect status');destination=exc.headers['Location'];exc.close()
finally:token=None
parts=urlsplit(destination);sdk.require(parts.scheme=='https' and parts.username is None and parts.password is None and parts.port in (None,443) and parts.hostname is not None and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.githubusercontent.com')),'unexpected download host')
with urlopen(Request(destination,method='HEAD',headers={'Accept-Encoding':'identity'}),timeout=30) as response:
 sdk.require(response.status==200,'HEAD failed');total=int(response.headers['Content-Length']);etag=response.headers['ETag']
sdk.require(total==json.loads((stage/'TERMINAL_DIAGNOSIS_02.json').read_text())['range']['total'],'log size changed')
probes=[];received=0
def fetch(start,end):
 global received
 sdk.require(0<=start<=end<total and end-start+1<=524288 and received+end-start+1<=2*1024**2,'range budget exceeded')
 with urlopen(Request(destination,headers={'Range':f'bytes={start}-{end}','If-Match':etag,'Accept-Encoding':'identity'}),timeout=30) as response:
  sdk.require(response.status==206 and response.headers.get('Content-Range')==f'bytes {start}-{end}/{total}','range identity differs')
  data=response.read(end-start+2);sdk.require(len(data)==end-start+1,'range length differs')
 received+=len(data);return data
pattern=re.compile(rb'(?m)^(2026-10-15T\d\d:\d\d:\d\d\.\d+Z) ')
lo,hi=0,total-1;target=datetime(2026,10,15,11,33,48,tzinfo=timezone.utc)
for _ in range(18):
 if hi-lo<=65536:break
 mid=(lo+hi)//2;end=min(total-1,mid+32767);data=fetch(mid,end);matches=list(pattern.finditer(data));sdk.require(bool(matches),'probe has no complete timestamped line')
 first=matches[0];stamp=datetime.fromisoformat(first.group(1).decode().replace('Z','+00:00'))
 probes.append({'start':mid,'end':end,'first_timestamp':first.group(1).decode(),'last_timestamp':matches[-1].group(1).decode(),'sha256':hashlib.sha256(data).hexdigest()})
 if stamp<target:lo=mid+first.start()
 else:hi=mid+first.start()
else:raise ValueError('timestamp search budget exhausted')
start=max(0,lo-131072);end=min(total-1,hi+131072);data=fetch(start,end)
with (stage/'timeout-window-03.log').open('xb') as f:f.write(data)
lines=data.decode('utf-8',errors='replace').splitlines();patterns=r'FullSummary|SummaryStats|\[\d+/39\]|timed out|##\[error|database.*bundle|locked|failed|39 queries|threads=|off-heap|Xmx|expect-discarded|operation was canceled'
selected=[re.sub(r'https?://\S+','[url omitted]',line) for line in lines if re.search(patterns,line,re.I)]
sdk.write_json(stage/'TIMEOUT_WINDOW_03.json',{'completed':True,'run_id':38692152632,'job_id':116280305164,'source_head':'9d396755c3f872d3a59932c6fe106b2b5e1b2e59','range':{'start':start,'end':end,'total':total,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'probes':probes,'downloaded_bytes_total':received,'filtered_diagnostics':selected,'signed_url_or_credential_recorded':False,'whole_log_downloaded':False})
print(json.dumps({'downloaded_bytes':received,'window_start':start,'window_end':end,'diagnostics':[x[:900] for x in selected[-45:]]},ensure_ascii=False))
