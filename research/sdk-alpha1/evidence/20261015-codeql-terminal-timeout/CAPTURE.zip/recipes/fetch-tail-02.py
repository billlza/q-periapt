from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler,urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
import hashlib,json,re,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
job=json.loads((stage/'job-01.stdout').read_text());annotations=json.loads((stage/'annotations-01.stdout').read_text())
sdk.require(job['status']=='completed' and job['conclusion']=='failure' and any('timed out after 300 minutes' in x.get('message','') for x in annotations),'terminal identity changed')
class StopRedirect(HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
api='https://api.github.com/repos/billlza/q-periapt/actions/jobs/116280305164/logs'
token=subprocess.check_output(['gh','auth','token','--hostname','github.com'],text=True,stderr=subprocess.PIPE).strip()
try:
 response=build_opener(StopRedirect).open(Request(api,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'}),timeout=30)
 response.close();raise ValueError('expected a log-download redirect')
except HTTPError as exc:
 sdk.require(exc.code==302,'log endpoint did not return the expected redirect');destination=exc.headers.get('Location');exc.close();sdk.require(isinstance(destination,str),'log redirect missing')
finally:token=None
parts=urlsplit(destination);sdk.require(parts.scheme=='https' and parts.username is None and parts.password is None and parts.port in (None,443) and parts.hostname is not None and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.githubusercontent.com')),'unexpected log download host')
with urlopen(Request(destination,method='HEAD',headers={'Accept-Encoding':'identity'}),timeout=30) as response:
 sdk.require(response.status==200,'log HEAD failed');total=int(response.headers['Content-Length']);etag=response.headers.get('ETag');sdk.require(0<total<16*1024**3 and isinstance(etag,str),'invalid object metadata')
start=max(0,total-262144);end=total-1
with urlopen(Request(destination,headers={'Range':f'bytes={start}-{end}','If-Match':etag,'Accept-Encoding':'identity'}),timeout=30) as response:
 sdk.require(response.status==206,'log service ignored explicit bounded range')
 expected=f'bytes {start}-{end}/{total}';sdk.require(response.headers.get('Content-Range')==expected,'range extent differs')
 body=response.read(262145);sdk.require(len(body)==end-start+1,'range body length differs')
with (stage/'job-tail-02.log').open('xb') as f:f.write(body)
selected=[line for line in body.decode('utf-8',errors='replace').splitlines() if re.search(r'FullSummary|SummaryStats|timed out|##\[error|Evaluat|failed|exceeded|38/39|39/39',line,re.I)]
selected=[re.sub(r'https?://\S+', '[url omitted]',line) for line in selected]
sdk.write_json(stage/'TERMINAL_DIAGNOSIS_02.json',{'completed':True,'run_id':38692152632,'job_id':116280305164,'source_head':'9d396755c3f872d3a59932c6fe106b2b5e1b2e59','job_conclusion':'failure','analyze_timeout_minutes':300,'range':{'start':start,'end':end,'total':total,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'download_host':parts.hostname,'etag_sha256':hashlib.sha256(etag.encode()).hexdigest(),'credential_or_signed_url_recorded':False,'filtered_diagnostics':selected[-60:],'whole_log_downloaded':False,'previous_failure':'Suffix range unsupported; explicit start-end with matching HEAD ETag used.'})
print(json.dumps({'range_bytes':len(body),'total_log_bytes':total,'filtered_diagnostics':[x[:600] for x in selected[-35:]]},ensure_ascii=False))
