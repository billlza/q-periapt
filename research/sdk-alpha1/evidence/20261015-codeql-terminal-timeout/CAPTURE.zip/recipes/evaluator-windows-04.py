"""Read bounded log ranges without retaining signed download URLs."""
from pathlib import Path
import hashlib, json, re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
prior = (stage / 'locate-timeout-03.py').read_text()
setup = prior.split('pattern=re.compile(', 1)[0]
sdk.require(setup != prior, 'range-reader boundary missing')
exec(compile(setup, str(stage / 'locate-timeout-03.py'), 'exec'))
windows = []
for label, start in [('initial', 68766875), ('middle', 300000000), ('late', 550000000)]:
    end = start + 524287
    data = fetch(start, end)
    path = stage / (label + '-evaluator-04.log')
    with path.open('xb') as output:
        output.write(data)
    lines = data.decode('utf-8', errors='replace').splitlines()
    selected = [re.sub(r'https?://\S+', '[url omitted]', line) for line in lines
                if re.search(r'TaintReach|iteration|execute queries|run-queries|Xmx|off-heap|dynamic-join|expect-discarded|Reading|Starting evaluation', line, re.I)]
    windows.append({'label': label, 'start': start, 'end': end,
                    'sha256': hashlib.sha256(data).hexdigest(),
                    'filtered_diagnostics': selected})
sdk.write_json(stage / 'EVALUATOR_WINDOWS_04.json', {
    'completed': True, 'total_log_bytes': total, 'downloaded_bytes': received,
    'windows': windows, 'credentials_or_signed_urls_recorded': False,
})
print(json.dumps({'downloaded_bytes': received,
                  'windows': [{'label': w['label'], 'matches': len(w['filtered_diagnostics']),
                               'selected': [x[:1200] for x in w['filtered_diagnostics'][:15]]}
                              for w in windows]}))
