from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import sys
import time

import continuity_multi_epoch_search as contract
from continuity_proof_fragments import collect_closed, restore
from continuity_recovery_proof import prover_environment
from bounded_process import capture_output, BoundedProcessError
from evidence_io import read_regular_snapshot
from formal_toolchain_contract import verify_installed

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-two-round-diagnostic'
OUT = BASE / 'run-01'
TOOLS = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/tools')
TARGET = 'two_rounds_recover_with_exposed_ancestor_is_executable'


def read(path, maximum=4 * 1024**2):
    return read_regular_snapshot(path, maximum=maximum, label='two-round diagnostic input').data


def sha(body):
    return hashlib.sha256(body).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def project_support_proofs(data):
    original = contract.theory(data)
    text = data.decode()
    clean = contract.uncomment(text)
    headers = list(contract._HEADER.finditer(clean))
    edits, projected = [], []
    for index, header in enumerate(headers):
        if header[1] == TARGET:
            continue
        end = header.end()
        while end < len(clean):
            if clean[end] == '\\':
                end += 2
                continue
            if clean[end] == '"':
                break
            end += 1
        assert end < len(clean)
        limit = headers[index + 1].start() if index + 1 < len(headers) else clean.rfind('\nend') + 1
        assert limit > end
        edits.append((end + 1, limit, '\nby sorry\n\n'))
        projected.append(header[1])
    for start, end, replacement in reversed(edits):
        text = text[:start] + replacement + text[end:]
    candidate = text.encode()
    assert contract.theory(candidate) == original and len(projected) == 39
    return candidate, projected


def execute(data, label, search):
    source = OUT / (label + '.input.spthy')
    output = OUT / (label + '.proof.spthy')
    with source.open('xb') as stream:
        stream.write(data)
    theory = contract.theory(data)
    argv = ['tamarin-prover', str(source), '--derivcheck-timeout=60', '--quit-on-warning', '--output=' + str(output)]
    if search:
        argv += ['--prove=' + TARGET, '--heuristic=i', '--bound=256']
    argv += ['+RTS', '-N1', '-M12G', '-c30', '-s', '-RTS']
    row = {'accepted_execution': False, 'search': search, 'argv': argv, 'input_sha256': sha(data),
           'started_utc': datetime.now(timezone.utc).isoformat(), 'timeout_seconds': 900,
           'maximum_stdout_bytes': 16 * 1024**2, 'maximum_stderr_bytes': 16 * 1024**2}
    write(OUT / (label + '.started.json'), row)
    started = time.monotonic()
    print('START', label, row['started_utc'], flush=True)
    try:
        with (OUT / (label + '.stdout')).open('xb', buffering=0) as stdout, (OUT / (label + '.stderr')).open('xb', buffering=0) as stderr:
            result = capture_output(argv, timeout_seconds=900, maximum_stdout_bytes=16 * 1024**2,
                maximum_stderr_bytes=16 * 1024**2, environment=prover_environment(),
                stdout_sink=stdout.write, stderr_sink=stderr.write)
        row['returncode'] = result.returncode
        assert result.returncode == 0, 'Prover process failed; original streams retained.'
        assert not re.search(rb'warning|invalid proof|wellformedness check failed', result.stderr, re.I)
        produced = read(output)
        assert b'invalid proof step' not in produced and read(source) == data
        assert contract.theory(produced) == theory
        inventory = contract.inventory(result.stdout, source, output, theory)
        row.update(accepted_execution=True, results=inventory, output_sha256=sha(produced))
        return produced, inventory
    except BaseException as error:
        row.update(error_type=type(error).__name__, error=str(error))
        if isinstance(error, BoundedProcessError):
            row.update(kind=error.kind, cleanup_ambiguous=error.cleanup_ambiguous)
        raise
    finally:
        row.update(elapsed_seconds=time.monotonic() - started, finished_utc=datetime.now(timezone.utc).isoformat())
        for suffix in ['stdout', 'stderr']:
            path = OUT / (label + '.' + suffix)
            if path.exists():
                row[suffix + '_sha256'] = sha(read(path, 16 * 1024**2))
        write(OUT / (label + '.terminal.json'), row)
        print('END', label, row.get('returncode'), row.get('error_type'), round(row['elapsed_seconds'], 3), flush=True)


def main():
    assert ROOT == Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    OUT.mkdir(mode=0o700, exist_ok=False)
    os.environ['PATH'] = str(TOOLS) + os.pathsep + os.environ['PATH']
    identities = {name: sha(read(TOOLS / name, 128 * 1024**2)) for name in ['tamarin-prover', 'maude']}
    assert identities == {'tamarin-prover': 'd6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f',
                          'maude': '266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf'}
    verify_installed('tamarin')
    member, original, original_contract = contract.load_frontier(ROOT, read)
    candidate, projected = project_support_proofs(original)
    with (OUT / 'original.spthy').open('xb') as stream:
        stream.write(original)
    state = {'completed': False, 'selected_theorem_verified': False, 'independent_replay_completed': False,
             'release_claim_eligible': False, 'selected_theorem': TARGET, 'source_member': member,
             'original_certificate_sha256': sha(original), 'candidate_input_sha256': sha(candidate),
             'operational_model_unchanged': True, 'all_40_query_contracts_unchanged': True,
             'all_query_attributes_unchanged': True, 'diagnostic_only_projected_proofs': projected,
             'reason': 'Separate target search from rechecking existing supporting proof bodies, following FRAGMENT_REPLAY.md. All original proofs must be restored before an independent full replay.',
             'distinction_from_previous_search': 'Previous search retained all 24 supporting proof bodies and changed two target hide attributes. This diagnostic projects all 39 other proof bodies and retains every original attribute.',
             'prior_failure_retained': 'research/sdk-alpha1/evidence/20261104-two-round-witness-search',
             'resource_limits': {'process_seconds': 900, 'heap_gib': 12, 'workers': 1, 'depth': 256, 'derivation_seconds': 60, 'compaction_percent': 30},
             'tool_sha256': identities, 'driver_sha256': sha(read(Path(__file__))),
             'concurrent_workload': 'Installed C Release qualification; no timing or resource-performance conclusion.'}
    write(OUT / 'PLAN.json', state)
    try:
        diagnostic, results = execute(candidate, '01-diagnostic', True)
        state['diagnostic_results'] = results
        if results[TARGET]['status'] != 'verified':
            state['remaining'] = 'Target remains incomplete. No automatic search retry.'
            return False
        fragments = collect_closed(original, diagnostic, TARGET)
        restored = restore(original, sha(original), TARGET, fragments)
        assert contract.theory(restored) == original_contract
        write(OUT / 'RESTORATION.json', {'fragment_paths': [list(item.case_path) for item in fragments],
              'restored_sha256': sha(restored), 'security_proof_verified': False,
              'complete_independent_replay_required': True})
        replay, replayed = execute(restored, '02-full-replay', False)
        assert replay == restored
        assert replayed[TARGET]['status'] == replayed[contract.MAIN]['status'] == 'verified'
        assert all(replayed[q.name]['status'] == 'verified' for q in original_contract.queries if q.reusable)
        assert sum(row['status'] == 'verified' for row in replayed.values()) >= 28
        assert {name: sha(read(TOOLS / name, 128 * 1024**2)) for name in identities} == identities
        assert contract.load_frontier(ROOT, read)[1] == original
        state.update(completed=True, selected_theorem_verified=True, independent_replay_completed=True,
                     final_certificate_sha256=sha(replay), final_results=replayed)
        return True
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(OUT / 'RESULT.json', state)


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
