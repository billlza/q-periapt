from pathlib import Path
import hashlib
import io
import json
import stat
import zipfile

import continuity_multi_epoch_search as contract

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-two-round-diagnostic'
RUN = BASE / 'run-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-two-round-diagnostic'
TOOLS = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/tools')
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
sha = lambda body: hashlib.sha256(body).hexdigest()
result = json.loads((RUN / 'RESULT.json').read_bytes())
terminal = json.loads((RUN / '01-diagnostic.terminal.json').read_bytes())
assert not result['completed'] and not result['selected_theorem_verified']
assert not result['independent_replay_completed'] and not terminal['accepted_execution']
assert terminal['returncode'] == 251 and terminal['elapsed_seconds'] < 900
assert 'Heap exhausted' in (RUN / '01-diagnostic.stderr').read_text()
assert not list(RUN.glob('*.proof.spthy')) and not (RUN / 'RESTORATION.json').exists()
original = (RUN / 'original.spthy').read_bytes()
diagnostic = (RUN / '01-diagnostic.input.spthy').read_bytes()
assert sha(original) == contract.MODEL_SHA256
assert sha(diagnostic) == result['candidate_input_sha256']
assert contract.theory(original) == contract.theory(diagnostic)
assert len(contract.theory(original).queries) == 40
for name, expected in result['tool_sha256'].items():
    assert sha((TOOLS / name).read_bytes()) == expected
assert sha((ROOT / contract.CAPTURE / 'CAPTURE.zip').read_bytes()) == contract.ARCHIVE_SHA256
files = {str(path.relative_to(BASE)): path.read_bytes() for path in sorted(RUN.rglob('*')) if path.is_file()}
for name in ['run.py', 'driver.stdout', 'driver.stderr', 'seal.py']:
    files[name] = (BASE / name).read_bytes()
for name in ['continuity_multi_epoch_search.py', 'continuity_proof_fragments.py']:
    files['checker/' + name] = (ROOT / 'artifact' / name).read_bytes()
readback = {'completed': False, 'evidence_readback_completed': True,
    'selected_theorem_verified': False, 'independent_replay_completed': False,
    'operational_and_query_contracts_unchanged': True, 'query_count': 40,
    'supporting_proof_bodies_projected_for_diagnosis': 39,
    'original_certificate_unchanged': True, 'fixed_tools_unchanged': True,
    'failure': 'Tamarin heap exhaustion, exit 251, no proof output.',
    'elapsed_seconds': terminal['elapsed_seconds'], 'configured_heap_bytes': 12884901888,
    'rts_maximum_residency_bytes': 11181761240, 'rts_total_memory_mib': 12480,
    'memory_scope': 'GHC RTS figures, not whole-process peak RSS.',
    'interpretation': 'Removing supporting proof-body replay did not close this target within the same resource bounds. No claim of an unreachable trace or a protocol counterexample.',
    'automatic_retry_performed': False, 'resource_limits_raised': False,
    'release_claim_eligible': False}
files['READBACK.json'] = encode(readback)
manifest = {name: {'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']), ('READBACK.json', files['READBACK.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
