from pathlib import Path
import hashlib,json,sys
import rust_sdk_profile as sdk
base=Path(sys.argv[1]);report=Path(sys.argv[2])
def read(name):return sdk.snapshot(base/name).data
identity=read('original.identity');prepared=read('prepared');assert len(identity)==64 and len(prepared)==164 and identity[32:]==prepared[4:36] and prepared[:4]==(1).to_bytes(4,'big') and not any(prepared[36:])
assert read('original.request')==read('activated.request') and read('final.identity')==identity==read('policy-renewed-identity')==read('roster-activated-identity')
unknown=read('policy-message-unknown');assert len(unknown)==64 and unknown[:32]==read('policy-connected') and read('policy-message-acknowledged')==unknown
assert read('policy-effect-before')==read('policy-effect-after')==unknown+b'persisted before process exit'
assert read('roster-peer-admitted.stdout')==b'peer-roster-admitted\n' and not read('roster-peer-admitted.stderr')
expiry=read('policy-expiry-observation');assert len(expiry)==32;until,at,renewed_at,target_until=[int.from_bytes(expiry[i:i+8],'big') for i in range(0,32,8)];assert until<=at<=renewed_at<target_until
assert read('expired-activation')==(104).to_bytes(4,'big') and read('expired-identity')==identity
for name,code in [('original-expired',104),('no-policy-fallback',1),('bad-signature',102),('cancelled',302)]:assert read('roster-'+name)==code.to_bytes(4,'big') and read('roster-'+name+'-identity')==identity
refreshed=read('roster-refreshed');assert len(refreshed)==148 and refreshed==read('roster-refreshed-replayed') and refreshed[:4]==(6).to_bytes(4,'big') and refreshed[4:68]==identity
assert refreshed[68:108]==read('inputs/trusted-roster-version')+read('inputs/trusted-roster-digest') and refreshed[108:]==read('inputs/renewal-version')+read('inputs/renewal-digest')
assert read('roster-pending-resolution')==(215).to_bytes(4,'big') and read('roster-local-completed')==(2).to_bytes(8,'big') and read('policy-process-count')==(43).to_bytes(8,'big')
status=read('policy-terminal');assert len(status)==160 and status[:4]==(2).to_bytes(4,'big') and status[40:72]==read('inputs/renewal-statement') and status[72:112]==read('inputs/policy-target/policy-version')+read('inputs/policy-target/policy-digest')
sdk.write_json(report,{'completed':True,'foreign_processes':43,'expired_original_refused':True,'unselected_target_refused':True,'same_original_identity_session_message':True,'business_effects':1,'staging_distinct_from_activation':True,'payload_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.is_file()}})
print('Verified local policy-roster '+str(base),flush=True)
