from pathlib import Path
import hashlib,json,shutil
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=root/'target/continuity-local-policy-roster';b=root/'target/continuity-android-roster-next';s=json.loads((b/'HARNESS_STATE.json').read_text());assert not s['live_producer'];source=Path(s['source']);tool=Path(s['environment']['RUSTC']).parent
pairs=[('android_policy_renewal.rs','android_policy_renewal.rs'),('android_policy_local_roster.rs','android_policy_renewal/local_roster.rs')]
sdk.command([str(tool/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(b/a) for a,_ in pairs]],out/'harness-rustfmt',root)
for a,z in pairs:shutil.copy2(b/a,source/'tests/common'/z)
s['live_producer']=True;(b/'HARNESS_STATE.json').write_text(json.dumps(s,indent=2)+'\n')
try:
 sdk.command([str(tool/'cargo'),'test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2'],out/'harness',source,environment=s['environment'])
 exe=c.built_artifact((out/'harness.stdout').read_bytes(),source,Path(s['environment']['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android');copy=out/'android-harness';shutil.copy2(exe,copy);sdk.write_json(out/'HARNESS.json',{'binary':str(copy),'sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'source':str(source),'sources':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'tests').rglob('*.rs')}})
 sdk.command([str(tool/'cargo'),'clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],out/'harness-clippy',source,environment=dict(s['environment'],CARGO_TARGET_DIR=str(Path(s['work'])/'clippy-build')))
finally:
 s['live_producer']=False;(b/'HARNESS_STATE.json').write_text(json.dumps(s,indent=2)+'\n')
print('Local selected-policy composition harness and strict Clippy passed',flush=True)
