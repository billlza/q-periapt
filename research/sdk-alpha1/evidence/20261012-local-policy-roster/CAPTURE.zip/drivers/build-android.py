from pathlib import Path
import hashlib,json,shutil,tempfile
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-local-policy-roster';old=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());assert old['completed'] and not old['live_producer'];settings=json.loads((root/'target/continuity-android-current/STATE.json').read_text());host=json.loads((root/'target/continuity-android-roster-next/HARNESS_STATE.json').read_text());env=host['environment']
for name,digest in old['source_sha256'].items():
 if name.startswith('research/continuity-identity-candidate/src/'):assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
work=Path(tempfile.mkdtemp(prefix='qperiapt-local-policy-roster-android-'));source=work/'source';shutil.copytree(old['android_source'],source);shutil.copytree(root/'bindings/c/ContinuityPackageConsumer/src',source/'src',dirs_exist_ok=True);shutil.copy2(root/'bindings/c/ContinuityPackageConsumer/qpc_owner.h',source/'qpc_owner.h')
tc=Path(settings['toolchain']);llvm=Path(settings['ndk'])/'toolchains/llvm/prebuilt/darwin-x86_64/bin';cc=llvm/'aarch64-linux-android23-clang';runtime=dict(env,CARGO_TARGET_DIR=str(work/'build'),CARGO_INCREMENTAL='0',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings -C link-arg=-Wl,-z,max-page-size=16384',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=str(cc),CC_aarch64_linux_android=str(cc),AR_aarch64_linux_android=str(llvm/'llvm-ar'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
record={'completed':False,'live_producer':True,'work':str(work),'source':str(source),'environment':runtime,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'bindings/c/ContinuityPackageConsumer/src').rglob('*.rs')}};(out/'ANDROID.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 sdk.command([str(tc/'bin/cargo'),'build','--offline','--locked','--lib','--target','aarch64-linux-android','--release','-j','2'],out/'android-native',source,environment=runtime)
 library=work/'build/aarch64-linux-android/release/libq_periapt_continuity_c_consumer.so';record.update(completed=True,library=str(library),library_sha256=hashlib.sha256(library.read_bytes()).hexdigest())
finally:
 record['live_producer']=False;(out/'ANDROID.json').write_text(json.dumps(record,indent=2)+'\n')
print('Explicit local policy Android arm64 native engine built',flush=True)
