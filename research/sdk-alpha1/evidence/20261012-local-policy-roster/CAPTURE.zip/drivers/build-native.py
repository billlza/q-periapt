from pathlib import Path
import hashlib,json,shutil
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-local-policy-roster';old=json.loads((root/'target/continuity-android-roster-next/HARNESS_STATE.json').read_text());assert not old['live_producer'];source=Path(old['source']);env=old['environment'];tool=Path(env['RUSTC']).parent
changed=['src/enrollment.rs','src/enrollment/roster_refresh.rs','src/configuration/tests.rs','src/configuration/tests/roster_policy.rs']
sdk.command([str(tool/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(root/'bindings/c/ContinuityPackageConsumer'/p) for p in changed]],out/'rustfmt',root)
for name in changed:shutil.copy2(root/'bindings/c/ContinuityPackageConsumer'/name,source/name)
shutil.copy2(root/'bindings/c/ContinuityPackageConsumer/qpc_owner.h',source/'qpc_owner.h')
record={'completed':False,'live_producer':True,'source':str(source),'environment':env,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'bindings/c/ContinuityPackageConsumer/src').rglob('*.rs')},'native':{'execution':{}}};(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 sdk.command([str(tool/'cargo'),'test','--offline','--locked','--lib','-j','2'],out/'native-tests',source,environment=env)
 sdk.command([str(tool/'cargo'),'clippy','--offline','--locked','--lib','--tests','-j','2','--','-D','warnings'],out/'native-clippy',source,environment=dict(env,CARGO_TARGET_DIR=str(Path(old['work'])/'clippy-build')))
 cc=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],out/'clang',root).decode().strip();platform=str(Path(sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],out/'sdk-path',root).decode().strip()).resolve(strict=True))
 for profile in ['debug','release']:
  sdk.command([str(tool/'cargo'),'rustc','--offline','--locked','--lib','-j','2']+(['--release'] if profile=='release' else [])+['--','-C','link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib'],out/('native-'+profile),source,environment=env)
  folder=out/('engine-'+profile);folder.mkdir();library=folder/'libq_periapt_continuity_c_consumer.dylib';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/profile/library.name,library);binaries={'C_library':{'path':str(library),'sha256':hashlib.sha256(library.read_bytes()).hexdigest()}}
  for key,name,files in [('C_client','qpc-c-client',['client.c','recovery_client.c','opening_client.c']),('configuration_client','qpc-configuration-client',['first_configuration_client.c'])]:
   exe=folder/name;sdk.command([cc,'-isysroot',platform,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread',*(['-O2'] if profile=='release' else ['-O0','-g']),*[str(source/f) for f in files],'-I'+str(source),'-L'+str(folder),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(exe)],out/(name+'-'+profile),source,environment=env);binaries[key]={'path':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
  record['native']['execution'][profile]={'binaries':binaries};(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
 record['completed']=True
finally:
 record['live_producer']=False;(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
print('Explicit local-policy C ABI tests and Debug/Release engines complete',flush=True)
