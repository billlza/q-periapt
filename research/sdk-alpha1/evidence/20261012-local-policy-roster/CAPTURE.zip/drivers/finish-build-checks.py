from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_swift_consumer as sw
import continuity_kotlin_consumer as kt
root=Path.cwd();out=root/'target/continuity-local-policy-roster';state=json.loads((out/'STATE.json').read_text());source=Path(state['source']);env=state['environment'];receipt=json.loads((out/'harness.json').read_text());assert receipt['returncode']==0
exe=c.built_artifact((out/'harness.stdout').read_bytes(),source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android');copy=out/'android-harness';assert hashlib.sha256(exe.read_bytes()).digest()==hashlib.sha256(copy.read_bytes()).digest()
sdk.write_json(out/'EXECUTABLE.json',{'binary':str(copy),'sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'source':str(source),'sources':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'tests').rglob('*.rs')}})
s=sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],out/'harness-clippy',source,environment=dict(env,CARGO_TARGET_DIR=str(Path(source).parent/'clippy-build')))
bind=out/'bindings-v2';sr=json.loads((bind/'swift-test.json').read_text());kr=json.loads((bind/'kotlin-test.json').read_text());assert sr['returncode']==kr['returncode']==0
sw.verify_tests((bind/'swift-test.stdout').read_bytes(),(bind/'swift-test.stderr').read_bytes());swift=Path(sr['argv'][sr['argv'].index('--package-path')+1]);kotlin=Path(kr['argv'][kr['argv'].index('--project-dir')+1]);assert all((kotlin/name).read_bytes()==data for name,data in kt.source_files().items());assert (swift/'Sources/QPeriaptContinuity/Enrollment.swift').read_bytes()==(root/'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity/Enrollment.swift').read_bytes();reports=kt.retain_test_reports(kotlin/'build/test-results/test',bind,profile='debug')
sdk.write_json(bind/'VERIFIED.json',{'completed':True,'swift_source':str(swift),'kotlin_source':str(kotlin),'kotlin_tests':reports,'scope':'Strict source builds and real-library owner tests; installed end-to-end package validation remains separate.','native_sha256':state['native']['execution']['debug']['binaries']['C_library']['sha256'],'retained_setup_failures':['bounded runner disallows worker-thread use; v2 ran sequentially','report profile local-policy refused; actual debug result revalidated and exported'],'harness_receipt':'EXECUTABLE.json'})
print('Successful compiler/test outputs revalidated; owner reports and harness receipt completed',flush=True)
