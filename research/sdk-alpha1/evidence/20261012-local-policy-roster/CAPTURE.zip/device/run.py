from pathlib import Path
import hashlib,json,re,subprocess,shutil
import rust_sdk_profile as sdk
root=Path.cwd();out=Path(__file__).resolve().parent;native=root/'target/continuity-local-policy-roster';state=json.loads((native/'STATE.json').read_text());assert state['completed'] and not state['live_producer'];saved=json.loads((native/'EXECUTABLE.json').read_text());source=Path(saved['source']);env=state['environment'];binary=out/'android-harness';shutil.copy2(saved['binary'],binary);assert hashlib.sha256(binary.read_bytes()).hexdigest()==saved['sha256'];assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==digest for name,digest in saved['sources'].items())
row=state['native']['execution']['debug']['binaries'];h={'copied_sha256':saved['sha256'],'test_sources':saved['sources'],'receiver':row['C_client']['path'],'target_client':row['configuration_client']['path']};sdk.write_json(out/'EXECUTABLE.json',h)
package=json.loads((out/'PACKAGE.json').read_text())
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest
def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.localpolicyroster20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(path.read_text())
  if not state.get('installation_attempted') or (state.get('cleanup') and not state.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
  def call(args):
   result=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(state.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);state['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;path.write_text(json.dumps(state,indent=2)+'\n')
results={}
try:
 for trust in ['fixed','recoverable']:
  name='roster_local_'+trust;cases=out/('cases-'+name);runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=h['receiver'],QPC_CONFIGURATION_TARGET_CLIENT=h['target_client'])
  stdout=sdk.command([str(binary),'--exact','android_policy_renewal::'+name,'--nocapture'],out/name,source,environment=runtime)
  assert stdout.count(b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 22 filtered out;')==1
  label='local-'+trust;count=int.from_bytes((cases/label/'policy-process-count').read_bytes(),'big');assert count==43
  assert stdout.count(('qualified policy renewal local/'+trust+': 43 foreign processes; expired P0, independent P2, original identity session message and one effect').encode())==1
  results[name]={'foreign_processes':count,'case':str(cases/label),'trust':trust,'device_label':label}
  sdk.write_json(out/('OUTCOME-'+name+'.json'),results[name])
 sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('local policy-roster qualification and owned cleanup failed',[original,failure])
 raise
print('86 ART explicit local-policy roster calls passed on the accepted phone',flush=True)
