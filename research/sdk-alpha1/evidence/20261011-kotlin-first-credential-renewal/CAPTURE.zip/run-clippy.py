from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main/"target/peer-account-retirement-process-current/source"
base=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=Path(base["outside"])/"c-consumer-kotlin-first-credential-01"
label,mode=sys.argv[1:3];assert mode in ("clippy","msrv-clippy")
run=out/label;run.mkdir()
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file() and not p.is_relative_to(consumer/"target")}
version="1.90.0" if mode=="msrv-clippy" else "1.98.1"
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains")/(version+"-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/("build-msrv" if mode=="msrv-clippy" else "build-authority-clippy")),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"))
if mode=="export":
    fixture_output=run/"fixtures"
    fixture_output.mkdir(mode=0o700)
    env["QPC_AUTHORITY_FIXTURE"]=str(fixture_output)
command="clippy" if mode.endswith("clippy") else "build" if mode=="build" else "test"
args=[str(tc/"bin/cargo"),command,"--locked","--offline","-j","2"]
args += ["--all-targets"] if command=="clippy" else ["--lib"]
if mode in ("focused","export"):args += ["authority_registry", "--", "--nocapture", "--test-threads=1"]
r={"label":label,"mode":mode,"command":args,"consumer":str(consumer),"source_sha256":files,"candidate_archive":base["candidate_archive"],"completed":False}
(run/"START.json").write_text(json.dumps(r,indent=2)+"\n")
start=time.monotonic()
with (run/"stdout").open("wb") as so,(run/"stderr").open("wb") as se:
    p=subprocess.Popen(args,cwd=consumer,env=env,stdout=so,stderr=se,start_new_session=True)
    try:code=p.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGTERM)
        try:p.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        raise
r.update(returncode=code,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items()))
r["completed"]=code==0 and r["source_unchanged"]
(run/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps({k:v for k,v in r.items() if k!="source_sha256"}));print((run/"stdout").read_text(errors="replace")[-2200:]);print((run/"stderr").read_text(errors="replace")[-2600:]);raise SystemExit(0 if r["completed"] else 1)
