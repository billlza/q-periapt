from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,time,shlex
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main
sys.path.insert(0,str(src/"artifact"))
import continuity_c_consumer as c
import continuity_c_authority as authority
base=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=root/"c-consumer-kotlin-first-credential-01"
run_dir=out/sys.argv[1];run_dir.mkdir()
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","JDK","GRADLE","KOTLIN")) and k not in ("_JAVA_OPTIONS","CLASSPATH")}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build-kotlin-first-credential-01"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"),DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
record={"source_sha256":files,"consumer":str(consumer),"candidate_archive":base["candidate_archive"],"runs":[],"profiles":{},"completed":False,"release_claim_eligible":False}
(run_dir/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(argv,label,cwd=consumer,*,runtime=None):
    start=time.monotonic()
    with (run_dir/(label+".stdout")).open("wb") as so,(run_dir/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(argv,cwd=cwd,env=env if runtime is None else runtime,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":argv,"returncode":code,"seconds":time.monotonic()-start})
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; retained stderr")
    return (run_dir/(label+".stdout")).read_bytes()

import continuity_first_configuration as configuration
runtime={k:v for k,v in env.items() if not k.startswith(("DYLD","LD_"))}
client_record=json.loads((out/"client-01/RESULT.json").read_text());assert client_record["completed"]
java=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java")
classpath=os.pathsep.join(sorted(client_record["jars"]))
record["jars"]=client_record["jars"]
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in record["jars"].items())
scope=root/sys.argv[1];scope.mkdir(mode=0o700)
mode,profile,collector=sys.argv[2:5]
assert mode in ("credential","policy","ordinary") and profile in ("debug","release") and collector in ("Serial","G1")
prepared=json.loads((out/"prepared-01/RESULT.json").read_text());item=prepared["profiles"][profile]
assert all(r["returncode"]==0 for r in prepared["runs"])
helper=Path(item["helper"]);assert hashlib.sha256(helper.read_bytes()).hexdigest()==item["helper_sha256"]
installed=root/("first-credential-installed-"+profile+"-05")
filename="libq_periapt_continuity_c_consumer.dylib"
expected={"debug":"e323b3f77f45a18862bd5bb43b169e9505d9ce8f87604dc66fd5bd13e8f8360d","release":"e22c4b7b1533916800f059032b31f740538d0bd6979d78a17577ede58a1e0b8b"}
assert hashlib.sha256((installed/filename).read_bytes()).hexdigest()==expected[profile]
selected=dict(runtime,QPERIAPT_C_OWNER_CLIENT=str(installed/"qpc-c-client"))
client=scope/("configuration-"+profile+"-"+collector.lower())
command=[str(java),"-Xms32m","-Xmx128m","-XX:+Use"+collector+"GC","--enable-native-access=ALL-UNNAMED","--illegal-native-access=deny","-Dqperiapt.continuity.lib="+str(installed/filename),"-cp",classpath,"configuration.FirstConfigurationClientKt"]
with client.open("x") as f:f.write("#!/bin/sh\nexec "+shlex.join(command)+' "$@"\n')
client.chmod(0o700)
checked=configuration._qualify(scope,run_dir,profile,selected,helper,client,run,receiver=installed/"qpc-c-client",language="Kotlin",collector=collector,managed=mode!="ordinary",credential=mode=="credential")
record["profiles"][profile]={collector:checked,"native_library":{"path":str(installed/filename),"sha256":expected[profile]}}
record["command"]=command
assert hashlib.sha256((installed/filename).read_bytes()).hexdigest()==expected[profile]
record["inputs_unchanged"]=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
record["jars_unchanged"]=all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in record["jars"].items())
record["completed"]=record["inputs_unchanged"] and record["jars_unchanged"]
(run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"completed":record["completed"],"profiles":list(record["profiles"]),"inputs_unchanged":record["inputs_unchanged"],"jars_unchanged":record["jars_unchanged"]}),flush=True)
