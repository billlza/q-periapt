from pathlib import Path
import hashlib,json,re,subprocess,zipfile
base=Path(__file__).resolve().parent
main=base.parent.parent
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=main,text=True).strip()
assert head=="0e92593a72ef56e1fa61ccbb9c3faefe0033091b"
variants=[(p,g) for p in ("debug","release") for g in ("serial","g1")]
labels=[f"kotlin-{kind}-{p}-{g}-02" for kind in ("credential","policy","ordinary") for p,g in variants]
labels += ["prepared-01","client-02","clippy-current","clippy-msrv"]
runs={n:json.loads((base/n/"RESULT.json").read_text()) for n in labels}
assert all(r["completed"] for r in runs.values())
for name,r in runs.items():
    assert r.get("inputs_unchanged",r.get("source_unchanged",False))
    if name.startswith("kotlin-"): assert r["jars_unchanged"]
    prefix="bindings/kotlin/ContinuityPackageConsumer/consumer" if name=="client-02" else "bindings/c/ContinuityPackageConsumer"
    for relative,digest in r["source_sha256"].items():
        if relative.startswith(("src/","tests/","negative/")):
            assert hashlib.sha256((main/prefix/relative).read_bytes()).hexdigest()==digest,(name,relative)
assert re.search(r"Ran 89 tests in .+\n\nOK\n",(base/"readers-full-git.stderr").read_text())
assert head in (base/"source-gate.stdout").read_text()
assert not (base/"fmt-after.stdout").read_bytes() and not (base/"fmt-after.stderr").read_bytes()
files=[]
for name in labels:
    for f in (base/name).rglob("*"):
        if f.is_file():
            assert not f.is_symlink() and f.suffix not in (".key",".redb",".dylib",".jar")
            files.append((f,name+"/"+f.relative_to(base/name).as_posix()))
for label in ("client-01","kotlin-credential-debug-serial-01"):
    for f in (base/label).iterdir():
        if f.is_file(): files.append((f,label+"/"+f.name))
for name in ("prepare.py","build-client.py","run.py","run-final.py","run-clippy.py","seal-evidence.py","readers.stdout","readers.stderr","readers-full-git.stdout","readers-full-git.stderr","source-gate.stdout","source-gate.stderr","fmt-before.stdout","fmt-before.stderr","fmt-after.stdout","fmt-after.stderr","consumer-fmt-prepared.stdout","consumer-fmt-prepared.stderr","consumer-fmt-baseline.stdout","consumer-fmt-baseline.stderr","FORMAT_CHECK.json","SDK_BASELINE_IDENTITY.json","WORKFLOW_CHECK.json","actionlint-before.json","actionlint-current.json","CI_BUDGET.json","CI_FAILURE.json","CI_CURRENT.json"):
    files.append((base/name,name))
output=main/"research/sdk-alpha1/evidence/20261011-kotlin-first-credential-renewal"
output.mkdir()
archive=output/"CAPTURE.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED) as z:
    for f,name in sorted(files,key=lambda pair:pair[1]): z.write(f,name)
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
profiles={}
for profile,gc in variants:
    profiles[profile+"-"+gc]={kind:runs[f"kotlin-{kind}-{profile}-{gc}-02"]["profiles"][profile] for kind in ("credential","policy","ordinary")}
checks={"source_commit":head,"completed":True,"release_claim_eligible":False,
"scope":"Installed Kotlin first-use managed credential renewal to a C peer on macOS arm64, Debug/Release and Serial/G1; same host and shared native engine.",
"validation":{"credential_scenarios":16,"managed_policy_regression_scenarios":16,"ordinary_regression_scenarios":24,"reader_and_inventory_tests":89,"strict_Clippy":["1.90.0","1.98.1"],"strict_Gradle":"offline, dependency verification strict, warning-mode fail, Kotlin warnings as errors","workspace_fmt":"passed","source_gate":"passed"},
"implementation_identity":"Current external Kotlin consumer and Rust/C harness byte-match the source commit. SDK implementation/build sources and exact Maven artifact match the earlier installed baseline; README differs. Native libraries remain the frozen 6d70c614 binaries. Prior SDK unit tests are not counted as rerun.",
"candidate_archive":runs["prepared-01"]["candidate_archive"],
"Maven":runs["client-02"]["maven"],"jars":runs["client-02"]["jars"],
"profiles":profiles,
"invariants":["Original signer, journal, session and message survive credential renewal after actual expiry","Fresh request and old activation remain refused after expiry (104)","Altered grant refuses authentication and retires the owner (102 then 2)","Closed or missing account authority refuses new Commit (202 or 211)","One real signed witness Commit is applied and its response is lost (218)","Historical recovery and terminal replay send no new Commit and need no selected registry","Historical recovery still cannot activate without current registry admission (211)","The C peer separately admits the signed grant and original message reaches acknowledged with one host effect","Registry release is observed through weak-reference enqueueing, positive GC counts and reclamation of 63 native slots; reopening does not revive old selections"],
"diagnostic":{"run":"kotlin-credential-debug-serial-01","cause":"First adapter closed the registry inside a renewal helper, then main cleanup closed it again. The original expected 202 was followed by a real close status 2. Moved registry ownership mutation to main and nulled the cleanup reference; retained SDK error semantics.","control":"Original installed client-01 and failed runtime logs retained; all four final variants use a distinct client-02 artifact."},
"maintainability":"Renewal identity readback, status encoding, staging and commit/reconciliation are separate functions. Registry lifetime mutation remains at the caller that owns cleanup. No native ABI or library implementation change.",
"parser_fixture":{"file":"artifact/fixtures/first-credential-kotlin-public-v1.zip","sha256":hashlib.sha256((main/"artifact/fixtures/first-credential-kotlin-public-v1.zip").read_bytes()).hexdigest(),"scope":"Actual Debug/Serial public records; reader controls test metadata/grammar linkage and GC observation, not independent signature verification."},
"format":json.loads((base/"FORMAT_CHECK.json").read_text()),
"workflow":json.loads((base/"WORKFLOW_CHECK.json").read_text()),
"CI_failure":json.loads((base/"CI_FAILURE.json").read_text()),
"CI_at_capture":json.loads((base/"CI_CURRENT.json").read_text()),
"limits":["No independent engine, physical-device, cross-platform or full release qualification","No throughput, RSS or energy improvement measured","Prepared consumer formatting has one verified pre-existing peer_bundle.rs style difference; no new consumer format diagnostics","Local actionlint retains two identical pre-existing runner-label catalog diagnostics"],
"capture":{"file":"CAPTURE.zip","sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"bytes":archive.stat().st_size,"members":len(files)}}
(output/"CHECKS.json").write_text(json.dumps(checks,indent=2)+"\n")
print(json.dumps({"completed":True,"capture":checks["capture"]}))
