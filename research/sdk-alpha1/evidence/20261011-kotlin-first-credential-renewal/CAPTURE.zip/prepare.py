from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main
sys.path.insert(0,str(src/"artifact"))
import continuity_c_consumer as c
import continuity_c_authority as authority
base=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=root/"c-consumer-kotlin-first-credential-01"
run_dir=out/sys.argv[1];run_dir.mkdir()
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build-kotlin-first-credential-01"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"),DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer")
shutil.copytree(root/"c-consumer-first-credential-05",consumer)
shutil.copy2(main/"bindings/c/ContinuityPackageConsumer/tests/first_configuration.rs",consumer/"tests/first_configuration.rs")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
record={"source_sha256":files,"consumer":str(consumer),"candidate_archive":base["candidate_archive"],"runs":[],"profiles":{},"completed":False,"release_claim_eligible":False}
(run_dir/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(argv,label,cwd=consumer,*,runtime=None):
    start=time.monotonic()
    with (run_dir/(label+".stdout")).open("wb") as so,(run_dir/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(argv,cwd=cwd,env=env if runtime is None else runtime,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":argv,"returncode":code,"seconds":time.monotonic()-start})
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; retained stderr")
    return (run_dir/(label+".stdout")).read_bytes()


for profile in ("debug","release"):
    extra=["--release"] if profile=="release" else []
    built=run([str(tc/"bin/cargo"),"test","--locked","--offline","--test","first_configuration","--no-run","--message-format=json","-j","2",*extra],"helper-build-"+profile)
    helper=c.built_artifact(built,consumer,root/"build-kotlin-first-credential-01"/profile,library=False,test_name="first_configuration")
    record["profiles"][profile]={"helper":str(helper),"helper_sha256":hashlib.sha256(helper.read_bytes()).hexdigest()}
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
record["inputs_unchanged"]=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
record["completed"]=record["inputs_unchanged"]
(run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"completed":record["completed"],"profiles":list(record["profiles"])}),flush=True)
