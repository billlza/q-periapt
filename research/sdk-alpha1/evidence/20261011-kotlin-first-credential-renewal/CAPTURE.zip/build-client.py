from pathlib import Path
import json,subprocess,os,shutil,hashlib,time,sys
out=Path(__file__).resolve().parent
main=out.parent.parent
sys.path.insert(0,str(main/"artifact"))
import continuity_kotlin_consumer as k
import jvm_sdk_package as jvm
meta=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text());root=Path(meta["outside"])
label=sys.argv[1];run=out/label;run.mkdir()
consumer=root/("kotlin-first-credential-consumer-"+label)
shutil.copytree(main/"bindings/kotlin/ContinuityPackageConsumer/consumer",consumer)
repo=root/"kotlin-authority-maven";maven=jvm.verify_maven(repo,contract=k.maven_contract())
jvm.pin_consumer_dependencies(consumer,repo,contract=k.maven_contract())
base=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed");java=base/"jdk-25.0.4.1+1/Contents/Home";gradle=base/"gradle-9.8.0/bin/gradle"
env={a:v for a,v in os.environ.items() if not a.startswith(("JAVA","JDK","GRADLE","KOTLIN","CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON")) and a not in ("_JAVA_OPTIONS","CLASSPATH")}
env.update(JAVA_HOME=str(java),GRADLE_USER_HOME=str(root/"kotlin-authority-gradle-home"),PATH=str(java/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
args=[str(gradle),"--no-daemon","--offline","--warning-mode","fail","--dependency-verification","strict","--max-workers","2","-Dorg.gradle.java.installations.auto-download=false","-Pkotlin.compiler.execution.strategy=in-process","-Dorg.gradle.java.home="+str(java),"--project-dir",str(consumer),"installDist","recordRuntime","-Pqperiapt.repository="+str(repo)]
r=dict(command=args,consumer=str(consumer),repository=str(repo),maven=maven,source_sha256=files,completed=False)
(run/"START.json").write_text(json.dumps(r,indent=2)+"\n");start=time.monotonic()
with (run/"stdout").open("wb") as so,(run/"stderr").open("wb") as se:
 p=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,timeout=1200)
r.update(returncode=p.returncode,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((consumer/name).read_bytes()).hexdigest()==value for name,value in files.items()),maven_unchanged=jvm.verify_maven(repo,contract=k.maven_contract())==maven)
(run/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
if p.returncode:
 print((run/"stdout").read_text()[-4500:]);print((run/"stderr").read_text()[-4500:]);p.check_returncode()
distribution=consumer/"build/install/continuity-installed-consumer"
r["runtime"]=k.runtime_closure(k.sdk.snapshot(consumer/"build/runtime.tsv").data,distribution,maven["jar_sha256"],root)
r["distribution"]=str(distribution)
r["jars"]={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (distribution/"lib").iterdir() if p.is_file()}
r["completed"]=r["source_unchanged"] and r["maven_unchanged"]
(run/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps({x:r[x] for x in ("completed","seconds","distribution")}))
