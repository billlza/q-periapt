"""Continue the same prototype, preserving the original failed manifest and graph."""
from pathlib import Path
import hashlib,json,os,sys
root=Path.cwd();out=root/'target/independent-installed-01/build-01';sys.path.insert(0,str(root/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
from installed_rust_graph import verify_resolution,external_lock
private=Path(json.loads((out/'LOCATION.json').read_text())['path']);consumer=private/'counterpart'
report=root/'target/independent-installed-01/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json';cohort=json.loads(report.read_text());packages=sdk.classify(json.loads((out/'workspace-metadata.stdout').read_text()))
manifest=consumer/'Cargo.toml';before=manifest.read_bytes();(out/'consumer-manifest-before-repair.toml').write_bytes(before)
s=before.decode();assert s.count('[workspace]\n')==1;s=s.replace('[workspace]\n','[workspace]\nexclude = ["packages/*"]\n')
name='q-periapt-rustls';row=cohort['crates'][name];value=sdk.snapshot(report.parent/'crates'/row['file']);assert value.sha256==row['sha256']
for relative,body in sdk.validate_archive(value.data,name,packages[name],set(row['files'])).items():
 p=consumer/'packages'/f'{name}-{sdk.VERSION}'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
s+=f'{name} = {{ path = "packages/{name}-{sdk.VERSION}" }}\n';manifest.write_text(s);sdk.copy(manifest,out/'consumer-Cargo.toml')
toolchain=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_','QPC_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(private/'consumer-build'),CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',RUSTC=str(toolchain/'bin/rustc'),RUSTDOC=str(toolchain/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'),PATH=str(toolchain/'bin')+os.pathsep+os.environ.get('PATH',os.defpath))
cargo=[str(toolchain/'bin/cargo')]
def run(argv,label):return sdk.command(argv,out/label,consumer,environment=env)
resolved=json.loads(run([*cargo,'metadata','--offline','--format-version','1'],'consumer-metadata-02'))
print('resolved product',[p['name']for p in resolved['packages']if p['name'].startswith('q-periapt')],flush=True)
original=(root/'research/continuity-openssl-peer/native/Cargo.lock').read_bytes()
versions={**dict.fromkeys((n for n in sdk.CONSUMER_CRATES if n!='q-periapt-rustls'),sdk.VERSION),package.NAME:package.VERSION}
result=verify_resolution(resolved,consumer,(consumer/'Cargo.lock').read_bytes(),original,consumer_name='q-periapt-independent-peer-counterpart',versions=versions)
(out/'RESOLUTION.json').write_text(json.dumps(result,indent=2)+'\n');sdk.copy(consumer/'Cargo.lock',out/'consumer-Cargo.lock')
run([*cargo,'build','--release','--locked','--offline','-j','2'],'consumer-build')
run([*cargo,'clippy','--release','--locked','--offline','--all-targets','-j','2','--','-D','warnings'],'consumer-clippy')
binary=private/'consumer-build/release/q-periapt-independent-peer-counterpart';sdk.copy(binary,out/'counterpart')
print(json.dumps({'native_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'completed':True}))
