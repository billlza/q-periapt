"""Prototype a counterpart built outside the checkout from verified Cargo archives."""
from pathlib import Path
import hashlib,json,os,sys,tempfile,tomllib
root=Path.cwd();out=root/'target/independent-installed-01/build-01';out.mkdir()
sys.path.insert(0,str(root/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
from rust_sdk_msrv import validate_report
from installed_rust_graph import verify_resolution
from evidence_io import parse_strict_json_bytes
sha=lambda b:hashlib.sha256(b).hexdigest()
report=root/'target/independent-installed-01/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json';data=report.read_bytes()
cohort=validate_report(data,sha(data),sha(data),sdk.source_identity()['rust_workspace_sha256'])
toolchain=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e')
private=Path(tempfile.mkdtemp(prefix='qperiapt-independent-installed-')).resolve();assert not private.is_relative_to(root)
(out/'LOCATION.json').write_text(json.dumps({'path':str(private)},indent=2)+'\n')
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_','QPC_'))}
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(private/'producer-build'),CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',RUSTC=str(toolchain/'bin/rustc'),RUSTDOC=str(toolchain/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'),PATH=str(toolchain/'bin')+os.pathsep+os.environ.get('PATH',os.defpath))
cargo=[str(toolchain/'bin/cargo')]
def run(argv,label,cwd=root,*,env=None):return sdk.command(argv,out/label,cwd,environment=environment if env is None else env)
environment=env
result={'completed':False,'sdk_report_sha256':sha(data),'sdk_source_commit':cohort.get('source_commit'),'outside':str(private),'source_inputs':{}}
try:
 metadata=parse_strict_json_bytes(run([*cargo,'metadata','--locked','--offline','--no-deps','--format-version','1'],'workspace-metadata'),label='SDK metadata');packages=sdk.classify(metadata)
 record,candidate=package.package_candidate(cargo,private/'producer',private/'producer-build',report.parent,cohort,packages,out,run,environment);result['candidate_archive']=record
 consumer=private/'counterpart';consumer.mkdir()
 source=root/'research/continuity-openssl-peer/native'
 for p in sorted((source/'src').glob('*.rs')):
  data=p.read_bytes();sdk.copy(p,consumer/'src'/p.name);result['source_inputs']['src/'+p.name]=sha(data)
 original=(source/'Cargo.toml').read_bytes();manifest=tomllib.loads(original.decode());text=original.decode()
 for name,dep in manifest['dependencies'].items():
  if not name.startswith('q-periapt'):continue
  assert type(dep)is dict and set(dep)=={'path'}
  version=package.VERSION if name==package.NAME else sdk.VERSION
  old=f'{name} = {{ path = "{dep["path"]}" }}';assert text.count(old)==1
  text=text.replace(old,f'{name} = {{ version = "={version}", path = "packages/{name}-{version}" }}')
 product=tuple(n for n in sdk.CONSUMER_CRATES if n!='q-periapt-rustls')
 text+='\n[patch.crates-io]\n'+''.join(f'{name} = {{ path = "packages/{name}-{sdk.VERSION}" }}\n'for name in product)
 (consumer/'Cargo.toml').write_text(text);result['source_inputs']['Cargo.toml']=sha(original)
 for name in product:
  row=cohort['crates'][name];archive=sdk.snapshot(report.parent/'crates'/row['file']);assert archive.sha256==row['sha256']
  members=sdk.validate_archive(archive.data,name,packages[name],set(row['files']))
  for relative,body in members.items():
   p=consumer/'packages'/f'{name}-{sdk.VERSION}'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 for relative,body in candidate.items():
  p=consumer/'packages'/f'{package.NAME}-{package.VERSION}'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 sdk.copy(source/'Cargo.lock',consumer/'Cargo.lock');original_lock=(source/'Cargo.lock').read_bytes()
 environment=dict(env,CARGO_TARGET_DIR=str(private/'consumer-build'))
 resolved=parse_strict_json_bytes(run([*cargo,'metadata','--offline','--format-version','1'],'consumer-metadata',consumer),label='installed counterpart graph')
 result['resolution']=verify_resolution(resolved,consumer,(consumer/'Cargo.lock').read_bytes(),original_lock,consumer_name=manifest['package']['name'],versions={**dict.fromkeys(product,sdk.VERSION),package.NAME:package.VERSION})
 sdk.copy(consumer/'Cargo.lock',out/'consumer-Cargo.lock')
 run([*cargo,'build','--release','--locked','--offline','-j','2'],'consumer-build',consumer)
 run([*cargo,'clippy','--release','--locked','--offline','--all-targets','-j','2','--','-D','warnings'],'consumer-clippy',consumer)
 binary=private/'consumer-build/release/q-periapt-independent-peer-counterpart';sdk.copy(binary,out/'counterpart');result['native_sha256']=sha(binary.read_bytes());result['completed']=True
except Exception as error:result['failure']=str(error);raise
finally:(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in {'source_inputs','candidate_archive'}}))
