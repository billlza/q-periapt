"""Seal installed-counterpart provenance and actual original-owner execution."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;formal=out/'source-checkout/target/installed-counterpart-02'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
installation=read(out/'INSTALLATION_READBACK.json');registration=read(out/'REGISTRATION_READBACK.json')
assert installation['native_sha256']==registration['native_sha256']==sha((out/'counterpart').read_bytes())
assert read(out/'FORMAL_CLONE_EXIT_02.json')['exit']==read(out/'RUNTIME_EXIT.json')['exit']==0
assert not any((out/n).read_bytes()for n in ['formal-clone-02.stderr','registration.stderr','review-installation.stderr','review-registration.stderr','actionlint.stderr'])
entries={};private_magic=(b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPREGS01',b'QPRFLC01',b'QPRFLI01',*(('QPREFS0'+str(i)).encode()for i in range(1,9)))
def add(name,body):
 assert name not in entries and not body.startswith(private_magic),name
 entries[name]=body

def tree(prefix,source):
 for p in sorted(source.rglob('*')):
  if p.is_file():
   assert not p.is_symlink()and p.name not in {'head','intent','authority','configuration','signer','key'}and not p.name.startswith('.stage-'),str(p)
   add(prefix+'/'+p.relative_to(source).as_posix(),p.read_bytes())
for p in sorted(out.iterdir()):
 if p.is_file()and(p.suffix in {'.py','.json','.stdout','.stderr','.txt'}or p.name in {'counterpart','sdk.zip'}):add('validation/'+p.name,p.read_bytes())
for p in sorted(formal.iterdir()):
 if p.is_file():add('formal/'+p.name,p.read_bytes())
for p in sorted((out/'source-checkout/target/installed-counterpart-01').iterdir()):
 if p.is_file():add('failed-formal/'+p.name,p.read_bytes())
for p in sorted((out/'build-01').iterdir()):
 if p.is_file():add('prototype/'+p.name,p.read_bytes())
tree('registration',out/'registration-01');tree('source',out/'source');tree('reader-program',out/'reader-program')
for n,h in read(formal/'INSTALLED_COUNTERPART.json')['source_inputs'].items():
 b=subprocess.check_output(['git','show',installation['head']+':'+n]);assert sha(b)==h;add('build-source/'+n,b)
for n in ['.github/workflows/independent-continuity.yml','artifact/continuity_independent_package.py','artifact/test_continuity_independent_package.py','research/continuity-openssl-peer/README.md']:
 add('current-integration/'+n,(root/n).read_bytes())
for name,body in list(entries.items()):
 if name in {'registration/local/private-fixture-path','registration/witness/private-fixture-path'}:
  config=Path(body.decode().strip())/'configuration';value=config.read_bytes();assert len(value)==2121;secret=value[:32]
  assert not any(secret in b for b in entries.values()),'private wrapping value in selected evidence'
scope={'build_head':installation['head'],'scope':installation['scope'],'qualification':'PublicCLI releasebuild/strictClippy fromcleanordinarycheckout,7helper/selectiontests,actionlint/diffcheck,actual92worker/21SIGKILL local+witness registration and2publicreaders. Source/provenance checks not replaced by packaging success.',
 'source_continuity':'Formalbuild69d478e1. CurrentCI dispatchselection adds onlyoneunused-by-buildfunction plus import; everyexistingbuildfunction ASTidentical (QUALITY.json). Actual peer99closure unchanged. CI installedmode still pending.',
 'failures':'Prototype path dependencies autojoinedworkspace; wildcardexclusion failed; literalexclusions restoredroot-onlymembership; unusedRustls patch thenremoved. Finalgraphfullnative lock exactlyunchanged. PublicCLI linkedworktree refused; samecommit normalcloneused withoutweakeninggate. DuplicateCargo.lockcopy failed; fixedonce withnewsetupregression. Originalprivatebuilddirs/failedreports retained.',
 'limits':'Same-host independent Python source + archive-installed Rust counterpart overcontrolpipe/trustedfixtureissuer. No installedPython distribution,cross-hostapplicationcarrier,deployedaccountservice,physicalerasure,powerloss,PCS orfull0.2.0 release claim.'}
add('SCOPE.json',(json.dumps(scope,indent=2)+'\n').encode())
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};add('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode())
folder=root/'research/sdk-alpha1/evidence/20261019-independent-installed-counterpart';folder.mkdir();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(entries.items()):
  i=zipfile.ZipInfo(n,(2026,10,19,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for n,item in manifest.items():assert sha(z.read(n))==item['sha256']and len(z.read(n))==item['bytes']
result={'installation':installation,'registration':registration,'quality':read(out/'QUALITY.json'),'scope':scope,'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())}}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
