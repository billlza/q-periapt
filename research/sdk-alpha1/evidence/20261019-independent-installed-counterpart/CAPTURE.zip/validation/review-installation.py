"""Bind actual installed graph and archive bytes to the executed registration."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;built=out/'source-checkout/target/installed-counterpart-02'
sys.path.insert(0,str(root/'artifact'));sys.path.insert(0,str(out/'reader-program'))
import continuity_independent_package as installed
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
r=read(built/'INSTALLED_COUNTERPART.json');head='69d478e17eb3acafaf7dc22ead941c491d3f3205'
assert r['source_commit']==head and r['completed']and r['sources_unchanged']and not r['runtime_qualified']and not r['release_claim_eligible']and 'failure'not in r
for name,h in r['source_inputs'].items():assert sha(subprocess.check_output(['git','show',head+':'+name]))==h
program=out/'reader-program/continuity_independent_package.py';assert sha(program.read_bytes())==r['source_inputs']['artifact/continuity_independent_package.py']
metadata=read(built/'consumer-metadata.stdout');consumer=Path(read(built/'LOCATION.json')['path'])/'counterpart'
original=subprocess.check_output(['git','show',head+':research/continuity-openssl-peer/native/Cargo.lock'])
assert installed.verify_graph(metadata,consumer,(built/'consumer-Cargo.lock').read_bytes(),original)==r['resolution']
original_manifest=subprocess.check_output(['git','show',head+':research/continuity-openssl-peer/native/Cargo.toml'])
assert installed.installed_manifest(original_manifest)==(built/'consumer-Cargo.toml').read_bytes()==(consumer/'Cargo.toml').read_bytes()
report=out/'sdk/sdk-rust-package/RUST_SDK_PACKAGE.json';body=report.read_bytes();cohort=validate_report(body,r['sdk_report_sha256'],sha(body),sdk.source_identity()['rust_workspace_sha256'])
assert cohort['base_commit']==r['sdk_base_commit']
sdk.verify_consumed_sources(consumer,report.parent,cohort['crates'],names=installed.PRODUCTS)
record=r['candidate_archive'];archive=built/record['file'];assert sha(archive.read_bytes())==record['sha256']and archive.stat().st_size==record['bytes']
candidate=package.validate_candidate(archive.read_bytes(),set(record['files']))
package.verify_candidate_files(consumer/'packages'/f'{package.NAME}-{package.VERSION}',candidate)
for command in ['consumer-build','consumer-clippy','consumer-metadata']:
 receipt=read(built/(command+'.json'));assert receipt['returncode']==0
 text=(built/(command+'.stderr')).read_bytes();assert not re.search(rb'(?m)^\s*(warning:|error:)',text)
assert {'--release','--locked','--offline'}<=set(read(built/'consumer-build.json')['argv'])
assert read(built/'consumer-clippy.json')['argv'][-3:]==['--','-D','warnings']
for item in r['tools'].values():assert sha(Path(item['path']).read_bytes())==item['sha256']
binary=(built/'counterpart').read_bytes();assert binary== (out/'counterpart').read_bytes()and sha(binary)==r['native_sha256']
assert binary[:4]==b'\xcf\xfa\xed\xfe'and int.from_bytes(binary[4:8],'little')==0x100000c
runtime=read(out/'registration-01/RESULT.json');public=read(out/'REGISTRATION_READBACK.json')
assert runtime['native_sha256']==public['native_sha256']==r['native_sha256']
assert public['head']==head and public['source_files']==runtime['source_files']
for label in ['local','witness']:
 assert runtime[label]['workers']==public['profiles'][label]['workers']
 assert runtime[label]['process_kills']==public['profiles'][label]['actual_SIGKILL']
result={'head':head,'native_sha256':r['native_sha256'],'sdk_report_sha256':r['sdk_report_sha256'],'sdk_base_commit':r['sdk_base_commit'],'candidate_archive':{k:record[k]for k in ['file','sha256','bytes']},'resolution':r['resolution'],'counterpart_inputs':r['source_inputs'],'runtime':runtime|{'source_files_count':len(runtime['source_files'])},'scope':'Actual CLI from clean ordinary checkout, same counterpart source installed from8 exactSDKarchives+currentcandidate. Exact9-product graph118external dependencies/originalfull lock, native bytes and public registration transcripts linked. Shared source parsers and same-host control pipe; not installedPython, deployedaccountauth,crosshostcarrier,physicalerasure,PCS orfull0.2.0 release.'}
result['runtime'].pop('source_files')
(out/'INSTALLATION_READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['head','native_sha256','resolution']}))
