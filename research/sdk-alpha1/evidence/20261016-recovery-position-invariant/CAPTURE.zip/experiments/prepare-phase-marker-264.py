"""Observe existing phase owners and strengthen only an existential witness."""
from dataclasses import replace
from pathlib import Path
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
qualified = json.loads((s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json').read_text())
checker = s / 'phase_certificate_check_251.py'
sdk.require(sdk.snapshot(checker).sha256 == qualified['checker_sha256'], 'checker changed')
spec = importlib.util.spec_from_file_location('marker_model_check', checker)
sdk.require(spec is not None and spec.loader is not None, 'checker missing')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
prepared = json.loads((s / 'PHASE_WITNESS_SEARCH_READY_256.json').read_text())
source = s / 'phase-wire-witness-254.spthy'
sdk.require(sdk.snapshot(source).sha256 == prepared['source_sha256'], 'source changed')
raw = source.read_text()
sdk.require(not any(x in raw for x in ('PhaseMarker', 'phase_a_marker', 'phase_b_marker')), 'observation name collision')
before = model.uncomment(raw)
rules = {r.name: r for _, _, r in c.rules(before)}
changed = {}
observations = 0
for name, rule in rules.items():
    added = tuple(c.Fact('PhaseMarker', f.args[:5]) for f in rule.conclusions if f.name == 'PhaseState')
    observations += len(added)
    changed[name] = replace(rule, actions=rule.actions + added)
sdk.require(observations == 13, 'phase observation census differs')
observed = c.replace_rules(raw, changed)
old_name = 'two_rounds_with_matching_wire_events_is_executable'
new_name = 'two_rounds_with_aligned_phase_owners_is_executable'
old_query = model.queries(raw)[old_name]
formula = old_query.split('"', 1)[1].rsplit('"', 1)[0]
quantifier = re.match(r'\s*∃\s+([^.]+)\.\s*(.*)\Z', formula, re.S)
sdk.require(quantifier is not None, 'expected existential formula missing')
anchors = [
    ('A', "'zero'", 'Ready', 'setup'), ('B', "'zero'", 'Ready', 'setup'),
    ('A', "'zero'", 'Offer3', 'os1'), ('B', "'zero'", 'Response4', 'or1'),
    ('B', "'zero'", 'Response6', 'rs1'), ('A', "'zero'", 'Final7', 'rr1'),
    ('A', "'zero'", 'Final8', 'fs1'), ('B', "'zero'", 'Receipt9', 'fr1'),
    ('B', "succ('zero')", 'Ready', 'b1'), ('A', "succ('zero')", 'Ready', 'ra1'),
    ('B', "succ('zero')", 'Offer1', 'g2'), ('B', "succ('zero')", 'Offer3', 'os2'),
    ('A', "succ('zero')", 'Response4', 'e2'), ('A', "succ('zero')", 'Response6', 'rs2'),
    ('B', "succ('zero')", 'Final7', 'rr2'), ('B', "succ('zero')", 'Final8', 'fs2'),
    ('A', "succ('zero')", 'Receipt9', 'fr2'), ('A', "succ(succ('zero'))", 'Ready', 'a2'),
    ('B', "succ(succ('zero'))", 'Ready', 'b2'),
]
extra = ' &\n  '.join(f"PhaseMarker(phase_{role.lower()}_marker,s,'{role}',{epoch},'{phase}') @ #{event}"
                       for role, epoch, phase, event in anchors)
# The entire old matrix is retained verbatim as the first conjunct. Only two
# fresh existential variables and deterministic observer conjuncts are added.
new_query = (f'lemma {new_name}:\n exists-trace\n "∃ phase_a_marker phase_b_marker '
             + quantifier[1] + '.\n (' + quantifier[2] + ') &\n (' + extra + ')"')
sdk.require(quantifier[2] in new_query and len(anchors) == 19, 'original witness matrix changed')
end = list(re.finditer(r'(?m)^end\s*$', observed))
sdk.require(len(end) == 1, 'theory end differs')
candidate = observed[:end[0].start()] + new_query + '\nby sorry\n\nend\n'
path = s / 'phase-markers-264.spthy'
with path.open('x') as f:
    f.write(candidate)
old_parsed = model.parsed('phase-marker-before-264', source)
new_parsed = model.parsed('phase-marker-after-264', path)


def verify_extension(old, new):
    old = model.uncomment(old)
    new = model.uncomment(new)
    old_rules = {r.name: r for _, _, r in c.rules(old)}
    new_rules = {r.name: r for _, _, r in c.rules(new)}
    sdk.require(list(old_rules) == list(new_rules), 'rule inventory differs')
    erased = {}
    count = 0
    for name, rule in old_rules.items():
        labels = tuple(c.Fact('PhaseMarker', f.args[:5]) for f in rule.conclusions if f.name == 'PhaseState')
        count += len(labels)
        sdk.require(new_rules[name] == replace(rule, actions=rule.actions + labels), 'observation rule changed: ' + name)
        erased[name] = rule
    sdk.require(count == 13, 'observation count differs')
    old_queries, new_queries = model.queries(old), model.queries(new)
    sdk.require(len(old_queries) == 16 and len(new_queries) == 17 and
                {k: v for k, v in new_queries.items() if k != new_name} == old_queries,
                'original complete queries changed')
    declarations = list(model.declaration.finditer(new))
    sdk.require(declarations[-1][1] == new_name, 'new query is not last')
    # Erase only the final, added existential query and deterministic labels.
    erased_text = c.replace_rules(new[:declarations[-1].start()] + 'end\n', erased)
    old_model = check.validated_model_comparison_text(old)
    erased_model = check.validated_model_comparison_text(erased_text)
    sdk.require(c.declarations_outside_rules(old_model, model) ==
                c.declarations_outside_rules(erased_model, model), 'global model changed')
    return count


sdk.require(verify_extension(old_parsed, new_parsed) == 13, 'parsed observation erasure failed')
new_rules = {r.name: r for _, _, r in c.rules(model.uncomment(new_parsed))}
controls = {}
variants = {}
setup = new_rules['Setup']
missing = dict(new_rules)
missing['Setup'] = replace(setup, actions=setup.actions[:-1])
variants['missing_observer'] = c.replace_rules(model.uncomment(new_parsed), missing)
wrong = dict(new_rules)
label = setup.actions[-1]
wrong['Setup'] = replace(setup, actions=setup.actions[:-1] + (replace(label, args=(c.Term('wrong_owner'), *label.args[1:])),))
variants['wrong_observed_owner'] = c.replace_rules(model.uncomment(new_parsed), wrong)
changed_rule = dict(new_rules)
changed_rule['Setup'] = replace(setup, conclusions=setup.conclusions[:-1])
variants['removed_original_output'] = c.replace_rules(model.uncomment(new_parsed), changed_rule)
variants['changed_original_query'] = new_parsed.replace(model.queries(new_parsed)[old_name],
                                                       'lemma ' + old_name + ': exists-trace "T"', 1)
variants['extra_restriction'] = new_parsed.replace('lemma ', 'restriction Hidden:\n "All s #i. Setup(s)@i ==> F"\n\nlemma ', 1)
for name, value in variants.items():
    try:
        verify_extension(old_parsed, value)
    except ValueError as exc:
        controls[name] = str(exc)
    else:
        raise ValueError('mutation admitted: ' + name)
sdk.write_json(s / 'PHASE_MARKERS_PREPARED_264.json', {
    'completed': True, 'source_sha256': sdk.snapshot(source).sha256,
    'candidate_sha256': sdk.snapshot(path).sha256,
    'observer_action_count': observations, 'witness_anchor_count': len(anchors),
    'all_sixteen_original_queries_unchanged': True,
    'new_query': new_name,
    'negative_controls_rejected': controls,
    'query_implication': 'The new existential quantifier adds two fresh variables; its first conjunct is the complete unchanged old existential matrix. Dropping the nineteen observer conjuncts and the two unused variables yields the previous wire witness.',
    'observation_erasure': 'Erase the thirteen deterministic PhaseMarker action labels. All rule inputs, outputs, original actions, equations and restrictions remain identical. New labels do not enter messages, premise facts or adversary knowledge. Original query truth is unchanged; the stronger existential query selects aligned lineages without restricting protocol executions.',
    'model_meta_equivalence_machine_proved': False,
    'helper_replay_under_observation_extension_required': True,
    'proof_produced': False, 'release_claim_eligible': False,
})
print('Thirteen deterministic observers erase exactly; all 16 old queries and the full original witness matrix retained; five mutations rejected.')
