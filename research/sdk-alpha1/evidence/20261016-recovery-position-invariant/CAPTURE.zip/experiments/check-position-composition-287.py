"""Qualify both helper proofs and prepare an actual missing-premise control."""
from pathlib import Path
import importlib.util
import json
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('position_composition_287', s / 'phase_certificate_check_251.py')
sdk.require(spec is not None and spec.loader is not None, 'checker missing')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
source, proof = s / 'position-composed-285.spthy', s / 'position-composed-replay-286-proof.spthy'
terminal = json.loads((s / 'position-composed-replay-286-TERMINAL.json').read_text())
helpers = ['first_responder_ready_event_is_unique', 'phase_position_event_is_unique']
sdk.require(terminal['accepted'] and terminal['required_verified_lemmas'] == helpers
            and terminal['input_sha256'] == sdk.snapshot(source).sha256
            and terminal['output_sha256'] == sdk.snapshot(proof).sha256, 'combined replay not accepted')
before = model.parsed('position-composed-input-287', source)
after = model.parsed('position-composed-certificate-287', proof)
a, b = check.validated_model_comparison_text(before), check.validated_model_comparison_text(after)
sdk.require(model.queries(a) == model.queries(b) and len(model.queries(a)) == 19, 'composition query mismatch')
sdk.require([r for _,_,r in c.rules(a)] == [r for _,_,r in c.rules(b)], 'composition rule mismatch')
sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model), 'composition global mismatch')

# This control intentionally inserts an UNPROVED reusable copy before the
# independent target; the acceptance gate must reject a conditional success.
# It is never composed into a positive proof model.
raw = (s / 'position-uniqueness-279.spthy').read_text()
first = next(model.declaration.finditer(raw))
sdk.require(first[1] == 'phase_position_event_is_unique', 'target is not first')
assumption = first[0].replace('phase_position_event_is_unique [use_induction]', 'unproved_position_dependency [reuse]', 1)
sdk.require(assumption != first[0], 'control rename failed')
negative = raw[:first.start()] + assumption + '\nby sorry\n\n' + raw[first.start():]
negative_path = s / 'position-missing-dependency-287.spthy'
with negative_path.open('x') as stream:
    stream.write(negative)
parsed = model.parsed('position-missing-dependency-287', negative_path)
queries = model.queries(parsed)
original = model.parsed('position-missing-original-287', s / 'position-uniqueness-279.spthy')
sdk.require(len(queries) == 20 and {k:v for k,v in queries.items() if k != 'unproved_position_dependency'} == model.queries(original), 'control changed existing declarations')
sdk.require([r for _,_,r in c.rules(model.uncomment(parsed))] == [r for _,_,r in c.rules(model.uncomment(original))], 'control changed a rule')
sdk.write_json(s / 'POSITION_COMPOSITION_CERTIFIED_287.json', {
    'completed': True, 'input_sha256': terminal['input_sha256'],
    'certificate_sha256': terminal['output_sha256'], 'complete_queries': 19,
    'actual_no_search_replay_accepted': True,
    'verified_helpers': {name: terminal['results'][name] for name in helpers},
    'complete_model_matches': True,
    'negative_control_path': negative_path.name,
    'negative_control_sha256': sdk.snapshot(negative_path).sha256,
    'negative_control_required': 'Conditional target success must fail acceptance while unproved_position_dependency remains incomplete.',
    'release_claim_eligible': False,
})
print(json.dumps({'combined_replay_qualified': True, 'queries': 19, 'helpers': helpers, 'missing_dependency_control_prepared': True}))
