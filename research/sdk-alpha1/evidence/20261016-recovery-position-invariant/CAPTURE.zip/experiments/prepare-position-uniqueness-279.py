"""Prepare an explicit independent induction obligation, retaining prior queries."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
checker = s / 'phase_certificate_check_251.py'
record = json.loads((s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json').read_text())
sdk.require(sdk.snapshot(checker).sha256 == record['checker_sha256'], 'checker changed')
spec = importlib.util.spec_from_file_location('position_uniqueness_checker', checker)
sdk.require(spec is not None and spec.loader is not None, 'checker unavailable')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
original = s / 'phase-position-269.spthy'
source = original.read_text()
sdk.require(sdk.snapshot(original).sha256 == '29ec040900cfd68e745dbbb2a398bdc6e597f096bba35fdc3f3ff632c211f5ed', 'source changed')
decls = list(model.declaration.finditer(source))
sdk.require(len(decls) == 18 and len(model.queries(source)) == 18, 'old query inventory differs')
sdk.require(not check.LATE_OPERATION.search(source[decls[0].start():]), 'late model declaration')
lemma = '''lemma phase_position_event_is_unique [use_induction]:
  all-traces
  "All owner s role epoch phase step s2 role2 epoch2 phase2 #i #j.
    PhaseStepMarker(owner,s,role,epoch,phase,step)@i
    & PhaseStepMarker(owner,s2,role2,epoch2,phase2,step)@j
    ==> #i = #j"
by sorry

'''
# This is an explicitly new search input with reset proof bodies, not a certificate
# or the normalized in-memory representation used by the comparison checker.
candidate = source[:decls[0].start()] + lemma + '\n\n'.join(d[0] + '\nby sorry' for d in decls) + '\n\nend\n'
candidate_path = s / 'position-uniqueness-279.spthy'
with candidate_path.open('x') as stream:
    stream.write(candidate)
before = model.parsed('position-uniqueness-old-279', original)
after = model.parsed('position-uniqueness-new-279', candidate_path)

def validate(text):
    old_queries, new_queries = model.queries(before), model.queries(text)
    sdk.require(len(new_queries) == 19 and next(iter(new_queries)) == 'phase_position_event_is_unique', 'new helper inventory differs')
    sdk.require({k:v for k,v in new_queries.items() if k != 'phase_position_event_is_unique'} == old_queries, 'old complete formulas or attributes changed')
    a, b = check.validated_model_comparison_text(before), check.validated_model_comparison_text(text)
    sdk.require([r for _,_,r in c.rules(a)] == [r for _,_,r in c.rules(b)], 'rule or annotation changed')
    ds = list(model.declaration.finditer(b))
    b = b[:ds[0].start()] + b[ds[1].start():]
    sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model), 'global declaration changed')
    first = next(model.declaration.finditer(text))
    sdk.require('[use_induction]' in first[0] and 'reuse' not in first[0] and 'sources' not in first[0], 'new helper must not be assumed')
    return True

validate(after)
negative = {}
for label, value in (
    ('missing_old_secrecy_query', after.replace(model.queries(after)['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'], '', 1)),
    ('new_helper_assumed', after.replace('[use_induction]', '[use_induction, reuse]', 1)),
    ('position_reset', after.replace('PhasePosition( phase_owner, succ(phase_step_count) )', "PhasePosition( phase_owner, 'zero' )", 1)),
):
    sdk.require(value != after, 'ineffective mutation: ' + label)
    try:
        validate(value)
    except ValueError as exc:
        negative[label] = str(exc)
    else:
        raise ValueError('mutation admitted: ' + label)

runner = (s / 'phase-position-run-273.py').read_text()
old = '\"--heuristic=O\", \"--oraclename=\" + str(stage / \"phase-position-oracle-273.sh\"),'
sdk.require(runner.count(old) == 1, 'runner invocation pattern differs')
runner = runner.replace(old, '\"--heuristic=i\",', 1)
# This run uses the built-in stateful ranking. No external oracle is invoked.
runner = runner.replace('(stage / "phase-position-oracle-273.failed").exists()', 'False')
with (s / 'position-uniqueness-run-279.py').open('x') as stream:
    stream.write(runner)
sdk.write_json(s / 'POSITION_UNIQUENESS_PREPARED_279.json', {
    'completed': True, 'candidate_sha256': sdk.snapshot(candidate_path).sha256,
    'original_sha256': sdk.snapshot(original).sha256, 'old_queries_retained': 18,
    'query_count': 19, 'helper': 'phase_position_event_is_unique',
    'negative_controls_rejected': negative,
    'same_rules_annotations_signature_equations_restrictions': True,
    'proof_bodies': 'All old proofs explicitly reset to sorry in this isolated search input. Original source and certificates are retained unchanged. The new helper is first, non-reusable, with no earlier helper assumptions.',
    'scope': 'Independent induction obligation about arbitrary private owners and positions. No protocol step/epoch bound. Not yet proved and not used by any old query.',
    'heuristic': 'Built-in i, documented for unbounded injective stateful protocols.',
    'official_reference': 'https://tamarin-prover.com/manual/master/book/011_advanced-features.html',
    'release_claim_eligible': False,
})
print(json.dumps({'prepared': True, 'queries': 19, 'controls': len(negative), 'candidate_sha256': sdk.snapshot(candidate_path).sha256}))
