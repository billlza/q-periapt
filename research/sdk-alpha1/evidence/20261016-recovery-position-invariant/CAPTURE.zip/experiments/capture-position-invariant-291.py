"""Archive independently checked private-position proofs and retained controls."""
from pathlib import Path
import json
import re
import subprocess
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
sdk.require(head == '302363aecd2a115e2065a86b9f0ad0ad4b8b7be8', 'source head differs')
proof = json.loads((s / 'POSITION_INDUCTION_OBSERVED_283.json').read_text())
composition = json.loads((s / 'POSITION_COMPOSITION_CERTIFIED_287.json').read_text())
dependency = json.loads((s / 'COMPOSED_WITNESS_READY_289.json').read_text())
sdk.require(proof['accepted'] and proof['complete_model_matches']
            and composition['actual_no_search_replay_accepted'] and composition['complete_model_matches']
            and dependency['negative_control']['accepted'] is False, 'qualification incomplete')
for label in ('position-induction-search-282', 'position-induction-replay-284', 'position-composed-replay-286'):
    terminal = json.loads((s / (label + '-TERMINAL.json')).read_text())
    sdk.require(terminal['accepted'] and terminal['returncode'] == 0 and not terminal['timed_out']
                and not terminal['output_exceeded'] and terminal['results']['phase_position_event_is_unique']['steps'] == 29,
                'proof execution failed: ' + label)
    sdk.require(sdk.snapshot(s / (label + '-proof.spthy')).sha256 == terminal['output_sha256'], 'certificate changed')
canonical = root / 'research/continuity-recovery-symbolic/multi-epoch.spthy'
sdk.require(sdk.snapshot(canonical).sha256 == '78aaca97033b6a5ff470991883d1e36ad881a95e16ef6bd9f7c146e51e83ea0b', 'canonical model changed')
files = {}
for path in sorted(s.rglob('*')):
    relative = path.relative_to(s).as_posix()
    if path.is_file() and any(268 <= int(n) <= 289 or int(n) == 264 for n in re.findall(r'(?<!\d)(\d{3})(?!\d)', relative)):
        sdk.require(not path.is_symlink() and '__pycache__' not in path.parts, 'unsafe capture member')
        files['experiments/' + relative] = path
for name in ('phase-wire-witness-254.spthy', 'PHASE_WITNESS_SEARCH_READY_256.json',
             'phase_state_codec_235.py', 'PHASE_STATE_CHECKER_VERIFIED_236.json',
             'phase_certificate_check_251.py', 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json',
             'verify-counter-model-89.py', 'capture-position-invariant-291.py'):
    files['experiments/' + name] = s / name
files['tools/TOOLS_08.json'] = root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json'
files['source/research/continuity-recovery-symbolic/multi-epoch.spthy'] = canonical
for name in ('python_bootstrap.py', 'rust_sdk_profile.py', 'bounded_process.py', 'continuity_recovery_proof.py',
             'continuity_recovery_profiles.py', 'formal_toolchain_contract.py'):
    files['source/artifact/' + name] = root / 'artifact' / name
snapshots = {name: sdk.snapshot(path, maximum=16 * 1024**2) for name, path in files.items()}
expanded = sum(len(item.data) for item in snapshots.values())
sdk.require(expanded <= 64 * 1024**2, 'capture exceeds size bound')
public = root / 'research/sdk-alpha1/evidence/20261016-recovery-position-invariant'
public.mkdir()
archive = public / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, snapshot in sorted(snapshots.items()):
        entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        output.writestr(entry, snapshot.data)
sdk.write_json(public / 'CAPTURE.json', {
    'source_commit': head, 'canonical_model_sha256': sdk.snapshot(canonical).sha256,
    'archive_sha256': sdk.snapshot(archive, maximum=16 * 1024**2).sha256,
    'members': {name: snapshot.sha256 for name, snapshot in sorted(snapshots.items())},
    'expanded_bytes': expanded, 'verified_property': 'phase_position_event_is_unique', 'verified_steps': 29,
    'independent_no_search_replays': ['position-induction-replay-284', 'position-composed-replay-286'],
    'combined_ready_helper_steps': 285, 'complete_query_inventory': 19,
    'actual_missing_proof_control_rejected': True,
    'base_representation_checkpoint': '../20261016-recovery-ready-invariant/CAPTURE.json',
    'base_representation_archive_sha256': 'c750a3ea4635b695b3a0b62df8924807c4f46c1156f5db937d04c1148724cf25',
    'step_is_not_application_counter_or_epoch': True,
    'trace_equivalence_meta_theorem_machine_checked': False,
    'original_protocol_model_modified': False, 'sdk_runtime_source_modified': False,
    'two_round_witness_or_multi_epoch_secrecy_proved': False,
    'hosted_replay_qualified': False, 'private_sdk_or_device_state_included': False,
    'retained_failed_searches': ['phase-position-witness-search-274', 'phase-state-first-witness-search-277', 'position-uniqueness-search-280'],
    'retained_observer_correction': 'PHASE_STATE_FIRST_LIMITS_CORRECTION_279.json',
    'pending_search_excluded': 'composed-position-witness-290',
    'release_claim_eligible': False,
})
print(json.dumps({'members': len(snapshots), 'expanded_bytes': expanded, 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': sdk.snapshot(archive).sha256}))
