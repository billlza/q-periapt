"""Rank all existing proof goals; retain input hashes and the complete permutation."""
from pathlib import Path
import json
import hashlib
import re
import sys
import time

stage = Path(__file__).resolve().parent
log = stage / "composed-position-oracle-289.jsonl"
failure = stage / "composed-position-oracle-289.failed"
try:
    raw = sys.stdin.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise ValueError("oracle input exceeds diagnostic bound")
    goals = []
    for line in raw.splitlines():
        match = re.match(r"^([0-9]+):\s*(.*)$", line)
        if not match:
            raise ValueError("unexpected goal encoding")
        goals.append((int(match[1]), match[2]))
    if len({number for number, _ in goals}) != len(goals):
        raise ValueError("duplicate goal inventory")

    def fact_arguments(goal, name):
        match = re.match(r"!?" + name + r"\s*\(", goal)
        if not match:
            return None
        start = match.end()
        depth, tuples, quoted = 1, 0, False
        fields = []
        for i in range(start, len(goal)):
            char = goal[i]
            if char == "'":
                quoted = not quoted
            elif not quoted:
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        if tuples:
                            raise ValueError("unbalanced goal tuple")
                        fields.append(goal[start:i].strip())
                        return fields
                elif char == "<":
                    tuples += 1
                elif char == ">":
                    tuples -= 1
                    if tuples < 0:
                        raise ValueError("unbalanced goal tuple")
                elif char == "," and depth == 1 and tuples == 0:
                    fields.append(goal[start:i].strip())
                    start = i + 1
        raise ValueError("unclosed goal fact")

    def score(item):
        _, goal = item
        marker = fact_arguments(goal, "PhaseStepMarker")
        if marker is not None:
            if len(marker) != 6:
                raise ValueError("phase step marker arity differs")
            order = ("setup", "os1", "or1", "rs1", "rr1", "fs1", "fr1", "b1", "ra1",
                     "g2", "os2", "e2", "rs2", "rr2", "fs2", "fr2", "a2", "b2")
            for position, event in enumerate(order):
                if re.search(r"@ #" + event + r"$", goal):
                    return -600 + position
            return -560
        position = fact_arguments(goal, "PhasePosition")
        if position is not None:
            if len(position) != 2:
                raise ValueError("phase position arity differs")
            return -500 + position[1].count("succ(")
        if goal.startswith("PhaseMarker("):
            order = ("setup", "os1", "or1", "rs1", "rr1", "fs1", "fr1", "b1", "ra1",
                     "g2", "os2", "e2", "rs2", "rr2", "fs2", "fr2", "a2", "b2")
            for position, event in enumerate(order):
                if re.search(r"@ #" + event + r"$", goal):
                    return -400 + position
            return -360
        application = fact_arguments(goal, "ApplicationEpoch")
        if application is not None:
            if len(application) != 2:
                raise ValueError("application epoch arity differs")
            if application[1] == "'zero'":
                return -300
        phase = fact_arguments(goal, "PhaseState")
        if phase is not None:
            if len(phase) != 6:
                raise ValueError("phase state arity differs")
            if phase[4] == "'Ready'":
                return 1.5
            if phase[4] in {"'Offer1'", "'Offer2'", "'Offer3'", "'Response4'", "'Response5'", "'Response6'", "'Final7'", "'Final8'", "'Receipt9'"}:
                return 3
            raise ValueError("unknown phase discriminator")
        if goal.startswith("ReadyState("):
            return -150
        if re.match(r"!?Peers\(", goal):
            return -200
        if re.match(r"Wire(?:Sent|Received)\(", goal):
            order = ("os1", "or1", "rs1", "rr1", "fs1", "fr1", "b1", "ra1",
                     "os2", "e2", "rs2", "rr2", "fs2", "fr2", "a2", "b2")
            for position, event in enumerate(order):
                if re.search(r"@ #" + event + r"$", goal):
                    return -100 + position
            return -80
        # Keep the two constraints on one existential event adjacent.
        # These are the query's timepoint names; all goals remain ranked.
        for event, base in (("b1", -10), ("a2", -8)):
            if re.search(r"@ #" + event + r"$", goal):
                if goal.startswith("CounterState("):
                    return base
                if goal.startswith("Confirmed("):
                    return base + 1
        if goal.startswith("CounterState(") and re.search(r"@ #m$", goal):
            return -6
        if re.match(r"!?(?:RootBefore|Confirmed|Saved)\(", goal):
            return 0
        if re.match(r"!?(?:Context|Wrap|Pinned|Signer|SignerFile|Peers|IdentityKey|StorageKey|CutPermit)\(", goal):
            return 1
        if re.match(r"!?Stored\(", goal):
            return 2
        if re.match(r"!?(?:Final8|Final7|Receipt9|Response6|Response5|Response4|Offer3|Offer2|Offer1)\(", goal):
            return 3
        if re.match(r"Ready\(", goal):
            return 1.5
        if re.match(r"!?KU\(", goal):
            return 5
        if re.match(r"(?:SendState|SendPermit)\(", goal):
            return 9
        if re.match(r"\((?:counter|closing|previous)(?:\.|\s)", goal):
            return 8
        return 6
    ranked = sorted(goals, key=score)
    entry = json.dumps({"monotonic": time.monotonic(), "lemma": sys.argv[1:],
                        "input_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                        "input_characters": len(raw), "goal_numbers": [number for number, _ in goals],
                        "ranking": [number for number, _ in ranked],
                        "selected_prefix": ranked[0][1][:1024] if ranked else None,
                        "full_goal_text_retained": False}, ensure_ascii=False) + "\n"
    if (log.stat().st_size if log.exists() else 0) + len(entry.encode()) > 16 * 1024**2:
        raise ValueError("oracle log exceeds diagnostic bound")
    with log.open("a") as stream:
        stream.write(entry)
    for number, _ in ranked:
        print(number)
except Exception as exc:
    failure.write_text(type(exc).__name__ + ": " + str(exc))
    raise
