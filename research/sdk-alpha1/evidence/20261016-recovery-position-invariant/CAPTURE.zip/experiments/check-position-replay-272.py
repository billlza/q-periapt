"""Check the actual replay certificate against the complete position model."""
from dataclasses import replace
import importlib.util
from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
qualified = json.loads((s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json').read_text())
checker_path = s / 'phase_certificate_check_251.py'
sdk.require(sdk.snapshot(checker_path).sha256 == qualified['checker_sha256'], 'certificate checker changed')
spec = importlib.util.spec_from_file_location('position_replay_certificate', checker_path)
sdk.require(spec is not None and spec.loader is not None, 'checker unavailable')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
source = s / 'phase-position-269.spthy'
proof = s / 'phase-position-helper-replay-271-proof.spthy'
prepared = json.loads((s / 'PHASE_POSITION_PREPARED_269.json').read_text())
terminal = json.loads((s / 'phase-position-helper-replay-271-TERMINAL.json').read_text())
helper = 'first_responder_ready_event_is_unique'
sdk.require(terminal['accepted'] and terminal['required_verified_lemmas'] == [helper]
            and terminal['input_sha256'] == prepared['candidate_sha256'] == sdk.snapshot(source).sha256
            and terminal['output_sha256'] == sdk.snapshot(proof).sha256,
            'actual independent replay is not accepted or its bytes changed')
original = model.parsed('phase-position-source-272', source)
certificate = model.parsed('phase-position-certificate-272', proof)


def compare(candidate):
    a = check.validated_model_comparison_text(original)
    b = check.validated_model_comparison_text(candidate)
    sdk.require(model.queries(a) == model.queries(b) and len(model.queries(a)) == 18,
                'complete query declarations changed')
    before = [r for _, _, r in c.rules(a)]
    after = [r for _, _, r in c.rules(b)]
    sdk.require(before == after, 'rule AST or annotations changed')
    sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model),
                'global declaration changed')
    return True


sdk.require(compare(certificate), 'certificate changed the model')
rules = {r.name: r for _, _, r in c.rules(model.uncomment(certificate))}
rule = rules['Offer_Signing_2']
sdk.require(rule.premises[-1].name == rule.conclusions[-1].name == 'PhasePosition',
            'position companion placement differs')
variants = {}
for label, changed in (
    ('missing_position_premise', replace(rule, premises=rule.premises[:-1])),
    ('reset_position', replace(rule, conclusions=rule.conclusions[:-1] + (
        replace(rule.conclusions[-1], args=(rule.conclusions[-1].args[0], c.Term("'zero'"))),))),
):
    replacements = dict(rules)
    replacements[rule.name] = changed
    variants[label] = c.replace_rules(model.uncomment(certificate), replacements)
queries = model.queries(certificate)
variants['weakened_ready_query'] = certificate.replace(queries[helper], queries[helper].split('"', 1)[0] + '"T"', 1)
variants['missing_original_secrecy_query'] = certificate.replace(
    queries['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'], '', 1)
rejected = {}
for name, value in variants.items():
    try:
        compare(value)
    except ValueError as exc:
        rejected[name] = str(exc)
    else:
        raise ValueError('changed certificate admitted: ' + name)
sdk.write_json(s / 'PHASE_POSITION_HELPER_CERTIFIED_272.json', {
    'completed': True, 'input_sha256': terminal['input_sha256'],
    'certificate_sha256': terminal['output_sha256'], 'helper': helper,
    'verified_steps': terminal['results'][helper]['steps'],
    'actual_no_search_replay_accepted': True, 'complete_queries_preserved': 18,
    'rule_ast_and_annotations_preserved': True, 'negative_controls_rejected': rejected,
    'scope': 'The original Ready helper actually replays under the unbounded companion-position extension. All complete queries and operational declarations are retained in the real certificate. Normalized comparison text is never used as a prover input.',
    'two_round_witness_or_recovery_secrecy_proved': False,
    'representation_meta_theorem_machine_proved': False, 'release_claim_eligible': False,
})
print(json.dumps({'helper_replay_verified': True, 'steps': terminal['results'][helper]['steps'],
                  'complete_queries_preserved': 18, 'mutations_rejected': len(rejected)}))
