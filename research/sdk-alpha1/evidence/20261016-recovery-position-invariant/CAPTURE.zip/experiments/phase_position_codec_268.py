"""Pair each private phase lineage with an erasable, unbounded step counter."""
from dataclasses import replace
import re

POSITION = 'PhasePosition'
MARKER = 'PhaseStepMarker'
STEP = 'phase_step_count'


def extend_rule(rule, c, require):
    inputs = [f for f in rule.premises if f.name == 'PhaseState']
    outputs = [f for f in rule.conclusions if f.name == 'PhaseState']
    if rule.name == 'Setup':
        require(not inputs and len(outputs) == 2, 'initial phase census differs')
        owners = [f.args[0] for f in outputs]
        require(len(set(owners)) == 2 and all(c.Fact('Fr', (owner,)) in rule.premises for owner in owners),
                'initial owners are not distinct fresh labels')
        positions = tuple(c.Fact(POSITION, (owner, c.Term("'zero'"))) for owner in owners)
        markers = tuple(c.Fact(MARKER, (*f.args[:5], c.Term("'zero'"))) for f in outputs)
        return replace(rule, actions=rule.actions + markers, conclusions=rule.conclusions + positions)
    if inputs or outputs:
        require(len(inputs) == len(outputs) == 1 and inputs[0].args[:3] == outputs[0].args[:3],
                'phase lineage joins, forks or changes owner/session/role')
        owner = inputs[0].args[0]
        before = c.Term(STEP)
        after = c.Term('succ', (before,))
        premise = c.Fact(POSITION, (owner, before), annotations=('no_precomp',))
        conclusion = c.Fact(POSITION, (owner, after))
        marker = c.Fact(MARKER, (*outputs[0].args[:5], after))
        return replace(rule, premises=rule.premises + (premise,), actions=rule.actions + (marker,),
                       conclusions=rule.conclusions + (conclusion,))
    return rule


def encode(text, c, model, require):
    require(not any(name in text for name in (POSITION, MARKER, STEP)), 'counter name collision')
    rules = {r.name: r for _, _, r in c.rules(model.uncomment(text))}
    changed = {name: extend_rule(rule, c, require) for name, rule in rules.items()}
    require(sum(changed[n] != r for n, r in rules.items()) == 12, 'phase rule census differs')
    return c.replace_rules(text, changed)


def verify(old, new, new_query_name, c, model, comparison, require):
    old, new = model.uncomment(old), model.uncomment(new)
    old_rules = {r.name: r for _, _, r in c.rules(old)}
    new_rules = {r.name: r for _, _, r in c.rules(new)}
    require(list(old_rules) == list(new_rules), 'rule inventory differs')
    for name, rule in old_rules.items():
        require(new_rules[name] == extend_rule(rule, c, require), 'phase counter extension differs: ' + name)
    old_queries, new_queries = model.queries(old), model.queries(new)
    require(len(old_queries) == 17 and len(new_queries) == 18 and
            {k: v for k, v in new_queries.items() if k != new_query_name} == old_queries,
            'original complete query set changed')
    declarations = list(model.declaration.finditer(new))
    require(declarations[-1][1] == new_query_name, 'stronger witness is not the last query')
    erased = c.replace_rules(new[:declarations[-1].start()] + 'end\n', old_rules)
    require(c.declarations_outside_rules(comparison(old), model) ==
            c.declarations_outside_rules(comparison(erased), model), 'global declarations changed')
    require(not any(name in erased for name in (POSITION, MARKER, STEP)), 'counter escaped erasure')
    return True
