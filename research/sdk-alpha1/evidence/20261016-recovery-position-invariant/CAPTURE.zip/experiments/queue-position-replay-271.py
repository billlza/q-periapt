"""Replay the exact helper only after the owned CodeQL evaluator has terminated."""
from pathlib import Path
import json
import os
import subprocess
import sys
import time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
native = root / 'target/continuity-codeql-9c65-terminal-20261016/native-summary-layout-102'
started = json.loads((native / 'STARTED.json').read_text())
prepared = json.loads((stage / 'PHASE_POSITION_PREPARED_269.json').read_text())
schedule = json.loads((stage / 'PHASE_POSITION_SCHEDULE_CHECKED_270.json').read_text())
model = stage / 'phase-position-269.spthy'
sdk.require(prepared['completed'] and schedule['completed'] and
            sdk.snapshot(model).sha256 == prepared['candidate_sha256'] == schedule['candidate_sha256'],
            'position model is not the checked input')
label = 'phase-position-helper-replay-271'
sdk.require(not any(stage.glob(label + '*')), 'replay output already exists')
argv = [sys.executable, '-I', '-S', '-B', '-W', 'error',
        str(root / 'artifact/python_bootstrap.py'), str(stage / 'phase-run-240.py'),
        model.name, label, 'replay', '300', '6', 'no-graph',
        'first_responder_ready_event_is_unique']
sdk.write_json(stage / 'PHASE_POSITION_REPLAY_QUEUED_271.json', {
    'state': 'waiting for native-summary-layout-102 terminal and process-group absence',
    'wait_bound_seconds': 900, 'blocking_process_group': started['pid'],
    'argv_after_wait': argv, 'model_sha256': prepared['candidate_sha256'],
    'runner_sha256': sdk.snapshot(stage / 'phase-run-240.py').sha256,
    'proof_started': False, 'proof_accepted': False,
})
deadline = time.monotonic() + 900
while not (native / 'TERMINAL.json').is_file():
    sdk.require(time.monotonic() < deadline, 'native terminal wait exceeded')
    time.sleep(1)
terminal = json.loads((native / 'TERMINAL.json').read_text())
sdk.require(terminal['query_sha256'] == started['query_sha256'], 'native control identity differs')
try:
    os.killpg(started['pid'], 0)
except ProcessLookupError:
    pass
else:
    raise ValueError('native evaluator process group is still live')
sdk.write_json(stage / 'PHASE_POSITION_REPLAY_RESOURCE_ADMISSION_271.json', {
    'prior_terminal_sha256': sdk.snapshot(native / 'TERMINAL.json').sha256,
    'prior_reason': terminal['reason'], 'prior_returncode': terminal['returncode'],
    'prior_process_group_absent': True, 'argv': argv,
    'scope': 'Resource admission only. No statement about the CodeQL result or proof correctness.',
})
result = subprocess.run(argv, cwd=root, timeout=330)
sdk.require(result.returncode == 0, 'replay driver failed')
replay = json.loads((stage / (label + '-TERMINAL.json')).read_text())
print(json.dumps({'replay_driver_exit': result.returncode, 'accepted': replay['accepted'],
                  'input_sha256': replay['input_sha256']}), flush=True)
