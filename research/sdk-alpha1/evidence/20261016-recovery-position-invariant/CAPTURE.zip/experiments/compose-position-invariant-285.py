"""Validate independent replay before composing the two actual helper proofs."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('composed_position_check', s / 'phase_certificate_check_251.py')
sdk.require(spec is not None and spec.loader is not None, 'checker missing')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
helper = 'phase_position_event_is_unique'
search = json.loads((s / 'POSITION_INDUCTION_OBSERVED_283.json').read_text())
replay = json.loads((s / 'position-induction-replay-284-TERMINAL.json').read_text())
search_certificate = s / 'position-induction-search-282-proof.spthy'
replay_certificate = s / 'position-induction-replay-284-proof.spthy'
sdk.require(search['accepted'] and search['complete_model_matches'] and replay['accepted']
            and replay['input_sha256'] == search['terminal']['output_sha256'] == sdk.snapshot(search_certificate).sha256
            and replay['output_sha256'] == sdk.snapshot(replay_certificate).sha256
            and replay['required_verified_lemmas'] == [helper]
            and replay['results'][helper]['steps'] == 29, 'independent replay not qualified')
parsed_search = model.parsed('position-composition-search-285', search_certificate)
parsed_replay = model.parsed('position-composition-replay-285', replay_certificate)
a, b = check.validated_model_comparison_text(parsed_search), check.validated_model_comparison_text(parsed_replay)
sdk.require(model.queries(a) == model.queries(b) and len(model.queries(a)) == 19, 'replay formula mismatch')
sdk.require([r for _,_,r in c.rules(a)] == [r for _,_,r in c.rules(b)], 'replay rule mismatch')
sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model), 'replay global mismatch')

original = s / 'phase-position-269.spthy'
sdk.require(sdk.snapshot(original).sha256 == '29ec040900cfd68e745dbbb2a398bdc6e597f096bba35fdc3f3ff632c211f5ed', 'old proof-bearing source changed')
old = original.read_text()
old_first = next(model.declaration.finditer(old))
raw = replay_certificate.read_text()
decls = list(model.declaration.finditer(raw))
sdk.require(decls[0][1] == helper and decls[1][1] == 'first_responder_ready_event_is_unique', 'replay declaration order differs')
block = raw[decls[0].start():decls[1].start()]
sdk.require(block.count('[use_induction]') == 1 and 'by sorry' not in block, 'helper proof is incomplete')
block = block.replace('[use_induction]', '[reuse, use_induction]', 1)
candidate = old[:old_first.start()] + block + old[old_first.start():]
candidate_path = s / 'position-composed-285.spthy'
with candidate_path.open('x') as stream:
    stream.write(candidate)
before = model.parsed('position-composition-original-285', original)
after = model.parsed('position-composition-candidate-285', candidate_path)
aq, bq = model.queries(before), model.queries(after)
sdk.require(len(bq) == 19 and {k:v for k,v in bq.items() if k != helper} == aq, 'old formula or attribute changed')
sdk.require(bq[helper].split('"', 1)[1] == model.queries(parsed_replay)[helper].split('"', 1)[1], 'proved helper formula changed')
attrs = re.search(r'\[([^]]+)\]', bq[helper])
sdk.require(attrs and {x.strip() for x in attrs[1].split(',')} == {'reuse', 'use_induction'}, 'unexpected helper attributes')
a, b = check.validated_model_comparison_text(before), check.validated_model_comparison_text(after)
sdk.require([r for _,_,r in c.rules(a)] == [r for _,_,r in c.rules(b)], 'composition changes rule or annotation')
decls = list(model.declaration.finditer(b))
b = b[:decls[0].start()] + b[decls[1].start():]
sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model), 'composition changes other declarations')
sdk.write_json(s / 'POSITION_COMPOSITION_PREPARED_285.json', {
    'completed': True, 'independent_replay_accepted': True, 'helper': helper,
    'helper_steps': 29, 'replay_certificate_sha256': sdk.snapshot(replay_certificate).sha256,
    'replay_complete_model_matches': True,
    'candidate_sha256': sdk.snapshot(candidate_path).sha256,
    'old_queries_retained': 18, 'total_queries': 19,
    'old_ready_proof_preserved': True,
    'new_helper': 'Only the independently proved helper gains reuse; its exact formula and actual proof script are preserved.',
    'required_next': 'Actual combined no-search replay must accept both helpers before a dependent witness search.',
    'recovery_secrecy_or_two_round_executability_proved': False,
    'release_claim_eligible': False,
})
print(json.dumps({'independent_replay_qualified': True, 'new_helper_steps': 29, 'composed_queries': 19}))
