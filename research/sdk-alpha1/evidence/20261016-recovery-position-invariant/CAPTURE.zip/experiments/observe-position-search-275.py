"""Bind every completed oracle exchange to the failed witness search."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import os
import re
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
START = '>>>>>>>>>>>>>>>>>>>>>>>> START INPUT\n'
MIDDLE = '\n>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT\n'
END = '\n>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call\n'


def frames_from_trace(text):
    pattern = re.escape(START) + '(.*?)' + re.escape(MIDDLE) + '(.*?)' + re.escape(END)
    frames = re.findall(pattern, text, re.S)
    sdk.require(len(frames) == text.count(START) == text.count(MIDDLE) == text.count(END),
                'incomplete or ambiguous oracle frame')
    return frames


def main():
    label = 'phase-position-witness-search-274'
    terminal = json.loads((s / (label + '-TERMINAL.json')).read_text())
    started = json.loads((s / (label + '-STARTED.json')).read_text())
    sdk.require(not terminal['accepted'] and terminal['timed_out'] and not terminal['output_exceeded']
                and terminal['returncode'] == -9 and terminal['output_sha256'] is None,
                'terminal needs a different disposition')
    try:
        os.killpg(started['pid'], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError('original prover process group is still live')
    rows = [json.loads(line) for line in (s / 'phase-position-oracle-273.jsonl').read_text().splitlines()]
    sdk.require(not (s / 'phase-position-oracle-273.failed').exists(), 'oracle itself failed')
    frames = frames_from_trace((s / (label + '.stderr')).read_text())
    actual = Counter()
    for raw, output in frames:
        goals = [int(line.split(':', 1)[0]) for line in raw.splitlines()]
        ranking = [int(line) for line in output.splitlines()]
        sdk.require(sorted(goals) == sorted(ranking) and len(goals) == len(set(goals)),
                    'goal dropped or duplicated')
        actual[(hashlib.sha256(raw.encode()).hexdigest(), tuple(goals), tuple(ranking))] += 1
    logged = Counter((row['input_sha256'], tuple(row['goal_numbers']), tuple(row['ranking'])) for row in rows)
    sdk.require(actual == logged, 'callback/frame multiset differs')
    families = Counter((row.get('selected_prefix') or '').split('(', 1)[0] for row in rows)
    sdk.write_json(s / 'PHASE_POSITION_SEARCH_OBSERVED_275.json', {
        'completed': True, 'input_sha256': terminal['input_sha256'],
        'terminal_sha256': sdk.snapshot(s / (label + '-TERMINAL.json')).sha256,
        'stderr_sha256': sdk.snapshot(s / (label + '.stderr'), maximum=64 * 1024**2).sha256,
        'oracle_sha256': sdk.snapshot(s / 'phase-position-oracle-273.py').sha256,
        'returncode': terminal['returncode'], 'elapsed_seconds': terminal['elapsed_seconds'],
        'reason': '600second deadline, then SIGKILL after the5second SIGINT grace period',
        'process_group_absent': True, 'oracle_frame_pairs_verified': len(frames),
        'selected_goal_families': dict(families),
        'maximum_input_characters': max(row['input_characters'] for row in rows),
        'proof_produced': False, 'accepted': False,
        'next_hypothesis': 'The oracle prioritized generic PhasePosition premises above phase-tagged PhaseState premises. Test ordering the latter first on the exact retained callback inputs before another bounded search. All goals, branches, model rules and queries must remain.',
        'limits': 'No oracle selection of PhaseState does not mean the simplifier never processed such facts. This is an ordering hypothesis, not a proof of the timeout cause or an attack.',
        'release_claim_eligible': False,
    })
    print(json.dumps({'verified_callback_pairs': len(frames), 'selected_goal_families': dict(families),
                      'prover_group_absent': True, 'proof_produced': False}))


if __name__ == '__main__':
    main()
