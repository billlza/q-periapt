"""Cross-check witness positions against the actual two phase paths."""
from pathlib import Path
import ast
import importlib.util
import json
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
prepared = json.loads((s / 'PHASE_POSITION_PREPARED_269.json').read_text())
source = s / 'phase-markers-264.spthy'
sdk.require(sdk.snapshot(source).sha256 == prepared['source_sha256'], 'source changed')
candidate = s / 'phase-position-269.spthy'
sdk.require(sdk.snapshot(candidate).sha256 == prepared['candidate_sha256'], 'candidate changed')
spec = importlib.util.spec_from_file_location('schedule_codec', s / 'phase_state_codec_235.py')
sdk.require(spec is not None and spec.loader is not None, 'codec missing')
c = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = c
spec.loader.exec_module(c)
rules = {r.name: r for _, _, r in c.rules(source.read_text())}
proposer = ['Key_Reservation_1', 'Offer_Signing_2', 'Offer_Commit_3',
            'Final_Reservation_7', 'Final_Commit_8', 'Receipt_Accept_0']
responder = ['Response_Reservation_4', 'Response_Compute_5', 'Response_Commit_6',
             'Receipt_Reservation_9', 'Receipt_Commit_0']
sdk.require(len(set(proposer + responder)) == 11, 'phase rule census differs')
states = {}
for role, schedule in (('A', proposer + responder), ('B', responder + proposer)):
    phase, epoch = 'Ready', 0
    states[role] = [(phase, epoch, 0)]
    for position, name in enumerate(schedule, 1):
        rule = rules[name]
        inputs = [f for f in rule.premises if f.name == 'PhaseState']
        outputs = [f for f in rule.conclusions if f.name == 'PhaseState']
        sdk.require(len(inputs) == len(outputs) == 1, 'phase lineage shape differs')
        before, after = inputs[0], outputs[0]
        sdk.require(before.args[4] == c.Term("'" + phase + "'"), 'schedule enters wrong phase')
        if after.args[3] == c.Term('succ', (before.args[3],)):
            epoch += 1
        else:
            sdk.require(after.args[3] == before.args[3], 'unexpected epoch step')
        phase = after.args[4].name.strip("'")
        states[role].append((phase, epoch, position))
    sdk.require(states[role][-1] == ('Ready', 2, 11), 'two-round endpoint differs')
tree = ast.parse((s / 'prepare-phase-position-269.py').read_text())
assignments = [n for n in tree.body if isinstance(n, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == 'anchors' for t in n.targets)]
sdk.require(len(assignments) == 1, 'anchor declaration differs')
anchors = ast.literal_eval(assignments[0].value)


def numeral(n):
    value = c.Term("'zero'")
    for _ in range(n):
        value = c.Term('succ', (value,))
    return value


def valid(anchor):
    role, epoch, phase, _, position = anchor
    return any((phase, position) == (p, n) and c.term(epoch) == numeral(e)
               for p, e, n in states[role])


sdk.require(len(anchors) == 19 and all(map(valid, anchors)), 'witness position disagrees with phase path')
for anchor in anchors:
    changed = (*anchor[:-1], anchor[-1] + 1)
    sdk.require(not valid(changed), 'off-by-one position control admitted')
sdk.write_json(s / 'PHASE_POSITION_SCHEDULE_CHECKED_270.json', {
    'completed': True, 'candidate_sha256': prepared['candidate_sha256'],
    'source_sha256': prepared['source_sha256'], 'phase_paths': states,
    'anchors_checked': len(anchors), 'off_by_one_controls_rejected': len(anchors),
    'scope': 'The19 chosen observer positions agree with the actual proposer/responder phase edges and epoch increments. This is not a full symbolic execution: message equations, signatures, persistence, attacker knowledge and the existential proof still require verification.',
    'retained_invocation_error': 'A duplicate preparation269 invocation was accidentally issued before this checker. Exclusive creation rejected the existing candidate before any overwrite or new proof run. The original prepared candidate and hash are unchanged.',
    'proof_produced': False, 'release_claim_eligible': False,
})
print('All19 witness positions match the actual phase paths; nineteen off-by-one mutations rejected. No protocol proof claimed.')
