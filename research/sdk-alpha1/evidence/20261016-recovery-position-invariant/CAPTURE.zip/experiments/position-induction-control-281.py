"""Rank all existing proof goals; retain input hashes and the complete permutation."""
from pathlib import Path
import json
import hashlib
import re
import sys
import time

stage = Path(__file__).resolve().parent
log = stage / "position-induction-control-281.jsonl"
failure = stage / "position-induction-control-281.failed"
try:
    raw = sys.stdin.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise ValueError("oracle input exceeds diagnostic bound")
    goals = []
    for line in raw.splitlines():
        match = re.match(r"^([0-9]+):\s*(.*)$", line)
        if not match:
            raise ValueError("unexpected goal encoding")
        goals.append((int(match[1]), match[2]))
    if len({number for number, _ in goals}) != len(goals):
        raise ValueError("duplicate goal inventory")

    def fact_arguments(goal, name):
        match = re.match(r"!?" + name + r"\s*\(", goal)
        if not match:
            return None
        start = match.end()
        depth, tuples, quoted = 1, 0, False
        fields = []
        for i in range(start, len(goal)):
            char = goal[i]
            if char == "'":
                quoted = not quoted
            elif not quoted:
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        if tuples:
                            raise ValueError("unbalanced goal tuple")
                        fields.append(goal[start:i].strip())
                        return fields
                elif char == "<":
                    tuples += 1
                elif char == ">":
                    tuples -= 1
                    if tuples < 0:
                        raise ValueError("unbalanced goal tuple")
                elif char == "," and depth == 1 and tuples == 0:
                    fields.append(goal[start:i].strip())
                    start = i + 1
        raise ValueError("unclosed goal fact")

    def score(item):
        _, goal = item
        marker = fact_arguments(goal, "PhaseStepMarker")
        if marker is not None:
            if len(marker) != 6:
                raise ValueError("step marker arity differs")
            return -3
        position = fact_arguments(goal, "PhasePosition")
        if position is not None:
            if len(position) != 2:
                raise ValueError("position arity differs")
            return -2
        if goal.startswith("Fr("):
            return -1
        return 0
    ranked = sorted(goals, key=score)
    entry = json.dumps({"monotonic": time.monotonic(), "lemma": sys.argv[1:],
                        "input_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                        "input_characters": len(raw), "goal_numbers": [number for number, _ in goals],
                        "ranking": [number for number, _ in ranked],
                        "selected_prefix": ranked[0][1][:1024] if ranked else None,
                        "full_goal_text_retained": False}, ensure_ascii=False) + "\n"
    if (log.stat().st_size if log.exists() else 0) + len(entry.encode()) > 16 * 1024**2:
        raise ValueError("oracle log exceeds diagnostic bound")
    with log.open("a") as stream:
        stream.write(entry)
    for number, _ in ranked:
        print(number)
except Exception as exc:
    failure.write_text(type(exc).__name__ + ": " + str(exc))
    raise
