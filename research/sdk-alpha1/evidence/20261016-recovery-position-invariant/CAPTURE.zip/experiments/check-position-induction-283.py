"""Observe the induction run and, if successful, bind its actual certificate."""
from collections import Counter
from dataclasses import replace
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, s / filename)
    sdk.require(spec is not None and spec.loader is not None, 'module missing')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

frames_reader = load('induction_frames', 'observe-position-search-275.py')
check = load('induction_certificate', 'phase_certificate_check_251.py')
c, model = check.c, check.model
label = 'position-induction-search-282'
terminal = json.loads((s / (label + '-TERMINAL.json')).read_text())
started = json.loads((s / (label + '-STARTED.json')).read_text())
try:
    os.killpg(started['pid'], 0)
except ProcessLookupError:
    pass
else:
    raise ValueError('prover process group is still live')
oracle = s / 'position-induction-oracle-281.py'
prepared = json.loads((s / 'POSITION_INDUCTION_ORDER_PREPARED_281.json').read_text())
sdk.require(sdk.snapshot(oracle).sha256 == prepared['oracle_sha256'], 'oracle changed')
sdk.require(not (s / 'position-induction-oracle-281.failed').exists(), 'oracle failed')
frames = frames_reader.frames_from_trace((s / (label + '.stderr')).read_text())
rows = [json.loads(line) for line in (s / 'position-induction-oracle-281.jsonl').read_text().splitlines()]
actual = Counter()
for raw, output in frames:
    goals = [int(line.split(':', 1)[0]) for line in raw.splitlines()]
    ranking = [int(line) for line in output.splitlines()]
    sdk.require(len(set(goals)) == len(goals) and sorted(goals) == sorted(ranking), 'goal removed or repeated')
    actual[(hashlib.sha256(raw.encode()).hexdigest(), tuple(goals), tuple(ranking))] += 1
logged = Counter((row['input_sha256'], tuple(row['goal_numbers']), tuple(row['ranking'])) for row in rows)
sdk.require(actual == logged, 'oracle frame/log mismatch')
record = {
    'completed': True, 'accepted': terminal['accepted'], 'terminal': terminal,
    'process_group_absent': True, 'oracle_frame_pairs_verified': len(frames),
    'selected_goal_families': dict(Counter((row.get('selected_prefix') or '').split('(', 1)[0] for row in rows)),
    'oracle_sha256': sdk.snapshot(oracle).sha256,
    'stderr_sha256': sdk.snapshot(s / (label + '.stderr'), maximum=64 * 1024**2).sha256,
    'scope': 'No protocol or branch bound; no previous helper is assumed. Other 18 full declarations retained with incomplete proof bodies in this isolated input.',
    'independent_replay_completed': False, 'release_claim_eligible': False,
}
if terminal['accepted']:
    helper = 'phase_position_event_is_unique'
    source = s / 'position-uniqueness-279.spthy'
    proof = s / (label + '-proof.spthy')
    sdk.require(terminal['required_verified_lemmas'] == [helper]
                and sdk.snapshot(source).sha256 == terminal['input_sha256']
                and sdk.snapshot(proof).sha256 == terminal['output_sha256'], 'certificate identity differs')
    original = model.parsed('position-induction-source-283', source)
    certificate = model.parsed('position-induction-certificate-283', proof)
    def compare(candidate):
        a, b = check.validated_model_comparison_text(original), check.validated_model_comparison_text(candidate)
        sdk.require(model.queries(a) == model.queries(b) and len(model.queries(a)) == 19, 'query changed')
        sdk.require([r for _,_,r in c.rules(a)] == [r for _,_,r in c.rules(b)], 'rule or annotation changed')
        sdk.require(c.declarations_outside_rules(a, model) == c.declarations_outside_rules(b, model), 'global declaration changed')
    compare(certificate)
    rules = {r.name:r for _,_,r in c.rules(model.uncomment(certificate))}
    modified = dict(rules)
    transition = modified['Offer_Signing_2']
    sdk.require(transition.premises[-1].name == 'PhasePosition', 'position premise absent')
    modified[transition.name] = replace(transition, premises=transition.premises[:-1])
    variants = {
        'missing_position_premise': c.replace_rules(model.uncomment(certificate), modified),
        'weakened_helper': certificate.replace(model.queries(certificate)[helper], model.queries(certificate)[helper].split('"',1)[0] + '"T"', 1),
        'missing_old_query': certificate.replace(model.queries(certificate)['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'], '', 1),
    }
    rejected = {}
    for name, candidate in variants.items():
        try:
            compare(candidate)
        except ValueError as exc:
            rejected[name] = str(exc)
        else:
            raise ValueError('mutation admitted: ' + name)
    record.update(complete_model_matches=True, complete_queries=19, negative_controls_rejected=rejected,
                  verified_steps=terminal['results'][helper]['steps'])
sdk.write_json(s / 'POSITION_INDUCTION_OBSERVED_283.json', record)
print(json.dumps({'accepted': record['accepted'], 'verified_callbacks': len(frames),
                  'complete_model_matches': record.get('complete_model_matches', False),
                  'selected_goal_families': record['selected_goal_families']}))
