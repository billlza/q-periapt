"""Require a real dependency rejection before the stronger witness search."""
from pathlib import Path
import json
import os
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
good = json.loads((s / 'POSITION_COMPOSITION_CERTIFIED_287.json').read_text())
negative = json.loads((s / 'position-missing-dependency-288-TERMINAL.json').read_text())
sdk.require(good['actual_no_search_replay_accepted'] and good['complete_model_matches'], 'helper composition incomplete')
sdk.require(negative['returncode'] == 0 and not negative['timed_out'] and not negative['output_exceeded']
            and not negative['accepted']
            and negative['input_sha256'] == good['negative_control_sha256']
            and negative['results']['phase_position_event_is_unique']['status'] == 'verified'
            and negative['results']['unproved_position_dependency']['status'] == 'analysis incomplete'
            and set(negative['required_verified_lemmas']) == {'unproved_position_dependency', 'phase_position_event_is_unique'},
            'actual missing-premise control did not reject a conditional success')
started = json.loads((s / 'position-missing-dependency-288-STARTED.json').read_text())
try:
    os.killpg(started['pid'], 0)
except ProcessLookupError:
    pass
else:
    raise ValueError('negative-control prover still live')
source = s / 'position-composed-285.spthy'
sdk.require(sdk.snapshot(source).sha256 == good['input_sha256'], 'composed source changed')
for extension in ('py', 'sh'):
    original = (s / ('phase-position-oracle-273.' + extension)).read_text()
    changed = original.replace('phase-position-oracle-273', 'composed-position-oracle-289')
    sdk.require(changed.replace('composed-position-oracle-289', 'phase-position-oracle-273') == original, 'oracle logic changed')
    path = s / ('composed-position-oracle-289.' + extension)
    with path.open('x') as stream:
        stream.write(changed)
    if extension == 'sh':
        path.chmod(0o700)
runner = (s / 'phase-position-run-273.py').read_text().replace('phase-position-oracle-273', 'composed-position-oracle-289')
with (s / 'composed-position-run-289.py').open('x') as stream:
    stream.write(runner)
sdk.write_json(s / 'COMPOSED_WITNESS_READY_289.json', {
    'completed': True, 'input': source.name, 'input_sha256': sdk.snapshot(source).sha256,
    'proved_dependencies': good['verified_helpers'], 'complete_queries': 19,
    'negative_control': {
        'terminal': 'position-missing-dependency-288-TERMINAL.json',
        'conditional_target_verified': True, 'unproved_dependency_incomplete': True,
        'accepted': False, 'prover_group_absent': True,
    },
    'selected_lemma': 'two_rounds_with_exact_phase_positions_is_executable',
    'oracle_logic_unchanged_from': 'phase-position-oracle-273.py',
    'comparison': 'All 18 old complete queries and operational declarations remain. The only model-level addition compared with failed witness274 is the actual independently replayed 29-step universal helper and its reuse attribute.',
    'time_budget_seconds': 900,
    'budget_reason': 'The old Ready replay alone previously took240s, and the new independent replay27s. A900s whole-process limit leaves bounded search time after required dependency validation; this is not a protocol bound.',
    'release_claim_eligible': False,
})
print(json.dumps({'conditional_control_correctly_rejected': True, 'dependencies': 2, 'queries': 19, 'ready': True}))
