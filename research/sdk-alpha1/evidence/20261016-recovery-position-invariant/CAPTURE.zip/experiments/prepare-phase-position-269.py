"""Check an unbounded position extension and a stronger concrete trace witness."""
from dataclasses import replace
from pathlib import Path
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, s / filename)
    sdk.require(spec is not None and spec.loader is not None, 'checker missing')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


qualified = json.loads((s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json').read_text())
sdk.require(sdk.snapshot(s / 'phase_certificate_check_251.py').sha256 == qualified['checker_sha256'], 'certificate checker changed')
check = load('position_certificate_check', 'phase_certificate_check_251.py')
codec = load('position_codec', 'phase_position_codec_268.py')
c, model = check.c, check.model
source = s / 'phase-markers-264.spthy'
prepared = json.loads((s / 'PHASE_MARKERS_PREPARED_264.json').read_text())
sdk.require(sdk.snapshot(source).sha256 == prepared['candidate_sha256'], 'observer model changed')
raw = source.read_text()
encoded = codec.encode(raw, c, model, sdk.require)
old_name = 'two_rounds_with_aligned_phase_owners_is_executable'
new_name = 'two_rounds_with_exact_phase_positions_is_executable'
formula = model.queries(raw)[old_name].split('"', 1)[1].rsplit('"', 1)[0]
quantifier = re.match(r'\s*∃\s+([^.]+)\.\s*(.*)\Z', formula, re.S)
sdk.require(quantifier is not None, 'complete existential formula missing')
anchors = [
    ('A', "'zero'", 'Ready', 'setup', 0), ('B', "'zero'", 'Ready', 'setup', 0),
    ('A', "'zero'", 'Offer3', 'os1', 3), ('B', "'zero'", 'Response4', 'or1', 1),
    ('B', "'zero'", 'Response6', 'rs1', 3), ('A', "'zero'", 'Final7', 'rr1', 4),
    ('A', "'zero'", 'Final8', 'fs1', 5), ('B', "'zero'", 'Receipt9', 'fr1', 4),
    ('B', "succ('zero')", 'Ready', 'b1', 5), ('A', "succ('zero')", 'Ready', 'ra1', 6),
    ('B', "succ('zero')", 'Offer1', 'g2', 6), ('B', "succ('zero')", 'Offer3', 'os2', 8),
    ('A', "succ('zero')", 'Response4', 'e2', 7), ('A', "succ('zero')", 'Response6', 'rs2', 9),
    ('B', "succ('zero')", 'Final7', 'rr2', 9), ('B', "succ('zero')", 'Final8', 'fs2', 10),
    ('A', "succ('zero')", 'Receipt9', 'fr2', 10), ('A', "succ(succ('zero'))", 'Ready', 'a2', 11),
    ('B', "succ(succ('zero'))", 'Ready', 'b2', 11),
]


def numeral(number):
    value = "'zero'"
    for _ in range(number):
        value = 'succ(' + value + ')'
    return value


extra = ' &\n '.join(f"PhaseStepMarker(phase_{role.lower()}_marker,s,'{role}',{epoch},'{phase}',{numeral(step)}) @ #{event}"
                     for role, epoch, phase, event, step in anchors)
new_query = (f'lemma {new_name}:\n exists-trace\n "∃ ' + quantifier[1] + '.\n (' + quantifier[2]
             + ') &\n (' + extra + ')"')
sdk.require(quantifier[2] in new_query and len(anchors) == 19, 'old witness matrix changed')
end = list(re.finditer(r'(?m)^end\s*$', encoded))
sdk.require(len(end) == 1, 'theory end differs')
candidate = encoded[:end[0].start()] + new_query + '\nby sorry\n\nend\n'
path = s / 'phase-position-269.spthy'
with path.open('x') as f:
    f.write(candidate)
old = model.parsed('phase-position-before-269', source)
new = model.parsed('phase-position-after-269', path)


def verify(value):
    return codec.verify(old, value, new_name, c, model, check.validated_model_comparison_text, sdk.require)


sdk.require(verify(new), 'counter erasure failed')
rules = {r.name: r for _, _, r in c.rules(model.uncomment(new))}
variants = {}
for label, change in (
    ('missing_counter_premise', lambda r: replace(r, premises=r.premises[:-1])),
    ('duplicated_counter_premise', lambda r: replace(r, premises=r.premises + (r.premises[-1],))),
    ('wrong_counter_owner', lambda r: replace(r, premises=r.premises[:-1] + (replace(r.premises[-1], args=(c.Term('wrong_owner'), r.premises[-1].args[1])),))),
    ('reset_counter', lambda r: replace(r, conclusions=r.conclusions[:-1] + (replace(r.conclusions[-1], args=(r.conclusions[-1].args[0], c.Term("'zero'"))),))),
    ('initial_only_counter_guard', lambda r: replace(r, premises=r.premises[:-1] + (replace(r.premises[-1], args=(r.premises[-1].args[0], c.Term("'zero'"))),))),
    ('counter_network_escape', lambda r: replace(r, conclusions=r.conclusions + (c.Fact('Out', (c.Term(codec.STEP),)),))),
):
    changed = dict(rules)
    changed['Offer_Signing_2'] = change(rules['Offer_Signing_2'])
    variants[label] = c.replace_rules(model.uncomment(new), changed)
variants['weakened_original_query'] = new.replace(model.queries(new)[old_name], 'lemma ' + old_name + ': exists-trace "T"', 1)
variants['new_restriction'] = new.replace('lemma ', 'restriction Hidden:\n "All s #i. Cut(s)@i ==> F"\n\nlemma ', 1)
rejected = {}
for name, value in variants.items():
    try:
        verify(value)
    except ValueError as exc:
        rejected[name] = str(exc)
    else:
        raise ValueError('mutation admitted: ' + name)
sdk.write_json(s / 'PHASE_POSITION_PREPARED_269.json', {
    'completed': True, 'source_sha256': sdk.snapshot(source).sha256,
    'candidate_sha256': sdk.snapshot(path).sha256,
    'codec_sha256': sdk.snapshot(s / 'phase_position_codec_268.py').sha256,
    'original_query_count': 17, 'candidate_query_count': 18,
    'negative_controls_rejected': rejected,
    'projection': 'Erase PhasePosition premises/conclusions and PhaseStepMarker actions. Every old rule, original action, message, equation, restriction and complete query is restored exactly.',
    'lifting': 'The checked base encoding creates two globally fresh private owner labels at Setup and preserves each through one-input/one-output phase transitions. Add one Position(owner,zero) at each initialization and advance it with succ at each transition of that lineage. There is no counter test, upper bound, join, fork or other use of the step variable. Thus each finite original trace lifts with its per-lineage transition count, for arbitrary trace length.',
    'stronger_witness': 'The entire old existential matrix is the first conjunct. Nineteen new observer conjuncts select the minimal two-round phase schedule; each lineage ends at step11. These concrete positions occur only in the added existential query, never as a protocol-round bound or a restriction.',
    'counter_is_not_application_nonce_or_epoch': True,
    'meta_equivalence_machine_proved': False,
    'required_before_reuse': 'Independently replay the existing Ready helper under this extension before treating it as a proved reusable premise; unchanged proof text alone is not acceptance.',
    'proof_search_started': False, 'proof_produced': False, 'release_claim_eligible': False,
})
print('Unbounded companion counters erase exactly; all 17 original queries remain; eight invalid transformations rejected. No proof search or security claim.')
