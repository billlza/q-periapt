"""Run the prepared witness search only after the current evaluator is gone."""
from pathlib import Path
import json
import os
import subprocess
import sys
import time
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
native = root / 'target/continuity-codeql-9c65-terminal-20261016/native-summary-normal-118'
started = json.loads((native / 'STARTED.json').read_text())
prepared = json.loads((s / 'PHASE_POSITION_ORDER_PREPARED_273.json').read_text())
certified = json.loads((s / 'PHASE_POSITION_HELPER_CERTIFIED_272.json').read_text())
label = 'phase-position-witness-search-274'
sdk.require(not any(s.glob(label + '*')), 'witness search output already exists')


def check_inputs():
    sdk.require(prepared['completed'] and certified['actual_no_search_replay_accepted'] and
                sdk.snapshot(s / 'phase-position-269.spthy').sha256 ==
                prepared['model_sha256'] == certified['input_sha256'], 'model/helper identity changed')
    for name, digest in prepared['files'].items():
        sdk.require(sdk.snapshot(s / name).sha256 == digest, 'prepared runner/oracle changed')
    sdk.require(not (s / 'phase-position-oracle-273.failed').exists() and
                not (s / 'phase-position-oracle-273.jsonl').exists(), 'oracle output is not fresh')


check_inputs()
argv = [sys.executable, '-I', '-S', '-B', '-W', 'error',
        str(root / 'artifact/python_bootstrap.py'), str(s / 'phase-position-run-273.py'),
        'phase-position-269.spthy', label, 'search', '600', '6', 'no-graph',
        'two_rounds_with_exact_phase_positions_is_executable']
sdk.write_json(s / 'PHASE_POSITION_SEARCH_QUEUED_274.json', {
    'state': 'waiting for native-summary-normal-118 terminal and process-group absence',
    'queue_pid': os.getpid(), 'wait_bound_seconds': 1800,
    'blocking_process_group': started['pid'], 'argv_after_wait': argv,
    'model_sha256': prepared['model_sha256'], 'search_started': False,
    'required_verified_lemmas': ['first_responder_ready_event_is_unique',
                                 'two_rounds_with_exact_phase_positions_is_executable'],
    'scope': 'Immediate dependent execution in the active goal; no recurring automation or protocol change.',
})
deadline = time.monotonic() + 1800
while not (native / 'TERMINAL.json').is_file():
    sdk.require(time.monotonic() < deadline, 'native terminal wait exceeded')
    time.sleep(1)
terminal = json.loads((native / 'TERMINAL.json').read_text())
sdk.require(terminal['query_sha256'] == started['query_sha256'], 'native control identity changed')
try:
    os.killpg(started['pid'], 0)
except ProcessLookupError:
    pass
else:
    raise ValueError('native evaluator process group is still live')
check_inputs()
sdk.write_json(s / 'PHASE_POSITION_SEARCH_RESOURCE_ADMISSION_274.json', {
    'prior_terminal_sha256': sdk.snapshot(native / 'TERMINAL.json').sha256,
    'prior_reason': terminal['reason'], 'prior_returncode': terminal['returncode'],
    'prior_process_group_absent': True, 'argv': argv,
    'scope': 'Resource admission only. Search success requires all selected and reusable lemmas verified.',
})
# The existing runner owns the prover's600second deadline, output bounds,
# process-group interruption and terminal receipt. An outer timeout must not
# kill that watchdog while leaving its separately grouped prover alive.
result = subprocess.run(argv, cwd=root)
sdk.require(result.returncode == 0, 'witness search driver failed')
receipt = json.loads((s / (label + '-TERMINAL.json')).read_text())
print(json.dumps({'search_driver_exit': result.returncode, 'accepted': receipt['accepted'],
                  'input_sha256': receipt['input_sha256']}), flush=True)
