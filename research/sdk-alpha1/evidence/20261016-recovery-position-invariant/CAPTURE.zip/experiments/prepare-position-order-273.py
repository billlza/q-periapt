"""Prioritize exact observer positions while retaining every original proof goal."""
from pathlib import Path
import ast
import json
import sys
from bounded_process import capture_output
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
certified = json.loads((s / 'PHASE_POSITION_HELPER_CERTIFIED_272.json').read_text())
sdk.require(certified['completed'] and certified['actual_no_search_replay_accepted'] and
            sdk.snapshot(s / 'phase-position-269.spthy').sha256 == certified['input_sha256'],
            'helper replay does not qualify the current model')
old_record = json.loads((s / 'PHASE_MARKER_ORDER_PREPARED_265.json').read_text())
for name, digest in old_record['files'].items():
    sdk.require(sdk.snapshot(s / name).sha256 == digest, 'prior ordering/runner changed')
old = (s / 'phase-marker-oracle-265.py').read_text()
addition = '''        marker = fact_arguments(goal, "PhaseStepMarker")
        if marker is not None:
            if len(marker) != 6:
                raise ValueError("phase step marker arity differs")
            order = ("setup", "os1", "or1", "rs1", "rr1", "fs1", "fr1", "b1", "ra1",
                     "g2", "os2", "e2", "rs2", "rr2", "fs2", "fr2", "a2", "b2")
            for position, event in enumerate(order):
                if re.search(r"@ #" + event + r"$", goal):
                    return -600 + position
            return -560
        position = fact_arguments(goal, "PhasePosition")
        if position is not None:
            if len(position) != 2:
                raise ValueError("phase position arity differs")
            return -500 + position[1].count("succ(")
'''
new = old.replace('phase-marker-oracle-265', 'phase-position-oracle-273')
needle = '        _, goal = item\n'
sdk.require(new.count(needle) == 1, 'score boundary differs')
new = new.replace(needle, needle + addition, 1)
sdk.require(new.replace(addition, '', 1).replace('phase-position-oracle-273', 'phase-marker-oracle-265') == old,
            'unrelated ranking logic changed')
files = {}
for name, data in (
    ('phase-position-oracle-273.py', new),
    ('phase-position-oracle-273.sh', (s / 'phase-marker-oracle-265.sh').read_text().replace('phase-marker-oracle-265', 'phase-position-oracle-273')),
    ('phase-position-run-273.py', (s / 'phase-marker-run-265.py').read_text().replace('phase-marker-oracle-265', 'phase-position-oracle-273')),
):
    path = s / name
    if name.endswith('.py'):
        ast.parse(data)
    with path.open('x') as f:
        f.write(data)
    if name.endswith('.sh'):
        path.chmod(0o700)
    files[name] = sdk.snapshot(path).sha256
out = s / 'phase-position-controls-273'
out.mkdir(mode=0o700)
controls = [
    ('mixed', "4: PhaseStepMarker(a,s,'A',n,'Final8',succ('zero')) @ #fs2\n2: !Peers(s,'A','B') ▶₀ #r\n8: PhaseStepMarker(a,s,'A','zero','Ready','zero') @ #setup\n1: PhaseMarker(a,s,'A',n,'Final8') @ #fs2\n3: PhasePosition(a,succ(succ('zero'))) ▶₄ #vr.1\n6: PhasePosition(a,'zero') ▶₄ #vr.2\n", [8, 4, 6, 3, 1, 2]),
    ('unknown_goal', '9: UnrecognizedButValid(a) @ #x\n', [9]),
    ('empty', '', []),
    ('bad_arity', '1: PhasePosition(a,b,c) ▶₀ #r\n', None),
    ('duplicate_goal', '1: PhasePosition(a,b) ▶₀ #r\n1: Saved(a,b) @ #s\n', None),
]
observed = []
lemma = 'two_rounds_with_exact_phase_positions_is_executable'
for label, raw, expected in controls:
    folder = out / label
    folder.mkdir(mode=0o700)
    script, source = folder / 'oracle.py', folder / 'input'
    script.write_text(new)
    source.write_text(raw)
    source.chmod(0o600)
    with source.open('rb') as f:
        result = capture_output([sys.executable, '-I', '-S', '-B', '-W', 'error',
                                 str(root / 'artifact/python_bootstrap.py'), str(script), lemma],
                                timeout_seconds=10, maximum_stdout_bytes=65536,
                                maximum_stderr_bytes=65536, stdin_fd=f.fileno())
    if expected is None:
        sdk.require(result.returncode != 0 and not result.stdout and
                    (folder / 'phase-position-oracle-273.failed').is_file(), 'malformed goal admitted')
    else:
        sdk.require(result.returncode == 0 and not result.stderr and
                    [int(x) for x in result.stdout.splitlines()] == expected, 'ranking differs')
    observed.append({'case': label, 'expected_ranking': expected, 'returncode': result.returncode})
sdk.write_json(s / 'PHASE_POSITION_ORDER_PREPARED_273.json', {
    'completed': True, 'model_sha256': certified['input_sha256'], 'files': files,
    'required_replayed_helper': certified['helper'], 'real_controls': observed,
    'ordering_change': 'Prioritize exact step-marker anchors, then their companion positions. Every original numbered goal is retained; no rule, query, restriction, search branch or required proof is removed.',
    'next_search': {'model': 'phase-position-269.spthy', 'lemma': lemma,
                    'maximum_seconds': 600, 'heap_gib': 6, 'threads': 1},
    'search_started': False, 'two_round_witness_proved': False, 'release_claim_eligible': False,
})
print(json.dumps({'real_ordering_controls': len(observed), 'search_started': False,
                  'all_original_goals_retained': True}))
