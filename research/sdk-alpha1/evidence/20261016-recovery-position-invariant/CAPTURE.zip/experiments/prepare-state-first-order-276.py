"""Test phase-state-before-position ordering on every retained real callback."""
from collections import Counter
from pathlib import Path
import ast
import importlib.util
import json
import sys
from bounded_process import capture_output
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
observation = json.loads((s / 'PHASE_POSITION_SEARCH_OBSERVED_275.json').read_text())
ready = json.loads((s / 'PHASE_POSITION_ORDER_PREPARED_273.json').read_text())
sdk.require(observation['completed'] and observation['process_group_absent'], 'previous search is not closed')
for name, digest in ready['files'].items():
    sdk.require(sdk.snapshot(s / name).sha256 == digest, 'prepared file changed')
sdk.require(sdk.snapshot(s / 'phase-position-269.spthy').sha256 == ready['model_sha256'], 'model changed')
spec = importlib.util.spec_from_file_location('state_first_trace', s / 'observe-position-search-275.py')
sdk.require(spec is not None and spec.loader is not None, 'trace checker missing')
trace = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = trace
spec.loader.exec_module(trace)
stderr = sdk.snapshot(s / 'phase-position-witness-search-274.stderr', maximum=64 * 1024**2)
sdk.require(stderr.sha256 == observation['stderr_sha256'], 'retained callback trace changed')
frames = trace.frames_from_trace(stderr.data.decode())
sdk.require(len(frames) == observation['oracle_frame_pairs_verified'] == 144, 'callback census differs')
old_name, new_name = 'phase-position-oracle-273', 'phase-state-first-oracle-276'
old = (s / (old_name + '.py')).read_text()
old_score = '            return -500 + position[1].count("succ(")\n'
new_score = '            return 4\n'
sdk.require(old.count(old_score) == 1, 'position ranking boundary differs')
candidate = old.replace(old_name, new_name).replace(old_score, new_score, 1)
sdk.require(candidate.replace(new_score, old_score, 1).replace(new_name, old_name) == old,
            'unrelated ordering change')
files = {}
for name, text in (
    (new_name + '.py', candidate),
    (new_name + '.sh', (s / (old_name + '.sh')).read_text().replace(old_name, new_name)),
    ('phase-state-first-run-276.py', (s / 'phase-position-run-273.py').read_text().replace(old_name, new_name)),
):
    path = s / name
    if name.endswith('.py'):
        ast.parse(text)
    with path.open('x') as f:
        f.write(text)
    if name.endswith('.sh'):
        path.chmod(0o700)
    files[name] = sdk.snapshot(path).sha256
folder = s / 'phase-state-first-controls-276'
folder.mkdir(mode=0o700)
changed_first = 0
states_before_positions = 0
families = Counter()
for index, (raw, prior) in enumerate(frames):
    case = folder / f'{index:03d}'
    case.mkdir(mode=0o700)
    script, source = case / 'oracle.py', case / 'input'
    script.write_text(candidate)
    source.write_text(raw)
    source.chmod(0o600)
    with source.open('rb') as f:
        result = capture_output([sys.executable, '-I', '-S', '-B', '-W', 'error',
                                 str(root / 'artifact/python_bootstrap.py'), str(script),
                                 'two_rounds_with_exact_phase_positions_is_executable'],
                                timeout_seconds=10, maximum_stdout_bytes=65536,
                                maximum_stderr_bytes=65536, stdin_fd=f.fileno())
    sdk.require(result.returncode == 0 and not result.stderr, 'oracle control failed')
    goals = {int(line.split(':', 1)[0]): line.split(':', 1)[1].strip() for line in raw.splitlines()}
    ranking = [int(line) for line in result.stdout.splitlines()]
    old_ranking = [int(line) for line in prior.splitlines()]
    sdk.require(sorted(ranking) == sorted(goals) and len(ranking) == len(set(ranking)),
                'new ordering omitted or duplicated a goal')
    states = [ranking.index(n) for n, goal in goals.items() if goal.startswith('PhaseState(')]
    positions = [ranking.index(n) for n, goal in goals.items() if goal.startswith('PhasePosition(')]
    if states and positions:
        sdk.require(max(states) < min(positions), 'phase-state-before-position contract failed')
        states_before_positions += 1
    changed_first += int(ranking[:1] != old_ranking[:1])
    families[(goals[ranking[0]] if ranking else '').split('(', 1)[0]] += 1
sdk.write_json(s / 'PHASE_STATE_FIRST_ORDER_PREPARED_276.json', {
    'completed': True, 'model_sha256': ready['model_sha256'], 'files': files,
    'real_callbacks_replayed': len(frames), 'callbacks_with_both_fact_kinds': states_before_positions,
    'changed_first_goal': changed_first, 'new_selected_families': dict(families),
    'only_strategy_change': 'PhasePosition score changes from -500+depth to4, after phase-tagged PhaseState goals and before attacker KU goals. Every original goal and all old model/query declarations remain. No depth or protocol bound was added.',
    'search_bounds_unchanged': '600seconds6GiBN1; helper and main must both verify',
    'search_started': False, 'proof_produced': False, 'release_claim_eligible': False,
})
print(json.dumps({'real_callbacks': len(frames), 'changed_first': changed_first,
                  'states_before_positions_checked': states_before_positions,
                  'new_selected_families': dict(families), 'proof_produced': False}))
