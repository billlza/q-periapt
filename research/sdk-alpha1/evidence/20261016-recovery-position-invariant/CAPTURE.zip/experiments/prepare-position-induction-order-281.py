"""Prepare a goal-order diagnostic for the independently stated token invariant."""
from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
old = (s / 'phase-position-oracle-273.py').read_text()
start, end = old.index('    def score(item):'), old.index('    ranked = sorted(goals, key=score)')
score = '''    def score(item):
        _, goal = item
        marker = fact_arguments(goal, "PhaseStepMarker")
        if marker is not None:
            if len(marker) != 6:
                raise ValueError("step marker arity differs")
            return -3
        position = fact_arguments(goal, "PhasePosition")
        if position is not None:
            if len(position) != 2:
                raise ValueError("position arity differs")
            return -2
        if goal.startswith("Fr("):
            return -1
        return 0
'''
oracle = (old[:start] + score + old[end:]).replace('phase-position-oracle-273', 'position-induction-oracle-281')
oracle_path = s / 'position-induction-oracle-281.py'
with oracle_path.open('x') as stream:
    stream.write(oracle)
wrapper = (s / 'phase-position-oracle-273.sh').read_text().replace('phase-position-oracle-273', 'position-induction-oracle-281')
wrapper_path = s / 'position-induction-oracle-281.sh'
with wrapper_path.open('x') as stream:
    stream.write(wrapper)
wrapper_path.chmod(0o700)
runner = (s / 'phase-position-run-273.py').read_text().replace('phase-position-oracle-273', 'position-induction-oracle-281')
with (s / 'position-induction-run-281.py').open('x') as stream:
    stream.write(runner)
# Test an isolated copy so control logs cannot be confused with prover callbacks.
control = s / 'position-induction-control-281.py'
with control.open('x') as stream:
    stream.write(oracle.replace('position-induction-oracle-281', 'position-induction-control-281'))
root = Path.cwd()
cases = (
    ("7: !KU( x ) @ #k\n2: PhasePosition( owner, n )[no_precomp] > #j\n9: PhaseStepMarker( owner, s, r, e, p, n ) @ #i\n", [9, 2, 7]),
    ("4: PhasePosition( owner, succ(n) )[no_precomp] > #j\n1: Fr( ~owner ) @ #i\n5: PhaseState( owner, s, r, e, p, data ) > #x\n", [4, 1, 5]),
    ("8: PhaseStepMarker( o, s, r, e, p, n ) @ #i\n3: PhaseStepMarker( o, s2, r2, e2, p2, n ) @ #j\n", [8, 3]),
    ("", []),
)
results = []
for raw, expected in cases:
    result = subprocess.run(['/opt/homebrew/opt/python@3.14/bin/python3.14', '-I', '-S', '-B', '-W', 'error', str(root / 'artifact/python_bootstrap.py'), str(control), 'phase_position_event_is_unique'], input=raw, capture_output=True, text=True, timeout=15, check=False)
    actual = [int(x) for x in result.stdout.splitlines()]
    sdk.require(result.returncode == 0 and not result.stderr and actual == expected, 'ordering control failed')
    sdk.require(sorted(actual) == sorted(int(line.split(':', 1)[0]) for line in raw.splitlines()), 'goal dropped')
    results.append({'input': raw, 'actual_ranking': actual})
sdk.write_json(s / 'POSITION_INDUCTION_ORDER_PREPARED_281.json', {
    'completed': True, 'controls': results,
    'oracle_sha256': sdk.snapshot(oracle_path).sha256,
    'input_unchanged': 'position-uniqueness-279.spthy',
    'purpose': 'After a terminal built-in-ranking control, isolate ordering that follows the two linear position predecessors. Full oracle input frames and all returned goal permutations are retained; no branch or model edits.',
    'proof_produced': False, 'release_claim_eligible': False,
})
print(json.dumps({'prepared': True, 'controls_passed': len(results)}))
