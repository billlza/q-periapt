from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent;repo=out.parent.parent
head='f0b861e2dcbafa4e4d5803363120354b31ccafff'
host=repo/'target/reference-exchange-hosted-01'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
result=json.loads((out/'checkout/target/exchange-result/RESULT.json').read_text())
assert result['source_commit']==head and result['completed'] is True and result['release_claim_eligible'] is False
for label,count in [('exchange',8),('client',10)]:
    observed=result[label+'_execution'];assert observed['tests']==count and observed['successful'] is True
    assert all(observed[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes'])
rows=json.loads((host/'READBACK_ubuntu-24.04-macos-15.json').read_text());assert len(rows)==2
entries={}
for p in sorted(out.iterdir()):
    if p.is_file() and p.suffix in {'.stdout','.stderr','.json','.py'}:entries['local/'+p.name]=p.read_bytes()
for p in sorted((out/'initial-failure').iterdir()):
    assert p.suffix=='.py' and p.is_file();entries['local/initial-failure/'+p.name]=p.read_bytes()
for p in sorted((out/'checkout/target/exchange-result').iterdir()):
    assert p.is_file() and p.suffix in {'.json','.stdout','.stderr','.txt','.whl'}
    entries['local/installed/'+p.name]=p.read_bytes()
for name,digest in result['source_inputs'].items():
    data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
    assert hashlib.sha256(data).hexdigest()==digest
    entries['source/'+head+'/'+name]=data
for row in rows:
    assert row['head']=='128569f3be4824d0c07d0291097c1e74ae833c07' and row['run']==39212845634 and row['members']==37
    folder=host/row['platform'];payload=(folder/'upstream.zip').read_bytes()
    assert len(payload)==row['artifact_bytes'] and 'sha256:'+hashlib.sha256(payload).hexdigest()==row['artifact_sha256']
    for name in ['upstream.zip','JOB.json','ARTIFACT.json']:
        entries['hosted/'+row['platform']+'/'+name]=(folder/name).read_bytes()
for name in ['COHORT.json','RUN_OBSERVED.json','READBACK_ubuntu-24.04-macos-15.json','readback.py','readback.stdout','readback.stderr']:
    entries['hosted/'+name]=(host/name).read_bytes()
host_head=rows[0]['head'];host_report=json.loads((host/'ubuntu-24.04/public/exchange/RESULT.json').read_text())
paths=set(host_report['source_inputs'])
paths.update(subprocess.check_output(['git','ls-tree','-r','--name-only',host_head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines())
for name in sorted(paths):entries['source/'+host_head+'/'+name]=subprocess.check_output(['git','show',host_head+':'+name],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-independent-enrollment-client';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist())==len(entries) and set(z.namelist())==set(entries)
    for name,value in manifest.items():
        body=z.read(name);assert len(body)==value['bytes'] and hashlib.sha256(body).hexdigest()==value['sha256']
checks={'source_commit':head,'local_installed':result,'hosted_prior_adapter':rows,
        'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
        'initial_failure':'Two assertions expected Provisioned, but existing Registration contract uses Preparing before a request. Fixed test expectations; original failing logs/source/private states retained. Not a product red/green claim.',
        'scope':'Local installed client10 and adapter8 tests with real signatures and5 SIGKILL cuts; explicit test issuer. Hosted earlier128569f3 adapter8, Node17 and Rust26 debug/release. Separate source cohorts, not combined lifecycle admission. No actual host account approval or operational signed-policy publisher.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text("""# Independent enrollment client checks

Local source `f0b861e2dcbafa4e4d5803363120354b31ccafff` adds a persistent
configuration coordinator and CLI for original device enrollment. It reuses the
existing encrypted journal and Registration owner; account authorization remains
external. The host retains the original client ID and wrapping key. No account
signup, private signing-key export or browser cookie is introduced.

A fresh wheel built from an ordinary immutable checkout was installed outside the
checkout. All 50 package modules, wheel metadata/licenses/RECORD and installed
bytes were verified before/after runtime. The installed adapter passed 8 checks;
the installed client passed 10 checks, with actual CLI subprocesses and 5 SIGKILL
cuts. No tests were skipped. The provider was cryptography48.0.1/OpenSSL4.0.1.

Three cuts recover the original device creation target, readiness target and
committed request. Two earlier cuts remain explicit failures: no formally
published original device intent means no discoverable original device. Recovery
does not recreate a signer or select an arbitrary orphan. Wrong keys/IDs, missing
active state, replacement authority and concurrent ownership are rejected. These
are component checks with fresh test issuers, not actual host-account approval.

The first source run had two wrong test expectations (`Provisioned` versus the
existing `Preparing` phase). The original failures and source snapshots are kept;
the repaired expectations preserve the existing contract. Source tests then
passed client10/adapter8, followed by the distinct installed-wheel run.

[Hosted run39212845634](https://github.com/billlza/q-periapt/actions/runs/39212845634)
checks the EARLIER source `128569f3be4824d0c07d0291097c1e74ae833c07` on Linuxx86_64
and AppleSilicon. Its terminal artifacts were verified against GitHub digests,
closed37-member inventories,63 Git-source inputs and the identical installed
48-module wheel. Both platforms passed adapter8, Node17 and Rust26 debug/release
entries (25 behavioral and1 dispatcher), formatting, strictClippy and build.
Those hosted results do not cover the newer client. No live CI logs were read.

The capture includes public logs, terminal metadata, both hosted archives,
source snapshots and the local inspected wheel. Private fixtures, wrapping keys,
account databases and client private images remain outside the capture. A public
manifest binds every member; no downloaded native executable was run.

Full session CLI integration, operational policy publication, real browser-to-client
authorization, the pre-publication first-use recovery transition and remaining
0.2.0 lifecycle/research/release requirements stay open. No physical-device rerun
or release-readiness claim is made by this receipt.
""")
print(json.dumps(checks['capture']))
