from pathlib import Path
import datetime
import json
import os
import platform
import re
import subprocess
import sys
import time
import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE=package.ROOT
REPO=SOURCE.parents[2]
STAGE=REPO/'target/continuity-throughput-resources-20261106'
kind,profile,label=sys.argv[1:]
assert kind in {'lifecycle','fanout'} and profile in {'local','witness'}
assert re.fullmatch(r'measurement-'+kind+'-'+profile+r'-[0-9]{2}',label)
build_file=STAGE/'build-01/OBSERVER_BUILD.json'
build=json.loads(build_file.read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True and build['tests_executed'] is False
assert sdk.inspect_package_source(SOURCE,allow_dirty=False)==(build['source_commit'],False)
outside=Path(json.loads((STAGE/'build-01/LOCATION.json').read_bytes())['path'])
consumer=outside/'observer'
binary=Path(build['binaries'][kind]['path'])
sdk_path=SOURCE/'target/sdk-020/RUST_SDK_PACKAGE.json'
assert sdk.snapshot(sdk_path).sha256==build['sdk_report_sha256']
sdk_report=json.loads(sdk_path.read_bytes())
candidate_root=SOURCE/'target/continuity-installed-rust-current'
candidate=json.loads((candidate_root/'CONTINUITY_PACKAGE.json').read_bytes())

def verify_inputs():
    assert sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binaries'][kind]['sha256']
    for name,digest in build['observer_source'].items():
        assert sdk.snapshot(consumer/name).sha256==digest
    for name,row in build['archives'].items():
        if name==package.NAME:
            archive=sdk.snapshot(candidate_root/candidate['archive']['file'])
            members=package.validate_candidate(archive.data,set(candidate['archive']['files']))
            version=package.VERSION
        else:
            archive=sdk.snapshot(sdk_path.parent/'crates'/sdk_report['crates'][name]['file'])
            members=sdk.archive_files(archive.data,name)
            version=sdk.VERSION
        assert archive.sha256==row['sha256'] and archive.size==row['bytes'] and len(members)==row['members']
        folder=consumer/'packages'/(name+'-'+version)
        assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}==set(members)
        for relative,data in members.items():
            assert sdk.snapshot(folder/relative).data==data

verify_inputs()
OUT=STAGE/'cohorts'/label
OUT.mkdir(mode=0o700,parents=True)
private=outside/(label+'-private')
private.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPC_','QPERIAPT_'))}
env.update(QPC_JOURNAL_PROFILE=profile,QPC_JOURNAL_OUTPUT=str(OUT/'RESULT.json'),
    QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(private/'installation'),RUST_BACKTRACE='1')
if kind=='fanout':
    env['QPC_FANOUT_LAYOUT']='peer'
processes=subprocess.run(['/bin/ps','-axo','pid,ppid,pcpu,pmem,etime,comm'],check=True,
    stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
assert processes.stderr==b''
concurrent=[line for line in processes.stdout.decode().splitlines()
    if re.search(r'qperiapt-continuity-package-|qperiapt-(?:operation|fanout|throughput)-resources-.*/build/|/(?:rustc|cargo|java)$',line)]
assert not concurrent,'another qualification process overlaps the measurement'
record={'completed':False,'kind':kind,'profile':profile,'source_commit':build['source_commit'],
    'binary_sha256':build['binaries'][kind]['sha256'],'build_report_sha256':sdk.snapshot(build_file).sha256,
    'driver_sha256':sdk.snapshot(Path(__file__)).sha256,'observer_source':build['observer_source'],
    'private_runtime':str(private),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'platform':platform.platform(),'machine':platform.machine(),'load_before':os.getloadavg(),
    'allocator_environment':{k:v for k,v in os.environ.items() if k.startswith('Malloc')},
    'concurrent_task_processes':concurrent,'performance_qualified':False,'release_claim_eligible':False,
    'scope':'Continuous serial workload observations on the recorded host, with original diagnostics and recovery checks retained. No saturation, maximum capacity, mobile energy or frozen product-budget claim.'}
started=time.monotonic()
try:
    record['hardware']=sdk.command(['/usr/sbin/sysctl','hw.model','hw.ncpu','hw.memsize','machdep.cpu.brand_string'],
        OUT/'hardware',SOURCE,environment=env).decode()
    stdout=sdk.command(['/usr/bin/time','-l','-o',str(OUT/'time.txt'),str(binary),
        '--exact','measure_installed_'+kind,'--nocapture','--test-threads=1'],
        OUT/'runtime',consumer,environment=env)
    assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out;',stdout,re.M)
    result=json.loads((OUT/'RESULT.json').read_bytes())
    assert result['schema_version']==2 and result['completed'] is True and result['profile']==profile
    assert result['kind']=='qperiapt.installed_'+kind+'_throughput'
    assert len(result['phases'])==3
    assert len(result['spans'])==(106 if kind=='lifecycle' else 89)
    assert len(result['effects'])==(49 if kind=='lifecycle' else 26)
    verify_inputs()
    assert sdk.inspect_package_source(SOURCE,allow_dirty=False)==(build['source_commit'],False)
    record.update(completed=True,sources_unchanged=True,result_sha256=sdk.snapshot(OUT/'RESULT.json',maximum=32*1024**2).sha256)
except BaseException as error:
    record['failure']=str(error)
    raise
finally:
    record.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        seconds=time.monotonic()-started,load_after=os.getloadavg(),private_runtime_preserved=True)
    sdk.write_json(OUT/'RUN.json',record)
print(json.dumps({'completed':record['completed'],'kind':kind,'profile':profile,
    'phases':3,'performance_qualified':False}),flush=True)
