from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

import continuity_package as package
import rust_sdk_profile as sdk
from installed_rust_graph import external_lock, verify_resolution
from rust_sdk_msrv import validate_report

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
STAGE = REPO / 'target/continuity-throughput-resources-20261106'
OUT = STAGE / 'build-01'
OUT.mkdir()
commit, dirty = sdk.inspect_package_source(SOURCE, allow_dirty=False)
assert commit == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8' and not dirty
outside = Path(tempfile.mkdtemp(prefix='qperiapt-throughput-resources-')).resolve()
consumer = outside / 'observer'
consumer.mkdir()
sdk.write_json(OUT / 'LOCATION.json', {'path': str(outside)})
template = STAGE / 'observer'
for path in template.rglob('*'):
    if path.is_file():
        sdk.copy(path, consumer / path.relative_to(template))
before = {p.relative_to(consumer).as_posix(): sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}
versions = {name: sdk.VERSION for name in sdk.CONSUMER_CRATES}
versions[package.NAME] = package.VERSION
report_path = SOURCE / 'target/sdk-020/RUST_SDK_PACKAGE.json'
pinned = sdk.snapshot(report_path)
cohort = validate_report(pinned.data,
    '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d',
    pinned.sha256, sdk.source_identity()['rust_workspace_sha256'])
archives = {}
members_by_package = {}
for name in sdk.CONSUMER_CRATES:
    row = cohort['crates'][name]
    actual = sdk.snapshot(report_path.parent / 'crates' / row['file'])
    assert actual.sha256 == row['sha256'] and actual.size == row['bytes']
    members_by_package[name] = sdk.archive_files(actual.data, name)
    assert set(members_by_package[name]) == set(row['files'])
    archives[name] = {'sha256': actual.sha256, 'bytes': actual.size, 'members': len(members_by_package[name])}
candidate_root = SOURCE / 'target/continuity-installed-rust-current'
producer = json.loads((candidate_root / 'CONTINUITY_PACKAGE.json').read_bytes())
assert producer['completed'] is True and producer['source_commit'] == commit
record = producer['archive']
package.verify_candidate_archive(candidate_root, record)
members_by_package[package.NAME] = package.validate_candidate(sdk.snapshot(candidate_root / record['file']).data, set(record['files']))
archives[package.NAME] = {'sha256': record['sha256'], 'bytes': record['bytes'], 'members': len(members_by_package[package.NAME])}
for name, members in members_by_package.items():
    for relative, data in members.items():
        target = consumer / 'packages' / (name + '-' + versions[name]) / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
known = {}
for lock in (SOURCE / 'Cargo.lock', package.CANDIDATE / 'Cargo.lock'):
    for identity, value in external_lock(lock.read_bytes()).items():
        assert identity not in known or known[identity] == value
        known[identity] = value
original = 'version = 4\n'
for (name, version), (registry, checksum) in sorted(known.items()):
    original += '\n[[package]]\nname=' + json.dumps(name) + '\nversion=' + json.dumps(version) + '\nsource=' + json.dumps(registry) + '\nchecksum=' + json.dumps(checksum) + '\n'
(consumer / 'Cargo.lock').write_text(original)
toolchain = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
assert not any((cache / name).exists() for name in ('config', 'config.toml', 'credentials', 'credentials.toml'))
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPC_', 'QPERIAPT_'))}
for key in ('CC', 'CXX', 'AR', 'LD', 'CPP', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH',
            'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'OBJC_INCLUDE_PATH', 'LIBRARY_PATH', 'SDKROOT',
            'MACOSX_DEPLOYMENT_TARGET', 'OPENSSL_CONF', 'OPENSSL_CONF_INCLUDE', 'OPENSSL_MODULES',
            'OPENSSL_ENGINES', 'SSL_CERT_FILE', 'SSL_CERT_DIR'):
    env.pop(key, None)
env.update(CARGO_HOME=str(cache), CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR=str(outside / 'build'), CARGO=str(toolchain / 'bin/cargo'), RUSTC=str(toolchain / 'bin/rustc'),
    RUSTDOC=str(toolchain / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
    DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'), PATH=str(toolchain / 'bin') + os.pathsep + env.get('PATH', os.defpath))

def run(argv, label):
    print(label, flush=True)
    return sdk.command(argv, OUT / label, consumer, environment=env)

result = {'completed': False, 'tests_executed': False, 'release_claim_eligible': False, 'source_commit': commit,
    'sdk_report_sha256': pinned.sha256, 'archives': archives, 'observer_source': before,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'Build-only installed lifecycle/fanout throughput observers with a shared monotonic phase clock. No workload or budget qualification yet.'}
try:
    cc = Path(run(['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'clang'], 'clang-path').decode().strip()).resolve()
    sdkroot = Path(run(['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path'], 'sdk-path').decode().strip()).resolve()
    env.update(CC=str(cc), CFLAGS='-isysroot ' + str(sdkroot))
    result['rustc'] = run([str(toolchain / 'bin/rustc'), '-vV'], 'rustc').decode()
    result['clippy'] = run([str(toolchain / 'bin/cargo-clippy'), '--version'], 'clippy-version').decode()
    result['clang'] = {'path': str(cc), 'sha256': sdk.snapshot(cc, maximum=256 * 1024**2).sha256,
        'version': run([str(cc), '--version'], 'clang-version').decode(),
        'sdk_settings_sha256': sdk.snapshot(sdkroot / 'SDKSettings.json').sha256}
    metadata = json.loads(run([str(toolchain / 'bin/cargo'), 'metadata', '--offline', '--format-version', '1'], 'metadata'))
    result['resolution'] = verify_resolution(metadata, consumer, (consumer / 'Cargo.lock').read_bytes(), original.encode(),
        consumer_name='q-periapt-continuity-throughput-observer', versions=versions)
    assert metadata['workspace_members'] == metadata['workspace_default_members'] == [metadata['resolve']['root']]
    before['Cargo.lock'] = sdk.snapshot(consumer / 'Cargo.lock').sha256
    sdk.copy(consumer / 'Cargo.lock', OUT / 'Cargo.lock')
    sdk.copy(consumer / 'Cargo.toml', OUT / 'Cargo.toml')
    raw = run([str(toolchain / 'bin/cargo'), 'test', '--release', '--locked', '--offline', '--test', 'journal_fanout', '--test', 'journal_lifecycle',
        '--no-run', '--message-format=json', '-j', '2'], 'compile')
    rows = [json.loads(line) for line in raw.splitlines()]
    binaries = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] in {'journal_fanout', 'journal_lifecycle'}]
    assert len(binaries) == 2 and {row['target']['name'] for row in binaries} == {'journal_fanout', 'journal_lifecycle'}
    result['binaries'] = {}
    for row in binaries:
        binary = Path(row['executable'])
        assert binary.parent == outside / 'build/release/deps'
        result['binaries'][row['target']['name'].removeprefix('journal_')] = {
            'path': str(binary), 'sha256': sdk.snapshot(binary, maximum=256 * 1024**2).sha256}
    run([str(toolchain / 'bin/cargo-clippy'), 'clippy', '--release', '--locked', '--offline', '--test', 'journal_fanout', '--test', 'journal_lifecycle',
        '-j', '2', '--', '-D', 'warnings'], 'clippy')
    for name, digest in before.items():
        assert sdk.snapshot(consumer / name).sha256 == digest
    for name, members in members_by_package.items():
        folder = consumer / 'packages' / (name + '-' + versions[name])
        assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()} == set(members)
        for relative, data in members.items():
            assert sdk.snapshot(folder / relative).data == data
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (commit, dirty)
    result.update(completed=True, sources_unchanged=True)
finally:
    sdk.write_json(OUT / 'OBSERVER_BUILD.json', result)
