from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE=sdk.ROOT
REPO=SOURCE.parents[2]
DRIVERS=SOURCE/'target/current-rust-readback'
STAGE=REPO/'target/continuity-throughput-resources-20261106'
OUT=STAGE/'repeats-01'
assert sdk.inspect_package_source(SOURCE,allow_dirty=False)==('5678d1019861fa1b04f3a219ba3fde7e0ddaaba8',False)
build=json.loads((STAGE/'build-01/OBSERVER_BUILD.json').read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True
cases=[('lifecycle','local'),('lifecycle','witness'),('fanout','local'),('fanout','witness')]
for kind,profile in cases:
    pilot=STAGE/'cohorts'/('measurement-'+kind+'-'+profile+'-01')
    run=json.loads((pilot/'RUN.json').read_bytes())
    reader=json.loads((pilot/'READBACK.json').read_bytes())
    assert run['completed'] is True and reader['validation']['operation_timeline_verified'] is True
    assert len(reader['altered_observation_controls'])==25
orders=[(0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1)]
plan=[]
for round_index,order in enumerate(orders):
    for position,case_index in enumerate(order):
        kind,profile=cases[case_index]
        label='measurement-'+kind+'-'+profile+f'-{round_index+2:02d}'
        assert not (STAGE/'cohorts'/label).exists()
        plan.append({'round':round_index+1,'position':position+1,'kind':kind,'profile':profile,'label':label})
OUT.mkdir()
controller_names=('run-throughput-cohort.py','readback-throughput.py',
    'readback-operation-repeat.py','readback-fanout.py','run-throughput-repeats.py')
controller_sources={name:hashlib.sha256((DRIVERS/name).read_bytes()).hexdigest() for name in controller_names}
protocol={'planned_before_execution':True,'source_commit':build['source_commit'],'rounds':4,'cohorts':16,'plan':plan,
    'binaries':build['binaries'],'build_report_sha256':hashlib.sha256((STAGE/'build-01/OBSERVER_BUILD.json').read_bytes()).hexdigest(),
    'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'controller_sources':controller_sources,
    'scope':'Four balanced orders, fresh fixture for each serial lifecycle/fanout cohort, unchanged installed archives. Complete measured epoch and two-epoch workload intervals include diagnostics and independent control. All observations retained; no saturation, maximum capacity, mobile energy or frozen product budget.',
    'host_controls':'Qualification processes must be absent at each boundary. Power, thermal-report and load snapshots retained; desktop applications/cache/clock frequency uncontrolled. No host setting changes.',
    'performance_qualified':False,'release_claim_eligible':False}
sdk.write_json(OUT/'PROTOCOL.json',protocol)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
records=[]

def host_snapshot(prefix):
    result=subprocess.run(['/bin/ps','-axo','pid,ppid,pcpu,pmem,etime,comm'],stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,check=True,timeout=30)
    assert result.stderr==b''
    concurrent=[line for line in result.stdout.decode().splitlines()
        if re.search(r'qperiapt-continuity-package-|qperiapt-(?:operation|fanout|throughput)-resources-.*/build/|/(?:rustc|cargo|java)$',line)]
    value={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),
        'concurrent_qualification_processes':concurrent}
    for option,name in [('batt','power'),('therm','thermal')]:
        response=subprocess.run(['/usr/bin/pmset','-g',option],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            check=True,timeout=30)
        assert response.stderr==b''
        value[name+'_report']=response.stdout.decode()
    sdk.write_json(prefix.with_suffix('.json'),value)
    assert not concurrent,'another qualification process overlaps this baseline'

def execute(argv,prefix):
    with prefix.with_suffix('.stdout').open('xb') as stdout,prefix.with_suffix('.stderr').open('xb') as stderr:
        process=subprocess.run(argv,cwd=SOURCE,env=os.environ.copy(),stdout=stdout,stderr=stderr)
    sdk.write_json(prefix.with_suffix('.json'),{'argv':argv,'cwd':str(SOURCE),'returncode':process.returncode})
    assert process.returncode==0,str(prefix)+': command failed'
    assert prefix.with_suffix('.stderr').read_bytes()==b'',str(prefix)+': unexpected diagnostics'

try:
    for index,case in enumerate(plan):
        step=OUT/f'step-{index+1:02d}';step.mkdir()
        assert all(hashlib.sha256((DRIVERS/name).read_bytes()).hexdigest()==digest for name,digest in controller_sources.items())
        host_snapshot(step/'host-before')
        begin=time.monotonic()
        execute(['sh',str(SOURCE/'artifact/python-run.sh'),str(DRIVERS/'run-throughput-cohort.py'),
            case['kind'],case['profile'],case['label']],step/'run')
        host_snapshot(step/'host-after')
        execute(['sh',str(SOURCE/'artifact/python-run.sh'),str(DRIVERS/'readback-throughput.py'),
            str(STAGE),case['label']],step/'readback')
        directory=STAGE/'cohorts'/case['label']
        run=json.loads((directory/'RUN.json').read_bytes())
        reader=json.loads((directory/'READBACK.json').read_bytes())
        assert all(hashlib.sha256((DRIVERS/name).read_bytes()).hexdigest()==digest for name,digest in controller_sources.items())
        assert run['completed'] is True and run['concurrent_task_processes']==[]
        assert reader['validation']['operation_timeline_verified'] is True
        record={**case,'completed':True,'controller_seconds':time.monotonic()-begin,
            'run_sha256':hashlib.sha256((directory/'RUN.json').read_bytes()).hexdigest(),
            'result_sha256':run['result_sha256'],
            'readback_sha256':hashlib.sha256((directory/'READBACK.json').read_bytes()).hexdigest(),
            'phases':len(reader['validation']['phases']),
            'effects':reader['validation']['native_workload']['effects'],
            'witness_exchanges':reader['validation']['native_workload']['witness_exchanges']}
        records.append(record)
        sdk.write_json(step/'PROGRESS.json',{'completed_cohorts':len(records),'planned_cohorts':16,'record':record})
        print(json.dumps(record),flush=True)
    sdk.write_json(OUT/'RESULT.json',{'completed':True,'started_utc':started,
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':records,
        'completed_cohorts':16,'performance_qualified':False,'release_claim_eligible':False})
except BaseException as error:
    sdk.write_json(OUT/'FAILURE.json',{'completed':False,'failure':str(error),
        'completed_cohorts':len(records),'cohorts':records,'failed_or_partial_evidence_preserved':True})
    raise
