from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import statistics
import sys
from evidence_io import parse_strict_json_bytes

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode

def load(path):
    return parse_strict_json_bytes(path.read_bytes(),label=str(path))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    value=Fraction(value)
    return {'numerator':value.numerator,'denominator':value.denominator}

def summarize(cohorts):
    groups=defaultdict(list)
    total_spans=total_effects=total_controls=total_witness=0
    for row in cohorts:
        record,readback=row['record'],row['readback']
        result=readback['validation']
        original=result['native_workload']
        assert result['operation_timeline_verified'] is True and len(result['phases'])==3
        total_spans+=original['spans']
        total_effects+=original['effects']
        total_controls+=len(readback['altered_observation_controls'])
        total_witness+=original['witness_exchanges']
        for phase in result['phases']:
            key=(record['kind'],record['profile'],phase['phase'],phase['epoch'])
            groups[key].append({'round':record['round'],'label':record['label'],**phase})
    assert len(cohorts)==16 and total_spans==1560 and total_effects==600 and total_controls==400
    assert total_witness==10452 and len(groups)==12
    summaries=[]
    for (kind,profile,name,epoch),rows in groups.items():
        assert len(rows)==4 and {row['round'] for row in rows}=={1,2,3,4}
        duration=sum(row['elapsed_ns'] for row in rows)
        deliveries=sum(row['confirmed_deliveries'] for row in rows)
        plaintext=sum(row['delivered_plaintext_bytes'] for row in rows)
        aggregates=sum(row['retired_aggregates'] for row in rows)
        rates=[Fraction(row['confirmed_deliveries']*1_000_000_000,row['elapsed_ns']) for row in rows]
        payload_rates=[Fraction(row['delivered_plaintext_bytes']*1_000_000_000,row['elapsed_ns']) for row in rows]
        pooled={'confirmed_deliveries_per_second':encoded(Fraction(deliveries*1_000_000_000,duration)),
            'delivered_plaintext_bytes_per_second':encoded(Fraction(plaintext*1_000_000_000,duration))}
        if kind=='fanout':
            pooled['retired_aggregates_per_second']=encoded(Fraction(aggregates*1_000_000_000,duration))
        durations=[row['elapsed_ns'] for row in rows]
        operation_ns=sum(row['measured_operation_wall_ns'] for row in rows)
        gaps=sum(row['outside_operation_spans_ns'] for row in rows)
        assert operation_ns+gaps==duration
        summaries.append({'kind':kind,'profile':profile,'phase':name,'epoch':epoch,'repetitions':4,
            'total_elapsed_ns':duration,'confirmed_deliveries':deliveries,
            'delivered_plaintext_bytes':plaintext,'retired_aggregates':aggregates,
            'control_updates':sum(row['control_updates'] for row in rows),
            'elapsed_ns':{'minimum':min(durations),'median':statistics.median(durations),'maximum':max(durations)},
            'pooled_rates':pooled,'per_run_delivery_rate':{'minimum':encoded(min(rates)),
                'median':encoded(statistics.median(rates)),'maximum':encoded(max(rates))},
            'per_run_plaintext_rate':{'minimum':encoded(min(payload_rates)),
                'median':encoded(statistics.median(payload_rates)),'maximum':encoded(max(payload_rates))},
            'measured_operation_wall_ns':operation_ns,'outside_operation_spans_ns':gaps,
            'omitted_denominator_fraction':encoded(Fraction(gaps,duration)),
            'sum_only_rate_overstatement_fraction':encoded(Fraction(gaps,operation_ns)),
            'witness_exchanges':sum(row['witness_exchanges'] for row in rows),
            'witness_exchanges_outside_operation_spans':sum(row['witness_exchanges_outside_operation_spans'] for row in rows),
            'process_cpu_user_us':sum(row['cpu_user_us'] for row in rows),
            'process_cpu_system_us':sum(row['cpu_system_us'] for row in rows),
            'all_phase_samples':rows})
    summary={'cohorts':16,'operation_spans':total_spans,'phase_intervals':48,'business_effects':total_effects,
        'negative_controls':total_controls,'witness_exchanges':total_witness,'phase_groups':12,
        'all_samples_retained':True,'nested_phase_intervals_not_added_together':True,
        'rate_method':'For each group, pool completed delivery or plaintext counts over the sum of complete measured interval durations. Never invert a per-call latency or sum nested epoch/workload intervals.',
        'scope':'Repeated observed serial workload rates on the recorded host, including diagnostics and independent control. No saturation, cross-host network, maximum-capacity, mobile-energy or frozen-budget claim.',
        'performance_qualified':False,'release_claim_eligible':False}
    return summary,summaries

def main():
    stage=Path(sys.argv[1])
    experiment=stage/'repeats-01'
    protocol=load(experiment/'PROTOCOL.json')
    completion=load(experiment/'RESULT.json')
    assert protocol['planned_before_execution'] is True and completion['completed'] is True
    assert completion['completed_cohorts']==len(completion['cohorts'])==16
    cohorts=[];host=[];inputs={}
    for index,(planned,record) in enumerate(zip(protocol['plan'],completion['cohorts'],strict=True)):
        assert all(record[k]==v for k,v in planned.items()) and record['completed'] is True
        directory=stage/'cohorts'/record['label']
        for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
            raw=(directory/name).read_bytes()
            assert sha(raw)==record[key]
            inputs[record['label']+'/'+name]={'bytes':len(raw),'sha256':sha(raw)}
        run=load(directory/'RUN.json');readback=load(directory/'READBACK.json')
        assert run['completed'] is True and run['concurrent_task_processes']==[]
        assert run['source_commit']==protocol['source_commit']
        assert run['binary_sha256']==protocol['binaries'][record['kind']]['sha256']
        assert readback['result_sha256']==run['result_sha256']
        snapshots=[load(experiment/f'step-{index+1:02d}'/(boundary+'.json')) for boundary in ('host-before','host-after')]
        assert all(row['concurrent_qualification_processes']==[] for row in snapshots)
        host.append({'label':record['label'],'before':snapshots[0],'after':snapshots[1],
            'hardware':run['hardware'],'allocator_environment':run['allocator_environment']})
        cohorts.append({'record':record,'readback':readback})
    summary,groups=summarize(cohorts)
    summary.update(source_commit=protocol['source_commit'],host_observations=host,
        started_utc=completion['started_utc'],completed_utc=completion['completed_utc'])
    out=stage/'analysis-01';out.mkdir()
    for name,value in [('SUMMARY.json',summary),('PHASE_SUMMARY.json',groups),('INPUTS.json',inputs)]:
        with (out/name).open('x') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in {'host_observations','scope','rate_method'}}))

if __name__=='__main__':
    main()
