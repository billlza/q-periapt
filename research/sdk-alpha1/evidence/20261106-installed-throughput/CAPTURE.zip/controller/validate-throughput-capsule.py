from pathlib import Path
import hashlib
import json
import math
import re
import runpy
import sys
import zipfile
from evidence_io import parse_strict_json_bytes

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
HERE=Path(__file__).resolve().parent
reader=runpy.run_path(str(HERE/'readback-throughput.py'),run_name='throughput_validation')
analysis=runpy.run_path(str(HERE/'analyze-throughput.py'),run_name='throughput_analysis')
archive_path,manifest_path,output_path=map(Path,sys.argv[1:])
manifest=parse_strict_json_bytes(manifest_path.read_bytes(),label='capsule inventory')
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check_rate(rate,count,duration):
    assert set(rate)=={'numerator','denominator'}
    n,d=rate['numerator'],rate['denominator']
    assert type(n) is int and type(d) is int and n>=0 and d>0 and math.gcd(n,d)==1
    assert n*duration==count*1_000_000_000*d
observed={};repeats=[];total_effects=total_spans=total_phases=total_controls=0
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist())==len(manifest) and set(archive.namelist())==set(manifest)
    for name,expected in manifest.items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
    def read(name):
        return parse_strict_json_bytes(archive.read(name),label=name)
    protocol=read('experiment/PROTOCOL.json')
    completion=read('experiment/RESULT.json')
    build=read('build/OBSERVER_BUILD.json')
    assert protocol['planned_before_execution'] is True and completion['completed'] is True
    assert completion['completed_cohorts']==len(completion['cohorts'])==16
    assert build['completed'] is True and build['sources_unchanged'] is True
    assert sha(archive.read('build/OBSERVER_BUILD.json'))==protocol['build_report_sha256']
    for name,digest in protocol['controller_sources'].items():
        assert sha(archive.read('controller/'+name))==digest
    entries=[]
    for kind,profile in [('lifecycle','local'),('lifecycle','witness'),('fanout','local'),('fanout','witness')]:
        entries.append({'kind':kind,'profile':profile,'label':'measurement-'+kind+'-'+profile+'-01',
            'prefix':'pilots/'+kind+'-'+profile+'/','pilot':True})
    for index,(planned,record) in enumerate(zip(protocol['plan'],completion['cohorts'],strict=True)):
        assert all(record[k]==v for k,v in planned.items()) and record['completed'] is True
        prefix=f'cohorts/{index+1:02d}/'
        for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
            assert sha(archive.read(prefix+name))==record[key]
        for boundary in ('host-before','host-after'):
            assert read(f'experiment/step-{index+1:02d}/{boundary}.json')['concurrent_qualification_processes']==[]
        entries.append({**record,'prefix':prefix,'pilot':False})
    for entry in entries:
        prefix=entry['prefix'];kind=entry['kind']
        run,value,original=[read(prefix+name) for name in ('RUN.json','RESULT.json','READBACK.json')]
        assert run['completed'] is True and run['sources_unchanged'] is True and run['concurrent_task_processes']==[]
        assert run['source_commit']==protocol['source_commit']=='5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
        assert run['profile']==entry['profile'] and run['kind']==kind
        assert run['binary_sha256']==build['binaries'][kind]['sha256']
        assert sha(archive.read(prefix+'RESULT.json'))==run['result_sha256']==original['result_sha256']
        assert read(prefix+'runtime.json')['returncode']==0 and archive.read(prefix+'runtime.stderr')==b''
        stdout=archive.read(prefix+'runtime.stdout')
        assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;',stdout,re.M)
        trace=[parse_strict_json_bytes(line,label='emitted operation') for line in re.findall(rb'OPERATION_RESOURCE_SPAN (.+)$',stdout,re.M)]
        phases=[parse_strict_json_bytes(line,label='emitted phase') for line in re.findall(rb'OPERATION_RESOURCE_PHASE (.+)$',stdout,re.M)]
        effect_prefix=prefix+'public-effects/'
        effects={name.removeprefix(effect_prefix):archive.read(name) for name in manifest if name.startswith(effect_prefix)}
        context=read(prefix+'PUBLIC_CONTEXT.json') if kind=='fanout' else None
        actual=reader['validate'](kind,value,trace,phases,effects,context)
        assert actual==original['validation']
        controls=reader['negative_controls'](kind,value,trace,phases,effects,context)
        assert controls==original['altered_observation_controls'] and len(controls)==25
        for phase in actual['phases']:
            check_rate(phase['rates']['confirmed_deliveries_per_second'],phase['confirmed_deliveries'],phase['elapsed_ns'])
            check_rate(phase['rates']['delivered_plaintext_bytes_per_second'],phase['delivered_plaintext_bytes'],phase['elapsed_ns'])
            if kind=='fanout':
                check_rate(phase['rates']['retired_aggregates_per_second'],phase['retired_aggregates'],phase['elapsed_ns'])
        observed[entry['label']]={'kind':kind,'profile':entry['profile'],'pilot':entry['pilot'],
            'spans':actual['native_workload']['spans'],'phases':len(actual['phases']),'effects':len(effects),
            'negative_controls_reexecuted':len(controls),'result_sha256':run['result_sha256']}
        total_effects+=len(effects);total_spans+=len(trace);total_phases+=len(phases);total_controls+=len(controls)
        if not entry['pilot']:
            record={k:v for k,v in entry.items() if k not in {'prefix','pilot'}}
            repeats.append({'record':record,'readback':original})
    assert len(observed)==20 and total_effects==750 and total_spans==1950 and total_phases==60 and total_controls==500
    summary,groups=analysis['summarize'](repeats)
    assert groups==read('analysis/PHASE_SUMMARY.json')
    expected=read('analysis/SUMMARY.json')
    assert all(expected[key]==value for key,value in summary.items())
    for group in groups:
        check_rate(group['pooled_rates']['confirmed_deliveries_per_second'],group['confirmed_deliveries'],group['total_elapsed_ns'])
        check_rate(group['pooled_rates']['delivered_plaintext_bytes_per_second'],group['delivered_plaintext_bytes'],group['total_elapsed_ns'])
        if group['kind']=='fanout':
            check_rate(group['pooled_rates']['retired_aggregates_per_second'],group['retired_aggregates'],group['total_elapsed_ns'])
record={'archive_sha256':sha(archive_path.read_bytes()),'members_verified':len(manifest),'cohorts':observed,
    'pilot_cohorts':4,'repeated_cohorts':16,'business_files_verified':750,'operation_spans_verified':1950,
    'phase_intervals_verified':60,'negative_controls_reexecuted':500,'phase_groups_reproduced':12,
    'exact_rate_cross_products_checked':True,'pilots_excluded_from_repeated_statistics':True,
    'private_runtime_accessed':False,'native_workload_rerun':False,
    'performance_qualified':False,'release_claim_eligible':False}
with output_path.open('x') as stream:stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='cohorts'}))
