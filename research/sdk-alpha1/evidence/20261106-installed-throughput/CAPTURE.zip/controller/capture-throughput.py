from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE=Path(__file__).resolve().parents[2]
REPO=SOURCE.parents[2]
STAGE=REPO/'target/continuity-throughput-resources-20261106'
DEST=REPO/'research/sdk-alpha1/evidence/20261106-installed-throughput'
build=json.loads((STAGE/'build-01/OBSERVER_BUILD.json').read_bytes())
completion=json.loads((STAGE/'repeats-01/RESULT.json').read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True
assert completion['completed'] is True and completion['completed_cohorts']==16
outside=Path(json.loads((STAGE/'build-01/LOCATION.json').read_bytes())['path'])
files={}
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(name,path):
    assert name not in files and path.is_file() and not path.is_symlink(),name
    files[name]=path
def tree(prefix,directory):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            add(prefix+'/'+path.relative_to(directory).as_posix(),path)
tree('build',STAGE/'build-01')
tree('experiment',STAGE/'repeats-01')
tree('analysis',STAGE/'analysis-01')
add('observer/INSTRUMENTATION.json',STAGE/'INSTRUMENTATION.json')
for name,digest in build['observer_source'].items():
    path=outside/'observer'/name
    assert sha(path.read_bytes())==digest
    add('observer/source/'+name,path)
for kind,record in build['binaries'].items():
    path=Path(record['path'])
    assert sha(path.read_bytes())==record['sha256']
    add('binaries/'+kind,path)
for name,row in build['archives'].items():
    version='0.0.0' if name=='q-periapt-continuity-identity-candidate' else '0.2.0'
    folder=SOURCE/('target/continuity-installed-rust-current' if version=='0.0.0' else 'target/sdk-020/crates')
    path=folder/(name+'-'+version+'.crate')
    assert path.stat().st_size==row['bytes'] and sha(path.read_bytes())==row['sha256']
    add('inputs/'+path.name,path)
for name,relative in [('RUST_SDK_PACKAGE.json','target/sdk-020/RUST_SDK_PACKAGE.json'),
    ('CONTINUITY_PACKAGE.json','target/continuity-installed-rust-current/CONTINUITY_PACKAGE.json')]:
    add('inputs/'+name,SOURCE/relative)
for index,record in enumerate(completion['cohorts']):
    directory=STAGE/'cohorts'/record['label']
    for name,key in [('RUN.json','run_sha256'),('RESULT.json','result_sha256'),('READBACK.json','readback_sha256')]:
        assert sha((directory/name).read_bytes())==record[key]
    tree(f'cohorts/{index+1:02d}',directory)
for kind,profile in [('lifecycle','local'),('lifecycle','witness'),('fanout','local'),('fanout','witness')]:
    directory=STAGE/'cohorts'/('measurement-'+kind+'-'+profile+'-01')
    run=json.loads((directory/'RUN.json').read_bytes())
    assert run['completed'] is True and sha((directory/'RESULT.json').read_bytes())==run['result_sha256']
    tree('pilots/'+kind+'-'+profile,directory)
for name in ('build-throughput-observers.py','run-throughput-cohort.py','readback-throughput.py',
    'readback-operation-repeat.py','readback-fanout.py','run-throughput-repeats.py',
    'analyze-throughput.py','validate-throughput-capsule.py','capture-throughput.py'):
    add('controller/'+name,SOURCE/'target/current-rust-readback'/name)
for path in sorted(STAGE.iterdir()):
    if path.is_file() and path.suffix in ('.stdout','.stderr'):
        add('controller/'+path.name,path)
for suffix in ('stdout','stderr'):
    add('controller/throughput-observers-build.'+suffix,SOURCE.parent/('throughput-observers-build.'+suffix))
readers={}
for name in ('python-run.sh','python-env.sh','python_bootstrap.py','evidence_io.py'):
    path=SOURCE/'artifact'/name
    original=subprocess.run(['git','show',build['source_commit']+':artifact/'+name],cwd=SOURCE,
        check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    assert original.stderr==b'' and original.stdout==path.read_bytes()
    readers['artifact/'+name]=sha(path.read_bytes())
    add('reader-source/artifact/'+name,path)
DEST.mkdir()
manifest={}
with zipfile.ZipFile(DEST/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):
        raw=path.read_bytes()
        manifest[name]={'bytes':len(raw),'sha256':sha(raw)}
        archive.writestr(name,raw)
with zipfile.ZipFile(DEST/'CAPTURE.zip') as archive:
    assert len(archive.namelist())==len(manifest) and set(archive.namelist())==set(manifest)
    for name,expected in manifest.items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
for name in ('SUMMARY.json','PHASE_SUMMARY.json'):
    (DEST/name).write_bytes((STAGE/'analysis-01'/name).read_bytes())
(DEST/'PROTOCOL.json').write_bytes((STAGE/'repeats-01/PROTOCOL.json').read_bytes())
(DEST/'INSTRUMENTATION.json').write_bytes((STAGE/'INSTRUMENTATION.json').read_bytes())
(DEST/'FILES.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(DEST/'READER_SOURCE.json').write_text(json.dumps({'source_commit':build['source_commit'],'files':readers},indent=2,sort_keys=True)+'\n')
summary={'source_commit':build['source_commit'],'bytes':(DEST/'CAPTURE.zip').stat().st_size,
    'sha256':sha((DEST/'CAPTURE.zip').read_bytes()),'members':len(manifest),
    'pilot_cohorts':4,'repeated_cohorts':16,'all_cohort_operation_spans':1950,'all_cohort_phase_intervals':60,
    'business_effect_files':750,'new_timing_controls':500,'actual_observer_binaries':build['binaries'],
    'all_members_reread':True,'private_runtime_included':False,
    'performance_qualified':False,'release_claim_eligible':False}
(DEST/'CAPTURE.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary))
