from collections import Counter
from fractions import Fraction
from pathlib import Path
import copy
import hashlib
import json
import re
import runpy
import sys
from evidence_io import parse_strict_json_bytes

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
HERE=Path(__file__).resolve().parent
saved_argv=sys.argv
try:
    sys.argv=[str(HERE/'readback-operation-repeat.py'),str(HERE)]
    lifecycle=runpy.run_path(str(HERE/'readback-operation-repeat.py'),run_name='lifecycle_validation')
    fanout=runpy.run_path(str(HERE/'readback-fanout.py'),run_name='fanout_validation')
finally:
    sys.argv=saved_argv

def require(value,message):
    if not value:
        raise ValueError(message)

def load(path):
    return parse_strict_json_bytes(path.read_bytes(),label=str(path))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def natural(value):
    return type(value) is int and value>=0

def ratio(numerator,denominator):
    value=Fraction(numerator,denominator)
    return {'numerator':value.numerator,'denominator':value.denominator}

def validate(kind,value,trace,phase_trace,effects,context):
    require(kind in {'lifecycle','fanout'},'unknown workload')
    require(type(value['schema_version']) is int and value['schema_version']==2
        and value['kind']=='qperiapt.installed_'+kind+'_throughput','throughput schema/kind differs')
    require(trace==value['spans'] and phase_trace==value['phases'],'raw emitted observations differ')
    projected=copy.deepcopy(value)
    phases=projected.pop('phases')
    projected['schema_version']=1
    projected['kind']='qperiapt.installed_'+('operation_resources' if kind=='lifecycle' else 'fanout_resources')
    projected_trace=[]
    previous=0
    for row in projected['spans']:
        start=row.pop('start_ns')
        end=row.pop('end_ns')
        require(natural(start) and natural(end) and previous<=start<end<900_000_000_000,
            'operation timeline is invalid or overlapping')
        require(end-start==row['elapsed_ns'],'operation duration differs from shared clock')
        previous=end
        projected_trace.append(copy.deepcopy(row))
    original=(lifecycle['validate'](projected,projected_trace,effects) if kind=='lifecycle'
        else fanout['validate'](projected,projected_trace,effects,context))
    require(type(phases) is list and len(phases)==3,'three complete phases required')
    require([(p['phase'],p['epoch']) for p in phases]==[('epoch',0),('epoch',1),('ordinary-workload',None)],
        'phase identity/order differs')
    prefixes=[{'requests':0,'framed_bytes':0,'read_ns':0,'handle_ns':0,'write_ns':0}]
    for row in value['witness']['rows']:
        next_prefix=dict(prefixes[-1])
        next_prefix['requests']+=1
        next_prefix['framed_bytes']+=7341
        for key in ('read_ns','handle_ns','write_ns'):
            next_prefix[key]+=row[key]
        prefixes.append(next_prefix)
    boundaries=[(4,52),(53,101),(4,101)] if kind=='lifecycle' else [(6,42),(44,80),(6,80)]
    phase_fields={'phase','epoch','first_span','past_last_span','start_ns','end_ns','elapsed_ns',
        'cpu_user_us','cpu_system_us','witness_before','witness_after','confirmed_deliveries',
        'delivered_plaintext_bytes','delivered_associated_data_bytes','retired_aggregates',
        'retained_outcome_reads','control_updates','measured_operation_wall_ns',
        'outside_operation_spans_ns','scope'}
    summaries=[]
    for phase,(first,last) in zip(phases,boundaries,strict=True):
        require(set(phase)==phase_fields,'phase field inventory differs')
        require(all(natural(v) for k,v in phase.items() if k not in
            {'phase','epoch','witness_before','witness_after','scope'}),'invalid phase integer')
        require(phase['epoch'] is None or type(phase['epoch']) is int,'invalid epoch type')
        require((phase['first_span'],phase['past_last_span'])==(first,last),'phase omits required operations')
        start,end=phase['start_ns'],phase['end_ns']
        require(start<end<900_000_000_000 and phase['elapsed_ns']==end-start,'phase duration differs from shared clock')
        require(value['spans'][first-1]['end_ns']<=start
            and end<=value['spans'][last]['start_ns'],'phase crosses neighboring operations')
        selected=value['spans'][first:last]
        for row in selected:
            require(start<=row['start_ns']<row['end_ns']<=end,'operation lies outside its phase')
        for bound in ('witness_before','witness_after'):
            snapshot=phase[bound]
            require(type(snapshot) is dict and set(snapshot)==set(prefixes[0])
                and all(natural(n) for n in snapshot.values()),'invalid phase Witness prefix')
            index=snapshot['requests']
            require(index<len(prefixes) and snapshot==prefixes[index],'phase Witness prefix is not exact')
        before,after=phase['witness_before']['requests'],phase['witness_after']['requests']
        require(before<=after and all(before<=row['witness_before']['requests']<=row['witness_after']['requests']<=after
            for row in selected),'phase excludes operation Witness requests')
        counts=Counter(row['operation'] for row in selected)
        deliveries=[row['outcome'] for row in selected if row['operation'] in ('send_confirmed','deliver_account_member')]
        expected={
            'confirmed_deliveries':len(deliveries),
            'delivered_plaintext_bytes':sum(row['payload_bytes'] for row in deliveries),
            'delivered_associated_data_bytes':sum(row['associated_data_bytes'] for row in deliveries),
            'retired_aggregates':counts['retire_account_operation'],
            'retained_outcome_reads':counts['retained_member_outcome'],
            'control_updates':counts['traffic_independent_rekey']+counts['traffic_independent_member_rekey'],
            'measured_operation_wall_ns':sum(row['elapsed_ns'] for row in selected),
        }
        require(all(phase[key]==expected_value for key,expected_value in expected.items()),'phase workload accounting differs')
        require(expected['confirmed_deliveries']>0 and phase['measured_operation_wall_ns']<=phase['elapsed_ns']
            and phase['outside_operation_spans_ns']==phase['elapsed_ns']-phase['measured_operation_wall_ns'],
            'phase gap/time conservation differs')
        if phase['epoch'] is not None:
            require(all(row['epoch']==phase['epoch'] for row in deliveries) and phase['control_updates']==0,
                'epoch phase includes another epoch or rekey')
        for key in ('cpu_user_us','cpu_system_us'):
            require(phase[key]>=sum(row[key] for row in selected),'phase CPU excludes measured operations')
        rates={'confirmed_deliveries_per_second':ratio(expected['confirmed_deliveries']*1_000_000_000,phase['elapsed_ns']),
            'delivered_plaintext_bytes_per_second':ratio(expected['delivered_plaintext_bytes']*1_000_000_000,phase['elapsed_ns'])}
        if kind=='fanout':
            rates['retired_aggregates_per_second']=ratio(expected['retired_aggregates']*1_000_000_000,phase['elapsed_ns'])
        attributed=sum(row['witness_after']['requests']-row['witness_before']['requests'] for row in selected)
        summaries.append({**phase,'witness_exchanges':after-before,'witness_framed_bytes':(after-before)*7341,
            'witness_exchanges_outside_operation_spans':after-before-attributed,'rates':rates})
    first,second,whole=phases
    require(whole['start_ns']<=first['start_ns']<first['end_ns']<=second['start_ns']
        <second['end_ns']<=whole['end_ns'],'phase nesting/epoch order differs')
    require(first['witness_after']['requests']<=second['witness_before']['requests'],
        'epoch Witness intervals overlap')
    expected_controls=1 if kind=='lifecycle' else 2
    require(whole['control_updates']==expected_controls and whole['confirmed_deliveries']==(48 if kind=='lifecycle' else 24),
        'whole workload is incomplete')
    return {'native_workload':original,'operation_timeline_verified':True,'phases':summaries,
        'rate_scope':'Observed continuous serial workload, including diagnostics and inter-epoch control. No saturation or frozen-budget claim.',
        'performance_qualified':False,'release_claim_eligible':False}

def negative_controls(kind,value,trace,phase_trace,effects,context):
    changes=[
        ('schema',lambda v:v.update(schema_version=1)),
        ('missing_phase',lambda v:v['phases'].pop()),
        ('phase_label',lambda v:v['phases'][0].update(phase='partial')),
        ('phase_epoch',lambda v:v['phases'][0].update(epoch=1)),
        ('phase_duration',lambda v:v['phases'][0].update(elapsed_ns=v['phases'][0]['elapsed_ns']-1)),
        ('phase_first_span',lambda v:v['phases'][0].update(first_span=v['phases'][0]['first_span']+1)),
        ('phase_last_span',lambda v:v['phases'][0].update(past_last_span=v['phases'][0]['past_last_span']-1)),
        ('phase_delivery_count',lambda v:v['phases'][0].update(confirmed_deliveries=v['phases'][0]['confirmed_deliveries']+1)),
        ('phase_payload_count',lambda v:v['phases'][0].update(delivered_plaintext_bytes=v['phases'][0]['delivered_plaintext_bytes']+1)),
        ('phase_ad_count',lambda v:v['phases'][0].update(delivered_associated_data_bytes=v['phases'][0]['delivered_associated_data_bytes']+1)),
        ('phase_retirement_count',lambda v:v['phases'][0].update(retired_aggregates=v['phases'][0]['retired_aggregates']+1)),
        ('phase_retained_reads',lambda v:v['phases'][0].update(retained_outcome_reads=v['phases'][0]['retained_outcome_reads']+1)),
        ('phase_control_count',lambda v:v['phases'][2].update(control_updates=0)),
        ('phase_gap_count',lambda v:v['phases'][0].update(outside_operation_spans_ns=0)),
        ('phase_cpu',lambda v:v['phases'][0].update(cpu_user_us=0)),
        ('phase_counter_boolean',lambda v:v['phases'][0].update(confirmed_deliveries=True)),
        ('phase_prefix',lambda v:v['phases'][0]['witness_before'].update(framed_bytes=v['phases'][0]['witness_before']['framed_bytes']+7341)),
        ('operation_duration',lambda v:v['spans'][5].update(elapsed_ns=v['spans'][5]['elapsed_ns']+1)),
        ('operation_time_boolean',lambda v:v['spans'][5].update(start_ns=True)),
        ('extra_operation_field',lambda v:v['spans'][5].update(unaccounted_delay=1)),
        ('completion',lambda v:v.update(completed=False)),
        ('effect_digest',lambda v:v['effects'][0]['sha3_256'].__setitem__(0,v['effects'][0]['sha3_256'][0]^1)),
    ]
    controls=[]
    for name,change in changes:
        altered=copy.deepcopy(value);change(altered)
        try:
            validate(kind,altered,altered['spans'],altered['phases'],effects,context)
        except ValueError as error:
            controls.append({'name':name,'rejection':str(error)})
        else:
            raise ValueError('altered throughput observation accepted: '+name)
    for name,changed_trace,changed_phases,changed_effects in [
        ('raw_operation_stream',trace[:-1],phase_trace,effects),
        ('raw_phase_stream',trace,phase_trace[:-1],effects),
        ('durable_business_bytes',trace,phase_trace,{**effects,next(iter(effects)):effects[next(iter(effects))]+b'changed'}),
    ]:
        try:
            validate(kind,value,changed_trace,changed_phases,changed_effects,context)
        except ValueError as error:
            controls.append({'name':name,'rejection':str(error)})
        else:
            raise ValueError('altered raw evidence accepted: '+name)
    return controls

def main():
    stage,label=Path(sys.argv[1]),sys.argv[2]
    directory=stage/'cohorts'/label
    run=load(directory/'RUN.json')
    kind=run['kind']
    require(kind in {'lifecycle','fanout'} and re.fullmatch('measurement-'+kind+'-'+run['profile']+'-[0-9]{2}',label) is not None,'cohort identity differs')
    require(run['completed'] is True and run['sources_unchanged'] is True
        and run['performance_qualified'] is False and run['release_claim_eligible'] is False,'cohort execution/scope differs')
    build=load(stage/'build-01/OBSERVER_BUILD.json')
    require(sha((stage/'build-01/OBSERVER_BUILD.json').read_bytes())==run['build_report_sha256']
        and run['binary_sha256']==build['binaries'][kind]['sha256'],'cohort binary/build identity differs')
    raw=(directory/'RESULT.json').read_bytes()
    require(sha(raw)==run['result_sha256'],'result bytes changed')
    value=parse_strict_json_bytes(raw,label='throughput observation')
    require(value['profile']==run['profile'],'profile differs')
    require(load(directory/'runtime.json')['returncode']==0 and (directory/'runtime.stderr').read_bytes()==b'','native execution diagnostics/failure')
    stdout=(directory/'runtime.stdout').read_bytes()
    require(re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;',stdout,re.M) is not None,'native success result absent')
    trace=[parse_strict_json_bytes(row,label='emitted operation') for row in re.findall(rb'OPERATION_RESOURCE_SPAN (.+)$',stdout,re.M)]
    phase_trace=[parse_strict_json_bytes(row,label='emitted phase') for row in re.findall(rb'OPERATION_RESOURCE_PHASE (.+)$',stdout,re.M)]
    private=Path(run['private_runtime'])/('installation' if kind=='lifecycle' else 'installation-account')
    effects={}
    names=['responder'] if kind=='lifecycle' else ['responder','responder-2']
    for index,name in enumerate(names):
        folder=private/name/'measured-effects'
        require(folder.is_dir() and not folder.is_symlink(),'business directory missing')
        for path in folder.iterdir():
            require(path.is_file() and not path.is_symlink() and re.fullmatch('[0-9a-f]{64}',path.name) is not None,'nonregular business file')
            effects[(str(index)+'/' if kind=='fanout' else '')+path.name]=path.read_bytes()
    context=({'owner_accounts':[list((private/name/'local-account').read_bytes())
        for name in ('initiator','responder','responder-2')]} if kind=='fanout' else None)
    result=validate(kind,value,trace,phase_trace,effects,context)
    controls=negative_controls(kind,value,trace,phase_trace,effects,context)
    public=directory/'public-effects';public.mkdir()
    for name,data in effects.items():
        target=public/name;target.parent.mkdir(exist_ok=True)
        with target.open('xb') as stream:stream.write(data)
    if context is not None:
        with (directory/'PUBLIC_CONTEXT.json').open('x') as stream:stream.write(json.dumps(context,indent=2,sort_keys=True)+'\n')
    record={'kind':kind,'profile':run['profile'],'source_commit':run['source_commit'],'binary_sha256':run['binary_sha256'],
        'result_sha256':sha(raw),'validation':result,'altered_observation_controls':controls}
    with (directory/'READBACK.json').open('x') as stream:stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'kind':kind,'profile':run['profile'],'phases':3,'effects':len(effects),
        'negative_controls':len(controls),'performance_qualified':False}))

if __name__=='__main__':
    main()
