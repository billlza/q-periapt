use super::{fixture, p, Result};
use p::connection_transport::{Actor, ConnectionEndpoint, Run};
use q_periapt_host_store::PolicyStore;
use q_periapt_rustls::connection::Credentials;
use std::{net::SocketAddr, path::Path, sync::Arc};
use zeroize::{Zeroize, Zeroizing};

pub struct Sender {
    pub service: p::DeviceService,
    pub contexts: Vec<Arc<p::BootstrapContext>>,
    signer: p::DeviceSigningKey,
    policy: Arc<p::VerifiedSessionPolicy>,
    sdk: PolicyStore,
    endpoints: Vec<ConnectionEndpoint>,
    certificate: Vec<u8>,
    private_key: Zeroizing<Vec<u8>>,
    peer_certificates: Vec<Vec<u8>>,
}
impl Sender {
    pub fn open(root: &Path, witness: Option<&fixture::WitnessFixture>, sessions: Option<&[[u8; 32]]>) -> Result<Self> {
        let sdk = fixture::sdk(root)?;
        let policy = fixture::protocol_policy(root, &sdk)?;
        let family = fixture::array(root, "family")?;
        let peers = [root.join("peer-0"), root.join("peer-1")];
        let contexts = peers.iter().map(|path| {
            fixture::with_bundle_for_family(path, family, |bundle, requirements| {
                Ok(Arc::new(bundle.verify(Arc::clone(&policy), requirements, fixture::now()?)?))
            })
        }).collect::<Result<Vec<_>>>()?;
        let local = contexts.first().ok_or("first account context")?.device(p::BootstrapRole::Initiator);
        let key = p::JournalKey::open(&root.join("wrap.key"))?;
        let signer = p::DeviceSigningKey::open(&root.join("signer.key"), &key,
            p::SigningKeyId::from_trusted_state(fixture::array(root, "signer-id")?)?)?;
        let paths = p::InstallationPaths::new(&root.join("installation.redb"), &root.join("journal.redb"), &root.join("archives.redb"))?;
        let installation = p::DeviceInstallation::open(paths, &key, local, &policy, fixture::now()?)?;
        let mut service = installation.activate(key, local, &policy, fixture::now()?,
            witness.map(|value| value.client(root)).transpose()?)?;
        if let Some(sessions) = sessions {
            if sessions.len() != peers.len() { return Err("original account sessions differ".into()); }
            for (path, session) in peers.iter().zip(sessions) {
                fixture::with_bundle_for_family(path, family, |bundle, requirements| {
                    let request = bundle.request_reopen(Arc::clone(&policy), requirements,
                        p::BootstrapRole::Initiator, *session, fixture::now()?)?;
                    service.reopen_peer(request, fixture::now()?)?;
                    Ok(())
                })?;
            }
        }
        let certificate = fixture::read(root, "tls-cert", 8192)?;
        let key = Zeroizing::new(fixture::read(root, "tls-key", 8192)?);
        let peer_certificates = peers.iter().map(|path| fixture::read(path, "tls-peer", 8192)).collect::<Result<Vec<_>>>()?;
        let endpoints = peer_certificates.iter().zip(&contexts).map(|(peer, context)| {
            Ok(ConnectionEndpoint::client(context, Credentials {
                certificate: &certificate, private_key: &key, peer_certificate: peer,
            }, fixture::tls_limits())?)
        }).collect::<Result<Vec<_>>>()?;
        Ok(Self { service, contexts, signer, policy, sdk, endpoints,
            certificate, private_key: key, peer_certificates })
    }
    pub fn establish(&mut self, index: usize, address: SocketAddr) -> Result<[u8; 32]> {
        let context = self.contexts.get(index).ok_or("account context index")?;
        let (journal, archives) = self.service.stores()?;
        let established = self.endpoints.get(index).ok_or("account endpoint index")?.establish(
            Actor { journal, archives, context, signer: &self.signer }, p::InitiationId::generate()?,
            Run { address, server_name: "responder.test", limits: fixture::limits(), cancel: &p::Cancellation::default() }, fixture::now)?;
        Ok(established.session)
    }
    pub fn send(&mut self, index: usize, address: SocketAddr, input: p::FanoutInput<'_>, session: [u8; 32], cancel: &p::Cancellation)
        -> std::result::Result<p::connection_transport::AccountDelivered, p::connection_transport::Error> {
        let context = self.contexts.get(index).ok_or(p::connection_transport::Error::Binding)?;
        let (journal, archives) = self.service.stores()?;
        self.endpoints.get(index).ok_or(p::connection_transport::Error::Binding)?.send_account_member(
            Actor { journal, archives, context, signer: &self.signer }, input, session,
            Run { address, server_name: "responder.test", limits: p::connection_transport::RunLimits { exchanges: 1, ..fixture::limits() }, cancel }, fixture::now)
    }
    pub fn rekey(&mut self, index: usize, session: [u8; 32], address: SocketAddr, target: u64) -> Result<p::control_transport::Completed> {
        let context = self.contexts.get(index).ok_or("rekey context index")?;
        let control = p::control_transport::ControlEndpoint::client(context, session, Credentials {
            certificate: &self.certificate, private_key: &self.private_key,
            peer_certificate: self.peer_certificates.get(index).ok_or("rekey TLS peer")?,
        }, fixture::tls_limits())?;
        let (journal, _) = self.service.stores()?;
        Ok(control.run(p::control_transport::Session { journal, context, signer: &self.signer },
            p::control_transport::Run { target, address, server_name: "responder.test",
                limits: fixture::limits(), cancel: &p::Cancellation::default() }, fixture::now)?)
    }
    pub fn close(&mut self) {
        for endpoint in &self.endpoints { endpoint.close(); }
        self.service.close(); self.signer.close(); self.policy.close(); self.sdk.close();
        self.private_key.zeroize();
    }
}
impl Drop for Sender { fn drop(&mut self) { self.close(); } }
