use super::{check, cpu, observer_io, witness_snapshot, Result};
use serde_json::{json, Value};
use std::time::Instant;

pub struct Phase<'a> {
    clock: &'a Instant,
    name: &'static str,
    epoch: Option<u64>,
    first_span: usize,
    start_ns: u128,
    cpu_before: [u64; 2],
    witness_before: Value,
}

impl<'a> Phase<'a> {
    pub fn start(
        clock: &'a Instant,
        witness: Option<&observer_io::Witness>,
        name: &'static str,
        epoch: Option<u64>,
        first_span: usize,
    ) -> Result<Self> {
        let witness_before = witness_snapshot(witness)?;
        let cpu_before = cpu()?;
        let start_ns = clock.elapsed().as_nanos();
        Ok(Self { clock, name, epoch, first_span, start_ns, cpu_before, witness_before })
    }

    pub fn finish(self, witness: Option<&observer_io::Witness>, spans: &[Value]) -> Result<Value> {
        let end_ns = self.clock.elapsed().as_nanos();
        let cpu_after = cpu()?;
        let witness_after = witness_snapshot(witness)?;
        let elapsed_ns = end_ns.checked_sub(self.start_ns).ok_or("phase clock moved backwards")?;
        check(elapsed_ns > 0, "empty phase duration")?;
        let selected = spans.get(self.first_span..).ok_or("phase span boundary missing")?;
        check(!selected.is_empty(), "phase has no completed operations")?;
        let mut previous_end = self.start_ns;
        let mut operation_wall_ns = 0u128;
        let mut confirmed_deliveries = 0u64;
        let mut delivered_plaintext_bytes = 0u64;
        let mut delivered_associated_data_bytes = 0u64;
        let mut retired_aggregates = 0u64;
        let mut retained_outcome_reads = 0u64;
        let mut control_updates = 0u64;
        for row in selected {
            let start = u128::from(row["start_ns"].as_u64().ok_or("operation start missing")?);
            let end = u128::from(row["end_ns"].as_u64().ok_or("operation end missing")?);
            let duration = u128::from(row["elapsed_ns"].as_u64().ok_or("operation duration missing")?);
            check(self.start_ns <= start && previous_end <= start && start < end && end <= end_ns,
                "operation outside or overlapping phase")?;
            check(end - start == duration, "operation clock interval differs")?;
            previous_end = end;
            operation_wall_ns = operation_wall_ns.checked_add(duration).ok_or("phase time overflow")?;
            match row["operation"].as_str().ok_or("operation label missing")? {
                "send_confirmed" | "deliver_account_member" => {
                    let outcome = &row["outcome"];
                    if let Some(epoch) = self.epoch {
                        check(outcome["epoch"].as_u64() == Some(epoch), "delivery belongs to another epoch")?;
                    }
                    confirmed_deliveries = confirmed_deliveries.checked_add(1).ok_or("delivery count overflow")?;
                    delivered_plaintext_bytes = delivered_plaintext_bytes.checked_add(
                        outcome["payload_bytes"].as_u64().ok_or("payload count missing")?
                    ).ok_or("payload counter overflow")?;
                    delivered_associated_data_bytes = delivered_associated_data_bytes.checked_add(
                        outcome["associated_data_bytes"].as_u64().ok_or("associated data count missing")?
                    ).ok_or("associated data counter overflow")?;
                }
                "retire_account_operation" => {
                    retired_aggregates = retired_aggregates.checked_add(1).ok_or("retirement count overflow")?;
                }
                "retained_member_outcome" => {
                    retained_outcome_reads = retained_outcome_reads.checked_add(1).ok_or("retained count overflow")?;
                }
                "traffic_independent_rekey" | "traffic_independent_member_rekey" => {
                    control_updates = control_updates.checked_add(1).ok_or("control count overflow")?;
                }
                "next_message_id" | "next_account_id" => {}
                other => return Err(format!("unexpected ordinary phase operation: {other}").into()),
            }
        }
        check(confirmed_deliveries > 0 && operation_wall_ns <= elapsed_ns, "phase conservation failed")?;
        let cpu_user_us = cpu_after[0].checked_sub(self.cpu_before[0]).ok_or("phase user CPU moved backwards")?;
        let cpu_system_us = cpu_after[1].checked_sub(self.cpu_before[1]).ok_or("phase system CPU moved backwards")?;
        let value = json!({
            "phase":self.name,"epoch":self.epoch,"first_span":self.first_span,"past_last_span":spans.len(),
            "start_ns":self.start_ns,"end_ns":end_ns,"elapsed_ns":elapsed_ns,
            "cpu_user_us":cpu_user_us,"cpu_system_us":cpu_system_us,
            "witness_before":self.witness_before,"witness_after":witness_after,
            "confirmed_deliveries":confirmed_deliveries,"delivered_plaintext_bytes":delivered_plaintext_bytes,
            "delivered_associated_data_bytes":delivered_associated_data_bytes,
            "retired_aggregates":retired_aggregates,"retained_outcome_reads":retained_outcome_reads,
            "control_updates":control_updates,"measured_operation_wall_ns":operation_wall_ns,
            "outside_operation_spans_ns":elapsed_ns-operation_wall_ns,
            "scope":"Continuous serial workload interval, including surrounding status checks, data preparation and observation overhead. Whole-process CPU and shared Witness; no saturation or per-client budget claim."
        });
        println!("OPERATION_RESOURCE_PHASE {value}");
        Ok(value)
    }
}
