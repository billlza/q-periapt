//! Operation observations using actual installed owners; no frozen resource budget.
#[path = "../packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;
mod observer_phase;
mod observer_account;

use observer_peer::{Server, Task};
use p::connection_transport::{AccountDeliveryOutcome, Consumption, Error};
use q_periapt_continuity_identity_candidate as p;
use q_periapt_core::Xof256;
use serde_json::{json, Value};
use std::{fs, io::Write, path::PathBuf, sync::Arc, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;

fn check(value: bool, message: &str) -> Result<()> {
    if value { Ok(()) } else { Err(message.to_owned().into()) }
}
fn body(index: usize, length: usize) -> Vec<u8> {
    (0..length).map(|offset| ((index + offset) % 251) as u8).collect()
}
fn digest(bytes: &[u8]) -> [u8; 32] {
    let mut hash = q_periapt_backends::Sha3_256Xof::new();
    hash.absorb_public(bytes);
    hash.squeeze32()
}
unsafe extern "C" { fn qpc_observer_memory(values: *mut u64) -> i32; }
fn memory(stage: &str, paths: &[PathBuf]) -> Result<Value> {
    let mut values = [0u64; 6];
    let status = unsafe { qpc_observer_memory(values.as_mut_ptr()) };
    check(status == 0, &format!("task_info failed: {status}"))?;
    let databases = paths.iter().map(|path| Ok(fs::metadata(path.join("journal.redb"))?.len())).collect::<Result<Vec<_>>>()?;
    Ok(json!({"stage":stage,"resident_bytes":values[0],"physical_footprint_bytes":values[1],
        "malloc_blocks_in_use":values[2],"malloc_size_in_use_bytes":values[3],
        "malloc_max_size_in_use_bytes":values[4],"malloc_size_allocated_bytes":values[5],"journal_database_bytes":databases}))
}

fn cpu() -> Result<[u64; 2]> {
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    if unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    let usage = unsafe { usage.assume_init() };
    let convert = |value: libc::timeval| -> Result<u64> {
        let seconds = u64::try_from(value.tv_sec)?;
        let micros = u64::try_from(value.tv_usec)?;
        check(micros < 1_000_000, "invalid CPU microseconds")?;
        seconds.checked_mul(1_000_000).and_then(|n| n.checked_add(micros)).ok_or_else(|| "CPU counter overflow".into())
    };
    Ok([convert(usage.ru_utime)?, convert(usage.ru_stime)?])
}
fn witness_snapshot(witness: Option<&observer_io::Witness>) -> Result<Value> {
    match witness {
        Some(witness) => witness.snapshot(),
        None => Ok(json!({"requests":0,"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0})),
    }
}
fn measure(clock: &Instant, witness: Option<&observer_io::Witness>, name: &str, action: impl FnOnce() -> Result<Value>) -> Result<Value> {
    let before = witness_snapshot(witness)?;
    let cpu_before = cpu()?;
    let start_ns = clock.elapsed().as_nanos();
    let outcome = action()?;
    let end_ns = clock.elapsed().as_nanos();
    let elapsed_ns = end_ns.checked_sub(start_ns).ok_or("operation clock moved backwards")?;
    let cpu_after = cpu()?;
    let after = witness_snapshot(witness)?;
    let delta = [cpu_after[0].checked_sub(cpu_before[0]).ok_or("user CPU moved backwards")?,
        cpu_after[1].checked_sub(cpu_before[1]).ok_or("system CPU moved backwards")?];
    let observed = json!({"operation":name,"start_ns":start_ns,"end_ns":end_ns,"elapsed_ns":elapsed_ns,"cpu_user_us":delta[0],"cpu_system_us":delta[1],
        "witness_before":before,"witness_after":after,"outcome":outcome});
    println!("OPERATION_RESOURCE_SPAN {observed}");
    Ok(observed)
}

fn targets<'a>(contexts: &'a [Arc<p::BootstrapContext>], sessions: &[[u8; 32]]) -> Result<Vec<p::FanoutTarget<'a>>> {
    check(contexts.len() == 2 && sessions.len() == 2, "complete two-member target set required")?;
    Ok(contexts.iter().zip(sessions).map(|(context, session)| p::FanoutTarget { context, session: *session }).collect())
}

#[test]
fn measure_installed_fanout() -> Result<()> {
    let clock = Instant::now();
    let mut phases = Vec::new();
    let profile = std::env::var("QPC_JOURNAL_PROFILE")?;
    let layout = std::env::var("QPC_FANOUT_LAYOUT")?;
    check(matches!(profile.as_str(), "local" | "witness") && matches!(layout.as_str(), "own" | "peer"), "unknown resource profile")?;
    let output = PathBuf::from(std::env::var_os("QPC_JOURNAL_OUTPUT").ok_or("output required")?);
    let private = PathBuf::from(std::env::var_os("QPERIAPT_PUBLIC_SERVICE_EVIDENCE").ok_or("private root required")?);
    check(output.is_absolute() && !output.exists() && private.is_absolute() && !private.exists(), "fresh absolute paths required")?;
    let mut witness = if profile == "witness" { Some(observer_io::Witness::start(&private.with_extension("witness"))?) } else { None };
    let pin = witness.as_ref().map(|w| &w.configured);
    let mut spans = Vec::new();
    let mut setup_result = None;
    spans.push(measure(&clock, witness.as_ref(), "provision_three_installed_owners", || {
        setup_result = Some(fixture::setup_devices(pin, None, None, true, layout == "own", true)?);
        Ok(json!({"owners":3,"recipients":2,"layout":layout}))
    })?);
    let (setup, second) = setup_result.ok_or("setup result missing")?;
    let second = second.ok_or("second recipient missing")?;
    let paths = vec![setup.initiator.clone(), setup.responder.clone(), second.clone()];
    let recipient_paths = [setup.responder.clone(), second];
    let account = fixture::array::<32>(&setup.responder, "local-account")?;
    check(account == fixture::array::<32>(&recipient_paths[1], "local-account")?, "recipient account mismatch")?;
    check((account == fixture::array::<32>(&setup.initiator, "local-account")?) == (layout == "own"), "account layout mismatch")?;
    let mut opened = None;
    spans.push(measure(&clock, witness.as_ref(), "open_sender", || {
        opened = Some(observer_account::Sender::open(&setup.initiator, pin, None)?);
        Ok(json!({"opened":true}))
    })?);
    let mut sender = opened.ok_or("sender missing")?;
    let mut servers = Vec::new();
    for (index, path) in recipient_paths.iter().enumerate() {
        spans.push(measure(&clock, witness.as_ref(), "open_recipient", || {
            let configured = pin.map(|w| fixture::WitnessFixture { store: Arc::clone(&w.store), address: w.address });
            let server = Server::start(path.clone(), configured)?;
            let open_ns = server.open_ns;
            servers.push(server);
            Ok(json!({"recipient":index,"sdk_open_ns":open_ns}))
        })?);
    }
    let mut sessions = Vec::new();
    for (index, server) in servers.iter().enumerate() {
        spans.push(measure(&clock, witness.as_ref(), "establish_member", || {
            server.begin(Task::Bootstrap)?;
            let session = sender.establish(index, server.address)?;
            let peer = server.finish_operation()?;
            check(peer["established"] == json!(session), "bootstrap identities differ")?;
            sessions.push(session);
            Ok(json!({"recipient":index,"session":session,"peer":peer}))
        })?);
    }
    let mut resources = vec![memory("established", &paths)?];
    let payloads = [(64usize, 0usize), (1024, 32), (16384, 1024)];
    let mut effects = Vec::new();
    let mut batches = Vec::new();
    let ordinary = observer_phase::Phase::start(&clock, witness.as_ref(), "ordinary-workload", None, spans.len())?;
    let mut epoch_phase = Some(observer_phase::Phase::start(&clock, witness.as_ref(), "epoch", Some(0), spans.len())?);
    for batch_index in 0..12usize {
        let (length, ad_length) = payloads[batch_index % payloads.len()];
        let plaintext = body(batch_index, length);
        let ad = body(batch_index + 73, ad_length);
        let contexts = sender.contexts.clone();
        let selected = targets(&contexts, &sessions)?;
        let mut next = None;
        spans.push(measure(&clock, witness.as_ref(), "next_account_id", || {
            let id = sender.service.stores()?.0.next_fanout_id()?; next = Some(id);
            Ok(json!({"batch_index":batch_index,"batch":id.as_bytes()}))
        })?);
        let batch = next.ok_or("next batch missing")?;
        for offset in 0..2 {
            let index = (batch_index + offset) % 2;
            spans.push(measure(&clock, witness.as_ref(), "deliver_account_member", || {
                servers[index].begin(Task::Message { fail_after_effect:false })?;
                let delivered = sender.send(index, servers[index].address,
                    p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad },
                    sessions[index], &p::Cancellation::default())?;
                let peer = servers[index].finish_operation()?;
                check(matches!(delivered.outcome, AccountDeliveryOutcome::Consumption(Consumption::Confirmed)) && delivered.exchanges == 1, "member was not consumed")?;
                check(peer["effects"] == 1 && peer["calls"] == 1, "member effect count differs")?;
                effects.push((index, delivered.message, plaintext.clone()));
                Ok(json!({"batch_index":batch_index,"batch":batch.as_bytes(),"recipient":index,"member_order":offset,
                    "epoch":batch_index/6,"payload_bytes":length,"associated_data_bytes":ad_length,
                    "message":delivered.message.as_bytes(),"exchanges":delivered.exchanges,"peer":peer}))
            })?);
        }
        for (index, server) in servers.iter().enumerate() {
            spans.push(measure(&clock, witness.as_ref(), "retained_member_outcome", || {
                let retained = sender.send(index, server.address,
                    p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad },
                    sessions[index], &p::Cancellation::default())?;
                check(retained.exchanges == 0 && matches!(retained.outcome, AccountDeliveryOutcome::Consumption(Consumption::Confirmed)), "retained member changed outcome")?;
                Ok(json!({"batch_index":batch_index,"batch":batch.as_bytes(),"recipient":index,"exchanges":retained.exchanges,"message":retained.message.as_bytes()}))
            })?);
        }
        spans.push(measure(&clock, witness.as_ref(), "retire_account_operation", || {
            sender.service.stores()?.0.retire_fanout(batch, &selected)?;
            Ok(json!({"batch_index":batch_index,"batch":batch.as_bytes()}))
        })?);
        check(sender.service.stores()?.0.fanout_status(batch)? == p::FanoutStatus::Retired, "batch was not durably retired")?;
        batches.push(batch);
        if batch_index == 5 {
            phases.push(epoch_phase.take().ok_or("first epoch phase missing")?.finish(witness.as_ref(), &spans)?);
            resources.push(memory("epoch-zero-complete", &paths)?);
            for (index, server) in servers.iter().enumerate() {
                spans.push(measure(&clock, witness.as_ref(), "traffic_independent_member_rekey", || {
                    server.begin(Task::Rekey { session:sessions[index], target:1 })?;
                    let done = sender.rekey(index, sessions[index], server.address, 1)?;
                    let peer = server.finish_operation()?;
                    check(done.epoch == 1 && peer["epoch"] == 1, "member epoch not confirmed")?;
                    Ok(json!({"recipient":index,"epoch":1,"exchanges":done.exchanges,"peer":peer}))
                })?);
            }
            epoch_phase = Some(observer_phase::Phase::start(&clock, witness.as_ref(), "epoch", Some(1), spans.len())?);
        }
    }
    phases.push(epoch_phase.take().ok_or("second epoch phase missing")?.finish(witness.as_ref(), &spans)?);
    phases.push(ordinary.finish(witness.as_ref(), &spans)?);
    resources.push(memory("ordinary-batches-complete", &paths)?);
    let contexts = sender.contexts.clone();
    let selected = targets(&contexts, &sessions)?;
    let mut next = None;
    spans.push(measure(&clock, witness.as_ref(), "next_uncertain_account_id", || {
        let id = sender.service.stores()?.0.next_fanout_id()?; next = Some(id);
        Ok(json!({"batch":id.as_bytes()}))
    })?);
    let batch = next.ok_or("uncertain batch missing")?;
    let plaintext = body(12, 1024);
    let ad = body(85, 32);
    spans.push(measure(&clock, witness.as_ref(), "member_effect_committed_result_lost", || {
        servers[0].begin(Task::Message { fail_after_effect:true })?;
        let outcome = sender.send(0, servers[0].address,
            p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad },
            sessions[0], &p::Cancellation::default());
        let last_error = match outcome {
            Err(Error::RetryExhausted { attempts:1, last }) => format!("{last:?}"),
            other => return Err(format!("expected original member uncertainty: {other:?}").into()),
        };
        let peer = servers[0].finish_operation()?;
        check(peer["application_result_lost"] == true && peer["effects"] == 1 && peer["calls"] == 1, "unknown member did not commit exactly one effect")?;
        Ok(json!({"batch":batch.as_bytes(),"recipient":0,"attempts":1,"last_error":last_error,"peer":peer}))
    })?);
    check(sender.service.stores()?.0.fanout_status(batch)? == p::FanoutStatus::Committed, "uncertain batch no longer committed")?;
    let original = sender.service.stores()?.0.send_account_message(
        p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad }, fixture::now()?)?;
    let original_wires = original.into_iter().map(|member| match member.output {
        p::FanoutOutput::Committed(wire) => Ok((member.session, member.message, wire)),
        _ => Err("uncertain batch lost original committed wire".into()),
    }).collect::<Result<Vec<_>>>()?;
    check(original_wires.len() == 2, "original member wire count")?;
    spans.push(measure(&clock, witness.as_ref(), "reopen_three_original_owners", || {
        for server in &servers { server.begin(Task::Reopen)?; }
        sender.close();
        sender = observer_account::Sender::open(&setup.initiator, pin, Some(&sessions))?;
        let peers = servers.iter().map(Server::finish_operation).collect::<Result<Vec<_>>>()?;
        check(peers.iter().all(|peer| peer["reopened"] == true), "recipient reopen failed")?;
        Ok(json!({"batch":batch.as_bytes(),"peers":peers}))
    })?);
    let contexts = sender.contexts.clone();
    let selected = targets(&contexts, &sessions)?;
    let recovered = sender.service.stores()?.0.send_account_message(
        p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad }, fixture::now()?)?;
    for member in recovered {
        let original = original_wires.iter().find(|(session, _, _)| *session == member.session).ok_or("original session missing")?;
        let p::FanoutOutput::Committed(wire) = member.output else { return Err("reopened member lost ciphertext".into()); };
        check(member.message == original.1 && wire == original.2, "original member identity/ciphertext changed")?;
    }
    for (index, server) in servers.iter().enumerate() {
        spans.push(measure(&clock, witness.as_ref(), "deliver_original_uncertain_account_member", || {
            server.begin(Task::Message { fail_after_effect:false })?;
            let delivered = sender.send(index, server.address,
                p::FanoutInput { id:batch, account, targets:&selected, plaintext:&plaintext, associated_data:&ad },
                sessions[index], &p::Cancellation::default())?;
            let peer = server.finish_operation()?;
            let original = original_wires.iter().find(|(session, _, _)| *session == sessions[index]).ok_or("retry session missing")?;
            check(delivered.message == original.1 && matches!(delivered.outcome, AccountDeliveryOutcome::Consumption(Consumption::Confirmed)), "original member result changed")?;
            check(peer["calls"] == 1 && peer["effects"] == json!(index), "retry duplicated original effect")?;
            effects.push((index, delivered.message, plaintext.clone()));
            Ok(json!({"recipient":index,"batch":batch.as_bytes(),"message":delivered.message.as_bytes(),"wire_bytes":original.2.len(),"wire_sha3_256":digest(&original.2),"peer":peer}))
        })?);
    }
    spans.push(measure(&clock, witness.as_ref(), "retire_recovered_account_operation", || {
        sender.service.stores()?.0.retire_fanout(batch, &selected)?;
        Ok(json!({"batch":batch.as_bytes()}))
    })?);
    check(sender.service.stores()?.0.fanout_status(batch)? == p::FanoutStatus::Retired, "recovered batch did not retire")?;
    batches.push(batch);
    let mut next = None;
    spans.push(measure(&clock, witness.as_ref(), "next_cancelled_account_id", || {
        let id = sender.service.stores()?.0.next_fanout_id()?; next = Some(id);
        Ok(json!({"batch":id.as_bytes()}))
    })?);
    let cancelled = next.ok_or("cancelled batch missing")?;
    spans.push(measure(&clock, witness.as_ref(), "pre_cancelled_account_delivery", || {
        let cancel = p::Cancellation::default(); cancel.cancel();
        let result = sender.send(0, servers[0].address,
            p::FanoutInput { id:cancelled, account, targets:&selected, plaintext:b"not admitted", associated_data:b"" }, sessions[0], &cancel);
        check(matches!(result, Err(Error::Cancelled)), "pre-cancelled account send had another outcome")?;
        Ok(json!({"batch":cancelled.as_bytes(),"cancelled":true}))
    })?);
    check(sender.service.stores()?.0.fanout_status(cancelled)? == p::FanoutStatus::Absent
        && sender.service.stores()?.0.next_fanout_id()? == cancelled, "cancelled account reserved or advanced its original ID")?;
    resources.push(memory("recovered-and-cancelled", &paths)?);
    let mut server_summaries = Vec::new();
    for (index, server) in servers.iter_mut().enumerate() {
        let summary = server.finish()?;
        check(summary["effects"] == 13 && summary["calls"] == json!(if index == 0 { 14 } else { 13 }), "recipient business count differs")?;
        server_summaries.push(summary);
    }
    check(effects.len() == 26 && batches.len() == 13, "whole account workload incomplete")?;
    let mut public_effects = Vec::new();
    for (index, id, plaintext) in &effects {
        let filename = fixture::hex(id.as_bytes());
        let actual = fs::read(recipient_paths[*index].join("measured-effects").join(&filename))?;
        let mut expected = sessions[*index].to_vec(); expected.extend_from_slice(id.as_bytes()); expected.extend_from_slice(plaintext);
        check(actual == expected, "durable account effect bytes differ")?;
        public_effects.push(json!({"recipient":index,"file":filename,"bytes":actual.len(),"sha3_256":digest(&actual)}));
    }
    spans.push(measure(&clock, witness.as_ref(), "close_sender", || {
        sender.close(); check(sender.service.stores().is_err(), "closed sender retains journal access")?;
        Ok(json!({"closed":true}))
    })?);
    let final_witness = witness_snapshot(witness.as_ref())?;
    let witness_record = match witness.as_mut() {
        Some(witness) => witness.finish()?,
        None => json!({"rows":[],"closed":true,"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0}),
    };
    drop(sender); drop(servers); drop(witness);
    resources.push(memory("owners-closed", &paths)?);
    let result = json!({"schema_version":2,"kind":"qperiapt.installed_fanout_throughput","completed":true,
        "profile":profile,"layout":layout,"recipient_count":2,"account":account,"sessions":sessions,
        "ordinary_batches":12,"ordinary_member_deliveries":24,"total_batches":13,"effects":public_effects,"servers":server_summaries,
        "spans":spans,"phases":phases,"resources":resources,"witness":witness_record,"final_witness_snapshot":final_witness,
        "payload_matrix":[[64,0],[1024,32],[16384,1024]],"samples_per_payload_per_epoch":2,"epochs":[0,1],
        "scope":"Three pre-provisioned installed DeviceService owners, two current signed-roster recipients, real hybrid TLS and optional required signed-TCP Witness in one process. Complete original fanout, retained consumption, retirement and orderly reopen after lost application result. CPU/memory include peers, Witness and observer. No process crash, registry/login enrollment, 32-recipient capacity, mobile energy or frozen performance budget claim.",
        "release_claim_eligible":false});
    let mut file = fs::OpenOptions::new().create_new(true).write(true).open(output)?;
    file.write_all(&serde_json::to_vec_pretty(&result)?)?; file.sync_all()?;
    println!("FANOUT_RESOURCE_COMPLETE profile={profile} layout={layout} ordinary=12 effects=26");
    Ok(())
}

