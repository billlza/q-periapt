"""Preserve the failed run and recheck the final archive guard on its real bytes."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

import continuity_package as package
import rust_sdk_profile as sdk

out = Path("target/installed-final-archive-01")
archive = Path("target/ci-fd42-installed-linux-terminal.zip")
expected = "7cd6e5e2696cad397d67c5b9bc262eda16154f4dc8d74572d5e817b780ba6c7f"
sdk.require(hashlib.sha256(archive.read_bytes()).hexdigest() == expected, "download hash")
with zipfile.ZipFile(archive) as z:
    report = json.loads(z.read("CONTINUITY_PACKAGE.json"))
    sdk.require(report["failure"] == "name 'filename' is not defined" and not report["completed"]
                and not report["partition_completed"], "original failure changed")
    record = report["archive"]
    payload = z.read(record["file"])
    sdk.require(hashlib.sha256(payload).hexdigest() == record["sha256"]
                and len(payload) == record["bytes"], "candidate archive mismatch")
    actual = out / "actual"
    actual.mkdir()
    (actual / record["file"]).write_bytes(payload)
    public = out / "public"
    public.mkdir()
    names = ["CONTINUITY_PACKAGE.json", "sources-before.json", "consumer-debug.stdout", "consumer-release.stdout"]
    for profile in ("debug", "release"):
        for label in ("c-input-compile", "c-input-contract"):
            for suffix in ("json", "stdout", "stderr"):
                name = f"{label}-{profile}.{suffix}"
                names.append(name)
            receipt = json.loads(z.read(f"{label}-{profile}.json"))
            sdk.require(receipt["returncode"] == 0, "C input command failed")
        compile_receipt = json.loads(z.read(f"c-input-compile-{profile}.json"))
        sdk.require({"-std=c11", "-Werror", "-Wpedantic"} <= set(compile_receipt["argv"]), "strict C11 flags")
        sdk.require(z.read(f"c-input-contract-{profile}.stdout") ==
                    b"CONSUMER_INPUT_PASS c11=true seek_set_cur_end=true exact_position=true original_bytes=true\n",
                    "C input runtime result")
        sdk.require(report["c_consumer"]["execution"][profile]["input_contract"]["completed"], "C input record")
    for name in names:
        (public / name).write_bytes(z.read(name))

old = subprocess.check_output(["git", "show", "fd42b370:artifact/continuity_package.py"]).decode()
old_qualify = next(n for n in ast.parse(old).body if isinstance(n, ast.FunctionDef) and n.name == "qualify")
old_statement = next(n for n in ast.walk(old_qualify) if isinstance(n, ast.Expr)
                     and "candidate archive changed" in ast.get_source_segment(old, n))
(out / "old-guard.py.txt").write_text(ast.get_source_segment(old, old_statement) + "\n")
environment = {"sdk": sdk, "output": actual, "result": {"archive": record},
               "verify_candidate_archive": package.verify_candidate_archive}
try:
    exec(compile(ast.Module(body=[old_statement], type_ignores=[]), "old-final-guard", "exec"), environment)
except NameError as error:
    sdk.require(str(error) == "name 'filename' is not defined", "different old guard failure")
else:
    raise ValueError("old guard unexpectedly succeeded")
current = Path(package.__file__).read_text()
new_qualify = next(n for n in ast.parse(current).body if isinstance(n, ast.FunctionDef) and n.name == "qualify")
statement = next(n for n in ast.walk(new_qualify) if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                 and isinstance(n.value.func, ast.Name) and n.value.func.id == "verify_candidate_archive")
exec(compile(ast.Module(body=[statement], type_ignores=[]), "new-final-guard", "exec"), environment)
result = {"head": report["source_commit"], "run": 39119367383, "job": 117653451578,
          "artifact": 12136726947, "artifact_bytes": archive.stat().st_size, "artifact_sha256": expected,
          "original_completed": False, "original_failure": report["failure"],
          "C11_runtime_profiles_reverified": ["debug", "release"],
          "original_guard_reproduced": True, "new_actual_callsite_passed_on_original_archive": True,
          "candidate_archive": {k: record[k] for k in ("file", "sha256", "bytes")},
          "focused_tests": 30, "new_full_installed_run": "not yet run",
          "scope": "Final archive guard and strict C11 runtime readback only. The old failed qualification remains failed; this does not replace a new complete installed run."}
(out / "READBACK.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
