from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import sys

MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
SOURCE = MAIN / 'target/continuity-managed-maintenance/source-f560d803'
BASE = MAIN / 'target/continuity-android-managed-cohort'
C_BASE = MAIN / 'target/continuity-c-managed-cohort'
C_OUTPUT = SOURCE / 'target/c-managed-qualification/result-01'
OUTPUT = SOURCE / 'target/android-managed-qualification/result-01'
TOOLS_BASE = MAIN / 'target/continuity-jvm-tools'
CHAIN = MAIN / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def obj(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert Path.cwd() == SOURCE
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
    import rust_sdk_profile as sdk
    import continuity_package as package
    from continuity_apple_package import file_hashes
    from continuity_kotlin_consumer import tool_identity
    from continuity_android_jni import qualify_android_jni
    from rust_sdk_msrv import validate_report
    assert sdk.ROOT == package.ROOT == SOURCE
    sdk.validate_no_registry_credentials(os.environ)
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
    assert obj(C_BASE / 'LAUNCH_RESULT.json')['completed']
    assert obj(C_BASE / 'DRIVER_RESULT.json')['completed']
    assert obj(MAIN / 'target/continuity-kotlin-managed-cohort/LAUNCH_RESULT.json')['completed']
    assert obj(MAIN / 'target/continuity-swift-managed-cohort/LAUNCH_RESULT.json')['completed']
    foundation_bytes = (C_OUTPUT / 'CONTINUITY_PACKAGE.json').read_bytes()
    foundation = json.loads(foundation_bytes)
    native_bytes = (C_OUTPUT / 'C_CONSUMER.json').read_bytes()
    native = json.loads(native_bytes)
    assert foundation['completed'] and foundation['partition_completed'] and foundation['sources_unchanged']
    assert foundation['source_commit'] == COMMIT and foundation['rust_report_sha256'] == REPORT_SHA
    assert foundation['c_consumer'] == native and native['completed'] and native['partition_completed']
    assert foundation['build_profiles'] == native['build_profiles'] == ['debug', 'release']
    assert all(native['execution'][p]['witness_openssl']['completed'] for p in ['debug', 'release'])
    before = package.source_inputs()
    assert before == foundation['source_inputs'] and digest(REPORT) == REPORT_SHA
    cohort = validate_report(REPORT.read_bytes(), REPORT_SHA, REPORT_SHA, before['rust_workspace_sha256'])
    archives = {}
    for name, row in cohort['crates'].items():
        path = REPORT.parent / 'crates' / row['file']
        assert not path.is_symlink() and path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
        archives[name] = {'path': str(path), 'sha256': row['sha256'], 'bytes': row['bytes']}
    compiler = package.compiler_identity(CHAIN)
    assert compiler == foundation['tool_binaries']
    readiness = obj(TOOLS_BASE / 'PREPARATION.json')
    assert readiness['completed'] and not readiness['execution_started']
    assert digest(TOOLS_BASE / 'TOOLS.json') == readiness['tools_manifest_sha256']
    java_home = Path(readiness['java_home'])
    tools = {'java': tool_identity(java_home)}
    assert tools['java'] == obj(TOOLS_BASE / 'TOOLS.json')['java']
    outside = Path(obj(C_OUTPUT / 'location.json')['path'])
    assert outside.resolve(strict=True) == outside and not outside.is_relative_to(SOURCE)
    c_source_before = file_hashes(outside / 'c-consumer')
    binaries = {}
    for profile, row in native['execution'].items():
        for name, binary in row['binaries'].items():
            path = Path(binary['path'])
            assert path.is_relative_to(outside) and digest(path) == binary['sha256']
            binaries[profile + '/' + name] = binary
    helper = MAIN / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    OUTPUT.mkdir(parents=True, mode=0o700, exist_ok=False)
    (OUTPUT / 'base-CONTINUITY_PACKAGE.json').write_bytes(foundation_bytes)
    (OUTPUT / 'base-C_CONSUMER.json').write_bytes(native_bytes)
    native_build_receipts = {}
    for profile in ('debug', 'release'):
        for target in ('enrollment', 'enrollment-witness', 'retirement'):
            for suffix in ('json', 'stdout', 'stderr'):
                name = f'c-{target}-build-{profile}.{suffix}'
                sdk.copy(C_OUTPUT / name, OUTPUT / name)
                native_build_receipts[name] = digest(OUTPUT / name)
    environment = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    environment.update(CARGO_HOME=str(outside / 'cargo-home'), CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never',
        CARGO_HTTP_MULTIPLEXING='false', CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(outside / 'build'),
        RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
        RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
        PATH=str(CHAIN / 'bin') + os.pathsep + environment.get('PATH', os.defpath))
    state = {'schema_version': 1, 'kind': 'qperiapt.continuity_android_host_jni_extension',
        'completed': False, 'release_claim_eligible': False, 'publication_performed': False,
        'started_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': COMMIT,
        'source_inputs': before, 'sdk_producer_commit': cohort['base_commit'], 'sdk_report_sha256': REPORT_SHA,
        'foundation_report_sha256': hashlib.sha256(foundation_bytes).hexdigest(),
        'foundation_c_report_sha256': hashlib.sha256(native_bytes).hexdigest(),
        'scope': 'Both existing Android adapter host JNI profiles over identical previously completed Rust/C foundation. Packaged Java classes, actual JNI bridge and installed C engine on macOS arm64; physical ART/AAR, emulator, hosted CI and final release qualification remain separate.',
        'foundation_native_scope': 'Actual completed Rust/C Debug+Release outputs reused without altering either foundation receipt.',
        'compiler': compiler, 'tools': tools, 'sdk_archives': archives,
        'outside': str(outside), 'c_source_before': c_source_before, 'native_binaries': binaries,
        'native_build_receipts': native_build_receipts,
        'driver_sha256': digest(Path(__file__)), 'stream_helper_sha256': digest(helper)}
    write(BASE / 'INPUTS.json', state)
    try:
        state['android_jni'] = qualify_android_jni(outside, OUTPUT, native, environment, java_home)
        consumer = state['android_jni']
        assert consumer['completed'] and consumer['partition_completed']
        assert consumer['build_profiles'] == ['debug', 'release'] and set(consumer['profiles']) == {'debug', 'release'}
        assert package.source_inputs() == before and sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
        assert package.compiler_identity(CHAIN) == compiler
        assert {'java': tool_identity(java_home)} == tools
        assert file_hashes(outside / 'c-consumer') == c_source_before
        assert (C_OUTPUT / 'CONTINUITY_PACKAGE.json').read_bytes() == foundation_bytes
        assert (C_OUTPUT / 'C_CONSUMER.json').read_bytes() == native_bytes
        for name, expected in native_build_receipts.items():
            assert digest(C_OUTPUT / name) == digest(OUTPUT / name) == expected
        for row in binaries.values():
            assert digest(Path(row['path'])) == row['sha256']
        for row in archives.values():
            assert digest(Path(row['path'])) == row['sha256']
        state.update(completed=True, source_inputs_unchanged=True, native_foundation_unchanged=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'DRIVER_RESULT.json', state)
        print(json.dumps({'completed': state['completed'], 'output': str(OUTPUT),
                          'error_type': state.get('error_type'), 'error': state.get('error')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
