"""Seal a failed parent-budget run without manufacturing a terminal qualifier."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-android-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = SOURCE / 'target/android-managed-qualification/result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-android-parent-timeout'
sha = lambda body: hashlib.sha256(body).hexdigest()
obj = lambda path: json.loads(path.read_bytes())
launch = obj(BASE / 'LAUNCH_RESULT.json')
assert launch['completed'] is False and launch['kind'] == 'timeout' and launch['timeout_seconds'] == 18000
assert not (BASE / 'DRIVER_RESULT.json').exists() and not (OUTPUT / 'ANDROID_JNI_CONSUMER.json').exists()
cleanup = obj(BASE / 'ORPHAN_CLEANUP_RESULT.json')
assert len(cleanup['before']) == 1 and cleanup['after'] == [] and cleanup['signals'] == ['SIGTERM']
inputs = obj(BASE / 'INPUTS.json')
assert inputs['source_commit'] == 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
workflow = (ROOT / '.github/workflows/ci.yml').read_text()
section = workflow.split('\n  continuity-installed-swift:\n', 1)[1]
section = re.split(r'\n  [A-Za-z0-9_-]+:\n', section, maxsplit=1)[0]
patterns = re.findall(r'^\s+target/continuity-installed-swift/(.+)$', section, re.M)
selected = set()
for pattern in patterns:
    if pattern.endswith('/**'):
        for directory in OUTPUT.glob(pattern[:-3]):
            assert directory.is_dir() and not directory.is_symlink()
            selected.update(path for path in directory.rglob('*') if path.is_file())
    else: selected.update(path for path in OUTPUT.glob(pattern) if path.is_file())
actual = {path for path in OUTPUT.rglob('*') if path.is_file()}
assert selected == actual and not any(path.is_symlink() for path in OUTPUT.rglob('*'))
manifests = []
for path in sorted(OUTPUT.rglob('PUBLIC_FILES.json')):
    record = obj(path); assert record['completed'] is True
    for name, digest in record['files'].items():
        relative = Path(name); assert not relative.is_absolute() and '..' not in relative.parts
        assert sha((path.parent / relative).read_bytes()) == digest
    assert {p.relative_to(path.parent).as_posix() for p in path.parent.rglob('*') if p.is_file()} == set(record['files']) | {'PUBLIC_FILES.json'}
    manifests.append({'path': path.relative_to(OUTPUT).as_posix(), 'files': len(record['files']), 'sha256': sha(path.read_bytes())})
completed, nonterminal = [], []
for path in sorted(OUTPUT.glob('*.json')):
    row = obj(path)
    if isinstance(row, dict) and isinstance(row.get('argv'), list):
        if 'returncode' in row:
            assert row['returncode'] == 0
            completed.append({'path': path.name, 'returncode': row['returncode'],
                              'reused_foundation_receipt': path.name in inputs['native_build_receipts']})
        else: nonterminal.append(path.name)
assert len(completed) == 111 and sum(row['reused_foundation_receipt'] for row in completed) == 6
assert nonterminal == ['android-jni-release-joint-cycle.json']
stdout = (BASE / 'driver.stdout').read_text().splitlines()
assert sum(line.startswith('START ') for line in stdout) == 106 and sum(line.startswith('END ') for line in stdout) == 105
assert stdout[-1].startswith('START android-jni-release-joint-cycle ')
files = {'output/' + path.relative_to(OUTPUT).as_posix(): path for path in selected}
for path in sorted(BASE.iterdir()):
    if path.is_file(): files['driver/' + path.name] = path
files['driver/run.py'] = SOURCE / 'target/android-managed-qualification/run.py'
files['driver/streamed_command.py'] = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
files['source/qualified-bounded_process.py'] = SOURCE / 'artifact/bounded_process.py'
files['source/current-bounded_process.py'] = ROOT / 'artifact/bounded_process.py'
assert files['source/qualified-bounded_process.py'].read_bytes() == files['source/current-bounded_process.py'].read_bytes()
files['source/qualified-ci.yml'] = SOURCE / '.github/workflows/ci.yml'
files['source/current-ci.yml'] = ROOT / '.github/workflows/ci.yml'
for path in sorted((ROOT / 'target/continuity-nested-boundary-diagnostic').iterdir()):
    if path.is_file(): files['minimal-reproduction/' + path.name] = path
reproduction = obj(ROOT / 'target/continuity-nested-boundary-diagnostic/RESULT.json')
assert reproduction['reproduced_orphan'] and not reproduction['cleanup_remaining']
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed': False,
           'release_claim_eligible': False, 'source_commit': inputs['source_commit'],
           'parent_timeout': launch, 'top_level_terminal_commands': len(completed),
           'reused_foundation_commands': 6, 'fresh_completed_commands': 105,
           'nonterminal_command_receipts': nonterminal, 'completed_commands': completed,
           'public_manifests': manifests, 'public_output_files': len(selected),
           'orphan_cleanup': cleanup, 'minimal_reproduction': reproduction,
           'missing_terminal_evidence': ['DRIVER_RESULT.json', 'ANDROID_JNI_CONSUMER.json'],
           'private_fixture_state_retained_locally_not_archived': True,
           'scope': 'Original macOS arm64 host JNI run; no ART/emulator/device qualification. Whole run failed the fixed aggregate budget. Successful command receipts do not complete the interrupted Release cycle or qualify the aggregate.'}
DEST.mkdir()
with (DEST / 'READBACK.json').open('x') as out: json.dump(summary, out, indent=2); out.write('\n')
files['READBACK.json'] = DEST / 'READBACK.json'
def archive_for(name):
    if name.startswith('output/'):
        tokens = set(re.split(r'[-/._]+', name.lower()))
        for profile in ('debug', 'release'):
            if profile in tokens: return profile.upper() + '.zip'
    return 'CAPTURE.zip'
groups = {}
for name, path in sorted(files.items()): groups.setdefault(archive_for(name), {})[name] = path
index, archives = {}, {}
for archive_name, entries in sorted(groups.items()):
    target = DEST / archive_name
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
        for name, path in entries.items():
            assert path.is_file() and not path.is_symlink()
            body = path.read_bytes(); assert len(body) <= 16 * 1024**2
            entry = zipfile.ZipInfo(name, (2000, 1, 1, 0, 0, 0)); entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED; packed.writestr(entry, body)
            index[name] = {'archive': archive_name, 'bytes': len(body), 'sha256': sha(body)}
    with zipfile.ZipFile(target) as packed:
        assert packed.testzip() is None and set(packed.namelist()) == set(entries)
        for name, path in entries.items(): assert sha(packed.read(name)) == sha(path.read_bytes()) == index[name]['sha256']
    assert target.stat().st_size < 100 * 1024**2
    archives[archive_name] = {'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()), 'members': len(entries)}
    print(json.dumps({'archive': archive_name, **archives[archive_name]}), flush=True)
for name, data in [('FILES.json', index), ('ARCHIVES.json', archives)]:
    with (DEST / name).open('x') as out: json.dump(data, out, indent=2, sort_keys=True); out.write('\n')
