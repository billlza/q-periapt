"""Read back an already terminal Android host JNI extension; never launch it."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import subprocess
import zipfile

import continuity_package as package
from continuity_kotlin_consumer import tool_identity
import continuity_android_jni as android
import continuity_android_account as account
import continuity_android_local_credential as local_credential
from continuity_apple_package import file_hashes
import rust_sdk_profile as sdk
from c_package_manifest import RUST_WORKSPACE_INPUTS

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-android-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = SOURCE / 'target/android-managed-qualification/result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-continuity-android-maintenance'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def obj(path):
    return json.loads(read(path))


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


launch = obj(BASE / 'LAUNCH_RESULT.json')
driver = obj(BASE / 'DRIVER_RESULT.json')
consumer = obj(OUTPUT / 'ANDROID_JNI_CONSUMER.json')
assert launch['completed'] and launch['returncode'] == 0 and driver['completed']
assert launch['timeout_seconds'] == 18000 and launch['component_timeout_seconds'] == 900
assert launch['component_stream_limit_bytes'] == 16 * 1024**2
assert driver['source_inputs_unchanged'] and driver['native_foundation_unchanged']
assert driver['source_commit'] == COMMIT and driver['sdk_report_sha256'] == REPORT_SHA
assert digest(REPORT) == REPORT_SHA
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
assert consumer == driver['android_jni'] and consumer['completed'] and consumer['partition_completed']
assert consumer['build_profiles'] == ['debug', 'release'] and set(consumer['profiles']) == {'debug', 'release'}
for suffix in ['stdout', 'stderr']:
    assert digest(BASE / ('driver.' + suffix)) == launch[suffix + '_sha256']
assert digest(BASE / 'launch.py') == launch['launch_driver_sha256']
assert digest(SOURCE / 'target/android-managed-qualification/run.py') == driver['driver_sha256']
helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
assert digest(helper) == driver['stream_helper_sha256']
gate = obj(BASE / 'START_GATE.json')
for name, expected in gate['prerequisite_terminal_receipts'].items():
    assert digest(ROOT / name) == expected and obj(ROOT / name)['completed']
for name, expected in gate['driver_hashes'].items():
    assert digest(ROOT / name) == expected
before = driver['source_inputs']
current = package.source_inputs()
windows_delta_path = ROOT / 'target/continuity-windows-test-imports/SOURCE_DELTA.json'
windows_delta = obj(windows_delta_path)
assert before['rust_workspace_sha256'] == windows_delta['qualified_workspace_sha256']
assert current['rust_workspace_sha256'] == windows_delta['fixed_workspace_sha256']
workspace_changes = subprocess.check_output(['git', 'diff', '--name-only', COMMIT, '--', *RUST_WORKSPACE_INPUTS], cwd=ROOT, text=True).splitlines()
assert workspace_changes == windows_delta['changed_workspace_files'] == [
    'crates/q-periapt-host-store/src/filesystem/directory_publication/windows_tests.rs']
assert digest(SOURCE / workspace_changes[0]) == windows_delta['old_test_sha256']
assert digest(ROOT / workspace_changes[0]) == windows_delta['new_test_sha256']
assert '#[cfg(all(test, windows))]\nmod windows_tests;' in read(SOURCE / 'crates/q-periapt-host-store/src/filesystem/directory_publication.rs').decode()
differences = {name: {'qualified': before['files'][name], 'current': current['files'][name]}
               for name in sorted(current['files'].keys() & before['files'].keys())
               if current['files'][name] != before['files'][name]}
added = {name: current['files'][name] for name in sorted(current['files'].keys() - before['files'].keys())}
assert set(differences) == {
    '.github/workflows/ci.yml', 'artifact/continuity_apple_package.py', 'artifact/continuity_apple_consumer.py',
    'bindings/swift/ContinuityPackageConsumer/ApplePackageREADME.md',
    'research/continuity-identity-candidate/src/durable/messages/tests.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'}
assert set(added) == {
    'research/continuity-identity-candidate/src/durable/messages/tests/classical_alias.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure/aggregate_copy.rs'}
assert not before['files'].keys() - current['files'].keys()
assert all(digest(SOURCE / name) == expected for name, expected in before['files'].items())
assert sdk.rust_workspace_source_digest(SOURCE) == before['rust_workspace_sha256']
assert file_hashes(Path(driver['outside']) / 'c-consumer') == driver['c_source_before']
assert package.compiler_identity(ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1') == driver['compiler']
for row in driver['tools'].values():
    assert tool_identity(Path(row['root'])) == row
assert consumer['tools'] == driver['tools']['java']
assert digest(Path(consumer['compiler']['path'])) == consumer['compiler']['sha256']
platform = Path(read(OUTPUT / 'android-jni-sdk-path.stdout').decode().strip())
assert digest(platform / 'SDKSettings.json') == consumer['compiler']['sdk_settings_sha256']
assert digest(OUTPUT / 'continuity-android-classes.jar') == consumer['jar_sha256']
assert {name: sha(data) for name, data in android.source_files().items()} == consumer['source_hashes']
for row in driver['native_binaries'].values():
    assert digest(Path(row['path'])) == row['sha256']
for row in driver['sdk_archives'].values():
    assert digest(Path(row['path'])) == row['sha256']
for name, expected in driver['native_build_receipts'].items():
    assert digest(OUTPUT / name) == digest(SOURCE / 'target/c-managed-qualification/result-01' / name) == expected
assert len(driver['native_build_receipts']) == 18
for filename, key in [('CONTINUITY_PACKAGE.json', 'foundation_report_sha256'), ('C_CONSUMER.json', 'foundation_c_report_sha256')]:
    assert digest(OUTPUT / ('base-' + filename)) == driver[key]
    assert digest(SOURCE / 'target/c-managed-qualification/result-01' / filename) == driver[key]

native = obj(OUTPUT / 'base-C_CONSUMER.json')
profile_readback = {}
extra_binaries = {}
for profile, row in consumer['profiles'].items():
    bridge_receipt = obj(OUTPUT / f'android-jni-{profile}-bridge.json')
    argv = bridge_receipt['argv']
    assert bridge_receipt['returncode'] == 0 and argv[-2] == '-o'
    bridge = Path(argv[-1])
    installed = bridge.parent
    assert installed.is_relative_to(Path(driver['outside'])) and installed.name == profile
    assert digest(bridge) == row['bridge_sha256']
    assert row['native_sha256'] == native['execution'][profile]['binaries']['C_library']['sha256']
    assert digest(installed / 'libq_periapt_continuity_c_consumer.dylib') == row['native_sha256']
    assert digest(installed / 'qpc-c-client') == row['receiver_sha256']
    assert digest(installed / 'qpc-configuration-client') == row['policy_target_client_sha256']
    test_receipt = obj(OUTPUT / f'android-jni-{profile}-test-catalog.json')
    assert test_receipt['returncode'] == 0
    assert digest(Path(test_receipt['argv'][0])) == row['test_sha256']
    assert read(OUTPUT / f'android-jni-{profile}-boundary.stdout') == b'configuration:bridge:passed\n'
    assert read(OUTPUT / f'android-jni-{profile}-boundary.stderr') == b'' and row['boundary_checks'] is True
    lifecycle = local_credential.verify_execution(read(OUTPUT / f'android-jni-{profile}-execution.stdout'), installed / 'cases')
    aggregate = account.verify_execution(read(OUTPUT / f'android-jni-{profile}-account.stdout'), installed / 'account-cases')
    assert lifecycle == row['outcomes'] and aggregate == row['account_outcomes']
    for trust in ['fixed', 'recoverable']:
        for name in local_credential.PUBLIC:
            assert read(installed / 'cases' / trust / name) == read(OUTPUT / f'android-jni-{profile}-{trust}-{name}.public')
        for name in account.PUBLIC:
            assert read(installed / 'account-cases' / trust / name) == read(OUTPUT / f'android-jni-{profile}-account-{trust}-{name}.public')
    extra_binaries[f'binaries/{profile}/libqperiapt_continuity_jni.dylib'] = read(bridge)
    profile_readback[profile] = {'lifecycle': lifecycle, 'account': aggregate,
        'bridge_sha256': row['bridge_sha256'], 'native_sha256': row['native_sha256'],
        'receiver_sha256': row['receiver_sha256'], 'test_sha256': row['test_sha256'],
        'scope': 'Existing lifecycle/account validators reread original public outcomes and their exported copies; all other scenario receipts are retained with the terminal qualifier result.'}

workflow = read(ROOT / '.github/workflows/ci.yml')
section = workflow.decode().split('\n  continuity-installed-swift:\n', 1)[1]
section = re.split(r'\n  [A-Za-z0-9_-]+:\n', section, maxsplit=1)[0]
patterns = re.findall(r'^\s+target/continuity-installed-swift/(.+)$', section, re.M)
assert 'continuity-android-classes.jar' in patterns and 'android-jni-*.public' in patterns
selected = set()
for pattern in patterns:
    if pattern.endswith('/**'):
        for directory in OUTPUT.glob(pattern[:-3]):
            assert directory.is_dir() and not directory.is_symlink()
            selected.update(p for p in directory.rglob('*') if p.is_file())
    else:
        selected.update(p for p in OUTPUT.glob(pattern) if p.is_file())
actual = {p for p in OUTPUT.rglob('*') if p.is_file()}
assert selected == actual, {'unselected': sorted(str(p.relative_to(OUTPUT)) for p in actual - selected)}
assert not any(p.is_symlink() for p in OUTPUT.rglob('*'))
public_manifests = []
for path in sorted(OUTPUT.rglob('PUBLIC_FILES.json')):
    row = obj(path)
    assert row['completed'] and isinstance(row['files'], dict)
    for name, expected in row['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert digest(path.parent / relative) == expected
    leaves = {p.relative_to(path.parent).as_posix() for p in path.parent.rglob('*') if p.is_file()}
    assert leaves == set(row['files']) | {'PUBLIC_FILES.json'}
    public_manifests.append({'path': path.relative_to(OUTPUT).as_posix(), 'files': len(row['files']), 'sha256': digest(path)})
commands = []
for path in sorted(OUTPUT.glob('*.json')):
    row = obj(path)
    if isinstance(row, dict) and isinstance(row.get('argv'), list) and 'returncode' in row:
        commands.append({'receipt': path.name, 'returncode': row['returncode'],
                         'reused_native_build_receipt': path.name in driver['native_build_receipts']})
copied = [row for row in commands if row['reused_native_build_receipt']]
assert len(copied) == 6
assert all(row['returncode'] == 0 for row in commands), 'Unexpected nonzero top-level receipt requires explicit classification.'
print(json.dumps({'phase': 'validated', 'output_files': len(selected), 'commands': len(commands),
                  'copied_commands': len(copied), 'public_manifests': len(public_manifests)}), flush=True)
files = {'output/' + p.relative_to(OUTPUT).as_posix(): read(p) for p in sorted(selected)}
files.update(extra_binaries)
for name in ['PREPARATION.json', 'START_GATE.json', 'INPUTS.json', 'LAUNCH.json', 'LAUNCH_RESULT.json',
             'DRIVER_RESULT.json', 'launch.py', 'driver.stdout', 'driver.stderr', 'launcher.stdout',
             'launcher.stderr', 'seal_complete.py']:
    files['driver/' + name] = read(BASE / name)
files['driver/run.py'] = read(SOURCE / 'target/android-managed-qualification/run.py')
files['driver/streamed_command.py'] = read(helper)
files['source/WINDOWS_TEST_DELTA.json'] = read(windows_delta_path)
files['source/qualified/windows_tests.rs'] = read(SOURCE / workspace_changes[0])
files['source/current/windows_tests.rs'] = read(ROOT / workspace_changes[0])
for name in ['PREPARATION.json', 'TOOLS.json']:
    files['tools/' + name] = read(ROOT / 'target/continuity-jvm-tools' / name)
for path in sorted((SOURCE / 'artifact').glob('continuity_android_*.py')):
    files['source/qualified/artifact/' + path.name] = read(path)
files['source/qualified/.github/workflows/ci.yml'] = read(SOURCE / '.github/workflows/ci.yml')
files['source/current-ci.yml'] = workflow
files['producer/RUST_SDK_PACKAGE.json'] = read(REPORT)
current_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
readback = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed': True,
    'source_commit': COMMIT, 'current_main_commit': current_commit, 'sdk_producer_commit': driver['sdk_producer_commit'],
    'sdk_report_sha256': REPORT_SHA, 'scope': driver['scope'],
    'native_foundation_reused': True, 'native_foundation_unchanged': True,
    'all_selected_inputs_identical_to_current_main': False,
    'selected_input_changes': differences, 'selected_input_additions': added,
    'workspace_source_delta': windows_delta,
    'compatibility_scope': 'Native production, C/Android runtime and Android qualifier inputs unchanged. Current workspace digest differs because of the exact Windows-test-only repair; its next SDK producer must be rebuilt. Other differences are CI export/artifact ordering, Apple support and candidate test-only sources. This remains the ff072bd6 cohort, not qualification of the fixed full source.',
    'profile_readback': profile_readback, 'public_manifests': public_manifests,
    'top_level_command_receipts': commands, 'new_top_level_commands': len(commands) - len(copied),
    'reused_native_build_commands': len(copied), 'observed_returncodes': dict(Counter(str(row['returncode']) for row in commands)),
    'returncode_scope': 'Nested fault/refusal child exits retain their actual semantics under unchanged scenario validators.',
    'output_files': len(selected), 'output_bytes': sum(p.stat().st_size for p in selected),
    'upload_patterns': patterns, 'current_workflow_sha256': sha(workflow),
    'gate_elapsed_seconds': launch['elapsed_seconds'], 'timeout_seconds': launch['timeout_seconds'],
    'component_timeout_seconds': 900, 'release_claim_eligible': False, 'publication_performed': False,
    'not_claimed': ['Hosted CI completion', 'Android ART/AAR, emulator or physical device qualification',
                    'GNU/Linux runtime', 'Physical power loss', 'Current candidate complete native suite',
                    'Formal Continuity product ABI admission', 'External review', 'Formal release']}
files['READBACK.json'] = encode(readback)


def archive_for(name):
    if name.startswith(('output/', 'binaries/')):
        tokens = set(re.split(r'[-/._]+', name.lower()))
        profile = next((p for p in ['debug', 'release'] if p in tokens), None)
        if profile:
            return profile.upper() + '.zip'
    return 'CAPTURE.zip'


manifest = {name: {'archive': archive_for(name), 'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
groups = {}
for name, body in files.items():
    groups.setdefault(archive_for(name), {})[name] = body
assert {'DEBUG.zip', 'RELEASE.zip', 'CAPTURE.zip'} == groups.keys()
payloads = {}
for archive_name, entries in sorted(groups.items()):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    data = buffer.getvalue()
    assert len(data) < 100 * 1024**2, f'Split {archive_name}; repository blob bound unchanged.'
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert len(archive.infolist()) == len(set(archive.namelist())) == len(entries)
        assert set(archive.namelist()) == set(entries)
        assert all(archive.read(name) == body for name, body in entries.items())
    payloads[archive_name] = data
    print(json.dumps({'archive': archive_name, 'bytes': len(data), 'members': len(entries), 'readback': True}), flush=True)
DEST.mkdir(parents=True, exist_ok=False)
for name, body in {**payloads, 'FILES.json': files['FILES.json'], 'READBACK.json': files['READBACK.json']}.items():
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {name: {'bytes': len(data), 'members': len(groups[name]), 'sha256': sha(data)} for name, data in sorted(payloads.items())}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary), flush=True)
