from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import subprocess
import time
from bounded_process import capture_output, BoundedProcessError

base = Path(__file__).resolve().parent
record = {'started_utc': datetime.now(timezone.utc).isoformat(), 'qualification_passed': False,
          'source_sha256': hashlib.sha256(Path('artifact/bounded_process.py').read_bytes()).hexdigest()}
leaf = None
try:
    try:
        capture_output(['/bin/sh', 'artifact/python-run.sh', str(base / 'inner.py')],
                       timeout_seconds=2, maximum_stdout_bytes=4096, maximum_stderr_bytes=4096)
    except BoundedProcessError as error:
        record['outer_error'] = {'kind': error.kind, 'message': str(error), 'cleanup_ambiguous': error.cleanup_ambiguous}
    else:
        raise AssertionError('outer deadline did not fail')
    leaf = json.loads((base / 'leaf.json').read_bytes())
    record['leaf'] = leaf
    assert leaf['pgid'] != os.getpgrp()
    observed = subprocess.run(['ps', '-p', str(leaf['pid']), '-o', 'pid=,ppid=,pgid=,state=,command='],
                              check=True, text=True, capture_output=True).stdout
    assert str(base / 'leaf.py') in observed and os.getpgid(leaf['pid']) == leaf['pgid']
    record.update(leaf=leaf, live_orphan_snapshot=observed, reproduced_orphan=True)
finally:
    if leaf is None and (base / 'leaf.json').exists():
        leaf = json.loads((base / 'leaf.json').read_bytes())
    if leaf is not None:
        os.killpg(leaf['pgid'], signal.SIGTERM)
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            observed = subprocess.run(['ps', '-p', str(leaf['pid']), '-o', 'pid=,pgid=,state='],
                                      text=True, capture_output=True)
            if not observed.stdout.strip(): break
            time.sleep(0.05)
        record['cleanup_remaining'] = observed.stdout.strip()
        assert not record['cleanup_remaining']
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    with (base / 'RESULT.json').open('x') as out: json.dump(record, out, indent=2); out.write('\n')
    print(json.dumps(record), flush=True)
