from pathlib import Path
import json
import os
import sys
import time

Path(sys.argv[1]).write_text(json.dumps({'pid': os.getpid(), 'pgid': os.getpgrp(), 'parent': os.getppid()}))
time.sleep(20)
