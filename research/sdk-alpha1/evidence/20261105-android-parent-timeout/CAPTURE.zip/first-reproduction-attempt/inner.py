from pathlib import Path
import sys
from bounded_process import capture_output

root = Path(__file__).resolve().parent
capture_output(['/bin/sh', 'artifact/python-run.sh', str(root / 'leaf.py'), str(root / 'leaf.json')],
               timeout_seconds=30, maximum_stdout_bytes=1024, maximum_stderr_bytes=1024)
