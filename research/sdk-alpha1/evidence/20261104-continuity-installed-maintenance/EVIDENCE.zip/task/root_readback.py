from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

import continuity_package as package
import continuity_enrollment as enrollment
import continuity_roster_renewal as roster
import continuity_device_replacement as replacement
import continuity_device_retirement as retirement
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-installed-managed-cohort'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output = BASE / 'ROOT_READBACK.json'
    assert not output.exists()
    result = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'scope': 'Independent reread of completed installed Rust evidence and archive-derived counterpart build; no new execution, foreign platform or complete wheel claim.',
              'driver_sha256': digest(Path(__file__)), 'python': sys.executable,
              'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
              'no_bytecode': sys.dont_write_bytecode}
    try:
        installed = BASE / 'rust-01'
        report = json.loads((installed / 'CONTINUITY_PACKAGE.json').read_bytes())
        assert report['completed'] and report['sources_unchanged']
        assert report['source_commit'] == '4effa8b2b25e7403ab912b65894a7d1e73695542'
        assert report['build_profiles'] == ['debug', 'release']
        assert report['publication_performed'] is False and report['release_claim_eligible'] is False
        package.verify_candidate_archive(installed, report['archive'])
        candidate = package.validate_candidate((installed / report['archive']['file']).read_bytes(), set(report['archive']['files']))
        original = Path(json.loads((installed / 'location.json').read_bytes())['path'])
        assert not original.is_relative_to(ROOT)
        package.verify_candidate_files(original / 'consumer/packages' / f'{package.NAME}-{package.VERSION}', candidate)
        profiles = {}
        for profile in report['build_profiles']:
            runtime = original / (profile + '-runtime')
            actual = package.verify_execution((installed / ('consumer-' + profile + '.stdout')).read_bytes(),
                runtime, runtime.with_name(runtime.name + '-session-reopen'),
                runtime.with_name(runtime.name + '-roster-renewal') / 'public',
                runtime.with_name(runtime.name + '-device-replacement') / 'public',
                runtime.with_name(runtime.name + '-device-retirement') / 'public')
            expected = {k: v for k, v in report['execution'][profile].items() if k != 'binary'}
            assert actual == expected, profile
            for component, verifier, suffix in [
                    ('enrollment', enrollment.verify, 'enrollment'),
                    ('roster_renewal', roster.verify, 'roster-renewal'),
                    ('device_replacement', replacement.verify, 'device-replacement'),
                    ('device_retirement', retirement.verify, 'device-retirement')]:
                assert verifier(installed / (profile + '-' + suffix + '-public')) == actual[component]
            reopen = actual['session_reopen']
            assert enrollment.verify_reopen(installed / (profile + '-enrollment-reopen-public'),
                reopen['test_protocol_time'], reopen['session'], public_only=True) == reopen['enrollment']
            profiles[profile] = {'original_runtime_readback': True, 'exported_public_readback': True,
                                 'test_stdout_sha256': digest(installed / ('consumer-' + profile + '.stdout')),
                                 'tests': 3}
        counterpart_dir = BASE / 'counterpart-01'
        counterpart = json.loads((counterpart_dir / 'INSTALLED_COUNTERPART.json').read_bytes())
        assert counterpart['completed'] and counterpart['sources_unchanged']
        assert counterpart['runtime_qualified'] is False
        assert counterpart['source_commit'] == report['source_commit']
        assert counterpart['sdk_report_sha256'] == report['rust_report_sha256']
        assert counterpart['candidate_archive']['sha256'] == report['archive']['sha256']
        package.verify_candidate_archive(counterpart_dir, counterpart['candidate_archive'])
        assert digest(counterpart_dir / 'counterpart') == counterpart['native_sha256']
        assert digest(counterpart_dir / 'importer') == counterpart['importer_sha256']
        counterpart_root = Path(json.loads((counterpart_dir / 'LOCATION.json').read_bytes())['path'])
        assert not counterpart_root.is_relative_to(ROOT)
        package.verify_candidate_files(counterpart_root / 'counterpart/packages' / f'{package.NAME}-{package.VERSION}', candidate)
        inputs = json.loads((BASE / 'INPUTS.json').read_bytes())
        sdk_report_path = Path(inputs['report'])
        assert digest(sdk_report_path) == inputs['report_sha256'] == report['rust_report_sha256']
        sdk_report = json.loads(sdk_report_path.read_bytes())
        assert len(inputs['archives']) == 12
        for record in inputs['archives'].values():
            archive = Path(record['path'])
            assert digest(archive) == record['sha256'] and archive.stat().st_size == record['bytes']
        sdk.verify_consumed_sources(original / 'consumer', sdk_report_path.parent, sdk_report['crates'])
        import continuity_independent_package as independent
        sdk.verify_consumed_sources(counterpart_root / 'counterpart', sdk_report_path.parent,
                                    sdk_report['crates'], names=independent.PRODUCTS)
        source_counts = {}
        for label, record in [('rust', report), ('counterpart', counterpart)]:
            files = record['source_inputs']['files']
            mismatches = [name for name, expected in files.items() if digest(ROOT / name) != expected]
            assert not mismatches, mismatches
            source_counts[label] = len(files)
        result.update(completed=True, source_commit=report['source_commit'], profiles=profiles,
                      candidate_archive_sha256=report['archive']['sha256'],
                      native_sha256=counterpart['native_sha256'], importer_sha256=counterpart['importer_sha256'],
                      sdk_report_sha256=report['rust_report_sha256'], source_file_counts=source_counts,
                      all_sdk_archive_count=12, installed_product_crate_count=9)
    except BaseException as error:
        result.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with output.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
