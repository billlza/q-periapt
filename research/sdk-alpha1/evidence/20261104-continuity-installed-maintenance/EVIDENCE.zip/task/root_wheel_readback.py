from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

import continuity_independent_python_run as gate
from continuity_independent_python import inspect_wheel, verify_installation, verify_roster_capacity
from continuity_independent_composition import verify_composition, verify_capacity

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-installed-managed-cohort'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    destination = BASE / 'ROOT_WHEEL_READBACK.json'
    assert not destination.exists()
    result = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'driver_sha256': digest(Path(__file__)), 'isolated': sys.flags.isolated,
              'no_site': sys.flags.no_site, 'no_bytecode': sys.dont_write_bytecode,
              'scope': 'Readback of original complete installed-wheel execution, its 25 command streams and identities; no test rerun or new CLI producer execution.'}
    try:
        driver = read(BASE / 'WHEEL-DRIVER.json')
        assert driver['completed'] and driver['sources_unchanged'] and driver['provider_files_unchanged']
        assert driver['command_count'] == 25 and driver['module_count'] == 105
        original = Path(driver['output_original'])
        report = read(original / 'PYTHON_INSTALLATION.json')
        counterpart = read(BASE / 'counterpart-01/INSTALLED_COUNTERPART.json')
        assert report['completed'] and report['sources_unchanged'] and not report['release_claim_eligible']
        assert report['source_commit'] == driver['source_commit'] == counterpart['source_commit'] == '4effa8b2b25e7403ab912b65894a7d1e73695542'
        assert report['native_sha256'] == driver['native_sha256'] == counterpart['native_sha256'] == digest(BASE / 'counterpart-01/counterpart')
        assert len(report['source_inputs']) == 240
        assert all(digest(ROOT / name) == expected for name, expected in report['source_inputs'].items())
        outside = Path(read(original / 'LOCATION.json')['path'])
        assert not outside.is_relative_to(ROOT)
        application = outside / 'research/continuity-openssl-peer'
        modules = {p.name: p.read_bytes() for p in (gate.SOURCE / gate.PACKAGE).glob('*.py')}
        expected = {name: hashlib.sha256(body).hexdigest() for name, body in modules.items()}
        assert len(expected) == 105 and report['modules'] == expected == read(original / 'EXPECTED_MODULES.json')
        provenance = read(original / 'PROVENANCE.json')
        assert provenance['modules'] == expected
        assert Path(provenance['package_root']) == application / gate.PACKAGE
        assert all(provenance[key] == 1 for key in ['isolated', 'no_site', 'dont_write_bytecode'])
        assert Path(provenance['pycache_prefix']) == outside / 'private-cache'
        assert not any((outside / 'private-cache').iterdir())
        wheel = original / gate.WHEEL
        assert digest(wheel) == report['wheel_sha256'] == driver['wheel_sha256']
        files = inspect_wheel(wheel.read_bytes(), modules,
            {name: (gate.SOURCE / name).read_bytes() for name in ['LICENSE-APACHE', 'LICENSE-MIT']},
            (gate.SOURCE / 'README.md').read_bytes())
        actual = gate.installed_files(application)
        installed_hashes = read(original / 'INSTALLED_FILES.json')
        installed = {name: actual[name] for name in installed_hashes}
        assert {name: hashlib.sha256(body).hexdigest() for name, body in installed.items()} == installed_hashes
        verify_installation(installed, files, wheel_url=wheel.as_uri(), digest=report['wheel_sha256'])
        harness = {p.relative_to(gate.SOURCE).as_posix(): p.read_bytes() for p in gate.runtime_files()
                   if not p.is_relative_to(gate.SOURCE / gate.PACKAGE)}
        assert actual == installed | harness
        for path, maximum in gate.archived_inputs().items():
            name = path.relative_to(ROOT).as_posix()
            assert gate.snapshot(outside / name, maximum=maximum).sha256 == report['source_inputs'][name]
        named = {}
        for path in original.glob('*.json'):
            value = read(path)
            if isinstance(value, dict) and 'argv' in value:
                key = json.dumps(value['argv'])
                assert key not in named
                named[key] = path
        streams = BASE / 'wheel-streams-01'
        receipts = sorted(streams.glob('command-*.json'))
        assert len(receipts) == len(named) == 25
        commands = []
        seen = set()
        previous_end = None
        for number, path in enumerate(receipts, 1):
            assert path.name == f'command-{number:02d}.json'
            row = read(path)
            assert row['process_completed'] and row['returncode'] == 0 and 'error_type' not in row
            assert row['timeout_seconds'] == 900 and row['elapsed_seconds'] < 900
            assert row['maximum_stdout_bytes'] == row['maximum_stderr_bytes'] == 1024**2
            key = json.dumps(row['argv'])
            assert key not in seen
            seen.add(key)
            receipt = named[key]
            recorded = read(receipt)
            assert recorded['exit'] == 0 and recorded['cwd'] == row['cwd'] == str(outside)
            began = datetime.fromisoformat(row['started_utc'])
            ended = datetime.fromisoformat(row['finished_utc'])
            assert ended > began and (previous_end is None or began >= previous_end)
            previous_end = ended
            for suffix in ['stdout', 'stderr']:
                data = path.with_suffix('.' + suffix).read_bytes()
                assert hashlib.sha256(data).hexdigest() == row[suffix + '_sha256']
                assert len(data) <= row['maximum_' + suffix + '_bytes']
                assert data == receipt.with_suffix('.' + suffix).read_bytes()
                if suffix == 'stderr': assert not data
            commands.append({'number': number, 'label': receipt.stem,
                             'elapsed_seconds': row['elapsed_seconds'], 'timeout_seconds': 900})
        verify_roster_capacity(report['common_account']['roster_capacity'])
        verify_composition(report['policy_composition'])
        verify_capacity(report['policy_composition_capacity'])
        assert report['directory_cli']['completed'] and report['directory_cli']['historical_only']
        assert report['directory_cli']['current_authorization_or_consumption'] is False
        provider_input = read(BASE / 'provider-inputs.json')
        provider = Path(provider_input['provider'])
        actual_provider = {str(p.relative_to(provider)): digest(p) for p in provider.rglob('*') if p.is_file()}
        assert actual_provider == provider_input['files']
        result.update(completed=True, source_commit=report['source_commit'], original_report=str(original / 'PYTHON_INSTALLATION.json'),
                      original_report_sha256=digest(original / 'PYTHON_INSTALLATION.json'), source_file_count=240,
                      modules=105, installed_files=len(installed), copied_harness_files=len(harness),
                      outside_installation=str(outside), native_sha256=report['native_sha256'],
                      wheel_sha256=report['wheel_sha256'], provider=report['provider'], provider_files_unchanged=True,
                      commands=commands, complete_commands=25,
                      checked_capacity_profiles=[{'members': r['members'], 'witnessed': r['witnessed'],
                                                  'workers': r['workers'], 'process_kills': r['process_kills']}
                                                 for r in report['policy_composition_capacity']['profiles']],
                      directory_cli_scope=driver['directory_cli_scope'])
    except BaseException as error:
        result.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with destination.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
        print(json.dumps({k: v for k, v in result.items() if k != 'commands'}, indent=2))


if __name__ == '__main__':
    main()
