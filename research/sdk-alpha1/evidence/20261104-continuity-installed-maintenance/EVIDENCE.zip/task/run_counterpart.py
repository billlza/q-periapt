from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import runpy
import shutil
import sys

MAIN = Path('${CHECKOUT}')
BASE = MAIN / 'target/continuity-installed-managed-cohort'
helpers = runpy.run_path(str(BASE / 'run_package.py'), run_name='managed_package_helpers')
SOURCE, CHAIN, REPORT, REPORT_SHA = (helpers[k] for k in ('SOURCE', 'CHAIN', 'REPORT', 'REPORT_SHA'))
assert Path.cwd() == SOURCE
assert sys.version_info[:2] == (3, 14) and os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
assert json.loads((BASE / 'PACKAGE-DRIVER.json').read_text())['completed'] is True
import rust_sdk_profile as sdk
sdk.command = helpers['streamed_command']
import continuity_independent_package as gate
selected = SOURCE / 'target/continuity-installed-managed-cohort/counterpart-01'
args = argparse.Namespace(report=REPORT, report_sha256=REPORT_SHA, toolchain_root=CHAIN,
    cargo_home=REPORT.parent / 'cargo-home', output=selected)
state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'output_original': str(selected), 'gate': 'artifact/continuity_independent_package.py build',
         'sdk_report_sha256': REPORT_SHA, 'driver_sha256': hashlib.sha256((BASE / 'run_counterpart.py').read_bytes()).hexdigest(),
         'helper_sha256': hashlib.sha256((BASE / 'run_package.py').read_bytes()).hexdigest(),
         'runtime_qualified': False}
try:
    result = gate.build(args)
    assert result['completed'] is True
    state.update(completed=True, native_sha256=result['native_sha256'],
                 importer_sha256=result['importer_sha256'], candidate_archive=result['candidate_archive']['sha256'])
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    state['report_unchanged'] = helpers['digest'](REPORT) == REPORT_SHA
    (BASE / 'COUNTERPART-DRIVER.json').write_text(json.dumps(state, indent=2) + '\n')
    if selected.exists(): shutil.copytree(selected, BASE / 'counterpart-01')
    print(json.dumps(state, indent=2), flush=True)
