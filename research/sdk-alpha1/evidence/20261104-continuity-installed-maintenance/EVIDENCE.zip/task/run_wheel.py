from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import shutil
import sys
import time

MAIN = Path('${CHECKOUT}')
BASE = MAIN / 'target/continuity-installed-managed-cohort'
SOURCE = MAIN / 'target/continuity-managed-maintenance/source-f560d803'
assert Path.cwd() == SOURCE
assert sys.version_info[:2] == (3, 14) and os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
assert json.loads((BASE / 'PACKAGE-DRIVER.json').read_text())['completed'] is True
counterpart = json.loads((BASE / 'counterpart-01/INSTALLED_COUNTERPART.json').read_text())
assert counterpart['completed'] is True
assert counterpart['sdk_report_sha256'] == '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'
native = BASE / 'counterpart-01/counterpart'
assert hashlib.sha256(native.read_bytes()).hexdigest() == counterpart['native_sha256']
preflight = json.loads((BASE / 'wheel-preflight.json').read_text())
wheel = Path(preflight['wheel'])
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == preflight['wheel_sha256']
provider = Path(preflight['provider_root'])
public = Path(preflight['directory_cli_public'])
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in public.iterdir()} == preflight['directory_cli_public_hashes']

import continuity_independent_python_run as gate
original_capture = gate.capture_output
streams = BASE / 'wheel-streams-01'
streams.mkdir(mode=0o700)
sequence = 0


def streamed_capture(argv, **kwargs):
    """Add stream retention without changing the existing runner's assertions."""
    global sequence
    sequence += 1
    assert kwargs['timeout_seconds'] == 900
    assert kwargs['maximum_stdout_bytes'] == kwargs['maximum_stderr_bytes'] == 1024**2
    assert kwargs.get('stdout_sink') is None and kwargs.get('stderr_sink') is None
    prefix = streams / f'command-{sequence:02d}'
    receipt = {'argv': list(argv), 'cwd': str(Path.cwd()), 'started_utc': datetime.now(timezone.utc).isoformat(),
               'timeout_seconds': kwargs['timeout_seconds'],
               'maximum_stdout_bytes': kwargs['maximum_stdout_bytes'],
               'maximum_stderr_bytes': kwargs['maximum_stderr_bytes'], 'process_completed': False}
    prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('START', prefix.name, receipt['started_utc'], flush=True)
    started = time.monotonic()
    try:
        with prefix.with_suffix('.stdout').open('xb', buffering=0) as out, prefix.with_suffix('.stderr').open('xb', buffering=0) as err:
            result = original_capture(argv, **dict(kwargs, stdout_sink=out.write, stderr_sink=err.write))
        receipt.update(process_completed=True, returncode=result.returncode)
        return result
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        for attribute in ('kind', 'cleanup_ambiguous', 'signal_number'):
            if hasattr(error, attribute): receipt[attribute] = getattr(error, attribute)
        raise
    finally:
        receipt.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-started)
        for suffix in ('stdout', 'stderr'):
            receipt[suffix + '_sha256'] = hashlib.sha256(prefix.with_suffix('.' + suffix).read_bytes()).hexdigest()
        prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print('END', prefix.name, receipt.get('returncode'), receipt.get('error_type'),
              round(receipt['elapsed_seconds'], 3), flush=True)


gate.capture_output = streamed_capture
selected = SOURCE / 'target/continuity-installed-managed-cohort/wheel-01'
args = argparse.Namespace(wheel=wheel.resolve(strict=True), native=native.resolve(strict=True),
    provider_root=provider, directory_cli_public=public, output=selected)
state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'gate': 'artifact/continuity_independent_python_run.py qualify',
         'output_original': str(selected), 'wheel_sha256': preflight['wheel_sha256'],
         'native_sha256': counterpart['native_sha256'], 'sdk_report_sha256': counterpart['sdk_report_sha256'],
         'source_commit': counterpart['source_commit'],
         'directory_cli_scope': preflight['directory_cli_scope'],
         'driver_sha256': hashlib.sha256((BASE / 'run_wheel.py').read_bytes()).hexdigest()}
provider_before = {str(p.relative_to(provider)): hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted(provider.rglob('*')) if p.is_file()}
(BASE / 'provider-inputs.json').write_text(json.dumps({'provider':str(provider),'files':provider_before}, indent=2) + '\n')
try:
    result = gate.qualify(args)
    assert result['completed'] is True and result['native_sha256'] == counterpart['native_sha256']
    state.update(completed=True, module_count=len(result['modules']), command_count=sequence,
                 sources_unchanged=result['sources_unchanged'])
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error), command_count=sequence)
    raise
finally:
    after = {str(p.relative_to(provider)): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted(provider.rglob('*')) if p.is_file()}
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), provider_files_unchanged=provider_before==after)
    if provider_before != after:
        state.update(completed=False, provider_failure='Provider files changed during qualification')
    (BASE / 'WHEEL-DRIVER.json').write_text(json.dumps(state, indent=2) + '\n')
    if selected.exists(): shutil.copytree(selected, BASE / 'wheel-01')
    print(json.dumps(state, indent=2), flush=True)
    assert provider_before == after, 'Provider files changed during qualification'
