from pathlib import Path
import hashlib
import json

ROOT = Path('${CHECKOUT}')
BASE = ROOT / 'target/continuity-installed-managed-cohort'
inputs = json.loads((BASE / 'INPUTS.json').read_text())
package = json.loads((BASE / 'rust-01/CONTINUITY_PACKAGE.json').read_text())
counterpart = json.loads((BASE / 'counterpart-01/INSTALLED_COUNTERPART.json').read_text())
wheel_driver = json.loads((BASE / 'WHEEL-DRIVER.json').read_text())
WHEEL_ORIGINAL = Path(wheel_driver['output_original'])
wheel = json.loads((WHEEL_ORIGINAL / 'PYTHON_INSTALLATION.json').read_text())
public = json.loads((BASE / 'wheel-preflight.json').read_text())
assert package['completed'] is True and counterpart['completed'] is True
assert wheel['completed'] is True and wheel_driver['completed'] is True
assert package['source_commit'] == counterpart['source_commit'] == wheel['source_commit'] == inputs['source_commit']
assert package['rust_report_sha256'] == counterpart['sdk_report_sha256'] == inputs['report_sha256']
assert counterpart['native_sha256'] == wheel['native_sha256'] == wheel_driver['native_sha256']
assert package['archive']['sha256'] == counterpart['candidate_archive']['sha256']
assert hashlib.sha256(Path(inputs['report']).read_bytes()).hexdigest() == inputs['report_sha256']
for name, row in inputs['archives'].items():
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], name
assert all(report['sources_unchanged'] is True for report in (package, counterpart, wheel))
assert wheel_driver['provider_files_unchanged'] is True

commands = []
for phase in ('rust-01', 'counterpart-01'):
    for path in sorted((BASE / phase).glob('*.json')):
        value = json.loads(path.read_text())
        if isinstance(value, dict) and 'argv' in value:
            commands.append(dict(value, phase=phase, label=path.stem,
                receipt=str(path), stdout=str(path.with_suffix('.stdout')), stderr=str(path.with_suffix('.stderr'))))
named = {}
for path in WHEEL_ORIGINAL.glob('*.json'):
    value = json.loads(path.read_text())
    if isinstance(value, dict) and 'argv' in value:
        named[json.dumps(value['argv'])] = path
wheel_commands = []
for path in sorted((BASE / 'wheel-streams-01').glob('*.json')):
    value = json.loads(path.read_text())
    original = named[json.dumps(value['argv'])]
    row = dict(value, phase='wheel-01', label=original.stem,
        receipt=str(path), stdout=str(path.with_suffix('.stdout')), stderr=str(path.with_suffix('.stderr')),
        original_receipt=str(original))
    wheel_commands.append(row)
    commands.append(row)
commands.sort(key=lambda row: row['started_utc'])
assert all(row['returncode'] == 0 for row in commands)
with (BASE / 'COMMANDS.json').open('x') as stream:
    json.dump(commands, stream, indent=2); stream.write('\n')

result = {
    'schema_version': 1, 'qualification_completed': True, 'scope': 'Same-host Apple Silicon installed candidate Rust Debug/Release consumers and complete existing installed-wheel lifecycle with archive-derived native counterpart. This success does not claim the redundant private-tree copy completed.',
    'source_commit': inputs['source_commit'], 'sdk_producer_commit': inputs['producer_commit'],
    'wheel_original_root': str(WHEEL_ORIGINAL),
    'wheel_original_report_sha256': hashlib.sha256((WHEEL_ORIGINAL / 'PYTHON_INSTALLATION.json').read_bytes()).hexdigest(),
    'private_wheel_mirror_completed': False, 'partial_mirror_authoritative': False,
    'wheel_outer_driver_returncode': 130,
    'copy_postprocessing': 'Explicitly interrupted after successful qualification to avoid duplicating 65,890 private files. No symlink or special-file cause was observed. Original evidence is complete and authoritative.',
    'sdk_report_sha256': inputs['report_sha256'], 'sdk_archives_verified_before_and_after': len(inputs['archives']),
    'candidate_archive_sha256': package['archive']['sha256'],
    'candidate_archive_identical_across_two_package_runs': True,
    'rust_profiles': package['build_profiles'], 'rust_tests_per_profile': 3,
    'rust_resolution': package['resolution'], 'counterpart_resolution': counterpart['resolution'],
    'native_sha256': counterpart['native_sha256'], 'importer_sha256': counterpart['importer_sha256'],
    'wheel_sha256': wheel['wheel_sha256'], 'wheel_modules': len(wheel['modules']),
    'wheel_commands': len(wheel_commands), 'provider': wheel['provider'],
    'provider_files_unchanged': True, 'source_package_identities_unchanged': True,
    'global_selected_tool_bytes_unchanged': json.loads((BASE / 'PACKAGE-DRIVER.json').read_text())['global_selected_tool_bytes_unchanged'],
    'directory_cli_scope': public['directory_cli_scope'],
    'prior_evidence_not_requalified': 'The prior contract-purpose descriptor/crypto and two focused independent checks used native source 21e00e9c; they were not treated as completion of this new cohort.',
    'launch_preparation_failure': 'launch-preparation-01.json preserves exit 126 before Python started; invocation corrected to /bin/sh without changing permissions or acceptance.',
    'primary_agent_readback': {'completed': True, 'successful_report': str(BASE / 'ROOT_READBACK-02.json'),
        'preceding_diagnostic_failure': str(BASE / 'ROOT_READBACK.json'),
        'wheel_readback': str(BASE / 'ROOT_WHEEL_READBACK.json'),
        'scope': 'Independent reread of the same existing Rust/package evidence. The initial KeyError was a report-schema assumption, not a product failure or test rerun; neither readback is external security review.'},
    'product_source_modified_by_this_task': False, 'shared_verifier_file_modified_by_this_task': False, 'ci_triggered': False,
    'publication_performed': False, 'release_claim_eligible': False,
    'excluded': ['Full candidate Release CI test suite', 'C/Swift/Kotlin/Android consumers', 'Windows/Linux execution or cross-host qualification', 'Physical power-loss tests', 'New source directory CLI producer run', 'External security review or release admission'],
    'reports': {'rust': str(BASE / 'rust-01/CONTINUITY_PACKAGE.json'),
        'counterpart': str(BASE / 'counterpart-01/INSTALLED_COUNTERPART.json'),
        'wheel': str(WHEEL_ORIGINAL / 'PYTHON_INSTALLATION.json')},
    'commands': str(BASE / 'COMMANDS.json'),
    'public_archive_allowlist': str(BASE / 'PUBLIC_ARCHIVE_ALLOWLIST.json'),
}
with (BASE / 'RESULT.json').open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
with (BASE / 'RUST_SDK_PACKAGE.json').open('xb') as stream:
    stream.write(Path(inputs['report']).read_bytes())
table = '\n'.join(f"| {r['phase']} / {r['label']} | {r['started_utc']} | {r['finished_utc']} | {r['elapsed_seconds']:.3f} | {r['returncode']} |" for r in commands)
readme = f'''# Installed Continuity validation for managed SDK cohort

Completed the existing Rust installed-package consumer gate (Debug and Release, three public API tests per profile, strict Clippy and source/archive/tool readback), then built the independent native counterpart/importer from installed archives and completed the existing installed Python wheel lifecycle runner ({len(wheel_commands)} commands, {len(wheel['modules'])} modules).

Source checkout: `{inputs['source_commit']}`. SDK producer: `{inputs['producer_commit']}`. Their intervening changes were only documentation/evidence. SDK report SHA-256: `{inputs['report_sha256']}`; all 12 archive digests and sizes were checked before and after. The candidate archive was byte-identical across both packaging paths: `{package['archive']['sha256']}`.

Native counterpart SHA-256: `{counterpart['native_sha256']}`. The installed wheel runner used this exact new archive-derived native binary. Its source-bound wheel SHA-256 was `{wheel['wheel_sha256']}`; the wheel was newly installed outside checkout, and its installed modules and copied harness were rechecked after execution. Provider identity and unchanged file hashes are recorded separately.

The prior 21e00e9c contract descriptor/crypto checks and two focused independent checks were not counted as this new cohort. The actual directory CLI public capture was reused solely for historical public-byte verification; no new CLI producer or installed-CLI claim is made.

All orchestration changes are task-private Python files. The repository's acceptance code and assertions were unchanged. SDK commands retained 900 seconds and 16 MiB per stream; wheel commands retained 900 seconds and 1 MiB per stream. Streaming sinks preserve partial output on failure/timeout. All qualification entrypoints use `/bin/sh artifact/python-run.sh`, with explicit `QPERIAPT_PYTHON`. Initial read-only JSON inventory inspection used a direct Python invocation; it was not an acceptance run. `launch-preparation-01.json` retains the shell execute-permission error before Python started; that preparation invocation was corrected to `/bin/sh` without chmod.

This is same-host Apple Silicon archive installation/consumer evidence, not public-registry publication. It does not replace full candidate Release CI, other platform/language consumers, physical power loss, external review or formal release admission. Raw runtime evidence remains private under target and is not a public capture archive.

## Result paths

- [Joint result]({BASE / 'RESULT.json'})
- [All commands, exact argv, timing and full stream paths]({BASE / 'COMMANDS.json'})
- [Command interval table]({BASE / 'TIMELINE.md'})
- [SDK and tool input identities]({BASE / 'INPUTS.json'})
- [Rust candidate package/Debug/Release report]({BASE / 'rust-01/CONTINUITY_PACKAGE.json'})
- [Installed native counterpart/importer report]({BASE / 'counterpart-01/INSTALLED_COUNTERPART.json'})
- [Complete installed-wheel result, original authoritative directory]({WHEEL_ORIGINAL / 'PYTHON_INSTALLATION.json'})
- [Wheel/provider/public-fixture inputs]({BASE / 'wheel-preflight.json'}) and [provider file hashes]({BASE / 'provider-inputs.json'})
- [Primary agent successful readback]({BASE / 'ROOT_READBACK-02.json'}) and [preserved initial reader diagnostic]({BASE / 'ROOT_READBACK.json'}). The initial `KeyError: files` came from assuming two different `source_inputs` schemas were identical; this was not a product failure or qualification rerun. The successful readback compared 1399 Rust and 26 counterpart source inputs with the main checkout, all 12 SDK archives, and both raw runtime/public-export profiles. It is internal readback, not external security review.
- [Primary agent complete wheel readback]({BASE / 'ROOT_WHEEL_READBACK.json'}) checked 240 source inputs, 105 modules, 113 installed files plus 120 copied harness files, all 25 original/stream pairs, provider bytes and complete composition/capacity profiles.
- [Public archive allowlist]({BASE / 'PUBLIC_ARCHIVE_ALLOWLIST.json'}) and [content review]({BASE / 'PUBLIC_ARCHIVE_REVIEW.md'}).
- [Private-copy interruption and actual outer exit 130]({BASE / 'COPY-INTERRUPTION-RESULT.json'}).

Rust and counterpart gate outputs were copied here after completion. The wheel's original directory above is authoritative. Its 25 commands and final identity readback succeeded before a redundant copy of the private runtime tree was deliberately interrupted with the parent's permission; the outer driver exited 130. The partial `wheel-01` mirror is retained and is not authoritative. Both lstat audits observed 65,890 regular files and 299 directories, with no symlink or special entry; no special-file cause is claimed. No tests were rerun. Runtime package consumers were created outside the checkout. Existing package-gate retirement of completed build caches remains recorded in its storage receipts.

The instantaneous runtime load observations are not root-cause or benchmark evidence. Observation 02 explicitly corrects observation 01's overly broad argument-substring process classification; both are retained.
'''
with (BASE / 'README.md').open('x') as stream:
    stream.write(readme)
with (BASE / 'TIMELINE.md').open('x') as stream:
    stream.write('# Actual command intervals\n\n| Phase / command | Started UTC | Finished UTC | Wall seconds | Exit |\n| --- | --- | --- | ---: | ---: |\n' + table + '\n')
allowlist = json.loads((BASE / 'PUBLIC_ARCHIVE_ALLOWLIST.json').read_text())
manifest = {'scope': 'Reviewed public exports, command streams/JSON and provenance/diagnostic metadata only. No traversal or hashing of original or partial private runtime trees.',
            'source_roots': {'task': str(BASE), 'wheel_original': str(WHEEL_ORIGINAL)}, 'files': []}
for row in allowlist['files']:
    root = BASE if row['source_root'] == 'task' else WHEEL_ORIGINAL
    path = root / row['path']
    assert path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    manifest['files'].append({k:row[k] for k in ('source_root','path','bytes','sha256','classification')})
for name in ('README.md','RESULT.json','COMMANDS.json','TIMELINE.md','PUBLIC_ARCHIVE_ALLOWLIST.json','PUBLIC_ARCHIVE_REVIEW.md'):
    path = BASE / name
    manifest['files'].append({'source_root':'task','path':name,'bytes':path.stat().st_size,
                             'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'classification':'derived public/provenance index; local paths may occur'})
with (BASE / 'FILES.json').open('x') as stream:
    json.dump(manifest, stream, indent=2); stream.write('\n')
print(json.dumps({k:result[k] for k in ['qualification_completed','source_commit','candidate_archive_sha256','native_sha256','wheel_commands','wheel_modules','wheel_outer_driver_returncode','release_claim_eligible']}, indent=2))
