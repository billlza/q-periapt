from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import stat

import continuity_enrollment as enrollment
import continuity_roster_renewal as roster
import continuity_device_replacement as replacement
import continuity_device_retirement as retirement

BASE = Path('${CHECKOUT}/target/continuity-installed-managed-cohort')
driver = json.loads((BASE / 'WHEEL-DRIVER.json').read_text())
WHEEL = Path(driver['output_original'])
aggregate = json.loads((WHEEL / 'PYTHON_INSTALLATION.json').read_text())
package = json.loads((BASE / 'rust-01/CONTINUITY_PACKAGE.json').read_text())
assert driver['completed'] and aggregate['completed'] and package['completed']
assert driver['command_count'] == 25
assert json.loads((BASE / 'COPY-INTERRUPTION-RESULT.json').read_text())['outer_shell_returncode'] == 130

entries = []
shapes = {}
seen = set()
path_markers = (b'/Users/', b'/private/var/', b'/var/folders/', b'/tmp/qperiapt-')


def add(root, path, category, basis, *, opaque=False):
    base = BASE if root == 'task' else WHEEL
    key = (root, str(path.relative_to(base)))
    assert key not in seen
    seen.add(key)
    assert stat.S_ISREG(path.lstat().st_mode), path
    data = path.read_bytes()
    # A quoted marker in reviewer source is not a PEM key. Check actual delimited
    # multiline PEM material; public classification still rests on the reviewed
    # field semantics and closed exporter sets, not this supplemental check.
    pem_private = rb'-----BEGIN (?:[A-Z]+ )*PRIVATE KEY-----\r?\n(?:[A-Za-z0-9+/=]+\r?\n)+-----END (?:[A-Z]+ )*PRIVATE KEY-----'
    assert re.search(pem_private, data) is None
    local_paths = any(marker in data for marker in path_markers)
    if opaque:
        assert not local_paths, 'Review an unexpected host path in an opaque public export before publishing'
    entries.append({'source_root':root,'path':key[1],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
        'classification':category,'basis':basis,'contains_local_host_paths':local_paths,
        'public_copy_policy':('preserve opaque public bytes exactly' if opaque else
            'metadata only; local path normalization is recommended in a derived public copy, retaining the original SHA256' if local_paths else 'raw reviewed bytes may be archived')})


def json_shape(value):
    leaves = {}
    maps = {'source_files','loaded_product_modules','source_inputs','modules','source_sha256','public_readbacks','public_files'}
    def walk(x, at=''):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in maps:
                    leaves[at + '.' + k] = ['reviewed source/hash/path/public-file metadata map']
                else: walk(v, at + '.' + k)
        elif isinstance(x, list):
            for v in x: walk(v, at + '[]')
        else:
            leaves.setdefault(at, [])
            kind = type(x).__name__
            if kind not in leaves[at]: leaves[at].append(kind)
    walk(value)
    return leaves


# These are the existing exporters' closed public sets, not a directory-name rule.
exports = []
for profile in ('debug', 'release'):
    execution = package['execution'][profile]
    checks = [
        ('enrollment-public', enrollment.verify, execution['enrollment']),
        ('roster-renewal-public', roster.verify, execution['roster_renewal']),
        ('device-replacement-public', replacement.verify, execution['device_replacement']),
        ('device-retirement-public', retirement.verify, execution['device_retirement']),
    ]
    reopen = execution['session_reopen']
    checks.append(('enrollment-reopen-public',
        lambda p, r=reopen: enrollment.verify_reopen(p, r['test_protocol_time'], r['session'], public_only=True),
        reopen['enrollment']))
    for suffix, check, expected in checks:
        directory = BASE / 'rust-01' / (profile + '-' + suffix)
        observed = check(directory)
        assert observed == expected, directory
        public = observed['public_readbacks']
        for name, record in sorted(public.items()):
            path = directory / name
            assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
            add('task', path, 'closed Rust public export',
                'Existing exporter/reader rechecked exact inventory, framing, binding and public_readbacks digest; not a private runtime copy.', opaque=True)
        exports.append({'directory':str(directory.relative_to(BASE)),'files':len(public),'reader':check.__name__})

# Actual top-level outputs were reviewed together with their producer summaries.
# These summaries contain counters, public IDs/commitments, hashes, refusal labels
# and source/runtime paths. The detailed case trees are deliberately excluded.
wheel_top = sorted(p for p in WHEEL.iterdir() if p.is_file() and p.suffix in ('.stdout','.stderr','.json'))
command_count = 0
for path in wheel_top:
    if path.suffix == '.stderr':
        assert path.read_bytes() == b'', path
        category = 'empty successful command stderr'
    elif path.suffix == '.json':
        value = json.loads(path.read_text())
        if isinstance(value, dict) and 'argv' in value:
            assert set(value) == {'argv','cwd','exit'} and value['exit'] == 0
            command_count += 1
            category = 'exact command argv/cwd/exit metadata'
        else:
            category = 'public result/provenance/hash metadata'
        shapes[path.name] = json_shape(value)
    elif path.name == 'install.stdout':
        category = 'pip local-wheel installation status and paths'
    elif path.stat().st_size == 0:
        category = 'empty successful command stdout'
    else:
        shapes[path.name] = json_shape(json.loads(path.read_text()))
        category = 'public test summary, counters, IDs, commitments, hashes and refusal labels'
    add('wheel_original', path, category,
        'Exact current bytes reviewed; top-level only. No raw signing/KEM/wrapping/session keys, journal/database body or native private fixture export was observed.')
assert command_count == 25

# Retain both successful command streams and the streamed timing/error metadata.
for path in sorted((BASE / 'wheel-streams-01').iterdir()):
    if path.suffix in ('.json','.stdout','.stderr'):
        add('task', path, 'bounded command stream or timing metadata',
            'All 25 stream byte pairs were matched to original gate outputs by ROOT_WHEEL_READBACK; no new execution.')

# These gate-root files are build/source metadata and public test traces, not
# consumers' runtime trees. Binary executables and .crate archives are excluded.
for phase in ('rust-01','counterpart-01'):
    for path in sorted((BASE / phase).iterdir()):
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr','.lock','.toml'):
            add('task', path, 'archive-derived build/consumer provenance or public test trace',
                'Gate-root metadata, Cargo messages and public test markers; consumers and private state remain outside this set.')

names = [
    'run_package.py','run_counterpart.py','run_wheel.py','finalize.py','review_public_archive.py',
    'review_public_archive_01.py','PUBLIC-REVIEW-01.json',
    'INPUTS.json','PRIOR-SCOPES.json','wheel-preflight.json','provider-inputs.json',
    'PACKAGE-LAUNCH.json','COUNTERPART-LAUNCH.json','WHEEL-LAUNCH.json',
    'PACKAGE-DRIVER.json','COUNTERPART-DRIVER.json','WHEEL-DRIVER.json',
    'package-driver.stdout','package-driver.stderr','counterpart-driver.stdout','counterpart-driver.stderr',
    'wheel-driver.stdout','wheel-driver.stderr','launch-preparation-01.json',
    'COPY-TREE-TYPES.json','COPY-INTERRUPTION.json','COPY-INTERRUPTION-RESULT.json',
    'ROOT_READBACK.json','ROOT_READBACK-02.json','ROOT_WHEEL_READBACK.json',
    'root_readback.py','root_readback_02.py','root_wheel_readback.py',
    'root-readback.stdout','root-readback.stderr','root-readback-02.stdout','root-readback-02.stderr',
    'root-wheel-readback.stdout','root-wheel-readback.stderr',
]
for name in names:
    add('task', BASE / name, 'driver/input/internal-readback/postprocessing provenance',
        'Reviewed task code and provenance only. Exit126 preparation, KeyError reader diagnostic, and authorized copy interruption/exit130 remain explicit; none is rewritten as a product failure or rerun.')
for path in sorted((BASE / 'preflight').iterdir()):
    add('task', path, 'local checkout/report admission metadata',
        'Git status/head/local fetch and documentation-only followup inventory; no credentials or private runtime data.')

result = {
    'schema_version':1,'review_completed':True,'observed_utc':datetime.now(timezone.utc).isoformat(),
    'source_roots':{'task':'directory containing this allowlist','wheel_original':'WHEEL-DRIVER.json.output_original; never the partial task/wheel-01 mirror'},
    'original_wheel_report_sha256':hashlib.sha256((WHEEL / 'PYTHON_INSTALLATION.json').read_bytes()).hexdigest(),
    'scope':'Explicit exact-file public/provenance allowlist. No runtime tree traversal or copying. No product test/build rerun.',
    'method':'Manual actual JSON/stdout field and producer-summary review plus existing closed Rust public readers. Not a claim based solely on a secret-name scan or a directory named public.',
    'wheel_top_level_review':{'files':len(wheel_top),'command_receipts':25,
        'content':'Public statuses, counters, public operation/journal/session IDs, state commitments, artifact/source hashes, refusal labels, module origins and local paths. More than just status/path fields, but no raw private key or ledger/database body.',
        'aggregate_non_source_leaf_path_count':409,
        'host_path_note':'Some metadata contains absolute user/temporary/tool paths. Normalize only derived public metadata if desired and preserve its original SHA256. Never rewrite signed/public binary exports.'},
    'rust_public_exports':exports,
    'excluded':['Original and partial wheel runtime subdirectories (65,890-file tree)',
        'All consumer/location temp trees, private-fixture-path/private-witness-path targets, signers, wrapping/KEM/session keys and journals/databases',
        'Whole directories merely named native/public; these are not the reviewed exporter closure',
        'counterpart/importer executables, bulk archives/toolchain/provider trees and unreviewed files'],
    'files':entries,
}
with (BASE / 'PUBLIC_ARCHIVE_ALLOWLIST.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
with (BASE / 'PUBLIC_JSON_SHAPES.json').open('x') as f:
    json.dump(shapes,f,indent=2);f.write('\n')
raw_count = sum(not r['contains_local_host_paths'] for r in entries)
text = f'''# Public archive boundary

The 25 qualification commands and final readback succeeded. The optional whole private-tree copy was stopped afterward with explicit authorization; its outer driver exit is 130. The original wheel root from `WHEEL-DRIVER.json.output_original` remains authoritative. The partial `wheel-01` mirror is not a source for publication.

The exact-file allowlist has {len(entries)} entries, including {sum(x['files'] for x in exports)} files in 10 Rust public export closures and {len(wheel_top)} original wheel top-level stdout/stderr/JSON files. {raw_count} entries have no detected local-host path prefix; other reviewed metadata is marked separately. The allowlist records every source alias, relative path, size and SHA-256. It does not authorize globbing any private case tree.

The wheel top-level JSON/stdout files contain public test state, counts, public operation/journal/session identifiers, public state commitments, artifact/source hashes, refusal summaries and paths. They are not limited to just booleans and paths. The final aggregate is 638264 bytes and has 409 reviewed non-source-metadata leaf paths. No raw signing/KEM/wrapping/session keys, native private fixture payloads or journal/database bodies were observed in this closed top-level set. Source/hash/module maps are provenance. The 80-hex target/head values are public state-position/commitment encodings; journal and session values are identifiers, not stored journal bodies or secret roots.

Some JSON/stdout/traceback/driver records contain absolute local user, temporary and tool paths. A public repository can use derived path-normalized metadata with the original file SHA retained. Keep raw originals private and unchanged. Do not normalize the authenticated binary exports.

The safe Rust exports are Debug and Release enrollment, enrollment-reopen, roster-renewal, device-replacement and device-retirement public closures. Each was re-read by its existing reader and matched against the qualified report's full public_readbacks inventory. They contain public requests, certificates/rosters/public keys, ciphertexts, receipts/authentication tags, identifiers, test application effects and public process traces. A report MAC is a tag, not its secret key. The local-root/journal files in these particular closures are public identifiers. Their existing structural readers do not replace native signature/MAC verification or external security review.

Do not archive the original or partial 65,890-file wheel runtime tree, any outside consumer/temp directory, private-fixture-path/private-witness-path targets, signing/wrapping/session material, database/journal files, or arbitrary nested RESULT/NATIVE/WITNESS files. A nested folder called native/public is not automatically covered. Both lstat audits found no symlink or special file; stopping the copy avoids an unnecessary duplicate private tree, not a demonstrated special-file failure.

Root readback diagnostics, launcher exit126 and the authorized copy exit130 are retained as provenance, separate from the successful product qualification commands. PUBLIC-REVIEW-01.json also retains a reviewer-only false positive: the first audit treated its own quoted PEM marker as key material. The corrected supplemental check recognizes an actual multiline PEM block; classification rests on actual field semantics and closed readers, not a marker scan. No new build or test run was performed for this review.
'''
with (BASE / 'PUBLIC_ARCHIVE_REVIEW.md').open('x') as f:f.write(text)
print(json.dumps({'review_completed':True,'allowlisted_files':len(entries),'rust_public_files':sum(x['files'] for x in exports),
                  'wheel_top_level_files':len(wheel_top),'metadata_with_local_paths':len(entries)-raw_count},indent=2))
