# Installed Continuity validation for managed SDK cohort

Completed the existing Rust installed-package consumer gate (Debug and Release, three public API tests per profile, strict Clippy and source/archive/tool readback), then built the independent native counterpart/importer from installed archives and completed the existing installed Python wheel lifecycle runner (25 commands, 105 modules).

Source checkout: `4effa8b2b25e7403ab912b65894a7d1e73695542`. SDK producer: `f560d803c43a24fff222daa5e5e5bd623bfdf874`. Their intervening changes were only documentation/evidence. SDK report SHA-256: `93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8`; all 12 archive digests and sizes were checked before and after. The candidate archive was byte-identical across both packaging paths: `9bd308702bbb922122ae9f69c40d0cd691f67da9ef0d7d6c2b5381adf2cce163`.

Native counterpart SHA-256: `eaf5e7cc305775b7d13292252dfba581bc797bca90be2a2b94d66ba2c2205254`. The installed wheel runner used this exact new archive-derived native binary. Its source-bound wheel SHA-256 was `596bba62781296558a64d768a12ed618043b8cf3e14070cdf81c2ed423d3a094`; the wheel was newly installed outside checkout, and its installed modules and copied harness were rechecked after execution. Provider identity and unchanged file hashes are recorded separately.

The prior 21e00e9c contract descriptor/crypto checks and two focused independent checks were not counted as this new cohort. The actual directory CLI public capture was reused solely for historical public-byte verification; no new CLI producer or installed-CLI claim is made.

All orchestration changes are task-private Python files. The repository's acceptance code and assertions were unchanged. SDK commands retained 900 seconds and 16 MiB per stream; wheel commands retained 900 seconds and 1 MiB per stream. Streaming sinks preserve partial output on failure/timeout. All qualification entrypoints use `/bin/sh artifact/python-run.sh`, with explicit `QPERIAPT_PYTHON`. Initial read-only JSON inventory inspection used a direct Python invocation; it was not an acceptance run. `launch-preparation-01.json` retains the shell execute-permission error before Python started; that preparation invocation was corrected to `/bin/sh` without chmod.

This is same-host Apple Silicon archive installation/consumer evidence, not public-registry publication. It does not replace full candidate Release CI, other platform/language consumers, physical power loss, external review or formal release admission. Raw runtime evidence remains private under target and is not a public capture archive.

## Result paths

- [Joint result](${CHECKOUT}/target/continuity-installed-managed-cohort/RESULT.json)
- [All commands, exact argv, timing and full stream paths](${CHECKOUT}/target/continuity-installed-managed-cohort/COMMANDS.json)
- [Command interval table](${CHECKOUT}/target/continuity-installed-managed-cohort/TIMELINE.md)
- [SDK and tool input identities](${CHECKOUT}/target/continuity-installed-managed-cohort/INPUTS.json)
- [Rust candidate package/Debug/Release report](${CHECKOUT}/target/continuity-installed-managed-cohort/rust-01/CONTINUITY_PACKAGE.json)
- [Installed native counterpart/importer report](${CHECKOUT}/target/continuity-installed-managed-cohort/counterpart-01/INSTALLED_COUNTERPART.json)
- [Complete installed-wheel result, original authoritative directory](${CHECKOUT}/target/continuity-managed-maintenance/source-f560d803/target/continuity-installed-managed-cohort/wheel-01/PYTHON_INSTALLATION.json)
- [Wheel/provider/public-fixture inputs](${CHECKOUT}/target/continuity-installed-managed-cohort/wheel-preflight.json) and [provider file hashes](${CHECKOUT}/target/continuity-installed-managed-cohort/provider-inputs.json)
- [Primary agent successful readback](${CHECKOUT}/target/continuity-installed-managed-cohort/ROOT_READBACK-02.json) and [preserved initial reader diagnostic](${CHECKOUT}/target/continuity-installed-managed-cohort/ROOT_READBACK.json). The initial `KeyError: files` came from assuming two different `source_inputs` schemas were identical; this was not a product failure or qualification rerun. The successful readback compared 1399 Rust and 26 counterpart source inputs with the main checkout, all 12 SDK archives, and both raw runtime/public-export profiles. It is internal readback, not external security review.
- [Primary agent complete wheel readback](${CHECKOUT}/target/continuity-installed-managed-cohort/ROOT_WHEEL_READBACK.json) checked 240 source inputs, 105 modules, 113 installed files plus 120 copied harness files, all 25 original/stream pairs, provider bytes and complete composition/capacity profiles.
- [Public archive allowlist](${CHECKOUT}/target/continuity-installed-managed-cohort/PUBLIC_ARCHIVE_ALLOWLIST.json) and [content review](${CHECKOUT}/target/continuity-installed-managed-cohort/PUBLIC_ARCHIVE_REVIEW.md).
- [Private-copy interruption and actual outer exit 130](${CHECKOUT}/target/continuity-installed-managed-cohort/COPY-INTERRUPTION-RESULT.json).

Rust and counterpart gate outputs were copied here after completion. The wheel's original directory above is authoritative. Its 25 commands and final identity readback succeeded before a redundant copy of the private runtime tree was deliberately interrupted with the parent's permission; the outer driver exited 130. The partial `wheel-01` mirror is retained and is not authoritative. Both lstat audits observed 65,890 regular files and 299 directories, with no symlink or special entry; no special-file cause is claimed. No tests were rerun. Runtime package consumers were created outside the checkout. Existing package-gate retirement of completed build caches remains recorded in its storage receipts.

The instantaneous runtime load observations are not root-cause or benchmark evidence. Observation 02 explicitly corrects observation 01's overly broad argument-substring process classification; both are retained.
