from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-installed-managed-cohort'
OUT = ROOT / 'research/sdk-alpha1/evidence/20261104-continuity-installed-maintenance'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    assert not OUT.exists()
    allowlist_path = BASE / 'PUBLIC_ARCHIVE_ALLOWLIST.json'
    allowlist_bytes = allowlist_path.read_bytes()
    allowed = json.loads(allowlist_bytes)
    joint = read(BASE / 'RESULT.json')
    assert joint['qualification_completed'] and not joint['private_wheel_mirror_completed']
    assert joint['wheel_outer_driver_returncode'] == 130
    assert read(BASE / 'ROOT_READBACK-02.json')['completed']
    assert read(BASE / 'ROOT_WHEEL_READBACK.json')['completed']
    original = Path(read(BASE / 'WHEEL-DRIVER.json')['output_original'])
    assert sha((original / 'PYTHON_INSTALLATION.json').read_bytes()) == allowed['original_wheel_report_sha256']
    roots = {'task': BASE, 'wheel_original': original}
    rows = list(allowed['files'])
    extra = ['RESULT.json', 'COMMANDS.json', 'FILES.json', 'README.md', 'TIMELINE.md',
             'RUST_SDK_PACKAGE.json', 'PUBLIC_ARCHIVE_ALLOWLIST.json', 'PUBLIC_ARCHIVE_REVIEW.md',
             'PUBLIC_JSON_SHAPES.json', 'public-review-02.stdout', 'public-review-02.stderr', 'seal_public.py']
    existing = {(row['source_root'], row['path']) for row in rows}
    for name in extra:
        assert ('task', name) not in existing
        body = (BASE / name).read_bytes()
        rows.append({'source_root': 'task', 'path': name, 'bytes': len(body), 'sha256': sha(body),
                     'classification': 'Final reviewed index or archive-construction provenance',
                     'public_copy_policy': 'Derived metadata; retain original SHA-256 and normalize local paths'})
    substitutions = [
        (str(ROOT), '${CHECKOUT}'),
        ('${CARGO_HOME}', '${CARGO_HOME}'),
        ('${ORIGINAL_TOOLCHAIN}', '${ORIGINAL_TOOLCHAIN}'),
        ('${PYTHON_ROOT}', '${PYTHON_ROOT}'),
        ('${PYTHON_LAUNCHER}', '${PYTHON_LAUNCHER}'),
        ('${USER_HOME}', '${USER_HOME}'),
        ('${HOST_TEMP}', '${HOST_TEMP}'),
        ('${HOST_TEMP}', '${HOST_TEMP}'),
    ]
    files = {}
    members = {}
    for row in rows:
        root = roots[row['source_root']]
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        source = root / relative
        assert source.resolve().is_relative_to(root.resolve())
        assert stat.S_ISREG(source.lstat().st_mode)
        raw = source.read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
        opaque = row['public_copy_policy'] == 'preserve opaque public bytes exactly'
        if opaque:
            archived = raw
        else:
            text = raw.decode('utf-8')
            for old, new in substitutions:
                text = text.replace(old, new)
            archived = text.encode('utf-8')
            assert b'${USER_HOME}' not in archived
            assert b'${HOST_TEMP_ID}' not in archived
            if relative.suffix == '.json': json.loads(archived)
        name = row['source_root'] + '/' + relative.as_posix()
        assert name not in members
        members[name] = archived
        files[name] = {'bytes': len(archived), 'sha256': sha(archived),
                       'original_bytes': len(raw), 'original_sha256': sha(raw),
                       'derived_path_normalization': raw != archived,
                       'opaque_public_bytes_unchanged': opaque,
                       'classification': row['classification']}
    assert sum(row['opaque_public_bytes_unchanged'] for row in files.values()) == 534
    assert allowlist_path.read_bytes() == allowlist_bytes
    manifest = {'schema_version': 1, 'source_commit': joint['source_commit'],
                'original_allowlist_sha256': sha(allowlist_bytes),
                'allowlisted_entries': 835, 'additional_final_metadata_entries': len(extra),
                'scope': 'Only exact reviewed public exports and metadata. No private runtime tree or executable. Opaque exports retain original bytes. Metadata with local paths is a derived disclosure copy, not the original command receipt.',
                'path_aliases': sorted(set(value for _, value in substitutions)),
                'original_locations': 'Private originals remain under target/continuity-installed-managed-cohort and WHEEL-DRIVER.output_original. The partial wheel mirror is not authoritative.',
                'files': files}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    OUT.mkdir(parents=True)
    with zipfile.ZipFile(OUT / 'EVIDENCE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in [*sorted(members.items()), ('MANIFEST.json', manifest_bytes)]:
            item = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100600 << 16
            archive.writestr(item, body)
    with zipfile.ZipFile(OUT / 'EVIDENCE.zip') as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(members) | {'MANIFEST.json'}
        assert archive.read('MANIFEST.json') == manifest_bytes
        for name, row in files.items():
            body = archive.read(name)
            assert len(body) == row['bytes'] and sha(body) == row['sha256']
    (OUT / 'FILES.json').write_bytes(manifest_bytes)
    summary = {key: joint[key] for key in ['qualification_completed', 'scope', 'source_commit', 'sdk_producer_commit',
               'sdk_report_sha256', 'sdk_archives_verified_before_and_after', 'candidate_archive_sha256',
               'rust_profiles', 'rust_tests_per_profile', 'native_sha256', 'importer_sha256', 'wheel_sha256',
               'wheel_modules', 'wheel_commands', 'provider', 'provider_files_unchanged',
               'source_package_identities_unchanged', 'global_selected_tool_bytes_unchanged',
               'directory_cli_scope', 'private_wheel_mirror_completed', 'partial_mirror_authoritative',
               'wheel_outer_driver_returncode', 'copy_postprocessing', 'publication_performed', 'release_claim_eligible', 'excluded']}
    last = read(BASE / 'wheel-streams-01/command-25.json')
    summary.update(archive_sha256=sha((OUT / 'EVIDENCE.zip').read_bytes()), archive_members=len(files) + 1,
                   manifest_sha256=sha(manifest_bytes), closed_public_files=534,
                   derived_metadata_files=sum(row['derived_path_normalization'] for row in files.values()),
                   slowest_wheel_command_seconds=last['elapsed_seconds'], command_timeout_seconds=900,
                   root_rust_readback_completed=True, root_wheel_readback_completed=True,
                   sealed_utc=datetime.now(timezone.utc).isoformat())
    (OUT / 'RESULT.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: summary[key] for key in ['qualification_completed', 'archive_sha256', 'archive_members',
          'manifest_sha256', 'derived_metadata_files', 'slowest_wheel_command_seconds', 'release_claim_eligible']}, indent=2))


if __name__ == '__main__':
    main()
