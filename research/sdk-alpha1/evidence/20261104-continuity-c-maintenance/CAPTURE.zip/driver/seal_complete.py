from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import io
import json
import re
import stat
import zipfile

import continuity_package as package
import continuity_c_witness_openssl as openssl
import continuity_c_enrollment as enrollment

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-c-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = SOURCE / 'target/c-managed-qualification/result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-continuity-c-maintenance'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
digest = lambda body: hashlib.sha256(body).hexdigest()


def obj(path):
    return json.loads(path.read_bytes())


def path_digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


launch = obj(BASE / 'LAUNCH_RESULT.json')
driver = obj(BASE / 'DRIVER_RESULT.json')
assert launch['completed'] and launch['returncode'] == 0 and driver['completed']
foundation = obj(OUTPUT / 'CONTINUITY_PACKAGE.json')
native = obj(OUTPUT / 'C_CONSUMER.json')
assert foundation['completed'] and foundation['partition_completed'] and foundation['sources_unchanged']
assert native['completed'] and native['partition_completed'] and foundation['c_consumer'] == native
assert foundation['source_commit'] == COMMIT and foundation['rust_report_sha256'] == REPORT_SHA
assert foundation['build_profiles'] == native['build_profiles'] == ['debug', 'release']
assert package.source_inputs() == foundation['source_inputs']
assert path_digest(REPORT) == REPORT_SHA
assert path_digest(ROOT / 'artifact/continuity_c_witness_openssl.py') == path_digest(SOURCE / 'artifact/continuity_c_witness_openssl.py')
openssl_checks = {}
publication_checks = {}
binaries = {}
for profile in ['debug', 'release']:
    witness = native['execution'][profile]['witness_openssl']
    assert witness['completed'] and set(witness['execution']) == {'server', 'client', 'rejections'}
    assert witness['execution']['server']['witness_exchanges'] == 146
    assert witness['execution']['client']['exchanges'] == 2
    assert witness['execution']['rejections']['store_calls'] == 0
    for kind, recorded in witness['execution'].items():
        stdout = (OUTPUT / f'c-witness-openssl-{kind}-{profile}.stdout').read_bytes()
        directory = OUTPUT / 'c-witness-openssl-public' / profile / kind
        replayed = openssl.verify_execution(kind, stdout, directory)
        expected = dict(recorded)
        exported = expected.pop('exported_public_files')
        assert replayed == expected
        assert exported == replayed['public_readbacks'] | replayed['command_logs']
    openssl_checks[profile] = {'server_exchanges': 146, 'client_exchanges': 2,
        'pre_store_rejections': witness['execution']['rejections']['cases'],
        'version': witness['peer']['version'], 'public_verifier_replay': True}
    publication_directory = OUTPUT / 'c-publication-public' / profile
    replayed = enrollment.verify_execution((OUTPUT / f'c-publication-trace-{profile}.stdout').read_bytes(),
                                           publication_directory, publication=True)
    expected = dict(native['execution'][profile]['publication'])
    expected.pop('binary')
    assert replayed == expected
    leaves = {path.relative_to(publication_directory).as_posix() for path in publication_directory.rglob('*') if path.is_file()}
    assert leaves == set(replayed['public_readbacks'])
    publication_checks[profile] = {'files': len(leaves), 'original_public_verifier_replay': True}
    for name, row in native['execution'][profile]['binaries'].items():
        assert path_digest(Path(row['path'])) == row['sha256']
        binaries[profile + '/' + name] = row

workflow_path = SOURCE / '.github/workflows/ci.yml'
workflow = workflow_path.read_text()
job = workflow.split('\n  continuity-installed-rust:\n', 1)[1].split('\n  continuity-installed-swift:\n', 1)[0]
patterns = re.findall(r'^\s+target/continuity-installed-rust/(.+)$', job, re.M)
assert '*.json' in patterns and '*.crate' in patterns and 'c-witness-openssl-public/**' in patterns
selected = set()
additional_patterns = ['c-publication-public/**']
assert additional_patterns[0] not in patterns, 'Reassess the pinned CI export gap if its input changed.'
for pattern in patterns + additional_patterns:
    if pattern.endswith('/**'):
        for directory in OUTPUT.glob(pattern[:-3]):
            assert directory.is_dir() and not directory.is_symlink()
            selected.update(path for path in directory.rglob('*') if path.is_file())
    else:
        selected.update(path for path in OUTPUT.glob(pattern) if path.is_file())
actual = {path for path in OUTPUT.rglob('*') if path.is_file()}
assert selected == actual, 'An output is outside the pinned CI selection plus the independently replayed publication export.'
assert all(not path.is_symlink() for path in OUTPUT.rglob('*'))
public_manifests = []
for manifest in sorted(OUTPUT.rglob('PUBLIC_FILES.json')):
    row = obj(manifest)
    assert row['completed'] and isinstance(row['files'], dict)
    for name, expected in row['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert path_digest(manifest.parent / relative) == expected
    leaves = {path.relative_to(manifest.parent).as_posix() for path in manifest.parent.rglob('*') if path.is_file()}
    assert leaves == set(row['files']) | {'PUBLIC_FILES.json'}
    public_manifests.append({'path': manifest.relative_to(OUTPUT).as_posix(), 'files': len(row['files']),
                             'sha256': path_digest(manifest)})
commands = []
for path in sorted(OUTPUT.glob('*.json')):
    row = obj(path)
    if isinstance(row, dict) and isinstance(row.get('argv'), list) and 'returncode' in row:
        commands.append({'receipt': path.name, 'returncode': row['returncode']})
files = {'output/' + path.relative_to(OUTPUT).as_posix(): path.read_bytes() for path in sorted(selected)}
for name in ['PREPARATION.json', 'INPUTS.json', 'LAUNCH.json', 'LAUNCH_RESULT.json', 'DRIVER_RESULT.json',
             'launch.py', 'driver.stdout', 'driver.stderr']:
    files['driver/' + name] = (BASE / name).read_bytes()
files['driver/run.py'] = (SOURCE / 'target/c-managed-qualification/run.py').read_bytes()
files['driver/streamed_command.py'] = (ROOT / 'target/continuity-installed-managed-cohort/run_package.py').read_bytes()
files['driver/seal_complete.py'] = Path(__file__).read_bytes()
files['producer/RUST_SDK_PACKAGE.json'] = REPORT.read_bytes()
files['source/ci.yml'] = workflow_path.read_bytes()
readback = {'completed': True, 'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'source_commit': COMMIT, 'sdk_producer_commit': obj(REPORT)['base_commit'],
    'sdk_report_sha256': REPORT_SHA, 'candidate_archive': foundation['archive'],
    'scope': 'Full existing local installed Rust/C Debug+Release gate on macOS arm64, with the independent OpenSSL TLS carrier and unchanged exact scenario validators.',
    'host_os': foundation['host_os'], 'host_arch': foundation['host_arch'],
    'rust_profiles': sorted(foundation['execution']), 'c_profiles': sorted(native['execution']),
    'current_main_runtime_inputs_identical': True,
    'native_binaries_reread': binaries, 'openssl': openssl_checks,
    'publication_public_readback': publication_checks,
    'command_receipts': len(commands), 'observed_returncodes': dict(Counter(str(row['returncode']) for row in commands)),
    'returncode_scope': 'Fault and refusal commands retain their original expected nonzero returns; the unmodified scenario validators and complete gate determine acceptance.',
    'public_manifest_readbacks': public_manifests,
    'output_files': len(selected), 'output_bytes': sum(len(body) for name, body in files.items() if name.startswith('output/')),
    'ci_export_patterns': patterns, 'ci_workflow_sha256': path_digest(workflow_path),
    'additional_public_export_patterns': additional_patterns,
    'ci_export_gap': 'Pinned CI omits c-publication-public/**. The complete original public export is independently replayed and retained here; upload configuration correction is separate from this runtime gate.',
    'gate_elapsed_seconds': launch['elapsed_seconds'], 'timeout_seconds': launch['timeout_seconds'],
    'component_timeout_seconds': 900, 'release_claim_eligible': False, 'publication_performed': False,
    'not_claimed': ['Hosted CI completion', 'GNU/Linux runtime', 'Swift/Kotlin/Android acceptance',
                    'Independent Witness signature engine', 'Cross-host qualification', 'Physical power loss', 'Formal product ABI admission']}
files['READBACK.json'] = encode(readback)
manifest = {name: {'bytes': len(body), 'sha256': digest(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
assert len(payload) < 100 * 1024**2, 'Split the capture explicitly rather than exceed the repository artifact bound.'
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']), ('READBACK.json', files['READBACK.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': digest(payload)}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
