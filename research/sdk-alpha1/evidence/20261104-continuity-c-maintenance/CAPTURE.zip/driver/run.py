from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import runpy
import sys

MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
SOURCE = MAIN / 'target/continuity-managed-maintenance/source-f560d803'
BASE = MAIN / 'target/continuity-c-managed-cohort'
CHAIN = MAIN / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
OPENSSL = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert Path.cwd() == SOURCE
    assert sys.version_info[:2] == (3, 14) and sys.flags.isolated and sys.flags.no_site
    assert sys.dont_write_bytecode and os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
    helper = MAIN / 'target/continuity-installed-managed-cohort/run_package.py'
    helpers = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')
    import rust_sdk_profile as sdk
    import continuity_package as package
    from rust_sdk_msrv import validate_report
    assert sdk.ROOT == package.ROOT == SOURCE
    sdk.validate_no_registry_credentials(os.environ)
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
    assert digest(REPORT) == REPORT_SHA
    before = package.source_inputs()
    cohort = validate_report(REPORT.read_bytes(), REPORT_SHA, digest(REPORT), before['rust_workspace_sha256'])
    archives = {}
    for name, row in cohort['crates'].items():
        path = REPORT.parent / 'crates' / row['file']
        assert path.is_file() and not path.is_symlink()
        assert digest(path) == row['sha256'] and path.stat().st_size == row['bytes']
        archives[name] = {'path': str(path), 'sha256': row['sha256'], 'bytes': row['bytes']}
    assert len(archives) == 12
    tools = package.compiler_identity(CHAIN)
    previous = json.loads((MAIN / 'target/continuity-installed-managed-cohort/rust-01/CONTINUITY_PACKAGE.json').read_bytes())
    assert previous['completed'] and previous['rust_report_sha256'] == REPORT_SHA
    assert before == previous['source_inputs'], 'A prior runtime input changed; do not infer cohort equivalence'
    metadata = {'source_commit': COMMIT, 'sdk_producer_commit': cohort['base_commit'],
                'report_sha256': REPORT_SHA, 'archives': archives, 'source_inputs': before,
                'prior_source_commit': previous['source_commit'], 'prior_source_inputs_identical': True,
                'prior_candidate_archive_sha256': previous['archive']['sha256'],
                'tool_binaries': tools, 'openssl_prefix': str(OPENSSL),
                'driver_sha256': digest(Path(__file__)), 'stream_helper_sha256': digest(helper),
                'python': sys.executable, 'allocator_environment': os.environ.get('MallocNanoZone'),
                'command_limits': {'timeout_seconds': 900, 'stdout_bytes': 16 * 1024**2, 'stderr_bytes': 16 * 1024**2},
                'gate': 'Existing continuity_package.qualify with both Rust/C profiles and OpenSSL witness enabled; original assertions unchanged.'}
    with (BASE / 'INPUTS.json').open('x') as stream:
        json.dump(metadata, stream, indent=2)
        stream.write('\n')
    sdk.command = helpers['streamed_command']
    output = SOURCE / 'target/c-managed-qualification/result-01'
    args = argparse.Namespace(output=output, report=REPORT, report_sha256=REPORT_SHA,
        toolchain_root=CHAIN, build_profile=None, with_c_consumer=True,
        with_apple_package=False, with_swift_consumer=False, swift_minimum_toolchain_root=None,
        with_kotlin_consumer=False, kotlin_java_home=None, kotlin_gradle_home=None,
        with_android_jni_consumer=False, android_java_home=None, witness_openssl_prefix=OPENSSL)
    state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
             'source_commit': COMMIT, 'output_original': str(output),
             'scope': 'Full existing same-host installed Rust/C Debug/Release gate and independent OpenSSL TLS carrier. No foreign wrapper, other OS, hosted CI or release approval claim.',
             'publication_performed': False, 'release_claim_eligible': False}
    try:
        result = package.qualify(args)
        assert result['completed'] and result['sources_unchanged']
        assert result['c_consumer']['completed'] and result['c_consumer']['partition_completed']
        assert sorted(result['execution']) == sorted(result['c_consumer']['execution']) == ['debug', 'release']
        assert digest(REPORT) == REPORT_SHA and package.source_inputs() == before
        assert package.compiler_identity(CHAIN) == tools
        for row in archives.values():
            path = Path(row['path'])
            assert digest(path) == row['sha256'] and path.stat().st_size == row['bytes']
        assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
        state.update(completed=True, source_inputs_unchanged=True, archives_unchanged=True,
                     candidate_archive_sha256=result['archive']['sha256'],
                     candidate_archive_identical_to_previous=result['archive']['sha256'] == previous['archive']['sha256'],
                     c_profiles=sorted(result['c_consumer']['execution']))
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with (BASE / 'DRIVER_RESULT.json').open('x') as stream:
            json.dump(state, stream, indent=2)
            stream.write('\n')
        print(json.dumps(state, indent=2), flush=True)


if __name__ == '__main__':
    main()
