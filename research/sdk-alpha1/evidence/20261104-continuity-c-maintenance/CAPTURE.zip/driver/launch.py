from pathlib import Path
from datetime import datetime, timezone
import contextlib
import hashlib
import json
import os
import time

from bounded_process import capture_output, TimeoutPolicy

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-c-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
argv = ['/bin/sh', 'artifact/python-run.sh', 'target/c-managed-qualification/run.py']
environment = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3')
state = {'completed': False, 'argv': argv, 'cwd': str(SOURCE),
         'started_utc': datetime.now(timezone.utc).isoformat(), 'timeout_seconds': 9000,
         'budget_origin': 'Existing ci.yml continuity-installed-rust full Rust/C gate: 150 minutes. This local execution is macOS arm64, not an Ubuntu or macOS foreign-wrapper CI pass.',
         'component_timeout_seconds': 900, 'component_stream_limit_bytes': 16 * 1024**2,
         'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
         'workflow_sha256': hashlib.sha256((SOURCE / '.github/workflows/ci.yml').read_bytes()).hexdigest(),
         'launch_driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (BASE / 'LAUNCH.json').open('x') as stream:
    json.dump(state, stream, indent=2)
    stream.write('\n')
started = time.monotonic()
try:
    with (BASE / 'driver.stdout').open('xb', buffering=0) as stdout, (BASE / 'driver.stderr').open('xb', buffering=0) as stderr:
        with contextlib.chdir(SOURCE):
            captured = capture_output(argv, timeout_seconds=9000, timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
                maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2,
                environment=environment, stdout_sink=stdout.write, stderr_sink=stderr.write)
    state['returncode'] = captured.returncode
    assert captured.returncode == 0, 'Installed Rust/C gate failed; preserve original per-command streams.'
    assert json.loads((BASE / 'DRIVER_RESULT.json').read_bytes())['completed']
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    for name in ['kind', 'cleanup_ambiguous', 'signal_number']:
        if hasattr(error, name): state[name] = getattr(error, name)
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    for suffix in ['stdout', 'stderr']:
        state[suffix + '_sha256'] = hashlib.sha256((BASE / ('driver.' + suffix)).read_bytes()).hexdigest()
    with (BASE / 'LAUNCH_RESULT.json').open('x') as stream:
        json.dump(state, stream, indent=2)
        stream.write('\n')
    print(json.dumps(state, indent=2), flush=True)
