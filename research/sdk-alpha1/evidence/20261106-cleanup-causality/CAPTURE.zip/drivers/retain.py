from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
root = Path.cwd()
stage = Path(__file__).resolve().parent
out = root / 'research/sdk-alpha1/evidence/20261106-cleanup-causality'
assert not out.exists()
parent = '932e6e5d5c84efcb2d42fb194cb748c446cde6db'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == parent
validation = stage / 'validation-01'
result = json.loads((validation / 'RESULT.json').read_text())
assert result['completed'] and result['source_inputs_unchanged']
assert result['parent_commit'] == parent and not result['release_claim_eligible']
assert len(result['commands']) == 14
assert all(row['completed'] and row['returncode'] == 0 for row in result['commands'])
def digest(data):
    return hashlib.sha256(data).hexdigest()
def head(name):
    return subprocess.check_output(['git', 'show', parent + ':' + name])
test = 'research/continuity-identity-candidate/src/durable/messages/tests/closure.rs'
inputs = json.loads((validation / 'INPUTS.json').read_text())
assert all(digest((root / name).read_bytes()) == value for name, value in inputs.items())
native_changes = subprocess.check_output(['git', 'diff', '--name-only', '--',
    'crates', 'research/continuity-identity-candidate', 'Cargo.lock']).decode().splitlines()
assert native_changes == [test]
files = {}
def add(name, data):
    assert name not in files
    files[name] = data
for path in sorted(validation.iterdir()):
    assert path.is_file()
    add('validation/' + path.name, path.read_bytes())
for name in ['validate.py', 'retain.py', 'validation.stdout', 'validation.stderr']:
    add('drivers/' + name, (stage / name).read_bytes())
add('patch/test.patch', subprocess.check_output(['git', 'diff', '--', test]))
sources = [test,
    'docs/continuity/CLEANUP_REKEY_CAUSALITY_V1.md',
    'docs/continuity/CLEANUP_REPORT_MAC_V1.md',
    'docs/continuity/KEM_CHALLENGE_ADAPTER_V1.md',
    'research/continuity-identity-candidate/src/durable.rs',
    'research/continuity-identity-candidate/src/durable/write_intent.rs',
    'research/continuity-identity-candidate/src/durable/write_intent/pending_recovery.rs',
    'research/continuity-identity-candidate/src/durable/retired_report.rs',
    'research/continuity-identity-candidate/src/durable/messages/retired.rs',
    'research/continuity-identity-candidate/src/durable/messages/closure.rs',
    'research/continuity-identity-candidate/src/durable/messages/fanout/abandonment.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-identity-candidate/src/enrollment/witness_pending_write_recovery_tests.rs',
    'research/continuity-recovery-symbolic/multi-epoch.spthy']
source_hashes = {}
for name in sources:
    data = (root / name).read_bytes()
    add('source/' + name, data)
    is_new = name == 'docs/continuity/CLEANUP_REKEY_CAUSALITY_V1.md'
    old = None if is_new else head(name)
    if old is not None and old != data:
        add('before/' + name, old)
    source_hashes[name] = {'before': None if old is None else digest(old), 'after': digest(data)}
    if '/src/' in name and name != test:
        assert old == data
model = 'research/continuity-recovery-symbolic/multi-epoch.spthy'
assert (root / model).read_bytes() == head(model)
binaries = {}
faults = 0
for profile in ['debug', 'release']:
    row = result['native_tests'][profile]
    binary = Path(row['binary'])
    data = binary.read_bytes()
    assert digest(data) == row['sha256'] and len(row['executions']) == 4
    binaries[profile] = {'path': str(binary), 'sha256_after_execution': digest(data), 'bytes': len(data)}
    markers = row['executions'][0]['markers']
    assert markers == [
        'CLOSURE_REKEY_RELEASE stage=0 closed_role=1 live_next_message_epoch=0',
        'CLOSURE_REKEY_RELEASE stage=1 closed_role=2 live_send_epoch=1 wire_bytes=137 peer_receive=Suspended',
        'CLOSURE_REKEY_RELEASE stage=2 closed_role=1 live_send_epoch=1 wire_bytes=136 peer_receive=Suspended']
    for marker in row['executions'][3]['markers']:
        match = re.fullmatch(r'SESSION_CLOSURE_SYNC finish=(false|true) barriers=4 faults=8', marker)
        assert match
        faults += 8
assert faults == 32
out.mkdir()
archive = out / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 6, 6, 52, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data)
manifest = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(files.items())}
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(files)
    assert set(z.namelist()) == set(files)
    assert all(digest(z.read(name)) == meta['sha256'] and len(z.read(name)) == meta['bytes']
        for name, meta in manifest.items())
checks = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(),
    'parent_commit': parent, 'native_source_inventory_entries': len(inputs),
    'native_source_inventory_still_matches': True, 'runtime_sources_unchanged': True,
    'native_tests_extended': 1, 'native_test_executions': 8, 'sync_fault_injections': faults,
    'rustfmt_and_strict_clippy_passed': True, 'full_library_test_suite_executed': False,
    'sources': source_hashes, 'native_executables': binaries,
    'archive': {'bytes': archive.stat().st_size, 'members': len(files), 'sha256': digest(archive.read_bytes())},
    'installed_package_qualification': False, 'physical_power_loss_test': False,
    'new_tamarin_execution': False, 'complete_computational_theorem': False,
    'raw_public_protocol_files_exported': False, 'native_binaries_included': False,
    'release_claim_eligible': False}
for name, value in [('FILES.json', manifest), ('CHECKS.json', checks), ('VALIDATION.json', result)]:
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': checks['archive'], 'source_inputs': len(inputs), 'native_executables': binaries}))
