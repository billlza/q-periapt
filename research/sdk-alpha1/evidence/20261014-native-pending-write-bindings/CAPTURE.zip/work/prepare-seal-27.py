from pathlib import Path
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
source = (stage / 'seal-26.py').read_text().replace('evidence/20261014-native-pending-write-recovery', 'evidence/20261014-native-pending-write-bindings')
source = source.replace("len(archive.filename) if False else (out / 'CAPTURE.zip').stat().st_size", "(out / 'CAPTURE.zip').stat().st_size")
with (stage / 'seal-27.py').open('x') as stream: stream.write(source)
sdk.write_json(stage / 'SEAL_26_REFUSAL.json', {'completed':False,
    'reason':'Evidence destination already belongs to an earlier accepted native-core checkpoint; exclusive creation correctly refused before any write',
    'existing_evidence_changed':False,'new_destination':'research/sdk-alpha1/evidence/20261014-native-pending-write-bindings'})
print('Selected a new binding-specific evidence destination; earlier evidence unchanged')
