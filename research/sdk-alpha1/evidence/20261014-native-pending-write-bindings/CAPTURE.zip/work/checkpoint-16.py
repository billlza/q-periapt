from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
path = stage / 'HANDOFF_CURRENT.json'
prior = json.loads(path.read_text())
sdk.write_json(stage / 'HANDOFF_BEFORE_16.json', prior)
prior.update({
    'installed_foreign_flows': {
        'C': {'run': 'flow-run-08.json', 'cases': 'c-flow-08', 'terminal_success': True, 'sealed': True},
        'Swift': {'run': 'swift-flow-run-10.json', 'package': 'SWIFT_INSTALLED_10.json', 'cases': 'swift-flow-10', 'terminal_success': True, 'sealed': True},
        'Kotlin': {'run': 'kotlin-flow-run-14.json', 'package': 'KOTLIN_INSTALLED_13.json', 'cases': 'kotlin-flow-14', 'terminal_success': True, 'sealed': True}},
    'verified_checks': {'Rust_1_90_installed_wrapper': 'native-msrv-check-15.json'},
    'live_sessions': {'apple_package_15': 19065},
    'device_prepared_only': 'prepare-device-16.py',
    'device_discovery': 'iPhone and iPad available; adb and mdns empty; prior Android address no route',
    'latest_failure_records': ['KOTLIN_ATTEMPT_11_FAILURE.json', 'continue-kotlin-12.py runtime scope refused checkout cache; finish-kotlin-13.py uses independent cache and strict verifier'],
    'swift_09_receipt': 'Original process handle unavailable and SWIFT_INSTALLED_09 absent; verify-swift-10 independently rechecks terminal build/link receipts plus every archive member. No assertion about original driver termination.',
    'toolchain_query_side_effect': 'rustup which --toolchain 1.90.0 cargo unexpectedly synced and downloaded six components into user rustup; terminal command returned existing toolchain path; no uninstall or default-toolchain change requested',
    'current_scope': 'Native bindings WIP; actual installed C/Swift/Kotlin original pending publication retirement with real expiry, independent approval and query-only retry. Android positive configured path and mobile positive recovery remain open. No new commit/push.'
})
path.write_text(json.dumps(prior, indent=2, sort_keys=True) + '\n')
print('Incremental handoff updated; all six completed recovery cohorts sealed')
