// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Fresh real-clock foreign confirmation of original publication retirement.
#[path = "/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qpc-pending-installed-tns3e3xi/c-consumer/packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs"]
mod fixture;
#[path = "/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qpc-pending-installed-tns3e3xi/c-consumer/tests/common/witness.rs"]
mod witness;
use q_periapt_continuity_identity_candidate as p;
use std::{fs, os::unix::fs::DirBuilderExt, path::Path, process::Command, time::{Duration, Instant}};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;

fn enrollment(path: &Path) -> Result<p::DeviceEnrollment> {
    let validity = fixture::array::<16>(path, "enrollment-validity")?;
    let from = u64::from_be_bytes(validity.get(..8).ok_or("validity start")?.try_into()?);
    let until = u64::from_be_bytes(validity.get(8..).ok_or("validity end")?.try_into()?);
    Ok(p::DeviceEnrollment::open(p::EnrollmentPaths::new(
        &path.join("wrap.key"), &path.join("signer.key"), &path.join("enrollment.redb"),
        p::InstallationPaths::new(&path.join("installation.redb"), &path.join("journal.redb"), &path.join("archives.redb"))?)?,
        p::EnrollmentIntent::new(p::PublicKey::decode(&fixture::read(path, "local-root", 8192)?)?,
            p::DeviceDescription::new(fixture::array(path, "local-device")?,
                u64::from_be_bytes(fixture::array(path, "local-generation")?), fixture::array(path, "family")?,
                p::Validity::new(from, until)?)?))?)
}
fn invoke(driver: &Path, mode: &str, path: &Path, endpoint: &str, input: &Path,
          evidence: &Path, label: &str, code: i32) -> Result<()> {
    let result = Command::new(driver).args([mode, path.to_str().ok_or("path UTF8")?, endpoint,
        input.to_str().ok_or("input UTF8")?]).output()?;
    fixture::store(evidence, &format!("{label}.stdout"), &result.stdout)?;
    fixture::store(evidence, &format!("{label}.stderr"), &result.stderr)?;
    assert!(result.stderr.is_empty(), "foreign diagnostics: {}", String::from_utf8_lossy(&result.stderr));
    assert_eq!(result.status.code(), Some(i32::from(code != 0)));
    assert_eq!(result.stdout, format!("code:{code}\nclose:0\n").as_bytes());
    Ok(())
}

#[test]
fn exact_pending_write_through_foreign_owner() -> Result<()> {
    let driver = std::path::PathBuf::from(std::env::var_os("QPC_PENDING_DRIVER").ok_or("foreign driver required")?);
    assert!(driver.is_absolute() && driver.is_file());
    let output = std::path::PathBuf::from(std::env::var_os("QPC_PENDING_EVIDENCE").ok_or("fresh evidence required")?);
    fs::DirBuilder::new().mode(0o700).create(&output)?;
    for applied in [false, true] {
        let evidence = output.join(if applied { "applied" } else { "unapplied" });
        fs::DirBuilder::new().mode(0o700).create(&evidence)?;
        let mut witness = witness::Witness::start()?;
        let setup = fixture::setup_expiring_policy(Some(&witness.configured), 90)?;
        let path = &setup.initiator;
        let mut peer = fixture::Peer::open_with_witness(path, Some(&witness.configured))?;
        let history = peer.context.original_policy().clone();
        let policy = peer.context.current_policy()?;
        let until = policy.validity().until();
        let validity = p::Validity::new(fixture::now()?, until)?;
        let kinds = [p::LeafKind::SignedClassical, p::LeafKind::OneTimeClassical,
                     p::LeafKind::LastResortPq, p::LeafKind::OneTimePq];
        let keys: Vec<_> = kinds.into_iter().map(|kind| p::PrekeyPublicationKey::generate(kind, validity)).collect();
        let plan = p::PrekeyPublicationPlan::new([83; 32], validity, &keys)?;
        let fixture::enrollment::DeviceOwner::Enrolled(active) = &mut peer.service else {
            return Err("original enrollment required".into());
        };
        let id = active.next_prekey_publication_id()?;
        let cancel = p::Cancellation::default();
        let prepared = active.prepare_prekey_publication(id, &plan, policy,
            p::PrekeyPublicationRun { cancel: &cancel, deadline: Instant::now() + Duration::from_secs(20) }, fixture::now)?;
        let artifact = prepared.artifact_digest();
        fixture::store(&evidence, "original-publication", id.as_bytes())?;
        fixture::store(&evidence, "original-artifact", prepared.as_bytes())?;
        assert_eq!(prepared.inventory_requests().len(), 4);
        witness.arm(if applied { 22 } else { 42 })?;
        let failure = active.retire_prekey_publication(id, artifact).expect_err("original reply withheld");
        assert!(matches!(failure, p::DurableError::Anchor(_)));
        peer.close(); drop(peer);
        let pin = witness.configured.store.lock().map_err(|_| "witness lock")?.pin()?;
        let expected = enrollment(path)?.pending_write_recovery_request(&history, &pin)?;
        // The independent fixture operator requested this precise retirement before
        // the fault. Other complete records must remain identical in both images.
        let ordinary = |view: &p::PendingWriteRecoveryView| view.records.iter()
            .filter(|r| !matches!(r.metadata, p::retired_device::RecordMetadata::PrekeyPublications { .. }))
            .cloned().collect::<Vec<_>>();
        assert_eq!(ordinary(expected.source()), ordinary(expected.target()));
        assert_eq!(expected.source().next_fanout_ordinal, expected.target().next_fanout_ordinal);
        let registry = |view: &p::PendingWriteRecoveryView| -> Result<_> {
            let rows: Vec<_> = view.records.iter().filter_map(|r| match &r.metadata {
                p::retired_device::RecordMetadata::PrekeyPublications { next_epoch, public_history } => Some((*next_epoch, public_history.clone())),
                _ => None,
            }).collect();
            let [row] = rows.as_slice() else { return Err("exact publication registry required".into()); };
            Ok(row.clone())
        };
        let a = registry(expected.source())?; let b = registry(expected.target())?;
        assert_eq!(a.0, b.0); assert_ne!(a.1, b.1);
        fixture::store(&evidence, "operator-expected-proposal", &expected.proposal().to_bytes())?;
        fixture::store(&evidence, "operator-expected-metadata", expected.metadata())?;
        let withheld = if applied {
            let captured = witness.captured.lock().map_err(|_| "captures")?;
            let row = captured.last().ok_or("original Advance missing")?;
            assert!(!row.delivered); row.request.clone()
        } else {
            let mut requests = witness.unprocessed.lock().map_err(|_| "withheld")?;
            assert_eq!(requests.len(), 1); requests.remove(0)
        };
        assert_eq!(withheld.get(204), Some(&2)); fixture::store(&evidence, "original-withheld-advance", &withheld)?;
        assert!(fixture::now()? < until);
        fixture::store(&evidence, "policy-until", &until.to_be_bytes())?;
        println!("waiting for real policy expiry: applied={applied}, until={until}");
        while fixture::now()? <= until { std::thread::sleep(Duration::from_millis(100)); }
        let endpoint = witness.configured.address.to_string();
        let request = evidence.join("request"); fs::DirBuilder::new().mode(0o700).create(&request)?;
        let requests_before = witness.captured.lock().map_err(|_| "captures")?.len();
        invoke(&driver, "request", path, &endpoint, &request, &evidence, "request", 0)?;
        assert_eq!(witness.captured.lock().map_err(|_| "captures")?.len(), requests_before);
        let approved = fixture::read(&request, "proposal", 393)?;
        let metadata = fixture::read(&request, "metadata", 8388608)?;
        let signed = fixture::read(&request, "signed", 8192)?;
        assert_eq!(approved, expected.proposal().to_bytes()); assert_eq!(metadata, expected.metadata());
        assert_eq!(fixture::array::<32>(&request, "binding")?, expected.proposal().binding());
        invoke(&driver, "copy-conflict", path, &endpoint, &request, &evidence, "copy-conflict", 107)?;
        if !applied { invoke(&driver, "confirm", path, &endpoint, &request, &evidence, "not-approved", 103)?; }
        // Approval is bound to the separately retained pre-expiry operator effect,
        // not derived merely from the old device's historical signature.
        let proposal = p::AnchorPendingWriteRecoveryProposal::from_trusted_state(&approved)?;
        assert_eq!(&proposal, expected.proposal());
        witness.configured.store.lock().map_err(|_| "controller")?
            .complete_pending_write_recovery(&proposal, &signed, &metadata, fixture::now()?)?;
        let before = witness.captured.lock().map_err(|_| "captures")?.len();
        for label in ["confirm", "retry"] { invoke(&driver, "confirm", path, &endpoint, &request, &evidence, label, 0)?; }
        let head = enrollment(path)?.confirm_pending_write_recovery(&proposal, &metadata, &history, pin.clone(),
            Box::new(p::AnchorTcpTransport::new(witness.configured.address)), Duration::from_secs(3))?;
        assert_eq!(head, proposal.target_head());
        let captured = witness.captured.lock().map_err(|_| "captures")?;
        assert_eq!(captured.len() - before, 3);
        assert!(captured.iter().skip(before).all(|r| r.request.get(204) == Some(&1) && r.delivered));
        drop(captured);
        assert!(matches!(enrollment(path)?.pending_write_recovery_request(&history, &pin), Err(p::DurableError::Absent)));
        witness.join()?;
        fixture::store(&evidence, "completed", b"exact-target;complete-metadata;query-only;original-owner\n")?;
        println!("foreign pending retirement passed: applied={applied}");
    }
    Ok(())
}
