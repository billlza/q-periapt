from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'FLOW_07.json').read_text()); harness = Path(cfg['harness'])
old = harness / 'src/lib.rs'
sdk.require(sdk.snapshot(old).sha256 == cfg['harness_source_sha256'], 'original failed fixture drift')
sdk.copy(old, stage / 'failed-build-fixture-07.rs')
consumer = Path(json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())['consumer'])
source = (stage / 'pending_fixture.rs').read_text().replace('@FIXTURE@',
    json.dumps(str(consumer / 'packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs')))
source = source.replace('@WITNESS@', json.dumps(str(consumer / 'tests/common/witness.rs')))
old.write_text(source); cfg['harness_source_sha256'] = sdk.snapshot(old).sha256
sdk.write_json(stage / 'FLOW_08.json', cfg)
driver = (stage / 'run-flow-07.py').read_text().replace('FLOW_07.json', 'FLOW_08.json').replace('-07', '-08')
(stage / 'run-flow-08.py').write_text(driver)
print('Fixture now verifies actual Applied/Current reply tags; no warning suppression')
