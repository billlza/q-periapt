from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'FOREIGN_FLOW_10.json').read_text()); install = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())
harness = Path(cfg['harness']); outside = Path(install['outside']); consumer = Path(install['consumer'])
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text()); cargo = str(Path(env['RUSTC']).parent / 'cargo')
target = outside / 'build'
metadata = json.loads(sdk.command([cargo, 'metadata', '--offline', '--format-version', '1'], stage / 'swift-flow-metadata-10', harness, environment=env))
selected = [row for row in metadata['packages'] if row['name'].startswith('q-periapt') and row['name'] != 'q-periapt-pending-foreign-harness']
sdk.require(len(selected) == 10, 'installed protocol dependency closure')
for row in selected:
    sdk.require(Path(row['manifest_path']).resolve() == consumer / 'packages' / (row['name'] + '-' + row['version']) / 'Cargo.toml'
                and row['source'] is None, 'fixture resolved outside installed archives')
sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--no-run', '--target-dir', str(target), '-j', '2'],
            stage / 'swift-flow-build-10', harness, environment=env)
evidence = stage / 'swift-flow-10'
runtime = dict(env, QPC_PENDING_DRIVER=cfg['client'], QPC_PENDING_EVIDENCE=str(evidence))
sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--target-dir', str(target), '-j', '2',
             'exact_pending_write_through_foreign_owner', '--', '--exact', '--nocapture'],
            stage / 'swift-flow-run-10', harness, environment=runtime)
for name in ['unapplied', 'applied']:
    sdk.require((evidence / name / 'completed').read_bytes() == b'exact-target;complete-metadata;query-only;original-owner\n', 'case incomplete')
sdk.require(sdk.snapshot(Path(cfg['library']), maximum=256*1024**2).sha256 == cfg['library_sha256'], 'library drift')
sdk.require(sdk.snapshot(harness / 'src/lib.rs').sha256 == cfg['harness_source_sha256'], 'fixture source drift')
print('Two fresh Swift installed-package original pending-write flows passed')
