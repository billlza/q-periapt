from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
inputs = json.loads((stage / 'INPUTS_01.json').read_text())
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
environment = json.loads((stage / 'ENVIRONMENT_01.json').read_text())
tool = Path(environment['RUSTC']).parent
consumer = stage / 'c-source-01'; target = stage / 'native-target'
cargo = str(tool / 'cargo')
sdk.command([cargo, 'metadata', '--offline', '--format-version', '1'], stage / 'native-metadata-02', consumer, environment=environment)
sdk.command([cargo, 'clippy', '--locked', '--offline', '--lib', '--target-dir', str(target), '-j', '2', '--', '-D', 'warnings'],
            stage / 'native-clippy-02', consumer, environment=environment)
sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--target-dir', str(target), '-j', '2',
             'enrollment::pending_recovery::tests', '--', '--test-threads=1'], stage / 'native-tests-02', consumer, environment=environment)
sdk.command([cargo, 'build', '--locked', '--offline', '--lib', '--target-dir', str(target), '-j', '2'],
            stage / 'native-library-02', consumer, environment=environment)
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
print('Strict source-linked C boundary and layout checks passed; library built')
