from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())
sdk.require(cfg['completed_build'], 'installed C build missing')
consumer = Path(cfg['consumer']); outside = Path(cfg['outside']); library = Path(cfg['library'])
java = json.loads((stage / 'JAVA_BUILD_02.json').read_text())
client = library.parent / 'pending-c-client'
sdk.command([java['clang'], '-isysroot', java['sdk'], '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic',
             str(stage / 'pending_client.c'), '-I' + str(consumer), '-L' + str(library.parent),
             '-lq_periapt_continuity_c_consumer', '-Wl,-rpath,@loader_path', '-o', str(client)],
            stage / 'pending-c-client-07', root)
harness = outside / 'pending-harness'; (harness / 'src').mkdir(parents=True)
manifest = (consumer / 'Cargo.toml').read_text()
manifest = manifest.replace('name = "q-periapt-continuity-c-consumer"', 'name = "q-periapt-pending-recovery-harness"')
manifest = manifest.replace('name = "q_periapt_continuity_c_consumer"', 'name = "qpc_pending_fixture"')
manifest = manifest.replace('crate-type = ["cdylib", "rlib"]\n', '')
manifest = re.sub(r'path = "(packages/[^\"]+)"', lambda match: 'path = ' + json.dumps(str(consumer / match[1])), manifest)
(harness / 'Cargo.toml').write_text(manifest)
sdk.copy(consumer / 'Cargo.lock', harness / 'Cargo.lock')
source = (stage / 'pending_fixture.rs').read_text()
source = source.replace('@FIXTURE@', json.dumps(str(consumer / 'packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs')))
source = source.replace('@WITNESS@', json.dumps(str(consumer / 'tests/common/witness.rs')))
(harness / 'src/lib.rs').write_text(source)
sdk.write_json(stage / 'FLOW_07.json', {'harness': str(harness), 'client': str(client), 'library': str(library),
    'library_sha256': cfg['library_sha256'], 'client_sha256': sdk.snapshot(client, maximum=64*1024**2).sha256,
    'harness_source_sha256': sdk.snapshot(harness / 'src/lib.rs').sha256,
    'scope': 'Real foreign pending publication retirement; actual installed core; same host/shared engine/signed TCP'})
print(json.dumps({'harness': str(harness), 'client': str(client)}))
