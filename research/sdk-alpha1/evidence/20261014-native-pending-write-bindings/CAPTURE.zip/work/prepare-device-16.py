from pathlib import Path
import json
import os
import secrets
import rust_sdk_profile as sdk
import continuity_apple_package as apple
from continuity_apple_consumer import verify_linkage

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text()); outside = Path(cfg['outside'])
package = json.loads((stage / 'apple-package-15/CONTINUITY_APPLE_PACKAGE.json').read_text())
sdk.require(package['completed'], 'Apple archive qualification not complete')
installed = outside / 'apple-package/installed'; consumer = installed / 'device-consumer-16'
for path in (root / 'bindings/swift/ContinuityBinaryConsumer').rglob('*'):
    if path.is_file(): sdk.copy(path, consumer / path.relative_to(root / 'bindings/swift/ContinuityBinaryConsumer'))
probe = consumer / 'Sources/Probe.swift'; old = probe.read_text()
sdk.require(old.count('do { try probe(); exit(0) }') == 1, 'probe entry drift')
old = old.replace('do { try probe(); exit(0) }', 'do { try probe(); try pendingDeviceBoundary(); exit(0) }')
# Keep the project's single-file source list. This is an isolated consumer, never
# an edit to the accepted binary package or an existing device cohort.
probe.write_text(old + '\n' + (stage / 'PendingDeviceBoundary.swift').read_text())
signing = json.loads((root / 'target/continuity-ios-device-preparation/SIGNING.json').read_text())
bundle = 'dev.qperiapt.PendingBoundary.r' + secrets.token_hex(12)
build = outside / 'pending-device-build-16'; link = outside / 'pending-device-$(TARGET_NAME)-LinkMap.txt'
env = {key: os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
result = sdk.command(['/usr/bin/xcodebuild', '-project', str(consumer / 'ContinuityBinaryConsumer.xcodeproj'),
    '-scheme', 'ContinuityBinaryConsumer', '-configuration', 'Release', '-sdk', 'iphoneos',
    '-destination', 'generic/platform=iOS', '-derivedDataPath', str(build), 'ARCHS=arm64',
    'CODE_SIGNING_ALLOWED=YES', 'CODE_SIGN_STYLE=Manual', 'CODE_SIGN_IDENTITY=' + signing['identity'],
    'PROVISIONING_PROFILE_SPECIFIER=' + signing['profile_uuid'], 'DEVELOPMENT_TEAM=' + signing['team'],
    'PRODUCT_BUNDLE_IDENTIFIER=' + bundle, 'LD_GENERATE_MAP_FILE=YES', 'LD_MAP_FILE_PATH=' + str(link), 'build'],
    stage / 'physical-consumer-build-16', consumer, environment=env)
sdk.require(b'** BUILD SUCCEEDED **' in result, 'physical consumer build missing')
for suffix in ['stdout','stderr']:
    import re
    sdk.require(not re.search(rb'(?im)(?:^|[^a-z])(warning|error):', (stage / ('physical-consumer-build-16.' + suffix)).read_bytes()), 'physical consumer diagnostics')
app = build / 'Build/Products/Release-iphoneos/ContinuityBinaryConsumer.app'
library = app.parent / apple.LIBRARY
sdk.require(sdk.snapshot(library, maximum=128*1024**2).sha256 == package['native']['aarch64-apple-ios']['sha256'], 'installed iOS slice differs')
linkage = verify_linkage(outside / 'pending-device-ContinuityBinaryConsumer-LinkMap.txt', library, app / 'ContinuityBinaryConsumer')
sdk.write_json(stage / 'PHYSICAL_APP_16.json', {'bundle': bundle, 'app': str(app), 'linkage': linkage,
    'executable_sha256': sdk.snapshot(app / 'ContinuityBinaryConsumer', maximum=128*1024**2).sha256,
    'source_sha256': sdk.snapshot(probe).sha256, 'archive_sha256': package['archive']['sha256'],
    'native_slice_sha256': package['native']['aarch64-apple-ios']['sha256'], 'completed_build': True,
    'scope': 'Packaged native ABI and cancelled-owner physical boundary probe; positive physical recovery remains separate'})
print('Fresh signed physical-device consumer built against exact installed Apple archive')
