from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_package as candidate
import continuity_c_consumer as c

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_06.json').read_text())
consumer = Path(cfg['consumer']); outside = Path(cfg['outside'])
for name, digest in cfg['source_files'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'binding source drift')
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text())
env['CARGO_TARGET_DIR'] = str(outside / 'build'); cargo = str(Path(env['RUSTC']).parent / 'cargo')
original = (consumer / 'Cargo.lock').read_bytes()
metadata = json.loads(sdk.command([cargo, 'metadata', '--offline', '--format-version', '1'],
                                 stage / 'installed-metadata-06', consumer, environment=env))
resolution = candidate.verify_resolution(metadata, consumer, (consumer / 'Cargo.lock').read_bytes(), original,
                                        consumer_name=c.NAME, required_features=c.FEATURES)
sdk.write_json(stage / 'INSTALLED_RESOLUTION_06.json', resolution)
sdk.command([cargo, 'rustc', '--locked', '--offline', '--lib', '--target-dir', str(outside / 'build'), '-j', '2', '--',
             '-C', 'link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib'],
            stage / 'installed-library-06', consumer, environment=env)
library = outside / 'build/debug/libq_periapt_continuity_c_consumer.dylib'
installed = outside / 'installed'; installed.mkdir(mode=0o700)
sdk.copy(library, installed / library.name, maximum=256 * 1024**2)
symbols = sdk.command(['/usr/bin/nm', '-gU', str(installed / library.name)], stage / 'installed-exports-06', root).decode()
names = {line.split()[-1].removeprefix('_') for line in symbols.splitlines() if line.strip()}
sdk.require(names == c.EXPORTS, 'installed exports differ')
cfg.update(library=str(installed / library.name), library_sha256=sdk.snapshot(library, maximum=256 * 1024**2).sha256,
           exports=len(names), completed_build=True)
sdk.write_json(stage / 'INSTALLED_BUILD_06.json', cfg)
for name, digest in cfg['source_files'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'binding source drift')
print(json.dumps({'built': True, 'exports': len(names), 'library': cfg['library'], 'scope': 'actual installed Cargo archives; lifecycle execution pending'}))
