from pathlib import Path
import datetime
import fnmatch
import hashlib
import json
import os
import plistlib
import secrets
import subprocess
import rust_sdk_profile as sdk
import continuity_apple_package as apple
from continuity_apple_consumer import verify_linkage

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text()); outside = Path(cfg['outside'])
package = json.loads((stage / 'apple-package-15/CONTINUITY_APPLE_PACKAGE.json').read_text())
sdk.require(package['completed'], 'Apple archive qualification not complete')
installed = outside / 'apple-package/installed'; consumer = installed / 'device-consumer-19'
for path in (installed / 'device-consumer-16').rglob('*'):
    if path.is_file(): sdk.copy(path, consumer / path.relative_to(installed / 'device-consumer-16'))
signing = json.loads((root / 'target/continuity-ios-device-preparation/SIGNING.json').read_text())
profile_bytes = sdk.snapshot(Path(signing['profile_path'])).data
profile_process = subprocess.run(['/usr/bin/security','cms','-D','-i',signing['profile_path']], capture_output=True, timeout=20, check=True)
profile = plistlib.loads(profile_process.stdout)
sdk.require(profile['UUID'] == signing['profile_uuid'] and profile['TeamIdentifier'] == [signing['team']], 'profile identity drift')
sdk.require(profile['ExpirationDate'].replace(tzinfo=datetime.timezone.utc) > datetime.datetime.now(datetime.timezone.utc), 'profile expired')
sdk.require(signing['identity'] in {hashlib.sha1(cert).hexdigest().upper() for cert in profile['DeveloperCertificates']}, 'signing certificate not in profile')
sdk.require({'<selected-private-device-or-signing-identifier>','<selected-private-device-or-signing-identifier>'} <= set(profile['ProvisionedDevices']), 'selected physical devices not provisioned')
bundle = 'dev.qperiapt.PendingBoundary.r' + secrets.token_hex(12)
application = signing['team'] + '.' + bundle
sdk.require(fnmatch.fnmatchcase(application, profile['Entitlements']['application-identifier']), 'new consumer outside profile scope')
build = outside / 'pending-device-build-19'; link = outside / 'pending-device19-$(TARGET_NAME)-LinkMap.txt'
env = {key: os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
result = sdk.command(['/usr/bin/xcodebuild', '-project', str(consumer / 'ContinuityBinaryConsumer.xcodeproj'),
    '-scheme', 'ContinuityBinaryConsumer', '-configuration', 'Release', '-sdk', 'iphoneos',
    '-destination', 'generic/platform=iOS', '-derivedDataPath', str(build), 'ARCHS=arm64',
    'CODE_SIGNING_ALLOWED=NO', 'PRODUCT_BUNDLE_IDENTIFIER=' + bundle,
    'LD_GENERATE_MAP_FILE=YES', 'LD_MAP_FILE_PATH=' + str(link), 'build'],
    stage / 'physical-consumer-build-19', consumer, environment=env)
sdk.require(b'** BUILD SUCCEEDED **' in result, 'physical consumer build missing')
for suffix in ['stdout','stderr']:
    import re
    sdk.require(not re.search(rb'(?im)(?:^|[^a-z])(warning|error):', (stage / ('physical-consumer-build-19.' + suffix)).read_bytes()), 'physical consumer diagnostics')
app = build / 'Build/Products/Release-iphoneos/ContinuityBinaryConsumer.app'; binary = app / 'ContinuityBinaryConsumer'
library = app.parent / apple.LIBRARY
sdk.require(sdk.snapshot(library, maximum=128*1024**2).sha256 == package['native']['aarch64-apple-ios']['sha256'], 'installed iOS slice differs')
linkage = verify_linkage(outside / 'pending-device19-ContinuityBinaryConsumer-LinkMap.txt', library, binary)
sdk.require(plistlib.loads((app / 'Info.plist').read_bytes())['CFBundleIdentifier'] == bundle, 'bundle differs')
entitlements = {'application-identifier': application, 'com.apple.developer.team-identifier': signing['team'],
    'get-task-allow': profile['Entitlements']['get-task-allow'], 'keychain-access-groups': [application]}
sdk.require(any(fnmatch.fnmatchcase(application, pattern) for pattern in profile['Entitlements']['keychain-access-groups']), 'keychain entitlement outside profile')
sign_file = outside / 'pending-device-entitlements-19.plist'
with sign_file.open('xb') as stream: stream.write(plistlib.dumps(entitlements))
with (app / 'embedded.mobileprovision').open('xb') as stream: stream.write(profile_bytes)
sdk.command(['/usr/bin/codesign','--force','--sign',signing['identity'],'--entitlements',str(sign_file),'--generate-entitlement-der',str(app)],
    stage / 'physical-consumer-sign-19', consumer, environment=env)
sdk.command(['/usr/bin/codesign','--verify','--strict','--deep',str(app)], stage / 'physical-consumer-verify-19', consumer, environment=env)
sdk.write_json(stage / 'PHYSICAL_APP_19.json', {'bundle': bundle, 'app': str(app), 'linkage': linkage,
    'executable_sha256': sdk.snapshot(binary, maximum=128*1024**2).sha256,
    'source_sha256': sdk.snapshot(consumer / 'Sources/Probe.swift').sha256, 'archive_sha256': package['archive']['sha256'],
    'native_slice_sha256': package['native']['aarch64-apple-ios']['sha256'], 'completed_build': True,
    'scope': 'Packaged native ABI and cancelled-owner physical boundary probe; positive physical recovery remains separate',
    'signing': 'Existing local development certificate and unexpired original profile; exact selected devices and bundle scope verified; no profile or account mutation'})
print('Fresh consumer built and signed offline against exact installed Apple archive')
