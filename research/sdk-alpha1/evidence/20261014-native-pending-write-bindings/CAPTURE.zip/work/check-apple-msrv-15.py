from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text()); outside = Path(cfg['outside'])
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text())
if sys.argv[1] == 'apple':
    import continuity_apple_package as apple
    output = stage / 'apple-package-15'; output.mkdir(mode=0o700)
    result = apple.qualify_apple(outside, output, env)
    sdk.require(result['completed'], 'Apple package not complete')
    print('Actual Apple XCFramework package and consumer builds passed; device runtime separate')
elif sys.argv[1] == 'msrv':
    tool = Path('/Users/bill/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin')
    sdk.require((tool / 'cargo').is_file() and (tool / 'rustc').is_file(), 'existing MSRV tools missing')
    env.update(RUSTC=str(tool / 'rustc'), RUSTDOC=str(tool / 'rustdoc'),
        PATH=str(tool) + ':' + env['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(tool.parent / 'lib'))
    sdk.command([str(tool / 'rustc'), '--version', '--verbose'], stage / 'native-msrv-version-15', outside, environment=env)
    sdk.command([str(tool / 'cargo'), 'check', '--locked', '--offline', '--lib', '--target-dir', str(outside / 'msrv-build-15'), '-j', '2'],
        stage / 'native-msrv-check-15', Path(cfg['consumer']), environment=env)
    print('Installed C binding and archived protocol core compile with Rust 1.90')
else:
    raise ValueError('unknown check')
