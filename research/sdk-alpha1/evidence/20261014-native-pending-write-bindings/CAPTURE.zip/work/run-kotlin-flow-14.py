from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'KOTLIN_FLOW_14.json').read_text()); install = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())
harness = Path(cfg['harness']); outside = Path(install['outside']); consumer = Path(install['consumer'])
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text()); cargo = str(Path(env['RUSTC']).parent / 'cargo')
target = outside / 'build'

package = json.loads((stage / 'KOTLIN_INSTALLED_13.json').read_text())
for item in package['runtime_resolution'].values():
    sdk.require(sdk.snapshot(Path(item['installed'])).sha256 == item['sha256'], 'installed Kotlin runtime drift')
for name, digest in package['files'].items():
    sdk.require(sdk.snapshot(Path(package['installed']) / name, maximum=256*1024**2).sha256 == digest, 'installed Kotlin package drift')
sdk.require(sdk.snapshot(Path(package['client'])).sha256 == package['client_sha256'], 'Kotlin launcher drift')
metadata = json.loads(sdk.command([cargo, 'metadata', '--offline', '--format-version', '1'], stage / 'kotlin-flow-metadata-14', harness, environment=env))
selected = [row for row in metadata['packages'] if row['name'].startswith('q-periapt') and row['name'] != 'q-periapt-pending-foreign-harness']
sdk.require(len(selected) == 10, 'installed protocol dependency closure')
for row in selected:
    sdk.require(Path(row['manifest_path']).resolve() == consumer / 'packages' / (row['name'] + '-' + row['version']) / 'Cargo.toml'
                and row['source'] is None, 'fixture resolved outside installed archives')
sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--no-run', '--target-dir', str(target), '-j', '2'],
            stage / 'kotlin-flow-build-14', harness, environment=env)
evidence = stage / 'kotlin-flow-14'
runtime = dict(env, QPC_PENDING_DRIVER=cfg['client'], QPC_PENDING_EVIDENCE=str(evidence))
sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--target-dir', str(target), '-j', '2',
             'exact_pending_write_through_foreign_owner', '--', '--exact', '--nocapture'],
            stage / 'kotlin-flow-run-14', harness, environment=runtime)
for name in ['unapplied', 'applied']:
    sdk.require((evidence / name / 'completed').read_bytes() == b'exact-target;complete-metadata;query-only;original-owner\n', 'case incomplete')
sdk.require(sdk.snapshot(Path(cfg['library']), maximum=256*1024**2).sha256 == cfg['library_sha256'], 'library drift')
sdk.require(sdk.snapshot(harness / 'src/lib.rs').sha256 == cfg['harness_source_sha256'], 'fixture source drift')
print('Two fresh Kotlin installed-package original pending-write flows passed')

package = json.loads((stage / 'KOTLIN_INSTALLED_13.json').read_text())
for item in package['runtime_resolution'].values():
    sdk.require(sdk.snapshot(Path(item['installed'])).sha256 == item['sha256'], 'installed Kotlin runtime drift')
for name, digest in package['files'].items():
    sdk.require(sdk.snapshot(Path(package['installed']) / name, maximum=256*1024**2).sha256 == digest, 'installed Kotlin package drift')
sdk.require(sdk.snapshot(Path(package['client'])).sha256 == package['client_sha256'], 'Kotlin launcher drift')
