from pathlib import Path
import json
import sys

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
label = sys.argv[1]; output = stage / ('physical-' + label + '-18')
launch = json.loads((output / 'launch-raw.json').read_text())['result']
details = json.loads((output / 'details-raw.json').read_text())['result']
print(json.dumps({'device': label, 'termination': launch['terminationResult'],
    'details_keys': sorted(details), 'console_tail': (output / 'launch.stdout').read_text().splitlines()[-4:]}))
