from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-native-pending-recovery'
fixture = root / 'bindings/c/ContinuityPackageConsumer'
new_module = 'bindings/c/ContinuityPackageConsumer/src/enrollment/pending_recovery.rs'
p = root / 'artifact/test_codeql_rust_quality.py'
source = p.read_text()
marker = '            "bindings/c/ContinuityPackageConsumer/src/enrollment/credential_request.rs",'
sdk.require(source.count(marker) == 2 and new_module not in source, 'source inventory controls')
p.write_text(source.replace(marker, marker + '\n            ' + json.dumps(new_module) + ','))
environment = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
environment.pop('CARGO_TARGET_DIR', None)
tool = Path(environment['RUSTC']).parent
rust = [fixture / 'src/enrollment.rs', fixture / 'src/witness.rs', root / new_module]
sdk.command([str(tool / 'rustfmt'), '--edition', '2021', '--config', 'skip_children=true', *map(str, rust)],
            stage / 'format-01', root, environment=environment)
changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
inputs = {name: sdk.snapshot(root / name).sha256 for name in sorted(changed)}
sdk.write_json(stage / 'INPUTS_01.json', inputs)
for name in inputs:
    sdk.copy(root / name, stage / 'source-01' / name)
consumer = stage / 'c-source-01'
consumer.mkdir()
for path in fixture.rglob('*'):
    sdk.require(not path.is_symlink(), 'C fixture source symlink')
    if path.is_file():
        sdk.copy(path, consumer / path.relative_to(fixture))
candidate = root / 'research/continuity-identity-candidate'
copied_candidate = consumer / 'packages/q-periapt-continuity-identity-candidate-0.0.0'
for path in candidate.rglob('*'):
    sdk.require(not path.is_symlink(), 'candidate source symlink')
    if path.is_file():
        sdk.copy(path, copied_candidate / path.relative_to(candidate))
patches = {name: str(root / 'crates' / name) for name in sdk.CONSUMER_CRATES}
patches['q-periapt-continuity-identity-candidate'] = str(copied_candidate)
with (consumer / 'Cargo.toml').open('a') as stream:
    stream.write('\n[patch.crates-io]\n')
    for name, path in patches.items():
        stream.write(name + ' = { path = ' + json.dumps(path) + ' }\n')
sdk.copy(candidate / 'Cargo.lock', consumer / 'Cargo.lock')
sdk.write_json(stage / 'ENVIRONMENT_01.json', environment)
sdk.write_json(stage / 'SCOPE_01.json', {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'consumer': str(consumer), 'patches': patches, 'scope': 'Isolated source-linked boundary/regression check; not installed package qualification'})
print(json.dumps({'source_paths': len(inputs), 'consumer': str(consumer), 'scope': 'source-linked checks'}))
