// SPDX-License-Identifier: Apache-2.0 OR MIT
import CQPCOwner

// This physical-device check exercises the packaged ABI boundary only. Positive
// recovery, independently approved effects and witness traffic are separate tests.
func pendingDeviceBoundary() throws {
    guard MemoryLayout<qpc_pending_write_request_info_v1>.size == 436,
          MemoryLayout<qpc_pending_write_request_info_v1>.alignment == 4,
          MemoryLayout<qpc_pending_write_request_info_v1>.offset(of: \.binding) == 404 else {
        throw ProbeFailure(message: "pending-write ABI layout differs")
    }
    var info = qpc_pending_write_request_info_v1(), error = qpc_error_v1()
    withUnsafeMutableBytes(of: &info) { $0.copyBytes(from: repeatElement(UInt8(37), count: $0.count)) }
    let before = withUnsafeBytes(of: &info) { Array($0) }
    guard qpc_enrollment_v1_pending_write_request(0, &info, &error) == 2,
          withUnsafeBytes(of: &info, { Array($0) }) == before else {
        throw ProbeFailure(message: "failed request published output")
    }
    let binding = [UInt8](repeating: 2, count: 32)
    var metadata: [UInt8] = [33], signed: [UInt8] = [34]
    let result = binding.withUnsafeBufferPointer { expected in
        metadata.withUnsafeMutableBufferPointer { document in
            signed.withUnsafeMutableBufferPointer { request in
                qpc_enrollment_v1_copy_pending_write_request(0, expected.baseAddress,
                    document.baseAddress, document.count, request.baseAddress, request.count, &error)
            }
        }
    }
    guard result == 2, metadata == [33], signed == [34],
          qpc_enrollment_v1_confirm_pending_write_recovery(0, nil, 0, nil, 0, &error) == 1 else {
        throw ProbeFailure(message: "pending-write invalid input or failed copy boundary")
    }
    print("QPC_PENDING_DEVICE_BOUNDARY_PASS exports=3 info_size=436 output_unchanged=true no_state=true")
}
