from pathlib import Path
import json
import os
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
for label in ['native-clippy-02', 'native-tests-02', 'native-library-02', 'java-main-02', 'java-tests-02', 'jni-syntax-02']:
    sdk.require(json.loads((stage / (label + '.json')).read_text())['returncode'] == 0, 'failed prerequisite')
changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
inputs = {name: sdk.snapshot(root / name).sha256 for name in sorted(changed)}
sdk.write_json(stage / 'INPUTS_03.json', inputs)
for name in inputs:
    sdk.copy(root / name, stage / 'source-03' / name)
copy = stage / 'foreign-source-03'
for relative in ['bindings/swift/ContinuityPackageConsumer', 'bindings/kotlin/ContinuityPackageConsumer']:
    for path in (root / relative).rglob('*'):
        sdk.require(not path.is_symlink(), 'foreign source symlink')
        if path.is_file():
            sdk.copy(path, copy / path.relative_to(root))
for name in ['Apache-2.0.txt', 'MIT.txt']:
    sdk.copy(root / 'LICENSES' / name, copy / 'LICENSES' / name)
library = stage / 'native-target/debug/libq_periapt_continuity_c_consumer.dylib'
runtime = stage / 'jni-runtime-03'; runtime.mkdir()
sdk.copy(library, runtime / library.name, maximum=256 * 1024**2)
env = {key: os.environ[key] for key in ['HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'USER', 'LOGNAME', 'PATH'] if key in os.environ}
kotlin = json.loads((root / 'target/continuity-kotlin-policy-credential/ENVIRONMENT.json').read_text())
env.update(JAVA_HOME=kotlin['JAVA_HOME'], GRADLE_USER_HOME=kotlin['GRADLE_USER_HOME'])
sdk.write_json(stage / 'FOREIGN_03.json', {'source': str(copy), 'library': str(library),
    'library_sha256': sdk.snapshot(library, maximum=256 * 1024**2).sha256, 'runtime': str(runtime), 'environment': env,
    'scope': 'Source-linked language and real JNI boundary checks; full installed lifecycle remains separate'})
print('Foreign source snapshots prepared; native library frozen')
