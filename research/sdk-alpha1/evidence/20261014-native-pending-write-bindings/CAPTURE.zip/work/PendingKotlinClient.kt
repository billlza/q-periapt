// SPDX-License-Identifier: Apache-2.0 OR MIT
package consumer

import dev.qperiapt.continuity.*
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.nio.file.attribute.PosixFilePermissions
import kotlin.system.exitProcess

private fun load(directory: Path, name: String, maximum: Int): ByteArray {
    val path = directory.resolve(name)
    require(Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) && Files.size(path) in 1..maximum.toLong())
    return Files.readAllBytes(path).also { require(it.size in 1..maximum) }
}
private fun counter(bytes: ByteArray): Counter64 {
    require(bytes.size == 8)
    return Counter64.parse(java.lang.Long.toUnsignedString(ByteBuffer.wrap(bytes).long))
}
private fun save(directory: Path, name: String, bytes: ByteArray) {
    FileChannel.open(directory.resolve(name), setOf(StandardOpenOption.WRITE, StandardOpenOption.CREATE_NEW),
        PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------"))).use { channel ->
        val buffer = ByteBuffer.wrap(bytes)
        while (buffer.hasRemaining()) check(channel.write(buffer) > 0)
        channel.force(true)
    }
}
fun main(args: Array<String>) {
    require(args.size == 4)
    val mode = args[0]; val path = Path.of(args[1]); val endpoint = args[2]; val directory = Path.of(args[3])
    var owner: ContinuityEnrollment? = null
    var code = 0; var closed = 0
    try {
        val validity = load(path, "enrollment-validity", 16)
        require(validity.size == 16)
        val intent = EnrollmentIntent(load(path, "local-root", 1985), load(path, "local-device", 16),
            counter(load(path, "local-generation", 8)), load(path, "family", 32),
            counter(validity.copyOfRange(0, 8)), counter(validity.copyOfRange(8, 16)))
        val opened = ContinuityEnrollment.prepareResume(path.toString(), intent, WitnessCarrier.SignedTCP(endpoint, 3000))
        owner = opened; opened.finishOpen()
        when (mode) {
            "request" -> {
                val value = opened.pendingWriteRecoveryRequest()
                for ((name, bytes) in listOf("proposal" to value.proposal, "binding" to value.binding,
                    "metadata" to value.metadata, "signed" to value.signedRequest)) save(directory, name, bytes.encoded())
                FileChannel.open(directory, StandardOpenOption.READ).use { it.force(true) }
            }
            "confirm", "confirm-damaged" -> {
                val proposal = load(directory, "proposal", 393); val metadata = load(directory, "metadata", 8388608)
                if (mode == "confirm-damaged") metadata[metadata.lastIndex] = (metadata.last().toInt() xor 1).toByte()
                opened.confirmPendingWriteRecovery(proposal, metadata)
            }
            else -> error("unknown mode")
        }
    } catch (failure: ContinuityFailure) {
        code = failure.code
    } catch (failure: Exception) {
        code = -1; System.err.println("foreign fixture failure: $failure")
    }
    try { owner?.close() }
    catch (failure: ContinuityFailure) { closed = failure.code }
    catch (failure: Exception) { closed = -1; System.err.println("foreign fixture close failure: $failure") }
    println("code:$code\nclose:$closed")
    exitProcess(if (code < 0 || closed != 0) 2 else if (code == 0) 0 else 1)
}
