from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
p = stage / 'c-source-01/packages/q-periapt-continuity-identity-candidate-0.0.0/Cargo.toml'
original = sdk.snapshot(p)
source, count = re.subn(r', path = "../../crates/q-periapt-[a-z-]+"', '', original.data.decode())
sdk.require(count == 7, 'copied source dependency paths')
p.write_text(source)
sdk.write_json(stage / 'SOURCE_LAYOUT_02.json', {
    'original_manifest_sha256': original.sha256, 'check_manifest_sha256': sdk.snapshot(p).sha256,
    'replaced_relative_paths': count,
    'reason': 'Copied source is outside its original relative workspace layout. Exact versions/features unchanged; parent source patches resolve the same SDK crates.',
    'scope': 'Source-linked checks only; not Cargo archive qualification',
})
driver = (stage / 'check-native-01.py').read_text()
for label in ['metadata', 'clippy', 'tests', 'library']:
    driver = driver.replace('native-' + label + '-01', 'native-' + label + '-02')
(stage / 'check-native-02.py').write_text(driver)
print('Isolated copied source paths corrected; product manifests unchanged')
