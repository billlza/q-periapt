from pathlib import Path
import json
import os
import sys
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'FOREIGN_03.json').read_text()); mode = sys.argv[1]
inputs = json.loads((stage / 'INPUTS_03.json').read_text())
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
library = Path(cfg['library']); source = Path(cfg['source']); env = cfg['environment']
sdk.require(sdk.snapshot(library, maximum=256 * 1024**2).sha256 == cfg['library_sha256'], 'library drift')
if mode == 'swift':
    import continuity_swift_consumer as gate
    package = source / 'bindings/swift/ContinuityPackageConsumer'
    sdk.command(['/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/swift',
                 'test', '--package-path', str(package), '--scratch-path', str(stage / 'swift-build-03'),
                 '-j', '2', '-Xswiftc', '-warnings-as-errors', '-Xcc', '-I' + str(root / 'bindings/c/ContinuityPackageConsumer'),
                 '-Xlinker', '-L' + str(library.parent), '-Xlinker', '-rpath', '-Xlinker', str(library.parent)],
                stage / 'swift-tests-03', root, environment=env)
    gate.verify_tests((stage / 'swift-tests-03.stdout').read_bytes(), (stage / 'swift-tests-03.stderr').read_bytes())
elif mode == 'kotlin':
    import continuity_kotlin_consumer as gate
    package = source / 'bindings/kotlin/ContinuityPackageConsumer'
    gradle = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/gradle-9.8.0/bin/gradle')
    sdk.command([str(gradle), '--offline', '--no-daemon', '--warning-mode', 'fail', '--dependency-verification', 'strict',
                 '--max-workers', '2', '-Dorg.gradle.java.installations.auto-download=false',
                 '-Pkotlin.compiler.execution.strategy=in-process', '-Dorg.gradle.java.home=' + env['JAVA_HOME'],
                 '--project-dir', str(package), 'test', '-Pqperiapt.continuity.lib=' + str(library)],
                stage / 'kotlin-tests-03', root, environment=env)
    sdk.write_json(stage / 'KOTLIN_TESTS_03.json', gate.verify_test_reports(package / 'build/test-results/test'))
elif mode == 'jni':
    java = json.loads((stage / 'JAVA_BUILD_02.json').read_text()); builder = Path(java['builder']); runtime = Path(cfg['runtime'])
    java_home = Path(java['java']); bridge = runtime / 'libqperiapt_continuity_jni.dylib'
    sdk.command([java['clang'], '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic', '-fvisibility=hidden',
                 '-isysroot', java['sdk'], '-I' + str(root / 'bindings/c/ContinuityPackageConsumer'),
                 '-I' + str(java_home / 'include'), '-I' + str(java_home / 'include/darwin'), '-dynamiclib',
                 *map(str, sorted((builder / 'jni').glob('*.c'))), '-L' + str(runtime), '-lq_periapt_continuity_c_consumer',
                 '-Wl,-rpath,@loader_path', '-o', str(bridge)], stage / 'jni-link-03', root, environment=env)
    sdk.require(sdk.snapshot(Path(java['jar'])).sha256 == java['jar_sha256'], 'Java archive drift')
    for name, expected in [('PendingWriteBridgeProbe', b'pending-write:bridge:passed\n'), ('BridgeProbe', b'configuration:bridge:passed\n')]:
        label = stage / ('jni-' + name + '-03')
        result = sdk.command([str(java_home / 'bin/java'), '--enable-native-access=ALL-UNNAMED', '-Xcheck:jni',
                             '-Djava.library.path=' + str(runtime), '-cp', java['jar'] + os.pathsep + java['tests'],
                             'dev.qperiapt.continuity.android.' + name], label, root, environment=env)
        sdk.require(result == expected and (Path(str(label) + '.stderr')).read_bytes() == b'', 'JNI diagnostics or missing result')
else:
    raise ValueError('unknown language check')
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
sdk.require(sdk.snapshot(library, maximum=256 * 1024**2).sha256 == cfg['library_sha256'], 'library drift')
print(mode + ' source-linked complete boundary checks passed')
