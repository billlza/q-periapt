from pathlib import Path
import hashlib
import json
import os
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_swift_consumer as swift
import third_party_licenses as licenses

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())
outside = Path(cfg['outside']); consumer = Path(cfg['consumer']); library = Path(cfg['library'])
sdk.require(sdk.snapshot(library, maximum=256*1024**2).sha256 == cfg['library_sha256'], 'library changed')
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text()); cargo = str(Path(env['RUSTC']).parent / 'cargo')
metadata = json.loads(sdk.command([cargo, 'metadata', '--locked', '--offline', '--format-version', '1',
                                  '--filter-platform', 'aarch64-apple-darwin'], stage / 'swift-license-metadata-09', consumer, environment=env))
notices = outside / 'swift-notices-09'; notices.mkdir(mode=0o700)
licenses.collect(consumer, notices, 'aarch64-apple-darwin', root_package=c.NAME, resolved_metadata=metadata)
source = root / 'bindings/swift/ContinuityPackageConsumer'
files = {path.relative_to(source).as_posix(): sdk.snapshot(path).data for path in source.rglob('*') if path.is_file()}
for name in ['LICENSE', 'LICENSE-APACHE', 'LICENSE-MIT']:
    files[name] = sdk.snapshot(root / 'research/continuity-identity-candidate' / name).data
files['native/include/qpc_owner.h'] = sdk.snapshot(consumer / 'qpc_owner.h').data
files['native/lib/' + library.name] = sdk.snapshot(library, maximum=256*1024**2).data
files['LICENSES/Rust-1.98.1-library.html'] = sdk.snapshot(root / 'LICENSES/Rust-1.98.1-library.html').data
for name in ['INVENTORY.sha256', 'LICENSE-INVENTORY.md', 'LICENSE.mlkem-native', 'PROVENANCE.md']:
    files['LICENSES/mlkem-native/' + name] = sdk.snapshot(root / 'crates/q-periapt-mlkem-native-sys/vendor' / name).data
for path in notices.rglob('*'):
    if path.is_file(): files[path.relative_to(notices).as_posix()] = sdk.snapshot(path).data
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
archive = stage / 'q-periapt-continuity-swift-pending-09.zip'
archive.write_bytes(swift.archive(files))
installed = outside / 'swift-installed-09'; swift.unpack(sdk.snapshot(archive, maximum=swift.MAX_PACKAGE).data, hashes, installed)
licenses.verify(installed, expected_target='aarch64-apple-darwin', root_package=c.NAME)
app = outside / 'swift-pending-client-09'; (app / 'Sources/PendingClient').mkdir(parents=True)
(app / 'Package.swift').write_text('''// swift-tools-version:6.0
import PackageDescription
let package = Package(name: "PendingClient", platforms: [.macOS(.v13)],
    dependencies: [.package(path: ''' + json.dumps(str(installed)) + ''')],
    targets: [.executableTarget(name: "PendingClient", dependencies: [.product(name: "QPeriaptContinuity", package: "swift-installed-09")])])
''')
sdk.copy(stage / 'PendingSwiftClient.swift', app / 'Sources/PendingClient/main.swift')
native = installed / 'native/lib'
runtime = {key: os.environ[key] for key in ['HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'USER', 'LOGNAME', 'PATH'] if key in os.environ}
sdk.command(['/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/swift',
             'build', '--package-path', str(app), '--scratch-path', str(app / 'build'), '-j', '2',
             '-Xswiftc', '-warnings-as-errors', '-Xcc', '-I' + str(installed / 'native/include'),
             '-Xlinker', '-L' + str(native), '-Xlinker', '-rpath', '-Xlinker', str(native)],
            stage / 'swift-consumer-build-09', app, environment=runtime)
binary = app / 'build/debug/PendingClient'
dependencies = sdk.command(['/usr/bin/otool', '-L', str(binary)], stage / 'swift-consumer-dependencies-09', app).decode()
loader = sdk.command(['/usr/bin/otool', '-l', str(binary)], stage / 'swift-consumer-loader-09', app).decode()
swift.verify_linkage(dependencies, loader, native)
for name, digest in hashes.items():
    sdk.require(sdk.snapshot(installed / name, maximum=256*1024**2).sha256 == digest, 'installed Swift bytes changed')
sdk.write_json(stage / 'SWIFT_INSTALLED_09.json', {'archive': str(archive), 'archive_sha256': sdk.snapshot(archive, maximum=swift.MAX_PACKAGE).sha256,
    'installed': str(installed), 'files': hashes, 'client': str(binary), 'client_sha256': sdk.snapshot(binary).sha256,
    'scope': 'Actual outside-checkout source Swift package, full native license closure and independent executable; flow pending'})
print('Actual installed Swift package and separate consumer built')
