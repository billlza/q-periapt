from pathlib import Path
import hashlib
import io
import json
import os
import shlex
import zipfile
import rust_sdk_profile as sdk
import continuity_kotlin_consumer as kotlin
import jvm_sdk_package as jvm
import third_party_licenses as licenses

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text()); outside = Path(cfg['outside'])
installed = outside / 'kotlin-installed-11'; archive = stage / 'q-periapt-continuity-kotlin-pending-11.zip'
blob = sdk.snapshot(archive, maximum=kotlin.MAX_PACKAGE)
with zipfile.ZipFile(io.BytesIO(blob.data)) as bundle:
    hashes = {name: hashlib.sha256(bundle.read(name)).hexdigest() for name in bundle.namelist()}
for name, digest in hashes.items():
    sdk.require(sdk.snapshot(installed / name, maximum=256*1024**2).sha256 == digest, 'installed package drift')
licenses.verify(installed, expected_target='aarch64-apple-darwin', root_package='q-periapt-continuity-c-consumer')
contract = kotlin.maven_contract(); identity = jvm.verify_maven(installed / 'maven', contract=contract)
sdk.require(json.loads((stage / 'kotlin-package-build-11.json').read_text())['returncode'] == 0, 'build failed')
tests = kotlin.verify_test_reports(outside / 'kotlin-builder-11/bindings/kotlin/ContinuityPackageConsumer/build/test-results/test')
original = json.loads((root / 'target/continuity-kotlin-policy-credential/ENVIRONMENT.json').read_text())
env = {key: os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
cache = outside / 'kotlin-cache-13'; cache.mkdir(mode=0o700)
sdk.command(['/bin/cp', '-cR', str(Path(original['GRADLE_USER_HOME']) / 'caches'), str(cache / 'caches')],
    stage / 'kotlin-cache-snapshot-13', outside, environment=env)
env.update(JAVA_HOME=original['JAVA_HOME'], GRADLE_USER_HOME=str(cache))
java = Path(env['JAVA_HOME']) / 'bin/java'
gradle = '/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/gradle-9.8.0/bin/gradle'
flags = [gradle, '--offline', '--no-daemon', '--warning-mode', 'fail', '--dependency-verification', 'strict',
    '--max-workers', '2', '-Dorg.gradle.java.installations.auto-download=false',
    '-Pkotlin.compiler.execution.strategy=in-process', '-Dorg.gradle.java.home=' + env['JAVA_HOME']]
app = outside / 'kotlin-pending-client-13'; (app / 'src/main/kotlin/consumer').mkdir(parents=True)
prior = outside / 'kotlin-pending-client-11'
for name in ['build.gradle.kts','settings.gradle.kts','src/main/kotlin/consumer/PendingKotlinClient.kt']:
    sdk.copy(prior / name, app / name)
jvm.pin_consumer_dependencies(app, installed / 'maven', contract=contract)
sdk.command([*flags, '--project-dir', str(app), 'installDist', 'recordRuntime',
    '-Pqperiapt.repository=' + str(installed / 'maven')], stage / 'kotlin-consumer-build-13', app, environment=env)
distribution = app / 'build/install/continuity-installed-consumer'
resolved = kotlin.runtime_closure(sdk.snapshot(app / 'build/runtime.tsv').data, distribution, identity['jar_sha256'], outside)
jars = {p.name: sdk.snapshot(p).sha256 for p in (distribution / 'lib').iterdir()}
classpath = os.pathsep.join(str(distribution / 'lib' / name) for name in sorted(jars))
argv = [str(java), '--enable-native-access=ALL-UNNAMED', '--illegal-native-access=deny',
    '-Dqperiapt.continuity.lib=' + str(installed / 'native/lib' / Path(cfg['library']).name), '-cp', classpath, 'consumer.PendingKotlinClientKt']
client = installed / 'pending-client-13'
with client.open('x') as stream: stream.write('#!/bin/sh\nexec ' + shlex.join(argv) + ' "$@"\n')
client.chmod(0o700)
sdk.write_json(stage / 'KOTLIN_INSTALLED_13.json', {'archive': str(archive), 'archive_sha256': blob.sha256,
    'installed': str(installed), 'files': hashes, 'client': str(client), 'client_sha256': sdk.snapshot(client).sha256,
    'runtime_jars': jars, 'runtime_resolution': resolved, 'maven': identity, 'tests': tests,
    'scope': 'Actual outside-checkout Maven package, dependencies and separate consumer; flow pending'})
print('Actual installed Kotlin Maven package and outside-checkout runtime closure verified')
