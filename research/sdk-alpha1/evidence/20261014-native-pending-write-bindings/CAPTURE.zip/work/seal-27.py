from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
source = json.loads((stage / 'SOURCE_COMMIT_25.json').read_text()); head = source['source_commit']
for checkout in [root,clone]:
    sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip() == head, 'source head drift')
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=checkout), 'source not clean')
for name,digest in source['files'].items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source changed')
checks = ['native-all-tests-04','native-all-clippy-04','swift-tests-03','kotlin-tests-03',
    'java-main-02','java-tests-02','jni-syntax-02','jni-PendingWriteBridgeProbe-03','jni-BridgeProbe-03',
    'flow-run-08','swift-flow-run-10','kotlin-flow-run-14','native-msrv-check-15','native-format-21','final-diff-21','source-gate-25']
for name in checks: sdk.require(json.loads((stage / (name + '.json')).read_text())['returncode'] == 0, 'failed required check: ' + name)
control = clone / 'target/native-pending-binding-checks'
sdk.require(json.loads((control / 'qualification-tests-06.json').read_text())['returncode'] == 0, 'inventory controls failed')
apple = json.loads((stage / 'apple-package-15/CONTINUITY_APPLE_PACKAGE.json').read_text())
physical = json.loads((stage / 'PHYSICAL_BOUNDARY_24.json').read_text())
sdk.require(apple['completed'] and physical['completed'], 'Apple package/device checks incomplete')
runs = []
for language,relative in [('C','c-flow-08'),('Swift','swift-flow-10'),('Kotlin','kotlin-flow-14')]:
    for name in ['unapplied','applied']:
        case = stage / relative / name
        sdk.require((case / 'completed').read_bytes() == b'exact-target;complete-metadata;query-only;original-owner\n', 'case incomplete')
        logs = sorted(case.glob('*.stdout'))
        sdk.require(len(logs) == (5 if name == 'unapplied' else 4), 'unexpected foreign invocation count')
        for log in logs: sdk.require(log.with_suffix('.stderr').read_bytes() == b'', 'foreign diagnostics')
        runs.append({'language':language,'case':name,'foreign_process_calls':len(logs),'completed':True,
            'original_proposal_sha256':sdk.snapshot(case / 'operator-expected-proposal').sha256,
            'original_metadata_sha256':sdk.snapshot(case / 'operator-expected-metadata').sha256})
sdk.require(sum(run['foreign_process_calls'] for run in runs) == 27, 'foreign call total')
packages = {name:json.loads((stage / path).read_text()) for name,path in
    [('Swift','SWIFT_INSTALLED_10.json'),('Kotlin','KOTLIN_INSTALLED_13.json')]}
for receipt in packages.values(): sdk.require(sdk.snapshot(Path(receipt['archive']),maximum=256*1024**2).sha256 == receipt['archive_sha256'], 'installed archive changed')
out = root / 'research/sdk-alpha1/evidence/20261014-native-pending-write-bindings'; out.mkdir()
qualification = {'source_commit':head,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_files':source['files'],'qualified_implementation_unchanged':True,
    'final_source_documentation_only_changes':source['additional_changes'],
    'runs':runs,'successful_recovery_cohorts':6,'foreign_process_calls':27,
    'required_terminal_checks':checks,'C_unit_tests':58,'Swift_unit_tests':77,'Kotlin_unit_tests':78,
    'package_inventory_tests':75,'tracked_Rust_sources':677,'C_exports':157,
    'installed_archives':{name:receipt['archive_sha256'] for name,receipt in packages.items()},
    'Apple_archive_sha256':apple['archive']['sha256'],'physical_boundary':physical,
    'scope':'Original pending publication retirement, actual installed C/Swift/Kotlin consumers, same engine and host, signed TCP, real-clock protocol policy expiry; iOS physical checks cover ABI rejection and owner cancellation only',
    'remaining':['Android positive recovery through public ContinuityConfiguration and ART',
        'positive mobile pending-write recovery and lifecycle composition',
        'new binding pending-write process/storage/cancellation fault matrix',
        'permanent installed-qualifier integration of this positive recovery workload',
        'CI and CodeQL for this source commit','independent engine/host qualification','PCS and full release admission'],
    'retained_failed_attempts':[
        'source-layout metadata failed before isolated installed-layout correction',
        'C flow-07 rejected an unread capture reply under warnings-as-errors; flow-08 explicitly asserts reply tags',
        'linked-worktree inventory check rejected main .git-file provenance; real-clone controls passed after exact new test-count fixture correction',
        'Kotlin driver-11 passed build/tests then rejected unsupported report profile; driver-12 rejected checkout dependency cache; driver-13 uses isolated cache and strict closure verifier',
        'Apple consumer-16 applied provisioning profile to Swift package library target; consumer-19 uses unsigned compile and separately verified offline app signing'],
    'Swift_09_driver_terminal_status':'not retained; verify-swift-10 independently checked every archive member plus successful build/link command receipts',
    'release_claim_eligible':False,'publication_performed':False,'pushed':False,
    'cohort_policy':'All successful and failed cohorts are sealed; use fresh identities, storage and outputs for future runs'}
sdk.write_json(out / 'QUALIFICATION.json',qualification)
entries = {}; redactions = ['<selected-private-device-or-signing-identifier>','<selected-private-device-or-signing-identifier>']
signing = json.loads((root / 'target/continuity-ios-device-preparation/SIGNING.json').read_text())
redactions += [signing['identity'],signing['profile_uuid']]
def add(path,name):
    sdk.require(name not in entries and not path.is_symlink(), 'ambiguous evidence member')
    data = sdk.snapshot(path,maximum=64*1024**2).data
    if path.suffix in {'.py','.json','.stdout','.stderr','.md','.txt'}:
        for value in redactions: data = data.replace(value.encode(),b'<selected-private-device-or-signing-identifier>')
    entries[name] = data
allowed = {'.py','.rs','.c','.h','.swift','.kt','.json','.stdout','.stderr'}
excluded = {'ipad-details-17.json','HANDOFF_CURRENT.json','HANDOFF_BEFORE_16.json'}
for path in sorted(stage.iterdir()):
    if path.is_file() and path.suffix in allowed and path.name not in excluded:
        add(path,'work/' + path.name)
for directory in ['source-06','documentation-21','kotlin-package-tests-12','apple-package-15/apple-package']:
    for path in sorted((stage / directory).rglob('*')):
        if path.is_file() and path.suffix in allowed | {'.md','.xml','.toml'}:
            add(path,'work/' + path.relative_to(stage).as_posix())
for path in control.iterdir():
    if path.is_file() and path.suffix in {'.json','.stdout','.stderr'}: add(path,'real-clone-controls/' + path.name)
for language,relative in [('C','c-flow-08'),('Swift','swift-flow-10'),('Kotlin','kotlin-flow-14')]:
    for path in sorted((stage / relative).rglob('*')):
        if path.is_file() and (path.suffix in {'.stdout','.stderr'} or path.name == 'completed'):
            add(path,'foreign/' + path.relative_to(stage).as_posix())
for label in ['ipad','iphone']:
    base = stage / ('physical-' + label + '-18')
    add(base / 'QUALIFIED.json','physical/' + label + '/QUALIFIED.json')
    # Preserve the actual terminal process result and test stdout without device
    # discovery/installation details, provisioning contents or hardware identifiers.
    terminal = json.loads((base / 'launch-raw.json').read_text())['result']['terminationResult']
    entries['physical/' + label + '/termination.json'] = (json.dumps(terminal,sort_keys=True) + '\n').encode()
    lines = (base / 'launch.stdout').read_text().splitlines()
    selected = [line for line in lines if line.startswith(('CONTINUITY_BINARY_CONSUMER_','QPC_PENDING_DEVICE_','The app terminated with the exit code'))]
    entries['physical/' + label + '/terminal.stdout'] = ('\n'.join(selected) + '\n').encode()
with zipfile.ZipFile(out / 'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
archive = sdk.snapshot(out / 'CAPTURE.zip',maximum=128*1024**2)
sdk.write_json(out / 'CAPTURE.json',{'source_commit':head,'archive_sha256':archive.sha256,'archive_bytes':archive.size,
    'members':len(entries),'files':{name:hashlib.sha256(value).hexdigest() for name,value in sorted(entries.items())},
    'excluded':'Private owners, databases, keys, raw device inventory, provisioning profile/certificates, package/compiler outputs and mutable handoff',
    'redacted':'Device UDIDs and existing development signing identifiers in retained scripts/command receipts; original local raw files are unchanged'})
with zipfile.ZipFile(out / 'CAPTURE.zip') as archive:
    sdk.require(archive.testzip() is None,'capture CRC failure')
    for name,data in entries.items(): sdk.require(archive.read(name) == data,'capture readback differs')
print(json.dumps({'evidence':str(out),'members':len(entries),'bytes':(out / 'CAPTURE.zip').stat().st_size}))
