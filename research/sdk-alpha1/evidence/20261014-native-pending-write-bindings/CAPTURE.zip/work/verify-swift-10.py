from pathlib import Path
import hashlib
import io
import json
import zipfile
import rust_sdk_profile as sdk
import continuity_swift_consumer as swift
import third_party_licenses as licenses

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text())
outside = Path(cfg['outside']); installed = outside / 'swift-installed-09'
archive = stage / 'q-periapt-continuity-swift-pending-09.zip'
blob = sdk.snapshot(archive, maximum=swift.MAX_PACKAGE)
with zipfile.ZipFile(io.BytesIO(blob.data)) as bundle:
    hashes = {name: hashlib.sha256(bundle.read(name)).hexdigest() for name in bundle.namelist()}
for name, digest in hashes.items():
    sdk.require(sdk.snapshot(installed / name, maximum=256*1024**2).sha256 == digest, 'installed archive drift: ' + name)
licenses.verify(installed, expected_target='aarch64-apple-darwin', root_package='q-periapt-continuity-c-consumer')
for name in ['build', 'dependencies', 'loader']:
    sdk.require(json.loads((stage / ('swift-consumer-' + name + '-09.json')).read_text())['returncode'] == 0, 'consumer command failed')
swift.verify_linkage((stage / 'swift-consumer-dependencies-09.stdout').read_text(),
                     (stage / 'swift-consumer-loader-09.stdout').read_text(), installed / 'native/lib')
binary = outside / 'swift-pending-client-09/build/debug/PendingClient'
sdk.write_json(stage / 'SWIFT_INSTALLED_10.json', {
    'archive': str(archive), 'archive_sha256': blob.sha256, 'installed': str(installed), 'files': hashes,
    'client': str(binary.resolve()), 'client_sha256': sdk.snapshot(binary.resolve()).sha256,
    'scope': 'Existing actual outside-checkout package read back and terminal build/link receipts verified; flow pending'})
print('Installed Swift archive and terminal build/link receipts verified')
