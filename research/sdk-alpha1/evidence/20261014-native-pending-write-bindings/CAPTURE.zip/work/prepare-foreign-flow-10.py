from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
old = json.loads((stage / 'FLOW_08.json').read_text())
client = json.loads((stage / 'SWIFT_INSTALLED_10.json').read_text())
prior = Path(old['harness']); harness = prior.parent / 'pending-foreign-harness-10'
sdk.require(sdk.snapshot(prior / 'src/lib.rs').sha256 == old['harness_source_sha256'], 'C fixture changed')
(harness / 'src').mkdir(parents=True)
manifest = (prior / 'Cargo.toml').read_text().replace('q-periapt-pending-recovery-harness', 'q-periapt-pending-foreign-harness')
(harness / 'Cargo.toml').write_text(manifest)
sdk.copy(prior / 'Cargo.lock', harness / 'Cargo.lock')
source = (prior / 'src/lib.rs').read_text()
old_case = 'invoke(&driver, "copy-conflict", path, &endpoint, &request, &evidence, "copy-conflict", 107)?;'
sdk.require(source.count(old_case) == 1, 'C-specific test drift')
source = source.replace(old_case, 'invoke(&driver, "confirm-damaged", path, &endpoint, &request, &evidence, "damaged-metadata", 102)?;\n        assert_eq!(witness.captured.lock().map_err(|_| "captures")?.len(), requests_before);')
(harness / 'src/lib.rs').write_text(source)
sdk.copy(harness / 'src/lib.rs', stage / 'pending-foreign-fixture-10.rs')
sdk.write_json(stage / 'FOREIGN_FLOW_10.json', dict(old, harness=str(harness), client=client['client'],
    client_sha256=client['client_sha256'], harness_source_sha256=sdk.snapshot(harness / 'src/lib.rs').sha256))
driver = (stage / 'run-flow-08.py').read_text().replace('FLOW_08.json', 'FOREIGN_FLOW_10.json')
driver = driver.replace('q-periapt-pending-recovery-harness', 'q-periapt-pending-foreign-harness')
driver = driver.replace('flow-', 'swift-flow-').replace('-08', '-10').replace('c-swift-flow', 'swift-flow')
driver = driver.replace('Two fresh C installed-library', 'Two fresh Swift installed-package')
(stage / 'run-swift-flow-10.py').write_text(driver)
print('Fresh Swift flow harness prepared; earlier C cohorts remain sealed')
