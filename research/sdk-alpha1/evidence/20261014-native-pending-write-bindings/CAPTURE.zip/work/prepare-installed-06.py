from pathlib import Path
import json
import subprocess
import tempfile
import rust_sdk_profile as sdk
import continuity_package as candidate

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
core = clone / 'target/native-pending-core-05'
records = json.loads((core / 'CORE_ARCHIVES.json').read_text())
sdk.require(records['completed'], 'core package producer incomplete')
base = 'e07c3ad22b0d10c2f0d1df9dc2e1bf48306a046b'
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == base
            and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'clone base differs')
paths = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
new = set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
paths.update(new)
inputs = {name: sdk.snapshot(root / name).sha256 for name in sorted(paths)}
for name in inputs:
    sdk.copy(root / name, stage / 'source-06' / name)
    target = clone / name; target.parent.mkdir(parents=True, exist_ok=True)
    original = subprocess.run(['git', 'show', 'HEAD:' + name], cwd=clone, capture_output=True)
    if original.returncode == 0:
        sdk.require(target.read_bytes() == original.stdout, 'clone preimage differs')
    else:
        sdk.require(not target.exists(), 'unexpected new clone source')
    target.write_bytes((root / name).read_bytes())
sdk.command(['git', 'add', '--', *inputs], stage / 'clone-overlay-06', clone)
sdk.write_json(stage / 'INPUTS_06.json', inputs)
outside = Path(tempfile.mkdtemp(prefix='qpc-pending-installed-')).resolve()
consumer = outside / 'c-consumer'
for path in (root / 'bindings/c/ContinuityPackageConsumer').rglob('*'):
    if path.is_file():
        sdk.copy(path, consumer / path.relative_to(root / 'bindings/c/ContinuityPackageConsumer'))
sdk.extract_recorded_crates(consumer, core, records['crates'])
record = records['candidate']; archive = sdk.snapshot(core / record['file'])
sdk.require(archive.sha256 == record['sha256'], 'candidate archive identity')
files = candidate.validate_candidate(archive.data, set(record['files']))
for name, data in files.items():
    path = consumer / 'packages/q-periapt-continuity-identity-candidate-0.0.0' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
with (consumer / 'Cargo.toml').open('a') as stream:
    stream.write('q-periapt-continuity-identity-candidate = { path = "packages/q-periapt-continuity-identity-candidate-0.0.0" }\n')
sdk.copy(root / 'research/continuity-identity-candidate/Cargo.lock', consumer / 'Cargo.lock')
sdk.write_json(stage / 'INSTALLED_06.json', {'outside': str(outside), 'consumer': str(consumer), 'core': str(core),
    'source_files': inputs, 'core_source_commit': records['source_commit'], 'candidate_sha256': record['sha256'],
    'scope': 'Fresh outside-checkout C consumer resolving ten actual Cargo archives; build/runtime results pending'})
print(json.dumps({'outside': str(outside), 'source_paths': len(inputs), 'candidate_sha256': record['sha256']}))
