/* SPDX-License-Identifier: Apache-2.0 OR MIT */
/* Isolated real-library consumer; all files belong to a fresh private fixture. */
#include "qpc_owner.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { uint8_t *data; size_t length; } blob;
static int path(char out[8192], const char *directory, const char *name) {
    int length = snprintf(out, 8192, "%s/%s", directory, name);
    return length > 0 && length < 8192;
}
static int load(const char *directory, const char *name, size_t maximum, blob *out) {
    char file[8192]; if (!path(file, directory, name)) return 0;
    int fd = open(file, O_RDONLY | O_NOFOLLOW); if (fd < 0) return 0;
    struct stat state; int result = 0;
    if (fstat(fd, &state) != 0 || !S_ISREG(state.st_mode) || state.st_size <= 0 || (uint64_t)state.st_size > maximum) goto done;
    out->length = (size_t)state.st_size; out->data = malloc(out->length);
    if (out->data == NULL) goto done;
    size_t offset = 0;
    while (offset < out->length) {
        ssize_t n = read(fd, out->data + offset, out->length - offset);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) goto done;
        offset += (size_t)n;
    }
    uint8_t extra; if (read(fd, &extra, 1) != 0) goto done;
    result = 1;
done:
    if (close(fd) != 0) result = 0;
    return result;
}
static int save(const char *directory, const char *name, const uint8_t *bytes, size_t length) {
    char file[8192]; if (!path(file, directory, name)) return 0;
    int fd = open(file, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600); if (fd < 0) return 0;
    size_t offset = 0; int result = 0;
    while (offset < length) {
        ssize_t n = write(fd, bytes + offset, length - offset);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) goto done;
        offset += (size_t)n;
    }
    if (fsync(fd) != 0) goto done;
#ifdef F_FULLFSYNC
    if (fcntl(fd, F_FULLFSYNC) != 0) goto done;
#endif
    result = 1;
done:
    if (close(fd) != 0) result = 0;
    return result;
}
static uint64_t integer(const uint8_t *bytes) {
    uint64_t value = 0; for (size_t i = 0; i < 8; ++i) value = (value << 8) | bytes[i]; return value;
}
int main(int argc, char **argv) {
    if (argc != 5) return 2;
    const char *mode = argv[1], *directory = argv[2], *endpoint = argv[3], *output = argv[4];
    blob roots = {0}, device = {0}, generation = {0}, family = {0}, validity = {0}, approved = {0}, metadata = {0};
    uint8_t *document = NULL, *signed_request = NULL; uint64_t handle = 0;
    int32_t code = -1, closed = 0; int result = 2;
    if (!load(directory, "local-root", 1985, &roots) || roots.length != 1985 ||
        !load(directory, "local-device", 16, &device) || device.length != 16 ||
        !load(directory, "local-generation", 8, &generation) || generation.length != 8 ||
        !load(directory, "family", 32, &family) || family.length != 32 ||
        !load(directory, "enrollment-validity", 16, &validity) || validity.length != 16) goto done;
    qpc_enrollment_intent_v1 intent = {0}; intent.root = roots.data; intent.root_length = roots.length;
    memcpy(intent.device, device.data, 16); memcpy(intent.family, family.data, 32);
    intent.generation = integer(generation.data); intent.valid_from = integer(validity.data); intent.valid_until = integer(validity.data + 8);
    qpc_witness_v1 witness = {(const uint8_t *)endpoint, strlen(endpoint), 3000};
    qpc_open_options_v1 options = {3, 0, 1, &witness}; qpc_error_v1 error = {0};
    code = qpc_enrollment_v1_prepare_resume((const uint8_t *)directory, strlen(directory), &intent, &options, &handle, &error);
    if (code != 0) goto reported;
    code = qpc_owner_v1_finish_open(handle, &error); if (code != 0) goto reported;
    if (strcmp(mode, "request") == 0 || strcmp(mode, "copy-conflict") == 0) {
        qpc_pending_write_request_info_v1 info = {0};
        code = qpc_enrollment_v1_pending_write_request(handle, &info, &error); if (code != 0) goto reported;
        if (info.metadata_length < 569 || info.metadata_length > 8388608 || info.signed_request_length == 0 ||
            info.signed_request_length > 8192 || info.reserved_zero[0] || info.reserved_zero[1] || info.reserved_zero[2]) goto done;
        document = malloc(info.metadata_length); signed_request = malloc(info.signed_request_length);
        if (document == NULL || signed_request == NULL) goto done;
        memset(document, 0xa7, info.metadata_length); memset(signed_request, 0xa7, info.signed_request_length);
        if (strcmp(mode, "copy-conflict") == 0) info.binding[0] ^= 1;
        code = qpc_enrollment_v1_copy_pending_write_request(handle, info.binding, document, info.metadata_length,
            signed_request, info.signed_request_length, &error);
        if (strcmp(mode, "copy-conflict") == 0) {
            for (size_t i = 0; i < info.metadata_length; ++i) if (document[i] != 0xa7) goto done;
            for (size_t i = 0; i < info.signed_request_length; ++i) if (signed_request[i] != 0xa7) goto done;
        } else if (code == 0) {
            if (!save(output, "proposal", info.proposal, 393) || !save(output, "binding", info.binding, 32) ||
                !save(output, "metadata", document, info.metadata_length) || !save(output, "signed", signed_request, info.signed_request_length)) goto done;
            int fd = open(output, O_RDONLY | O_DIRECTORY); if (fd < 0) goto done;
            int synced = fsync(fd); int ended = close(fd); if (synced != 0 || ended != 0) goto done;
        }
    } else if (strcmp(mode, "confirm") == 0) {
        if (!load(output, "proposal", 393, &approved) || approved.length != 393 || !load(output, "metadata", 8388608, &metadata)) goto done;
        code = qpc_enrollment_v1_confirm_pending_write_recovery(handle, approved.data, approved.length, metadata.data, metadata.length, &error);
    } else goto done;
reported:
    result = code == 0 ? 0 : 1;
done:
    if (handle != 0) { qpc_error_v1 error = {0}; closed = qpc_owner_v1_close(handle, &error); }
    free(roots.data); free(device.data); free(generation.data); free(family.data); free(validity.data);
    free(approved.data); free(metadata.data); free(document); free(signed_request);
    if (result == 2) fprintf(stderr, "fixture input/output failure\n");
    printf("code:%d\nclose:%d\n", code, closed);
    return closed == 0 ? result : 2;
}
