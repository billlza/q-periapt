from pathlib import Path
import json
import os
import subprocess
import sys
import rust_sdk_profile as sdk
import continuity_c_consumer as gate

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
consumer = stage / 'c-source-01'
relative = 'bindings/c/ContinuityPackageConsumer/src/enrollment/pending_recovery.rs'
old = json.loads((stage / 'INPUTS_03.json').read_text())
target = consumer / 'src/enrollment/pending_recovery.rs'
sdk.require(sdk.snapshot(target).sha256 == old[relative], 'source copy drift')
target.write_bytes((root / relative).read_bytes())
sdk.command(['git', 'add', '--', relative], stage / 'stage-module-04', root)
paths = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
paths.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
inputs = {name: sdk.snapshot(root / name).sha256 for name in sorted(paths)}
sdk.write_json(stage / 'INPUTS_04.json', inputs)
environment = json.loads((stage / 'ENVIRONMENT_01.json').read_text())
cargo = str(Path(environment['RUSTC']).parent / 'cargo'); build = stage / 'native-target'
sdk.command([cargo, 'clippy', '--locked', '--offline', '--lib', '--tests', '--target-dir', str(build), '-j', '2', '--', '-D', 'warnings'],
            stage / 'native-all-clippy-04', consumer, environment=environment)
authority = stage / 'native-authority-04'; authority.mkdir(mode=0o700)
result = sdk.command([cargo, 'test', '--locked', '--offline', '--lib', '--target-dir', str(build), '-j', '2'],
                     stage / 'native-all-tests-04', consumer, environment=dict(environment, QPC_AUTHORITY_FIXTURE=str(authority)))
gate.verify_admission(result)
sdk.command([sys.executable, '-B', 'artifact/python_bootstrap.py', '-m', 'unittest',
             'artifact.test_continuity_c_consumer', 'artifact.test_continuity_swift_consumer',
             'artifact.test_continuity_kotlin_consumer', 'artifact.test_codeql_rust_quality'],
            stage / 'qualification-tests-04', root)
symbols = sdk.command(['/usr/bin/nm', '-gU', str(build / 'debug/libq_periapt_continuity_c_consumer.dylib')],
                      stage / 'native-exports-04', root).decode()
names = {line.split()[-1].removeprefix('_') for line in symbols.splitlines() if line.strip()}
sdk.require(names == gate.EXPORTS, 'native exported set differs')
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
print(json.dumps({'native_admission_tests': 58, 'exports': len(names), 'scope': 'source-linked qualification controls'}))
