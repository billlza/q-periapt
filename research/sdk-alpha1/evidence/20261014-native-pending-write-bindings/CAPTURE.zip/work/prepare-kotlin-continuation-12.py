from pathlib import Path
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
source = (stage / 'package-kotlin-11.py').read_text()
start = source.index('for name, data in source.items():')
end = source.index('tests = kotlin.retain_test_reports(')
source = source[:start] + '''sdk.require(json.loads((stage / 'kotlin-package-build-11.json').read_text())['returncode'] == 0, 'package build failed')
for name, data in source.items():
    sdk.require(sdk.snapshot(builder / name).data == data, 'builder source drift')
report_dir = stage / 'kotlin-package-tests-12'; report_dir.mkdir()
''' + source[end:]
source = source.replace("stage, profile='pending-11'", "report_dir, profile='debug'")
source = source.replace("'KOTLIN_INSTALLED_11.json'", "'KOTLIN_INSTALLED_12.json'")
source = source.replace("'kotlin-consumer-build-11'", "'kotlin-consumer-build-12'")
with (stage / 'continue-kotlin-12.py').open('x') as stream: stream.write(source)
sdk.write_json(stage / 'KOTLIN_ATTEMPT_11_FAILURE.json', {'completed': False,
    'reason': 'Packaging driver supplied unsupported pending-11 report profile after successful tests and Maven build',
    'source': 'package-kotlin-11.py', 'continuation': 'continue-kotlin-12.py',
    'effect': 'No installed package or positive flow was claimed; retain the same completed test run under supported debug label in a fresh report directory'})
print('Resume from successful terminal build; exact source rechecked and new report directory selected')
