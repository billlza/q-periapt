from pathlib import Path
import hashlib
import json
import os
import shlex
import rust_sdk_profile as sdk
import continuity_kotlin_consumer as kotlin
import jvm_sdk_package as jvm
import third_party_licenses as licenses

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
cfg = json.loads((stage / 'INSTALLED_BUILD_06.json').read_text()); outside = Path(cfg['outside'])
library = Path(cfg['library']); sdk.require(sdk.snapshot(library, maximum=256*1024**2).sha256 == cfg['library_sha256'], 'native drift')
environment = json.loads((root / 'target/continuity-kotlin-policy-credential/ENVIRONMENT.json').read_text())
env = {key: os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
env.update(JAVA_HOME=environment['JAVA_HOME'], GRADLE_USER_HOME=environment['GRADLE_USER_HOME'])
java = Path(env['JAVA_HOME']) / 'bin/java'
gradle = '/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/gradle-9.8.0/bin/gradle'
flags = [gradle, '--offline', '--no-daemon', '--warning-mode', 'fail', '--dependency-verification', 'strict',
    '--max-workers', '2', '-Dorg.gradle.java.installations.auto-download=false',
    '-Pkotlin.compiler.execution.strategy=in-process', '-Dorg.gradle.java.home=' + env['JAVA_HOME']]
source = kotlin.source_files(); builder_root = outside / 'kotlin-builder-11'
builder = builder_root / 'bindings/kotlin/ContinuityPackageConsumer'
sdk.require(json.loads((stage / 'kotlin-package-build-11.json').read_text())['returncode'] == 0, 'package build failed')
for name, data in source.items():
    sdk.require(sdk.snapshot(builder / name).data == data, 'builder source drift')
report_dir = stage / 'kotlin-package-tests-12'; report_dir.mkdir()
tests = kotlin.retain_test_reports(builder / 'build/test-results/test', report_dir, profile='debug')
contract = kotlin.maven_contract(); maven = outside / 'kotlin-maven-11'
for path in (builder / 'build/candidate-maven' / contract.path).iterdir(): sdk.copy(path, maven / contract.path / path.name)
identity = jvm.verify_maven(maven, contract=contract)
files = {'maven/' + p.relative_to(maven).as_posix(): sdk.snapshot(p).data for p in maven.rglob('*') if p.is_file()}
notices = outside / 'swift-notices-09'
files.update({p.relative_to(notices).as_posix(): sdk.snapshot(p).data for p in notices.rglob('*') if p.is_file()})
files['README.md'] = source['README.md']
files['native/lib/' + library.name] = sdk.snapshot(library, maximum=256*1024**2).data
files['native/include/qpc_owner.h'] = sdk.snapshot(Path(cfg['consumer']) / 'qpc_owner.h').data
files['LICENSES/Rust-1.98.1-library.html'] = sdk.snapshot(root / 'LICENSES/Rust-1.98.1-library.html').data
for name in ['INVENTORY.sha256','LICENSE-INVENTORY.md','LICENSE.mlkem-native','PROVENANCE.md']:
    files['LICENSES/mlkem-native/' + name] = sdk.snapshot(root / 'crates/q-periapt-mlkem-native-sys/vendor' / name).data
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
archive = stage / 'q-periapt-continuity-kotlin-pending-11.zip'
with archive.open('xb') as stream: stream.write(kotlin.archive(files))
installed = outside / 'kotlin-installed-11'
kotlin.unpack(sdk.snapshot(archive, maximum=kotlin.MAX_PACKAGE).data, hashes, installed)
licenses.verify(installed, expected_target='aarch64-apple-darwin', root_package='q-periapt-continuity-c-consumer')
sdk.require(jvm.verify_maven(installed / 'maven', contract=contract) == identity, 'installed Maven identity differs')
app = outside / 'kotlin-pending-client-11'; (app / 'src/main/kotlin/consumer').mkdir(parents=True)
(app / 'build.gradle.kts').write_bytes(source['consumer/build.gradle.kts'].replace(b'consumer.ContinuityClientKt', b'consumer.PendingKotlinClientKt'))
(app / 'settings.gradle.kts').write_bytes(source['consumer/settings.gradle.kts'])
sdk.copy(stage / 'PendingKotlinClient.kt', app / 'src/main/kotlin/consumer/PendingKotlinClient.kt')
jvm.pin_consumer_dependencies(app, installed / 'maven', contract=contract)
sdk.command([*flags, '--project-dir', str(app), 'installDist', 'recordRuntime',
    '-Pqperiapt.repository=' + str(installed / 'maven')], stage / 'kotlin-consumer-build-12', app, environment=env)
distribution = app / 'build/install/continuity-installed-consumer'
expected = {contract.coordinate, 'org.jetbrains.kotlin:kotlin-stdlib:2.4.20', 'org.jetbrains:annotations:13.0'}
resolved = {}
for line in (app / 'build/runtime.tsv').read_text().splitlines():
    coordinate, filename, digest = line.split('\t'); path = Path(filename)
    sdk.require(coordinate in expected and coordinate not in resolved and path.resolve() == path and not path.is_relative_to(root), 'runtime resolution scope')
    sdk.require(sdk.snapshot(path).sha256 == digest == sdk.snapshot(distribution / 'lib' / path.name).sha256, 'runtime dependency drift')
    resolved[coordinate] = {'resolved': str(path), 'sha256': digest}
sdk.require(set(resolved) == expected and resolved[contract.coordinate]['sha256'] == identity['jar_sha256'], 'runtime closure differs')
jars = {p.name: sdk.snapshot(p).sha256 for p in (distribution / 'lib').iterdir()}
sdk.require(set(jars) == {Path(r['resolved']).name for r in resolved.values()} | {'continuity-installed-consumer.jar'}, 'extra runtime artifact')
classpath = os.pathsep.join(str(distribution / 'lib' / name) for name in sorted(jars))
argv = [str(java), '--enable-native-access=ALL-UNNAMED', '--illegal-native-access=deny',
    '-Dqperiapt.continuity.lib=' + str(installed / 'native/lib' / library.name), '-cp', classpath, 'consumer.PendingKotlinClientKt']
client = installed / 'pending-client'
with client.open('x') as stream: stream.write('#!/bin/sh\nexec ' + shlex.join(argv) + ' "$@"\n')
client.chmod(0o700)
sdk.write_json(stage / 'KOTLIN_INSTALLED_12.json', {'archive': str(archive), 'archive_sha256': sdk.snapshot(archive, maximum=kotlin.MAX_PACKAGE).sha256,
    'installed': str(installed), 'files': hashes, 'client': str(client), 'client_sha256': sdk.snapshot(client).sha256,
    'runtime_jars': jars, 'runtime_resolution': resolved, 'maven': identity, 'tests': tests,
    'scope': 'Actual outside-checkout Maven package and separate consumer; strict pinned cached external dependencies; flow pending'})
print('Actual installed Kotlin Maven package and separate consumer built')
