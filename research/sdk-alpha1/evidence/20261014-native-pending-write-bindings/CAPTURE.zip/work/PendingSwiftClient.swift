// SPDX-License-Identifier: Apache-2.0 OR MIT
import QPeriaptContinuity
import Foundation
import Darwin

enum FixtureFailure: Error { case input, io }
func load(_ directory: String, _ name: String, _ maximum: Int) throws -> [UInt8] {
    let bytes = [UInt8](try Data(contentsOf: URL(fileURLWithPath: directory).appendingPathComponent(name)))
    guard !bytes.isEmpty, bytes.count <= maximum else { throw FixtureFailure.input }
    return bytes
}
func counter(_ bytes: [UInt8]) throws -> UInt64 {
    guard bytes.count == 8 else { throw FixtureFailure.input }
    return bytes.reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
}
func save(_ directory: String, _ name: String, _ bytes: [UInt8]) throws {
    let path = URL(fileURLWithPath: directory).appendingPathComponent(name).path
    let fd = Darwin.open(path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, mode_t(0o600))
    guard fd >= 0 else { throw FixtureFailure.io }
    let written = bytes.withUnsafeBytes { buffer -> Bool in
        guard let start = buffer.baseAddress else { return false }
        var offset = 0
        while offset < buffer.count {
            let count = Darwin.write(fd, start.advanced(by: offset), buffer.count - offset)
            if count < 0 && errno == EINTR { continue }
            if count <= 0 { return false }
            offset += count
        }
        return true
    }
    let synced = fsync(fd), full = fcntl(fd, F_FULLFSYNC), closed = Darwin.close(fd)
    guard written, synced == 0, full == 0, closed == 0 else { throw FixtureFailure.io }
}
guard CommandLine.arguments.count == 5 else { Darwin.exit(2) }
let mode = CommandLine.arguments[1], path = CommandLine.arguments[2]
let endpoint = CommandLine.arguments[3], directory = CommandLine.arguments[4]
var owner: ContinuityEnrollment?
var code: Int32 = 0, closed: Int32 = 0
do {
    let validity = try load(path, "enrollment-validity", 16)
    guard validity.count == 16 else { throw FixtureFailure.input }
    let intent = try EnrollmentIntent(root: load(path, "local-root", 1985), device: load(path, "local-device", 16),
        generation: counter(load(path, "local-generation", 8)), family: load(path, "family", 32),
        validFrom: counter(Array(validity.prefix(8))), validUntil: counter(Array(validity.suffix(8))))
    let opened = try ContinuityEnrollment.prepareResume(path: path, intent: intent,
        witness: .signedTCP(address: endpoint, timeoutMilliseconds: 3000))
    owner = opened; try opened.finishOpen()
    switch mode {
    case "request":
        let value = try opened.pendingWriteRecoveryRequest()
        for (name, bytes) in [("proposal", value.proposal), ("binding", value.binding),
                              ("metadata", value.metadata), ("signed", value.signedRequest)] {
            try save(directory, name, bytes)
        }
        let fd = Darwin.open(directory, O_RDONLY | O_DIRECTORY)
        guard fd >= 0 else { throw FixtureFailure.io }
        let synced = fsync(fd), ended = Darwin.close(fd)
        guard synced == 0, ended == 0 else { throw FixtureFailure.io }
    case "confirm", "confirm-damaged":
        let proposal = try load(directory, "proposal", 393)
        var metadata = try load(directory, "metadata", 8388608)
        if mode == "confirm-damaged" { metadata[metadata.count - 1] ^= 1 }
        try opened.confirmPendingWriteRecovery(approved: proposal, recordedMetadata: metadata)
    default: throw FixtureFailure.input
    }
} catch let failure as ContinuityFailure {
    code = failure.code
} catch {
    code = -1
    FileHandle.standardError.write(Data("foreign fixture input/output failure: \(error)\n".utf8))
}
if let owner {
    do { try owner.close() }
    catch let failure as ContinuityFailure { closed = failure.code }
    catch { closed = -1; FileHandle.standardError.write(Data("foreign fixture close failure\n".utf8)) }
}
print("code:\(code)\nclose:\(closed)")
Darwin.exit(closed != 0 || code < 0 ? 2 : code == 0 ? 0 : 1)
