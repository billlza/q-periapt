from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
app = json.loads((stage / 'PHYSICAL_APP_19.json').read_text()); devices = {}
for label in ['ipad','iphone']:
    output = stage / ('physical-' + label + '-18')
    observation = json.loads((output / 'OBSERVATION.json').read_text())
    result = json.loads((output / 'launch-raw.json').read_text())['result']
    detail = json.loads((output / 'details-raw.json').read_text())['result']
    sdk.require(result['terminationResult'] == {'exitCode': 0, 'wasCoreDumpCreated': False}, 'physical process did not exit successfully')
    for command in ['details','install','launch']:
        receipt = json.loads((output / (command + '.json')).read_text())
        sdk.require(receipt['returncode'] == 0, 'physical command failed')
    sdk.require(observation['markers_present'] and observation['app_sha256'] == app['executable_sha256'], 'test app identity differs')
    hardware = {k:v for k,v in detail['hardwareProperties'].items() if k in ['deviceType','productType','marketingName','reality','cpuType']}
    software = {k:v for k,v in detail['deviceProperties'].items() if k in ['osVersionNumber','osBuildUpdate','developerModeStatus','bootState']}
    sdk.require(hardware.get('reality') == 'physical' and hardware.get('deviceType') == ('iPad' if label == 'ipad' else 'iPhone'), 'physical hardware differs')
    sdk.require('osVersionNumber' in software and 'productType' in hardware, 'physical platform identity missing')
    devices[label] = {'completed': True, 'hardware': hardware, 'software': software,
        'transport': detail['connectionProperties']['transportType'], 'exit_code': 0,
        'app_sha256': app['executable_sha256'], 'archive_sha256': app['archive_sha256'],
        'launch_receipt_sha256': sdk.snapshot(output / 'launch-raw.json').sha256,
        'scope': app['scope']}
    sdk.write_json(output / 'QUALIFIED.json', devices[label])
sdk.write_json(stage / 'PHYSICAL_BOUNDARY_24.json', {'completed': True, 'devices': devices,
    'positive_physical_pending_write_recovery': False, 'fresh_application': True,
    'existing_device_storage_opened': False, 'release_claim_eligible': False})
print(json.dumps({'completed': True, 'devices': {k:{'model':v['hardware']['productType'],'os':v['software']['osVersionNumber'],'exit':v['exit_code']} for k,v in devices.items()}}))
