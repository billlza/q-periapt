from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
original = json.loads((stage / 'INPUTS_06.json').read_text())
changed = set(subprocess.check_output(['git','diff','HEAD','--name-only'], text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'], text=True).splitlines())
docs = {f'bindings/{language}/ContinuityPackageConsumer/README.md' for language in ['c','swift','kotlin','android']}
sdk.require(changed == set(original) | docs, 'unexpected increment source changes')
for name, digest in original.items(): sdk.require(sdk.snapshot(root / name).sha256 == digest, 'qualified implementation changed: ' + name)
current = {name: sdk.snapshot(root / name).sha256 for name in sorted(changed)}
sdk.write_json(stage / 'INPUTS_21.json', current)
for name in docs: sdk.copy(root / name, stage / 'documentation-21' / name)
env = json.loads((stage / 'ENVIRONMENT_01.json').read_text()); tool = Path(env['RUSTC']).parent
sdk.command([str(tool / 'rustfmt'), '--check', '--edition', '2021',
    'bindings/c/ContinuityPackageConsumer/src/enrollment/pending_recovery.rs'], stage / 'native-format-21', root, environment=env)
sdk.command(['git','diff','--check'], stage / 'final-diff-21', root)
print('All 29 qualified implementation inputs unchanged; four documentation additions and format verified')
