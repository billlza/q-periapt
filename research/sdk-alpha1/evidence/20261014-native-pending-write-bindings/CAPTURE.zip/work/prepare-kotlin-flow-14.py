from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-native-pending-recovery'
flow = json.loads((stage / 'FOREIGN_FLOW_10.json').read_text())
client = json.loads((stage / 'KOTLIN_INSTALLED_13.json').read_text())
flow.update(client=client['client'], client_sha256=client['client_sha256'])
sdk.write_json(stage / 'KOTLIN_FLOW_14.json', flow)
source = (stage / 'run-swift-flow-10.py').read_text().replace('FOREIGN_FLOW_10.json', 'KOTLIN_FLOW_14.json')
source = source.replace('swift-flow-', 'kotlin-flow-').replace('-10', '-14').replace('Two fresh Swift', 'Two fresh Kotlin')
guard = '''
package = json.loads((stage / 'KOTLIN_INSTALLED_13.json').read_text())
for item in package['runtime_resolution'].values():
    sdk.require(sdk.snapshot(Path(item['installed'])).sha256 == item['sha256'], 'installed Kotlin runtime drift')
for name, digest in package['files'].items():
    sdk.require(sdk.snapshot(Path(package['installed']) / name, maximum=256*1024**2).sha256 == digest, 'installed Kotlin package drift')
sdk.require(sdk.snapshot(Path(package['client'])).sha256 == package['client_sha256'], 'Kotlin launcher drift')
'''
index = source.index('metadata = json.loads(')
source = source[:index] + guard + source[index:] + guard
with (stage / 'run-kotlin-flow-14.py').open('x') as stream: stream.write(source)
print('Fresh Kotlin cohorts prepared with installed dependency guards')
