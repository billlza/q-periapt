from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
inputs = json.loads((stage / 'INPUTS_21.json').read_text())
original = json.loads((stage / 'INPUTS_06.json').read_text())
parent = 'e07c3ad22b0d10c2f0d1df9dc2e1bf48306a046b'
def git(*args, cwd=root): return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
for checkout in [root, clone]: sdk.require(git('rev-parse','HEAD',cwd=checkout) == parent, 'head drift')
changed = set(git('diff','HEAD','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
sdk.require(changed == set(inputs), 'unrelated source diff')
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
    if name not in original:
        before = subprocess.check_output(['git','show','HEAD:' + name], cwd=clone)
        sdk.require(sdk.snapshot(clone / name).data == before, 'clone documentation changed independently')
        (clone / name).write_bytes(sdk.snapshot(root / name).data)
    sdk.require(sdk.snapshot(clone / name).sha256 == digest, 'clone source drift')
for checkout, label in [(root,'main'),(clone,'clone')]:
    sdk.command(['git','add','--',*sorted(inputs)], stage / ('source-stage-' + label + '-25'), checkout)
sdk.command(['git','commit','-m','Expose original pending write recovery in native bindings'], stage / 'source-commit-25', root)
head = git('rev-parse','HEAD'); tree = git('rev-parse','HEAD^{tree}')
sdk.require(git('write-tree',cwd=clone) == tree, 'clone index is not exact committed tree')
sdk.command(['git','fetch','--no-tags','--no-write-fetch-head',str(root),head], stage / 'source-fetch-25', clone)
# Advancing this owned detached clone is safe only after the exact staged tree
# equals the committed tree. No source or uncommitted data is discarded.
sdk.command(['git','update-ref','HEAD',head,parent], stage / 'source-clone-head-25', clone)
for checkout in [root,clone]:
    sdk.require(not git('status','--porcelain',cwd=checkout), 'source checkout not clean')
    sdk.require(git('rev-parse','HEAD',cwd=checkout) == head, 'clone commit differs')
sdk.write_json(stage / 'SOURCE_COMMIT_25.json', {'source_commit': head, 'parent': parent, 'files': inputs,
    'qualified_implementation_inputs_unchanged': True, 'additional_changes': sorted(set(inputs) - set(original)),
    'pushed': False})
sdk.command([sys.executable,'-B',str(clone / 'artifact/python_bootstrap.py'),
    str(clone / 'artifact/source_results_assembler.py'),'ci-source-gate',
    '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],
    stage / 'source-gate-25', clone)
print('Exact source committed locally and real-clone source gate passed: ' + head)
