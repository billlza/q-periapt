from pathlib import Path
import json
import os
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
inputs = json.loads((stage / 'INPUTS_01.json').read_text())
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
source = root / 'bindings/android/ContinuityPackageConsumer'
builder = stage / 'android-source-02'
for path in source.rglob('*'):
    if path.is_file():
        sdk.copy(path, builder / path.relative_to(source))
java = Path(json.loads((root / 'target/continuity-kotlin-policy-credential/ENVIRONMENT.json').read_text())['JAVA_HOME'])
environment = {key: os.environ[key] for key in ['HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'USER', 'LOGNAME', 'PATH']
               if key in os.environ}
classes = stage / 'android-classes-02'; classes.mkdir()
sdk.command([str(java / 'bin/javac'), '--release', '11', '-Xlint:all', '-Werror', '-d', str(classes),
             *map(str, sorted((builder / 'src/main/java').rglob('*.java')))], stage / 'java-main-02', root, environment=environment)
jar = stage / 'android-classes-02.jar'
with zipfile.ZipFile(jar, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(classes.rglob('*.class')):
        archive.write(path, path.relative_to(classes).as_posix())
tests = stage / 'android-tests-02'; tests.mkdir()
sdk.command([str(java / 'bin/javac'), '--release', '17', '-Xlint:all', '-Werror', '-cp', str(jar), '-d', str(tests),
             *map(str, sorted((builder / 'src/test/java').glob('*.java')))], stage / 'java-tests-02', root, environment=environment)
clang = sdk.command(['xcrun', '--sdk', 'macosx', '--find', 'clang'], stage / 'clang-path-02', root).decode().strip()
platform = sdk.command(['xcrun', '--sdk', 'macosx', '--show-sdk-path'], stage / 'sdk-path-02', root).decode().strip()
sdk.command([clang, '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic', '-fvisibility=hidden',
             '-isysroot', platform, '-I' + str(root / 'bindings/c/ContinuityPackageConsumer'),
             '-I' + str(java / 'include'), '-I' + str(java / 'include/darwin'), '-fsyntax-only',
             *map(str, sorted((builder / 'jni').glob('*.c')))], stage / 'jni-syntax-02', root, environment=environment)
sdk.write_json(stage / 'JAVA_BUILD_02.json', {'java': str(java), 'clang': clang, 'sdk': platform,
    'jar': str(jar), 'jar_sha256': sdk.snapshot(jar).sha256, 'tests': str(tests), 'builder': str(builder),
    'environment': environment, 'scope': 'Source-linked compile checks, pending real JNI execution'})
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
print('Android Java and JNI strict compilation passed')
