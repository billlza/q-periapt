from pathlib import Path
import json
import os
import sys
import rust_sdk_profile as sdk

root = Path.cwd(); stage = root / 'target/continuity-native-pending-recovery'
app = json.loads((stage / 'PHYSICAL_APP_19.json').read_text())
sdk.require(app['completed_build'], 'app not built')
sdk.require(sdk.snapshot(Path(app['app']) / 'ContinuityBinaryConsumer', maximum=128*1024**2).sha256 == app['executable_sha256'], 'signed executable changed')
devices = {'ipad': '<selected-private-device-or-signing-identifier>', 'iphone': '<selected-private-device-or-signing-identifier>'}
label = sys.argv[1]; device = devices[label]
output = stage / ('physical-' + label + '-18'); output.mkdir(mode=0o700)
env = {key: os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
def run(args, name):
    return sdk.command(['/usr/bin/xcrun','devicectl', *args[:3], '--device', device,
        '--timeout', '45', '--json-output', str(output / (name + '-raw.json')), *args[3:]], output / name, root, environment=env)
run(['device','info','details'], 'details')
run(['device','install','app', app['app']], 'install')
stdout = run(['device','process','launch','--console','--terminate-existing', app['bundle']], 'launch')
markers = [b'CONTINUITY_BINARY_CONSUMER_PASS cancelled=302 closed=2 created_state=false',
    b'QPC_PENDING_DEVICE_BOUNDARY_PASS exports=3 info_size=436 output_unchanged=true no_state=true']
sdk.require(all(stdout.count(marker) == 1 for marker in markers) and b'_FAIL' not in stdout, 'physical test marker missing or failed')
sdk.require(sdk.snapshot(Path(app['app']) / 'ContinuityBinaryConsumer', maximum=128*1024**2).sha256 == app['executable_sha256'], 'app changed during test')
raw = json.loads((output / 'launch-raw.json').read_text())
sdk.write_json(output / 'OBSERVATION.json', {'markers_present': True, 'command_returncode': 0,
    'app_sha256': app['executable_sha256'], 'package_sha256': app['archive_sha256'],
    'scope': app['scope'], 'process_terminal_result_keys': sorted(raw.get('result', {})),
    'completed': False, 'reason': 'Await explicit inspection of structured process termination receipt'})
print(label + ': both physical test markers observed; termination receipt keys=' + str(sorted(raw.get('result', {}))))
