import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = '4cda512f0e2a8d5e986f49a28261bd37a74cb0bb'
PRODUCT = '1bdb29a20d1d9c68496648f3be91efad710e4b0c'
PREFIX = 'research/continuity-identity-candidate/src/durable/'
SOURCES = [
    'messages.rs', 'messages/closure.rs', 'messages/fanout.rs',
    'messages/fanout/abandonment.rs', 'messages/fanout/codec.rs',
    'messages/terminal.rs', 'messages/traffic.rs', 'messages/resolution.rs',
    'messages/acknowledgement.rs', 'messages/delivery.rs',
    'messages/tests/closure.rs', 'messages/tests/fanout/abandonment.rs',
    'messages/tests/epoch_resolution.rs',
]
SELECTED = {
    'epoch_resolution': [
        'closed_epoch_resolution_reports_exact_data_and_never_invents_delivery_success',
        'resolution_scope_authority_and_checkpoint_invariants_are_enforced',
        'every_resolution_sync_fault_recovers_exact_report_or_application_acknowledgement',
        'killed_resolution_commits_recover_without_early_report_or_false_delivery',
    ],
    'closure': [
        'independent_session_closure_accounts_all_epochs_and_a_real_reserved_input',
        'independent_session_closure_fences_pending_rekey_flights_before_and_after_cutover',
        'independent_session_closure_every_observed_sync_fault_reconciles_one_transition',
    ],
    'fanout::abandonment': [
        'account_fanout_abandonment_process_cuts_freeze_and_close_all_sessions',
        'account_fanout_abandonment_sync_faults_reconcile_each_measured_barrier',
    ],
}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    path = ROOT / 'capture' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(data)

source_hashes = {}
for relative in SOURCES:
    name = PREFIX + relative
    data = (REPO / name).read_bytes()
    for commit in (SOURCE, PRODUCT):
        require(data == subprocess.check_output(['git','show',commit+':'+name],cwd=REPO), 'source differs from referenced commit')
    source_hashes[name] = sha(data)
    save('source/' + name, data)

original = REPO / 'research/sdk-alpha1/evidence/20261105-renewal-roster-verification/VALIDATION.zip'
require(sha(original.read_bytes()) == '9c6e0a574fe197d88f4e3b2ba6299948c28d2a490e444e919e7ba970580e3a34', 'original validation capsule changed')
with zipfile.ZipFile(original) as archive:
    names = ['full-release-01/' + n for n in ('READBACK.json','RESULT.json','INPUTS.json','runtime.stdout','runtime.stderr')]
    original_files = {n: archive.read(n) for n in names}
for name, data in original_files.items():
    save('previous-release/' + name, data)
record = json.loads(original_files['full-release-01/READBACK.json'])
result = json.loads(original_files['full-release-01/RESULT.json'])
stdout = original_files['full-release-01/runtime.stdout']
require(record['full_release_tests_passed'] is True and record['actual_tests'] == 1461 and
        record['failed'] == record['ignored'] == record['filtered_out'] == 0, 'full Release readback differs')
require(record['stdout_sha256'] == sha(stdout) and record['original_result_sha256'] == sha(original_files['full-release-01/RESULT.json']), 'original result provenance differs')
require(result['completed'] is True and result['returncode'] == 0 and result['passed'] is False and
        result['error'] == 'actual full test inventory differs', 'original reader failure was lost')
passed = re.findall(r'^test (.+?) \.\.\. ok$', stdout.decode(), re.M)
require(len(passed) == len(set(passed)) == 1461, 'runtime inventory changed')
observations = []
for module, cases in SELECTED.items():
    path = PREFIX + 'messages/tests/' + module.replace('::','/') + '.rs'
    lines = (REPO/path).read_text().splitlines()
    for case in cases:
        name = 'durable::messages::tests::' + module + '::' + case
        require(passed.count(name) == 1, 'selected case not passed exactly once')
        declaration = [i+1 for i,line in enumerate(lines) if line.startswith('fn '+case+'(')]
        require(len(declaration) == 1, 'selected test source declaration changed')
        observations.append({'test':name,'result':'ok','file':path,'declaration_line':declaration[0]})
note = 'docs/continuity/CLEANUP_REPORT_MAC_V1.md'
save('note/' + note, (REPO/note).read_bytes())
save('capture.py', pathlib.Path(__file__).read_bytes())
audit = {'source_commit':SOURCE, 'same_selected_sources_as_product_commit':PRODUCT,
    'source_files':source_hashes, 'source_files_count':len(source_hashes),
    'selected_existing_release_outcomes':observations, 'new_native_executions':0,
    'original_validation_capsule':{'path':original.relative_to(REPO).as_posix(),'sha256':sha(original.read_bytes())},
    'original_test_binary_sha256':record['binary_sha256'], 'original_stdout_sha256':sha(stdout),
    'full_release_tests':1461, 'original_reader_failure_preserved':True,
    'scope':'Source audit of three report families and references to nine already completed Release cases. Does not establish all partial acquisitions, multi-report simulation, physical erasure, or the main computational theorem.',
    'release_claim_eligible':False}
(ROOT/'SOURCE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
save('SOURCE_AUDIT.json', (ROOT/'SOURCE_AUDIT.json').read_bytes())
files = {p.relative_to(ROOT/'capture').as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
         for p in sorted((ROOT/'capture').rglob('*')) if p.is_file()}
(ROOT/'FILES.json').write_text(json.dumps(files,indent=2)+'\n')
with zipfile.ZipFile(ROOT/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name in files:
        archive.write(ROOT/'capture'/name,name)
with zipfile.ZipFile(ROOT/'CAPTURE.zip') as archive:
    require(set(archive.namelist()) == set(files), 'capsule inventory mismatch')
    for name,row in files.items():
        data=archive.read(name)
        require(len(data)==row['bytes'] and sha(data)==row['sha256'], 'capsule readback differs')
print(json.dumps({'source_files':len(source_hashes),'selected_prior_outcomes':len(observations),
    'new_native_executions':0,'capsule_bytes':(ROOT/'CAPTURE.zip').stat().st_size,
    'capsule_sha256':sha((ROOT/'CAPTURE.zip').read_bytes()),'members':len(files)}))
