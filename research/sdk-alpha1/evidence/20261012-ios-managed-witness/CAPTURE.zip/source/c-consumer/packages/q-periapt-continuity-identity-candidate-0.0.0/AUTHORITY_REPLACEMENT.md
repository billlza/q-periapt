# Account-root and witness authority replacement

Status: the native witness account-root transaction, original-journal fence,
original-enrollment parent fence, explicit peer-account retirement and initial
managed replacement owner are implemented;
the complete managed account cutover and witness-key handoff
are **not implemented**. Both
remain part of the required 0.2.0 lifecycle. Existing registration, credential
renewal, policy continuation and device replacement do not complete that lifecycle.

## Managed original replacement owner

`ManagedAccountRootReplacement` composes the existing native registry, enrollment
and journal engines without adding a storage format or witness protocol. `begin`
consumes a device already bound to the selected registry/checkpoint and retains
the independently approved plan before a witness freeze may be requested. It
keeps the original enrollment lease throughout preparation; a separate open cannot
take over that parent while the controller waits for the witness. Closing or
dropping the controller revokes registry access before disposing database owners.

The independently authorized control plane still issues the successor, approves
the plan, freezes the witness and commits its root replacement. The controller
authenticates the original freeze receipt, binds the exact proposal in the registry
and transfers the same enrollment into restricted parent/journal recovery.
`retain_witness_retirement` verifies the exact signed retirement and persists it
in child and parent before selecting the successor in the registry. These are
ordered commits, not one cross-database transaction. A lost return may follow any
commit; `resume_original` requires the same existing registry, checkpoint, approved
plan, enrollment paths/intent and witness pin. It neither creates an absent
operation nor treats silence as non-commit. Replaying the original receipt cannot
advance the application revision twice.

`activate_successor` requires retained retirement in both local owners and the
exact target journal/account from the approved proposal. It then uses ordinary
current credential/policy admission, fresh witness verification and durable
registry binding. Committed history does not bypass expiry or authorize a different
target. The controller must outlive returned operating owners;
`successor_authority` supplies the same revocable registry descriptor for ordinary
enrollment reopening and later lifecycle operations.

The [native owner checkpoint](../sdk-alpha1/evidence/20261011-managed-root-owner/CHECKS.json)
records 32 account-root tests on each of Rust 1.98.1 and 1.90.0, 11 focused Release
tests, strict Clippy on both compilers, and seven actual process-loss cuts in each
tested profile. The initial prototype's missing preparation lease is retained as
a failing regression followed by the corrected result. These are controlled native
fixtures on one macOS arm64 host, with real signatures and storage; they do not
qualify deployed authority transport or installed foreign-language consumers.

`retain_witness_noncommit` now persists the original signed permanent plan closure,
including before a freeze result was bound. Closed plans keep old traffic suspended;
reopening them retains the existing parent lease or exact restricted journal owner.
A closure does not cancel an in-flight freeze. `ManagedAccountRootTransition::verify`
authenticates the original closure and the next freeze against independently retained
plans and witness pins. Neither receipt chooses the next target.

`transition_after_noncommit` persists the closure, next preparation and exact
binding before reconciling parent and child. A live bound parent validates the
local head before advancing the registry intent. `resume_transition` repeats those
same steps across any partial commit. It distinguishes an authenticated parent
with no previous fence from a missing or corrupt parent; only the former can take
its initial approved fence. Existing journal history is preserved, and a retry of
an initial fence is admitted only after the registry has checked the original
closure and exact next plan. A known closed next target is refused before mutation;
another independently approved plan is required. Original operation identities and
the application revision survive multiple abandoned targets and final commitment.

Receipt decoding, signature and requested-scope failures are rejected before the
storage/recovery path and leave the controller usable. They do not revoke unrelated
application accounts sharing its registry. A failure inside persistence or recovery
still consumes the owner and can follow commit; explicit close/drop also revokes
registry access. Preserve the original inputs and reconcile after those failures.

The [managed transition checkpoint](../sdk-alpha1/evidence/20261011-managed-root-transition/CHECKS.json)
records 38 account-root tests on Rust 1.98.1 and 1.90.0, 17 focused Release tests,
strict Clippy and the exact 14 new process-loss cuts in each tested profile. It
retains failing regressions for unrelated-account revocation by invalid receipts
and acceptance of a known closed next target. It also records the corrected test
module path, child-fence selector and atomic checkpoint-publication race; earlier
green counts that did not execute the intended cuts are not used as qualification.

`ManagedAccountRootAdoption::verify` now combines the original signed non-commit
with an independently approved exact winner and its signed retirement. The managed
owner distinguishes prepared plans from adopted proposals; adoption does not invent
a local preparation for an operation committed elsewhere. A losing unbound freeze
may adopt a separately approved competing freeze. An already bound original must
still satisfy the retained freeze scope.

`adopt_committed_winner` first retains original non-commit, then checks the same
prospective registry image used by native adoption before changing the parent.
Cross-application root reuse is refused at that boundary. It reconciles the original
parent/journal transition, retains retirement in child and parent, and only then
selects the winner locally. `resume_adoption` repeats that original approved operation
across partial commits without a new plan, key, database or revision. Current
successor activation still verifies the exact target, credential/policy and witness;
an expired credential cannot gain validity from the historical retirement.

The [managed adoption checkpoint](../sdk-alpha1/evidence/20261011-managed-root-adoption/CHECKS.json)
records 58 related tests per current/minimum Rust compiler, 22 focused Release
tests, strict Clippy and 18 actual adoption process-loss cuts in each tested profile.
All existing 14 alternate-target and seven initial cutover cuts also run. Registry
admission is checked against the same prospective image used for commitment, and
the cross-application refusal test verifies that original parent rows stay unchanged.
These native same-host checks do not qualify installed foreign adapters or physical
platforms, and do not claim a new storage format or product C ABI.

The native controller also owns historical cleanup through `with_retired_cleanup`.
Preparing/Pending are refused before invoking its callback. Once the registry and
original parent have committed retirement, the existing inventory/report/host-ACK
and erasure sequence runs under that same controller. The private original-owner
state is exclusively preparing enrollment, fenced root recovery, or retired
enrollment; the registry remains owned across each successful cleanup step.

For example, `controller.with_retired_cleanup(|old| old.installation()?.proposal())`
retains and returns the original inventory. Subsequent callbacks use the existing
`RetiredDeviceEnrollment` operations for report retention, explicit durable host
accounting, purpose-21 acknowledgement, journal erasure and separate signer erasure.
No callback makes external host effects atomic. Callback/storage errors close the
controller and revoke its delegated successor owners. An unwind does the same through
owned scope destruction and still propagates to the caller. There is no catch-and-success
path. Successful signer erasure closes its restricted native owner; the controller
then reopens only that same historical parent, preserving the successor registry.

Resume with the original preparation, approved alternate-target transition, or
approved committed-winner adoption as appropriate. A retained combined retirement
parent is admitted only under the same committed registry proposal/checkpoint,
original paths, enrollment intent and witness pin. Missing state is never first use.
Original receipt retries keep revision 2 and do not reopen old traffic or invent a
preparation for an adopted winner. Historical cleanup does not extend an expired
successor credential; successor activation still checks current authorization.

The [managed cleanup qualification](../sdk-alpha1/evidence/20261011-managed-root-cleanup/CHECKS.json)
records 58 root-lifecycle tests on each Rust compiler, 16 direct ordinary enrollment
regressions, 36 historical retirement regressions, ten focused Release tests and
strict Clippy on both compilers. Eight new process-loss cuts run in each root Debug
suite and Release. The callback-unwind regression first observed a still-live
controller/cached successor, then passed after operations took scoped ownership.
The 44 inventory checks and current 534-source gate pass; installed package and
physical-platform evidence are separate requirements.

Installed foreign adapters, deployed control-plane transport and supported-platform
qualification remain required. They must preserve original identities and approvals;
they cannot reset Preparing/Pending or regenerate a root to recover availability.

## Preserve the current identity meanings

`identity::account_id` commits to the complete root public key. A new root has a
new cryptographic account ID, even when the device key, device ID and generation
are unchanged. `AccountPin::new` correctly refuses an old account ID paired with
the new root. The enrollment intent, immutable storage owner and signed rosters
also bind the original root/account. Those checks must remain.

A product may keep the same **application account** across this transition, but
that mapping needs independently authenticated host authority. It must not rename
an old cryptographic account, rewrite its journal header or derive the application's
account association from a replacement message. The original account, session,
message and delivery identities remain attached to historical records.

Creating a new `AccountPin` does not revoke an existing pin, verified roster or
stored roster. Closing a root signing owner only removes that owner's ability to
sign; it does not revoke issued credentials. `VerifiedRoster::from_journal`
authenticates the original stored authority; it is not a root-replacement registry.
The product transition therefore needs a durable current-authority owner whose
fence applies to cached objects, reopened state and newly admitted peers.

The [source-bound boundary experiment](../sdk-alpha1/evidence/20261010-authority-cutover-boundary/CHECKS.json)
executes six isolated cases and an existing pinned-root negative control. Its
real witness-store case retires the original device, enrolls a new-root account,
then explicitly enrolls a previously unseen device under the old root. The old
device remains retired; the other two subjects remain current after reopening
the MAC-authenticated witness store. These are trusted-control-plane operations with actual
signatures. The result confirms the existing per-device contract and rules out
using that composition as account-root retirement; it is not a network enrollment
exploit or an implemented replacement transaction.

## Authorization and disclosure scope

Recovery after disclosure of the old root requires approval independent of that
root. An old-root signature, even together with a new self-signed root, cannot by
itself distinguish an authorized recovery from an attacker-selected successor.
The host must authenticate the application account and independently obtain the
exact target root and roster expectation before approving the transition.

Approval must bind the host's original account association, original authority
revision, original and target cryptographic account/root, operation ID, target
enrollment identity, policy family and witness authority. Retries retain this
whole operation. The target's credential and device proof must still verify under
the independently selected target root. Public IDs and a structurally valid
descriptor do not supply this approval.

Root-only disclosure is separate from device signing-key, policy-root, witness,
wrapping-key or entropy-source disclosure. Recovery cannot reuse an authority or
secret whose continued trust is assumed without stating that assumption. It
cannot promise to remove knowledge already obtained by an attacker.

## Durable cutover obligations

The following are required state properties, not allocated wire tags or a final
storage layout:

| State | Required behavior |
| --- | --- |
| Current | Only the independently retained current authority admits new operations. |
| Replacement intent retained | The exact approved operation and target survive restart; old authority is fenced before the transition reports that fence as durable. Unknown persistence outcomes permit only original-operation reconciliation. |
| Target prepared | Original target configuration/enrollment and any witness preparation are retained. Preparation alone grants no target traffic authority. |
| Target committed | The durable authority revision selects the exact target. Final activation checks it before returning an owner. Cached old owners cannot release new operational results. |
| Historical cleanup | Old sessions and operations retain their original identities and explicit outcomes. Cleanup cannot reactivate the old account or turn unknown delivery into success. |

An approved recovery cannot fall back to the compromised root because target
creation, network access or witness confirmation fails. Partial target creation
must resume the original operation, without reusing the old journal as the new
account or silently generating another enrollment. Any cancellation semantics
must distinguish a planned rotation from recovery after revoked trust; cancellation
must not be invented as an automatic error path.

The owner must govern both local-account and peer-account admission. Borrowed
Rust handles, foreign aliases, reopened journals and fresh configuration imports
must not bypass its persisted authority revision. Existing session views are
historical inputs; carrying a session into a new root requires its own explicit
construction. The initial replacement path should establish a fresh authenticated
session under the new account while preserving old loss/delivery accounting.

## Required witness boundary

Existing witness device replacement retires named device subjects. Root retirement
must also reject future enrollment under the retired account/root, including a
device ID that was never previously observed. Enumerating only existing subjects
leaves that case uncovered. A durable account-wide retirement floor must govern
both trusted-control-plane enrollment and ordinary subject operations; host
approval of a stale descriptor cannot erase the floor.

Keeping the witness key during account-root replacement and replacing the witness
key are distinct transitions. `AnchorPin` binds both the witness instance ID and
its full public key: reusing the instance ID with another key changes its binding.
New witness enrollment at revision one must not stand in for transfer of an old
head, fence, last-command identity, retired authority floors or pending outcomes.

A witness-key handoff needs exact retained state and independently authorized
target trust. If the old witness is compromised or unavailable, its signature or
silence cannot prove a safe current head or an uncommitted operation. That case
needs an explicit recovery construction and unknown-outcome treatment. Neither
root replacement nor fresh installation silently supplies it.

## Acceptance before product admission

### Native witness transaction

`account_root_replacement_proposal` retains an independent operation ID, both full
roots, a fresh target account/journal and all old-account subjects. The operator
must authenticate application-account recovery and the target enrollment outside
this API. Incoming bytes or the old root's signature cannot supply that approval.
The target must use the same required witness and different root-key components.
Unknown legacy entry identities suspend preparation until independently classified.

`replace_account_root` compares the exact original descriptor, current target
authorization and complete old-account snapshot before one atomic store commit.
It admits the target genesis and permanently fences old-root enrollment, including
unseen device IDs, old subject requests and device-replacement attempts. Unrelated
account progress does not invalidate the old-account snapshot. A changed old head,
new old-account subject, competing target or reused operation identity conflicts.
Requests served before the commit may still arrive late over a transport; this
witness transaction does not replace a local managed-authority fence.

`account_root_replacement_status` and exact committed retries preserve historical
Committed after target expiry. Unavailable never permits fallback. Sync failures
consume the current store owner and can follow commit: reopen the same instance
and reconcile the original descriptor. No frozen head, pending command or unknown
delivery is reclassified as successful consumption.

`retired_account_observation` returns frozen public metadata.
`retired_account_receipt` signs purpose 22 over
`QPARTR01[8] || witness_binding[32] || proposal_binding[32]`; its verifier is
`AnchorPin::verify_retired_account`. It is a 72-byte body and 3449-byte envelope.
The statement proves historical retirement under continued witness key/storage
trust, not freshness, successor permission, physical erasure or witness migration.

The canonical unsigned proposal is `QPARPL01`, with a 4452-byte fixed portion and
209 bytes per frozen subject. At most 256 subjects and 65536 input bytes are
accepted. Its binding uses domain `Q-PERIAPT-CONTINUITY-ACCOUNT-ROOT-REPLACEMENT/v1`.
The store emits `QPANC015` when account replacements exist without preparation freezes. It retains all old
entry layouts, device retirement, cleanup, reports and acknowledgement records.
Earlier layouts keep their canonical nonempty-table requirements; empty older
sections are permitted only inside this new aggregate format. Unknown versions,
including reserved `QPANC005`, still refuse admission.

The existing 256-entry and 1-MiB aggregate limits still apply, along with a maximum
of 256 account-replacement records. Capacity failure commits nothing and is not a
successful emergency fence. Capacity planning/reclamation, the local authority
owner, account authentication, foreign adapters and complete cutover failure
qualification remain product requirements. The witness's own rollback protection
remains an independent deployment assumption.

The [2026-10-10 native qualification](../sdk-alpha1/evidence/20261010-account-root-retirement/CHECKS.json)
retains 828 passing Release library tests, 12 focused root-retirement test entries
(including one subprocess helper), 15 compile-fail doctests, strict Clippy and the
Rust 1.90 check. The focused paths exercise four real pre/post-sync failures and
process termination after durable commit but before return. These fresh macOS
arm64 fixtures qualify this native component; they do not complete the managed
local/foreign cutover or the platform requirements below.

### Local original-journal transaction

`DeviceJournal::begin_account_root_replacement` consumes that journal's operational
ownership and retains the exact independently approved witness proposal. Its
`AccountRootJournalRecovery` result cannot return a traffic owner. The original
encrypted image and pending write/cancellation bytes remain unchanged, including
unresolved outcomes. This local transaction does not advance the witness head and
therefore does not itself invalidate the original root-replacement snapshot.

The separate `account-root-fence` row uses `QPARJF01`, a dedicated HKDF-derived MAC
key, the original subject/image and the exact pending-intent commitment. Ordinary
opening and existing lifecycle recovery reject it. `resume_original` only
reconciles the independently retained original inputs against existing storage;
missing or conflicting files never create a new journal or an old traffic owner.
I/O errors close ownership and may follow commit.

`LocalFenced` reports no witness outcome. `retain_witness_retirement` authenticates
purpose 22 and durably retains its original statement before reporting
`WitnessCommitted`. Re-signing the same statement does not replace the first
retained receipt. Historical observation remains possible after runtime closure;
neither state admits the successor or turns an unknown old delivery into success.

The [local-fence qualification](../sdk-alpha1/evidence/20261010-account-root-local-fence/CHECKS.json)
retains 838 passing Release library tests, ten focused entries (one subprocess
helper), 16 compile-fail doctests, strict Clippy and the Rust 1.90 check. Four
fence-sync faults, six receipt-sync faults and four real process-termination cuts
preserve the original image, pending intent and operation. These are native macOS
arm64 component results, not full managed-cutover or cross-platform qualification.

This is one **required-witness journal** component, not the independent current
account-authority store. In particular, restoring the whole journal from before
the local fence can remove that row before the witness commits retirement. The
parent intent is retained by the enrollment integration below. A stable current
authority revision must still govern all configuration imports/reopen. Peer-account
admission, successor installation/activation and the account-specific historical
cleanup workflow also remain to be integrated. A per-journal marker must not be
described as an executed managed account cutover or whole-host rollback protection.

The [fresh backup-boundary experiment](../sdk-alpha1/evidence/20261010-account-root-backup-boundary/CHECKS.json)
confirms this distinction with a real two-endpoint handshake and application
ciphertext. Before witness retirement, restoring the complete pre-fence journal
permits anchored reopening and release of the identical cached ciphertext. After
witness retirement, the same restored bytes cannot reopen a traffic journal. The
fixture transport reports the witness's refusal as unavailability; a separate
purpose-22 receipt supplies authenticated historical retirement. This does not
test whole-host or witness rollback.

### Original-account inventory, reporting and logical erasure

A verified `AnchorRetiredAccount::retired_subject` selects only an original frozen
subject. The existing inventory/report/host-ACK protocol retains the actual
account-root proposal binding and its domain separation; it never fabricates a
device-generation replacement. Witness inventory admission selects the root
proposal by the subject's original account, without hashing every stored account
proposal. An earlier retained device inventory remains authoritative: a different
root-bound inventory for that same subject conflicts instead of overwriting it.

After both original parent and journal retain purpose 22,
`AccountRootEnrollmentRecovery::into_retired` transfers the still-held enrollment
lease to `RetiredDeviceEnrollment`. It reuses the existing installation accounting
and signer-erasure flow. Recovery uses `RetiredDeviceEnrollment::open` with the
original paths, intent, witness pin and that same verified retired subject; ordinary
root-replacement recovery cannot be used after the cleanup record is retained.
Uncommitted, mismatched or competing local root operations refuse this transition.

The root-replacement row and unchanged enrollment image remain in the parent beside
the exact cleanup inventory. Both records must bind the same original subject and
root operation, with a retained verified retirement receipt. This extends the
permitted row combination in the candidate enrollment schema: older binaries reject
such a parent; downgrade/recreation is not a supported recovery path. No product C
ABI has been added. The managed controller now owns this sequence; installed foreign entry points
still need to expose it.

Reporting authenticates the original source, pending intent, target and session
archives. It preserves unconfirmed ciphertext identities and distinguishes an
uncommitted target from a witness-committed target; root retirement supplies no
message-consumption acknowledgement. The host must retain the full report and
request separate purpose-21 acknowledgement before explicit journal erasure. The
journal image, pending intent and exact root fence are then replaced atomically by
the authenticated terminal record. Only afterwards can the original signer file be
prepared and logically erased. Missing originals, archives or receipts fail; no
successor or fresh identity is created. Retained pages, wrapping keys, backups and
previously copied signing owners remain outside this logical-erasure claim.

The [native root-cleanup qualification](../sdk-alpha1/evidence/20261011-account-root-cleanup/CHECKS.json)
retains 48 root-lifecycle tests on each of Rust 1.98.1 and 1.90, 36 historical
retirement regressions, 19 witness-cleanup regressions, the actual unconfirmed
traffic/pending-target test, six focused Release tests, and strict Clippy on both
compilers. The new checks include four actual process-loss cuts and every observed
pre/post-sync boundary of the parent inventory, journal erasure and signer-plan
commits. All 2719 artifact tests pass without skips, and the 530-source readiness
gate passes with `release_claim_eligible=false`. These are native component results;
installed-language and physical-platform qualification remain open. The later managed
integration is qualified separately.

### Original enrollment parent transaction

`EnrolledDevice::begin_account_root_replacement` consumes the old service and
signer, retains the exact independently approved proposal in its original
enrollment database, then fences the original journal. The existing enrollment
lease and wrapping-key/path binding remain authoritative. Its separate
`root-replacement` row uses `QPERPL01` and authenticates the unchanged enrollment
image, signing identity, journal identity and complete proposal. It does not
rewrite the original enrollment, key, credential, policy or roster history.

`AccountRootEnrollmentRecovery::resume_original` opens only those existing paths
and the independently retained original intent. A failed first parent commit can
be reconciled with the same proposal. Once the marker exists, a competing proposal
is refused, and ordinary enrollment opening, activation and credential/policy
recovery cannot use the parent for traffic. Restoring only the old journal does
not remove this enrollment fence. Recovery re-establishes the exact child fence;
missing children or signer files never trigger replacement or key generation.

`IntentRetained` reports no witness outcome. Receipt retention first verifies the
exact purpose-22 statement and durably retains it in the child, then in the parent.
Only the latter boundary acknowledges `WitnessCommitted`. Loss between commits
requires the original operation/receipt; it cannot infer no-commit. A retained
parent receipt also survives a later child-backup restoration. Historical recovery
does not reopen signing material or require a live traffic runtime.

The native focused checks exercise restored child backups, two competing intents,
bad signatures/MACs, authenticated wrong-image markers, extra schema and missing
children. They measure three parent sync barriers for intent and three for receipt,
inject all twelve pre/post-sync faults, and terminate owned processes at both sides
of both commits. Target enrollment activation remains a separate current-authority
check; the same prepared target refuses before witness admission and succeeds after
the actual witness commit. These component checks do not qualify installed foreign
calls or replace the full regression and platform gates.

This parent is one original local enrollment. It does not implement a stable
application-account authority registry, govern arbitrary low-level journal imports,
fence cached remote-account owners, select/activate a successor on the user's behalf,
or transfer the witness key. Restoring the parent or whole host is outside this
local backup boundary. These remaining obligations still block managed cutover.

### Explicit peer-account retirement

`DeviceService::retire_peer_account` explicitly adopts an `AnchorRetiredAccount`
that the host has authenticated and independently approved. Receipt verification
remains pure. Adoption requires a known remote account, the original installation's
required witness and current local credential/policy authority. It cannot retire
the local account or admit an unknown peer. A different witness is refused even
when its signature is valid.

The original roster record gains a `QPRHST07` prefix containing the operation ID,
statement commitment, successor account and witness binding (136 additional bytes).
The encrypted journal authenticates this local decision; these fields are not a
transferable witness signature. Retain the original proposal and receipt for exact
reconciliation. Historical rosters, generation floors, renewal grants, session and
message identities remain intact. Ordinary roster and credential refresh cannot
clear the retirement marker, including an otherwise identical refresh.

The normal encrypted-image/write-intent transaction advances this sender's own
witness head. After acknowledged commit, an older whole-journal backup cannot
remove the peer floor while that witness retains its current state. Storage errors
close the journal and may follow commit; reopening reconciles the original sealed
intent before admitting traffic, and the same retirement can then be retried.
An identical retry performs no additional journal transaction. Capacity and policy
errors do not claim that a durable fence exists; managed approval-intent retention
before this component remains part of the unfinished account-authority owner.

Operational admission checks the marker for cached sessions, fresh bootstrap,
message/retransmission and complete-roster fanout. Historical cleanup still reports
the original peer and unknown deliveries; it does not relabel them under the target.
The successor account is recorded for correlation only. This operation selects no
application-account mapping, creates no successor session and transfers no witness
trust. Foreign adapters and complete managed cutover remain required.

The peer-adoption process regression also kills the actual sender process at four
boundaries: before an intent exists, after the original sealed intent is durable,
after the real witness commits while its signed reply is withheld, and after the
local image commit before the API returns. The parent retains the same durable
witness and independently verifies its signed head replies. Restart resumes the
exact original statement, preserves unknown delivery accounting and never advances
the head again merely for an identical retry. Before intent persistence, the test
correctly observes that no durable local fence exists yet; it does not infer one
from host approval. These are process-loss checks with a bounded test IPC carrier,
not TCP/TLS qualification, simultaneous witness failure or physical power-loss tests.

### Remaining product acceptance

Actual installed owners must exercise the same original operation across cuts
before and after each durable boundary, lost replies, competing targets, stale
approvals and reopening. Check cached aliases and old configuration imports after
commit, old-root issuance for a previously unseen device, full-roster fanout races,
and old-account traffic/ACK rejection under the new account. Reports must retain
unknown old deliveries without relabeling them as delivered or replaying their
business effects under a new identity.

Keep signature/namespace experiments, authenticated-store transitions, witness
transactions, installed foreign calls and platform persistence as separate evidence.
A pin decoder or a successful new registration is not an executed root cutover.

### Application authority registry component

`AccountAuthorityStore` is a native foundation for an independently authenticated
application account ID and its current cryptographic root. It retains the exact
approved replacement proposal, advances its own revision by one on verified
witness retirement, and preserves original-operation history. A pending entry
suspends both roots at this registry. Its old read leases stay revoked after a
replacement or owner close; an unrelated application's successful update does
not revoke other entries. An uncertain database mutation closes the owner and
all its leases, and recovery must reopen the same path/key/identity and retry
the original proposal or verified retirement.

The public state is MAC authenticated under a separately retained key, with
path, registry identity, policy family and witness binding. The committed bit
records the locally verified decision; the registry does not retain a separately
transferable witness signature. This is neither encryption nor protection from
rollback of the entire registry or host. The bounded format currently retains
64 associations and 256 replacement operations globally, with explicit capacity
errors. Resetting history to regain capacity is not a supported recovery path.

`DeviceJournal::adopt_account_authority` now explicitly binds an existing
required-witness journal to the original registry and local application revision
through its ordinary image/write-intent/witness transaction. The new authenticated
image variants `QPVLT023`/`QPVLT024` add a 104-byte registry/checkpoint binding;
unbound `QPVLT021`/`QPVLT022` encodings remain unchanged. This is an explicit format
transition: older readers cannot open the new image. The original witnessed head
refuses a restored pre-binding backup. Neither format conversion nor missing
storage is silently recreated during reopen.

`open_anchored_with_account_authority` requires the same registry scope before
replaying any saved adoption intent and rechecks it after witness I/O. Ordinary
open refuses a bound image or pending bound target. Each live local and peer
admission reads the registry's current mapping; post-witness message, ACK and
fanout release checks repeat that admission. A shared registry read lock checks
the selected accounts at one point before returning, while replacement invalidation
takes the write lock before persistence. This does not recall bytes already returned
before a fence. A parent intent that precedes the journal fence resumes through
the existing restricted `AccountRootJournalRecovery`, without reopening old traffic.
Historical peer-delivery accounting preserves its original account and unknown
outbox even when current peer traffic is refused.

This is still a native journal component. Owning installation/enrollment binding,
original successor enrollment coordination, lifetime-capacity migration, foreign
owners and witness-key handoff remain required for managed cutover.
An executed counterexample also remains open: an ordinary old-device message
committed after proposal capture makes that original witness snapshot stale.
The registry correctly retains its original pending intent and refuses to replace
it with a fresh proposal, but currently has no terminal reconciliation path for
this race. Managed orchestration needs a preparation freeze or an authenticated,
durably terminal decision that the original proposal can never commit. An absent
observation, local reset or silent proposal regeneration is insufficient.
Observing a committed historical operation never authorizes its successor if a
later operation has already retired that root.


### Durable preparation freeze component

`AnchorAccountFreezeRequest` binds an original independent approval to the witness,
old cryptographic root and a separate freeze operation ID. Retain that request
before submitting it through the independently authenticated control plane.
`freeze_account` captures all then-current old-account subjects and freezes the
whole namespace in the same witness transaction. An old device can advance before
this transaction and its new head is then included; it cannot change the snapshot
after it commits. Known subjects and future unseen devices are refused through the
ordinary request, trusted enrollment, replacement and renewal admission paths.
Unrelated accounts remain usable. Unclassified legacy entries prevent the freeze.
A root signature alone remains insufficient control-plane authority.

Freeze is a historical preparation fact, distinct from permanent replacement,
delivery, erasure or permission for a successor. No target is enrolled by freezing.
After an uncertain commit, reopen the same witness and retry the original request;
a matching retry returns the retained original snapshot without advancing revision.
A changed request or reused operation under another root conflicts. Absence does
not mean terminal non-commit, and no unfreeze/reset operation is provided. Delayed
pre-freeze operating replies remain possible; local account-authority admission
must still fence release.

The `QPANC016` authenticated witness image retains canonical `QPAFRZ01` snapshots,
including for an empty namespace. Prior layouts and unfrozen `QPARPL01` descriptor
bytes stay unchanged. A frozen replacement uses `QPARPL02`, adding 32 bytes for the
original freeze binding. `frozen_account_replacement_proposal` accepts only the
exact retained freeze; both fresh commit and image validation enforce this binding.
An equal old head is insufficient to reuse an unbound legacy proposal. Actual
replacement still requires independently approved, currently valid target inputs.

`account_freeze_receipt` carries the bounded complete snapshot followed by a
3449-byte signed envelope. Signature purpose **23** authenticates a 72-byte
`QPAFRS01` statement containing the witness and a domain-separated digest of the
complete snapshot. This preserves the existing 16 KiB signed-body ceiling while
supporting all 256 subjects. `verify_account_freeze` requires the independently
retained original request and pin, bounds and parses the complete snapshot, then
checks both signature components and the exact commitment. Neither this receipt
nor its type can substitute for a retirement receipt or a fresh operating reply.

This native component resolves snapshot capture races only when the caller uses
this preparation path. The existing registry counterexample remains a valid
observation for its old read-only proposal path. Managed orchestration must still
persist an original local draft before freezing, reconcile the exact returned
snapshot, obtain independent target approval, and coordinate original enrollment
and child journal fences. The terminal reconciliation below handles target expiry
and competing approvals at the native component boundary; freezing alone does not supply it. A full
witness can still lack room for the successor, and retained freeze/replacement
history requires a bounded lifetime-capacity migration design. Foreign owners,
installed consumer qualification, witness-key handoff and whole-host rollback
protection remain separate work.


### Original local preparation intent

`AnchorAccountReplacementPlan` (`QPAFPL01`, bounded to 8192 bytes) is an independent
approval of a fixed target and one exact future freeze request. Its dedicated
constructor validates the target through existing witness enrollment checks but
does not claim that a transient old-head observation is the approved snapshot.
A retained exact legacy proposal is never implicitly converted into this plan.

`AccountAuthorityStore::begin_preparation` records that plan under the original
application checkpoint before witness freezing. The new `Preparing` state revokes
old leases and denies both old and target authority through the existing journal
admission checks. The `QPAAST02` registry image preserves the plan alongside the
operation for its entire history; images without plans still use the exact prior
`QPAAST01` layout. Older readers reject the new layout. The existing 64-account and
256-operation limits remain; each record can additionally hold one bounded plan.
These are explicit candidate-format transitions, not a released ABI promise.

After reopen, `preparation` returns the same original plan. `replacement` returns
`Suspended` while only the target template exists, so it cannot be mistaken for an
exact witness proposal. `bind_preparation` accepts only an authenticated freeze
whose full original request matches that plan, then fixes the exact snapshot and
enters `Pending`. The immutable plan survives binding and root commitment. No
request, target or bound snapshot is silently regenerated. MAC-authenticated image
validation rejects a committed unbound template or a binding inconsistent with its
original plan. It records a locally verified decision, not a separately retained
transferable freeze signature; witness continuity and whole-host rollback remain
independent assumptions.

The native combination now retains a local plan before freezing, fences real
cached message release, tolerates actual old-device progress after plan creation,
reopens the original registry, binds the exact witness snapshot, resumes the
original restricted journal and selects the successor exactly once. Each of the
three registry mutations has typed pre/post-sync recovery tests. Three actual
owned child processes are also killed after the corresponding database commits
and before API return; each reopens the same registry/key/identity, retains its
original plan and retries without selecting the root twice. The original witness
remains independently retained by the parent in this experiment. This is still a
native composition, not the owning installed workflow, network qualification or
simultaneous witness-loss test. Original successor enrollment orchestration,
integration of terminal reconciliation, lifetime-capacity migration and foreign owners
remain required. `Preparing` or `Pending` must never
be reset to regain old traffic when an outcome is unknown.

### Permanent non-commit and approved successor reconciliation

`close_account_replacement` permanently closes one exact original proposal.
`close_account_preparation` instead closes the original plan, including when a
competing freeze prevented that plan from obtaining a snapshot. Both are trusted
control-plane actions requiring independently retained approval. They do not
depend on current target validity or an unchanged old head. An already committed
operation remains `Committed`; a different statement reusing its operation ID
conflicts. `Unavailable`, silence and transport errors never mean non-commit.

The witness retains at most 256 closure records in `QPANC017`, under the existing
one-MiB image bound: an exact proposal uses 65 bytes, and a plan uses 97 bytes.
The latter binds the original plan and freeze request, denying every snapshot
variant of that same approved target. Conflicting reuse of the operation ID is
rejected. Closure and commitment of one operation cannot coexist in a valid image.
This is permanent bounded history; eviction and capacity migration remain open.
Images without closures retain their prior layout. Older readers reject V17.

`closed_account_replacement_receipt` signs purpose 24 over
`QPARNM01[8] || witness_binding[32] || proposal_binding[32]`.
`closed_account_preparation_receipt` signs purpose 25 over
`QPAPCL01[8] || witness_binding[32] || plan_binding[32]`.
Each is a 3449-byte hybrid-signature envelope. The corresponding pinned verifier
returns a private typed fact for the independently retained original expectation.
A plan non-commit **does not prove or cancel a freeze**: an already dispatched
original freeze may still arrive. Neither receipt unfreezes the old account,
enrolls a target, authorizes traffic or proves delivery or erasure.

The local registry retains typed exact/plan closure or explicit committed-winner
adoption in `QPAAST03`. `Closed` keeps the old application authority suspended.
A separately approved new plan may follow it, retaining any known original
freeze binding. `adopt_committed_replacement` requires both an independently
approved exact winner and its authenticated retirement. A target seen only in
closed attempts of the same application may be adopted; cross-application and
formerly active root reuse remain forbidden. An actual retirement matching an
original preparation can also recover a lost local binding acknowledgement.
`operation_checkpoint` recovers an original expectation, never current permission.

For an already fenced journal, `AccountRootJournalTransition` pairs authenticated
original non-commit with an independently approved next proposal.
`transition_after_noncommit` commits only its fence descriptor and a bounded
history entry. `resume_transition` reconciles that same transition after a lost
return, with the original path, key, identity, device and witness. It preserves
the encrypted image, pending intent and original message identities byte for byte;
it returns a restricted recovery owner. It cannot overwrite a retained retirement,
reset to an earlier proposal, or use missing storage to create a new journal.

The `QPARJF02` fence appends at most 256 entries of 129 bytes: original operation,
previous and next proposal commitments, closure kind, and closure commitment.
Its MAC protects local history, which is not a transferable witness proof. Retain
full original expectations and recreate the authenticated closure under the same
witness on recovery. Entries must form a contiguous chain with unique operations
and the final commitment must match the current proposal. Unchanged fences keep
the original `QPARJF01` encoding. Registry and witness remain independent owners;
this API does not make all their databases one atomic transaction.

Native regression covers a target expiring at time 160, refusal at time 170, and
an independently approved valid successor committed at 170 under the same freeze.
Real unacknowledged ciphertext and a pending encrypted write remain unchanged.
The new witness closure and local terminal/journal transitions exercise every
measured pre/post-sync fault boundary; journal handoff also has actual process
loss before and after commit without API return. Proof tests reject changed
expectations, witness pins, signature components and purpose substitution.
Authenticated history tests reject broken links, repeated operations and a changed
retry. These establish the native composition, not a fully integrated installed
root-replacement workflow, independent implementation, or cross-platform result.

### Enrollment-owned terminal transition

`AccountRootEnrollmentRecovery::transition_after_noncommit` now coordinates the
original parent and child. It first authenticates the original parent, verifies
the closure against its retained proposal and validates the approved next proposal
against the actual child image and pending intent while holding the child lease.
An incompatible local head fails before replacing the parent intent. A missing
child can never be supplied by creating another journal.

Only after that validation does the enrollment commit the next proposal and
transition history. It then reconciles its child journal and returns the restricted
owner. A failure consumes all local owners and can follow either database commit;
`resume_transition` uses the same original closure and independent approval to
reconcile either side of those commits. Original enrollment bytes, signing
identity, journal identity and encrypted image/pending bytes remain unchanged.
This coordinates two commits; it does not claim a cross-database atomic commit.

The parent uses `QPERPL02` only when it has transition history; ordinary root
fences retain the exact `QPERPL01` layout. It reuses the journal's bounded history
codec and validation, including its 256-entry limit. The parent MAC and original
enrollment binding authenticate that locally retained authorization. It is not a
transferable witness receipt and does not protect a rollback of the whole host.
Older readers explicitly reject the extended parent layout.

After the new parent intent commits, `resume_original` with that exact next
proposal can restore a compatible older child backup using the parent's retained
history. The child must be unfenced or retain an exact prefix of that history;
its original encrypted state must still satisfy the approved witnessed head.
A conflicting child proposal, unrelated history, missing file or incompatible
state fails explicitly. The crate-internal parent checkpoint is not an external
journal API for supplying arbitrary history. A retained parent retirement is
reapplied to the child before returning the restricted owner.

Native regression now covers an original target expiring at 160 and activation
of a separately enrolled successor through the actual `EnrolledDevice` API at
170, under fresh witness admission. It also covers multiple abandoned targets,
restoration of child backups taken before a fence and after an intermediate
transition, six typed parent sync faults and four actual process-loss cuts around
the parent-first/child-second commits. A red/green regression records the new
implementation's initial validation-order defect and its correction. These tests
compose the registry with enrollment recovery; they do not yet make the registry,
target enrollment and foreign service lifetimes one managed product owner.
Installed language adapters, that owning orchestration and the remaining release
and platform qualifications remain required.

### Registry admission through enrollment activation

`DeviceEnrollment::with_account_authority` takes the independently retained
`JournalAccountAuthority` for the original application checkpoint and registry.
It checks the original account and family against that live owner; it does not
associate a new root, infer approval from a network message or create a registry.
Supply it again when reopening the same enrollment. Registry closure invalidates
its access descriptors; reopening the original registry requires fresh access from
that owner, not revival of an old descriptor.

Activation opens an already bound journal only with the matching descriptor. For
an explicitly selected initial binding, it checks original registry permission,
reconciles the original witnessed journal and validates installation genesis before
committing the installation. It then persists the registry binding through the
existing witnessed journal transaction before returning `EnrolledDevice`. A sync
or witness error may follow commit and returns no owner: retry with the original
paths, keys, identity and descriptor. Do not switch to the unmanaged entry point.
An already pending binding must match the original descriptor; authentication,
scope or storage failure never triggers automatic adoption or a new registry.

The descriptor stays with the enrollment owner through installation reconciliation,
credential renewal, policy continuation and roster preparation. These paths reuse
the existing journal engine and storage formats. The ordinary unmanaged activation
entry remains available for unbound journals and explicitly refuses a bound journal
when its required descriptor is missing. The optional runtime field is not a
replacement for independently retained registry configuration.

New credential, independent-policy and roster commit commands additionally check
the authenticated journal and pending target's original registry scope before
dispatch. Missing, different, closed or suspended authority cannot authorize a new
commit. Exact historical observation, installation of an already witnessed target,
terminal retention and acknowledgement remain recovery operations; they do not
grant traffic authority or remove the stored registry binding. Already admitted
commands can still be in flight during concurrent closure; historical outcomes
must be reconciled rather than rewritten as no-commit.

Native tests exercise first Creating activation, exact managed reopen, another
registry refusal, real prekey generation/signing and replay, cached publication
refusal after registry closure, closure after an actual witness reply, and every
measured parent activation sync fault. Credential renewal crosses original expiry
at 160 and activates its successor at 170 with the original signer. Fresh commit
tests cover credential, policy and roster paths; a lost credential commit reply is
historically recovered after registry closure without dispatching another commit.
These are native owner-integration results, not installed foreign-language,
physical-device, independent-endpoint or final product-ABI qualification. The
application still owns the original registry lifetime. Separate C package
workloads exercise registry ownership and managed session traffic; Swift/Kotlin
registry adapters and the complete root-replacement controller remain required.


### Registry admission through standalone installation entry points

`InstallationAdmission::managed` carries the original required witness and
`JournalAccountAuthority` together into `DeviceInstallation::activate`,
`reopen_session` and `reopen_continued_session`. Existing unmanaged callers may
continue passing `Option<AnchorClient>`; bound journals still reject that form.
The private admission fields prevent callers from substituting an unanchored
managed mode. Activation alone may explicitly adopt an unbound witnessed journal,
using the same genesis-before-binding ordering as enrollment. Session reopening
requires an existing exact registry binding and never performs adoption.

These entry points keep the original registry checks through current-policy and
completed-continuation admission. The continued-session regression uses real
independent witness G/T approval, expiry of P0, both enrolled endpoints and an
actual rekey before standalone reopening at time 170. The original archived
session and cached ciphertext survive; registry closure denies further release.
Other regressions cover initial activation, refusal to adopt during reopening,
missing/wrong/closed registry admission before dispatch and closure immediately
after a signed witness reply. This is native entry-point coverage. The C
installed-package workload additionally exercises a managed initiator against an
ordinary C receiver, same-ID delivery recovery, rekey and cached-owner closure.
It uses the same native engine on one host. Other language/platform adapters,
independent implementations and the full root-replacement controller remain
separate qualification boundaries.


### First-account enrollment and admission before creation

`DeviceEnrollment::provision_with_account_authority` checks the independently
selected registry against the approved account root and family before creating
an enrollment record. `open_with_account_authority` performs the same admission
before opening original state. Known scope refusal leaves no newly created
registration. Later failures can still follow I/O, including concurrent registry
closure; preserve and reconcile the same original intent. These constructors
reuse the existing provisioning/opening engine and do not change storage formats.

A first device cannot depend on an already-issued credential to request its own
registration. The ordinary approved intent first produces its original signed
request. The independently authorizing issuer verifies that request, issues its
real credential and roster, and associates that account in the host registry.
`select_account_authority` then attaches the live original descriptor to the same
registration owner before acceptance, witness enrollment and activation. Selection
performs no I/O and known admission refusal leaves the previous selection intact.
`with_account_authority` remains the consuming Rust convenience form. Request
possession is still not membership or operating permission; the existing policy,
credential, witness and durable activation checks remain mandatory.

The C entry `qpc_authority_v1_select_enrollment` exposes that non-I/O selection on
an enrollment handle. It validates the size header first, preserves a live
registration after a known scope refusal, and rejects an already operational
device handle. Current C-boundary regressions use the first real request to issue
and associate a new account, retain it across a failed witness admission, require
the original registry on subsequent activation, and refuse a known wrong root
before record creation while allowing the correct original intent afterward.
An additional installed C executable workload now carries that first request
through real issuance, subsequent registry selection, witness activation,
reopening and recovery of an original uncertain-delivery message. It covers fixed
and recoverable SDK roots with signed TCP and mutual TLS witnesses, and checks
that omitting the selected registry on activation returns `211`. Its control
plane independently associates the issued account; it does not copy a device
identity or installation store into the new installation. These same-host
processes share the native engine. Swift and Kotlin owners also exercise the same
first-use flow, with explicit-close and final ARC/Cleaner revocation checks. The
Kotlin workload observes actual collection and completed native cleanup under
Serial and G1 GC. Managed policy renewal, direct managed existing-owner language
constructors and the full account replacement controller require separate
integration and qualification.
