import Foundation
import Darwin

private struct ActiveRelay {
    let cancellation: Int32
    let task: Task<Int32, Never>
}

func usbOperation(arguments: [String], source: URL, mode: String, run: String) async throws {
    var active: [ActiveRelay] = []
    let operation = Result {
        let routes = [("peer", "connection-address"), ("witness", "witness-address")]
        for (route, file) in routes where FileManager.default.fileExists(atPath: source.appendingPathComponent(file).path) {
            var descriptors: [Int32] = [-1, -1, -1, -1]
            var ports: [UInt16] = [0, 0]
            let code = qpc_test_relay_prepare(&descriptors, &ports)
            guard code == 0 else { throw ClientError("USB relay preparation errno=\(code)") }
            let transport = descriptors[0], local = descriptors[1], cancellation = descriptors[2], port = ports[0]
            let task = Task.detached {
                route.withCString { routePointer in
                    run.withCString { runPointer in
                        qpc_test_relay_run(transport, local, cancellation, port, routePointer, runPointer)
                    }
                }
            }
            active.append(ActiveRelay(cancellation: descriptors[3], task: task))
            try Data("127.0.0.1:\(ports[1])".utf8).write(to: source.appendingPathComponent(file), options: .atomic)
        }
        try ConfigurationCommands.run(arguments)
    }
    var errors: [Int32] = []
    for relay in active {
        let stopped = qpc_test_relay_stop(relay.cancellation)
        if stopped != 0 { errors.append(stopped) }
    }
    for relay in active {
        let result = await relay.task.value
        if result != 0 { errors.append(result) }
    }
    guard errors.isEmpty else { throw ClientError("USB relay errors=\(errors); SDK outcome=\(operation)") }
    print("QPC_IOS_RELAY_EXIT status=0")
    try operation.get()
}
