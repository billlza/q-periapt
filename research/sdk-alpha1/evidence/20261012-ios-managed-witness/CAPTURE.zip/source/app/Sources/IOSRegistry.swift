import Foundation
import Darwin
import QPeriaptContinuity

func createRegistry(source: URL, path: String, output: URL) throws {
    let input = source.appendingPathComponent("registry-public", isDirectory: true)
    let trust = try AccountAuthorityTrust(identity: AccountAuthorityID(bytes: exact(input, "registry-id", 32)),
        family: exact(input, "family", 32), witness: exact(input, "witness-id", 32), publicKey: exact(input, "witness-public", 1985))
    guard mkdir(path, 0o700) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    try ContinuityAccountAuthority.provisionWrappingKey(path: path)
    let registry = try ContinuityAccountAuthority.prepareCreate(path: path, trust: trust)
    let outcome = Result {
        try registry.finishOpen()
        let application = try ApplicationAccountID(bytes: exact(input, "application", 32))
        let pin = try AccountPin(account: AccountID(bytes: exact(source, "trusted-account", 32)),
            root: exact(source, "enrollment-root", 1985), family: trust.family,
            checkpoint: RosterCheckpoint(version: counter(exact(source, "trusted-roster-version", 8)[...]), digest: exact(source, "trusted-roster-digest", 32)))
        let current = try registry.associate(application: application, pin: pin,
            certificate: load(source, "grant-certificate", 8192), roster: load(source, "grant-roster", 65536))
        guard current.revision == 1, try registry.checkpoint(application: application) == current else { throw ClientError("initial account checkpoint") }
        let peer = try AccountPin(account: AccountID(bytes: exact(input, "peer-account", 32)),
            root: exact(input, "peer-root", 1985), family: trust.family,
            checkpoint: RosterCheckpoint(version: counter(exact(input, "peer-roster-version", 8)[...]), digest: exact(input, "peer-roster-digest", 32)))
        let peerCheckpoint = try registry.associate(application: ApplicationAccountID(bytes: exact(input, "peer-application", 32)), pin: peer,
            certificate: load(input, "peer-certificate", 8192), roster: load(input, "peer-roster", 65536))
        guard peerCheckpoint.revision == 1 else { throw ClientError("initial peer account checkpoint") }
        var revision = current.revision.bigEndian
        let bytes = current.application.bytes + withUnsafeBytes(of: &revision) { Array($0) } + current.account.bytes
        try Data(bytes).write(to: output, options: .withoutOverwriting)
    }
    do { try registry.close() } catch { throw ClientError("registry cleanup: \(error); operation: \(outcome)") }
    try outcome.get()
    print("QPC_CONFIGURATION_AUTHORITY_CREATED")
}
