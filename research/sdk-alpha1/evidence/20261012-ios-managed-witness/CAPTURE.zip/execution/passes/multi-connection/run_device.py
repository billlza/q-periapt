from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import json,hashlib,os,subprocess,time
from device_support import OUT,APP,BUNDLE,selected,command,installed
import rust_sdk_profile as sdk
root=Path.cwd();device=selected();assert Path(APP['app']).is_dir();fixture=json.loads((OUT/'FIXTURE.json').read_text());before=OUT/'device-control';before.mkdir()
if installed(device,before/'before'):raise RuntimeError('run-owned app already exists; refusing overwrite')
state={'completed':False,'live_producer':True,'cleanup_armed':True,'bundle_id':BUNDLE,'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'app_executable_sha256':hashlib.sha256((Path(APP['app'])/'ContinuityIOSRunner').read_bytes()).hexdigest()};path=OUT/'DEVICE_STATE.json';path.write_text(json.dumps(state,indent=2)+'\n')
try:
 command(device,['device','install','app',APP['app']],before/'install',timeout=60)
 if not installed(device,before/'installed'):raise RuntimeError('installation not observed')
 public=OUT/'device-public';public.mkdir();env=dict(os.environ,QPC_CONFIGURATION_CLIENT=str(OUT/'ios_client.py'),QPC_CONFIGURATION_LANGUAGE='Swift',QPC_IOS_PUBLIC=str(public),QPC_CONFIGURATION_RECEIVER=str(root/'target/continuity-local-policy-roster/engine-debug/qpc-c-client'))
 sdk.command([fixture['binary'],'--exact','ios_configuration_creates_and_reopens_device_identity','--nocapture'],OUT/'device-fixture',root,environment=env)
 records=[json.loads(p.read_text()) for p in (OUT/'device-execution').glob('*/RESULT.json')]
 if len(records)!=20 or any(not r['completed'] for r in records):raise RuntimeError('incomplete iOS command matrix')
 for profile in ['fixed','recoverable']:
  p=public/profile
  if p.joinpath('request.bin').read_bytes()!=p.joinpath('resumed.bin').read_bytes() or p.joinpath('request.bin').read_bytes()!=p.joinpath('after-activation.bin').read_bytes():raise RuntimeError('identity changed')
 state['completed']=True;state['operations']=len(records)
finally:
 state['live_producer']=False
 # Reconcile installation even when install itself returned an unknown result.
 for attempt in range(6):
  if installed(device,before/f'cleanup-query-{attempt}'):
   command(device,['device','uninstall','app',BUNDLE],before/f'uninstall-{attempt}',allow_failure=True)
  else:
   state['cleanup_armed']=False;break
 if state['cleanup_armed']:
  path.write_text(json.dumps(state,indent=2)+'\n');raise RuntimeError('device cleanup unresolved')
 path.write_text(json.dumps(state,indent=2)+'\n')
print('iPhone first-use configuration: 20 launches, two fresh identities, original TLS session/message recovery passed',flush=True)
