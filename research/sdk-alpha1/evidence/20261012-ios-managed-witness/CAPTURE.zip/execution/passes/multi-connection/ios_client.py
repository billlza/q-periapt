#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import sys,json,hashlib,secrets,shutil
from device_support import OUT,BUNDLE,selected,command

def main():
 args=sys.argv[1:]
 if len(args)!=5:raise RuntimeError('configuration argument count')
 mode,profile,src,target,output=args;source=Path(src);destination=Path(output)
 if mode not in {'arc-capacity','cancel-create','create','reconcile','resume','enroll-local','connect','uncertain-send','retry-send'} or profile not in {'fixed','recoverable'}:raise RuntimeError('unexpected mode/profile')
 if not source.is_dir() or source.is_symlink() or not destination.is_absolute() or destination.exists():raise RuntimeError('input/output paths')
 case=hashlib.sha256(target.encode()).hexdigest()[:32];run=secrets.token_hex(16);capture=OUT/'device-execution'/run;capture.mkdir(parents=True)
 allowed={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope','recovery-root','recovery-enrollment','grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest','connection-address','connection-initiation','connection-session','connection-message'}
 files=list(source.iterdir())
 for x in files:
  if x.name=='peer' and x.is_dir() and not x.is_symlink():
   peer_names={'family','directory','bootstrap.bundle','tls-peer','tls-peer-name'}|{p+s for p in ('initiator','responder') for s in ('-account','-root','-roster-version','-roster-digest','-device','-generation')}
   if any(not f.is_file() or f.is_symlink() or f.name not in peer_names or f.stat().st_size>65536 for f in x.iterdir()):raise RuntimeError('unapproved peer input')
  elif not x.is_file() or x.is_symlink() or x.name not in allowed or x.stat().st_size>65536:raise RuntimeError('unapproved or oversized provisioning input')
 device=selected();domain=['--domain-type','appDataContainer','--domain-identifier',BUNDLE]
 # Only provisioning inputs are transferred. Native identity and journals remain on the iPhone.
 command(device,['device','copy','to','--source',str(source),'--destination','Documents/inputs-'+case,*domain],capture/'inputs')
 if mode in {'connect','uncertain-send','retry-send'}:
  import usb_transport
  result=usb_transport.launch(device,BUNDLE,mode,profile,case,run,capture,{route:(source/name).read_text() for route,name in [('peer','connection-address'),('witness','witness-address')] if (source/name).exists()})
 else:
  result,_=command(device,['device','process','launch','--console',BUNDLE,mode,profile,case,run],capture/'launch',timeout=60)
 expected=f'QPC_IOS_CONFIGURATION_PASS mode={mode} profile={profile} run={run}\n'.encode()
 if result.stdout.splitlines().count(expected.rstrip(b'\n'))!=1 or result.stdout.splitlines().count(b'The app terminated with the exit code 0.')!=1 or b'QPC_IOS_CONFIGURATION_FAIL' in result.stdout+result.stderr:raise RuntimeError('missing terminal iOS operation proof')
 command(device,['device','copy','from','--source','Documents/receipt-'+run+'.txt','--destination',str(capture/'receipt.txt'),*domain],capture/'receipt-copy')
 if (capture/'receipt.txt').read_bytes()!=expected:raise RuntimeError('container receipt differs')
 if mode=='resume' and result.stdout.splitlines().count(b'QPC_IOS_STORAGE_BOUNDARY_PASS symlink=203 mode=203')!=1:raise RuntimeError('storage boundary negatives missing')
 markers={'arc-capacity':'ARC_PASS','cancel-create':'CREATE_CANCELLED','enroll-local':'LOCAL_ACTIVE','connect':'CONNECTION_PASS','uncertain-send':'UNKNOWN_COMMITTED','retry-send':'ORIGINAL_ACKNOWLEDGED'}
 if mode not in {'arc-capacity','cancel-create'}:
  command(device,['device','copy','from','--source','Documents/result-'+run+'.bin','--destination',str(capture/'public-result.bin'),*domain],capture/'result-copy')
  data=(capture/'public-result.bin').read_bytes()
  if not 1<=len(data)<=65536:raise RuntimeError('public result width')
  with destination.open('xb') as f:f.write(data)
 (capture/'RESULT.json').write_text(json.dumps({'completed':True,'mode':mode,'profile':profile,'case':case,'run':run,'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'public_result_sha256':hashlib.sha256(data).hexdigest() if mode not in {'arc-capacity','cancel-create'} else None},indent=2)+'\n')
 print('QPC_CONFIGURATION_'+markers.get(mode,'REQUEST_PASS'))
if __name__=='__main__':
 try:main()
 except Exception as error:
  print(str(error),file=sys.stderr);sys.exit(1)
