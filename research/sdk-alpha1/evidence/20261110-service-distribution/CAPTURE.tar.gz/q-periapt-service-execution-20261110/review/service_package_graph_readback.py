#!/usr/bin/env python3
"""Read back a real service distribution against the selected SDK/engine manifests.

This independently assembles candidate package rows from unmodified source
manifests and invokes the repository's package-graph validator. It does not
validate a full specification lock, rebuild SDK archives, qualify account
protocols, authorize release, or publish anything.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tomllib


RECEIPT = "CONTINUITY_SERVICE_PACKAGE_GRAPH_READBACK.json"
ENGINE_MANIFEST = "research/continuity-identity-candidate/Cargo.toml"
COPIES = "input-manifests"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
    path.chmod(0o644)


def plain_directory(path):
    path = path.absolute()
    require(path.is_dir() and not path.is_symlink() and path.resolve() == path,
            "selected directory must be canonical and plain: " + str(path))
    return path


def load_tools(source):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source / "artifact"))
    modules = [importlib.import_module(name) for name in (
        "rust_sdk_profile", "continuity_release_manifest", "continuity_service_package", "git_provenance")]
    require(all(Path(module.__file__).resolve().parent == source / "artifact" for module in modules),
            "validator modules do not belong to the selected source")
    return modules


def source_identity(source, sdk, git):
    commit, dirty = sdk.inspect_package_source(source, allow_dirty=False)
    require(not dirty, "selected source is dirty")
    return {"commit": commit, "tree": git.run_git_text(source, ["rev-parse", "--verify", commit + "^{tree}"])}


def copied_source_rows(source, output, sdk):
    """Preserve complete original manifests and independently derive their edges."""
    selected = [f"crates/{name}/Cargo.toml" for name in sdk.COHORT] + [ENGINE_MANIFEST]
    originals = {relative: sdk.snapshot(source / relative) for relative in ["Cargo.toml", *selected]}
    documents = {relative: tomllib.loads(value.data.decode("utf-8")) for relative, value in originals.items()}
    root_workspace = documents["Cargo.toml"]["workspace"]
    require(type(root_workspace) is dict, "root Cargo workspace is absent")
    copies = output / COPIES
    copies.mkdir(mode=0o700)
    references = {}
    for relative, value in originals.items():
        target = copies / relative
        write_new(target, value.data)
        references[relative] = {"path": f"{COPIES}/{relative}", "bytes": value.size, "sha256": value.sha256}

    by_name, definitions = {}, {}
    for relative in selected:
        document, package = documents[relative], documents[relative]["package"]
        name = package["name"]
        is_engine = relative == ENGINE_MANIFEST
        require(name == ("q-periapt-continuity" if is_engine else Path(relative).parent.name),
                "source package name differs: " + relative)
        require(name not in by_name, "source package name is duplicated")
        own_workspace = document.get("workspace")
        require(own_workspace is None or type(own_workspace) is dict, "package workspace is malformed")
        workspace = root_workspace if own_workspace is None else own_workspace
        version = package["version"]
        if version == {"workspace": True}:
            version = workspace["package"]["version"]
        require(version == "0.2.0", "selected package version differs: " + name)
        by_name[name] = {"id": "continuity-engine" if is_engine else name,
                         "role": "engine" if is_engine else "sdk", "name": name,
                         "version": version, "format": "cargo", "metadata": references[relative],
                         "workspace": references["Cargo.toml"] if own_workspace is None else None,
                         "dependencies": [], "interfaces": [], "artifacts": [], "assessments": []}
        definitions[name] = document, workspace

    for name, (document, workspace) in definitions.items():
        observed = set()
        sections = [document, *document.get("target", {}).values()]
        for section in sections:
            for field in ("dependencies", "build-dependencies"):
                for alias, raw in section.get(field, {}).items():
                    specification = {"version": raw} if isinstance(raw, str) else dict(raw)
                    if "workspace" in specification:
                        require(specification["workspace"] is True
                                and set(specification) <= {"workspace", "features", "optional", "default-features"},
                                "inherited dependency overrides source identity")
                        inherited = workspace.get("dependencies", {}).get(alias)
                        specification = {"version": inherited} if isinstance(inherited, str) else dict(inherited)
                    target = specification.get("package", alias)
                    if target.startswith("q-periapt-"):
                        require(target in by_name, "internal dependency is missing from the selected graph: " + target)
                        require(specification.get("version") == "=" + by_name[target]["version"],
                                "internal dependency version differs: " + target)
                        observed.add(by_name[target]["id"])
        by_name[name]["dependencies"] = sorted(observed)

    # Use actual edges, retaining the cohort's declared order only as a tie-break.
    remaining, rows, completed = list(by_name.values()), [], set()
    while remaining:
        available = next((row for row in remaining if set(row["dependencies"]) <= completed), None)
        require(available is not None, "selected source graph has a cycle or missing dependency")
        rows.append(available)
        completed.add(available["id"])
        remaining.remove(available)
    require(len(rows) == 13 and len(sdk.COHORT) == 12, "selected SDK/engine cohort size differs")
    return rows, originals


def readback(source, output):
    source, output = plain_directory(source), plain_directory(output)
    sdk, manifest, service, git = load_tools(source)
    selected_source = source_identity(source, sdk, git)
    receipt_path = output / RECEIPT
    require(not receipt_path.exists() and not receipt_path.is_symlink(), "readback receipt already exists")
    require(not (output / COPIES).exists() and not (output / COPIES).is_symlink(), "input manifest copies already exist")
    receipt = {"schema_version": 1, "kind": "qperiapt.independent_service_candidate_package_graph",
               "completed": False, "stage": "candidate", "source": selected_source,
               "release_claim_eligible": False, "publication_performed": False,
               "full_spec_lock_verified": False,
               "scope": "Exact original 12-SDK and engine Cargo manifest graph plus the actual service distribution row, artifacts and assessments; candidate package consistency only."}
    try:
        inputs = manifest.Inputs(output)
        row_snapshot = sdk.snapshot(output / service.ROW)
        row_reference = {"path": service.ROW, "bytes": row_snapshot.size, "sha256": row_snapshot.sha256}
        row = inputs.json(row_reference)
        require(row.get("id") == "continuity-services" and row.get("role") == "service"
                and row.get("format") == "distribution" and row.get("name") == service.NAME
                and row.get("version") == service.VERSION and row.get("dependencies") == ["continuity-engine"],
                "actual service row identity or selected engine differs")
        require(row["metadata"]["path"] == service.IDENTITY
                and [ref["path"] for ref in row["assessments"]] == [service.REPORT, service.INSTALLATION],
                "service row does not identify both original producer receipts")
        report, installed = [inputs.json(ref, maximum=manifest.MAX_ASSESSMENT) for ref in row["assessments"]]
        for document, kind in ((report, "qperiapt.continuity_service_package"),
                               (installed, "qperiapt.continuity_service_installation")):
            require(document.get("kind") == kind and document.get("completed") is True
                    and "failure" not in document and document.get("source") == selected_source,
                    "service producer receipt is incomplete or belongs to another source")
            require(row["artifacts"] == [document.get("archive")], "service archive reference differs")
        require(report.get("name") == service.NAME and report.get("version") == service.VERSION
                and report.get("source_package") == service.source_package(source)
                and report.get("installation") == row["assessments"][1]
                and report.get("target") == installed.get("target"),
                "service build and installation provenance differ")
        # Pin required artifact bytes before creating any copied manifests.
        for reference in row["artifacts"]:
            inputs.read(reference, maximum=manifest.MAX_ARTIFACT, binary=True)
        rows, originals = copied_source_rows(source, output, sdk)
        rows.append(row)
        observed = manifest._packages(rows, inputs, stage="candidate", source=selected_source, interfaces={})
        inputs.unchanged()
        for relative, original in originals.items():
            current = sdk.snapshot(source / relative)
            require((current.size, current.sha256) == (original.size, original.sha256),
                    "original manifest changed during readback: " + relative)
        require(source_identity(source, sdk, git) == selected_source, "source changed during readback")
        receipt.update(completed=True, package_rows=rows, validation=observed,
                       source_manifests={relative: {"bytes": value.size, "sha256": value.sha256}
                                         for relative, value in originals.items()},
                       observed_inputs=list(inputs.refs.values()),
                       validator_sha256=sdk.snapshot(source / "artifact/continuity_release_manifest.py").sha256,
                       script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    except BaseException as error:
        receipt["failure"] = str(error)
        raise
    finally:
        write_new(receipt_path, canonical(receipt))
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    receipt = readback(args.source, args.output)
    print(json.dumps({"kind": receipt["kind"], "completed": receipt["completed"],
                      "packages": receipt["validation"]["packages"], "receipt": str(args.output / RECEIPT)}))


if __name__ == "__main__":
    main()
