from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head='1dc0f16fef08de67a2607dafa43afbb8876ab77d';run=39203490343
metadata=json.loads(subprocess.check_output(['gh','api',f'repos/billlza/q-periapt/actions/runs/{run}'],timeout=60))
assert metadata['head_sha']==head and metadata['status']=='completed' and metadata['conclusion']=='success'
(out/'RUN_TERMINAL.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=json.loads((out/'READBACK_ubuntu-24.04-macos-15.json').read_text());assert len(rows)==2
entries={}
for row in rows:
    assert row['head']==head and row['run']==run and len(row['test_names'])==26 and row['members']==16
    folder=out/row['platform'];data=(folder/'upstream.zip').read_bytes()
    assert len(data)==row['artifact_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==row['artifact_sha256']
    for p in sorted(folder.rglob('*')):
        if p.is_file():entries['local/'+p.relative_to(out).as_posix()]=p.read_bytes()
for p in sorted(out.iterdir()):
    if p.is_file() and p.suffix in {'.json','.py','.stdout','.stderr'}:entries['local/'+p.name]=p.read_bytes()
sources=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
assert len(sources)==30
for name in sources:entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-hosted-reference-http';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for n,v in manifest.items():
        b=z.read(n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
data=archive.read_bytes()
checks={'head':head,'run':run,'source_files':len(sources),'readbacks':rows,'capture':{'bytes':len(data),'members':len(entries),'sha256':hashlib.sha256(data).hexdigest()},'scope':'Terminal hosted debug and release tests, strict Clippy/build and exact artifact/source/lock/architecture/compiler checks. Per profile26 entries include25 behavioral tests and1 dispatcher. Three actualTCP enrollment scenarios cover host authorization, body-disconnect/original-response recovery, sameDBrestart and reapproval. Existing14 SIGKILL boundaries remain library tests; no newHTTPcuts. SoftwareUV andpolicyfamily are fixtures. No browser enrollment controls, installed independent-client live-policy acceptance, deployed HTTPS, full replacement or release admission at this frozen head.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text("""# Hosted enrollment HTTP checks

[Run 39203490343](https://github.com/billlza/q-periapt/actions/runs/39203490343)
completed successfully at `1dc0f16fef08de67a2607dafa43afbb8876ab77d` on
Linux x86_64 and Apple Silicon. Both profiles ran all 26 source-derived test
entries (25 behavioral tests and one child dispatcher), with 20 library and 6
binary results. Formatting, strict all-target Clippy and release builds passed.

Three enrollment scenarios use actual loopback TCP, software WebAuthn signatures
and native SDK requests. They cover account/Origin/input isolation, exact result
recovery after disconnect before consuming the issuance body, original-database
restart and fresh login, explicit roster-conflict reapproval, cancellation and
root suspension. The frozen library suite retains 14 distinct SIGKILL boundaries;
these are not new HTTP cuts. Software user verification and policy family remain
fixtures; no physical or live signed-policy admission is claimed.

Readback checked exact head/lock/compiler/architecture, all debug and release test
names and summaries, and both 16-member archives against their GitHub digests.
The capture contains those archives, terminal metadata, reader and 30 exact
app/workflow source files. SDK dependencies are identified by the pinned Git head.
Executables and private/child-marker state were not exported or replayed. No live
job logs were read.

Browser enrollment controls and installed independent-client acceptance were not
implemented at this pinned head. Newer browser edits in the current worktree are
not covered by this receipt. Deployed HTTPS, full lifecycle and release admission
remain separate gates. This optional host does not make signup an SDK requirement.
""")
print(json.dumps(checks['capture']))
