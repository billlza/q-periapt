"""Seal exact terminal records and the optional app's Git source, not private state."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
HEAD = "c891e32a874d76f14a8e8e6247517282dfefb77d"
DEST = REPO / "research/sdk-alpha1/evidence/20261019-hosted-reference-account"
DEST.mkdir(exist_ok=False)
entries = {}
for name in ["RUN_TERMINAL.json", "ARTIFACTS.json", "READBACK.json", "readback.py", "readback.stdout", "readback.stderr", "seal.py"]:
    entries["local/" + name] = (ROOT / name).read_bytes()
for platform in ["ubuntu-24.04", "macos-15"]:
    for path in sorted((ROOT / platform).rglob("*")):
        if path.is_file():
            entries["local/" + path.relative_to(ROOT).as_posix()] = path.read_bytes()
files = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "--", "research/continuity-reference-app", ".github/workflows/reference-account.yml"], cwd=REPO).decode().splitlines()
assert len(files) == 13
for name in files:
    entries["source/" + name] = subprocess.check_output(["git", "show", HEAD + ":" + name], cwd=REPO)
manifest = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in sorted(entries.items())}
entries["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
capture = DEST / "CAPTURE.zip"
with zipfile.ZipFile(capture, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
with zipfile.ZipFile(capture) as z:
    assert set(z.namelist()) == set(entries) and z.testzip() is None
    for name, item in manifest.items():
        data = z.read(name)
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
    assert z.read("local/ubuntu-24.04/upstream.zip") == (ROOT / "ubuntu-24.04/upstream.zip").read_bytes()
    assert z.read("local/macos-15/upstream.zip") == (ROOT / "macos-15/upstream.zip").read_bytes()
data = capture.read_bytes()
assert len(data) < 50 * 1024 * 1024
checks = {
    "head": HEAD,
    "run": 39190947340,
    "source_files": {name: manifest["source/" + name]["sha256"] for name in files},
    "readbacks": json.loads((ROOT / "READBACK.json").read_text()),
    "capture": {"bytes": len(data), "members": len(entries), "sha256": hashlib.sha256(data).hexdigest()},
    "scope": "Exact terminal hosted outputs and original artifact digests. Eight tests per supported host use a software authenticator. This is not device enrollment, hardware authentication, deployed service, installed application or release qualification. The source snapshot contains the app and workflow; SDK dependency sources remain identified by the exact Git commit. Build binary hashes are producer observations; executable bytes were not exported.",
}
(DEST / "CHECKS.json").write_text(json.dumps(checks, indent=2) + "\n")
(DEST / "README.md").write_text("""# Hosted optional reference-account checks

[Run 39190947340](https://github.com/billlza/q-periapt/actions/runs/39190947340)
completed successfully at `c891e32a874d76f14a8e8e6247517282dfefb77d` on
Linux x86_64 and Apple Silicon. Both terminal artifacts were downloaded after
completion, checked against their GitHub digests, and read without executing
artifact code.

Each host passed formatting, all eight named storage/authentication/HTTP tests,
strict all-target Clippy and a release build. Readback checked the exact Git
head and lockfile, all expected test names, no ignored/filtered tests, Rust
1.98.1 and the expected target architecture. It did not inspect live job logs.

The tests use an upstream software authenticator and simulated user verification.
The separate local real-user Passkey/restart receipt remains separate evidence.
No hosted executable was exported: `binary.sha256` is a producer observation,
not a locally inspected or installed binary. Device approval/issuance, deployed
HTTPS, installed application qualification and the complete lifecycle remain open.

`CAPTURE.zip` retains both complete upstream artifacts, terminal job/run metadata,
readback scripts/results and the exact 13 app/workflow source files. Its manifest
checks every other member. SDK dependency sources are identified by the exact
Git head rather than duplicated here. No private account database, browser
session, real account name or device secret is included. The optional app is
not an SDK account requirement.
""")
print(json.dumps(checks["capture"]))
