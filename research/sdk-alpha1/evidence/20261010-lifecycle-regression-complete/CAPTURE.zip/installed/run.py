from pathlib import Path
import subprocess,os,json,time,hashlib,signal
base=Path(__file__).resolve().parent
preflight=json.loads((base/'PREFLIGHT.json').read_text());source=Path(preflight['source']);head=preflight['head'];report=Path(preflight['SDK_report'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
assert hashlib.sha256(report.read_bytes()).hexdigest()==preflight['SDK_report_sha256']
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON','JAVA','JDK','GRADLE','KOTLIN','SWIFT')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
env.update(PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',TMPDIR='/private/tmp')
command=['/usr/bin/caffeinate','-i','sh','artifact/python-run.sh','artifact/continuity_package.py','--report',str(report),'--report-sha256',preflight['SDK_report_sha256'],'--toolchain-root',str(rust),'--with-c-consumer','--with-swift-consumer','--witness-openssl-prefix','/opt/homebrew/opt/openssl@3','--output',preflight['output']]
record=dict(preflight,command=command,timeout_seconds=14400,scope='Fresh current Continuity archive and Rust/C/Swift installed-package verification, Debug and Release with existing full native/foreign lifecycle checks. Same macOS arm64 host and shared native protocol engine; not independent implementation, other platforms or minimum OS qualification.',completed=False)
(base/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic();timed_out=False
with (base/'stdout').open('wb') as stdout,(base/'stderr').open('wb') as stderr:
 child=subprocess.Popen(command,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 (base/'PROCESS.json').write_text(json.dumps({'pid':child.pid,'head':head,'source':str(source),'started_monotonic':start},indent=2)+'\n')
 try:code=child.wait(timeout=14400)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
record.update(returncode=code,timed_out=timed_out,seconds=time.monotonic()-start,source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head)
record['completed']=code==0 and not timed_out and record['source_clean'] and record['head_unchanged']
(base/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('source_inputs','command')}),flush=True)
if code:print((base/'stderr').read_text(errors='replace')[-4000:])
raise SystemExit(0 if record['completed'] else 1)
