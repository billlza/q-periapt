from pathlib import Path
import json,subprocess,os,sys,hashlib,time
b=Path(__file__).resolve().parent;label,profile=sys.argv[1:];out=b/label;out.mkdir(mode=0o700)
items=[json.loads(line) for line in (b/('retirement-test-build-'+profile)/'stdout.log').read_text().splitlines()];tests=[x['executable'] for x in items if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='retirement' and x.get('executable')];assert len(tests)==1
pathcmd=['/usr/bin/xcrun','swift','build','--package-path',str(b/'swift-consumer'),'--scratch-path',str(b/('swift-build-'+profile)),'--configuration',profile,'--show-bin-path']
client=Path(subprocess.check_output(pathcmd,text=True).strip())/'ContinuityClient';lib=b/'artifacts'/(profile+'-purpose')/'libq_periapt_continuity_c_consumer.dylib';harness=Path(tests[0]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):sha(p) for p in [client,lib,harness]}
env={k:v for k,v in os.environ.items() if not k.startswith(('SWIFT','CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))};env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_C_OWNER_CLIENT=str(client),QPERIAPT_INSTALLED_CLIENT_LANGUAGE='Swift',QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(lib),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'evidence'))
cmd=[str(harness),'--exact','c_retired_enrollment_preserves_complete_report_and_original_erasure_across_processes','--nocapture'];t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,env=env,cwd=b/'consumer',stdout=so,stderr=se,timeout=300)
r=dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-t,binaries_before=before,binaries_unchanged=all(sha(Path(p))==h for p,h in before.items()),client_selector=pathcmd)
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((out/'stdout.log').read_text()[-2500:]);print((out/'stderr.log').read_text()[-5000:]);assert r['binaries_unchanged'];p.check_returncode()
