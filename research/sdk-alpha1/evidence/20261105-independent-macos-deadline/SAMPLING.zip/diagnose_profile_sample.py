"""Measure the failed 32-member witnessed profile with the exact hosted binary."""
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-independent-macos-failure'
OUT = BASE / 'sample-profile-01'
PEER = ROOT / 'research/continuity-openssl-peer'
PROVIDER = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
NATIVE = BASE / 'hosted-counterpart'
record = json.loads((BASE / 'INPUTS.json').read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(NATIVE) == record['native_sha256']
assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
OUT.mkdir()
NATIVE.chmod(0o700)
sys.path.insert(0, str(PEER))
from qperiapt_continuity_reference.provider import load_provider
crypto, backend = load_provider(PROVIDER)
assert {'cryptography': crypto.__version__, 'openssl': backend.openssl_version_text()} == record['provider']
from run import Counterpart
from policy_composition_checks import run_profile

state = {'completed': False, 'qualification_passed': False,
         'scope': 'Single-profile diagnostic with an observational five-second macOS CPU sample of native-original-R-under-P. Exact hosted ff072 binary and source inputs; unchanged 30-second exchange deadline. Sampling perturbs execution and is not a replacement for concurrent CI qualification.',
         'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
         'native_sha256': sha(NATIVE), 'source_files': record['source_files'], 'provider': record['provider'],
         'python_version': sys.version, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'whole_diagnostic_budget_seconds': 900, 'original_native_exchange_seconds': 30,
         'native_pids': [], 'sampler_results': [], 'driver_sha256': sha(Path(__file__))}
with (OUT / 'DIAGNOSTIC_INPUTS.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
events = (OUT / 'transport-timing.jsonl').open('x', buffering=1)
lock = threading.Lock()
event_count = 0
def emit(value):
    global event_count
    with lock:
        if event_count >= 8192: raise RuntimeError('diagnostic observation capacity exceeded')
        events.write(json.dumps(value, sort_keys=True) + '\n'); event_count += 1
initialize, transfer = Counterpart.__init__, Counterpart.transfer
def observed_initialize(self, *args, **kwargs):
    initialize(self, *args, **kwargs)
    state['native_pids'].append(self.process.pid)
    emit({'event': 'native-start', 'pid': self.process.pid, 'unix_ns': time.time_ns()})
def observed_transfer(self, data):
    started = time.monotonic()
    item = {'pid': self.process.pid, 'first_byte': data[0], 'request_bytes': len(data),
            'request_sha256': hashlib.sha256(data).hexdigest(), 'started_unix_ns': time.time_ns()}
    emit({'event': 'transfer-start', **item})
    sampler = None
    handles = []
    if item['request_sha256'] == '797c27ce5b513ffb01344918726b6d876bb214a4853639760e810f40ce40126e':
        assert not state['sampler_results'], 'target sampled more than once'
        command = ['/usr/bin/sample', str(self.process.pid), '5', '2', '-file', str(OUT / 'target.sample.txt')]
        handles = [(OUT / ('sampler.' + suffix)).open('xb') for suffix in ('stdout', 'stderr')]
        sampler = subprocess.Popen(command, stdout=handles[0], stderr=handles[1], start_new_session=True)
        state['sampler_results'].append({'command': command, 'pid': sampler.pid, 'native_pid': self.process.pid,
                                         'started_utc': datetime.now(timezone.utc).isoformat()})
    try:
        reply = transfer(self, data)
        item.update(reply_bytes=len(reply), reply_sha256=hashlib.sha256(reply).hexdigest())
        return reply
    except BaseException as error:
        item.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        emit({'event': 'transfer-end', **item, 'elapsed_seconds': time.monotonic() - started})
        if sampler is not None:
            result = state['sampler_results'][-1]
            try:
                result['returncode'] = sampler.wait(timeout=10)
            except subprocess.TimeoutExpired:
                result['cleanup_reason'] = 'sampler did not exit within ten seconds after the exchange'
                if sampler.poll() is None: os.killpg(sampler.pid, signal.SIGKILL)
                result['returncode'] = sampler.wait(timeout=5)
                raise
            finally:
                for handle in handles: handle.close()
                result['finished_utc'] = datetime.now(timezone.utc).isoformat()
                result['files'] = {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha(OUT / name)}
                                   for name in ('sampler.stdout', 'sampler.stderr', 'target.sample.txt') if (OUT / name).is_file()}

Counterpart.__init__, Counterpart.transfer = observed_initialize, observed_transfer

def budget_expired(_number, _frame):
    raise TimeoutError('single-profile diagnostic reached its 900-second budget')
def interrupted(number, _frame):
    raise SystemExit(128 + number)
assert signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0)
previous = {number: signal.getsignal(number) for number in (signal.SIGALRM, signal.SIGTERM, signal.SIGHUP)}
signal.signal(signal.SIGALRM, budget_expired)
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGHUP, interrupted)
signal.setitimer(signal.ITIMER_REAL, 900)
started = time.monotonic()
try:
    # The alarm unwinds this same owner into the existing Fixture.finally cleanup;
    # it does not kill an intermediate supervisor while leaving its groups alive.
    state['profile'] = run_profile(SimpleNamespace(output=OUT, native=NATIVE, provider_root=PROVIDER), 32, True)
    assert sha(NATIVE) == record['native_sha256']
    assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
    assert len(state['sampler_results']) == 1
    assert state['sampler_results'][0]['returncode'] == 0, 'macOS sampling failed; inspect retained diagnostics'
    assert (OUT / 'target.sample.txt').stat().st_size > 0
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    signal.setitimer(signal.ITIMER_REAL, 0)
    for number, handler in previous.items(): signal.signal(number, handler)
    events.close()
    Counterpart.__init__, Counterpart.transfer = initialize, transfer
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started,
                 observation_rows=event_count, transport_timing_sha256=sha(OUT / 'transport-timing.jsonl'))
    with (OUT / 'DIAGNOSTIC_RESULT.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
    print(json.dumps({key: state.get(key) for key in ('completed', 'error', 'elapsed_seconds', 'native_pids')}), flush=True)
