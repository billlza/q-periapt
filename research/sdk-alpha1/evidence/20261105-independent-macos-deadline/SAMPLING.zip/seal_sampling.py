"""Retain the isolated five-second CPU observation without rewriting CI evidence."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-independent-macos-failure'
SOURCE = BASE / 'sample-profile-01'
OUT = ROOT / 'research/sdk-alpha1/evidence/20261105-independent-macos-deadline'
sha = lambda value: hashlib.sha256(value).hexdigest()
dump = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
first = json.loads((OUT / 'CAPTURE.json').read_bytes())
assert sha((OUT / 'CAPTURE.zip').read_bytes()) == first['archive_sha256']
result = json.loads((SOURCE / 'DIAGNOSTIC_RESULT.json').read_bytes())
assert result['completed'] is True and result['qualification_passed'] is False
assert len(result['sampler_results']) == 1 and result['sampler_results'][0]['returncode'] == 0
assert result['native_sha256'] == sha((BASE / 'hosted-counterpart').read_bytes())
assert result['driver_sha256'] == sha((BASE / 'diagnose_profile_sample.py').read_bytes())
for name, expected in result['source_files'].items():
    assert sha((ROOT / 'research/continuity-openssl-peer' / name).read_bytes()) == expected
for pid in result['native_pids'] + [s['pid'] for s in result['sampler_results']]:
    try: os.kill(pid, 0)
    except ProcessLookupError: pass
    else: raise AssertionError(('observed process still exists', pid))
timings = [json.loads(row) for row in (SOURCE / 'transport-timing.jsonl').read_text().splitlines()]
target = [row for row in timings if row['event'] == 'transfer-end' and row['request_sha256'] ==
          '797c27ce5b513ffb01344918726b6d876bb214a4853639760e810f40ce40126e']
assert len(target) == 1 and target[0]['reply_bytes'] == 73 and target[0]['elapsed_seconds'] < 30
stats = json.loads((SOURCE / 'SAMPLE_READBACK.json').read_bytes())
assert stats['sample_report_sha256'] == sha((SOURCE / 'target.sample.txt').read_bytes())
assert stats['thread_samples'] == 1941 and stats['top_frame_p256_multiply_and_sub_samples'] == 1156
members = {}
for path in sorted(SOURCE.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        members['public/' + str(path.relative_to(SOURCE))] = path.read_bytes()
for name in ('diagnose_profile_sample.py', 'seal_sampling.py'):
    members[name] = (BASE / name).read_bytes()
for name, value in members.items():
    if any(part in name.lower() for part in ('private', 'secret', '.pem')):
        assert name.endswith(('private-fixture-path', 'private-witness-path')), name
        text = value.decode()
        assert text.startswith('/') and '\n' not in text.removesuffix('\n')
        assert '\x00' not in text and '\r' not in text and len(text) < 4096
readback = {
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'original_capture_sha256': first['archive_sha256'],
    'completed': True, 'qualification_passed': False,
    'source_commit': result['source_commit'], 'native_sha256': result['native_sha256'],
    'source_files_verified': len(result['source_files']), 'provider': result['provider'],
    'elapsed_seconds': result['elapsed_seconds'], 'target_transfer': target[0],
    'whole_diagnostic_budget_seconds': result['whole_diagnostic_budget_seconds'],
    'original_native_exchange_seconds': result['original_native_exchange_seconds'],
    'sampling_duration_seconds': 5, 'sampling_interval_milliseconds': 2,
    'native_and_sampler_processes_exited': True,
    'thread_samples': stats['thread_samples'],
    'p256_field_multiply_top_samples': 615, 'p256_field_sub_inner_top_samples': 541,
    'top_sample_fraction': 1156 / 1941,
    'observation': 'During this local target exchange, 1,156 of 1,941 main-thread samples have P-256 field multiply or sub_inner at the top. Call paths include roster refresh preparation, pending-image decoding, historical credential verification and roster signature authentication.',
    'limits': 'Sampling perturbs execution and covers only five seconds of one local command. Counts are not exact time shares. This does not establish the hosted timeout cause, redundant-check removability, correctness of a proposed optimization, or a need to change any deadline.',
    'private_state_included': False, 'remote_rerun_performed': False, 'release_claim_eligible': False,
}
members['READBACK.json'] = dump(readback)
with zipfile.ZipFile(OUT / 'SAMPLING.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, value in sorted(members.items()): z.writestr(name, value)
manifest = {'archive_bytes': (OUT / 'SAMPLING.zip').stat().st_size,
            'archive_sha256': sha((OUT / 'SAMPLING.zip').read_bytes()),
            'members': {name: {'bytes': len(value), 'sha256': sha(value)} for name, value in sorted(members.items())}}
with zipfile.ZipFile(OUT / 'SAMPLING.zip') as z:
    assert z.testzip() is None and set(z.namelist()) == set(members)
    for name, value in members.items(): assert z.read(name) == value
(OUT / 'SAMPLING.json').write_bytes(dump(manifest))
(OUT / 'SAMPLING_READBACK.json').write_bytes(dump(readback))
print(json.dumps({'archive_bytes': manifest['archive_bytes'], 'archive_sha256': manifest['archive_sha256'], 'members': len(members)}))
