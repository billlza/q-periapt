// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Fresh public enrollment for the independent counterpart.
use q_periapt_continuity_identity_candidate::{
    bootstrap_suite_digest, AccountPin, AllowedPrekeyModes, AnchorRequirement,
    ApplicationSendBudget, BootstrapContext, ClassicalChoice, DeviceDescription, DeviceSigningKey,
    DirectoryExpectation, LeafKind, ManifestContext, PolicyPin, PolicySigningKey, PqChoice,
    PrekeyLeaf, PrekeyQuality, PublicKey, RootSigningKey, SessionPolicyParameters, Validity,
    VerifiedCredentialRenewal, VerifiedDevice,
};
use q_periapt_core::ZeroizingBytes;
use q_periapt_sdk::{Limits, Runtime};
use q_periapt_sig::Signer;
use std::{fs, io::Write, path::Path, sync::Arc};
use zeroize::Zeroize;

use crate::{Result, NOW};

#[path = "fixture_extension.rs"]
mod extension;

pub(super) struct Fixture {
    pub times: Times,
    pub context: Arc<BootstrapContext>,
    pub policy: Arc<q_periapt_continuity_identity_candidate::VerifiedSessionPolicy>,
    pub signer: DeviceSigningKey,
    pub prekey: q_periapt_sdk::HybridKey,
    pub responder: Arc<VerifiedDevice>,
    pub witness: Option<Arc<crate::witness::Witness>>,
    pub local_grants: Vec<VerifiedCredentialRenewal>,
    pub local_rosters: Vec<VerifiedDevice>,
    pub registration: Option<crate::registration::Retained>,
    pub enrolled_peer: Option<crate::enrolled_peer::Configuration>,
    pub policy_renewal: Option<crate::policy_lifecycle::Authority>,
}

pub(super) fn save(directory: &Path, name: &str, bytes: &[u8]) -> Result<()> {
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(directory.join(name))?;
    file.write_all(bytes)?;
    Ok(())
}

fn runtime(directory: &Path) -> Result<Arc<Runtime>> {
    let document = b"schema_version=1\npolicy_version=1\nmin_nist_level=3\ndefault_profile=\"ContextBound\"\nallowed_kems=[\"ML-KEM-768\",\"X25519\"]\nallowed_sigs=[\"ML-DSA-65\"]\ndeprecated=[]\n";
    let mut seed = ZeroizingBytes::<32>::zeroed();
    getrandom::fill(seed.as_mut_bytes())?;
    let (mut secret, public) = q_periapt_backends::MlDsa65::generate(*seed.as_bytes());
    let mut signature = vec![0; q_periapt_backends::ML_DSA_65_SIG_LEN];
    getrandom::fill(seed.as_mut_bytes())?;
    let result = q_periapt_backends::MlDsa65.sign(
        &secret,
        &q_periapt_policy::policy_signature_message(document),
        seed.as_bytes(),
        &mut signature,
    );
    secret.zeroize();
    result.map_err(|error| format!("SDK policy sign: {error:?}"))?;
    let runtime = Arc::new(Runtime::from_signed_policy(
        document,
        &signature,
        &public,
        None,
        Limits::default(),
    )?);
    save(directory, "sdk-document", document)?;
    save(directory, "sdk-signature", &signature)?;
    save(directory, "pin-sdk-root", &public)?;
    save(
        directory,
        "pin-sdk-state",
        &runtime.trusted_state().encode(),
    )?;
    Ok(runtime)
}

pub(super) struct Options {
    pub restartable_successor: bool,
    pub budget: u16,
    pub peer_lifecycle: bool,
    pub intermediate_peer: bool,
    pub local_lifecycle: bool,
    pub short_roster: bool,
    pub extension: bool,
    pub account_members: Option<u8>,
    pub enrolled_peer: bool,
    pub policy_lifecycle: bool,
    pub policy_composition: bool,
}
#[derive(Clone, Copy)]
pub(super) struct Times {
    pub bootstrap: u64,
    pub traffic: u64,
}
impl Options {
    pub fn times(&self) -> Times {
        if self.extension || self.intermediate_peer {
            Times {
                bootstrap: 210,
                traffic: 220,
            }
        } else {
            Times {
                bootstrap: NOW,
                traffic: 170,
            }
        }
    }
}

pub(super) fn create(
    directory: &Path,
    peer_key: PublicKey,
    options: Options,
    witness: Option<Arc<crate::witness::Witness>>,
    registration: Option<crate::registration::Approved>,
) -> Result<Fixture> {
    let times = options.times();
    let Options {
        restartable_successor,
        budget,
        peer_lifecycle,
        intermediate_peer,
        local_lifecycle,
        short_roster,
        extension,
        account_members,
        enrolled_peer,
        policy_lifecycle,
        policy_composition,
    } = options;
    let runtime = runtime(directory)?;
    let (authority, mut registered, retained) = match registration {
        Some(value) => (
            value.policy,
            Some((value.root, value.certificate)),
            Some(value.retained),
        ),
        None => (PolicySigningKey::generate()?, None, None),
    };
    let validity = Validity::new(
        100,
        if policy_lifecycle {
            180
        } else if peer_lifecycle || local_lifecycle || extension || account_members.is_some() {
            400
        } else {
            200
        },
    )?;
    let family = authority.policy_family()?;
    if extension {
        extension::publish_original_policy(
            directory,
            &authority,
            &runtime,
            witness.as_ref(),
            budget,
        )?;
    }
    let policy = authority.issue_session_policy(
        &runtime,
        SessionPolicyParameters::new(
            if extension { 2 } else { 1 },
            validity,
            AllowedPrekeyModes::new(&[PrekeyQuality::ReusableBoth])?,
            witness
                .as_ref()
                .map_or_else(AnchorRequirement::local_only, |w| {
                    AnchorRequirement::required(&w.pin)
                }),
            ApplicationSendBudget::new(budget)?,
        )?,
    )?;
    save(
        directory,
        "pin-policy-root",
        &authority.public_key()?.encode(),
    )?;
    let mut checkpoint = policy.checkpoint().version().to_be_bytes().to_vec();
    checkpoint.extend_from_slice(&policy.checkpoint().digest());
    save(directory, "pin-policy-head", &checkpoint)?;
    save(directory, "policy", policy.as_bytes())?;
    save(directory, "pin-directory", &[99; 32])?;
    let policy_pin = PolicyPin::new(family, authority.public_key()?, policy.checkpoint())?;
    let verified_policy =
        Arc::new(policy_pin.verify(policy.as_bytes(), Arc::clone(&runtime), times.bootstrap)?);
    let (enrolled_peer, signer) = if enrolled_peer {
        let root = registered
            .as_ref()
            .ok_or("native enrollment requires independent registration root")?
            .0
            .public_key()?;
        let (configuration, signer) = crate::enrolled_peer::Configuration::provision(
            directory,
            root,
            family,
            usize::from(account_members.ok_or("missing shared account count")?),
            if policy_lifecycle && !policy_composition {
                450
            } else {
                200
            },
        )?;
        (Some(configuration), signer)
    } else {
        (
            None,
            match &witness {
                Some(w) => w.provision_device()?,
                None => DeviceSigningKey::generate()?,
            },
        )
    };
    let (devices, local_grants, local_rosters, account_root) = if let Some(count) = account_members
    {
        shared_devices(
            directory,
            [peer_key, signer.public_key()?],
            family,
            policy.checkpoint().digest(),
            (count, policy_lifecycle, policy_composition),
            registered.take(),
            enrolled_peer.as_ref(),
        )?
    } else {
        let mut devices = Vec::new();
        let mut local_grants = Vec::new();
        for (role, id, public) in [("i", 1, peer_key), ("r", 2, signer.public_key()?)] {
            let registered_device = if role == "i" { registered.take() } else { None };
            let (root, existing_certificate) = match registered_device {
                Some((root, certificate)) => (root, Some(certificate)),
                None => (RootSigningKey::generate()?, None),
            };
            let certificate = match existing_certificate {
                Some(certificate) => certificate,
                None => root.issue_device(
                    DeviceDescription::new(
                        [id; 16],
                        1,
                        family,
                        if local_lifecycle || peer_lifecycle {
                            let renewed =
                                (local_lifecycle && id == 1) || (peer_lifecycle && id == 2);
                            Validity::new(100, if renewed { 200 } else { 350 })?
                        } else {
                            validity
                        },
                    )?,
                    public,
                )?,
            };
            let (certificate, roster) = if extension && role == "i" {
                extension::credential(directory, &root, certificate, family, times)?
            } else {
                let roster = root.issue_roster(1, validity, &[root.roster_entry(&certificate)?])?;
                (certificate, roster)
            };
            let pin = AccountPin::new(
                root.account_id()?,
                root.public_key()?,
                roster.checkpoint(),
                family,
            )?;
            let original = Arc::new(pin.verify_device(
                &certificate,
                roster.as_bytes(),
                if intermediate_peer && role == "r" {
                    NOW
                } else {
                    times.bootstrap
                },
            )?);
            let grants = if (peer_lifecycle && role == "r") || (local_lifecycle && role == "i") {
                crate::peer_lifecycle::publish(
                    directory,
                    &root,
                    &certificate,
                    &original,
                    roster.as_bytes(),
                    crate::peer_lifecycle::Scope {
                        policy: policy.checkpoint().digest(),
                        family,
                        local: role == "i",
                        short_roster: role == "i" && short_roster,
                    },
                )?
            } else {
                Vec::new()
            };
            let (certificate, roster_bytes, device) = if intermediate_peer && role == "r" {
                let current = grants
                    .first()
                    .ok_or("missing intermediate peer grant")?
                    .successor_device();
                let certificate = root.issue_credential_extension(&original, 300, 170)?;
                (
                    certificate,
                    current.roster().as_bytes().to_vec(),
                    Arc::new(current.clone()),
                )
            } else {
                (certificate, roster.as_bytes().to_vec(), original)
            };
            let mut expectation = root.account_id()?.to_vec();
            expectation.extend_from_slice(&device.roster().checkpoint().version().to_be_bytes());
            expectation.extend_from_slice(&device.roster().checkpoint().digest());
            expectation.extend_from_slice(&[id; 16]);
            expectation.extend_from_slice(&1u64.to_be_bytes());
            save(
                directory,
                &format!("pin-{role}-root"),
                &root.public_key()?.encode(),
            )?;
            save(directory, &format!("pin-{role}-head"), &expectation)?;
            save(directory, &format!("{role}-credential"), &certificate)?;
            save(directory, &format!("{role}-roster"), &roster_bytes)?;
            devices.push(device);
            if role == "i" {
                local_grants = grants;
            }
        }
        (devices, local_grants, Vec::new(), None)
    };
    let initiator = devices.first().ok_or("missing initiator")?;
    let responder = devices.get(1).ok_or("missing responder")?;
    let key = if restartable_successor {
        save(
            directory,
            "restart-bootstrap-time",
            &times.bootstrap.to_be_bytes(),
        )?;
        save(directory, "pin-policy-family", &family)?;
        witness
            .as_ref()
            .ok_or("restart requires original witness")?
            .prekey(&runtime, true)?
    } else {
        runtime.generate_key()?
    };
    let public = key.public_key()?.to_bytes();
    let (pq, classical) = public.split_at(q_periapt_backends::ML_KEM_768_PK_LEN);
    let advertisement = if extension || intermediate_peer {
        Validity::new(times.bootstrap, 260)?
    } else {
        Validity::new(100, 160)?
    };
    let manifest = signer.issue_manifest(
        responder,
        ManifestContext::new(
            1,
            runtime.trusted_state().digest(),
            bootstrap_suite_digest(),
            [99; 32],
            advertisement,
        )?,
        &[
            PrekeyLeaf::new(LeafKind::SignedClassical, classical, advertisement)?,
            PrekeyLeaf::new(LeafKind::LastResortPq, pq, advertisement)?,
        ],
    )?;
    let verified = responder.verify_manifest(manifest.as_bytes(), times.bootstrap)?;
    let mut proofs = std::collections::BTreeMap::new();
    for index in 0..2 {
        let proof = manifest.proof(index)?;
        let kind = verified.verify_leaf(&proof, times.bootstrap)?.kind() as u8;
        save(directory, &format!("proof-{kind}"), &proof.encode()?)?;
        proofs.insert(kind, proof);
    }
    save(directory, "manifest", manifest.as_bytes())?;
    let selection = Arc::new(verified.select_prekeys(
        proofs.get(&1).ok_or("missing classical proof")?,
        proofs.get(&3).ok_or("missing PQ proof")?,
        ClassicalChoice::SignedOnly,
        PqChoice::LastResort,
        times.bootstrap,
    )?);
    save(directory, "expected-selection", selection.as_bytes())?;
    let context = Arc::new(BootstrapContext::new(
        Arc::clone(&verified_policy),
        Arc::clone(initiator),
        Arc::clone(responder),
        selection,
        DirectoryExpectation::from_trusted_state([99; 32])?,
        times.bootstrap,
    )?);
    save(directory, "expected-context", &context.digest())?;
    let policy_renewal = if policy_lifecycle {
        Some(crate::policy_lifecycle::Authority::new(
            directory,
            authority,
            account_root.ok_or("policy profile needs its account issuer")?,
            &runtime,
            Arc::clone(&verified_policy),
            policy_composition,
        )?)
    } else {
        None
    };
    Ok(Fixture {
        times,
        context,
        policy: verified_policy,
        signer,
        prekey: key,
        responder: Arc::clone(responder),
        witness,
        local_grants,
        local_rosters,
        registration: retained,
        enrolled_peer,
        policy_renewal,
    })
}

type AccountFixtures = (
    Vec<Arc<VerifiedDevice>>,
    Vec<VerifiedCredentialRenewal>,
    Vec<VerifiedDevice>,
    Option<RootSigningKey>,
);

fn shared_devices(
    directory: &Path,
    keys: [PublicKey; 2],
    family: [u8; 32],
    policy: [u8; 32],
    members: (u8, bool, bool),
    registered: Option<(RootSigningKey, Vec<u8>)>,
    enrolled_peer: Option<&crate::enrolled_peer::Configuration>,
) -> Result<AccountFixtures> {
    let (count, policy_lifecycle, policy_composition) = members;
    let credential_until = if policy_lifecycle && !policy_composition {
        450
    } else {
        200
    };
    let (root, original) = match registered {
        Some((root, certificate)) => (root, Some(certificate)),
        None => (RootSigningKey::generate()?, None),
    };
    let mut certificates = Vec::new();
    for (index, public) in keys.into_iter().enumerate() {
        let id = u8::try_from(index + 1)?;
        let certificate = if index == 0 {
            match &original {
                Some(certificate) => certificate.clone(),
                None => root.issue_device(
                    DeviceDescription::new(
                        [id; 16],
                        1,
                        family,
                        Validity::new(100, credential_until)?,
                    )?,
                    public,
                )?,
            }
        } else if let Some(enrolled) = enrolled_peer {
            root.issue_enrollment(enrolled.request(), NOW)?
        } else {
            root.issue_device(
                DeviceDescription::new([id; 16], 1, family, Validity::new(100, credential_until)?)?,
                public,
            )?
        };
        certificates.push(certificate);
    }
    for id in 3..=count {
        certificates.push(root.issue_device(
            DeviceDescription::new([id; 16], 1, family, Validity::new(100, credential_until)?)?,
            DeviceSigningKey::generate()?.public_key()?,
        )?);
    }
    let published = if policy_lifecycle && !policy_composition {
        crate::policy_lifecycle::publish_account(&directory.join("account"), &root, &certificates)?
    } else {
        crate::account_fixture::publish(
            &directory.join("account"),
            &root,
            certificates,
            family,
            policy,
        )?
    };
    let pin = AccountPin::new(
        root.account_id()?,
        root.public_key()?,
        published.checkpoint,
        family,
    )?;
    let mut devices = Vec::new();
    for (role, id) in [("i", 1u8), ("r", 2)] {
        let certificate = fs::read(directory.join("account").join(format!("credential-1-{id}")))?;
        let device = Arc::new(pin.verify_device(&certificate, &published.initial_roster, NOW)?);
        let mut expectation = root.account_id()?.to_vec();
        expectation.extend_from_slice(&published.checkpoint.version().to_be_bytes());
        expectation.extend_from_slice(&published.checkpoint.digest());
        expectation.extend_from_slice(&[id; 16]);
        expectation.extend_from_slice(&1u64.to_be_bytes());
        save(
            directory,
            &format!("pin-{role}-root"),
            &root.public_key()?.encode(),
        )?;
        save(directory, &format!("pin-{role}-head"), &expectation)?;
        save(directory, &format!("{role}-credential"), &certificate)?;
        save(
            directory,
            &format!("{role}-roster"),
            &published.initial_roster,
        )?;
        devices.push(device);
    }
    Ok((
        devices,
        published.local_grants,
        published.local_rosters,
        Some(root),
    ))
}

// Read-only test-controller import. Every trust input is supplied separately
// from the publication; this is not a directory or SDK network command.
pub(super) fn verify_one_time_publication(
    path: &Path,
    lease_output: Option<&Path>,
) -> Result<Vec<u8>> {
    use q_periapt_continuity_identity_candidate::{
        PolicyCheckpoint, PrekeyPublicationId, PrekeyPublicationKey, PrekeyPublicationPlan,
        RosterCheckpoint,
    };
    use std::io::{Cursor, Read};

    fn array<const N: usize>(input: &mut Cursor<&[u8]>) -> Result<[u8; N]> {
        let mut value = [0; N];
        input.read_exact(&mut value)?;
        Ok(value)
    }
    fn field(input: &mut Cursor<&[u8]>) -> Result<Vec<u8>> {
        let length = usize::try_from(u32::from_be_bytes(array(input)?))?;
        if length > 65536 {
            return Err("publication fixture field capacity".into());
        }
        let mut value = vec![0; length];
        input.read_exact(&mut value)?;
        Ok(value)
    }
    fn fixed<const N: usize>(input: &mut Cursor<&[u8]>) -> Result<[u8; N]> {
        field(input)?
            .try_into()
            .map_err(|_| "publication fixture fixed field".into())
    }

    let mut raw = Vec::new();
    fs::File::open(path)?
        .take(128 * 1024 + 1)
        .read_to_end(&mut raw)?;
    if raw.len() > 128 * 1024 {
        return Err("publication fixture capacity".into());
    }
    let mut input = Cursor::new(raw.as_slice());
    if array::<8>(&mut input)? != *b"QPOPTF01" {
        return Err("publication fixture schema".into());
    }
    let now = u64::from_be_bytes(fixed(&mut input)?);
    let interval = fixed::<16>(&mut input)?;
    let mut interval = Cursor::new(interval.as_slice());
    let validity = Validity::new(
        u64::from_be_bytes(array(&mut interval)?),
        u64::from_be_bytes(array(&mut interval)?),
    )?;
    let directory = fixed(&mut input)?;
    let journal = fixed(&mut input)?;
    let id = PrekeyPublicationId::from_trusted_state(fixed(&mut input)?)?;
    let family = fixed(&mut input)?;
    let policy_head = fixed::<40>(&mut input)?;
    let mut policy_head = Cursor::new(policy_head.as_slice());
    let policy_checkpoint = PolicyCheckpoint::from_trusted_state(
        u64::from_be_bytes(array(&mut policy_head)?),
        array(&mut policy_head)?,
    )?;
    let device_head = fixed::<96>(&mut input)?;
    let mut device_head = Cursor::new(device_head.as_slice());
    let account = array(&mut device_head)?;
    let roster_checkpoint = RosterCheckpoint::from_trusted_state(
        u64::from_be_bytes(array(&mut device_head)?),
        array(&mut device_head)?,
    )?;
    let expected_device = array::<16>(&mut device_head)?;
    let expected_generation = u64::from_be_bytes(array(&mut device_head)?);
    let sdk_state = fixed::<36>(&mut input)?;
    let document = field(&mut input)?;
    let signature = field(&mut input)?;
    let sdk_root = field(&mut input)?;
    let policy_root = PublicKey::decode(&field(&mut input)?)?;
    let policy_wire = field(&mut input)?;
    let account_root = PublicKey::decode(&field(&mut input)?)?;
    let certificate = field(&mut input)?;
    let roster = field(&mut input)?;
    let publication = field(&mut input)?;
    if usize::try_from(input.position())? != raw.len() {
        return Err("publication fixture trailing bytes".into());
    }
    let runtime = Arc::new(Runtime::from_signed_policy(
        &document,
        &signature,
        &sdk_root,
        None,
        Limits::default(),
    )?);
    if runtime.trusted_state().encode() != sdk_state {
        return Err("publication fixture SDK pin".into());
    }
    let policy = PolicyPin::new(family, policy_root, policy_checkpoint)?.verify(
        &policy_wire,
        runtime,
        now,
    )?;
    let device = AccountPin::new(account, account_root, roster_checkpoint, family)?.verify_device(
        &certificate,
        &roster,
        now,
    )?;
    if device.device_id() != expected_device || device.generation() != expected_generation {
        return Err("publication fixture device pin".into());
    }
    let keys = [
        LeafKind::SignedClassical,
        LeafKind::OneTimeClassical,
        LeafKind::LastResortPq,
        LeafKind::OneTimePq,
    ]
    .map(|kind| PrekeyPublicationKey::generate(kind, validity));
    let plan = PrekeyPublicationPlan::new(directory, validity, &keys)?;
    let selection = plan.verify_artifact(&publication, &journal, id, &device, &policy, now)?;
    if selection.quality() != PrekeyQuality::OneTimeBoth {
        return Err("publication fixture selection quality".into());
    }
    if let Some(output) = lease_output {
        use q_periapt_continuity_identity_candidate::{
            DirectoryLeaseConflict, DirectoryLeaseRequest, DirectoryPin, DirectorySigningKey,
        };
        // Deliberate signer equivocation fixture, not a durable allocator.
        // Only public receipts escape; the new service owner stays in this process.
        let signer = DirectorySigningKey::generate()?;
        let pin = DirectoryPin::new([0xd1; 32], signer.public_key()?)?;
        let first_request =
            DirectoryLeaseRequest::new([0xa1; 32], [0xb1; 32], directory, validity)?;
        let second_request =
            DirectoryLeaseRequest::new([0xa2; 32], [0xb2; 32], directory, validity)?;
        let first = signer.issue_lease(&pin, first_request, &selection, &device, &policy, now)?;
        let second = signer.issue_lease(&pin, second_request, &selection, &device, &policy, now)?;
        let resigned =
            signer.issue_lease(&pin, first_request, &selection, &device, &policy, now)?;
        let conflict = DirectoryLeaseConflict::verify(&pin, first.as_bytes(), second.as_bytes())?;
        fs::create_dir(output)?;
        save(output, "service-id", &pin.identity())?;
        save(output, "service-key", &pin.public_key().encode())?;
        save(output, "service-binding", &pin.binding())?;
        save(output, "first", first.as_bytes())?;
        save(output, "second", second.as_bytes())?;
        save(output, "resigned-first", resigned.as_bytes())?;
        save(output, "conflict", &conflict.to_bytes())?;
        let verified = pin.verify_historical_lease(first.as_bytes())?;
        save(
            output,
            "statement-digest-first",
            &verified.statement_digest(),
        )?;
    }
    let mut result = selection.as_bytes().to_vec();
    result.extend_from_slice(&selection.digest());
    Ok(result)
}
