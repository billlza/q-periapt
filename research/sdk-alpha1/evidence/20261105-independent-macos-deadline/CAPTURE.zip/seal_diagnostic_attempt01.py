"""Seal the original failed profile and a separate exact-binary diagnostic."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-independent-macos-failure'
OUT = ROOT / 'research/sdk-alpha1/evidence/20261105-independent-macos-deadline'
PEER = ROOT / 'research/continuity-openssl-peer'
SOURCE_ZIP = BASE / 'artifact-13415808519.zip'
sha = lambda value: hashlib.sha256(value).hexdigest()
dump = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
expected_zip = 'a2c93354514e151c8f4a3e8b853b7e3faaee39c493ca84b939ee6d554d4d6a44'
assert sha(SOURCE_ZIP.read_bytes()) == expected_zip
inputs = json.loads((BASE / 'INPUTS.json').read_bytes())
local = json.loads((BASE / 'single-profile-01/DIAGNOSTIC_RESULT.json').read_bytes())
assert local['completed'] is True and local['qualification_passed'] is False
assert inputs['native_sha256'] == sha((BASE / 'hosted-counterpart').read_bytes())
assert local['native_sha256'] == inputs['native_sha256']
assert inputs['provider'] == local['provider']
assert inputs['source_files'] == local['source_files']
assert len(inputs['source_files']) == 225
assert all(sha((PEER / name).read_bytes()) == value for name, value in inputs['source_files'].items())
timings = [json.loads(line) for line in (BASE / 'single-profile-01/transport-timing.jsonl').read_text().splitlines()]
target = (4).to_bytes(8, 'big') + (320).to_bytes(8, 'big')
target_hash = sha(bytes([40]) + target)
measured = [row for row in timings if row['event'] == 'transfer-end' and row['request_sha256'] == target_hash]
assert len(measured) == 1 and measured[0]['reply_bytes'] == 73
assert measured[0]['elapsed_seconds'] < 30
members = {}
def add(name, value):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and name not in members
    members[name] = value

profiles = []
with zipfile.ZipFile(SOURCE_ZIP) as source:
    assert source.testzip() is None
    names = set(source.namelist())
    assert len(names) == len(source.namelist()) == 24933
    for info in source.infolist():
        if info.filename.startswith('policy-composition/') and not info.is_dir():
            add('remote/' + info.filename, source.read(info))
    for name in ('policy-composition.stderr', 'policy-composition.stdout', 'source-head.txt',
                 'rustc.txt', 'host.txt', 'metadata.json', 'qualification-phase.txt',
                 'build.stderr', 'build.stdout', 'provider.stderr', 'provider.stdout'):
        add('remote/' + name, source.read(name))
    assert 'policy-composition-capacity.stdout' not in names
    assert 'policy-composition-capacity.stderr' not in names
    for count in (3, 32):
        for label in ('local', 'witness'):
            prefix = f'policy-composition/{count}/{label}/'
            request = source.read(prefix + 'native/cases/native-original-R-under-P.input')
            reply = source.read(prefix + 'native/cases/native-original-R-under-P.output')
            assert request == target
            complete = prefix + 'RESULT.json' in names
            assert complete == ((count, label) != (32, 'witness'))
            assert len(reply) == (73 if complete else 0)
            profiles.append({'members': count, 'witnessed': label == 'witness',
                             'result_present': complete, 'target_input_sha256': sha(request),
                             'target_output_bytes': len(reply), 'target_output_sha256': sha(reply)})
    assert source.read('policy-composition/32/witness/native/native.stderr') == b''

for path in sorted((BASE / 'single-profile-01').rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        add('local/' + str(path.relative_to(BASE / 'single-profile-01')), path.read_bytes())
for name in ('diagnose_one_profile.py', 'hosted-counterpart', 'ZIP_INDEX.json'):
    add(name, (BASE / name).read_bytes())
add('remote/job-127182900343.log',
    (ROOT / 'target/continuity-next-wave-20261105/monitor-1312/job-127182900343.log').read_bytes())
for name, expected in inputs['source_files'].items():
    value = (PEER / name).read_bytes()
    assert sha(value) == expected
    add('source/research/continuity-openssl-peer/' + name, value)
add('seal_diagnostic.py', Path(__file__).read_bytes())
private_names = [name for name in members if any(part in name.lower() for part in ('private', 'secret', '.pem'))]
assert all(name.endswith(('private-fixture-path', 'private-witness-path', 'private_files.py'))
           for name in private_names), private_names
for name in private_names:
    if name.endswith('-path'):
        value = members[name].decode()
        assert value.startswith('/') and value.count('\n') == 1

readback = {
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'remote': {'run': 42008994078, 'job': 127182900343, 'artifact': 13415808519,
               'artifact_bytes': SOURCE_ZIP.stat().st_size, 'artifact_sha256': expected_zip,
               'artifact_members': 24933, 'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
               'job_passed': False, 'failure': 'native output deadline', 'native_exchange_seconds': 30,
               'profiles': profiles, 'following_capacity_command_started': False},
    'local': {'completed': True, 'qualification_passed': False,
              'scope': local['scope'], 'elapsed_seconds': local['elapsed_seconds'],
              'native_sha256': local['native_sha256'], 'python_version': local['python_version'],
              'source_files_verified': 225, 'provider': inputs['provider'],
              'target_transfer': measured[0], 'workers': local['profile']['workers'],
              'process_kills': local['profile']['process_kills'], 'observation_rows': len(timings)},
    'conclusion': 'The exact hosted binary completed the failed profile in isolation. The original concurrent CI deadline failure remains unexplained and failed; this is not a repair or a replacement qualification.',
    'private_state_included': False,
    'archive_scope': 'Complete remote policy-composition public subtree, relevant original job metadata/logs, exact native binary, byte-identical source inputs, and complete local single-profile public observations. Private path records are identifiers only; their destinations were not followed.',
    'remote_rerun_performed': False, 'release_claim_eligible': False,
}
add('READBACK.json', dump(readback))
OUT.mkdir()
with zipfile.ZipFile(OUT / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, value in sorted(members.items()): archive.writestr(name, value)
manifest = {'archive_bytes': (OUT / 'CAPTURE.zip').stat().st_size,
            'archive_sha256': sha((OUT / 'CAPTURE.zip').read_bytes()),
            'members': {name: {'bytes': len(value), 'sha256': sha(value)} for name, value in sorted(members.items())}}
with zipfile.ZipFile(OUT / 'CAPTURE.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(members)
    for name, value in members.items(): assert archive.read(name) == value
(OUT / 'CAPTURE.json').write_bytes(dump(manifest))
(OUT / 'READBACK.json').write_bytes(dump(readback))
print(json.dumps({'archive_bytes': manifest['archive_bytes'], 'archive_sha256': manifest['archive_sha256'], 'members': len(members),
                  'sections': dict(Counter(name.split('/')[0] for name in members))}))
