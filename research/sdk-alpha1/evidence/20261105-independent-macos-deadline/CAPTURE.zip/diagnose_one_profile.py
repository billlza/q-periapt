"""Measure the failed 32-member witnessed profile with the exact hosted binary."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-independent-macos-failure'
OUT = BASE / 'single-profile-01'
PEER = ROOT / 'research/continuity-openssl-peer'
PROVIDER = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
NATIVE = BASE / 'hosted-counterpart'
record = json.loads((BASE / 'INPUTS.json').read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(NATIVE) == record['native_sha256']
assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
OUT.mkdir()
NATIVE.chmod(0o700)
sys.path.insert(0, str(PEER))
from qperiapt_continuity_reference.provider import load_provider
crypto, backend = load_provider(PROVIDER)
assert {'cryptography': crypto.__version__, 'openssl': backend.openssl_version_text()} == record['provider']
from run import Counterpart
from policy_composition_checks import run_profile

state = {'completed': False, 'qualification_passed': False,
         'scope': 'Single-profile diagnostic, members=32 witnessed=True; exact hosted ff072 source binary and byte-identical Python inputs. This does not substitute for the concurrent four-profile CI workload.',
         'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
         'native_sha256': sha(NATIVE), 'source_files': record['source_files'], 'provider': record['provider'],
         'python_version': sys.version, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'whole_diagnostic_budget_seconds': 900, 'original_native_exchange_seconds': 30,
         'native_pids': [], 'driver_sha256': sha(Path(__file__))}
with (OUT / 'DIAGNOSTIC_INPUTS.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
events = (OUT / 'transport-timing.jsonl').open('x', buffering=1)
lock = threading.Lock()
event_count = 0
def emit(value):
    global event_count
    with lock:
        if event_count >= 8192: raise RuntimeError('diagnostic observation capacity exceeded')
        events.write(json.dumps(value, sort_keys=True) + '\n'); event_count += 1
initialize, transfer = Counterpart.__init__, Counterpart.transfer
def observed_initialize(self, *args, **kwargs):
    initialize(self, *args, **kwargs)
    state['native_pids'].append(self.process.pid)
    emit({'event': 'native-start', 'pid': self.process.pid, 'unix_ns': time.time_ns()})
def observed_transfer(self, data):
    started = time.monotonic()
    item = {'pid': self.process.pid, 'first_byte': data[0], 'request_bytes': len(data),
            'request_sha256': hashlib.sha256(data).hexdigest(), 'started_unix_ns': time.time_ns()}
    emit({'event': 'transfer-start', **item})
    try:
        reply = transfer(self, data)
        item.update(reply_bytes=len(reply), reply_sha256=hashlib.sha256(reply).hexdigest())
        return reply
    except BaseException as error:
        item.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        emit({'event': 'transfer-end', **item, 'elapsed_seconds': time.monotonic() - started})
Counterpart.__init__, Counterpart.transfer = observed_initialize, observed_transfer

def budget_expired(_number, _frame):
    raise TimeoutError('single-profile diagnostic reached its 900-second budget')
def interrupted(number, _frame):
    raise SystemExit(128 + number)
assert signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0)
previous = {number: signal.getsignal(number) for number in (signal.SIGALRM, signal.SIGTERM, signal.SIGHUP)}
signal.signal(signal.SIGALRM, budget_expired)
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGHUP, interrupted)
signal.setitimer(signal.ITIMER_REAL, 900)
started = time.monotonic()
try:
    # The alarm unwinds this same owner into the existing Fixture.finally cleanup;
    # it does not kill an intermediate supervisor while leaving its groups alive.
    state['profile'] = run_profile(SimpleNamespace(output=OUT, native=NATIVE, provider_root=PROVIDER), 32, True)
    assert sha(NATIVE) == record['native_sha256']
    assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    signal.setitimer(signal.ITIMER_REAL, 0)
    for number, handler in previous.items(): signal.signal(number, handler)
    events.close()
    Counterpart.__init__, Counterpart.transfer = initialize, transfer
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started,
                 observation_rows=event_count, transport_timing_sha256=sha(OUT / 'transport-timing.jsonl'))
    with (OUT / 'DIAGNOSTIC_RESULT.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
    print(json.dumps({key: state.get(key) for key in ('completed', 'error', 'elapsed_seconds', 'native_pids')}), flush=True)
