from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

base = Path(__file__).resolve().parent
root = base.parent.parent
frozen = json.loads((base / 'FROZEN_SOURCE.json').read_text())
source = Path(frozen['source'])
out = base / 'release-full-01'
out.mkdir(mode=0o700)
rust = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO', 'RUST', 'QPERIAPT', 'QPC', 'DYLD', 'LD_', 'PYTHON', 'JAVA', 'KOTLIN', 'GRADLE'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(root / 'target/account-root-retirement-current/build'), RUSTC=str(rust / 'bin/rustc'), RUSTDOC=str(rust / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', PATH=str(rust / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', DYLD_FALLBACK_LIBRARY_PATH=str(rust / 'lib'))
argv = [str(rust / 'bin/cargo'), 'test', '--manifest-path', str(source / 'research/continuity-identity-candidate/Cargo.toml'), '--all-features', '--locked', '--offline', '-j', '2', '--lib', '--release', '--', '--nocapture', '--test-threads=1']
record = {**frozen, 'command': argv, 'completed': False}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == frozen['preview_head']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True) == ''
assert all(hashlib.sha256((source / f).read_bytes()).hexdigest() == h for f, h in frozen['source_sha256'].items())
(out / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
timed_out = False
with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=source, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        result = child.wait(timeout=5400)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            result = child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            result = child.wait()
record.update(returncode=result, timed_out=timed_out, seconds=time.monotonic()-start, source_clean=subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)=='', head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()==frozen['preview_head'], inputs_unchanged=all(hashlib.sha256((source/f).read_bytes()).hexdigest()==h for f,h in frozen['source_sha256'].items()))
record['completed'] = result == 0 and not timed_out and record['source_clean'] and record['head_unchanged'] and record['inputs_unchanged']
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k!='source_sha256'}), flush=True)
print((out/'stdout').read_text(errors='replace')[-4000:], flush=True)
print((out/'stderr').read_text(errors='replace')[-1600:], flush=True)
raise SystemExit(0 if record['completed'] else 1)
