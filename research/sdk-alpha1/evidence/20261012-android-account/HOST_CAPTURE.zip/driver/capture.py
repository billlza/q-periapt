from pathlib import Path
import json,hashlib,zipfile,tempfile
import continuity_android_account as account
import rust_sdk_profile as sdk
root=Path.cwd();base=Path(__file__).resolve().parent;src=base/'final2'
state=json.loads((src/'STATE.json').read_text());assert state['completed'] and not state['live_producer']
boundary=json.loads((base/'BOUNDARY.json').read_text());assert boundary['completed'] and not boundary['live_producer']
for name,h in state['inputs'].items():assert sdk.snapshot(root/name).sha256==h,name
for name,h in boundary['source_hashes'].items():
 if name.startswith(('jni/','src/main/java/')):assert sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==h,name
out=root/'research/sdk-alpha1/evidence/20261012-android-account';out.mkdir()
members={}
def add(name,path):members[name]=path.read_bytes()
for name in state['inputs']:add('source/'+name,root/name)
for profile in ('debug','release'):
 stdout=(src/(profile+'-execution.stdout')).read_bytes();result=account.verify_execution(stdout,src/profile);assert result==state['profiles'][profile]['outcomes']
 for trust in result:
  for name in account.PUBLIC:add('public/'+profile+'/'+trust+'/'+name,src/profile/trust/name)
 for kind in ['build','catalog','execution']:
  for suffix in ['json','stdout','stderr']:add('execution/'+profile+'-'+kind+'.'+suffix,src/(profile+'-'+kind+'.'+suffix))
 for kind in ['bridge','boundary']:
  for suffix in ['json','stdout','stderr']:add('execution/'+profile+'-'+kind+'.'+suffix,base/(profile+'-'+kind+'.'+suffix))
for suffix in ['json','stdout','stderr']:add('execution/clippy.'+suffix,src/('clippy.'+suffix))
for name in ['compile-main','compile-tests']:
 for suffix in ['json','stdout','stderr']:add('execution/'+name+'.'+suffix,base/(name+'.'+suffix))
add('execution/qualification.json',src/'STATE.json');add('execution/boundary.json',base/'BOUNDARY.json')
for name in ['clippy.json','clippy.stdout','clippy.stderr','failing-module.rs']:add('failures/initial-lint/'+name,base/'final'/name)
for name in ['check_boundary.py','check_final_retry.py','capture.py']:add('driver/'+name,base/name)
archive=out/'HOST_CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory() as t,zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items());z.extractall(t)
 for profile in ('debug','release'):assert account.verify_execution((Path(t)/'execution'/f'{profile}-execution.stdout').read_bytes(),Path(t)/'public'/profile)==state['profiles'][profile]['outcomes']
checks={'completed':True,'scope':'macOS arm64 host JNI against installed Debug/Release C libraries; Android device acceptance remains separately scoped','profiles':state['profiles'],'boundary':boundary['profiles'],'foreign_processes':108,'receiver_exit_77_cuts':4,'clippy_warnings_denied':True,'public_source_matches_boundary_compile':True,'all_archive_hashes_verified':True,'archive_members':len(members),'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({k:checks[k] for k in ['completed','foreign_processes','archive_members','capture_sha256']},indent=2))
