from pathlib import Path
import os,json,shutil
import rust_sdk_profile as sdk
import continuity_android_jni as jni
import continuity_android_account as account
import continuity_android_contract as contract
import continuity_c_consumer as c
root=Path.cwd();base=Path(__file__).resolve().parent;out=base/'final2';out.mkdir()
old=json.loads((base/'process-v2/PROCESS.json').read_text());assert old['completed'] and not old['live_producer']
work=Path(old['work']);consumer=work/'c-consumer'
shutil.copytree(root/'bindings/c/ContinuityPackageConsumer/tests',consumer/'tests',dirs_exist_ok=True)
prior=root/'target/continuity-apple-package-stable';env=dict(json.loads((prior/'PRIVATE_ENVIRONMENT.json').read_text()),CARGO_TARGET_DIR=str(work/'rust-target'))
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');tool=Path(env['RUSTC']).parent
paths=[p for p in jni.SOURCE.rglob('*') if p.is_file()]+[root/'bindings/c/ContinuityPackageConsumer/tests'/p for p in ['android.rs','common/android_account.rs']]+[root/'artifact'/p for p in ['continuity_android_jni.py','continuity_android_contract.py','continuity_android_account.py']]
state={'completed':False,'live_producer':True,'work':str(work),'profiles':{},'inputs':{str(p.relative_to(root)):sdk.snapshot(p).sha256 for p in paths}}
def save():(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,label,cwd=consumer,runtime=None):return sdk.command(list(map(str,args)),out/label,cwd,environment=env if runtime is None else runtime)
save()
try:
 run([tool/'cargo','clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],'clippy')
 for profile in ('debug','release'):
  extra=['--release'] if profile=='release' else []
  built=run([tool/'cargo','test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2',*extra],profile+'-build')
  binary=c.built_artifact(built,consumer,work/'rust-target'/profile,library=False,test_name='android')
  catalog=run([binary,'--list'],profile+'-catalog');contract.verify_catalog(catalog)
  driver=jni._driver(work/profile,jdk/'bin/java',work/'classes',work/'tests',work/profile)
  cases=work/profile/'account-cases-final2'
  runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(driver))
  stdout=run([binary,'--exact',account.TEST,'--nocapture'],profile+'-execution',runtime=runtime)
  results=account.verify_execution(stdout,cases)
  for trust in results:
   for name in account.PUBLIC:sdk.copy(cases/trust/name,out/profile/trust/name)
  state['profiles'][profile]={'passed':True,'binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'outcomes':results};save()
 assert all(sdk.snapshot(root/name).sha256==digest for name,digest in state['inputs'].items());state['completed']=True
finally:state['live_producer']=False;save()
print('Integrated driver/catalog, clippy and Debug/Release account qualification passed',flush=True)
