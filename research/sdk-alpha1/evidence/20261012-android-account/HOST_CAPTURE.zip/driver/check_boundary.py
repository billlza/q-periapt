from pathlib import Path
import os,json,tempfile,shutil
import rust_sdk_profile as sdk
import continuity_android_jni as android

root=Path.cwd(); out=Path(__file__).resolve().parent
prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())
assert prior['completed'] and not prior['live_producer']
work=Path(tempfile.mkdtemp(prefix='qpc-android-account-boundary-')).resolve()
source=work/'source'; shutil.copytree(android.SOURCE,source)
env={k:v for k,v in prior['environment'].items() if k not in {'JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','CLASSPATH'} and not k.startswith(('JAVA_','GRADLE_','KOTLIN_','QPERIAPT_','QPC_','LD_'))}
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
state={'completed':False,'live_producer':True,'work':str(work),'source_hashes':{str(p.relative_to(source)):sdk.snapshot(p).sha256 for p in source.rglob('*') if p.is_file()},'profiles':{}}
def save(): (out/'BOUNDARY.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,label):return sdk.command(list(map(str,args)),out/label,work,environment=env)
save()
try:
 classes=work/'classes';classes.mkdir();tests=work/'tests';tests.mkdir()
 run([jdk/'bin/javac','--release','11','-Xlint:all','-Werror','-d',classes,*sorted((source/'src/main/java').rglob('*.java'))],'compile-main')
 run([jdk/'bin/javac','--release','17','-Xlint:all','-Werror','-cp',classes,'-d',tests,*sorted((source/'src/test/java').glob('*.java'))],'compile-tests')
 clang=run(['xcrun','--sdk','macosx','--find','clang'],'clang').decode().strip()
 platform=run(['xcrun','--sdk','macosx','--show-sdk-path'],'sdk').decode().strip()
 for profile in ('debug','release'):
  installed=work/profile;installed.mkdir()
  record=prior['native']['execution'][profile]['binaries']['C_library'];native=Path(record['path'])
  assert sdk.snapshot(native,maximum=256*1024*1024).sha256==record['sha256']
  shutil.copy2(native,installed/native.name)
  bridge=installed/'libqperiapt_continuity_jni.dylib'
  run([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-isysroot',platform,
       '-I'+str(root/'bindings/c/ContinuityPackageConsumer'),'-I'+str(jdk/'include'),'-I'+str(jdk/'include/darwin'),
       '-dynamiclib',*sorted((source/'jni').glob('*.c')),'-L'+str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',bridge],profile+'-bridge')
  stdout=run([jdk/'bin/java','--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(installed),'-cp',str(classes)+os.pathsep+str(tests),'dev.qperiapt.continuity.android.BridgeProbe'],profile+'-boundary')
  assert stdout==b'configuration:bridge:passed\n' and (out/(profile+'-boundary.stderr')).read_bytes()==b''
  state['profiles'][profile]={'passed':True,'native_sha256':record['sha256'],'bridge_sha256':sdk.snapshot(bridge,maximum=256*1024*1024).sha256};save()
 assert all(sdk.snapshot(android.SOURCE/name).sha256==digest for name,digest in state['source_hashes'].items())
 state['completed']=True
finally:state['live_producer']=False;save()
print('Debug/Release real JNI account boundary checks passed; aggregate process delivery remains unqualified',flush=True)
