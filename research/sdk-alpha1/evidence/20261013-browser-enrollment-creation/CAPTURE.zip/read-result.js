async page => ({ result: await page.evaluate(() => globalThis.result), progress: await page.locator('#result').textContent() })
