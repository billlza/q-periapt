from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;source=repo/'target/continuity-browser-storage/source'
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','crates','research/continuity-identity-candidate'],cwd=source,text=True).splitlines()
inputs={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in names if (source/name).is_file()}
state={'completed':False,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'inputs_sha256':inputs,
       'shared_storage_io_sha256':hashlib.sha256((repo/'crates/q-periapt-sdk-wasm/package/web/storage-io.js').read_bytes()).hexdigest()}
try:
    base=['sh',str(stage/'cargo.sh')];manifest=['--manifest-path','research/continuity-identity-candidate/Cargo.toml']
    sdk.command([*base,'build',*manifest,'--target','wasm32-unknown-unknown','--release','--locked','--offline'],stage/'wasm-build4',source)
    sdk.command([*base,'clippy',*manifest,'--lib','--target','wasm32-unknown-unknown','--locked','--offline','--','-D','warnings'],stage/'wasm-clippy3',source)
    sdk.command([*base,'clippy',*manifest,'--all-features','--lib','--tests','--examples','--locked','--offline','--','-D','warnings'],stage/'native-clippy3',source)
    for name,digest in inputs.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
    state['completed']=True
finally:sdk.write_json(stage/'BUILD3.json',state)
print('Bridge build and WASM/native strict Clippy passed with frozen source')
