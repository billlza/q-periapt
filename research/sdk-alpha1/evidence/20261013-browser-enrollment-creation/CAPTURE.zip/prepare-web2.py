from pathlib import Path
import hashlib,json,os,shutil
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;source=repo/'target/continuity-browser-storage/source';web=stage/'web2';web.mkdir()
build=json.loads((stage/'BUILD3.json').read_text());assert build['completed']
wasm=stage/'rust-target/wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
sdk.command([str(repo/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(web/'pkg'),str(wasm)],stage/'bindgen2',repo)
for name in ('storage-root.js','storage-database.js','storage-catalogue.js'):
    shutil.copy2(source/'research/continuity-identity-candidate/src/storage/browser'/name,web/'pkg'/name)
shared=repo/'crates/q-periapt-sdk-wasm/package/web/storage-io.js'
assert hashlib.sha256(shared.read_bytes()).hexdigest()==build['shared_storage_io_sha256']
shutil.copy2(shared,web/'pkg/storage-io.js')
for name in ('index.html','run.js','worker.js'):
    text=(stage/'web'/name).read_text().replace("'./pkg/policy-database.js'","'./pkg/storage-io.js'")
    (web/name).write_text(text)
issuer=stage/'private-issuer2';issuer.mkdir(mode=0o700);(web/'inputs').mkdir()
native=stage/'rust-target/debug/examples/browser_owned_enrollment'
assert hashlib.sha256(native.read_bytes()).hexdigest()==json.loads((stage/'WEB_BUILD.json').read_text())['native_binary_sha256']
env=dict(os.environ,DYLD_FALLBACK_LIBRARY_PATH='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
sdk.command([str(native),'prepare',str(issuer)],stage/'native-prepare2',repo,environment=env)
for name in ('root.bin','description.bin'):shutil.copy2(issuer/name,web/'inputs'/name)
server=(stage/'serve.py').read_text().replace("output=stage/'browser1'","output=stage/'browser2'").replace("web=stage/'web'","web=stage/'web2'")
(stage/'serve2.py').write_text(server)
(stage/'WEB2.json').write_text(json.dumps({p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()},indent=2)+'\n')
sdk.write_json(stage/'WEB_BUILD2.json',{'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'native_binary':str(native),'native_binary_sha256':hashlib.sha256(native.read_bytes()).hexdigest()})
late=(stage/'late-worker.js').read_text()
late=late.replace("const observed = async promise => { try { return { ok: true, value: await promise }; } catch (error) { return { ok: false, error: String(error) }; } };",'''function causes(error, depth = 0) {
  if (!error || depth > 4) return [];
  return [error.code ?? error.name, ...causes(error.cause, depth + 1),
    ...(error instanceof AggregateError ? error.errors.flatMap(value => causes(value, depth + 1)) : [])];
}
const observed = async promise => { try { return { ok: true, value: await promise }; }
  catch (error) { return { ok: false, error: String(error), code: error.code, causes: causes(error) }; } };''')
late=late.replace("attempt.error.includes(code) && attempt.error.includes('ClosePending')", "attempt.code === code && attempt.causes.includes('ClosePending')")
late=late.replace("error: attempt.error, concurrent: concurrent.error", "error: attempt.error, causes: attempt.causes, concurrent: concurrent.error")
(stage/'late-worker2.js').write_text(late)
