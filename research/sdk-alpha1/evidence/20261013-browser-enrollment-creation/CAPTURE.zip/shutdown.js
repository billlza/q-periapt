async page => await page.evaluate(async () => ({ status: (await fetch('/shutdown', {method:'POST'})).status }))
