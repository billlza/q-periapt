/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_browserenrollmentprobe_free: (a: number, b: number) => void;
export const browserenrollmentprobe_close: (a: number) => any;
export const browserenrollmentprobe_create: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
export const browserenrollmentprobe_open: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
export const browserenrollmentprobe_request: (a: number, b: bigint) => any;
export const browserenrollmentprobe_resume: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
export const wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___bool__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: number) => [number, number];
export const wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
export const wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___q_periapt_continuity_identity_candidate_4c9cec294764ac23___storage__browser__HostSecret__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___wasm_bindgen_5ef15f9c59dd1dc3___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
