from pathlib import Path
import hashlib,json,subprocess,zipfile
import wasm_browser_storage as browser
import wasm_sdk_package as package

stage=Path(__file__).resolve().parent;repo=stage.parent.parent
out=repo/'research/sdk-alpha1/evidence/20261013-browser-enrollment-creation';out.mkdir(mode=0o700,exist_ok=True)
assert not any(out.iterdir()),'capture destination is not empty'
read=lambda path:json.loads(path.read_text())
latest=read(stage/'browser2/RESULT.json');native=read(stage/'native-verification3/RESULT.json');late=read(stage/'late2/RESULT.json')
assert latest['completed'] and len(latest['cases'])==12
assert native['completed'] and native['requests_verified']==19 and native['distinct_original_signers']==7
assert late['completed'] and len(late['cases'])==5
assert [row['mode'] for row in late['cases']]==['decrypt','handle','open','transaction','foreign-directory']
for row in late['cases'][:4]:
    assert row['elapsed_ms']>=19000 and 'ClosePending' in row['causes'] and 'Busy' in row['concurrent']
    assert row['release_observations'][-1]==0 and len(row['request_sha256'])==64
assert 'Exists' in late['cases'][-1]['create'] and 'Absent' in late['cases'][-1]['resume']
assert read(stage/'late1/RESULT.json')['completed'] is False
for directory,manifest in (('web','WEB1.json'),('web-late','WEB_LATE.json'),('web2','WEB2.json'),('web-late2','WEB_LATE2.json')):
    for name,digest in read(stage/manifest).items():assert hashlib.sha256((stage/directory/name).read_bytes()).hexdigest()==digest,(directory,name)
integrated=read(stage/'INTEGRATED.json')
for name,digest in integrated['files_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
binding=read(stage/'native-binding/RESULT2.json');assert binding['completed']
for name,digest in binding['inputs_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
qualification=read(stage/'policy-qualified-01/BROWSER_STORAGE.json');receipt=read(stage/'policy-package-01/INSTALLED_CONSUMER.json')
assert qualification['completed'] and qualification['archive_sha256']==receipt['sha256']
manifest=package.verify(Path(receipt['installed']),receipt['manifest_sha256']);package.validate_consumer_source(manifest)
for name,marker in [('storage-acceptance.js','BROWSER_POLICY_STORAGE_PASS'),('storage-quota-acceptance.js','BROWSER_POLICY_QUOTA_PASS'),('storage-deadline-acceptance.js','BROWSER_POLICY_DEADLINE_PASS')]:
    assert browser.result((stage/'policy-qualified-01'/(name+'.stdout')).read_bytes(),marker)==qualification[name]
members={}
def add(path,name=None):
    name=name or path.relative_to(stage).as_posix()
    assert name not in members and not path.is_symlink()
    assert not any(part.startswith('private-issuer') for part in Path(name).parts)
    body=path.read_bytes();assert len(body)<16*1024*1024,name
    members[name]=body
for directory in ('browser1','browser2','late1','late2','native-verification','native-verification3','policy-qualified-01'):
    for path in (stage/directory).iterdir():
        if path.is_file():add(path)
for directory in ('web2','web-late2'):
    for path in (stage/directory).rglob('*'):
        if path.is_file():add(path)
for directory in ('web','web-late'):
    for path in (stage/directory).rglob('*'):
        if path.is_file() and path.suffix in ('.js','.html','.ts'):add(path)
for path in stage.iterdir():
    if path.name.startswith('capture') and path.suffix in ('.stdout','.stderr'):continue
    if path.is_file() and path.suffix in ('.py','.sh','.json','.stdout','.stderr','.js'):
        add(path)
for directory in ('native-binding','policy-package-01'):
    for path in (stage/directory).iterdir():
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr','.sh'):add(path)
add(stage/'policy-package-01/package/PACKAGE_CONTENTS.json')
for name in integrated['files_sha256']:add(repo/name,'source/'+name)
for name in ('research/continuity-identity-candidate/README.md','crates/q-periapt-sdk-wasm/package/web/storage-io.js',
             'crates/q-periapt-sdk-wasm/package/web/policy-database.js','crates/q-periapt-sdk-wasm/tests/serve.cjs'):
    add(repo/name,'source/'+name)
members['SOURCE.patch']=subprocess.check_output(['git','diff','--binary'],cwd=repo)
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,body in sorted(members.items()):archive.writestr(name,body)
with zipfile.ZipFile(out/'CAPTURE.zip') as archive:
    assert set(archive.namelist())==set(members)
    for name,body in members.items():assert archive.read(name)==body
body=(out/'CAPTURE.zip').read_bytes()
checks={'schema_version':1,'completed':True,'main_base':integrated['main_before'],
        'prototype_base':integrated['prototype_source_base'],'implementation_integrated':True,
        'scope':'Candidate browser first-use enrollment only; not unified product WASM or operational lifecycle admission.',
        'creation_cases':12,'real_worker_terminations':8,'native_verified_public_requests':19,'distinct_generated_signers':7,
        'late_completion_cases':4,'foreign_directory_preserved':True,
        'failure_fixed':'The WASM facade stringified host errors and lost structured cleanup causes. Host causes and combined native/host cleanup failures now retain their original error objects.',
        'shared_browser_io':'The policy owner and candidate adapter use the same storage-io.js completion/lease implementation.',
        'native_source_checks':{'strict_clippy':'Rust 1.98.1; candidate all features/tests/examples and C adapter all targets',
                                'minimum':'Rust 1.90; native C adapter and tests compiled',
                                'runtime_suite':'959 tests passed on the preceding frozen storage adapter cohort; a complete run of the final integrated source remains separate.'},
        'policy_installed_package':{'sha256':receipt['sha256'],'manifest_sha256':receipt['manifest_sha256'],
                                    'browser_groups':3,'cleanup_completed':True},
        'browser_wasm':{'raw_cargo_sha256':read(stage/'WEB_BUILD2.json')['wasm_sha256'],
                         'served_bindgen_sha256':read(stage/'WEB2.json')['pkg/q_periapt_continuity_identity_candidate_bg.wasm']},
        'preserved_failed_attempts':['wrong-cwd initial WASM build, not used as candidate output',
             'first late-completion cohort exposed lost structured cleanup error',
             'native request verifier initially compared against the previous web directory and rejected it',
             'C adapter source check initially omitted its declared installed test-fixture directory',
             'first archive included its own still-open controller stdout/stderr; preserved locally and resealed excluding those logs'],
        'limits':['Same Rust protocol engine; no independent implementation claim.',
                  'No operational grant/session/root/roster browser lifecycle or browser transport admission.',
                  'No browser schema migration, rollback resistance against whole-profile restoration, secure erasure, or native power-loss equivalence claim.',
                  'Non-extractable CryptoKey is an API boundary, not a hardware or hostile-origin security claim.',
                  'The Rust/C/Swift overall installed package qualifier remains incomplete after its earlier interruption.',
                  'Private issuer keys, private journals and browser profiles are excluded. Captured request/credential bytes are public.'],
        'capture':{'file':'CAPTURE.zip','sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'members':len(members),
                   'member_sha256':{name:hashlib.sha256(value).hexdigest() for name,value in sorted(members.items())}},
        'release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({key:checks[key] for key in ('completed','creation_cases','real_worker_terminations','native_verified_public_requests','distinct_generated_signers','late_completion_cases','implementation_integrated')}))
print(json.dumps({key:checks['capture'][key] for key in ('sha256','bytes','members')}))
