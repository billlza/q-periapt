from pathlib import Path
stage=Path(__file__).resolve().parent
text=(stage/'verify-browser2.py').read_text().replace("output=stage/'native-verification2'", "output=stage/'native-verification3'").replace("stage/'web'/name", "stage/'web2'/name")
(stage/'verify-browser3.py').write_text(text)
