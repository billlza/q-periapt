from pathlib import Path
repo=Path(__file__).resolve().parents[2]
path=repo/'target/continuity-browser-storage/source/research/continuity-identity-candidate/src/browser_enrollment_probe.rs'
s=path.read_text()
s=s.replace('fn intent(root: &[u8], description: &[u8]) -> Result<EnrollmentIntent, DurableError> {','fn intent(root: &[u8], description: &[u8]) -> Result<(EnrollmentIntent, Vec<u8>), DurableError> {')
s=s.replace('    Ok(EnrollmentIntent::new(\n        PublicKey::decode(root)?,\n        DeviceDescription::new(device, generation, family, Validity::new(from, until)?)?,\n    ))','''    let public = PublicKey::decode(root)?;
    let mut binding = b"QPC-BROWSER-ENROLLMENT-INITIAL/v2".to_vec();
    binding.extend_from_slice(&public.encode());
    binding.extend_from_slice(description);
    Ok((EnrollmentIntent::new(
        public,
        DeviceDescription::new(device, generation, family, Validity::new(from, until)?)?,
    ), binding))''')
start=s.index('/// Isolated diagnostic of Rust\'s target-specific lexical path interpretation.')
end=s.index('/// Experiment owner with explicit creation versus exact original reopening.')
s=s[:start]+'''enum Opening {
    Create,
    Open,
    Resume,
}

'''+s[end:]
start=s.index('    /// Create fresh browser-owned vault, wrapping key and original enrollment intent.')
end=s.index('    /// Return the exact committed original request; concurrent use is refused.')
s=s[:start]+'''    /// Create a fresh vault with atomically published wrapping key and exact intent.
    pub async fn create(name: String, id: String, root: Vec<u8>, description: Vec<u8>) -> Result<Self, JsValue> {
        Self::acquire(name, id, root, description, Opening::Create).await
    }
    /// Open a completed original initialization without repairing missing objects.
    pub async fn open(name: String, id: String, root: Vec<u8>, description: Vec<u8>) -> Result<Self, JsValue> {
        Self::acquire(name, id, root, description, Opening::Open).await
    }
    /// Resume only the authenticated original first-use intent. Published files cannot be replaced.
    pub async fn resume(name: String, id: String, root: Vec<u8>, description: Vec<u8>) -> Result<Self, JsValue> {
        Self::acquire(name, id, root, description, Opening::Resume).await
    }
'''+s[end:]
start=s.index('impl BrowserEnrollmentProbe {\n    async fn create_enrollment(')
end=s.index('impl Drop for BrowserEnrollmentProbe')
s=s[:start]+'''impl BrowserEnrollmentProbe {
    async fn acquire(name: String, id: String, root: Vec<u8>, description: Vec<u8>, mode: Opening) -> Result<Self, JsValue> {
        let (intent, binding) = intent(&root, &description).map_err(js)?;
        let storage = match mode {
            Opening::Create => Storage::create(&name, &id, &binding).await,
            Opening::Open => Storage::open(&name, &id, &binding).await,
            Opening::Resume => Storage::resume(&name, &id, &binding).await,
        }.map_err(js)?;
        let result = Self::initialize_or_open(&storage, intent, mode).await;
        match result {
            Ok(owner) => Ok(Self { enrollment: RefCell::new(Some(owner)), storage, closed: Cell::new(false) }),
            Err(primary) => {
                let cleanup = storage.close().await;
                Err(js_with_cleanup(primary, cleanup))
            }
        }
    }
    async fn initialize_or_open(storage: &Storage, intent: EnrollmentIntent, mode: Opening) -> Result<DeviceEnrollment, DurableError> {
        if matches!(mode, Opening::Open) || storage.creation_ready()? {
            return DeviceEnrollment::open_with_storage(storage.clone(), paths(storage)?, intent).await;
        }
        let configuration = storage.prefix()? + "enrollment.redb";
        let owner = if storage.missing(Path::new(&configuration)).await? {
            // The authenticated catalogue proves this original intent never published
            // an enrollment database. An absent *published* row is rejected in storage.
            DeviceEnrollment::provision_with_storage(storage.clone(), paths(storage)?, intent).await?
        } else {
            DeviceEnrollment::open_with_storage(storage.clone(), paths(storage)?, intent).await?
        };
        storage.finish_creation().await?;
        Ok(owner)
    }
}
'''+s[end:]
path.write_text(s)
