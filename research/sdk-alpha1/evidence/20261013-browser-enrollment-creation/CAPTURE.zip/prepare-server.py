from pathlib import Path
import hashlib,json,shutil
stage=Path(__file__).resolve().parent;repo=stage.parent.parent
shutil.copy2(stage/'web/storage-catalogue.js',stage/'web/pkg/storage-catalogue.js')
server=(repo/'target/continuity-browser-storage/serve3.py').read_text().replace("output=stage/'browser3'","output=stage/'browser1'").replace("web=stage/'web3'","web=stage/'web'")
(stage/'serve.py').write_text(server)
manifest={p.relative_to(stage/'web').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (stage/'web').rglob('*') if p.is_file()}
(stage/'WEB1.json').write_text(json.dumps(manifest,indent=2)+'\n')
