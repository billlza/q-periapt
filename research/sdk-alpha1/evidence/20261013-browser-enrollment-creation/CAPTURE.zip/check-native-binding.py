from pathlib import Path
import hashlib,json,shutil,subprocess
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;out=stage/'native-binding';out.mkdir(mode=0o700)
consumer=out/'consumer';shutil.copytree(repo/'bindings/c/ContinuityPackageConsumer',consumer)
with (consumer/'Cargo.toml').open('a') as stream:
    stream.write('\n[patch.crates-io]\n')
    for name in sdk.CONSUMER_CRATES:
        stream.write(name+' = { path = '+json.dumps(str(repo/'crates'/name))+' }\n')
    stream.write('q-periapt-continuity-identity-candidate = { path = '+json.dumps(str(repo/'research/continuity-identity-candidate'))+' }\n')
shutil.copy2(repo/'research/continuity-identity-candidate/Cargo.lock',consumer/'Cargo.lock')
wrapper=out/'cargo.sh';wrapper.write_text((stage/'cargo.sh').read_text().replace(str(stage/'rust-target'),str(out/'rust-target')))
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','crates','research/continuity-identity-candidate','bindings/c/ContinuityPackageConsumer'],cwd=repo,text=True).splitlines()
inputs={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in names if (repo/name).is_file()}
record={'completed':False,'inputs_sha256':inputs,'scope':'Current source compatibility of native C adapter and tests; not installed-package runtime qualification'}
try:
    metadata=json.loads(sdk.command(['sh',str(wrapper),'metadata','--offline','--format-version','1'],out/'metadata',consumer))
    for package in metadata['packages']:
        if package['name'].startswith('q-periapt') and package['name']!='q-periapt-continuity-c-consumer':
            assert Path(package['manifest_path']).is_relative_to(repo)
    sdk.command(['sh',str(wrapper),'clippy','--all-features','--all-targets','--locked','--offline','--','-D','warnings'],out/'clippy',consumer)
    for name,digest in inputs.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
    record['completed']=True
finally:sdk.write_json(out/'RESULT.json',record)
print(record['scope']+': passed')
