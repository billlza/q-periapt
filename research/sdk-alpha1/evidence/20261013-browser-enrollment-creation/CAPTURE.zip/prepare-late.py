from pathlib import Path
import hashlib,json,shutil
stage=Path(__file__).resolve().parent;web=stage/'web-late';shutil.copytree(stage/'web',web)
shutil.copy2(stage/'late-worker.js',web/'late-worker.js')
(web/'index.html').write_text('''<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Creation cleanup receipts</title><pre id="result">Running</pre><script type="module">
const worker=new Worker('./late-worker.js',{type:'module'});const timer=setTimeout(()=>{worker.terminate();globalThis.result={completed:false,error:'overall deadline'};document.querySelector('#result').textContent=JSON.stringify(result)},125000);
worker.onmessage=async({data})=>{if(data.progress){document.querySelector('#result').textContent=data.progress;return}clearTimeout(timer);globalThis.result=data;document.querySelector('#result').textContent=JSON.stringify(data,null,2);const response=await fetch('/capture/RESULT.json',{method:'POST',body:JSON.stringify(data,null,2)});if(!response.ok)throw Error('capture failed');worker.terminate()};
worker.onerror=event=>{clearTimeout(timer);worker.terminate();globalThis.result={completed:false,error:event.message};document.querySelector('#result').textContent=JSON.stringify(result)};
</script>''')
server=(stage/'serve.py').read_text().replace("output=stage/'browser1'","output=stage/'late1'").replace("web=stage/'web'","web=stage/'web-late'")
(stage/'serve-late.py').write_text(server)
(stage/'WEB_LATE.json').write_text(json.dumps({p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()},indent=2)+'\n')
