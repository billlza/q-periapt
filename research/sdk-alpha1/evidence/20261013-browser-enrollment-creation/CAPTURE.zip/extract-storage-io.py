from pathlib import Path
repo=Path(__file__).resolve().parents[2]
path=repo/'crates/q-periapt-sdk-wasm/package/web/policy-database.js'
text=path.read_text();class_start=text.index('export class QPeriaptStorageError')
fail_start=text.index('const fail =');deadline_start=text.index('const DEADLINE =')
open_start=text.index('export function openDatabase(')
header='// SPDX-License-Identifier: Apache-2.0 OR MIT\n'
io=header+'// Shared browser I/O ownership; no policy or protocol decisions.\n'+text[class_start:fail_start]
io+='const fail = (code, cause) => new QPeriaptStorageError(code, cause);\n'
io+=text[deadline_start:open_start].replace('function pendingOperation(onTimeout)', 'export function pendingOperation(onTimeout)')
(path.parent/'storage-io.js').write_text(io)
imports='''import { QPeriaptStorageError, pendingOperation } from './storage-io.js';
export { QPeriaptStorageError, capabilities, lease, closeReceipt } from './storage-io.js';
'''
path.write_text(header+'// IndexedDB policy image operations; caller results and native receipts stay distinct.\n'+imports+text[fail_start:deadline_start]+text[open_start:])
browser=repo/'target/continuity-browser-storage/source/research/continuity-identity-candidate/src/storage/browser'
browser.mkdir()
for name in ('storage-catalogue.js','storage-database.js','storage-root.js'):
    source=repo/'target/continuity-browser-creation/web'/name
    body=source.read_text().replace("'./policy-database.js'", "'./storage-io.js'")
    (browser/name).write_text(body)
root=browser/'storage-root.js'
root.write_text(root.read_text()+'''
// Preserve both primary failure and cleanup status across the WASM error boundary.
export function combineFailures(primary, cleanup) {
  return fail(primary.code ?? 'NativeFailure', new AggregateError([primary, cleanup]));
}
''')
