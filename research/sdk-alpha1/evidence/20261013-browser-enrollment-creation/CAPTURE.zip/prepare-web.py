from pathlib import Path
import hashlib,json,os,shutil
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;web=stage/'web';pkg=web/'pkg'
assert json.loads((stage/'BUILD.json').read_text())['completed']
target=stage/'rust-target';wasm=target/'wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
sdk.command([str(repo/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(pkg),str(wasm)],stage/'bindgen',repo)
for name in ('policy-database.js','storage-catalogue.js','storage-database.js','storage-root.js'):
    shutil.copy2(web/name,pkg/name)
issuer=stage/'private-issuer';issuer.mkdir(mode=0o700)
binary=target/'debug/examples/browser_owned_enrollment'
env=dict(os.environ,DYLD_FALLBACK_LIBRARY_PATH='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
sdk.command([str(binary),'prepare',str(issuer)],stage/'native-prepare',repo,environment=env)
(web/'inputs').mkdir()
for name in ('root.bin','description.bin'):shutil.copy2(issuer/name,web/'inputs'/name)
sdk.write_json(stage/'WEB_BUILD.json',{'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),
    'native_binary':str(binary),'native_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
    'initial_js_sha256':{name:hashlib.sha256((web/name).read_bytes()).hexdigest() for name in ('policy-database.js','storage-catalogue.js','storage-database.js','storage-root.js')}})
