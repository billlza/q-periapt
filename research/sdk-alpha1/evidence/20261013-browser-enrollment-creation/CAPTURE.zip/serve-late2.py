from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import json,re,threading
stage=Path(__file__).resolve().parent;output=stage/'late2';output.mkdir(mode=0o700);web=stage/'web-late2'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(web),**kwargs)
    def log_message(self,format,*args):pass
    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp');self.send_header('Cache-Control','no-store');super().end_headers()
    def do_POST(self):
        if self.path=='/shutdown' and self.headers.get('Origin')==origin:
            self.send_response(200);self.end_headers();threading.Thread(target=server.shutdown,daemon=True).start();return
        match=re.fullmatch(r'/capture/([a-zA-Z0-9.-]+\.(?:bin|json))',self.path)
        length=int(self.headers.get('Content-Length','0'))
        if not match or not 0<length<=1048576:self.send_error(400);return
        if self.headers.get('Origin')!=origin:self.send_error(403);return
        target=output/match[1]
        try:
            with target.open('xb') as file:
                body=self.rfile.read(length)
                if len(body)!=length:raise ValueError('truncated capture')
                file.write(body)
        except (FileExistsError,ValueError):self.send_error(409);return
        self.send_response(201);self.end_headers();self.wfile.write(b'captured')
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);origin='http://127.0.0.1:'+str(server.server_port)
(output/'SERVER.json').write_text(json.dumps({'origin':origin,'web':str(web),'output':str(output)})+'\n')
print(origin,flush=True)
try:server.serve_forever()
finally:server.server_close()
