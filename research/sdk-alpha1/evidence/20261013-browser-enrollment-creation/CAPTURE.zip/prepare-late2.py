from pathlib import Path
import hashlib,json,shutil
stage=Path(__file__).resolve().parent;web=stage/'web-late2';shutil.copytree(stage/'web2',web)
shutil.copy2(stage/'late-worker2.js',web/'late-worker.js')
(web/'index.html').write_text((stage/'web-late/index.html').read_text())
server=(stage/'serve.py').read_text().replace("output=stage/'browser1'","output=stage/'late2'").replace("web=stage/'web'","web=stage/'web-late2'")
(stage/'serve-late2.py').write_text(server)
(stage/'WEB_LATE2.json').write_text(json.dumps({p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()},indent=2)+'\n')
