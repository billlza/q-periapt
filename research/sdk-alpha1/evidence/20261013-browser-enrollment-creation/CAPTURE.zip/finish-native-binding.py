from pathlib import Path
import hashlib,json,shutil
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;out=stage/'native-binding';consumer=out/'consumer'
record=json.loads((out/'RESULT.json').read_text());assert not record['completed']
for name,digest in record['inputs_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
fixture=consumer/'packages/q-periapt-continuity-identity-candidate-0.0.0'
shutil.copytree(repo/'research/continuity-identity-candidate',fixture)
record.update(completed=False,first_attempt='test fixture directory missing; retained original failure and populated the declared installed-test layout')
try:
    sdk.command(['sh',str(out/'cargo.sh'),'clippy','--all-features','--all-targets','--locked','--offline','--','-D','warnings'],out/'clippy2',consumer)
    wrapper=out/'cargo-msrv.sh'
    wrapper.write_text((out/'cargo.sh').read_text().replace('RUSTUP_TOOLCHAIN=1.98.1-aarch64-apple-darwin','RUSTUP_TOOLCHAIN=1.90.0-aarch64-apple-darwin'))
    sdk.command(['sh',str(wrapper),'check','--all-features','--all-targets','--locked','--offline'],out/'msrv-check',consumer)
    for name,digest in record['inputs_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
    record.update(completed=True,minimum_rust='1.90.0-aarch64-apple-darwin',strict_clippy='1.98.1-aarch64-apple-darwin')
finally:sdk.write_json(out/'RESULT2.json',record)
print('Current native C adapter and tests: strict Clippy and Rust 1.90 source checks passed')
