from pathlib import Path
import hashlib,json,os,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;output=stage/'native-verification3';output.mkdir(mode=0o700)
result=json.loads((stage/'browser2/RESULT.json').read_text());assert result['completed'] and len(result['cases'])==12
expected={'missing-root','root-before-commit','root-published','directory-created','staged-flush','enrollment-published','ready-before-commit','ready-published','delete-enrollment','delete-wrap','damage-catalogue','request-committed'}
assert {row['case'] for row in result['cases']}==expected
for name,digest in json.loads((stage/'WEB2.json').read_text()).items():assert hashlib.sha256((stage/'web2'/name).read_bytes()).hexdigest()==digest,name
build=json.loads((stage/'WEB_BUILD2.json').read_text());binary=Path(build['native_binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['native_binary_sha256']
assert len(result['captures'])==19
env=dict(os.environ,DYLD_FALLBACK_LIBRARY_PATH='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
verified=[]
for row in result['captures']:
    path=stage/'browser2'/row['name'];wire=path.read_bytes();assert len(wire)==5506 and hashlib.sha256(wire).hexdigest()==row['sha256']
    stdout=sdk.command([str(binary),'verify',str(stage/'private-issuer2'),str(path),str(output/(path.stem+'.credential'))],output/path.stem,repo,environment=env)
    match=re.fullmatch(rb'request_sha256=([0-9a-f]{64}) signing_identity=([0-9a-f]{64}) public_key_sha256=([0-9a-f]{64}) credential_sha256=([0-9a-f]{64})\n',stdout);assert match
    digest,identity,public,credential=[value.decode() for value in match.groups()]
    assert digest==row['sha256'] and credential==hashlib.sha256((output/(path.stem+'.credential')).read_bytes()).hexdigest()
    verified.append(dict(row,signing_identity=identity,public_key_sha256=public,credential_sha256=credential))
assert len({row['signing_identity'] for row in verified})==7
for row in result['cases']:
    if 'cut' in row:assert row['cut']['lease_observations'][-1]['count']==0
    if 'before' in row:
        assert row['before']['wrap_sha256']==row['after']['wrap_sha256']
        if row['before']['database_id']:assert row['before']['database_id']==row['after']['database_id']
        assert row['resumed']['sha256']==row['reopened']['sha256']==row['repeated']['sha256']
    if row['case']=='request-committed':assert row['cut']['requestDigest']==row['request']['sha256']
record={'completed':True,'cases':12,'requests_verified':19,'distinct_original_signers':7,'requests':verified,
        'scope':'actual browser-generated keys and eight Worker termination boundaries; same Rust protocol implementation, not independent-implementation interoperability; full operational browser lifecycle remains open'}
sdk.write_json(output/'RESULT.json',record)
print(json.dumps({key:value for key,value in record.items() if key!='requests'}))
