from pathlib import Path
import hashlib,json,subprocess
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;source=repo/'target/continuity-browser-storage/source'
text=(stage/'verify-browser.py').read_text().replace("output=stage/'native-verification'","output=stage/'native-verification2'").replace("stage/'browser1", "stage/'browser2").replace("stage/'WEB1.json'", "stage/'WEB2.json'").replace("stage/'WEB_BUILD.json'", "stage/'WEB_BUILD2.json'").replace("stage/'private-issuer'", "stage/'private-issuer2'")
(stage/'verify-browser2.py').write_text(text)
build=json.loads((stage/'BUILD3.json').read_text());assert build['completed']
for name,digest in build['inputs_sha256'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
assert json.loads((stage/'browser2/RESULT.json').read_text())['completed']
late=json.loads((stage/'late2/RESULT.json').read_text());assert late['completed'] and len(late['cases'])==5
for row in late['cases'][:4]:
    assert 'ClosePending' in row['causes'] and 'Busy' in row['concurrent'] and row['release_observations'][-1]==0
changed=subprocess.check_output(['git','diff','--name-only','--','research/continuity-identity-candidate'],cwd=source,text=True).splitlines()
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','research/continuity-identity-candidate'],cwd=source,text=True).splitlines()
assert len(set(changed+added))==len(changed+added)
for name in changed:
    original=subprocess.check_output(['git','show',build['source_base']+':'+name],cwd=source)
    assert (repo/name).read_bytes()==original,'main changed independently: '+name
for name in added:assert not (repo/name).exists(),'new path already present: '+name
for name in changed+added:
    target=repo/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((source/name).read_bytes())
record={'prototype_source_base':build['source_base'],'main_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
        'files_sha256':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changed+added},
        'shared_storage_io_sha256':hashlib.sha256((repo/'crates/q-periapt-sdk-wasm/package/web/storage-io.js').read_bytes()).hexdigest(),
        'scope':'candidate enrollment storage engine and explicit experimental browser owner; operational browser lifecycle remains unadmitted'}
(stage/'INTEGRATED.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'changed':len(changed),'added':len(added),'scope':record['scope']}))
