from pathlib import Path
import hashlib,shutil
stage=Path(__file__).resolve().parent;repo=stage.parent.parent
out=repo/'research/sdk-alpha1/evidence/20261013-browser-enrollment-creation'
assert hashlib.sha256((out/'CAPTURE.zip').read_bytes()).hexdigest()=='2459fff5c332d3c4c7439bd0ca98cd93c8cf17de6394d2b3b136980390d75e93'
retained=stage/'capture-initial';retained.mkdir(mode=0o700)
for name in ('CAPTURE.zip','CHECKS.json'):shutil.move(out/name,retained/name)
