from pathlib import Path
import hashlib,json,os,subprocess
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;repo=stage.parent.parent;source=repo/'target/continuity-browser-storage/source'
wrapper=stage/'cargo.sh'
wrapper.write_text((repo/'target/continuity-browser-engine/cargo.sh').read_text().replace(str(repo/'target/continuity-browser-engine/rust-target'),str(stage/'rust-target')))
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','crates','research/continuity-identity-candidate'],cwd=source,text=True).splitlines()
inputs={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in names if (source/name).is_file()}
state={'completed':False,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'inputs_sha256':inputs}
try:
    sdk.command(['sh',str(wrapper),'build','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--target','wasm32-unknown-unknown','--release','--locked','--offline'],stage/'wasm-build2',source)
    sdk.command(['sh',str(wrapper),'build','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--example','browser_owned_enrollment','--locked','--offline'],stage/'native-issuer',source)
    for name,digest in inputs.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
    state['completed']=True
finally:sdk.write_json(stage/'BUILD.json',state)
print('Frozen-source WASM and native issuer builds completed')
