from pathlib import Path
import os, subprocess, sys, json, time, hashlib, shlex
from continuity_c_enrollment import PUBLICATION_TEST, export
import continuity_kotlin_consumer as gate

b = Path(__file__).resolve().parent
outside = Path(json.loads((b/'KOTLIN_PUBLICATION_OUTSIDE.json').read_text())['path'])
build = json.loads((b/'kotlin-publication-consumer-build-02/RESULT.json').read_text())
assert build['returncode'] == 0 and len(build['runtime_closure']) == 3
profile, collector = sys.argv[1:]
assert profile in ('debug', 'release') and collector in ('serial', 'g1')
out = b/('kotlin-publication-runtime-'+profile+'-'+collector+'-01')
out.mkdir(mode=0o700)
java = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java')
native = b/('swift-publication-installed-native-'+profile)/'libq_periapt_continuity_c_consumer.dylib'
distribution = outside/'consumer-qualified/build/install/continuity-installed-consumer'
jars = sorted((distribution/'lib').glob('*.jar'))
gate.runtime_closure((outside/'consumer-qualified/build/runtime.tsv').read_bytes(), distribution, build['maven']['jar_sha256'], outside)
flags = ['-Xms32m', '-Xmx128m', '-XX:+UseSerialGC' if collector == 'serial' else '-XX:+UseG1GC',
         '--enable-native-access=ALL-UNNAMED', '--illegal-native-access=deny', '-Dqperiapt.continuity.lib='+str(native)]
launcher = outside/('publication-client-'+profile+'-'+collector)
launcher.write_text('#!/bin/sh\nexec '+shlex.join([str(java), *flags, '-cp', ':'.join(map(str,jars)), 'consumer.ContinuityClientKt'])+' "$@"\n')
launcher.chmod(0o700)
label = 'publication-c-test-build-'+profile+('-03' if profile == 'debug' else '-02')
assert json.loads((b/label/'RESULT.json').read_text())['returncode'] == 0
rows = [json.loads(line) for line in (b/label/'stdout.log').read_text().splitlines()]
paths = [Path(row['executable']) for row in rows if row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'enrollment' and row.get('executable')]
assert len(paths) == 1
harness = paths[0]
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
inputs = {str(path):sha(path) for path in [java, native, harness, launcher, *jars]}
env = {k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK','GRADLE','KOTLIN','CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', QPERIAPT_C_OWNER_CLIENT=str(launcher),
           QPERIAPT_INSTALLED_CLIENT_LANGUAGE='Kotlin', QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'evidence'))
command = [str(harness), '--exact', PUBLICATION_TEST, '--nocapture']
started = time.monotonic()
with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
    process = subprocess.run(command, cwd=b/'publication-consumer', env=env, stdout=stdout, stderr=stderr, timeout=400)
result = dict(command=command, returncode=process.returncode, seconds=time.monotonic()-started,
              binaries=inputs, binaries_unchanged=all(sha(Path(path)) == digest for path,digest in inputs.items()),
              collector=collector, vm_flags=flags,
              scope='Private Maven consumer through the selected shared native library; actual registered device publication and exact reopen, followed by normal application traffic. The C-specific short-buffer probe is separate, not a Kotlin CLI operation.')
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'binaries'}),flush=True)
if process.returncode:
    print((out/'stderr.log').read_text()[-7000:],flush=True)
assert result['binaries_unchanged']
process.check_returncode()
verified = export((out/'stdout.log').read_bytes(),out/'evidence',out/'public-readback',language='Kotlin',publication=True)
(out/'VERIFIED.json').write_text(json.dumps(verified,indent=2)+'\n')
print(json.dumps({'public_readback_completed':verified['completed']}),flush=True)
