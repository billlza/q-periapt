from pathlib import Path
import json, hashlib, datetime, zipfile
import continuity_kotlin_consumer as gate

b = Path(__file__).resolve().parent
root = b.parents[1]
out = root/'research/sdk-alpha1/evidence/20261009-kotlin-publication'
main = root/'bindings/kotlin/ContinuityPackageConsumer'
compiled = b/'kotlin-publication/bindings/kotlin/ContinuityPackageConsumer'
outside = Path(json.loads((b/'KOTLIN_PUBLICATION_OUTSIDE.json').read_text())['path'])
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
inputs = {str(p.relative_to(main)):sha(p) for top in ('src','consumer/src') for p in (main/top).rglob('*') if p.is_file()}
for name in ('build.gradle.kts','settings.gradle.kts','gradle/verification-metadata.xml','consumer/build.gradle.kts','consumer/settings.gradle.kts'):
    inputs[name] = sha(main/name)
assert all(sha(compiled/name) == digest for name,digest in inputs.items())
assert all(sha(outside/'consumer-qualified'/name.removeprefix('consumer/')) == digest for name,digest in inputs.items() if name.startswith('consumer/'))
contract = gate.maven_contract()
verified_maven = gate.jvm.verify_maven(outside/'maven',contract=contract)
with zipfile.ZipFile(outside/'maven'/contract.path/(contract.prefix+'-sources.jar')) as archive:
    for path in (main/'src/main/kotlin').rglob('*.kt'):
        assert archive.read(str(path.relative_to(main/'src/main/kotlin'))) == path.read_bytes()
build = json.loads((b/'kotlin-publication-consumer-build-02/RESULT.json').read_text())
assert build['returncode'] == 0 and build['maven']['jar_sha256'] == verified_maven['jar_sha256']
closure = gate.runtime_closure((outside/'consumer-qualified/build/runtime.tsv').read_bytes(),
    outside/'consumer-qualified/build/install/continuity-installed-consumer', verified_maven['jar_sha256'],outside)
files = {}; profiles = {}; tests = {}
for profile,label in [('debug','kotlin-publication-debug-02'),('release','kotlin-publication-release-01')]:
    result = json.loads((b/label/'RESULT.json').read_text()); assert result['returncode'] == 0
    checked = gate.verify_test_reports(b/label/'test-reports'); assert checked['tests'] == 58
    tests[profile] = {'run':result,'reports':checked}
    for path in (b/label).rglob('*'):
        if path.is_file(): files['runs/'+label+'/'+str(path.relative_to(b/label))] = path
    for collector in ('serial','g1'):
        label = 'kotlin-publication-runtime-'+profile+'-'+collector+'-01'
        result = json.loads((b/label/'RESULT.json').read_text())
        verified = json.loads((b/label/'VERIFIED.json').read_text())
        assert result['returncode'] == 0 and result['binaries_unchanged'] and verified['completed']
        assert len(verified['public_readbacks']) == 85
        assert all(sha(Path(path)) == digest for path,digest in result['binaries'].items())
        profiles[profile+'-'+collector] = {'runtime':result,'public_readback':verified}
        for path in (b/label).iterdir():
            if path.is_file(): files['runs/'+label+'/'+path.name] = path
        for path in (b/label/'public-readback').rglob('*'):
            if path.is_file(): files['public/'+profile+'-'+collector+'/'+str(path.relative_to(b/label/'public-readback'))] = path
native_label = 'publication-owner-interface-full-debug-01'
native = json.loads((b/native_label/'RESULT.json').read_text())
assert native['returncode'] == 0 and all(sha(root/'research/continuity-identity-candidate'/path) == digest for path,digest in native['inputs'].items())
assert '816 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (b/native_label/'stdout.log').read_text()
for label in ('kotlin-publication-debug-01','kotlin-publication-consumer-build-01','kotlin-publication-consumer-build-02',native_label):
    for path in (b/label).iterdir():
        if path.is_file(): files['runs/'+label+'/'+path.name] = path
for name in ('KOTLIN_PUBLICATION_STAGING_REFUSAL.json','KOTLIN_PUBLICATION_CLOSURE_REFUSAL.json','SWIFT_PUBLICATION_LIBRARY_LAYOUT.json',
             'kotlin-publication-reader-tests.stdout','kotlin-publication-reader-tests.stderr','kotlin-publication-reader-tests-02.stdout','kotlin-publication-reader-tests-02.stderr'):
    files['inspection/'+name] = b/name
assert 'Ran 11 tests' in (b/'kotlin-publication-reader-tests-02.stderr').read_text() and (b/'kotlin-publication-reader-tests-02.stderr').read_text().endswith('OK\n')
for name in ('run-kotlin-publication.py','run-kotlin-publication-release.py','build-kotlin-publication-consumer.py','build-kotlin-publication-consumer-02.py',
             'run-kotlin-publication-registration.py','seal-kotlin-publication.py'):
    files['drivers/'+name] = b/name
for path in (outside/'maven').rglob('*'):
    if path.is_file() and not path.name.endswith('.jar'): files['maven/'+str(path.relative_to(outside/'maven'))] = path
files['runtime.tsv'] = outside/'consumer-qualified/build/runtime.tsv'
out.mkdir()
with zipfile.ZipFile(out/'CAPTURES.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()): archive.write(path,name)
with zipfile.ZipFile(out/'CAPTURES.zip') as archive:
    assert archive.testzip() is None and all(hashlib.sha256(archive.read(name)).hexdigest() == sha(path) for name,path in files.items())
result = dict(schema_version=1,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    native_source_commit='a71195ec72e83a270a6af096e38d50f92ca3f08c', kotlin_compiled_inputs=inputs,
    maven=verified_maven, runtime_closure=closure, tests=tests, profiles=profiles, native_full_tests=816,
    captures=dict(file='CAPTURES.zip',sha256=sha(out/'CAPTURES.zip'),bytes=(out/'CAPTURES.zip').stat().st_size,members=len(files)),
    scope='Private Maven consumer outside the checkout with exact pinned dependencies, Debug/Release source-built native C/Rust libraries and Serial/G1. Original registration, complete local publication, exact retry, cancellation and retirement, followed by normal application traffic. Shared protocol engine; the traffic still uses a remote fixture advertisement. No claim of independent protocol verification, complete installed-distribution qualification or release.',
    initial_refusals=['Exact JVM layout test omitted the three new layouts; expected map expanded without relaxing equality.',
                     'Maven staging included parent metadata; original tree retained and exact version inventory staged.',
                     'Consumer initially resolved dependencies from the checkout cache; fresh external consumer used a copied cache and passed unchanged location/byte validation.',
                     'Attempt to pin dependencies twice was refused by exclusive creation; fresh external consumer prepared.',
                     'Reader report inventory omitted the new PublicationTests file; explicit expected inventory corrected.'],
    remaining=['Successor must use its owned publication for actual remote connection instead of native fixture prekeys.',
               'Complete current-source installed distribution and current-head CI.',
               'Old-binary v22 refusal, independent implementation, physical/minOS/platform storage, external review and recovery security analysis.'],
    remote_registry_publication=False, release_claim_eligible=False)
(out/'QUALIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['captures']))
