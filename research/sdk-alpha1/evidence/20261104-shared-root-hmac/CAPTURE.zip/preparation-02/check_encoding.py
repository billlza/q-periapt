from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import time
import tomllib

import rust_sdk_profile as sdk

ROOT = Path.cwd()
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
BASE = ROOT / 'target/continuity-hmac-joint-reduction'
FIXTURE = BASE / 'encoding-check'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
REGISTRY = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-continuity-package-g03ryny6/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f')
LOCK = SOURCE / 'research/continuity-identity-candidate/Cargo.lock'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
packages = tomllib.loads(LOCK.read_text())['package']
by_name = {}
for package in packages:
    by_name.setdefault(package['name'], []).append(package)


def resolve(dependency):
    fields = dependency.split()
    matches = [p for p in by_name[fields[0]] if len(fields) == 1 or p['version'] == fields[1]]
    assert len(matches) == 1, dependency
    return matches[0]


todo = [resolve('hmac'), resolve('hkdf'), resolve('sha2 0.11.0')]
selected = {}
while todo:
    package = todo.pop()
    key = (package['name'], package['version'])
    if key in selected:
        continue
    assert package['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
    selected[key] = package
    todo.extend(resolve(item) for item in package.get('dependencies', []))

state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'scope': 'Finite byte-encoding comparison with pinned real HMAC/HKDF/SHA-256 libraries, not a security proof.',
         'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
         'source_checkout': str(SOURCE),
         'candidate_lock_sha256': digest(LOCK), 'command_timeout_seconds': 900,
         'network_access_required': False, 'product_sources_modified': False}
started = time.monotonic()
try:
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (state['source_commit'], False)
    vendor = FIXTURE / 'vendor'
    vendor.mkdir(exist_ok=False)
    dependency_records = {}
    for (name, version), package in sorted(selected.items()):
        source = REGISTRY / f'{name}-{version}'
        checksum = json.loads((source / '.cargo-checksum.json').read_bytes())
        assert checksum['package'] == package['checksum']
        for relative, expected in checksum['files'].items():
            path = source / relative
            assert path.is_file() and not path.is_symlink() and digest(path) == expected
        shutil.copytree(source, vendor / source.name)
        dependency_records[source.name] = {'package_sha256': package['checksum'],
                                           'files': checksum['files']}
    (FIXTURE / '.cargo').mkdir(exist_ok=False)
    (FIXTURE / '.cargo/config.toml').write_text('[source.crates-io]\nreplace-with = "vendored-sources"\n\n[source.vendored-sources]\ndirectory = "vendor"\n')
    tools = {name: digest(CHAIN / 'bin' / name) for name in ['cargo', 'rustc', 'rustfmt']}
    product_files = [SOURCE / 'research/continuity-identity-candidate' / name for name in [
        'Cargo.toml', 'Cargo.lock', 'src/durable/messages.rs',
        'src/durable/messages/rekey/response.rs', 'src/durable/messages/rekey/completion.rs']]
    before = {str(path.relative_to(SOURCE)): digest(path) for path in product_files}
    assert all(digest(ROOT / name) == expected for name, expected in before.items())
    sdk.write_json(BASE / 'ENCODING_INPUTS.json', {'product_files': before,
        'tools': tools, 'dependency_sources': dependency_records,
        'driver_sha256': digest(Path(__file__)),
        'fixture_sources': {name: digest(FIXTURE / name) for name in ['Cargo.toml', 'src/main.rs', '.cargo/config.toml']}})
    environment = dict(os.environ, PATH=str(CHAIN / 'bin') + os.pathsep + os.environ['PATH'],
                       CARGO_HOME=str(FIXTURE / 'cargo-home'), RUSTC=str(CHAIN / 'bin/rustc'),
                       RUSTDOC=str(CHAIN / 'bin/rustdoc'), RUSTFLAGS='-D warnings',
                       CARGO_TARGET_DIR=str(FIXTURE / 'target'), CARGO_NET_OFFLINE='true',
                       CARGO_TERM_COLOR='never')
    sdk.validate_no_registry_credentials(environment)
    sdk.command([str(CHAIN / 'bin/cargo'), 'generate-lockfile', '--offline'], BASE / 'encoding-lock', FIXTURE, environment=environment)
    output = sdk.command([str(CHAIN / 'bin/cargo'), 'run', '--locked', '--offline'], BASE / 'encoding-run', FIXTURE, environment=environment)
    observed = json.loads(output)
    assert observed['row_checks'] == observed['wrong_offset_rejected'] == 56
    assert observed['column_checks'] == observed['extract_checks'] == 16
    assert observed['shared_pair_checks'] == observed['absent_zero_salt_checks'] == 4
    for package in tomllib.loads((FIXTURE / 'Cargo.lock').read_text())['package']:
        if 'source' in package:
            key = (package['name'], package['version'])
            assert package['checksum'] == selected[key]['checksum']
    assert {str(path.relative_to(SOURCE)): digest(path) for path in product_files} == before
    assert all(digest(ROOT / name) == expected for name, expected in before.items())
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (state['source_commit'], False)
    assert {name: digest(CHAIN / 'bin' / name) for name in tools} == tools
    sdk.write_json(BASE / 'ENCODING_OBSERVED.json', observed)
    state.update(completed=True, observed=observed, product_files_unchanged=True,
                 tools_unchanged=True, fixture_lock_sha256=digest(FIXTURE / 'Cargo.lock'),
                 fixture_binary_sha256=digest(FIXTURE / 'target/debug/continuity-hmac-encoding-check'))
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    with (BASE / 'ENCODING_RESULT.json').open('xb') as stream:
        stream.write(encode(state))
    print(json.dumps(state, indent=2))
