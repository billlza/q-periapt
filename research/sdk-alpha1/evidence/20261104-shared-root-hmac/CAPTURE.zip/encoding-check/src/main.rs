use hkdf::Hkdf;
use hmac::{Hmac, KeyInit, Mac};
use sha2::{block_api::compress256, Sha256};

const IV: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

fn digest(state: [u32; 8]) -> [u8; 32] {
    let mut result = [0_u8; 32];
    for (chunk, word) in result.chunks_exact_mut(4).zip(state) {
        chunk.copy_from_slice(&word.to_be_bytes());
    }
    result
}

fn state(bytes: [u8; 32]) -> [u32; 8] {
    let mut result = [0_u32; 8];
    for (word, chunk) in result.iter_mut().zip(bytes.chunks_exact(4)) {
        *word = u32::from_be_bytes(chunk.try_into().expect("four-byte chunk"));
    }
    result
}

fn h(block: [u8; 64], initial: [u8; 32]) -> [u8; 32] {
    let mut value = state(initial);
    compress256(&mut value, &[block]);
    digest(value)
}

fn key_pad(key: [u8; 32], byte: u8) -> [u8; 64] {
    let mut block = [byte; 64];
    for (entry, key_byte) in block.iter_mut().zip(key) {
        *entry ^= key_byte;
    }
    block
}

fn padded(message: &[u8], prior_bytes: u64) -> Vec<[u8; 64]> {
    let length = u64::try_from(message.len()).expect("representable fixture length");
    let bit_length = prior_bytes.checked_add(length).expect("length sum")
        .checked_mul(8).expect("SHA-256 length field");
    let mut bytes = message.to_vec();
    bytes.push(0x80);
    while bytes.len() % 64 != 56 {
        bytes.push(0);
    }
    bytes.extend_from_slice(&bit_length.to_be_bytes());
    bytes.chunks_exact(64).map(|chunk| chunk.try_into().expect("complete block")).collect()
}

fn iterate(initial: [u8; 32], message: &[u8], prior_bytes: u64) -> [u8; 32] {
    let mut value = state(initial);
    compress256(&mut value, &padded(message, prior_bytes));
    digest(value)
}

fn b(value: [u8; 32]) -> [u8; 64] {
    let mut block = [0_u8; 64];
    block[..32].copy_from_slice(&value);
    block[32] = 0x80;
    block[56..].copy_from_slice(&768_u64.to_be_bytes());
    block
}

fn library_hmac(key: [u8; 32], message: &[u8]) -> [u8; 32] {
    let mut mac = <Hmac<Sha256> as KeyInit>::new_from_slice(&key).expect("32-byte key");
    mac.update(message);
    mac.finalize().into_bytes().into()
}

fn row(key: [u8; 32], message: &[u8], prior_bytes: u64) -> [u8; 32] {
    let alpha = h(key_pad(key, 0x36), digest(IV));
    let beta = h(key_pad(key, 0x5c), digest(IV));
    let inner = iterate(alpha, message, prior_bytes);
    iterate(beta, &inner, prior_bytes)
}

fn column(salt: [u8; 32], root: [u8; 32]) -> [u8; 32] {
    let alpha = h(key_pad(salt, 0x36), digest(IV));
    let beta = h(key_pad(salt, 0x5c), digest(IV));
    h(b(h(b(root), alpha)), beta)
}

fn hexadecimal(bytes: [u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn main() {
    let mut ascending = [0_u8; 32];
    for (index, byte) in ascending.iter_mut().enumerate() {
        *byte = u8::try_from(index).expect("fixture index");
    }
    let roots = [[0; 32], [0xff; 32], ascending, [0xa5; 32]];
    let lengths = [0_usize, 1, 31, 32, 55, 56, 63, 64, 65, 119, 120, 127, 128, 1024];
    let mut row_checks = 0;
    let mut wrong_offset_rejected = 0;
    let mut column_checks = 0;
    let mut extract_checks = 0;
    for root in roots {
        assert_eq!(padded(&root, 64), vec![b(root)]);
        let i = key_pad(root, 0x36);
        let o = key_pad(root, 0x5c);
        assert_ne!(&i[32..], &o[32..]);
        assert_ne!(&i[32..], &b(root)[32..]);
        assert_ne!(&o[32..], &b(root)[32..]);
        for length in lengths {
            let message: Vec<u8> = (0..length).map(|index| {
                u8::try_from((index * 37 + 11) % 256).expect("fixture byte")
            }).collect();
            let actual = library_hmac(root, &message);
            assert_eq!(actual, row(root, &message, 64));
            row_checks += 1;
            assert_ne!(actual, row(root, &message, 0), "unshifted padding must be detected");
            wrong_offset_rejected += 1;
            assert_eq!(padded(&message, 64).len(), (length + 9).div_ceil(64));
        }
        for salt in roots {
            assert_eq!(library_hmac(salt, &root), column(salt, root));
            column_checks += 1;
            let (prk, _) = Hkdf::<Sha256>::extract(Some(&salt), &root);
            assert_eq!(prk.as_slice(), column(salt, root));
            extract_checks += 1;
        }
        assert_eq!(row(root, &root, 64), column(root, root));
        let (prk_absent, _) = Hkdf::<Sha256>::extract(None, &root);
        let (prk_zero, _) = Hkdf::<Sha256>::extract(Some(&[0; 32]), &root);
        assert_eq!(prk_absent, prk_zero);
        assert_eq!(prk_absent.as_slice(), column([0; 32], root));
    }
    println!("{{\"row_checks\":{row_checks},\"wrong_offset_rejected\":{wrong_offset_rejected},\"column_checks\":{column_checks},\"extract_checks\":{extract_checks},\"shared_pair_checks\":4,\"absent_zero_salt_checks\":4,\"roots\":4,\"message_lengths\":{lengths:?},\"zero_root_zero_message_hmac\":\"{}\",\"ascending_root_self_hmac\":\"{}\"}}", hexadecimal(library_hmac([0; 32], &[0; 32])), hexadecimal(library_hmac(ascending, &ascending)));
}
