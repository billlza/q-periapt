from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-hmac-joint-reduction'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261104-shared-root-hmac'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
digest = lambda body: hashlib.sha256(body).hexdigest()
result = json.loads((BASE / 'ENCODING_RESULT.json').read_bytes())
inputs = json.loads((BASE / 'ENCODING_INPUTS.json').read_bytes())
assert result['completed'] and result['product_files_unchanged'] and result['tools_unchanged']
assert result['source_commit'] == 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
assert digest((BASE / 'DRAFT.md').read_bytes()) == '839074528e9e972289838ad18b13be5891e6beba232488c08b3cd233055b309b'
assert digest((BASE / 'REVIEW.md').read_bytes()) == 'cd74b4205630c467c93aae47aa30cbe82dccfa1f89c01d1232be0f80b56b66f2'
assert '839074528e9e972289838ad18b13be5891e6beba232488c08b3cd233055b309b' in (BASE / 'REVIEW.md').read_text()
assert digest((BASE / 'encoding-check/Cargo.lock').read_bytes()) == result['fixture_lock_sha256']
assert digest((BASE / 'encoding-check/target/debug/continuity-hmac-encoding-check').read_bytes()) == result['fixture_binary_sha256']
for name, expected in inputs['fixture_sources'].items():
    assert digest((BASE / 'encoding-check' / name).read_bytes()) == expected
for command in ['encoding-lock', 'encoding-run']:
    assert json.loads((BASE / (command + '.json')).read_bytes())['returncode'] == 0
    sdk.validate_cargo_output(command, [(BASE / (command + '.' + stream)).read_text() for stream in ['stdout', 'stderr']])
assert json.loads((BASE / 'encoding-run.stdout').read_bytes()) == result['observed']
assert json.loads((BASE / 'ENCODING_OBSERVED.json').read_bytes()) == result['observed']

names = ['DRAFT.md', 'REVIEW.md', 'check_encoding.py', 'check_encoding-initial.py',
         'encoding-initial-driver.stdout', 'encoding-initial-driver.stderr',
         'encoding-driver.stdout', 'encoding-driver.stderr',
         'ENCODING_INPUTS.json', 'ENCODING_RESULT.json', 'ENCODING_OBSERVED.json',
         'encoding-check/Cargo.toml', 'encoding-check/Cargo.lock',
         'encoding-check/src/main.rs', 'encoding-check/.cargo/config.toml']
names.extend(command + '.' + suffix for command in ['encoding-lock', 'encoding-run'] for suffix in ['json', 'stdout', 'stderr'])
names.extend(directory + '/' + name for directory in ['preparation-02', 'preparation-03']
             for name in ['check_encoding.py', 'encoding-driver.stdout', 'encoding-driver.stderr', 'ORIGINAL_RESULT.json'])
files = {name: (BASE / name).read_bytes() for name in names}
files['seal.py'] = Path(__file__).read_bytes()
files['SHARED_ROOT_HMAC_V1.md'] = (ROOT / 'docs/continuity/SHARED_ROOT_HMAC_V1.md').read_bytes()
for name, expected in inputs['product_files'].items():
    body = (SOURCE / name).read_bytes()
    assert digest(body) == expected and (ROOT / name).read_bytes() == body
    files['source/' + name] = body

assessment = {
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Conditional single-root HMAC Row/Col reduction in one ideal compression QROM, plus finite real-dependency encoding checks.',
    'draft_sha256': digest(files['DRAFT.md']), 'review_sha256': digest(files['REVIEW.md']),
    'review_kind': 'Independent internal mathematical applicability check, followed by primary-source and simulation review by the integrating author.',
    'review_clarifications_applied': ['Joint product initialization with every oracle-dependent preparation query counted.',
        'Length bound 8*(64+L)<2^64 includes the consumed key pad.',
        'Real/J output-probability bound; the independent-table I endpoint precedes equality repair.'],
    'primary_sources': [
        {'url': 'https://arxiv.org/pdf/2206.08132', 'passages': 'Section 4.2 Theorem 2, conditions (6)-(7), and the adaptive-loss accounting in Section 4.3.'},
        {'url': 'https://eprint.iacr.org/2021/774.pdf', 'passages': 'Sections 2, 4 Proposition 4, 5 Proposition 6, Appendix D one-block outer padding and Appendix E shifted padding.',
         'retrieval': 'Original indexed full text; direct PDF retrieval returned 403. No downloaded-binary hash or visual PDF verification claimed.'}],
    'encoding_result': result,
    'preparation_failures': [
        {'attempt': 1, 'execution_started': False, 'reason': 'The whole-MAIN cleanliness guard rejected existing ignored bytecode and retained untracked source inputs. Use the actual clean qualification clone and compare each relevant file with MAIN; do not relax the guard.'},
        {'attempt': 2, 'execution_started': False, 'reason': 'The preparer wrongly expected cargo-vendor checksum metadata in a Cargo registry extraction. Pinned original crate archives exist and must be verified directly.'},
        {'attempt': 3, 'execution_started': False, 'reason': 'The SDK-specific archive reader additionally requires package inputs that arbitrary registry crates need not contain. A separate isolated vendor reader verifies pinned archive hashes, safe regular members and normalized package identity. Product readers remain unchanged.'}],
    'negative_control': 'Unshifted padding differs from the real library in all 56 retained cases; these finite comparisons are not a theorem.',
    'not_claimed': ['Machine-checked computational proof', 'Concrete SHA-256 ideality', 'Actual accepted-prefix simulation',
                    'Full leakage or multi-epoch composition', 'External review', 'Release qualification'],
    'product_source_changed': False, 'dependency_upgrade': False, 'new_product_assumption_adopted': False,
}
files['ASSESSMENT.json'] = encode(assessment)
manifest = {name: {'bytes': len(body), 'sha256': digest(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']), ('ASSESSMENT.json', files['ASSESSMENT.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': digest(payload)}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
