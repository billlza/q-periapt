# Candidate reduction for a shared 32-byte HMAC root

Draft for a full correctness audit. This is a proposed reduction in the quantum
random-oracle model of the SHA-256 compression function, not a claim that concrete
SHA-256 is a random oracle, an accepted-prefix proof, a multi-epoch theorem or an
external review. It changes no product primitive, format or API. The construction
and all reductions below must be checked before promotion into the security note.

## Experiment and exact encodings

Let h : {0,1}^512 x {0,1}^256 -> {0,1}^256 be one public quantum random oracle,
with arguments (message block, chaining value). IV is the actual fixed SHA-256
initial state. Let R be uniformly random in {0,1}^256, independently of h and
the algorithm's initial auxiliary state. All oracle-dependent prefix preparation
is part of the algorithm and is counted. The algorithm has no raw-R, state,
compression-midstate or ciphertext-disclosure interface.

It may make q quantum queries to h, C classical queries to Col(a)=HMAC(a,R),
where a is exactly 32 bytes, and T classical queries to Row(m)=HMAC(R,m), where
|m|<=L bytes. Queries may be adaptive. Equal arguments are cached consistently.
The message-length bound must be below SHA-256's length-encoding limit.

For a 32-byte x define the following 64-byte blocks, writing byte concatenation
and bytewise XOR explicitly; 0^r denotes r zero bytes:

    I(x) = (x || 0^32) XOR 0x36^64
    O(x) = (x || 0^32) XOR 0x5c^64
    B(x) = x || P
    P    = 0x80 || 0^23 || BE64(768)

P has 32 bytes. The encoded length is 768 bits because one 64-byte HMAC key pad
has already been compressed before the 32-byte message/digest. The last 32 bytes
of I(x), O(x), B(x) are respectively 0x36^32, 0x5c^32, P. These are distinct,
so the three block ranges are disjoint, for all x, without a probabilistic event.
Each map is injective in x.

Define alpha(a)=h(I(a),IV), beta(a)=h(O(a),IV), and Gamma(a)=(alpha(a),beta(a)).
The column is exactly

    Col(a) = h(B(h(B(R),alpha(a))), beta(a)).

For the row, let pad64(m) be m followed by SHA-256 padding whose encoded bit
length is 8*(64+|m|), not 8*|m|. Write Iter_h(s,blocks) for compression starting
at s. Then

    Row(m) = Iter_h(beta(R), pad64(Iter_h(alpha(R),pad64(m)))).

This is an NMAC form with the fixed 64-byte length offset in both padding calls.
It is not byte-identical to NMAC using an unshifted length suffix. pad64 is
injective, appends a suffix depending only on length, and yields complete blocks.
Set ell=1+ceil((L+9)/64); this bounds both the relevant padded-message block count
and all ordinary row compression calls after its two private key-pad calls.

The source checks use hmac 0.13.0 (`get_der_key`, `HmacCore::new_from_slice`,
`finalize_fixed_core`) and sha2 0.11.0 (`Sha256VarCore::update_blocks` and
`finalize_variable_core`). The former zero-pads a short key and precompresses both
key pads; the latter retains that consumed-block count in the final length field.
The candidate lock contains both sha2 0.10.9 and 0.11.0; the relevant HMAC/HKDF
path must continue to be tied to its actual selected 0.11.0 dependency.

## First hybrid: replace only the compression calls containing raw R

Define F_R(tag,s)=h(tau_tag(R),s), with tau_in=I, tau_out=O, tau_message=B.
For each fixed (tag,s), the encoded point has probability at most 2^-256.
For distinct effective (tag,s) pairs, encoded points differ for every R: distinct
tags have disjoint block ranges and equal tags retain the distinct chaining value.

The two private interfaces can be evaluated using F_R, ordinary h calls and no
other raw use of R. Cache equal (tag,s) calls before using the private function.
There are at most C+2 fresh private calls: two fixed key-pad calls and at most C
message-block calls. There are at most Q1=q+3C+ell*T ordinary h calls, counting
the column's two public pad states and one outer call, and all row continuation
calls. Caller-chosen a or m may accidentally equal R; do not forbid this.

Apply Don, Fehr and Huang, Theorem 2, to this exact encoding:

    E1 = min(1, 4 sqrt(2 (C+2)^2 Q1 / 2^256)
                + 4 sqrt(2 Q1^2 (C+2) / 2^256)).

Source: https://arxiv.org/pdf/2206.08132, section 4.2.
The resulting private random table has mutually independent restrictions:
A=F(in,IV), D=F(out,IV), and f(s)=F(message,s), all independent of h. Reusing
A and D across row calls is mandatory. f is a random function, not a newly
sampled value on every repeated state. It is never directly exposed to the caller.

Now Row is NMAC_{A,D}^{pad64}; Col(a)=h(B(f(alpha(a))),beta(a)). These formulas
are statements about the first ideal hybrid. They do not assert that real
HMAC midstate values were independent before the replacement.

## Second hybrid: replace the row while retaining the actual column simulation

Apply Hosoyamada and Iwata, Proposition 6, to the NMAC row, with n=256, m=512,
independent 256-bit keys A,D, and the admissible pad64 padding. The adversary in
that reduction simulates each classical column by maintaining its own independent
f table and making the three necessary h calls. Thus Q=T and q_h<=q+3C.

Denote the proposition's bound by E_NMAC(T,q+3C,ell). Its stated asymptotic form
is O(sqrt((q+3C+T)^3 * ell^5 / 2^256)); no unspecified big-O constant is turned
into a numerical security level here. Replace Row by a private random function
U(m), independent of h and f. The simultaneous column has not been omitted.

Source: https://eprint.iacr.org/2021/774.pdf, section 5, Proposition 6.

## Third hybrid: replace the column without assuming public salt independence

Reindex the SAME entire compression oracle by the fixed bit permutation

    h_tilde((t,s),y) = h(y || t, s),

where t,s,y each have 256 bits. This is a bijection on all 768 input bits.
It can be performed coherently with one oracle call and its inverse wire
permutation; it does not invent a second independent hash oracle.

Then the column is

    F1(alpha(a), (P,beta(a)))
    where F1(u,v) = h_tilde(v, f(u)).

This is exactly the function of Hosoyamada and Iwata, Proposition 4, with
n=256, m=512 and m'=0. A reduction evaluates alpha(a),beta(a) using h, then
queries F1 once. It also simulates the independent classical U table for rows.
Consequently Q=C, q_h<=q+2C, and q_star=max(C,q+2C). The proposition supplies
E_F1(C,q+2C)=O(sqrt(q_star^3/2^256)) within its q_star=o(2^(256/3)) regime.

The final column is a private random function V(alpha(a),beta(a)), independent
of h and U. Distinct salts whose public Gamma values coincide MUST share this
value. No injectivity of Gamma, collision-free assumption or new runtime check
is used. Equal salts, including a zero session identifier aliasing the zero
salt, preserve exact column reuse.

Source: https://eprint.iacr.org/2021/774.pdf, section 4, Proposition 4.

## Cross-interface equality and proposed bound

The preceding independent-table ideal I has Row(m)=U(m) and Col(a)=V(Gamma(a)).
It is independent of hidden R, but does not enforce the real equality at the
cross-interface pair a=R,m=R. Do not claim pointwise equivalence there.

Define a coupled ideal J by keeping Col unchanged and setting

    Row_J(m) = V(Gamma(R)) if m is exactly the 32-byte R;
               U(m)      otherwise.

This preserves the shared HMAC pair and all repeated calls. Until the first
classical row query equal to R, I and J agree. I's whole observable computation
is independent of R, so that event has probability at most T/2^256. Public
quantum h queries do not change this independence in I. The ordinary hybrid
coupling thus adds at most T/2^256, without excluding an actual input.

The proposed output-probability distinguishing bound for the stated interfaces is

    min(1, E1 + E_NMAC(T,q+3C,ell) + E_F1(C,q+2C) + T/2^256).

The published asymptotic bounds retain their stated query regimes. This is not a
trace-distance statement that reveals the hidden root or the private oracle table
to the distinguisher. Such extra access is outside the experiment and can defeat
the conclusion. No concrete security-bit claim follows from unspecified constants.

## Audit points and remaining protocol work

Check the padding offset, the complete q/Q accounting, the simulation of the
other interface in each reduction, the fixed full-domain permutation for h_tilde,
and the cross-interface coupling. In particular, replacing NMAC while silently
discarding the column, or replacing V(Gamma(a)) by independent V(a) without a
separate collision argument, is not this proposed proof.

The actual accepted prefix still has to supply a uniform R with the required
joint oracle/auxiliary-state distribution; an oracle-correlated root cannot just
be relabelled uniform. All captured state, reservation coins, identity authority,
public image/intent views, key reuse across epochs, downstream signatures,
confirmation and message/ACK key schedules must be preserved in the eventual
reduction. Existing symbolic acceptance and this one-root primitive experiment
do not replace those steps. External review of the finished construction remains
required before release.
