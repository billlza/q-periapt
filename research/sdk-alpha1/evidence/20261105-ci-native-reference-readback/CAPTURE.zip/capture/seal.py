from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ci-native-reference-readback'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-native-reference-readback'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
jobs = {j['id']: j for j in json.loads((BASE / 'JOBS.json').read_bytes())}
status = json.loads((BASE / 'CI_STATUS.json').read_bytes())
raw = {j: (BASE / f'job-{j}.log').read_bytes() for j in jobs}
logs = {j: b.decode() for j, b in raw.items()}
native, reference = 126445763257, 126445737533
heads = {native: '9aa535b48b464ec4d4a8b5a4b20221049a6067b9',
         reference: '475cd23923e45819b01b6041c91c44540ec056ec'}
for j, head in heads.items():
    assert jobs[j]['conclusion'] == 'success'
    assert re.search(r'git log -1 --format=%H\n\S+Z ' + head + r'\s*\n', logs[j])
summaries = re.findall(r'^\S+Z test result: (ok\..+)$', logs[native], re.M)
counts = [int(re.match(r'ok\. ([0-9]+) passed;', s)[1]) for s in summaries]
assert counts == [1451, 4, 2, 4, 3, 19, 27, 4], counts
assert all('; 0 failed; 0 ignored;' in s for s in summaries)
nsteps = {s['number']: s for s in jobs[native]['steps']}
for n in [9, 13, 15]: assert nsteps[n]['conclusion'] == 'success'
for n in [16, 17, 18]: assert nsteps[n]['conclusion'] == 'skipped'
rsteps = {s['number']: s for s in jobs[reference]['steps']}
for n in [7, 8, 9, 10]: assert rsteps[n]['conclusion'] == 'success'
markers = ['SPQR_REFERENCE_PASS scenarios=7 sends=14336 minimum_version=1',
           'SPQR_CHUNK64_EXPERIMENT_PASS scenarios=7 sends=14336 minimum_version=1',
           'WHOLE_KEM_REFERENCE_PASS profiles=3 scenarios=21 sends=43008']
for m in markers: assert logs[reference].count(m) == 2
artifacts = {
    native: {'id': 13388450071, 'bytes': 62119,
        'sha256': '533a898c28102e4dadd8d9749af6d5359e8d5316ad27e7b5ebab9d2f392f9c45'},
    reference: {'id': 13387463747, 'bytes': 24658856,
        'sha256': 'df830a22cc95c42201977f29804a8c9ab1da2dfe0fca02bcf76fc6bf64b8dc40'},
}
for j, a in artifacts.items():
    assert a['sha256'] in logs[j]
    assert f"Final size is {a['bytes']} bytes. Artifact ID is {a['id']}" in logs[j]
classification = {
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at': status['observed_at'], 'wave_counts': status['counts'],
    'native_release': {'job_id': native, 'run_id': jobs[native]['run_id'],
        'actual_checkout': heads[native], 'test_summaries': summaries,
        'candidate_library_cases': 1451, 'candidate_other_cases': 32, 'sdk_cases': 31,
        'independent_public_verification_executed': False,
        'scope': 'Original PR #117 merge Release matrix row; not the later local maintenance source or corrected artifact-order execution.'},
    'reference': {'job_id': reference, 'run_id': jobs[reference]['run_id'],
        'actual_checkout': heads[reference],
        'pass_markers': [{'marker': m, 'occurrences': 2} for m in markers],
        'scope': 'Original PR #117 branch source; pinned reference replay, isolated chunk-size experiment and whole-KEM controls. No product performance or protocol-security conclusion.'},
    'reported_artifacts': {str(k): v for k, v in artifacts.items()},
    'logs': {str(j): {'bytes': len(b), 'sha256': sha(b), 'url': jobs[j]['html_url']} for j, b in raw.items()},
    'artifacts_downloaded_locally': False, 'new_failed_jobs_since_prior_snapshot': [],
    'effective_wave_open': True, 'push_performed': False, 'rerun_performed': False,
    'workflow_cancelled': False, 'release_claim_eligible': False,
}
files = {'capture/' + p.name: p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for n, b in sorted(files.items()):
        info = zipfile.ZipInfo(n, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, b)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(files) and set(archive.namelist()) == set(files)
    for n, b in files.items(): assert archive.read(n) == b
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload),
           'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for n, b in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
             ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / n).open('xb') as f: f.write(b)
print(json.dumps(summary, indent=2), flush=True)
