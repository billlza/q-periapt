from pathlib import Path
import base64
import hashlib
import json
import re
import secrets
import subprocess
import sys

stage=Path(__file__).resolve().parent;out=stage/'physical-08'
mode,profile,inputs,target,output=sys.argv[1:];inputs=Path(inputs);output=Path(output)
assert profile=='recoverable' and inputs.parent.name=='tls-recoverable-applied'
allowed={'managed-witness-create','authority-create','managed-witness-prepare','managed-witness-activate',
 'roster-witness-peer-unassociated','authority-peer-associate','roster-witness-peer-connect','roster-witness-peer-uncertain',
 'pending-roster-unknown','pending-request','pending-confirm-damaged','pending-confirm-unapproved',
 'pending-confirm-cancelled','pending-confirm','pending-request-absent','pending-activate-expired','pending-identity'}
assert mode in allowed
label=output.name;assert re.fullmatch(r'[a-z][a-z0-9.-]{0,63}',label)
run=out/'device-09';run.mkdir(mode=0o700,exist_ok=True);state_path=run/'STATE.json'
state=json.loads(state_path.read_text()) if state_path.exists() else {'completed':False,'cleanup':False,'cases':[]}
assert not state['completed'] and not state.get('failure') and not state['cleanup']
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';package='dev.qperiapt.continuity.pendingmatrix20261014'
prepared=json.loads((out/'PREPARED_APK_09.json').read_text());assert prepared['completed'] and prepared['signed']
rows=subprocess.run([adb,'-P','15037','devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
matches=[line for line in rows if ' device ' in line and hashlib.sha256(line.split()[0].encode()).hexdigest()=='<SELECTED_ANDROID_DEVICE_SHA256>']
assert len(matches)==1;transport=re.search(r'transport_id:(\d+)',matches[0]).group(1)
redactions=[]
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def safe(text):
    for secret in redactions:text=text.replace(secret,'<redacted test TLS credential>')
    return text
def command(name,args,expected=0,timeout=30,bind_conflict=False):
    cmd=[adb,'-P','15037','-t',transport]+args
    try:result=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
    except subprocess.TimeoutExpired:raise RuntimeError(name+' exceeded '+str(timeout)+' seconds') from None
    stdout,stderr=safe(result.stdout),safe(result.stderr)
    for suffix,value in [('stdout',stdout),('stderr',stderr),('json',json.dumps({'command':[safe(v) for v in cmd],'returncode':result.returncode},indent=2)+'\n')]:
        with (run/(label+'-'+name+'.'+suffix)).open('x') as stream:stream.write(value)
    if bind_conflict and result.returncode==1 and not stdout.strip() and stderr.strip()=='adb: error: cannot bind listener: Address already in use':return None
    assert result.returncode==expected and not stderr,(name,result.returncode,stderr)
    return stdout
def clear_maps():
    for port in list(state.get('owned_reverse_ports',[])):
        command('reverse-remove-'+str(port),['reverse','--remove','tcp:'+str(port)])
        state['owned_reverse_ports'].remove(port);save()
def cleanup():
    clear_maps()
    command('cleanup-stop',['shell','am','force-stop',package])
    assert not command('cleanup-process',['shell','pidof',package],expected=1).strip()
    assert command('uninstall',['uninstall',package],timeout=60).strip()=='Success'
    assert not command('uninstalled',['shell','pm','list','packages','--user','0',package]).strip()
    state['cleanup']=True;save()
try:
    if mode=='managed-witness-create':
        assert not state.get('installation_attempted') and not command('preexisting',['shell','pm','list','packages','--user','0',package]).strip()
        assert command('api',['shell','getprop','ro.build.version.sdk']).strip()=='37'
        assert command('abi',['shell','getprop','ro.product.cpu.abi']).strip()=='arm64-v8a'
        assert hashlib.sha256(Path(prepared['apk']).read_bytes()).hexdigest()==prepared['apk_sha256']
        state.update(apk_sha256=prepared['apk_sha256'],aar_sha256=prepared['aar_sha256'],installation_attempted=True);save()
        assert command('install',['install','--no-incremental','-t',prepared['apk']],timeout=90).splitlines().count('Success')==1
    else:assert state['installation_attempted']
    carrier=(inputs/'witness-carrier').read_text()
    assert carrier==('signed' if mode in ['managed-witness-create','authority-create','managed-witness-prepare'] else 'tls')
    names=['witness-carrier','witness-id','witness-public','witness-address']
    if carrier=='tls':names+=['witness-tls-cert','witness-tls-key','witness-tls-peer','witness-tls-name']
    if mode=='managed-witness-create':names+=['sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version',
        'policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope','recovery-root','recovery-enrollment']
    else:
        names+=['authority-id','authority-application']
        if mode!='authority-create':names+=['authority-checkpoint']
    if mode in ['authority-create','managed-witness-prepare']:names+=['grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest']
    if mode=='authority-peer-associate':names+=['authority-peer-application','peer-approved-certificate','peer-approved-roster']
    peer_mode=mode.removeprefix('roster-witness-') if mode.startswith('roster-witness-peer-') else None
    if peer_mode:
        names+=['peer-'+p.name for p in sorted((inputs/'peer').iterdir()) if p.is_file()]
        if peer_mode!='peer-unassociated':names+=['connection-address','connection-initiation' if peer_mode=='peer-connect' else 'connection-session']
    if mode=='pending-roster-unknown':names+=['remote-roster','remote-roster-version','remote-roster-digest']
    if mode.startswith('pending-confirm'):names+=['pending-proposal','pending-metadata']
    assert len(names)==len(set(names))
    args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation',mode,'-e','label',label]
    for name in names:
        path=inputs/'peer'/name[5:] if name.startswith('peer-') else inputs/name
        value=base64.b64encode(path.read_bytes()).decode('ascii')
        if name in ['tls-key','witness-tls-key']:redactions.append(value)
        args+=['-e',name,value]
    args+=[package+'/dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation']
    match=re.fullmatch(r'127\.0\.0\.1:(\d+)',(inputs/'witness-address').read_text());assert match
    witness_port=int(match.group(1));ports=[] if mode.startswith('authority-') else [witness_port]
    if peer_mode and peer_mode!='peer-unassociated':
        match=re.fullmatch(r'127\.0\.0\.1:(\d+)',(inputs/'connection-address').read_text());assert match
        peer_port=int(match.group(1));assert peer_port not in ports;ports.append(peer_port)
    try:
        for host_port in ports:
            assert 1<=host_port<=65535;attempted=set()
            for attempt in range(8):
                selected=host_port if attempt==0 else 49152+secrets.randbelow(16384)
                if selected in attempted or selected in state.get('owned_reverse_ports',[]):continue
                attempted.add(selected)
                bound=command('reverse-create-'+str(selected),['reverse','--no-rebind','tcp:'+str(selected),'tcp:'+str(host_port)],bind_conflict=True)
                if bound is None:continue
                assert bound.strip()==str(selected)
                state.setdefault('owned_reverse_ports',[]).append(selected);save()
                if selected!=host_port:
                    field='witness-address' if host_port==witness_port else 'connection-address';index=args.index(field)+1
                    assert args[index]==base64.b64encode(('127.0.0.1:'+str(host_port)).encode()).decode('ascii')
                    args[index]=base64.b64encode(('127.0.0.1:'+str(selected)).encode()).decode('ascii')
                break
            else:raise RuntimeError('no reverse port after eight bounded attempts')
        assert sum(len(value.encode())+1 for value in args)<=60000,'instrumentation IPC bound'
        result=command('instrument',args,timeout=90)
    finally:clear_maps()
    expected=profile+':'+mode+':passed'
    assert 'INSTRUMENTATION_RESULT: result='+expected+'\n' in result,result
    assert result.rstrip().endswith('INSTRUMENTATION_CODE: -1')
    assert 'INSTRUMENTATION_RESULT: apk_sha256='+state['apk_sha256']+'\n' in result
    pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',result,re.M).group(1))
    assert pid not in [row['pid'] for row in state['cases']]
    payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',result,re.M).group(1),validate=True)
    assert 1<=len(payload)<=(65536 if mode.startswith('pending-') else 8192)
    with output.open('xb') as stream:stream.write(payload)
    command('stop',['shell','am','force-stop',package]);assert not command('process-absent',['shell','pidof',package],expected=1).strip()
    state['cases'].append({'mode':mode,'label':label,'pid':pid,'result_sha256':hashlib.sha256(payload).hexdigest(),
        'installed_apk_sha256':state['apk_sha256'],'process_absent_after_stop':True})
    if mode=='pending-identity' and label=='original-identity-after':cleanup();state['completed']=True
    save();print(expected)
except BaseException as error:
    state['failure']=repr(error);save()
    if state.get('installation_attempted') and not state['cleanup']:
        try:cleanup()
        except BaseException as failure:state['cleanup_failure']=repr(failure);save()
    raise
