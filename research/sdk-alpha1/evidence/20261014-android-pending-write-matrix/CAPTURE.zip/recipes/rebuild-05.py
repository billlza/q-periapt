from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_android_contract as contract

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'BUILD_03.json').read_text())
env=json.loads((stage/'ENVIRONMENT_02.json').read_text());tool=Path(env['RUSTC']).parent;consumer=Path(cfg['consumer'])
name='bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/transport.rs'
installed=consumer/'tests/common/android_pending_write/transport.rs'
sdk.require(sdk.snapshot(installed).sha256==cfg['source_files'][name],'compiled transport source changed')
sdk.copy(installed,stage/'compiled-03-transport.rs')
sdk.command([str(tool/'rustfmt'),'--edition','2021','--config','skip_children=true',name],stage/'format-05',root,environment=env)
for other,digest in cfg['source_files'].items():
    if other!=name:sdk.require(sdk.snapshot(root/other).sha256==digest,'unexpected source change')
installed.write_bytes(sdk.snapshot(root/name).data);cfg['source_files'][name]=sdk.snapshot(root/name).sha256
target=Path(cfg['outside'])/'build'
output=sdk.command([str(tool/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json',
 '--target-dir',str(target),'-j','2'],stage/'harness-05',consumer,environment=env)
rows=[json.loads(line) for line in output.splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'matrix harness count')
contract.verify_catalog(sdk.command([tests[0],'--list'],stage/'catalog-05',consumer,environment=env))
sdk.command([str(tool/'cargo'),'clippy','--locked','--offline','--test','android','--target-dir',str(target),'-j','2','--','-D','warnings'],stage/'clippy-05',consumer,environment=env)
cfg['harness']=tests[0];cfg['harness_sha256']=sdk.snapshot(Path(tests[0]),maximum=256*1024**2).sha256
sdk.write_json(stage/'BUILD_05.json',cfg)
recipe=(stage/'run-04.py').read_text().replace('BUILD_03.json','BUILD_05.json').replace('host-cases-04','host-cases-06').replace('host-run-04','host-run-06').replace('public-04','public-06').replace('RESULT_04.json','RESULT_06.json')
with (stage/'run-06.py').open('x') as stream:stream.write(recipe)
print('Both actual TLS endpoints pinned; corrected64-test harness and strict Clippy passed')
