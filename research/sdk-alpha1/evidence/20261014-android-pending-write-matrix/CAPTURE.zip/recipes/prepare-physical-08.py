from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;old=root/'target/continuity-android-pending-recovery'
package=json.loads((old/'physical-12/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():
    sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
out=stage/'physical-08'
apk=(old/'apk-15.py').read_text().replace('continuity-android-pending-recovery','continuity-android-pending-matrix').replace('physical-12','physical-08')
apk=apk.replace('agp-15','agp-09').replace('qualification-15.p12','qualification-09.p12').replace('consumer-15.apk','consumer-09.apk').replace('PREPARED_APK_15.json','PREPARED_APK_09.json').replace('dev.qperiapt.continuity.pending20261014','dev.qperiapt.continuity.pendingmatrix20261014')
driver=(old/'device-driver-15.py').read_text().replace('physical-12','physical-08').replace('device-15','device-09').replace('PREPARED_APK_15.json','PREPARED_APK_09.json').replace('dev.qperiapt.continuity.pending20261014','dev.qperiapt.continuity.pendingmatrix20261014')
def replace(text,old,new):
    sdk.require(text.count(old)==1,'physical recipe shape: '+old[:70]);return text.replace(old,new)
driver=replace(driver,"assert profile=='fixed' and inputs.parent.name=='signed-fixed-unapplied'","assert profile=='recoverable' and inputs.parent.name=='tls-recoverable-applied'")
driver=replace(driver,"'pending-confirm','pending-request-absent'","'pending-confirm-cancelled','pending-confirm','pending-request-absent'")
driver=replace(driver,"    assert (inputs/'witness-carrier').read_text()=='signed'",'''    carrier=(inputs/'witness-carrier').read_text()
    assert carrier==('signed' if mode in ['managed-witness-create','authority-create','managed-witness-prepare'] else 'tls')''')
driver=replace(driver,"    names=['witness-carrier','witness-id','witness-public','witness-address']",'''    names=['witness-carrier','witness-id','witness-public','witness-address']
    if carrier=='tls':names+=['witness-tls-cert','witness-tls-key','witness-tls-peer','witness-tls-name']''')
driver=replace(driver,"        'policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent']", "        'policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope','recovery-root','recovery-enrollment']")
driver=replace(driver,"        if name=='tls-key':redactions.append(value)","        if name in ['tls-key','witness-tls-key']:redactions.append(value)")
run=(old/'run-device-15.py').read_text().replace('continuity-android-pending-recovery','continuity-android-pending-matrix').replace('physical-12','physical-08')
run=run.replace('INSTALLED_BUILD_11.json','BUILD_05.json').replace('PREPARED_APK_15.json','PREPARED_APK_09.json').replace('run-15','run-09').replace('device-15','device-09').replace('device-driver-15.py','device-driver-09.py').replace('dev.qperiapt.continuity.pending20261014','dev.qperiapt.continuity.pendingmatrix20261014')
run=replace(run,"files={name:Path(cfg[name])", "label='tls-recoverable-applied'\nfiles={name:Path(cfg[name])")
run=run.replace("'engine_source_commit':cfg['source_commit']","'engine_source_commit':cfg['installed_base']['source_commit']")
run=run.replace('pending.TEST,','pending.TESTS[label],').replace('pending.verify_execution(stdout,cases)','pending.verify_execution(stdout,cases,label)').replace('pending.verify_execution(stdout,out/\'public\')','pending.verify_execution(stdout,out/\'public\',label)')
run=run.replace('pending.CASES','pending.cases(True)').replace('pending.PUBLIC','pending.public(True)').replace('pending.LABEL','label')
run=run.replace('signed/fixed/unapplied pending recovery','TLS/recoverable/applied pending recovery with pre-call cancellation').replace('all 18 original pending recovery calls','all 19 original pending recovery calls')
for value in [apk,driver,run]:ast.parse(value)
out.mkdir();sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');package['reused_unchanged_implementation']=True
sdk.write_json(out/'PACKAGE.json',package)
for name,text in [('apk-09.py',apk),('device-driver-09.py',driver),('run-device-09.py',run)]:
    with (stage/name).open('x') as stream:stream.write(text)
sdk.write_json(stage/'PHYSICAL_RECIPES_08.json',{name:sdk.snapshot(stage/name).sha256 for name in ['apk-09.py','device-driver-09.py','run-device-09.py']})
print('Fresh TLS/recoverable/applied physical route prepared with exact unchanged actual AAR')
