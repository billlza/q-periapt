from pathlib import Path
import ast
import json
import shutil
import subprocess
import tempfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
new=['bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/'+name+'.rs' for name in ['accounting','flow','transport']]
for name in ['ARTIFACT.md','artifact/codeql_rust_quality.py']:
    path=root/name;text=path.read_text();sdk.require(text.count('682')==1,'Rust census shape');path.write_text(text.replace('682','685'))
path=root/'artifact/test_codeql_rust_quality.py';text=path.read_text();key='            "bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write.rs",\n'
sdk.require(text.count(key)==2,'tracked Rust inventory fixture');path.write_text(text.replace(key,key+''.join('            '+json.dumps(name)+',\n' for name in new)))
subprocess.run(['git','add','--',*new],check=True)
env=json.loads((root/'target/continuity-android-pending-recovery/ENVIRONMENT_01.json').read_text())
rust=['bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write.rs',*new]
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',*rust],stage/'format-02',root,environment=env)
for name in ['artifact/continuity_android_contract.py','artifact/continuity_android_jni.py','artifact/continuity_android_pending.py','artifact/test_continuity_android_pending.py']:
    ast.parse((root/name).read_text(),filename=name)
old=json.loads((root/'target/continuity-android-pending-recovery/INSTALLED_BUILD_11.json').read_text())
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
 'bindings/c/ContinuityPackageConsumer/src','bindings/c/ContinuityPackageConsumer/Cargo.toml','bindings/android/ContinuityPackageConsumer/src/main',
 'bindings/android/ContinuityPackageConsumer/jni']),'actual archived engine or binding implementation changed')
outside=Path(tempfile.mkdtemp(prefix='qpc-pending-matrix-')).resolve();consumer=outside/'c-consumer'
shutil.copytree(Path(old['consumer']),consumer)
source=root/'bindings/c/ContinuityPackageConsumer';hashes={}
for path in source.rglob('*'):
    if path.is_file() and path.name!='Cargo.toml':
        target=consumer/path.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(sdk.snapshot(path).data);hashes[str(path.relative_to(root))]=sdk.snapshot(path).sha256
builder=outside/'android-source';shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',builder)
hashes.update({str(path.relative_to(root)):sdk.snapshot(path).sha256 for path in (root/'bindings/android/ContinuityPackageConsumer').rglob('*') if path.is_file()})
for name in ['receiver','library','jar','bridge']:
    sdk.require(sdk.snapshot(Path(old[name]),maximum=256*1024**2).sha256==old[name+'_sha256'],'prior installed binary changed')
sdk.write_json(stage/'INPUTS_02.json',{'outside':str(outside),'consumer':str(consumer),'android_source':str(builder),
 'source_files':hashes,'installed_base':old,'candidate_sha256':old['candidate_sha256'],
 'scope':'New consumer matrix with unchanged actual archived engine and SDK; original installed runtime identities retained'})
sdk.write_json(stage/'ENVIRONMENT_02.json',env)
print('Fresh actual-archive consumer and exact unchanged runtime prepared; Rust inventory685')
