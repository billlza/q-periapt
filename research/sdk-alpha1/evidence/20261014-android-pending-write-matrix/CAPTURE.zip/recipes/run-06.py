from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk
import continuity_android_pending as pending
import continuity_c_witness_openssl as openssl

root=Path.cwd();stage=Path(__file__).resolve().parent;cfg=json.loads((stage/'BUILD_05.json').read_text())
def unchanged():
    for name in ['harness','driver','receiver','library','jar','bridge']:
        sdk.require(sdk.snapshot(Path(cfg[name]),maximum=256*1024**2).sha256==cfg[name+'_sha256'],'runtime changed')
    for name,digest in cfg['test_classes'].items():sdk.require(sdk.snapshot(Path(cfg['outside'])/'tests'/name).sha256==digest,'Java class changed')
    for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'consumer source changed')
    openssl.verify_dependencies(cfg['openssl']['dependency_files'])
unchanged();cases=stage/'host-cases-06';sdk.require(not cases.exists(),'matrix output already exists')
record={'completed':False,'scope':cfg['scope'],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'candidate_sha256':cfg['candidate_sha256'],'physical_ART':False,'release_claim_eligible':False}
env=dict(cfg['environment'],QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=cfg['driver'],
         QPC_CONFIGURATION_RECEIVER=cfg['receiver'],QPERIAPT_WITNESS_OPENSSL_PEER=cfg['openssl']['path'])
try:
    stdout=sdk.command([cfg['harness'],'android_pending_write::','--test-threads=2','--nocapture'],stage/'host-run-06',Path(cfg['consumer']),environment=env)
    results={}
    for label in pending.TESTS:
        results.update(pending.verify_execution(stdout,cases,label,batch=True))
        for name in pending.public(label.endswith('-applied')):sdk.copy(cases/label/name,stage/'public-06'/label/name)
        sdk.require(pending.verify_execution(stdout,stage/'public-06',label,batch=True)[label]==results[label],'public readback differs')
    unchanged();record.update(completed=True,cases=results,foreign_processes=sum(row['foreign_processes'] for row in results.values()))
except BaseException as error:record['failure']=repr(error);raise
finally:sdk.write_json(stage/'RESULT_06.json',record)
print('Actual-archive Android host matrix completed all eight routes and '+str(record['foreign_processes'])+' foreign calls')
