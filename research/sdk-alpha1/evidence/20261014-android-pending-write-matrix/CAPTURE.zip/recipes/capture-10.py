from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent;device=stage/'physical-08'
host=json.loads((stage/'RESULT_06.json').read_text());physical=json.loads((device/'run-09/RESULT.json').read_text())
state=json.loads((device/'device-09/STATE.json').read_text())
sdk.require(host['completed'] and physical['completed'] and physical['cleanup'] and state['completed'] and state['cleanup']
 and not state.get('owned_reverse_ports'),'matrix or device not terminal')
sdk.require(host['foreign_processes']==156 and physical['physical_processes']==19,'execution census')
out=root/'research/sdk-alpha1/evidence/20261014-android-pending-write-matrix';out.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'capture duplicate');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(base,prefix,label):
    for suffix in ['json','stdout','stderr']:add(base/(prefix+'.'+suffix),label+'.'+suffix)
for name in ['readers-03','harness-03','catalog-03','clippy-03','java-03','harness-05','catalog-05','clippy-05',
 'source-gate-07','clone-controls-07','host-run-06']:
    logs(stage,name,'host/'+name)
for path in stage.glob('witness-openssl-*-03.*'):
    sdk.require(path.suffix in ['.json','.stdout','.stderr'],'OpenSSL receipt type');add(path,'host/'+path.name)
for name in ['BUILD_05.json','RESULT_06.json','SOURCE_07.json','SOURCE_COMMIT_07.json','compiled-03-transport.rs']:
    add(stage/name,'host/'+name)
for label in pending.TESTS:
    for name in pending.public(label.endswith('-applied')):add(stage/'public-06'/label/name,'host/public/'+label+'/'+name)
    if label.startswith('tls-') and label.endswith('-unapplied'):
        add(stage/'host-cases-06'/label/'openssl-witness-server.stderr','host/tls/'+label+'/negotiation.stderr')
for name in ['PACKAGE.json','PREPARED_APK_09.json']:add(device/name,'android/'+name)
for name in ['build','keytool','sign','signature']:logs(device/'agp-09',name,'android/'+name)
add(device/'agp-09/STATE.json','android/STATE.json')
logs(device/'run-09','catalog','device/catalog');logs(device/'run-09','execution','device/execution')
add(device/'run-09/RESULT.json','device/RESULT.json')
for path in sorted((device/'device-09').iterdir()):
    sdk.require(path.is_file() and path.suffix in ['.json','.stdout','.stderr'],'device receipt type')
    add(path,'device/commands/'+path.name)
label='tls-recoverable-applied'
for name in pending.public(True):add(device/'run-09/public'/label/name,'device/public/'+label+'/'+name)
for name in ['prepare-installed-02.py','build-03.py','rebuild-05.py','run-06.py','commit-07.py','prepare-physical-08.py',
 'apk-09.py','device-driver-09.py','run-device-09.py','capture-10.py']:add(stage/name,'recipes/'+name)
for key in ['tls-key','witness-tls-key']:
    secret=(device/'run-09/cases'/label/'inputs'/key).read_bytes()
    for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'test private key included')
for name,payload in list(files.items()):
    if name.endswith(('.py','.json','.stdout','.stderr')):
        files[name]=payload.replace(b'<SELECTED_ANDROID_DEVICE>',b'<SELECTED_ANDROID_DEVICE>').replace(
            b'<SELECTED_ANDROID_DEVICE_SHA256>',b'<SELECTED_ANDROID_DEVICE_SHA256>')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,data)
manifest={'format':1,'source_commit':host['source_commit'],'engine_source_commit':physical['engine_source_commit'],
 'candidate_sha256':host['candidate_sha256'],'aar_sha256':physical['aar_sha256'],'apk_sha256':physical['apk_sha256'],
 'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'host_routes':8,'host_foreign_processes':156,'physical_ART_processes':19,'physical_API':37,'release_claim_eligible':False,
 'recipe_hardware_selectors_redacted':True}
sdk.write_json(out/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-pending-matrix-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'capture inventory')
        for name,digest in manifest['members'].items():
            data=bundle.read(name);sdk.require(hashlib.sha256(data).hexdigest()==digest,'capture hash')
            if '/public/' in name:
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        results={}
        for route in pending.TESTS:results.update(pending.verify_execution(bundle.read('host/host-run-06.stdout'),extracted/'host/public',route,batch=True))
        sdk.require(results==host['cases'],'host matrix readback')
        sdk.require(pending.verify_execution(bundle.read('device/execution.stdout'),extracted/'device/public',label)==physical['result'],'physical readback')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256'],
 'all_host_and_device_public_readers':True,'private_test_keys_excluded':True})
print(json.dumps({'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256']}))
