# Accepted-flight and reservation simulation: current research notes

Working analysis, 2026-11-05. This is not an admitted computational theorem or
a new release blocker. It refines the accepted-prefix/authentication obligations
already recorded in COMPUTATIONAL_RECOVERY_V1.md. No product code is changed.

## Observed source boundary

Qualification source is ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20. PublicKey::verify
in candidate crypto.rs requires both the canonical low-S P-256 signature and
ML-DSA-65 verification. The signed message is

    SIGNATURE_CONTEXT || purpose_u8 || length_be32(body) || body

with fixed 42-byte SIGNATURE_CONTEXT, also passed to the external ML-DSA
context parameter. Purpose plus body has an injective encoding within the
existing body bound. Signature validity is still separate from the pinned
device/role and current roster/policy authorization.

SigningReservation persists a 32-byte binding and 32-byte rnd. The binding
includes the public key, operation and complete signed message. The backend
passes rnd to fips204 0.4.6 try_sign_with_seed. That library uses
SHAKE256(K || rnd || mu, 64) to derive its internal signing seed; the persisted
rnd is not that internal 64-byte seed or the per-loop masking vector. This
distinction follows FIPS 204 section 6.2 and the pinned implementation. It
does not alone prove security when permitted historical reservations disclose
rnd. Source getrandom calls likewise do not prove independent entropy.

prepare_rekey_offer rebuilds the KEM public key from the original reservation
and appends that key to the exact control prefix before reserving the signature.
respond_rekey_offer verifies the peer offer before reserving encapsulation,
retains its exact wire, and binds the operation and KEM context to its digest.
accept_rekey_response verifies the signed response, checks the prefix against
the retained offer, recreates and checks its private owner's public key, then
decapsulates and checks the response's real root confirmation. These are actual
source paths, not a completed reduction of their whole state/output interfaces.

## Body origin is different from full-wire origin

Conditional elementary reduction: if the relevant ML-DSA public key is honestly
generated, uncompromised, and unforgeable under the permitted signing/nonce
interface, an accepted hybrid signature on a previously unsigned purpose/body
gives an ML-DSA forgery on its injectively encoded message. A reduction can
generate and disclose the classical component itself. It needs neither secrecy
nor unforgeability of P-256 for this implication. Multiple target PQ keys and
adaptive registration still require their ordinary target-selection accounting.

This implication concerns bodies, not complete signature bytes. The existing
bootstrap::classical_alias_tests regression captures only P-256, closes the
original hybrid signer, keeps the ML-DSA signature and body unchanged, and
constructs another valid low-S P-256 signature. Hybrid verification and the
initiator's reply checks pass; the resulting root/session split is rejected by
the final step. The native connection tests separately check the final READY
boundary. The already completed source-bound Release run contains all three
passing tests and the four-control/four-alias marker; the relevant current
source files match its recorded hashes. This is retained evidence, not a new
test execution in these notes.

Consequently, a computational prefix argument must not equate PQ body
unforgeability with full original-wire authenticity. The rekey digest bindings,
stored-wire comparisons, confirmation stages and required collision-resistance
events must be included separately. No actual rekey alias attack or failure
has been established by the bootstrap evidence.

## Candidate nonce-aware signature route

Kosuge and Xagawa, The Security of ML-DSA against Fault-Injection Attacks,
2025/904, Definition 6 / Figure 7 explicitly lets the signing adversary choose
the message and rnd. Its no-fault case is relevant to simulating a known
historical rnd. The game rejects repeated message/nonce pairs; a fault-free
deterministic computation can instead be cached for exact repeats. This
identifies a useful interface, not a completed application of its theorem.

The paper uses typed H_mu, H_he, H_em and H_ch interfaces, and bounds the
rejection loop. The actual library uses one SHAKE256 implementation and a
u16 counter with increments in a loop. Its bound/tail and shared-oracle
interpretation still need justification. No hardware-fault requirement is
being added: only the identity/no-fault case is under consideration here.

In particular, names do not establish disjoint SHAKE inputs. For this fixed
signature context the message-representative input has 155 + body_length
bytes. ML-DSA-65 challenge input length is 64 + 768 = 832 bytes. Thus length
alone would not separate them for a 677-byte body at the generic signing-codec
level. These notes have not established that such a body is an admitted
protocol message, or an attack; the observation prevents an unjustified blanket
length-separation claim. All honest uses, adversarial queries and correlations
with key generation/mask expansion must retain their actual encodings.

## KEM challenge simulation still to establish

A possible fixed-target simulation can use an IND-CCA challenge public key and
ciphertext/test secret, generate the independent classical component itself,
and answer the honest target-ciphertext use from the saved challenge reply.
That internal use must never be sent to the forbidden challenge decapsulation
oracle. Other allowed component ciphertexts can use its ordinary decapsulation
interface. Exact retries and altered classical components/context require a
consistent cache of the same PQ secret and effective combiner arguments.

The challenge's private key-generation/encapsulation coins are not given to
this simulator. Replacing public image/intent commitments before embedding
the challenge may make a private symbolic state representation possible, but
the actual whole-image and pending-state disclosure model must justify every
replacement. The original conditions on target entropy and post-Cut record
acquisition cannot be weakened. Matching accepted endpoints, correctness
failure, adaptive target choice, all other-epoch disclosures and the shared
SHA3/QROM continuation remain part of that proof.

## Primary materials read

- FIPS 204 sections 3.6.1 and 6.2, Algorithms 6/7:
  https://nvlpubs.nist.gov/nistpubs/fips/nist.fips.204.pdf.
- Kosuge/Xagawa original metadata and revised September 2025 paper:
  https://eprint.iacr.org/2025/904;
  indexed full text at https://www.eprint.mirror.cypherpunks.su/2025/904/1757297257.pdf.
  Direct PDF retrieval returned 403/502; the indexed text was readable. No
  downloaded-PDF hash or visual PDF verification is claimed.
- The March 2026 ML-DSA security-considerations Internet-Draft was consulted
  as work in progress, not as an IETF standard or proof. Its general warning
  about signing randomness is not treated as a demonstrated attack on persisted
  rnd; rnd, internal seed and masking vector are kept distinct.
