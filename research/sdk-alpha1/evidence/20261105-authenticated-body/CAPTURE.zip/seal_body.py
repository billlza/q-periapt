from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import tarfile
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-accepted-prefix'
NATIVE = ROOT / 'target/continuity-aggregate-diagnosis'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-authenticated-body'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
observations = json.loads((BASE / 'SOURCE_OBSERVATIONS.json').read_bytes())
files = {name: (BASE / name).read_bytes() for name in ['SOURCE_OBSERVATIONS.json', 'NOTES.md', 'read_source.py']}
for name, expected in observations['source_files_identical'].items():
    data = (BASE / 'source' / name).read_bytes()
    assert sha(data) == expected and data == (ROOT / name).read_bytes()
    files['source/' + name] = data
crypto = files['source/research/continuity-identity-candidate/src/crypto.rs']
purposes = re.search(rb'signature_purposes! \{(.*?)\n\}', crypto, re.S)[1]
tags = [(m[1].decode(), int(m[2])) for m in re.finditer(rb'\s*([A-Za-z0-9_]+) = ([0-9]+),', purposes)]
assert len(tags) == 39 and {v for _, v in tags} == set(range(1, 40))
dependency = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-continuity-package-g03ryny6/cargo-home/registry/cache/index.crates.io-1949cf8c6b5b557f/fips204-0.4.6.crate').read_bytes()
assert sha(dependency) == observations['fips204_crate_sha256']
with tarfile.open(fileobj=io.BytesIO(dependency), mode='r:gz') as archive:
    for name, expected in observations['dependency_files'].items():
        data = (BASE / 'dependency/fips204-0.4.6' / name).read_bytes()
        assert sha(data) == expected and data == archive.extractfile('fips204-0.4.6/' + name).read()
        files['dependency/fips204-0.4.6/' + name] = data
    for name in ['LICENSE-APACHE', 'LICENSE-MIT', 'Cargo.toml']:
        files['dependency/fips204-0.4.6/' + name] = archive.extractfile('fips204-0.4.6/' + name).read()
record = (NATIVE / 'FORMAL_RELEASE_RESULT.json').read_bytes()
assert sha(record) == observations['original_release_result_sha256']
files['original-run/FORMAL_RELEASE_RESULT.json'] = record
extracts = {}
for kind in ['stdout', 'stderr']:
    data = (NATIVE / ('formal-release-run.' + kind)).read_bytes()
    assert sha(data) == observations['original_release_' + kind + '_sha256']
    lines = data.decode().splitlines()
    selected = []
    for number, line in enumerate(lines, 1):
        if (kind == 'stdout' and any(line == 'test ' + name + ' ... ok' for name in observations['reused_tests'])) or (kind == 'stderr' and line == observations['bootstrap_alias_marker']):
            selected.append({'line': number, 'text': line})
    assert len(selected) == (3 if kind == 'stdout' else 1)
    extracts[kind] = {'original_path': str(NATIVE / ('formal-release-run.' + kind)),
                      'original_sha256': sha(data), 'original_bytes': len(data), 'selected_lines': selected}
files['original-run/EXTRACTS.json'] = encode(extracts)
files['AUTHENTICATED_BODY_LEMMA_V1.md'] = (ROOT / 'docs/continuity/AUTHENTICATED_BODY_LEMMA_V1.md').read_bytes()
readback = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'source_files_matched': len(observations['source_files_identical']),
            'dependency_files_matched': len(observations['dependency_files']), 'signature_purposes': tags,
            'historical_tests': observations['reused_tests'], 'new_runtime_execution': False,
            'scope': 'Conditional hybrid-wrapper body-origin reduction; existing source and historical alias-test evidence. Not the underlying primitive or accepted-prefix theorem.',
            'accepted_prefix_theorem_completed': False, 'whole_protocol_theorem_completed': False,
            'external_review_completed': False, 'implementation_changed': False}
files['READBACK.json'] = encode(readback)
files['seal_body.py'] = Path(__file__).read_bytes()
manifest = {n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    for name, body in files.items(): assert archive.read(name) == body
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
DEST.mkdir(parents=True, exist_ok=False)
for name, data in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']),
                   ('READBACK.json', files['READBACK.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(data)
print(json.dumps(summary, indent=2), flush=True)
