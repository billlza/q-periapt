from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import tarfile
import io

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-accepted-prefix'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
NATIVE = ROOT / 'target/continuity-aggregate-diagnosis'
REGISTRY = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-continuity-package-g03ryny6/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f')
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = [
    'research/continuity-identity-candidate/src/crypto.rs',
    'research/continuity-identity-candidate/src/contract.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-identity-candidate/src/bootstrap/classical_alias_tests.rs',
    'research/continuity-identity-candidate/src/connection_transport/confirmation_tests.rs',
    'crates/q-periapt-backends/src/mldsa.rs',
]
result = json.loads((NATIVE / 'FORMAL_RELEASE_RESULT.json').read_bytes())
assert result['completed'] and result['source_unchanged']
run = next(item for item in result['commands'] if item['label'] == 'run') if 'commands' in result else next(item for item in result['runs'] if item['label'] == 'run')
assert run['completed'] and run['exit'] == 0
source_files = {}
for name in paths:
    body = (ROOT / name).read_bytes()
    assert body == (SOURCE / name).read_bytes()
    assert sha(body) == result['source_before'][name]
    destination = BASE / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream: stream.write(body)
    source_files[name] = sha(body)
stdout = (NATIVE / 'formal-release-run.stdout').read_bytes()
stderr = (NATIVE / 'formal-release-run.stderr').read_bytes()
tests = [
    'bootstrap::classical_alias_tests::classical_signature_alias_preserves_reply_authentication_but_final_rejects_root_split',
    'connection_transport::confirmation_tests::native_establish_authenticates_ready_after_classical_reply_alias',
    'connection_transport::confirmation_tests::native_establish_rejects_public_ready_after_classical_reply_alias',
]
for test in tests:
    assert stdout.count(('test ' + test + ' ... ok\n').encode()) == 1
marker = b'BOOTSTRAP_CLASSICAL_ALIAS controls=4 aliases=4 pq_bytes_unchanged=4 bodies_unchanged=4 initiator_reply_checks_passed=4 final_scope_rejections=4 original_reply_conflicts=4'
assert stderr.splitlines().count(marker) == 1
context = re.search(rb'SIGNATURE_CONTEXT: &\[u8\] = b"([^"\\]+)";', (SOURCE / paths[1]).read_bytes())[1]
assert len(context) == 42
archive_path = REGISTRY.parent.parent / 'cache' / REGISTRY.name / 'fips204-0.4.6.crate'
archive = archive_path.read_bytes()
assert sha(archive) == 'c9fb5a367b9846933e271a3c2a992930743f82ae5e8cb7faa780715a80fa0b15'
dependency_files = {}
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as package:
    for name in ['src/ml_dsa.rs', 'src/traits.rs', 'src/hashing.rs', 'src/lib.rs']:
        body = package.extractfile('fips204-0.4.6/' + name).read()
        assert body == (REGISTRY / 'fips204-0.4.6' / name).read_bytes()
        destination = BASE / 'dependency/fips204-0.4.6' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream: stream.write(body)
        dependency_files[name] = sha(body)
record = {'observed_utc': datetime.now(timezone.utc).isoformat(),
    'qualification_source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
    'reused_test_source_commit': result['source_commit'], 'reused_test_implementation_commit': result['implementation_commit'],
    'source_files_identical': source_files, 'reused_tests': tests, 'reused_run': run,
    'original_release_result_sha256': sha((NATIVE / 'FORMAL_RELEASE_RESULT.json').read_bytes()),
    'original_release_stdout_sha256': sha(stdout), 'original_release_stderr_sha256': sha(stderr),
    'bootstrap_alias_marker': marker.decode(), 'signature_context_bytes': len(context),
    'mu_input_bytes_before_body': 71 + 2 * len(context), 'fips204_crate_sha256': sha(archive),
    'dependency_files': dependency_files, 'new_runtime_test_execution': False,
    'accepted_prefix_theorem_completed': False}
with (BASE / 'SOURCE_OBSERVATIONS.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({'matched_source_files': len(source_files), 'historical_passing_tests': len(tests),
                  'dependency_source_files': len(dependency_files), 'new_runtime_execution': False}))
