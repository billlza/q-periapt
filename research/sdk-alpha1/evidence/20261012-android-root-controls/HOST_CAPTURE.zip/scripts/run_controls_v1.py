from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_android_contract as contract
root=Path.cwd();work=root/'target/continuity-android-root-next';out=work/'root-controls-v1';out.mkdir(mode=0o700)
build=work/'boundary-v7';boundary=json.loads((build/'STATE.json').read_text());harness=json.loads((work/'harness-v4/STATE.json').read_text())
assert boundary['completed'] and not boundary['live_producer'] and harness['completed'] and not harness['live_producer']
binary=Path(harness['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==harness['binary_sha256']
routes={'noncommit':(41,7)}
tests={route:'android_root_owned::'+route.replace('-','_')+'_account_root_replacement' for route in routes}
catalog=(work/'harness-v4/catalog.stdout').read_text();expected=contract.TESTS|{'android_root_owned::'+r.replace('-','_')+'_account_root_replacement' for r in ['original','transition','bound-transition','adoption','noncommit']};names=re.findall(r'^(\S+): test$',catalog,re.M);assert len(names)==len(expected) and set(names)==expected
prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text());jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
state={'completed':False,'live_producer':True,'source_sha256':boundary['source_sha256'],'harness_sha256':harness['binary_sha256'],'routes':{},'scope':'Android-created original and distinct target enrollments; original, transition, bound transition and adoption; Debug/Release host JVM. Independent native issuer/witness and existing C receiver. Same-phone ART software execution is separate.'}
def save(): (out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for profile in ('debug','release'):
  for route,(count,cuts) in routes.items():
   directory=out/(profile+'-'+route);directory.mkdir(mode=0o700)
   driver=android._driver(directory,jdk/'bin/java',build/'qperiapt-continuity-android.jar',build/'tests',build/profile)
   path=directory/'driver.py';text=path.read_text();assert text.count('probes = (')==1;path.write_text(text.replace('probes = (',"probes = (('root-', 'RootOwnedProbe'), "));compile(path.read_text(),str(path),'exec')
   receiver=prior['native']['execution'][profile]['binaries']['C_client'];assert hashlib.sha256(Path(receiver['path']).read_bytes()).hexdigest()==receiver['sha256']
   cases=directory/'cases';env={k:v for k,v in prior['environment'].items() if not k.startswith(('QPC_','QPERIAPT_'))};env.update(QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(driver),QPC_CONFIGURATION_RECEIVER=receiver['path'])
   test=tests[route];stdout=sdk.command([str(binary),'--exact',test,'--nocapture'],directory/'execution',Path(harness['source']),environment=env)
   lines=stdout.decode().splitlines();assert lines.count('test '+test+' ... ok')==1
   assert sum(line.startswith(f'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; {len(expected)-1} filtered out;') for line in lines)==1
   for trust in ('fixed','recoverable'):
    assert lines.count(f'qualified Android account-root {route} {trust}: {count} Java processes; {cuts} process cuts; original report, new root traffic and controller-close revocation')==1
    case=cases/('signed-'+trust);assert (case/'process-count').read_bytes()==count.to_bytes(8,'big')
    assert (case/'inputs/root-route').read_bytes()==route.encode()
    assert (case/'root-complete-report').read_bytes()==(case/'root-verified').read_bytes()
    assert (case/'roster-effect-before').read_bytes()==(case/'root-original-effect-after').read_bytes()
    assert (case/'root-effect-before').read_bytes()==(case/'root-effect-after').read_bytes()
    assert (case/'root-effect-count').read_bytes()==(2).to_bytes(8,'big')
    if route!='original':assert (case/'inputs/root-original-target-account').read_bytes()!=(case/'inputs/root-target-account').read_bytes()
   state['routes'][profile+'-'+route]={'completed':True,'foreign_processes':count*2,'process_cuts':cuts*2,'bridge_sha256':boundary['profiles'][profile]['bridge_sha256'],'jar_sha256':boundary['jar_sha256']};save()
 assert all(hashlib.sha256((work/'source'/n).read_bytes()).hexdigest()==d for n,d in state['source_sha256'].items())
 state['completed']=True
finally:
 state['live_producer']=False;save()
print('Direct noncommit and cancellation controls passed 164 host calls and 28 process cuts; same-phone ART software execution remains separate.')
