from pathlib import Path
import hashlib,json,zipfile

# Public linkage only. Signatures and report MACs are checked by the native execution.
def check_case(read,route,count):
    assert read('root-preparation-cancelled')==read('root-successor-cancelled')==(302).to_bytes(4,'big')
    assert read('root-bad-noncommit')==(102).to_bytes(4,'big')
    assert read('root-noncommit-retained')==read('root-noncommit-replayed')==(4).to_bytes(4,'big')
    assert read('process-count')==count.to_bytes(8,'big') and read('inputs/root-route')==route.encode()
    assert read('original.request')==read('activated.request')
    assert read('root-begun')==read('root-preparing')==(1).to_bytes(4,'big')
    if route!='adoption':
     assert read('root-bound')==read('root-bound-replayed') and read('root-bound').startswith((b'QPARPL01',b'QPARPL02'))
     assert read('root-bad-freeze')==(102).to_bytes(4,'big')
    if route!='original':
     assert read('inputs/root-original-target-account')==read('inputs/root-original-target/trusted-account')!=read('inputs/root-target-account')
     assert read('root-original-target.request')!=read('root-target.request')
     assert read('inputs/root-original-target/enrollment-root')!=read('inputs/root-target/enrollment-root')
    checkpoint=read('root-retained');assert checkpoint==read('root-retained-replayed') and len(checkpoint)==72
    assert checkpoint[:32]==read('inputs/authority-application') and checkpoint[32:40]==(2).to_bytes(8,'big')
    assert checkpoint[40:]==read('inputs/root-target/trusted-account')==read('inputs/root-target-account')!=read('inputs/trusted-account')
    assert read('inputs/root-target/enrollment-root')!=read('inputs/enrollment-root')
    assert read('root-connected')!=read('roster-connected') and read('root-unknown')==read('root-acknowledged')
    assert read('root-effect-before')==read('root-effect-after') and read('root-effect-count')==(2).to_bytes(8,'big')
    assert read('roster-effect-before')==read('root-original-effect-after')
    assert read('root-complete-report')==read('root-verified') and read('root-verified')[8:321]==read('root-inventory')
    proposal=read('root-report-proposal');assert len(proposal)==353 and proposal[8:321]==read('root-inventory')
    assert proposal==read('root-report-unknown')==read('root-ack-proposal')==read('root-journal-unknown')==read('root-signer-unknown')
    for name,code in [('root-close-revoked',202),('root-activation-unknown',218),('root-tampered-report',208),('root-wrong-purpose',102)]:assert read(name)==code.to_bytes(4,'big')
