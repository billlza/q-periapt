// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Compiled native side of the independent C declaration/layout comparison.

macro_rules! abi_record {
    ($name:literal, $record:ty, { $($field:ident: $kind:ty,)+ }) => {{
        // A layout match alone cannot detect a changed signedness, pointee or
        // pointer mutability. These coercions also check each actual field type.
        $(let _: fn(&$record) -> &$kind = |record| &record.$field;)+
        print!("QPC_ABI {} {} {}", $name, std::mem::size_of::<$record>(),
               std::mem::align_of::<$record>());
        $(print!(" {}:{}:{}", stringify!($field),
                 std::mem::offset_of!($record, $field), std::mem::size_of::<$kind>());)+
        println!();
    }};
}


#[repr(C)]
pub struct Options {
    pub address: *const u8,
    pub address_length: usize,
    pub timeout_ms: u32,
    pub missing_from_c: u32,
}
fn main() {
 abi_record!("qpc_witness_v1", Options, { address: *const u8, address_length: usize, timeout_ms: u32, });
 assert_eq!(std::mem::size_of::<Options>(), 24);
 assert_eq!(std::mem::offset_of!(Options, missing_from_c), 20);
}
