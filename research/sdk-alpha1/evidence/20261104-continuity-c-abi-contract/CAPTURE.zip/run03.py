from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
import continuity_c_consumer as c
import continuity_c_abi as abi
from rust_sdk_msrv import validate_report

out=ROOT/'target/continuity-c-abi-contract/run-03'
out.mkdir()
outside=Path(json.loads((ROOT/'target/continuity-c-abi-contract/run-01/LOCATION.json').read_bytes())['path'])
consumer=outside/'consumer'; build=outside/'build'
sdk.write_json(out/'LOCATION.json',{'path':str(outside)})
fixture_inputs={p.relative_to(c.FIXTURE).as_posix():sdk.snapshot(p).sha256
                for p in c.FIXTURE.rglob('*') if p.is_file()}
reader_inputs={name:sdk.snapshot(ROOT/'artifact'/name).sha256 for name in
               ('continuity_c_abi.py','continuity_c_consumer.py','continuity_package.py')}
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPC_','QPERIAPT_'))}
for key in ('CC','CXX','AR','LD','CPP','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','CPATH',
            'C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','LIBRARY_PATH','SDKROOT',
            'MACOSX_DEPLOYMENT_TARGET','OPENSSL_CONF','OPENSSL_CONF_INCLUDE','OPENSSL_MODULES',
            'OPENSSL_ENGINES','SSL_CERT_FILE','SSL_CERT_DIR'):
    env.pop(key,None)
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',
           CARGO_TARGET_DIR=str(build),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),
           RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),
           PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
def run(argv,label,cwd=consumer,*,runtime=None):
    print(label,flush=True)
    return sdk.command(argv,out/label,cwd,environment=env if runtime is None else runtime)
report=ROOT/'target/openssl-witness-census/installed-02/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json'
pinned=sdk.snapshot(report)
cohort=validate_report(pinned.data,'d9cd990bf3dc6a731ec09b659fdc38f3f3cbc17b2f035b09e5e61094cbc11885',
                      pinned.sha256,sdk.source_identity()['rust_workspace_sha256'])
base=ROOT/'target/contract-purpose-admission/source-current/target/contract-purpose-installed'
producer=json.loads((base/'INSTALLED_COUNTERPART.json').read_bytes());assert producer['completed'] is True
package.verify_candidate_archive(base,producer['candidate_archive'])
record=producer['candidate_archive']
candidate=package.validate_candidate(sdk.snapshot(base/record['file']).data,set(record['files']))
previous=json.loads((ROOT/'target/continuity-c-abi-contract/run-02/RESULT.json').read_bytes())
for relative,expected in previous['fixture_inputs'].items():
    if relative=='Cargo.toml':continue
    assert sdk.snapshot(consumer/relative).sha256==expected,relative
for source in c.FIXTURE.rglob('*'):
    if source.is_file() and source.name!='Cargo.toml':
        shutil.copyfile(source,consumer/source.relative_to(c.FIXTURE))
for name in sdk.CONSUMER_CRATES:
    item=cohort['crates'][name]
    archive=sdk.snapshot(report.parent/'crates'/item['file'])
    assert archive.sha256==item['sha256']
    members=sdk.archive_files(archive.data,name)
    for relative,data in members.items():
        assert sdk.snapshot(consumer/'packages'/f'{name}-{sdk.VERSION}'/relative).data==data

for name,data in candidate.items():
    path=consumer/'packages'/f'{package.NAME}-{package.VERSION}'/name
    assert sdk.snapshot(path).data==data
original_lock=(package.CANDIDATE/'Cargo.lock').read_bytes()
# Retain the original installed resolution; verify it below.
result={'completed':False,'source_head_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'fixture_inputs':fixture_inputs,'reader_inputs':reader_inputs,'sdk_report_sha256':pinned.sha256,
        'candidate_archive_sha256':record['sha256'],'candidate_producer':producer['source_commit'],
        'profiles':{},'release_claim_eligible':False,'publication_performed':False}
try:
    metadata=json.loads(run([str(tc/'bin/cargo'),'metadata','--offline','--format-version','1'],'metadata'))
    result['resolution']=package.verify_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),
        original_lock,consumer_name=c.NAME,required_features=c.FEATURES)
    result['rustc']=run([str(tc/'bin/rustc'),'-vV'],'rustc').decode()
    cc=Path(run(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],'cc-path').decode().strip()).resolve()
    sdkroot=Path(run(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()).resolve()
    flags=['-isysroot',str(sdkroot)]
    result['cc']={'path':str(cc),'sha256':sdk.snapshot(cc,maximum=c.MAX_BINARY).sha256,
                  'version':run([str(cc),'--version'],'cc-version').decode(),
                  'sdk_settings_sha256':sdk.snapshot(sdkroot/'SDKSettings.json').sha256}
    filename='lib'+c.LIBRARY+'.dylib'
    for profile in ('debug','release'):
        extra=['--release'] if profile=='release' else []
        output=run([str(tc/'bin/cargo'),'rustc','--locked','--offline','--lib','--message-format=json','-j','2',
                    *extra,'--','-C','link-arg=-Wl,-install_name,@rpath/'+filename],'library-'+profile)
        library=c.built_artifact(output,consumer,build/profile,library=True)
        installed=outside/('installed-'+profile+'-03');installed.mkdir()
        sdk.copy(library,installed/filename,maximum=c.MAX_BINARY)
        symbols=run(['/usr/bin/nm','-gU',str(installed/filename)],'exports-'+profile).decode()
        names={line.split()[-1].removeprefix('_') for line in symbols.splitlines() if line.strip()}
        assert names==c.EXPORTS
        output=run([str(tc/'bin/cargo'),'test','--locked','--offline','--lib','--no-run','--message-format=json',
                    '-j','2',*extra],'unit-build-'+profile)
        unit=c.built_artifact(output,consumer,build/profile,library=False,unit=True)
        runtime={k:v for k,v in env.items() if not k.startswith(('DYLD_','LD_'))}
        result['profiles'][profile]=abi.qualify(consumer,installed,cc,flags,profile,unit,run,
            darwin=True,runtime=runtime,filename=filename)
        run([str(tc/'bin/cargo-clippy'),'clippy','--locked','--offline','--lib','--tests','-j','2',
             *extra,'--','-D','warnings'],'clippy-'+profile)
        sdk.write_json(out/('PROFILE_'+profile.upper()+'.json'),result['profiles'][profile])
    after={p.relative_to(c.FIXTURE).as_posix():sdk.snapshot(p).sha256 for p in c.FIXTURE.rglob('*') if p.is_file()}
    assert after==fixture_inputs
    assert reader_inputs=={name:sdk.snapshot(ROOT/'artifact'/name).sha256 for name in reader_inputs}
    result['sources_unchanged']=True;result['completed']=True
except BaseException as error:
    result['failure']=str(error)
    raise
finally:
    sdk.write_json(out/'RESULT.json',result)
print('COMPLETE',flush=True)
