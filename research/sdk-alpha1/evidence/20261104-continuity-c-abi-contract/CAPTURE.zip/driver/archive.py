from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import continuity_c_abi as abi
import rust_sdk_profile as sdk
source=ROOT/'target/continuity-c-abi-contract'
destination=ROOT/'research/sdk-alpha1/evidence/20261104-continuity-c-abi-contract'
destination.mkdir()
qualification=json.loads((source/'run-04/RESULT.json').read_bytes())
admission=json.loads((source/'full-admission/RESULT.json').read_bytes())
assert qualification['completed'] is True and qualification['sources_unchanged'] is True
assert admission['completed'] is True
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert commit.startswith('43c60a80')
for name,expected in qualification['fixture_inputs'].items():
    path='bindings/c/ContinuityPackageConsumer/'+name
    data=subprocess.check_output(['git','show',commit+':'+path],cwd=ROOT)
    assert hashlib.sha256(data).hexdigest()==expected,path
for name,expected in qualification['reader_inputs'].items():
    data=subprocess.check_output(['git','show',commit+':artifact/'+name],cwd=ROOT)
    assert hashlib.sha256(data).hexdigest()==expected,name
runtime_unchanged=[]
for name in subprocess.check_output(['git','diff','--name-only','c58d0928',commit,'--',
                                     'bindings/c/ContinuityPackageConsumer/src'],cwd=ROOT,text=True).splitlines():
    if name.endswith('/abi_contract.rs'):continue
    old=subprocess.check_output(['git','show','c58d0928:'+name],cwd=ROOT,text=True)
    current=(ROOT/name).read_text()
    restored=re.sub(r'\n// BEGIN C ABI CHECKS.*?// END C ABI CHECKS\n','',current,flags=re.S)
    if name.endswith('/lib.rs'):
        restored=restored.replace('\n#[cfg(test)]\n#[macro_use]\nmod abi_contract;\n','')
    assert restored.rstrip()==old.rstrip(),name
    runtime_unchanged.append(name)
outside=Path(json.loads((source/'run-04/LOCATION.json').read_bytes())['path'])
binary_equal={}
for profile in ('debug','release'):
    old=outside/f'installed-{profile}-02/libq_periapt_continuity_c_consumer.dylib'
    current=outside/f'installed-{profile}-04/libq_periapt_continuity_c_consumer.dylib'
    digest=hashlib.sha256(current.read_bytes()).hexdigest()
    assert digest==hashlib.sha256(old.read_bytes()).hexdigest()
    binary_equal[profile]=digest
contract=abi.load(ROOT/'bindings/c/ContinuityPackageConsumer')
join={'source_commit':commit,'source_join':'all captured C facade and reader hashes match the committed tree',
      'fixture_files':len(qualification['fixture_inputs']),'reader_files':len(qualification['reader_inputs']),
      'production_source_unchanged_from_parent':runtime_unchanged,
      'shared_libraries_unchanged_between_review_iterations':binary_equal,
      'qualification_sha256':sdk.snapshot(source/'run-04/RESULT.json').sha256,
      'admission_sha256':sdk.snapshot(source/'full-admission/RESULT.json').sha256}
sdk.write_json(source/'SOURCE_JOIN.json',join)
files={}
for p in source.rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(source).as_posix()
    if p.suffix in ('.json','.stdout','.stderr','.py','.rs','.c') and p.name!='archive.py':
        files[relative]=p.read_bytes()
# Header and review-snapshot bytes used by the negative probes are public inputs.
for p in source.rglob('qpc_owner.h'):
    files[p.relative_to(source).as_posix()]=p.read_bytes()
files['driver/archive.py']=Path(__file__).read_bytes()
for name in ('artifact/continuity_c_abi.py','artifact/test_continuity_c_abi.py',
             'bindings/c/ContinuityPackageConsumer/src/abi_contract.rs',
             'bindings/c/ContinuityPackageConsumer/abi/qpc-owner-v1.json'):
    files['source/'+name]=(ROOT/name).read_bytes()
files['source/change.patch']=subprocess.check_output(['git','diff','c58d0928',commit],cwd=ROOT)
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
          for name,data in sorted(files.items())}
with zipfile.ZipFile(destination/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
        info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
with zipfile.ZipFile(destination/'CAPTURE.zip') as archive:
    assert archive.namelist()==sorted(files)
    for name,row in manifest.items():
        data=archive.read(name)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
sdk.write_json(destination/'SHA256.json',manifest)
checks={'source_commit':commit,'completed_scope':'Apple Silicon installed C ABI declaration/type/layout qualification',
        'exports':len(contract['functions']),'c_records':len(contract['records']),
        'native_record_types':69,'record_fields':sum(map(len,contract['records'].values())),
        'callbacks':len(contract['callbacks']),'declared_constants':len(contract['constants']),
        'build_profiles':['debug','release'],'owner_tests_per_profile':59,'failed':0,'ignored':0,'filtered':0,
        'python_regression_tests':111,'windows_packaging_workflow_tests':15,
        'strict_clippy_profiles':['debug','release'],'rustfmt_changed_files':24,'tracked_rust_sources':1165,
        'codeql_database_scan_performed':False,'windows_native_execution_performed':False,
        'candidate_archive_sha256':qualification['candidate_archive_sha256'],
        'candidate_source_commit':qualification['candidate_producer'],
        'sdk_report_sha256':qualification['sdk_report_sha256'],
        'installed_resolution':qualification['resolution'],
        'failed_aggregate_attempts_retained':['run-01','run-02','run-03'],
        'succeeded_aggregate_attempt':'run-04','full_owner_regressions_are_separate':True,
        'review_counterexamples_reproduced_and_rejected_after_fix':True,
        'ci_current_head_counts_at_122139_utc':{'success':262,'queued':61,'failure':7,'skipped':2},
        'separate_older_independent_run':{'id':41791763191,'success':2,'in_progress':1,'queued':1},
        'capture_members':len(files),'capture_bytes':sum(map(len,files.values())),
        'capture_sha256':sdk.snapshot(destination/'CAPTURE.zip').sha256,
        'frozen_product_contract':False,'release_claim_eligible':False,'remote_mutations_performed':False}
sdk.write_json(destination/'CHECKS.json',checks)
print(json.dumps(checks,indent=2))
