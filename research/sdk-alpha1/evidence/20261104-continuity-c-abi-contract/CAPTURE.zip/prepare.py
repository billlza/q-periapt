from pathlib import Path
import re, json, sys
ROOT = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0, str(ROOT / 'artifact'))
import continuity_c_abi as abi
from continuity_c_consumer import EXPORTS
consumer = ROOT / 'bindings/c/ContinuityPackageConsumer'
mapping_text = '''
error lib ErrorRecord
account_target account Target
account_delivered account Delivered
witness witness Options
open_options opening Options
setup_status setup Status
setup_preparation setup Preparation
enrollment_intent enrollment Intent
configuration_header configuration Header
configuration_blob configuration Blob
configuration_sdk_trust configuration SdkTrustInput
configuration_protocol configuration ProtocolInput
configuration_create configuration CreateInput
configuration_open configuration OpenInput
configuration_witness configuration WitnessInput
roster_checkpoint enrollment Checkpoint
credential_renewal_status enrollment RenewalStatus
account_pin enrollment Pin
authority_options account_authority Options
authority_checkpoint account_authority Checkpoint
authority_association account_authority Association
authority_enrollment_options account_authority EnrollmentOptions
authority_open_options account_authority OpenOptions
authority_enrollment_selection account_authority EnrollmentSelection
root_scope root_replacement Scope
root_alternative root_replacement/alternative Alternative
enrollment_status enrollment Status
roster_refresh_resolution enrollment/roster_resolution RosterResolution
enrollment_request enrollment RequestBytes
policy_document enrollment/policy Document
policy_checkpoint enrollment/policy/renewal PolicyCheckpoint
policy_renewal_scope enrollment/policy/renewal Scope
public_record enrollment/policy/renewal PublicRecord
credential_renewal_request enrollment/credential_request CredentialRequest
pending_write_request_info enrollment/pending_recovery RequestInfo
policy_renewal_request enrollment/policy/renewal PolicyRequest
policy_renewal_status enrollment/policy/renewal PolicyStatus
independent_policy_proposal enrollment/policy/renewal/witness Proposal
independent_policy_preparation enrollment/policy/renewal/witness Preparation
independent_policy_progress enrollment/policy/renewal/witness Progress
roster_refresh_proposal enrollment/roster_refresh Proposal
roster_refresh_scope enrollment/roster_refresh Scope
roster_refresh_preparation enrollment/roster_refresh Preparation
roster_refresh_progress enrollment/roster_refresh Progress
roster_refresh_target enrollment/roster_refresh Target
policy_renewal_proposal enrollment/policy ProposalBytes
policy_renewal_cancellation enrollment/policy CancellationBytes
credential_renewal_proposal enrollment RenewalProposal
credential_renewal_cancellation enrollment RenewalCancellation
served server ServedRecord
closure_header recovery Header
closure_epoch recovery Epoch
closure_reserved recovery Reserved
closure_unconfirmed recovery Unconfirmed
closure_delivery recovery Delivery
closure_status recovery Status
account_cleanup_header recovery/account AccountHeader
account_cleanup_member recovery/account Member
account_cleanup_status recovery Status
account_reconciled_member recovery/account ReconciledMember
account_reconciliation recovery/account Reconciliation
retired_authority retirement Options
retired_inventory retirement Inventory
retired_proposal retirement Proposal
retired_report_info retirement ReportInfo
publication_key publication Key
publication_plan publication Plan
publication_status publication Status
peer_device peer_configuration ExpectedDeviceInput
peer_configuration peer_configuration Input
'''
mapping = {}
for line in mapping_text.splitlines():
    if line:
        name, module, native = line.split()
        mapping['qpc_' + name + '_v1'] = (module, native)
assert len(mapping) == 70
snapshot = dict(schema_version=1, abi='qpc-owner/1', package_version='0.0.0',
                frozen_product_contract=False,
                declarations=abi.declarations((consumer/'qpc_owner.h').read_text()))
(consumer/'abi').mkdir(exist_ok=True)
(consumer/abi.CONTRACT).write_text(json.dumps(snapshot,indent=2)+'\n')
contract = abi.load(consumer)
assert set(contract['records']) == set(mapping)
definitions, functions = {}, {}
for path in sorted((consumer/'src').rglob('*.rs')):
    module = path.relative_to(consumer/'src').with_suffix('').as_posix()
    text = path.read_text()
    if '\n// BEGIN C ABI CHECKS' in text:
        text = text.split('\n// BEGIN C ABI CHECKS')[0] + '\n'
    text = re.sub(r'//[^\n]*', '', text)
    for match in re.finditer(r'#\[repr\(C\)\](?:\s*#\[[^\]]+\])*\s*pub struct (\w+)\s*\{([^}]+)\}',text):
        fields = []
        for field in match[2].split(','):
            if not field.strip(): continue
            m = re.fullmatch(r'\s*pub ([a-z][a-z0-9_]*):\s*(.+?)\s*',field,re.S)
            assert m, (module,field)
            fields.append((m[1], ' '.join(m[2].split()).replace('p::MAX_DEVICES','32')))
        definitions[module,match[1]] = fields
    for match in re.finditer(r'pub unsafe extern "C" fn (qpc_\w+)\((.*?)\)\s*->\s*i32\s*\{',text,re.S):
        types = []
        for arg in match[2].split(','):
            if not arg.strip(): continue
            m = re.fullmatch(r'\s*\w+:\s*(.+?)\s*',arg,re.S)
            assert m, (module,arg)
            types.append(' '.join(m[1].split()).replace('ARCHIVE_BYTES','362'))
        assert match[1] not in functions
        functions[match[1]] = (module,types)
assert set(functions) == EXPORTS, (set(functions)-EXPORTS, EXPORTS-set(functions))
assert set(definitions) == set(mapping.values()), (set(definitions)-set(mapping.values()))
for name, key in mapping.items():
    assert contract['records'][name] == [f for f,t in definitions[key]], (name,key)

# Independently compare scalar widths, pointer mutability, arrays and mapped
# record identities before retaining these declaration assertions.
scalars = {'uint8_t':'u8','uint16_t':'u16','uint32_t':'u32','uint64_t':'u64',
           'int32_t':'i32','size_t':'usize','void':'c_void'}
all_keys = set(definitions)
def native_identity(ty,module):
    if ty.startswith('*const '): return ('const', native_identity(ty[7:],module))
    if ty.startswith('*mut '): return ('mut', native_identity(ty[5:],module))
    if m := re.fullmatch(r'\[(.+); (.+)\]',ty):
        return ('array', native_identity(m[1],module), 32 if m[2]=='p::MAX_DEVICES' else int(m[2]))
    if ty == 'Option<Commit>': return 'callback'
    if ty in scalars.values(): return ty
    if module=='peer_configuration' and ty in ('Header','Blob'):
        return ('configuration',ty)
    pieces=ty.split('::')
    if len(pieces)>1:
        relative='/'.join(pieces[:-1]); name=pieces[-1]
        parents=module.split('/') if module!='lib' else []
        options=[]
        for n in range(len(parents)+1):
            candidate=('/'.join(parents[:n]+[relative]),name)
            if candidate in all_keys: options.append(candidate)
        assert len(options)==1,(module,ty,options)
        return options[0]
    parents=module.split('/') if module!='lib' else []
    for n in range(len(parents),-1,-1):
        key=('/'.join(parents[:n]) or 'lib',ty)
        if key in all_keys:return key
    options=[key for key in all_keys if key[1]==ty]
    assert len(options)==1,(module,ty,options)
    return options[0]
def c_identity(text, parameter):
    text=' '.join(text.split())
    m=re.fullmatch(r'(const )?(\w+) (\* )?\w+(?: \[ (\w+) \])?',text)
    assert m,text
    base=scalars.get(m[2],mapping.get(m[2], 'callback' if m[2]=='qpc_commit_v1' else None))
    assert base is not None,text
    if m[3] or (parameter and m[4]):return ('const' if m[1] else 'mut',base)
    if m[4]:return ('array',base,int(m[4]))
    assert not m[1],text
    return base
for row in snapshot['declarations']:
    if not row.startswith('typedef struct '): continue
    name,field_names=abi.record_fields(row)
    module,native=mapping[name]
    body=row.split('{ ',1)[1].rsplit(' }',1)[0]
    c_fields=[]
    for item in body.split(' ; '):
        item=item.removesuffix(' ;')
        m=re.fullmatch(r'((?:const )?\w+) (.+)',item)
        assert m,item
        c_fields.extend(c_identity(m[1]+' '+part,False) for part in m[2].split(' , '))
    assert c_fields == [native_identity(t,module) for _,t in definitions[module,native]],name
for name,(module,types) in functions.items():
    arguments=contract['functions'][name].split(' , ')
    c_types=[c_identity(part,True) for part in arguments]
    r_types=[native_identity(t,module) for t in types]
    assert len(c_types)==len(r_types),(name,c_types,r_types)
    for argument, c_type, r_type in zip(arguments,c_types,r_types):
        if c_type!=r_type and isinstance(r_type,tuple) and r_type[0] in ('const','mut'):
            element=r_type[1]
            if isinstance(element,tuple) and element[0]=='array':
                extent=re.search(r' \[ (\w+) \]$',argument)
                assert extent and (int(extent[1]) if extent[1].isdigit() else contract['constants'][extent[1]])==element[2], (name,argument,r_type)
                r_type=(r_type[0],element[1])
        assert c_type==r_type,(name,argument,c_type,r_type)

modules=set(module for module,_ in definitions)|set(module for module,_ in functions.values())
for module in tuple(modules):
    pieces=module.split('/')
    for n in range(1,len(pieces)): modules.add('/'.join(pieces[:n]))
modules.add('lib')
for module in sorted(modules):
    path=consumer/'src'/f'{module}.rs'
    text=path.read_text()
    if '\n// BEGIN C ABI CHECKS' in text:
        text=text.split('\n// BEGIN C ABI CHECKS')[0]+'\n'
    lines=['', '// BEGIN C ABI CHECKS: reviewed alongside abi/qpc-owner-v1.json.',
           '#[cfg(test)]', 'pub(crate) fn verify_c_abi() {']
    for name,(source,native) in mapping.items():
        if source!=module:continue
        lines.append(f'    abi_record!("{name}", {native}, {{')
        for field,ty in definitions[module,native]: lines.append(f'        {field}: {ty},')
        lines.append('    });')
    for name,(source,types) in sorted(functions.items()):
        if source==module:
            lines.append('    let _: unsafe extern "C" fn('+', '.join(types)+f') -> i32 = {name};')
    children=[]
    for child in modules-{'lib'}:
        parent,_,leaf=child.rpartition('/')
        if (parent or 'lib')==module:children.append(leaf)
    for child in sorted(children):lines.append(f'    {child}::verify_c_abi();')
    lines+=['}','// END C ABI CHECKS','']
    path.write_text(text+'\n'.join(lines))
lib=consumer/'src/lib.rs'
text=lib.read_text()
marker='#![deny(unsafe_op_in_unsafe_fn)]\n'
assert text.count(marker)==1
if 'mod abi_contract;' not in text:
    text=text.replace(marker,marker+'\n#[cfg(test)]\n#[macro_use]\nmod abi_contract;\n')
lib.write_text(text)
(ROOT/'target/continuity-c-abi-contract/MAPPING.json').write_text(json.dumps(dict(
    records={k:list(v) for k,v in mapping.items()},
    functions={k:dict(module=m,types=t) for k,(m,t) in functions.items()},
    reviewed_type_pairs=len(functions)+sum(len(x) for x in definitions.values())),indent=2)+'\n')
print(json.dumps(dict(exports=len(functions),records=len(mapping),native_records=len(definitions),
                     native_modules=len(modules),constants=len(contract['constants']))))
