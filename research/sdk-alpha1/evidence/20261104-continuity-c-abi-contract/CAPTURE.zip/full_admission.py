from pathlib import Path
import hashlib,json,os,sys
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import continuity_c_consumer as c
import rust_sdk_profile as sdk
out=ROOT/'target/continuity-c-abi-contract/full-admission';out.mkdir()
base=ROOT/'target/continuity-c-abi-contract/run-04'
qualified=json.loads((base/'RESULT.json').read_bytes());assert qualified['completed'] is True
outside=Path(json.loads((base/'LOCATION.json').read_bytes())['path'])
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPC_','QPERIAPT_'))}
result={'completed':False,'profiles':{},'qualification_sha256':sdk.snapshot(base/'RESULT.json').sha256,
        'release_claim_eligible':False}
try:
    for profile in ('debug','release'):
        artifact=c.built_artifact((base/('unit-build-'+profile+'.stdout')).read_bytes(),outside/'consumer',
                                  outside/'build'/profile,library=False,unit=True)
        assert sdk.snapshot(artifact,maximum=c.MAX_BINARY).sha256==qualified['profiles'][profile]['identities']['rust_test']
        fixture=outside/('authority-fixture-'+profile);fixture.mkdir(mode=0o700)
        stdout=sdk.command([str(artifact)],out/profile,outside/'consumer',
                           environment=dict(env,QPC_AUTHORITY_FIXTURE=str(fixture)))
        c.verify_admission(stdout)
        assert sdk.snapshot(artifact,maximum=c.MAX_BINARY).sha256==qualified['profiles'][profile]['identities']['rust_test']
        result['profiles'][profile]={'tests':59,'failed':0,'ignored':0,'filtered':0,
                                    'binary_sha256':qualified['profiles'][profile]['identities']['rust_test']}
    result['completed']=True
except BaseException as error:
    result['failure']=str(error);raise
finally:
    sdk.write_json(out/'RESULT.json',result)
