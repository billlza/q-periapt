// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Compiled native side of the independent C declaration/layout comparison.

macro_rules! abi_record {
    ($name:literal, $record:ident, { $($field:ident: $kind:ty,)+ }) => {{
        // A layout match alone cannot detect a changed signedness, pointee or
        // pointer mutability. These coercions also check each actual field type.
        $(let _: fn(&$record) -> &$kind = |record| &record.$field;)+
        // Exhaustiveness also detects an added field that fits existing padding.
        let _: fn(&$record) = |record| {
            let $record { $($field: _,)+ } = record;
        };
        println!("QPC_ABI_NATIVE {} {}", $name,
                 std::any::type_name::<$record>().replace(' ', ""));
        print!("QPC_ABI {} {} {}", $name, std::mem::size_of::<$record>(),
               std::mem::align_of::<$record>());
        $(print!(" {}:{}:{}:{}", stringify!($field),
                 std::mem::offset_of!($record, $field), std::mem::size_of::<$kind>(),
                 std::any::type_name::<$kind>().replace(' ', ""));)+
        println!();
    }};
}

macro_rules! abi_signature {
    ($name:ident, ($($kind:ty),* $(,)?)) => {{
        print!("QPC_ABI_FUNCTION {} i32", stringify!($name));
        $(print!(" {}", std::any::type_name::<$kind>().replace(' ', ""));)*
        println!();
    }};
}

macro_rules! abi_function {
    ($name:ident, ($($kind:ty),* $(,)?)) => {{
        let _: unsafe extern "C" fn($($kind),*) -> i32 = $name;
        abi_signature!($name, ($($kind),*));
    }};
}

#[repr(C)]
pub struct Options {
    pub address: *const u8,
    pub address_length: usize,
    pub timeout_ms: u32,
}
unsafe extern "C" fn qpc_dummy(_: u32) -> i32 { 0 }
fn main() {
 abi_function!(qpc_dummy, (u32));
 abi_record!("qpc_witness_v1", Options, { address: *const u8, address_length: usize, timeout_ms: u32, });
 assert_eq!(std::mem::size_of::<Options>(), 24);
}
