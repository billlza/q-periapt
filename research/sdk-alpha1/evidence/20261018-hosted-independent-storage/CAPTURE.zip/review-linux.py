from pathlib import Path
import hashlib,io,json,re,subprocess,sys,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.extend([str(root/'artifact'),str(root/'target/independent-bootstrap-01/provider'),str(root/'research/continuity-openssl-peer')])
from evidence_io import parse_strict_json_bytes as parse
from peer.authority import DevicePin,Materials,Pins,authenticate
from peer.bootstrap import digest
from peer.wire import Reader,VerificationKey
head='0cff3934a8042816259944f2e4fd28236e61c49a'; runid=39129803021; jobid=117682453935
api=lambda path:subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+path],timeout=60)
run=parse(api(f'actions/runs/{runid}'),label='run');job=parse(api(f'actions/jobs/{jobid}'),label='job')
assert run['head_sha']==head and job['head_sha']==head and job['run_id']==runid
assert job['status']=='completed' and job['conclusion']=='success'
metadata=parse(api(f'actions/runs/{runid}/artifacts'),label='artifacts')
a=next(x for x in metadata['artifacts'] if x['name']=='independent-bootstrap-ubuntu-24.04')
assert a['id']==12138070686 and not a['expired'] and a['workflow_run']['head_sha']==head
path=out/'linux-0cff.zip'
if not path.exists(): path.write_bytes(api(f"actions/artifacts/{a['id']}/zip"))
raw=path.read_bytes();assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 names=z.namelist();assert len(names)==len(set(names))
 assert z.read('source-head.txt').decode().strip()==head
 assert z.read('rustc.txt').decode().startswith('rustc 1.98.1 ') and 'host: x86_64-unknown-linux-gnu' in z.read('rustc.txt').decode()
 assert 'x86_64' in z.read('host.txt').decode()
 for name in names:
  if name.endswith(('.stdout','.stderr')): assert not re.search(r'(?mi)^\s*(error:|warning:)',z.read(name).decode()),name
 assert z.read('exchange/native.stderr')==b'' and z.read('exchange.stderr')==b''
 r=parse(z.read('exchange/RESULT.json'),label='result')
 assert len(r['peer_sources'])==24
 for name,sha in r['peer_sources'].items():
  source=subprocess.check_output(['git','show',head+':research/continuity-openssl-peer/'+name])
  assert hashlib.sha256(source).hexdigest()==sha,name
 binary=z.read('counterpart');assert hashlib.sha256(binary).hexdigest()==r['native_sha256']
 assert binary[:6]==b'\x7fELF\x02\x01' and int.from_bytes(binary[18:20],'little')==62
 assert r['provider']['cryptography']=='48.0.1'
 for name,sha in r['public_files'].items(): assert hashlib.sha256(z.read('exchange/public/'+name)).hexdigest()==sha
 for name,sha in r['case_files'].items(): assert hashlib.sha256(z.read('exchange/cases/'+name)).hexdigest()==sha
 local=parse((root/'target/independent-traffic-01/run-03/RESULT.json').read_bytes(),label='admitted local traffic')
 expected={x['case']:(x['command'],x['status'],x['error'].encode() if x['error'] is not None else None) for x in local['native_commands']}
 assert len(r['native_commands'])==41 and {x['case'] for x in r['native_commands']}==set(expected)
 for case in r['native_commands']:
  name=case['case'];command,status,value=expected[name]
  inp=z.read('exchange/cases/'+name+'.input');result=z.read('exchange/cases/'+name+'.output')
  assert command==case['command'] and status==case['status']==result[0]
  assert value is None or result[1:]==value
  assert hashlib.sha256(inp).hexdigest()==case['input_sha256']
  assert hashlib.sha256(result[1:]).hexdigest()==case['output_sha256']
 for name in ('initial','final'):
  assert z.read('exchange/cases/'+name+'.output')==z.read('exchange/cases/duplicate-'+name+'.output')
 local=parse((root/'target/independent-traffic-01/run-03/RESULT.json').read_bytes(),label='local')
 assert len(r['python_refusals'])==51 and {c['case'] for c in r['python_refusals']}=={c['case'] for c in local['python_refusals']}
 assert all(c['exception'] in ('ValueError','InvalidSignature','InvalidTag') for c in r['python_refusals'])
 def read(name): return z.read('exchange/public/'+name)
 def pin(role):
  q=Reader(read('pin-'+role+'-head'));v=DevicePin(VerificationKey(read('pin-'+role+'-root')),q.take(32),q.integer(8),q.take(32),q.take(16),q.integer(8));q.finish();return v
 q=Reader(read('pin-policy-head'));pins=Pins(read('pin-sdk-root'),read('pin-sdk-state'),VerificationKey(read('pin-policy-root')),q.integer(8),q.take(32),pin('i'),pin('r'),read('pin-directory'));q.finish()
 m=Materials(*(read(n) for n in ('sdk-document','sdk-signature','policy','i-credential','i-roster','r-credential','r-roster','manifest','proof-1','proof-3')))
 ctx=authenticate(pins,m,150);assert ctx.digest==read('expected-context') and ctx.selection==read('expected-selection')
 initial=z.read('exchange/initial.bin');reply=z.read('exchange/reply.bin');final=z.read('exchange/final.bin');session=z.read('exchange/session.id')
 ib=ctx.initiator.open(initial,5,2440);rb=ctx.responder.open(reply,6,1256)
 assert ib[:40]==b'QPBSI001'+ctx.digest
 assert rb[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',initial)
 assert len(final)==136 and final[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',initial)+digest(b'reply-wire',reply)
 assert session==digest(b'session-id',final[:104])==z.read('exchange/cases/final.output')[1:]
 bad=ctx.initiator.open(z.read('exchange/cases/valid-signature-invalid-kem-confirmation.input'),5,2440)
 assert bad[:1288]==ib[:1288] and bad[1288]==ib[1288]^1 and bad[1289:]==ib[1289:]
 synthetic=VerificationKey(z.read('exchange/confirmation-control.public'))
 body=synthetic.open(z.read('exchange/confirmation-control.reply'),6,1256);assert body[-32:]==bytes(32)
 assert r['traffic']==local['traffic']
 assert all(x.end==160 for x in ctx.intervals[5:]) and all(x.end==200 for x in ctx.intervals[:5])
 di=z.read('exchange/durable-bootstrap-initial');dr=z.read('exchange/durable-bootstrap-reply');df=z.read('exchange/durable-bootstrap-final');ds=z.read('exchange/durable-bootstrap-session')
 dib=ctx.initiator.open(di,5,2440);drb=ctx.responder.open(dr,6,1256)
 assert dib[:40]==b'QPBSI001'+ctx.digest
 assert drb[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',di)
 assert len(df)==136 and df[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',di)+digest(b'reply-wire',dr)
 assert ds==digest(b'session-id',df[:104])
 for name in ('durable-final','durable-activate'):assert z.read('exchange/cases/'+name+'.output')==b'\1'+ds
 for label in ('reply','complete','skipped','outbox','ACK'):
  assert z.read('exchange/cases/durable-reopen-'+label+'.output')==b'\1reopened'
 assert z.read('exchange/cases/durable-initial.output')==z.read('exchange/cases/durable-initial-replay.output')
 assert z.read('exchange/cases/durable-send-2.output')==z.read('exchange/cases/durable-send-replay.output')
 def frame(value,direction,index,plain_size):
  assert len(value)==109+plain_size and value[:41]==b'QPCMSG03'+ds+bytes([direction])
  assert value[41:49]==bytes(8) and int.from_bytes(value[49:57],'big')==index
  from peer.traffic import message_id
  assert value[57:89]==message_id(ds,direction,index) and int.from_bytes(value[89:93],'big')==plain_size
 def app(value):
  n=int.from_bytes(value[:2],'big');assert n<=1024;return value[2:2+n],value[2+n:]
 plaintexts=[b'',b'independent application message',bytes(range(256))*64]
 for index,name in ((0,'durable-receive-0'),(1,'durable-receive-1'),(2,'durable-receive-last')):
  ad,value=app(z.read('exchange/cases/'+name+'.input'));assert len(ad)==(5,19,1024)[index]
  frame(value,1,index,len(plaintexts[index]))
  assert z.read('exchange/cases/'+name+'.output')==b'\1'+plaintexts[index]
  output=z.read('exchange/cases/durable-send-'+str(index)+'.output');assert output[0]==1
  frame(output[1:],2,index,len(plaintexts[index]))
  original=z.read('exchange/cases/durable-send-'+str(index)+'.input')
  assert original[:32]==output[58:90]
  original_ad,original_plain=app(original[32:]);assert original_ad==ad and original_plain==plaintexts[index]
 def ack(value,direction,floor):
  assert len(value)==81 and value[:41]==b'QPCMACK1'+ds+bytes([direction]) and int.from_bytes(value[41:49],'big')==floor
 for name,floor in (('last',0),('first',1),('middle',3)):
  value=z.read('exchange/cases/durable-consume-'+name+'.output');assert value[0]==1;ack(value[1:],1,floor)
 for name,requested,actual in (('zero',0,0),('complete',3,3),('stale',1,3)):
  ack(z.read('exchange/cases/durable-ACK-'+name+'.input'),2,requested)
  assert z.read('exchange/cases/durable-ACK-'+name+'.output')==b'\1'+actual.to_bytes(8,'big')
 assert not any(Path(name).name in ('key','journal','identity') for name in names)

 d=parse(z.read('session-recovery/RESULT.json'),label='durable session')
 st=parse(z.read('storage-cuts/RESULT.json'),label='storage cuts')
 assert d['source_files']==r['peer_sources'] and d['process_kills']==6 and len(d['worker_operations'])==27 and len(d['codec_refusals'])==6
 assert st['process_kills']==16 and len(st['results'])==37
 markers=[]
 for name in names:
  if name.startswith('storage-cuts/') and name.endswith('.stage'):
   marker=parse(z.read(name),label='cut');assert set(marker)=={'pid','stage'} and type(marker['pid'])is int and marker['pid']>0;markers.append(marker)
 assert len(markers)==16
 for item in d['worker_operations']:
  name=item['case'];value=z.read('session-recovery/'+name+'.stdout');err=z.read('session-recovery/'+name+'.stderr').decode()
  if 'signal' in item:
   assert item['signal']=='SIGKILL' and parse(value,label='session cut')=={'pid':item['worker_pid'],'stage':item['cut']} and not err
  elif 'refused' in item: assert not value and item['refused']in err
  else: assert hashlib.sha256(value).hexdigest()==item['stdout_sha256']and not err
 assert len(d['native_commands'])==9
 for item in d['native_commands']:
  prefix='session-recovery/native/cases/'+item['case'];before=z.read(prefix+'.input');after=z.read(prefix+'.output')
  assert after[0]==item['status']==1 and hashlib.sha256(before).hexdigest()==item['input_sha256']and hashlib.sha256(after[1:]).hexdigest()==item['output_sha256']
 def read(name): return z.read('session-recovery/native/public/'+name)
 q=Reader(read('pin-policy-head'));pins=Pins(read('pin-sdk-root'),read('pin-sdk-state'),VerificationKey(read('pin-policy-root')),q.integer(8),q.take(32),pin('i'),pin('r'),read('pin-directory'));q.finish()
 m=Materials(*(read(n)for n in ('sdk-document','sdk-signature','policy','i-credential','i-roster','r-credential','r-roster','manifest','proof-1','proof-3')))
 ctx=authenticate(pins,m,150);assert ctx.digest==read('expected-context')
 di=z.read('session-recovery/native/cases/persisted-initial.input');dr=z.read('session-recovery/native/cases/persisted-initial.output')[1:];df=z.read('session-recovery/native/cases/persisted-final.input')
 assert ctx.initiator.open(di,5,2440)[:40]==b'QPBSI001'+ctx.digest
 assert ctx.responder.open(dr,6,1256)[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',di)
 assert df[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',di)+digest(b'reply-wire',dr)
 assert z.read('session-recovery/native/cases/persisted-final.output')[1:]==digest(b'session-id',df[:104])
 def worker(name):return parse(z.read('session-recovery/'+name+'.stdout'),label=name)['result']
 assert worker('recover-ciphertext')==worker('repeat-ciphertext')
 assert worker('recover-plaintext')==worker('duplicate-plaintext')
 assert worker('recover-ACK')==worker('duplicate-consumption')
 assert worker('acknowledged-status')=='Acknowledged'
 assert z.read('storage-cuts.stderr')==z.read('session-recovery.stderr')==b''
 assert not any(Path(n).name in ('head','intent','configuration')or Path(n).name.startswith('.stage-')for n in names)
 report={'head':head,'run':runid,'job':jobid,'artifact':a['id'],'artifact_bytes':len(raw),'artifact_sha256':hashlib.sha256(raw).hexdigest(),'members':len(names),'native_binary_sha256':r['native_sha256'],'actual_binary_architecture':'ELF64 x86_64','peer_source_files_exact_git':24,'public_authority_and_signatures_independently_reverified':True,'native_commands':41,'python_refusals':51,'traffic':r['traffic'],'provider':{k:v for k,v in r['provider'].items() if k!='loaded_files'},'scope':'Linux independent volatile bootstrap and epoch-zero traffic versus actual Rust journal. Public identity/signature/frame/ACK fields and all native statuses rechecked; secret MAC/AEAD keys are not exported/rederived by this readback. macOS remains separate. No independent persistence, process-crash or full lifecycle claim.'}
report.update(storage={'process_kills':16,'controls':37},session={'process_kills':6,'worker_operations':27,'codec_refusals':6,'native_commands':9},source_files=r['peer_sources'],scope='Linux independent local-only persisted bootstrap/epoch-zero session and volatile regression. Direct worker PID at every cut, public transcripts and native results rechecked. No independent durable rekey, witness, full lifecycle, hardware power loss or release claim.')
(out/'LINUX_STORAGE_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
