from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
import time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-retirement/harness04'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'expired-unapplied','expired-applied','signer-commit-loss','signer-missing','signer-swapped'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-retirement-package-01'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for source, name in (('worker.js','worker.js'), ('controller.js','controller.js'), ('storage-fault.js','storage-fault.js')): shutil.copyfile(stage / source, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Original account recovery</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
browser_session = 'qpc-retirement-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage.parent / ('group-target-02/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker.js', stage / 'controller.js', stage / 'server.py', stage / 'storage-fault.js']}
run_state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Installed browser original permanent retirement and complete host accounting; native independent control plane, original two-recipient account and same shared engine on one host', 'cases': []}
sequence = 0

def browser(args, name, timeout=80):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', browser_session, *args], timeout_seconds=timeout,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name, 240 if args['action']=='expiry-held' else 80).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    run_state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="fanout_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("fanout_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            console = browser(['console', 'warning'], 'startup-console').decode()
            sdk.require(console == '### Result\nTotal messages: 0 (Errors: 0, Warnings: 0)\n\n', 'startup console error')
            run_state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case':case, 'calls':[], 'completed':False}; run_state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare-expiring-all' if case.startswith('expired-') else 'prepare',directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text()); cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json',inputs / (key + '.json'))
                args = {'case':key,'name':key+'-'+uuid.uuid4().hex[:8], 'id':uuid.uuid4().hex+uuid.uuid4().hex, 'profile':profile}
                success(dict(args,action='create'))
                grant_path = inputs / (key + '-grant.json')
                trace = output / (case + '-native-prepare'); trace.mkdir(mode=0o700)
                native('peer',['prepare-group',directory,output/'captures'/(key+'.bin'),grant_path,inputs,trace],case+'-group-prepare')
                grant = json.loads(grant_path.read_text())
                for slot in range(2):
                    peer = json.loads((inputs / (key + f'-peer-{slot}.json')).read_text())
                    sdk.require(peer['account'] == cfg['account'] and peer['root'] == cfg['root'] and peer['roster'] == grant['roster'] and peer['digest'] == grant['digest'], 'independent group roster mismatch')
                accepted = success(dict(args,action='accept')); prepared = success(dict(args,action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness',['enroll',directory,grant_path,output/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
                active = success(dict(args,action='activate')); sdk.require(active['journal'] == prepared['journal'], 'activation identity')
                row['journal'] = active['journal']
                sessions = []
                for slot in range(2):
                    established = success(dict(args,action='establish',slot=slot,requestId=list(os.urandom(32))))
                    sdk.require(established['journal'] == row['journal'], 'per-peer owner replaced original journal')
                    sessions.append(established['session'])
                    sdk.write_json(directory/'recipients'/str(slot)/'peer/session.json',established['session'])
                sdk.require(sessions[0] != sessions[1], 'different members share a session')
                args['sessions'] = sessions; row['sessions'] = sessions
                operation = success(dict(args,action='account-next'))['operation']; args['operation'] = operation; row['operation'] = operation
                original_slots = success(dict(args,action='session-slots'))['messages']; row['original_messages'] = original_slots
                lost=invoke(dict(args,action='account-deliver',selected=0,mode='drop-ack'))
                sdk.require(lost.get('code')=='PeerTransport' and lost.get('ownerClosed') is True,'original ACK loss not established')
                members=success(dict(args,action='cleanup-account-members'))['members']
                sdk.require([v['message'] for v in members]==original_slots and [v['phase'] for v in members]==[1,1],'original aggregate not fully committed')
                data_frames=[r for r in peers.get(key,[]) if r['kind']==3]
                sdk.require(len(data_frames)==1,'unexpected original data dispatch')
                effects=list((directory/'recipients/0/peer/effects').iterdir())
                sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(sessions[0])+bytes(original_slots[0])+b'all account devices','original business effect')
                effect=effects[0]; stat=effect.stat(); row['effect_before']=[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]
                expired=case.startswith('expired-')
                if expired:
                    mode='drop-before-advance' if case=='expired-unapplied' else 'drop-advance'
                    cut=invoke(dict(args,action='cleanup-session-begin',session=sessions[0],witnessMode=mode,cut='1'))
                    sdk.require(cut.get('code')=='WitnessTransport' and cut.get('ownerClosed') is True,'original cleanup cut missing')
                    fault=[v for v in records.get(key,[]) if v['mode']==mode and v['trigger']]
                    sdk.require(len(fault)==1 and fault[0]['dispatched']==(case=='expired-applied'),'wrong before/after witness cut')
                    until=max(cfg['until'],cfg['policy_until'])
                    sdk.require(time.time()<until,'fixture expired before original cut')
                    print(json.dumps({'case':case,'phase':'waiting for actual signed credential and policy expiry','until':until}),flush=True)
                    while time.time()<=until: time.sleep(min(5,max(0.05,until-time.time()+0.1)))
                    row['expiry']={'until':until,'observed':int(time.time())}
                old_calls=len(records.get(key,[]))
                retirement_path=inputs/(key+'-retirement.json')
                native('witness',['retire-device',directory,grant_path,output/'captures'/(key+'-genesis.json'),retirement_path],case+'-retirement')
                proof=json.loads(retirement_path.read_text()); row['retirement']=proof
                sdk.require(proof['retired'] is True and (not expired or proof['at']>max(proof['original_until'],proof['original_policy_until'])),'retirement authority time')
                def retired(action,**extra):
                    value=success(dict(args,action='retirement-'+action,**extra))
                    sdk.require(value['runtimeCreated'] is False,'retirement constructed operational runtime')
                    return value
                for negative in ('wrongProof','wrongSubject','wrongWitness'):
                    result=invoke(dict(args,action='retirement-inventory',**{negative:True}))
                    sdk.require('error' in result and result['runtimeCreated'] is False,'unverified retirement accepted')
                inventory=retired('inventory'); row['inventory']=inventory
                sdk.require((inventory['pending'] is not None)==expired,'original pending intent lost or invented')
                again=retired('inventory'); sdk.require(all(again[k]==inventory[k] for k in ('wire','binding','stored','pending')),'inventory changed after reopening')
                denied=invoke(dict(args,action='ordinary-open'))
                sdk.require(denied.get('code')=='Suspended' and denied['runtimeCreated'] is False,'ordinary reopening survived retirement')
                denied=invoke(dict(args,action='retirement-denied-send'))
                sdk.require(denied.get('code')=='State' and denied.get('ownerClosed') is True,'retired owner exposed traffic')
                accounting=output/'accounting'/key; accounting.mkdir(parents=True,mode=0o700)
                def persist(name,wire):
                    path=accounting/name
                    with path.open('xb') as stream: stream.write(wire); stream.flush(); os.fsync(stream.fileno())
                    descriptor=os.open(accounting,os.O_RDONLY)
                    try: os.fsync(descriptor)
                    finally: os.close(descriptor)
                    sdk.require(path.read_bytes()==wire,'host readback mismatch')
                    value=path.stat(); row.setdefault('host_accounting',[]).append({'path':str(path.relative_to(output)),
                        'sha256':sdk.snapshot(path).sha256,'identity':[value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns]})
                    return path
                def control(mode,wire,name):
                    request=persist(name+'-request.bin',bytes(wire)); reply=accounting/(name+'-receipt.bin')
                    native('witness',[mode,directory,request,reply],case+'-'+name)
                    return list(reply.read_bytes())
                args['inventoryReceipt']=control('retain-inventory',inventory['wire'],'inventory')
                request=retired('prepare-report'); row['report_request']=request
                again=retired('report-request')['request']
                sdk.require(again is not None and all(again[k]==request[k] for k in ('wire','report','inventory')),'original report request not retained')
                args['reportReceipt']=control('retain-report',request['wire'],'report')
                report=retired('report'); document=json.loads(report['document'])
                sdk.require(report['report']==request['report'] and document['report_id']==bytes(report['report']).hex() and document['schema']==1,'report ID/schema')
                sdk.require(document['inventory']==bytes(inventory['wire']).hex(),'inventory missing from JSON')
                views=document['views']; expected_roles=['authoritative','uncommitted_target'] if case=='expired-unapplied' else ['superseded_source','authoritative'] if case=='expired-applied' else ['authoritative']
                sdk.require([v['role'] for v in views]==expected_roles,'wrong source/target authority meaning')
                sdk.require(document['intent']['kind']==('write' if expired else 'none'),'ordinary pending record misclassified')
                if expired: sdk.require(document['intent']['transaction']=={'kind':'ordinary'},'generic cleanup relabeled renewal')
                common={}
                for index,view in enumerate(views):
                    sdk.require(set(view)=={'role','head','local_account','next_fanout_ordinal','records'} and view['local_account']==bytes(cfg['account']).hex(),'incomplete original view')
                    sdk.require(all(isinstance(view['head'][k],str) and view['head'][k].isdigit() for k in ('revision','fence')),'head integer precision')
                    session_records=[r['metadata']['session'] for r in view['records'] if r['metadata']['kind']=='session']
                    sdk.require(len(session_records)==2,'original member session omitted')
                    batches=[r['metadata'] for r in view['records'] if r['metadata']['kind']=='fanout']
                    sdk.require(len(batches)==1 and batches[0]['batch']==bytes(operation).hex() and len(batches[0]['members'])==2,'original aggregate missing')
                    for record in view['records']:
                        sdk.require(set(record)=={'id','context','phase','authorities','one_time_claims','inventory_references','metadata'},'record fields omitted')
                    for slot,session_id in enumerate(sessions):
                        item=next(v for v in session_records if v['session']==bytes(session_id).hex())
                        sdk.require(set(item)=={'source','session','role','peer_account','peer_device','peer_generation','progress','state'},'session fields omitted')
                        sdk.require(item['role']==1 and item['peer_generation']=='1' and item['peer_device']==bytes([82+slot]*16).hex(),'original peer changed')
                        session_state=item['state']; sdk.require(session_state['kind']=='live' and len(session_state['epochs'])==1,'original epoch missing')
                        sdk.require((session_state['previous_closure'] is not None)==(expired and index==1 and slot==0),'closure moved to wrong image')
                        epoch=session_state['epochs'][0]
                        sdk.require(set(epoch)=={'accounting','send_closed','consumed_out_of_order','reservation'},'epoch projection incomplete')
                        account=epoch['accounting']; sdk.require(account['sent']=='1' and account['acknowledged_before']=='0','unknown delivery turned into consumption')
                        sdk.require(len(account['unconfirmed'])==1 and account['unconfirmed'][0]['message']==bytes(original_slots[slot]).hex(),'original unknown message missing')
                        if slot in common: sdk.require(common[slot]==account['unconfirmed'][0],'same original ciphertext changed across views')
                        else: common[slot]=account['unconfirmed'][0]
                sdk.require(retired('report')['canonical']==report['canonical'] and retired('report')['document']==report['document'],'full report changed across reopen')
                canonical=persist(bytes(report['report']).hex()+'.bin',bytes(report['canonical']))
                persist(bytes(report['report']).hex()+'.json',report['document'].encode())
                args['recordedReport']=list(canonical.read_bytes())
                bad=invoke(dict(args,action='retirement-prepare-ack',wrongRecorded=True))
                sdk.require(bad.get('code')=='Authentication' and bad.get('ownerClosed') is True,'changed host report accepted')
                sdk.require(retired('ack-request')['request'] is None,'failed accounting fabricated host intent')
                acknowledged=retired('prepare-ack')
                sdk.require(acknowledged['wire']==request['wire'] and retired('ack-request')['request']['wire']==request['wire'],'original host intent changed')
                args['ackReceipt']=control('ack-report',acknowledged['wire'],'ack')
                sdk.require(retired('journal-state')['state']==0,'journal erased before explicit request')
                bad=invoke(dict(args,action='retirement-erase-journal',ackReceipt=args['reportReceipt']))
                sdk.require('error' in bad and bad.get('ownerClosed') is True and retired('journal-state')['state']==0,'wrong purpose erased journal')
                retired('erase-journal'); sdk.require(retired('journal-state')['state']==1,'journal erasure not authenticated')
                retired('prepare-signer'); sdk.require(retired('signer-state')['state']==0,'original signer missing before erasure')
                before_signer=retired('storage-observe'); row['signer_before']=before_signer
                sdk.require(before_signer['present'] and before_signer['revision']==1,'original signer descriptor')
                if case in ('signer-missing','signer-swapped'):
                    changed=retired('storage-fault',storageFault=case.split('-',1)[1]); row['storage_fault']=changed
                    sdk.require(all(changed['before'][k]==before_signer[k] for k in changed['before']),'fault selected wrong signer')
                    expected_code='Absent' if case=='signer-missing' else 'Conflict'
                    for action in ('retirement-signer-state','retirement-erase-signer'):
                        refused=invoke(dict(args,action=action))
                        sdk.require(refused.get('code')==expected_code and refused.get('ownerClosed') is True,'missing/swapped signer accepted')
                    after=retired('storage-observe'); sdk.require(all(after[k]==changed['after'][k] for k in changed['after']),'foreign record changed after refusal')
                    row['cleanup_complete']=False
                else:
                    if case=='signer-commit-loss':
                        result=invoke(dict(args,action='retirement-erase-signer',killAfterSignerCommit=True))
                        sdk.require(result.get('workerTerminatedAfterSignerCommit') is True,'real postcommit Worker termination missing')
                        row['unknown_signer_return']=result
                    else: sdk.require(retired('erase-signer')['closed'] is True,'successful signer erasure retained owner')
                    sdk.require(retired('signer-state')['state']==1,'same signer erasure not recovered')
                    after=retired('storage-observe'); row['signer_after']=after
                    sdk.require(after['identity']==before_signer['identity'] and after['revision']==2 and after['length']==8,'signer object replaced rather than retired')
                    sdk.require(retired('erase-signer')['closed'] is True,'exact erasure retry failed')
                    repeated=retired('storage-observe'); sdk.require(all(repeated[k]==after[k] for k in after if k not in ('runtimeCreated','observedAt')),'terminal changed during retry')
                    row['cleanup_complete']=True
                denied=invoke(dict(args,action='ordinary-open')); sdk.require(denied.get('code')=='Suspended','ordinary activation returned')
                sdk.require(len(records.get(key,[]))==old_calls,'retired cleanup sent ordinary witness requests')
                sdk.require(len([v for v in peers.get(key,[]) if v['kind']==3])==1,'retirement sent application traffic')
                stat=effect.stat();row['effect_after']=[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]
                sdk.require(row['effect_before']==row['effect_after'],'original business effect replayed or changed')
                for receipt in row['host_accounting']:
                    path=output/receipt['path']; stat=path.stat()
                    sdk.require(sdk.snapshot(path).sha256==receipt['sha256'] and [stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]==receipt['identity'],'host accounting rewritten')
                sdk.require(not failures,'native fixture errors: '+json.dumps(failures))
                row.update(completed=True,view_roles=expected_roles,unknown_messages=common)
                print(json.dumps({'case':case,'completed':True,'cleanup_complete':row['cleanup_complete'],'views':len(views)}),flush=True)
            run_state['witness_records'] = records; run_state['peer_records'] = peers
        except BaseException as error:
            run_state['protocol_failure']=repr(error)
            raise
        finally:
            run_state['witness_records']=records; run_state['peer_records']=peers; run_state['fixture_failures']=failures
            browser(['close'],'close')
    for name,digest in producer.items(): sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'installed web drift')
    run_state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    run_state['failure'] = repr(error); raise
finally:
    sdk.write_json(output/'RESULT.json',run_state)
print(json.dumps({'completed':True,'cases':cases,'scope':run_state['scope']}))
