import { tweakSigner } from './storage-fault.js';
import initialize, * as sdk from '../node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const bytes = value => new Uint8Array(value);
const get = async name => {
  const response = await fetch('../inputs/' + name, { credentials:'omit', cache:'no-store' });
  if (!response.ok) throw Error('public input response ' + response.status);
  return response.json();
};
onmessage = async ({data}) => {
  const resources = [], own = value => { resources.push(value); return value; };
  let owner, value, failure, ownerClosed, runtimeCreated = false;
  const cleanupErrors = [], start = performance.now();
  try {
    const cfg = await get(data.case + '.json'), at = () => BigInt(Math.floor(Date.now()/1000));
    const intent = own(new sdk.QPeriaptContinuityEnrollment(bytes(cfg.root),bytes(cfg.description).slice(0,16),1n,bytes(cfg.family),BigInt(cfg.from),BigInt(cfg.until)));
    const storage = bytes(data.id.match(/../g).map(v => parseInt(v,16)));
    const witness = () => {
      const id = bytes(cfg.witness_id); if (data.wrongWitness) id[0] ^= 1;
      return own(sdk.QPeriaptContinuityWitness.for_loopback(id,bytes(cfg.witness_public),new URL('/witness/'+data.case+'?mode='+(data.witnessMode ?? 'normal')+'&cut='+(data.cut ?? '0'),location.origin).href,5000));
    };
    if (data.action === 'create') {
      owner = await sdk.QPeriaptContinuityDevice.create(data.name,storage,intent);
      value = {request:[...await owner.request(at())]};
    } else if (data.action === 'ordinary-open') {
      owner = await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);
      value = {unexpected:true};
    } else if (data.action.startsWith('retirement-')) {
      const approved = await get(data.case+'-retirement.json');
      const receipt = bytes(approved.receipt), subject = bytes(approved.subject);
      if (data.wrongProof) receipt[receipt.length-1] ^= 1;
      if (data.wrongSubject) subject[32] ^= 1;
      const proof = own(new sdk.QPeriaptContinuityRetirement(witness(),bytes(approved.approved),subject,receipt));
      if (data.action === 'retirement-storage-fault' || data.action === 'retirement-storage-observe') {
        value = await tweakSigner(data.name,data.id,cfg,data.action === 'retirement-storage-observe'?'inspect':data.storageFault);
      } else {
        owner = await sdk.QPeriaptContinuityDevice.open_retired(data.name,storage,intent,proof);
        const request = item => { own(item); return {wire:[...item.to_bytes()],report:[...item.report_id()],inventory:[...item.inventory_binding()]}; };
        if (data.action === 'retirement-inventory') {
          const item = own(await owner.retirement_inventory());
          value={wire:[...item.to_bytes()],binding:[...item.binding()],stored:[...item.stored_image_digest()],pending:item.pending_intent_digest()===undefined?null:[...item.pending_intent_digest()]};
        } else if (data.action === 'retirement-prepare-report') value=request(await owner.prepare_retired_report(bytes(data.inventoryReceipt)));
        else if (data.action === 'retirement-report-request') {
          const item=await owner.retired_report_request(); value={request:item===undefined?null:request(item)};
        } else if (data.action === 'retirement-report') {
          const item=own(await owner.retired_report(bytes(data.inventoryReceipt),bytes(data.reportReceipt)));
          value={canonical:[...item.to_bytes()],document:item.to_json(),report:[...item.report_id()]};
        } else if (data.action === 'retirement-prepare-ack') {
          const recorded=bytes(data.recordedReport); if(data.wrongRecorded)recorded[recorded.length-1]^=1;
          value=request(await owner.prepare_retired_host_acknowledgement(recorded,bytes(data.inventoryReceipt),bytes(data.reportReceipt)));
        } else if (data.action === 'retirement-ack-request') {
          const item=await owner.retired_host_acknowledgement_request();value={request:item===undefined?null:request(item)};
        } else if (data.action === 'retirement-journal-state') value={state:await owner.retired_journal_erasure_status()};
        else if (data.action === 'retirement-erase-journal') {await owner.erase_retired_journal(bytes(data.ackReceipt));value={erased:true};}
        else if (data.action === 'retirement-prepare-signer') {await owner.prepare_retired_signer_erasure(bytes(data.ackReceipt));value={prepared:true};}
        else if (data.action === 'retirement-signer-state') value={state:await owner.retired_signer_erasure_status()};
        else if (data.action === 'retirement-erase-signer') {
          if(data.killAfterSignerCommit) {
            const originalPut=IDBObjectStore.prototype.put;
            IDBObjectStore.prototype.put=function(value,key) {
              const request=originalPut.call(this,value,key);
              if(this.name==='files' && value?.kind==='bytes' && value.revision===2 && value.length===8 && String(key).endsWith('/signer.key')) {
                // Hold the native completion callback after the real transaction
                // commits. The parent kills this Worker; no SDK success is returned.
                this.transaction.oncomplete=()=>postMessage({signerCommitObserved:true,identity:value.id,revision:value.revision});
              }
              return request;
            };
          }
          await owner.erase_retired_signer(); value={erased:true,closed:owner.is_closed()};
        } else if(data.action === 'retirement-denied-send') value={unexpected:[...await owner.next_account_message_id()]};
        else throw Error('unknown retired operation');
      }
      value.runtimeCreated=runtimeCreated;value.observedAt=Number(at());
    } else if (data.action.startsWith('cleanup-')) {
      owner = await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);
      const p = cfg.policies[data.wrongHistory ? (data.profile === 'local' ? 'required' : 'local') : data.profile];
      const history = own(new sdk.QPeriaptContinuityHistoricalPolicy(bytes(cfg.policy_root),bytes(cfg.family),BigInt(p.version),bytes(p.digest),bytes(p.wire)));
      const local = data.profile === 'local' || data.forceLocal;
      const isAccount = data.action.startsWith('cleanup-account-');
      if (isAccount) {
        const id = bytes(data.operation); if (data.wrongOperation) id[31] ^= 1;
        if (local) await owner.recover_account_local(id,history);
        else await owner.recover_account(id,history,witness());
      } else {
        const id = bytes(data.session); if (data.wrongSession) id[0] ^= 1;
        if (local) await owner.recover_session_local(id,history);
        else await owner.recover_session(id,history,witness());
      }
      const accountStatus = async () => {
        const s = own(await owner.recovered_account_status());
        return {operation:[...s.operation_id()],phase:s.phase(),report:s.abandonment_id() === undefined ? null : [...s.abandonment_id()]};
      };
      const sessionStatus = async () => {
        const s = own(await owner.recovered_session_status());
        return {phase:s.phase(),report:s.report_id() === undefined ? null : [...s.report_id()]};
      };
      if (data.action === 'cleanup-account-status') value = {status:await accountStatus()};
      else if (data.action === 'cleanup-account-members') {
        const members = own(await owner.recovered_account_members()), rows=[];
        for (let index=0; index<members.len(); ++index) {
          const member = own(members.member(index));
          rows.push({device:[...member.device()],session:[...member.session()],message:[...member.message()],phase:member.phase()});
        }
        value = {operation:[...members.operation_id()],members:rows,status:await accountStatus()};
      } else if (data.action === 'cleanup-account-begin') {
        const report = own(await owner.begin_account_abandonment());
        value = {document:report.to_json(),report:[...report.report_id()],operation:[...report.operation_id()],members:report.member_count(),status:await accountStatus()};
      } else if (data.action === 'cleanup-account-ack') {
        await owner.acknowledge_account_abandonment(bytes(data.report)); value={status:await accountStatus()};
      } else if (data.action === 'cleanup-account-retire') {
        await owner.retire_recovered_account(); value={status:await accountStatus()};
      } else if (data.action === 'cleanup-session-status') value={status:await sessionStatus()};
      else if (data.action === 'cleanup-session-begin') {
        const report = own(await owner.begin_session_closure());
        value={document:report.to_json(),report:[...report.report_id()],session:[...report.session_id()],status:await sessionStatus()};
      } else if (data.action === 'cleanup-session-ack') {
        await owner.acknowledge_session_closure(bytes(data.report)); value={status:await sessionStatus()};
      } else if (data.action === 'cleanup-account-send') {
        value={unexpected:[...await owner.next_account_message_id()]};
      } else throw Error('unknown cleanup action');
      value.runtimeCreated=runtimeCreated; value.observedAt=Number(at());
    } else {
      const grant=await get(data.case+'-grant.json');
      const runtime=own(new sdk.QPeriaptRuntime(bytes(cfg.sdk_policy),bytes(cfg.sdk_signature),bytes(cfg.sdk_root),bytes(cfg.sdk_state),32,4)); runtimeCreated=true;
      const p=cfg.policies[data.profile];
      const policy=own(new sdk.QPeriaptContinuityPolicy(runtime,bytes(cfg.policy_root),bytes(cfg.family),BigInt(p.version),bytes(p.digest),bytes(p.wire),at()));
      const account=g=>own(new sdk.QPeriaptContinuityAccountTrust(bytes(cfg.account),bytes(cfg.root),BigInt(g.version),bytes(g.digest),bytes(cfg.family)));
      owner=await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);
      if(data.action==='accept') value={journal:[...await owner.accept(bytes(grant.certificate),bytes(grant.roster),account(grant),policy,at())]};
      else if(data.action==='prepare') {
        const prepared=own(await owner.prepare(policy,at())), status=own(await owner.status());
        value={phase:prepared.requires_witness()?'requires-witness-enrollment':'prepared-local',journal:[...status.journal()]};
        if(prepared.requires_witness()) Object.assign(value,{subject:[...prepared.subject()],genesis:[...prepared.image_digest()]});
      } else {
        const journal=data.profile==='local'?await owner.activate_local(policy,at()):await owner.activate(policy,witness(),at());
        const context=async slot=>{
          const peer=await get(data.case+'-peer-'+slot+'.json');
          const a=own(new sdk.QPeriaptContinuityParticipant(account(grant),bytes(cfg.description).slice(0,16),1n));
          const b=own(new sdk.QPeriaptContinuityParticipant(account(peer),bytes(peer.device),1n));
          return {bundle:bytes(peer.bundle),required:own(new sdk.QPeriaptContinuityPeerTrust(a,b,sdk.QPeriaptContinuityQuality.OneTimeBoth,new Uint8Array(32).fill(77)))};
        };
        const endpoint=slot=>own(sdk.QPeriaptContinuityEndpoint.for_loopback(new URL('/peer/'+data.case+'/'+slot+'?mode='+(data.mode??'normal'),location.origin).href));
        const reopen=async slot=>{const c=await context(slot);return own(await owner.reopen_session(c.bundle,policy,c.required,sdk.QPeriaptContinuityRole.Initiator,bytes(data.sessions[slot]),at()));};
        if(data.action==='activate') value={journal:[...journal]};
        else if(data.action==='establish') {
          const c=await context(data.slot),peer=own(await owner.admit_peer(c.bundle,policy,c.required,sdk.QPeriaptContinuityRole.Initiator,at()));
          const session=own(await owner.establish_session(peer,bytes(data.requestId),endpoint(data.slot),10000,at));
          value={session:[...session.id()],journal:[...journal]};
        } else if(data.action==='account-next') value={operation:[...await owner.next_account_message_id()]};
        else {
          const sessions=[await reopen(0),await reopen(1)];
          if(data.action==='session-slots') value={messages:[[...await owner.next_session_message_id(sessions[0],at())],[...await owner.next_session_message_id(sessions[1],at())]]};
          else {
            const targets=own(new sdk.QPeriaptContinuityAccountTargets()); for(const session of sessions) targets.add(session);
            const input=own(new sdk.QPeriaptContinuityAccountMessage(bytes(data.operation),bytes(cfg.account),new TextEncoder().encode('all account devices'),new TextEncoder().encode('account/v1')));
            if(data.action==='runtime-closed') runtime.close();
            if(data.action==='expiry-held') {
              const until=Math.max(cfg.policy_until,cfg.until),heldAt=Number(at());
              if(heldAt>=until) throw Error('owner was not acquired before expiry');
              const progress=await fetch('/progress/'+data.case+'.json',{method:'POST',credentials:'omit',body:JSON.stringify({heldAt,until,runtimeCreated})});
              if(!progress.ok) throw Error('expiry observation not retained');
              while(Number(at())<=until) await new Promise(resolve=>setTimeout(resolve,500));
            }
            if(data.action!=='account-deliver' && data.action!=='expiry-held' && data.action!=='runtime-closed') throw Error('unknown operational action');
            const result=own(await owner.deliver_account_member(targets,input,data.selected??0,endpoint(data.selected??0),10000,at));
            value={message:[...result.message()],outcome:result.outcome(),exchanges:result.exchanges()};
          }
        }
      }
    }
  } catch(error) {failure=error;ownerClosed=owner?.is_closed();}
  finally {
    if(owner) {
      try{await owner.close();}catch(error){cleanupErrors.push(String(error));}
      try{owner.free();}catch(error){cleanupErrors.push(String(error));}
    }
    for(const resource of resources.reverse()) {
      try{if(typeof resource.close==='function')await resource.close();}catch(error){cleanupErrors.push(String(error));}
      try{resource.free();}catch(error){cleanupErrors.push(String(error));}
    }
  }
  const diagnostics={runtimeCreated,observedAt:Math.floor(Date.now()/1000),elapsedMs:performance.now()-start};
  if(failure||cleanupErrors.length)postMessage({done:true,error:String(failure??'cleanup failure'),code:failure?.code,ownerClosed,cleanupErrors,...diagnostics});
  else postMessage({done:true,value,cleanupErrors,...diagnostics});
};
postMessage({ready:true});
