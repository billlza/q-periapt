from pathlib import Path
import json
import os
import re
import sys
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
inputs=json.loads((stage/'OWNER_INPUTS_03.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'precheck drift')
mode=sys.argv[1]
if mode=='package':
    sdk.command(['sh',str(stage/'build-package.sh')],stage/'package-build-01',root)
elif mode=='controls':
    clone=root/'target/continuity-browser-publication/source'
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(clone/name).sha256==digest,'clone drift')
    env=dict(os.environ); env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PYTHONPATH='artifact')
    sdk.command(['sh','artifact/python-run.sh','-m','unittest','artifact.test_codeql_rust_quality','artifact.test_wasm_sdk_package','artifact.test_wasm_browser_storage'],stage/'controls-01',clone,environment=env)
elif mode=='native':
    env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
    env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
    cargo=Path(env['RUSTC']).parent/'cargo'; counts={}
    for label,selected in [('retired','retired'),('renewal_boundary','expired_cleanup_intent')]:
        output=sdk.command([str(cargo),'test','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--lib',selected,'--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','--nocapture'],stage/('regression-'+label),root,environment=env).decode()
        matches=re.findall(r'^test result: ok\. (\d+) passed; 0 failed;',output,re.MULTILINE)
        sdk.require(matches and all(int(value)>0 for value in matches),'empty or failed suite')
        counts[label]=[int(value) for value in matches]
    sdk.write_json(stage/'NATIVE_REGRESSIONS.json',{'completed':True,'counts':counts,'inputs':inputs})
else: raise ValueError('mode')
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'postcheck drift')
print(mode+' check terminal success',flush=True)
