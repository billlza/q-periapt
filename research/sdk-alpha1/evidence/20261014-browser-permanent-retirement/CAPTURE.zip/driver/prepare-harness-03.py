from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd(); stage=root/'target/continuity-browser-retirement'; old=stage/'harness02'; new=stage/'harness03'; new.mkdir()
for name in ('run.py','server.py','worker.js','controller.js','storage-fault.js'): sdk.copy(old/name,new/name)
path=new/'run.py';path.write_text(path.read_text().replace('continuity-browser-retirement/harness02','continuity-browser-retirement/harness03'))
path=new/'controller.js'; source=path.read_text(); marker='        if (data.value?.request) {'
sdk.require(source.count(marker)==1,'capture guard marker')
path.write_text(source.replace(marker,"        if (args.action === 'create' && data.value?.request) {"))
for p in new.iterdir():
    if p.suffix=='.py': ast.parse(p.read_text(),filename=str(p))
    elif p.suffix=='.js': sdk.command(['/opt/homebrew/bin/node','--check',str(p)],new/('syntax-'+p.stem),root)
print('Fresh harness03 restricts enrollment capture to original create; failed run02 remains sealed')
