from pathlib import Path
import rust_sdk_profile as sdk

root=Path.cwd(); path=root/'crates/q-periapt-sdk-wasm/src/continuity/retirement/reports.rs'
source=path.read_text()
start=source.index('fn bootstrap('); middle=source.index('fn session('); end=source.index('fn fanout_status(')
parts={'bootstrap_metadata.rs':source[start:middle], 'session_metadata.rs':source[middle:end]}
folder=path.with_suffix(''); folder.mkdir(exist_ok=True)
for name,body in parts.items():
    target=folder/name; sdk.require(not target.exists(),'new module already exists')
    body=body.replace('fn bootstrap(', 'pub(super) fn bootstrap(').replace('fn cancellation(', 'pub(super) fn cancellation(').replace('fn session(', 'pub(super) fn session(')
    target.write_text('// SPDX-License-Identifier: Apache-2.0 OR MIT\nuse super::*;\n\n'+body)
source=source[:start]+source[end:]
source=source.replace('fn optional(', 'mod bootstrap_metadata;\nmod session_metadata;\nuse bootstrap_metadata::{bootstrap, cancellation};\nuse session_metadata::session;\n\nfn optional(',1)
path.write_text(source)
print('Complete accounting projection split at bootstrap and session boundaries')
