from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'; clone=root/'target/continuity-browser-publication/source'
base='3c223dcd3e7a2191b42e69188bac38a235b6c82a'
def git(where,*args): return subprocess.run(['git',*args],cwd=where,check=True,capture_output=True).stdout
sdk.require(git(root,'rev-parse','HEAD').decode().strip()==base and git(clone,'rev-parse','HEAD').decode().strip()==base,'base moved')
sdk.require(not git(clone,'status','--porcelain') and not git(root,'diff','--cached','--name-only'),'unexpected clone/index changes')
new=sorted(name for name in git(root,'ls-files','--others','--exclude-standard').decode().splitlines() if name.endswith('.rs'))
sdk.require(len(new)==7,'unexpected new source count')
for name,old,new_count in [('ARTIFACT.md','659 tracked `.rs` files','666 tracked `.rs` files'),('artifact/codeql_rust_quality.py','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 659','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 666')]:
    p=root/name; source=p.read_text(); sdk.require(source.count(old)==1,'inventory marker'); p.write_text(source.replace(old,new_count))
p=root/'artifact/test_codeql_rust_quality.py'; source=p.read_text()
marker='            "research/continuity-identity-candidate/src/enrollment/witness_recovery_renewal_tests.rs",'
sdk.require(source.count(marker)==2,'positive and missing-module controls required')
source=source.replace(marker,marker+'\n'+'\n'.join('            '+json.dumps(name)+',' for name in new)); p.write_text(source)
paths=sorted(set(git(root,'diff','--name-only').decode().splitlines())|set(git(root,'ls-files','--others','--exclude-standard').decode().splitlines()))
inputs={name:sdk.snapshot(root/name).sha256 for name in paths}
sdk.write_json(stage/'OWNER_INPUTS_03.json',inputs)
for name,digest in inputs.items():
    source=sdk.snapshot(root/name); sdk.require(source.sha256==digest,'source drift')
    target=clone/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(source.data)
git(clone,'add','--',*paths)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':base,'source':str(clone),'overlay':inputs})
sdk.copy(clone/'target/browser-recovery-build.py',clone/'target/browser-retirement-build.py')
script=(root/'target/continuity-browser-recovery/build-package.sh').read_text()
(stage/'build-package.sh').write_text(script.replace('browser-recovery-build.py','browser-retirement-build.py').replace('browser-recovery-package-01','browser-retirement-package-01'))
print(json.dumps({'files':len(paths),'new_rust':new,'tracked_rust':666,'clone_overlay_ready':True}))
