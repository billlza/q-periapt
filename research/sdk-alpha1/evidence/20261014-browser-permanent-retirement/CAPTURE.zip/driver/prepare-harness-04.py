from pathlib import Path
import ast
import re
import rust_sdk_profile as sdk
root=Path.cwd(); stage=root/'target/continuity-browser-retirement'; old=stage/'harness03'; new=stage/'harness04'; new.mkdir()
for name in ('run.py','server.py','worker.js','controller.js','storage-fault.js'): sdk.copy(old/name,new/name)
p=new/'run.py'; source=p.read_text().replace('continuity-browser-retirement/harness03','continuity-browser-retirement/harness04')
old_line="                        state=item['state']; sdk.require(state['kind']=='live' and len(state['epochs'])==1,"
sdk.require(source.count(old_line)==1,'session-state marker')
source=source.replace(old_line,"                        session_state=item['state']; sdk.require(session_state['kind']=='live' and len(session_state['epochs'])==1,")
source=source.replace("sdk.require((state['previous_closure']","sdk.require((session_state['previous_closure']").replace("epoch=state['epochs'][0]","epoch=session_state['epochs'][0]")
source=re.sub(r'\bstate(?=\[|\.update\(| = \{)','run_state',source).replace("sdk.write_json(output/'RESULT.json',state)","sdk.write_json(output/'RESULT.json',run_state)")
tree=ast.parse(source,filename=str(p)); sdk.require(not any(isinstance(node,ast.Name) and node.id=='state' for node in ast.walk(tree)),'ambiguous run-state name remains')
p.write_text(source)
print('Fresh harness04 separates run receipt from session metadata; failed run03 raw CLI records retained')
