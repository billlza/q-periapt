from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
inputs=json.loads((stage/'OWNER_INPUTS_03.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'precheck source drift')
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None)
rustup=root/'target/continuity-browser-connection/msrv-tools/rustup'
toolchain=rustup/'toolchains/1.90.0-aarch64-apple-darwin'
env.update(RUSTC=str(toolchain/'bin/rustc'),RUSTDOC=str(toolchain/'bin/rustdoc'),
    RUSTUP_HOME=str(rustup),RUSTUP_TOOLCHAIN='1.90.0-aarch64-apple-darwin',
    DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'),CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang')
sdk.command([str(toolchain/'bin/rustc'),'--version'],stage/'msrv-version',root,environment=env)
sdk.command([str(toolchain/'bin/cargo'),'check','--locked','--offline','-p','q-periapt-sdk-wasm',
    '--features','browser-continuity','--lib','--target','wasm32-unknown-unknown',
    '--target-dir',str(root/'target/continuity-browser-fanout/msrv-check-target'),'-j','2'],
    stage/'msrv-check',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'postcheck source drift')
print('Recovery API Rust1.90 WASM check passed')
