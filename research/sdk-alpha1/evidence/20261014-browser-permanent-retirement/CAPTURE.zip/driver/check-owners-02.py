from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
env['CC_wasm32_unknown_unknown']='/opt/homebrew/opt/llvm/bin/clang'
toolchain=Path(env['RUSTC']).parent
mode=sys.argv[1]
if mode=='prepare':
    files=sorted(set(subprocess.run(['git','diff','--name-only'],check=True,capture_output=True,text=True).stdout.splitlines())
        |set(subprocess.run(['git','ls-files','--others','--exclude-standard'],check=True,capture_output=True,text=True).stdout.splitlines()))
    sdk.require(files and all((name.startswith('research/continuity-identity-candidate/src/') or name.startswith('crates/q-periapt-sdk-wasm/src/')) and name.endswith(('.rs','.js')) for name in files),'unexpected scope')
    sdk.command([str(toolchain/'rustfmt'),'--edition','2021','--config','skip_children=true',*[name for name in files if name.endswith('.rs')]],stage/'format-owners02-02',root,environment=env)
    for i,name in enumerate(name for name in files if name.endswith('.js')):
        sdk.command(['/opt/homebrew/bin/node','--check',name],stage/f'owners02-js-{i}',root)
    sdk.write_json(stage/'OWNER_INPUTS_02.json',{name:sdk.snapshot(root/name).sha256 for name in files})
else:
    sdk.require(mode in ('native','wasm'),'mode')
    inputs=json.loads((stage/'OWNER_INPUTS_02.json').read_text())
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'input drift')
    args=[str(toolchain/'cargo'),'clippy','--locked','--offline']
    if mode=='native': args+=['--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets']
    else: args+=['-p','q-periapt-sdk-wasm','--features','browser-continuity','--lib','--target','wasm32-unknown-unknown']
    args+=['--target-dir',str(root/('target/continuity-browser-fanout/'+mode+'-target')),'-j','2','--','-D','warnings']
    sdk.command(args,stage/('owners02-'+mode+'-02'),root,environment=env)
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'input drift')
    print(mode+' signer retirement strict Clippy passed')
