from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
old=stage/'group-fixture'; new=stage/'group-fixture-02'
for source in [old/'Cargo.toml',old/'Cargo.lock',*sorted((old/'src').rglob('*.rs'))]: sdk.copy(source,new/source.relative_to(old))
path=new/'src/bin/retirement/control.rs'; source=path.read_text()
marker='    let roster = root.issue_roster(2, validity, &[root.roster_entry(&certificate)?])?;'
sdk.require(source.count(marker)==1,'complete roster construction marker')
replacement='''    let mut entries = vec![root.roster_entry(&certificate)?];
    let previous_pin = p::AccountPin::new(root.account_id()?, root.public_key()?, original.roster().checkpoint(), array(cfg, "family")?)?;
    for slot in 0..2 {
        let retained = load(&dir.join(format!("recipients/{slot}/peer/PUBLIC.json")))?;
        let certificate = bytes(&retained, "certificate")?;
        let peer = previous_pin.verify_historical_device(&certificate, &bytes(&grant, "roster")?)?;
        if peer.device_id() == original.device_id() { return Err("replacement selected original device as peer".into()); }
        entries.push(root.roster_entry(&certificate)?);
    }
    let roster = root.issue_roster(2, validity, &entries)?;'''
source=source.replace(marker,replacement);path.write_text(source)
driver=(stage/'build-fixture.py').read_text().replace("stage/'group-fixture'","stage/'group-fixture-02'").replace("stage/'group-target'","stage/'group-target-02'").replace('-01','-03').replace('GROUP_INPUTS_01','GROUP_INPUTS_03')
(stage/'build-fixture-03.py').write_text(driver)
old_harness=stage/'harness01'; harness=stage/'harness02'; harness.mkdir()
for name in ('worker.js','controller.js','server.py','storage-fault.js','run.py'): sdk.copy(old_harness/name,harness/name)
path=harness/'run.py'; source=path.read_text().replace('continuity-browser-retirement/harness01','continuity-browser-retirement/harness02').replace('group-target/debug','group-target-02/debug');path.write_text(source)
for path in harness.glob('*.py'): ast.parse(path.read_text(),filename=str(path))
print('Original failed run01 remains sealed; fresh fixture02 preserves both other account members')
