from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-retirement';old=stage/'harness04';new=stage/'harness06';new.mkdir()
for name in ('run.py','server.py','worker.js','controller.js','storage-fault.js'): sdk.copy(old/name,new/name)
p=new/'run.py';source=p.read_text().replace('continuity-browser-retirement/harness04','continuity-browser-retirement/harness06')
source=source.replace("'expired-unapplied','expired-applied','signer-commit-loss','signer-missing','signer-swapped'","'expired-unapplied','expired-applied'")
marker='                    while time.time()<=until: time.sleep(min(5,max(0.05,until-time.time()+0.1)))'
sdk.require(source.count(marker)==1,'signed second boundary marker')
source=source.replace(marker,'                    while int(time.time())<=until: time.sleep(min(5,max(0.05,until+1-time.time()+0.1)))')
ast.parse(source,filename=str(p));p.write_text(source)
print('Fresh harness06 waits beyond the entire signed second; no old cohort resumed')
