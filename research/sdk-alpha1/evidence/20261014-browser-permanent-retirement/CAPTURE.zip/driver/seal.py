from pathlib import Path
import hashlib
import json
import re
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-retirement'
destination = root / 'research/sdk-alpha1/evidence/20261014-browser-permanent-retirement'
overlay = json.loads((stage / 'SOURCE_OVERLAY.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, digest in overlay['overlay'].items():
    sdk.require(sha(root / name) == sha(Path(overlay['source']) / name) == digest, 'source drift: ' + name)
selected = []
for number in (4, 6, 7):
    parent = stage / f'harness{number:02}'
    run = parent / f'run{number:02}'
    data = json.loads((run / 'RESULT.json').read_text())
    if number == 4:
        partial = json.loads((stage / 'PARTIAL_ACCEPTANCE_04.json').read_text())
        sdk.require(not data['completed'] and sha(run / 'RESULT.json') == partial['source_result_sha256'], 'partial result changed')
        cases = data['cases'][:3]
    else:
        sdk.require(data['completed'] and data['producer_unchanged'], 'runtime incomplete')
        cases = data['cases']
    for name, digest in data['producer'].items():
        sdk.require(sha(Path(name)) == digest, 'producer drift: ' + name)
    for name, digest in data['static_web'].items():
        sdk.require(sha(parent / f'run{number:02}-web' / name) == digest, 'static input drift: ' + name)
    for case in cases:
        sdk.require(case['completed'], 'case incomplete')
        selected.append({'run': number, 'case': case['case'], 'cleanup_complete': case['cleanup_complete'],
                         'calls': len(case['calls']), 'views': case['view_roles']})
sdk.require(len(selected) == 7 and sum(c['cleanup_complete'] for c in selected) == 5, 'scenario coverage')
for prefix in ('regression-retired', 'regression-renewal_boundary', 'controls-01', 'owners02-native-02', 'owners02-wasm-02', 'msrv-check', 'package-build-01'):
    sdk.require(json.loads((stage / (prefix + '.json')).read_text())['returncode'] == 0, 'check incomplete: ' + prefix)
sdk.require(re.search(r'Ran 60 tests in [0-9.]+s\s+OK', (stage / 'controls-01.stderr').read_text()), 'controls missing')
package = Path(overlay['source']) / 'target/browser-retirement-package-01'
receipt = json.loads((package / 'INSTALLED_CONSUMER.json').read_text())
sdk.require(sha(package / 'q-periapt-sdk-wasm-0.2.0.tgz') == receipt['sha256'], 'package drift')
files = {}
def add(path, name):
    sdk.require(path.is_file() and not path.is_symlink() and name not in files, 'invalid capture member: ' + name)
    files[name] = path
for name in overlay['overlay']:
    add(root / name, 'source-overlay/' + name)
for p in stage.iterdir():
    if p.is_file() and p.suffix in ('.json', '.stdout', '.stderr', '.py', '.sh', '.rs') and p.name != 'HANDOFF_CURRENT.json':
        add(p, 'driver/' + p.name)
for number in range(1, 8):
    parent = stage / f'harness{number:02}'
    run = parent / f'run{number:02}'
    for p in parent.iterdir():
        if p.is_file(): add(p, f'harness{number:02}/' + p.name)
    for p in run.rglob('*'):
        relative = p.relative_to(run)
        if p.is_file() and not any(part.startswith('.') for part in relative.parts):
            add(p, f'run{number:02}/' + relative.as_posix())
    for p in (parent / f'run{number:02}-web/inputs').glob('*.json'):
        add(p, f'public-inputs{number:02}/' + p.name)
for folder in ('group-fixture', 'group-fixture-02'):
    for p in (stage / folder).rglob('*'):
        relative = p.relative_to(stage / folder)
        if p.is_file() and 'target' not in relative.parts and not any(part.startswith('.') for part in relative.parts):
            add(p, folder + '/' + relative.as_posix())
for p in package.iterdir():
    if p.is_file(): add(p, 'package/' + p.name)
add(package / 'package/PACKAGE_CONTENTS.json', 'package/PACKAGE_CONTENTS.json')
add(destination / 'README.md', 'README.md')
archive = destination / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()): z.write(path, name)
with zipfile.ZipFile(archive) as z:
    sdk.require(z.testzip() is None and len(z.namelist()) == len(files), 'capture invalid')
    for name, path in files.items(): sdk.require(hashlib.sha256(z.read(name)).hexdigest() == sha(path), 'capture changed')
checks = {'completed': True, 'release_claim_eligible': False, 'base_commit': overlay['base_commit'],
    'archive': {'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': len(files)},
    'cases': selected, 'browser_calls': sum(c['calls'] for c in selected),
    'package': {k: receipt[k] for k in ('sha256', 'manifest_sha256', 'installed_node_tests', 'typescript', 'browser_runtime')},
    'source_overlay': overlay['overlay'], 'private_state_included': False,
    'validation': {'native_retired_tests': 36, 'native_expiry_boundary_tests': 2, 'artifact_controls': 60,
                   'strict_native_and_wasm_clippy': True, 'wasm_rust_1_90': True},
    'documentation': {'docs/continuity/PRODUCT_ADMISSION.md': sha(root / 'docs/continuity/PRODUCT_ADMISSION.md')},
    'limits': ['same shared engine on one host; loopback transport', 'logical erasure, not physical deletion or backup erasure',
               'in-place renewal across unapplied expired intent remains open', 'managed account-root cutover and witness-key handoff remain open',
               'nonempty inbox/prekey/terminal metadata, wider lifecycle/platform and release qualification remain open']}
sdk.write_json(destination / 'CHECKS.json', checks)
print(json.dumps({'archive': checks['archive'], 'cases': selected, 'browser_calls': checks['browser_calls']}))
