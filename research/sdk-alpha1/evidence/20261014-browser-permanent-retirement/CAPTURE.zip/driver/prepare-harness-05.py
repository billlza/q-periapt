from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-retirement';old=stage/'harness04';new=stage/'harness05';new.mkdir()
for name in ('run.py','server.py','worker.js','controller.js','storage-fault.js'): sdk.copy(old/name,new/name)
sdk.copy(stage/'retirement-cuts.js',new/'retirement-cuts.js')
p=new/'worker.js';source=p.read_text();source="import { interruptJournalFlush, cancelSignerCommit } from './retirement-cuts.js';\n"+source
marker="else if (data.action === 'retirement-erase-journal') {await owner.erase_retired_journal(bytes(data.ackReceipt));value={erased:true};}"
sdk.require(source.count(marker)==1,'journal action marker')
source=source.replace(marker,"else if (data.action === 'retirement-erase-journal') {if(data.killAfterJournalFlush)interruptJournalFlush();await owner.erase_retired_journal(bytes(data.ackReceipt));value={erased:true};}")
marker="        else if (data.action === 'retirement-erase-signer') {"
sdk.require(source.count(marker)==1,'signer action marker')
source=source.replace(marker,"        else if (data.action === 'retirement-cancel-signer') {\n          value=await cancelSignerCommit(owner,()=>sdk.QPeriaptContinuityDevice.open_retired(data.name,storage,intent,proof),data.name);\n        }\n"+marker)
p.write_text(source)
p=new/'controller.js';source=p.read_text();marker='      if (data.signerCommitObserved) {'
sdk.require(source.count(marker)==1,'controller marker')
source=source.replace(marker,"      if (data.journalBoundaryObserved) {\n        if(!args.killAfterJournalFlush || data.boundary!=='retired-bytes-flushed')throw Error('unexpected journal cut');\n        finish(undefined,{done:true,workerTerminatedAfterJournalFlush:true,marker:data});return;\n      } else if (data.signerCommitObserved) {");p.write_text(source)
p=new/'run.py';source=p.read_text().replace('continuity-browser-retirement/harness04','continuity-browser-retirement/harness05')
source=source.replace("'expired-unapplied','expired-applied','signer-commit-loss','signer-missing','signer-swapped'","'journal-interruption','signer-cancellation'")
source=source.replace("('storage-fault.js','storage-fault.js')","('storage-fault.js','storage-fault.js'), ('retirement-cuts.js','retirement-cuts.js')")
source=source.replace("stage / 'storage-fault.js']","stage / 'storage-fault.js', stage / 'retirement-cuts.js']")
marker="                retired('erase-journal'); sdk.require(retired('journal-state')['state']==1,'journal erasure not authenticated')"
sdk.require(source.count(marker)==1,'journal transition marker')
source=source.replace(marker,"""                if case=='journal-interruption':
                    result=invoke(dict(args,action='retirement-erase-journal',killAfterJournalFlush=True))
                    sdk.require(result.get('workerTerminatedAfterJournalFlush') is True,'real journal flush interruption missing')
                    row['unknown_journal_return']=result
                    observed=retired('journal-state')['state'];sdk.require(observed in (0,1),'journal neither original nor authenticated terminal')
                    row['journal_recovery_state']=observed
                retired('erase-journal'); sdk.require(retired('journal-state')['state']==1,'journal erasure not authenticated')""")
marker="                    if case=='signer-commit-loss':"
sdk.require(source.count(marker)==1,'signer branch marker')
source=source.replace(marker,"""                    if case=='signer-cancellation':
                        result=retired('cancel-signer');row['cancelled_signer_commit']=result
                        sdk.require(result['before']['closed'] is True and result['before']['closeSettled'] is False and result['before']['held']==1,'close released the root before receipt settlement')
                        sdk.require(result['before']['contender'].get('success') is False and result['before']['contender'].get('code')=='Busy','concurrent original opener obtained a lease')
                        sdk.require(result['erasure']['success'] is False and result['erasure'].get('ownerClosed') is True and result['erasure'].get('code') in ('CommitUnknown','Closed'),'cancelled operation claimed success or lost closed state')
                        sdk.require(result['close']['success'] is True and result['recovered']==1,'original committed signer retirement not recovered after close')
                    elif case=='signer-commit-loss':""")
p.write_text(source)
for path in new.iterdir():
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    elif path.suffix=='.js':sdk.command(['/opt/homebrew/bin/node','--check',str(path)],new/('syntax-'+path.stem),root)
print('Fresh harness05 covers an actual journal write/flush interruption and cancellation while signer completion receipt is held')
