from pathlib import Path
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
prior=root/'target/continuity-browser-recovery/group-fixture-02'; work=stage/'group-fixture'
work.mkdir(); (work/'src/bin/retirement').mkdir(parents=True)
for name in ('Cargo.toml','Cargo.lock'): sdk.copy(prior/name,work/name)
for source in (prior/'src/bin').glob('*.rs'): sdk.copy(source,work/'src/bin'/source.name)
p=work/'src/bin/qpc-fanout-witness.rs'; source=p.read_text()
source=source.replace('fn main() -> Result<()> {','#[path = "retirement/control.rs"]\nmod retirement;\nfn main() -> Result<()> {',1)
marker='        _ => return Err("unknown witness mode".into()),'
sdk.require(source.count(marker)==1,'command marker')
source=source.replace(marker,'        "retire-device" | "retain-inventory" | "retain-report" | "ack-report" => retirement::run(mode, dir, &cfg, &args, now)?,\n'+marker)
p.write_text(source)
print('Fresh fixture source prepared; no original runtime cohort opened')
