from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-retirement'
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
env['CC_wasm32_unknown_unknown']='/opt/homebrew/opt/llvm/bin/clang'
toolchain=Path(env['RUSTC']).parent
mode=sys.argv[1]
if mode=='prepare':
    files=subprocess.run(['git','diff','--name-only'],check=True,capture_output=True,text=True).stdout.splitlines()
    sdk.require(len(files)==5 and all(name.endswith('.rs') for name in files),'unexpected source scope')
    sdk.command([str(toolchain/'rustfmt'),'--edition','2021','--config','skip_children=true',*files],stage/'format-storage-02',root,environment=env)
    sdk.write_json(stage/'STORAGE_INPUTS_02.json',{name:sdk.snapshot(root/name).sha256 for name in files})
else:
    sdk.require(mode in ('native','wasm'),'mode')
    inputs=json.loads((stage/'STORAGE_INPUTS_02.json').read_text())
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'input drift')
    args=[str(toolchain/'cargo'),'clippy','--locked','--offline']
    if mode=='native': args+=['--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets']
    else: args+=['-p','q-periapt-sdk-wasm','--features','browser-continuity','--lib','--target','wasm32-unknown-unknown']
    args+=['--target-dir',str(root/('target/continuity-browser-fanout/'+mode+'-target')),'-j','2','--','-D','warnings']
    sdk.command(args,stage/('storage-'+mode+'-02'),root,environment=env)
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'input drift')
    print(mode+' storage retirement strict Clippy passed')
