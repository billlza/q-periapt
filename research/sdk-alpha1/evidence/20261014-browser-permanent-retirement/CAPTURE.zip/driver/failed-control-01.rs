//! Isolated independently approved replacement and permanent-retention controller.
use super::*;
use std::os::unix::fs::DirBuilderExt;

fn raw(path: &str) -> Result<Vec<u8>> {
    let mut wire = Vec::new();
    fs::File::open(path)?.take(65537).read_to_end(&mut wire)?;
    if wire.len() > 65536 {
        return Err("bounded control input".into());
    }
    Ok(wire)
}
fn original_policy(cfg: &Value) -> Result<p::HistoricalSessionPolicy> {
    let value = &cfg["policies"]["required"];
    Ok(p::PolicyPin::new(
        array(cfg, "family")?,
        p::PublicKey::decode(&bytes(cfg, "policy_root")?)?,
        p::PolicyCheckpoint::from_trusted_state(
            number(value, "version")?,
            array(value, "digest")?,
        )?,
    )?
    .verify_historical(&bytes(value, "wire")?)?)
}
fn replace(dir: &Path, cfg: &Value, args: &[String], now: u64) -> Result<()> {
    if args.len() != 6 {
        return Err("retire-device directory grant genesis output".into());
    }
    let grant = load(Path::new(&args[3]))?;
    let original_genesis = load(Path::new(&args[4]))?;
    let original_policy = original_policy(cfg)?;
    let original = p::AccountPin::new(
        array(cfg, "account")?,
        p::PublicKey::decode(&bytes(cfg, "root")?)?,
        p::RosterCheckpoint::from_trusted_state(
            number(&grant, "version")?,
            array(&grant, "digest")?,
        )?,
        array(cfg, "family")?,
    )?
    .verify_historical_device(&bytes(&grant, "certificate")?, &bytes(&grant, "roster")?)?;
    let subject = p::AnchorSubject::for_device(
        p::JournalIdentity::from_trusted_state(array(&original_genesis, "journal")?)?,
        &original,
        &original_policy,
    )?;
    if subject.to_bytes() != bytes(&original_genesis, "subject")? {
        return Err("original subject mismatch".into());
    }
    let wrapping = p::JournalKey::open(&dir.join("private-wrap.key"))?;
    let root_id = p::SigningKeyId::from_trusted_state(
        fs::read(dir.join("root-id.bin"))?.as_slice().try_into()?,
    )?;
    let root = p::RootSigningKey::open(&dir.join("private-root.key"), &wrapping, root_id)?;
    let policy_id = p::SigningKeyId::from_trusted_state(
        fs::read(dir.join("policy-id.bin"))?.as_slice().try_into()?,
    )?;
    let authority =
        p::PolicySigningKey::open(&dir.join("private-policy.key"), &wrapping, policy_id)?;
    if root.public_key()?.encode() != bytes(cfg, "root")?
        || authority.public_key()?.encode() != bytes(cfg, "policy_root")?
    {
        return Err("independent issuer mismatch".into());
    }
    let runtime = Arc::new(q_periapt_sdk::Runtime::from_signed_policy(
        &bytes(cfg, "sdk_policy")?,
        &bytes(cfg, "sdk_signature")?,
        &bytes(cfg, "sdk_root")?,
        None,
        q_periapt_sdk::Limits::default(),
    )?);
    let mut witness = store(dir, cfg)?;
    let pin = witness.pin()?;
    let validity = p::Validity::new(number(cfg, "from")?, now + 3600)?;
    let issued = authority.issue_session_policy(
        &runtime,
        p::SessionPolicyParameters::new(
            3,
            validity,
            p::AllowedPrekeyModes::new(&[p::PrekeyQuality::OneTimeBoth])?,
            p::AnchorRequirement::required(&pin),
            p::ApplicationSendBudget::new(8)?,
        )?,
    )?;
    let policy = p::PolicyPin::new(
        array(cfg, "family")?,
        authority.public_key()?,
        issued.checkpoint(),
    )?
    .verify(issued.as_bytes(), runtime, now)?;
    let target = dir.join("replacement");
    fs::DirBuilder::new().mode(0o700).create(&target)?;
    let key = p::JournalKey::provision(&target.join("wrap.key"))?;
    let identity = p::SigningKeyId::generate()?;
    publish_private_bytes(&target.join("signer-id.bin"), identity.as_bytes())?;
    let signer = p::DeviceSigningKey::provision(&target.join("signer.key"), &key, identity)?;
    let mut description = original.description.clone();
    description.generation += 1;
    description.validity = validity;
    let certificate = root.issue_device(description, signer.public_key()?)?;
    let roster = root.issue_roster(2, validity, &[root.roster_entry(&certificate)?])?;
    let device = p::AccountPin::new(
        root.account_id()?,
        root.public_key()?,
        roster.checkpoint(),
        array(cfg, "family")?,
    )?
    .verify_device(&certificate, roster.as_bytes(), now)?;
    let mut journal = p::DeviceJournal::provision_anchored(
        &target.join("journal.redb"),
        key,
        &device,
        &policy,
        p::JournalIdentity::generate()?,
        now,
    )?;
    let genesis = journal.anchor_genesis(&device, &policy)?;
    journal.close();
    let predecessors = [(subject, original.roster().checkpoint(), &original_policy)];
    let proposal =
        witness.device_replacement_proposal(&genesis, &device, &policy, &predecessors, now)?;
    // Retain exact independent approval before the irreversible witness transition.
    publish_private_bytes(&target.join("approved-proposal.bin"), &proposal.to_bytes()?)?;
    publish_private_bytes(
        &target.join("PUBLIC.json"),
        &serde_json::to_vec_pretty(&json!({
        "certificate":certificate,"roster":roster.as_bytes(),"policy":issued.as_bytes(),
        "policy_version":issued.checkpoint().version(),"policy_digest":issued.checkpoint().digest(),
        "subject":genesis.subject().to_bytes(),"genesis":genesis.image_digest(),"approved":proposal.to_bytes()?}))?,
    )?;
    witness.replace_device(&proposal, &genesis, &device, &policy, &predecessors, now)?;
    let receipt = witness.retired_subject_receipt(&proposal, subject)?;
    let retired = pin.verify_retired_subject(&proposal, subject, &receipt)?;
    let head = retired.observed_head();
    publish_private_bytes(
        Path::new(&args[5]),
        &serde_json::to_vec_pretty(&json!({
        "approved":proposal.to_bytes()?,"subject":subject.to_bytes(),"receipt":receipt,
        "observed_head":{"fence":head.fence().to_string(),"revision":head.revision().to_string(),"digest":head.digest()},
        "retired":true,"at":now,"original_until":number(cfg,"until")?,"original_policy_until":number(cfg,"policy_until")?}))?,
    )?;
    witness.close();
    Ok(())
}
pub(super) fn run(mode: &str, dir: &Path, cfg: &Value, args: &[String], now: u64) -> Result<()> {
    if mode == "retire-device" {
        return replace(dir, cfg, args, now);
    }
    if args.len() != 5 {
        return Err("retention command directory request receipt".into());
    }
    let input = raw(&args[3])?;
    let mut witness = store(dir, cfg)?;
    let receipt = match mode {
        "retain-inventory" => {
            let request = p::AnchorRetiredCleanupProposal::from_trusted_state(&input)?;
            witness.retain_retired_cleanup(&request)?;
            witness.retired_cleanup_receipt(&request)?
        }
        "retain-report" => {
            let request = p::AnchorRetiredReportProposal::from_trusted_state(&input)?;
            witness.retain_retired_report(&request)?;
            witness.retired_report_receipt(&request)?
        }
        "ack-report" => {
            let request = p::AnchorRetiredReportProposal::from_trusted_state(&input)?;
            witness.acknowledge_retired_report(&request)?;
            witness.retired_report_acknowledgement_receipt(&request)?
        }
        _ => return Err("control mode".into()),
    };
    witness.close();
    publish_private_bytes(Path::new(&args[4]), &receipt)?;
    Ok(())
}
