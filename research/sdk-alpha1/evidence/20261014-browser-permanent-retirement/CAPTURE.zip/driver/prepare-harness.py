from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd(); stage=root/'target/continuity-browser-retirement'; prior=root/'target/continuity-browser-recovery'
harness=stage/'harness01'; harness.mkdir()
source=(prior/'worker-live.js').read_text()
source="import { tweakSigner } from './storage-fault.js';\n"+source
marker="    } else if (data.action.startsWith('cleanup-')) {"
sdk.require(source.count(marker)==1,'worker insertion marker')
source=source.replace(marker,(stage/'retirement-worker-branch.js').read_text()+marker)
(harness/'worker.js').write_text(source); sdk.copy(stage/'storage-fault.js',harness/'storage-fault.js')
controller=(prior/'controller.js').read_text(); marker='      if (data.ready) {'
sdk.require(controller.count(marker)==1,'controller marker')
controller=controller.replace(marker,"      if (data.signerCommitObserved) {\n        if (!args.killAfterSignerCommit || data.revision!==2) throw Error('unexpected signer commit cut');\n        finish(undefined,{done:true,workerTerminatedAfterSignerCommit:true,marker:data}); return;\n      } else if (data.ready) {")
(harness/'controller.js').write_text(controller)
server=(prior/'server_advance.py').read_text().replace("('normal', 'drop-advance', 'hold-advance')","('normal', 'drop-advance', 'hold-advance', 'drop-before-advance')")
marker="                with prefix.with_suffix('.stdout').open('xb') as out, prefix.with_suffix('.stderr').open('xb') as err:"
sdk.require(server.count(marker)==1,'witness dispatch marker')
cut="""                key = (case, cut, mode)
                if mode == 'drop-before-advance' and key not in faulted and data[204] == 2:
                    faulted.add(key)
                    record = dict(number=number, mode=mode, cut=cut, trigger=True, dispatched=False,
                        request_tag=2, reply_tag=None, advance_applied_reply=False,
                        request_sha256=hashlib.sha256(data).hexdigest(), reply_sha256=None)
                    records.setdefault(case, []).append(record)
                    (folder / 'RECORDS.json').write_text(json.dumps(records[case], indent=2) + '\\n')
                    self.close_connection = True; return
"""
server=server.replace(marker,cut+marker).replace('record.update(number=number, mode=mode, cut=cut, trigger=trigger,','record.update(number=number, mode=mode, cut=cut, trigger=trigger, dispatched=True,')
(harness/'server.py').write_text(server)
base=(prior/'run-live-02.py').read_text()
start=base.index("                before = len([r for r in peers.get(key,[]) if r['kind']==3])")
end=base.index("            state['witness_records'] = records; state['peer_records'] = peers",start)
driver=base[:start]+(stage/'run-body.py').read_text()+base[end:]
driver=driver.replace("import uuid\n","import uuid\nimport time\n")
driver=driver.replace('from server_advance import serving','from server import serving')
driver=driver.replace("stage = root / 'target/continuity-browser-recovery'","stage = root / 'target/continuity-browser-retirement/harness01'")
driver=driver.replace("allowed = {'required-live', 'reserved-live'}","allowed = {'expired-unapplied','expired-applied','signer-commit-loss','signer-missing','signer-swapped'}")
driver=driver.replace('browser-recovery-package-02','browser-retirement-package-01').replace('worker-live.js','worker.js').replace('server_advance.py','server.py').replace("stage / ('group-target-02/debug/","stage.parent / ('group-target/debug/")
driver=driver.replace("browser_session = 'qpc-recovery-'","browser_session = 'qpc-retirement-'")
driver=driver.replace("('worker.js','worker.js'), ('controller.js','controller.js')","('worker.js','worker.js'), ('controller.js','controller.js'), ('storage-fault.js','storage-fault.js')")
driver=driver.replace("stage / 'server.py']","stage / 'server.py', stage / 'storage-fault.js']")
driver=driver.replace("native('seed', ['prepare',directory], case + '-seed')","native('seed', ['prepare-expiring-all' if case.startswith('expired-') else 'prepare',directory], case + '-seed')")
driver=driver.replace('Installed browser complete account/session cleanup with closed local runtime and still-current required witness authority; two original native recipients, same engine on one macOS host','Installed browser original permanent retirement and complete host accounting; native independent control plane, original two-recipient account and same shared engine on one host')
(harness/'run.py').write_text(driver)
for path in harness.iterdir():
    if path.suffix=='.py': ast.parse(path.read_text(),filename=str(path))
    elif path.suffix=='.js': sdk.command(['/opt/homebrew/bin/node','--check',str(path)],harness/('syntax-'+path.stem),root)
print('Fresh retirement harness01 syntax checked; no browser state created yet')
