"""Resolve one recorded source goal and retain every pending frontier."""
from pathlib import Path
import fcntl
import hashlib
import json
import re
import sys
import time

stage = Path(__file__).resolve().parent
folder = stage / 'initial-send-oracle-frames'
expected = '!Entropy( s.1, %epoch, kind, t )[no_precomp] ▶₀ #vr'
try:
    if sys.argv[1:] != ['epoch_generation_secret_derivation_origin']:
        raise ValueError('unexpected lemma')
    raw = sys.stdin.read(4 * 1024 * 1024 + 1)
    payload = raw.encode()
    if not raw or len(payload) > 4 * 1024 * 1024:
        raise ValueError('frontier input bound')
    matches = [re.fullmatch(r'([0-9]+):\s*(.+)', line) for line in raw.splitlines()]
    if not all(matches):
        raise ValueError('unexpected goal encoding')
    goals = {int(match[1]): match[2] for match in matches}
    if len(goals) != len(matches):
        raise ValueError('duplicate goal number')
    with (stage / 'initial-send-oracle.lock').open('a') as lock:
        deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('frontier capture lock exceeded five seconds')
                time.sleep(0.01)
        records = [json.loads(path.read_text()) for path in folder.glob('*.json')]
        if len(records) >= 32 or sum(row['input_bytes'] for row in records) + len(payload) > 16 * 1024 * 1024:
            raise ValueError('frontier capture budget exceeded')
        previous_choices = sum(bool(row['ranking']) for row in records)
        if previous_choices > 1:
            raise ValueError('more than one source goal was selected')
        ranking = [number for number, goal in goals.items() if goal == expected] if previous_choices == 0 else []
        if len(ranking) > 1:
            raise ValueError('ambiguous entropy source goal')
        stem = f'{len(records):04}'
        with (folder / (stem + '.txt')).open('xb') as stream:
            stream.write(payload)
        with (folder / (stem + '.json')).open('x') as stream:
            json.dump({'input_sha256': hashlib.sha256(payload).hexdigest(), 'input_bytes': len(payload),
                'goal_numbers': list(goals), 'ranking': ranking, 'diagnostic_stop': not ranking,
                'stop_reason': None if ranking else 'frontier-capture-no-further-choice',
                'selected_goal': expected if ranking else None, 'captured_input': stem + '.txt'}, stream, indent=2)
            stream.write('\n')
        (stage / 'initial-send-oracle.diagnostic-stop').write_text('bounded-source-resolution-probe\n')
    if ranking:
        print(ranking[0])
except Exception as error:
    (stage / 'initial-send-oracle.failed').write_text(type(error).__name__ + ': ' + str(error) + '\n')
    raise
