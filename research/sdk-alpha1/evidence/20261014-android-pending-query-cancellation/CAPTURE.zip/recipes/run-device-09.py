from pathlib import Path
import hashlib
import json
import shlex
import sys
import rust_sdk_profile as sdk
import continuity_android_contract as contract
import continuity_android_pending as pending

root=Path.cwd();stage=root/'target/continuity-android-pending-query';device=stage/'physical-08'
cfg=json.loads((stage/'BUILD_06.json').read_text())
prepared=json.loads((device/'PREPARED_APK_09.json').read_text());sdk.require(prepared['completed'],'APK incomplete')
out=device/'run-09';out.mkdir();cases=out/'cases';driver=out/'driver'
driver.write_text('#!/bin/sh\nset -eu\nexport QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14\nexec /bin/sh '+
    shlex.quote(str(root/'artifact/python-run.sh'))+' '+shlex.quote(str(stage/'device-driver-09.py'))+' "$@"\n')
driver.chmod(0o700)
label='tls-recoverable-applied';case_label=label+'-query-cancel'
files={name:Path(cfg[name]) for name in ['harness','receiver','library']}
files.update(driver=driver,controller=stage/'device-driver-09.py',apk=Path(prepared['apk']))
digests={name:sdk.snapshot(path,maximum=256*1024**2).sha256 for name,path in files.items()}
for name in ['harness','receiver','library']:sdk.require(digests[name]==cfg[name+'_sha256'],'installed binary changed')
sdk.require(digests['apk']==prepared['apk_sha256'],'APK changed')
env=dict(cfg['environment'],QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(driver),QPC_CONFIGURATION_RECEIVER=cfg['receiver'])
record={'completed':False,'cleanup':False,'source_commit':prepared['source_commit'],'engine_source_commit':cfg['installed_base']['source_commit'],
 'candidate_sha256':cfg['candidate_sha256'],'aar_sha256':prepared['aar_sha256'],'apk_sha256':prepared['apk_sha256'],
 'input_sha256':digests,'release_claim_eligible':False,'scope':'One accepted API37 arm64 phone; TLS/recoverable/applied pending recovery with pre-call and held Query cancellation, actual R8 APK/AAR, independent controller, same protocol implementation'}
state_path=device/'device-09/STATE.json'
try:
    contract.verify_catalog(sdk.command([cfg['harness'],'--list'],out/'catalog',Path(cfg['consumer']),environment=env))
    stdout=sdk.command([cfg['harness'],'--exact',pending.QUERY_TESTS[label],'--nocapture'],out/'execution',Path(cfg['consumer']),environment=env)
    result=pending.verify_execution(stdout,cases,label,query_cancel=True)
    state=json.loads(state_path.read_text())
    sdk.require(state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports'),'ART completion or cleanup missing')
    sdk.require(len(state['cases'])==len(pending.cases(True,query_cancel=True)) and len({row['pid'] for row in state['cases']})==len(pending.cases(True,query_cancel=True)),'ART process census')
    for row in state['cases']:
        sdk.require(sdk.snapshot(cases/case_label/row['label']).sha256==row['result_sha256']
            and row['installed_apk_sha256']==prepared['apk_sha256'] and row['process_absent_after_stop'],'ART result provenance')
    for name in pending.public(True,query_cancel=True):sdk.copy(cases/case_label/name,out/'public'/case_label/name)
    sdk.require(pending.verify_execution(stdout,out/'public',label,query_cancel=True)==result,'public readback differs')
    for name,path in files.items():sdk.require(sdk.snapshot(path,maximum=256*1024**2).sha256==digests[name],'producer changed')
    record.update(completed=True,cleanup=True,result=result,physical_processes=len(state['cases']))
except BaseException as error:
    record['failure']=repr(error);raise
finally:
    if state_path.exists():
        state=json.loads(state_path.read_text())
        if state.get('installation_attempted') and not state.get('cleanup'):
            try:
                sdk.require(state.get('apk_sha256')==prepared['apk_sha256'],'cleanup ownership')
                adb=['/Users/bill/Library/Android/sdk/platform-tools/adb','-P','15037','-s','<SELECTED_ANDROID_DEVICE>']
                for port in list(state.get('owned_reverse_ports',[])):
                    sdk.command(adb+['reverse','--remove','tcp:'+str(port)],out/('cleanup-reverse-'+str(port)),root)
                    state['owned_reverse_ports'].remove(port);sdk.write_json(state_path,state)
                package='dev.qperiapt.continuity.pendingquery20261014'
                present=sdk.command(adb+['shell','pm','list','packages','--user','0',package],out/'cleanup-present',root)
                if present.strip():
                    sdk.require(present.strip()==('package:'+package).encode(),'cleanup package differs')
                    sdk.command(adb+['shell','am','force-stop',package],out/'cleanup-stop',root)
                    sdk.require(sdk.command(adb+['uninstall',package],out/'cleanup-uninstall',root).strip()==b'Success','cleanup uninstall')
                sdk.require(not sdk.command(adb+['shell','pm','list','packages','--user','0',package],out/'cleanup-absent',root).strip(),'residual package')
                state['cleanup']=True;record['cleanup']=True;sdk.write_json(state_path,state)
            except BaseException as error:record['cleanup_failure']=repr(error)
    sdk.write_json(out/'RESULT.json',record)
print('Actual API37 phone completed all 21 original pending recovery calls and owned-resource cleanup')
