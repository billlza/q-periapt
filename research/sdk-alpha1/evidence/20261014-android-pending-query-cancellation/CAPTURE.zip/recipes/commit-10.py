from pathlib import Path
import ast
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;clone=root/'target/continuity-browser-publication/source'
cfg=json.loads((stage/'BUILD_06.json').read_text());sdk.require(cfg['built'],'matrix not built')
for label in ['readers-06','harness-06','catalog-06','clippy-06']:
    sdk.require(json.loads((stage/(label+'.json')).read_text())['returncode']==0,'incomplete check')
for name,digest in cfg['source_files'].items():sdk.require(sdk.snapshot(root/name).sha256==digest,'matrix source changed')
paths=sorted(set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines()) |
 set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()))
sdk.require(all(name=='ARTIFACT.md' or name.startswith(('artifact/','bindings/c/ContinuityPackageConsumer/','bindings/android/ContinuityPackageConsumer/')) for name in paths),'unrelated source change')
for name in paths:
    if name.endswith('.py'):ast.parse((root/name).read_text(),filename=name)
sdk.write_json(stage/'SOURCE_10.json',{name:sdk.snapshot(root/name).sha256 for name in paths})
sdk.command(['git','diff','--check'],stage/'diff-10',root)
sdk.command(['git','add','--',*paths],stage/'stage-10',root)
sdk.command(['git','commit','-m','Qualify cancellation of in-flight pending recovery queries'],stage/'commit-10',root)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'main source dirty')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'clone source dirty')
sdk.command(['git','fetch',str(root),head],stage/'clone-fetch-10',clone)
sdk.command(['git','checkout','--detach',head],stage/'clone-checkout-10',clone)
python=[sys.executable,'-B',str(clone/'artifact/python_bootstrap.py')]
sdk.command([*python,str(clone/'artifact/source_results_assembler.py'),'ci-source-gate',
 '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],stage/'source-gate-10',clone)
sdk.command([*python,'-m','unittest','artifact.test_codeql_rust_quality','artifact.test_continuity_package',
 'artifact.test_continuity_android_pending','artifact.test_continuity_android_jni','artifact.test_continuity_android_joint_cycle'],stage/'clone-controls-10',clone)
sdk.write_json(stage/'SOURCE_COMMIT_10.json',{'source_commit':head,'pushed':False,'clean_clone_gate':True,'source_paths':paths})
print('Matrix source committed and exact source/inventory controls passed: '+head)
