from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent;device=stage/'physical-08'
host=json.loads((stage/'RUN_RESULT_07.json').read_text());physical=json.loads((device/'run-09/RESULT.json').read_text())
state=json.loads((device/'device-09/STATE.json').read_text())
sdk.require(host['completed'] and physical['completed'] and physical['cleanup'] and state['completed'] and state['cleanup']
 and not state.get('owned_reverse_ports'),'host or phone not terminal')
sdk.require(host['foreign_processes']==43 and physical['physical_processes']==21,'execution census')
source=json.loads((stage/'SOURCE_COMMIT_10.json').read_text())
sdk.require(source['source_commit']==host['source_commit']==physical['source_commit'],'qualification source differs')
out=root/'research/sdk-alpha1/evidence/20261014-android-pending-query-cancellation';out.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'capture duplicate');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(base,prefix,label):
    for suffix in ['json','stdout','stderr']:add(base/(prefix+'.'+suffix),label+'.'+suffix)
for name in ['readers-06','harness-06','catalog-06','clippy-06','java-06','source-gate-10','clone-controls-10','host-run-07',
             'socket-compile-08','socket-run-08']:
    logs(stage,name,'host/'+name)
for name in ['BUILD_06.json','RUN_RESULT_07.json','SOURCE_10.json','SOURCE_COMMIT_10.json']:
    add(stage/name,'host/'+name)
for label in pending.QUERY_TESTS:
    case_label=label+'-query-cancel'
    for name in pending.public(label.endswith('-applied'),query_cancel=True):add(stage/'public-07'/case_label/name,'host/public/'+case_label+'/'+name)
for name in ['harness-03','baseline-run-05']:logs(stage,name,'failed/'+name)
for name in ['BASELINE_RESULT_05.json','BUILD_04.json','failed-control-03.rs']:add(stage/name,'failed/'+name)
baseline=json.loads((stage/'BUILD_04.json').read_text())
for relative in ['src/test/java/PendingWriteCancellation.java','src/test/java/PendingWriteProbe.java']:
    add(Path(baseline['android_source'])/relative,'failed/source/'+relative)
add(Path(baseline['consumer'])/'tests/common/android_pending_write/cancellation.rs','failed/source/cancellation.rs')
for label in pending.QUERY_TESTS:
    for suffix in ['stdout','stderr']:
        add(stage/'baseline-cases-05'/(label+'-query-cancel')/('query-cancelled.'+suffix),'failed/'+label+'/query-cancelled.'+suffix)
for name in source['source_paths']:add(root/name,'source/'+name)
for name in ['PACKAGE.json','PREPARED_APK_09.json']:add(device/name,'android/'+name)
for name in ['build','keytool','sign','signature']:logs(device/'agp-09',name,'android/'+name)
add(device/'agp-09/STATE.json','android/STATE.json')
logs(device/'run-09','catalog','device/catalog');logs(device/'run-09','execution','device/execution')
add(device/'run-09/RESULT.json','device/RESULT.json')
for path in sorted((device/'device-09').iterdir()):
    sdk.require(path.is_file() and path.suffix in ['.json','.stdout','.stderr'],'device receipt type')
    add(path,'device/commands/'+path.name)
label='tls-recoverable-applied';case_label=label+'-query-cancel'
for name in pending.public(True,query_cancel=True):add(device/'run-09/public'/case_label/name,'device/public/'+case_label+'/'+name)
for name in ['prepare-06.py','build-06.py','run-installed-07.py','commit-10.py','prepare-physical-08.py',
 'apk-09.py','device-driver-09.py','run-device-09.py','capture-11.py','control-socket-probe.rs']:
    add(stage/name,'recipes/'+name)
# Only public allowlisted files are captured. Also scan every retained payload
# against the actual test TLS private keys before writing the archive.
cohorts=[stage/'host-cases-07'/(r+'-query-cancel') for r in pending.QUERY_TESTS]
cohorts += [stage/'baseline-cases-05'/(r+'-query-cancel') for r in pending.QUERY_TESTS]
cohorts += [device/'run-09/cases'/case_label]
for cohort in cohorts:
    for key in ['tls-key','witness-tls-key']:
        path=cohort/'inputs'/key
        if not path.exists():
            sdk.require(key=='witness-tls-key' and cohort.name.startswith('signed-'),'missing expected test key')
            continue
        secret=path.read_bytes()
        for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'test private key included')
for name,payload in list(files.items()):
    if name.endswith(('.py','.json','.stdout','.stderr')):
        files[name]=payload.replace(b'<SELECTED_ANDROID_DEVICE>',b'<SELECTED_ANDROID_DEVICE>').replace(
            b'<SELECTED_ANDROID_DEVICE_SHA256>',b'<SELECTED_ANDROID_DEVICE_SHA256>')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,data)
manifest={'format':1,'source_commit':host['source_commit'],'engine_source_commit':physical['engine_source_commit'],
 'candidate_sha256':host['candidate_sha256'],'aar_sha256':physical['aar_sha256'],'apk_sha256':physical['apk_sha256'],
 'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'host_routes':2,'host_foreign_processes':43,'physical_ART_processes':21,'physical_API':37,'release_claim_eligible':False,
 'recipe_hardware_selectors_redacted':True,'failed_baseline_retained':True,'product_implementation_changed':False}
sdk.write_json(out/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-query-cancel-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'capture inventory')
        for name,digest in manifest['members'].items():
            data=bundle.read(name);sdk.require(hashlib.sha256(data).hexdigest()==digest,'capture hash')
            if '/public/' in name:
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        results={}
        for route in pending.QUERY_TESTS:results.update(pending.verify_execution(bundle.read('host/host-run-07.stdout'),extracted/'host/public',route,batch=True,query_cancel=True))
        sdk.require(results==host['cases'],'host readback')
        sdk.require(pending.verify_execution(bundle.read('device/execution.stdout'),extracted/'device/public',label,query_cancel=True)==physical['result'],'phone readback')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256'],
 'all_host_and_device_public_readers':True,'private_test_keys_excluded':True})
print(json.dumps({'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256']}))
