from pathlib import Path
import ast
import json
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;old=root/'target/continuity-android-pending-matrix'
package=json.loads((old/'physical-08/PACKAGE.json').read_text())
sdk.require(package['completed'] and sdk.snapshot(Path(package['aar']),maximum=256*1024**2).sha256==package['aar_sha256'],'actual AAR changed')
for name,digest in package['source_sha256'].items():
    sdk.require(sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,'AAR implementation changed')
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
 'bindings/c/ContinuityPackageConsumer/src','bindings/c/ContinuityPackageConsumer/Cargo.toml','bindings/android/ContinuityPackageConsumer/src/main',
 'bindings/android/ContinuityPackageConsumer/jni']),'AAR implementation changed')
def replace(text,old,new):
    sdk.require(text.count(old)==1,'recipe shape: '+old[:80]);return text.replace(old,new)
def template(name):
    return (old/name).read_text().replace('continuity-android-pending-matrix','continuity-android-pending-query').replace('dev.qperiapt.continuity.pendingmatrix20261014','dev.qperiapt.continuity.pendingquery20261014')
apk=replace(template('apk-09.py'),"'PendingWriteProbe']","'PendingWriteProbe', 'PendingWriteCancellation']")
driver=replace(template('device-driver-09.py'),"inputs.parent.name=='tls-recoverable-applied'","inputs.parent.name=='tls-recoverable-applied-query-cancel'")
driver=replace(driver,"'pending-confirm-cancelled','pending-confirm'","'pending-confirm-inflight','pending-confirm-cancelled','pending-confirm'")
driver=replace(driver,"    assert len(names)==len(set(names))","    if mode=='pending-confirm-inflight':names+=['cancel-control-token','cancel-control-address']\n    assert len(names)==len(set(names))")
driver=replace(driver,"    try:\n        for host_port in ports:","""    fields={witness_port:'witness-address'}
    if peer_mode and peer_mode!='peer-unassociated':fields[peer_port]='connection-address'
    if mode=='pending-confirm-inflight':
        match=re.fullmatch(r'127\\.0\\.0\\.1:(\\d+)',(inputs/'cancel-control-address').read_text());assert match
        control_port=int(match.group(1));assert control_port not in ports
        ports.append(control_port);fields[control_port]='cancel-control-address'
    try:
        for host_port in ports:""")
driver=replace(driver,"field='witness-address' if host_port==witness_port else 'connection-address'","field=fields[host_port]")
run=template('run-device-09.py').replace('BUILD_05.json','BUILD_06.json')
run=replace(run,"label='tls-recoverable-applied'","label='tls-recoverable-applied';case_label=label+'-query-cancel'")
run=replace(run,'pending.TESTS[label]','pending.QUERY_TESTS[label]')
run=run.replace('pending.cases(True)','pending.cases(True,query_cancel=True)').replace('pending.public(True)','pending.public(True,query_cancel=True)')
run=replace(run,'pending.verify_execution(stdout,cases,label)','pending.verify_execution(stdout,cases,label,query_cancel=True)')
run=replace(run,"pending.verify_execution(stdout,out/'public',label)","pending.verify_execution(stdout,out/'public',label,query_cancel=True)")
run=run.replace('cases/label','cases/case_label').replace("out/'public'/label","out/'public'/case_label")
run=run.replace('pending recovery with pre-call cancellation','pending recovery with pre-call and held Query cancellation').replace('all 19 original pending recovery calls','all 21 original pending recovery calls')
out=stage/'physical-08';out.mkdir()
sdk.copy(Path(package['aar']),out/'q-periapt-continuity-android-0.0.0.aar',maximum=256*1024**2)
package['aar']=str(out/'q-periapt-continuity-android-0.0.0.aar');package['reused_unchanged_implementation']=True
sdk.write_json(out/'PACKAGE.json',package)
for name,value in [('apk-09.py',apk),('device-driver-09.py',driver),('run-device-09.py',run)]:
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
sdk.write_json(stage/'PHYSICAL_RECIPES_08.json',{name:sdk.snapshot(stage/name).sha256 for name in ['apk-09.py','device-driver-09.py','run-device-09.py']})
print('Fresh Query cancellation physical recipes ready; actual AAR unchanged; control reverse map explicit')
