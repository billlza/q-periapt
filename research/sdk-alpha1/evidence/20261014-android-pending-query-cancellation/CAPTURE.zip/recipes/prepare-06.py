from pathlib import Path
import ast
import json
import shutil
import subprocess
import tempfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
result=json.loads((stage/'BASELINE_RESULT_05.json').read_text())
sdk.require(not result['completed'] and 'failure' in result,'baseline not terminal failed')
old=json.loads((stage/'BUILD_04.json').read_text())
# Preserve the exact qualification source consumed by the failed baseline.
for name,digest in old['source_files'].items():
    if name.startswith('bindings/c/ContinuityPackageConsumer/'):
        path=Path(old['consumer'])/name.removeprefix('bindings/c/ContinuityPackageConsumer/')
    else:path=Path(old['android_source'])/name.removeprefix('bindings/android/ContinuityPackageConsumer/')
    sdk.require(sdk.snapshot(path).sha256==digest,'baseline source preimage differs')
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
 'bindings/c/ContinuityPackageConsumer/src','bindings/c/ContinuityPackageConsumer/Cargo.toml','bindings/android/ContinuityPackageConsumer/src/main',
 'bindings/android/ContinuityPackageConsumer/jni']),'installed implementation changed')
env=json.loads((stage/'ENVIRONMENT_01.json').read_text())
rust=['bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/cancellation.rs',
      'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/flow.rs']
sdk.command([str(Path(env['RUSTC']).parent/'rustfmt'),'--edition','2021','--config','skip_children=true',*rust],stage/'format-06',root,environment=env)
outside=Path(tempfile.mkdtemp(prefix='qpc-pending-query-contract-')).resolve();consumer=outside/'c-consumer'
shutil.copytree(Path(old['installed_base']['consumer']),consumer)
fixture=root/'bindings/c/ContinuityPackageConsumer';hashes={}
for path in fixture.rglob('*'):
    if path.is_file() and path.name!='Cargo.toml':
        target=consumer/path.relative_to(fixture);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(sdk.snapshot(path).data);hashes[str(path.relative_to(root))]=sdk.snapshot(path).sha256
builder=outside/'android-source';shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',builder)
hashes.update({str(path.relative_to(root)):sdk.snapshot(path).sha256 for path in (root/'bindings/android/ContinuityPackageConsumer').rglob('*') if path.is_file()})
sdk.write_json(stage/'INPUTS_06.json',{'outside':str(outside),'consumer':str(consumer),'android_source':str(builder),
 'source_files':hashes,'installed_base':old['installed_base'],'candidate_sha256':old['candidate_sha256'],
 'scope':'Actual archives, existing dispatch cancellation contract218, explicit bounded blocking control socket; no engine changes'})
recipe=(stage/'build-04.py').read_text().replace('INPUTS_04.json','INPUTS_06.json').replace('-04','-06').replace('BUILD_04.json','BUILD_06.json')
run=(stage/'run-baseline-05.py').read_text().replace('BUILD_04.json','BUILD_06.json').replace('baseline-cases-05','accepted-cases-07').replace('BASELINE_STATE_05.json','RUN_STATE_07.json').replace('BASELINE_RESULT_05.json','RUN_RESULT_07.json').replace('baseline-run-05','accepted-run-07')
for name,value in [('build-06.py',recipe),('run-installed-07.py',run)]:
    ast.parse(value)
    with (stage/name).open('x') as stream:stream.write(value)
print('Failed baseline retained; fresh qualification consumer prepared with unchanged actual engine')
