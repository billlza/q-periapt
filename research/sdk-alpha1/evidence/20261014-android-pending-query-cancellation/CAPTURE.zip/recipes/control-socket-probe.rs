use std::{io::Read, net::{TcpListener, TcpStream}, time::{Duration, Instant}};

fn main() -> std::io::Result<()> {
    let listener = TcpListener::bind("127.0.0.1:0")?;
    listener.set_nonblocking(true)?;
    let _client = TcpStream::connect(listener.local_addr()?)?;
    let (mut accepted, _) = listener.accept()?;
    accepted.set_read_timeout(Some(Duration::from_millis(200)))?;
    let mut byte = [0];
    let start = Instant::now();
    let error = accepted.read(&mut byte).expect_err("no peer data");
    println!("inherited: kind={:?} elapsed_ms={}", error.kind(), start.elapsed().as_millis());
    accepted.set_nonblocking(false)?;
    let start = Instant::now();
    let error = accepted.read(&mut byte).expect_err("no peer data");
    println!("explicit_blocking: kind={:?} elapsed_ms={}", error.kind(), start.elapsed().as_millis());
    Ok(())
}
