"""Read back the completed installed-wheel lane without rewriting its failed peer."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-independent-macos-failure'
SOURCE = BASE / 'artifact-13421798027.zip'
OUT = ROOT / 'research/sdk-alpha1/evidence/20261105-independent-installed-macos'
sha = lambda value: hashlib.sha256(value).hexdigest()
dump = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
assert SOURCE.stat().st_size == 319046817
assert sha(SOURCE.read_bytes()) == '2f30d0b4a76fd7ab74be0a855152a1d76ce6e08b4b6b1bb797fb44dd7c72cd9c'
original = json.loads((BASE / 'INPUTS.json').read_bytes())
members = {}
def add(name, value):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and name not in members
    members[name] = value

with zipfile.ZipFile(SOURCE) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == 65935
    report = json.loads(archive.read('python-installed/PYTHON_INSTALLATION.json'))
    assert report['completed'] is True and report['sources_unchanged'] is True
    assert report['release_claim_eligible'] is False
    assert report['source_commit'] == 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
    assert report['native_sha256'] == original['native_sha256']
    expected = json.loads(archive.read('python-installed/EXPECTED_MODULES.json'))
    installed = json.loads(archive.read('python-installed/INSTALLED_FILES.json'))
    provenance = json.loads(archive.read('python-installed/PROVENANCE.json'))
    assert len(expected) == 105 and report['modules'] == expected == provenance['modules']
    assert provenance['isolated'] == provenance['no_site'] == provenance['dont_write_bytecode'] == 1
    wheel_name = 'python-installed/qperiapt_continuity_reference-0.0.0-py3-none-any.whl'
    wheel = archive.read(wheel_name)
    assert sha(wheel) == report['wheel_sha256']
    with zipfile.ZipFile(io.BytesIO(wheel)) as package:
        assert package.testzip() is None
        for name, digest in expected.items():
            entry = 'qperiapt_continuity_reference/' + name
            assert sha(package.read(entry)) == digest == installed[entry]
    native = archive.read('counterpart')
    assert sha(native) == report['native_sha256']
    composition = json.loads(archive.read('python-installed/policy-composition/RESULT.json'))
    capacity = json.loads(archive.read('python-installed/policy-composition-capacity/RESULT.json'))
    assert composition == report['policy_composition']
    assert capacity == report['policy_composition_capacity']
    inputs = json.loads(archive.read('python-installed/policy-composition/INPUTS.json'))
    assert inputs == {k:composition[k] for k in ('source_files','native_sha256','provider')} == original
    profiles = []
    for row in composition['profiles']:
        count, witnessed = row['members'], row['witnessed']
        label = 'witness' if witnessed else 'local'
        prefix = f'python-installed/policy-composition/{count}/{label}/'
        native_rows = json.loads(archive.read(prefix + 'NATIVE.json'))
        witness_rows = json.loads(archive.read(prefix + 'WITNESS.json')) if witnessed else []
        workers = json.loads(archive.read(prefix + 'WORKERS.json'))
        assert len(workers) == row['workers'] and sum('signal' in w for w in workers) == row['process_kills'] == 15
        assert len({n['case'] for n in native_rows}) == len(native_rows)
        native_by_case = {n['case']:n for n in native_rows}
        for call in native_rows:
            name = call['case']
            request = archive.read(prefix + 'native/cases/' + name + '.input')
            response = archive.read(prefix + 'native/cases/' + name + '.output')
            assert sha(request) == call['input_sha256']
            assert response and response[0] == call['status'] and sha(response[1:]) == call['output_sha256']
            assert call['error'] == (response[1:].decode('ascii') if response[0] == 2 else None)
        for call in witness_rows:
            name = call['case']
            request = archive.read(prefix + name + '.request')
            assert len(request) == 3674 and sha(request) == call['request_sha256']
            assert request[204] == call['kind']
            assert request[140:172].hex() == call['command_id'] and request[172:204].hex() == call['challenge']
            if call['fault'] == 'before':
                assert name not in native_by_case and call['delivery'] == 'not_dispatched_by_fixture'
                continue
            native_row = native_by_case[name]
            assert native_row['command'] == 31 and native_row['input_sha256'] == call['request_sha256']
            assert native_row['status'] == call['native_status']
            if call['native_status'] == 2:
                assert call['delivery'] == 'native_rejected_no_signed_reply' and call['error'] == native_row['error']
                continue
            reply = archive.read(prefix + name + '.reply')
            assert len(reply) == 3659 and sha(reply) == call['signed_reply_sha256'] == native_row['output_sha256']
            if call['fault'] == 'after':
                assert call['delivery'] == 'signed_reply_withheld_by_fixture'
            else:
                transported = reply[:-1] + bytes([reply[-1] ^ 1]) if call['fault'] == 'corrupt' else reply
                assert sha(transported) == call['transport_reply_sha256']
                assert call['delivery'] == ('corrupted_by_fixture' if call['fault'] else 'sent')
        for worker in workers:
            name = worker['case']
            request = json.loads(archive.read(prefix + name + '.request.json'))
            assert request['action'] == worker['action']
            stdout = archive.read(prefix + name + '.stdout')
            stderr = archive.read(prefix + name + '.stderr')
            if 'signal' in worker:
                value = json.loads(stdout)
                assert worker['signal'] == 'SIGKILL' and value == {'pid':worker['worker_pid'],'stage':worker['cut']}
                assert stderr == b''
            elif 'refused' in worker:
                assert stdout == b'' and worker['refused'] in stderr.decode()
            else:
                assert sha(stdout) == worker['stdout_sha256'] and stderr == b''
                assert set(json.loads(stdout)) == {'result'}
        target = native_by_case['native-original-R-under-P']
        assert target['command'] == 40 and target['status'] == 1
        assert len(archive.read(prefix + 'native/cases/native-original-R-under-P.output')) == 73
        profiles.append({'members':count,'witnessed':witnessed,'native_commands':len(native_rows),
                         'witness_attempts':len(witness_rows),'workers':len(workers),'process_kills':row['process_kills']})
    assert {(p['members'],p['witnessed']) for p in profiles} == {(3,False),(3,True),(32,False),(32,True)}
    for info in archive.infolist():
        if info.filename.startswith('python-installed/policy-composition/') and not info.is_dir():
            add(info.filename, archive.read(info))
    for name in ('source-head.txt','host.txt','rustc.txt','metadata.json','build.stdout','build.stderr','counterpart',
                 wheel_name,'python-installed/PYTHON_INSTALLATION.json','python-installed/EXPECTED_MODULES.json',
                 'python-installed/INSTALLED_FILES.json','python-installed/LOCATION.json','python-installed/PROVENANCE.json',
                 'python-installed/policy-composition-capacity/INPUTS.json','python-installed/policy-composition-capacity/RESULT.json'):
        add(name, archive.read(name))
add('job-127182900587.log', (ROOT / 'target/continuity-next-wave-20261105/monitor-1435/job-127182900587.log').read_bytes())
add('seal_installed_peer.py', Path(__file__).read_bytes())
for name, value in members.items():
    if any(word in name.lower() for word in ('private','secret','.pem')):
        assert name.endswith(('private-fixture-path','private-witness-path')), name
        text = value.decode()
        assert text.startswith('/') and '\n' not in text.removesuffix('\n') and '\x00' not in text and '\r' not in text
readback = {
    'captured_utc':datetime.now(timezone.utc).isoformat(),
    'run':42008994078,'job':127182900587,'artifact':13421798027,
    'artifact_bytes':319046817,'artifact_sha256':sha(SOURCE.read_bytes()),'artifact_members':65935,
    'source_commit':report['source_commit'],'completed_installed_report':True,'job_conclusion':'success',
    'wheel_sha256':report['wheel_sha256'],'installed_package_modules_checked':105,
    'native_sha256':report['native_sha256'],'same_native_as_failed_source_lane':True,
    'same_225_source_inputs_as_failed_source_lane':True,'same_provider_as_failed_source_lane':True,
    'composition_profiles':profiles,'composition_public_trace_replayed':True,
    'capacity_report_profiles':[{k:p[k] for k in ('members','witnessed','workers','process_kills')} for p in capacity['profiles']],
    'capacity_public_trace_replayed':False,
    'rust_boundary':'Source-built Rust counterpart. This does not substitute for a truly installed Rust crate/SDK endpoint.',
    'failed_source_job_reclassified':False,'current_modified_source_qualified':False,'release_claim_eligible':False,
    'private_state_included':False,
    'scope':'Retained successful installed-wheel lane on ff072, with exact source/binary/provider comparison and complete four-profile composition transcript readback. Original source-lane timeout remains failed and causally unresolved; this is not a rerun or qualification of later local changes.'
}
add('READBACK.json',dump(readback))
OUT.mkdir()
with zipfile.ZipFile(OUT / 'CAPTURE.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,value in sorted(members.items()):archive.writestr(name,value)
manifest={'archive_bytes':(OUT/'CAPTURE.zip').stat().st_size,
          'archive_sha256':sha((OUT/'CAPTURE.zip').read_bytes()),
          'members':{name:{'bytes':len(value),'sha256':sha(value)} for name,value in sorted(members.items())}}
with zipfile.ZipFile(OUT/'CAPTURE.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    for name,value in members.items():assert archive.read(name)==value
(OUT/'CAPTURE.json').write_bytes(dump(manifest));(OUT/'READBACK.json').write_bytes(dump(readback))
print(json.dumps({'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256'],'members':len(members),'profiles':profiles}))

