from pathlib import Path
import re,difflib,json
root=Path.cwd();stage=Path(__file__).resolve().parent
pattern=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
paths=[root/'target/continuity-recovery-interactive-20261015/baseline-21.spthy',stage/'helpers-proof-04.spthy',stage/'contents-proof-12.spthy']
rows=[{m.group(1):m.group() for m in pattern.finditer(p.read_text())} for p in paths]
for j in (1,2):
 for n,old in rows[0].items():
  if old!=rows[j][n]:
   print(n,paths[j].name)
   print(''.join(difflib.unified_diff(old.splitlines(True),rows[j][n].splitlines(True),fromfile='prior',tofile=paths[j].name)))
