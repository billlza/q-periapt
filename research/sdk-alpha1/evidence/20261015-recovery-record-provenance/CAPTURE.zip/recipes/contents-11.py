from pathlib import Path
import hashlib,json,re
stage=Path(__file__).resolve().parent;base=(stage/'helpers-03.spthy').read_text();variant=base;added=[]
rows=[('Key_Reservation_1','A','1','<old,~key>'),('Offer_Signing_2','A','2','<old,key>'),('Offer_Commit_3','A','3','<old,key,wire>'),('Response_Reservation_4','B','4','<old,wire,~coins>'),('Response_Compute_5','B','5','<old,offer,core,root>'),('Response_Commit_6','B','6','<old,offer,wire,root>'),('Final_Reservation_7','A','7','<old,offer,response,root>'),('Final_Commit_8','A','8','<root,offer,response,final>'),('Receipt_Reservation_9','B','9','<old,root,offer,response,final>'),('Receipt_Commit_0','B','0','<root,offer,response,final,receipt>'),('Receipt_Accept_0','A','0','<root,offer,response,final,receipt>')]
for name,role,phase,value in rows:
 start=variant.index('rule '+name+':');m=re.search(r'\n(?:rule|restriction|lemma) ',variant[start+1:]);end=start+1+m.start() if m else len(variant)
 block=variant[start:end];saved="Saved(s,~rev,'"+phase+"')";stored="!Stored(s,'"+role+"','"+phase+"',~rev,"+value+")"
 assert block.count(saved)==1 and block.count(stored)==1,(name,'writer mapping differs')
 tag="StoredContents(s,'"+role+"','"+phase+"',~rev,"+value+")";added.append(tag)
 variant=variant[:start]+block.replace(saved,saved+', '+tag)+variant[end:]
tag='ReadContents(s,role,phase,revision,plaintext)';added.append(tag)
assert variant.count('CapturedPhase(s,role,phase)')==1
variant=variant.replace('CapturedPhase(s,role,phase)','CapturedPhase(s,role,phase), '+tag)
projection=variant
for tag in added:
 assert projection.count(', '+tag)==1
 projection=projection.replace(', '+tag,'')
assert projection==base,'erasing observer labels must exactly recover original operational model'
lemma='''lemma captured_contents_have_stored_origin [sources]:
 "All s role phase revision plaintext #read.
    ReadContents(s,role,phase,revision,plaintext)@read
    ==> (Ex #written. StoredContents(s,role,phase,revision,plaintext)@written
                    & written < read)"

'''
variant=variant.replace('lemma generation_secret_origin [use_induction]:',lemma+'lemma generation_secret_origin [use_induction]:')
with (stage/'contents-11.spthy').open('x') as f:f.write(variant)
with (stage/'CONTENTS_PROJECTION_11.json').open('x') as f:json.dump({'completed':True,'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'added_write_observer_labels':11,'added_read_observer_labels':1,'erasure_byte_identical':True,'new_fact_consumption_or_output':False,'new_restriction':False,'new_proof_obligation':'captured_contents_have_stored_origin','assumed_verified':False},f,indent=2)
print('Added observational labels to 11 writes and one read; erasure exactly recovers the prior model')
