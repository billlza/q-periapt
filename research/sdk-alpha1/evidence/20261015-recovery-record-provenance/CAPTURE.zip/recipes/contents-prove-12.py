from pathlib import Path
import json,os,re,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text());source=stage/'contents-11.spthy'
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--prove=captured_contents_have_stored_origin','--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(stage/'contents-proof-12.spthy'),'+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False
with (stage/'contents-12.stdout').open('xb') as out,(stage/'contents-12.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/'CONTENTS_STARTED_12.json',{'pid':p.pid,'argv':argv,'maximum_seconds':180})
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
summary=(stage/'contents-12.stdout').read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
accepted=code==0 and not timed_out and results.get('captured_contents_have_stored_origin',{}).get('status')=='verified'
sdk.write_json(stage/'CONTENTS_TERMINAL_12.json',{'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'results':results,'accepted':accepted,'input_sha256':sdk.snapshot(source).sha256})
print(json.dumps({'returncode':code,'timed_out':timed_out,'results':results,'accepted':accepted}),flush=True)
