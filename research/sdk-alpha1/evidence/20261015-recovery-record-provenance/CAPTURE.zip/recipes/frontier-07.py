from pathlib import Path
import json,os,re,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(json.loads((stage/'HELPERS_TERMINAL_04.json').read_text())['accepted'],'helper proofs not verified')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text());source=stage/'helpers-proof-04.spthy'
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--prove=clean_reservation_recovers_symbolic_message_secrecy','--heuristic=O','--oraclename='+str(stage/'signature-oracle-06.sh'),'--oracle-only','--quiet','--derivcheck-timeout=60','--quit-on-warning','--output='+str(stage/'frontier-07.spthy'),'+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False
with (stage/'frontier-07.stdout').open('xb') as out,(stage/'frontier-07.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/'FRONTIER_STARTED_07.json',{'pid':p.pid,'argv':argv,'maximum_seconds':180,'maximum_ranked_calls':80})
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
summary=(stage/'frontier-07.stdout').read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
required=['retained_record_has_saved_origin','stored_records_follow_fresh_reservations','clean_reservation_recovers_symbolic_message_secrecy']
verified=code==0 and not timed_out and all(results.get(n,{}).get('status')=='verified' for n in required)
sdk.write_json(stage/'FRONTIER_TERMINAL_07.json',{'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'results':results,'accepted':verified,'diagnostic_search_limit_is_not_model_restriction':True,'release_claim_eligible':False})
print(json.dumps({'returncode':code,'timed_out':timed_out,'results':results,'accepted':verified}),flush=True)
