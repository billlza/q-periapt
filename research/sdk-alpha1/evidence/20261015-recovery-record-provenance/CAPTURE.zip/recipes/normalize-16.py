from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
for label,source in [('prior',root/'target/continuity-recovery-interactive-20261015/baseline-21.spthy'),('helper',stage/'helpers-proof-04.spthy'),('contents',stage/'contents-proof-12.spthy')]:
 output=stage/(label+'-normalized-16.spthy');sdk.require(not output.exists(),'normalization output already exists')
 sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(source),'--parse-only','--output='+str(output)],stage/(label+'-normalize-16'),root)
 sdk.require(output.is_file(),'parser output missing')
print('Normalized three public theories with the pinned parser; parse success is not proof acceptance')
