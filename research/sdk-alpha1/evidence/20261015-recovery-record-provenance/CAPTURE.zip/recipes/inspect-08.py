from pathlib import Path
import json
stage=Path(__file__).resolve().parent
rows=[json.loads(x) for x in (stage/'oracle-calls-06.jsonl').read_text().splitlines()]
for row in rows[-14:]:
 goals=dict(row['goals']);first=row['ranked'][0] if row['ranked'] else None
 print(json.dumps({'call':row['call'],'goals':len(goals),'selected':goals[first][:400] if first is not None else 'STOP','other_goals':[t[:130] for i,t in row['goals'] if i!=first][:5]},ensure_ascii=False))
