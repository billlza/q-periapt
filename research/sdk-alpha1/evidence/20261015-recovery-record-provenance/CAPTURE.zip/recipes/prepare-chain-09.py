from pathlib import Path
import ast
stage=Path(__file__).resolve().parent
old=(stage/'signature-oracle-06.py').read_text()
start=old.index('def priority(row):');end=old.index("with (stage/'oracle-calls",start)
priority='''def priority(row):
 index,text=row
 if '~~>' in text:rank=0
 elif any(re.match(r'!?'+name+r'\\s*\\(',text) for name in names if name!='Saved'):rank=1
 elif re.match(r'!?KU\\(\\s*sign\\(',text):rank=2
 elif re.match(r'!?KU\\(\\s*~(?:sa|sb|key|coins)(?:[. ]|\\))',text):rank=3
 elif text.startswith(('splitEqs(', 'disjunction(')):rank=4
 elif text.startswith('Saved('):rank=5
 elif '~payload' in text:rank=7
 else:rank=6
 return rank,index
'''
new=(old[:start]+priority+old[end:]).replace('oracle-calls-06.jsonl','oracle-calls-09.jsonl')
ast.parse(new)
with (stage/'chain-oracle-09.py').open('x') as f:f.write(new)
wrapper=(stage/'signature-oracle-06.sh').read_text().replace('signature-oracle-06.py','chain-oracle-09.py')
with (stage/'chain-oracle-09.sh').open('x') as f:f.write(wrapper)
(stage/'chain-oracle-09.sh').chmod(0o700)
runner=(stage/'frontier-07.py').read_text().replace('signature-oracle-06.sh','chain-oracle-09.sh').replace('frontier-07','frontier-10').replace('FRONTIER_STARTED_07','FRONTIER_STARTED_10').replace('FRONTIER_TERMINAL_07','FRONTIER_TERMINAL_10')
ast.parse(runner)
with (stage/'frontier-10.py').open('x') as f:f.write(runner)
print('Prepared same-budget chain-first diagnostic; original experiment and model unchanged')
