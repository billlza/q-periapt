from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.require(json.loads((stage/'SEMANTICS_17.json').read_text())['completed'],'semantic identities unchecked')
DECL=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
text=(stage/'helpers-proof-04.spthy').read_text();blocks={m.group(1):m for m in DECL.finditer(text)}
start=blocks['retained_record_has_saved_origin'].end();end=blocks['stored_records_follow_fresh_reservations'].start()
missing=text[:start]+'\nby sorry\n\n'+text[end:]
sdk.require([m.group() for m in DECL.finditer(text)]==[m.group() for m in DECL.finditer(missing)],'proof-removal control changed declarations')
with (stage/'missing-helper-18.spthy').open('x') as f:f.write(missing)
all_results={}
for label,source,expected in [('helpers',stage/'helpers-proof-04.spthy',{'retained_record_has_saved_origin':13,'stored_records_follow_fresh_reservations':42}),('contents',stage/'contents-proof-12.spthy',{'captured_contents_have_stored_origin':16}),('missing-helper',stage/'missing-helper-18.spthy',{'stored_records_follow_fresh_reservations':42})]:
 prefix=stage/(label+'-replay-18')
 sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(source),'--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M4G','-RTS'],prefix,root)
 summary=prefix.with_suffix('.stdout').read_text().rsplit('summary of summaries:',1)[-1]
 parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)',summary,re.M)
 results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
 sdk.require(len(results)==(8 if label=='contents' else 7),'required lemma inventory missing')
 verified={n:r['steps'] for n,r in results.items() if r['status']=='verified'};sdk.require(verified==expected,'verified inventory differs')
 sdk.require(all(r['status']=='analysis incomplete' for n,r in results.items() if n not in expected),'unexpected result for unselected query')
 all_results[label]={'input_sha256':sdk.snapshot(source).sha256,'results':results,'required_helper_group_accepted':label!='missing-helper'}
 print(label+': '+json.dumps(verified),flush=True)
sdk.write_json(stage/'REPLAYS_18.json',{'completed':True,'proof_search_requested':False,'results':all_results,'missing_helper_rejected_despite_exit_zero':True,'original_main_secrecy_proof_accepted':False,'release_claim_eligible':False})
