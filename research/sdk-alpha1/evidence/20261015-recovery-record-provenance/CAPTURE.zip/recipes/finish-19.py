from pathlib import Path
import json,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='170bd63b7e6c873a4b0bd4d1dfcb65164d1dde5a' and not subprocess.check_output(['git','status','--porcelain']),'source changed before documentation')
sdk.require(json.loads((stage/'REPLAYS_18.json').read_text())['completed'],'independent replays incomplete')
expected={'ORIGINAL_TERMINAL_02.json':(-2,True),'INDUCTION_TERMINAL_02.json':(-9,True),'HELPER_SECRECY_TERMINAL_05.json':(-2,True),'SOURCE_SECRECY_TERMINAL_13.json':(-9,True),'FRONTIER_TERMINAL_07.json':(0,False),'FRONTIER_TERMINAL_10.json':(0,False)}
for name,(code,timeout) in expected.items():
 row=json.loads((stage/name).read_text());sdk.require(row['returncode']==code and row['timed_out']==timeout and not row['accepted'],'failed/incomplete search changed')
processes=subprocess.check_output(['ps','-axo','pgid=,pid=,command='],text=True).splitlines()
pids={json.loads(p.read_text())['pid'] for p in stage.glob('*STARTED*.json')}
for line in processes:
 parts=line.strip().split(None,2)
 if len(parts)!=3:raise ValueError('unparseable process row')
 sdk.require(int(parts[0]) not in pids,'owned proof process group still live')
sdk.write_json(stage/'CLEANUP_19.json',{'completed':True,'owned_process_groups_absent':sorted(pids),'private_sdk_state_accessed':False,'device_state_accessed':False})
sdk.write_json(stage/'SETUP_FAILURES_19.json',{'observed_failures':[{'recipe':'check-inputs-14.py','error':'original quantified declarations changed','cause':'Only line wrapping differed between interactive and CLI rendering of recovery_is_executable; declaration-diff-15.py preserves the distinguishing inspection.','resolved_by':'check-normalized-17.py uses the pinned parser output for exact declaration comparison and also checks unchanged raw declarations.'},{'recipe':'normalize-16.py','error':'parser output missing','cause':'The successful parse-only command emitted its theory to stdout instead of the requested output file.','resolved_by':'check-normalized-17.py reads the actual parser stdout.'}],'original_failed_recipes_retained':True,'no_model_or_formula_weakened':True})
path=root/'research/continuity-recovery-symbolic/README.md';text=path.read_text();marker='## Modeled boundaries\n'
sdk.require(text.count(marker)==1,'research section anchor changed')
section='''## Retained-record proof obligations

A separate [provenance checkpoint](../sdk-alpha1/evidence/20261015-recovery-record-provenance/README.md)
checks two auxiliary statements on a lemma-only extension: every Snapshot has an
earlier Saved event (13 steps), and fresh reservations after Cut put every record
of that exchange after Cut (42 steps). Its operational rules and the original
five complete declarations are unchanged. A third, observational extension
checks that the exact content read matches an earlier write (16 steps). Erasing
its 12 observer labels recovers the preceding model byte for byte. These labels
are proof observations, not additional network outputs or SDK logging.

Fresh processes replay the three helper proofs without automatic search. A
control removes the 13-step proof while retaining the 42-step proof: exit zero
and one verified helper do not admit the incomplete helper group. Ordinary,
inductive and helper-assisted searches still do not close the main secrecy
query. Two bounded oracle diagnostics return incomplete proof trees, not attacks
or security proofs. All failed attempts remain recorded. These auxiliary results
are separate from the four original checked statements and do not extend their
product or computational scope.

'''
path.write_text(text.replace(marker,section+marker))
path=root/'docs/continuity/RECOVERY_DEPENDENCIES_V1.md';text=path.read_text();sdk.require('retained-record proof obligations' not in text,'dependency note already present')
path.write_text(text+'''
The [retained-record proof obligations](../../research/continuity-recovery-symbolic/README.md#retained-record-proof-obligations)
now separately check record origin, its timing relative to fresh reservations,
and content correspondence under removable observer labels. Independent replays
and a missing-helper control pass. These facts constrain the storage side of the
argument; attempted composition with message secrecy remains incomplete. The
next proof work must address authenticated KEM and traffic-secret provenance,
without replacing the unchanged recovery condition or assuming an unproved lemma.
''')
print('Three helper proofs independently replayed; failed main searches retained; owned proof groups absent; research status updated')
