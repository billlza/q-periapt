from pathlib import Path
import hashlib,json
root=Path.cwd();stage=Path(__file__).resolve().parent
source=root/'research/continuity-recovery-symbolic/protected-state.spthy';data=source.read_text()
name='clean_reservation_recovers_symbolic_message_secrecy'
assert data.count('lemma '+name+':')==1
changed=data.replace('lemma '+name+':','lemma '+name+' [use_induction]:')
with (stage/'original-01.spthy').open('x') as f:f.write(data)
with (stage/'induction-01.spthy').open('x') as f:f.write(changed)
with (stage/'INPUTS_01.json').open('x') as f:json.dump({'base_commit':'170bd63b7e6c873a4b0bd4d1dfcb65164d1dde5a','canonical_sha256':hashlib.sha256(data.encode()).hexdigest(),'induction_sha256':hashlib.sha256(changed.encode()).hexdigest(),'only_variant_change':'use_induction proof-method hint on the existing clean-reservation lemma','rules_formulas_and_lemma_inventory_changed':False},f,indent=2)
print('Prepared immutable bare-model and induction-method copies; no query or transition changed')
