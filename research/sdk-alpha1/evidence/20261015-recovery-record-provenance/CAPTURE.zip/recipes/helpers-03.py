from pathlib import Path
import hashlib,json
root=Path.cwd();stage=Path(__file__).resolve().parent;source=(stage/'original-01.spthy').read_text()
helpers='''lemma retained_record_has_saved_origin [reuse]:
 "All s revision #seen.
    Snapshot(s,revision)@seen
    ==> (Ex phase #saved. Saved(s,revision,phase)@saved & saved < seen)"

lemma stored_records_follow_fresh_reservations [reuse]:
 "All s revision phase #saved #c #g #e.
    Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Saved(s,revision,phase)@saved & c < g & c < e
  ==> c < saved"

'''
marker='lemma clean_reservation_recovers_symbolic_message_secrecy:'
assert source.count(marker)==1
variant=source.replace(marker,helpers+marker)
with (stage/'helpers-03.spthy').open('x') as f:f.write(variant)
with (stage/'HELPERS_03.json').open('x') as f:json.dump({'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'original_rule_equation_restriction_prefix_unchanged':source.split('\nlemma ',1)[0]==variant.split('\nlemma ',1)[0],'original_five_lemma_declarations_unchanged':True,'additional_proof_obligations':['retained_record_has_saved_origin','stored_records_follow_fresh_reservations'],'assumed_verified':False},f,indent=2)
print('Added two candidate provenance obligations to an isolated copy; neither is accepted until independently verified')
