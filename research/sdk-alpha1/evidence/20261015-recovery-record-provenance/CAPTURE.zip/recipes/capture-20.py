from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
replays=json.loads((stage/'REPLAYS_18.json').read_text());semantic=json.loads((stage/'SEMANTICS_17.json').read_text());projection=json.loads((stage/'CONTENTS_PROJECTION_11.json').read_text())
sdk.require(replays['completed'] and replays['missing_helper_rejected_despite_exit_zero'],'helper replay controls incomplete')
sdk.require(semantic['completed'] and semantic['original_five_full_declarations_unchanged_after_pinned_parser_normalization'] and semantic['observer_erasure_byte_identical'],'semantic checks incomplete')
sdk.require(json.loads((stage/'CLEANUP_19.json').read_text())['completed'],'process cleanup incomplete')
for label,file in [('helpers','helpers-proof-04.spthy'),('contents','contents-proof-12.spthy'),('missing-helper','missing-helper-18.spthy')]:sdk.require(replays['results'][label]['input_sha256']==sdk.snapshot(stage/file).sha256,'replay input changed')
sdk.require(sdk.snapshot(root/'research/continuity-recovery-symbolic/protected-state.spthy').sha256==json.loads((stage/'INPUTS_01.json').read_text())['canonical_sha256'],'canonical model changed')
failed={name:json.loads((stage/name).read_text()) for name in ['ORIGINAL_TERMINAL_02.json','INDUCTION_TERMINAL_02.json','HELPER_SECRECY_TERMINAL_05.json','SOURCE_SECRECY_TERMINAL_13.json','FRONTIER_TERMINAL_07.json','FRONTIER_TERMINAL_10.json']}
sdk.require(all(not row['accepted'] for row in failed.values()),'unproved main search was accepted')
files={}
def add(path,name):
 sdk.require(name not in files,'duplicate archive entry');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
for path in stage.iterdir():
 if not path.is_file():continue
 if path.suffix=='.spthy':folder='proof/'
 elif path.suffix in ('.py','.sh'):folder='recipes/'
 elif path.suffix=='.jsonl':folder='diagnostics/'
 elif path.suffix in ('.json','.stdout','.stderr'):folder='receipts/'
 else:raise ValueError('unexpected evidence file: '+path.name)
 add(path,folder+path.name)
for name in ['README.md','protected-state.spthy']:add(root/'research/continuity-recovery-symbolic'/name,'source/'+name)
add(root/'docs/continuity/RECOVERY_DEPENDENCIES_V1.md','source/RECOVERY_DEPENDENCIES_V1.md')
add(root/'target/continuity-recovery-interactive-20261015/baseline-21.spthy','proof/prior-bare-export.spthy')
prior=root/'target/continuity-recovery-symbolic-20261015'
for name in ['TOOLS_08.json','tool-contract-09.json','tool-contract-09.stdout','tool-contract-09.stderr']:add(prior/name,'toolchain/'+name)
output=root/'research/sdk-alpha1/evidence/20261015-recovery-record-provenance';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'format':1,'base_commit':'170bd63b7e6c873a4b0bd4d1dfcb65164d1dde5a','capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},'canonical_source_sha256':sdk.snapshot(stage/'original-01.spthy').sha256,'verified_helpers':{'retained_record_has_saved_origin':13,'stored_records_follow_fresh_reservations':42,'captured_contents_have_stored_origin':16},'certificates':{n:replays['results'][n]['input_sha256'] for n in ('helpers','contents')},'main_secrecy_verified':False,'original_four_statement_checkpoint':'20261015-recovery-symbolic-disclosure','original_five_query_declarations_unchanged':True,'plain_helper_operational_prefix_unchanged':True,'observer_labels_added':12,'observer_erasure_byte_identical':True,'failed_or_incomplete_main_search_receipts':list(failed),'missing_helper_rejected_despite_exit_zero':True,'owned_process_groups_terminal':True,'canonical_model_changed':False,'production_code_changed':False,'release_claim_eligible':False}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.namelist())==len(set(z.namelist()))==len(files),'archive inventory differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'archive member differs')
 for name in ['receipts/REPLAYS_18.json','receipts/SEMANTICS_17.json','receipts/CONTENTS_PROJECTION_11.json','receipts/CLEANUP_19.json']:sdk.require(json.loads(z.read(name))['completed'],'archived check incomplete')
 sdk.require(not json.loads(z.read('receipts/SOURCE_SECRECY_TERMINAL_13.json'))['accepted'],'unproved main query admitted')
sdk.write_json(output/'READBACK.json',{'completed':True,'members':len(files),'capture_sha256':manifest['capture_sha256'],'independently_replayed_helper_count':3,'main_secrecy_verified':False,'private_sdk_runtime_data_selected':False})
print(json.dumps({'members':len(files),'capture_sha256':manifest['capture_sha256'],'verified_helpers':manifest['verified_helpers'],'main_secrecy_verified':False}))
