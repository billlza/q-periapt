from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
texts={'prior':(stage/'prior-normalize-16.stdout').read_text()}
sdk.require(json.loads((stage/'prior-normalize-16.json').read_text())['returncode']==0,'prior parser command failed')
for label,source in [('helper',stage/'helpers-proof-04.spthy'),('contents',stage/'contents-proof-12.spthy')]:
 data=sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(source),'--parse-only'],stage/(label+'-normalize-17'),root)
 texts[label]=data.decode()
DECL=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
rows={label:{m.group(1):m.group() for m in DECL.finditer(text)} for label,text in texts.items()};a,b,c=[rows[k] for k in ('prior','helper','contents')]
sdk.require(len(a)==5 and len(b)==7 and len(c)==8,'lemma inventory differs')
sdk.require(all(a[n]==b[n]==c[n] for n in a),'original normalized declarations changed')
sdk.require(all(b[n]==c[n] for n in b),'timing helper declarations changed')
sdk.require(texts['prior'].split('\nlemma ',1)[0]==texts['helper'].split('\nlemma ',1)[0],'helper prefix changed')
source=(root/'research/continuity-recovery-symbolic/protected-state.spthy').read_text();sdk.require(source==(stage/'original-01.spthy').read_text(),'canonical source changed')
raw_a={m.group(1):m.group() for m in DECL.finditer(source)};raw_b={m.group(1):m.group() for m in DECL.finditer((stage/'helpers-03.spthy').read_text())}
sdk.require(all(raw_a[n]==raw_b[n] for n in raw_a),'original raw declarations changed')
projection=json.loads((stage/'CONTENTS_PROJECTION_11.json').read_text());sdk.require(projection['erasure_byte_identical'] and projection['input_sha256']==sdk.snapshot(stage/'contents-11.spthy').sha256 and projection['base_sha256']==sdk.snapshot(stage/'helpers-03.spthy').sha256,'observer projection identity differs')
oracles={}
for log_name in ('oracle-calls-06.jsonl','oracle-calls-09.jsonl'):
 calls=[json.loads(x) for x in (stage/log_name).read_text().splitlines()]
 for i,row in enumerate(calls,1):
  sdk.require(row['call']==i,'oracle call sequence broken');ids=[j for j,t in row['goals']]
  if row['diagnostic_stop']:sdk.require(i>80 and row['ranked']==[],'oracle stop changed')
  else:sdk.require(i<=80 and sorted(row['ranked'])==sorted(ids) and len(ids)==len(set(ids)),'oracle changed goal inventory')
 oracles[log_name]={'ranked_calls':sum(not r['diagnostic_stop'] for r in calls),'stopped_calls':sum(r['diagnostic_stop'] for r in calls)}
sdk.write_json(stage/'SEMANTICS_17.json',{'completed':True,'original_five_full_declarations_unchanged_after_pinned_parser_normalization':True,'original_raw_declarations_unchanged':True,'timing_helpers_unchanged':True,'plain_helper_operational_prefix_unchanged':True,'observer_erasure_byte_identical':True,'canonical_source_unchanged':True,'oracle_rankings':oracles,'oracle_rankings_are_permutations':True,'earlier_check_14_failure':'interactive and CLI pretty printers wrap the honest witness declaration differently','normalizer_16_failure':'parse-only emits the theory on stdout even when --output is supplied','no_unproved_property_accepted':True})
print('Pinned-parser normalization confirms unchanged original declarations; raw extension and observer projection also match')
