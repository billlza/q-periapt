from pathlib import Path
import json,os,signal,subprocess,sys,time,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;mode=sys.argv[1]
sdk.require(mode in ('original','induction'),'invalid proof mode')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text());source=stage/(mode+'-01.spthy');prefix=stage/(mode+'-02')
limit=180 if mode=='original' else 600
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--prove=clean_reservation_recovers_symbolic_message_secrecy','--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(stage/(mode+'-proof-02.spthy')),'+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False;output_exceeded=False
with prefix.with_suffix('.stdout').open('xb') as out,prefix.with_suffix('.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/(mode.upper()+'_STARTED_02.json'),{'pid':p.pid,'argv':argv,'maximum_seconds':limit,'input_sha256':sdk.snapshot(source).sha256})
 while p.poll() is None:
  timed_out=time.monotonic()-start>=limit
  output_exceeded=max(out.tell(),err.tell())>32*1024**2
  if timed_out or output_exceeded:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   break
  time.sleep(0.2)
 code=p.wait(timeout=5)
text=prefix.with_suffix('.stdout').read_text();summary=text.rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
accepted=code==0 and not timed_out and not output_exceeded and results.get('clean_reservation_recovers_symbolic_message_secrecy',{}).get('status')=='verified'
sdk.write_json(stage/(mode.upper()+'_TERMINAL_02.json'),{'argv':argv,'returncode':code,'timed_out':timed_out,'output_exceeded':output_exceeded,'elapsed_seconds':time.monotonic()-start,'input_sha256':sdk.snapshot(source).sha256,'results':results,'accepted':accepted,'release_claim_eligible':False})
print(json.dumps({'mode':mode,'returncode':code,'timed_out':timed_out,'results':results,'accepted':accepted}),flush=True)
