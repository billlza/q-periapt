from pathlib import Path
import json,os,re,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(json.loads((stage/'CONTENTS_TERMINAL_12.json').read_text())['accepted'],'source lemma not verified')
sdk.require(json.loads((stage/'CONTENTS_PROJECTION_11.json').read_text())['erasure_byte_identical'],'operational projection differs')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text());source=stage/'contents-proof-12.spthy'
names=['retained_record_has_saved_origin','stored_records_follow_fresh_reservations','clean_reservation_recovers_symbolic_message_secrecy']
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),*['--prove='+n for n in names],'--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(stage/'source-secrecy-proof-13.spthy'),'--output-json='+str(stage/'source-secrecy-trace-13.json'),'+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False
with (stage/'source-secrecy-13.stdout').open('xb') as out,(stage/'source-secrecy-13.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/'SOURCE_SECRECY_STARTED_13.json',{'pid':p.pid,'argv':argv,'maximum_seconds':300,'input_sha256':sdk.snapshot(source).sha256})
 try:code=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
summary=(stage/'source-secrecy-13.stdout').read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
verified=code==0 and not timed_out and all(results.get(n,{}).get('status')=='verified' for n in ['captured_contents_have_stored_origin',*names])
sdk.write_json(stage/'SOURCE_SECRECY_TERMINAL_13.json',{'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'results':results,'accepted':verified,'input_sha256':sdk.snapshot(source).sha256,'release_claim_eligible':False})
print(json.dumps({'returncode':code,'timed_out':timed_out,'results':results,'accepted':verified}),flush=True)
