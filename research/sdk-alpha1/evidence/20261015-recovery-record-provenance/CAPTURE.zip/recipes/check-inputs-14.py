from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
DECL=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
baseline=(root/'target/continuity-recovery-interactive-20261015/baseline-21.spthy').read_text()
helper=(stage/'helpers-proof-04.spthy').read_text();observed=(stage/'contents-proof-12.spthy').read_text()
a={m.group(1):m.group() for m in DECL.finditer(baseline)};b={m.group(1):m.group() for m in DECL.finditer(helper)};c={m.group(1):m.group() for m in DECL.finditer(observed)}
sdk.require(len(a)==5 and len(b)==7 and len(c)==8,'lemma inventory differs')
sdk.require(all(a[n]==b[n]==c[n] for n in a),'original quantified declarations changed')
sdk.require(all(b[n]==c[n] for n in b),'timing helper declarations changed')
sdk.require(baseline.split('\nlemma ',1)[0]==helper.split('\nlemma ',1)[0],'plain helper extension changed operational theory')
source=(root/'research/continuity-recovery-symbolic/protected-state.spthy').read_text()
sdk.require(source==(stage/'original-01.spthy').read_text(),'canonical source changed')
allowed_helpers={'retained_record_has_saved_origin','stored_records_follow_fresh_reservations'}
sdk.require(set(b)-set(a)==allowed_helpers and set(c)-set(b)=={'captured_contents_have_stored_origin'},'unexpected additional obligation')
projection=json.loads((stage/'CONTENTS_PROJECTION_11.json').read_text());sdk.require(projection['erasure_byte_identical'],'observer erasure failed')
for log_name in ('oracle-calls-06.jsonl','oracle-calls-09.jsonl'):
 rows=[json.loads(x) for x in (stage/log_name).read_text().splitlines()]
 for i,row in enumerate(rows,1):
  sdk.require(row['call']==i,'oracle call sequence broken')
  ids=[j for j,t in row['goals']]
  if row['diagnostic_stop']:sdk.require(i>80 and row['ranked']==[],'oracle stop changed')
  else:sdk.require(i<=80 and sorted(row['ranked'])==sorted(ids) and len(ids)==len(set(ids)),'oracle changed the goal inventory')
sdk.write_json(stage/'SEMANTICS_14.json',{'completed':True,'original_five_full_declarations_unchanged':True,'timing_helper_declarations_unchanged':True,'plain_helper_operational_prefix_unchanged':True,'observer_erasure_byte_identical':True,'canonical_source_unchanged':True,'oracle_ranked_calls_each':80,'oracle_rankings_are_permutations':True,'no_unproved_property_accepted':True})
print('Original 5 declarations unchanged; helper-only model prefix unchanged; observer erasure checked; both diagnostic rankings preserve every goal')
