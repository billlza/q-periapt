from pathlib import Path
import hashlib
import json
import zipfile
import subprocess

root = Path.cwd()
out = root / 'target/independent-control-hosted-a676-mac-01'
folder = root / 'research/sdk-alpha1/evidence/20261018-hosted-independent-control-mac'
folder.mkdir(exist_ok=False)
def sha(data):
    return hashlib.sha256(data).hexdigest()

control = json.loads((out / 'CONTROL_READBACK.json').read_text())
regressions = json.loads((out / 'REGRESSION_READBACK.json').read_text())
artifact = json.loads((out / 'ARTIFACT.json').read_text())
job = json.loads((out / 'JOB.json').read_text())
assert control['source_files'] == regressions['source_files']
assert control['native_sha256'] == regressions['native_sha256']
entries = {n: (out / n).read_bytes() for n in ['CONTROL_READBACK.json', 'REGRESSION_READBACK.json',
    'ARTIFACT.json', 'JOB.json', 'mac-a676.zip', 'download.py', 'download.stdout', 'download.stderr',
    'review-control.py', 'review-control.stdout', 'review-control.stderr', 'review-regressions.py',
    'review-regressions.stdout', 'review-regressions.stderr', 'seal.py']}
for name in ['download.stderr', 'review-control.stderr', 'review-regressions.stderr']:
    assert not entries[name]
for name, expected in control['source_files'].items():
    data = subprocess.check_output(['git','show','a6760a651c19ae481510ff7e7c87a6a4a702718a:research/continuity-openssl-peer/'+name])
    assert sha(data) == expected
    entries['source/' + name] = data
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(entries.items())}
entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = folder / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        item = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        z.writestr(item, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(entries) and z.testzip() is None
    for name, item in manifest.items():
        data = z.read(name)
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
report = {'head': control['head'], 'run': job['run_id'], 'job': job['id'], 'job_conclusion': job['conclusion'],
          'artifact_id': artifact['id'], 'artifact_bytes': artifact['size_in_bytes'], 'artifact_digest': artifact['digest'],
          'artifact_members': 1884, 'control': control, 'regressions': regressions,
          'capture': {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())},
          'macOS_hosted': 'Completed success; Linux for the same commit was already independently reviewed.',
          'scope': 'Seven completed Apple Silicon runtime lanes at a6760a65; does not qualify later version-four resolution with public signature/transcript/PID/source/binary readback. No network carrier, scheduler energy, hardware power-loss, erasure or PCS proof claim.'}
(folder / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'native_sha256': control['native_sha256'], 'capture': report['capture']}))
