from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path(__file__).resolve().parent
main=base.parent.parent
names=('prepared','managed-policy-c-01','managed-policy-swift-01','managed-policy-kotlin-01','ordinary-policy-c-01','clippy-msrv','clippy-current')
runs={name:json.loads((base/name/'RESULT.json').read_text()) for name in names}
assert all(value['completed'] for value in runs.values())
red=json.loads((base/'red-old-admission/RESULT.json').read_text())
assert red['runs'][-1]['returncode']==101
assert 'configuration status 211' in (base/'red-old-admission/managed-configuration-c-debug.stderr').read_text()
assert 'EXPIRED_POLICY_PASS' in (base/'red-old-admission/managed-configuration-c-debug.stdout').read_text()
assert 'Ran 65 tests' in (base/'readers-full-git.stderr').read_text() and '\nOK\n' in (base/'readers-full-git.stderr').read_text()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()
assert 'SDK_SOURCE_READINESS_PASS' in (base/'source-gate.stdout').read_text() and head in (base/'source-gate.stdout').read_text()
consumer=Path(runs['prepared']['consumer'])
for source in (main/'bindings/c/ContinuityPackageConsumer/tests').rglob('*.rs'):
    assert source.read_bytes()==(consumer/source.relative_to(main/'bindings/c/ContinuityPackageConsumer')).read_bytes()
# Reused binaries are appropriate only while product sources stay unchanged.
changed=subprocess.check_output(['git','diff','--name-only','b241ca76',head],cwd=main,text=True).splitlines()
assert all(path.startswith(('artifact/','bindings/c/ContinuityPackageConsumer/tests/')) or path.endswith('/README.md') for path in changed)
profiles={}
for language,label in [('C','managed-policy-c-01'),('Swift','managed-policy-swift-01'),('Kotlin','managed-policy-kotlin-01')]:
    profiles[language]={}
    for profile in ('debug','release'):
        row=runs[label]['profiles'][profile]
        results={collector:row[collector] for collector in ('Serial','G1')} if language=='Kotlin' else {'default':row}
        profiles[language][profile]={}
        for collector,result in results.items():
            assert result['completed'] and result['policy_renewal_composition'] and result['real_clock_policy_expiry']
            assert result['credential_renewal_qualified'] is False and len(result['scenarios'])==4
            profiles[language][profile][collector]={k:result[k] for k in ('scenarios','expiry_observations','binaries','registry_lifetime_probes','gc_observations')}
output=main/'research/sdk-alpha1/evidence/20261011-managed-policy-expiry'
output.mkdir(parents=True,exist_ok=False)
files=[]
for name in (*names,'red-old-admission'):
    for path in (base/name).rglob('*'):
        if path.is_file():
            assert not path.is_symlink() and path.suffix not in ('.key','.redb','.dylib','.jar')
            files.append((path,name+'/'+path.relative_to(base/name).as_posix()))
for name in ('prepare.py','run-c-red.py','run-c.py','run-swift.py','run-kotlin.py','run-c-ordinary.py','run-clippy.py','seal-evidence.py','MAINTENANCE.json','reused-source-identity.json','readers.stdout','readers.stderr','readers-full-git.stdout','readers-full-git.stderr','source-gate.stdout','source-gate.stderr','ci.json'):
    files.append((base/name,name))
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for path,name in sorted(files,key=lambda pair:pair[1]):z.write(path,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
checks={'source_commit':head,'completed':True,'release_claim_eligible':False,
'scope':'Installed managed first registration, real-clock protocol-policy expiry and independently approved renewal during original-message recovery. C/Swift/Kotlin initiators, C receiver, same host and native engine.',
'identity':'Current Rust harness byte-matches the code commit; native archive remains 6d70c614 (no product code changed). Reuses previously qualified C and Swift installations, and final Kotlin client-03 Maven runtime distribution. This is component composition evidence, not a complete current distribution or release qualification.',
'native_archive':runs['prepared']['candidate_archive'],
'reused_source_identity':json.loads((base/'reused-source-identity.json').read_text()),
'validation':{'managed_scenarios':32,'ordinary_C_regression_scenarios':12,'readers_and_inventory_tests':65,'strict_Clippy':['1.90.0','1.98.1'],'source_gate':'passed','red':'Previous invocation builder omits registry and correctly receives 211 after real-clock expiry; current invocation preserves original registry and completes renewal.'},
'profiles':profiles,
'invariants':['Real signed first request precedes independent account association','Expired original policy cannot activate (104), while original request remains recoverable','Independent account and policy signatures authorize target policy; altered approval is refused (102)','Original registry is supplied during renewal, then original session/message is acknowledged','Receiver adopts the target before expiry; host deduplication preserves exactly one business effect','No weakening of registry omission (211), close or ARC/Cleaner disposal (202) probes'],
'maintainability':json.loads((base/'MAINTENANCE.json').read_text()),
'limits':['Protocol-policy renewal only: installed managed credential renewal and SDK policy replacement remain separate','No independent protocol implementation, cross-host, physical-device or complete account replacement claim','No new throughput, RSS or energy measurements','JDK 25 Serial/G1 with bounded heap, not all-JVM Cleaner scheduling guarantees','Initial inventory run from linked worktree correctly refused its .git file; all 65 tests then passed in a full Git checkout without changing the gate'],
'ci':json.loads((base/'ci.json').read_text()),
'capture':{'file':'CAPTURE.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)}}
(output/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'completed':True,'capture':checks['capture']}))
