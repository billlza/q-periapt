from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
sys.path.insert(0, str(repo / 'artifact'))
from android_runtime_control import Control

sha = lambda b: hashlib.sha256(b).hexdigest()
payloads = {}
observations = {}
artifacts = json.loads((root / 'ARTIFACTS.json').read_text())['artifacts']
metadata = {a['name']: a for a in artifacts}
for name, artifact_name in [('framework', 'android-framework-instrumentation-control'),
                            ('file-copy', 'android-runtime-no-sdk-control')]:
    path = root / (name + '.zip')
    info = metadata[artifact_name]
    assert path.stat().st_size == info['size_in_bytes']
    assert 'sha256:' + sha(path.read_bytes()) == info['digest']
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        result = json.loads(archive.read('RESULT.json'))
        assert result['source_commit'] == '4b1e975caa6018c7d065c99b24da5ad62b0e2d0a'
        assert result['sdk_workload_executed'] is False
        assert result['completed'] is False
        console = archive.read('guest-logcat.log')
        crashes = [{'line': number, 'text': line} for number, line in
                   enumerate(console.decode().splitlines(), 1)
                   if re.search(r'Fatal signal[^\n]*\(system_server\)', line)]
        # Reprocess the actual retained console with the corrected final parser.
        with tempfile.TemporaryDirectory() as directory:
            obj = Control.__new__(Control)
            obj.output = Path(directory)
            obj.children = []  # Archived logs have no live producer.
            obj.result = {'system_crash_observed': result.get('system_crash_observed', False)}
            (obj.output / 'guest-logcat.log').write_bytes(console)
            obj.retain_console_observation()
            assert obj.result['system_crash_observed'] is True
            assert obj.result['observations_clean'] is False
            assert obj.result['guest_console_observation']['complete'] is True
            parsed = obj.result
        transfers = [{k: command[k] for k in ('label', 'capture_method', 'started_utc',
                     'returncode', 'timed_out', 'stdout_bytes', 'stdout_sha256')}
                     for command in result['commands'] if command['label'].endswith('-transfer')]
        for transfer in transfers:
            assert transfer['returncode'] == 0 and not transfer['timed_out']
            assert transfer['stdout_bytes'] == result['guest_file_size']
            assert transfer['stdout_sha256'] == result['guest_file_sha256']
        observations[name] = dict(artifact=info['id'], bytes=path.stat().st_size,
            sha256=sha(path.read_bytes()), failure=result['failure'],
            boot_observed_utc=result['boot_observed_utc'],
            system_server_crashes=crashes, completed_samples=len(result['samples']),
            transfers=transfers, archived_console_reprocessed=parsed)
        for item in archive.infolist():
            # Keep diagnostic text, not copied platform ELF files or the APK.
            if item.filename.endswith(('.json', '.log', '.ini', '.stderr')) or (
                item.filename.endswith('.stdout') and not item.filename.endswith('-transfer.stdout')):
                payloads[name + '/' + item.filename] = archive.read(item)
assert len(observations['framework']['system_server_crashes']) == 2
assert len(observations['file-copy']['system_server_crashes']) == 1
assert len(observations['file-copy']['transfers']) == 5

for name in ['RUN.json', 'JOBS.json', 'ARTIFACTS.json', 'seal.py',
             'regression-red.stdout', 'regression-red.stderr',
             'regression-green.stdout', 'regression-green.stderr',
             'regression-final.stdout', 'regression-final.stderr']:
    payloads[name] = (root / name).read_bytes()
payloads['CONSOLE_OBSERVATIONS.json'] = (json.dumps(observations, indent=2) + '\n').encode()
patch = subprocess.check_output(['git', 'diff', '--', 'artifact/android_runtime_control.py',
    'artifact/android_instrumentation_control.py', 'artifact/test_android_runtime_control.py'], cwd=repo)
payloads['DIAGNOSTIC_FIX.patch'] = patch
report = dict(
    source_commit='4b1e975caa6018c7d065c99b24da5ad62b0e2d0a', run=38049944494,
    url='https://github.com/billlza/q-periapt/actions/runs/38049944494',
    remote_conclusion='failure', release_claim_eligible=False,
    observations=observations,
    conclusions=[
        'Both fresh emulator controls fail without executing the SDK. The framework group crashes twice, including before boot acknowledgement and before its attempted APK install; no instrumentation invocation ran.',
        'The file-copy group completes two direct/bounded pairs and one further direct read, all 14967936 bytes with the expected guest SHA-256. It stops on the subsequent missing system_server PID after a recorded SIGSEGV. No truncated read was observed in these five transfers.',
        'The complete guest console establishes crashes that later ADB log snapshots miss. The corrected controller checks the final console for both workloads, preserves prior failures, and treats unavailable or over-limit diagnostics as failure.',
        'This isolates a no-SDK platform/control failure. It does not identify the emulator crash root cause, establish that earlier APK truncation had the same cause, or exonerate every SDK/native path.',
    ],
    validation={
        'command': "QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 sh artifact/python-run.sh -m unittest discover -s artifact -p 'test_android*control.py'",
        'red': '20 tests: two failures and one error for the absent final-console contract; the earlier-crash preservation case already passes.',
        'green_initial': '20 tests passed.',
        'green_final': '21 tests passed, including refusal to call a live producer console complete.',
        'actual_failed_artifacts_reprocessed': True,
        'new_controller_remote_execution': False,
    },
    limits=['The five successful copies are not the planned 24-copy clean observation.',
            'Neither observation is Android SDK/16KiB qualification or physical-device evidence.',
            'No GC/image/CPU/memory setting was changed and no failure was retried into success.'],
    primary_context=[{
        'url': 'https://android-developers.googleblog.com/2024/08/adding-16-kb-page-size-to-android.html',
        'scope': 'Google describes x86_64 ps16k as application-side 16KiB alignment emulation over a 4KiB kernel. This is platform context, not a diagnosis for the recorded crashes.'}],
    retention='Complete upstream ZIPs remain under target after byte/hash/CRC checks. Selected diagnostic text, exact source patch, test logs and metadata are retained here; platform ELF and APK payloads are excluded.')
out = repo / 'research/sdk-alpha1/evidence/20261010-android-no-sdk-crashes'
out.mkdir(exist_ok=True)
with zipfile.ZipFile(out / 'CAPTURE.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payloads.items()):
        archive.writestr(name, data)
capture = out / 'CAPTURE.zip'
report['capture'] = dict(file='CAPTURE.zip', bytes=capture.stat().st_size,
    sha256=sha(capture.read_bytes()), members={name: sha(data) for name, data in sorted(payloads.items())})
(out / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'capture_bytes': report['capture']['bytes'], 'members': len(payloads),
    'capture_sha256': report['capture']['sha256'], 'reprocessed_crashes': 3}))
