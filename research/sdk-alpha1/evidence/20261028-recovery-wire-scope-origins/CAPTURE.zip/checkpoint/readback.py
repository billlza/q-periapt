from pathlib import Path
import hashlib
import json
import re
import runpy

root = Path.cwd()
stage = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline_path = root / 'target/p0-static-key-source-replay-703/static-key-replay-proof.spthy'
baseline = baseline_path.read_text()
assert sha(baseline.encode()) == '259264abd13b7cc76d9a1d946beeeed7f4cda9f025b510d861e09c809ba9fc80'
prefix = lambda text: text.split('lemma ', 1)[0]
pattern = r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)\s*"([^"]*)"'
def queries(text):
    return {name: (' '.join(attrs.split()), mode, ' '.join(formula.split()))
            for name, attrs, mode, formula in re.findall(pattern, text)}
def section(text, name):
    return re.search(r'(?ms)^lemma ' + re.escape(name) + r'\b.*?(?=^lemma |^end$)', text)[0]
def normalized(text):
    return re.sub(r'\s+', ' ', re.sub(r'/\*.*?\*/', '', text, flags=re.S)).strip()

original = queries(baseline)
assert len(original) == 27
selected = {
    'reservations_inherit_locally_confirmed_root': 14,
    'generation_and_session_identifiers_are_distinct': 1,
    'signed_wire_scope_has_session_and_parent_origin': 47,
}
experiments = []
for folder_name, label, code, accepted in (
    ('p0-reservation-origin-704', 'reservation-origin', 0, True),
    ('p0-wire-scope-origin-704', 'wire-scope-origin', 1, False),
    ('p0-wire-scope-origin-704-02', 'wire-scope-origin', 0, False),
    ('p0-wire-scope-origin-704-03', 'wire-scope-origin', 0, False),
    ('p0-wire-scope-origin-704-04', 'wire-scope-origin', 0, True),
    ('p0-wire-scope-replay-704', 'wire-scope-replay', 0, True),
):
    folder = root / 'target' / folder_name
    terminal = json.loads((folder / (label + '-TERMINAL.json')).read_text())
    source = (folder / 'model.spthy').read_bytes()
    assert sha(source) == terminal['input_sha256']
    assert prefix(source.decode()) == prefix(baseline)
    assert terminal['returncode'] == code and terminal['accepted'] is accepted
    assert not terminal['timed_out'] and not terminal['output_exceeded']
    assert '-M12G' in terminal['argv'] and '-N1' in terminal['argv']
    if 'replay' not in folder_name:
        assert '--bound=16' in terminal['argv']
    else:
        assert not any(a.startswith(('--prove', '--oracle', '--oraclename')) for a in terminal['argv'])
    parsed = queries(source.decode())
    assert all(parsed[name] == value for name, value in original.items())
    if folder_name.endswith('-02') or folder_name.endswith('-03') or folder_name.endswith('-04'):
        assert terminal['input_sha256'] == '06b6ae4ef8561fa0de188e30f683f8cf40cd5004d3454b8102e161afa95ab827'
    if terminal['output_sha256'] is not None:
        proof = (folder / (label + '-proof.spthy')).read_text()
        assert sha(proof.encode()) == terminal['output_sha256']
        assert prefix(proof) == prefix(baseline)
        current = queries(proof)
        assert all(current[name] == value for name, value in original.items())
        assert normalized(section(proof, 'epoch_generation_secret_derivation_origin')) == normalized(section(baseline, 'epoch_generation_secret_derivation_origin'))
        assert terminal['results']['epoch_generation_secret_derivation_origin'] == {'mode': 'all-traces', 'status': 'analysis incomplete', 'steps': 197}
        assert terminal['results']['initial_epoch_traffic_advances_counter_is_executable'] == {'mode': 'exists-trace', 'status': 'verified', 'steps': 414}
    else:
        assert folder_name == 'p0-wire-scope-origin-704'
        assert 'Formula guardedness' in (folder / (label + '.stdout')).read_text()
        assert not terminal['results']

    checked_frames = []
    if (folder / 'initial-send-oracle.py').exists():
        frames = [json.loads(p.read_text()) for p in sorted((folder / 'initial-send-oracle-frames').glob('*.json'))]
        parts = (folder / (label + '.stderr')).read_text().split('>>>>>>>>>>>>>>>>>>>>>>>> START INPUT\n')[1:]
        assert len(parts) == len(frames)
        rank = runpy.run_path(str(folder / 'initial-send-oracle.py'))['rank']
        for index, (frame, part) in enumerate(zip(frames, parts, strict=True)):
            incoming, outgoing = part.split('>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT\n', 1)
            candidates = [x for x in {incoming, incoming.removesuffix('\n')} if sha(x.encode()) == frame['input_sha256']]
            assert len(candidates) == 1
            raw = candidates[0]
            goals, expected = rank(raw)
            observed = [int(s) for s in outgoing.split('>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call', 1)[0].split()]
            assert not frame['diagnostic_stop']
            assert observed == expected == frame['ranking']
            assert sorted(observed) == sorted(frame['goal_numbers']) == sorted(n for n, _ in goals)
            assert len(raw) == frame['input_characters'] and len(raw.encode()) == frame['input_bytes']
            checked_frames.append({'index': index, 'input_sha256': frame['input_sha256'], 'ranking': observed})
        assert len(frames) == (26 if folder_name.endswith('-03') else 27)
    experiments.append({'stage': folder_name, 'terminal': terminal, 'oracle_frames': checked_frames})

search = root / 'target/p0-wire-scope-origin-704-04/wire-scope-origin-proof.spthy'
replay = root / 'target/p0-wire-scope-replay-704/wire-scope-replay-proof.spthy'
search_text, replay_text = search.read_text(), replay.read_text()
assert queries(search_text) == queries(replay_text) and len(queries(replay_text)) == 29
for name, count in selected.items():
    for record in experiments[-2:]:
        assert record['terminal']['results'][name] == {'mode': 'all-traces', 'status': 'verified', 'steps': count}
    a, b = section(search_text, name), section(replay_text, name)
    assert normalized(a) == normalized(b)
    assert not re.search(r'\b(?:sorry|invalid)\b', a)
assert sum(row['mode'] == 'all-traces' and row['status'] == 'verified'
           for row in experiments[-1]['terminal']['results'].values()) == 14

result = {
    'verified': True, 'operational_prefix_sha256': sha(prefix(baseline).encode()),
    'original_queries_and_attributes_unchanged': 27, 'final_query_count': 29,
    'new_completed_obligations': selected, 'independent_all_trace_lemmas_verified': 14,
    'initial_traffic_witness_steps': 414, 'unchanged_origin_partial_steps': 197,
    'oracle_frames_checked': 53, 'oracle_stops': 0, 'experiments': experiments,
    'independent_certificate_sha256': sha(replay.read_bytes()),
    'interpretation': 'Existing RootBefore inheritance is now proved in the initial-traffic model. Two additional derived obligations prove fresh session/key separation and all emitted signed-envelope scope/session/hash-parent shape. Initial unguarded formula, default99step and static-priority33step incomplete attempts retained. Branch-local guarded reformulation is logically equivalent; no rule or threat changed. Final source ordering reaches a47step proof at unchanged totaldepth16 from a fresh helper root. Independent replay verifies14all-trace helpers plus414step initial traffic. These new helpers have not yet been moved ahead of or used to close the197step generation-origin conjecture.',
    'main_origin_complete': False, 'multi_epoch_secrecy_complete': False,
    'sdk_correspondence_complete': False, 'release_claim_eligible': False,
}
destination = stage / 'EXPERIMENTS.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'path': str(destination), 'sha256': sha(destination.read_bytes()), 'obligations': selected}))
