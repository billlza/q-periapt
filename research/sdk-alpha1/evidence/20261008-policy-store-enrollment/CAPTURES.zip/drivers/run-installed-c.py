from pathlib import Path
import os,sys,subprocess,json,hashlib,tempfile,tarfile,shutil,shlex,time
base=Path(__file__).resolve().parent;repo=base.parents[1];out=base/sys.argv[1];out.mkdir(mode=0o700)
producer=json.loads((base/'c-package-01/RESULT.json').read_text());assert producer['returncode']==0 and producer['clean_source_after'] and producer['head_unchanged']
bundle=repo/'target/policy-recovery-ffi-current/source/target/policy-enrollment-c-package-01/q-periapt-c-abi2-0.2.0-aarch64-apple-darwin.tar.gz'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
archive_sha=sha(bundle);driver=base/'enrollment_consumer.c';driver_sha=sha(driver)
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','PKG_CONFIG','RUST','CARGO_','QPERIAPT_','QPC_','PYTHON'))};env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
record={'producer_head':producer['head'],'archive_sha256':archive_sha,'driver_sha256':driver_sha,'outside_checkout':True,'runs':[]}
def run(label,cmd,cwd,environment=env):
 start=time.monotonic();r=subprocess.run(cmd,cwd=cwd,env=environment,capture_output=True,timeout=60);so=out/(label+'.stdout');se=out/(label+'.stderr');so.write_bytes(r.stdout);se.write_bytes(r.stderr);e={'label':label,'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(so),'stderr_sha256':sha(se)};record['runs'].append(e);(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(e),flush=True)
 if r.returncode:print(r.stderr.decode(),flush=True)
 r.check_returncode();assert b'warning:' not in r.stderr.lower();return r.stdout.decode()
with tempfile.TemporaryDirectory(prefix='qperiapt-enrollment-installed-',dir='/private/tmp') as folder:
 tmp=Path(folder);unpack=tmp/'unpack';unpack.mkdir()
 with tarfile.open(bundle) as archive:archive.extractall(unpack,filter='data')
 native=unpack/'q-periapt-c-abi2-0.2.0-aarch64-apple-darwin';assert native.is_dir()
 record['static_sha256']=sha(native/'lib/libq_periapt_ffi_abi2.a');record['dylib_sha256']=sha(native/'lib/libq_periapt_ffi.2.dylib');record['header_sha256']=sha(native/'include/qperiapt/abi2/q_periapt.h')
 shutil.copyfile(driver,tmp/'enrollment_consumer.c');shutil.copyfile(base/'c-source-01/recovery_fixture.h',tmp/'recovery_fixture.h')
 package_env={**env,'PKG_CONFIG_LIBDIR':str(native/'lib/pkgconfig'),'PKG_CONFIG_PATH':str(native/'lib/pkgconfig')}
 for mode in ['shared','static']:
  package='qperiapt-abi2-static' if mode=='static' else 'qperiapt-abi2';flags=shlex.split(run('pkg-config-'+mode,['/opt/homebrew/bin/pkg-config','--cflags','--libs',package],tmp,package_env));exe=tmp/('enrollment-'+mode)
  run('compile-'+mode,['/usr/bin/clang','-std=c11','-Wall','-Wextra','-Wpedantic','-Werror',str(tmp/'enrollment_consumer.c'),*flags,'-Wl,-rpath,'+str(native/'lib'),'-o',str(exe)],tmp)
  linked=run('link-'+mode,['/usr/bin/otool','-L',str(exe)],tmp);assert ('libq_periapt_ffi.2.dylib' in linked)==(mode=='shared')
  store=tmp/('store-'+mode);store.mkdir(mode=0o700)
  assert run('execute-'+mode,[str(exe),str(store/'policy.redb')],tmp).strip()=='SDK_POLICY_ENROLLMENT_C_PASS'
assert sha(bundle)==archive_sha and sha(driver)==driver_sha
record['passed']=True;(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
