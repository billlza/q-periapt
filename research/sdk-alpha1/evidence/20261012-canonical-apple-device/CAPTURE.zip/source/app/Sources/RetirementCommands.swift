import Foundation
import Darwin
import QPeriaptContinuity

func cutIOS<T: AnyObject>(_ owner: T, report: [UInt8], output: String,
                    mode: String, profile: String, run: String) throws -> Never {
    try durableIOS(report,output)
    let marker="QPC_IOS_REPLACEMENT_CUT mode=\(mode) profile=\(profile) run=\(run)\n"
    let receipt=(output as NSString).deletingLastPathComponent + "/receipt-" + run + ".txt"
    try durableIOS(Array(marker.utf8),receipt)
    try FileHandle.standardOutput.write(contentsOf:Data(marker.utf8))
    withExtendedLifetime(owner) { _exit(77) }
}
func retiredOperation(_ input: ReplacementInputs, mode: String, profile: String, output: String, run: String) throws {
    let authority = try RetiredEnrollmentAuthority(witness:input.fixed("witness-id",32),publicKey:input.fixed("witness-public",1985),
        replacement:input.read("retirement-proposal"),subject:input.fixed("witness-subject",96),receipt:input.fixed("retirement-receipt",3754))
    let owner = try ContinuityRetiredEnrollment.prepareOpen(path:input.path,intent:input.intent(),authority:authority)
    func receipt(_ name: String) throws -> [UInt8] { try input.read("retirement-"+name) }
    func identifier() throws -> [UInt8] { Array(try input.fixed("retirement-report-proposal",353).suffix(32)) }
    func recorded() throws -> [UInt8] { try load(URL(fileURLWithPath:input.path),"retirement-host-report",8388608) }
    func prepareAck(_ record: [UInt8]) throws -> RetiredReportProposal {
        let proposal = try owner.prepareAcknowledgement(inventoryReceipt:receipt("inventory-receipt"),reportReceipt:receipt("report-receipt"),recordedReport:record)
        try requireIOS(proposal.bytes == receipt("report-proposal"),"original acknowledgement proposal")
        try requireIOS(owner.acknowledgementProposal() == proposal,"acknowledgement readback")
        return proposal
    }
    let outcome = Result {
        try owner.finishOpen()
        switch mode {
        case "retired-owned-inventory":
            let inventory = try owner.inventory()
            do { _ = try owner.prepareReport(inventoryReceipt:[UInt8](repeating:0,count:3689)); throw ClientError("short receipt admitted") }
            catch ContinuityBoundaryError.inputLength { }
            try requireIOS(owner.inventory() == inventory,"preflight changed inventory")
            try expect(101) { _ = try owner.prepareReport(inventoryReceipt:[UInt8](repeating:0,count:3690)) }
            try expect(2) { _ = try owner.inventory() }; return inventory.bytes
        case "retired-owned-cancelled":
            try owner.cancel(); try expect(302) { _ = try owner.inventory() }; return bigNumber(UInt32(302))
        case "retired-owned-prepare-report":
            let proposal = try owner.prepareReport(inventoryReceipt:receipt("inventory-receipt"))
            try requireIOS(owner.reportProposal() == proposal,"report proposal readback"); return proposal.bytes
        case "retired-owned-report-unknown":
            let report = try owner.loadReport(inventoryReceipt:receipt("inventory-receipt"),reportReceipt:receipt("report-receipt"))
            try requireIOS(report.report.bytes == identifier(),"original report identity")
            try durableIOS(report.canonicalBytes,input.path+"/retirement-host-report")
            try cutIOS(owner,report:report.report.bytes,output:output,mode:mode,profile:profile,run:run)
        case "retired-owned-report-reopen":
            let report = try owner.loadReport(inventoryReceipt:receipt("inventory-receipt"),reportReceipt:receipt("report-receipt"))
            try requireIOS(report.canonicalBytes == recorded() && report.report.bytes == identifier(),"report changed after cut")
            return report.report.bytes + bigNumber(report.viewCount) + report.canonicalBytes
        case "retired-owned-ack-tampered":
            var value = try recorded(); value[value.count-1] ^= 1
            try expect(208) { _ = try owner.prepareAcknowledgement(inventoryReceipt:receipt("inventory-receipt"),reportReceipt:receipt("report-receipt"),recordedReport:value) }
            try expect(2) { _ = try owner.inventory() }; return bigNumber(UInt32(208))
        case "retired-owned-prepare-ack":
            try requireIOS(owner.acknowledgementProposal() == nil,"unexpected local ACK")
            return try prepareAck(recorded()).bytes
        case "retired-owned-erase-wrong-purpose":
            try expect(102) { try owner.eraseJournal(hostAcknowledgement:receipt("report-receipt")) }
            try expect(2) { _ = try owner.journalState() }; return bigNumber(UInt32(102))
        case "retired-owned-journal-unknown":
            try requireIOS(owner.journalState() == .retained,"journal erased before ACK")
            try owner.eraseJournal(hostAcknowledgement:receipt("ack"))
            try cutIOS(owner,report:identifier(),output:output,mode:mode,profile:profile,run:run)
        case "retired-owned-signer-unknown":
            try requireIOS(owner.journalState() == .erased,"journal terminal absent")
            try owner.prepareSignerErasure(hostAcknowledgement:receipt("ack"))
            try requireIOS(owner.signerState() == .retained,"signer already erased")
            try owner.eraseSigner()
            try cutIOS(owner,report:identifier(),output:output,mode:mode,profile:profile,run:run)
        case "retired-owned-verify":
            _ = try prepareAck(recorded())
            try requireIOS(owner.journalState() == .erased && owner.signerState() == .erased,"retirement terminal absent")
            try owner.eraseSigner(); try expect(2) { _ = try owner.signerState() }; return try recorded()
        default: throw ClientError("unknown retirement operation")
        }
    }
    do { try owner.close() } catch { throw ClientError("retired close \(error); operation \(outcome)") }
    try durableIOS(outcome.get(),output)
}
