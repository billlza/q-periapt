import Foundation
import QPeriaptContinuity

func rootCleanup(_ c:RootContext,root:ContinuityAccountAuthority) throws -> [UInt8] {
    let i=c.input
    func recorded() throws -> [UInt8] { try load(URL(fileURLWithPath:i.path),"root-host-report",8388608) }
    switch c.mode {
    case "root-inventory": return try root.retiredInventory().bytes
    case "root-prepare-report": return try root.prepareRetiredReport(inventoryReceipt:i.read("root-inventory-receipt")).bytes
    case "root-report-unknown":
        let report=try root.loadRetiredReport(inventoryReceipt:i.read("root-inventory-receipt"),reportReceipt:i.read("root-report-receipt"))
        try durableIOS(report.canonicalBytes,i.path+"/root-host-report")
        try c.cut(root,i.fixed("root-report-proposal",353))
    case "root-report-reopen":
        let report=try root.loadRetiredReport(inventoryReceipt:i.read("root-inventory-receipt"),reportReceipt:i.read("root-report-receipt"))
        try requireIOS(report.canonicalBytes == recorded(),"root report changed");return report.canonicalBytes
    case "root-prepare-ack":
        let proposal=try root.prepareRetiredAcknowledgement(inventoryReceipt:i.read("root-inventory-receipt"),reportReceipt:i.read("root-report-receipt"),recordedReport:recorded())
        try requireIOS(proposal.bytes == i.fixed("root-report-proposal",353),"root report ACK changed");return proposal.bytes
    case "root-journal-unknown":
        try root.eraseRetiredJournal(hostAcknowledgement:i.read("root-ack"));try c.cut(root,i.fixed("root-report-proposal",353))
    case "root-signer-unknown":
        try root.prepareRetiredSignerErasure(hostAcknowledgement:i.read("root-ack"));try root.eraseRetiredSigner()
        try requireIOS(root.rootReplacementState() == .committed,"signer erasure consumed root controller")
        try c.cut(root,i.fixed("root-report-proposal",353))
    case "root-verify":
        try requireIOS(root.retiredJournalState() == .erased && root.retiredSignerState() == .erased,"root cleanup terminal")
        return try recorded()
    default: throw ClientError("unknown root cleanup mode")
    }
}
