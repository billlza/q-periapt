// SPDX-License-Identifier: Apache-2.0 OR MIT
import QPeriaptContinuity

func credentialIdentity(_ owner: ContinuityEnrollment) throws -> [UInt8] {
    let status = try owner.status()
    guard let journal = status.journal else { throw ClientError("credential renewal requires the original journal") }
    return status.signingID.bytes + journal.bytes
}
