import Foundation
import QPeriaptContinuity

private final class RootLease {
    let value: ContinuityAccountAuthority
    private var closed = false
    init(_ value: ContinuityAccountAuthority) { self.value = value }
    func close() throws {
        guard !closed else { return }
        closed = true
        try value.close()
    }
}

final class RootContext {
    let input: ReplacementInputs, profile: String, mode: String, output: String, run: String
    private var registry: RootLease?
    var disposals: [() throws -> Void] = []
    init(_ args:[String]) {
        mode=args[1]; profile=args[2]; input=ReplacementInputs(source:URL(fileURLWithPath:args[3]),path:args[4]); output=args[5]; run=args[6]
    }
    func scope() throws -> RootReplacementScope { try RootReplacementScope(checkpoint:input.checkpoint(),witness:input.fixed("witness-id",32),publicKey:input.fixed("witness-public",1985)) }
    func plan() throws -> RootReplacementPlan { try RootReplacementPlan(approvedBytes:input.read("root-plan",131072)) }
    func transition() throws -> RootReplacementTransition {
        try RootReplacementTransition(original:plan(),independentlyApprovedNext:RootReplacementPlan(approvedBytes:input.read("root-next-plan",131072)),noncommitReceipt:input.fixed("root-noncommit",3449),freezeReceipt:input.read("root-freeze",131072))
    }
    func adoption() throws -> RootReplacementAdoption {
        try RootReplacementAdoption(original:plan(),independentlyApprovedWinner:RootReplacementProposal(approvedBytes:input.read("root-winner")),noncommitReceipt:input.fixed("root-noncommit",3449),retirementReceipt:input.fixed("root-retirement",3449))
    }
    func controller() throws -> ContinuityAccountAuthority {
        let value=try ContinuityAccountAuthority.prepareOpen(path:input.registryPath,trust:input.registryTrust())
        let lease = RootLease(value); registry = lease
        disposals.append { try lease.close() };try value.finishOpen();return value
    }
    func closeController() throws {
        guard let registry else { throw ClientError("missing original registry lease") }
        try registry.close()
    }
    func enrollment(_ selected:ReplacementInputs,create:Bool=false) throws -> ContinuityEnrollment {
        let configuration=create ? try ContinuityConfiguration.prepareCreate(path:selected.path,input:initial(selected.source,profile=="recoverable")) :
            try ContinuityConfiguration.prepareOpen(path:selected.path,trust:trust(selected.source,profile=="recoverable"),protocolPolicy:policy(selected.source))
        disposals.append { try configuration.close() };try configuration.finishOpen()
        let witness=try witness(input.source,"signed",wrong:false)
        let value=create ? try configuration.createEnrollment(intent:selected.intent(),witness:witness) : try configuration.resumeEnrollment(intent:selected.intent(),witness:witness)
        disposals.append { try value.close() };return value
    }
    func target(_ original:Bool=false) -> ReplacementInputs {
        let name=original ? "root-original-target" : "root-target"
        return ReplacementInputs(source:input.source.appendingPathComponent(name),path:input.path+"."+name)
    }
    func successor(_ root:ContinuityAccountAuthority) throws -> ContinuityDevice {
        let registration=try enrollment(target()),value=try root.activateRootSuccessor(registration)
        disposals.append { try value.close() };return value
    }
    func peer(_ device:ContinuityDevice,_ selected:ReplacementInputs) throws -> ContinuityOwner {
        let value=try device.preparePeerReopen(configuration:peerInput(selected.source),quality:.oneTimeBoth,role:.initiator,session:SessionID(bytes:selected.fixed("connection-session",32)))
        disposals.append { try value.close() };try value.finishOpen();return value
    }
    func status(_ peer:ContinuityOwner,_ selected:ReplacementInputs) throws -> MessageStatus {
        try peer.status(session:SessionID(bytes:selected.fixed("connection-session",32)),message:MessageID(bytes:selected.fixed("connection-message",32)))
    }
    func revoked(_ device:ContinuityDevice) throws {
        try expect(202) { _ = try peer(device,target()) }
    }
    func cut(_ root:ContinuityAccountAuthority,_ bytes:[UInt8]) throws -> Never {
        try cutIOS(root,report:bytes,output:output,mode:mode,profile:profile,run:run)
    }
    func resume(_ root:ContinuityAccountAuthority) throws {
        guard let route=String(bytes:try input.read("root-route",32),encoding:.utf8) else { throw ClientError("root route UTF-8") }
        let before=mode.hasPrefix("root-noncommit-") || ["root-cancel-preparing","root-state","root-freeze-bad","root-freeze-original","root-transition-unknown","root-adopt-unknown"].contains(mode)
        if before || route=="original" { try root.resumeRootReplacement(path:input.path,intent:input.intent(),scope:scope(),plan:plan()) }
        else if ["transition","bound-transition","noncommit"].contains(route) { try root.resumeRootTransition(path:input.path,intent:input.intent(),scope:scope(),approval:transition()) }
        else if route=="adoption" { try root.resumeRootAdoption(path:input.path,intent:input.intent(),scope:scope(),approval:adoption()) }
        else { throw ClientError("root recovery route") }
    }
}
