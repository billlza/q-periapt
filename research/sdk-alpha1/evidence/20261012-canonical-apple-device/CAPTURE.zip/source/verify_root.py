from pathlib import Path
import re
import continuity_android_root as roots
import rust_sdk_profile as sdk

def verify(stdout:bytes,cases:Path,route:str):
 sdk.require(route in roots.ROUTES,'unknown root route');text=stdout.decode()
 sdk.require(re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)==[roots.TESTS[route]],'wrong iOS root test')
 sdk.require(len(re.findall(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 29 filtered out;',text,re.M))==1,'incomplete iOS root workload')
 count,cuts=roots.ROUTES[route];expected={f'qualified iOS account-root {route} {p}: {count} Swift processes; {cuts} process cuts; original report, new root traffic and controller-close revocation' for p in ['fixed','recoverable']}
 markers=re.findall(r'^qualified .*$',text,re.M);sdk.require(set(markers)==expected and len(markers)==2,'iOS root markers')
 return {p:roots.verify_records(cases/('signed-'+p),p,route) for p in ['fixed','recoverable']}
