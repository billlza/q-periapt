from pathlib import Path
import json,subprocess,hashlib
import rust_sdk_profile as sdk
import continuity_apple_package as apple
from continuity_apple_consumer import verify_linkage
r=Path.cwd();o=r/'target/continuity-canonical-ipad-root';prepared=json.loads((o/'PREPARATION.json').read_text());outside=Path(prepared['outside']);consumer=outside/'consumer';installed=outside/'installed'/apple.NAME;header=(r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes()
inputs={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob('*') if p.is_file()}
state={'completed':False,'live_producer':True,'source_inputs':inputs,'package_sha256':prepared['package_sha256']};path=o/'BUILD_STATE.json';path.write_text(json.dumps(state,indent=2)+'\n')
try:
 apple.verify_package(installed,prepared['package_contents'],prepared['native'],header)
 with (o/'project.log').open('wb') as log:subprocess.run(['xcodegen','generate','--spec','project.json'],cwd=consumer,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (o/'build.log').open('wb') as log:
  result=subprocess.run(['xcodebuild','-project',str(consumer/'ContinuityIOS.xcodeproj'),'-scheme','ContinuityIOSRunner','-configuration','Release','-sdk','iphoneos','-destination','generic/platform=iOS','-derivedDataPath',str(outside/'build-device'),'LD_GENERATE_MAP_FILE=YES','LD_MAP_FILE_PATH='+str(outside/'consumer-$(TARGET_NAME)-LinkMap.txt'),'build'],stdout=log,stderr=subprocess.STDOUT)
 lines=(o/'build.log').read_text().splitlines();diagnostics=[x for x in lines if 'error:' in x or 'warning:' in x]
 for line in diagnostics:print(line)
 result.check_returncode();assert '** BUILD SUCCEEDED **' in lines and not diagnostics
 app=Path(json.loads((o/'APP.json').read_text())['app']);binary=app/'ContinuityIOSRunner';library=app.parent/apple.LIBRARY
 assert hashlib.sha256(library.read_bytes()).hexdigest()==prepared['native']['aarch64-apple-ios']['sha256']
 state['linkage']=verify_linkage(outside/'consumer-ContinuityIOSRunner-LinkMap.txt',library,binary)
 for name,h in inputs.items():assert hashlib.sha256((consumer/name).read_bytes()).hexdigest()==h,name
 apple.verify_package(installed,prepared['package_contents'],prepared['native'],header)
 state.update(completed=True,app_executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
 frozen={'package_sha256':prepared['package_sha256'],'app_sha256':state['app_executable_sha256'],'fixture_sha256':prepared['fixture_sha256'],'receiver_sha256':prepared['receiver_sha256'],'native_staticlib_sha256':prepared['native']['aarch64-apple-ios']['sha256'],'inputs':{n:hashlib.sha256((o/n).read_bytes()).hexdigest() for n in ['ios_client.py','device_support.py','usb_transport.py','run_device.py','verify_root.py']},'app_sources':inputs}
 (o/'FROZEN_INPUTS.json').write_text(json.dumps(frozen,indent=2)+'\n')
 print('Canonical archive physical consumer built and signed offline; linked native slice hash verified',flush=True)
finally:
 state['live_producer']=False;path.write_text(json.dumps(state,indent=2)+'\n')
