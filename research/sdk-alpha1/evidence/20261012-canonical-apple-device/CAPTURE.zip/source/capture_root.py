from pathlib import Path
import sys,json,hashlib,zipfile,tempfile,shutil,collections
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_root import verify,roots
r=Path.cwd();src=Path(__file__).resolve().parent;out=r/'research/sdk-alpha1/evidence/20261012-canonical-apple-device'
state=json.loads((src/'DEVICE_STATE.json').read_text());assert state['completed'] and not state['live_producer'] and not state['cleanup_armed'] and state['operations']==362 and state['cuts']==62
frozen=json.loads((src/'FROZEN_INPUTS.json').read_text())
for name,h in frozen['inputs'].items():assert hashlib.sha256((src/name).read_bytes()).hexdigest()==h,name
prepared=json.loads((src/'PREPARATION.json').read_text());outside=Path(prepared['outside']);consumer=outside/'consumer'
import continuity_apple_package as apple
from continuity_apple_consumer import verify_linkage
package=r/'target/continuity-apple-package-stable/QPeriaptContinuity-Apple-candidate.zip'
assert hashlib.sha256(package.read_bytes()).hexdigest()==frozen['package_sha256']==prepared['package_sha256']
installed=outside/'installed'/apple.NAME
apple.verify_package(installed,prepared['package_contents'],prepared['native'],(r/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes())
for name,h in frozen['app_sources'].items():assert hashlib.sha256((consumer/name).read_bytes()).hexdigest()==h,name
app=Path(json.loads((src/'APP.json').read_text())['app']);binary=app/'ContinuityIOSRunner';library=app.parent/apple.LIBRARY
assert hashlib.sha256(binary.read_bytes()).hexdigest()==frozen['app_sha256']==state['app_executable_sha256']
assert hashlib.sha256(library.read_bytes()).hexdigest()==frozen['native_staticlib_sha256']
fixture=Path(json.loads((src/'FIXTURE.json').read_text())['binary'])
assert hashlib.sha256(fixture.read_bytes()).hexdigest()==frozen['fixture_sha256']
assert hashlib.sha256((r/'target/continuity-local-policy-roster/engine-debug/qpc-c-client').read_bytes()).hexdigest()==frozen['receiver_sha256']
linkmap=outside/'consumer-ContinuityIOSRunner-LinkMap.txt'
assert verify_linkage(linkmap,library,binary)==json.loads((src/'BUILD_STATE.json').read_text())['linkage']
results=json.loads((src/'ROOT_CHECKS.json').read_text())
for route in roots.ROUTES:assert verify((src/('device-'+route+'.stdout')).read_bytes(),src/'device-public'/route,route)==results[route]
mutations=[('root-verified',lambda b:b[:-1]+bytes([b[-1]^1])),('root-close-revoked',lambda b:(0).to_bytes(4,'big')),('root-activation-unknown',lambda b:(0).to_bytes(4,'big')),('root-retained',lambda b:b[:-1]+bytes([b[-1]^1])),('root-acknowledged',lambda b:b[:-1]+bytes([b[-1]^1])),('root-effect-count',lambda b:(1).to_bytes(8,'big')),('root-original-effect-after',lambda b:b[:-1]+bytes([b[-1]^1])),('root-report-unknown.stdout',lambda b:b'passed\n')]
rejected=[];stdout=(src/'device-original.stdout').read_bytes()
for name,change in mutations:
 with tempfile.TemporaryDirectory() as t:
  p=Path(t)/'public';shutil.copytree(src/'device-public/original',p);f=p/'signed-fixed'/name;b=f.read_bytes();changed=change(b);assert changed!=b;f.write_bytes(changed)
  try:verify(stdout,p,'original')
  except ValueError:rejected.append(name)
  else:raise AssertionError('accepted altered root evidence '+name)
for raw in [stdout.replace(b'29 filtered out',b'28 filtered out'),stdout.replace(b'original_account_root_replacement ... ok',b'other_test ... ok')]:
 try:verify(raw,src/'device-public/original','original')
 except ValueError:rejected.append('native execution identity')
 else:raise AssertionError('accepted wrong native execution')
rows=[json.loads(p.read_text()) for p in (src/'device-execution').glob('*/RESULT.json')];assert len(rows)==362 and len({x['run'] for x in rows})==362 and len({x['case'] for x in rows})==10
streams=collections.Counter();modes=collections.Counter();cuts=0
for x in rows:
 p=src/'device-execution'/x['run'];cut=x['app_exit']==77;cuts+=cut;modes[x['mode']]+=1
 marker=f'QPC_IOS_REPLACEMENT_{"CUT" if cut else "PASS"} mode={x["mode"]} profile={x["profile"]} run={x["run"]}\n'.encode()
 assert (p/'receipt.txt').read_bytes()==marker and (p/'launch.stderr').read_bytes()==b''
 lines=(p/'launch.stdout').read_bytes().splitlines();assert lines.count(marker.rstrip(b'\n'))==1 and lines.count(f'The app terminated with the exit code {x["app_exit"]}.'.encode())==1
 assert json.loads((p/'launch.status.json').read_text())['returncode']==x['app_exit']
 assert lines.count(f'QPC_IOS_READY run={x["run"]}'.encode())==1
 for command in ['inputs','admission','receipt-copy','result-copy']:
  assert json.loads((p/(command+'.status.json')).read_text())['returncode']==0
  assert (p/(command+'.stderr')).read_bytes()==b''
 assert (p/'USB_TRANSPORT.json').is_file()
 assert hashlib.sha256((p/'public-result.bin').read_bytes()).hexdigest()==x['public_result_sha256']
 if (p/'USB_TRANSPORT.json').exists():
  t=json.loads((p/'USB_TRANSPORT.json').read_text());assert t['completed'] and t['startup_admitted'];sequence=collections.Counter()
  for e in t['exchanges']:
   sequence[e['route']]+=1;assert e['index']==sequence[e['route']]<=64;streams[(e['route'],e['completed'])]+=1
   if not e['completed']:assert x['mode'] in {'root-peer-uncertain','roster-witness-peer-uncertain'} and e['route']=='peer' and e['remote_failure']=='connection_refused' and e['errno']==61
assert cuts==62 and streams[('peer',True)]==50 and streams[('peer',False)]==140 and streams[('witness',True)]==3340 and len(streams)==3
assert modes['policy-create']==modes['root-target-create']==10 and modes['root-original-target-create']==8
members={}
def add(name,path):
 if path.is_dir():
  for p in path.rglob('*'):
   if p.is_file() and not p.is_symlink():members[name+'/'+str(p.relative_to(path))]=p.read_bytes()
 else:members[name]=path.read_bytes()
for n in ['device-control','device-execution','device-public']:add('execution/'+n,src/n)
for n in ['DEVICE_STATE.json','FROZEN_INPUTS.json','ROOT_CHECKS.json','PREPARATION.json','BUILD_STATE.json','build.log','project.log']:add('execution/'+n,src/n)
for route in roots.ROUTES:
 for ext in ['json','stdout','stderr']:add('execution/device-'+route+'.'+ext,src/('device-'+route+'.'+ext))
add('source/app/Sources',consumer/'Sources')
for n in ['project.json','Info.plist']:add('source/app/'+n,consumer/n)
for n in ['ios_client.py','device_support.py','usb_transport.py','run_device.py','verify_root.py','build_app.py','capture_root.py']:add('source/'+n,src/n)
for n in ['continuity_android_root.py','continuity_android_contract.py','continuity_apple_package.py','continuity_apple_consumer.py','apple_sdk_profile.py','rust_sdk_profile.py']:add('source/artifact/'+n,r/'artifact'/n)
add('package/PACKAGE_CONTENTS.json',installed/'PACKAGE_CONTENTS.json')
add('package/app-link-map.txt',linkmap)
assert not any(Path(n).name in {'STATE.json','SIGNING.json','authority.key','tls-key','wrap.key','signer.key'} or n.endswith('.redb') for n in members)
out.mkdir();archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory() as t,zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(m)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in m.items());z.extractall(t)
 for route in roots.ROUTES:assert verify((Path(t)/('execution/device-'+route+'.stdout')).read_bytes(),Path(t)/'execution/device-public'/route,route)==results[route]
checks={'completed':True,'canonical_package_sha256':frozen['package_sha256'],'canonical_package_producer_evidence':'20261012-apple-package-producer','startup_admissions':362,'device':state['device_model'],'os':state['device_os'],'Swift_app_calls':362,'explicit_app_exit_77_cuts':62,'native_receiver_exit_77_cuts':20,'fresh_on_device_identities':28,'routes':list(roots.ROUTES),'fixed_and_recoverable_trust':True,'unknown_activation_refused':218,'controller_close_revokes_successor':202,'tampered_report_refused':208,'wrong_purpose_erasure_refused':102,'signed_noncommit_persists_closed':True,'cancellation_preserves_live_successor_until_close':True,'business_effects_per_case':2,'peer_TLS_exchanges':streams[('peer',True)],'witness_USB_streams':streams[('witness',True)],'observed_refused_reconnections':streams[('peer',False)],'negative_controls_rejected':len(rejected),'run_owned_app_removed':True,'source_before_after_equal':True,'private_device_keys_or_journals_exported':False,'native_staticlib_sha256':frozen['native_staticlib_sha256'],'app_executable_sha256':state['app_executable_sha256'],'fixture_sha256':frozen['fixture_sha256'],'receiver_sha256':frozen['receiver_sha256'],'archive_members':len(members),'all_archive_hashes_verified':True,'archived_public_records_reread':True,'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');(out/'PUBLIC_CHECKS.json').write_text(json.dumps({'rejected':rejected},indent=2)+'\n');print(json.dumps(checks,indent=2))
