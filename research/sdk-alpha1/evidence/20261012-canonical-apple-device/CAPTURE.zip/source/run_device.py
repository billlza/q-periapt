from pathlib import Path
import sys,json,hashlib,os
sys.path.insert(0,str(Path(__file__).resolve().parent))
from device_support import OUT,APP,BUNDLE,selected,command,installed
from verify_root import verify,roots
import rust_sdk_profile as sdk
r=Path.cwd();device=selected();fixture=json.loads((OUT/'FIXTURE.json').read_text());control=OUT/'device-control';control.mkdir()
if installed(device,control/'before'):raise RuntimeError('owned bundle already installed')
state={'completed':False,'live_producer':True,'cleanup_armed':True,'bundle_id':BUNDLE,'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'device_model':device['hardwareProperties']['marketingName'],'device_os':device['deviceProperties']['osVersionNumber'],'app_executable_sha256':hashlib.sha256((Path(APP['app'])/'ContinuityIOSRunner').read_bytes()).hexdigest(),'completed_routes':[]}
path=OUT/'DEVICE_STATE.json';path.write_text(json.dumps(state,indent=2)+'\n')
try:
 command(device,['device','install','app',APP['app']],control/'install',timeout=60)
 if not installed(device,control/'installed'):raise RuntimeError('installation not observed')
 results={};public=OUT/'device-public';public.mkdir();(OUT/'device-cases').mkdir(mode=0o700)
 for route in ["transition","original","bound-transition","adoption","noncommit"]:
  test=roots.TESTS[route]
  cases=OUT/'device-cases'/route;env=dict(os.environ,QPC_ANDROID_DRIVER=str(OUT/'ios_client.py'),QPC_ANDROID_CASES=str(cases),QPC_CONFIGURATION_RECEIVER=str(r/'target/continuity-local-policy-roster/engine-debug/qpc-c-client'))
  sdk.command([fixture['binary'],'--exact',test,'--nocapture'],OUT/('device-'+route),r,environment=env)
  result=verify((OUT/('device-'+route+'.stdout')).read_bytes(),cases,route)
  for profile,record in result.items():
   for name in record['public_readbacks']:sdk.copy(cases/('signed-'+profile)/name,public/route/('signed-'+profile)/name)
  assert verify((OUT/('device-'+route+'.stdout')).read_bytes(),public/route,route)==result
  results[route]=result;state['completed_routes'].append(route);path.write_text(json.dumps(state,indent=2)+'\n')
  print('iPad root route passed: '+route,flush=True)
 rows=[json.loads(p.read_text()) for p in (OUT/'device-execution').glob('*/RESULT.json')]
 assert len(rows)==362 and all(row['completed'] for row in rows) and sum(row['app_exit']==77 for row in rows)==62
 (OUT/'ROOT_CHECKS.json').write_text(json.dumps(results,indent=2)+'\n');state.update(completed=True,operations=362,cuts=62)
finally:
 state['live_producer']=False
 for attempt in range(6):
  if installed(device,control/f'cleanup-query-{attempt}'):command(device,['device','uninstall','app',BUNDLE],control/f'uninstall-{attempt}',allow_failure=True)
  else:state['cleanup_armed']=False;break
 path.write_text(json.dumps(state,indent=2)+'\n')
 if state['cleanup_armed']:raise RuntimeError('device cleanup unresolved')
print('Physical iPad five-route account-root lifecycle passed: 362 calls, 62 process cuts',flush=True)
