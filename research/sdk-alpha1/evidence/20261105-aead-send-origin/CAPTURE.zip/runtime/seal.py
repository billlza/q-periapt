from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-aead-send-origin'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-aead-send-origin'
COMMIT = '39d35880b7f5bff012f9a1b09588adebb3bd22dd'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
obj = lambda p: json.loads(p.read_bytes())

initial = obj(BASE / 'LAUNCH_RESULT.json')
final = obj(BASE / 'run-02/LAUNCH_RESULT.json')
result = obj(BASE / 'run-02/RESULT.json')
assert not initial['completed'] and initial['returncode'] == 1
assert final['completed'] and final['returncode'] == 0 and result['completed']
assert result['source_commit'] == COMMIT and result['selected_source_inputs_unchanged'] and result['tool_binaries_unchanged']
assert obj(BASE / 'INPUTS.json')['source_inputs'] == result['source_inputs']
for directory, launch in [(BASE, initial), (BASE / 'run-02', final)]:
    assert launch['timeout_seconds'] == 1800 and launch['component_timeout_seconds'] == 900
    assert sha((directory / 'run.py').read_bytes()) == launch['driver_sha256']
    assert sha((directory / 'launch.py').read_bytes()) == launch['launcher_sha256']
    for suffix in ['stdout', 'stderr']:
        assert sha((directory / ('driver.' + suffix)).read_bytes()) == launch[suffix + '_sha256']
assert "('fanout-reserved', '4')" in (BASE / 'run.py').read_text()
assert "('fanout-reserved', '2')" in (BASE / 'run-02/run.py').read_text()

sources = [
    'Cargo.toml', 'Cargo.lock', 'src/contract.rs', 'src/durable.rs',
    'src/durable/messages.rs', 'src/durable/messages/traffic.rs',
    'src/durable/messages/fanout.rs', 'src/durable/messages/fanout/codec.rs',
    'src/durable/messages/fanout/abandonment.rs', 'src/durable/messages/closure.rs',
    'src/durable/messages/terminal.rs', 'src/durable/messages/retired.rs',
    'src/durable/messages/resolution.rs', 'src/durable/messages/acknowledgement.rs',
    'src/durable/messages/rekey/completion.rs', 'src/durable/cancellation.rs',
    'src/durable/write_intent.rs', 'src/durable/messages/tests.rs',
    'src/durable/messages/tests/fanout.rs', 'src/durable/messages/tests/fanout/process.rs',
    'src/durable/messages/tests/fanout/abandonment.rs']
sources = ['research/continuity-identity-candidate/' + name for name in sources]
files = {}
source_manifest = {}
for name in sources:
    body = (ROOT / name).read_bytes()
    assert sha(body) == result['source_inputs']['files'][name], name
    files['source/' + name] = body
    source_manifest[name] = sha(body)


def source(name): return (ROOT / 'research/continuity-identity-candidate/src' / name).read_text()
def ordered(text, tokens):
    positions = []; start = 0
    for token in tokens:
        at = text.index(token, start); positions.append(at); start = at + len(token)
    return [{'token': token, 'byte_offset_in_selected_text': position} for token, position in zip(tokens, positions)]


messages = source('durable/messages.rs')
traffic = source('durable/messages/traffic.rs')
fanout = source('durable/messages/fanout.rs')
single = messages.split('pub async fn send_message(', 1)[1].split('pub async fn message_status(', 1)[0]
reserve = fanout.split('pub async fn send_account_message(', 1)[1].split('pub async fn resume_account_message(', 1)[0]
resume = fanout.split('pub async fn resume_account_message(', 1)[1].split('async fn replay_committed_fanout(', 1)[0]
send = traffic.split('fn send_input(', 1)[1].split('pub(super) fn receive(', 1)[0]
checks = {
    'individual_reserve_encrypt_commit_release': ordered(single, ['traffic.pending = Some(SendPlan', 'self.persist(&mut image).await?', '.send(id, plaintext, associated_data)?', 'self.persist(&mut image).await?', 'self.check_session_context_release', 'Ok(wire)']),
    'aggregate_reserve_before_resume': ordered(reserve, ['traffic.pending = Some(SendPlan', 'self.persist(&mut image).await?', 'self.resume_account_message']),
    'aggregate_compute_before_commit': ordered(resume, ['traffic.pending.as_ref()', 'traffic.send_reserved(member.message)?', 'batch.state = BatchState::Committed', 'self.persist(&mut image).await?', 'self.replay_committed_fanout']),
    'same_origin_check_before_encryption': ordered(send, ['plan.plaintext.as_slice() != plaintext || plan.ad != ad', 'step(&self.send, self.sent)?', '.encrypt_inout_detached(', '&Nonce::from([0; 12])', 'self.pending = None', 'self.send = next', 'self.sent += 1']),
    'cached_outbox_before_key_derivation': ordered(send, ['Entry::Occupied', 'Ok(saved.wire.as_slice())', 'step(&self.send, self.sent)?'])}
assert 'fn new(budget: u16, same_account: bool)' in source('durable/messages/tests/fanout.rs')
assert 'enrollment(40, if same_account { 3 } else { 2 }, policy.family())' in source('durable/messages/tests/fanout.rs')
assert 'pub const MESSAGE_DOMAIN: &[u8] = b"Q-PERIAPT-CONTINUITY-MESSAGES-CANDIDATE/v2/";' in source('contract.rs')
assert traffic.count('.encrypt_inout_detached(') == 1
production = [ROOT / 'research/continuity-identity-candidate/src/durable/messages.rs']
production += [p for p in (ROOT / 'research/continuity-identity-candidate/src/durable/messages').rglob('*.rs')
               if 'tests' not in p.relative_to(ROOT / 'research/continuity-identity-candidate/src/durable/messages').parts and p.name != 'tests.rs']
encrypt_sites = [p.relative_to(ROOT).as_posix() for p in production if '.encrypt_inout_detached(' in p.read_text()]
assert encrypt_sites == ['research/continuity-identity-candidate/src/durable/messages/traffic.rs']
executions = []
binaries = {}
for profile, records in result['profiles'].items():
    assert set(records) == {'single-sync', 'fanout-sync', 'fanout-process', 'unsafe-reset'}
    for label, record in records.items():
        reused = profile == 'debug' and label != 'unsafe-reset'
        assert record['reused_completed_test'] == reused
        directory = BASE if reused else BASE / 'run-02'
        stem = directory / (profile + '-' + label)
        receipt = obj(stem.with_suffix('.json'))
        stdout = stem.with_suffix('.stdout').read_bytes(); stderr = stem.with_suffix('.stderr').read_bytes()
        assert receipt['returncode'] == 0 and record['test'] in receipt['argv']
        assert sha(stdout) == record['stdout_sha256'] and sha(stderr) == record['stderr_sha256']
        assert stdout.decode().splitlines().count('test ' + record['test'] + ' ... ok') == 1
        assert re.findall(r'^test result: (.+)$', stdout.decode(), re.M) == [record['summary']]
        assert '1 passed; 0 failed; 0 ignored;' in record['summary']
        match = re.search(r'Running unittests src/lib.rs \(([^)]+)\)', stderr.decode()); assert match
        path = ROOT / match[1]
        with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        binary = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}
        if profile in binaries: assert binaries[profile] == binary
        binaries[profile] = binary
        executions.append({'profile': profile, 'case': label, 'receipt': stem.with_suffix('.json').relative_to(BASE).as_posix(), **record})
assert len(executions) == 8
audit = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': COMMIT,
    'source_files': source_manifest, 'source_anchor_checks': checks, 'message_encryption_sites': encrypt_sites,
    'message_header_bytes': 8 + 32 + 1 + 8 + 8 + 32 + 4, 'nonce_bytes': 12, 'tag_bytes': 16,
    'source_check_scope': 'Literal call-order anchors and production-module inventory for the manual invariant argument; not a machine-checked control-flow or cryptographic proof.',
    'test_executions': executions, 'test_binaries_read_back': binaries,
    'initial_outer_readback_failed': True, 'initial_elapsed_seconds': initial['elapsed_seconds'],
    'corrected_outer_readback_completed': True, 'corrected_elapsed_seconds': final['elapsed_seconds'],
    'completed_debug_test_commands_reused': 3, 'new_test_commands_in_completion': 5,
    'actual_recipients_in_process_fixture': 2, 'send_budget_in_process_fixture': 4,
    'process_kills_in_selected_cases': 8, 'power_loss_claimed': False,
    'product_or_test_source_changes': False, 'full_native_suite_rerun': False,
    'aead_security_or_multi_epoch_theorem_established': False, 'release_claim_eligible': False,
    'primary_reference': 'https://www.rfc-editor.org/rfc/rfc8439.html#section-4'}
for path in BASE.rglob('*'):
    if path.is_file():
        assert not path.is_symlink()
        files['runtime/' + path.relative_to(BASE).as_posix()] = path.read_bytes()
for name in ['docs/continuity/AEAD_SEND_ORIGIN_V1.md', 'docs/continuity/STORAGE_RECOVERY_V1.md']:
    files['documents/' + name] = (ROOT / name).read_bytes()
files['SOURCE_AUDIT.json'] = encode(audit)
files['FILES.json'] = encode({name: {'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('SOURCE_AUDIT.json', files['SOURCE_AUDIT.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
