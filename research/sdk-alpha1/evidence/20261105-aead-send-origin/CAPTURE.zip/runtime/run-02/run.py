from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import runpy
import sys
import continuity_package as package
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-aead-send-origin/run-02'
ORIGINAL = BASE.parent
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
BUILD = ROOT / 'target/continuity-aggregate-reservation-copy/build'
COMMIT = '39d35880b7f5bff012f9a1b09588adebb3bd22dd'
MANIFEST = 'research/continuity-identity-candidate/Cargo.toml'
TESTS = {
    'single-sync': 'durable::messages::tests::every_message_sync_failure_reconciles_without_early_output_or_replacement',
    'fanout-sync': 'durable::messages::tests::fanout::account_fanout_sync_faults_reconcile_all_members_together_at_every_measured_barrier',
    'fanout-process': 'durable::messages::tests::fanout::process::account_fanout_process_cuts_preserve_all_members_and_exclude_concurrent_writers',
    'unsafe-reset': 'durable::messages::tests::fanout::abandonment::account_fanout_unsafe_reservation_reset_reuses_the_actual_message_keystream'}


def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    with path.open('x') as stream: json.dump(data, stream, indent=2); stream.write('\n')


def main():
    assert ROOT == package.ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sdk.validate_no_registry_credentials(os.environ)
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    before = package.source_inputs(); tools = package.compiler_identity(CHAIN)
    assert sdk.command(['git', 'rev-parse', 'HEAD'], BASE / 'source-head', ROOT).decode().strip() == COMMIT
    assert sdk.command(['git', 'diff', '--name-only'], BASE / 'tracked-delta', ROOT) == b''
    assert json.loads((BUILD.parent / 'RESULT.json').read_bytes())['completed'] and BUILD.is_dir()
    environment = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    environment.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
        CARGO_TARGET_DIR=str(BUILD), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
        CARGO_TERM_COLOR='never', RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
        RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'),
        PATH=str(CHAIN / 'bin') + os.pathsep + os.environ.get('PATH', os.defpath))
    prior = json.loads((ORIGINAL / 'LAUNCH_RESULT.json').read_bytes())
    assert not prior['completed'] and prior['returncode'] == 1
    assert json.loads((ORIGINAL / 'RESULT.json').read_bytes())['error_type'] == 'AssertionError'
    fixture = (ROOT / 'research/continuity-identity-candidate/src/durable/messages/tests/fanout.rs').read_text()
    assert 'fn new(budget: u16, same_account: bool)' in fixture
    assert 'enrollment(40, if same_account { 3 } else { 2 }, policy.family())' in fixture
    state = {'prior_launcher_completed': False, 'prior_launcher_sha256': digest(ORIGINAL / 'LAUNCH_RESULT.json'),
        'prior_readback_failure': 'The first reader confused the send budget 4 with recipient cardinality 2. All three original Debug test commands passed; their unchanged streams are reread, not rerun.',
        'completed': False, 'source_commit': COMMIT, 'source_inputs': before, 'tool_binaries': tools,
        'started_utc': datetime.now(timezone.utc).isoformat(), 'driver_sha256': digest(Path(__file__)),
        'command_helper_sha256': digest(helper), 'build_cache_reused': str(BUILD),
        'rust_source_changed': False, 'full_native_suite_rerun': False, 'hosted_ci_claimed': False,
        'scope': 'Existing individual and aggregate original-input sync/process-cut regressions; actual private precommit wire equals recovered wire. Does not establish distinct derived keys, AEAD confidentiality or the multi-epoch theorem.',
        'physical_power_loss_claimed': False, 'release_claim_eligible': False, 'profiles': {}}
    write(BASE / 'INPUTS.json', state)
    try:
        for profile in ['debug', 'release']:
            records = {}
            for label, test in TESTS.items():
                argv = [str(CHAIN / 'bin/cargo'), 'test', '--manifest-path', MANIFEST, '--lib', '--all-features', '--locked', '--offline']
                if profile == 'release': argv.append('--release')
                argv += [test, '--', '--exact', '--nocapture']
                reused = profile == 'debug' and label != 'unsafe-reset'
                stem = (ORIGINAL if reused else BASE) / (profile + '-' + label)
                stdout = (stem.with_suffix('.stdout').read_text() if reused else
                          sdk.command(argv, stem, ROOT, environment=environment).decode())
                receipt = json.loads(stem.with_suffix('.json').read_bytes())
                assert receipt['returncode'] == 0 and receipt['argv'] == argv
                stderr = stem.with_suffix('.stderr').read_text()
                assert stdout.splitlines().count('test ' + test + ' ... ok') == 1
                summaries = re.findall(r'^test result: (.+)$', stdout, re.M)
                assert len(summaries) == 1 and summaries[0].startswith('ok. 1 passed; 0 failed; 0 ignored;')
                assert not re.search(r'(?im)^(?:warning|error)(?:\[|:)', stderr)
                markers = []
                if label == 'fanout-sync':
                    markers = re.findall(r'^ACCOUNT_FANOUT_SYNC_RECOVERY barriers=(\d+) faults=(\d+) phases=(.+)$', stderr, re.M)
                    assert len(markers) == 1 and int(markers[0][1]) == 2 * int(markers[0][0])
                if label == 'fanout-process':
                    markers = re.findall(r'^ACCOUNT_FANOUT_PROCESS_RECOVERY cut=([^ ]+) recipients=(\d+) competing_writer=Busy$', stderr, re.M)
                    assert markers == [('fanout-reserved', '2'), ('fanout-computed', '2'), ('fanout-committed', '2')]
                if label == 'unsafe-reset':
                    markers = [line for line in stderr.splitlines() if line.startswith('FANOUT_RESET_COUNTEREXAMPLE ')]
                    assert markers == ['FANOUT_RESET_COUNTEREXAMPLE actual_precommit_ciphertext=true same_keystream=true shipping_replacement_refused=true']
                records[label] = {'reused_completed_test': reused, 'test': test, 'summary': summaries[0], 'markers': markers,
                                  'stdout_sha256': digest(stem.with_suffix('.stdout')), 'stderr_sha256': digest(stem.with_suffix('.stderr'))}
            state['profiles'][profile] = records
        assert package.source_inputs() == before and package.compiler_identity(CHAIN) == tools
        state.update(completed=True, selected_source_inputs_unchanged=True, tool_binaries_unchanged=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error)); raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'RESULT.json', state)
        print(json.dumps({k: state.get(k) for k in ['completed', 'error_type', 'error', 'profiles']}, indent=2), flush=True)


if __name__ == '__main__': main()
