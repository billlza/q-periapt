from pathlib import Path
import hashlib, json, os, subprocess, sys, time
base=Path(__file__).resolve().parent
root=base.parent/'policy-recovery-ffi-current/source'
out=base/sys.argv[1];out.mkdir()
toolbase=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244')
tc=toolbase/'rustup/toolchains/1.98.1-aarch64-apple-darwin'
report=root/'target/registry-alias-rust-package-01/RUST_SDK_PACKAGE.json'
def sha(p):
 with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','PYTHON','DYLD','LD_'))}
env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PATH=str(tc/'bin')+':/Users/bill/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
command=['sh','artifact/python-run.sh','artifact/policy_maintenance_package.py','--report',str(report),'--report-sha256',sha(report),'--toolchain-root',str(tc),'--cargo-home',str(report.parent/'cargo-home'),'--output',str(root/'target'/('policy-maintenance-'+sys.argv[1]))]
start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:r=subprocess.run(command,cwd=root,env=env,stdout=so,stderr=se)
record={'head':head,'source':str(root),'command':command,'returncode':r.returncode,'seconds':time.monotonic()-start,'clean_source_after':not git('status','--porcelain'),'head_unchanged':git('rev-parse','HEAD')==head,'stdout_sha256':sha(out/'stdout.log'),'stderr_sha256':sha(out/'stderr.log')}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print((out/'stderr.log').read_text()[-5000:],flush=True);print((out/'stdout.log').read_text()[-2000:],flush=True)
assert record['clean_source_after'] and record['head_unchanged'];r.check_returncode()
