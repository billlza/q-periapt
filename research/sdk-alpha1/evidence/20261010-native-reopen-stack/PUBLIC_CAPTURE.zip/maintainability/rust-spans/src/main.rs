use std::{env, fs, process::Command};
use syn::{visit::{self, Visit}, spanned::Spanned, punctuated::Punctuated, Token, Meta, Attribute};
fn requires_test(meta: &Meta) -> bool {
    match meta {
        Meta::Path(p) => p.is_ident("test"),
        Meta::List(l) if l.path.is_ident("all") || l.path.is_ident("any") => {
            let values=l.parse_args_with(Punctuated::<Meta, Token![,]>::parse_terminated).expect("cfg metadata");
            if l.path.is_ident("all") { values.iter().any(requires_test) }
            else { !values.is_empty() && values.iter().all(requires_test) }
        },
        _ => false,
    }
}
fn test_only(attrs: &[Attribute]) -> bool {
    attrs.iter().any(|a| a.path().is_ident("test") || (a.path().is_ident("cfg") && a.parse_args::<Meta>().map(|m| requires_test(&m)).unwrap_or(false)))
}
struct Functions { path: String, rows: Vec<serde_json::Value> }
impl Functions {
    fn record(&mut self, sig: &syn::Signature, end: proc_macro2::Span) {
        let start=sig.span().start().line; let end=end.end().line;
        self.rows.push(serde_json::json!({"path": self.path,"function":sig.ident.to_string(),"line":start,"end_line":end,"lines":end-start+1,"arguments":sig.inputs.len()}));
    }
}
impl<'a> Visit<'a> for Functions {
    fn visit_item_mod(&mut self, item: &'a syn::ItemMod) { if !test_only(&item.attrs) { visit::visit_item_mod(self,item); } }
    fn visit_item_fn(&mut self, item: &'a syn::ItemFn) { if !test_only(&item.attrs) { self.record(&item.sig,item.block.span()); visit::visit_item_fn(self,item); } }
    fn visit_impl_item_fn(&mut self,item: &'a syn::ImplItemFn) { if !test_only(&item.attrs) {self.record(&item.sig,item.block.span());visit::visit_impl_item_fn(self,item);} }
}
fn main() {
    let root=env::args().nth(1).expect("repository root");
    let output=Command::new("git").args(["-C",&root,"ls-files","-z","*.rs"]).output().expect("git files"); assert!(output.status.success());
    let mut rows=vec![];let mut excluded=vec![];
    for name in output.stdout.split(|b| *b==0).filter(|b| !b.is_empty()) {
        let name=std::str::from_utf8(name).expect("UTF8 path");
        if name.split('/').any(|s|matches!(s,"tests"|"benches"|"vendor")) || name.ends_with("/tests.rs") || name.ends_with("_tests.rs") || name.contains("/test_") {excluded.push(name.to_string());continue;}
        let source=fs::read_to_string(std::path::Path::new(&root).join(name)).expect("source");
        let syntax=syn::parse_file(&source).unwrap_or_else(|e|panic!("{name}: {e}"));
        let mut v=Functions{path:name.into(),rows:vec![]};v.visit_file(&syntax);rows.extend(v.rows);
    }
    rows.sort_by_key(|r| std::cmp::Reverse(r["lines"].as_u64().unwrap()));
    println!("{}",serde_json::to_string_pretty(&serde_json::json!({"scope":"Rust syntax function spans excluding explicit test-only modules/functions and test/bench/vendor paths; macros are not expanded; no runtime profiling","excluded_paths":excluded,"functions":rows})).unwrap());
}
