from pathlib import Path
import subprocess,json,hashlib,os,sys,time
b=Path(__file__).resolve().parent;source=b/'swift-consumer';label,profile,command,*extra=sys.argv[1:];out=b/label;out.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('SWIFT','DYLD','LD_','QPERIAPT','QPC','PYTHON','CARGO','RUST'))}
env['DEVELOPER_DIR']='/Applications/Xcode.app/Contents/Developer'
swift=subprocess.check_output(['/usr/bin/xcrun','--find','swift'],env=env,text=True).strip()
inputs={str(f.relative_to(source)):hashlib.sha256(f.read_bytes()).hexdigest() for f in source.rglob('*') if f.is_file()}
cmd=['/usr/bin/caffeinate','-i',swift,command,'--package-path',str(source),'--configuration',profile,'--scratch-path',str(b/f'swift-build-{profile}'),'--cache-path',str(b/'swift-cache'),'-j','2','-Xswiftc','-warnings-as-errors','-Xcc','-I'+str(source/'native/include'),'-Xlinker','-L'+str(source/'native'/profile),'-Xlinker','-rpath','-Xlinker',str(source/'native'/profile),*extra]
r={'command':cmd,'source':str(source),'inputs':inputs,'swift':subprocess.check_output([swift,'--version'],env=env,text=True)};(out/'START.json').write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,env=env,stdout=so,stderr=se)
r.update(returncode=p.returncode,seconds=time.monotonic()-start);(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='inputs'}));print((out/'stdout.log').read_text()[-5000:]);print((out/'stderr.log').read_text()[-7000:]);p.check_returncode()
