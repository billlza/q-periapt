from pathlib import Path
import hashlib,json,subprocess,os,time,sys
b=Path(__file__).resolve().parent;source=b/'consumer';label,*args=sys.argv[1:];out=b/label;out.mkdir()
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.90.0-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','PYTHON'))}
env.update(RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',
 CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',
 CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(b/'consumer-build-msrv'),
 PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
inputs={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
cmd=['/usr/bin/caffeinate','-i',str(tc/'bin/cargo'),*args];record=dict(command=cmd,source=str(source),inputs=inputs);(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,cwd=source,env=env,stdout=so,stderr=se)
record.update(returncode=p.returncode,seconds=time.monotonic()-start,source_unchanged=inputs=={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()});assert record['source_unchanged'];(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='inputs'}));print((out/'stdout.log').read_text()[-3000:]);print((out/'stderr.log').read_text()[-4000:]);p.check_returncode()
