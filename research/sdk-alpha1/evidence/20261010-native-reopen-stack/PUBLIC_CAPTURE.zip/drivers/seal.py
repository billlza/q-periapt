from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
b=Path(__file__).resolve().parent;root=b.parents[1];dest=root/'research/sdk-alpha1/evidence/20261010-native-reopen-stack';dest.mkdir()
checks=json.loads((b/'CHECKS_PENDING.json').read_text());checks['created_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();checks['validation']={}
labels=['integrated-native-debug-01','integrated-native-release-01','integrated-clippy-01','integrated-msrv-01','integrated-swift-debug-01','integrated-swift-release-01','integrated-swift-account-01','integrated-swift-account-release-01','integrated-c-owner-03']
for name in labels:
 j=json.loads((b/name/'RESULT.json').read_text())
 if 'returncode' in j and j['returncode']!=0:raise ValueError(name+' did not pass')
 if 'completed' in j and j['completed'] is not True:raise ValueError(name+' did not complete')
 checks['validation'][name]={k:v for k,v in j.items() if k not in ('inputs','result','swift')}
checks['validation']['Swift_unit_tests_per_profile']=62
checks['validation']['Swift_account_tests_per_profile']=3
checks['validation']['Swift_account_scenarios_per_profile']=9
checks['integration']=json.loads((b/'INTEGRATION_IDENTITY.json').read_text())
checks['source_comparison']=json.loads((b/'SOURCE_COMPARISON.json').read_text())
checks['remaining']=['full Rust/C/Swift/Kotlin package qualification on corrected commit','corrected-commit remote CI','other 0.2.0 release gates remain open; no release/publication claim']
checks['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['bindings/c/ContinuityPackageConsumer/src/owner.rs','bindings/c/ContinuityPackageConsumer/tests/common/receiver_process.rs']}
files={}
for label in labels + [r['label'] for r in checks['controlled_runs']] + ['integrated-c-owner-01','integrated-c-owner-02','native-default-worker-01']:
 for p in (b/label).iterdir():
  if p.is_file() and (p.suffix in ('.json','.log','.stdout','.stderr') or p.name in ('stdout','stderr')): files['runs/'+label+'/'+p.name]=p.read_bytes()
for name in ['SOURCE_COMPARISON.json','INTEGRATION_IDENTITY.json','DIAGNOSIS_CURRENT.json','original-prologues.json','diagnostic-prologues.json','split-prologues.json','integrated-prologues.json','pressure-prologue.txt']:
 files['analysis/'+name]=(b/name).read_bytes()
for p in b.glob('run-*.py'):files['drivers/'+p.name]=p.read_bytes()
files['drivers/seal.py']=Path(__file__).read_bytes()
files['patches/INTEGRATED.patch']=subprocess.check_output(['git','diff','--','bindings/c/ContinuityPackageConsumer/src/owner.rs','bindings/c/ContinuityPackageConsumer/tests/common/receiver_process.rs'],cwd=root)
pressure_diff=subprocess.run(['git','diff','--no-index','--',str(b/'activation-split-owner.rs'),str(b/'pressure-owner.rs')],stdout=subprocess.PIPE,check=False)
if pressure_diff.returncode!=1 or b'retained_stack_pressure' not in pressure_diff.stdout:raise ValueError('negative control diff differs')
files['patches/STACK_PRESSURE_CONTROL.patch']=pressure_diff.stdout
old=root/'target/installed-first-configuration-current/source/target/continuity-first-configuration-8218da58'
for name in ['swift-account-reconciliation-debug.json','swift-account-reconciliation-debug.stdout','swift-account-reconciliation-debug.stderr']:files['original-full-pipeline/'+name]=(old/name).read_bytes()
for name in ['FILE_INVENTORY.json','PYTHON_FUNCTIONS.json','RUST_FUNCTIONS.json']:files['maintainability/'+name]=(root/'target/maintainability-current'/name).read_bytes()
for name in ['src/main.rs','Cargo.toml','Cargo.lock']:files['maintainability/rust-spans/'+name]=(root/'target/maintainability-current/rust-spans'/name).read_bytes()
archive=dest/'PUBLIC_CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None:raise ValueError('corrupt archive')
 for name,data in files.items():
  if z.read(name)!=data:raise ValueError(name+' roundtrip mismatch')
checks['capture']={'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(files),'selection':'Explicit diagnostic/test logs, public metadata, source patches and analysis only; no runtime directories, private stores or binary process memory'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
review=json.loads((root/'target/maintainability-current/ASSESSMENT.json').read_text());review['runtime_fix']['validation'].update(release_build='passed',Swift_release_unit_tests=62,Swift_release_account_scenarios=9,Rust_1_90_all_targets='passed');(dest/'MAINTENANCE_REVIEW.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(checks['capture']))
