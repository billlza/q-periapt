from pathlib import Path
import sys,os,json,hashlib,time,subprocess,shutil
b=Path(__file__).resolve().parent;root=b.parents[1];sys.path.insert(0,str(root/'artifact'))
import rust_sdk_profile as sdk
import continuity_foreign_account_results as accounts
import continuity_c_consumer as c
label,mode=sys.argv[1:];out=b/label;out.mkdir();outside=Path('/private/tmp/qperiapt-continuity-package-4f9z3d40')
record=json.loads((root/'target/installed-first-configuration-current/source/target/continuity-first-configuration-8218da58/C_CONSUMER.json').read_text());native=record['execution']['release']
env={k:v for k,v in os.environ.items() if not k.startswith(('QPERIAPT','QPC','DYLD','LD_','SWIFT','CARGO','RUST'))}
env.update(PATH='/opt/homebrew/opt/openssl@3/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
lib=b/'swift-fixed/native/release/libq_periapt_continuity_c_consumer.dylib';swift=b/'swift-fixed-build-release/out/Products/Release/ContinuityClient'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'mode':mode,'scope':'Focused regression using installed original harness and matching source dependencies; corrected native bridge; no loader override; not a full package qualification','native_sha256':sha(lib),'completed':False};(out/'START.json').write_text(json.dumps(state,indent=2)+'\n');start=time.monotonic()
try:
 if mode=='Swift':
  env.update(QPERIAPT_C_OWNER_CLIENT=str(swift),QPERIAPT_INSTALLED_CLIENT_LANGUAGE='Swift',QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(lib))
  def run(argv,label,*,runtime):return sdk.command(argv,out/('swift-'+label),outside,environment=runtime)
  harness=c.built_artifact((root/'target/installed-first-configuration-current/source/target/continuity-first-configuration-8218da58/c-enrollment-build-release.stdout').read_bytes(),outside/'c-consumer',outside/'build/release',library=False,test_name='enrollment')
  state['result']=accounts.qualify(out,'release',env,native,harness,run,language='Swift')
 elif mode=='C':
  installed=b/'c-fixed';installed.mkdir();binary=installed/'qpc-c-client';shutil.copyfile(native['binaries']['C_client']['path'],binary);binary.chmod(0o700);shutil.copyfile(lib,installed/lib.name)
  env.update(QPERIAPT_C_OWNER_CLIENT=str(binary),QPERIAPT_INSTALLED_CLIENT_LANGUAGE='C',QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'runtime'))
  harness=Path(native['binaries']['Rust_trace']['path'])
  raw=sdk.command([str(harness),'--exact',c.TEST,'--nocapture'],out/'c-trace',outside,environment=env)
  state['result']=c.verify_execution(raw,out/'runtime')
 else:raise ValueError('unknown mode')
 state['completed']=True
finally:
 state['seconds']=time.monotonic()-start;state['native_unchanged']=sha(lib)==state['native_sha256'];(out/'RESULT.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:v for k,v in state.items() if k!='result'}))
