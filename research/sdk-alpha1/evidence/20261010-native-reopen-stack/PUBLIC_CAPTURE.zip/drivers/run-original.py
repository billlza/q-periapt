from pathlib import Path
import os,subprocess,json,hashlib,time,sys
b=Path(__file__).resolve().parent;outside=Path('/private/tmp/qperiapt-continuity-package-4f9z3d40');out=b/sys.argv[1];out.mkdir(mode=0o700)
harness=outside/'build/debug/deps/enrollment-be29dc63cc0960eb';swift=outside/'swift-installed-debug/.build/out/Products/Debug/ContinuityClient';c=outside/'c-installed-debug/qpc-c-client';wrapper=b/'observed-swift';lib=outside/'swift-installed-debug/native/lib/libq_periapt_continuity_c_consumer.dylib';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identities={str(p):sha(p) for p in [harness,swift,c,wrapper,lib]}
env={k:v for k,v in os.environ.items() if not k.startswith(('QPERIAPT','QPC','DYLD','LD_','SWIFT','CARGO','RUST'))}
env.update(PATH='/opt/homebrew/opt/openssl@3/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',QPERIAPT_C_OWNER_CLIENT=str(c),QPERIAPT_INSTALLED_CLIENT_LANGUAGE='C',QPERIAPT_ACCOUNT_RESULT_CLIENT=str(wrapper),QPERIAPT_ACCOUNT_RESULT_LANGUAGE='Swift',QPERIAPT_PEER_ROSTER_LIFECYCLE_CLIENT=str(wrapper),QPERIAPT_PEER_ROSTER_LIFECYCLE_LANGUAGE='Swift',QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(lib))
for name in ('ENROLLMENT','POLICY','ROSTER'):env['QPERIAPT_'+name+'_LIFECYCLE_CLIENT']=str(wrapper);env['QPERIAPT_'+name+'_LIFECYCLE_LANGUAGE']='Swift'
test='credential_renewal::independent_policy::witnessed::roster::traffic::fanout::c_peer_roster_unknown_commit_cancel_and_kill_recover_original_target_without_current_sdk'
cmd=[str(harness),'--exact',test,'--nocapture','--test-threads=1'];record={'command':cmd,'identities':identities,'scope':'Observe actual installed Swift process exit without debugger, memory reads or runtime changes'};(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:r=subprocess.run(cmd,cwd=outside,env=env,stdout=so,stderr=se,timeout=600)
record.update(returncode=r.returncode,seconds=time.monotonic()-start,binaries_unchanged=all(sha(Path(p))==s for p,s in identities.items()));(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='identities'}));print((out/'stdout').read_text()[-2200:]);print((out/'stderr').read_text()[-4000:]);r.check_returncode()
