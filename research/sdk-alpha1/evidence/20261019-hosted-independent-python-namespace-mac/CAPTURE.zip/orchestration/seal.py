"""Seal completed installed-reference CI readbacks and preserved reader failures."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

root = Path.cwd()
base = Path(__file__).resolve().parent
platform = sys.argv[1]
assert platform in {"linux", "mac"}
out = base / platform
head = "115fb323c9082f4db573ff2fdbb17c75c4c3f372"
def read(path):
    return json.loads(path.read_text())
def sha(data):
    return hashlib.sha256(data).hexdigest()

labels = ["REGRESSION", "CONTROL", "RESOLUTION", "WITNESS", "PEER_LIFECYCLE",
          "REPLY_RELEASE", "LOCAL_RENEWAL", "LOCAL_CREDENTIAL", "PENDING",
          "PUBLIC_INPUTS", "REGISTRATION", "INSTALLATION"]
reports = {label: read(out / (label + "_READBACK.json")) for label in labels}
readers = read(out / "READERS.json")
assert len(readers) == 12 and all(row["exit"] == 0 for row in readers)
for row in readers:
    assert not (out / (row["reader"] + ".stderr")).read_bytes()
sources = read(out / "SOURCE_FILES.json")
assert len(sources) == 99
for label, report in reports.items():
    if label not in {"REPLY_RELEASE", "INSTALLATION"}:
        assert report["head"] == head and report["source_files"] == sources
        assert report["native_sha256"] == reports["INSTALLATION"]["native_sha256"]
job = read(out / "JOB.json")
artifact = read(out / "ARTIFACT.json")
assert job["head_sha"] == head and job["run_id"] == 39184186420
assert job["status"] == "completed" and job["conclusion"] == "success"
archive = out / (platform + "-115f.zip")
body = archive.read_bytes()
assert len(body) == artifact["size_in_bytes"] and "sha256:" + sha(body) == artifact["digest"]
entries = {archive.name: body}
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {".py", ".json", ".txt", ".stdout", ".stderr"}:
        entries[path.name] = path.read_bytes()
for name in ["INPUTS.json", "PREPARED.json", "run-readers.py",
             "review-installation.py", "seal.py", "READER_SOURCE_FILES.json"]:
    entries["orchestration/" + name] = (base / name).read_bytes()
for name, expected in sources.items():
    data = (out / "source" / name).read_bytes()
    assert sha(data) == expected
    entries["peer-source/" + name] = data
for name, expected in read(base / "READER_SOURCE_FILES.json").items():
    data = (base / "reader-source" / name).read_bytes()
    assert sha(data) == expected
    entries["build-reader-source/" + name] = data
for name in ["SDK_ARTIFACT.json", "sdk/sdk-rust-package/RUST_SDK_PACKAGE.json"]:
    entries["sdk/" + Path(name).name] = (root / "target/independent-installed-01" / name).read_bytes()
manifest = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(entries.items())}
entries["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
folder = root / "research/sdk-alpha1/evidence" / ("20261019-hosted-independent-python-namespace-" + platform)
folder.mkdir()
groups = {
    "CAPTURE.zip": {n: b for n, b in entries.items() if not n.startswith("build-reader-source/")},
    "SOURCE.zip": {n: b for n, b in entries.items() if n.startswith("build-reader-source/")},
}
assert set(groups["CAPTURE.zip"]).isdisjoint(groups["SOURCE.zip"])
assert set(groups["CAPTURE.zip"]) | set(groups["SOURCE.zip"]) == set(entries)
captures = {}
for filename, selected in groups.items():
    capture = folder / filename
    with zipfile.ZipFile(capture, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(selected.items()):
            item = zipfile.ZipInfo(name, (2026, 10, 19, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            z.writestr(item, data)
    with zipfile.ZipFile(capture) as z:
        assert z.testzip() is None and len(z.namelist()) == len(selected) == len(set(z.namelist()))
        for name in selected:
            assert z.read(name) == selected[name]
    assert capture.stat().st_size < 50 * 1024**2
    captures[filename] = {"bytes": capture.stat().st_size, "members": len(selected), "sha256": sha(capture.read_bytes())}
result = {
    "head": head, "run": job["run_id"], "job": job["id"], "job_conclusion": job["conclusion"],
    "artifact": {"id": artifact["id"], "bytes": artifact["size_in_bytes"], "digest": artifact["digest"]},
    "capture": captures["CAPTURE.zip"], "source_capture": captures["SOURCE.zip"],
    "capture_layout": "Disjoint CAPTURE.zip and SOURCE.zip; MANIFEST.json in CAPTURE.zip covers every member across both archives.",
    "readbacks": reports,
    "scope": "Nineteen reference lanes executed against the counterpart built from eight pinned SDK archives and current Continuity crate outside checkout. Twelve readbacks link exact source, graph, binary and public protocol records. The native counterpart and public importer are built from the same installed graph; the Python reference remains source-run at this CI head. Remote private-state and final filesystem assertions remain producer observations. Not deployed account authentication, cross-host transport, full multidevice lifecycle, PCS, energy or release admission. This run covers the new Python namespace from source; wheel installation remains separately qualified locally and is added to CI only by the following entry-point change.",
    "reader_failures": "Readers use frozen115f sources. Imports and the two current-source inventory globs use qperiapt_continuity_reference; the historical peer/state_codec.py archive key is deliberately unchanged. Auxiliary decoder, strict remote path checks and installed importer binding are retained. All readers passed their first execution.",
    "sdk_archives": "Report and artifact identity retained here; exact upstream SDK archive bytes are also retained in 20261019-independent-installed-counterpart."
}
(folder / "CHECKS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(captures))
