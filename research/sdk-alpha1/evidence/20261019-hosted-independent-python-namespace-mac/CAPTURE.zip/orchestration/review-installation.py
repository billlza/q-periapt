"""Bind hosted installed build receipts to the binary and public runtime records.

This reads trusted local/Git helpers, never the uploaded executable. Remote
post-build file checks and tool hashes remain producer observations.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import subprocess
import sys

REPO = Path.cwd()
OUT = Path(__file__).resolve().parent
ROOT = OUT / "reader-source"
HEAD = "115fb323c9082f4db573ff2fdbb17c75c4c3f372"
platform = sys.argv[1]
assert platform in {"linux", "mac"}
folder = OUT / platform
public = folder / "public"
built = public / "installed"
sys.path.insert(0, str(ROOT / "artifact"))
import continuity_independent_package as installed
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def git(name):
    return subprocess.check_output(["git", "show", HEAD + ":" + name])

report = read(built / "INSTALLED_COUNTERPART.json")
assert report["source_commit"] == HEAD and report["completed"] is True
assert report["sources_unchanged"] is True and report["runtime_qualified"] is False
assert report["release_claim_eligible"] is False and "failure" not in report
assert (report["host_os"], report["host_arch"]) == (
    ("Darwin", "arm64") if platform == "mac" else ("Linux", "x86_64"))
for name, digest in report["source_inputs"].items():
    assert sha(git(name)) == digest == sha((ROOT / name).read_bytes()), name

metadata = read(built / "consumer-metadata.stdout")
remote_consumer = PurePosixPath(read(built / "LOCATION.json")["path"]) / "counterpart"
assert remote_consumer.is_absolute() and ".." not in remote_consumer.parts
# Check exact remote paths before the shared same-host helper calls resolve().
# On this macOS reader /tmp is /private/tmp, unlike the Linux producer.
for row in metadata["packages"]:
    if not row["name"].startswith("q-periapt"):
        continue
    expected = (remote_consumer / "Cargo.toml" if row["name"] == installed.NAME else
                remote_consumer / "packages" / (row["name"] + "-" + installed.VERSIONS[row["name"]]) / "Cargo.toml")
    assert row["manifest_path"] == str(expected), row["name"]
consumer = Path(remote_consumer).resolve()
original_lock = git("research/continuity-openssl-peer/native/Cargo.lock")
resolution = installed.verify_graph(metadata, consumer,
    (built / "consumer-Cargo.lock").read_bytes(), original_lock)
assert resolution == report["resolution"]
assert installed.installed_manifest(git("research/continuity-openssl-peer/native/Cargo.toml")) == (
    built / "consumer-Cargo.toml").read_bytes()
assert (built / "consumer-metadata.stdout").read_bytes() == (public / "metadata.json").read_bytes()

inputs = read(OUT / "INPUTS.json")
sdk_report = REPO / "target/independent-installed-01/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json"
source_identity = sdk.source_identity()
cohort = validate_report(sdk_report.read_bytes(), inputs["sdk_report_sha256"],
    sha(sdk_report.read_bytes()), source_identity["rust_workspace_sha256"])
assert report["sdk_report_sha256"] == inputs["sdk_report_sha256"]
assert report["sdk_base_commit"] == cohort["base_commit"]
# Rebase only metadata paths used to compare archive sources with local Git.
# The installed graph above is checked with the unmodified remote paths.
workspace = read(built / "workspace-metadata.stdout")
checkout = Path(workspace["workspace_root"])
def local_path(value):
    if value is None or not Path(value).is_absolute():
        return value
    return str(ROOT / Path(value).relative_to(checkout))
for row in workspace["packages"]:
    row["manifest_path"] = local_path(row["manifest_path"])
    row["readme"] = local_path(row["readme"])
    for dependency in row["dependencies"]:
        if "path" in dependency:
            dependency["path"] = local_path(dependency["path"])
packages = sdk.classify(workspace)
archives = {}
for name in installed.PRODUCTS:
    row = cohort["crates"][name]
    archive = sdk_report.parent / "crates" / row["file"]
    data = archive.read_bytes()
    assert sha(data) == row["sha256"]
    files = sdk.validate_archive(data, name, packages[name], set(row["files"]))
    archives[name] = {"sha256": sha(data), "files": len(files)}
candidate = report["candidate_archive"]
data = (built / candidate["file"]).read_bytes()
assert len(data) == candidate["bytes"] and sha(data) == candidate["sha256"]
package.validate_candidate(data, set(candidate["files"]))

for command in ["consumer-build", "consumer-clippy", "consumer-metadata", "importer-build", "importer-clippy"]:
    receipt = read(built / (command + ".json"))
    assert receipt["returncode"] == 0 and receipt["cwd"] == str(remote_consumer)
    assert not re.search(rb"(?m)^\s*(warning:|error:)", (built / (command + ".stderr")).read_bytes())
assert {"--release", "--locked", "--offline"} <= set(read(built / "consumer-build.json")["argv"])
assert read(built / "consumer-clippy.json")["argv"][-3:] == ["--", "-D", "warnings"]
binary = (built / "counterpart").read_bytes()
assert binary == (public / "counterpart").read_bytes()
assert sha(binary) == report["native_sha256"]
if platform == "mac":
    assert binary[:4] == b"\xcf\xfa\xed\xfe" and int.from_bytes(binary[4:8], "little") == 0x100000c
else:
    assert binary[:6] == b"\x7fELF\x02\x01" and int.from_bytes(binary[18:20], "little") == 62
importer = (built / "importer").read_bytes()
assert importer == (public / "importer").read_bytes()
assert sha(importer) == report["importer_sha256"] == read(public / "public-inputs/RESULT.json")["importer_sha256"]
assert read(built / "importer-clippy.json")["argv"][-3:] == ["--", "-D", "warnings"]
assert {"--release", "--locked", "--offline", "--example", "import_bootstrap_bundle"} <= set(read(built / "importer-build.json")["argv"])
runtime = read(public / "registration/RESULT.json")
registration = read(folder / "REGISTRATION_READBACK.json")
assert runtime["native_sha256"] == registration["native_sha256"] == report["native_sha256"]
assert registration["head"] == HEAD and runtime["source_files"] == registration["source_files"]
assert (built / "rustc.stdout").read_text() == report["rustc"] == (public / "rustc.txt").read_text()

loaded = {}
for module in tuple(sys.modules.values()):
    name = getattr(module, "__file__", None)
    if not name or Path(name).parent != ROOT / "artifact":
        continue
    path = Path(name)
    relative = path.relative_to(ROOT).as_posix()
    assert path.read_bytes() == git(relative), relative
    loaded[relative] = sha(path.read_bytes())
result = {
    "head": HEAD, "platform": platform, "native_sha256": report["native_sha256"],
    "importer_sha256": report["importer_sha256"], "sdk_report_sha256": report["sdk_report_sha256"], "sdk_base_commit": report["sdk_base_commit"],
    "resolution": resolution, "sdk_archives": archives,
    "candidate_archive": {k: candidate[k] for k in ["file", "bytes", "sha256"]},
    "reader_sources": loaded, "registration": registration["profiles"],
    "scope": "Actual installed native binary linked to public registration records and exact 9-product graph/original lock. SDK archives and candidate source members checked locally. Remote final consumed-file checks and compiler hashes remain producer observations. Python reference is source-run; native counterpart and public importer are installed; same-host control pipe, not deployed account authentication, cross-host transport, physical erasure, PCS or full release admission."
}
(folder / "INSTALLATION_READBACK.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["head", "platform", "native_sha256", "resolution"]}))
