"""Replay the sixteen actual selected goals with all six other open trees restored."""
from pathlib import Path
import hashlib,json,re,shutil
root=Path.cwd();capture=root/'target/p0-origin-offer-response-715';sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((capture/'offer-response-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded'] and not (capture/'initial-send-oracle.failed').exists()
value=(capture/'offer-response-proof.spthy').read_text();assert sha(value.encode())==terminal['output_sha256']=='151ebf4bb11a8713cc147713c48cc849e84ac32e64adea838cdf7ad068ebb73e'
full=(root/'target/p0-origin-snapshot-producers-replay-714/snapshot-producers-replay-proof.spthy').read_text();assert sha(full.encode())=='85b3f4f5fc2f89def1ac5fb841608059da3a543300381bee5e8c4df8583109a5'
def region(t):
    a=t.index('lemma epoch_generation_secret_derivation_origin ');b=t.index('\nlemma ',a);return a,b,t[a:b]
def roots(t):return {m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',t)}
def children(t):return {m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',t)}
a,b,main=region(value);_,_,old=region(full);current,previous=roots(main),roots(old)
assert len(current)==18 and set(current)==set(previous) and all(current[n]==v for n,v in previous.items() if n!='Snapshot_case_5')
focused,original=children(current['Snapshot_case_5']),children(previous['Snapshot_case_5']);assert len(focused)==11 and set(focused)==set(original)
frames=[]
for p in sorted((capture/'initial-send-oracle-frames').glob('*.json')):
    row=json.loads(p.read_text());text=(p.parent/row['captured_input']).read_text();assert sha(text.encode())==row['input_sha256'] and not row['ranking'];frames.append((row,text))
assert len(frames)==22 and main.count('by sorry')==22 and main.count('Oracle ranked no proof methods')==22
selected={'Offer_Signing_2':5,'Offer_Commit_3':4,'Response_Compute_5':7};closed={'Key_Reservation_1','Response_Reservation_4'}
snapshot=current['Snapshot_case_5'];index=0;methods=[];restored=[]
for name,body in focused.items():
    leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',body))
    if name in closed:
        assert not leaves and body==original[name];continue
    if name not in selected:
        assert len(leaves)==1;snapshot=snapshot.replace(body,original[name],1);index+=1
        restored.append({'producer':name,'sha256':sha(original[name].encode()),'open_leaves':original[name].count('by sorry')});continue
    assert len(leaves)==selected[name];replacements=[]
    for leaf in leaves:
        row,text=frames[index];chains=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',text)
        if chains:
            assert len(chains)==1;method=chains[0];kind='knowledge_chain'
        else:
            phase=re.findall(r'(?m)^\d+: (PositionedPhaseState\([^\n]+▶₀ #vr(?:\.[0-9]+)?)$',text)
            assert len(phase)==1;method=phase[0];kind='phase_producer'
        replacements.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
        methods.append({'producer':name,'frame_index':index,'frame':row['captured_input'],'frame_sha256':row['input_sha256'],'kind':kind,'method':method});index+=1
    updated=body
    for left,right,replacement in reversed(replacements):updated=updated[:left]+replacement+updated[right:]
    snapshot=snapshot.replace(body,updated,1)
assert index==22 and len(methods)==16 and len(restored)==6 and sum(r['kind']=='knowledge_chain' for r in methods)==10
main=main.replace(current['Snapshot_case_5'],snapshot,1);candidate=value[:a]+main+value[b:]
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,full) and candidate[:candidate.index('lemma ')]==full[:full.index('lemma ')]
assert main.count('by sorry')==19 and 'Oracle ranked no proof methods' not in main
stage=root/'target/p0-origin-offer-response-replay-715';stage.mkdir();(stage/'model.spthy').write_text(candidate);shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'full_parent_sha256':sha(full.encode()),'capture_sha256':sha(value.encode()),'input_sha256':sha(candidate.encode()),'actual_selected_methods':methods,
    'restored_unselected_open_subtrees':restored,'closed_stored_subtrees_retained':{n:sha(original[n].encode()) for n in sorted(closed)},
    'all18_sources_11stored_producers_29queries_retained':True,'operational_prefix_unchanged':True,'independent_replay_no_search_or_oracle':True,
    'maximum_explicit_prefix':8,'total_depth_limit':16,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'chains':10,'phase_producers':6,'restored_open_subtrees':6,'closed_subtrees_retained':2}))
