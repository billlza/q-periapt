"""Capture the newly expanded original-parent and key-bearing payload branches."""
from pathlib import Path
import hashlib,json,re,shutil
root=Path.cwd();parent=root/'target/p0-origin-offer-response-replay-715';sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((parent/'offer-response-replay-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
source=parent/'offer-response-replay-proof.spthy';data=source.read_bytes();assert sha(data)==terminal['output_sha256']=='98234f786a55028fd0210f7bee1abe1dd3f8e20530438f032b0e0b5a82c33ffa'
value=data.decode();a=value.index('lemma epoch_generation_secret_derivation_origin ');b=value.index('\nlemma ',a);main=value[a:b]
roots={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(roots)==18 and sum('by sorry' not in t for t in roots.values())==17 and not re.search(r'\binvalid\b',main)
stored=roots['Snapshot_case_5'];assert stored.count('by sorry')==37
children={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',stored)}
selected={'Offer_Signing_2':4,'Offer_Commit_3':7,'Response_Compute_5':7};closed=['Key_Reservation_1','Response_Reservation_4'];preserved={};focused=stored
assert len(children)==11
for n,body in children.items():
    if n in selected:assert body.count('by sorry')==selected[n]
    elif n in closed:assert 'by sorry' not in body
    else:
        assert 'by sorry' in body;focused=focused.replace(body,'      case '+n+'\n      by sorry\n',1);preserved[n]={'sha256':sha(body.encode()),'open_leaves':body.count('by sorry')}
new_main=main.replace(stored,focused,1);candidate=value[:a]+new_main+value[b:]
assert new_main.count('by sorry')==24 and len(preserved)==6 and max(len(m[1]) for m in re.finditer(r'(?m)^( +)by sorry',new_main))==16
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,value) and candidate[:candidate.index('lemma ')]==value[:value.index('lemma ')]
stage=root/'target/p0-origin-offer-response-details-715';stage.mkdir();(stage/'model.spthy').write_text(candidate);base=root/'target/p0-origin-source-frontiers-705'
for n in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):shutil.copy2(base/n,stage/n)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1;driver.write_text(driver.read_text().replace('--bound=13','--bound=8'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)));(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(source),'full_parent_sha256':sha(data),'input_sha256':sha(candidate.encode()),'selected_producers':selected,
    'closed_producers_preserved':{n:sha(children[n].encode()) for n in closed},'unselected_open_subtrees_preserved_in_parent':preserved,
    'all18_sources_11stored_producers_29queries_retained':True,'focused_open_leaves':24,'existing_open_prefix_maximum':8,'remaining_search_bound':8,'total_depth_limit':16,
    'must_restore_all_six_open_subtrees_before_final_replay':True,'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'focused_leaves':24,'prefix':8,'remaining_bound':8}))
