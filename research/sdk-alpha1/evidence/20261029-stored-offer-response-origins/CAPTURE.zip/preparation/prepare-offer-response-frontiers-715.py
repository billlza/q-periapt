"""Inspect the actual signing and computation lineage while retaining closed sources."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
root=Path.cwd();parent=root/'target/p0-origin-snapshot-producers-replay-714/snapshot-producers-replay-proof.spthy'
sha=lambda b:hashlib.sha256(b).hexdigest()
data=parent.read_bytes();assert sha(data)=='85b3f4f5fc2f89def1ac5fb841608059da3a543300381bee5e8c4df8583109a5'
archive=root/'research/sdk-alpha1/evidence/20261028-stored-reservation-closure/CAPTURE.zip';assert sha(archive.read_bytes())=='303f3021b1d2f4ea7748922b4fbee48e8e3f15632dd014ad9a6fc55889fabeef'
with zipfile.ZipFile(archive) as z:assert z.read('experiments/p0-origin-snapshot-producers-replay-714/snapshot-producers-replay-proof.spthy')==data
value=data.decode();a=value.index('lemma epoch_generation_secret_derivation_origin ');b=value.index('\nlemma ',a);main=value[a:b]
roots={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(roots)==18 and sum('by sorry' not in t for t in roots.values())==17
stored=roots['Snapshot_case_5'];assert stored.count('by sorry')==35
children={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',stored)}
assert len(children)==11
selected={'Offer_Signing_2':5,'Offer_Commit_3':4,'Response_Compute_5':7};closed=['Key_Reservation_1','Response_Reservation_4'];preserved={};focused=stored
for n,body in children.items():
    if n in selected:assert body.count('by sorry')==selected[n]
    elif n in closed:assert 'by sorry' not in body
    else:
        assert 'by sorry' in body;focused=focused.replace(body,'      case '+n+'\n      by sorry\n',1)
        preserved[n]={'sha256':sha(body.encode()),'open_leaves':body.count('by sorry')}
new_main=main.replace(stored,focused,1);candidate=value[:a]+new_main+value[b:]
assert len(preserved)==6 and new_main.count('by sorry')==22 and max(len(m[1]) for m in re.finditer(r'(?m)^( +)by sorry',new_main))==14
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,value)
assert sha(candidate[:candidate.index('lemma ')].encode())=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-offer-response-715';stage.mkdir();(stage/'model.spthy').write_text(candidate)
base=root/'target/p0-origin-source-frontiers-705'
for n in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):shutil.copy2(base/n,stage/n)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1;driver.write_text(driver.read_text().replace('--bound=13','--bound=9'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)));(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(parent),'full_parent_sha256':sha(data),'input_sha256':sha(candidate.encode()),'selected_producers':selected,
    'closed_producers_preserved':{n:sha(children[n].encode()) for n in closed},'unselected_open_subtrees_preserved_in_parent':preserved,
    'all18_sources_11stored_producers_29queries_retained':True,'focused_open_leaves':22,'existing_open_prefix_maximum':7,'remaining_search_bound':9,'total_depth_limit':16,
    'must_restore_all_six_open_subtrees_before_final_replay':True,'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'focused_leaves':22,'closed_producers_preserved':len(closed),'open_subtrees_preserved':len(preserved)}))
