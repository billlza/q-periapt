from pathlib import Path
import hashlib, json, re, shutil, subprocess, zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
steps=json.loads((out/'FINAL_CHECK_COMMANDS.json').read_text())
assert len(steps)==7 and all(s['exit_code']==0 for s in steps)
for stage in ['tests-04','release-tests-02']:
    text=(out/(stage+'.stdout')).read_text()
    assert all(f'{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in text for count in [20,6])
for stage in ['tests-04','release-tests-02','clippy-02','build-02']:
    text=(out/(stage+'.stderr')).read_text()
    assert 'Finished ' in text and not re.search(r'^(?:error|warning)(?:\[|:)',text,re.M)
assert 'HTTP status 200 instead of 422' in (out/'predecessor-red.stdout').read_text()
assert 'test result: FAILED. 0 passed; 1 failed;' in (out/'predecessor-red.stdout').read_text()
source=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
entries={}
for name in source:
    data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
    assert data==(repo/name).read_bytes()
    entries['source/'+name]=data
source_text='\n'.join(data.decode() for name,data in entries.items() if name.endswith('.rs'))
expected=set(re.findall(r'#\[(?:tokio::)?test\]\s*(?:async )?fn (\w+)',source_text))
assert len(expected)==26
for stage in ['tests-04','release-tests-02']:
    observed=set(re.findall(r'^test [\w:]+::(\w+) \.\.\. ok$',(out/(stage+'.stdout')).read_text(),re.M))
    assert observed==expected
for p in sorted(out.iterdir()):
    if p.is_file() and p.suffix in {'.stdout','.stderr','.json','.py'}: entries['local/'+p.name]=p.read_bytes()
for p in sorted((out/'explicit-predecessor-red').iterdir()):
    assert p.is_file() and p.suffix=='.rs'
    entries['local/explicit-predecessor-red/'+p.name]=p.read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-reference-enrollment-http'
dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,record in manifest.items():
        data=z.read(name)
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
binary=repo/'target/continuity-reference-app/release/q-periapt-continuity-reference-app'
copy=out/'release-strict-final'
assert not copy.exists()
shutil.copy2(binary,copy)
checks={'head':head,'source_files':len(source),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'binary_sha256_build_observation':hashlib.sha256(binary.read_bytes()).hexdigest(),
'validation':{'debug_entries':26,'release_entries':26,'behavioral_entries_per_profile':25,'child_dispatcher_entries_per_profile':1,'existing_distinct_sigkill_boundaries':14,'new_actual_tcp_enrollment_scenarios':3,'strict_all_target_clippy':'passed','strict_release_build':'passed','fmt_and_diff':'passed'},
'new_behavior':'Authenticated same-origin HTTP adapter calls original host transactions. Exact issued response bytes; original client signer/request reopen; wrong-account and anonymous rejection; body/proof/Origin checks; roster-conflict reapproval; cancellation and suspension distinguish history/current permission.',
'network_loss':'Client reads only issuance headers then closes actual TCP socket before consuming body. Status recovers the original bytes; graceful server restart on original database requires fresh software-WebAuthn authentication and returns byte-identical issuance without advancing roster again.',
'red_green':'New HTTP Option<Checkpoint> silently accepted an omitted predecessor as None. Actual TCP regression observed200 instead of422. Required-field deserializer now rejects omission while explicitnull remains valid for empty roster; full debug/release suites pass. Pre-fix source and failed output retained. Initial test compilation also failed on serde_json macro repeated-array syntax; repaired test syntax without weakening checks.',
'limits':'Optional local host only. Software authenticator simulates UV; family42 is a test fixture. No browser enrollment UI or installed-independent-client acceptance yet. No real signed-policy/traffic admission, deployed HTTPS, new power-loss/SIGKILL cuts, expired-unissued credential transition, final ABI or full lifecycle/release claim. Original real-user DB and live service untouched. No SDK source/dependency changes.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text(f'''# Authenticated enrollment HTTP adapter

Source `{head}` connects the reference host's existing enrollment transactions
to bounded same-origin HTTP routes. Authentication remains host-owned; no account
signup or Passkey dependency is added to the SDK. The adapter returns committed
issuance bytes directly and keeps historical responses separate from current
root/roster observations.

Debug and release each passed 26 entries (25 behavioral tests and one existing
child dispatcher). Three new scenarios use actual loopback TCP, software WebAuthn
signatures and native SDK device proofs. They cover account/Origin/input isolation,
original-request retries, a response-body disconnect and original-database reopen,
roster-conflict reapproval, cancellation and suspension. The existing library
suite retains its 14 distinct SIGKILL boundaries; these are not new HTTP cuts.
Strict all-target Clippy, release build, formatting and diff checks passed.

A new boundary error was reproduced before repair: omitting the reapproval
predecessor silently selected an empty roster and returned 200. The decoder now
requires that field, while explicit null still selects the empty roster. The
capture preserves the failing regression and pre-fix sources, plus the initial
test-macro compilation failure. It contains exact app/workflow source and public
diagnostics, not account databases, private keys or executables.

This is local component evidence. Browser enrollment controls, installed-client
acceptance with independently authenticated live policy/trust, deployed HTTPS,
full replacement and the expired-unissued credential transition remain open.
The real user's account database and existing local service were not modified.
''')
print(json.dumps(checks['capture']))
