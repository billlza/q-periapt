"""Reconstruct supplied fragments and transfer only exact open case leaves."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
TARGET = 'epoch_generation_secret_derivation_origin_with_phase_roots'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def target_span(text):
    start = text.index('lemma ' + TARGET + ' ')
    following = re.search(r'(?m)^lemma |^/\* All wellformedness|^end$', text[start + 1:])
    if following is None:
        raise ValueError('target has no closing boundary')
    return start, start + 1 + following.start()

def paths(text):
    start, end = target_span(text)
    stack, spans = [], {}
    offset = start
    def finish():
        node = stack.pop()
        path = tuple(x['name'] for x in stack) + (node['name'],)
        if path in spans:
            raise ValueError('duplicate case path')
        spans[path] = (node['start'], offset)
    for line in text[start:end].splitlines(keepends=True):
        case = re.fullmatch(r'( *)case (\S+)\s*', line)
        boundary = re.fullmatch(r'( *)(?:next|qed)\s*', line)
        if case:
            indent = len(case[1])
            while stack and stack[-1]['indent'] >= indent:
                finish()
            stack.append({'name': case[2], 'indent': indent, 'start': offset + len(line)})
        elif boundary:
            indent = len(boundary[1])
            while stack and stack[-1]['indent'] > indent:
                finish()
        offset += len(line)
    while stack:
        finish()
    return spans

def replace(text, edits):
    for start, end, content in sorted(edits, reverse=True):
        text = text[:start] + content + text[end:]
    return text

data = Path('/Users/bill/Downloads/snapshot-origin-progress.json').read_bytes()
if digest(data) != '2aed5e15ab6e724f2bbe35d395947e4927d7f1eb87a117b1428036828d4bd440':
    raise ValueError('supplied progress changed')
progress = json.loads(data)
base = (ROOT / 'target/p0-origin-response-final-replay-721/origin-response-final-replay-proof.spthy').read_text()
current_file = ROOT / 'target/p0-snapshot-final-replay-726/snapshot-final-replay-proof.spthy'
current = current_file.read_text()
if digest(base.encode()) != progress['base_model_sha256']:
    raise ValueError('supplied base differs')
if digest(current.encode()) != '3bfc6ae1fd37fd39f6c079a0c48bd64f9587bddc40e89aa7863553f2a06906b8':
    raise ValueError('current baseline differs')
base_paths, current_paths = paths(base), paths(current)
base_edits, edits, disposition, seen = [], [], [], set()
for item in progress['closed_branches']:
    path, proof = tuple(item['case_path']), item['proof']
    if path in seen or any(path[:len(other)] == other or other[:len(path)] == path for other in seen):
        raise ValueError('overlapping or duplicate fragment')
    seen.add(path)
    if re.search(r'\b(?:sorry|admit)\b', proof):
        raise ValueError('fragment is not closed')
    lo, hi = base_paths[path]
    if not re.fullmatch(r'\s*by sorry\s*', base[lo:hi]):
        raise ValueError('base is not an exact open leaf')
    base_edits.append((lo, hi, proof))
    if path not in current_paths:
        status = 'not_present_in_current_tree'
    else:
        lo, hi = current_paths[path]
        if re.fullmatch(r'\s*by sorry\s*', current[lo:hi]):
            edits.append((lo, hi, proof))
            status = 'transferred_pending_full_replay'
        elif 'sorry' not in current[lo:hi]:
            status = 'already_closed'
        else:
            raise ValueError('current subtree changed but remains open')
    disposition.append({'case_path': path, 'status': status})
rebuilt = replace(base, base_edits)
if digest(rebuilt.encode()) != progress['output_model_sha256']:
    raise ValueError('reconstructed supplied model differs')
candidate = replace(current, edits)
start, end = target_span(current)
cstart, cend = target_span(candidate)
if current[:start] != candidate[:cstart] or current[end:] != candidate[cend:]:
    raise ValueError('modified another lemma or model')
if len(edits) != 15 or len(re.findall(r'(?m)^lemma ', candidate)) != 35:
    raise ValueError('transfer inventory differs')
for name, text in [('supplied-reconstructed.spthy', rebuilt), ('model.spthy', candidate)]:
    with (OUT / name).open('x') as stream:
        stream.write(text)
shutil.copyfile(ROOT / 'target/p0-snapshot-final-replay-726/run.py', OUT / 'run.py')
report = {'schema_version': 1, 'progress_sha256': digest(data),
          'supplied_base_sha256': digest(base.encode()),
          'supplied_reconstructed_sha256': digest(rebuilt.encode()),
          'current_base_sha256': digest(current.encode()),
          'candidate_sha256': digest(candidate.encode()),
          'transferred_fragments': len(edits), 'queries': 35,
          'unmodified_other_lemmas_and_operational_prefix': True,
          'disposition': disposition, 'kernel_replay_verified': False,
          'origin_theorem_verified': False, 'main_secrecy_verified': False}
with (OUT / 'TRANSFER.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key != 'disposition'}))
