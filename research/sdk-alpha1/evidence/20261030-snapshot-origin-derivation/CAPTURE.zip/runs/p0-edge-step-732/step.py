"""One explicit kernel-offered proof step in a bounded loopback session."""
from pathlib import Path
from html.parser import HTMLParser
import ast,hashlib,json,os,re,signal,socket,subprocess,sys,time,urllib.request,urllib.error,urllib.parse
root=Path.cwd();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'artifact'))
from continuity_recovery_proof import prover_environment
from continuity_multi_epoch_search import theory
from evidence_io import parse_strict_json_bytes
source=root/'target/p0-role-closed-731/role-closed-replay-proof.spthy';data=source.read_bytes();assert hashlib.sha256(data).hexdigest()=='00a71757e5d40dca8bb4ed93d648e12520505088297690b51b81e408ee6a8b58'
(stage/'model.spthy').write_bytes(data)
name='epoch_generation_secret_derivation_origin_with_phase_roots'
helper=root/'target/p0-snapshot-transfer-729/prepare.py';tree=ast.parse(helper.read_text());ns={'re':re,'TARGET':name};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(helper),'exec'),ns)
text=data.decode();selected=[path for path,(lo,hi) in ns['paths'](text).items() if path[:3]==('non_empty_trace','Snapshot_case_5','Response_Compute_5') and path[-1]=='d_0_snd' and re.fullmatch(r'\s*by sorry\s*',text[lo:hi])];assert len(selected)==1
identity=json.loads((root/'target/witness-renewal-01/P0_PINNED_PROVER_IDENTITY_01.json').read_text());tools={k:identity[k]['path'] for k in ['tamarin','maude']}
for k,p in tools.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==identity[k]['sha256']
env=prover_environment();env['PATH']=os.pathsep.join([str(Path(p).parent) for p in tools.values()]+[env['PATH']])
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
origin=f'http://127.0.0.1:{port}'
argv=[tools['tamarin'],'interactive','--interface=127.0.0.1',f'--port={port}','--with-maude='+tools['maude'],'--derivcheck-timeout=60','--quit-on-warning',str(stage),'+RTS','-N1','-M12G','-c100','-s','-RTS']
class Methods(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.current=None
 def handle_starttag(self,t,a):
  if t=='a':
   d=dict(a)
   if 'proof-method' in d.get('class','').split():self.current={'href':d['href'],'text':''}
 def handle_data(self,s):
  if self.current is not None:self.current['text']+=s
 def handle_endtag(self,t):
  if t=='a' and self.current is not None:self.rows.append(self.current);self.current=None
start=time.monotonic();calls=[];failure=None
with (stage/'server.stdout').open('xb') as out,(stage/'server.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 (stage/'STARTED.json').write_text(json.dumps({'pid':p.pid,'port':port,'argv':argv,'maximum_seconds':900,'input_sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
 def request(path,label):
  assert len(calls)<12 and time.monotonic()-start<900
  url=urllib.parse.urljoin(origin,path);assert urllib.parse.urlsplit(url).netloc==f'127.0.0.1:{port}'
  with urllib.request.urlopen(url,timeout=min(600,900-(time.monotonic()-start))) as r:raw=r.read(10*1024**2+1)
  assert len(raw)<=10*1024**2
  (stage/(label+'.response')).write_bytes(raw);calls.append({'path':path,'label':label,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});return raw
 try:
  while True:
   assert p.poll() is None and time.monotonic()-start<900
   try:
    with urllib.request.urlopen(origin+'/',timeout=5) as response:landing=response.read(1024*1024)
    break
   except urllib.error.URLError as e:
    if not isinstance(e.reason,ConnectionRefusedError):raise
    time.sleep(.25)
  assert b'/thy/trace/1/overview/help' in landing
  route='/thy/trace/1/main/proof/'+name+'/'+'/'.join(urllib.parse.quote(v,safe='') for v in selected[0])
  response=parse_strict_json_bytes(request(route,'state'),label='prover state')
  parser=Methods();parser.feed(response['html']);methods=[m for m in parser.rows if 'solve(' in m['text'].replace(' ','') and '~~>' in m['text']];assert len(methods)==1,parser.rows
  method=methods[0];assert '/main/method/'+name+'/' in method['href']
  print(json.dumps({'case_path':selected[0],'method':method}),flush=True)
  raw=request(method['href'],'applied');result=parse_strict_json_bytes(raw,label='prover step response')
  print(json.dumps({'response_keys':list(result),'response_summary':{k:v[:1200] for k,v in result.items() if isinstance(v,str)}}),flush=True)
  (stage/'METHOD.json').write_text(json.dumps({'case_path':selected[0],'method':method,'response':result},indent=2)+'\n')
  if set(result)=={'redirect'} and isinstance(result['redirect'],str):
   matched=re.match(r'^/thy/trace/([0-9]+)/',result['redirect']);assert matched
   exported=request('/thy/trace/'+matched[1]+'/download/ContinuityMultiEpochRecoveryProjection.spthy','export')
   assert theory(exported)==theory(data);(stage/'exported.spthy').write_bytes(exported)
 except BaseException as e:failure={'type':type(e).__name__,'message':str(e)[:6000]}
 finally:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  record={'calls':calls,'failure':failure,'process_returncode':p.returncode,'seconds':time.monotonic()-start,'independent_full_replay_pending':True,'release_claim_eligible':False}
  (stage/'TERMINAL.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'failure':failure,'seconds':record['seconds'],'requests':len(calls)}),flush=True)
 if failure:raise SystemExit(1)
