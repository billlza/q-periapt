"""Insert only the twelve deduction methods observed at unchanged open leaves."""
from pathlib import Path
import ast,hashlib,json,re,sys
root=Path.cwd();stage=Path(__file__).resolve().parent
name='epoch_generation_secret_derivation_origin_with_phase_roots'
helper=root/'target/p0-snapshot-transfer-729/prepare.py';tree=ast.parse(helper.read_text());ns={'re':re,'TARGET':name};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(helper),'exec'),ns)
previous=root/'target/p0-snapshot-transfer-729/transferred-full-replay-proof.spthy';prior=previous.read_text();source=root/'target/p0-role-closed-731/role-closed-replay-proof.spthy';data=source.read_bytes();assert hashlib.sha256(data).hexdigest()=='00a71757e5d40dca8bb4ed93d648e12520505088297690b51b81e408ee6a8b58';text=data.decode()
old_leaves=sorted((lo,hi,path) for path,(lo,hi) in ns['paths'](prior).items() if re.fullmatch(r'\s*by sorry\s*',prior[lo:hi]));assert len(old_leaves)==26
current=ns['paths'](text);edits=[];records=[]
for ordinal,(_,_,path) in enumerate(old_leaves):
 frame=root/'target/p0-snapshot-frontiers-731/initial-send-oracle-frames'/f'{ordinal:04}.txt';raw=frame.read_bytes();lines=raw.decode().splitlines();selected=[s for s in lines if re.fullmatch(r'0: \(#vr(?:\.[0-9]+)?, 0\) ~~> \(#known, 0\)',s)]
 if not selected:continue
 assert len(selected)==1
 lo,hi=current[path];assert re.fullmatch(r'\s*by sorry\s*',text[lo:hi])
 indent=re.search(r'(?m)^( *)by sorry',text[lo:hi])[1];goal=selected[0].split(': ',1)[1]
 edits.append((lo,hi,indent+'by solve( '+goal+' )\n'));records.append({'case_path':path,'captured_goal':selected[0],'frontier_sha256':hashlib.sha256(raw).hexdigest(),'frontier_ordinal':ordinal})
assert len(edits)==12
candidate=ns['replace'](text,edits);sys.path.insert(0,str(root/'artifact'));from continuity_multi_epoch_search import theory
assert theory(candidate.encode())==theory(data) and len(theory(data).queries)==35
(stage/'model.spthy').write_text(candidate);(stage/'run.py').write_bytes((root/'target/p0-snapshot-transfer-729/run.py').read_bytes())
record={'source':str(source),'source_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'methods':records,'all_35_queries_and_operational_rules_preserved':True,'full_replay_pending':True,'closure_not_assumed':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'methods':len(edits),'input_sha256':record['input_sha256']}))
