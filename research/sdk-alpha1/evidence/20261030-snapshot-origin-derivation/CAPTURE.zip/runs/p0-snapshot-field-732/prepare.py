"""Follow exact observed constructor edges and the original encapsulation source."""
from pathlib import Path
import ast,hashlib,json,re,sys,urllib.parse
root=Path.cwd();stage=Path(__file__).resolve().parent;name='epoch_generation_secret_derivation_origin_with_phase_roots'
source=root/'target/p0-edge-frontier-732/edge-frontier-replay-proof.spthy';data=source.read_bytes();assert b'invalid proof step' not in data;text=data.decode()
helper=root/'target/p0-snapshot-transfer-729/prepare.py';tree=ast.parse(helper.read_text());ns={'re':re,'TARGET':name};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(helper),'exec'),ns);paths=ns['paths'](text)
cap=root/'target/p0-edge-states-732';report=json.loads((cap/'CAPTURE.json').read_text());assert report['failure'] is None and len(report['reads'])==15
assert json.loads((cap/'STARTED.json').read_text())['input_sha256']==hashlib.sha256(data).hexdigest()
edits=[];records=[];counts={'contradiction':0,'edge':0,'encapsulation_source':0}
for number,row in enumerate(report['reads']):
 raw=(cap/row['page']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 methods=[dict(m,normalized=' '.join(m['text'].split())) for m in row['methods']]
 contradictions=[m for m in methods if m['normalized'].startswith('contradiction')]
 edges=[m for m in methods if re.fullmatch(r'solve\( \(#vr(?:\.[0-9]+)?, 0\) ~~> \(#known, 0\) \)',m['normalized'])]
 if contradictions:
  assert len(contradictions)==1;kind='contradiction';method=contradictions[0];proof='by contradiction'
 elif edges:
  assert len(edges)==1;kind='edge';method=edges[0];proof='by '+method['normalized']
 elif number==14:
  selected=[m for m in methods if 'PositionedPhaseState(' in m['normalized'] and "'Response4'" in m['normalized'] and '▶₀ #vr.8' in m['normalized']]
  assert len(selected)==1;kind='encapsulation_source';method=selected[0];proof='by '+method['normalized']
 else:continue
 path=tuple(urllib.parse.unquote(row['target'].split('/main/proof/'+name+'/')[1]).split('/'));lo,hi=paths[path]
 assert re.fullmatch(r'\s*by sorry\s*',text[lo:hi]);indent=re.search(r'(?m)^( *)by sorry',text[lo:hi])[1]
 edits.append((lo,hi,indent+proof+'\n'));records.append({'case_path':path,'method':method,'kind':kind,'state_sha256':row['sha256']});counts[kind]+=1
assert counts=={'contradiction':3,'edge':8,'encapsulation_source':1}
candidate=ns['replace'](text,edits);sys.path.insert(0,str(root/'artifact'));from continuity_multi_epoch_search import theory
assert theory(candidate.encode())==theory(data) and len(theory(data).queries)==35
(stage/'model.spthy').write_text(candidate);(stage/'run.py').write_bytes((root/'target/p0-snapshot-transfer-729/run.py').read_bytes())
record={'source':str(source),'source_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'methods':records,'counts':counts,'all_35_queries_and_operational_rules_preserved':True,'full_replay_pending':True,'main_secrecy_verified':False,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'counts':counts,'input_sha256':record['input_sha256']}))
