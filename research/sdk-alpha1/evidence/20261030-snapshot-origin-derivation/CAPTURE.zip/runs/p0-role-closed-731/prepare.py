"""Close only four kernel-listed contradictions in the unchanged full theory."""
from pathlib import Path
from html.parser import HTMLParser
import ast,hashlib,json,re,sys,urllib.parse
root=Path.cwd();stage=Path(__file__).resolve().parent;target='epoch_generation_secret_derivation_origin_with_phase_roots'
parent=root/'target/p0-snapshot-role-731/role-source-replay-proof.spthy';data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()=='e275d7d7b3f3001d22e6a47df58a9dd973a4d54ae279a7ad02ad7ccb52fea8ad'
helper=root/'target/p0-snapshot-transfer-729/prepare.py';ast_tree=ast.parse(helper.read_text());ns={'re':re,'TARGET':target}
exec(compile(ast.Module(body=[n for n in ast_tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(helper),'exec'),ns)
class Methods(HTMLParser):
 def __init__(self):super().__init__();self.current=None;self.rows=[]
 def handle_starttag(self,t,a):
  if t=='a':
   attrs=dict(a)
   if 'proof-method' in attrs.get('class','').split():self.current={'href':attrs['href'],'text':''}
 def handle_data(self,s):
  if self.current is not None:self.current['text']+=s
 def handle_endtag(self,t):
  if t=='a' and self.current is not None:self.rows.append(self.current);self.current=None
states=root/'target/p0-role-states-731';targets=json.loads((states/'TARGETS.json').read_text());assert len(targets)==4
text=data.decode();paths=ns['paths'](text);edits=[];records=[]
for number,url in enumerate(targets):
 raw=(states/f'page-{number}.html').read_bytes();response=json.loads(raw);parser=Methods();parser.feed(response['html'])
 assert len(parser.rows)==1 and 'contradiction' in parser.rows[0]['text'] and 'forbidden KD-fact' in parser.rows[0]['text']
 parts=tuple(urllib.parse.unquote(url.split('/main/proof/'+target+'/')[1]).split('/'));assert parts[-2]=='d_0_scope_role' and parts[-1] in ('Setup_case_1','Setup_case_2')
 lo,hi=paths[parts];assert re.fullmatch(r'\s*by sorry\s*',text[lo:hi])
 indent=re.search(r'(?m)^( *)by sorry',text[lo:hi])[1]
 edits.append((lo,hi,indent+'by contradiction\n'));records.append({'case_path':parts,'kernel_method':parser.rows[0],'state_response_sha256':hashlib.sha256(raw).hexdigest()})
candidate=ns['replace'](text,edits);sys.path.insert(0,str(root/'artifact'));from continuity_multi_epoch_search import theory
assert theory(candidate.encode())==theory(data) and len(theory(data).queries)==35
(stage/'model.spthy').write_text(candidate);(stage/'run.py').write_bytes((root/'target/p0-snapshot-transfer-729/run.py').read_bytes())
record={'parent_sha256':hashlib.sha256(data).hexdigest(),'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'kernel_states':records,'all_35_queries_and_operational_rules_preserved':True,'full_replay_pending':True,'main_secrecy_verified':False,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'four_explicit_contradictions':len(edits),'input_sha256':record['input_sha256']}))
