"""Start, inspect, and stop one bounded local prover without idle hand-off."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,os,signal,socket,subprocess,sys,time,urllib.request,urllib.error,urllib.parse
sys.path.insert(0,str(Path.cwd()/'artifact'))
from continuity_recovery_proof import prover_environment
root=Path.cwd();stage=Path(__file__).resolve().parent
source=root/'target/p0-snapshot-field-732/field-replay-proof.spthy';data=source.read_bytes();assert b'invalid proof step' not in data
(stage/'model.spthy').write_bytes(data)
identity=json.loads((root/'target/witness-renewal-01/P0_PINNED_PROVER_IDENTITY_01.json').read_text())
tools={k:identity[k]['path'] for k in ['tamarin','maude']}
for k,p in tools.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==identity[k]['sha256']
env=prover_environment();env['PATH']=os.pathsep.join([str(Path(p).parent) for p in tools.values()]+[env['PATH']])
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
origin='http://127.0.0.1:'+str(port)
argv=[tools['tamarin'],'interactive','--interface=127.0.0.1','--port='+str(port),'--with-maude='+tools['maude'],'--derivcheck-timeout=60','--quit-on-warning',str(stage),'+RTS','-N1','-M12G','-c100','-s','-RTS']
class Links(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.current=None
 def handle_starttag(self,t,a):
  if t=='a':self.current={'href':dict(a).get('href'),'classes':dict(a).get('class',''),'text':''}
 def handle_data(self,s):
  if self.current is not None:self.current['text']+=s
 def handle_endtag(self,t):
  if t=='a' and self.current is not None:self.rows.append(self.current);self.current=None
start=time.monotonic();reads=[];failure=None
with (stage/'server.stdout').open('xb') as out,(stage/'server.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 (stage/'STARTED.json').write_text(json.dumps({'pid':p.pid,'port':port,'argv':argv,'maximum_seconds':900,'input_sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
 try:
  while True:
   assert p.poll() is None,'prover stopped before request'
   assert time.monotonic()-start<900,'bounded session expired'
   try:
    with urllib.request.urlopen(origin+'/',timeout=5) as r:raw=r.read(10*1024**2+1)
    break
   except urllib.error.URLError as e:
    if not isinstance(e.reason,ConnectionRefusedError):raise
    time.sleep(.25)
  targets=json.loads((stage/'TARGETS.json').read_text())
  for number,relative in enumerate(targets):
   url=urllib.parse.urljoin(origin,relative);assert urllib.parse.urlsplit(url).netloc=='127.0.0.1:'+str(port)
   with urllib.request.urlopen(url,timeout=min(600,900-(time.monotonic()-start))) as response:raw=response.read(10*1024**2+1)
   assert len(raw)<=10*1024**2
   page=stage/f'page-{number}.html';page.write_bytes(raw)
   response=json.loads(raw);parser=Links();parser.feed(response['html']);links=parser.rows
   reads.append({'target':relative,'page':page.name,'sha256':hashlib.sha256(raw).hexdigest(),'links':links})
   methods=[r for r in links if 'proof-method' in r['classes'].split()]
   reads[-1]['methods']=methods
   print(json.dumps({'page':number,'method_count':len(methods),'first_methods':[' '.join(r['text'].split())[:150] for r in methods[:2]]}),flush=True)
 except BaseException as e:
  failure={'type':type(e).__name__,'message':str(e)}
 finally:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  record={'reads':reads,'failure':failure,'process_returncode':p.returncode,'seconds':time.monotonic()-start,'proof_modified':False,'release_claim_eligible':False}
  (stage/'CAPTURE.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'pages':len(reads),'failure':failure,'seconds':record['seconds'],'process_returncode':p.returncode}),flush=True)
 if failure:raise SystemExit(1)
