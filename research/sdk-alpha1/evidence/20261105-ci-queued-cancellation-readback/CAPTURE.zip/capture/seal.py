from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ci-readback-26'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-queued-cancellation-readback'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
status = json.loads((BASE / 'CI_STATUS.json').read_bytes())
jobs = {j['id']: (r['run_id'], j) for r in status['results'] for j in r['jobs']}
assert len(jobs) == 334
counts = {}
for _, j in jobs.values():
    key = j['conclusion'] or j['status']; counts[key] = counts.get(key, 0) + 1
assert counts == status['counts'] == {'success': 298, 'failure': 29, 'skipped': 2, 'in_progress': 4, 'cancelled': 1}
_, cancelled = jobs[126456506355]
assert cancelled['status'] == 'completed' and cancelled['conclusion'] == 'cancelled'
assert cancelled['steps'] == [] and cancelled['runner_id'] == 0 and cancelled['runner_name'] == ''
started = datetime.fromisoformat(cancelled['started_at'].replace('Z', '+00:00'))
ended = datetime.fromisoformat(cancelled['completed_at'].replace('Z', '+00:00'))
assert (ended - started).total_seconds() == 86401
missing = json.loads((BASE / 'cancelled-job-log-response.json').read_bytes())
assert missing['isError'] and missing['structuredContent']['error_code'] == 'NOT_FOUND'
assert 'BlobNotFound' in missing['structuredContent']['error']
unsupported = json.loads((BASE / 'check-run-endpoint-response.json').read_bytes())
assert unsupported['isError'] and unsupported['structuredContent']['error_code'] == 'INVALID_ARGUMENT'
assert 'not an allowed public GitHub repository or search endpoint' in unsupported['structuredContent']['error']
_, failed = jobs[126449258004]
assert failed['status'] == 'completed' and failed['conclusion'] == 'failure'
text = (BASE / 'job-126449258004.log').read_text()
commit = '475cd23923e45819b01b6041c91c44540ec056ec'
assert re.search(r'git log -1 --format=%H\n\S+Z ' + commit + r'\s*\n', text)
assert 'report["witness_exchanges"] == 142' in text
assert 'ValueError: OpenSSL server exchange census differs' in text
assert 'result["c_consumer"] = qualify_c(' in text
matches = re.findall(r'Artifact (.+?) has been successfully uploaded! Final size is ([0-9]+) bytes\. Artifact ID is ([0-9]+)', text)
digests = re.findall(r'SHA256 digest of uploaded artifact is ([0-9a-f]{64})', text)
assert len(matches) == len(digests) == 1
name, size, artifact_id = matches[0]
classification = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at': status['observed_at'], 'wave_counts': status['counts'],
    'queued_cancellation': {'job_id': cancelled['id'], 'run_id': cancelled['run_id'],
        'status': cancelled['status'], 'conclusion': cancelled['conclusion'], 'steps': [],
        'runner_id': 0, 'runner_name': '', 'api_started_at': cancelled['started_at'],
        'api_completed_at': cancelled['completed_at'], 'reported_timestamp_span_seconds': 86401,
        'execution_established': False, 'cancel_cause_established': False,
        'log_result': '404 BlobNotFound', 'annotation_endpoint_result': 'Connector URL endpoint unsupported',
        'scope': 'Never count the queued timestamp as observed execution time. No runner or step execution is established. The cancellation cause and actor are not established by these receipts.'},
    'new_p0': {'job_id': failed['id'], 'run_id': failed['run_id'], 'actual_checkout': commit,
        'observed_p0_failure_count': 23, 'hosted_numeric_server_count_disclosed': False,
        'kotlin_consumer_execution_established': False,
        'reported_artifact': {'name': name, 'bytes': int(size), 'id': int(artifact_id), 'sha256': digests[0]},
        'artifact_downloaded_locally': False},
    'documentation_check': {'url': 'https://docs.github.com/en/actions/reference/limits',
        'observed_utc': '2026-11-05', 'scope': 'The published 24-hour job-queue row is labelled self-hosted; it is not used to assert a cause for this macos-15 job.'},
    'effective_wave_open': True, 'push_performed': False, 'rerun_performed': False,
    'workflow_cancelled_by_this_task': False, 'release_claim_eligible': False}
files = {'capture/' + p.name: p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
