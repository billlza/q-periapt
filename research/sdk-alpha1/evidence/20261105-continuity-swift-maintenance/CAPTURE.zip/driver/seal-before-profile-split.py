"""Seal a terminal Apple/Swift extension; never interpret a partial run as passed."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import zipfile

import continuity_package as package
import continuity_swift_consumer as swift
import continuity_c_enrollment as enrollment
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-swift-managed-cohort'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = SOURCE / 'target/swift-managed-qualification/result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-continuity-swift-maintenance'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
WORKFLOW_SHA = 'aa6e752c641ada7a712f889b290109fb634b7b48b963ff34a273a6ee29a81586'


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def obj(path): return json.loads(read(path))
def encode(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


launch = obj(BASE / 'LAUNCH_RESULT.json')
driver = obj(BASE / 'DRIVER_RESULT.json')
assert launch['completed'] and launch['returncode'] == 0 and driver['completed']
assert driver['source_inputs_unchanged'] and driver['native_foundation_unchanged']
assert driver['source_commit'] == COMMIT and driver['sdk_report_sha256'] == REPORT_SHA
assert digest(REPORT) == REPORT_SHA
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (COMMIT, False)
apple = obj(OUTPUT / 'CONTINUITY_APPLE_PACKAGE.json')
consumer = obj(OUTPUT / 'SWIFT_CONSUMER.json')
assert apple == driver['apple_package'] and apple['completed']
assert consumer == driver['swift_consumer'] and consumer['completed'] and consumer['partition_completed']
assert consumer['build_profiles'] == ['debug', 'release'] and set(consumer['profiles']) == {'debug', 'release'}
assert consumer['minimum_root']['completed']
assert apple['targets'] == ['aarch64-apple-darwin', 'aarch64-apple-ios', 'aarch64-apple-ios-sim']
assert not apple['physical_device_execution'] and not apple['simulator_execution']
before = driver['source_inputs']
current = package.source_inputs()
assert current['rust_workspace_sha256'] == before['rust_workspace_sha256']
assert current['files'].keys() == before['files'].keys()
differences = {name: {'qualified': before['files'][name], 'current': value}
               for name, value in current['files'].items() if value != before['files'][name]}
assert set(differences) == {'.github/workflows/ci.yml'}
assert differences['.github/workflows/ci.yml']['current'] == WORKFLOW_SHA
assert all(digest(SOURCE / name) == expected for name, expected in before['files'].items())
assert sdk.rust_workspace_source_digest(SOURCE) == before['rust_workspace_sha256']
for row in driver['native_binaries'].values(): assert digest(Path(row['path'])) == row['sha256']
for row in driver['sdk_archives'].values(): assert digest(Path(row['path'])) == row['sha256']
for name, expected in driver['native_build_receipts'].items():
    assert digest(OUTPUT / name) == expected
    assert digest(SOURCE / 'target/c-managed-qualification/result-01' / name) == expected
archive = apple['archive']
assert (OUTPUT / archive['file']).stat().st_size == archive['bytes']
assert digest(OUTPUT / archive['file']) == archive['sha256']
publications = {}
for profile, row in consumer['profiles'].items():
    swift.verify_tests(read(OUTPUT / f'swift-tests-{profile}.stdout'), read(OUTPUT / f'swift-tests-{profile}.stderr'))
    assert digest(OUTPUT / row['archive']) == row['archive_sha256']
    assert digest(Path(row['binary']['path'])) == row['binary']['sha256']
    directory = OUTPUT / 'swift-publication-public' / profile
    checked = enrollment.verify_execution(read(OUTPUT / f'swift-publication-{profile}.stdout'),
                                           directory, language='Swift', publication=True)
    assert checked == row['enrollment']['publication']['execution']
    assert {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()} == set(checked['public_readbacks'])
    publications[profile] = {'exact_publication_readback': True, 'files': len(checked['public_readbacks']),
                             'archive_sha256': row['archive_sha256'], 'binary_sha256': row['binary']['sha256']}

workflow = read(ROOT / '.github/workflows/ci.yml')
assert sha(workflow) == WORKFLOW_SHA
section = workflow.decode().split('\n  continuity-installed-swift:\n', 1)[1]
section = re.split(r'\n  [A-Za-z0-9_-]+:\n', section, maxsplit=1)[0]
patterns = re.findall(r'^\s+target/continuity-installed-swift/(.+)$', section, re.M)
assert 'swift-publication-public/**' in patterns and '*.zip' in patterns and '*.json' in patterns
selected = set()
for pattern in patterns:
    if pattern.endswith('/**'):
        for directory in OUTPUT.glob(pattern[:-3]):
            assert directory.is_dir() and not directory.is_symlink()
            selected.update(p for p in directory.rglob('*') if p.is_file())
    else:
        selected.update(p for p in OUTPUT.glob(pattern) if p.is_file())
actual = {p for p in OUTPUT.rglob('*') if p.is_file()}
assert selected == actual, 'Every output must be covered by the repaired explicit CI upload selection.'
assert not any(p.is_symlink() for p in OUTPUT.rglob('*'))
public_manifests = []
for path in sorted(OUTPUT.rglob('PUBLIC_FILES.json')):
    row = obj(path)
    assert row['completed'] and isinstance(row['files'], dict)
    for name, expected in row['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert digest(path.parent / relative) == expected
    leaves = {p.relative_to(path.parent).as_posix() for p in path.parent.rglob('*') if p.is_file()}
    assert leaves == set(row['files']) | {'PUBLIC_FILES.json'}
    public_manifests.append({'path': path.relative_to(OUTPUT).as_posix(), 'files': len(row['files']), 'sha256': digest(path)})
commands = []
for path in sorted(OUTPUT.glob('*.json')):
    row = obj(path)
    if isinstance(row, dict) and isinstance(row.get('argv'), list) and 'returncode' in row:
        commands.append({'receipt': path.name, 'returncode': row['returncode']})
files = {'output/' + p.relative_to(OUTPUT).as_posix(): read(p) for p in sorted(selected)}
for name in ['PREPARATION.json', 'NATIVE_RECEIPT_PREPARATION.json', 'INPUTS.json', 'LAUNCH.json',
             'LAUNCH_RESULT.json', 'DRIVER_RESULT.json', 'launch.py', 'driver.stdout', 'driver.stderr',
             'run-before-build-receipts.py', 'seal_complete.py']:
    files['driver/' + name] = read(BASE / name)
files['driver/run.py'] = read(SOURCE / 'target/swift-managed-qualification/run.py')
files['driver/streamed_command.py'] = read(ROOT / 'target/continuity-installed-managed-cohort/run_package.py')
files['source/qualified-ci.yml'] = read(SOURCE / '.github/workflows/ci.yml')
files['source/repaired-export-ci.yml'] = workflow
files['producer/RUST_SDK_PACKAGE.json'] = read(REPORT)
readback = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed': True,
    'source_commit': COMMIT, 'sdk_producer_commit': driver['sdk_producer_commit'], 'sdk_report_sha256': REPORT_SHA,
    'scope': driver['scope'], 'apple_targets': apple['targets'],
    'physical_device_execution': False, 'simulator_execution': False,
    'native_foundation_reused': True, 'native_foundation_unchanged': True,
    'runtime_source_inputs_identical_to_current_main': True,
    'only_selected_input_difference': differences,
    'publication_readback': publications, 'owner_test_outputs_rechecked': ['debug', 'release'],
    'minimum_root_completed': True, 'minimum_root_scope': consumer['minimum_root']['scope'],
    'public_manifests': public_manifests, 'top_level_command_receipts': len(commands),
    'observed_returncodes': dict(Counter(str(row['returncode']) for row in commands)),
    'returncode_scope': 'Expected fault/refusal exits remain retained and are evaluated by their unchanged scenario validators.',
    'output_files': len(selected), 'output_bytes': sum(p.stat().st_size for p in selected),
    'upload_patterns': patterns, 'gate_elapsed_seconds': launch['elapsed_seconds'],
    'timeout_seconds': launch['timeout_seconds'], 'component_timeout_seconds': 900,
    'release_claim_eligible': False, 'publication_performed': False,
    'not_claimed': ['Hosted CI completion', 'Kotlin/Android qualification', 'iOS runtime', 'GNU/Linux runtime',
                    'Physical power loss', 'Formal Continuity product ABI admission', 'External review']}
files['READBACK.json'] = encode(readback)
manifest = {name: {'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
groups = {'PACKAGES.zip': {}, 'CAPTURE.zip': {}}
for name, body in files.items():
    group = 'PACKAGES.zip' if name.startswith('output/') and name.endswith('.zip') else 'CAPTURE.zip'
    groups[group][name] = body
assert len(groups['PACKAGES.zip']) == 4, 'Reassess the package inventory if it changes.'
payloads = {}
for archive_name, entries in groups.items():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
            info.create_system = 3; info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    data = buffer.getvalue()
    assert len(data) < 100 * 1024**2, f'Split {archive_name} explicitly before exceeding the repository artifact bound.'
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert len(archive.infolist()) == len(set(archive.namelist())) == len(entries)
        assert set(archive.namelist()) == set(entries)
        assert all(archive.read(name) == body for name, body in entries.items())
    payloads[archive_name] = data
DEST.mkdir(parents=True, exist_ok=False)
for name, body in {**payloads, 'FILES.json': files['FILES.json'], 'READBACK.json': files['READBACK.json']}.items():
    with (DEST / name).open('xb') as stream: stream.write(body)
summary = {name: {'bytes': len(data), 'members': len(groups[name]), 'sha256': sha(data)} for name, data in payloads.items()}
with (DEST / 'SHA256.json').open('xb') as stream: stream.write(encode(summary))
print(json.dumps(summary), flush=True)
