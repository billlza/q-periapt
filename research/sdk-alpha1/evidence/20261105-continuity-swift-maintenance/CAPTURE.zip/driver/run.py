from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import sys

MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
SOURCE = MAIN/'target/continuity-managed-maintenance/source-f560d803'
BASE = MAIN/'target/continuity-swift-managed-cohort'
C_BASE = MAIN/'target/continuity-c-managed-cohort'
C_OUTPUT = SOURCE/'target/c-managed-qualification/result-01'
OUTPUT = SOURCE/'target/swift-managed-qualification/result-01'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
REPORT = SOURCE/'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def obj(path):
    return json.loads(path.read_bytes())

def write(path, value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')

def main():
    assert Path.cwd() == SOURCE
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
    import rust_sdk_profile as sdk
    import continuity_package as package
    from continuity_apple_package import qualify_apple, file_hashes
    from continuity_swift_consumer import qualify_swift
    from rust_sdk_msrv import validate_report, tool_identity
    assert sdk.ROOT == package.ROOT == SOURCE
    sdk.validate_no_registry_credentials(os.environ)
    assert sdk.inspect_package_source(SOURCE,allow_dirty=False) == (COMMIT,False)
    # Both native profiles must have completed before this dependent extension.
    assert obj(C_BASE/'LAUNCH_RESULT.json')['completed']
    assert obj(C_BASE/'DRIVER_RESULT.json')['completed']
    foundation_bytes=(C_OUTPUT/'CONTINUITY_PACKAGE.json').read_bytes()
    foundation=json.loads(foundation_bytes)
    native_bytes=(C_OUTPUT/'C_CONSUMER.json').read_bytes()
    native=json.loads(native_bytes)
    assert foundation['completed'] and foundation['partition_completed'] and foundation['sources_unchanged']
    assert foundation['source_commit']==COMMIT and foundation['rust_report_sha256']==REPORT_SHA
    assert foundation['c_consumer']==native
    assert native['completed'] and native['partition_completed']
    assert foundation['build_profiles']==native['build_profiles']==['debug','release']
    assert set(native['execution'])=={'debug','release'}
    assert all(native['execution'][p]['witness_openssl']['completed'] for p in native['execution'])
    before=package.source_inputs()
    assert before==foundation['source_inputs']
    assert digest(REPORT)==REPORT_SHA
    cohort=validate_report(REPORT.read_bytes(),REPORT_SHA,REPORT_SHA,before['rust_workspace_sha256'])
    archives={}
    for name,row in cohort['crates'].items():
        path=REPORT.parent/'crates'/row['file']
        assert not path.is_symlink() and path.stat().st_size==row['bytes'] and digest(path)==row['sha256']
        archives[name]={'path':str(path),'sha256':row['sha256'],'bytes':row['bytes']}
    readiness=obj(BASE/'PREPARATION.json')
    chain=Path(readiness['full_toolchain'])
    minimum=Path(readiness['minimum_toolchain'])
    tools=package.compiler_identity(chain)
    minimum_tools=tool_identity(minimum)
    for name,row in tools.items():
        assert row['sha256']==foundation['tool_binaries'][name]['sha256'],name
    for name,expected in readiness['host_std_identical'].items():
        assert digest(chain/'lib/rustlib/aarch64-apple-darwin/lib'/name)==expected
    for target,rows in readiness['apple_target_std'].items():
        for name,row in rows.items():
            path=chain/'lib/rustlib'/target/'lib'/name
            assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256']
    outside=Path(obj(C_OUTPUT/'location.json')['path'])
    assert outside.resolve(strict=True)==outside and not outside.is_relative_to(SOURCE)
    c_source_before=file_hashes(outside/'c-consumer')
    binaries={}
    for profile,row in native['execution'].items():
        for name,binary in row['binaries'].items():
            path=Path(binary['path'])
            assert path.is_relative_to(outside) and digest(path)==binary['sha256']
            binaries[profile+'/'+name]=binary
    helper=MAIN/'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command=runpy.run_path(str(helper),run_name='installed_stream_capture_helpers')['streamed_command']
    OUTPUT.mkdir(parents=True,mode=0o700,exist_ok=False)
    (OUTPUT/'base-CONTINUITY_PACKAGE.json').write_bytes(foundation_bytes)
    (OUTPUT/'base-C_CONSUMER.json').write_bytes(native_bytes)
    # Foreign enrollment/retirement validators read the original native Cargo
    # build streams from this output root to bind their reused harness binaries.
    native_build_receipts={}
    for profile in ('debug','release'):
        for target in ('enrollment','enrollment-witness','retirement'):
            for suffix in ('json','stdout','stderr'):
                name=f'c-{target}-build-{profile}.{suffix}'
                sdk.copy(C_OUTPUT/name,OUTPUT/name)
                native_build_receipts[name]=digest(OUTPUT/name)
    env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_'))}
    env.update(CARGO_HOME=str(outside/'cargo-home'),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',
        CARGO_HTTP_MULTIPLEXING='false',CARGO_TARGET_DIR=str(outside/'build'),CARGO_INCREMENTAL='0',
        RUSTC=str(chain/'bin/rustc'),RUSTDOC=str(chain/'bin/rustdoc'),
        RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',
        DYLD_FALLBACK_LIBRARY_PATH=str(chain/'lib'),
        PATH=str(chain/'bin')+os.pathsep+env.get('PATH',os.defpath))
    state={'schema_version':1,'kind':'qperiapt.continuity_swift_installed_extension',
        'completed':False,'release_claim_eligible':False,'publication_performed':False,
        'started_utc':datetime.now(timezone.utc).isoformat(),'source_commit':COMMIT,
        'source_inputs':before,'sdk_producer_commit':cohort['base_commit'],'sdk_report_sha256':REPORT_SHA,
        'foundation_report_sha256':hashlib.sha256(foundation_bytes).hexdigest(),
        'foundation_c_report_sha256':hashlib.sha256(native_bytes).hexdigest(),
        'foundation_native_scope':'Previously completed same-host installed Rust/C Debug+Release, including independent OpenSSL carrier; actual original outputs reused without changing their receipts.',
        'scope':'Full existing Apple packaging and Swift Debug/Release qualifiers over the identical installed C foundation; Rust 1.90 minimum root regression. iOS builds are not device or simulator runtime acceptance.',
        'tool_binaries':tools,'minimum_tool_binaries':minimum_tools,'sdk_archives':archives,
        'outside':str(outside),'c_source_before':c_source_before,'native_binaries':binaries,
        'native_build_receipts':native_build_receipts,
        'driver_sha256':digest(Path(__file__)),'stream_helper_sha256':digest(helper),
        'allocator_environment':os.environ.get('MallocNanoZone')}
    write(BASE/'INPUTS.json',state)
    try:
        state['apple_package']=qualify_apple(outside,OUTPUT,env)
        state['swift_consumer']=qualify_swift(outside,OUTPUT,native,env,minimum)
        assert state['apple_package']['completed']
        assert state['swift_consumer']['completed'] and state['swift_consumer']['partition_completed']
        assert state['swift_consumer']['minimum_root']['completed']
        assert sorted(state['swift_consumer']['profiles'])==['debug','release']
        assert package.source_inputs()==before and sdk.inspect_package_source(SOURCE,allow_dirty=False)==(COMMIT,False)
        assert package.compiler_identity(chain)==tools and tool_identity(minimum)==minimum_tools
        assert file_hashes(outside/'c-consumer')==c_source_before
        assert (C_OUTPUT/'CONTINUITY_PACKAGE.json').read_bytes()==foundation_bytes
        assert (C_OUTPUT/'C_CONSUMER.json').read_bytes()==native_bytes
        for name,expected in native_build_receipts.items():
            assert digest(C_OUTPUT/name)==digest(OUTPUT/name)==expected
        for row in binaries.values():assert digest(Path(row['path']))==row['sha256']
        for row in archives.values():assert digest(Path(row['path']))==row['sha256']
        for name,expected in readiness['host_std_identical'].items():
            assert digest(chain/'lib/rustlib/aarch64-apple-darwin/lib'/name)==expected
        for target,rows in readiness['apple_target_std'].items():
            for name,row in rows.items():assert digest(chain/'lib/rustlib'/target/'lib'/name)==row['sha256']
        state.update(completed=True,source_inputs_unchanged=True,native_foundation_unchanged=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:
        state['finished_utc']=datetime.now(timezone.utc).isoformat()
        write(BASE/'DRIVER_RESULT.json',state)
        print(json.dumps({'completed':state['completed'],'output':str(OUTPUT),
                          'error_type':state.get('error_type'),'error':state.get('error')},indent=2),flush=True)

if __name__=='__main__':main()
