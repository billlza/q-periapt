from pathlib import Path
import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import sys
import time

from bounded_process import capture_output
import rust_sdk_profile as sdk

MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
BASE = MAIN / 'target/continuity-installed-managed-cohort'
SOURCE = MAIN / 'target/continuity-managed-maintenance/source-f560d803'
CHAIN = MAIN / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
COMMIT = '4effa8b2b25e7403ab912b65894a7d1e73695542'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def streamed_command(argv, prefix, cwd, *, environment=None):
    """Retain sdk.command's validation/limits and stream both bounded outputs."""
    prefix = Path(prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    receipt_path = prefix.with_suffix('.json')
    assert not receipt_path.exists(), receipt_path
    receipt = {'argv': list(argv), 'cwd': str(cwd), 'started_utc': timestamp(),
               'timeout_seconds': 900, 'maximum_stdout_bytes': 16 * 1024**2,
               'maximum_stderr_bytes': 16 * 1024**2, 'completed': False}
    if environment is not None:
        names = ('CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_NET_OFFLINE', 'CARGO_HTTP_MULTIPLEXING',
                 'CARGO_INCREMENTAL', 'CARGO', 'RUSTC', 'RUSTDOC', 'RUSTFLAGS', 'RUSTDOCFLAGS',
                 'DYLD_FALLBACK_LIBRARY_PATH', 'LD_LIBRARY_PATH', 'PATH',
                 'QPERIAPT_PUBLIC_SERVICE_EVIDENCE')
        receipt['selected_environment'] = {k: environment[k] for k in names if k in environment}
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print('START', prefix.name, timestamp(), flush=True)
    started = time.monotonic()
    try:
        with prefix.with_suffix('.stdout').open('xb', buffering=0) as out, prefix.with_suffix('.stderr').open('xb', buffering=0) as err:
            with contextlib.chdir(cwd):
                result = capture_output(argv, timeout_seconds=900,
                    maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2,
                    environment=environment, stdout_sink=out.write, stderr_sink=err.write)
        receipt.update(returncode=result.returncode)
        sdk.require(result.returncode == 0, f'command failed ({result.returncode}): {prefix}.stderr')
        sdk.validate_cargo_output(prefix.name, [result.stdout.decode(), result.stderr.decode()])
        receipt['completed'] = True
        return result.stdout
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        for attribute in ('kind', 'cleanup_ambiguous', 'signal_number'):
            if hasattr(error, attribute): receipt[attribute] = getattr(error, attribute)
        raise
    finally:
        receipt.update(finished_utc=timestamp(), elapsed_seconds=time.monotonic() - started,
                       stdout_sha256=digest(prefix.with_suffix('.stdout')),
                       stderr_sha256=digest(prefix.with_suffix('.stderr')))
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        print('END', prefix.name, receipt.get('returncode'), receipt.get('error_type'),
              round(receipt['elapsed_seconds'], 3), flush=True)


def main():
    assert Path.cwd() == SOURCE and sdk.ROOT == SOURCE
    assert sys.version_info[:2] == (3, 14)
    assert os.environ.get('QPERIAPT_PYTHON_ENV_INITIALIZED') == '1'
    preflight = BASE / 'preflight'
    preflight.mkdir(mode=0o700)
    assert (SOURCE / '.git').is_dir()
    assert streamed_command(['git', 'status', '--porcelain'], preflight / 'git-status-before', SOURCE) == b''
    head = streamed_command(['git', 'rev-parse', 'HEAD'], preflight / 'git-head-before', SOURCE).decode().strip()
    if head != COMMIT:
        streamed_command(['git', 'fetch', 'origin', COMMIT], preflight / 'git-fetch', SOURCE)
        streamed_command(['git', 'merge', '--ff-only', COMMIT], preflight / 'git-fast-forward', SOURCE)
    assert streamed_command(['git', 'rev-parse', 'HEAD'], preflight / 'git-head-selected', SOURCE).decode().strip() == COMMIT
    assert streamed_command(['git', 'status', '--porcelain'], preflight / 'git-status-selected', SOURCE) == b''
    changes = streamed_command(['git', 'diff', '--name-only', 'f560d803c43a24fff222daa5e5e5bd623bfdf874', COMMIT], preflight / 'cohort-followups', SOURCE).decode().splitlines()
    assert all(p.startswith(('docs/', 'research/sdk-alpha1/evidence/')) for p in changes), changes
    assert digest(REPORT) == REPORT_SHA
    report = json.loads(REPORT.read_bytes())
    assert report['base_commit'] == 'f560d803c43a24fff222daa5e5e5bd623bfdf874'
    from rust_sdk_msrv import validate_report
    validate_report(REPORT.read_bytes(), REPORT_SHA, digest(REPORT), sdk.source_identity()['rust_workspace_sha256'])
    archives = {}
    for name, record in report['crates'].items():
        path = REPORT.parent / 'crates' / record['file']
        assert path.is_file() and not path.is_symlink()
        assert digest(path) == record['sha256'] and path.stat().st_size == record['bytes']
        archives[name] = {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}
    assert len(archives) == 12
    loader = json.loads((MAIN / 'target/continuity-managed-maintenance/private-toolchain-loader.json').read_text())
    global_root = Path(loader['original'])
    tools = {}
    for name, expected in loader['copied_binary_sha256'].items():
        private, original = CHAIN / name, global_root / name
        assert digest(private) == expected == digest(original)
        tools[name] = expected
    (BASE / 'INPUTS.json').write_text(json.dumps({
        'source_commit': COMMIT, 'producer_commit': report['base_commit'],
        'report': str(REPORT), 'report_sha256': REPORT_SHA, 'archives': archives,
        'followup_changes': changes, 'tools': tools, 'private_toolchain': str(CHAIN),
        'driver_sha256': digest(BASE / 'run_package.py'), 'python': sys.executable,
        'python_isolated': sys.flags.isolated, 'python_no_site': sys.flags.no_site,
        'python_no_bytecode': sys.dont_write_bytecode,
        'command_policy': 'Existing sdk.command 900-second/16-MiB limits and validate_cargo_output, with streaming sinks; no acceptance changes.',
        'scope': 'Installed candidate archive and Debug/Release Rust consumer. Same host, no release qualification.'}, indent=2) + '\n')
    sdk.command = streamed_command
    import continuity_package as package
    selected = SOURCE / 'target/continuity-installed-managed-cohort/rust-01'
    args = argparse.Namespace(output=selected, report=REPORT, report_sha256=REPORT_SHA,
        toolchain_root=CHAIN, build_profile=None, with_c_consumer=False,
        with_apple_package=False, with_swift_consumer=False, swift_minimum_toolchain_root=None,
        with_kotlin_consumer=False, kotlin_java_home=None, kotlin_gradle_home=None,
        with_android_jni_consumer=False, android_java_home=None, witness_openssl_prefix=None)
    state = {'completed': False, 'output_original': str(selected), 'started_utc': timestamp(),
             'gate': 'artifact/continuity_package.py qualify', 'profiles': ['debug', 'release']}
    try:
        result = package.qualify(args)
        assert result['completed'] is True
        state.update(completed=True, candidate_archive_sha256=result['archive']['sha256'],
                     execution_profiles=sorted(result['execution']))
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = timestamp()
        state['report_unchanged'] = digest(REPORT) == REPORT_SHA
        state['global_selected_tool_bytes_unchanged'] = all(digest(global_root / name) == value for name, value in tools.items())
        (BASE / 'PACKAGE-DRIVER.json').write_text(json.dumps(state, indent=2) + '\n')
        if selected.exists():
            shutil.copytree(selected, BASE / 'rust-01')
        print(json.dumps(state, indent=2), flush=True)


if __name__ == '__main__':
    main()
