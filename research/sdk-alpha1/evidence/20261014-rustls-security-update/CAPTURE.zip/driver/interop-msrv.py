from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-ci-f09';inputs=json.loads((stage/'SOURCE_OVERLAY.json').read_text())['overlay'];env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';env['PYTHONPATH']='artifact'
toolchain=Path(env['RUSTC']).parent;target=root/'target/continuity-browser-fanout/native-target'
for name,digest in inputs.items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
sdk.command([str(toolchain/'cargo'),'test','--locked','--offline','-p','q-periapt-rustls','--features','standard-tls,bench-baseline,rustls/tls12','--target-dir',str(target),'-j','2'],stage/'tls12-coexistence',root,environment=env)
sdk.command([str(toolchain/'cargo'),'build','--locked','--offline','-p','q-periapt-rustls','--example','standard_peer','--features','standard-tls','--target-dir',str(target),'-j','2'],stage/'interop-build',root,environment=env)
sdk.command(['sh','artifact/python-run.sh','artifact/standard_tls_interop.py','--openssl','/opt/homebrew/opt/openssl@3/bin/openssl','--peer',str(target/'debug/examples/standard_peer'),'--output',str(stage/'interop')],stage/'interop-run',root,environment=env)
rustup=root/'target/continuity-browser-connection/msrv-tools/rustup';minimum=rustup/'toolchains/1.90.0-aarch64-apple-darwin';env.update(RUSTC=str(minimum/'bin/rustc'),RUSTDOC=str(minimum/'bin/rustdoc'),RUSTUP_HOME=str(rustup),RUSTUP_TOOLCHAIN='1.90.0-aarch64-apple-darwin',DYLD_FALLBACK_LIBRARY_PATH=str(minimum/'lib'))
sdk.command([str(minimum/'bin/cargo'),'check','--locked','--offline','-p','q-periapt-rustls','--all-features','--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/msrv-check-target'),'-j','2'],stage/'msrv-rustls',root,environment=env)
for name,digest in inputs.items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
sdk.write_json(stage/'INTEROP_MSRV_VERIFIED.json',{'completed':True,'inputs':inputs,'tls12_additive_test':True,'independent_openssl':True,'rust_1_90':True})
print('TLS feature coexistence, independent OpenSSL and Rust1.90 checks passed')
