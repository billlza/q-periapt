from pathlib import Path
import hashlib
import json
import tomllib
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-ci-f09'
destination = root / 'research/sdk-alpha1/evidence/20261014-rustls-security-update'
source = json.loads((stage / 'SOURCE_COMMIT.json').read_text())
package = Path(source['source']) / 'target/rustls-security-package-03'
report = json.loads((package / 'RUST_SDK_PACKAGE.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert report['base_commit'] == source['head'] and source['package_verified']
assert not report['git_dirty'] and not report['diagnostic_only'] and report['sources_unchanged']
assert not report['publication_performed'] and not report['release_claim_eligible']
assert report['source_inputs'] == sdk.source_identity()
for name, digest in source['paths'].items(): assert sha(root / name) == digest
for name in ('NATIVE_VERIFIED.json', 'AUDIT_VERIFIED.json', 'INTEROP_MSRV_VERIFIED.json',
             'CBOM_VERIFIED.json', 'SOURCE_CLEAN_VERIFIED.json', 'PACKAGE_03_CLEAN_VERIFIED.json'):
    assert json.loads((stage / name).read_text())['completed']
assert len(report['crates']) == 12 and report['consumer']['tests'] == 4
audits = dict(report['dependency_audits'], consumer=report['consumer']['audit'])
for audit in audits.values():
    assert audit['vulnerabilities'] == audit['warnings'] == 0
    assert audit['advisory_db_commit'] == 'caee11f41fab07d676c0a4655a2a5dd1f94da97c'
consumer = tomllib.loads((package / 'consumer-Cargo.lock').read_text())
assert [p['version'] for p in consumer['package'] if p['name'] == 'rustls'] == ['0.23.46']
interop = json.loads((stage / 'interop/manifest.json').read_text())
assert interop['completed'] and len(interop['observations']) == 8
assert all(row['passed'] for row in interop['observations'])
files = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink() and name not in files
    files[name] = path
for p in stage.iterdir():
    if p.is_file() and p.suffix in ('.json', '.stdout', '.stderr', '.py', '.log', '.zip') and p.name != 'HANDOFF_CURRENT.json':
        add(p, 'driver/' + p.name)
for p in package.iterdir():
    if p.is_file() and (p.suffix in ('.json', '.stdout', '.stderr') or p.name == 'consumer-Cargo.lock'):
        add(p, 'package/' + p.name)
for name, record in report['crates'].items():
    p = package / record['file']
    assert sha(p) == record['sha256'] and p.stat().st_size == record['bytes']
    add(p, 'package/crates/' + p.name)
for p in (stage / 'interop').iterdir():
    if p.is_file() and p.suffix in ('.json', '.stdout', '.stderr'):
        add(p, 'interop/' + p.name)
for name in source['paths']: add(root / name, 'source/' + name)
add(destination / 'README.md', 'README.md')
archive = destination / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()): z.write(path, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)
    for name, path in files.items(): assert hashlib.sha256(z.read(name)).hexdigest() == sha(path)
checks = {'completed': True, 'release_claim_eligible': False, 'source_commit': source['head'],
    'capture': {'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': len(files)},
    'source_inputs': report['source_inputs'], 'changed_inputs': source['paths'],
    'package_report_sha256': sha(package / 'RUST_SDK_PACKAGE.json'), 'crates': report['crates'],
    'consumer_tests': 4, 'native_rustls_tests': 31, 'witness_tls_tests': 16,
    'additive_tls12_tests': 21, 'openssl_cases': interop['observations'],
    'audit': audits, 'rust_1_90': True, 'strict_clippy': True,
    'unchanged_configured_algorithms': True, 'publication_performed': False,
    'private_state_included': False,
    'remaining': ['current hosted package and platform CI', 'targeted current-device refresh',
                  'CodeQL SummaryStats completion', 'full lifecycle, PCS, performance and release admission']}
sdk.write_json(destination / 'CHECKS.json', checks)
print(json.dumps({'capture': checks['capture'], 'source_commit': source['head'], 'crates': len(report['crates'])}))
