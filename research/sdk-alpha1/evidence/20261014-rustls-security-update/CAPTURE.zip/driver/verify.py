from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-ci-f09';overlay=json.loads((stage/'SOURCE_OVERLAY.json').read_text());clone=Path(overlay['source'])
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['CARGO_BUILD_JOBS']='2';env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';env['PYTHONPATH']='artifact'
toolchain=Path(env['RUSTC']).parent
for name,digest in overlay['overlay'].items():sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'source drift')
mode=sys.argv[1]
if mode=='native':
 for label,args in [('rustls-tests',['test','--locked','--offline','-p','q-periapt-rustls','--all-features','--lib','--tests']),('anchor-tls-tests',['test','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--lib','anchor::tls']),('clippy',['clippy','--locked','--offline','-p','q-periapt-rustls','--all-features','--all-targets'])]:
  sdk.command([str(toolchain/'cargo'),*args,'--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2'],stage/label,root,environment=env)
elif mode=='audit':
 env['CARGO_NET_OFFLINE']='false'
 sdk.command(['sh','artifact/python-run.sh','artifact/rust_publish_contract.py','verify-workspace-dependency-audit'],stage/'workspace-audit',clone,environment=env)
elif mode=='package':
 env['CARGO_NET_OFFLINE']='false'
 sdk.command(['sh','artifact/rust-publish-contract.sh','--profile','sdk-020','--output','target/rustls-security-package-01'],stage/'package',clone,environment=env)
else:raise ValueError(mode)
for name,digest in overlay['overlay'].items():sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'source drift')
sdk.write_json(stage/(mode.upper()+'_VERIFIED.json'),{'completed':True,'source':overlay,'mode':mode})
print(mode+' verification completed')
