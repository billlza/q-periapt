from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-ci-f09';source=json.loads((stage/'SOURCE_COMMIT.json').read_text());clone=Path(source['source']);env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['CARGO_NET_OFFLINE']='false';env['CARGO_BUILD_JOBS']='2';env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14';env['PYTHONPATH']='artifact'
for name,digest in source['paths'].items():sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'source changed')
mode=sys.argv[1]
if mode=='package':
 sdk.command(['sh','artifact/rust-publish-contract.sh','--profile','sdk-020','--output','target/rustls-security-package-02'],stage/'package-02',clone,environment=env)
elif mode=='source':
 historical='9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda'
 sdk.command(['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate',historical,source['head'],'--profile','sdk-020'],stage/'source-gate',clone,environment=env)
else:raise ValueError(mode)
for name,digest in source['paths'].items():sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'source changed')
sdk.write_json(stage/(mode.upper()+'_CLEAN_VERIFIED.json'),{'completed':True,'head':source['head'],'mode':mode})
print(mode+' clean-source verification completed')
