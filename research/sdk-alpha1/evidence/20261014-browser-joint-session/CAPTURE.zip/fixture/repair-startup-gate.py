from pathlib import Path
import json
import rust_sdk_profile as sdk
stage = Path.cwd() / 'target/continuity-browser-joint-session'
failed = json.loads((stage / 'run03/RESULT.json').read_text())
sdk.require(not failed['completed'] and 'startup console warning or error' in failed['failure'], 'unexpected failed run')
source = (stage / 'run-clean.py').read_text()
old = """            browser(['console', 'warning'], 'startup-console')
            console_files = sorted((output / '.playwright-cli').glob('console-*.log'))
            sdk.require(console_files and all(not p.read_text().strip() for p in console_files), 'startup console warning or error')"""
new = """            console = browser(['console', 'warning'], 'startup-console').decode()
            console_files = sorted((output / '.playwright-cli').glob('console-*.log'))
            sdk.require(console == '### Result\\nTotal messages: 0 (Errors: 0, Warnings: 0)\\n\\n'
                and all(not p.read_text().strip() for p in console_files), 'startup console warning or error')"""
sdk.require(source.count(old) == 1, 'startup gate shape')
sdk.require(not (stage / 'run-clean-v2.py').exists(), 'repaired driver exists')
(stage / 'run-clean-v2.py').write_text(source.replace(old, new))
print('Zero-message CLI result explicitly required; failed original retained')
