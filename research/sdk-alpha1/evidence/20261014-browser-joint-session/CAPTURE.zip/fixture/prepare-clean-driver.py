from pathlib import Path
import rust_sdk_profile as sdk
stage = Path.cwd() / 'target/continuity-browser-joint-session'
source = (stage / 'run.py').read_text()
html = '<!doctype html><meta charset="utf-8"><title>Joint policy maintenance</title><script type="module" src="./controller.js"></script>'
sdk.require(source.count(html) == 1, 'test page template')
source = source.replace(html, html.replace('<title>', '<link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>'))
source = source.replace("output = stage / label;", '''(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label;''')
before = "            for case in cases:"
sdk.require(source.count(before) == 1, 'startup gate insertion')
source = source.replace(before, '''            startup = logs / 'startup-assets.js'
            startup.write_text('async page => { await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); return {iconLoaded:true}; }')
            browser(['run-code', '--filename', str(startup)], 'startup-assets')
            browser(['console', 'warning'], 'startup-console')
            console_files = sorted((output / '.playwright-cli').glob('console-*.log'))
            sdk.require(console_files and all(not p.read_text().strip() for p in console_files), 'startup console warning or error')
            state['startup_console_clean'] = True
''' + before)
sdk.require(not (stage / 'run-clean.py').exists(), 'clean driver exists')
(stage / 'run-clean.py').write_text(source)
print('Missing test-page favicon supplied; clean startup gate added')
