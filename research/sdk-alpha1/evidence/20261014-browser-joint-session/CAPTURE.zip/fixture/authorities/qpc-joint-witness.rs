use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json, Value};
use std::{
    fs,
    io::Read,
    path::Path,
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn load(path: &Path) -> Result<Value> {
    let mut data = Vec::new();
    fs::File::open(path)?.take(1048577).read_to_end(&mut data)?;
    if data.len() > 1048576 {
        return Err("public input size".into());
    }
    Ok(serde_json::from_slice(&data)?)
}
fn bytes(v: &Value, name: &str) -> Result<Vec<u8>> {
    Ok(serde_json::from_value(
        v.get(name).ok_or("missing bytes")?.clone(),
    )?)
}
fn array(v: &Value, name: &str) -> Result<[u8; 32]> {
    Ok(bytes(v, name)?.as_slice().try_into()?)
}
fn number(v: &Value, name: &str) -> Result<u64> {
    v.get(name)
        .and_then(Value::as_u64)
        .ok_or_else(|| "missing integer".into())
}
fn store(dir: &Path, cfg: &Value) -> Result<p::AnchorStore> {
    let key = p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
    let signer = p::AnchorSigningKey::open(
        &dir.join("private-witness.key"),
        &key,
        p::SigningKeyId::from_trusted_state(array(cfg, "witness_signer_id")?)?,
    )?;
    let store = p::AnchorStore::open(
        &dir.join("private-witness.redb"),
        key,
        signer,
        p::AnchorIdentity::from_trusted_state(array(cfg, "witness_id")?)?,
    )?;
    if store.pin()?.public_key().encode() != bytes(cfg, "witness_public")? {
        return Err("witness key mismatch".into());
    }
    Ok(store)
}
fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let mode = args.get(1).ok_or("mode")?;
    let dir = Path::new(args.get(2).ok_or("directory")?);
    let cfg = load(&dir.join("PUBLIC.json"))?;
    let now = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
    match mode.as_str() {
        "enroll" => {
            if args.len() != 5 {
                return Err("enroll directory grant genesis".into());
            }
            let grant = load(Path::new(&args[3]))?;
            let genesis = load(Path::new(&args[4]))?;
            let runtime = q_periapt_sdk::Runtime::from_signed_policy(
                &bytes(&cfg, "sdk_policy")?,
                &bytes(&cfg, "sdk_signature")?,
                &bytes(&cfg, "sdk_root")?,
                None,
                q_periapt_sdk::Limits::default(),
            )?;
            let v = cfg
                .get("policies")
                .and_then(|v| v.get("required"))
                .ok_or("required policy")?;
            let policy = p::PolicyPin::new(
                array(&cfg, "family")?,
                p::PublicKey::decode(&bytes(&cfg, "policy_root")?)?,
                p::PolicyCheckpoint::from_trusted_state(
                    number(v, "version")?,
                    array(v, "digest")?,
                )?,
            )?
            .verify(&bytes(v, "wire")?, Arc::new(runtime), now)?;
            let device = p::AccountPin::new(
                array(&cfg, "account")?,
                p::PublicKey::decode(&bytes(&cfg, "root")?)?,
                p::RosterCheckpoint::from_trusted_state(
                    number(&grant, "version")?,
                    array(&grant, "digest")?,
                )?,
                array(&cfg, "family")?,
            )?
            .verify_device(
                &bytes(&grant, "certificate")?,
                &bytes(&grant, "roster")?,
                now,
            )?;
            let subject = p::AnchorSubject::for_device(
                p::JournalIdentity::from_trusted_state(array(&genesis, "journal")?)?,
                &device,
                &policy,
            )?;
            if subject.to_bytes() != bytes(&genesis, "subject")? {
                return Err("genesis subject".into());
            }
            let mut witness = store(dir, &cfg)?;
            witness.enroll(
                &p::AnchorGenesis::from_trusted_state(subject, array(&genesis, "genesis")?)?,
                &device,
                &policy,
                now,
            )?;
            witness.close();
            println!("{}", json!({"enrolled":true,"journal":genesis["journal"]}));
        }
        "handle" => {
            if args.len() != 7 {
                return Err("handle directory genesis request reply trace".into());
            }
            let request = fs::read(&args[4])?;
            if request.len() != 3674 {
                return Err("request size".into());
            }
            let mut witness = store(dir, &cfg)?;
            let reply = witness.handle(&request, now)?;
            witness.close();
            if reply.len() != 3659 {
                return Err("reply size".into());
            }
            publish_private_bytes(Path::new(&args[5]), &reply)?;
            // Tags are public wire metadata, examined only after authenticated
            // native processing. They do not claim a before/after private head.
            publish_private_bytes(
                Path::new(&args[6]),
                &serde_json::to_vec_pretty(&json!({
                    "request_tag":request[204], "reply_tag":reply[204],
                    "commit_applied_reply":request[204]==5 && reply[204]==8
                }))?,
            )?;
        }
        _ => return Err("unknown witness mode".into()),
    }
    Ok(())
}
