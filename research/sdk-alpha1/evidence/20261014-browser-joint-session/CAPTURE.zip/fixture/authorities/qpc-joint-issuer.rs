use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json, Value};
use std::{
    fs,
    io::Read,
    path::Path,
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

fn load(path: &Path) -> Result<Value> {
    let mut data = Vec::new();
    fs::File::open(path)?.take(1048577).read_to_end(&mut data)?;
    if data.len() > 1048576 {
        return Err("public input too large".into());
    }
    Ok(serde_json::from_slice(&data)?)
}
fn bytes(v: &Value, name: &str) -> Result<Vec<u8>> {
    Ok(serde_json::from_value(
        v.get(name).ok_or("missing bytes")?.clone(),
    )?)
}
fn array(v: &Value, name: &str) -> Result<[u8; 32]> {
    Ok(bytes(v, name)?.as_slice().try_into()?)
}
fn number(v: &Value, name: &str) -> Result<u64> {
    v.get(name)
        .and_then(Value::as_u64)
        .ok_or_else(|| "missing integer".into())
}
fn decimal(v: &Value, name: &str) -> Result<u64> {
    Ok(v.get(name)
        .and_then(Value::as_str)
        .ok_or("missing decimal")?
        .parse()?)
}
fn pin(cfg: &Value, roster: &Value) -> Result<p::AccountPin> {
    Ok(p::AccountPin::new(
        array(cfg, "account")?,
        p::PublicKey::decode(&bytes(cfg, "root")?)?,
        p::RosterCheckpoint::from_trusted_state(
            number(roster, "version")?,
            array(roster, "digest")?,
        )?,
        array(cfg, "family")?,
    )?)
}
fn policy_pin(cfg: &Value, policy: &Value) -> Result<p::PolicyPin> {
    Ok(p::PolicyPin::new(
        array(cfg, "family")?,
        p::PublicKey::decode(&bytes(cfg, "policy_root")?)?,
        p::PolicyCheckpoint::from_trusted_state(
            number(policy, "version")?,
            array(policy, "digest")?,
        )?,
    )?)
}
fn runtime(cfg: &Value) -> Result<Arc<q_periapt_sdk::Runtime>> {
    Ok(Arc::new(q_periapt_sdk::Runtime::from_signed_policy(
        &bytes(cfg, "sdk_policy")?,
        &bytes(cfg, "sdk_signature")?,
        &bytes(cfg, "sdk_root")?,
        None,
        q_periapt_sdk::Limits::default(),
    )?))
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    if !(args.len() == 8 || args.len() == 9) {
        return Err(
            "issue|approve|cancel directory original previous|- request output profile [metadata]"
                .into(),
        );
    }
    let mode = args[1].as_str();
    if !matches!((mode, args.len()), ("issue", 8) | ("approve" | "cancel", 9)) {
        return Err("issuer mode".into());
    }
    let dir = Path::new(&args[2]);
    let cfg = load(&dir.join("PUBLIC.json"))?;
    let original = load(Path::new(&args[3]))?;
    let previous = if args[4] == "-" {
        None
    } else {
        Some(load(Path::new(&args[4]))?)
    };
    let request = load(Path::new(&args[5]))?;
    let profile = args[7].as_str();
    if !matches!(profile, "local" | "required") {
        return Err("profile".into());
    }
    let p0 = cfg
        .get("policies")
        .and_then(|v| v.get(profile))
        .ok_or("original policy")?;
    let prior = previous.as_ref().unwrap_or(&original);
    let prior_policy = match &previous {
        Some(v) => v.get("policy").ok_or("prior policy")?,
        None => p0,
    };
    let prior_t = previous
        .as_ref()
        .map(|v| array(v, "transaction"))
        .transpose()?;
    let submitted_t = match request
        .get("current_policy_authorization")
        .ok_or("missing policy authorization")?
    {
        Value::Null => None,
        _ => Some(array(&request, "current_policy_authorization")?),
    };
    let prior_until = match &previous {
        Some(v) => number(v, "valid_until")?,
        None => number(&cfg, "until")?,
    };
    if bytes(&request, "original_credential")? != bytes(&original, "certificate")?
        || bytes(&request, "original_roster")? != bytes(&original, "roster")?
        || bytes(&request, "previous_credential")? != bytes(prior, "certificate")?
        || bytes(&request, "previous_roster")? != bytes(prior, "roster")?
        || array(&request, "journal")? != array(&original, "journal")?
        || decimal(&request, "original_roster_version")? != number(&original, "version")?
        || array(&request, "original_roster_digest")? != array(&original, "digest")?
        || decimal(&request, "previous_roster_version")? != number(prior, "version")?
        || array(&request, "previous_roster_digest")? != array(prior, "digest")?
        || array(&request, "original_policy_digest")? != array(p0, "digest")?
        || decimal(&request, "current_policy_version")? != number(prior_policy, "version")?
        || array(&request, "current_policy_digest")? != array(prior_policy, "digest")?
        || submitted_t != prior_t
        || decimal(&request, "previous_valid_from")? != number(&cfg, "from")?
        || decimal(&request, "previous_valid_until")? != prior_until
    {
        return Err("request differs from independently retained enrollment/predecessor".into());
    }
    let old = pin(&cfg, &original)?.verify_historical_device(
        &bytes(&original, "certificate")?,
        &bytes(&original, "roster")?,
    )?;
    let current = pin(&cfg, prior)?
        .verify_historical_device(&bytes(prior, "certificate")?, &bytes(prior, "roster")?)?;
    let original_policy = policy_pin(&cfg, p0)?.verify_historical(&bytes(p0, "wire")?)?;
    let previous_policy =
        policy_pin(&cfg, prior_policy)?.verify_historical(&bytes(prior_policy, "wire")?)?;
    let now = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
    let operation = p::CredentialRenewalId::from_trusted_state(array(&request, "operation")?)?;
    let key = p::JournalKey::open(&dir.join("private-wrap.key"))?;
    let root = p::RootSigningKey::open(
        &dir.join("private-root.key"),
        &key,
        p::SigningKeyId::from_trusted_state(
            fs::read(dir.join("root-id.bin"))?.as_slice().try_into()?,
        )?,
    )?;
    let authority = p::PolicySigningKey::open(
        &dir.join("private-policy.key"),
        &key,
        p::SigningKeyId::from_trusted_state(
            fs::read(dir.join("policy-id.bin"))?.as_slice().try_into()?,
        )?,
    )?;
    if root.public_key()?.encode() != bytes(&cfg, "root")?
        || authority.public_key()?.encode() != bytes(&cfg, "policy_root")?
    {
        return Err("independent root mismatch".into());
    }
    let mut issued = if mode == "issue" {
        let until = prior_until.checked_add(600).ok_or("credential lifetime")?;
        let certificate = root.issue_credential_extension(&current, until, now)?;
        let roster = root.issue_roster(
            number(prior, "version")?
                .checked_add(1)
                .ok_or("roster version")?,
            p::Validity::new(
                number(&cfg, "from")?,
                until.checked_add(60).ok_or("roster lifetime")?,
            )?,
            &[root.roster_entry(&certificate)?],
        )?;
        let account = p::AccountPin::new(
            array(&cfg, "account")?,
            root.public_key()?,
            roster.checkpoint(),
            array(&cfg, "family")?,
        )?;
        let grant = root.issue_credential_renewal(
            p::CredentialRenewalMaterials {
                original_credential: &bytes(&original, "certificate")?,
                previous_credential: &bytes(prior, "certificate")?,
                previous_roster: &bytes(prior, "roster")?,
                successor_credential: &certificate,
                successor_roster: roster.as_bytes(),
            },
            &p::CredentialRenewalAuthorization {
                operation,
                previous: current.roster().checkpoint(),
                policy_digest: original_policy.checkpoint().digest(),
            },
            &account,
            now,
        )?;
        let policy = authority.issue_session_policy(
            runtime(&cfg)?.as_ref(),
            p::SessionPolicyParameters::new(
                previous_policy
                    .checkpoint()
                    .version()
                    .checked_add(1)
                    .ok_or("policy version")?,
                p::Validity::new(
                    previous_policy.validity().from(),
                    previous_policy
                        .validity()
                        .until()
                        .checked_add(600)
                        .ok_or("policy lifetime")?,
                )?,
                previous_policy.allowed_modes(),
                previous_policy.anchor_requirement(),
                previous_policy.application_send_budget(),
            )?,
        )?;
        json!({"grant":grant.as_bytes(),"certificate":certificate,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),
            "digest":roster.checkpoint().digest(),"valid_until":until,"policy":{"wire":policy.as_bytes(),"version":policy.checkpoint().version(),"digest":policy.checkpoint().digest()}})
    } else {
        load(Path::new(&args[6]))?
    };
    let target_pin = pin(&cfg, &issued)?;
    let historical_g = p::HistoricalCredentialRenewal::verify(
        &bytes(&issued, "grant")?,
        &target_pin,
        original_policy.checkpoint().digest(),
    )?;
    if historical_g.operation() != operation
        || historical_g.original_storage_owner() != array(&request, "original_owner")?
    {
        return Err("original grant owner or operation".into());
    }
    let scope = p::PolicyContinuationScope {
        operation,
        journal: p::JournalIdentity::from_trusted_state(array(&request, "journal")?)?,
        original_owner: historical_g.original_storage_owner(),
        original_credential: old.credential_digest(),
        previous_credential: current.credential_digest(),
        previous_roster: current.roster().checkpoint(),
        original_policy: original_policy.checkpoint(),
        previous_policy: previous_policy.checkpoint(),
        previous_authorization: prior_t,
    };
    let issued_policy = issued.get("policy").ok_or("target policy")?;
    let target_history =
        policy_pin(&cfg, issued_policy)?.verify_historical(&bytes(issued_policy, "wire")?)?;
    if mode == "cancel" {
        let materials = p::HistoricalPolicyContinuationMaterials {
            original: &original_policy,
            previous: &previous_policy,
            target: &target_history,
            credential: &historical_g,
        };
        let continuation = p::HistoricalPolicyContinuation::from_bytes(
            &bytes(&issued, "joint")?,
            &scope,
            &materials,
        )?;
        let cancellation =
            p::AnchorCredentialRenewalCancellation::from_trusted_state(&fs::read(&args[8])?)?;
        let mut witness = open_witness(dir, &cfg)?;
        if witness.close_unprepared_policy_continuation(cancellation, &continuation, &materials)?
            != p::AnchorCredentialCancellationState::Closed
        {
            return Err("cancellation not Closed".into());
        }
        witness.close();
        println!(
            "{}",
            json!({"closed":true,"operation":operation.as_bytes()})
        );
        return Ok(());
    }
    let target = policy_pin(&cfg, issued_policy)?.verify(
        &bytes(issued_policy, "wire")?,
        runtime(&cfg)?,
        now,
    )?;
    let grant = p::VerifiedCredentialRenewal::verify(
        &bytes(&issued, "grant")?,
        &target_pin,
        original_policy.checkpoint().digest(),
        now,
    )?;
    let materials = p::PolicyContinuationMaterials {
        original: &original_policy,
        previous: &previous_policy,
        target: &target,
        credential: &grant,
    };
    if mode == "approve" {
        let continuation = p::VerifiedPolicyContinuation::from_bytes(
            &bytes(&issued, "joint")?,
            &scope,
            &materials,
            now,
        )?;
        let proposal =
            p::AnchorCredentialRenewalProposal::from_trusted_state(&fs::read(&args[8])?)?;
        let mut witness = open_witness(dir, &cfg)?;
        if witness.prepare_policy_continuation(proposal, &continuation, &materials, now)?
            != p::AnchorCredentialRenewalState::Prepared
        {
            return Err("joint target not Prepared".into());
        }
        witness.close();
        println!(
            "{}",
            json!({"prepared":true,"operation":operation.as_bytes(),"transaction":continuation.statement_digest()})
        );
        return Ok(());
    }
    let statement = p::PolicyContinuationStatement::new(&scope, &materials, now)?;
    let account = root.approve_policy_continuation(&statement)?;
    let policy = authority.approve_policy_continuation(&statement)?;
    let proof = p::VerifiedPolicyContinuation::verify(&account, &policy, &scope, &materials, now)?;
    if p::VerifiedPolicyContinuation::verify(&account, &account, &scope, &materials, now).is_ok() {
        return Err("one root accepted for both roles".into());
    }
    issued["joint"] = json!(proof.as_bytes());
    issued["transaction"] = json!(proof.statement_digest());
    issued["statement"] = json!(grant.statement_digest());
    issued["operation"] = json!(operation.as_bytes());
    publish_private_bytes(Path::new(&args[6]), &serde_json::to_vec_pretty(&issued)?)?;
    println!(
        "{}",
        json!({"issued":true,"independent_predecessor_checked":true,"operation":operation.as_bytes(),"negative_controls":1,"policy_version":target.checkpoint().version()})
    );
    Ok(())
}
fn open_witness(dir: &Path, cfg: &Value) -> Result<p::AnchorStore> {
    let key = p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
    let signer = p::AnchorSigningKey::open(
        &dir.join("private-witness.key"),
        &key,
        p::SigningKeyId::from_trusted_state(array(cfg, "witness_signer_id")?)?,
    )?;
    let witness = p::AnchorStore::open(
        &dir.join("private-witness.redb"),
        key,
        signer,
        p::AnchorIdentity::from_trusted_state(array(cfg, "witness_id")?)?,
    )?;
    if witness.pin()?.public_key().encode() != bytes(cfg, "witness_public")? {
        return Err("witness mismatch".into());
    }
    Ok(witness)
}
