from pathlib import Path
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint-session'
prior = root / 'target/continuity-browser-joint'
server = (prior / 'server.py').read_text()
peer_server = (root / 'target/continuity-browser-credential-policy-sessions/server.py').read_text()
peer_function = peer_server.split('        def peer(', 1)[1].split('        def do_POST(', 1)[0]
server = server.replace('def serving(web, output, private, binary):', 'def serving(web, output, private, binary, peer_binary):')
server = server.replace('    failures, faulted = [], set()', '''    failures, faulted = [], set()
    peers, ready_proofs, control_receipts, peer_faulted = {}, {}, {}, set()
    peer_traces = output / 'peer'; peer_traces.mkdir(mode=0o700)''')
server = server.replace('        def do_POST(self):', '        def peer(' + peer_function + '        def do_POST(self):')
server = server.replace('            if capture:\n', '''            peer = re.fullmatch(r'/peer/([a-z0-9-]+)', target.path)
            if peer:
                modes = parse_qs(target.query)
                if set(modes) != {'mode'} or len(modes['mode']) != 1: self.send_error(400); return
                self.peer(peer[1], modes['mode'][0], data); return
            if capture:
''')
server = server.replace('yield origin, records, failures', 'yield origin, records, peers, failures')
(stage / 'server.py').write_text(server)
driver = (prior / 'run.py').read_text()
driver = driver.replace("stage = root / 'target/continuity-browser-joint'", "stage = root / 'target/continuity-browser-joint-session'\nprior = root / 'target/continuity-browser-joint'")
driver = driver.replace("allowed = {'local', 'required', 'commit-loss', 'worker-cut', 'closed', 'no-local-fallback'}", "allowed = {'local', 'required', 'commit-loss', 'worker-cut'}")
driver = driver.replace("for name in ('worker.js', 'controller.js'):", "for name in ('worker.js', 'controller.js', 'session-checks.js'):")
driver = driver.replace("binaries = {name: stage /", "binaries = {name: prior /")
driver = driver.replace('static = {', "binaries['peer'] = stage / 'native-target/debug/q-periapt-browser-policy-session-peer-v2'\nstatic = {")
driver = driver.replace("stage / 'server.py']", "stage / 'server.py', stage / 'session-checks.js']")
driver = driver.replace('Installed browser joint G/T owner lifecycle with independent issuer/witness processes; same native protocol implementation; session traffic and full release remain separate', 'Original application and pending rekey across two browser G/T updates; independently approved peer G, native peer keeps live P0; same shared implementation on one host')
driver = driver.replace("with serving(web, output, private, binaries['witness']) as (origin, records, failures):", "with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):")
driver = driver.replace("                shutil.copyfile(directory / 'PUBLIC.json', inputs / (key + '.json'))", '''                cfg = json.loads((directory / 'PUBLIC.json').read_text())
                cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json', inputs / (key + '.json'))''')
before = '                previous_path = \'-\'; previous = None'
sdk.require(driver.count(before) == 1, 'session setup location')
driver = driver.replace(before, '''                def trace(name):
                    path = output / (case + '-native-' + name); path.mkdir(mode=0o700); return path
                def peer_result(arguments, name):
                    return parse_strict_json_bytes(native('peer', arguments, case + '-' + name), label='native peer')
                def session_action(action, **extra):
                    return success(dict(args, action='session', sessionAction=action, **extra))
                native('peer', ['prepare', directory, original_path, inputs / (key + '-peer.json'), trace('prepare')], case + '-peer-prepare')
                args['requestId'] = session_action('new-request')['requestId']
                args['session'] = session_action('establish')['session']
                sdk.write_json(directory / 'peer/session.json', args['session'])
                row['session'] = args['session']
                args['message'] = session_action('new-message')['message']; row['message'] = args['message']
                lost = invoke(dict(args, action='session', sessionAction='send', peerMode='drop-ack'))
                sdk.require(lost.get('code') == 'PeerTransport' and lost.get('ownerClosed') is True, 'message reply not lost')
                sdk.require(session_action('status') == {'status': 2}, 'original application not pending')
                effect_files = list((directory / 'peer/effects').iterdir())
                sdk.require(len(effect_files) == 1, 'one original effect expected')
                effect_path = effect_files[0]
                effect_before = effect_path.stat()
                effect_identity = [effect_before.st_dev, effect_before.st_ino, effect_before.st_size, effect_before.st_mtime_ns]
                sdk.require(effect_path.read_bytes() == bytes(args['session']) + bytes(args['message']) + b'browser to native', 'wrong original application effect')
                row['effect_before'] = effect_identity
                session_file = output / (case + '-session.json'); sdk.write_json(session_file, args['session'])
                reverse = inputs / (key + '-reverse.bin')
                reverse_prepared = peer_result(['send-prepare', directory, session_file, reverse, trace('reverse-prepare')], 'reverse-prepare')
                sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'], 'native original dispatch')
                args['reverseMessage'] = reverse_prepared['message']
                row['reverse_prepared'] = reverse_prepared
                lost_control = invoke(dict(args, action='session', sessionAction='drive-rekey', target=1, peerMode='control-drop-first'))
                sdk.require(lost_control.get('code') == 'PeerTransport' and lost_control.get('ownerClosed') is True, 'control reply not lost')
                pending_control = session_action('rekey-progress')
                sdk.require(pending_control['confirmed'] == '0' and pending_control['pending'] == '1', 'original pending rekey absent')
                row['pending_rekey'] = pending_control
''' + before)
driver = driver.replace("for generation in range(1, 2 if case == 'closed' else 3):", 'for generation in range(1, 3):')
insertion = '                    previous, previous_path = issued, issued_path'
sdk.require(driver.count(insertion) == 1, 'generation completion')
driver = driver.replace(insertion, '''                    admitted = peer_result(['admit-browser', directory, issued_path, trace('admit-' + str(generation))], 'admit-' + str(generation))
                    sdk.require(admitted['admitted'] and admitted['exact_retry'] and admitted['same_original_journal'] and admitted['session'] == args['session'], 'native peer admission changed original session')
                    args['generation'] = generation
                    sdk.require(session_action('rekey-progress') == pending_control, 'joint update changed original pending rekey')
                    sdk.require(session_action('status') == {'status': 2}, 'joint update lost original application')
                    stats = effect_path.stat()
                    sdk.require([stats.st_dev, stats.st_ino, stats.st_size, stats.st_mtime_ns] == effect_identity, 'joint update rewrote original effect')
''' + insertion)
finish = "                row['completed'] = True"
sdk.require(driver.count(finish) == 1, 'case completion')
driver = driver.replace(finish, '''                legacy = invoke(dict(args, action='session', sessionAction='rekey-progress', legacyReopen=True))
                sdk.require(legacy.get('code') == 'Conflict', 'old reopening bypassed actual policy continuation')
                renewed = session_action('drive-rekey', target=1)
                sdk.require(renewed['epoch'] == '1', 'original rekey not completed')
                row['rekey'] = renewed
                controls = [v for v in peers[key] if v['kind'] == 4]
                sdk.require(len(controls) >= 2 and controls[0]['trigger'] and controls[0]['request_sha256'] == controls[1]['request_sha256'], 'control retry changed original frame')
                delivery = session_action('send')
                sdk.require(delivery == {'consumption': 1, 'status': 3}, 'original application not acknowledged')
                row['delivery'] = delivery
                frames = [v for v in peers[key] if v['kind'] == 3]
                sdk.require(len(frames) == 2 and frames[0]['trigger'] and frames[0]['request_sha256'] == frames[1]['request_sha256'], 'application retry changed original wire')
                stats = effect_path.stat()
                sdk.require([stats.st_dev, stats.st_ino, stats.st_size, stats.st_mtime_ns] == effect_identity and len(list((directory / 'peer/effects').iterdir())) == 1, 'original effect duplicated or rewritten')
                row['effect_after'] = effect_identity
                received = session_action('receive')
                sdk.require(received['application']['calls'] == 1 and received['application']['effects'] == 1, 'reverse host effect count')
                duplicate = session_action('receive')
                sdk.require(not duplicate['callbackInvoked'] and duplicate['reply'] == received['reply'] and duplicate['application'] == received['application'], 'duplicate released plaintext or changed original ACK')
                ack = output / (case + '-reverse-ack.bin'); ack.write_bytes(bytes(received['reply']))
                row['reverse_finished'] = peer_result(['send-finish', directory, reverse, ack, trace('reverse-finish')], 'reverse-finish')
                sdk.require(row['reverse_finished']['same_original_wire'] and row['reverse_finished']['authenticated_browser_consumption'], 'reverse original message incomplete')
                fresh = session_action('new-message')['message']
                sdk.require(session_action('send', message=fresh, plaintext='after G2/T2') == {'consumption': 1, 'status': 3}, 'fresh post-update message failed')
                sdk.require(not failures, 'fixture failure: ' + json.dumps(failures))
                print(json.dumps({'case': case, 'completed': True, 'same_original_message': True, 'two_joint_updates': True}), flush=True)
''' + finish)
driver = driver.replace("state['witness_records'] = records", "state['witness_records'] = records\n            state['peer_records'] = peers")
(stage / 'run.py').write_text(driver)
print('Fresh browser joint-session driver and loopback fault server created')
