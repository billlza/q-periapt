import { sessionAction } from './session-checks.js';
import initialize, * as sdk from '../node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const bytes = value => new Uint8Array(value);
const check = (condition, message) => { if (!condition) throw Error(message); };
const get = async name => {
  const response = await fetch('../inputs/' + name, { credentials: 'omit', cache: 'no-store' });
  if (!response.ok) throw Error('input response ' + response.status);
  return response.json();
};
let activeOwner;
onmessage = async ({ data }) => {
  if (data.cancel) { if (activeOwner) await activeOwner.close(); postMessage({ cancellation_requested: true }); return; }
  const owned = [], own = value => { owned.push(value); return value; };
  let owner, value, primary, ownerClosed, runtime;
  const cleanupErrors = [];
  const optional = value => value === undefined ? null : [...value];
  const checkpoint = value => value === undefined ? null : { version: String(own(value).version()), digest: [...value.digest()] };
  const status = async () => {
    const s = own(await owner.credential_renewal_status());
    return { phase: s.phase(), operation: optional(s.operation_id()), statement: optional(s.statement()), target: checkpoint(s.target()) };
  };
  const describe = request => {
    const result = {};
    for (const key of ['operation_id','journal','original_owner','original_policy_digest','current_policy_digest',
        'original_roster_digest','previous_roster_digest','original_credential','original_roster','previous_credential','previous_roster']) {
      result[key === 'operation_id' ? 'operation' : key] = [...request[key]()];
    }
    for (const key of ['current_policy_version','original_roster_version','previous_roster_version','previous_valid_from','previous_valid_until'])
      result[key] = String(request[key]());
    result.current_policy_authorization = optional(request.current_policy_authorization());
    return result;
  };
  try {
    const cfg = await get(data.case + '.json'), at = BigInt(Math.floor(Date.now() / 1000));
    const description = bytes(cfg.description);
    const intent = own(new sdk.QPeriaptContinuityEnrollment(bytes(cfg.root), description.slice(0,16), 1n,
      bytes(cfg.family), BigInt(cfg.from), BigInt(cfg.until)));
    const storage = bytes(data.id.match(/../g).map(v => parseInt(v,16)));
    if (data.action === 'create') {
      owner = await sdk.QPeriaptContinuityDevice.create(data.name, storage, intent);
      activeOwner = owner; value = { request: [...await owner.request(at)] };
    } else {
      const originalGrant = await get(data.case + '-grant.json');
      const p0 = cfg.policies[data.profile];
      const historical = p => own(new sdk.QPeriaptContinuityHistoricalPolicy(bytes(cfg.policy_root), bytes(cfg.family), BigInt(p.version), bytes(p.digest), bytes(p.wire)));
      const original = historical(p0);
      const current = p => {
        if (!runtime) runtime = own(new sdk.QPeriaptRuntime(bytes(cfg.sdk_policy), bytes(cfg.sdk_signature), bytes(cfg.sdk_root), bytes(cfg.sdk_state), 32, 4));
        return own(new sdk.QPeriaptContinuityPolicy(runtime, bytes(cfg.policy_root), bytes(cfg.family), BigInt(p.version), bytes(p.digest), bytes(p.wire), at));
      };
      const trust = g => own(new sdk.QPeriaptContinuityAccountTrust(bytes(cfg.account), bytes(cfg.root), BigInt(g.version), bytes(g.digest), bytes(cfg.family)));
      const witness = own(sdk.QPeriaptContinuityWitness.for_loopback(bytes(cfg.witness_id), bytes(cfg.witness_public),
        new URL('/witness/' + data.case + '?mode=' + (data.mode ?? 'normal') + '&cut=' + (data.generation ?? 0), location.origin).href, 5000));
      owner = await sdk.QPeriaptContinuityDevice.open(data.name, storage, intent); activeOwner = owner;
      const request = async () => own(data.profile === 'local'
        ? await owner.credential_renewal_request(bytes(data.operation), original)
        : await owner.witnessed_credential_renewal_request(bytes(data.operation), original, witness));
      if (data.action === 'session') {
        let policy;
        if (data.generation) {
          const issued = await get(data.case + '-joint-' + data.generation + '.json');
          policy = current(issued.policy);
          if (data.profile === 'local') await owner.activate_local_policy_continuation(original, policy, at);
          else await owner.activate_witnessed_policy_continuation(original, policy, witness, at);
        } else {
          policy = current(p0);
          if (data.profile === 'local') await owner.activate_local(policy, at);
          else await owner.activate(policy, witness, at);
        }
        value = await sessionAction(owner, policy, runtime, cfg, originalGrant,
          {...data, continued: !!data.generation}, original);
      } else if (data.action === 'accept') {
        value = { journal: [...await owner.accept(bytes(originalGrant.certificate), bytes(originalGrant.roster), trust(originalGrant), current(p0), at)] };
      } else if (data.action === 'prepare') {
        const prepared = own(await owner.prepare(current(p0), at)), state = own(await owner.status());
        value = { phase: prepared.requires_witness() ? 'requires-witness-enrollment' : 'prepared-local', journal: [...state.journal()] };
        if (prepared.requires_witness()) Object.assign(value, { subject: [...prepared.subject()], genesis: [...prepared.image_digest()] });
      } else if (data.action === 'activate') {
        const policy = current(p0);
        const journal = data.profile === 'local' ? await owner.activate_local(policy, at) : await owner.activate(policy, witness, at);
        const prekey = await owner.generate_prekey(policy, new Uint8Array(32).fill(55), sdk.QPeriaptContinuityPrekeyKind.OneTimePq, BigInt(cfg.from), BigInt(cfg.until), at);
        value = { journal: [...journal], prekey: [...prekey] };
      } else if (data.action === 'request') {
        value = { credentialRequest: describe(await request()), status: await status(), runtimeCreated: runtime !== undefined };
      } else if (data.action === 'status') {
        value = { status: await status(), runtimeCreated: runtime !== undefined };
      } else {
        const issued = await get(data.case + '-joint-' + data.generation + '.json');
        const operation = bytes(issued.operation), transaction = bytes(issued.transaction);
        if (data.action === 'stage') {
          const r = await request();
          const grant = own(new sdk.QPeriaptContinuityCredentialGrant(bytes(issued.grant), trust(issued), original, at));
          const previous = data.generation === 1 ? p0 : (await get(data.case + '-joint-' + (data.generation - 1) + '.json')).policy;
          const predecessor = historical(previous), target = current(issued.policy);
          const bad = bytes(issued.joint); bad[bad.length - 1] ^= 1;
          let refused;
          try { own(new sdk.QPeriaptContinuityPolicyContinuation(bad, r, grant, original, predecessor, target, at)); }
          catch (error) { refused = error; }
          check(refused?.code && !owner.is_closed(), 'invalid signature accepted or mutated owner');
          const proof = own(new sdk.QPeriaptContinuityPolicyContinuation(bytes(issued.joint), r, grant, original, predecessor, target, at));
          check(JSON.stringify([...proof.statement()]) === JSON.stringify(issued.transaction), 'T statement');
          check(JSON.stringify([...proof.credential_statement()]) === JSON.stringify(issued.statement), 'G statement');
          const first = own(await owner.stage_policy_continuation(grant, proof, operation, target, at));
          const second = own(await owner.stage_policy_continuation(grant, proof, operation, target, at));
          check(first.phase() === sdk.QPeriaptContinuityCredentialPhase.Pending && second.phase() === first.phase(), 'exact stage replay');
          value = { status: await status(), predecessor: optional(proof.previous_statement()), rejectedApproval: refused.code };
        } else if (data.action === 'local-commit') {
          own(await owner.reconcile_policy_continuation(original, current(issued.policy), at)); value = { status: await status() };
        } else if (data.action === 'witness-prepare') {
          const proposal = own(await owner.prepare_witnessed_credential_renewal(original, current(issued.policy), witness, at));
          const recovered = await owner.recover_witnessed_credential_renewal_preparation(original, at);
          check(recovered !== undefined && JSON.stringify([...own(recovered).bytes()]) === JSON.stringify([...proposal.bytes()]), 'retained proposal');
          check(proposal.adopts_policy() && proposal.independent_policy_statement() === undefined, 'joint proposal mode');
          check(JSON.stringify([...proposal.credential_statement()]) === JSON.stringify(issued.statement) && JSON.stringify([...proposal.statement()]) === JSON.stringify(issued.transaction), 'proposal G/T identity');
          value = { proposal: [...proposal.bytes()], status: await status() };
        } else if (data.action === 'commit') {
          const proposal = own(new sdk.QPeriaptContinuityCredentialProposal(bytes(data.proposal)));
          own(await owner.commit_witnessed_credential_renewal(proposal, original, current(issued.policy), witness, at));
          value = { status: await status() };
        } else if (data.action === 'history' || data.action === 'close') {
          const method = data.action === 'close' ? 'close_witnessed_credential_renewal' : 'reconcile_witnessed_credential_renewal';
          own(await owner[method](operation, transaction, original, witness, at));
          value = { status: await status(), runtimeCreated: runtime !== undefined };
        } else if (data.action === 'cancel-prepare') {
          const cancellation = own(await owner.prepare_witnessed_credential_cancellation(original, at));
          value = { cancellation: [...cancellation.bytes()], status: await status(), runtimeCreated: runtime !== undefined };
        } else if (data.action === 'historical-local') {
          own(await owner.recover_historical_policy_continuation(operation, transaction, original, historical(issued.policy), at));
          value = { status: await status(), runtimeCreated: runtime !== undefined };
        } else if (data.action === 'joint-activate') {
          const target = current(issued.policy);
          const journal = data.profile === 'local' || data.forceLocal
            ? await owner.activate_local_policy_continuation(original, target, at)
            : await owner.activate_witnessed_policy_continuation(original, target, witness, at);
          value = { journal: [...journal], status: await status() };
        } else throw Error('unknown joint action');
      }
    }
  } catch (error) { primary = error; ownerClosed = owner?.is_closed(); }
  finally {
    activeOwner = undefined;
    if (owner) {
      try { await owner.close(); } catch (error) { cleanupErrors.push(String(error)); }
      try { owner.free(); } catch (error) { cleanupErrors.push(String(error)); }
    }
    for (const resource of owned.reverse()) {
      try { if (typeof resource.close === 'function') await resource.close(); }
      catch (error) { cleanupErrors.push(String(error)); }
      try { resource.free(); } catch (error) { cleanupErrors.push(String(error)); }
    }
  }
  if (primary || cleanupErrors.length) postMessage({ done: true, error: String(primary ?? 'cleanup failure'), code: primary?.code, ownerClosed, cleanupErrors });
  else postMessage({ done: true, value, cleanupErrors });
};
postMessage({ ready: true });
