from pathlib import Path
import rust_sdk_profile as sdk
stage = Path.cwd() / 'target/continuity-browser-joint-session'
source = (stage / 'run.py').read_text()
source = source.replace("allowed = {'local', 'required', 'commit-loss', 'worker-cut'}", "allowed = {'commit-loss', 'worker-cut'}")
target = "lost = invoke(dict(args, action='session', sessionAction='send', peerMode='drop-ack'))"
sdk.require(source.count(target) == 1, 'original application dispatch boundary')
source = source.replace(target, target.replace("'drop-ack'", "'after-effect'"))
target = "sdk.require(session_action('status') == {'status': 2}, 'original application not pending')"
sdk.require(source.count(target) == 1, 'original pending boundary')
source = source.replace(target, target + '''
                failure = [record for record in peers[key] if record['kind'] == 3]
                sdk.require(len(failure) == 1 and failure[0]['trigger'] and failure[0]['application_unconfirmed']
                    and failure[0]['returncode'] != 0, 'receiver did not fail after durable business effect')
                row['application_result_lost_after_effect'] = True''')
source = source.replace('Original application and pending rekey across two browser G/T updates;', 'Receiver result lost after durable application effect, then two interrupted browser G/T updates and original pending rekey;')
sdk.require(not (stage / 'run-faults.py').exists(), 'fault driver already exists')
(stage / 'run-faults.py').write_text(source)
print('Fresh application-effect plus joint-commit fault driver created')
