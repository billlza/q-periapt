from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-joint-session'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'local', 'required', 'commit-loss', 'worker-cut'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-joint-package-03'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for name in ('worker.js', 'controller.js', 'session-checks.js'): shutil.copyfile(stage / name, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Joint policy maintenance</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
session = 'qpc-joint-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: prior / ('native-target/debug/qpc-joint-' + name) for name in ('seed', 'issuer', 'witness')}
binaries['peer'] = stage / 'native-target/debug/q-periapt-browser-policy-session-peer-v2'
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker.js', stage / 'controller.js', stage / 'server.py', stage / 'session-checks.js']}
state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Original application and pending rekey across two browser G/T updates; independently approved peer G, native peer keeps live P0; same shared implementation on one host', 'cases': []}
sequence = 0

def browser(args, name):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', session, *args], timeout_seconds=80,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

def assert_status(value, issued, phase):
    status = value['status']
    sdk.require(status['phase'] == phase and status['operation'] == issued['operation'] and status['statement'] == issued['transaction'], 'wrong joint status')

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            browser(['snapshot'], 'snapshot')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="joint_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("joint_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            startup = logs / 'startup-assets.js'
            startup.write_text('async page => { await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); return {iconLoaded:true}; }')
            browser(['run-code', '--filename', str(startup)], 'startup-assets')
            browser(['console', 'warning'], 'startup-console')
            console_files = sorted((output / '.playwright-cli').glob('console-*.log'))
            sdk.require(console_files and all(not p.read_text().strip() for p in console_files), 'startup console warning or error')
            state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case': case, 'calls': [], 'completed': False}; state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare', directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text())
                cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json', inputs / (key + '.json'))
                args = {'case': key, 'name': key + '-' + uuid.uuid4().hex[:8], 'id': uuid.uuid4().hex + uuid.uuid4().hex, 'profile': profile}
                success(dict(args, action='create'))
                original_path = inputs / (key + '-grant.json')
                native('seed', ['issue', directory, output / 'captures' / (key + '.bin'), original_path], case + '-enroll-grant')
                original = json.loads(original_path.read_text())
                accepted = success(dict(args, action='accept')); prepared = success(dict(args, action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness', ['enroll', directory, original_path, output / 'captures' / (key + '-genesis.json')], case + '-witness-enroll')
                registered = directory / 'REGISTERED.json'
                sdk.write_json(registered, dict(original, journal=prepared['journal']))
                activated = success(dict(args, action='activate'))
                sdk.require(activated['journal'] == prepared['journal'], 'original activation identity')
                row['journal'] = prepared['journal']; row['original_prekey'] = activated['prekey']
                def trace(name):
                    path = output / (case + '-native-' + name); path.mkdir(mode=0o700); return path
                def peer_result(arguments, name):
                    return parse_strict_json_bytes(native('peer', arguments, case + '-' + name), label='native peer')
                def session_action(action, **extra):
                    return success(dict(args, action='session', sessionAction=action, **extra))
                native('peer', ['prepare', directory, original_path, inputs / (key + '-peer.json'), trace('prepare')], case + '-peer-prepare')
                args['requestId'] = session_action('new-request')['requestId']
                args['session'] = session_action('establish')['session']
                sdk.write_json(directory / 'peer/session.json', args['session'])
                row['session'] = args['session']
                args['message'] = session_action('new-message')['message']; row['message'] = args['message']
                lost = invoke(dict(args, action='session', sessionAction='send', peerMode='drop-ack'))
                sdk.require(lost.get('code') == 'PeerTransport' and lost.get('ownerClosed') is True, 'message reply not lost')
                sdk.require(session_action('status') == {'status': 2}, 'original application not pending')
                effect_files = list((directory / 'peer/effects').iterdir())
                sdk.require(len(effect_files) == 1, 'one original effect expected')
                effect_path = effect_files[0]
                effect_before = effect_path.stat()
                effect_identity = [effect_before.st_dev, effect_before.st_ino, effect_before.st_size, effect_before.st_mtime_ns]
                sdk.require(effect_path.read_bytes() == bytes(args['session']) + bytes(args['message']) + b'browser to native', 'wrong original application effect')
                row['effect_before'] = effect_identity
                session_file = output / (case + '-session.json'); sdk.write_json(session_file, args['session'])
                reverse = inputs / (key + '-reverse.bin')
                reverse_prepared = peer_result(['send-prepare', directory, session_file, reverse, trace('reverse-prepare')], 'reverse-prepare')
                sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'], 'native original dispatch')
                args['reverseMessage'] = reverse_prepared['message']
                row['reverse_prepared'] = reverse_prepared
                lost_control = invoke(dict(args, action='session', sessionAction='drive-rekey', target=1, peerMode='control-drop-first'))
                sdk.require(lost_control.get('code') == 'PeerTransport' and lost_control.get('ownerClosed') is True, 'control reply not lost')
                pending_control = session_action('rekey-progress')
                sdk.require(pending_control['confirmed'] == '0' and pending_control['pending'] == '1', 'original pending rekey absent')
                row['pending_rekey'] = pending_control
                previous_path = '-'; previous = None
                for generation in range(1, 3):
                    operation = list(os.urandom(32))
                    selected = dict(args, generation=generation, operation=operation)
                    request = success(dict(selected, action='request'))['credentialRequest']
                    replay = success(dict(selected, action='request'))['credentialRequest']
                    sdk.require(request == replay and request['journal'] == row['journal'], 'original request replay')
                    request_path = output / (key + f'-request-{generation}.json'); sdk.write_json(request_path, request)
                    issued_path = inputs / (key + f'-joint-{generation}.json')
                    issuer_args = [directory, registered, previous_path, request_path, issued_path, profile]
                    native('issuer', ['issue', *issuer_args], case + f'-joint-{generation}')
                    issued = json.loads(issued_path.read_text())
                    staged = success(dict(selected, action='stage')); assert_status(staged, issued, 2)
                    sdk.require(staged['predecessor'] == (previous['transaction'] if previous else None), 'T predecessor')
                    assert_status(success(dict(selected, action='status')), issued, 2)
                    if case == 'closed':
                        cancellation = success(dict(selected, action='cancel-prepare'))
                        metadata = output / (key + '-cancellation.bin'); metadata.write_bytes(bytes(cancellation['cancellation']))
                        native('issuer', ['cancel', *issuer_args, metadata], case + '-approve-cancel')
                        history = success(dict(selected, action='history')); assert_status(history, issued, 5)
                        sdk.require(history['runtimeCreated'] is False, 'historical cancel created runtime')
                        rejected = invoke(dict(selected, action='joint-activate'))
                        sdk.require('error' in rejected and rejected.get('ownerClosed') is True, 'Closed target activated')
                        break
                    if profile == 'local':
                        assert_status(success(dict(selected, action='local-commit')), issued, 4)
                        history = success(dict(selected, action='historical-local')); assert_status(history, issued, 4)
                        sdk.require(history['runtimeCreated'] is False, 'historical local created runtime')
                    else:
                        proposal = success(dict(selected, action='witness-prepare'))['proposal']
                        metadata = output / (key + f'-proposal-{generation}.bin'); metadata.write_bytes(bytes(proposal))
                        native('issuer', ['approve', *issuer_args, metadata], case + f'-approve-{generation}')
                        if case in ('commit-loss', 'worker-cut'):
                            mode = 'drop-commit' if case == 'commit-loss' else 'hold-commit'
                            result = invoke(dict(selected, action='commit', proposal=proposal, mode=mode, killAfterApplied=case == 'worker-cut'))
                            if case == 'worker-cut': sdk.require(result.get('workerTerminatedAfterApplied') is True, 'worker was not terminated after Applied')
                            else: sdk.require('error' in result and result.get('ownerClosed') is True, 'lost reply did not close unknown owner')
                            sdk.require(any(v['trigger'] and v['cut'] == str(generation) and v['commit_applied_reply'] for v in records.get(key, [])), 'missing actual Commit/Applied cut')
                        else:
                            assert_status(success(dict(selected, action='commit', proposal=proposal)), issued, 4)
                        start = len(records.get(key, []))
                        history = success(dict(selected, action='history')); assert_status(history, issued, 4)
                        sdk.require(history['runtimeCreated'] is False, 'history created runtime')
                        sdk.require(all(v['request_tag'] not in (5,7) for v in records.get(key, [])[start:]), 'passive history submitted Commit/Close')
                        if case == 'commit-loss': assert_status(success(dict(selected, action='close')), issued, 4)
                        if case == 'no-local-fallback':
                            refused = invoke(dict(selected, action='joint-activate', forceLocal=True))
                            sdk.require(refused.get('code') == 'AnchorRequired' and refused.get('ownerClosed') is True, 'required witness downgraded')
                    active = success(dict(selected, action='joint-activate')); assert_status(active, issued, 4)
                    sdk.require(active['journal'] == row['journal'], 'joint activation changed journal')
                    admitted = peer_result(['admit-browser', directory, issued_path, trace('admit-' + str(generation))], 'admit-' + str(generation))
                    sdk.require(admitted['admitted'] and admitted['exact_retry'] and admitted['same_original_journal'] and admitted['session'] == args['session'], 'native peer admission changed original session')
                    args['generation'] = generation
                    sdk.require(session_action('rekey-progress') == pending_control, 'joint update changed original pending rekey')
                    sdk.require(session_action('status') == {'status': 2}, 'joint update lost original application')
                    stats = effect_path.stat()
                    sdk.require([stats.st_dev, stats.st_ino, stats.st_size, stats.st_mtime_ns] == effect_identity, 'joint update rewrote original effect')
                    previous, previous_path = issued, issued_path
                if case != 'closed':
                    latest = success(dict(args, action='request', operation=list(os.urandom(32))))['credentialRequest']
                    sdk.require(latest['current_policy_authorization'] == previous['transaction'] and latest['previous_credential'] == previous['certificate']
                        and latest['previous_roster'] == previous['roster'] and latest['original_credential'] == original['certificate']
                        and latest['original_roster'] == original['roster'], 'next request lost original or current lineage')
                    row['next_request'] = latest
                legacy = invoke(dict(args, action='session', sessionAction='rekey-progress', legacyReopen=True))
                sdk.require(legacy.get('code') == 'Conflict', 'old reopening bypassed actual policy continuation')
                renewed = session_action('drive-rekey', target=1)
                sdk.require(renewed['epoch'] == '1', 'original rekey not completed')
                row['rekey'] = renewed
                controls = [v for v in peers[key] if v['kind'] == 4]
                sdk.require(len(controls) >= 2 and controls[0]['trigger'] and controls[0]['request_sha256'] == controls[1]['request_sha256'], 'control retry changed original frame')
                delivery = session_action('send')
                sdk.require(delivery == {'consumption': 1, 'status': 3}, 'original application not acknowledged')
                row['delivery'] = delivery
                frames = [v for v in peers[key] if v['kind'] == 3]
                sdk.require(len(frames) == 2 and frames[0]['trigger'] and frames[0]['request_sha256'] == frames[1]['request_sha256'], 'application retry changed original wire')
                stats = effect_path.stat()
                sdk.require([stats.st_dev, stats.st_ino, stats.st_size, stats.st_mtime_ns] == effect_identity and len(list((directory / 'peer/effects').iterdir())) == 1, 'original effect duplicated or rewritten')
                row['effect_after'] = effect_identity
                received = session_action('receive')
                sdk.require(received['application']['calls'] == 1 and received['application']['effects'] == 1, 'reverse host effect count')
                duplicate = session_action('receive')
                sdk.require(not duplicate['callbackInvoked'] and duplicate['reply'] == received['reply'] and duplicate['application'] == received['application'], 'duplicate released plaintext or changed original ACK')
                ack = output / (case + '-reverse-ack.bin'); ack.write_bytes(bytes(received['reply']))
                row['reverse_finished'] = peer_result(['send-finish', directory, reverse, ack, trace('reverse-finish')], 'reverse-finish')
                sdk.require(row['reverse_finished']['same_original_wire'] and row['reverse_finished']['authenticated_browser_consumption'], 'reverse original message incomplete')
                fresh = session_action('new-message')['message']
                sdk.require(session_action('send', message=fresh, plaintext='after G2/T2') == {'consumption': 1, 'status': 3}, 'fresh post-update message failed')
                sdk.require(not failures, 'fixture failure: ' + json.dumps(failures))
                print(json.dumps({'case': case, 'completed': True, 'same_original_message': True, 'two_joint_updates': True}), flush=True)
                row['completed'] = True
            sdk.require(not failures, 'witness handler failures: ' + json.dumps(failures))
            state['witness_records'] = records
            state['peer_records'] = peers
        finally:
            browser(['close'], 'close')
    for name, digest in producer.items(): sdk.require(sdk.snapshot(Path(name), maximum=256*1024**2).sha256 == digest, 'producer drift')
    for name, digest in static.items(): sdk.require(sdk.snapshot(web / name).sha256 == digest, 'installed web drift')
    state.update(completed=True, producer_unchanged=True)
except BaseException as error:
    state['failure'] = repr(error)
    raise
finally:
    sdk.write_json(output / 'RESULT.json', state)
print(json.dumps({'completed': True, 'cases': cases, 'scope': state['scope']}))
