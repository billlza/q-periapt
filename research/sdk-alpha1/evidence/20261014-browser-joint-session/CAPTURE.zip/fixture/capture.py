from pathlib import Path
import json
import zipfile
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint-session'
expected_head = 'e8949e78e531528736fb5731c4f41143773c82df'
sdk.require(sdk.command(['git', 'rev-parse', 'HEAD'], stage / 'source-head', root).decode().strip() == expected_head, 'source commit changed')
sdk.require(not sdk.command(['git', 'status', '--porcelain'], stage / 'source-status', root), 'source not clean before capture')
expected = {'run01': ['local', 'required'], 'run02': ['commit-loss', 'worker-cut'], 'run04': ['local']}
members, results = {}, {}
def include(path, name):
    sdk.require(name not in members and path.is_file() and not path.is_symlink(), 'capture member: ' + name)
    members[name] = sdk.snapshot(path, maximum=64*1024**2).data
for name, cases in expected.items():
    result = json.loads((stage / name / 'RESULT.json').read_text())
    sdk.require(result['completed'] and result['producer_unchanged'] and [row['case'] for row in result['cases']] == cases
        and all(row['completed'] for row in result['cases']), 'incomplete run: ' + name)
    for path, digest in result['producer'].items():
        sdk.require(sdk.snapshot(Path(path), maximum=256*1024**2).sha256 == digest, 'producer changed: ' + path)
    results[name] = result
sdk.require(results['run04']['startup_console_clean'], 'clean startup not checked')
failed = json.loads((stage / 'run03/RESULT.json').read_text())
sdk.require(not failed['completed'] and 'startup console warning or error' in failed['failure'], 'failed startup gate not retained')
for name in (*expected, 'run03'):
    for path in (stage / name).rglob('*'):
        relative = path.relative_to(stage / name)
        if path.is_file() and (not any(part.startswith('.') for part in relative.parts)
                              or (relative.parts[0] == '.playwright-cli' and path.suffix == '.log')):
            include(path, name + '/' + relative.as_posix())
    for folder in ('inputs', 'creation'):
        for path in (stage / (name + '-web') / folder).rglob('*'):
            if path.is_file(): include(path, name + '-web/' + path.relative_to(stage / (name + '-web')).as_posix())
for path in stage.glob('*.py'): include(path, 'fixture/' + path.name)
for path in stage.glob('*.js'): include(path, 'fixture/' + path.name)
for name in ('Cargo.toml', 'Cargo.lock'):
    include(stage / 'native-peer' / name, 'fixture/native-peer/' + name)
include(stage / 'native-peer/src/main.rs', 'fixture/native-peer/src/main.rs')
for prefix in ('native-build', 'native-format', 'source-head', 'source-status'):
    for path in stage.glob(prefix + '.*'):
        if path.suffix in ('.json', '.stdout', '.stderr'): include(path, 'checks/' + path.name)
prior = root / 'target/continuity-browser-joint'
include(prior / 'SOURCE_OVERLAY.json', 'package/SOURCE_OVERLAY.json')
include(prior / 'FINALIZED.json', 'package/FINALIZED.json')
package = root / 'target/continuity-browser-publication/source/target/browser-joint-package-03'
installed = json.loads((package / 'INSTALLED_CONSUMER.json').read_text())
include(package / 'INSTALLED_CONSUMER.json', 'package/INSTALLED_CONSUMER.json')
for name in ('seed', 'issuer', 'witness'):
    include(prior / ('authority/src/bin/qpc-joint-' + name + '.rs'), 'fixture/authorities/qpc-joint-' + name + '.rs')
destination = root / 'research/sdk-alpha1/evidence/20261014-browser-joint-session'
destination.mkdir(parents=True)
archive = destination / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 14, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o100600 << 16
        output.writestr(info, data)
with zipfile.ZipFile(archive) as output:
    sdk.require(output.testzip() is None and len(output.namelist()) == len(members), 'archive validation')
    for name, data in members.items(): sdk.require(output.read(name) == data, 'archive payload drift')
cases = [{'run': name, 'case': row['case'], 'calls': len(row['calls']),
          'effect_identity_unchanged': row['effect_before'] == row['effect_after'],
          'epoch': row['rekey']['epoch'], 'delivery': row['delivery'],
          'receiver_failed_after_effect': row.get('application_result_lost_after_effect', False),
          'reverse_confirmed': row['reverse_finished']['authenticated_browser_consumption']}
         for name, result in results.items() for row in result['cases']]
checks = {'schema': 1, 'completed': True, 'release_claim_eligible': False, 'product_code_changed': False,
          'source_commit': expected_head, 'package_sha256': installed['sha256'], 'cases': cases,
          'browser_calls': sum(row['calls'] for row in cases),
          'archive': {'path': archive.name, 'sha256': sdk.snapshot(archive).sha256, 'bytes': archive.stat().st_size, 'members': len(members)},
          'startup': {'original_error': 'missing test-page favicon 404', 'fixed': True,
                      'failed_check': 'run03 required a console log file even for zero messages; failed result and original driver retained',
                      'accepted_run': 'run04', 'errors': 0, 'warnings': 0},
          'scope': 'Current installed browser package and current-source native peer, same engine on one macOS arm64 host; native peer keeps still-live P0 and independently admits each peer G',
          'remaining': ['Both-endpoint policy expiry and continuation in this joint browser session scenario',
                        'Browser process cut between local joint journal commit and completion receipt',
                        'Independent implementation, broader platforms/lifecycle/PCS/performance and release admission'],
          'private_material_archived': False}
sdk.write_json(destination / 'CHECKS.json', checks)
print(json.dumps({'captured': True, 'archive': checks['archive'], 'browser_calls': checks['browser_calls'], 'cases': len(cases)}))
