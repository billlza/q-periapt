from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint-session'
prior = root / 'target/continuity-browser-joint'
work = stage / 'native-peer'
(work / 'src').mkdir(parents=True)
old = root / 'target/continuity-browser-policy-sessions/native-peer-v2'
for name in ('Cargo.toml', 'Cargo.lock'):
    sdk.copy(old / name, work / name)
source = (old / 'src/main.rs').read_text()
selection = 'v.get("policies").and_then(|v|v.get("required"))'
sdk.require(source.count(selection) == 2, 'policy selectors')
source = source.replace(selection, 'v.get("policies").and_then(|policies|policies.get(v.get("profile")?.as_str()?))')
start = 'fn activate(mut pending:p::DeviceEnrollment,dir:&Path,config:&Value,policy:&p::VerifiedSessionPolicy,trace:&Path)->Result<p::EnrolledDevice>{'
sdk.require(source.count(start) == 1, 'activation boundary')
source = source.replace(start, start + '''
 if config["profile"]=="local" {
  if retained_policy(dir)?.is_some(){return Err("local peer policy changes outside fixture".into())}
  return Ok(pending.activate(policy,now()?,None)?);
 }
 if config["profile"]!="required" {return Err("explicit protection profile required".into())}
''')
old_prepare = ''' let p::InstallationPreparation::RequiresEnrollment(genesis)=pending.prepare(&policy,now()?)? else{return Err("required witness omitted".into())};
 let mut store=witness(dir,&config)?;store.enroll(&genesis,&device,&policy,now()?)?;store.close();'''
sdk.require(source.count(old_prepare) == 1, 'native preparation boundary')
source = source.replace(old_prepare, ''' match (config["profile"].as_str(), pending.prepare(&policy,now()?)?) {
  (Some("local"), p::InstallationPreparation::Local)=>{},
  (Some("required"), p::InstallationPreparation::RequiresEnrollment(genesis))=>{
   let mut store=witness(dir,&config)?;store.enroll(&genesis,&device,&policy,now()?)?;store.close();
  },
  _=>return Err("explicit protection profile differs from installation".into()),
 }''')
(work / 'src/main.rs').write_text(source)
for name in ('run.py', 'worker.js', 'controller.js', 'server.py'):
    sdk.copy(prior / name, stage / ('original-' + name))
sdk.copy(root / 'target/continuity-browser-credential-policy-sessions/session-checks.js', stage / 'session-checks.js')
worker = (prior / 'worker.js').read_text()
worker = "import { sessionAction } from './session-checks.js';\n" + worker
before = "if (data.action === 'accept') {"
sdk.require(worker.count(before) == 1, 'worker dispatch')
worker = worker.replace(before, '''if (data.action === 'session') {
        let policy;
        if (data.generation) {
          const issued = await get(data.case + '-joint-' + data.generation + '.json');
          policy = current(issued.policy);
          if (data.profile === 'local') await owner.activate_local_policy_continuation(original, policy, at);
          else await owner.activate_witnessed_policy_continuation(original, policy, witness, at);
        } else {
          policy = current(p0);
          if (data.profile === 'local') await owner.activate_local(policy, at);
          else await owner.activate(policy, witness, at);
        }
        value = await sessionAction(owner, policy, runtime, cfg, originalGrant,
          {...data, continued: !!data.generation}, original);
      } else ''' + before)
(stage / 'worker.js').write_text(worker)
sdk.copy(prior / 'controller.js', stage / 'controller.js')
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
bin_dir = Path(env['RUSTC']).parent
sdk.command([str(bin_dir / 'rustfmt'), '--edition', '2021', str(work / 'src/main.rs')], stage / 'native-format', root, environment=env)
sdk.command([str(bin_dir / 'cargo'), 'build', '--locked', '--offline', '--bins', '--message-format=json',
    '--target-dir', str(stage / 'native-target'), '-j', '2'], stage / 'native-build', work, environment=env)
print('Current-source native peer and fresh browser session harness prepared')
