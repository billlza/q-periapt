from pathlib import Path
import json,hashlib,zipfile,tempfile
import rust_sdk_profile as sdk
import continuity_android_recovery_records as records
import continuity_android_recovery as recovery
root=Path.cwd();base=Path(__file__).resolve().parent;src=base/'integrated4'
state=json.loads((src/'STATE.json').read_text());assert state['completed'] and not state['live_producer']
boundary=json.loads((base/'boundary5/BOUNDARY.json').read_text());assert boundary['completed'] and not boundary['live_producer']
for name,digest in boundary['source_hashes'].items():assert sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,name
for name,digest in state['source_inputs'].items():assert sdk.snapshot(root/name).sha256==digest,name
for profile,result in state['profiles'].items():
 prefix='android-jni-'+profile+'-recovery'
 assert records.first_use((src/(prefix+'-first-use.stdout')).read_bytes(),src/(prefix+'-first-use-public'))==result['first_use']
 assert records.dispatches(src/(prefix+'-witness-calls'),expected_java=44,expected_c=18,
  account_reports={r['batch']:r['public_readbacks']['c-account-loss-report'] for r in result['native_oracles']})==result['witness']
 assert records.dispatches(src/(prefix+'-result-calls'),expected_java=18,expected_c=0)==result['committed_members']
 for i,(_,verify) in enumerate(recovery.WITNESS_CASES):
  oracle=verify((src/(prefix+'-witness-'+str(i)+'.stdout')).read_bytes(),src/(prefix+'-oracle-'+str(i)),language='C')
  assert {k:v for k,v in oracle.items() if k not in ('scope','language')}==result['native_oracles'][i]
members={}
def add(name,path):
 assert path.is_file() and not path.is_symlink();members[name]=path.read_bytes()
for path in src.rglob('*'):
 if path.is_file():add('execution/'+str(path.relative_to(src)),path)
for name in boundary['source_hashes']:add('source/android/'+name,root/'bindings/android/ContinuityPackageConsumer'/name)
for name in ['continuity_android_recovery.py','continuity_android_recovery_records.py','continuity_android_jni.py','continuity_android_contract.py','continuity_android_account.py']:
 add('source/artifact/'+name,root/'artifact'/name)
consumer=Path(json.loads((base/'witness/STATE.json').read_text())['consumer'])
for name in ['tests/common/android_account.rs','tests/common/android_account_recovery.rs','tests/enrollment/witness_roster_fanout.rs']:
 original=root/'bindings/c/ContinuityPackageConsumer'/name
 assert sdk.snapshot(original).sha256==sdk.snapshot(consumer/name).sha256,name
 add('source/c/'+name,original)
for path in (base/'boundary5').glob('*'):
 if path.is_file():add('boundary/'+path.name,path)
for path in (base/'first-use').glob('*'):
 if path.is_file() and path.suffix!='.jar':add('initial-first-use/'+path.name,path)
for path in (base/'integrated').glob('*'):
 if path.is_file():add('failures/private-parent/'+path.name,path)
for lane,label in [('integrated2','redundant-status'),('integrated3','missing-retired-check')]:
 for path in (base/lane).glob('*'):
  if path.is_file():add('failures/'+label+'/'+path.name,path)
for lane,label in [('boundary3','redundant-status'),('boundary4','missing-retired-check')]:
 old=json.loads((base/lane/'BOUNDARY.json').read_text())
 add('failures/'+label+'/RecoveryProbe.java',Path(old['work'])/'source/src/test/java/RecoveryProbe.java')
for name in ['qualify_integrated_complete.py','check_first_use.py','capture.py']:add('drivers/'+name,base/name)
assert not any(Path(n).name in {'PRIVATE_ENVIRONMENT.json','wrap.key','signer.key','tls-key'} or n.endswith('.redb') for n in members)
out=root/'research/sdk-alpha1/evidence/20261012-android-recovery';out.mkdir();archive=out/'HOST_CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory() as t,zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items());z.extractall(t);ex=Path(t)/'execution'
 for profile,result in state['profiles'].items():
  prefix='android-jni-'+profile+'-recovery'
  assert records.first_use((ex/(prefix+'-first-use.stdout')).read_bytes(),ex/(prefix+'-first-use-public'))==result['first_use']
  assert records.dispatches(ex/(prefix+'-witness-calls'),expected_java=44,expected_c=18,
   account_reports={r['batch']:r['public_readbacks']['c-account-loss-report'] for r in result['native_oracles']})==result['witness']
  assert records.dispatches(ex/(prefix+'-result-calls'),expected_java=18,expected_c=0)==result['committed_members']
  for i,(_,verify) in enumerate(recovery.WITNESS_CASES):
   checked=verify((ex/(prefix+'-witness-'+str(i)+'.stdout')).read_bytes(),ex/(prefix+'-oracle-'+str(i)),language='C')
   assert {k:v for k,v in checked.items() if k not in ('scope','language')}==result['native_oracles'][i]
checks={'completed':True,'scope':recovery.SCOPE,'Java_processes':292,'Java_first_use_processes':168,'Java_recovery_only_processes':176,'Debug_and_Release':True,'complete_immutable_reports':True,'archive_index_restore':True,'mutated_archive_refused':208,'acknowledged_and_unknown_distinguished':True,'witness_reply_losses_reconciled':True,'original_source_rechecked':True,'archive_members':len(members),'all_archived_records_replayed':True,'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
