from pathlib import Path
import json,shutil
import rust_sdk_profile as sdk
import continuity_android_jni as jni
import continuity_android_recovery as recovery
root=Path.cwd();base=Path(__file__).resolve().parent;out=base/'integrated4';out.mkdir()
boundary=json.loads((base/'boundary5/BOUNDARY.json').read_text());first=json.loads((base/'first-use/STATE.json').read_text());old=json.loads((base/'witness/STATE.json').read_text())
assert all(x['completed'] and not x['live_producer'] for x in [boundary,first,old])
work=Path(boundary['work']);consumer=Path(old['consumer']);native_work=consumer.parent
env=dict(json.loads((root/'target/continuity-apple-package-stable/PRIVATE_ENVIRONMENT.json').read_text()),CARGO_TARGET_DIR=str(native_work/'rust-target'))
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
jar=base/'first-use/continuity-android-recovery-classes.jar';assert sdk.snapshot(jar).sha256==first['jar_sha256']
native=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())['native']
paths=[root/'artifact'/name for name in ['continuity_android_recovery.py','continuity_android_recovery_records.py','continuity_android_jni.py','continuity_android_account.py','continuity_android_contract.py']]
state={'completed':False,'live_producer':True,'work':str(work),'profiles':{},'source_inputs':{str(p.relative_to(root)):sdk.snapshot(p).sha256 for p in paths}}
def save():(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,label,cwd=consumer,runtime=None):return sdk.command(list(map(str,args)),out/('android-jni-'+label),cwd,environment=env if runtime is None else runtime)
save()
try:
 for profile in ('debug','release'):
  installed=work/profile;source=Path(native['execution'][profile]['binaries']['C_client']['path']);receiver=installed/'qpc-c-client';shutil.copy2(source,receiver)
  assert sdk.snapshot(receiver,maximum=256*1024*1024).sha256==native['execution'][profile]['binaries']['C_client']['sha256']
  expected=first['profiles'][profile]['binary_sha256'];matches=[p for p in (native_work/'rust-target'/profile/'deps').glob('android-*') if p.is_file() and p.stat().st_mode&0o111 and sdk.snapshot(p,maximum=256*1024*1024).sha256==expected];assert len(matches)==1
  driver=jni._driver(installed,jdk/'bin/java',jar,work/'tests',installed)
  result=recovery.qualify(consumer,installed,out,profile,env,run,java=jdk/'bin/java',jar=jar,tests=work/'tests',android=matches[0],android_driver=driver,client=receiver)
  assert result['completed'];state['profiles'][profile]=result;save();print(profile+' canonical Android recovery qualifier passed',flush=True)
 for name,digest in boundary['source_hashes'].items():assert sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,name
 for name,digest in state['source_inputs'].items():assert sdk.snapshot(root/name).sha256==digest,name
 state['completed']=True
finally:state['live_producer']=False;save()
