from pathlib import Path
import os,json,shutil,sys,shlex,zipfile
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();base=Path(__file__).resolve().parent;out=base/'first-use';out.mkdir()
boundary=json.loads((base/'boundary3/BOUNDARY.json').read_text());assert boundary['completed'] and not boundary['live_producer'];work=Path(boundary['work'])
prior=json.loads((base/'witness/STATE.json').read_text());assert prior['completed'] and not prior['live_producer'];consumer=Path(prior['consumer']);native_work=consumer.parent
for name in ['android_account.rs','android_account_recovery.rs']:shutil.copy2(root/'bindings/c/ContinuityPackageConsumer/tests/common'/name,consumer/'tests/common'/name)
env=dict(json.loads((root/'target/continuity-apple-package-stable/PRIVATE_ENVIRONMENT.json').read_text()),CARGO_TARGET_DIR=str(native_work/'rust-target'));tool=Path(env['RUSTC']).parent
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
jar=out/'continuity-android-recovery-classes.jar'
with zipfile.ZipFile(jar,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((work/'classes').rglob('*.class')):
  info=zipfile.ZipInfo(p.relative_to(work/'classes').as_posix());info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
state={'completed':False,'live_producer':True,'work':str(work),'profiles':{},'jar_sha256':sdk.snapshot(jar).sha256}
def save():(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,label,runtime=None):return sdk.command(list(map(str,args)),out/label,consumer,environment=env if runtime is None else runtime)
save()
try:
 run([tool/'cargo','clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],'clippy')
 for profile in ('debug','release'):
  installed=work/profile
  command=[str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(installed),'-cp',str(jar)+os.pathsep+str(work/'tests')]
  driver=installed/'first-use-driver.py'
  driver.write_text('import os,sys\nmode,profile,inputs,target,output=sys.argv[1:]\nprobe="FirstUseRecoveryProbe" if mode.startswith("recovery-") else "AccountProbe" if mode.startswith("account-") else "EnrollmentProbe"\ncommand='+repr(command)+'+["dev.qperiapt.continuity.android.tests."+probe,inputs,target,profile,mode,output]\nos.execv(command[0],command)\n')
  launcher=installed/'first-use-driver';launcher.write_text('#!/bin/sh\nexec '+shlex.join([sys.executable,str(driver)])+' "$@"\n');launcher.chmod(0o700)
  extra=['--release'] if profile=='release' else []
  built=run([tool/'cargo','test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2',*extra],profile+'-build')
  binary=c.built_artifact(built,consumer,native_work/'rust-target'/profile,library=False,test_name='android')
  test='android_account::recovery::first_use';runtime=dict(env,QPC_ANDROID_CASES=str(installed/'first-use-cases'),QPC_ANDROID_DRIVER=str(launcher))
  stdout=run([binary,'--exact',test,'--nocapture'],profile+'-execution',runtime)
  assert stdout.decode().splitlines().count('test '+test+' ... ok')==1 and b'1 passed; 0 failed;' in stdout
  assert stdout.count(b'qualified first-use recovery ')==2
  state['profiles'][profile]={'passed':True,'binary_sha256':sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256};save();print(profile+' Java-created installation and archive/index recovery passed',flush=True)
 for name,digest in boundary['source_hashes'].items():assert sdk.snapshot(root/'bindings/android/ContinuityPackageConsumer'/name).sha256==digest,name
 state['completed']=True
finally:state['live_producer']=False;save()
