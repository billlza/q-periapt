from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main/"target/peer-account-retirement-process-current/source"
checks=json.loads((out/"CHECKS.json").read_text())
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=src,text=True).strip()
assert head==checks["head"] and not subprocess.check_output(["git","status","--porcelain"],cwd=src,text=True)
checks["environment"]={"architecture":"arm64","macos":"27.0","rust":"rustc 1.98.1 (48a229cea 2026-09-01)","msrv":"rustc 1.90.0 (1159e78c4 2025-09-14)","minimum_macos_13_tested":False}
(out/"CHECKS.json").write_text(json.dumps(checks,indent=2)+"\n")
labels=list(checks["checks"])+["managed-installed-entry-02","managed-installed-entry-03","managed-installed-clippy"]
with zipfile.ZipFile(out/"CAPTURE.zip","w",zipfile.ZIP_DEFLATED) as z:
    for f in sorted(out.iterdir()):
        if f.is_file() and f.name not in ("CAPTURE.zip","CAPTURE.json") and f.stat().st_size<5000000:z.write(f,"evidence/"+f.name)
    for label in labels:
        folder=main/"target/account-authority-current"/label
        for f in sorted(folder.rglob("*")):
            if f.is_file():z.write(f,"runs/"+str(f.relative_to(main/"target/account-authority-current")))
    for name in ["CHECKS.json","CAPTURE.json","CAPTURE.zip"]:
        z.write(main/"target/account-managed-activation-current"/name,"prior-managed-enrollment/"+name)
    for path in subprocess.check_output(["git","diff","--name-only","39df517e",head],cwd=src,text=True).splitlines():z.write(src/path,"source/"+path)
cap=out/"CAPTURE.zip"
with zipfile.ZipFile(cap) as z:members=len(z.infolist());assert z.testzip() is None
record={"head":head,"bytes":cap.stat().st_size,"members":members,"sha256":hashlib.sha256(cap.read_bytes()).hexdigest(),"native_current_focused_checks":True,"full_native_current_head":False,"foreign_managed_owner_qualification":False,"release_claim_eligible":False}
(out/"CAPTURE.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
