from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main/"target/peer-account-retirement-process-current/source"
def git(*args,cwd=src): return subprocess.check_output(["git",*args],cwd=cwd,text=True).strip()
def save(path,value):path.write_text(json.dumps(value,indent=2)+"\n")
labels=["managed-installed-regression-02","managed-enrollment-final","managed-existing-witness-session-02","managed-installed-clippy-02","managed-installed-msrv","managed-installed-doc"]
checks={}
for label in labels:
    path=main/"target/account-authority-current"/label
    d=json.loads((path/"RESULT.json").read_text())
    assert d["completed"] and d["returncode"]==0 and d["source_unchanged"] and d["head_unchanged"],label
    assert len(d["source_sha256"])==509
    assert all(hashlib.sha256((src/f).read_bytes()).hexdigest()==h for f,h in d["source_sha256"].items()),label
    checks[label]={k:v for k,v in d.items() if k!="source_sha256"}
    checks[label]["matches_committed_sources"]=True
allowed={"ARTIFACT.md","artifact/codeql_rust_quality.py","artifact/test_codeql_rust_quality.py","research/continuity-identity-candidate/AUTHORITY_REPLACEMENT.md"}
allowed|={"research/continuity-identity-candidate/src/"+f for f in ["enrollment/account_authority.rs","enrollment/witness_policy_session_tests.rs","enrollment/witness_policy_session_managed_tests.rs","installation.rs","installation/admission.rs","installation/reopen.rs","installation/tests/reopen.rs","installation/tests/reopen/account_authority.rs","lib.rs"]}
changed=set(git("diff","HEAD","--name-only").splitlines())
assert changed==allowed,(changed,allowed)
assert not git("ls-files","--others","--exclude-standard")
subprocess.run(["git","diff","--check"],cwd=src,check=True)
(out/"SOURCE.diff").write_bytes(subprocess.check_output(["git","diff","HEAD"],cwd=src))
subprocess.run(["git","add","--",*sorted(allowed)],cwd=src,check=True)
subprocess.run(["git","commit","-m","Expose managed admission for installed sessions"],cwd=src,check=True)
head=git("rev-parse","HEAD");assert not git("status","--porcelain")
record={"updated_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":head,"source":str(src),"checks":checks,"tests":{"managed_enrollment":12,"installation_related":70,"new_managed_cases_included":6,"existing_witnessed_session":1,"doctests":17,"source_inventory_units":44},"source_inventory":509,"frozen_prior_full":{"head":"39df517efc64624affeef593170db2c048ca372c","session":45812,"complete":False},"foreign_managed_registry_owners_implemented":False,"installed_foreign_managed_qualification":False,"performance_measured":False,"release_claim_eligible":False}
save(out/"CHECKS.json",record)
s=json.loads((out/"STATE.json").read_text());s.update(head=head,committed=True,working_tree_clean=True,validation_session=None,local_focused_qualification_complete=True,checks=str(out/"CHECKS.json"));save(out/"STATE.json",s)
m=json.loads((out/"MAINTENANCE.json").read_text());m.update(head=head,source_head=head,working_tree_modified=False,shared_reconciliation_helpers_before=2,shared_reconciliation_helpers_after=1);save(out/"MAINTENANCE.json",m)
print(json.dumps({"committed":head,"installation_tests":70,"source_matched_checks":len(checks)}),flush=True)
