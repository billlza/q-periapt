from pathlib import Path
import subprocess
base=Path(__file__).resolve().parent
root=base.parent.parent
python="/opt/homebrew/opt/python@3.14/bin/python3.14"
steps=[("managed-installed-regression-02", "focused", "installation"), ("managed-enrollment-final", "focused", "managed_enrollment"), ("managed-existing-witness-session-02", "focused", "real_witnessed_session_reopens_after_p0_expiry"), ("managed-installed-msrv", "msrv"), ("managed-installed-doc", "doc")]
for step in steps:
    with (base/(step[0]+".stdout")).open("wb") as stdout, (base/(step[0]+".stderr")).open("wb") as stderr:
        r=subprocess.run([python,"-B",str(root/"target/account-authority-current/run-check.py"),*step],cwd=root,stdout=stdout,stderr=stderr)
    print(f"{step[0]} exit={r.returncode}",flush=True)
    if r.returncode: raise SystemExit(r.returncode)
