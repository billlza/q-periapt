"""Controlled public APK byte source for the isolated host pipe experiment."""
import os
from pathlib import Path
import sys
import time

mode, payload_name, count_text = sys.argv[1:]
payload = Path(payload_name).read_bytes()
count = int(count_text)
if mode == "leader-exits":
    child = os.fork()
    if child:
        os._exit(0)
    time.sleep(0.1)
if mode == "timeout":
    os.write(1, payload[:1024])
    time.sleep(10)
    raise SystemExit("unexpected timeout survival")
if mode == "over-limit":
    payload += b"x"
else:
    payload = payload[:count]
chunk_size = 4093 if mode == "fragmented" else len(payload)
if mode == "chunked":
    chunk_size = 65536
for offset in range(0, len(payload), chunk_size):
    remaining = memoryview(payload)[offset:offset + chunk_size]
    while remaining:
        written = os.write(1, remaining)
        if written <= 0:
            raise RuntimeError("child write made no progress")
        remaining = remaining[written:]
os._exit(7 if mode == "nonzero" else 0)
