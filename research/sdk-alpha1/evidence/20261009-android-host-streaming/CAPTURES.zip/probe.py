"""Exercise the unchanged bounded file writer with real Linux child processes."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

import bounded_process

root = Path(__file__).resolve().parent
inputs = json.loads((root / "INPUTS.json").read_text())
payload = root / "payload.apk"
assert hashlib.sha256(payload.read_bytes()).hexdigest() == inputs["payload_sha256"]
assert hashlib.sha256((root / "bounded_process.py").read_bytes()).hexdigest() == inputs["bounded_process_sha256"]
output = root / "outputs"
output.mkdir(mode=0o700)
directory = os.open(output, os.O_RDONLY | os.O_DIRECTORY)
report = {
    "inputs": inputs,
    "platform": platform.platform(),
    "python": sys.version,
    "uid": os.getuid(),
    "runs": [],
    "complete": False,
    "scope": "Controlled host pipe and filesystem writer only; no ADB, ART or SDK workload.",
}
cases = []
for mode in ("bulk", "fragmented", "chunked", "leader-exits"):
    for repeat in range(2):
        cases.append((f"{mode}-{repeat}", mode, inputs["payload_bytes"], None))
for length in (1119744, 6271488):
    cases.append((f"zero-exit-short-{length}", "short", length, None))
cases.extend([
    ("nonzero-short", "nonzero", 1119744, None),
    ("over-limit", "over-limit", inputs["payload_bytes"], "output_limit"),
    ("timeout", "timeout", inputs["payload_bytes"], "timeout"),
])
try:
    for label, mode, length, expected_failure in cases:
        name = label + ".out"
        command = [sys.executable, str(root / "emit.py"), mode, str(payload), str(length)]
        start = time.monotonic()
        record = {"label": label, "command": command, "expected_failure": expected_failure}
        try:
            result = bounded_process.write_stdout_at(
                command, output_directory_fd=directory, output_name=name,
                timeout_seconds=1 if mode == "timeout" else 15,
                maximum_bytes=inputs["payload_bytes"], stderr=subprocess.DEVNULL,
            )
        except bounded_process.BoundedProcessError as error:
            assert error.kind == expected_failure, (label, error.kind)
            assert not getattr(error, "__notes__", None), (label, error.__notes__)
            assert not (output / name).exists(), label
            record.update(error_kind=error.kind, partial_output_published=False)
        else:
            assert expected_failure is None, label
            record["returncode"] = result.returncode
            if mode == "nonzero":
                assert result.returncode == 7 and not (output / name).exists()
                record["partial_output_published"] = False
            else:
                assert result.returncode == 0
                data = (output / name).read_bytes()
                digest = hashlib.sha256(data).hexdigest()
                assert len(data) == length
                assert data == payload.read_bytes()[:length]
                exact = len(data) == inputs["payload_bytes"] and digest == inputs["payload_sha256"]
                assert exact == (mode != "short"), label
                record.update(bytes=len(data), sha256=digest, matches_whole_apk=exact)
        record["seconds"] = time.monotonic() - start
        report["runs"].append(record)
        (root / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    assert not list(output.glob(".*.bounded-*"))
    report["complete"] = True
    report["temporary_outputs_remaining"] = False
    (root / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"cases": len(cases), "complete": True, "platform": report["platform"]}))
finally:
    os.close(directory)
