"""Bind the full-model helper replay and isolate the next bounded search."""
from pathlib import Path
import ast
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

s = Path(__file__).resolve().parent
prepared = json.loads((s / 'PHASE_WITNESS_PREPARED_254.json').read_text())
terminal = json.loads((s / 'phase-wire-helper-255-TERMINAL.json').read_text())
qualified = json.loads((s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json').read_text())
checker = s / 'phase_certificate_check_251.py'
sdk.require(sdk.snapshot(checker).sha256 == qualified['checker_sha256'], 'certificate checker changed')
spec = importlib.util.spec_from_file_location('witness_replay_check', checker)
sdk.require(spec is not None and spec.loader is not None, 'checker missing')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
model = check.model
source = s / 'phase-wire-witness-254.spthy'
certificate = s / 'phase-wire-helper-255-proof.spthy'
sdk.require(terminal['accepted'] and terminal['returncode'] == 0 and not terminal['timed_out']
            and not terminal['output_exceeded'], 'helper replay did not complete')
sdk.require(not any(a.startswith('--prove') for a in terminal['argv']), 'helper replay requested search')
sdk.require(sdk.snapshot(source).sha256 == prepared['candidate_sha256'] == terminal['input_sha256'], 'input identity differs')
sdk.require(sdk.snapshot(certificate).sha256 == terminal['output_sha256'], 'replayed certificate changed')
name = 'first_responder_ready_event_is_unique'
sdk.require(terminal['results'][name] == {'mode': 'all-traces', 'status': 'verified', 'steps': 285}, 'helper result differs')
original = model.uncomment((s / 'phase-wire-original-254-parse-89.stdout').read_text())
candidate = model.parsed('phase-witness-input-256', source)
queries = model.queries(candidate)
sdk.require(len(queries) == 16 and {k: v for k, v in queries.items() if k != name} == model.queries(original),
            'original query inventory differs')
offset = re.search(r'(?m)^lemma ', original).start()
expected = original[:offset] + queries[name] + '\nby sorry\n\n' + original[offset:]
parsed = model.parsed('phase-witness-replay-256', certificate)
sdk.require(len(check.verify_certificate_model(expected, parsed)) == 11, 'replayed model correspondence differs')
sdk.require(model.queries(parsed) == queries, 'replayed query inventory differs')
ordering = json.loads((s / 'PHASE_ORDER_PREPARED_241.json').read_text())
for suffix, key in (('.py', 'oracle_sha256'),):
    sdk.require(sdk.snapshot(s / ('phase-order-oracle-241' + suffix)).sha256 == ordering[key], 'oracle changed')
sdk.require(sdk.snapshot(s / 'phase-order-run-241.py').sha256 == ordering['driver_sha256'], 'driver changed')
outputs = {}
for old_name, new_name in (
    ('phase-order-oracle-241.py', 'phase-witness-oracle-256.py'),
    ('phase-order-oracle-241.sh', 'phase-witness-oracle-256.sh'),
    ('phase-order-run-241.py', 'phase-witness-run-256.py'),
):
    old = (s / old_name).read_text()
    new = old.replace('phase-order-oracle-241', 'phase-witness-oracle-256')
    sdk.require(new.replace('phase-witness-oracle-256', 'phase-order-oracle-241') == old, 'non-identity change')
    if new_name.endswith('.py'):
        ast.parse(new)
    path = s / new_name
    with path.open('x') as f:
        f.write(new)
    if new_name.endswith('.sh'):
        path.chmod(0o700)
    outputs[new_name] = sdk.snapshot(path).sha256
sdk.write_json(s / 'PHASE_WITNESS_SEARCH_READY_256.json', {
    'completed': True,
    'source_sha256': sdk.snapshot(source).sha256,
    'replayed_certificate_sha256': sdk.snapshot(certificate).sha256,
    'helper_independently_verified_under_full_wire_model': terminal['results'][name],
    'all_sixteen_complete_queries_preserved': True,
    'full_rule_and_global_model_correspondence_passed': True,
    'fresh_runner_files': outputs,
    'ranking_change': 'None; only oracle paths/log identities differ from checked 241.',
    'required_main_results': prepared['required_before_main_acceptance'],
    'main_witness_proved': False,
    'release_claim_eligible': False,
})
print('Full-model helper replay bound to all 16 queries; fresh identical oracle and bounded runner prepared.')
