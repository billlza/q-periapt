"""Read only the isolated loopback proof views; retain bounded raw responses."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import build_opener, ProxyHandler, HTTPRedirectHandler
from urllib.parse import urlsplit
import hashlib
import json
import re
import sys
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
started = json.loads((stage / "INTERACTIVE_STARTED_238.json").read_text())
relative, label = sys.argv[1:]
sdk.require(relative == "/" or re.fullmatch(r"/thy/trace/[0-9]+/(?:main|overview|graph|interactive-graph-def)/(?:proof|cases|lemma|help|rules)(?:/[A-Za-z0-9_.%+-]+)*", relative) is not None, "not a read-only theory view")
sdk.require(re.fullmatch(r"[a-z0-9-]+", label) is not None, "invalid output label")
base = "http://127.0.0.1:" + str(started["port"])

class LocalRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        sdk.require(newurl.startswith(base + "/"), "non-loopback redirect")
        return super().redirect_request(req, fp, code, msg, headers, newurl)

class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.text = []
        self.links = []
    def handle_data(self, data):
        if data.strip():
            self.text.append(data.strip())
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("href"):
            self.links.append(attrs["href"])

opener = build_opener(ProxyHandler({}), LocalRedirect())
try:
    with opener.open(base + relative, timeout=30) as response:
        data = response.read(2*1024**2 + 1)
        sdk.require(response.status == 200 and len(data) <= 2*1024**2, "proof view failed or exceeded bound")
        kind = response.headers.get("Content-Type", "")
except OSError as exc:
    sdk.write_json(stage / (label + ".json"), {"completed": False, "path": relative, "error": str(exc)})
    raise
with (stage / (label + ".body")).open("xb") as stream:
    stream.write(data)
text = data.decode("utf-8")
if "json" in kind:
    payload = json.loads(text)
    text = payload.get("html", text) if isinstance(payload, dict) else text
page = Page()
page.feed(text)
sdk.write_json(stage / (label + ".json"), {"completed": True, "path": relative, "content_type": kind,
    "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "text": page.text, "links": page.links})
print(json.dumps({"bytes": len(data), "content_type": kind, "text": page.text[:70], "links": page.links[:24]}, ensure_ascii=False))
