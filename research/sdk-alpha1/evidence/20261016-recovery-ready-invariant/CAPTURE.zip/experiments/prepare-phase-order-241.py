"""Preserve phase priorities and check impossible epoch-zero application first."""
from pathlib import Path
import ast
import importlib.util
import json
import re
import sys
from bounded_process import capture_output
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('phase_order_codec', s / 'phase_state_codec_235.py')
sdk.require(spec is not None and spec.loader is not None, 'codec missing')
c = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = c
spec.loader.exec_module(c)
prepared = json.loads((s / 'PHASE_INJECTIVITY_OBSERVED_239.json').read_text())
sdk.require(prepared['completed'], 'tool recognition not observed')
old = (s / 'ready-action-oracle-225.py').read_text()
new = old.replace('ready-action-oracle-225', 'phase-order-oracle-241')
helper = '''    def fact_arguments(goal, name):
        match = re.match(r"!?" + name + r"\\s*\\(", goal)
        if not match:
            return None
        start = match.end()
        depth, tuples, quoted = 1, 0, False
        fields = []
        for i in range(start, len(goal)):
            char = goal[i]
            if char == "'":
                quoted = not quoted
            elif not quoted:
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        if tuples:
                            raise ValueError("unbalanced goal tuple")
                        fields.append(goal[start:i].strip())
                        return fields
                elif char == "<":
                    tuples += 1
                elif char == ">":
                    tuples -= 1
                    if tuples < 0:
                        raise ValueError("unbalanced goal tuple")
                elif char == "," and depth == 1 and tuples == 0:
                    fields.append(goal[start:i].strip())
                    start = i + 1
        raise ValueError("unclosed goal fact")

'''
needle = '    def score(item):\n'
sdk.require(new.count(needle) == 1, 'score definition differs')
new = new.replace(needle, helper + needle, 1)
addition = '''        application = fact_arguments(goal, "ApplicationEpoch")
        if application is not None:
            if len(application) != 2:
                raise ValueError("application epoch arity differs")
            if application[1] == "'zero'":
                return -300
        phase = fact_arguments(goal, "PhaseState")
        if phase is not None:
            if len(phase) != 6:
                raise ValueError("phase state arity differs")
            if phase[4] == "'Ready'":
                return 1.5
            if phase[4] in {"'Offer1'", "'Offer2'", "'Offer3'", "'Response4'", "'Response5'", "'Response6'", "'Final7'", "'Final8'", "'Receipt9'"}:
                return 3
            raise ValueError("unknown phase discriminator")
'''
new = new.replace('        _, goal = item\n', '        _, goal = item\n' + addition, 1)
sdk.require(new.replace(helper, '', 1).replace(addition, '', 1).replace('phase-order-oracle-241', 'ready-action-oracle-225') == old, 'unrelated oracle change')
ast.parse(new)

def functions(source):
    tree = ast.parse(source)
    found = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name in ('score', 'fact_arguments')]
    namespace = {'re': re}
    exec(compile(ast.Module(body=found, type_ignores=[]), '<ranking-only>', 'exec'), namespace)
    return namespace

before, after = functions(old)['score'], functions(new)['score']
original = (s / 'phase-original-235-parse.stdout').read_text()
model_spec = importlib.util.spec_from_file_location('phase_order_model', s / 'verify-counter-model-89.py')
sdk.require(model_spec is not None and model_spec.loader is not None, 'model checker missing')
model = importlib.util.module_from_spec(model_spec)
model_spec.loader.exec_module(model)
source_rules = c.rules(model.uncomment(original))
application_producers = []
phase_checks = 0
for _, _, rule in source_rules:
    for f in rule.conclusions:
        if f.name == 'ApplicationEpoch':
            sdk.require(f.persistent and len(f.args) == 2 and f.args[1].name == 'succ'
                        and f.args[1].args is not None and len(f.args[1].args) == 1, 'unexpected application epoch producer')
            application_producers.append(rule.name)
    for f in (*rule.premises, *rule.conclusions):
        if f.name in c.PHASES:
            encoded = c.encode_fact(f, c.OWNER)
            sdk.require(before((0, f.text() + ' ▶₀ #control')) == after((0, encoded.text() + ' ▶₀ #control')),
                        'phase priority mapping differs')
            phase_checks += 1
sdk.require(application_producers == ['Final_Commit_8', 'Receipt_Commit_0'] and phase_checks == 24, 'source census differs')

for suffix, data in (
    ('.py', new),
    ('.sh', (s / 'ready-action-oracle-225.sh').read_text().replace('ready-action-oracle-225', 'phase-order-oracle-241')),
):
    path = s / ('phase-order-oracle-241' + suffix)
    with path.open('x') as f:
        f.write(data)
    if suffix == '.sh':
        path.chmod(0o700)
driver = (s / 'ready-action-run-225.py').read_text().replace('ready-action-oracle-225', 'phase-order-oracle-241')
ast.parse(driver)
with (s / 'phase-order-run-241.py').open('x') as f:
    f.write(driver)

samples = {
    'priority': "9: SendState(s,'B','zero',r,o,p,c)[+,no_precomp] ▶₀ #i\n7: !ApplicationEpoch(s,'zero')[no_precomp] ▶₁ #i\n3: PhaseState(owner,s,'B',n,'Ready',<h(<a,b>),r,'A'>)[no_precomp] ▶₀ #j\n5: !KU(sign(<x,y>,k)) @ #q\n",
    'positive_epoch': "1: !ApplicationEpoch(s,succ('zero'))[no_precomp] ▶₁ #i\n2: PhaseState(owner,s,'A',n,'Offer1',<p,r,k>)[no_precomp] ▶₀ #j\n",
    'malformed_phase': "0: PhaseState(owner,s,'A',n,'Ready',<x,y>)\n1: PhaseState(owner,s)\n",
    'unknown_phase': "0: PhaseState(owner,s,'A',n,'Unknown',<x,y>)\n",
}
control = s / 'phase-order-control-241'
control.mkdir(mode=0o700)
checks = []
for label, raw in samples.items():
    folder = control / label
    folder.mkdir(mode=0o700)
    script = folder / 'oracle.py'
    script.write_text(new)
    path = folder / 'input'
    path.write_text(raw)
    path.chmod(0o600)
    with path.open('rb') as stream:
        result = capture_output([sys.executable, '-I', '-S', '-B', str(root / 'artifact/python_bootstrap.py'), str(script),
                                 'first_responder_ready_event_is_unique'], timeout_seconds=10,
                                maximum_stdout_bytes=65536, maximum_stderr_bytes=65536, stdin_fd=stream.fileno())
    rejected = label in ('malformed_phase', 'unknown_phase')
    if rejected:
        sdk.require(result.returncode != 0 and not result.stdout and (folder / 'phase-order-oracle-241.failed').is_file(), 'invalid input admitted')
        ranking = None
    else:
        sdk.require(result.returncode == 0 and not result.stderr, 'oracle control failed')
        ranking = [int(x) for x in result.stdout.splitlines()]
        sdk.require(ranking == ([7, 3, 5, 9] if label == 'priority' else [2, 1]), 'unexpected goal ordering')
    checks.append({'case': label, 'input_sha256': sdk.snapshot(path).sha256, 'ranking': ranking, 'rejected': rejected})
sdk.write_json(s / 'PHASE_ORDER_PREPARED_241.json', {
    'completed': True, 'source_phase_occurrences_mapped': phase_checks,
    'application_epoch_producers': application_producers,
    'real_oracle_controls': checks,
    'model_sha256': sdk.snapshot(s / 'phase-state-235.spthy').sha256,
    'oracle_sha256': sdk.snapshot(s / 'phase-order-oracle-241.py').sha256,
    'driver_sha256': sdk.snapshot(s / 'phase-order-run-241.py').sha256,
    'scope': 'Same exact model and ten queries. Encoded phase facts inherit their prior phase-specific priorities; only the existing impossible epoch-zero ApplicationEpoch premise is selected earlier. Every numbered goal remains ranked.',
    'proof_produced': False, 'release_claim_eligible': False,
})
print('Mapped all 24 phase occurrences; actual epoch-zero priority and invalid-input controls passed.')
