"""Bind actual certificates to the checked model; never execute normalized text."""
from dataclasses import replace
import importlib.util
from pathlib import Path
import re
import sys
import json
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
qualified = json.loads((s / 'PHASE_STATE_CHECKER_VERIFIED_236.json').read_text())
sdk.require(sdk.snapshot(s / 'phase_state_codec_235.py').sha256 == qualified['checker_sha256'], 'codec changed')

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, s / filename)
    sdk.require(spec is not None and spec.loader is not None, 'checker missing')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

c = load('certificate_phase_codec', 'phase_state_codec_235.py')
model = load('certificate_decl_model', 'verify-counter-model-89.py')
LATE_OPERATION = re.compile(r'(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic|predicate)\b')


def validated_model_comparison_text(value):
    """Model comparison only. Returned text is NOT a certificate or prover input."""
    text = model.uncomment(value)
    declarations = list(model.declaration.finditer(text))
    sdk.require(declarations, 'certificate has no complete query declarations')
    sdk.require(not LATE_OPERATION.search(text[declarations[0].start():]), 'late model declaration in proof region')
    # Validate the diagnostic builtin/type metadata before removing only those
    # redundant pretty-printer lines. The expanded signature/equations remain.
    empty = {r.name: replace(r, premises=(), actions=(), conclusions=()) for _, _, r in c.rules(text)}
    model.operational(c.replace_rules(text, empty))
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$','',text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$','',text)
    declarations = list(model.declaration.finditer(text))
    sdk.require(len(declarations) == len(model.queries(text)), 'duplicate query declaration')
    end = list(re.finditer(r'(?m)^end\s*$', text))
    sdk.require(len(end) == 1 and end[0].start() > declarations[-1].end(), 'theory end differs')
    # Preserve every full header/formula/attribute. Real proof scripts are
    # checked independently by Tamarin from the unchanged certificate file.
    return text[:declarations[0].start()] + '\n\n'.join(d[0] + '\nby sorry' for d in declarations) + '\n\nend\n'


def verify_certificate_model(original, certificate):
    sdk.require(model.queries(original) == model.queries(certificate), 'certificate query declaration differs')
    return c.verify(validated_model_comparison_text(original),
                    validated_model_comparison_text(certificate), model)


def main():
    original_path = s / 'phase-original-235-parse.stdout'
    sdk.require(sdk.snapshot(original_path).sha256 == qualified['parsed_original_sha256'], 'original parsed model changed')
    original = original_path.read_text()
    certificate = s / 'phase-order-search-242-proof.spthy'
    search = json.loads((s / 'phase-order-search-242-TERMINAL.json').read_text())
    sdk.require(search['accepted'] and sdk.snapshot(certificate).sha256 == search['output_sha256'], 'search certificate identity differs')
    parsed_path = s / 'phase-certificate-249-parse-89.stdout'
    parsed = parsed_path.read_text()
    # Recheck the archived parse command identity as well as its successful exit.
    parse = json.loads((s / 'phase-certificate-249-parse-89.json').read_text())
    sdk.require(parse['returncode'] == 0 and str(certificate) in parse['argv'] and '--parse-only' in parse['argv'], 'certificate parse identity differs')
    sdk.require(len(verify_certificate_model(original, parsed)) == 11, 'rule mapping census differs')
    sdk.require(len(model.queries(parsed)) == 10, 'query census differs')
    variants = {}
    equation = 'decap(x, kemct(kempk(x), y)) = y'
    sdk.require(parsed.count(equation) == 1, 'equation control missing')
    variants['changed_equation'] = parsed.replace(equation, 'decap(x, kemct(kempk(x), y)) = x', 1)
    declarations = list(model.declaration.finditer(model.uncomment(parsed)))
    first = declarations[0]
    uncommented = model.uncomment(parsed)
    variants['late_restriction'] = uncommented[:first.end()] + '\nrestriction NoTrace:\n "All s #i. Setup(s)@i ==> F"\n' + uncommented[first.end():]
    helper = model.queries(parsed)['first_responder_ready_event_is_unique']
    variants['weakened_helper'] = parsed.replace(helper, helper.split('"',1)[0] + '"T"', 1)
    main_query = model.queries(parsed)['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy']
    variants['missing_original_security_query'] = parsed.replace(main_query, '', 1)
    variants['added_reusable_assumption'] = parsed.replace('lemma first_responder_ready_event_is_unique:',
                                                         'lemma first_responder_ready_event_is_unique [reuse]:', 1)
    rules = {r.name:r for _,_,r in c.rules(model.uncomment(parsed))}
    changed = dict(rules)
    setup = changed['Setup']
    changed['Setup'] = replace(setup, premises=setup.premises[:-1])
    variants['missing_owner_freshness'] = c.replace_rules(model.uncomment(parsed), changed)
    rejected = {}
    for name, value in variants.items():
        sdk.require(value != parsed, 'ineffective certificate mutation: ' + name)
        try:
            verify_certificate_model(original, value)
        except ValueError as exc:
            rejected[name] = str(exc)
        else:
            raise ValueError('certificate mutation admitted: ' + name)
    sdk.write_json(s / 'PHASE_CERTIFICATE_MODEL_VERIFIED_251.json', {
        'completed': True, 'candidate_sha256': search['input_sha256'],
        'certificate_sha256': search['output_sha256'],
        'parsed_certificate_sha256': sdk.snapshot(parsed_path).sha256,
        'checker_sha256': sdk.snapshot(Path(__file__)).sha256,
        'all_ten_queries_and_original_rules_preserved_under_checked_encoding': True,
        'negative_controls_rejected': rejected,
        'comparison_scope': 'Validated pretty-printer metadata and proof scripts are excluded only from in-memory model comparison. All signatures, equations, restrictions, rules, annotations and complete query declarations remain checked. Normalized text is never saved as or passed to the prover as a certificate.',
        'retained_initial_failure': '249 used the input-model checker directly and rejected the new proof script/global printer metadata. The shell lacked set -e, so real replay250 started despite that comparison failure. Replay remains independently labelled and cannot qualify the model until this check succeeds.',
        'independent_replay_completed': False, 'release_claim_eligible': False,
    })
    print('Actual search certificate matches all model declarations; six certificate mutations rejected. Replay remains independent.')


if __name__ == '__main__':
    main()
