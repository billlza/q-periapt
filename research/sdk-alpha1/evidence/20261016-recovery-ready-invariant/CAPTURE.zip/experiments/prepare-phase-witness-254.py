"""Carry the independently checked Ready lemma into the full wire witness."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
record = json.loads((s / 'FIRST_READY_CERTIFIED_253.json').read_text())
sdk.require(record['completed'] and record['independent_replay']['accepted'], 'Ready helper is not certified')
helper_source = s / 'phase-replay-250-proof.spthy'
sdk.require(sdk.snapshot(helper_source).sha256 == record['independent_replay']['output_sha256'], 'helper certificate changed')
base = s / 'wire-observations-215.spthy'
sdk.require(sdk.snapshot(base).sha256 == 'a82cf0dfb5f71affa415b4bd918a8877967095289e284d58aee5841569920cab', 'wire witness model changed')
spec = importlib.util.spec_from_file_location('phase_witness_certificate_checker', s / 'phase_certificate_check_251.py')
sdk.require(spec is not None and spec.loader is not None, 'certificate checker missing')
check = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = check
spec.loader.exec_module(check)
c, model = check.c, check.model
original = model.uncomment(model.parsed('phase-wire-original-254', base))
encoded = c.encode(original)
sdk.require(len(c.verify(original, encoded, model)) == 11, 'wire model encoding differs')
old_queries = model.queries(original)
sdk.require(len(old_queries) == 15, 'wire query census differs')
name = 'first_responder_ready_event_is_unique'
certificate = helper_source.read_text()
block = re.search(r'(?ms)^lemma ' + re.escape(name) + r':.*?^qed$', certificate)
sdk.require(block is not None and name not in old_queries, 'complete helper proof missing or duplicated')
helper = block[0].replace('lemma ' + name + ':', 'lemma ' + name + ' [reuse]:', 1)
declaration = next(model.declaration.finditer(helper))[0]
offset = re.search(r'(?m)^lemma ', encoded).start()
augmented = encoded[:offset] + helper + '\n\n' + encoded[offset:]
old_offset = re.search(r'(?m)^lemma ', original).start()
# Expected declarations only: this in-memory comparison value is never run as
# a proof. The actual input below carries the real checked helper script.
expected = original[:old_offset] + declaration + '\nby sorry\n\n' + original[old_offset:]
raw = base.read_text()
raw_boundary = re.search(r'(?m)^rule ', raw).start()
encoded_boundary = re.search(r'(?m)^rule ', augmented).start()
actual = raw[:raw_boundary] + augmented[encoded_boundary:]
path = s / 'phase-wire-witness-254.spthy'
with path.open('x') as f:
    f.write(actual)
parsed = model.parsed('phase-wire-prepared-254', path)
queries = model.queries(parsed)
sdk.require(len(queries) == 16 and {k:v for k,v in queries.items() if k != name} == old_queries,
            'one of fifteen original complete queries changed')
sdk.require(len(check.verify_certificate_model(expected, parsed)) == 11, 'wire model correspondence changed')
reusable = [k for k,v in queries.items() if re.search(r'\b(?:reuse|sources)\b', v.split(':',1)[0])]
sdk.require(reusable == [name], 'unexpected reusable premise')
sdk.write_json(s / 'PHASE_WITNESS_PREPARED_254.json', {
    'completed': True, 'original_wire_model_sha256': sdk.snapshot(base).sha256,
    'candidate_sha256': sdk.snapshot(path).sha256,
    'checked_helper_certificate_sha256': sdk.snapshot(helper_source).sha256,
    'all_fifteen_original_queries_preserved': True,
    'phase_encoding_and_wire_observation_correspondence_preserved': True,
    'only_reusable_helper': name,
    'required_before_main_acceptance': [name, 'two_rounds_with_matching_wire_events_is_executable'],
    'next_step': 'Replay the supplied helper under this exact wire-observation extension before searching the main witness. Both terminal results must verify in any accepted main-search certificate.',
    'scope': 'The stronger witness still projects to the original two-round nonvacuity query. No round bound, disclosure restriction, equation or protocol transition is changed.',
    'main_witness_proved': False, 'release_claim_eligible': False,
})
print('Prepared all fifteen original witness/model queries plus the independently checked Ready helper; no new assumption admitted.')
