#!/bin/sh
exec /opt/homebrew/opt/python@3.14/bin/python3.14 -I -S -B /Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/artifact/python_bootstrap.py /Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-recovery-multi-epoch-20261015/ready-action-oracle-225.py "$@"
