"""Inspect one partial proof on loopback; stop on an owned marker or deadline."""
from pathlib import Path
import json
import os
import signal
import socket
import subprocess
import time
from continuity_recovery_proof import prover_environment
from formal_toolchain_contract import verify_installed
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
work = stage / "interactive-238"
work.mkdir(mode=0o700)
source = stage / "phase-state-235.spthy"
sdk.require(sdk.snapshot(source).sha256 == "e4ae6f2db1d3ebb7da2e8898a31f6178db24c9b8ac7c67f311da9422291ac5dc", "partial proof changed")
sdk.copy(source, work / "phase.spthy")
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
environment = prover_environment()
environment["PATH"] = os.pathsep.join((str(Path(tools["tamarin"]).parent), str(Path(tools["maude"]).parent), environment["PATH"]))
verify_installed("tamarin", path_environment=environment["PATH"])
with socket.socket() as reserved:
    reserved.bind(("127.0.0.1", 0))
    port = reserved.getsockname()[1]
argv = [tools["tamarin"], "interactive", str(work), "--interface=127.0.0.1", "--port=" + str(port),
        "--with-maude=" + tools["maude"], "--with-dot=/opt/homebrew/bin/dot", "--heuristic=s",
        "--derivcheck-timeout=60", "--quit-on-warning", "+RTS", "-N1", "-M6G", "-c100", "-s", "-RTS"]
started = time.monotonic()
reason = "process-exit"
with (stage / "interactive-238.stdout").open("xb") as stdout, (stage / "interactive-238.stderr").open("xb") as stderr:
    process = subprocess.Popen(argv, cwd=root, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
    sdk.write_json(stage / "INTERACTIVE_STARTED_238.json", {"pid": process.pid, "port": port,
        "argv": argv, "maximum_seconds": 300, "source_sha256": sdk.snapshot(source).sha256,
        "interface": "127.0.0.1", "proof_search_requested": False})
    try:
        while process.poll() is None:
            if (work / "STOP").exists():
                reason = "owned-stop-marker"
                break
            if time.monotonic() - started >= 300:
                reason = "deadline"
                break
            if max(stdout.tell(), stderr.tell()) > 4*1024**2:
                reason = "output-bound"
                break
            time.sleep(0.2)
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        code = process.wait(timeout=5)
sdk.write_json(stage / "INTERACTIVE_TERMINAL_238.json", {"returncode": code, "reason": reason,
    "elapsed_seconds": time.monotonic() - started, "no_security_property_claimed": True})
print(json.dumps({"reason": reason, "returncode": code}))
