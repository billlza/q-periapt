"""Bind the counter proofs to a conservative observation extension of the model."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root=Path.cwd()
stage=Path(__file__).resolve().parent
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
declaration=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')

def parsed(label,path):
    return sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(path),'--parse-only','--quit-on-warning'],stage/(label+'-parse-89'),root).decode()

def uncomment(text):
    return re.sub(r'//[^\n]*','',re.sub(r'/\*.*?\*/','',text,flags=re.S))

def queries(text):
    matches=list(declaration.finditer(uncomment(text)))
    sdk.require(len(matches)==len({m.group(1) for m in matches}),'duplicate query')
    return {m.group(1):m.group() for m in matches}

def split_actions(text):
    parts=[];start=0;depth=0
    for i,char in enumerate(text):
        if char in '(<[':depth+=1
        elif char in ')>]':depth-=1
        elif char==',' and depth==0:
            parts.append(text[start:i]);start=i+1
    sdk.require(depth==0,'unbalanced action list')
    parts.append(text[start:])
    return parts

def operational(text,erase_observations=False):
    head,tail=uncomment(text).split('\nlemma ',1)
    sdk.require(not re.search(r'(?m)^(?:rule|restriction|functions|equations|builtin|function|macros|heuristic|tactic)\b',tail),'late operational declaration')
    signature=re.search(r'(?s)functions:\s*(.*?)\nequations:',head)
    sdk.require(signature is not None,'missing expanded signature')
    functions={name:int(arity) for name,arity in re.findall(r'(\w+)/(\d+)',signature.group(1))}
    info=re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$',head)
    for name,args,result in info:
        types=[item.strip() for item in args.split(',') if item.strip()]
        sdk.require(name in functions and len(types)==functions[name] and set(types)<={'Any'} and result=='Any','function type differs')
    sdk.require({name for name,_,_ in info} in ({'kempk','kemct','decap','succ','scope'},set(functions)),'function inventory differs')
    sdk.require(set(re.findall(r'(?m)^builtin\s+(\S+)\s*$',head)) in (set(),{'hashing','signing','symmetric-encryption'}),'builtin inventory differs')
    head=re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$','',head)
    head=re.sub(r'(?m)^builtin\s+\S+\s*$','',head)
    head=re.sub(r'\[(?:\+\s*,\s*)?no_precomp\]','',head)
    removed=0
    def actions(match):
        nonlocal removed
        parts=split_actions(match.group(1));kept=[]
        for part in parts:
            if erase_observations and re.match(r'\s*CounterState\s*\(',part):removed+=1
            else:kept.append(part)
        return '--['+','.join(kept)+']->'
    head=re.sub(r'--\[(.*?)\]\s*->',actions,head,flags=re.S)
    return re.sub(r'\s+','',head),removed

def main():
    sources={
        'old':'counter-constructor-77.spthy','observed':'counter-state-81.spthy',
        'priority':'counter-priority-84.spthy','search':'counter-state-82-proof.spthy',
        'short-search':'counter-priority-85-proof.spthy',
    }
    data={name:parsed(name,stage/filename) for name,filename in sources.items()}
    expected=operational(data['observed'])[0]
    for name in ('priority','search','short-search'):
        sdk.require(operational(data[name])[0]==expected,'changed proof model: '+name)
    erased,count=operational(data['observed'],True)
    sdk.require(count==7 and erased==operational(data['old'])[0],'observation erasure changes original semantics')
    all_queries=queries(data['observed'])
    sdk.require(len(all_queries)==7,'observed query inventory differs')
    for name in ('priority','search','short-search'):
        sdk.require(queries(data[name])==all_queries,'complete proof query differs: '+name)
    original_queries=dict(all_queries);del original_queries['produced_counter_has_public_constructor']
    sdk.require(queries(data['old'])==original_queries,'one of six previous complete queries changed')
    sdk.require(not re.search(r'\b(?:reuse|sources)\b','\n'.join(q.split(':',1)[0] for q in all_queries.values())),'unproved reusable premise')
    controls={}
    changed=data['observed'].replace('CounterState(', 'ChangedCounterState(',1)
    sdk.require(changed!=data['observed'] and operational(changed)[0]!=expected,'missing observation not rejected')
    controls['changed_counter_observation']=True
    changed=data['observed'].replace('RootBefore(', 'ChangedRootBefore(',1)
    sdk.require(changed!=data['observed'] and operational(changed,True)[0]!=erased,'changed old action not rejected')
    controls['changed_original_action']=True
    missing=dict(all_queries);del missing['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy']
    sdk.require(missing!=all_queries,'missing original security query not rejected')
    controls['missing_original_security_query']=True
    sdk.write_json(stage/'COUNTER_MODEL_VERIFIED_89.json',{
        'completed':True,'source_files':{filename:sdk.snapshot(stage/filename).sha256 for filename in sources.values()},
        'parsed_files':{name:sdk.snapshot(stage/(name+'-parse-89.stdout')).sha256 for name in sources},
        'all_seven_complete_queries_match_search_certificates':True,
        'seven_observations_erase_to_original_operational_model':True,
        'no_reuse_or_sources_premise':True,'identity_controls_rejected':controls,
        'independent_replay_still_required':True,'release_claim_eligible':False,
    })
    print('Both search certificates match all seven complete queries and the observation-preserving model')

if __name__=='__main__':main()
