"""Check an isolated, reversible encoding of the linear phase-state family.

This is a representation checker, not a security proof or a new protocol.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
import importlib.util
from pathlib import Path
import re
import rust_sdk_profile as sdk

PHASES = {
    'Ready': (6, 2), 'Offer1': (6, 2), 'Offer2': (6, 2), 'Offer3': (7, 2),
    'Response4': (9, 3), 'Response5': (9, 3), 'Response6': (9, 3),
    'Final7': (11, 3), 'Final8': (9, 3), 'Receipt9': (12, 3),
}
STATE = 'PhaseState'
OWNERS = ('~phase_owner_a', '~phase_owner_b')
OWNER = 'phase_owner'
TOKEN = re.compile(r"'[^']*'|[~$#]?[A-Za-z0-9_][A-Za-z0-9_.]*|[(),<>]")


@dataclass(frozen=True)
class Term:
    name: str
    args: tuple[Term, ...] | None = None

    def text(self):
        if self.args is None:
            return self.name
        if self.name == 'pair':
            sdk.require(len(self.args) == 2, 'pair arity differs')
            return '<' + ','.join(x.text() for x in self.args) + '>'
        return self.name + '(' + ','.join(x.text() for x in self.args) + ')'


def tuple_term(values):
    sdk.require(len(values) >= 2, 'tuple needs at least two fields')
    result = values[-1]
    for value in reversed(values[:-1]):
        result = Term('pair', (value, result))
    return result


def tuple_fields(value, count):
    sdk.require(count >= 2, 'tuple schema too short')
    result = []
    for _ in range(count - 1):
        sdk.require(value.name == 'pair' and value.args is not None and len(value.args) == 2,
                    'phase payload tuple is truncated')
        left, value = value.args
        result.append(left)
    return (*result, value)


def term(text):
    tokens = TOKEN.findall(text)
    sdk.require(''.join(tokens) == re.sub(r'\s+', '', text), 'unsupported term grammar')
    index = 0

    def take():
        nonlocal index
        sdk.require(index < len(tokens), 'truncated term')
        value = tokens[index]
        index += 1
        return value

    def parse():
        nonlocal index
        first = take()
        if first == '<':
            args = [parse()]
            while tokens[index:index + 1] == [',']:
                take()
                args.append(parse())
            sdk.require(take() == '>', 'unterminated tuple')
            return tuple_term(args)
        sdk.require(first not in (')', '>', ',', '('), 'invalid atom')
        if tokens[index:index + 1] != ['(']:
            return Term(first)
        take()
        args = []
        if tokens[index:index + 1] != [')']:
            args.append(parse())
            while tokens[index:index + 1] == [',']:
                take()
                args.append(parse())
        sdk.require(take() == ')', 'unterminated function')
        return Term(first, tuple(args))

    parsed = parse()
    sdk.require(index == len(tokens), 'trailing term input')
    return parsed


def split_fields(text):
    parts = []
    stack = []
    quoted = False
    start = 0
    for i, char in enumerate(text):
        if char == "'":
            quoted = not quoted
        elif not quoted:
            if char in '(<[':
                stack.append(char)
            elif char in ')>]':
                sdk.require(stack and '(<['[')>]'.index(char)] == stack.pop(), 'unbalanced field')
            elif char == ',' and not stack:
                parts.append(text[start:i].strip())
                start = i + 1
    sdk.require(not quoted and not stack, 'unterminated field')
    if text.strip():
        parts.append(text[start:].strip())
    sdk.require(all(parts), 'empty field')
    return parts


def bracket(text, start, opening, closing):
    sdk.require(text[start:start + 1] == opening, 'missing opening delimiter')
    depth = 0
    quoted = False
    for i in range(start, len(text)):
        char = text[i]
        if char == "'":
            quoted = not quoted
        elif not quoted:
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth == 0:
                    return text[start + 1:i], i + 1
    raise ValueError('unterminated delimiter')


@dataclass(frozen=True)
class Fact:
    name: str
    args: tuple[Term, ...]
    persistent: bool = False
    annotations: tuple[str, ...] = ()

    def text(self):
        annotation = '[' + ','.join(self.annotations) + ']' if self.annotations else ''
        return ('!' if self.persistent else '') + self.name + '(' + ','.join(x.text() for x in self.args) + ')' + annotation


def fact(text):
    match = re.match(r'(!?)([A-Za-z][A-Za-z0-9_]*)\s*\(', text)
    sdk.require(match is not None, 'invalid fact')
    inside, end = bracket(text, match.end() - 1, '(', ')')
    tail = text[end:].strip()
    annotations = ()
    if tail:
        annotation, end = bracket(tail, 0, '[', ']')
        sdk.require(not tail[end:].strip(), 'trailing fact input')
        annotations = tuple(split_fields(annotation))
        sdk.require(set(annotations) <= {'+', '-', 'no_precomp'}, 'unsupported fact annotation')
    return Fact(match[2], tuple(term(x) for x in split_fields(inside)), bool(match[1]), annotations)


@dataclass(frozen=True)
class Rule:
    name: str
    header: str
    premises: tuple[Fact, ...]
    actions: tuple[Fact, ...]
    conclusions: tuple[Fact, ...]

    def text(self):
        show = lambda facts: '[ ' + ',\n   '.join(f.text() for f in facts) + ' ]'
        arrow = '--' + show(self.actions) + '->' if self.actions else '-->'
        return self.header + '\n   ' + show(self.premises) + '\n  ' + arrow + '\n   ' + show(self.conclusions) + '\n\n'


def rules(text):
    matches = list(re.finditer(r'(?ms)^(rule(?: \(modulo E\))? (\w+):)\s*(.*?)(?=^rule |^restriction |^lemma |^end\b|\Z)', text))
    parsed = []
    for match in matches:
        body = match[3].strip()
        inside, end = bracket(body, 0, '[', ']')
        premises = tuple(fact(x) for x in split_fields(inside))
        rest = body[end:].strip()
        if rest.startswith('-->'):
            actions = ()
            rest = rest[3:].strip()
        else:
            sdk.require(rest.startswith('--['), 'invalid rule arrow')
            inside, end = bracket(rest, 2, '[', ']')
            actions = tuple(fact(x) for x in split_fields(inside))
            sdk.require(rest[end:].startswith('->'), 'missing action arrow')
            rest = rest[end + 2:].strip()
        inside, end = bracket(rest, 0, '[', ']')
        conclusions = tuple(fact(x) for x in split_fields(inside))
        sdk.require(not rest[end:].strip(), 'unparsed rule tail')
        parsed.append((match.start(), match.end(), Rule(match[2], match[1], premises, actions, conclusions)))
    sdk.require(parsed and len({r.name for _, _, r in parsed}) == len(parsed), 'rule inventory invalid')
    return parsed


def encode_fact(old, owner):
    arity, epoch = PHASES[old.name]
    sdk.require(len(old.args) == arity and not old.persistent, 'phase fact contract differs')
    payload = tuple_term(tuple(a for i, a in enumerate(old.args) if i not in (0, 1, epoch)))
    return Fact(STATE, (Term(owner), old.args[0], old.args[1], old.args[epoch], Term("'" + old.name + "'"), payload), False, old.annotations)


def decode_fact(encoded):
    sdk.require(encoded.name == STATE and len(encoded.args) == 6 and not encoded.persistent, 'encoded phase shape differs')
    owner, session, role, epoch_value, tag, payload = encoded.args
    sdk.require(tag.args is None and tag.name.startswith("'") and tag.name.endswith("'"), 'invalid phase discriminator')
    name = tag.name[1:-1]
    sdk.require(name in PHASES, 'unknown phase discriminator')
    arity, epoch = PHASES[name]
    rest = iter(tuple_fields(payload, arity - 3))
    args = tuple(session if i == 0 else role if i == 1 else epoch_value if i == epoch else next(rest) for i in range(arity))
    return Fact(name, args, False, encoded.annotations), owner


def replace_rules(text, replacements):
    result = text
    for start, end, old in reversed(rules(text)):
        result = result[:start] + replacements[old.name].text() + result[end:]
    return result


def declarations_outside_rules(text, model):
    # Rules are already compared as complete ASTs, including their annotations.
    # Do not compare pretty-printed tuple spellings: <a,b,c> and <a,<b,c>>
    # are the same pair term. Compare every remaining declaration separately.
    empty = {r.name: replace(r, premises=(), actions=(), conclusions=())
             for _, _, r in rules(text)}
    outside = model.uncomment(replace_rules(text, empty))
    return re.sub(r"'[^']*'|\s+", lambda match: match[0] if match[0].startswith("'") else '', outside)


def encode(text):
    sdk.require(not any(name in text for name in (STATE, OWNER, *OWNERS)), 'reserved encoding name already used')
    result = {}
    for _, _, old in rules(text):
        before = [f for f in old.premises if f.name in PHASES]
        after = [f for f in old.conclusions if f.name in PHASES]
        sdk.require(not any(f.name in PHASES for f in old.actions), 'phase fact used as observation')
        if old.name == 'Setup':
            sdk.require(not before and len(after) == 2 and all(f.name == 'Ready' for f in after), 'initial phase inventory differs')
            sdk.require([f.args[1] for f in after] == [Term("'A'"), Term("'B'")], 'initial roles differ')
            owners = iter(OWNERS)
            conclusions = tuple(encode_fact(f, next(owners)) if f.name in PHASES else f for f in old.conclusions)
            result[old.name] = replace(old, premises=old.premises + tuple(Fact('Fr', (Term(x),)) for x in OWNERS), conclusions=conclusions)
        elif before or after:
            sdk.require(len(before) == len(after) == 1 and before[0].args[:2] == after[0].args[:2], 'phase join, fork or principal change')
            result[old.name] = replace(old,
                premises=tuple(encode_fact(f, OWNER) if f.name in PHASES else f for f in old.premises),
                conclusions=tuple(encode_fact(f, OWNER) if f.name in PHASES else f for f in old.conclusions))
        else:
            result[old.name] = old
    return replace_rules(text, result)


def verify(original, candidate, model):
    old_rules = {r.name: r for _, _, r in rules(original)}
    new_rules = {r.name: r for _, _, r in rules(candidate)}
    sdk.require(list(old_rules) == list(new_rules), 'rule inventory or order changed')
    erased = {}
    transitions = {}
    for name, new in new_rules.items():
        sdk.require(not any(f.name in PHASES for f in (*new.premises, *new.actions, *new.conclusions)), 'unencoded old phase remains')
        sdk.require(not any(f.name == STATE for f in new.actions), 'private phase leaked to action')
        inputs = [(f, *decode_fact(f)) for f in new.premises if f.name == STATE]
        outputs = [(f, *decode_fact(f)) for f in new.conclusions if f.name == STATE]
        kept = new.premises
        if name == 'Setup':
            sdk.require(not inputs and len(outputs) == 2, 'initial phase inventory changed')
            sdk.require([owner for _, _, owner in outputs] == list(map(Term, OWNERS)), 'initial owners not distinct and fresh')
            added = tuple(Fact('Fr', (Term(x),)) for x in OWNERS)
            sdk.require(kept[-2:] == added and all(kept.count(f) == 1 for f in added), 'fresh owner premises differ')
            kept = kept[:-2]
        elif inputs or outputs:
            sdk.require(len(inputs) == len(outputs) == 1, 'encoded phase join or fork')
            sdk.require(inputs[0][2] == outputs[0][2] == Term(OWNER), 'private owner not propagated')
            sdk.require(inputs[0][1].args[:2] == outputs[0][1].args[:2], 'phase principal changed')
            transitions[name] = (inputs[0][1].name, outputs[0][1].name)
        erased[name] = replace(new,
            premises=tuple(decode_fact(f)[0] if f.name == STATE else f for f in kept),
            conclusions=tuple(decode_fact(f)[0] if f.name == STATE else f for f in new.conclusions))
        sdk.require(erased[name] == old_rules[name], 'rule erasure differs: ' + name)
    sdk.require(len(transitions) == 11, 'phase transition census differs')
    erased_text = replace_rules(candidate, erased)
    sdk.require(declarations_outside_rules(erased_text, model) == declarations_outside_rules(original, model),
                'global declarations or restrictions changed')
    sdk.require(model.queries(candidate) == model.queries(original), 'complete query declarations changed')
    # Exact rule erasure above also forbids owner occurrences in actions,
    # messages, other facts or expressions, as these would remain unerased.
    sdk.require(not any(name in erased_text for name in (STATE, OWNER, *OWNERS)), 'private identifier escaped erasure')
    return transitions


def main():
    root = Path.cwd()
    stage = Path(__file__).resolve().parent
    source = stage / 'first-ready-222.spthy'
    sdk.require(sdk.snapshot(source).sha256 == 'b4a3fb348a592da2dd7fcb02ea78bd92c27ac63de94d8fd8fbfb2147eb8e115d', 'source identity changed')
    spec = importlib.util.spec_from_file_location('phase_model_check', stage / 'verify-counter-model-89.py')
    sdk.require(spec is not None and spec.loader is not None, 'model checker missing')
    model = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(model)
    def parse(label, source_path):
        # parse-only emits typed diagnostic declarations even when spthy is
        # requested. Keep this output for comparison, not as an input prelude.
        return sdk.command([model.tools['tamarin'], '--with-maude=' + model.tools['maude'],
                            str(source_path), '--parse-only', '--output-module=spthy', '--quit-on-warning'],
                           stage / (label + '-parse'), root).decode()
    original = model.uncomment(parse('phase-original-235', source))
    candidate = encode(original)
    transitions = verify(original, candidate, model)
    raw = sdk.snapshot(source).data.decode()
    raw_start = re.search(r'(?m)^rule ', raw)
    encoded_start = re.search(r'(?m)^rule ', candidate)
    sdk.require(raw_start is not None and encoded_start is not None, 'missing original rule boundary')
    # Preserve the original builtins/functions/equations verbatim. The parsed
    # rules are valid spthy syntax; only the diagnostic prelude is replaced.
    candidate_input = raw[:raw_start.start()] + candidate[encoded_start.start():]
    path = stage / 'phase-state-235.spthy'
    with path.open('x') as stream:
        stream.write(candidate_input)
    parsed = model.uncomment(parse('phase-encoded-235', path))
    sdk.require(verify(original, parsed, model) == transitions, 'parsed correspondence differs')
    sdk.require(len(model.queries(parsed)) == 10, 'query count differs')
    sdk.write_json(stage / 'PHASE_STATE_PREPARED_235.json', {
        'completed': True, 'base_sha256': sdk.snapshot(source).sha256,
        'candidate_sha256': sdk.snapshot(path).sha256,
        'checker_sha256': sdk.snapshot(Path(__file__)).sha256,
        'transitions': transitions, 'exact_rule_erasure_and_parsed_roundtrip': True,
        'all_ten_complete_queries_unchanged': True,
        'trace_projection': 'Erase private owner fields and the two Setup owner-fresh premises. Each encoded transition is exactly its original rule under the checked inverse; all actions and non-phase facts are unchanged.',
        'trace_lifting': 'For each finite original trace, assign two unused fresh private identifiers to the two Setup phase occurrences. Propagate each along its linear one-input/one-output phase lineage. The checker excludes phase joins, forks, principal changes and any identifier occurrence outside PhaseState/Setup Fr. Every original substitution therefore extends with that lineage identifier; no new equation or guard can restrict it. Additional fresh generation steps have no original observations. This covers arbitrary finite trace lengths, not a fixed round bound.',
        'knowledge_and_query_scope': 'No private identifier enters Out, In, actions, cryptographic expressions, restrictions or unchanged queries. Original message knowledge and action ordering/equality are preserved. SendState and SendPermit are unchanged.',
        'security_proof_produced': False, 'tool_injectivity_observed': False,
        'negative_controls_passed': False, 'release_claim_eligible': False,
    })
    print('Parsed phase-state encoding roundtrips all rules and ten queries; trace correspondence conditions checked.')


if __name__ == '__main__':
    main()
