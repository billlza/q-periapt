"""Counterexamples for the phase encoding checker and upstream static criteria."""
from pathlib import Path
from dataclasses import replace
import hashlib
import importlib.util
import json
import re
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    sdk.require(spec is not None and spec.loader is not None, 'checker module missing')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

c = load('phase_codec_control', s / 'phase_state_codec_235.py')
model = load('phase_model_control', s / 'verify-counter-model-89.py')
original = model.uncomment((s / 'phase-original-235-parse.stdout').read_text())
candidate = model.uncomment((s / 'phase-encoded-235-parse.stdout').read_text())
rule_set = {r.name: r for _, _, r in c.rules(candidate)}
sdk.require(len(c.verify(original, candidate, model)) == 11, 'positive correspondence failed')
sdk.require(c.term('<a,b,c>') == c.term('<a,<b,c>>'), 'right-associated pair normalization differs')
sdk.require(c.term('<a,<b,c>,d>') != c.term('<a,b,c,d>'), 'nested payload boundaries collapsed')

variants = {}
def mutated_rule(label, name, change):
    updated = dict(rule_set)
    updated[name] = change(updated[name])
    variants[label] = c.replace_rules(candidate, updated)

def map_phase(facts, change):
    return tuple(change(f) if f.name == c.STATE else f for f in facts)

def argument(f, index, value):
    args = list(f.args)
    args[index] = value
    return replace(f, args=tuple(args))

mutated_rule('new_owner_on_transition', 'Key_Reservation_1', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 0, c.Term('other_owner')))))
mutated_rule('missing_fresh_owner', 'Setup', lambda r: replace(r, premises=r.premises[:-1]))
mutated_rule('shared_setup_owner', 'Setup', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 0, c.Term(c.OWNERS[0])))))
mutated_rule('owner_exposed_on_network', 'Offer_Commit_3', lambda r: replace(r,
    conclusions=(*r.conclusions, c.Fact('Out', (c.Term(c.OWNER),)))))
mutated_rule('owner_observation_added', 'Offer_Commit_3', lambda r: replace(r,
    actions=(*r.actions, c.Fact('OwnerExposed', (c.Term(c.OWNER),)))))
mutated_rule('phase_fork', 'Key_Reservation_1', lambda r: replace(r,
    conclusions=(*r.conclusions, next(f for f in r.conclusions if f.name == c.STATE))))
mutated_rule('phase_join', 'Key_Reservation_1', lambda r: replace(r,
    premises=(*r.premises, next(f for f in r.premises if f.name == c.STATE))))
mutated_rule('principal_changed', 'Offer_Signing_2', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 2, c.Term('different_role')))))
mutated_rule('epoch_reset', 'Receipt_Accept_0', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 3, c.Term("'zero'")))))
mutated_rule('phase_relabelled', 'Key_Reservation_1', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 4, c.Term("'Offer2'")))))
mutated_rule('payload_truncated', 'Offer_Commit_3', lambda r: replace(r,
    conclusions=map_phase(r.conclusions, lambda f: argument(f, 5, c.Term('short_payload')))))
mutated_rule('send_state_priority_removed', 'Application_Message', lambda r: replace(r,
    premises=tuple(replace(f, annotations=tuple(a for a in f.annotations if a != '+')) if f.name == 'SendState' else f for f in r.premises)))
mutated_rule('stored_capture_changed', 'Snapshot', lambda r: replace(r,
    actions=tuple(replace(f, name='DifferentCapturedPhase') if f.name == 'CapturedPhase' else f for f in r.actions)))
variants['extra_restriction'] = candidate.replace('\nlemma ', '\nrestriction NoTrace:\n "All s #i. Setup(s)@i ==> F"\n\nlemma ', 1)
equation = 'decap(x, kemct(kempk(x), y)) = y'
sdk.require(candidate.count(equation) == 1, 'equation control missing')
variants['equation_changed'] = candidate.replace(equation, 'decap(x, kemct(kempk(x), y)) = x', 1)
queries = model.queries(candidate)
q = queries['multi_epoch_fresh_reservations_recover_symbolic_message_secrecy']
variants['main_query_weakened'] = candidate.replace(q, q.split('"', 1)[0] + '"T"', 1)
variants['original_rule_removed'] = candidate.replace(rule_set['Cut'].text(), '') if rule_set['Cut'].text() in candidate else None
if variants['original_rule_removed'] is None:
    start, end, _ = next(row for row in c.rules(candidate) if row[2].name == 'Cut')
    variants['original_rule_removed'] = candidate[:start] + candidate[end:]

rejected = {}
for label, value in variants.items():
    sdk.require(value != candidate, 'ineffective mutation: ' + label)
    try:
        c.verify(original, value, model)
    except ValueError as exc:
        rejected[label] = str(exc)
    else:
        raise ValueError('checker admitted mutation: ' + label)

upstream = json.loads((s / 'upstream-injective-facts-metadata-229.json').read_text())
data = (s / 'upstream-injective-facts-229.hs').read_bytes()
sdk.require(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == upstream['sha'], 'upstream source identity differs')
static = {}
copied = False
for name, r in rule_set.items():
    inputs = [f for f in r.premises if f.name == c.STATE]
    outputs = [f for f in r.conclusions if f.name == c.STATE]
    sdk.require(all(not f.persistent for f in inputs + outputs), 'phase is not linear')
    copied |= bool(inputs and outputs)
    sdk.require(len({f.args[0] for f in outputs}) == len(outputs), 'duplicate output first term')
    for f in outputs:
        fresh = c.Fact('Fr', (f.args[0],)) in r.premises
        same = [p for p in inputs if p.args[0] == f.args[0]]
        sdk.require(fresh or len(same) == 1, 'upstream fresh/copied condition fails')
        static.setdefault(name, []).append('fresh' if fresh else 'copied')
sdk.require(copied and len(static) == 12, 'upstream candidate condition fails')
sdk.write_json(s / 'PHASE_STATE_CHECKER_VERIFIED_236.json', {
    'completed': True,
    'candidate_sha256': sdk.snapshot(s / 'phase-state-235.spthy').sha256,
    'checker_sha256': sdk.snapshot(s / 'phase_state_codec_235.py').sha256,
    'parsed_original_sha256': sdk.snapshot(s / 'phase-original-235-parse.stdout').sha256,
    'parsed_candidate_sha256': sdk.snapshot(s / 'phase-encoded-235-parse.stdout').sha256,
    'ten_queries_and_every_original_rule_field_preserved': True,
    'negative_controls_rejected': rejected,
    'upstream_injectivity_static_conditions': static,
    'upstream_source': upstream,
    'scope': 'Representation correspondence preconditions and inverse are checked, including fresh private lineages and exact observations. Static conditions match the pinned tool algorithm; actual tool recognition and security proof are not yet observed.',
    'retained_preparation_failures': {
        '232': 'String comparison treated equivalent tuple spellings as different; full rule AST comparison plus an exact outside-rule skeleton now preserves both structure and declarations.',
        '233': 'Typed parse-only prelude is not valid spthy input.',
        '234': 'Explicit output-module=spthy still emitted the typed parse-only prelude. 235 preserves the original input prelude verbatim and independently reparses/computes the full inverse.',
    },
    'tool_injectivity_observed': False, 'security_proof_produced': False,
    'release_claim_eligible': False,
})
print(f'All {len(rejected)} correspondence mutations rejected; twelve rule sites meet pinned injectivity preconditions.')
