"""Run bounded precomputation only, retaining diagnostics on every boundary."""
from pathlib import Path
import json
import os
import re
import subprocess
import time
from bounded_process import BoundedProcessError, capture_stdout
from continuity_recovery_proof import prover_environment
from formal_toolchain_contract import verify_installed
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
prepared = json.loads((s / 'PHASE_STATE_CHECKER_VERIFIED_236.json').read_text())
source = s / 'phase-state-235.spthy'
sdk.require(prepared['completed'] and len(prepared['negative_controls_rejected']) == 17, 'encoding controls missing')
sdk.require(sdk.snapshot(source).sha256 == prepared['candidate_sha256'], 'candidate changed')
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
env = prover_environment()
env['PATH'] = os.pathsep.join((str(Path(tools['tamarin']).parent), str(Path(tools['maude']).parent), env['PATH']))
verify_installed('tamarin', path_environment=env['PATH'])
output = s / 'phase-precompute-237.spthy'
sdk.require(not output.exists(), 'precomputation output already exists')
argv = [tools['tamarin'], '--with-maude=' + tools['maude'], str(source),
        '--precompute-only', '--derivcheck-timeout=60', '--quit-on-warning', '--output=' + str(output),
        '+RTS', '-N1', '-M6G', '-c100', '-s', '-RTS']
started = time.monotonic()
record = {'argv': argv, 'source_sha256': sdk.snapshot(source).sha256, 'maximum_seconds': 300,
          'scope': 'Precomputation only; no security query is searched or admitted.',
          'security_proof_produced': False, 'release_claim_eligible': False}
sdk.write_json(s / 'phase-precompute-237-STARTED.json', record)
with (s / 'phase-precompute-237.log').open('xb') as log:
    try:
        result = capture_stdout(argv, timeout_seconds=300, maximum_bytes=16 * 1024**2,
                                stderr=subprocess.STDOUT, environment=env, output_sink=log.write)
        record.update(returncode=result.returncode, boundary=None, cleanup_ambiguous=False)
    except BoundedProcessError as exc:
        record.update(returncode=None, boundary=exc.kind, reason=str(exc), cleanup_ambiguous=exc.cleanup_ambiguous)
record.update(elapsed_seconds=time.monotonic() - started, output_sha256=sdk.snapshot(output).sha256 if output.is_file() else None)
sdk.write_json(s / 'phase-precompute-237-TERMINAL.json', record)
print(json.dumps(record), flush=True)
