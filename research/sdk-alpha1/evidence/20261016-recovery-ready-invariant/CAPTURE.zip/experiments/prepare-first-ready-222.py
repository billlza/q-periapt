"""Pose an independent first-epoch state uniqueness obligation."""
from pathlib import Path
import importlib.util
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = root / 'research/continuity-recovery-symbolic/multi-epoch.spthy'
snapshot = sdk.snapshot(source)
sdk.require(snapshot.sha256 == '78aaca97033b6a5ff470991883d1e36ad881a95e16ef6bd9f7c146e51e83ea0b', 'canonical source changed')
before = snapshot.data.decode()
name = 'first_responder_ready_event_is_unique'
addition = '''lemma first_responder_ready_event_is_unique:
 "All s root_left parent_left root_right parent_right #left #right.
    ReadyState(s,'B',succ('zero'),root_left,parent_left)@left
  & ReadyState(s,'B',succ('zero'),root_right,parent_right)@right
  ==> #left = #right"

'''
offset = before.rindex('end')
after = before[:offset] + addition + before[offset:]
sdk.require(after.replace(addition, '', 1) == before, 'original theory changed')
path = stage / 'first-ready-222.spthy'
with path.open('x') as f:
    f.write(after)
spec = importlib.util.spec_from_file_location('ready_model_check', stage / 'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None, 'model checker missing')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
original = model.parsed('first-ready-original-222', source)
prepared = model.parsed('first-ready-prepared-222', path)
old_queries, queries = model.queries(original), model.queries(prepared)
sdk.require(len(old_queries) == 9 and len(queries) == 10, 'query count differs')
sdk.require({k: v for k, v in queries.items() if k != name} == old_queries, 'original complete query changed')
sdk.require(model.operational(original)[0] == model.operational(prepared)[0], 'operational model changed')
sdk.require(not any(re.search(r'\b(reuse|sources)\b', q.split(':', 1)[0]) for q in queries.values()), 'unproved reusable premise')
sdk.write_json(stage / 'FIRST_READY_PREPARED_222.json', {
    'completed': True, 'canonical_sha256': snapshot.sha256,
    'candidate_sha256': sdk.snapshot(path).sha256,
    'all_nine_original_queries_and_operations_unchanged': True,
    'new_assumptions_or_reusable_premises': False,
    'new_obligation': queries[name],
    'basis': 'Wire-witness callbacks 82/78 expand a B first-epoch Ready source while a confirmed first-epoch B event is already present. If independently proved, event uniqueness could identify this repeated source rather than unfold another transcript ancestry.',
    'limits': 'Only B at succ(zero); does not establish arbitrary-epoch uniqueness, secrecy, nonce safety or SDK correspondence.',
    'actual_Tamarin_parse_passed': True, 'proof_produced': False, 'release_claim_eligible': False,
})
print('Prepared first-responder Ready uniqueness query; original nine queries and protocol unchanged.')
