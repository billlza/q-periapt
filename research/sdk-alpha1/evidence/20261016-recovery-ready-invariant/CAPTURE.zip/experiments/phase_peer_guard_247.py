"""Check that carrying an already-established persistent peer fact is redundant."""
from dataclasses import replace
import importlib.util
import json
from pathlib import Path
import re
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
s = Path(__file__).resolve().parent
qualified = json.loads((s / 'PHASE_STATE_CHECKER_VERIFIED_236.json').read_text())
sdk.require(qualified['completed'], 'base encoding not qualified')
for filename, field in (
    ('phase_state_codec_235.py', 'checker_sha256'),
    ('phase-state-235.spthy', 'candidate_sha256'),
    ('phase-original-235-parse.stdout', 'parsed_original_sha256'),
    ('phase-encoded-235-parse.stdout', 'parsed_candidate_sha256'),
):
    sdk.require(sdk.snapshot(s / filename).sha256 == qualified[field], 'base encoding input changed: ' + filename)

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, s / filename)
    sdk.require(spec is not None and spec.loader is not None, 'checker missing')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

c = load('peer_guard_codec', 'phase_state_codec_235.py')
model = load('peer_guard_model', 'verify-counter-model-89.py')
PEER_POSITIONS = {
    'Response4': (0, 2, 1), 'Response5': (0, 2, 1), 'Response6': (0, 2, 1),
    'Receipt9': (0, 2, 1), 'Final7': (0, 1, 2), 'Final8': (0, 1, 2),
}

def peer(phase):
    sdk.require(phase.name in PEER_POSITIONS, 'phase has no carried peer relation')
    return c.Fact('Peers', tuple(phase.args[i] for i in PEER_POSITIONS[phase.name]), True)


def check_invariant(original):
    producers = {}
    for _, _, rule in c.rules(original):
        inputs = [f for f in rule.premises if f.name in PEER_POSITIONS]
        for output in rule.conclusions:
            if output.name not in PEER_POSITIONS:
                continue
            expected = peer(output)
            # Search annotations do not participate in fact matching. Keep
            # original annotations intact in the rule correspondence check.
            if any(replace(f, annotations=()) == expected for f in rule.premises):
                basis = 'persistent premise'
            else:
                matches = [f for f in inputs if peer(f) == expected]
                sdk.require(len(matches) == 1, 'peer invariant not established or carried: ' + rule.name)
                basis = 'carried from ' + matches[0].name
            producers.setdefault(output.name, []).append({'rule': rule.name, 'basis': basis, 'fact': expected.text()})
    sdk.require(set(producers) == set(PEER_POSITIONS)
                and all(len(items) == 1 for items in producers.values()), 'peer-bearing producer census differs')
    return producers


def add_guards(encoded):
    changed = {}
    guards = {}
    for _, _, rule in c.rules(encoded):
        phases = [c.decode_fact(f)[0] for f in rule.premises if f.name == c.STATE]
        candidates = [f for f in phases if f.name in PEER_POSITIONS]
        if candidates:
            sdk.require(len(candidates) == 1, 'multiple peer-bearing phase inputs')
            expected = peer(candidates[0])
            sdk.require(expected not in rule.premises, 'guard already present in this control')
            changed[rule.name] = replace(rule, premises=rule.premises + (expected,))
            guards[rule.name] = expected
        else:
            changed[rule.name] = rule
    sdk.require(len(guards) == 6, 'redundant guard census differs')
    return c.replace_rules(encoded, changed), guards


def verify(original, encoded, guarded):
    invariant = check_invariant(original)
    c.verify(original, encoded, model)
    expected_text, guards = add_guards(encoded)
    expected = {r.name: r for _, _, r in c.rules(expected_text)}
    actual = {r.name: r for _, _, r in c.rules(guarded)}
    sdk.require(actual == expected, 'rule differs from the six exact redundant guards')
    sdk.require(c.declarations_outside_rules(encoded, model) == c.declarations_outside_rules(guarded, model),
                'declarations or queries changed')
    sdk.require(model.queries(encoded) == model.queries(guarded), 'complete queries changed')
    return invariant, guards


def main():
    original = model.uncomment((s / 'phase-original-235-parse.stdout').read_text())
    encoded = model.uncomment((s / 'phase-encoded-235-parse.stdout').read_text())
    guarded, guards = add_guards(encoded)
    invariant, _ = verify(original, encoded, guarded)
    old_rules = {r.name: r for _, _, r in c.rules(original)}
    controls = {}

    def reject_original(label, name, change):
        changed = dict(old_rules)
        changed[name] = change(changed[name])
        try:
            check_invariant(c.replace_rules(original, changed))
        except ValueError as exc:
            controls[label] = str(exc)
        else:
            raise ValueError('invariant checker admitted ' + label)

    reject_original('original_reservation_guard_removed', 'Response_Reservation_4', lambda r: replace(r,
        premises=tuple(f for f in r.premises if f.name != 'Peers')))
    reject_original('original_guard_not_persistent', 'Final_Reservation_7', lambda r: replace(r,
        premises=tuple(replace(f, persistent=False) if f.name == 'Peers' else f for f in r.premises)))
    def change_peer(rule):
        result = []
        for f in rule.conclusions:
            if f.name == 'Response5':
                args = list(f.args)
                args[2] = args[1]
                f = replace(f, args=tuple(args))
            result.append(f)
        return replace(rule, conclusions=tuple(result))
    reject_original('carried_peer_replaced', 'Response_Compute_5', change_peer)

    actual = {r.name: r for _, _, r in c.rules(guarded)}
    variants = {}
    name = 'Response_Compute_5'
    changed = dict(actual)
    changed[name] = replace(changed[name], premises=changed[name].premises[:-1])
    variants['guard_omitted'] = c.replace_rules(guarded, changed)
    changed = dict(actual)
    added = changed[name].premises[-1]
    wrong = replace(added, args=(added.args[0], added.args[2], added.args[1]))
    changed[name] = replace(changed[name], premises=(*changed[name].premises[:-1], wrong))
    variants['guard_changed'] = c.replace_rules(guarded, changed)
    changed = dict(actual)
    changed[name] = replace(changed[name], premises=(c.Fact('ExtraAuthority', (c.Term('s'),), True), *changed[name].premises))
    variants['unproved_guard_added'] = c.replace_rules(guarded, changed)
    changed = dict(actual)
    changed[name] = replace(changed[name], premises=changed[name].premises[1:])
    variants['original_phase_input_removed'] = c.replace_rules(guarded, changed)
    for label, value in variants.items():
        try:
            verify(original, encoded, value)
        except ValueError as exc:
            controls[label] = str(exc)
        else:
            raise ValueError('guard checker admitted ' + label)

    raw = (s / 'phase-state-235.spthy').read_text()
    raw_boundary = re.search(r'(?m)^rule ', raw)
    boundary = re.search(r'(?m)^rule ', guarded)
    sdk.require(raw_boundary is not None and boundary is not None, 'prelude boundary missing')
    candidate = raw[:raw_boundary.start()] + guarded[boundary.start():]
    path = s / 'phase-peer-guards-248.spthy'
    with path.open('x') as f:
        f.write(candidate)
    parsed = model.uncomment(model.parsed('phase-peer-guard-248', path))
    verify(original, encoded, parsed)
    sdk.write_json(s / 'PHASE_PEER_GUARDS_VERIFIED_248.json', {
        'completed': True, 'base_sha256': sdk.snapshot(s / 'phase-state-235.spthy').sha256,
        'candidate_sha256': sdk.snapshot(path).sha256,
        'checker_sha256': sdk.snapshot(Path(__file__)).sha256,
        'original_phase_producer_invariant': invariant,
        'exact_redundant_guards': {name: f.text() for name, f in guards.items()},
        'negative_controls_rejected': controls,
        'ten_complete_queries_unchanged': True,
        'trace_argument': 'Induct over original executions. A Response4/Final7 state is created only with its matching persistent Peers premise; each later peer-bearing phase is copied from a phase with the same relation. No rule removes persistent facts. Thus every added guard already holds whenever its original consumer runs. Erasing the six guards gives exactly the checked phase encoding; every old execution remains enabled. This is an explicitly checked inductive redundancy argument, not a newly assumed authority condition.',
        'actual_parse_and_full_rule_comparison_passed': True,
        'retained_preparation_failure': '245 compared search annotations as part of semantic premise identity and rejected the existing no_precomp Peers premise. 247 normalizes only that semantic membership comparison; all original rule annotations remain covered by the exact AST comparison.',
        'security_proof_produced': False, 'release_claim_eligible': False,
    })
    print('Six carried peer guards verified by producer induction; seven mutations rejected; ten queries retained.')


if __name__ == '__main__':
    main()
