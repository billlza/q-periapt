from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
expected=json.loads((root/'READBACK.json').read_text())
for name,digest in expected['verified_reader_sources'].items():
 assert hashlib.sha256((root/'reader-source'/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(root/'reader-source/artifact'))
import continuity_android_local_credential as credential
import continuity_android_account as account
import continuity_enrollment as enrollment
for profile,row in expected['profiles'].items():
 path=root/'public'/profile
 assert credential.verify_execution((path/'execution.stdout').read_bytes(),path/'lifecycle')==row['lifecycle']
 assert account.verify_execution((path/'account.stdout').read_bytes(),path/'account')==row['account']
 assert enrollment.verify(path/'enrollment')==row['native_enrollment']
print(json.dumps({'profiles':sorted(expected['profiles']),'reader_sources':len(expected['verified_reader_sources']),'scope':'Public contract replay only; no binary execution or independent signature verification'}))
