"""Replay original public Android host-JNI lifecycle/account contract readers."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent
frozen=out/'reader-source'
sys.path.insert(0,str(frozen/'artifact'))
import continuity_android_jni as android
import continuity_android_local_credential as credential
import continuity_android_account as account
import continuity_enrollment as enrollment
head='893d15178af2915d02d667ee49b1c7b9aa2151c0'
sha=lambda b:hashlib.sha256(b).hexdigest()
records={}
for profile in sys.argv[1:]:
 assert profile in {'debug','release'}
 folder=out/('android-'+profile);report=json.loads((folder/'CONTINUITY_PACKAGE.json').read_text());expected=report['android_jni_consumer']['profiles'][profile]
 replay=folder/'public-readback';replay.mkdir()
 with zipfile.ZipFile(folder/'terminal.zip')as z:
  mapping={}
  for trust in ['fixed','recoverable']:
   for name in credential.PUBLIC:
    mapping[f'lifecycle/{trust}/{name}']=f'android-jni-{profile}-{trust}-{name}.public'
   for name,_ in android.CASES:
    for suffix in ['stdout','stderr']:
     mapping[f'lifecycle/{trust}/{name}.{suffix}']=f'android-jni-{profile}-{trust}-{name}.{suffix}'
   for name in account.PUBLIC:
    mapping[f'account/{trust}/{name}']=f'android-jni-{profile}-account-{trust}-{name}.public'
  for role in enrollment.ROLES:
   for name in enrollment.FILES:
    mapping[f'enrollment/{role}/{name}']=f'{profile}-enrollment-public/{role}/{name}'
  for dst,src in mapping.items():
   data=z.read(src);p=replay/dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  lifecycle=credential.verify_execution(z.read(f'android-jni-{profile}-execution.stdout'),replay/'lifecycle')
  accounts=account.verify_execution(z.read(f'android-jni-{profile}-account.stdout'),replay/'account')
  original=enrollment.verify(replay/'enrollment')
  assert lifecycle==expected['outcomes']and accounts==expected['account_outcomes']and original==report['execution'][profile]['enrollment']
  records[profile]={'lifecycle':lifecycle,'account':accounts,'native_enrollment':original,'input_files':len(mapping)}
loaded={}
for module in tuple(sys.modules.values()):
 name=getattr(module,'__file__',None)
 if name is None:continue
 path=Path(name)
 if path.parent!=frozen/'artifact'or path.suffix!='.py':continue
 relative=str(path.relative_to(frozen));committed=subprocess.check_output(['git','show',head+':'+relative])
 assert path.read_bytes()==committed,relative
 loaded[relative]=sha(committed)
result={'head':head,'profiles':records,'verified_reader_sources':loaded,'scope':'Original public readers rederive Android packaged Java/JNI lifecycle, same original request/message, local renewal and account outcomes plus native enrollment framing/commitments. Signatures remain native-verifier evidence; this reader does not implement independent signature verification. macOS arm64 host JNI, not ART/device rerun or full six-partition release admission.'}
(out/('ANDROID_PUBLIC_READBACK_'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'profiles':list(records),'reader_sources':len(loaded),'input_files':{k:v['input_files']for k,v in records.items()}}))
