from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
out=Path(__file__).resolve().parent;repo=out.parent.parent
head='893d15178af2915d02d667ee49b1c7b9aa2151c0';run=39187630264
sha=lambda data:hashlib.sha256(data).hexdigest()
metadata=json.loads(subprocess.check_output(['gh','api',f'repos/billlza/q-periapt/actions/runs/{run}'],timeout=60))
assert metadata['head_sha']==head and metadata['status']=='completed' and metadata['conclusion']=='success'
readback=json.loads((out/'ANDROID_PUBLIC_READBACK_debug-release.json').read_text())
assert readback['head']==head and set(readback['profiles'])=={'debug','release'} and len(readback['verified_reader_sources'])==43
entries={'READBACK.json':(json.dumps(readback,indent=2)+'\n').encode(),'RUN_TERMINAL.json':(json.dumps(metadata,indent=2)+'\n').encode()}
artifacts=[]
for profile in ['debug','release']:
 folder=out/('android-'+profile);report=json.loads((folder/'CONTINUITY_PACKAGE.json').read_text());artifact=json.loads((folder/'ARTIFACT.json').read_text())
 archive=folder/'terminal.zip';assert 'sha256:'+sha(archive.read_bytes())==artifact['digest']
 assert report['source_commit']==head and report['sources_unchanged'] and report['partition_completed'] and report['completed'] is False
 source=json.loads((folder/'SOURCE_READBACK.json').read_text());assert source['git_verified_sources']==1132 and source['head']==head
 for name in ['JOB.json','ARTIFACT.json','CONTINUITY_PACKAGE.json','sources-before.json','sources-after.json','SOURCE_READBACK.json']:
  entries[f'metadata/{profile}/{name}']=(folder/name).read_bytes()
 public=folder/'public-readback';files=[p for p in public.rglob('*') if p.is_file()];assert len(files)==430
 for p in files:entries[f'public/{profile}/'+p.relative_to(public).as_posix()]=p.read_bytes()
 with zipfile.ZipFile(archive) as z:
  entries[f'public/{profile}/execution.stdout']=z.read(f'android-jni-{profile}-execution.stdout')
  entries[f'public/{profile}/account.stdout']=z.read(f'android-jni-{profile}-account.stdout')
  candidate=report['archive'];data=z.read(candidate['file']);assert len(data)==candidate['bytes'] and sha(data)==candidate['sha256']
  if 'package/'+candidate['file'] in entries:assert entries['package/'+candidate['file']]==data
  else:entries['package/'+candidate['file']]=data
  jar=z.read('continuity-android-classes.jar');assert sha(jar)==report['android_jni_consumer']['jar_sha256']
  entries[f'package/{profile}/continuity-android-classes.jar']=jar
 artifacts.append({'profile':profile,'id':artifact['id'],'sha256':artifact['digest'],'bytes':archive.stat().st_size,'public_reader_inputs':430,'original_archive_retained_locally':True})
for name,expected in readback['verified_reader_sources'].items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
 assert sha(data)==expected and (out/'reader-source'/name).read_bytes()==data
 entries['reader-source/'+name]=data
for name in ['download.py','verify-sources.py','review-android.py','seal-public.py','DOWNLOADS_debug-release.json','EXPECTED_SOURCES.json','PREPARED.json','MISSING_EXPORTS_READBACK.json','download-both.stdout','download-both.stderr','source-readback-both.stdout','source-readback-both.stderr','public-readback-both.stdout','public-readback-both.stderr']:
 p=out/name
 if p.is_file():entries['local/'+name]=p.read_bytes()
replay='''from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
expected=json.loads((root/'READBACK.json').read_text())
for name,digest in expected['verified_reader_sources'].items():
 assert hashlib.sha256((root/'reader-source'/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(root/'reader-source/artifact'))
import continuity_android_local_credential as credential
import continuity_android_account as account
import continuity_enrollment as enrollment
for profile,row in expected['profiles'].items():
 path=root/'public'/profile
 assert credential.verify_execution((path/'execution.stdout').read_bytes(),path/'lifecycle')==row['lifecycle']
 assert account.verify_execution((path/'account.stdout').read_bytes(),path/'account')==row['account']
 assert enrollment.verify(path/'enrollment')==row['native_enrollment']
print(json.dumps({'profiles':sorted(expected['profiles']),'reader_sources':len(expected['verified_reader_sources']),'scope':'Public contract replay only; no binary execution or independent signature verification'}))
'''
entries['replay-public.py']=replay.encode()
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-hosted-installed-android-public';dest.mkdir()
a=dest/'CAPTURE.zip'
with zipfile.ZipFile(a,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
reopened=out/'sealed-public-replay';reopened.mkdir()
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for n,record in manifest.items():
  data=z.read(n);assert len(data)==record['bytes'] and sha(data)==record['sha256']
  p=reopened/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
with (out/'sealed-replay.stdout').open('xb') as stdout,(out/'sealed-replay.stderr').open('xb') as stderr:
 result=subprocess.run([sys.executable,str(reopened/'replay-public.py')],cwd=repo,stdout=stdout,stderr=stderr,timeout=60)
assert result.returncode==0
checks={'head':head,'run':run,'source_files_per_profile':1132,'original_artifacts':artifacts,'reader_sources':43,'public_inputs_per_profile':430,'standalone_public_replay_exit':result.returncode,'capture':{'bytes':a.stat().st_size,'members':len(entries),'sha256':sha(a.read_bytes())},'scope':'Separate focused debug/release Android JNI cohort. Actual host JVM/JNI packaged-consumer executions on macOS arm64, rederived fixed/recoverable lifecycle and account outcomes, and native enrollment public commitments. Not ART or physical-device rerun. No independent signature verification, new six-profile join, full lifecycle or release admission. Old2328 missing-export failures remain unchanged; the new cohort is not spliced into that join. Original70MB archives remain local; selected complete public reader inputs,43 frozen readers,candidate source crate and packaged JARs are retained here.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text('''# Focused installed Android JNI public readback

[Run 39187630264](https://github.com/billlza/q-periapt/actions/runs/39187630264)
completed both debug and release partitions at
`893d15178af2915d02d667ee49b1c7b9aa2151c0`. Both upstream archives were checked
against their GitHub digests. Before/after manifests matched all 1132 committed
source files per profile; candidate source archives and packaged JARs were checked.

The original public readers rederived fixed/recoverable lifecycle, original
request/message recovery, local credential renewal and account outcomes, plus
native enrollment commitments. Each profile supplied all 430 required public
inputs. All 43 loaded reader sources matched the frozen Git commit. A separate
replay from this capture passed for both profiles without executing native code.

This closes the focused public-export/readback gap. Earlier missing-export
failures from the2328 cohort remain preserved. These new partitions are not
spliced into its older six-profile join and do not turn partial producer flags
into a full release claim.

The CI execution is macOS arm64 host JVM/JNI, not a fresh ART/emulator or physical
Android-device acceptance. Existing accepted physical-device evidence stays a
separate cohort. Signature verification remains native producer evidence; the
public replay is not an independent cryptographic verifier. The capture contains
complete selected public inputs, frozen readers, source crate, packaged JARs and
metadata. Full70MB upstream archives remain local rather than being duplicated
in Git. No private runtime state or native executables are included.
''')
print(json.dumps(checks['capture']))
