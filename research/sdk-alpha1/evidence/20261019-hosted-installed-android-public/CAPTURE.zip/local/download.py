"""Fetch only terminal focused Android partitions, without executing artifacts."""
from pathlib import Path,PurePosixPath
import hashlib,json,stat,subprocess,sys,zipfile
out=Path(__file__).resolve().parent
head='893d15178af2915d02d667ee49b1c7b9aa2151c0';run=39187630264
jobs={'debug':117853298992,'release':117853299263}
def api(path):return subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+path],timeout=180 if path.endswith('/zip') else 60)
artifacts=json.loads(api(f'actions/runs/{run}/artifacts?per_page=100'))
rows=[]
for profile in sys.argv[1:]:
 assert profile in jobs
 job_id=jobs[profile];label='android-'+profile;job=json.loads(api(f'actions/jobs/{job_id}'))
 assert job['head_sha']==head and job['run_id']==run
 folder=out/label;folder.mkdir(exist_ok=True)
 (folder/'JOB.json').write_text(json.dumps(job,indent=2)+'\n')
 if job['status']!='completed':
  rows.append({'label':label,'status':job['status'],'downloaded':False});continue
 assert job['conclusion']=='success'
 a=next(a for a in artifacts['artifacts']if a['name']=='continuity-installed-'+label)
 assert not a['expired']and a['workflow_run']['head_sha']==head and a['size_in_bytes']<192*1024**2
 path=folder/'terminal.zip'
 if not path.exists():path.write_bytes(api(f'actions/artifacts/{a["id"]}/zip'))
 data=path.read_bytes();assert len(data)==a['size_in_bytes']and 'sha256:'+hashlib.sha256(data).hexdigest()==a['digest']
 (folder/'ARTIFACT.json').write_text(json.dumps(a,indent=2)+'\n')
 with zipfile.ZipFile(path)as z:
  items=z.infolist();assert len(items)==len({i.filename for i in items})<65000
  assert sum(i.file_size for i in items)<768*1024**2
  for i in items:
   p=PurePosixPath(i.filename)
   assert not p.is_absolute()and '..'not in p.parts and str(p)==i.filename and '\\'not in i.filename and not i.flag_bits&1 and not stat.S_ISLNK(i.external_attr>>16)
  assert z.testzip()is None
  for name in ['CONTINUITY_PACKAGE.json','sources-before.json','sources-after.json']:(folder/name).write_bytes(z.read(name))
  report=json.loads(z.read('CONTINUITY_PACKAGE.json'))
  assert report['source_commit']==head and report['completed']is False and report['kind']=='qperiapt.continuity_candidate_package_partition'
  assert report['partition_completed']is True and report['sources_unchanged']and 'failure'not in report
  assert report['build_profiles']==[profile]and report['requested_consumers']==['Rust','C','AndroidJNI']
  assert report['host_os']=='Darwin'and report['host_arch']=='arm64'and report['release_claim_eligible']is False and report['publication_performed']is False
  for key,execution in [('c_consumer','execution'),('android_jni_consumer','profiles')]:
   part=report[key];assert part['completed']is False and part['partition_completed']is True and part['build_profiles']==[profile]and set(part[execution])=={profile}and 'failure'not in part
  before=json.loads(z.read('sources-before.json'));assert before==json.loads(z.read('sources-after.json'))==report['source_inputs']
 row={'label':label,'job':job_id,'status':'success','artifact':a['id'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':len(items),'source_files':len(before['files']),'scope':'Download integrity and terminal producer flags only; original public contract replay remains separate.'}
 rows.append(row);print(json.dumps(row),flush=True)
(out/('DOWNLOADS_'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
