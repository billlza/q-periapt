from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

stage = Path(__file__).resolve().parent
repo = stage.parent.parent
out = repo / 'research/sdk-alpha1/evidence/20261013-codeql-analysis-budget'
out.mkdir(mode=0o700)
records = {}
for name in ('codeql-job-progress', 'codeql-job-range2'):
    receipt = json.loads((stage / name / 'STATE.json').read_text())
    body = (stage / name / 'tail.log').read_bytes()
    assert receipt['completed'] and receipt['sha256'] == hashlib.sha256(body).hexdigest()
    records[name] = (receipt, body.decode())
progress = records['codeql-job-progress'][1]
started = re.findall(r'Starting evaluation of (codeql/[^\s]+)\.ql\.', progress)
finished = re.findall(r'Evaluation done; writing results to (codeql/[^\s]+)\.bqrs\.', progress)
assert len(started) == len(set(started)) == 39
assert len(finished) == len(set(finished)) == 38
missing = sorted(set(started) - set(finished))
assert missing == ['codeql/rust-queries/queries/summary/SummaryStats']
selected = [line for line in progress.splitlines() if
            'Starting evaluation of codeql/' in line or
            'Evaluation done; writing results to codeql/' in line or
            "The action 'Analyze' has timed out" in line]
assert len(selected) == 78
assert sum('timed out after 180 minutes' in line for line in selected) == 1
evictions = [line for line in records['codeql-job-range2'][1].splitlines()
             if 'Pausing evaluation to evict' in line or 'Unpausing evaluation:' in line]
assert len(evictions) >= 10
job = json.loads(subprocess.check_output([
    'gh', 'api', 'repos/billlza/q-periapt/actions/jobs/114995350136'], text=True))
job = {key: job[key] for key in ('id', 'run_id', 'head_sha', 'html_url', 'status', 'conclusion', 'started_at', 'completed_at', 'name', 'steps')}
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
members = {
    'QUERY_PROGRESS.txt': ('\n'.join(selected) + '\n').encode(),
    'LATE_CACHE_EVICTION_EXCERPT.txt': ('\n'.join(evictions[-10:]) + '\n').encode(),
    'JOB.json': (json.dumps(job, indent=2) + '\n').encode(),
    'RANGE_RECEIPTS.json': (json.dumps({name: pair[0] for name, pair in records.items()}, indent=2) + '\n').encode(),
    'MEMORY_COMPARISON.json': (repo / 'target/codeql-memory-current/COMPARISON.json').read_bytes(),
    'THREAD_COMPARISON.json': (repo / 'target/codeql-resource-control-current/readback/READBACK.json').read_bytes(),
    'codeql.yml': (repo / '.github/workflows/codeql.yml').read_bytes(),
    'capture-codeql-budget.py': Path(__file__).read_bytes(),
}
with zipfile.ZipFile(out / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, body in sorted(members.items()):
        archive.writestr(name, body)
with zipfile.ZipFile(out / 'CAPTURE.zip') as archive:
    assert set(archive.namelist()) == set(members)
    for name, body in members.items():
        assert archive.read(name) == body
archive_bytes = (out / 'CAPTURE.zip').read_bytes()
record = {
    'schema_version': 1,
    'source_head': 'dc2561f081720bc9f8a8173ca156fafbd3f976ca',
    'analyzed_merge': job['head_sha'],
    'workflow_run': job['run_id'], 'rust_job': job['id'],
    'completed': False, 'queries_started': started, 'queries_completed': finished,
    'unfinished_queries': missing, 'analyze_timeout_minutes': 180,
    'observation': '38 of 39 query evaluations completed. Full SummaryStats remained unfinished at the Analyze deadline. The post-timeout diagnostic excerpt contains repeated cache eviction; it does not establish a runtime estimate or exact algorithmic cause.',
    'change': {'analyze_minutes': 300, 'rust_job_minutes': 360, 'other_language_minutes': 60,
               'query_set_changed': False, 'quality_gate_changed': False,
               'runner_changed': False, 'paid_service_added': False},
    'reason': 'The same bundle previously completed full statistics on smaller source. The retained one-versus-four-thread experiment favors four threads; both 900-second heap/native-memory arms still evicted cache and timed out. Keep those parameters and permit one longer bounded full-suite run. This is not proof of sufficiency.',
    'validation': {'actionlint': 'passed', 'git_diff_check': 'passed', 'hosted_retry': 'pending'},
    'sources': ['https://docs.github.com/en/actions/reference/limits',
                'https://github.com/billlza/q-periapt/actions/runs/38304182825/job/114995350136'],
    'limits': ['No quality-gated Rust SARIF upload followed the failed Analyze step.',
               'Only hash-verified HTTP ranges and selected public progress lines were retained here; the full 567203943-byte log was not downloaded.',
               'The older timing/resource comparisons use different source and are not a same-input performance guarantee.',
               'The larger timeout is an execution bound, not a relaxation of any pass condition.'],
    'capture': {'file': 'CAPTURE.zip', 'sha256': hashlib.sha256(archive_bytes).hexdigest(),
                'bytes': len(archive_bytes), 'members': len(members),
                'member_sha256': {name: hashlib.sha256(body).hexdigest() for name, body in members.items()}},
    'release_claim_eligible': False,
}
(out / 'CHECKS.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'output': str(out), 'capture_sha256': record['capture']['sha256'], 'members': len(members)}))
