from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import sys
import time

import continuity_multi_epoch_search as contract
from bounded_process import capture_output, BoundedProcessError
from continuity_recovery_proof import prover_environment
from evidence_io import read_regular_snapshot
from formal_toolchain_contract import verify_installed

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-two-round-witness'
OUT=BASE/'run-01'
TOOLS=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/tools')
TARGET='two_rounds_recover_with_exposed_ancestor_is_executable'
HIDDEN=('local_phase_event_is_unique_per_role_epoch_and_phase','no_strictly_ordered_duplicate_local_phase')

def sha(body):return hashlib.sha256(body).hexdigest()
def read(path,limit=4*1024**2):
    return read_regular_snapshot(path,maximum=limit,label='two-round witness input').data
def write(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')

def selected_input(data):
    original=contract.theory(data)
    text=data.decode()
    clean=contract.uncomment(text)
    headers=list(contract._HEADER.finditer(clean))
    edits=[]; projected=[]
    for i,header in enumerate(headers):
        query=original.by_name[header[1]]
        if query.reusable or query.name==TARGET:continue
        end=header.end()
        while end<len(clean):
            if clean[end]=='\\':end+=2;continue
            if clean[end]=='"':break
            end+=1
        assert end<len(clean)
        limit=headers[i+1].start() if i+1<len(headers) else clean.rfind('\nend')+1
        assert limit>end
        edits.append((end+1,limit,'\nby sorry\n\n'))
        projected.append(query.name)
    for start,end,replacement in reversed(edits):text=text[:start]+replacement+text[end:]
    pattern=r'(lemma\s+'+TARGET+r'\s*)\[([^\]]+)\]'
    match=re.search(pattern,text)
    assert match is not None and len(re.findall(pattern,text))==1
    attrs=[a.strip() for a in match[2].split(',')]
    expected=['hide_lemma=ready_parent_has_tagged_epoch_origin',*(f'hide_lemma={name}' for name in HIDDEN)]
    assert attrs==expected
    text=text[:match.start()]+match[1]+'[hide_lemma=ready_parent_has_tagged_epoch_origin]'+text[match.end():]
    updated=contract.theory(text.encode())
    assert original.prefix==updated.prefix and len(updated.queries)==40
    for before,after in zip(original.queries,updated.queries,strict=True):
        assert (before.name,before.mode,before.formula)==(after.name,after.mode,after.formula)
        if before.name!=TARGET:assert before.attributes==after.attributes
        else:assert after.attributes==('hide_lemma','=','ready_parent_has_tagged_epoch_origin')
    return text.encode(),projected,original.by_name[TARGET].attributes,updated.by_name[TARGET].attributes

def execute(data,label,search):
    source=OUT/(label+'.input.spthy')
    output=OUT/(label+'.proof.spthy')
    source.write_bytes(data)
    theory=contract.theory(data)
    argv=['tamarin-prover',str(source),'--derivcheck-timeout=60','--quit-on-warning','--output='+str(output)]
    if search:argv+=['--prove='+TARGET,'--heuristic=i','--bound=256']
    argv+=['+RTS','-N1','-M12G','-c30','-s','-RTS']
    row={'accepted_execution':False,'search':search,'argv':argv,'input_sha256':sha(data),
         'started_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':900,
         'maximum_stdout_bytes':16*1024**2,'maximum_stderr_bytes':16*1024**2}
    write(OUT/(label+'.started.json'),row)
    started=time.monotonic()
    print('START',label,row['started_utc'],flush=True)
    try:
        with (OUT/(label+'.stdout')).open('xb',buffering=0) as stdout,(OUT/(label+'.stderr')).open('xb',buffering=0) as stderr:
            result=capture_output(argv,timeout_seconds=900,maximum_stdout_bytes=16*1024**2,
                maximum_stderr_bytes=16*1024**2,environment=prover_environment(),
                stdout_sink=stdout.write,stderr_sink=stderr.write)
        row['returncode']=result.returncode
        assert result.returncode==0,'prover process failed'
        assert not re.search(rb'warning|invalid proof|wellformedness check failed',result.stderr,re.I)
        produced=read(output)
        assert b'invalid proof step' not in produced and read(source)==data
        assert contract.theory(produced)==theory,'operational/query contract changed'
        results=contract.inventory(result.stdout,source,output,theory)
        row.update(accepted_execution=True,results=results,output_sha256=sha(produced))
        return produced,results
    except BaseException as error:
        row.update(error_type=type(error).__name__,error=str(error))
        if isinstance(error,BoundedProcessError):row.update(kind=error.kind,cleanup_ambiguous=error.cleanup_ambiguous)
        raise
    finally:
        row.update(elapsed_seconds=time.monotonic()-started,finished_utc=datetime.now(timezone.utc).isoformat())
        for suffix in ['stdout','stderr']:
            path=OUT/(label+'.'+suffix)
            if path.exists():row[suffix+'_sha256']=sha(read(path,16*1024**2))
        write(OUT/(label+'.terminal.json'),row)
        print('END',label,row.get('returncode'),row.get('error_type'),round(row['elapsed_seconds'],3),flush=True)

def main():
    assert ROOT==Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    OUT.mkdir(mode=0o700,exist_ok=False)
    os.environ['PATH']=str(TOOLS)+os.pathsep+os.environ['PATH']
    identities={name:sha(read(TOOLS/name,128*1024**2)) for name in ['tamarin-prover','maude']}
    assert identities=={'tamarin-prover':'d6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f',
                        'maude':'266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf'}
    verify_installed('tamarin')
    member,original,original_contract=contract.load_frontier(ROOT,read)
    candidate,projected,before_attrs,after_attrs=selected_input(original)
    (OUT/'original.spthy').write_bytes(original)
    state={'completed':False,'selected_theorem_verified':False,'independent_replay_completed':False,
           'release_claim_eligible':False,'selected_theorem':TARGET,'source_member':member,
           'original_certificate_sha256':sha(original),'candidate_input_sha256':sha(candidate),
           'operational_model_unchanged':True,'all_40_query_formulas_and_modes_unchanged':True,
           'target_attributes_before':before_attrs,'target_attributes_after':after_attrs,
           'nonreusable_proofs_projected_for_exploration':projected,
           'reusable_proofs_retained':sum(q.reusable for q in original_contract.queries),
           'main_replayed_in_this_run':False,'retained_joint_main_certificate_unchanged':True,
           'reason':'Use the two later independently checked phase-uniqueness invariants in the original two-round witness search; preserve all rules, queries and disclosure conditions.',
           'resource_limits':{'process_seconds':900,'heap_gib':12,'workers':1,'search_depth':256,'derivation_seconds':60,'compaction_percent':30},
           'depth_rationale':'Exploration of a complete original two-round witness, rather than a 16-step continuation of a partly discharged universal proof. Wall/heap/worker limits unchanged.',
           'tool_sha256':identities,'driver_sha256':sha(read(Path(__file__))),
           'concurrent_workload':'Existing installed Rust/C qualification session remains active; no performance claim.'}
    write(OUT/'PLAN.json',state)
    try:
        candidate,results=execute(candidate,'01-search',True)
        state['search_results']=results
        state['search_found_witness']=results[TARGET]['status']=='verified'
        if not state['search_found_witness']:
            state['remaining']='Original witness still incomplete; no automatic retry.'
            return False
        replay,replayed=execute(candidate,'02-replay',False)
        assert results==replayed and replay==candidate
        assert all(replayed[q.name]['status']=='verified' for q in contract.theory(replay).queries if q.reusable)
        assert {name:sha(read(TOOLS/name,128*1024**2)) for name in identities}==identities
        assert contract.load_frontier(ROOT,read)[1]==original
        state.update(completed=True,selected_theorem_verified=True,independent_replay_completed=True,
                     final_certificate_sha256=sha(replay),final_results=replayed)
        return True
    except BaseException as error:
        state.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:
        state['finished_utc']=datetime.now(timezone.utc).isoformat()
        write(OUT/'RESULT.json',state)

if __name__=='__main__':raise SystemExit(0 if main() else 1)
