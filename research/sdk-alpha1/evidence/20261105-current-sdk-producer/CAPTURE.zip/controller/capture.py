import hashlib
import json
import pathlib
import subprocess
import zipfile

ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT/'source'
PRODUCER=SOURCE/'target/sdk-020'
REPO=ROOT.parents[1]
DEST=REPO/'research/sdk-alpha1/evidence/20261105-current-sdk-producer'
DEST.mkdir()

def sha(data):return hashlib.sha256(data).hexdigest()

report=json.loads((PRODUCER/'RUST_SDK_PACKAGE.json').read_text())
assert report['base_commit']=='5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert report['source_inputs']['rust_workspace_sha256']=='c064df108a07da40099f9c2fe8115577d54f421fea918a0fefb1810d76a42c4d'
files={}
for p in PRODUCER.iterdir():
    if p.is_file() and (p.suffix in ('.json','.stdout','.stderr') or p.name=='consumer-Cargo.lock'):
        files['producer/'+p.name]=p
for p in (PRODUCER/'crates').glob('*.crate'):
    files['producer/crates/'+p.name]=p
for name in ('REQUEST.json','RESULT.json','READBACK.json','CHECKOUT.json','checkout-0.stdout','checkout-0.stderr',
             'checkout-1.stdout','checkout-1.stderr','producer.stdout','producer.stderr','capture.py'):
    files['controller/'+name]=ROOT/name
source_names=set(report['source_inputs']['files'])
source_names.update(('artifact/python-env.sh','artifact/python_bootstrap.py','artifact/python-run.sh','Cargo.toml','Cargo.lock','rust-toolchain.toml'))
for name in source_names:
    data=(SOURCE/name).read_bytes()
    assert data==subprocess.check_output(['git','show',report['base_commit']+':'+name],cwd=SOURCE)
    files['source/'+name]=SOURCE/name
manifest={}
with zipfile.ZipFile(DEST/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in sorted(files.items()):
        data=p.read_bytes();manifest[name]={'bytes':len(data),'sha256':sha(data)};archive.writestr(name,data)
with zipfile.ZipFile(DEST/'CAPTURE.zip') as archive:
    assert set(archive.namelist())==set(manifest) and archive.testzip() is None
    for name,row in manifest.items():
        data=archive.read(name);assert len(data)==row['bytes'] and sha(data)==row['sha256']
(DEST/'FILES.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
for name in ('RUST_SDK_PACKAGE.json',):
    with (DEST/name).open('xb') as out:out.write((PRODUCER/name).read_bytes())
with (DEST/'READBACK.json').open('xb') as out:out.write((ROOT/'READBACK.json').read_bytes())
data=(DEST/'CAPTURE.zip').read_bytes()
summary={'bytes':len(data),'sha256':sha(data),'members':len(manifest),'source_commit':report['base_commit'],
         'sdk_report_sha256':sha((PRODUCER/'RUST_SDK_PACKAGE.json').read_bytes()),'scope':'Current-source local SDK producer, exact archives and external consumer; no public registry publication or overall release acceptance.'}
(DEST/'CAPTURE.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
