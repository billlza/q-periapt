from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'required-live', 'reserved-live'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-recovery-package-02'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for source, name in (('worker-live.js','worker.js'), ('controller.js','controller.js')): shutil.copyfile(stage / source, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Original account recovery</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
browser_session = 'qpc-recovery-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage / ('group-target/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker-live.js', stage / 'controller.js', stage / 'server.py']}
state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Installed browser complete account/session cleanup with closed local runtime and still-current required witness authority; two original native recipients, same engine on one macOS host', 'cases': []}
sequence = 0

def browser(args, name, timeout=80):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', browser_session, *args], timeout_seconds=timeout,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name, 240 if args['action']=='expiry-held' else 80).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="fanout_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("fanout_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            console = browser(['console', 'warning'], 'startup-console').decode()
            sdk.require(console == '### Result\nTotal messages: 0 (Errors: 0, Warnings: 0)\n\n', 'startup console error')
            state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case':case, 'calls':[], 'completed':False}; state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare',directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text()); cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json',inputs / (key + '.json'))
                args = {'case':key,'name':key+'-'+uuid.uuid4().hex[:8], 'id':uuid.uuid4().hex+uuid.uuid4().hex, 'profile':profile}
                success(dict(args,action='create'))
                grant_path = inputs / (key + '-grant.json')
                trace = output / (case + '-native-prepare'); trace.mkdir(mode=0o700)
                native('peer',['prepare-group',directory,output/'captures'/(key+'.bin'),grant_path,inputs,trace],case+'-group-prepare')
                grant = json.loads(grant_path.read_text())
                for slot in range(2):
                    peer = json.loads((inputs / (key + f'-peer-{slot}.json')).read_text())
                    sdk.require(peer['account'] == cfg['account'] and peer['root'] == cfg['root'] and peer['roster'] == grant['roster'] and peer['digest'] == grant['digest'], 'independent group roster mismatch')
                accepted = success(dict(args,action='accept')); prepared = success(dict(args,action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness',['enroll',directory,grant_path,output/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
                active = success(dict(args,action='activate')); sdk.require(active['journal'] == prepared['journal'], 'activation identity')
                row['journal'] = active['journal']
                sessions = []
                for slot in range(2):
                    established = success(dict(args,action='establish',slot=slot,requestId=list(os.urandom(32))))
                    sdk.require(established['journal'] == row['journal'], 'per-peer owner replaced original journal')
                    sessions.append(established['session'])
                    sdk.write_json(directory/'recipients'/str(slot)/'peer/session.json',established['session'])
                sdk.require(sessions[0] != sessions[1], 'different members share a session')
                args['sessions'] = sessions; row['sessions'] = sessions
                operation = success(dict(args,action='account-next'))['operation']; args['operation'] = operation; row['operation'] = operation
                original_slots = success(dict(args,action='session-slots'))['messages']; row['original_messages'] = original_slots
                before = len([r for r in peers.get(key,[]) if r['kind']==3])
                is_reserved = case == 'reserved-live'
                lost = invoke(dict(args,action='account-deliver',selected=0,
                    mode='normal' if is_reserved else 'drop-ack',
                    witnessMode='drop-commit' if is_reserved else 'normal',cut='0'))
                sdk.require(lost.get('code') == ('WitnessTransport' if is_reserved else 'PeerTransport') and lost.get('ownerClosed') is True, 'wrong original failure')
                phase = success(dict(args,action='cleanup-account-status'))
                sdk.require(phase['status']['phase'] == (1 if is_reserved else 2) and phase['status']['operation']==operation and not phase['runtimeCreated'], 'actual original phase not established')
                data_frames = [r for r in peers.get(key,[]) if r['kind']==3]
                sdk.require(len(data_frames)==before+(0 if is_reserved else 1), 'unexpected pre-expiry dispatch')
                effect = None
                if not is_reserved:
                    effects=list((directory/'recipients/0/peer/effects').iterdir())
                    sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(sessions[0])+bytes(original_slots[0])+b'all account devices','original effect')
                    effect=effects[0]; s=effect.stat(); row['effect_before']=[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]
                closed=invoke(dict(args,action='runtime-closed',selected=0))
                sdk.require(closed.get('code')=='Closed' and closed.get('ownerClosed') is True and closed['runtimeCreated'] is True,'closed runtime granted operational access')
                observed={'until':min(cfg['until'],cfg['policy_until'])}
                sdk.require(closed['observedAt']<observed['until'],'witness authority expired before qualification')
                row['authority']={'local_runtime_closed_at':closed['observedAt'],'witness_valid_until':observed['until']}
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==len(data_frames),'closed runtime dispatched data')
                def cleanup(action, **extra):
                    result=success(dict(args,action=action,**extra))
                    sdk.require(result['runtimeCreated'] is False and result['observedAt']<observed['until'],'cleanup constructed runtime or exceeded current witness authority')
                    return result
                negatives=[('wrongHistory','Conflict'),('wrongOperation','Scope')]
                if profile=='required': negatives += [('forceLocal','AnchorRequired'),('wrongWitness','Conflict')]
                witness_before=len(records.get(key,[]))
                for parameter,code in negatives:
                    refused=invoke(dict(args,action='cleanup-account-status',**{parameter:True}))
                    sdk.require(refused.get('code')==code and refused.get('ownerClosed') is True and refused['runtimeCreated'] is False,'incorrect historical admission refusal: '+parameter)
                sdk.require(len(records.get(key,[]))==witness_before,'invalid recovery admission contacted witness')
                refused=invoke(dict(args,action='cleanup-account-send'))
                sdk.require(refused.get('code')=='State' and refused.get('ownerClosed') is True,'cleanup granted ordinary operation access')
                def report(value,kind,member_index=None):
                    document=json.loads(value['document'])
                    sdk.require(document['schema']==1 and document['kind']==kind and document['report']==bytes(value['report']).hex(),'report envelope')
                    row.setdefault('reports',[]).append(document)
                    if kind=='account':
                        sdk.require(document['batch']==bytes(operation).hex() and value['operation']==operation and value['members']==2 and len(document['sessions'])==2,'incomplete account report')
                        members=document['sessions']
                    else:
                        sdk.require(member_index is not None and document['session']==bytes(sessions[member_index]).hex() and value['session']==sessions[member_index] and document['peer_account']==bytes(cfg['account']).hex(),'session report scope')
                        members=[document]
                    for offset,member in enumerate(members):
                        slot=offset if kind=='account' else member_index
                        device=member['device'] if kind=='account' else member['peer_device']
                        generation=member['generation'] if kind=='account' else member['peer_generation']
                        sdk.require(device==bytes([82+slot]*16).hex() and generation=='1' and member['session']==bytes(sessions[slot]).hex() and member['role']==1,'original report member identity')
                        sdk.require(set(member['progress'])=={'confirmed_epoch','sending_epoch','receiving_epoch','pending_epoch'} and member['progress']=={'confirmed_epoch':'0','sending_epoch':'0','receiving_epoch':'0','pending_epoch':None},'rekey metadata missing or rounded')
                        pending=member['reserved']
                        if kind=='account':
                            sdk.require(pending=={'message':bytes(original_slots[slot]).hex(),'plaintext_bytes':19,'associated_data_bytes':10},'reserved input identity or lengths lost')
                        else: sdk.require(pending==[],'committed work relabeled reserved')
                        sdk.require(len(member['epochs'])==1,'epoch omitted')
                        epoch=member['epochs'][0]
                        sdk.require(set(epoch)=={'epoch','acknowledged_before','sent','consumed_before','received','peer_sent','resolution','unconfirmed','deliveries','skipped'},'incomplete epoch report')
                        sdk.require(epoch['epoch']=='0' and epoch['sent']==('0' if kind=='account' else '1') and epoch['acknowledged_before']=='0','send outcome invented or numeric precision changed')
                        sdk.require(epoch['consumed_before']=='0' and epoch['received']=='0' and epoch['peer_sent'] is None and epoch['resolution']=={'phase':'unrequested','report':None} and epoch['deliveries']==[] and epoch['skipped']==[],'receive/accounting metadata differs')
                        if kind=='account': sdk.require(epoch['unconfirmed']==[],'reserved ciphertext reported committed')
                        else:
                            sdk.require(len(epoch['unconfirmed'])==1 and epoch['unconfirmed'][0]['message']==bytes(original_slots[slot]).hex(),'original unconfirmed message omitted')
                            digest=epoch['unconfirmed'][0]['ciphertext_digest']
                            sdk.require(len(digest)==64 and all(c in '0123456789abcdef' for c in digest),'ciphertext commitment encoding')
                    return document
                def persist(value):
                    folder=output/'accounting'/key; folder.mkdir(parents=True,exist_ok=True)
                    path=folder/(bytes(value['report']).hex()+'.json'); wire=value['document'].encode()
                    with path.open('xb') as stream:
                        stream.write(wire); stream.flush(); os.fsync(stream.fileno())
                    descriptor=os.open(folder,os.O_RDONLY)
                    try: os.fsync(descriptor)
                    finally: os.close(descriptor)
                    sdk.require(path.read_bytes()==wire,'host accounting readback')
                    s=path.stat(); receipt={'path':str(path.relative_to(output)),'sha256':sdk.snapshot(path).sha256,'identity':[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]}
                    row.setdefault('host_accounting',[]).append(receipt)
                    return receipt
                def fault(action,cut,**extra):
                    result=invoke(dict(args,action=action,witnessMode='drop-commit',cut=str(cut),**extra))
                    sdk.require(result.get('code')=='WitnessTransport' and result.get('ownerClosed') is True and result['runtimeCreated'] is False,'missing processed witness loss: '+action)
                    sdk.require(any(r['mode']=='drop-commit' and r['cut']==str(cut) and r['trigger'] and r['commit_applied_reply'] for r in records.get(key,[])),'fault preceded actual Applied reply')
                if is_reserved:
                    refused=invoke(dict(args,action='cleanup-session-begin',session=sessions[0]))
                    sdk.require(refused.get('code')=='Suspended','individual closure split reserved aggregate')
                    refused=invoke(dict(args,action='cleanup-account-members'))
                    sdk.require(refused.get('code')=='Suspended','reserved input presented as committed members')
                    fault('cleanup-account-begin',1)
                    current=cleanup('cleanup-account-begin'); report(current,'account')
                    sdk.require(current['status']['phase']==3 and current['status']['report']==current['report'],'whole report not frozen')
                    receipt=persist(current)
                    again=cleanup('cleanup-account-begin')
                    sdk.require(again['document']==current['document'] and again['report']==current['report'],'whole frozen report changed after reopen')
                    fault('cleanup-account-ack',2,report=current['report'])
                    status=cleanup('cleanup-account-status')['status']
                    sdk.require(status['phase']==4 and status['report']==current['report'],'whole acknowledgement not recovered')
                    rows=cleanup('cleanup-account-members')['members']
                    sdk.require([r['phase'] for r in rows]==[6,6],'not every original session abandoned')
                else:
                    rows=cleanup('cleanup-account-members')['members']
                    sdk.require([r['message'] for r in rows]==original_slots and [r['phase'] for r in rows]==[1,1],'original aggregate outcomes changed')
                    refused=invoke(dict(args,action='cleanup-account-begin'))
                    sdk.require(refused.get('code')=='Conflict','committed aggregate abandoned as reserved')
                    refused=invoke(dict(args,action='cleanup-account-retire'))
                    sdk.require(refused.get('code')=='Suspended','unaccounted member retired')
                    for slot,session_id in enumerate(sessions):
                        if profile=='required': fault('cleanup-session-begin',1+2*slot,session=session_id)
                        current=cleanup('cleanup-session-begin',session=session_id); report(current,'session',slot)
                        sdk.require(current['status']['phase']==1 and current['status']['report']==current['report'],'session report not pending')
                        receipt=persist(current)
                        again=cleanup('cleanup-session-begin',session=session_id)
                        sdk.require(again['document']==current['document'] and again['report']==current['report'],'session frozen report changed after reopen')
                        wrong=list(current['report']); wrong[0]^=1
                        refused=invoke(dict(args,action='cleanup-session-ack',session=session_id,report=wrong))
                        sdk.require(refused.get('code')=='Conflict','different loss report acknowledged')
                        if profile=='required': fault('cleanup-session-ack',2+2*slot,session=session_id,report=current['report'])
                        else: cleanup('cleanup-session-ack',session=session_id,report=current['report'])
                        closed=cleanup('cleanup-session-status',session=session_id)['status']
                        sdk.require(closed['phase']==2 and closed['report']==current['report'],'original session acknowledgement lost')
                    rows=cleanup('cleanup-account-members')['members']
                    sdk.require([r['message'] for r in rows]==original_slots and [r['phase'] for r in rows]==[4,4],'unknown outcomes became consumption')
                for receipt in row['host_accounting']:
                    path=output/receipt['path']; s=path.stat()
                    sdk.require(sdk.snapshot(path).sha256==receipt['sha256'] and [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]==receipt['identity'],'host report changed during retry')
                if profile=='required': fault('cleanup-account-retire',10)
                else: sdk.require(cleanup('cleanup-account-retire')['status']['phase']==5,'metadata retirement')
                terminal=invoke(dict(args,action='cleanup-account-status'))
                if terminal.get('code')=='Retired': sdk.require(terminal.get('ownerClosed') is True,'retired open retained owner')
                else: sdk.require(terminal.get('value',{}).get('status',{}).get('phase')==5,'retirement not authenticated')
                sdk.require(terminal['runtimeCreated'] is False,'retired query reconstructed runtime')
                row['retirement']=terminal
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==len(data_frames),'cleanup dispatched application traffic')
                if effect is not None:
                    s=effect.stat(); row['effect_after']=[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]
                    sdk.require(row['effect_before']==row['effect_after'],'original business effect changed')
                sdk.require(not failures,'native fixture errors: '+json.dumps(failures))
                row['completed']=True
                print(json.dumps({'case':case,'completed':True,'closed_local_runtime':True,'current_witness_authority':True,'same_original_operation':True}),flush=True)
            state['witness_records'] = records; state['peer_records'] = peers
        except BaseException as error:
            state['protocol_failure']=repr(error)
            raise
        finally:
            state['witness_records']=records; state['peer_records']=peers; state['fixture_failures']=failures
            browser(['close'],'close')
    for name,digest in producer.items(): sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'installed web drift')
    state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    state['failure'] = repr(error); raise
finally:
    sdk.write_json(output/'RESULT.json',state)
print(json.dumps({'completed':True,'cases':cases,'scope':state['scope']}))
