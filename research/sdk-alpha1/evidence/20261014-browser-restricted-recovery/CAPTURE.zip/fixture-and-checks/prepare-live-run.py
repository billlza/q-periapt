from pathlib import Path
import ast
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
source=(stage/'worker.js').read_text()
marker="            if(data.action==='expiry-held') {"
sdk.require(source.count(marker)==1,'held action marker')
source=source.replace(marker,"            if(data.action==='runtime-closed') runtime.close();\n"+marker)
marker="if(data.action!=='account-deliver' && data.action!=='expiry-held')"
sdk.require(source.count(marker)==1,'action validation marker')
source=source.replace(marker,"if(data.action!=='account-deliver' && data.action!=='expiry-held' && data.action!=='runtime-closed')")
(stage/'worker-live.js').write_text(source)
driver=(stage/'run.py').read_text()
driver=driver.replace("{'local', 'required', 'reserved'}","{'required-live', 'reserved-live'}")
driver=driver.replace('browser-recovery-package-01','browser-recovery-package-02')
driver=driver.replace("for name in ('worker.js', 'controller.js'): shutil.copyfile(stage / name, web / 'creation' / name)","for source, name in (('worker-live.js','worker.js'), ('controller.js','controller.js')): shutil.copyfile(stage / source, web / 'creation' / name)")
driver=driver.replace("stage / 'worker.js', stage / 'controller.js'","stage / 'worker-live.js', stage / 'controller.js'")
driver=driver.replace("['prepare-expiring-all',directory]","['prepare',directory]")
driver=driver.replace("case == 'reserved'","case == 'reserved-live'")
start=driver.index("                print(json.dumps({'case':case,'phase':'holding original live owner")
end=driver.index("                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])",start)
replacement='''                closed=invoke(dict(args,action='runtime-closed',selected=0))
                sdk.require(closed.get('code')=='Closed' and closed.get('ownerClosed') is True and closed['runtimeCreated'] is True,'closed runtime granted operational access')
                observed={'until':min(cfg['until'],cfg['policy_until'])}
                sdk.require(closed['observedAt']<observed['until'],'witness authority expired before qualification')
                row['authority']={'local_runtime_closed_at':closed['observedAt'],'witness_valid_until':observed['until']}
'''
driver=driver[:start]+replacement+driver[end:]
driver=driver.replace("'expired owner dispatched data'","'closed runtime dispatched data'")
driver=driver.replace("result['observedAt']>observed['until'],'cleanup constructed current runtime or preceded expiry'","result['observedAt']<observed['until'],'cleanup constructed runtime or exceeded current witness authority'")
driver=driver.replace("'expired_credential_and_policy':True","'closed_local_runtime':True,'current_witness_authority':True")
driver=driver.replace('Installed browser original account/session cleanup after actual policy and credential expiry; two native recipients, one original roster/witness, same implementation on one macOS host',
    'Installed browser complete account/session cleanup with closed local runtime and still-current required witness authority; two original native recipients, same engine on one macOS host')
ast.parse(driver,filename='run-live.py')
(stage/'run-live.py').write_text(driver)
print('Fresh required-live/reserved-live fixtures preserve closed-local-runtime and current-witness authority distinction; old accepted/failed producers unchanged')
