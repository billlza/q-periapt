from pathlib import Path
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
prior=root/'target/continuity-browser-fanout/group-fixture'
work=stage/'group-fixture'; work.mkdir(); (work/'src/bin').mkdir(parents=True)
for name in ('Cargo.toml','Cargo.lock'):
    sdk.copy(prior/name,work/name)
for source in (prior/'src/bin').glob('*.rs'):
    sdk.copy(source,work/'src/bin'/source.name)
path=work/'src/bin/qpc-fanout-seed.rs'; source=path.read_text()
sdk.require(source.count('"prepare" | "prepare-expiring-policy"')==1,'seed command marker')
source=source.replace('"prepare" | "prepare-expiring-policy"','"prepare" | "prepare-expiring-policy" | "prepare-expiring-all"')
source=source.replace('if mode == "prepare-expiring-policy" {\n                    90','if mode != "prepare" {\n                    180')
marker='            let mut description = vec![73; 16];'
sdk.require(source.count(marker)==1,'device description marker')
source=source.replace(marker,'            let credential_until = if mode == "prepare-expiring-all" { policy_until } else { at + 3600 };\n'+marker)
sdk.require(source.count('&(at + 3600).to_be_bytes()')==1 and source.count('"until":at+3600')==1,'credential validity markers')
source=source.replace('&(at + 3600).to_be_bytes()','&credential_until.to_be_bytes()').replace('"until":at+3600','"until":credential_until')
path.write_text(source)
script=(root/'target/continuity-browser-fanout/build-group-fixture.py').read_text().replace("'target/continuity-browser-fanout'","'target/continuity-browser-recovery'")
(stage/'build-group.py').write_text(script)
print('Fresh fixture has explicit pre-signed180s policy-only or policy+credential expiry; existing cohorts untouched')
