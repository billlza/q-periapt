from pathlib import Path
import json
import ast
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
failed=json.loads((stage/'run03/RESULT.json').read_text())
last=failed['cases'][-1]['calls'][-1]['result']
sdk.require(not failed['completed'] and 'value' in last and not failed['fixture_failures'],'unexpected failure')
sdk.write_json(stage/'FAULT_CLASSIFICATION_FAILURE.json',{
    'run':'run03','completed':False,'SDK_operation_succeeded':True,'fault_injected':False,
    'cause':'Fixture copied the credential Commit(5)/Applied(8) predicate. Generic cleanup uses Advance(2)/Advanced(2), so the requested reply loss never triggered.',
    'evidence':'run03 witness record174 has request_tag2/reply_tag2, triggerfalse; step020 returned the real frozen session report.',
    'repair':'Separate fixture emits advance_applied_reply only after successful authenticated native Advance/Advanced; server and driver use explicit drop-advance mode. Old producer sources and binaries remain unchanged.'})
work=stage/'group-fixture-02'; work.mkdir(); (work/'src/bin').mkdir(parents=True)
for name in ('Cargo.toml','Cargo.lock'): sdk.copy(stage/'group-fixture'/name,work/name)
for source in (stage/'group-fixture/src/bin').glob('*.rs'): sdk.copy(source,work/'src/bin'/source.name)
path=work/'src/bin/qpc-fanout-witness.rs'; source=path.read_text()
marker='"commit_applied_reply":request[204]==5 && reply[204]==8'
sdk.require(source.count(marker)==1,'witness trace predicate')
source=source.replace(marker,'"credential_applied_reply":request[204]==5 && reply[204]==8,\n                    "advance_applied_reply":request[204]==2 && reply[204]==2')
path.write_text(source)
script=(stage/'build-group.py').read_text().replace("stage / 'group-fixture'","stage / 'group-fixture-02'").replace("stage / 'group-target'","stage / 'group-target-02'")
script=script.replace('group-format-01','group-format-02').replace('GROUP_INPUTS_01','GROUP_INPUTS_02').replace('group-build-01','group-build-02')
(stage/'build-group-02.py').write_text(script)
server=(stage/'server.py').read_text().replace('commit_applied_reply','advance_applied_reply').replace('drop-commit','drop-advance').replace('hold-commit','hold-advance')
(stage/'server_advance.py').write_text(server)
driver=(stage/'run-live.py').read_text().replace('from server import serving','from server_advance import serving')
driver=driver.replace("stage / 'server.py'","stage / 'server_advance.py'").replace('group-target/debug/qpc-fanout-','group-target-02/debug/qpc-fanout-')
driver=driver.replace('commit_applied_reply','advance_applied_reply').replace('drop-commit','drop-advance')
ast.parse(driver,filename='run-live-02.py'); ast.parse(server,filename='server_advance.py')
(stage/'run-live-02.py').write_text(driver)
print('Preserved failed missing-fault run; prepared separate native Advance/Advanced fixture and fresh driver')
