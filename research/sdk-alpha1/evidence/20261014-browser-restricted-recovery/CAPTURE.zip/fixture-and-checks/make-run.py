from pathlib import Path
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
source=(root/'target/continuity-browser-fanout/run-03.py').read_text()
source=source.replace("'target/continuity-browser-fanout'","'target/continuity-browser-recovery'")
source=source.replace("{'local', 'required', 'effect', 'worker-cut'}","{'local', 'required', 'reserved'}")
source=source.replace('browser-fanout-package-02','browser-recovery-package-01').replace('qpc-fanout-','qpc-recovery-')
# The freshly built fixture retains its original neutral binary names.
source=source.replace("('group-target/debug/qpc-recovery-' + name)","('group-target/debug/qpc-fanout-' + name)")
source=source.replace('def browser(args, name):','def browser(args, name, timeout=80):').replace('timeout_seconds=80,','timeout_seconds=timeout,')
old="browser(['run-code', '--filename', str(script)], name).decode()"
sdk.require(source.count(old)==1,'browser invocation marker')
source=source.replace(old,"browser(['run-code', '--filename', str(script)], name, 240 if args['action']=='expiry-held' else 80).decode()")
source=source.replace("native('seed', ['prepare',directory]", "native('seed', ['prepare-expiring-all',directory]")
source=source.replace('Complete account delivery','Original account recovery')
source=source.replace('Installed browser complete-account fanout to two native receivers, one independently signed three-device roster and one witness authority; same shared implementation on one host',
    'Installed browser original account/session cleanup after actual policy and credential expiry; two native recipients, one original roster/witness, same implementation on one macOS host')
start=source.index('def assert_status('); end=source.index('\ntry:',start)
source=source[:start]+source[end+1:]
start=source.index('                before = len(peers.get(key,[]))')
end=source.index("            state['witness_records'] = records; state['peer_records'] = peers",start)
source=source[:start]+(stage/'run-body.py').read_text()+source[end:]
marker="        finally:\n            browser(['close'],'close')"
sdk.require(source.count(marker)==1,'terminal capture marker')
source=source.replace(marker,"        except BaseException as error:\n            state['protocol_failure']=repr(error)\n            raise\n        finally:\n            state['witness_records']=records; state['peer_records']=peers; state['fixture_failures']=failures\n            browser(['close'],'close')")
(stage/'run.py').write_text(source)
print('Fresh recovery driver prepared: unchanged SDK deadlines, original cached owner crosses actual expiry, durable host accounting before ACK')
