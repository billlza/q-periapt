from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS','') + ' -D warnings'
env['CC_wasm32_unknown_unknown'] = '/opt/homebrew/opt/llvm/bin/clang'
toolchain = Path(env['RUSTC']).parent
mode = sys.argv[1]
if mode == 'prepare':
    files = sorted(set(subprocess.run(['git','diff','--name-only'], cwd=root, check=True, capture_output=True, text=True).stdout.splitlines())
        | set(subprocess.run(['git','ls-files','--others','--exclude-standard'], cwd=root, check=True, capture_output=True, text=True).stdout.splitlines()))
    sdk.require(files and all(name.endswith('.rs') for name in files), 'unexpected source scope')
    sdk.command([str(toolchain/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(root/name) for name in files]],stage/'format-owners-01',root,environment=env)
    sdk.write_json(stage/'OWNER_INPUTS_01.json',{name:sdk.snapshot(root/name).sha256 for name in files})
else:
    sdk.require(mode in ('native','wasm'), 'check selection')
    inputs = json.loads((stage/'OWNER_INPUTS_01.json').read_text())
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256 == digest,'precheck input drift')
    command = [str(toolchain/'cargo'),'clippy','--locked','--offline']
    if mode == 'native':
        command += ['--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets']
    else:
        command += ['-p','q-periapt-sdk-wasm','--features','browser-continuity','--lib','--target','wasm32-unknown-unknown']
    command += ['--target-dir',str(root/('target/continuity-browser-fanout/'+mode+'-target')),'-j','2','--','-D','warnings']
    sdk.command(command,stage/('owners-'+mode+'-01'),root,environment=env)
    for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256 == digest,'postcheck input drift')
    print(mode + ' recovery owners strict Clippy passed')
