                lost=invoke(dict(args,action='account-deliver',selected=0,mode='drop-ack'))
                sdk.require(lost.get('code')=='PeerTransport' and lost.get('ownerClosed') is True,'original consumption reply loss')
                frames=[r for r in peers.get(key,[]) if r['kind']==3]
                sdk.require(len(frames)==1 and frames[0]['slot']==0,'unexpected original dispatch')
                target_session=sessions[0]
                until=max(cfg['until'],cfg['policy_until'])
                if case=='expired-applied':
                    frozen=invoke(dict(args,action='cleanup-session-begin',session=target_session,witnessMode='drop-advance',cut='1'))
                    sdk.require(frozen.get('code')=='WitnessTransport' and frozen.get('ownerClosed') is True and frozen['observedAt']<until,'freeze was not attempted before actual expiry')
                    sdk.require(any(r['mode']=='drop-advance' and r['cut']=='1' and r['trigger'] and r['advance_applied_reply'] for r in records[key]),'freeze not actually Advanced before reply loss')
                    row['applied_before_expiry_at']=frozen['observedAt']
                print(json.dumps({'case':case,'phase':'waiting for actual witness authorization expiry','until':until}),flush=True)
                import time
                while time.time()<=until:
                    time.sleep(min(5,max(0.1,until+1-time.time())))
                row['expiry']={'until':until,'host_after':int(time.time())}
                checkpoint=len(records.get(key,[]))
                def cleanup(action,**extra):
                    result=success(dict(args,action=action,**extra))
                    sdk.require(result['runtimeCreated'] is False and result['observedAt']>until,'historical operation used runtime/current validity')
                    return result
                if case=='expired-applied':
                    report=cleanup('cleanup-session-begin',session=target_session)
                    document=json.loads(report['document'])
                    sdk.require(document['schema']==1 and document['kind']=='session' and document['session']==bytes(target_session).hex() and document['report']==bytes(report['report']).hex(),'original applied report scope')
                    sdk.require(report['status']['phase']==1 and report['status']['report']==report['report'],'applied freeze not recovered as pending host accounting')
                    sdk.require(len(document['epochs'])==1 and document['epochs'][0]['unconfirmed'][0]['message']==bytes(original_slots[0]).hex(),'original unknown message lost')
                    again=cleanup('cleanup-session-begin',session=target_session)
                    sdk.require(again['document']==report['document'] and again['report']==report['report'],'historical replay changed applied report')
                    folder=output/'accounting'/key; folder.mkdir(parents=True)
                    path=folder/(bytes(report['report']).hex()+'.json')
                    with path.open('xb') as stream:
                        stream.write(report['document'].encode()); stream.flush(); os.fsync(stream.fileno())
                    descriptor=os.open(folder,os.O_RDONLY)
                    try: os.fsync(descriptor)
                    finally: os.close(descriptor)
                    row['accounted_report']={'report':report['report'],'document':report['document'],'sha256':sdk.snapshot(path).sha256}
                    action='cleanup-session-ack'; extra={'session':target_session,'report':report['report']}
                else:
                    status=cleanup('cleanup-account-status')['status']
                    members=cleanup('cleanup-account-members')['members']
                    sdk.require(status['phase']==2 and status['operation']==operation and [m['message'] for m in members]==original_slots and [m['phase'] for m in members]==[1,1],'expired metadata query changed aggregate')
                    status=cleanup('cleanup-session-status',session=target_session)['status']
                    sdk.require(status=={'phase':0,'report':None},'fresh closure already present')
                    action='cleanup-session-begin'; extra={'session':target_session}
                for selected,arguments in [(action,extra),('cleanup-session-status',{'session':target_session})]:
                    count=len(records.get(key,[]))
                    refused=invoke(dict(args,action=selected,witnessMode='expired-denial',**arguments))
                    sdk.require(refused.get('code')=='WitnessTransport' and refused.get('ownerClosed') is True and refused['runtimeCreated'] is False and refused['observedAt']>until,'expired new/pending write succeeded')
                    current=records.get(key,[])[count:]
                    sdk.require(any(r.get('native_rejected')=='Validity' and r['request_tag']==2 and r['authenticated_reply'] is False for r in current),'native rejection not independently observed')
                after=records.get(key,[])[checkpoint:]
                sdk.require(after and all(r['request_tag'] in (1,2) and r.get('reply_tag')!=2 for r in after),'fresh witness advance occurred after expiry')
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==1,'expired cleanup dispatched application data')
                sdk.require(not failures,'unexpected fixture failure: '+json.dumps(failures))
                row['completed']=True
                row['cleanup_complete']=False
                row['expected_boundary']='Historical reads/exact applied confirmation only; new mutation and unapplied pending replay denied without current authorization.'
                print(json.dumps({'case':case,'completed':True,'new_cleanup_write_denied':True,'cleanup_complete':False}),flush=True)
