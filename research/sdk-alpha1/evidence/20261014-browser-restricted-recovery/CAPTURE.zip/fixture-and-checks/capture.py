from pathlib import Path
import json
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
overlay=json.loads((stage/'SOURCE_OVERLAY_02.json').read_text()); clone=Path(overlay['source'])
for name,digest in overlay['overlay'].items():
    sdk.require(sdk.snapshot(root/name).sha256==digest and sdk.snapshot(clone/name).sha256==digest,'source drift: '+name)
expected={'run01':['local'],'run04':['required-live','reserved-live'],'run05':['expired-refusal','expired-applied']}
results={}
for name,cases in expected.items():
    result=json.loads((stage/name/'RESULT.json').read_text())
    sdk.require(result['completed'] and result['producer_unchanged'] and result['startup_console_clean'],'run incomplete: '+name)
    sdk.require([r['case'] for r in result['cases']]==cases and all(r['completed'] for r in result['cases']),'scenario mismatch')
    for path,digest in result['producer'].items(): sdk.require(sdk.snapshot(Path(path),maximum=256*1024**2).sha256==digest,'producer drift: '+path)
    for path,digest in result['static_web'].items(): sdk.require(sdk.snapshot(stage/(name+'-web')/path).sha256==digest,'static web drift')
    results[name]=result
sdk.require(all(row['cleanup_complete'] is False for row in results['run05']['cases']),'expired refusal mislabeled complete cleanup')
for name in ('run02','run03'):
    sdk.require(not json.loads((stage/name/'RESULT.json').read_text())['completed'],'failed attempt overwritten')
native=json.loads((stage/'NATIVE_REGRESSIONS.json').read_text())
sdk.require(native['completed'] and native['counts']=={'portable':14,'fanout':61,'installation':3,'closure':15},'native suites incomplete')
for prefix in ('owners-native-02','owners-wasm-02','msrv-check','controls-01','group-build-02'):
    sdk.require(json.loads((stage/(prefix+'.json')).read_text())['returncode']==0,'check failed: '+prefix)
equivalence=json.loads((stage/'PACKAGE_RUNTIME_EQUIVALENCE.json').read_text())
sdk.require(equivalence['completed'] and equivalence['changed']==['PACKAGE_CONTENTS.json','README.md'],'documentation/runtime distinction lost')
packages={}
for number in ('01','02'):
    package=clone/('target/browser-recovery-package-'+number)
    installed=json.loads((package/'INSTALLED_CONSUMER.json').read_text())
    sdk.require(installed['source_bound'] and installed['sources_unchanged'] and installed['installed_node_tests']=='passed' and installed['browser_runtime']=='not-run','package evidence incomplete/rewritten')
    sdk.require(sdk.snapshot(Path(installed['archive'])).sha256==installed['sha256'],'package drift')
    sdk.require(sdk.snapshot(package/'package/PACKAGE_CONTENTS.json').sha256==installed['manifest_sha256'],'manifest drift')
    packages[number]=(package,installed)
members={}
def include(path,name):
    sdk.require(name not in members and path.is_file() and not path.is_symlink(),'capture member '+name)
    members[name]=sdk.snapshot(path,maximum=64*1024**2).data
for name in ('run01','run02','run03','run04','run05'):
    for path in (stage/name).rglob('*'):
        relative=path.relative_to(stage/name)
        if path.is_file() and (not any(part.startswith('.') for part in relative.parts)
            or (relative.parts[0]=='.playwright-cli' and path.suffix=='.log')):
            include(path,name+'/'+relative.as_posix())
    for folder in ('inputs','creation'):
        for path in (stage/(name+'-web')/folder).rglob('*'):
            if path.is_file(): include(path,name+'-web/'+path.relative_to(stage/(name+'-web')).as_posix())
for path in stage.iterdir():
    if path.is_file() and path.name!='HANDOFF_CURRENT.json' and path.suffix in ('.py','.js','.sh','.json','.stdout','.stderr','.rs','.md'):
        include(path,'fixture-and-checks/'+path.name)
for name in ('group-fixture','group-fixture-02'):
    for path in (stage/name/'src').rglob('*.rs'): include(path,'fixture/'+name+'/'+path.relative_to(stage/name).as_posix())
    for file in ('Cargo.toml','Cargo.lock'): include(stage/name/file,'fixture/'+name+'/'+file)
for number,(package,installed) in packages.items():
    for path in package.iterdir():
        if path.is_file() and path.suffix in ('.json','.stdout','.stderr'): include(path,'package-'+number+'/'+path.name)
    for file in ('package.json','PACKAGE_CONTENTS.json','README.md'): include(package/'package'/file,'package-'+number+'/'+file)
for name in overlay['overlay']: include(root/name,'source/'+name)
documentation={'docs/continuity/PRODUCT_ADMISSION.md':sdk.snapshot(root/'docs/continuity/PRODUCT_ADMISSION.md').sha256}
for name in documentation: include(root/name,'source/'+name)
destination=root/'research/sdk-alpha1/evidence/20261014-browser-restricted-recovery'
destination.mkdir(parents=True)
archive=destination/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,14,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100600<<16
        output.writestr(info,data)
with zipfile.ZipFile(archive) as output:
    sdk.require(output.testzip() is None and len(output.namelist())==len(members),'archive invalid')
    for name,data in members.items(): sdk.require(output.read(name)==data,'payload drift')
cases=[{'run':name,'case':row['case'],'calls':len(row['calls']),
    'cleanup_complete':row.get('cleanup_complete',True),
    'authority':row.get('authority'),'expiry':row.get('expiry'),
    'reports':len(row.get('host_accounting',[]))+(1 if 'accounted_report' in row else 0)}
    for name,result in results.items() for row in result['cases']]
checks={'schema':1,'completed':True,'release_claim_eligible':False,
    'source_base':overlay['base_commit'],'source_overlay':overlay['overlay'],'documentation':documentation,
    'package_sha256':packages['02'][1]['sha256'],'manifest_sha256':packages['02'][1]['manifest_sha256'],
    'runtime_equivalence':equivalence['scope'],'cases':cases,'browser_calls':sum(row['calls'] for row in cases),
    'native_regressions':native['counts'],'artifact_controls':53,
    'archive':{'path':archive.name,'sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,'bytes':archive.stat().st_size,'members':len(members)},
    'scope':'Actual installed Chrome package and native witness/receivers sharing one engine on macOS arm64. Local real-expiry cleanup; current-witness cleanup with closed local runtime; expired-witness reads/exact confirmation and deliberate fresh-write denial.',
    'failures_preserved':['Native negative fixture originally compared identical deterministic policies; now independently asserts differing checkpoint.',
        'run02 incorrectly expected fresh cleanup after witness expiry; native Rejected(Validity) is the correct contract.',
        'run03 used credential-commit tags for generic advances; no fault fired and the gate failed. Separate fixture now verifies Advance/Advanced(2/2).',
        'Pre-run py_compile was rejected by hardened launcher cache guard; validation changed to AST parsing without changing the guard.'],
    'remaining':['Composition with independently renewed witness authorization or permanent device/account retirement',
        'Additional local reservation/commit cuts, cancellation/concurrent close and nonempty inbox/skipped-report workloads',
        'Independent implementation/hosts, complete platform lifecycle, PCS, performance, CI and final release admission'],
    'private_material_archived':False}
sdk.write_json(destination/'CHECKS.json',checks)
print(json.dumps({'captured':True,'archive':checks['archive'],'cases':len(cases),'browser_calls':checks['browser_calls']}))
