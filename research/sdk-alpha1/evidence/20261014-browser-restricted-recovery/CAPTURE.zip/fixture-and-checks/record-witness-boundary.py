from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
failed=json.loads((stage/'run02/RESULT.json').read_text())
sdk.require(not failed['completed'] and failed['fixture_failures']==['native witness failed: run02-required/174'],'unexpected failure')
sdk.require((stage/'run02/witness/run02-required/174.stderr').read_text()=='Error: Rejected(Validity)\n','rejection cause changed')
sdk.write_json(stage/'WITNESS_EXPIRY_BOUNDARY.json',{
    'run':'run02','completed':False,'action':'cleanup-session-begin','request':174,
    'client_code':'WitnessTransport','client_cause':'HTTP 500, no authenticated commit receipt',
    'native_rejection':'Rejected(Validity)','commit_applied':False,
    'classification':'Incorrect qualification expectation, not a witness security defect.',
    'source':['research/continuity-identity-candidate/src/anchor/store.rs:524-549',
        'research/continuity-identity-candidate/src/anchor/store.rs:608-630',
        'research/continuity-identity-candidate/src/durable/messages/tests/fanout/witness.rs:769-805',
        'research/continuity-identity-candidate/src/durable/messages/tests/fanout/witness.rs:1302-1314'],
    'contract':'Effective witness validity intersects credential, roster and policy. Expired authorization allows queries and exact last-command confirmation, but no new Advance/Fence, including cleanup freeze/ack/retire. A local cleanup intent may remain pending and reopening cannot bypass expiry.',
    'scope':'Local real-expiry run01 passed. Anchored new-write completion after actual witness expiry is NOT qualified. Do not relabel run02 as passed or disable validity.',
    'next':'Qualify complete account/session cleanup under still-current witness authority with explicitly closed local runtime; qualify fresh expired read-only/AlreadyAppliedExact and refused new writes separately. Independently authorized renewal/permanent retirement remains part of full lifecycle work.'})
path=stage/'HANDOFF_CURRENT.json'; state=json.loads(path.read_text())
state['live_sessions']={}
state['terminal']+=' 17792run02terminal1 atrequiredstep020; reservednotstarted. Actualnativewitness174 rejectedValidity; server500 becameWitnessTransport. NoAppliedfaultoccurred; no rerun/reopenofthisfailedcohort.'
state['critical_correction']='WITNESS_EXPIRY_BOUNDARY.json: earlier testexpectedfreshcleanupcommitafterP/C/witnessexpiry, contrarytoAnchorStore::handleandexistingtests. Expiredonlyquery/AlreadyAppliedExact; freshAdvance/Fencevaliditycheckintentional. Userinformedourqualificationexpectationwaswrong,notsecuritycheckbug. Neverrelaxwitnessvalidity; donotmarkrun02passed. NoMaincodechangedforfailure.'
state['next']=[
    'Keepacceptedrun01producersimmutable (run.py,worker.js,controller.js,server.py,nativebins/package01). run02failedsameproducerspreserved. Alllocalproducersnowterminal; Main+clone stillOWNED658-sourceoverlayuncommitted atb9.',
    'CorrectPackageREADME toexplicitlystate expiredwitness onlyreads/exactalready-appliedconfirmations; newfreeze/ACK/retirerequirescurrentindependentwitnessauthority. Pendingintentmustnotbereset. ChangingonlyREADMEcanusepackage02 +exactruntimefilehashcomparison withpackage01; newscenarios shouldusepackage02. PreserveSOURCE_OVERLAY oldbeforeupdatingdocs; verifyallunchangedpaths.',
    'Forcurrent-witnessqualification createNEW worker-live.js andrun-live.py, do noteditacceptedworker/run.py. Seedprepare normal3600s. Casesrequired-live/reserved-live; workeractionruntime-closed usesrealSDKRuntime.close() onalreadyactiveownerthenattemptsoriginalsend=>Closed/ownerclosed/nopeerdata. CleanuphasnoRuntimebutrequiredwitnessstillwithinvalidity. Reuseallfullreports/fsync/reopen/badreport/no-subset/lostAppliedbegin+ACK+retire checks. Driverchecks cleanupobservedAt <actualwitness/credential/policyexpiry andlabelsaslocal-runtimeclosed,notexpiry. Scopefullworkflowconditionalonvalidwitness; nofakeclock.',
    'Additionalfreshactual-expirycase should EXPECTread-onlystatus/memberreconciliation andnewcommitrefusal,notfullcleanup. Addnewserver variant retainingexplicitRejected(Validity)recordforonlyexpectedexpiredscenario (clientstillWitnessTransport/noauthenticatedreceipt); do notswallowarbitraryerrorsorcallrefusalnoncommitwithoutsource-boundserverevidence. AlreadyAppliedExact-afterexpiry needsactualfreeze/ACKAppliedBEFOREexpiry, thenlose/holdreply/reopenafterexpiry; newACKstillblockedunlessfreshauthorization.',
    'Fullgoalrequires renewedauthorization orpermanentretirementpath. Existingrenew_credential_authority trustedcontrolpreservesheadbutrequiresSAMECURRENToriginalpolicy; cannotfixexpiredP0. G/Tpublicrenewal exists; investigate pendinggenericcleanup intentinteractionbeforeclaimingrenewalunblocks. prepare_renewal_request_with_anchor callsreconcile_installation and pendingintentmustreconcile; potentialorderingissueisUNPROVEN. No newprotocol/permissionbypassbasedonassumption. Permanentretirementalreadyhasseparatepurpose19/21nativeprotocol, browserstillnotported.',
    'Aftervalidqualification/correctscope, capturepublicevidenceandfailures; updatePRODUCT_ADMISSIONprecisely; finalscopedcommit+byteverified/backed-upcloneoverlayrestore+exactsourcegate. Currentpackage01hash9a15... andruntime/testsallremainvalidforobservedscopes,notexpiredwitnessnewwrites.',
    *state['next'][-1:]
]
path.write_text(json.dumps(state,indent=2)+'\n')
print('Recorded intentional witness expiry boundary and failed expectation; no active local producers, no authorization checks changed')
