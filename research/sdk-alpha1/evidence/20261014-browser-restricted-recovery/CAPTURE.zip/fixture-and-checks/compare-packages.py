from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
base=root/'target/continuity-browser-publication/source/target'
old=base/'browser-recovery-package-01'; new=base/'browser-recovery-package-02'
old_files={p.relative_to(old/'package').as_posix():sdk.snapshot(p).sha256 for p in (old/'package').rglob('*') if p.is_file()}
new_files={p.relative_to(new/'package').as_posix():sdk.snapshot(p).sha256 for p in (new/'package').rglob('*') if p.is_file()}
sdk.require(set(old_files)==set(new_files),'package file set changed')
changed=[name for name in old_files if old_files[name]!=new_files[name]]
sdk.require(set(changed)=={'README.md','PACKAGE_CONTENTS.json'},'runtime/package files changed beyond declared docs: '+repr(changed))
consumer=json.loads((new/'INSTALLED_CONSUMER.json').read_text())
sdk.require(consumer['source_bound'] and consumer['sources_unchanged'] and consumer['installed_node_tests']=='passed','new package verification incomplete')
sdk.write_json(stage/'PACKAGE_RUNTIME_EQUIVALENCE.json',{'completed':True,'changed':sorted(changed),
    'identical_files':{name:digest for name,digest in old_files.items() if name not in changed},
    'old_archive_sha256':json.loads((old/'INSTALLED_CONSUMER.json').read_text())['sha256'],
    'new_archive_sha256':consumer['sha256'],'new_manifest_sha256':consumer['manifest_sha256'],
    'scope':'All packaged files except README and its manifest are byte-identical, including JS/WASM/types. Existing local runtime qualification transfers across this documentation-only correction; new current-witness scenarios consume package02.'})
print(json.dumps({'runtime_identical':True,'changed':changed,'package_sha256':consumer['sha256']}))
