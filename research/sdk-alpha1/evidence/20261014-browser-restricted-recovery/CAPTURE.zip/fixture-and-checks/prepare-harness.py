from pathlib import Path
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'; prior=root/'target/continuity-browser-fanout'
controller=(prior/'controller.js').read_text()
sdk.require(controller.count('45000')==1,'controller deadline marker')
controller=controller.replace('45000', "args.action === 'expiry-held' ? 210000 : 45000")
(stage/'controller.js').write_text(controller)
server=(prior/'server_timed.py').read_text()
marker='            peer = re.fullmatch(r\'/peer/([a-z0-9-]+)/([01])\', target.path)'
sdk.require(server.count(marker)==1,'server dispatch marker')
server=server.replace(marker,'''            progress = re.fullmatch(r'/progress/([a-z0-9-]+)\\.json', target.path)
            if progress:
                if len(data) > 2048: self.send_error(413); return
                record = json.loads(data)
                if set(record) != {'heldAt', 'until', 'runtimeCreated'} or record['runtimeCreated'] is not True or not record['heldAt'] < record['until']:
                    self.send_error(400); return
                with (output / (progress[1] + '-expiry-held.json')).open('xb') as stream: stream.write(data)
                self.send_response(201); self.end_headers(); self.wfile.write(b'observed'); return
''' + marker)
old="or cut not in ('0', '1', '2') or not directory.is_dir()"
sdk.require(server.count(old)==1,'bounded fault marker')
server=server.replace(old,"or not cut.isdecimal() or not 0 <= int(cut) <= 32 or not directory.is_dir()")
(stage/'server.py').write_text(server)
print('Isolated timed server/controller prepared; SDK operation deadlines unchanged; expiry-held observation is public metadata only')
