from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
files = sorted(set(subprocess.run(['git','diff','--name-only'], cwd=root, check=True, capture_output=True, text=True).stdout.splitlines())
    | set(subprocess.run(['git','ls-files','--others','--exclude-standard'], cwd=root, check=True, capture_output=True, text=True).stdout.splitlines()))
sdk.require(files and all(name.endswith('.rs') for name in files), 'unexpected current source scope')
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS','') + ' -D warnings'
toolchain = Path(env['RUSTC']).parent
sdk.command([str(toolchain/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(root/name) for name in files]],stage/'format-enrollment-02',root,environment=env)
inputs = {name:sdk.snapshot(root/name).sha256 for name in files}
sdk.write_json(stage/'ENROLLMENT_INPUTS_02.json',inputs)
sdk.command([str(toolchain/'cargo'),'test','--locked','--offline','--manifest-path',
    'research/continuity-identity-candidate/Cargo.toml','--all-features','--lib',
    'enrolled_cleanup_accounts','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','--nocapture'],
    stage/'enrollment-test-02',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256 == digest,'input drift')
print('Original enrollment restricted-account lifecycle test passed')
