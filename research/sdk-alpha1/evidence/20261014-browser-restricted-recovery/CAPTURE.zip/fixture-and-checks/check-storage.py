from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
files = ['research/continuity-identity-candidate/src/installation/recovery.rs',
         'research/continuity-identity-candidate/src/durable/messages/fanout/archive.rs',
         'research/continuity-identity-candidate/src/durable/messages/closure/archive.rs']
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
toolchain = Path(env['RUSTC']).parent
sdk.command([str(toolchain / 'rustfmt'), '--edition', '2021', *[str(root / name) for name in files]], stage / 'format-storage-01', root, environment=env)
inputs = {name: sdk.snapshot(root / name).sha256 for name in files}
sdk.write_json(stage / 'STORAGE_INPUTS_01.json', inputs)
sdk.command([str(toolchain / 'cargo'), 'check', '--locked', '--offline', '--manifest-path',
    'research/continuity-identity-candidate/Cargo.toml', '--all-features', '--lib',
    '--target-dir', str(root / 'target/continuity-browser-fanout/native-target'), '-j', '2'],
    stage / 'check-storage-native-01', root, environment=env)
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'input drift')
print('Shared storage-aware account and session cleanup compiled on native target')
