from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server_expiry import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'expired-refusal','expired-applied'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-recovery-package-02'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for name in ('worker.js', 'controller.js'): shutil.copyfile(stage / name, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Original account recovery</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
browser_session = 'qpc-recovery-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage / ('group-target-02/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker.js', stage / 'controller.js', stage / 'server_expiry.py']}
state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Installed browser historical recovery and deliberate fresh-write refusal after actual witness authorization expiry; no complete cleanup without renewed authority is claimed', 'cases': []}
sequence = 0

def browser(args, name, timeout=80):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', browser_session, *args], timeout_seconds=timeout,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name, 240 if args['action']=='expiry-held' else 80).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="fanout_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("fanout_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            console = browser(['console', 'warning'], 'startup-console').decode()
            sdk.require(console == '### Result\nTotal messages: 0 (Errors: 0, Warnings: 0)\n\n', 'startup console error')
            state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case':case, 'calls':[], 'completed':False}; state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare-expiring-all',directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text()); cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json',inputs / (key + '.json'))
                args = {'case':key,'name':key+'-'+uuid.uuid4().hex[:8], 'id':uuid.uuid4().hex+uuid.uuid4().hex, 'profile':profile}
                success(dict(args,action='create'))
                grant_path = inputs / (key + '-grant.json')
                trace = output / (case + '-native-prepare'); trace.mkdir(mode=0o700)
                native('peer',['prepare-group',directory,output/'captures'/(key+'.bin'),grant_path,inputs,trace],case+'-group-prepare')
                grant = json.loads(grant_path.read_text())
                for slot in range(2):
                    peer = json.loads((inputs / (key + f'-peer-{slot}.json')).read_text())
                    sdk.require(peer['account'] == cfg['account'] and peer['root'] == cfg['root'] and peer['roster'] == grant['roster'] and peer['digest'] == grant['digest'], 'independent group roster mismatch')
                accepted = success(dict(args,action='accept')); prepared = success(dict(args,action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness',['enroll',directory,grant_path,output/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
                active = success(dict(args,action='activate')); sdk.require(active['journal'] == prepared['journal'], 'activation identity')
                row['journal'] = active['journal']
                sessions = []
                for slot in range(2):
                    established = success(dict(args,action='establish',slot=slot,requestId=list(os.urandom(32))))
                    sdk.require(established['journal'] == row['journal'], 'per-peer owner replaced original journal')
                    sessions.append(established['session'])
                    sdk.write_json(directory/'recipients'/str(slot)/'peer/session.json',established['session'])
                sdk.require(sessions[0] != sessions[1], 'different members share a session')
                args['sessions'] = sessions; row['sessions'] = sessions
                operation = success(dict(args,action='account-next'))['operation']; args['operation'] = operation; row['operation'] = operation
                original_slots = success(dict(args,action='session-slots'))['messages']; row['original_messages'] = original_slots
                lost=invoke(dict(args,action='account-deliver',selected=0,mode='drop-ack'))
                sdk.require(lost.get('code')=='PeerTransport' and lost.get('ownerClosed') is True,'original consumption reply loss')
                frames=[r for r in peers.get(key,[]) if r['kind']==3]
                sdk.require(len(frames)==1 and frames[0]['slot']==0,'unexpected original dispatch')
                target_session=sessions[0]
                until=max(cfg['until'],cfg['policy_until'])
                if case=='expired-applied':
                    frozen=invoke(dict(args,action='cleanup-session-begin',session=target_session,witnessMode='drop-advance',cut='1'))
                    sdk.require(frozen.get('code')=='WitnessTransport' and frozen.get('ownerClosed') is True and frozen['observedAt']<until,'freeze was not attempted before actual expiry')
                    sdk.require(any(r['mode']=='drop-advance' and r['cut']=='1' and r['trigger'] and r['advance_applied_reply'] for r in records[key]),'freeze not actually Advanced before reply loss')
                    row['applied_before_expiry_at']=frozen['observedAt']
                print(json.dumps({'case':case,'phase':'waiting for actual witness authorization expiry','until':until}),flush=True)
                import time
                while time.time()<=until:
                    time.sleep(min(5,max(0.1,until+1-time.time())))
                row['expiry']={'until':until,'host_after':int(time.time())}
                checkpoint=len(records.get(key,[]))
                def cleanup(action,**extra):
                    result=success(dict(args,action=action,**extra))
                    sdk.require(result['runtimeCreated'] is False and result['observedAt']>until,'historical operation used runtime/current validity')
                    return result
                if case=='expired-applied':
                    report=cleanup('cleanup-session-begin',session=target_session)
                    document=json.loads(report['document'])
                    sdk.require(document['schema']==1 and document['kind']=='session' and document['session']==bytes(target_session).hex() and document['report']==bytes(report['report']).hex(),'original applied report scope')
                    sdk.require(report['status']['phase']==1 and report['status']['report']==report['report'],'applied freeze not recovered as pending host accounting')
                    sdk.require(len(document['epochs'])==1 and document['epochs'][0]['unconfirmed'][0]['message']==bytes(original_slots[0]).hex(),'original unknown message lost')
                    again=cleanup('cleanup-session-begin',session=target_session)
                    sdk.require(again['document']==report['document'] and again['report']==report['report'],'historical replay changed applied report')
                    folder=output/'accounting'/key; folder.mkdir(parents=True)
                    path=folder/(bytes(report['report']).hex()+'.json')
                    with path.open('xb') as stream:
                        stream.write(report['document'].encode()); stream.flush(); os.fsync(stream.fileno())
                    descriptor=os.open(folder,os.O_RDONLY)
                    try: os.fsync(descriptor)
                    finally: os.close(descriptor)
                    row['accounted_report']={'report':report['report'],'document':report['document'],'sha256':sdk.snapshot(path).sha256}
                    action='cleanup-session-ack'; extra={'session':target_session,'report':report['report']}
                else:
                    status=cleanup('cleanup-account-status')['status']
                    members=cleanup('cleanup-account-members')['members']
                    sdk.require(status['phase']==2 and status['operation']==operation and [m['message'] for m in members]==original_slots and [m['phase'] for m in members]==[1,1],'expired metadata query changed aggregate')
                    status=cleanup('cleanup-session-status',session=target_session)['status']
                    sdk.require(status=={'phase':0,'report':None},'fresh closure already present')
                    action='cleanup-session-begin'; extra={'session':target_session}
                for selected,arguments in [(action,extra),('cleanup-session-status',{'session':target_session})]:
                    count=len(records.get(key,[]))
                    refused=invoke(dict(args,action=selected,witnessMode='expired-denial',**arguments))
                    sdk.require(refused.get('code')=='WitnessTransport' and refused.get('ownerClosed') is True and refused['runtimeCreated'] is False and refused['observedAt']>until,'expired new/pending write succeeded')
                    current=records.get(key,[])[count:]
                    sdk.require(any(r.get('native_rejected')=='Validity' and r['request_tag']==2 and r['authenticated_reply'] is False for r in current),'native rejection not independently observed')
                after=records.get(key,[])[checkpoint:]
                sdk.require(after and all(r['request_tag'] in (1,2) and r.get('reply_tag')!=2 for r in after),'fresh witness advance occurred after expiry')
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==1,'expired cleanup dispatched application data')
                sdk.require(not failures,'unexpected fixture failure: '+json.dumps(failures))
                row['completed']=True
                row['cleanup_complete']=False
                row['expected_boundary']='Historical reads/exact applied confirmation only; new mutation and unapplied pending replay denied without current authorization.'
                print(json.dumps({'case':case,'completed':True,'new_cleanup_write_denied':True,'cleanup_complete':False}),flush=True)
            state['witness_records'] = records; state['peer_records'] = peers
        except BaseException as error:
            state['protocol_failure']=repr(error)
            raise
        finally:
            state['witness_records']=records; state['peer_records']=peers; state['fixture_failures']=failures
            browser(['close'],'close')
    for name,digest in producer.items(): sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'installed web drift')
    state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    state['failure'] = repr(error); raise
finally:
    sdk.write_json(output/'RESULT.json',state)
print(json.dumps({'completed':True,'cases':cases,'scope':state['scope']}))
