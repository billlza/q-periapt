from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
old=json.loads((stage/'SOURCE_OVERLAY.json').read_text()); clone=Path(old['source'])
for name,digest in old['overlay'].items():
    sdk.require(sdk.snapshot(root/name).sha256==digest and sdk.snapshot(clone/name).sha256==digest,'source drift before documentation correction')
name='crates/q-periapt-sdk-wasm/PackageREADME.md'
sdk.copy(root/name,stage/'README_BEFORE_WITNESS_CORRECTION.md')
source=(root/name).read_text()
marker='cleanup-only owner; activation, renewal and ordinary message operations are\nunavailable on it. Status and member reconciliation retain the original IDs.\n'
sdk.require(source.count(marker)==1,'recovery documentation marker')
note='''
This does not extend witness authorization. Its effective validity is the
intersection of credential, roster and policy validity. Once that interval ends,
the witness refuses fresh cleanup freezes, acknowledgements and retirement writes,
just as it refuses other new state advances. Historical queries without an
unapplied pending write, and exact confirmation of an already-applied command,
remain possible. A refused write may leave the original intent pending; neither
reopening nor a local fallback may discard or complete it. New writes need
independent current witness authorization; permanent device/account retirement
uses its separate approved workflow. Closing a local runtime while the witness
authorization is still current is a different case and does allow restricted
cleanup. A transport error alone does not prove whether the witness committed.
'''
source=source.replace(marker,marker+note)
(root/name).write_text(source); (clone/name).write_text(source)
subprocess.run(['git','add','--',name],cwd=clone,check=True)
updated={key:sdk.snapshot(root/key).sha256 for key in old['overlay']}
sdk.write_json(stage/'SOURCE_OVERLAY_02.json',{**old,'overlay':updated})
sdk.write_json(stage/'OWNER_INPUTS_03.json',updated)
script=(stage/'build-package.sh').read_text().replace('browser-recovery-package-01','browser-recovery-package-02')
(stage/'build-package-02.sh').write_text(script)
sdk.write_json(stage/'DOCUMENTATION_CORRECTION.json',{'changed':[name],'runtime_code_changed':False,
    'reason':'Required-witness expiry deliberately blocks fresh cleanup advances; read-only/exact-applied recovery is distinct from current authorization.',
    'old_package':'browser-recovery-package-01','new_package':'browser-recovery-package-02','runtime_equivalence':'pending byte comparison after build'})
print('Clarified intentional witness boundary; only README changed; new exact-source package required')
