from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root/'target/continuity-browser-recovery'
clone = root/'target/continuity-browser-publication/source'
base = 'b9d4c954f999609a96bd0fa9dc4978479f500267'
def git(path, *args):
    return subprocess.run(['git',*args],cwd=path,check=True,capture_output=True).stdout
sdk.require(git(root,'rev-parse','HEAD').decode().strip()==base, 'main moved')
sdk.require(git(clone,'rev-parse','HEAD').decode().strip()==base and not git(clone,'status','--porcelain'), 'clone not clean expected base')
inputs=json.loads((stage/'OWNER_INPUTS_02.json').read_text())
actual=set(git(root,'diff','--name-only').decode().splitlines())|set(git(root,'ls-files','--others','--exclude-standard').decode().splitlines())
sdk.require(actual==set(inputs), 'unexpected source changes')
for name,digest in inputs.items():
    source=sdk.snapshot(root/name); sdk.require(source.sha256==digest,'source drift')
    path=clone/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(source.data)
git(clone,'add','--',*sorted(inputs))
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':base,'source':str(clone),'overlay':inputs})
sdk.copy(clone/'target/browser-fanout-build.py',clone/'target/browser-recovery-build.py')
script=(root/'target/continuity-browser-fanout/build-package-02.sh').read_text()
(stage/'build-package.sh').write_text(script.replace('browser-fanout-build.py','browser-recovery-build.py').replace('browser-fanout-package-02','browser-recovery-package-01'))
print('Exact658-source overlay staged in owned clean-base clone; isolated recovery package driver ready')
