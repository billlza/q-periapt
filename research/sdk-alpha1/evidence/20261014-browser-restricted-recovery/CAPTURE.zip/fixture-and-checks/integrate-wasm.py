from pathlib import Path
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
new = ['research/continuity-identity-candidate/src/enrollment/recovery.rs',
       'research/continuity-identity-candidate/src/browser/recovery.rs',
       'research/continuity-identity-candidate/src/session_exchange/tests/account/recovery.rs',
       'crates/q-periapt-sdk-wasm/src/continuity/recovery.rs',
       'crates/q-periapt-sdk-wasm/src/continuity/recovery/reports.rs']
for name in new: sdk.require((root/name).is_file(), 'missing new module')
exports = ['ClosurePhase','ClosureStatus','AccountAbandonment','SessionClosure']
for name in ('index.js','index.d.ts'):
    path = root/'crates/q-periapt-sdk-wasm/package/web'/name
    path.write_text(path.read_text()+'\nexport {\n  '+',\n  '.join('QPeriaptContinuity'+name for name in exports)+"\n} from './q_periapt_sdk_wasm.js';\n")
path = root/'artifact/codeql_rust_quality.py'
source = path.read_text(); sdk.require(source.count('EXPECTED_TRACKED_RUST_SOURCE_COUNT = 653') == 1,'inventory baseline')
path.write_text(source.replace('EXPECTED_TRACKED_RUST_SOURCE_COUNT = 653','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 658'))
path = root/'ARTIFACT.md'; source=path.read_text()
sdk.require(source.count('653 tracked `.rs`') == 1,'inventory documentation')
path.write_text(source.replace('653 tracked `.rs`','658 tracked `.rs`'))
path = root/'artifact/test_codeql_rust_quality.py'; source=path.read_text()
marker = '            "research/continuity-identity-candidate/src/browser/connections/account.rs",'
sdk.require(source.count(marker) == 2,'positive and missing inventory sentinels')
path.write_text(source.replace(marker, marker+''.join('\n            "'+name+'",' for name in new)))
sdk.write_json(stage/'NEW_RUST_FILES.json',new)
source = (stage/'check-owners.py').read_text().replace("all(name.endswith('.rs') for name in files)", "all(not name.startswith('target/') for name in files)")
source = source.replace('for name in files]],', "for name in files if name.endswith('.rs')]],")
source = source.replace('format-owners-01','format-owners-02').replace('OWNER_INPUTS_01','OWNER_INPUTS_02').replace("+'-01')", "+'-02')")
(stage/'check-bindings.py').write_text(source)
print('Typed recovery exports and exact658-file CodeQL inventory integrated')
