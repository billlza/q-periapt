from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
inputs=json.loads((stage/'OWNER_INPUTS_02.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'precheck source drift')
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
cargo=Path(env['RUSTC']).parent/'cargo'
counts={}
for label,selected in [('portable','session_exchange::tests'),('fanout','fanout'),
    ('installation','installation::tests::recovery'),('closure','durable::messages::tests::closure')]:
    output=sdk.command([str(cargo),'test','--locked','--offline','--manifest-path',
        'research/continuity-identity-candidate/Cargo.toml','--all-features','--lib',selected,
        '--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','--nocapture'],
        stage/('regression-'+label),root,environment=env).decode()
    values=re.findall(r'^test result: ok\. (\d+) passed; 0 failed;',output,re.MULTILINE)
    sdk.require(len(values)==1 and int(values[0])>0,'empty or failed suite: '+label)
    counts[label]=int(values[0]); print(json.dumps({'suite':label,'passed':counts[label]}),flush=True)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'postcheck source drift')
sdk.write_json(stage/'NATIVE_REGRESSIONS.json',{'completed':True,'counts':counts,'inputs_unchanged':True})
