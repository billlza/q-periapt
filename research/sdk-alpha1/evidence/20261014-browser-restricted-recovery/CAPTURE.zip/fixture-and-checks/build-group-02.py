from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd(); stage = root / 'target/continuity-browser-recovery'; work = stage / 'group-fixture-02'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None); env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
binary = Path(env['RUSTC']).parent
sdk.command([str(binary / 'rustfmt'), '--edition', '2021', *map(str, sorted((work / 'src/bin').glob('*.rs')))], stage / 'group-format-02', root, environment=env)
inputs = {str(p): sdk.snapshot(p).sha256 for p in sorted((work / 'src/bin').glob('*.rs'))}
sdk.write_json(stage / 'GROUP_INPUTS_02.json', inputs)
sdk.command([str(binary / 'cargo'), 'build', '--locked', '--offline', '--bins', '--message-format=json',
    '--target-dir', str(stage / 'group-target-02'), '-j', '2'], stage / 'group-build-02', work, environment=env)
for name, digest in inputs.items(): sdk.require(sdk.snapshot(Path(name)).sha256 == digest, 'fixture source drift')
print('Fresh complete-account native peer, issuer and coherent witness fixture built')
