from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
for name in ('run.py','server.py','run-body.py'):
    source=(stage/name).read_text()
    if name=='run-body.py': source='if True:\n'+source
    ast.parse(source,filename=name)
cache=Path('/tmp/qperiapt-python-cache.jU6K1yPC')
if cache.exists():
    files=[path for path in cache.rglob('*') if path.is_file()]
    sdk.require(files and all(path.suffix=='.pyc' and not path.is_symlink() for path in files),'unexpected syntax-check cache')
    sdk.write_json(stage/'DRIVER_VALIDATION_FAILURE_01.json',{
        'exit_code':125,'phase':'syntax validation before browser run',
        'cause':'Explicit py_compile wrote bytecode into the hardened launcher cache; its existing guard correctly rejected the populated prefix.',
        'repair':'AST parsing in memory, keeping the hardened launcher unchanged.',
        'cache_files':[str(path.relative_to(cache)) for path in files], 'browser_run_started':False})
    cache.rename(stage/'failed-syntax-cache-01')
sdk.require(not (stage/'run01').exists(),'fresh browser run already exists')
print('Driver syntax parsed in memory; failed pre-run cache check preserved; no launcher guard changed')
