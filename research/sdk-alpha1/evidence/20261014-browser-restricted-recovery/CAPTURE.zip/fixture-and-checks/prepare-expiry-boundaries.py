from pathlib import Path
import ast
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-browser-recovery'
server=(stage/'server_advance.py').read_text()
server=server.replace("('normal', 'drop-advance', 'hold-advance')","('normal', 'drop-advance', 'hold-advance', 'expired-denial')")
marker="                if result.returncode: raise ValueError('native witness failed: ' + case + '/' + str(number))"
sdk.require(server.count(marker)==1,'native error boundary')
replacement='''                if result.returncode and mode == 'expired-denial' and data[204] == 2 and prefix.with_suffix('.stderr').read_text() == 'Error: Rejected(Validity)\\n':
                    record = {'number':number,'mode':mode,'cut':cut,'trigger':False,
                        'request_tag':2,'request_sha256':hashlib.sha256(data).hexdigest(),
                        'native_rejected':'Validity','native_returncode':result.returncode,
                        'authenticated_reply':False,'advance_applied_reply':False}
                    records.setdefault(case, []).append(record)
                    (folder / 'RECORDS.json').write_text(json.dumps(records[case],indent=2)+'\\n')
                    self.send_error(403); return
''' + marker
server=server.replace(marker,replacement)
server=server.replace("trigger = mode != 'normal' and key not in faulted and record['advance_applied_reply']", "trigger = mode in ('drop-advance', 'hold-advance') and key not in faulted and record['advance_applied_reply']")
ast.parse(server,filename='server_expiry.py'); (stage/'server_expiry.py').write_text(server)
driver=(stage/'run.py').read_text().replace('from server import serving','from server_expiry import serving')
driver=driver.replace("{'local', 'required', 'reserved'}","{'expired-refusal','expired-applied'}").replace('browser-recovery-package-01','browser-recovery-package-02')
driver=driver.replace('group-target/debug/qpc-fanout-','group-target-02/debug/qpc-fanout-').replace("stage / 'server.py'","stage / 'server_expiry.py'")
start=driver.index("                before = len([r for r in peers.get(key,[]) if r['kind']==3])")
end=driver.index("            state['witness_records'] = records; state['peer_records'] = peers",start)
driver=driver[:start]+(stage/'expiry-body.py').read_text()+driver[end:]
driver=driver.replace('Installed browser original account/session cleanup after actual policy and credential expiry; two native recipients, one original roster/witness, same implementation on one macOS host',
    'Installed browser historical recovery and deliberate fresh-write refusal after actual witness authorization expiry; no complete cleanup without renewed authority is claimed')
ast.parse(driver,filename='run-expiry.py'); (stage/'run-expiry.py').write_text(driver)
print('Fresh expiry qualification preserves true native rejection, unsigned transport ambiguity, and already-applied versus new-write distinction')
