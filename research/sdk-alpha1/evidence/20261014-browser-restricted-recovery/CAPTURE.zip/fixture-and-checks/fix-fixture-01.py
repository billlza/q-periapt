from pathlib import Path
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-recovery'
name = 'research/continuity-identity-candidate/src/session_exchange/tests/account/recovery.rs'
sdk.copy(root / name, stage / 'failed-fixture-01.rs')
path = root / name
source = path.read_text()
old = '    let other = Group::new();\n'
new = '''    let (_, issued, pin, runtime) =
        crate::tests::session_policy_fixture(&[PrekeyQuality::ReusableBoth]);
    let other = pin.verify(issued.as_bytes(), runtime, 150).expect("different valid policy");
    assert_ne!(other.checkpoint(), group.policy.checkpoint(), "negative fixture must differ");
'''
sdk.require(source.count(old) == 1, 'negative fixture marker')
path.write_text(source.replace(old, new).replace('other.policy.historical()', 'other.historical()'))
source = (stage / 'check-enrollment-01.py').read_text().replace('format-enrollment-01', 'format-enrollment-02').replace('ENROLLMENT_INPUTS_01', 'ENROLLMENT_INPUTS_02').replace('enrollment-test-01', 'enrollment-test-02')
(stage / 'check-enrollment-02.py').write_text(source)
print('Preserved failed fixture: Group policies were intentionally deterministic and identical; negative now verifies a different allowed-mode policy checkpoint')
