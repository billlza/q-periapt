"""Loopback witness faults after actual authenticated Commit/Applied exchanges."""
from contextlib import contextmanager
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import json
import re
import subprocess
import threading
import time
from urllib.parse import urlsplit, parse_qs

@contextmanager
def serving(web, output, private, binary, peer_binary):
    captures = output / 'captures'; captures.mkdir(mode=0o700)
    traces = output / 'witness'; traces.mkdir(mode=0o700)
    records, locks, counter = {}, {}, {}
    failures, faulted = [], set()
    peers, peer_faulted = {}, set()
    peer_traces = output / 'peer'; peer_traces.mkdir(mode=0o700)
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(web), **kwargs)
        def setup(self): self.request.settimeout(10); super().setup()
        def log_message(self, *args): pass  # Public protocol receipts below.
        def end_headers(self):
            self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
            self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
            self.send_header('Cache-Control', 'no-store')
            super().end_headers()
        def do_GET(self):
            peer = re.fullmatch(r'/peer-status/([a-z0-9-]+)', self.path)
            if peer:
                self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers()
                self.wfile.write(json.dumps(peers.get(peer[1], [])).encode()); return
            match = re.fullmatch(r'/status/([a-z0-9-]+)', self.path)
            if match:
                self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers()
                self.wfile.write(json.dumps(records.get(match[1], [])).encode()); return
            super().do_GET()
        def peer(self, case, slot, mode, data):
            if mode not in ('normal', 'drop-ack', 'after-effect', 'reject-effect', 'hold-peer') or not 10 <= len(data) <= 32768 or data[:8] != b'QPCXCH01':
                self.send_error(400); return
            if self.headers.get('Cookie') or self.headers.get('Authorization'):
                self.send_error(400); return
            directory = private / case / 'recipients' / str(slot)
            if not (directory / 'peer/PUBLIC.json').is_file(): self.send_error(404); return
            lock = locks.setdefault(case, threading.Lock())
            if not lock.acquire(blocking=False): self.send_error(503); return
            try:
                number = len(peers.get(case, [])) + 1
                folder = peer_traces / case / f'{number:03}'
                folder.mkdir(mode=0o700, parents=True)
                request = folder / 'request.bin'; reply = folder / 'reply.bin'
                with request.open('xb') as stream: stream.write(data)
                kind = data[8]; key = (case, slot, mode)
                trigger = kind == 3 and mode != 'normal' and key not in peer_faulted
                if trigger: peer_faulted.add(key)
                effect = mode if trigger and mode in ('after-effect', 'reject-effect') else 'normal'
                started_ns = time.monotonic_ns()
                with (folder / 'native.stdout').open('xb') as out, (folder / 'native.stderr').open('xb') as err:
                    result = subprocess.run([str(peer_binary), 'handle', str(directory), str(request), str(reply), str(folder), effect],
                        stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=30, check=False)
                record = {'native_elapsed_ms': (time.monotonic_ns() - started_ns) / 1e6, 'number': number, 'slot': slot, 'kind': kind, 'mode': mode, 'trigger': trigger,
                          'returncode': result.returncode, 'request_sha256': hashlib.sha256(data).hexdigest()}
                if result.returncode:
                    if effect not in ('after-effect', 'reject-effect') or 'Application' not in (folder / 'native.stderr').read_text():
                        raise ValueError('unexpected native peer failure: ' + case + '/' + str(number))
                    record['application_unconfirmed'] = True
                    peers.setdefault(case, []).append(record)
                    (folder / 'RECORD.json').write_text(json.dumps(record, indent=2) + '\n')
                    self.send_error(503); return
                body = reply.read_bytes()
                record.update(json.loads((folder / 'native.stdout').read_text()))
                record['reply_sha256'] = hashlib.sha256(body).hexdigest()
                peers.setdefault(case, []).append(record)
                (folder / 'RECORD.json').write_text(json.dumps(record, indent=2) + '\n')
            except Exception as error:
                failures.append(str(error)); self.send_error(500); return
            finally: lock.release()
            if trigger and mode in ('drop-ack', 'hold-peer'):
                if mode == 'hold-peer': time.sleep(7)
                self.close_connection = True; return
            self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.send_header('Content-Length', str(len(body))); self.end_headers()
            try: self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError) as error:
                failures.append('unexpected peer disconnect: ' + case + '/' + str(number) + ': ' + type(error).__name__)

        def do_POST(self):
            target = urlsplit(self.path)
            capture = re.fullmatch(r'/capture/([a-z0-9-]+)\.bin|/capture/([a-z0-9-]+-genesis)\.json', target.path)
            witness = re.fullmatch(r'/witness/([a-z0-9-]+)', target.path)
            length = self.headers.get('Content-Length', '')
            if self.headers.get('Origin') != origin or not length.isdecimal() or not 0 < int(length) <= 131072:
                self.send_error(400); return
            data = self.rfile.read(int(length))
            if len(data) != int(length): self.send_error(400); return
            progress = re.fullmatch(r'/progress/([a-z0-9-]+)\.json', target.path)
            if progress:
                if len(data) > 2048: self.send_error(413); return
                record = json.loads(data)
                if set(record) != {'heldAt', 'until', 'runtimeCreated'} or record['runtimeCreated'] is not True or not record['heldAt'] < record['until']:
                    self.send_error(400); return
                with (output / (progress[1] + '-expiry-held.json')).open('xb') as stream: stream.write(data)
                self.send_response(201); self.end_headers(); self.wfile.write(b'observed'); return
            peer = re.fullmatch(r'/peer/([a-z0-9-]+)/([01])', target.path)
            if peer:
                modes = parse_qs(target.query)
                if set(modes) != {'mode'} or len(modes['mode']) != 1: self.send_error(400); return
                self.peer(peer[1], int(peer[2]), modes['mode'][0], data); return
            if capture:
                name = capture[1] + '.bin' if capture[1] else capture[2] + '.json'
                try:
                    with (captures / name).open('xb') as stream: stream.write(data)
                except FileExistsError: self.send_error(409); return
                self.send_response(201); self.end_headers(); self.wfile.write(b'captured'); return
            if not witness or len(data) != 3674 or self.headers.get('Cookie') or self.headers.get('Authorization'):
                self.send_error(400); return
            case = witness[1]; directory = private / case
            query = parse_qs(target.query)
            if set(query) != {'mode', 'cut'} or len(query['mode']) != 1 or len(query['cut']) != 1:
                self.send_error(400); return
            mode, cut = query['mode'][0], query['cut'][0]
            genesis = captures / (case + '-genesis.json')
            if mode not in ('normal', 'drop-advance', 'hold-advance', 'expired-denial') or not cut.isdecimal() or not 0 <= int(cut) <= 32 or not directory.is_dir() or not genesis.is_file():
                self.send_error(400); return
            lock = locks.setdefault(case, threading.Lock())
            if not lock.acquire(blocking=False): self.send_error(503); return
            try:
                number = counter.get(case, 0) + 1; counter[case] = number
                folder = traces / case; folder.mkdir(mode=0o700, exist_ok=True)
                prefix = folder / f'{number:03}'
                request = prefix.with_suffix('.request'); reply = prefix.with_suffix('.reply'); trace = prefix.with_suffix('.json')
                with request.open('xb') as stream: stream.write(data)
                with prefix.with_suffix('.stdout').open('xb') as out, prefix.with_suffix('.stderr').open('xb') as err:
                    result = subprocess.run([str(binary), 'handle', str(directory), str(genesis), str(request), str(reply), str(trace)],
                        stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=10, check=False)
                if result.returncode and mode == 'expired-denial' and data[204] == 2 and prefix.with_suffix('.stderr').read_text() == 'Error: Rejected(Validity)\n':
                    record = {'number':number,'mode':mode,'cut':cut,'trigger':False,
                        'request_tag':2,'request_sha256':hashlib.sha256(data).hexdigest(),
                        'native_rejected':'Validity','native_returncode':result.returncode,
                        'authenticated_reply':False,'advance_applied_reply':False}
                    records.setdefault(case, []).append(record)
                    (folder / 'RECORDS.json').write_text(json.dumps(records[case],indent=2)+'\n')
                    self.send_error(403); return
                if result.returncode: raise ValueError('native witness failed: ' + case + '/' + str(number))
                body = reply.read_bytes()
                if len(body) != 3659: raise ValueError('native reply size')
                record = json.loads(trace.read_text())
                key = (case, cut, mode)
                trigger = mode in ('drop-advance', 'hold-advance') and key not in faulted and record['advance_applied_reply']
                if trigger: faulted.add(key)
                record.update(number=number, mode=mode, cut=cut, trigger=trigger,
                    request_sha256=hashlib.sha256(data).hexdigest(), reply_sha256=hashlib.sha256(body).hexdigest())
                records.setdefault(case, []).append(record)
                (folder / 'RECORDS.json').write_text(json.dumps(records[case], indent=2) + '\n')
            except Exception as error:
                failures.append(str(error)); self.send_error(500); return
            finally: lock.release()
            if trigger:
                if mode == 'hold-advance': time.sleep(7)
                self.close_connection = True; return
            self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.send_header('Content-Length', str(len(body))); self.end_headers()
            try: self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError) as error:
                failures.append('unexpected disconnect: ' + case + '/' + str(number) + ': ' + type(error).__name__)
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler); server.daemon_threads = False
    origin = f'http://127.0.0.1:{server.server_port}'
    thread = threading.Thread(target=server.serve_forever); thread.start()
    try: yield origin, records, peers, failures
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)
        if thread.is_alive(): raise RuntimeError('fixture server did not stop')
