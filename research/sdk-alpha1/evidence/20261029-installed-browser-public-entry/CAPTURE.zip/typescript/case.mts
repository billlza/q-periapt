import { QPeriaptContinuityPolicyRequest } from 'q-periapt-sdk-wasm/web';
const operation: Uint8Array = QPeriaptContinuityPolicyRequest.new_operation_id();
void operation;
