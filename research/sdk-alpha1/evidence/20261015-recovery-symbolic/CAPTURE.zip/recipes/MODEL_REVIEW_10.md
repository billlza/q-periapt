# Recovery transition research model review

This is a one-exchange symbolic projection, not the complete Continuity protocol,
not an implementation refinement, and not a computational PQ recovery proof.
Initial old root knowledge is unconditional. A separate Cut discloses both
wrapping keys. The adversary may obtain any previously stored ciphertext,
including images written after Cut, reveal entropy, or reveal identity keys.
The signer-file rule exposes the encrypted signing file under the appropriate
wrapping-key derivative; it is classified as identity exposure because Cut also
grants that wrapping key. No hypothesis claims that a full host snapshot leaves
signers independent.

The positive formula requires Cut before generation and encapsulation
reservations, no identity or entropy disclosure, and no obtained record created
after Cut. These are sufficient-premise candidates, not minimal conditions.
Negative existential queries require known pre-cut generation reservations to
expose a later confirmed message, and later phase-8 storage access to defeat
fresh reservations. Every query remains unaccepted until an exact terminal
summary verifies it; a parsed or closed theory and exit code zero alone do not
qualify a lemma. Bounded witness search is not a universal security proof.

Phase correspondence follows Control encode/decode, response Plan and completion
Step in the candidate rekey sources. Phase 3 retains the generation token;
phase 4 retains encapsulation entropy; phases 5-7 and 9 retain the pending root;
phase 8 stores the new active root before local receipt acceptance. Stage zero
after receipt has the new root and no pending plan. The old root is already
public in this projection, so the setup omits an otherwise redundant phase-zero
snapshot of that root. Each commit retains a persistent encrypted record.
Interrupted computation is abstracted as staying in the previous durable phase;
real fsync, witness admission, locking and rollback resistance are not proved.

The signature and confirmation checks are separate Eq actions enforced by the
Equality restriction in transition-07 onward, matching the source's verification
structure. Complete authenticated public wires remain in local state. Later
public bodies bind hashes of earlier wires, as the Rust prefix constructors do.
The abandoned transition-06 used additional signature provenance facts and an
adversary signing rule; it is not the selected model.

Cryptographic abstraction is explicit: a perfect KEM equation returns a fresh
symbolic encapsulated secret. The concrete hybrid combiner, ML-KEM assumptions,
known classical contribution and reservation-to-secret computation are not
proved by that equation. Hash constructors abstract distinct KDF/confirmation
purposes; they do not prove the real HKDF extraction/PRF hypotheses. Perfect
signatures omit known ML-DSA signing-coin side information, which requires its
own argument. Signature files/identity-key disclosure are modeled separately.

An application event encrypts a fresh symbolic payload under a direction-bound
epoch key. It does not model the concrete per-message chain, nonce, ACK,
application-consumption accounting, old-epoch retention, policy expiry or device
revocation. No claim about those boundaries, exact maximum exposure, later
exchanges or an epoch-three recovery point follows from this projection.

Tool history is retained: the initial system tool is Tamarin 1.10.0 / Maude 2.7.1;
the official arm64 1.12.0 / 3.5.1 assets are locally extracted after digest checks
and pass the repository version/health contract. No global install or Intel
platform change occurred. Resource limits, timeouts and heap failures are
experiment outcomes, not proofs. Oracle scripts only order and return all goals.
The proposed no_precomp annotation changes when a Snapshot premise is solved,
not its meaning; mechanically removing the annotation recovers identical rules,
equations and lemma text.
