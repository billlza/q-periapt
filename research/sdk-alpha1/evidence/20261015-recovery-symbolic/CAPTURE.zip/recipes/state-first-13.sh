#!/bin/sh
exec /opt/homebrew/opt/python@3.14/bin/python3.14 -I -S -B /Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/artifact/python_bootstrap.py /Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-recovery-symbolic-20261015/state-first-13.py "$@"
