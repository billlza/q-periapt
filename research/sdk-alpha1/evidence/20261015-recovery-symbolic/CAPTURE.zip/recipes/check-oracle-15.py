"""Inspect public proof logs for complete permutations, preserving partial calls."""
from pathlib import Path
import json,re
stage=Path(__file__).resolve().parent
rows=[]
for path in sorted(stage.glob('executable-*.stderr')):
    data=path.read_text()
    calls=data.split('>>>>>>>>>>>>>>>>>>>>>>>> START INPUT')[1:]
    complete=0;partial=0
    for call in calls:
        if '>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call' not in call:
            partial+=1
            continue
        call=call.split('>>>>>>>>>>>>>>>>>>>>>>>> END Oracle call',1)[0]
        if '>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT' not in call:
            raise ValueError('missing oracle output boundary: '+path.name)
        source,output=call.split('>>>>>>>>>>>>>>>>>>>>>>>> START OUTPUT',1)
        indices=[int(x) for x in re.findall(r'^\s*(\d+):',source,re.M)]
        lines=[line.strip() for line in output.splitlines() if line.strip()]
        if any(not line.isdecimal() for line in lines):
            raise ValueError('non-index oracle output: '+path.name)
        ranked=[int(line) for line in lines]
        if len(indices)!=len(set(indices)) or sorted(indices)!=sorted(ranked):
            raise ValueError('oracle dropped, duplicated or invented a goal: '+path.name)
        complete+=1
    rows.append({'file':path.name,'complete_calls':complete,'partial_calls':partial})
print(json.dumps({'rows':rows,'scope':'Only complete logged oracle calls are checked. An interrupted final call does not count as verified.'},indent=2))
