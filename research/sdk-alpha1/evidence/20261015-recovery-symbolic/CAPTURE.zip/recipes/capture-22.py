from pathlib import Path
import hashlib,json,re,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
prefix=stage/'origin-18';receipt=json.loads(prefix.with_suffix('.json').read_text())
sdk.require(receipt['returncode']==0 and not receipt['timed_out'],'origin proof not terminal-successful')
raw=prefix.with_suffix('.stdout').read_text();parts=raw.split('summary of summaries:');sdk.require(len(parts)==2,'missing unique proof summary')
expected={'generation_secret_origin':('all-traces','verified',182),
 'recovery_is_executable':('exists-trace','analysis incomplete',1),
 'clean_reservation_recovers_symbolic_message_secrecy':('all-traces','analysis incomplete',1),
 'pre_cut_generation_reservation_remains_exposed':('exists-trace','analysis incomplete',1),
 'later_storage_access_defeats_fresh_reservations':('exists-trace','analysis incomplete',1)}
for name,(kind,status,steps) in expected.items():
 line=f'  {name} ({kind}): {status} ({steps} steps)'
 sdk.require(parts[-1].splitlines().count(line)==1,'unexpected lemma summary: '+name)
checked=root/'research/continuity-recovery-symbolic/protected-state.spthy'
sdk.require(checked.read_bytes()==(stage/'transition-17.spthy').read_bytes(),'checked-in theory differs from proved input')
sdk.require(re.findall(r'^lemma\s+(\w+)',checked.read_text(),re.M)==list(expected),'lemma inventory differs')
sdk.require(json.loads((stage/'tool-contract-09.json').read_text())['returncode']==0,'fixed tool contract failed')
files={}
def add(path,name):
 sdk.require(name not in files,'duplicate capture member');files[name]=sdk.snapshot(path,maximum=64*1024**2).data
for path in stage.iterdir():
 if path.is_file() and path.suffix in {'.py','.sh','.spthy','.md'} and path.name not in {'prove-19.py'}:
  add(path,'recipes/'+path.name)
for name in ['proof-01','tool-01','executable-03','executable-04','executable-05','executable-06','executable-07','executable-09','executable-10','executable-11','executable-12','executable-13','executable-14','origin-16','origin-17','origin-18','explicit-executable-20','maude-download-08','tamarin-download-08','architecture-08','dependencies-08','maude-version-08','tamarin-version-08','tool-contract-09','parse-10']:
 for suffix in ['.json','.stdout','.stderr']:add(stage/(name+suffix),'receipts/'+name+suffix)
for name in ['TOOLS_08.json','SUPERSEDED_02.json','ANNOTATION_10.json','WITNESS_REVIEW_12.json','STORAGE_PROJECTION_13.json']:
 add(stage/name,'receipts/'+name)
for path in (root/'research/continuity-recovery-symbolic').iterdir():
 if path.is_file():add(path,'research/'+path.name)
for name in ['src/durable/messages/rekey.rs','src/durable/messages/rekey/response.rs','src/durable/messages/rekey/completion.rs','src/crypto.rs','src/crypto/persistence.rs']:
 add(root/'research/continuity-identity-candidate'/name,'implementation/'+name)
output=root/'research/sdk-alpha1/evidence/20261015-recovery-symbolic';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'format':1,'base_commit':'29c6b052701645065cfe93472d019e84db1f637b','capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,
 'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},'verified_theory_sha256':sdk.snapshot(checked).sha256,
 'verified_lemmas':['generation_secret_origin'],'unproved_lemmas':[n for n in expected if n!='generation_secret_origin'],
 'verified_steps':182,'toolchain_contract':True,'global_installation_changed':False,'production_code_changed':False,'release_claim_eligible':False,
 'live_followup_included':False,'scope':'One provenance lemma in an ideal protected-state, independent-owner, one-exchange projection; no complete recovery or computational proof.'}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.namelist())==len(set(z.namelist()))==len(files),'archive member census differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'archive member digest differs')
 sdk.require(hashlib.sha256(z.read('research/protected-state.spthy')).hexdigest()==manifest['verified_theory_sha256'],'archived theory differs')
sdk.write_json(output/'READBACK.json',{'completed':True,'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemma_count':1,'unproved_lemma_count':4,'private_runtime_data_selected':False})
print(json.dumps({'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemmas':1,'unproved_lemmas':4}))
