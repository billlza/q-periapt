from pathlib import Path,PurePosixPath
import hashlib,json,stat,tarfile,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;destination=stage/'tools-08';destination.mkdir()
assets=[
 ('maude','https://github.com/maude-lang/Maude/releases/download/Maude3.5.1/Maude-3.5.1-macos-arm64.zip','95851274f57b3853aab833674e2b770ed800f38fb1f3d03c97dcac56346c13dc'),
 ('tamarin','https://github.com/tamarin-prover/tamarin-prover/releases/download/1.12.0/tamarin-prover-1.12.0.arm64_tahoe.bottle.tar.gz','c4174f9f850d31243473d1bc8c04eb20117b28ec5a66276078768b58ef6ee9fd')]
records=[]
for label,url,digest in assets:
 archive=destination/url.rsplit('/',1)[1]
 sdk.command(['/usr/bin/curl','--fail','--location','--connect-timeout','15','--max-time','120','--output',str(archive),url],stage/(label+'-download-08'),root)
 snap=sdk.snapshot(archive,maximum=64*1024**2);sdk.require(snap.sha256==digest,'official release asset digest differs')
 output=destination/label;output.mkdir()
 total=0
 if label=='maude':
  with zipfile.ZipFile(archive) as z:
   for member in z.infolist():
    path=PurePosixPath(member.filename)
    sdk.require(not path.is_absolute() and '..' not in path.parts and not stat.S_ISLNK(member.external_attr>>16),'unsafe archive member')
    total+=member.file_size;sdk.require(total<=256*1024**2,'archive expands beyond bound')
   z.extractall(output)
 else:
  with tarfile.open(archive) as z:
   members=z.getmembers()
   for member in members:
    path=PurePosixPath(member.name)
    sdk.require(not path.is_absolute() and '..' not in path.parts and (member.isfile() or member.isdir()),'unsafe archive member')
    total+=member.size;sdk.require(total<=256*1024**2,'archive expands beyond bound')
   z.extractall(output,filter='data')
 records.append({'name':label,'url':url,'sha256':digest,'bytes':snap.size,'expanded_bytes':total})
maude=destination/'maude/maude';tamarin=destination/'tamarin/tamarin-prover/1.12.0/bin/tamarin-prover'
sdk.require(maude.is_file() and tamarin.is_file(),'expected executables missing');maude.chmod(0o755)
sdk.command(['/usr/bin/file',str(maude),str(tamarin)],stage/'architecture-08',root)
sdk.command(['/usr/bin/otool','-L',str(tamarin)],stage/'dependencies-08',root)
sdk.command([str(maude),'--version'],stage/'maude-version-08',root)
sdk.command([str(tamarin),'--with-maude='+str(maude),'--version'],stage/'tamarin-version-08',root)
sdk.write_json(stage/'TOOLS_08.json',{'completed':True,'assets':records,'maude':str(maude),'tamarin':str(tamarin),'global_installation_changed':False,'intel_target_added':False})
print('Pinned arm64 formal tools downloaded, digest checked, extracted locally and executed')
