from pathlib import Path
import json,os,signal,subprocess,time
root=Path.cwd();stage=Path(__file__).resolve().parent
tools=json.loads((stage/"TOOLS_08.json").read_text())
argv=[tools['tamarin'],'--with-maude='+tools['maude'],str(stage/'transition-17.spthy'),'--prove=generation_secret_origin','--heuristic=O','--oraclename='+str(stage/'state-first-14.sh'),'--stop-on-trace=DFS','--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS']
start=time.monotonic();timed_out=False
with (stage/'origin-17.stdout').open('xb') as out,(stage/'origin-17.stderr').open('xb') as err:
 process=subprocess.Popen(argv,stdout=out,stderr=err,cwd=root,start_new_session=True)
 (stage/'LIVE_17.json').write_text(json.dumps({'pid':process.pid,'argv':argv,'timeout_seconds':180})+'\n')
 try:code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(process.pid,signal.SIGINT)
  try:code=process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
row={'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start}
(stage/'origin-17.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
if timed_out or code:raise SystemExit(1)
