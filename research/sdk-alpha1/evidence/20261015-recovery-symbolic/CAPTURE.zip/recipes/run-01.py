from pathlib import Path
import os,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.command(['/opt/homebrew/bin/tamarin-prover','--version'],stage/'tool-01',root)
sdk.command(['/opt/homebrew/bin/tamarin-prover',str(stage/'transition-01.spthy'),'--prove','--derivcheck-timeout=60'],stage/'proof-01',root)
print('Initial symbolic proof invocation terminated successfully; inspect individual lemmas before acceptance')
