"""Rank proof goals; return every index, without changing rules or branches."""
import re,sys
rows=[]
for line in sys.stdin:
 match=re.match(r'\s*(\d+):(.*)',line)
 if not match:
  continue
 index,text=match.groups()
 state=any(name+'(' in text or name+' (' in text for name in (
  'Final8','Receipt9','Final7','Response6','Response5','Response4','Offer3','Offer2','Offer1',
  'OfferStart','ResponseStart','CanSend','Signer','Wrap','CutPermit','Stored','SignerFile','Entropy',
  'Pinned','Confirmed','Message','Cut','KeyReserved','EncapReserved','Saved','Snapshot','CapturedPhase'))
 fresh='KU( ~' in text or 'KU(~' in text
 signature='sign(' in text and 'KU' in text
 split=text.lstrip().startswith(('splitEqs(', 'disjunction('))
 rows.append((0 if state or split else 1 if fresh else 2 if signature else 3,int(index)))
for _,index in sorted(rows):print(index)
