"""Rank all state goals before knowledge goals, then prefer smaller terms."""
import re
import sys

names = (
    'Final8', 'Receipt9', 'Final7', 'Response6', 'Response5', 'Response4',
    'Offer3', 'Offer2', 'Offer1', 'OfferStart', 'ResponseStart', 'CanSend',
    'Signer', 'Wrap', 'CutPermit', 'Stored', 'SignerFile', 'Entropy',
    'CapturedRecord', 'CapturedSigner', 'WrappingExposed', 'Pinned',
    'Confirmed', 'Message', 'Cut', 'KeyReserved', 'EncapReserved',
    'Saved', 'Snapshot', 'CapturedPhase',
)
rows = []
for line in sys.stdin:
    match = re.match(r'\s*(\d+):(.*)', line)
    if not match:
        continue
    index, text = match.groups()
    state = any(name + '(' in text or name + ' (' in text for name in names)
    split = text.lstrip().startswith(('splitEqs(', 'disjunction('))
    rows.append((0 if state else 1 if split else 2, len(text), int(index)))
for _, _, index in sorted(rows):
    print(index)
