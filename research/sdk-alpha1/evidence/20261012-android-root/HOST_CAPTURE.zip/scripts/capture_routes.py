from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();work=root/'target/continuity-android-root-next';out=work/'routes-capture';out.mkdir()
run=json.loads((work/'root-runtime-v3/STATE.json').read_text());assert run['completed'] and not run['live_producer']
assert all(hashlib.sha256((work/'source'/n).read_bytes()).hexdigest()==d for n,d in run['source_sha256'].items())
routes={'original':(34,6),'transition':(36,6),'bound-transition':(37,7),'adoption':(33,5)}
records='original.request authority-created prepared activated.request original.identity roster-peer-unassociated roster-peer-associated roster-connected roster-unknown roster-effect-before root-target.request root-target.prepared root-begun root-preparing root-retained root-retained-replayed root-activation-unknown root-activated root-connected root-unknown root-acknowledged root-effect-before root-effect-after root-effect-count root-inventory root-report-proposal root-report-unknown root-complete-report root-tampered-report root-ack-proposal root-wrong-purpose root-journal-unknown root-signer-unknown root-verified root-close-revoked root-original-effect-after process-count'.split()
inputs='sdk-policy sdk-signature sdk-root family policy-root policy-version policy-digest protocol-policy enrollment-root enrollment-intent witness-id witness-public authority-id authority-application authority-checkpoint grant-certificate grant-roster trusted-account trusted-roster-version trusted-roster-digest connection-session connection-message root-route root-plan root-retirement root-inventory-receipt root-report-proposal root-report-receipt root-ack root-target-account'.split()
target='sdk-policy sdk-signature sdk-root family policy-root policy-version policy-digest protocol-policy enrollment-root enrollment-intent grant-certificate grant-roster trusted-account trusted-roster-version trusted-roster-digest'.split()
members={}
def add(name,path):
 assert name not in members and path.is_file() and not path.is_symlink();members[name]=path.read_bytes()
for profile in ('debug','release'):
 for route in routes:
  directory=work/'root-runtime-v3'/(profile+'-'+route)
  for name in ('execution.json','execution.stdout','execution.stderr','driver.py'):add(profile+'-'+route+'/'+name,directory/name)
  for trust in ('fixed','recoverable'):
   case=directory/'cases'/('signed-'+trust);prefix=profile+'-'+route+'/signed-'+trust+'/'
   selected=records.copy();public=inputs.copy()
   if route!='adoption':selected+=['root-bad-freeze','root-bound','root-bound-replayed'];public+=['root-freeze']
   if route!='original':selected+=['root-original-target.request','root-original-target.prepared'];public+=['root-original-target-account','root-noncommit']
   if route=='bound-transition':selected+=['root-original-bound']
   if route in ('transition','bound-transition'):public+=['root-next-plan']
   if route=='adoption':public+=['root-winner']
   for name in selected:
    add(prefix+name,case/name)
    for suffix in ('.stdout','.stderr'):
     path=case/(name+suffix)
     if path.exists():add(prefix+name+suffix,path)
   for name in public:add(prefix+'inputs/'+name,case/'inputs'/name)
   for name in target+['connection-session','connection-message','connection-initiation']:
    add(prefix+'inputs/root-target/'+name,case/'inputs/root-target'/name)
   if route!='original':
    for name in target:add(prefix+'inputs/root-original-target/'+name,case/'inputs/root-original-target'/name)
for name in run['source_sha256']:add('source/android/'+name,work/'source'/name)
for name in ['tests/android.rs',*[str(p.relative_to(work/'c-consumer')) for p in sorted((work/'c-consumer/tests/common').glob('android_root*.rs'))], 'tests/common/android_retirement.rs','tests/common/peer_bundle.rs']:
 add('source/c-consumer/'+name,work/'c-consumer'/name)
for name in ['qpc_owner.h','run_root_v3.py','build_harness_v3.py','build_boundary_v6.py','capture_routes.py']:add('scripts/'+name,work/name)
for name in ['STATE.json','catalog.stdout','clippy.json','clippy.stdout','clippy.stderr']:add('harness/'+name,work/'harness-v3'/name)
add('runtime/STATE.json',work/'root-runtime-v3/STATE.json');add('boundary/STATE.json',work/'boundary-v6/STATE.json')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in sorted(members.items())},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 for profile in ('debug','release'):
  for route,(count,cuts) in routes.items():
   for trust in ('fixed','recoverable'):
    prefix=profile+'-'+route+'/signed-'+trust+'/'
    read=lambda name:z.read(prefix+name)
    assert read('process-count')==count.to_bytes(8,'big') and read('inputs/root-route')==route.encode()
    assert read('original.request')==read('activated.request')
    assert read('root-begun')==read('root-preparing')==(1).to_bytes(4,'big')
    if route!='adoption':
     assert read('root-bound')==read('root-bound-replayed') and read('root-bound').startswith((b'QPARPL01',b'QPARPL02'))
     assert read('root-bad-freeze')==(102).to_bytes(4,'big')
    if route!='original':
     assert read('inputs/root-original-target-account')==read('inputs/root-original-target/trusted-account')!=read('inputs/root-target-account')
     assert read('root-original-target.request')!=read('root-target.request')
     assert read('inputs/root-original-target/enrollment-root')!=read('inputs/root-target/enrollment-root')
    checkpoint=read('root-retained');assert checkpoint==read('root-retained-replayed') and len(checkpoint)==72
    assert checkpoint[:32]==read('inputs/authority-application') and checkpoint[32:40]==(2).to_bytes(8,'big')
    assert checkpoint[40:]==read('inputs/root-target/trusted-account')==read('inputs/root-target-account')!=read('inputs/trusted-account')
    assert read('inputs/root-target/enrollment-root')!=read('inputs/enrollment-root')
    assert read('root-connected')!=read('roster-connected') and read('root-unknown')==read('root-acknowledged')
    assert read('root-effect-before')==read('root-effect-after') and read('root-effect-count')==(2).to_bytes(8,'big')
    assert read('roster-effect-before')==read('root-original-effect-after')
    assert read('root-complete-report')==read('root-verified') and read('root-verified')[8:321]==read('root-inventory')
    proposal=read('root-report-proposal');assert len(proposal)==353 and proposal[8:321]==read('root-inventory')
    assert proposal==read('root-report-unknown')==read('root-ack-proposal')==read('root-journal-unknown')==read('root-signer-unknown')
    for name,code in [('root-close-revoked',202),('root-activation-unknown',218),('root-tampered-report',208),('root-wrong-purpose',102)]:assert read(name)==code.to_bytes(4,'big')
record={'completed_host_routes':list(routes),'host_processes':560,'actual_process_cuts':96,'archive_members':len(members),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_member_hashes_verified':True,'public_bindings_reread':16,'private_keys_or_journals_archived':False,'ART_root_qualified':False,'main_integrated':False,'additional_phone_required':False,'scope':'Android API-owned identities; independently approved original and distinct replacement targets; native issuer/witness, existing C counterparty. Public archive readback does not authenticate signatures or MACs; native execution does.'}
(out/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
