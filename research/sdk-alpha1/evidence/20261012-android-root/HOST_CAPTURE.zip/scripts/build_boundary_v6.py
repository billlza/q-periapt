from pathlib import Path
import hashlib,json,shutil,zipfile
import rust_sdk_profile as sdk

root=Path.cwd();work=root/'target/continuity-android-root-next';source=work/'source'
output=work/'boundary-v6';output.mkdir()
prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())
assert prior['completed'] and not prior['live_producer']
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
def source_hashes():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
before=source_hashes()
state={'completed':False,'live_producer':True,'source_sha256':before,'scope':'Isolated root adapter strict compile, public framing and real JNI rejection. No root lifecycle or physical execution claim.'}
(output/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def run(argv,label):return sdk.command([str(x) for x in argv],output/label,root)
try:
 classes=output/'classes';tests=output/'tests';classes.mkdir();tests.mkdir()
 run([jdk/'bin/javac','--release','11','-Xlint:all','-Werror','-d',classes,*sorted((source/'src/main/java').rglob('*.java'))],'main-compile')
 jar=output/'qperiapt-continuity-android.jar'
 with zipfile.ZipFile(jar,'x',zipfile.ZIP_DEFLATED) as z:
  for path in sorted(classes.rglob('*.class')):z.write(path,str(path.relative_to(classes)))
 run([jdk/'bin/javac','--release','17','-Xlint:all','-Werror','-cp',jar,'-d',tests,*sorted((source/'src/test/java').glob('*.java'))],'test-compile')
 clang=Path(run(['xcrun','--sdk','macosx','--find','clang'],'clang-path').decode().strip()).resolve(strict=True)
 platform=Path(run(['xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()).resolve(strict=True)
 state['profiles']={}
 for profile in ('debug','release'):
  installed=output/profile;installed.mkdir()
  library=prior['native']['execution'][profile]['binaries']['C_library'];original=Path(library['path'])
  assert hashlib.sha256(original.read_bytes()).hexdigest()==library['sha256']
  shutil.copy2(original,installed/original.name)
  run([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-O0' if profile=='debug' else '-O2',
       '-isysroot',platform,'-I'+str(work),'-I'+str(jdk/'include'),'-I'+str(jdk/'include/darwin'),'-dynamiclib',
       *sorted((source/'jni').glob('*.c')),'-L'+str(installed),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path',
       '-o',installed/'libqperiapt_continuity_jni.dylib'],profile+'-bridge')
  command=[jdk/'bin/java','--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(installed),'-cp',str(jar)+':'+str(tests)]
  assert run(command+['dev.qperiapt.continuity.android.RootBridgeProbe'],profile+'-root')==b'root:bridge:passed\n'
  assert run(command+['dev.qperiapt.continuity.android.RetiredBridgeProbe'],profile+'-retirement')==b'retirement:bridge:passed\n'
  assert run(command+['dev.qperiapt.continuity.android.BridgeProbe'],profile+'-existing-boundaries')==b'configuration:bridge:passed\n'
  state['profiles'][profile]={'native_sha256':library['sha256'],'bridge_sha256':hashlib.sha256((installed/'libqperiapt_continuity_jni.dylib').read_bytes()).hexdigest()}
 assert source_hashes()==before
 state.update(completed=True,jar_sha256=hashlib.sha256(jar.read_bytes()).hexdigest())
finally:
 state['live_producer']=False;(output/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Root adapter Debug/Release compile and JNI boundary checks passed; root lifecycle still unqualified.')
