import os, sys
mode, profile, inputs, target, output = sys.argv[1:]
probes = (('root-', 'RootOwnedProbe'), ('retired-owned-', 'RetiredOwnedProbe'), ('roster-witness-', 'RosterWitnessProbe'), ('roster-', 'RosterProbe'), ('policy-', 'PolicyProbe'), ('credential-', 'CredentialProbe'), ('authority-', 'AuthorityProbe'), (('witness-', 'managed-'), 'WitnessProbe'), ('peer-', 'PeerProbe'))
probe = next((name for prefix, name in probes if mode.startswith(prefix)), 'EnrollmentProbe')
command = ['/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java', '--enable-native-access=ALL-UNNAMED', '-Xcheck:jni', '-Djava.library.path=/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-android-root-next/boundary-v6/release', '-cp', '/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-android-root-next/boundary-v6/qperiapt-continuity-android.jar:/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-android-root-next/boundary-v6/tests']
command += ['dev.qperiapt.continuity.android.tests.' + probe, inputs, target, profile, mode, output]
os.execv(command[0], command)
