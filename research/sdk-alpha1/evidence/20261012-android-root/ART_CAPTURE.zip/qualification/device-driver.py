#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import base64,hashlib,json,os,re,subprocess,sys,zipfile
import secrets as port_random
out=Path(__file__).resolve().parent;mode,profile,inputs,target,output=sys.argv[1:];inputs=Path(inputs);output=Path(output);slot="original";variant=inputs.parent.name;route=os.environ["QPC_ROOT_ART_ROUTE"];assert route in ["original","transition","bound-transition","adoption"]
assert profile in ['fixed','recoverable'] and variant in ['signed-fixed','signed-recoverable']
assert mode.startswith(('policy-','roster-','root-')) or mode in ['authority-create','authority-peer-associate']
operation=mode
paths={}
retired=False;root_mode=mode.startswith('root-');cut=mode in ['root-begin-unknown','root-freeze-unknown','root-freeze-original','root-transition-unknown','root-adopt-unknown','root-retain-unknown','root-report-unknown','root-journal-unknown','root-signer-unknown']
label=slot+"-"+output.name;assert re.fullmatch(r'[a-z][a-z0-9.-]{0,63}',label);run=out/('device-'+route+'-'+variant);run.mkdir(mode=0o700,exist_ok=True);state_path=run/'STATE.json';s=json.loads(state_path.read_text()) if state_path.exists() else {'completed':False,'cleanup':False,'cases':[]};secrets=[]
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.root20261012'
lines=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();matches=[line for line in lines if ' device ' in line and hashlib.sha256(line.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(matches)==1;transport=re.search(r'transport_id:(\d+)',matches[0]).group(1)
def safe(text):
 for secret in secrets:text=text.replace(secret,'<redacted test TLS credential>')
 return text

def command(name,args,expected=0,timeout=30,bind_conflict=False):
 cmd=[adb,'-t',transport]+args
 try:r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
 except subprocess.TimeoutExpired:raise RuntimeError(name+' exceeded '+str(timeout)+' seconds') from None
 stdout,stderr=safe(r.stdout),safe(r.stderr)
 (run/(label+'-'+name+'.stdout')).write_text(stdout);(run/(label+'-'+name+'.stderr')).write_text(stderr);(run/(label+'-'+name+'.json')).write_text(json.dumps({'command':[safe(x) for x in cmd],'exit_code':r.returncode},indent=2)+'\n')
 if bind_conflict and r.returncode==1 and not stdout.strip() and stderr.strip()=='adb: error: cannot bind listener: Address already in use':return None
 assert (r.returncode in expected if isinstance(expected,tuple) else r.returncode==expected) and not stderr,(name,r.returncode,stderr);return stdout

def clear_maps():
 for selected in list(s.get('owned_reverse_ports',[])):
  command('reverse-remove-'+str(selected),['reverse','--remove','tcp:'+str(selected)])
  s['owned_reverse_ports'].remove(selected);state_path.write_text(json.dumps(s,indent=2)+'\n')

def cleanup():
 clear_maps()
 assert command('uninstall',['uninstall',pkg],timeout=60).strip()=='Success'
 assert not command('uninstalled',['shell','pm','list','packages','--user','0',pkg]).strip();s['cleanup']=True
try:
 if operation=='policy-create' and slot=='original':
  assert not s.get('installation_attempted') and not command('preexisting',['shell','pm','list','packages','--user','0',pkg]).strip()
  assert command('api',['shell','getprop','ro.build.version.sdk']).strip()=='37'
  assert command('abi',['shell','getprop','ro.product.cpu.abi']).strip()=='arm64-v8a'
  prepared=json.loads((out/'PREPARED_APK.json').read_text());assert prepared['completed'] and prepared['signed']
  assert hashlib.sha256((out/'consumer.apk').read_bytes()).hexdigest()==prepared['apk_sha256']
  s.update(apk_sha256=prepared['apk_sha256'],aar_sha256=prepared['aar_sha256'],installation_attempted=True);state_path.write_text(json.dumps(s,indent=2)+'\n')
  assert command('install',['install','--no-incremental','-t',str(out/'consumer.apk')],timeout=90).splitlines().count('Success')==1
 else:assert s['installation_attempted'] and not s['cleanup']
 args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation',mode,'-e','label',label,'-e','slot',slot]
 carrier=(inputs/'witness-carrier').read_text();assert carrier in ['local','signed','tls']
 names=['witness-carrier']
 if carrier!='local':names+=['witness-id','witness-public','witness-address']
 if mode=='policy-create':
  names+=['sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent']
  if profile=='recoverable':names+=['recovery-scope','recovery-root','recovery-enrollment']
 if mode in ['policy-prepare','authority-create']:names+=['grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest']
 if carrier!='local' and mode!='policy-create':
  names+=['authority-id','authority-application']
  if mode!='authority-create':names+=['authority-checkpoint']
 if carrier=='tls':names+=['witness-tls-cert','witness-tls-key','witness-tls-peer','witness-tls-name']
 if mode=='policy-target-create':names+=['target-policy-version','target-policy-digest','target-protocol-policy']
 if mode=='policy-request':names+=['renewal-operation']
 if mode.startswith('policy-stage'):names+=['renewal-request','renewal-approvals','renewal-statement']
 if mode.startswith('policy-witness-') and mode not in ['policy-witness-prepare','policy-witness-recover']:names+=['renewal-proposal']
 if mode.startswith('roster-'):
  witnessed=mode.startswith('roster-witness-');roster_peer=mode.startswith('roster-witness-peer-') if witnessed else mode.startswith('roster-peer-')
  if not witnessed or not roster_peer:names+=['renewal-roster','renewal-version','renewal-digest']
  if witnessed and not roster_peer:
   names+=['roster-operation']
   if not mode.startswith('roster-witness-prepare') and mode not in ['roster-witness-progress','roster-witness-recover','roster-witness-abandon-refused','roster-witness-resolve-local','roster-witness-activate-unmanaged']:names+=['roster-proposal']
 peer_mode=(mode.removeprefix('root-') if mode.startswith('root-peer-') else mode.removeprefix('roster-witness-') if mode.startswith('roster-witness-peer-') else mode.removeprefix('roster-') if mode.startswith('roster-peer-') else mode.removeprefix('policy-') if mode.startswith('policy-peer-') else None)
 if peer_mode and peer_mode.startswith('peer-roster-'):
  prefix='remote-roster-revoked' if peer_mode in ['peer-roster-revoke','peer-roster-revoked-reopen'] else 'remote-roster'
  names += [prefix,prefix+'-version',prefix+'-digest']
  if peer_mode=='peer-roster-reopen':names+=['remote-roster-next']
 if mode=='authority-peer-associate':names+=['authority-peer-application','peer-approved-certificate','peer-approved-roster']
 if peer_mode and not root_mode:
  names+=['peer-'+p.name for p in sorted((inputs/'peer').iterdir()) if p.is_file()]
  if peer_mode!='peer-unassociated':names+=['connection-address','connection-initiation' if peer_mode=='peer-connect' else 'connection-session']
  if peer_mode=='peer-retry' or peer_mode.startswith('peer-roster-'):names+=['connection-message']
 if root_mode:
  names=['witness-carrier','witness-id','witness-public','witness-address','authority-id','authority-application','authority-checkpoint']
  target_leaf='root-original-target' if mode.startswith('root-original-target-') else 'root-target'
  selected=inputs/target_leaf
  if mode.startswith(('root-target-','root-original-target-')):
   if mode.endswith('-create'):
    fields=['sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent']
    if profile=='recoverable':fields+=['recovery-scope','recovery-root','recovery-enrollment']
   else:fields=['grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest']
   for name in fields:names.append(name);paths[name]=selected/name
  else:
   # Approvals persist in the app's private input directory. Send each new stage's
   # fields once; the SDK reopens and authenticates those retained original bytes.
   staged={
    'root-begin-unknown':['root-route','root-plan'],
    'root-freeze-bad':['root-freeze'],
    'root-transition-unknown':['root-next-plan','root-noncommit','root-freeze'],
    'root-adopt-unknown':['root-winner','root-noncommit','root-retirement'],
    'root-retain-unknown':['root-retirement'],
    'root-prepare-report':['root-inventory-receipt'],
    'root-report-unknown':['root-report-proposal','root-report-receipt'],
    'root-journal-unknown':['root-ack'],
   }
   names += staged.get(mode,[])
   if mode=='root-begin-unknown':names+=['connection-session','connection-message']
   if peer_mode:
    for path in sorted((selected/'peer').iterdir()):
     if path.is_file():name='peer-'+path.name;names.append(name);paths[name]=path
    fields=['connection-address','connection-initiation' if peer_mode=='peer-connect' else 'connection-session']
    if peer_mode=='peer-retry':fields+=['connection-message']
    for name in fields:names.append(name);paths[name]=selected/name
 port=None
 if carrier!='local':
  address=(inputs/'witness-address').read_text();match=re.fullmatch(r'127\.0\.0\.1:(\d+)',address);assert match;port=int(match.group(1));assert 1<=port<=65535
 for name in names:
  path=paths.get(name,inputs/'peer'/name[5:] if name.startswith('peer-') else inputs/name)
  if name.startswith('target-'):path=inputs/'policy-target'/name.removeprefix('target-')
  value=base64.b64encode(path.read_bytes()).decode('ascii')
  if name in ['witness-tls-key','tls-key']:secrets.append(value)
  args+=['-e',name,value]
 args+=[pkg+'/dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation']
 assert sum(len(x.encode())+1 for x in args)<64000,'ADB invocation exceeds qualified input budget'
 ports=[] if retired or mode.startswith('authority-') or port is None else [port]
 if peer_mode and peer_mode!='peer-unassociated':
  endpoint=paths.get('connection-address',inputs/'connection-address').read_text();peer_match=re.fullmatch(r'127\.0\.0\.1:(\d+)',endpoint);assert peer_match
  peer_port=int(peer_match.group(1));assert 1<=peer_port<=65535 and peer_port not in ports;ports.append(peer_port)
 try:
  for host_port in ports:
   attempted=set()
   for attempt in range(8):
    selected=host_port if attempt==0 else 49152+port_random.randbelow(16384)
    if selected in attempted or selected in s.get('owned_reverse_ports',[]):continue
    attempted.add(selected)
    bound=command('reverse-create-'+str(selected),['reverse','--no-rebind','tcp:'+str(selected),'tcp:'+str(host_port)],bind_conflict=True)
    if bound is None:continue
    assert bound.strip()==str(selected)
    s.setdefault('owned_reverse_ports',[]).append(selected);state_path.write_text(json.dumps(s,indent=2)+'\n')
    if selected!=host_port:
     name='witness-address' if host_port==port else 'connection-address'
     position=args.index(name)+1
     assert args[position]==base64.b64encode(('127.0.0.1:'+str(host_port)).encode()).decode('ascii')
     args[position]=base64.b64encode(('127.0.0.1:'+str(selected)).encode()).decode('ascii')
    break
   else:raise RuntimeError('no available owned ADB reverse port after eight bounded attempts')
  result=command('instrument',args,expected=(0,1) if cut else 0,timeout=90)
 finally:clear_maps()
 expected=profile+':'+mode+':passed'
 if cut:
  assert 'INSTRUMENTATION_STATUS: stage=root-cut\n' in result and 'INSTRUMENTATION_STATUS_CODE: 3' in result,result
  for key,value in [('apk_sha256',s['apk_sha256']),('operation',mode),('label',label)]:assert 'INSTRUMENTATION_STATUS: '+key+'='+value+'\n' in result,result
  assert 'INSTRUMENTATION_RESULT: shortMsg=Process crashed.' in result and 'INSTRUMENTATION_RESULT: result=' not in result,result
  pid=int(re.search(r'^INSTRUMENTATION_STATUS: pid=(\d+)$',result,re.M).group(1))
  payload=base64.b64decode(re.search(r'^INSTRUMENTATION_STATUS: report=([^\n]+)$',result,re.M).group(1),validate=True)
  assert 1<=len(payload)<=65536
  if mode=='root-begin-unknown':assert payload==(1).to_bytes(4,'big')
  elif mode in ['root-retain-unknown','root-adopt-unknown']:assert len(payload)==72
  elif mode in ['root-report-unknown','root-journal-unknown','root-signer-unknown']:assert payload==(inputs/'root-report-proposal').read_bytes()
  else:assert payload.startswith((b'QPARPL01',b'QPARPL02'))
  assert not command('cut-process-absent',['shell','pidof',pkg],expected=1).strip()
 else:
  assert 'INSTRUMENTATION_RESULT: result='+expected+'\n' in result,result
  assert result.rstrip().endswith('INSTRUMENTATION_CODE: -1') and 'INSTRUMENTATION_RESULT: apk_sha256='+s['apk_sha256']+'\n' in result,result
  pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',result,re.M).group(1))
  payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',result,re.M).group(1),validate=True)
  assert len(payload)==33176 if mode=='policy-request' else 1<=len(payload)<=(65536 if root_mode else 8192)
  command('stop',['shell','am','force-stop',pkg]);assert not command('process-absent',['shell','pidof',pkg],expected=1).strip()
 assert pid not in [case['pid'] for case in s['cases']]
 with output.open('xb') as destination:destination.write(payload)
 s['cases'].append({'mode':mode,'label':label,'slot':slot,'output_name':output.name,'pid':pid,'result_sha256':hashlib.sha256(payload).hexdigest(),'installed_apk_sha256':s['apk_sha256'],'process_absent_after_operation':True,'actual_cut_observed':cut})
 if mode=='root-close-revokes':cleanup();s['completed']=True
 state_path.write_text(json.dumps(s,indent=2)+'\n')
 if cut:sys.exit(77)
 print(expected)
except BaseException as failure:
 if isinstance(failure,SystemExit) and cut and failure.code==77:raise
 if s.get('installation_attempted') and not s.get('cleanup'):cleanup()
 state_path.write_text(json.dumps(s,indent=2)+'\n');raise
