from pathlib import Path
import hashlib,json,zipfile,sys
root=Path.cwd();out=Path(__file__).resolve().parent;work=root/'target/continuity-android-root-next'
sys.path.insert(0,str(out));from public_readback import check_case
run=json.loads((out/'STATE.json').read_text());assert run['completed'] and not run['live_producer']
package=json.loads((out/'PACKAGE.json').read_text());apk=json.loads((out/'PREPARED_APK.json').read_text())
for n,d in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/n).read_bytes()).hexdigest()==d
assert hashlib.sha256((out/'consumer.apk').read_bytes()).hexdigest()==apk['apk_sha256']
assert hashlib.sha256(Path(package['aar']).read_bytes()).hexdigest()==package['aar_sha256']==apk['aar_sha256']
routes={'original':(34,6),'transition':(36,6),'bound-transition':(37,7),'adoption':(33,5)};members={}
def add(n,p):
 assert n not in members and p.is_file() and not p.is_symlink();members[n]=p.read_bytes()
with zipfile.ZipFile(work/'routes-capture/CAPTURE.zip') as host:
 for route in routes:
  for trust in ('fixed','recoverable'):
   prefix='debug-'+route+'/signed-'+trust+'/'
   names=[n.removeprefix(prefix) for n in host.namelist() if n.startswith(prefix)]
   assert names
   for name in names:add('art/'+route+'/signed-'+trust+'/'+name,out/route/'cases'/('signed-'+trust)/name)
   receipts=out/('device-'+route+'-signed-'+trust)
   for p in sorted(receipts.iterdir()):
    if p.is_file() and p.suffix in ('.json','.stdout','.stderr'):add('receipts/'+receipts.name+'/'+p.name,p)
  for name in ('execution.json','execution.stdout','execution.stderr'):add('execution/'+route+'/'+name,out/route/name)
 for profile in ('debug','release'):
  for route,(count,cuts) in routes.items():
   for trust in ('fixed','recoverable'):
    prefix=profile+'-'+route+'/signed-'+trust+'/'
    check_case(lambda n:host.read(prefix+n),route,count)
for name in package['source_sha256']:add('source/android/'+name,Path(package['source'])/name)
for name in ['run.py','QUALIFICATION_HISTORY.json','ADB_PAYLOAD_LIMIT.json','ALIGNMENT.json','READER_CHECKS.json','device-driver.py','build-aar.py','build-consumer.py','prepare-apk.py','public_readback.py','capture.py','STATE.json','OUTCOMES.json','EXECUTABLE.json','PACKAGE.json','PREPARED_APK.json','HOST_SOURCE_COHORT.json','REVISION.json','signature.stdout','signature.stderr','signature.json']:
 p=out/name
 if name=='signature.json':continue
 add('qualification/'+name,p)
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,data in sorted(members.items()):z.writestr(n,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in sorted(members.items())},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 for route,(count,cuts) in routes.items():
  for trust in ('fixed','recoverable'):
   prefix='art/'+route+'/signed-'+trust+'/'
   check_case(lambda n:z.read(prefix+n),route,count)
   device=json.loads(z.read('receipts/device-'+route+'-signed-'+trust+'/STATE.json'))
   assert device['completed'] and device['cleanup'] and not device['owned_reverse_ports']
   assert device['apk_sha256']==apk['apk_sha256'] and len(device['cases'])==count
   assert len({c['pid'] for c in device['cases']})==count
   assert sum(c['actual_cut_observed'] for c in device['cases'])==cuts
   for record in device['cases']:
    assert record['process_absent_after_operation'] and record['installed_apk_sha256']==apk['apk_sha256']
    assert hashlib.sha256(z.read(prefix+record['output_name'])).hexdigest()==record['result_sha256']
record={'completed':True,'host_routes_reread':16,'ART_routes_reread':8,'ART_processes':280,'ART_actual_process_cuts':48,'same_selected_API37_phone':True,'additional_phone_required':False,'all_apps_and_owned_reverse_maps_removed':True,'library_source_matches_host':True,'archive_members':len(members),'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'apk_sha256':apk['apk_sha256'],'aar_sha256':apk['aar_sha256'],'private_keys_or_journals_archived':False,'release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
