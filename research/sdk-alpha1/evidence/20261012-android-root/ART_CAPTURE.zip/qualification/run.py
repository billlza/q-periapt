from pathlib import Path
import hashlib,json,re,subprocess,shutil,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();out=Path(__file__).resolve().parent;work=root/'target/continuity-android-root-next'
native=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text());saved=json.loads((work/'harness-v3/STATE.json').read_text());qualified=json.loads((work/'root-runtime-v3/STATE.json').read_text())
assert saved['completed'] and not saved['live_producer'] and qualified['completed'] and not qualified['live_producer']
source=Path(saved['source']);env=native['environment'];binary=out/'android-harness';assert not binary.exists();shutil.copy2(saved['binary'],binary)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==saved['binary_sha256']==qualified['harness_sha256']
with zipfile.ZipFile(work/'routes-capture/CAPTURE.zip') as capture:
 for name in capture.namelist():
  if name.startswith('source/c-consumer/') and not name.endswith('/'):
   assert (source/name.removeprefix('source/c-consumer/')).read_bytes()==capture.read(name)
package=json.loads((out/'PACKAGE.json').read_text());assert package['completed']
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest
common={n:d for n,d in package['source_sha256'].items() if n.startswith(('src/main/','jni/'))}
assert common and all(qualified['source_sha256'][n]==d for n,d in common.items())
h={'copied_sha256':saved['binary_sha256'],'receiver':native['native']['execution']['debug']['binaries']['C_client']['path'],'same_host_qualified_library_source_count':len(common),'library_source_matches_host':True}
sdk.write_json(out/'EXECUTABLE.json',h)
state={'completed':False,'live_producer':True,'routes':{},'additional_phone_required':False}
def save(): (out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
save()
def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.root20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  record=json.loads(path.read_text())
  if not record.get('installation_attempted') or (record.get('cleanup') and not record.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
  def call(args):
   result=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(record.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);record['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();record['cleanup']=True;record['outer_cleanup']=True;path.write_text(json.dumps(record,indent=2)+'\n')
try:
 for route,(count,cuts) in {'original':(34,6),'transition':(36,6),'bound-transition':(37,7),'adoption':(33,5)}.items():
  directory=out/route;directory.mkdir();cases=directory/'cases'
  runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=h['receiver'],QPC_ROOT_ART_ROUTE=route)
  test='android_root_owned::'+route.replace('-','_')+'_account_root_replacement'
  stdout=sdk.command([str(binary),'--exact',test,'--nocapture'],directory/'execution',source,environment=runtime)
  assert stdout.count(b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 28 filtered out;')==1
  results={}
  for trust in ['fixed','recoverable']:
   case=cases/('signed-'+trust);assert (case/'process-count').read_bytes()==count.to_bytes(8,'big')
   assert (case/'root-complete-report').read_bytes()==(case/'root-verified').read_bytes()
   assert (case/'roster-effect-before').read_bytes()==(case/'root-original-effect-after').read_bytes()
   assert (case/'root-effect-before').read_bytes()==(case/'root-effect-after').read_bytes()
   assert (case/'root-effect-count').read_bytes()==(2).to_bytes(8,'big')
   device=json.loads((out/('device-'+route+'-signed-'+trust)/'STATE.json').read_text());assert device['completed'] and device['cleanup'] and not device.get('owned_reverse_ports')
   assert len(device['cases'])==count and len([c for c in device['cases'] if c.get('actual_cut_observed')])==cuts
   results[trust]={'foreign_processes':count,'actual_process_cuts':cuts,'case':str(case)}
  state['routes'][route]=results;save()
 state['completed']=True;sdk.write_json(out/'OUTCOMES.json',state['routes'])
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('root qualification and owned cleanup failed',[original,failure])
 raise
finally:
 state['live_producer']=False;save()
print('280 ART account-root calls and 48 actual process cuts passed; owned installations and mappings removed',flush=True)
