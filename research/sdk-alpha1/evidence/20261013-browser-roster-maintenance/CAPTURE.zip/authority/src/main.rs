use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json,Value};
use std::{fs,io::Read,path::Path,sync::Arc,time::{SystemTime,UNIX_EPOCH}};
type Result<T> = std::result::Result<T,Box<dyn std::error::Error>>;
fn now()->Result<u64>{Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs())}
fn read(path:&Path,max:u64)->Result<Vec<u8>>{let mut data=Vec::new();fs::File::open(path)?.take(max+1).read_to_end(&mut data)?;if data.len() as u64>max{return Err("oversize fixture input".into())}Ok(data)}
fn load(path:&Path)->Result<Value>{Ok(serde_json::from_slice(&read(path,1048576)?)?)}
fn bytes(v:&Value,key:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(key).ok_or("missing field")?.clone())?)}
fn array(v:&Value,key:&str)->Result<[u8;32]>{Ok(bytes(v,key)?.as_slice().try_into()?)}
fn number(v:&Value,key:&str)->Result<u64>{v.get(key).and_then(Value::as_u64).ok_or_else(||"missing number".into())}
fn pin(config:&Value,grant:&Value)->Result<p::AccountPin>{Ok(p::AccountPin::new(array(config,"account")?,p::PublicKey::decode(&bytes(config,"root")?)?,p::RosterCheckpoint::from_trusted_state(number(grant,"version")?,array(grant,"digest")?)?,array(config,"family")?)?)}
fn policy(v:&Value)->Result<p::VerifiedSessionPolicy>{
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(v,"sdk_policy")?,&bytes(v,"sdk_signature")?,&bytes(v,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
 let q=&v["policies"]["required"];
 let pin=p::PolicyPin::new(array(v,"family")?,p::PublicKey::decode(&bytes(v,"policy_root")?)?,p::PolicyCheckpoint::from_trusted_state(number(q,"version")?,array(q,"digest")?)?)?;
 Ok(pin.verify(&bytes(q,"wire")?,Arc::new(runtime),now()?)?)
}
fn witness(dir:&Path,v:&Value)->Result<p::AnchorStore>{
 let key=p::JournalKey::open(&dir.join("private-witness-wrap.key"))?;
 let signer=p::AnchorSigningKey::open(&dir.join("private-witness.key"),&key,p::SigningKeyId::from_trusted_state(array(v,"witness_signer_id")?)?)?;
 let store=p::AnchorStore::open(&dir.join("private-witness.redb"),key,signer,p::AnchorIdentity::from_trusted_state(array(v,"witness_id")?)?)?;
 if store.pin()?.public_key().encode()!=bytes(v,"witness_public")?{return Err("wrong witness".into())}Ok(store)
}
fn main()->Result<()>{
 let args=std::env::args().collect::<Vec<_>>();let mode=args.get(1).ok_or("mode")?;let dir=Path::new(args.get(2).ok_or("directory")?);let config=load(&dir.join("PUBLIC.json"))?;
 match mode.as_str(){
  "target" if args.len()==7=>{
   let grant=load(Path::new(&args[3]))?;let output=Path::new(&args[4]);let version:u64=args[5].parse()?;let ttl:u64=args[6].parse()?;
   let wrap=p::JournalKey::open(&dir.join("private-wrap.key"))?;let root=p::RootSigningKey::open(&dir.join("private-root.key"),&wrap,p::SigningKeyId::from_trusted_state(read(&dir.join("root-id.bin"),32)?.as_slice().try_into()?)?)?;
   let at=now()?;let from=number(&config,"from")?;let until=at.checked_add(ttl).ok_or("time overflow")?.min(number(&config,"until")?);
   let roster=root.issue_roster(version,p::Validity::new(from,until)?,&[root.roster_entry(&bytes(&grant,"certificate")?)?])?;
   let target=json!({"certificate":bytes(&grant,"certificate")?,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),"digest":roster.checkpoint().digest(),"from":from,"until":until});
   publish_private_bytes(output,&serde_json::to_vec_pretty(&target)?)?;println!("{}",json!({"version":version,"from":from,"until":until}));
  }
  "prepare" if args.len()==6=>{
   let original=load(Path::new(&args[3]))?;let target=load(Path::new(&args[4]))?;let proposal=p::AnchorRosterRefreshProposal::from_trusted_state(&read(Path::new(&args[5]),417)?)?;
   let old=pin(&config,&original)?.verify_device(&bytes(&original,"certificate")?,&bytes(&original,"roster")?,now()?)?;
   let next=pin(&config,&target)?.verify_device(&bytes(&target,"certificate")?,&bytes(&target,"roster")?,now()?)?;
   let policy=policy(&config)?;let mut store=witness(dir,&config)?;
   let state=store.prepare_roster_refresh(proposal,&old,&next,&policy,now()?)?;store.close();
   if state!=p::AnchorRosterRefreshState::Prepared{return Err(format!("unexpected preparation: {state:?}").into())}
   println!("{}",json!({"independent_preparation":"Prepared","binding":proposal.binding()}));
  }
  _=>return Err("arguments".into()),
 }Ok(())
}
