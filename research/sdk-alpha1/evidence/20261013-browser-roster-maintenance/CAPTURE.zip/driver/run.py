from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-roster';package=root/'target/continuity-browser-publication/source/target/roster-package-02'
web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Original roster maintenance</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
authority=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority';roster=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-roster-authority'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'installed browser original enrollment roster workflows, same native signed witness implementation and loopback; no independent implementation/deployment/release claim','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,roster]},'cases':[],'observations':[]}
allowed={'applied','closed','drop-commit','drop-ack','close-after-commit','timeout','cancel','unprepared','closed-policy','wrong-proposal','reserved-abandon','local','local-expired','no-local-fallback'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0

def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args['action'],'observations':value['result'].get('observations',[])});return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value

def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

def unchanged(original,current):sdk.require(current['journal']==original['journal'] and current['prekey']==original['prekey'],'roster changed original identity/key')
try:
 with serving(web,out,private,authority) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    profile='local' if case in ['local','local-expired'] else 'required'
    native(authority,['prepare',directory],case+'-authority');shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':profile}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(authority,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'})
    if profile=='required':
     sdk.require(prepared['phase']=='requires-witness-enrollment','missing required witness');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    else:sdk.require(prepared['phase']=='prepared-local','wrong local preparation')
    original=success({**args,'action':'activate'});row['original']=original
    row['scalars']=success({**args,'action':'scalar'})
    target=inputs/(key+'-target.json');native(roster,['target',directory,grant,target,2,120 if case=='local-expired' else 3600],case+'-target');target_data=json.loads(target.read_text());args['previous']={k:grant_data[k] for k in ['version','digest']}
    if profile=='local':
     pending=success({**args,'action':'local-refresh'});sdk.require(pending['status']['phase']==6,'local intent not pending');row['pending']=pending
     sdk.require(success({**args,'action':'local-refresh'})==pending,'local retry changed target')
     if case=='local-expired':
      args['at']=target_data['until']+1
      resolved=success({**args,'action':'local-resolve','historicalOnly':True});sdk.require(resolved['outcome']==2 and resolved['observed']=='1','wrong original expiry outcome');row['resolved']=resolved
      next_target=inputs/(key+'-target-next.json');native(roster,['target',directory,grant,next_target,3,3600],case+'-next-target');args['targetFile']=next_target.name
      success({**args,'action':'local-refresh'})
     current=success({**args,'action':'activate'});unchanged(original,current);row['current']=current
    elif case=='no-local-fallback':
     row['rejection']=rejected({**args,'action':'local-refresh'},'AnchorRequired');sdk.require(success({**args,'action':'progress','historicalOnly':True})=={'progress':None},'fallback retained R');unchanged(original,success({**args,'action':'activate'}))
    else:
     args['operationId']=success({**args,'action':'new-operation'})['operation']
     created=success({**args,'action':'prepare-roster'});proposal=created['proposal'];sdk.require(len(proposal)==417 and created['progress']['stage']==3 and not created['progress']['retired'],'wrong reservation');row['prepared']=created
     sdk.require(success({**args,'action':'prepare-roster'})==created,'exact R retry changed bytes')
     sdk.require(success({**args,'action':'recover-preparation','historicalOnly':True})['proposal']==proposal,'recovery changed proposal');args['proposal']=proposal
     if case=='unprepared':
      observed=success({**args,'action':'commit'});sdk.require(observed['state']==5 and observed['progress']['stage']==3 and not observed['progress']['retired'],'unprepared guessed outcome');row['unprepared']=observed
     proposal_file=out/(case+'-proposal.bin');proposal_file.write_bytes(bytes(proposal));native(roster,['prepare',directory,grant,target,proposal_file],case+'-witness-approval')
     if case in ['closed-policy','wrong-proposal','reserved-abandon']:
      before=len(records.get(key,[]));options={'action':'commit','closePolicy':True};expected='Closed'
      if case=='wrong-proposal':
       forged=proposal.copy();forged[136]^=1;options={'action':'reconcile','proposal':forged,'historicalOnly':True};expected='Conflict'
      elif case=='reserved-abandon':options={'action':'abandon','historicalOnly':True};expected='Conflict'
      row['rejection']=rejected({**args,**options},expected);sdk.require(len(records.get(key,[]))==before,'invalid operation dispatched')
     if case in ['drop-commit','drop-ack','close-after-commit','timeout','cancel']:
      mode={'drop-commit':'drop-after-advance','close-after-commit':'drop-after-advance','drop-ack':'drop-ack','timeout':'timeout-after-advance','cancel':'hold-after-advance'}[case]
      options={'mode':mode,'timeout':2000} if case=='timeout' else {'mode':mode}
      if case=='cancel':options['cancelOnAdvance']=True
      row['rejection']=rejected({**args,'action':'commit',**options},'Deadline' if case=='timeout' else 'Cancelled' if case=='cancel' else 'WitnessTransport')
      pending=success({**args,'action':'progress','historicalOnly':True});row['after_loss']=pending
      sdk.require(pending['progress']['stage']==(4 if case=='drop-ack' else 3) and not pending['progress']['retired'],'wrong durable cut')
      if case=='cancel':sdk.require(row['rejection']['cancellationRequested'],'cancel did not reach pending request')
      final=success({**args,'action':'close-roster' if case=='close-after-commit' else 'reconcile','historicalOnly':True})
     else:final=success({**args,'action':'close-roster','historicalOnly':True} if case=='closed' else {**args,'action':'commit'})
     expected=3 if case=='closed' else 2;sdk.require(final['state']==expected and final['progress']['stage']==(5 if case=='closed' else 4) and final['progress']['retired'],'terminal cleanup incomplete');row['final']=final
     sdk.require(success({**args,'action':'reconcile','historicalOnly':True})==final,'terminal not retained after ACK')
     current=success({**args,'action':'activate'});unchanged(original,current);sdk.require(current['progress']==final['progress'],'activation lost terminal history');row['current']=current
    row['witness_records']=records.get(key,[]);sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
