from pathlib import Path
import json,os,shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-roster';clone=root/'target/continuity-browser-publication/source'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay02-paths',root).decode().splitlines()
overlay={}
for name in paths:
 p=root/name;sdk.require(p.is_file() and not p.is_symlink(),'source file required');overlay[name]=sdk.snapshot(p).sha256
 dest=clone/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay02-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY_02.json',{'base_commit':'886397135ff4b2a88a4e627572e9f3912bdb6939','overlay':overlay,'source':str(clone)})
script=(stage/'build-package.sh').read_text().replace('roster-package-01','roster-package-02')
(stage/'build-package-02.sh').write_text(script)
