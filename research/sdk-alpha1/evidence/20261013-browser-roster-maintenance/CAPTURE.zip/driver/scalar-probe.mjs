import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const receipt=JSON.parse(readFileSync(process.argv[2],'utf8'));
const web=resolve(receipt.path,'node_modules/q-periapt-sdk-wasm/web');
const glue=await import(pathToFileURL(web+'/q_periapt_sdk_wasm.js'));
await glue.default({module_or_path:readFileSync(web+'/q_periapt_sdk_wasm_bg.wasm')});
const sdk=await import(pathToFileURL(web+'/index.js'));await sdk.default();
const cfg=JSON.parse(readFileSync('target/continuity-browser-roster/scalar-private-02/PUBLIC.json','utf8'));
const b=x=>new Uint8Array(x), results=[];
for(const [name,value] of [['valid',1n],['overflow',(1n<<64n)+1n],['negative-alias',1n-(1n<<64n)],['string','1'],['boolean',true]]) {
 let object;const row={name,value:String(value)};
 try {object=new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),value,new Uint8Array(32).fill(7),b(cfg.family));row.accepted=true;}
 catch(error){row.accepted=false;row.code=error.code;row.error=String(error)}
 finally {object?.free()}
 results.push(row);
}
console.log(JSON.stringify({scope:'Node instantiation of the installed web WASM; no browser storage claim',results},null,2));
