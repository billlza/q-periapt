from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-roster';package=root/'target/continuity-browser-publication/source/target/roster-package-02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
overlay=load(stage/'SOURCE_OVERLAY_02.json')
for name,digest in overlay['overlay'].items():assert sha(root/name)==digest,name
old=load(stage/'scalar-old.json');new=load(stage/'scalar-final.json')
assert all(r['accepted'] for r in old['results'])
assert new['results'][0]['accepted'] and all(not r['accepted'] and r['code']=='InvalidInput' for r in new['results'][1:])
red=load(stage/'run-01/RESULT.json');fixture=load(stage/'run-02/RESULT.json')
assert not red['completed'] and 'Database(File)' in red['failure']
assert not fixture['completed'] and 'Validity' in fixture['failure']
reports=[load(stage/n/'RESULT.json') for n in ['run-03','run-04']]
assert all(r['completed'] for r in reports)
cases={c['case']:c for r in reports for c in r['cases']}
expected={'applied','closed','drop-commit','drop-ack','close-after-commit','timeout','cancel','unprepared','closed-policy','wrong-proposal','reserved-abandon','local','local-expired','no-local-fallback'}
assert set(cases)==expected and sum(len(r['cases']) for r in reports)==14
for c in cases.values():assert c['scalars']['rejected']==10 and c['scalars']['hooks']==0
for name,c in cases.items():
 if 'current' in c:assert c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
 if 'final' in c:assert c['final']['progress']['retired'] and c['final']['state']==(3 if name=='closed' else 2)
assert cases['local-expired']['resolved']['outcome']==2 and cases['local-expired']['resolved']['observed']=='1'
assert cases['drop-ack']['after_loss']['progress']['stage']==4 and not cases['drop-ack']['after_loss']['progress']['retired']
assert cases['drop-commit']['after_loss']['progress']['stage']==3
assert cases['close-after-commit']['final']['state']==2
assert cases['unprepared']['unprepared']['state']==5 and not cases['unprepared']['unprepared']['progress']['retired']
assert cases['cancel']['rejection']['cancellationRequested']
browser=load(stage/'base-01/RESULT.json');assert browser['completed'] and len(browser['report']['cases'])==10
receipt=load(package/'INSTALLED_CONSUMER.json')
assert receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz') and receipt['source_bound'] and receipt['sources_unchanged']
assert '24 passed; 0 failed' in (stage/'native-roster-regression.log').read_text()
assert '1 passed; 0 failed' in (stage/'native-local-regression.log').read_text()
assert 'Ran 53 tests' in (stage/'controls.log').read_text() and (stage/'controls.log').read_text().rstrip().endswith('OK')
for name in ['msrv.log','native-msrv.log','wasm-clippy-03.log','native-clippy-final.log']:
 text=(stage/name).read_text();assert 'Finished ' in text and 'error:' not in text and 'warning:' not in text
assert not (stage/'fmt-check.log').read_bytes() and not (stage/'scalar-final.stderr').read_bytes()
members={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in members
 assert not any(v.endswith('-private') or v.startswith('private-') for v in p.parts),p
 members[name]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.name not in ['HANDOFF.json','seal.stdout','seal.stderr'] and p.suffix in ['.py','.js','.mjs','.json','.stdout','.stderr','.log','.sh','.txt']:add(p,'driver/'+p.name)
for directory in ['run-01','run-02','run-03','run-04']:
 add(stage/directory/'RESULT.json',directory+'/RESULT.json')
 for part in ['logs','captures','witness']:
  for p in sorted((stage/directory/part).rglob('*')):
   if p.is_file():add(p,directory+'/'+p.relative_to(stage/directory).as_posix())
for p in sorted((stage/'base-01').iterdir()):
 if p.is_file():add(p,'base/'+p.name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'authority'/name,'authority/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','witness/browser_activation_authority.rs')
web=Path(load(package/'consumer-location.json')['path'])
for p in sorted((web/'inputs').glob('run-*.json')):add(p,'public-inputs/'+p.name)
for name in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json','build-nodejs.json','build-web.json','typescript.json','consumer-installed.json','consumer-installed.stderr','consumer-product.json']:
 add(package/name,'package/'+name)
add(root/'target/continuity-browser-publication/source/target/roster-package-01/INSTALLED_CONSUMER.json','red-package/INSTALLED_CONSUMER.json')
add(root/'target/continuity-browser-publication/source/target/input-package-03/INSTALLED_CONSUMER.json','scalar-old-package/INSTALLED_CONSUMER.json')
add(stage/'scalar-private-02/PUBLIC.json','public-inputs/scalar-PUBLIC.json')
for name in overlay['overlay']:add(root/name,'source/'+name)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-roster-maintenance';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in members.items():assert sha(p)==hashlib.sha256(z.read(n)).hexdigest()==manifest[n]['sha256']
checks={'completed':True,'release_claim_eligible':False,'source':overlay,
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged','typescript']},
 'scalar_red_green':{'old_package_sha256':load(root/'target/continuity-browser-publication/source/target/input-package-03/INSTALLED_CONSUMER.json')['sha256'],'original':old,'corrected':new},
 'browser':{'version':browser['report']['browser'],'base_cases':10,'roster_cases':sorted(cases),'case_count':14,'scalar_rejections_per_cohort':10,'coercion_hooks':0},
 'validation':{'native_roster_cases':24,'native_local_expiry_cases':1,'artifact_controls':53,'wasm_clippy':'-D warnings passed','native_clippy':'all targets -D warnings passed','wasm_msrv':'Rust1.90.0 passed','native_msrv':'Rust1.90.0 passed','format':'passed'},
 'storage_red_green':'Installed package01 failed original roster preparation with Database(File); package02 uses the retained platform storage for inspection, original journal opening, account authorization, recovery and retirement. Identical applied scenario now completes with exact original journal and prekey.',
 'non_admitted_attempts':['Package01 browser roster preparation exposed native file-opening calls; recorded before fixing the platform storage seam.','Run02 root fixture shortened the new roster validity start. Original prekey validity then failed the existing containment rule. The corrected independent root fixture retains the original start and caps the end at the original credential validity. No SDK admission check was weakened.'],
 'scope':'Actual npm package in Chrome dedicated Workers with IndexedDB/Web Locks/OPFS and a loopback native signed witness using the same Rust engine. Historical recovery constructs no live runtime. Public prekey/journal continuity is exercised; this is not installed pairwise-session continuity, independent protocol implementation, deployed HTTPS, device, performance, PCS or full-release qualification.'}
sdk.write_json(dest/'CHECKS.json',checks)
(dest/'README.md').write_text('''# Installed browser roster maintenance

The product web entry now coordinates the original enrollment's same-credential roster update. A required-witness target uses the existing R protocol, independent root-signed roster and witness preparation. The browser owner retains the exact proposal, persists the actual terminal before ACK, and keeps recovery separate from current traffic admission. Historical policy verification requires the independently retained root, family, checkpoint and signed statement; it constructs no live runtime and grants no new traffic authority.

The first real installed browser run failed with `Database(File)`: preparation and later recovery helpers still opened native paths. The corrected path opens the retained platform storage and reuses the original authenticated database algorithms. No witness, account-authority or durability check was removed. Local expiry recovery uses the same storage boundary. Raw failed and successful runs, source overlays and package identities are retained in `CAPTURE.zip` with a verified member manifest.

Fourteen fresh installed Chrome Worker cohorts cover Applied, Closed, lost Commit reply, lost ACK reply, Close after remote commit, timeout, cancellation, absent independent witness preparation, closed policy, substituted proposal, forbidden abandonment after reservation, local update, expired uncommitted local target and refusal of a required-witness local fallback. Each operation closes its owner and reopens the same registration. Recovery-only calls construct no live runtime. Retried preparation returns the same 417 bytes; terminal history survives ACK and subsequent activation. Existing journal identity and original public prekey remain unchanged. Missing witness history is not called uncommitted; Close after commit stays Applied.

The scalar regression reproduced `2^64 + 1n`, `1n - 2^64`, string and boolean values being accepted as version 1 by the old installed binding. Version, generation and time inputs now require exact unsigned-64 BigInt values. The final package rejects these aliases, and each browser cohort rejects ten malformed account/time inputs without executing coercion hooks or stranding the owner. TypeScript signatures remain bigint.

Validation includes 24 native roster tests (including synchronization and process-termination cuts), one original local-expiry regression, ten installed base browser modes, 53 package/inventory controls, strict native/WASM Clippy, native/WASM Rust 1.90 and formatting. Package production ran real installed Node consumers and TypeScript 7.0.2. An initial fixture accidentally narrowed the target roster start beyond the original prekey validity; the SDK correctly rejected that request. The corrected independent root fixture retains the original start and caps the end at the credential validity. The failed attempt is retained; no admission rule was relaxed.

This evidence uses actual browser IndexedDB, Web Locks and OPFS with a loopback signed witness sharing the Rust protocol implementation. It does not establish installed pairwise-session continuity across the update, independent implementation, deployed HTTPS, device coverage, performance, PCS or release readiness. Credential, policy and account-root transitions remain separate browser integration work. Private signing/wrapping material, journal databases and browser profiles are excluded.
''')
print(json.dumps(checks['capture']))
