from pathlib import Path
import json,os,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
candidate=root/'research/continuity-identity-candidate'
toolchain=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
env=dict(os.environ);env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(stage/'build-02'),RUSTFLAGS='-D warnings',PATH=str(toolchain/'bin')+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'))
path=candidate/'src/durable/messages/tests/reservation_disclosure.rs'
fmt=subprocess.run([str(toolchain/'bin/rustfmt'),'--edition','2021','--emit','stdout'],input=path.read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
sdk.require(fmt.returncode==0 and not fmt.stderr,'test formatting failed')
path.write_bytes(fmt.stdout)
source={str(p.relative_to(candidate)):sdk.snapshot(p).sha256 for p in (candidate/'src').rglob('*.rs')}
sdk.write_json(stage/'TEST_INPUTS_02.json',{'base_commit':'ed95b1b0a6ea688b7359d4b1673bd33f4173a42d','files':source,'test_only_delta':str(path.relative_to(root))})
sdk.command([str(toolchain/'bin/cargo'),'test','--locked','--offline','--manifest-path',str(candidate/'Cargo.toml'),'--lib','--all-features','durable::messages::tests::reservation_disclosure::','--','--nocapture'],stage/'tests-02',root,environment=env)
sdk.require(source=={str(p.relative_to(candidate)):sdk.snapshot(p).sha256 for p in (candidate/'src').rglob('*.rs')},'source changed during execution')
sdk.write_json(stage/'TESTED_02.json',{'completed':True,'tests':3,'decrypted_messages':18,'new_asymmetric_epoch_two_messages':6,'scope':'Two retained original first-reservation cuts plus a fresh one-snapshot phase-3 counterexample; not a secrecy proof.'})
print('Three fresh disclosure experiments passed; asymmetric snapshot decrypts six epoch-two messages')
