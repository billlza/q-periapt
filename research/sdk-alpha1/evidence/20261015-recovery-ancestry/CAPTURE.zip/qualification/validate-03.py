from pathlib import Path
import json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;candidate=root/'research/continuity-identity-candidate'
toolchain=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
env=dict(os.environ);env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(stage/'build-02'),RUSTFLAGS='-D warnings',PATH=str(toolchain/'bin')+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'))
cargo=str(toolchain/'bin/cargo');base=[cargo,'--offline','--locked','--manifest-path',str(candidate/'Cargo.toml')]
for group in ['control_progress','send_budget']:
 sdk.command([cargo,'test',*base[1:],'--lib','--all-features','durable::messages::tests::'+group+'::','--','--nocapture'],stage/(group+'-03'),root,environment=env)
sdk.command([cargo,'clippy',*base[1:],'--all-features','--all-targets','--','-D','warnings'],stage/'clippy-03',root,environment=env)
sdk.command([str(toolchain/'bin/rustfmt'),'--edition','2021','--check',str(candidate/'src/durable/messages/tests/reservation_disclosure.rs')],stage/'format-03',root,environment=env)
sources=json.loads((stage/'TEST_INPUTS_02.json').read_text())['files']
sdk.require(sources=={str(p.relative_to(candidate)):sdk.snapshot(p).sha256 for p in (candidate/'src').rglob('*.rs')},'tested source changed')
sdk.write_json(stage/'VALIDATED_03.json',{'completed':True,'disclosure_tests':3,'control_progress_tests':True,'send_budget_tests':True,'strict_clippy_all_targets':True,'selected_format_check':True,'production_code_changed':False})
print('Control delivery and send-budget regressions, all-target strict Clippy and formatting passed')
