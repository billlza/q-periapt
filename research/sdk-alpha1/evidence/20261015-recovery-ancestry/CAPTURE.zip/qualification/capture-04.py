"""Capture only source, public logs and assertion results, never runtime stores."""
from pathlib import Path
import hashlib,json,re,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.require(json.loads((stage/'TESTED_02.json').read_text())['completed'],'disclosure experiment incomplete')
sdk.require(json.loads((stage/'VALIDATED_03.json').read_text())['completed'],'validation incomplete')
expected={
 'tests-02':(3,'3.34'),
 'control_progress-03':(5,'38.58'),
 'send_budget-03':(7,'30.50'),
}
for name,(count,_) in expected.items():
 sdk.require(json.loads((stage/(name+'.json')).read_text())['returncode']==0,'test invocation failed')
 stdout=(stage/(name+'.stdout')).read_text()
 sdk.require(len(re.findall(r'^test result: ok\. '+str(count)+r' passed; 0 failed; 0 ignored;',stdout,re.M))==1,'test counts differ')
log=(stage/'tests-02.stderr').read_text()
markers=[
 'SEALED_RESERVATION_DISCLOSURE cut=rekey-key-reserved confirmed_epoch=1 recovered_messages=6 directions=2 private_input=one_snapshot',
 'SEALED_RESERVATION_DISCLOSURE cut=rekey-response-kem-reserved confirmed_epoch=1 recovered_messages=6 directions=2 private_input=one_snapshot',
 'ASYMMETRIC_RESERVATION_DISCLOSURE lagging_confirmed=0 captured_confirmed=1 captured_pending=2 captured_phase=3 recovered_epoch=2 recovered_messages=6 directions=2 private_input=one_responder_snapshot',
]
for marker in markers:sdk.require(log.splitlines().count(marker)==1,'missing or duplicated experiment marker')
inputs=json.loads((stage/'TEST_INPUTS_02.json').read_text())
candidate=root/'research/continuity-identity-candidate'
for name,digest in inputs['files'].items():sdk.require(sdk.snapshot(candidate/name).sha256==digest,'candidate source changed')
files={}
def add(path,name):
 sdk.require(name not in files,'duplicate capture member')
 files[name]=sdk.snapshot(path,maximum=32*1024**2).data
for name in ['SOURCE_01.json','TEST_INPUTS_02.json','TESTED_02.json','VALIDATED_03.json','run-02.py','validate-03.py','capture-04.py','original-reservation-disclosure.rs.txt']:
 add(stage/name,'qualification/'+name)
for name in [*expected,'clippy-03','format-03']:
 for suffix in ['.json','.stdout','.stderr']:add(stage/(name+suffix),'qualification/'+name+suffix)
source_names=[
 'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs',
 'research/continuity-identity-candidate/src/durable/messages/tests.rs',
 'research/continuity-identity-candidate/src/durable/messages.rs',
 'research/continuity-identity-candidate/src/durable/messages/traffic.rs',
 'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
 'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
 'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
 'research/continuity-identity-candidate/src/crypto.rs',
 'research/continuity-identity-candidate/src/crypto/persistence.rs',
 'crates/q-periapt-sdk/src/expert/replay.rs',
 'docs/continuity/RECOVERY_CONDITIONS_V1.md','docs/continuity/RECOVERY_DEPENDENCIES_V1.md',
 'research/continuity-identity-candidate/RESERVATION_DISCLOSURE.md',
]
for name in source_names:add(root/name,'source/'+name)
output=root/'research/sdk-alpha1/evidence/20261015-recovery-ancestry';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'format':1,'base_commit':inputs['base_commit'],'capture_sha256':sdk.snapshot(archive).sha256,
 'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},'test_counts':{n:v[0] for n,v in expected.items()},
 'asymmetric_capture':{'lagging_confirmed_epoch':0,'captured_confirmed_epoch':1,'captured_pending_epoch':2,'captured_phase':3,'recovered_epoch':2,'recovered_messages':6,'directions':2,'snapshots':1},
 'all_experiments_recovered_messages':18,'production_code_changed':False,'release_claim_eligible':False,
 'private_runtime_data_included':False,'private_selection':'Explicit source and public command-receipt allowlist only; no runtime directory or private key data selected.',
 'scope':'Finite constructive disclosure counterexample and source-derived dependency map, not a maximum exposure bound or secrecy proof.'}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.namelist())==len(set(z.namelist()))==len(files),'archive census differs')
 sdk.require(set(z.namelist())==set(manifest['members']),'archive members differ')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'archive member changed')
 captured_log=z.read('qualification/tests-02.stderr').decode()
 for marker in markers:sdk.require(captured_log.splitlines().count(marker)==1,'archived marker differs')
sdk.write_json(output/'READBACK.json',{'completed':True,'capture_sha256':manifest['capture_sha256'],'members':len(files),'exact_public_markers':3,'source_files':len(source_names),'tests_passed':15,'private_states_reopened':False})
print(json.dumps({'capture_sha256':manifest['capture_sha256'],'members':len(files),'tests':15}))
