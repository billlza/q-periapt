"""Replay the original receipt join; this does not replace scenario readbacks."""
from pathlib import Path
import hashlib
import json
import sys

out = Path(__file__).resolve().parent
frozen = out.parent / "frozen-2328"
sys.path.insert(0, str(frozen / "artifact"))
import continuity_profiles

read = lambda p: json.loads(p.read_text())
initial = read(out / "READBACK.json")
sources = None
for label, proof in initial["partitions"].items():
    path = out / "partitions" / ("continuity-installed-" + label) / "CONTINUITY_PACKAGE.json"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == proof["report_sha256"]
    row = read(path)
    if sources is None:
        sources = row["source_inputs"]
    else:
        assert row["source_inputs"] == sources
actual = continuity_profiles.verify_partitions(out / "partitions", source_commit=initial["head"], source_inputs=sources)
assert actual == initial["exact_join"] == read(out / "CONTINUITY_PROFILE_COVERAGE.json")
for name, digest in initial["reader_sources"].items():
    assert hashlib.sha256((frozen / name).read_bytes()).hexdigest() == digest
assert not actual["release_claim_eligible"] and not actual["publication_performed"]
(out / "FORMAL_READBACK.json").write_text(json.dumps({"exact_join": actual, "scope": initial["scope"]}, indent=2) + "\n")
print("Exact original six-partition receipt join verified; scenario evidence remains separate.")
