from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
main=out.parent.parent
src=main
sys.path.insert(0,str(src/"artifact"))
import continuity_c_consumer as c
import continuity_c_authority as authority
base=json.loads((out/"RESULT.json").read_text());assert base["completed"]
root=Path(base["outside"]);consumer=Path(base["consumer"])
run_dir=out/"installed-authority-01";run_dir.mkdir()
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"),DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer")
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
record={"source_sha256":files,"consumer":str(consumer),"candidate_archive":base["candidate_archive"],"runs":[],"profiles":{},"completed":False,"release_claim_eligible":False}
(run_dir/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(argv,label,cwd=consumer,*,runtime=None):
    start=time.monotonic()
    with (run_dir/(label+".stdout")).open("wb") as so,(run_dir/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(argv,cwd=cwd,env=env if runtime is None else runtime,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":argv,"returncode":code,"seconds":time.monotonic()-start})
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; retained stderr")
    return (run_dir/(label+".stdout")).read_bytes()
cc=Path(run(["xcrun","--find","clang"],"clang").decode().strip())
sdk_path=run(["xcrun","--show-sdk-path"],"sdk-path").decode().strip()
cargo=[str(tc/"bin/cargo")]
filename="libq_periapt_continuity_c_consumer.dylib"
for profile in ("debug","release"):
    extra=["--release"] if profile=="release" else []
    build=root/"build"/profile
    built=run(cargo+["rustc","--lib","--locked","--offline","--message-format=json","-j","2",*extra,"--","-C","link-arg=-Wl,-install_name,@rpath/"+filename],"library-"+profile)
    library=c.built_artifact(built,consumer,build,library=True)
    installed=root/("enrollment-current-installed-"+profile);installed.mkdir(mode=0o700)
    shutil.copy2(library,installed/filename)
    assert hashlib.sha256(library.read_bytes()).digest()==hashlib.sha256((installed/filename).read_bytes()).digest()
    names={line.split()[-1].removeprefix("_") for line in run(["/usr/bin/nm","-gU",str(installed/filename)],"exports-"+profile).decode().splitlines() if line.strip()}
    assert names==c.EXPORTS,(names-c.EXPORTS,c.EXPORTS-names)
    fixtures=run_dir/("fixtures-"+profile);fixtures.mkdir(mode=0o700)
    runtime={k:v for k,v in env.items() if not k.startswith(("DYLD","LD_"))}
    built=run(cargo+["test","--lib","--locked","--offline","--no-run","--message-format=json","-j","2",*extra],"unit-build-"+profile)
    binary=c.built_artifact(built,consumer,build,library=False,unit=True)
    result=run([str(binary)],"admission-"+profile,runtime=dict(runtime,QPC_AUTHORITY_FIXTURE=str(fixtures)))
    c.verify_admission(result)
    fresh=root/("enrollment-current-"+profile);fresh.mkdir(mode=0o700)
    record["profiles"][profile]=authority.qualify(fresh,consumer,installed,fixtures,cc,["-isysroot",sdk_path],profile,run,darwin=True,runtime=runtime,filename=filename)
    executable=installed/"qpc-c-client"
    run([str(cc),"-isysroot",sdk_path,"-std=c11","-Wall","-Wextra","-Werror","-Wpedantic","-pthread",*( ["-O2"] if profile=="release" else ["-O0","-g"] ),*[str(consumer/f) for f in ("client.c","recovery_client.c","opening_client.c")],"-I",str(consumer),"-L",str(installed),"-l"+c.LIBRARY,"-Wl,-rpath,@loader_path","-o",str(executable)],"compile-"+profile)
    deps=run(["/usr/bin/otool","-L",str(executable)],"dependencies-"+profile).decode()
    loader=run(["/usr/bin/otool","-l",str(executable)],"loader-"+profile).decode()
    c.verify_linkage(deps,loader,filename,darwin=True)
    built=run(cargo+["test","--locked","--offline","--test","witness","--no-run","--message-format=json","-j","2",*extra],"witness-build-"+profile)
    binary=c.built_artifact(built,consumer,build,library=False,test_name="witness")
    evidence=fresh/"restoration"
    observed=run([str(binary),"--exact","opening::restored_session_constructors_keep_required_witness_and_cancel_partial_admission","--nocapture"],"restore-opening-"+profile,runtime=dict(runtime,QPERIAPT_C_OWNER_CLIENT=str(executable),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(evidence)))
    import continuity_c_opening as opening
    record["profiles"][profile]["restoration_opening"]=opening.verify_restore_execution(observed,evidence)
    (run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
record["inputs_unchanged"]=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
record["completed"]=record["inputs_unchanged"] and len(record["profiles"])==2
(run_dir/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps({"completed":record["completed"],"profiles":list(record["profiles"]),"inputs_unchanged":record["inputs_unchanged"]}),flush=True)
raise SystemExit(0 if record["completed"] else 1)
