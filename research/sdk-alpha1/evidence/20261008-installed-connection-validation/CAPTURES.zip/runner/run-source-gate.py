from pathlib import Path
import json,hashlib,os,subprocess,time
root=Path(__file__).resolve().parents[2];src=root/'target/policy-recovery-ffi-current/source';out=root/'target/native-linux-current/source-gate-01';out.mkdir()
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p,text=True).strip()
assert not git(root,'status','--porcelain') and not git(src,'status','--porcelain')
full=json.loads((root/'target/native-linux-current/full-artifact-01/RESULT.json').read_bytes());assert full['complete'] and full['returncode']==0 and full['head_unchanged'] and full['source_clean']
head=git(root,'rev-parse','HEAD');assert git(root,'rev-parse',head+':artifact')==git(root,'rev-parse',full['head']+':artifact')
subprocess.run(['git','fetch',str(root),head],cwd=src,check=True);subprocess.run(['git','switch','--detach',head],cwd=src,check=True)
h=hashlib.sha256((src/'artifact/results.json').read_bytes()).hexdigest();cmd=['sh','artifact/python-run.sh','artifact/source_results_assembler.py','ci-source-gate','--profile','sdk-020',h,head]
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO','QPERIAPT','QPC','PYTHON','DYLD','LD_'))};env['QPERIAPT_PYTHON']='/opt/homebrew/opt/python@3.14/bin/python3.14'
start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,cwd=src,env=env,stdout=so,stderr=se)
r={'head':head,'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'source_clean':not git(src,'status','--porcelain'),'head_unchanged':git(src,'rev-parse','HEAD')==head,'artifact_tree_unchanged_from_full_tests':True}
for stream in ['stdout','stderr']:r[stream+'_sha256']=hashlib.sha256((out/(stream+'.log')).read_bytes()).hexdigest()
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((out/'stdout.log').read_text()[-3000:]);print((out/'stderr.log').read_text()[-1000:]);assert r['source_clean'] and r['head_unchanged'];p.check_returncode()
