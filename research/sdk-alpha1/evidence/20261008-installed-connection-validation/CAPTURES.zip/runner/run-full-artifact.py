from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[2];source=root/'target/policy-recovery-ffi-current/source';out=root/'target/native-linux-current/full-artifact-01';out.mkdir()
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p,text=True).strip()
assert not git(root,'status','--porcelain') and not git(source,'status','--porcelain')
head=git(root,'rev-parse','HEAD');assert (source/'.git').is_dir()
subprocess.run(['git','fetch',str(root),head],cwd=source,check=True)
subprocess.run(['git','switch','--detach',head],cwd=source,check=True)
assert git(source,'rev-parse','HEAD')==head
base=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244');tc=base/'rustup/toolchains/1.98.1-aarch64-apple-darwin'
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO','QPC','QPERIAPT','PYTHON','DYLD','LD_'))}
env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cmd=['sh','artifact/python-run.sh','-c','import unittest; unittest.main(module=None,argv=["unittest","discover","-s","artifact","-p","test_*.py","-v"],warnings="error")']
record={'head':head,'source':str(source),'command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete':False}
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
 p=subprocess.run(cmd,cwd=source,env=env,stdout=so,stderr=se)
record.update(complete=True,returncode=p.returncode,seconds=time.monotonic()-start,head_unchanged=git(source,'rev-parse','HEAD')==head,source_clean=not git(source,'status','--porcelain'))
for stream in ['stdout','stderr']:record[stream+'_sha256']=hashlib.sha256((out/(stream+'.log')).read_bytes()).hexdigest()
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/'stderr.log').read_text()[-3000:]);assert record['head_unchanged'] and record['source_clean'];p.check_returncode()
