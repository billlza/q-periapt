# Candidate recovery dependencies and asymmetric progress

Status: source-derived disclosure analysis and a finite implementation experiment.
This is not a frozen security claim or a proof of post-compromise secrecy. It
refines [RECOVERY_CONDITIONS_V1.md](RECOVERY_CONDITIONS_V1.md) by identifying which
retained fields can expose later roots. A recovery label must follow these
fields, including both endpoints' pending work, rather than a single epoch counter.

## Scope and concrete dependency equations

For an exchange targeting epoch `e`, let `R[e-1]` be the previous rekey root,
`S[e]` the combined hybrid KEM secret, `C[e]` the public response core, and
`O[e]`/`P[e]` the complete signed public offer/response. With the exact domain
labels in the implementation, the pending root is:

```
R[e] = HKDF-SHA256(salt = R[e-1], IKM = S[e],
                  info = pending-root-domain || H(response-core-domain, C[e]), 32)
T[e] = HKDF-SHA256(salt = session-id, IKM = R[e],
                  info = epoch-traffic-domain || context || e ||
                         H(traffic-transcript-domain, O[e] || P[e]), 128)
```

[`response::derive_root`](../../research/continuity-identity-candidate/src/durable/messages/rekey/response.rs)
and [`State::add_epoch`](../../research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs)
implement these equations. `T[e]` creates two directional traffic chains and two
ACK keys. Knowing `R[e]` and the public transcript is sufficient to reproduce
the initial epoch material and subsequent chain steps. This is a constructive
sufficiency claim; absence of a listed derivation is not a secrecy proof.

The replay dependencies include:

| Captured inputs plus public information | Computable descendant |
| --- | --- |
| Matching wrapping key, generation reservation, operation/policy binding | Exact hybrid private/public key |
| That private key and the later response ciphertext/context | `S[e]` |
| Matching wrapping key, encapsulation reservation and retained authenticated offer | Exact ciphertext, `S[e]` and response core, even before response publication |
| `R[e-1]`, `S[e]`, response core | `R[e]` |
| `R[e]` and complete offer/response transcript | `T[e]`, directional message chains and ACK keys |
| Known wrapping key and subsequently obtained protected state | Whatever roots, reservations or retained traffic that later state actually contains |

The last row is ongoing disclosure, distinct from a single captured image.
The first two rows and the encapsulation row use the SDK's actual
[sealed-operation replay owner](../../crates/q-periapt-sdk/src/expert/replay.rs).
Honest SDK policy admission remains enforced, but it is not a cryptographic
barrier to an attacker already holding the token and its wrapping key: the
underlying replay computation can be reproduced outside that admission API.
A wrapper nonce or ciphertext published after capture does not add secrecy to
captured reservation entropy. For encapsulation, the response signature may
still be unpublished, but the predictor can already compute the response core;
it can use the later honest signature bytes when deriving transcript-bound traffic.

## Aggregate image lineage

[`seal_next_image`](../../research/continuity-identity-candidate/src/durable.rs)
advances a device-global revision and reseals the complete image after the caller
has updated its selected record. The image encoder samples its outer nonce after
encoding the plaintext. An unchanged message record therefore keeps its original
root, reservation and operation even when another session causes a new image.
The [executed two-session trace](../../research/sdk-alpha1/evidence/20261105-aggregate-reservation-copy/README.md)
checks that distinction through actual APIs, exact stored record equality,
reopen/retry and six subsequent target-message decryptions in each build profile.

The corresponding private-state mapping must preserve the origin of each
session's retained material, including copies carried by later aggregate images:

- A target generation or encapsulation reservation originates at the actual
  SDK reservation call. Both calls precede `store_message_state`; API return,
  a later global revision and a newly sampled image nonce are not that event.
- The original sealed target first becomes durable in the pending write before
  image application. Ordinary `apply` installs the exact retained target bytes;
  it does not rerun the KEM reservation or reseal that target.
- A sibling-only write preserves the target record's existing origin. It must
  not manufacture a new target `KeyReserved`/`EncapReserved` event. An unchanged
  pre-Cut session projection may retain its pre-Cut origin despite a later
  aggregate write; excluding it solely by the global write time would strengthen
  the declared acquisition restriction.
- Conversely, if an acquired aggregate carries target-session state that was
  saved after Cut, changing the last writer to another session does not make
  that acquisition admissible under MAIN's post-Cut `Saved`/`Snapshot` exclusion.
  The same accounting must include pending targets and retained copies.

These are source-derived obligations for a content/provenance relation between
device-global images and per-session symbolic states. The new test establishes
one unchanged-copy case, not the complete relation across every phase, archive,
failure and platform wrapper. The symbolic model performs reservation and save
in one rule; the implementation has separate sampling and durable-write steps.
A complete refinement must map those intervals explicitly rather than assign
freshness to the later commit or ignore a durable pending target.

The [hidden-record commitment argument](HIDDEN_RECORD_COMMITMENTS_V1.md) has a
different role: it can hide the public commitments of one private image/original
write using its fresh outer nonce. It neither replaces old KEM coins nor permits
acquisition of that nonce/preimage. Cross-image commitment simulation must retain
the same operation lineage and the unchanged disclosure conditions above.

## Stored phases and root ownership

Here `n` means that endpoint's local `confirmed_epoch`, and `e = n + 1`.
The phase numbers are private journal encodings, not a stable application API.
This table maps the exchange plan and active root; request records and traffic
records are separate. Independent signer files, retained storage pages, other
sessions and entropy-source state are additional assets.

| Phase | Retained rekey material beyond public wires | Root in `State.rekey` | New send / receive epochs |
| --- | --- | --- | --- |
| 0, no exchange plan | No KEM reservation in this plan; a control request may exist separately | `R[n]` | `n / n` |
| 1, key reserved | Generation token | `R[n]` | `n / n` |
| 2, offer signature reserved | Same generation token; signature reservation | `R[n]` | `n / n` |
| 3, offer ready | Same generation token | `R[n]` | `n / n` |
| 4, response encapsulation reserved | Encapsulation token and authenticated offer | `R[n]` | `n / n` |
| 5, response signature reserved | Pending `R[e]`; signature reservation | `R[n]` | `n / n` |
| 6, response ready | Pending `R[e]` | `R[n]` | `n / n` |
| 7, final signature reserved | Pending `R[e]`; signature reservation | `R[n]` | `n / n` |
| 8, final ready | New traffic installed; final outbox; pending root has moved into the active root field | **`R[e]`** | **`e / n`** |
| 9, receipt signature reserved | Pending `R[e]`; signature reservation | `R[n]` | `n / n` |

The encoding and transition sources are
[`Control::encode/decode`](../../research/continuity-identity-candidate/src/durable/messages/rekey.rs),
[`response::Plan`](../../research/continuity-identity-candidate/src/durable/messages/rekey/response.rs)
and [`completion::Plan`, `validate_epochs`, final/receipt commits](../../research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs).
Receipt commit installs `R[e]`, advances both directions and the local confirmed
counter, and clears the plan. Receipt acceptance at the proposer completes its
receive cutover later. Every row also requires accounting for the separate
retained traffic map: old keys, skipped keys, unconsumed plaintext and outboxes
are not erased merely because the rekey plan changes.

A signature reservation contains a binding and ML-DSA signing randomness. The
[current signer](../../research/continuity-identity-candidate/src/crypto.rs)
passes those coins to ML-DSA, while P-256 uses its own `try_sign` path. Treating
the captured bytes as an exposed P-256 nonce would be incorrect. The effect of
known ML-DSA signing coins remains part of the required auxiliary-information
security analysis; this table does not establish it.

The [persistent signer format](../../research/continuity-identity-candidate/src/crypto/persistence.rs)
encrypts both signing seeds under a key derived from the journal wrapping key.
A threat model granting that key and the corresponding signer file must include
identity compromise. Calling such a disclosure only a traffic-state snapshot
would exclude a real capability. The experiments below explicitly withhold
signer files/owners; they do not model an unrestricted whole-device compromise.

## A delayed receipt can hide a later exposed exchange

The asymmetric experiment holds the first receipt after the responder has
committed it. The initiator reports `(confirmed, send, receive, pending) =
(0, 1, 0, 1)`. The responder reports `(1, 1, 1, 2)` after committing its epoch-two
offer, with phase 3 retaining the generation token. Both observations survive
honest restart before the delayed receipt is delivered.

At that point the predictor receives **one responder snapshot**: its actual
`R[1]`, journal identity, wrapping key and retained generation token. It gets no
initiator snapshot, signer, epoch-two root, future reservation or later private
state. After the honest peers receive the delayed receipt and complete epoch 2,
the predictor reconstructs the epoch-two material from that capture and public
control wires. The experiment checks six actual newly generated application
payloads, three in each direction, after restart. A wrong wrapping key must fail.
See the [executed checkpoint](../../research/sdk-alpha1/evidence/20261015-recovery-ancestry/README.md).

This falsifies a universal exposure bound of `min(peer confirmed epochs) + 1`:
that quantity is one at capture, while epoch-two traffic is reconstructible.
It does not falsify a stated SDK security guarantee; `RekeyProgress` already
describes local progress only. It also does not establish the maximum possible
exposure, a bound relative to the newer peer's counter, or secrecy at epoch 3.
The legitimate asynchronous schedule should not be disabled just to make a
counter-based recovery claim appear true.

## Construction-specific recovery argument still required

For a candidate recovery epoch, the analysis must establish that the selected
hybrid contribution remains pseudorandom given the complete attacker view:
all disclosed ancestors and reservation coins, public transcripts, allowed
chosen inputs and any later state access. For a PQ claim that premise must
survive loss of the classical contribution. Both endpoints' phase/root ownership,
authentication authority and entropy-source recovery must be explicit.

A next proof step can then replace that contribution with an independent secret
in the exact root derivation, justify the root extractor/expander under the
actual previous-root and transcript distribution, and propagate the result to
the exact direction/epoch message keys. The assumptions must cover the
confirmation MACs, signature material, retained traffic and message/ACK cutover;
completing a flight is not that proof step. Further disclosure of the derived
root or traffic state defeats that candidate recovery point.

[RFC 5869 sections 3.1–3.4](https://www.rfc-editor.org/rfc/rfc5869.html#section-3)
explain salt, context and input-independence requirements. They do not supply a
security proof for this composition, whose salt is a previous protocol root and
whose context contains transcript-dependent values. A generic claim that one
unknown input makes every subsequent key secure is therefore not substituted
for the missing construction-specific argument.

The [construction-specific computational note](COMPUTATIONAL_RECOVERY_V1.md)
now expands the actual root, confirmation and traffic calls. It gives a
conditional three-step root replacement, maps the fixed 32-byte salt inputs to
a published HMAC swap-PRF result, and explains why downstream confirmation and
signature bytes must be recomputed consistently in proof hybrids. The combiner
premise, joint use of a root in both HMAC slots, PQ reductions and the full
message-secrecy argument remain open; no implementation or threat model changed.


A [symbolic research projection](../../research/continuity-recovery-symbolic/README.md)
now checks the original positive recovery formula through a
[20-property dependency group](../../research/sdk-alpha1/evidence/20261015-recovery-positive-symbolic/README.md).
The conditions require both reservations after Cut, no target-session identity
or entropy disclosure anywhere in the trace, and no acquired revision saved after
Cut. Other-session leakage remains allowed. Causal root/traffic/message knowledge
properties join authenticated KEM provenance to the retained-record timing facts.
The main query verifies in nine steps, with every dependency replayed in the same
process. Six observer actions erase to the original rules, and all five original
complete declarations remain unchanged.

The original generated-key provenance (182 steps), honest execution (59), pre-cut
generation-record disclosure (80), and later phase-8 disclosure (45) retain their
separate evidence. Both snapshot witnesses permit exactly one Snapshot and no
extra identity/entropy leakage. A new single-identity-disclosure witness shows
acceptance of an attacker-known root without snapshots or entropy disclosure.
These traces distinguish which sufficient condition has been lost; they do not
establish a maximum exposure bound.

This result assumes perfect primitives and ideal protected storage, with one
exchange per independently initialized pair. It supplies no concrete HKDF/hybrid
argument, shared-device or multi-epoch theorem, explicit-storage equivalence or
Rust refinement. The construction-specific argument above and the full product
release obligations remain open. No runtime flag can infer these attacker-view
conditions merely from protocol progress.

The [shared-identity follow-up](../../research/sdk-alpha1/evidence/20261015-recovery-shared-identity/README.md)
shows why the independent-identity premise matters. Reusing a signing-key pair
across two sessions admits a checked sibling-disclosure trace that violates the
unchanged session-scoped recovery formula. Both fresh target reservations and
the lack of target-session leak labels still hold. A separately checked key-origin
lemma locates the disclosure in the shared identity owner's scope.

The [key-scoped successor](../../research/sdk-alpha1/evidence/20261015-recovery-key-scoped/README.md)
now verifies a positive single-exchange formula with all 19 dependencies in one
fresh replay. Signing keys may be reused across sessions and roles; exclusions
name the actual two target keys. The model conservatively counts direct release
and signer-file capture as identity exposure throughout the trace. A separate
normal trace satisfies the premises while a third independent identity key is
known, so the condition does not prohibit all unrelated identity compromise.
Per-session wrapping keys, a freshly sampled publicly disclosed old root and
ideal primitives remain assumptions. Shared storage, arbitrary inherited roots,
multiple epochs and the construction-specific computational argument above remain
open. The automated CI gate now has explicit independent-identity and key-scoped
profiles with separate input pins, verdict inventories and retained results;
hosted qualification still requires completed runs of both profiles.

The [shared-storage projection](../../research/sdk-alpha1/evidence/20261015-recovery-shared-storage/README.md)
adds reusable wrapping keys and explicit ciphertext disclosure. A checked trace
obtains a target message from one target record and a wrapping key exposed through
a different session, without target-session Cut or identity/entropy disclosure.
Changing only wrapping-key allocation to independent per-session keys makes the
same witness unreachable. A separate normal trace uses the shared key for actual
storage in both sessions. This reinforces the device/journal ownership scope;
it does not establish a new SDK vulnerability. The
[positive successor](../../research/sdk-alpha1/evidence/20261015-recovery-shared-storage-positive/README.md)
now verifies all 20 properties together for this same per-record projection and
the unchanged main formula. A separate witness exercises simultaneous signing-key
and wrapping-key reuse in the same owner across roles. The SDK's whole-image
capture must account for every retained record in that image; the per-record
projection is not yet a proved refinement of that format. Arbitrary old-root
ancestry, multiple epochs and computational/SDK correspondence remain open.

## Multi-epoch symbolic successor

The [multi-epoch main-secrecy checkpoint](../../research/sdk-alpha1/evidence/20261031-multi-epoch-secrecy/README.md)
now verifies the original main formula in 508 steps together with all 24 reusable
dependencies in one independent replay. Unlike the earlier single-exchange
projections above, this model includes inherited roots, alternating proposers,
asymmetric local confirmation, initial traffic and unbounded epochs. The original
operational model and query formulas are retained; added invariants and changes
to dependency visibility/order are recorded explicitly.

The exact condition is that both target-epoch reservations occur after Cut,
neither actual target identity key nor that epoch's reserved entropy is disclosed,
and no acquired target-session record was saved after Cut. The model then excludes
adversarial derivation of the target application plaintext. It does not infer
these conditions from a completed rekey or an authenticated progress counter.

All 40 queries are retained. Eleven multi-round execution witnesses and two
unused historical all-trace queries remain incomplete; the initial-traffic
witness is verified separately in the same inventory. Main theorem closure must
not be reported as all queries passing or as completed multi-round non-vacuity
evidence. The symbolic primitives still do not supply the construction-specific
HKDF/hybrid argument, whole-journal correspondence, final implementation/platform
qualification or external security review required for release.

The [2026-11-04 independent replay](../../research/sdk-alpha1/evidence/20261104-multi-epoch-replay/README.md)
rechecked this same certificate with the fixed tools and unchanged 900-second
limit. MAIN and all reusable dependencies passed in 816.903 seconds; the output
certificate was byte-identical to the retained input. All 40 queries remained,
including the same 13 incomplete queries. This refreshes the symbolic evidence
without changing the separate open obligations above.

The subsequent [finite ground-trace record](../../research/sdk-alpha1/evidence/20261105-two-round-ground-trace/README.md)
constructs one two-round exposed-ancestor execution using these exact operational
rules and checks the complete original existential formula. A separate internal
source-derived calculation rechecks all rule instances and global quantifiers.
The skeleton can be expanded with the omitted fresh-generation and intruder
steps while preserving its witness ordering. This supplies concrete non-vacuity
evidence for that target; it is not a Tamarin certificate and does not change
any of the thirteen incomplete query results or the other obligations above.

The [finite delayed-receipt construction](../../research/sdk-alpha1/evidence/20261105-delayed-receipt-ground-trace/README.md)
then satisfies the original asymmetric-disclosure query. A pre-Cut B phase-3
snapshot, delayed first receipt and post-Cut A encapsulation lead to a derived
target-epoch payload. Both semantic calculations check the complete formula;
seven legal countertraces reject. Its point audit identifies post-Cut generation
as the sole false MAIN antecedent. The corresponding six-message SDK experiment
also appears in the current source-bound complete Release record, without a
new SDK run here. This supports the declared reservation-freshness boundary,
not a counterexample to MAIN or a change to the 27/13 Tamarin inventory.
