from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import runpy
import sys
import continuity_package as package
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-aggregate-reservation-copy'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
BUILD = BASE / 'build'
OLD_BUILD = ROOT / 'target/continuity-rekey-classical-alias/build'
MANIFEST = 'research/continuity-identity-candidate/Cargo.toml'
PARENT = 'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'
TEST = 'research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure/aggregate_copy.rs'
NAME = 'durable::messages::tests::reservation_disclosure::aggregate_copy::another_session_write_preserves_the_original_reservation_and_its_exposure'
MARKER = 'AGGREGATE_RESERVATION_COPY sessions=2 changed_session=sibling target_phase=3 original_target_bytes_preserved=1 changed_image_nonce=1 exact_retry_after_reopen=1 recovered_epoch=2 recovered_messages=6 directions=2 private_input=one_later_target_snapshot'

def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def write(p, data):
    with p.open('x') as f: json.dump(data, f, indent=2); f.write('\n')

def main():
    assert ROOT == package.ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sdk.validate_no_registry_credentials(os.environ)
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    before = package.source_inputs()
    tools = package.compiler_identity(CHAIN)
    commit = sdk.command(['git', 'rev-parse', 'HEAD'], BASE / 'source-head', ROOT).decode().strip()
    assert commit == '783739e4f1a9409ee50de71739d98411e5954cee'
    changed = sdk.command(['git', 'diff', '--name-only'], BASE / 'tracked-delta', ROOT).decode().splitlines()
    assert changed == [PARENT], changed
    assert TEST in before['files']
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
               CARGO_TARGET_DIR=str(BUILD), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2',
               CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never',
               RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
               RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
               DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'),
               PATH=str(CHAIN / 'bin') + os.pathsep + env.get('PATH', os.defpath))
    state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': commit, 'working_tree_test_delta': [PARENT, TEST],
        'source_inputs': before, 'tool_binaries': tools, 'driver_sha256': digest(Path(__file__)),
        'command_helper_sha256': digest(helper), 'production_implementation_unchanged_from_head': True,
        'scope': 'Actual shared journal with two complete sessions; a sibling send reseals the image, preserves target phase-three generation reservation, and a later target snapshot decrypts six epoch-two messages after exact recovery.',
        'full_native_suite_rerun': False, 'hosted_ci_claimed': False,
        'process_kill_performed': False, 'release_claim_eligible': False, 'profiles': {}}
    write(BASE / 'INPUTS.json', state)
    for name in [PARENT, TEST]:
        p = BASE / 'source' / name
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as f: f.write((ROOT / name).read_bytes())
    try:
        assert not BUILD.exists() and OLD_BUILD.is_dir()
        assert json.loads((ROOT / 'target/continuity-rekey-classical-alias/run-02/RESULT.json').read_bytes())['completed']
        sdk.command(['/bin/cp', '-cR', str(OLD_BUILD), str(BUILD)], BASE / 'copy-build-cache', ROOT)
        for profile in ['debug', 'release']:
            argv = [str(CHAIN / 'bin/cargo'), 'test', '--manifest-path', MANIFEST, '--lib', '--all-features', '--locked', '--offline']
            if profile == 'release': argv += ['--release']
            argv += [NAME, '--', '--exact', '--nocapture']
            stdout = sdk.command(argv, BASE / ('test-' + profile), ROOT, environment=env).decode()
            stderr = (BASE / ('test-' + profile + '.stderr')).read_text()
            assert stdout.splitlines().count('test ' + NAME + ' ... ok') == 1
            summaries = re.findall(r'^test result: (.+)$', stdout, re.M)
            assert len(summaries) == 1 and summaries[0].startswith('ok. 1 passed; 0 failed; 0 ignored;'), summaries
            assert stderr.splitlines().count(MARKER) == 1
            assert not re.search(r'(?im)^(?:warning|error)(?:\[|:)', stderr)
            state['profiles'][profile] = {'test': NAME, 'marker': MARKER, 'summary': summaries[0]}
        sdk.command([str(CHAIN / 'bin/cargo'), 'clippy', '--manifest-path', MANIFEST,
                     '--all-features', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'],
                    BASE / 'clippy', ROOT, environment=env)
        sdk.command([str(CHAIN / 'bin/rustfmt'), '--edition', '2021', '--check', PARENT, TEST],
                    BASE / 'rustfmt', ROOT, environment=env)
        assert package.source_inputs() == before and package.compiler_identity(CHAIN) == tools
        state.update(completed=True, source_inputs_unchanged=True, clippy_passed=True, rustfmt_passed=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'RESULT.json', state)
        print(json.dumps({k: state.get(k) for k in ['completed', 'error_type', 'error']}, indent=2), flush=True)

if __name__ == '__main__': main()
