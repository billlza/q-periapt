from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-aggregate-reservation-copy'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-aggregate-reservation-copy'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
run = json.loads((BASE / 'RESULT.json').read_bytes())
launch = json.loads((BASE / 'LAUNCH_RESULT.json').read_bytes())
assert run['completed'] and run['source_inputs_unchanged'] and run['clippy_passed'] and run['rustfmt_passed']
assert launch['completed'] and launch['returncode'] == 0
assert launch['timeout_seconds'] == 5400 and launch['component_timeout_seconds'] == 900
assert sha((BASE / 'run.py').read_bytes()) == launch['driver_sha256'] == run['driver_sha256']
assert sha((BASE / 'launch.py').read_bytes()) == launch['launcher_sha256']
for name in run['working_tree_test_delta']:
    assert sha((ROOT / name).read_bytes()) == run['source_inputs']['files'][name]
    assert (ROOT / name).read_bytes() == (BASE / 'source' / name).read_bytes()
for profile in ['debug', 'release']:
    receipt = json.loads((BASE / f'test-{profile}.json').read_bytes())
    assert receipt['completed'] and receipt['returncode'] == 0
    for suffix in ['stdout', 'stderr']:
        assert sha((BASE / f'test-{profile}.{suffix}').read_bytes()) == receipt[suffix + '_sha256']
    assert run['profiles'][profile]['marker'] in (BASE / f'test-{profile}.stderr').read_text()
    assert '1 passed; 0 failed; 0 ignored; 0 measured; 1458 filtered out;' in (BASE / f'test-{profile}.stdout').read_text()

model_path = ROOT / 'target/multi-epoch-replay/replay-01/original.spthy'
model = model_path.read_bytes()
assert sha(model) == 'dde5d06a071b1560da0d4c28c3f1fd81a3c39708f9fd8564ee391ddc362bcf7f'
text = model.decode()
name = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
start = text.index('lemma ' + name + ' ')
quote = text.index('"', text.index('all-traces', start))
end = text.index('"', quote + 1)
formula = text[quote + 1:end].encode()
assert sha(formula) == '0b92ee18d7731c7c83fa05329e486fd6813f8ea13d64ed92215346f10cdf8faa'
model_reference = {'model_sha256': sha(model), 'main_query': name,
    'main_formula_sha256': sha(formula), 'new_tamarin_execution': False,
    'prior_model_capture': 'research/sdk-alpha1/evidence/20261104-multi-epoch-replay',
    'lookup_note': 'The first diagnostic regex expected a quote immediately after the lemma colon and did not match the retained all-traces declaration. Corrected extraction recognizes that declaration; no model or query changed.',
    'full_refinement_claimed': False, 'main_counterexample_claimed': False}
with (BASE / 'MODEL_REFERENCE.json').open('xb') as f: f.write(encode(model_reference))
with (BASE / 'MAIN.formula.txt').open('xb') as f: f.write(formula)

files = {}
for p in BASE.iterdir():
    assert not p.is_symlink()
    if p.is_file(): files['capture/' + p.name] = p.read_bytes()
for folder in ['baseline', 'source']:
    for p in (BASE / folder).rglob('*'):
        assert not p.is_symlink()
        if p.is_file(): files['capture/' + p.relative_to(BASE).as_posix()] = p.read_bytes()
source_names = [
    'research/continuity-identity-candidate/src/durable.rs',
    'research/continuity-identity-candidate/src/durable/write_intent.rs',
    'research/continuity-identity-candidate/src/durable/messages.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/driver.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-identity-candidate/src/bootstrap.rs',
]
for name in source_names:
    body = (ROOT / name).read_bytes()
    assert sha(body) == run['source_inputs']['files'][name]
    files['implementation/' + name] = body
docs = [
    'docs/continuity/RECOVERY_CONDITIONS_V1.md',
    'docs/continuity/RECOVERY_DEPENDENCIES_V1.md',
    'docs/continuity/EXTERNAL_REVIEW_BRIEF.md',
    'research/sdk-alpha1/evidence/20261105-aggregate-reservation-copy/README.md',
]
for name in docs:
    p = ROOT / name
    body = p.read_bytes()
    for link in re.findall(r'\]\(([^)]+)\)', body.decode()):
        if '://' not in link and not link.startswith('#'):
            assert (p.parent / link.split('#', 1)[0]).resolve().is_file(), (name, link)
    files['documents/' + name] = body
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for n, b in sorted(files.items()):
        info = zipfile.ZipInfo(n, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, b)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(files) and set(archive.namelist()) == set(files)
    for n, b in files.items(): assert archive.read(n) == b
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'bytes': len(payload),
    'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True,
    'source_commit': run['source_commit'], 'working_tree_test_delta': run['working_tree_test_delta'],
    'focused_debug_and_release_passed': True, 'full_suite_rerun': False,
    'main_model_or_query_changed': False, 'release_claim_eligible': False}
for n, b in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']),
             ('SHA256.json', encode(summary)), ('MODEL_REFERENCE.json', encode(model_reference))]:
    with (DEST / n).open('xb') as f: f.write(b)
print(json.dumps(summary, indent=2), flush=True)
