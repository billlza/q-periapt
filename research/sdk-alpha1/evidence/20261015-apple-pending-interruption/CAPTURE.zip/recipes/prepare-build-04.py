from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
source=json.loads((stage/'APP_SOURCE_03.json').read_text());consumer=Path(source['consumer'])
for name,digest in source['source_files'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'drain source changed')
path=consumer/'Sources/USBRelay.c';text=path.read_text()
key='    descriptors[2] = cancellation[0]; descriptors[3] = cancellation[1];'
sdk.require(text.count(key)==1,'socket pair ownership boundary')
text=text.replace(key,'''    int one = 1;
    if (setsockopt(cancellation[0], SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0 ||
        setsockopt(cancellation[1], SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0) {
        int result = failure();
        result = close_owned(cancellation[0], result);
        result = close_owned(cancellation[1], result);
        result = close_owned(descriptors[0], result);
        result = close_owned(descriptors[1], result);
        descriptors[0] = descriptors[1] = -1;
        return result;
    }
'''+key);path.write_text(text)
path=stage/'usb_transport.py';text=path.read_text();start=text.index('def _forward(');end=text.index('\ndef launch(',start)
forward='''"""Opaque test transport; cut acceptance also requires exact app exit and native proof."""
import errno
import select
import socket
import time

'''+text[start:end].replace('def _forward(','def forward(')
ast.parse(forward)
with (stage/'relay_forward.py').open('x') as stream:stream.write(forward)
text=text[:start]+'from relay_forward import forward as _forward\n'+text[end:];ast.parse(text);path.write_text(text)
source['source_files']={str(p.relative_to(consumer)):sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}
sdk.write_json(stage/'APP_SOURCE_04.json',source)
text=(root/'target/continuity-apple-pending-recovery/attempt-24/build-app-24.py').read_text()
text=text.replace("stage/'PREPARED_03.json'","stage/'PREPARED_01.json'")
text=text.replace("stage/'APP_SOURCE_05.json'","stage/'APP_SOURCE_04.json'")
text=text.replace("(stage/'package-04/CONTINUITY_APPLE_PACKAGE.json').read_text()","Path(prepared['package_record']).read_text()")
for before,after in [('device-build-24','device-build-05'),('consumer24-','consumer05-'),('app-entitlements-24.plist','app-entitlements-05.plist')]:
    text=text.replace(before,after)
for label in ['project','build','sign','signature']:
    text=text.replace("stage/'"+label+"-24'","stage/'"+label+"-05'")
text=text.replace("('build-24.'+suffix)","('build-05.'+suffix)")
text=text.replace("'run-device-08.py'","'run-cases-06.py','relay_forward.py'")
ast.parse(text)
with (stage/'build-app-05.py').open('x') as stream:stream.write(text)
print('Final source and isolated build recipe prepared; normal transport errors remain failures')
