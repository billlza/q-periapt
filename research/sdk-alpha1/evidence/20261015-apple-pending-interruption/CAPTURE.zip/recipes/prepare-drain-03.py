from pathlib import Path
import json
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent
source=json.loads((stage/'APP_SOURCE_01.json').read_text());consumer=Path(source['consumer'])
for name,digest in source['source_files'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'initial app source changed')
for name in ['USBRelay.h','USBRelay.c','USBOperation.swift','ReplacementCommands.swift','PendingCommands.swift','PendingInterruption.swift']:
    sdk.copy(consumer/'Sources'/name,stage/'before-drain'/name)
path=consumer/'Sources/USBRelay.h';path.write_text(path.read_text()+'''\n/* Wait until the owned control stream's 72-byte identity and cut byte have
 * been forwarded upstream. This is a local relay barrier, not a witness reply. */
int qpc_test_relay_control_forwarded(int cancellation);
''')
path=consumer/'Sources/USBRelay.c';text=path.read_text()
text=text.replace('static int transfer(int first, int second) {','static int transfer(int first, int second, int cancellation, bool control) {\n    size_t forwarded_control = 0;')
key='''                int result = send_all(sockets[1-i], bytes, (size_t)n);
                if (result != 0) return result;'''
sdk.require(text.count(key)==1,'opaque forwarding boundary')
text=text.replace(key,key+'''
                if (control && i == 1) {
                    if (forwarded_control > 73 || (size_t)n > 73 - forwarded_control) return EOVERFLOW;
                    forwarded_control += (size_t)n;
                    if (forwarded_control == 73 && bytes[n-1] == 4) {
                        const unsigned char drained = 73;
                        result = send_all(cancellation, &drained, 1);
                        if (result != 0) return result;
                    }
                }''')
text=text.replace('transfer(transport, local)','transfer(transport, local, cancellation, strcmp(route, "control") == 0)')
text+='''
int qpc_test_relay_control_forwarded(int cancellation) {
    struct pollfd descriptor = {.fd = cancellation, .events = POLLIN};
    int ready = poll(&descriptor, 1, 3000);
    if (ready <= 0) return ready == 0 ? ETIMEDOUT : failure();
    unsigned char drained = 0;
    ssize_t count = recv(cancellation, &drained, 1, 0);
    if (count < 0) return failure();
    return count == 1 && drained == 73 ? 0 : EIO;
}
''';path.write_text(text)
path=consumer/'Sources/USBOperation.swift';text=path.read_text()
text=text.replace('    var active: [ActiveRelay] = []','    var active: [ActiveRelay] = []\n    var controlDrain: Int32?')
text=text.replace('            active.append(ActiveRelay(cancellation: descriptors[3], task: task))',
                  '            active.append(ActiveRelay(cancellation: descriptors[3], task: task))\n            if route == "control" { controlDrain = descriptors[3] }')
text=text.replace('try await ReplacementCommands.run(arguments)','try await ReplacementCommands.run(arguments, controlDrain: controlDrain)');path.write_text(text)
path=consumer/'Sources/ReplacementCommands.swift';text=path.read_text()
text=text.replace('static func run(_ args: [String]) async throws','static func run(_ args: [String], controlDrain: Int32?) async throws')
text=text.replace('PendingCommands.execute(mode, input:input, enrollment:enrollment)','PendingCommands.execute(mode, input:input, enrollment:enrollment, controlDrain:controlDrain)');path.write_text(text)
path=consumer/'Sources/PendingCommands.swift';text=path.read_text()
text=text.replace('enrollment: ContinuityEnrollment) async throws','enrollment: ContinuityEnrollment, controlDrain: Int32?) async throws')
text=text.replace('PendingInterruption.run(mode, input: input, enrollment: enrollment)','PendingInterruption.run(mode, input: input, enrollment: enrollment, controlDrain: controlDrain)');path.write_text(text)
path=consumer/'Sources/PendingInterruption.swift';text=path.read_text()
text=text.replace('enrollment: ContinuityEnrollment) async throws','enrollment: ContinuityEnrollment, controlDrain: Int32?) async throws')
key='''                    try send(descriptor, [4])
                    try cut(binding: request.binding, phase: 1)'''
sdk.require(text.count(key)==1,'cut drain boundary')
text=text.replace(key,'''                    guard let controlDrain else { throw ClientError("missing owned control relay") }
                    try send(descriptor, [4])
                    let drained = qpc_test_relay_control_forwarded(controlDrain)
                    try requireIOS(drained == 0, "control byte not forwarded before process cut: \\(drained)")
                    try cut(binding: request.binding, phase: 1)''');path.write_text(text)
source['source_files']={str(path.relative_to(consumer)):sdk.snapshot(path).sha256 for path in consumer.rglob('*') if path.is_file()}
sdk.write_json(stage/'APP_SOURCE_03.json',source)
print('Explicit local relay drain precedes the abrupt cut; host protocol and exit proof remain unchanged')
