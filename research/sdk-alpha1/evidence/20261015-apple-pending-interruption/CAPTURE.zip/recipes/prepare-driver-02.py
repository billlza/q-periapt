from pathlib import Path
import ast
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent
path=stage/'ios_client.py';text=path.read_text()
text=text.replace('import sys,json,hashlib,secrets,shutil,tempfile','import sys,json,hashlib,secrets,shutil,tempfile,re')
text=text.replace('CUT=set()',"CUT={'pending-confirm-process-cut','pending-confirm-result-cut'}")
key="PEER={'family'";sdk.require(text.count(key)==1,'driver input declarations')
text=text.replace(key,"MODES |= CUT | {'pending-confirm-inflight'}\nALLOWED |= {'cancel-control-token','cancel-control-address','witness-tls-peer','witness-tls-name','witness-tls-cert','witness-tls-key'}\n"+key)
text=text.replace("OUT/'device-cases-08'","OUT/'device-cases-04'")
old="  result=usb_transport.launch(device,BUNDLE,mode,profile,case,run,capture,{r:p.read_text() for r,p in [('peer',source/'connection-address'),('witness',source/'witness-address')] if p.exists()},'signed',True)"
new="""  carrier=(source/'witness-carrier').read_text()
  if carrier not in {'signed','tls'}:raise RuntimeError('witness carrier')
  routes=[('peer',source/'connection-address'),('witness',source/'witness-address')]
  if mode in {'pending-confirm-inflight','pending-confirm-process-cut'}:routes.append(('control',source/'cancel-control-address'))
  result=usb_transport.launch(device,BUNDLE,mode,profile,case,run,capture,{r:p.read_text() for r,p in routes if p.exists()},carrier,True)"""
sdk.require(text.count(old)==1,'driver launch boundary');text=text.replace(old,new)
start=text.index(" command(device,['device','copy','from','--source','Documents/receipt-")
end=text.index(' if not 1<=len(data)<=8388608:',start)
text=text[:start]+''' if mode in CUT:
  records=[match[1] for line in result.stdout.splitlines() if (match:=re.fullmatch(rb'QPC_IOS_CUT_RECORD run='+run.encode()+rb' data=([0-9a-f]{82})',line))]
  if len(records)!=1:raise RuntimeError('missing exact public cut record')
  data=bytes.fromhex(records[0].decode())
  if data[:8]!=b'QPPCUT01' or data[8]!=(1 if mode=='pending-confirm-process-cut' else 2):raise RuntimeError('cut phase framing')
  # Return the independently reaped app's cut promptly to the native control
  # peer. Container readback remains required by the outer run before acceptance.
  with (capture/'public-result.bin').open('xb') as stream:stream.write(data)
  with (capture/'expected-receipt.txt').open('xb') as stream:stream.write(marker)
 else:
  command(device,['device','copy','from','--source','Documents/receipt-'+run+'.txt','--destination',str(capture/'receipt.txt'),*domain],capture/'receipt-copy')
  if (capture/'receipt.txt').read_bytes()!=marker:raise RuntimeError('container receipt differs')
  command(device,['device','copy','from','--source','Documents/result-'+run+'.bin','--destination',str(capture/'public-result.bin'),*domain],capture/'result-copy')
  data=(capture/'public-result.bin').read_bytes()
''' +text[end:]
text=text.replace("'app_exit':expected_exit,","'app_exit':expected_exit,'container_readback_deferred':mode in CUT,")
ast.parse(text);path.write_text(text)
path=stage/'usb_transport.py';text=path.read_text()
text=text.replace('import socket,struct,plistlib,subprocess,threading,queue,time,select,tempfile,json,re','import socket,struct,plistlib,subprocess,threading,queue,time,select,tempfile,json,re,errno')
start=text.index('def _forward(');end=text.index('\ndef launch(',start)
text=text[:start]+'''def _forward(left,right,allow_device_cut=False):
 live={left:right,right:left};counts=[0,0];deadline=time.monotonic()+35
 while live:
  if time.monotonic()>=deadline:raise TimeoutError('USB relay deadline')
  ready,_,_=select.select(list(live),[],[],1)
  for src in ready:
   try:data=src.recv(16384)
   except OSError as error:
    if allow_device_cut and src is left and error.errno==errno.ECONNRESET:return counts,'device-reset'
    raise
   dest=live[src]
   if not data:
    try:dest.shutdown(socket.SHUT_WR)
    except OSError as error:
     if error.errno!=errno.ENOTCONN:raise
    if allow_device_cut and src is left:return counts,'device-eof'
    del live[src]
   else:
    try:dest.sendall(data)
    except OSError as error:
     if allow_device_cut and dest is left and error.errno in {errno.EPIPE,errno.ECONNRESET,errno.ENOTCONN}:return counts,'device-write-closed'
     raise
    counts[0 if src is left else 1]+=len(data)
 return counts,None
''' +text[end:]
text=text.replace("route not in {'peer','witness'}","route not in {'peer','witness','control'}")
text=text.replace('route=(peer|witness) port=', 'route=(peer|witness|control) port=')
text=text.replace('ThreadPoolExecutor(max_workers=2)','ThreadPoolExecutor(max_workers=3)')
old="   with peer:counts=_forward(usb,peer)\n  return {'route':route,'index':index,'completed':True,'bytes_by_direction':counts}"
new="""   allow_cut=mode=='pending-confirm-process-cut' and route in {'witness','control'}
   with peer:counts,cut=_forward(usb,peer,allow_cut)
  return {'route':route,'index':index,'completed':cut is None,'expected_device_disconnect':cut,'bytes_by_direction':counts}"""
sdk.require(text.count(old)==1,'relay completion boundary');text=text.replace(old,new)
ast.parse(text);path.write_text(text)
print('Control relay and explicit cut receipts prepared; deferred readback is mandatory before physical acceptance')
