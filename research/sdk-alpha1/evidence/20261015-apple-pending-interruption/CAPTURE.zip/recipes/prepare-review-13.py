from pathlib import Path
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / 'capture-10.py').read_text()


def replace(old, new):
    global text
    sdk.require(text.count(old) == 1, 'review recipe boundary changed')
    text = text.replace(old, new)


replace('import base64\n', 'import sys\n')
replace("stage = Path(__file__).resolve().parent\n", "stage = Path(__file__).resolve().parent\nsys.path.insert(0, str(stage))\nimport census_review\n")
replace("sdk.require(state['completed'] and state['cleanup'] and not state['live_producer'], 'device producer not accepted and terminal')\nsdk.require(json.loads((stage / 'device-driver-09.json').read_text())['returncode'] == 0, 'outer producer incomplete')", """sdk.require(not state['completed'] and state['cleanup'] and not state['live_producer']
            and state['failure'] == "ValueError('physical route/mode census differs')", 'unexpected producer failure or live state')
sdk.require(json.loads((stage / 'device-driver-09.json').read_text())['returncode'] == 1, 'original failed producer record changed')
sdk.require(json.loads((stage / 'census-controls-12.json').read_text())['returncode'] == 0, 'offline census controls incomplete')""")
replace("observed = {}\npids = set()", "observed = {}\nlaunch_arguments = []\nresults = {}\npids = set()")
replace("    args = process['launchOptions']['arguments']\n", "    args = process['launchOptions']['arguments']\n    launch_arguments.append(args)\n")
old = """    expected[(case, profile, carrier)] = [mode for _, mode in pending.cases(outcome == 'applied', **flags)]
    stdout = (stage / ('device-06-' + kind + '-' + label + '.stdout')).read_bytes()
    sdk.require(pending.verify_execution(stdout, stage / 'public-06', label, **flags)[full_label] == state['cases'][full_label], 'public route reread differs')
sdk.require(set(expected) == set(observed) and all(Counter(expected[key]) == Counter(observed[key]) for key in expected), 'operation census differs')"""
new = """    command_prefix = stage / ('device-06-' + kind + '-' + label)
    sdk.require(json.loads(command_prefix.with_suffix('.json').read_text())['returncode'] == 0, 'native route did not finish successfully')
    stdout = command_prefix.with_suffix('.stdout').read_bytes()
    results.update(pending.verify_execution(stdout, stage / 'public-06', label, **flags))
sdk.require(state['completed_routes'] == [label + '-' + kind for kind, label in routes], 'route completion record differs')
census = census_review.verify(launch_arguments, stage / 'device-cases-04')"""
replace(old, new)
start = text.index('for kind, label in routes:\n    inputs =')
end = text.index('signing = json.loads', start)
text = text[:start] + """# This review opens only public receipts, source and build artifacts. Private
# runtime cohorts remain sealed. Capture construction explicitly excludes input
# directories, keys, owner stores, native binaries and provisioning profiles.
sdk.require(all(not name.endswith(('/tls-key', '/witness-tls-key', '.redb', '.mobileprovision'))
                and not name.startswith('device-cases-') for name in files), 'private file selected')
for name, payload in files.items():
    sdk.require(b'-----BEGIN PRIVATE KEY-----' not in payload
                and b'-----BEGIN EC PRIVATE KEY-----' not in payload, 'private key text in capture')
""" + text[end:]
replace("    'sdk_implementation_changed': False, 'protocol_or_storage_changed': False, 'release_claim_eligible': False, 'goal_active': True}", """    'sdk_implementation_changed': False, 'protocol_or_storage_changed': False, 'release_claim_eligible': False, 'goal_active': True,
    'original_producer_completed': False, 'original_failure_retained': True,
    'offline_phase_census_completed': True, 'runtime_rerun_or_reopen': False, 'phase_census': census}""")
replace("state['cases'][full_label]", "results[full_label]")
replace("    'private_keys_excluded': True, 'public_readers': 4, 'physical_process_census': 90, 'actual_process_cuts': 4})", """    'private_keys_excluded': True, 'private_exclusion_method': 'explicit public file selection; no private runtime reopened',
    'original_producer_failure_preserved': True, 'phase_census_review_completed': True,
    'public_readers': 4, 'physical_process_census': 90, 'actual_process_cuts': 4})
sdk.write_json(stage / 'VERIFIED_14.json', {'completed': True, 'source_commit': prepared['source_commit'],
    'original_producer_completed': False, 'original_failure': state['failure'], 'runtime_rerun_or_reopen': False,
    'phase_census': census, 'actual_process_cuts': cut_count, 'cases': results,
    'capture_sha256': manifest['capture_sha256'], 'cleanup': True})""")
for unused in ['from collections import Counter\n', 'observed = {}\n', 'expected = {}\n',
               "    observed.setdefault((row['case'], row['profile'], args[4]), []).append(row['mode'])\n",
               "    case = hashlib.sha256(str(stage / 'device-cases-04' / full_label / 'installation').encode()).hexdigest()[:32]\n"]:
    replace(unused, '')
with (stage / 'capture-14.py').open('x') as stream:
    stream.write(text)
print('Separate public-only review preserves the original failed producer and its exact inputs')
