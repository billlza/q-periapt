from concurrent.futures import ThreadPoolExecutor
import socket
import unittest
from relay_forward import forward


def read_exact(stream, length):
    result=b''
    while len(result)<length:
        block=stream.recv(length-len(result))
        if not block:raise AssertionError('unexpected EOF')
        result+=block
    return result


class ForwardTests(unittest.TestCase):
    def sockets(self):
        sockets=(*socket.socketpair(),*socket.socketpair())
        for stream in sockets:stream.settimeout(2);self.addCleanup(stream.close)
        return sockets

    def test_ordinary_half_close_preserves_response(self):
        device,left,right,host=self.sockets()
        with ThreadPoolExecutor(max_workers=1) as executor:
            pending=executor.submit(forward,left,right)
            device.sendall(b'hello');device.shutdown(socket.SHUT_WR)
            self.assertEqual(read_exact(host,5),b'hello')
            self.assertEqual(host.recv(1),b'')
            self.assertFalse(pending.done())
            host.sendall(b'reply');host.shutdown(socket.SHUT_WR)
            self.assertEqual(read_exact(device,5),b'reply')
            self.assertEqual(pending.result(timeout=3),([5,5],None))

    def test_cut_finishes_without_waiting_for_host_exit_ack(self):
        device,left,right,host=self.sockets()
        with ThreadPoolExecutor(max_workers=1) as executor:
            pending=executor.submit(forward,left,right,True)
            identity_and_cut=b'x'*72+b'\4'
            device.sendall(identity_and_cut);device.shutdown(socket.SHUT_WR)
            self.assertEqual(read_exact(host,73),identity_and_cut)
            self.assertEqual(host.recv(1),b'')
            self.assertEqual(pending.result(timeout=3),([73,0],'device-eof'))

    def test_device_write_failure_is_not_accepted_without_cut_mode(self):
        device,left,right,host=self.sockets();device.close()
        with ThreadPoolExecutor(max_workers=1) as executor:
            pending=executor.submit(forward,left,right)
            host.sendall(b'reply');host.shutdown(socket.SHUT_WR)
            with self.assertRaises(OSError):pending.result(timeout=3)


if __name__=='__main__':unittest.main()
