"""Offline public launch census; never opens or runs a private device owner."""
from collections import Counter
from pathlib import Path
import hashlib
import continuity_android_pending as pending
import rust_sdk_profile as sdk

ROUTES = [(kind, label) for kind in ('query-cancel', 'process-loss')
          for label in ('signed-fixed-unapplied', 'tls-recoverable-applied')]
SETUP = ('managed-witness-create', 'authority-create', 'managed-witness-prepare')


def expected(cases: Path) -> Counter:
    result = Counter()
    for kind, label in ROUTES:
        carrier, profile, outcome = label.split('-')
        case = hashlib.sha256(str(cases / (label + '-' + kind) / 'installation').encode()).hexdigest()[:32]
        steps = pending.cases(outcome == 'applied', query_cancel=kind == 'query-cancel', process_loss=kind == 'process-loss')
        sdk.require(tuple(mode for _, mode in steps[:3]) == SETUP, 'registration prefix changed')
        for index, (_, mode) in enumerate(steps):
            # flow.rs creates the original identity and genesis before
            # transport::Carrier::start selects the configured witness carrier.
            selected = 'signed' if index < 3 else carrier
            result[(case, profile, selected, mode)] += 1
    return result


def verify(arguments: list[list[str]], cases: Path) -> dict:
    observed = Counter()
    runs = set()
    for args in arguments:
        sdk.require(len(args) == 6 and args[5] == 'managed', 'invalid launch framing')
        mode, profile, case, run, carrier, _ = args
        sdk.require(run not in runs, 'duplicate launch identity')
        runs.add(run)
        observed[(case, profile, carrier, mode)] += 1
    sdk.require(observed == expected(cases), 'exact phase/carrier/mode census differs')
    sdk.require(len(arguments) == 90, 'process count differs')
    return {'physical_processes': 90, 'routes': 4, 'setup_invocations': 12,
            'setup_carrier': 'signed', 'tls_after_registration_invocations': 38}
