from pathlib import Path
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / 'capture-14.py').read_text()
old = """for name, payload in files.items():
    sdk.require(b'-----BEGIN PRIVATE KEY-----' not in payload
                and b'-----BEGIN EC PRIVATE KEY-----' not in payload, 'private key text in capture')
"""
new = """# Recipe source contains the scanner's own literal. Scan data artifacts for
# actual PEM framing, including JSON-escaped line endings. Sources and preimages
# are separately selected by their recorded file identities.
import re
pem_key = re.compile(rb'-----BEGIN (?:EC |RSA |ENCRYPTED |OPENSSH )?PRIVATE KEY-----(?:\\r?\\n|\\\\r?\\\\n)')
sdk.require(pem_key.search(b'-----BEGIN PRIVATE KEY-----\\nAA==\\n-----END PRIVATE KEY-----'), 'PEM scanner positive control')
sdk.require(pem_key.search(b'-----BEGIN PRIVATE KEY-----\\\\nAA=='), 'JSON PEM scanner positive control')
sdk.require(not pem_key.search(b"b'-----BEGIN PRIVATE KEY-----'"), 'PEM scanner literal control')
for name, payload in files.items():
    if not name.startswith(('recipes/', 'source/', 'consumer/', 'preimages/')):
        sdk.require(not pem_key.search(payload), 'private key text in capture')
"""
sdk.require(text.count(old) == 1, 'capture scanner shape changed')
with (stage / 'capture-17.py').open('x') as stream:
    stream.write(text.replace(old, new))
print('Preserved failed scanner; separate capture checks PEM data without treating source literals as keys')
