from pathlib import Path
import ast
import json
import subprocess
import tempfile
import secrets
import rust_sdk_profile as sdk
import continuity_apple_package as apple

root=Path.cwd();stage=Path(__file__).resolve().parent
previous=root/'target/continuity-apple-pending-recovery';accepted=previous/'attempt-24'
old=json.loads((accepted/'APP.json').read_text());prepared=json.loads((previous/'PREPARED_03.json').read_text())
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'clean source required')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
allowed={'.github/workflows/codeql-memory-control.yml','artifact/codeql_memory_control.py','artifact/test_codeql_memory_control.py',
 'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md'}
changed=subprocess.check_output(['git','diff','--name-only',prepared['source_commit'],head],text=True).splitlines()
sdk.require(all(name in allowed or name.startswith('research/sdk-alpha1/evidence/20261015-apple-pending-recovery/') for name in changed),'SDK implementation differs from actual Apple package')
installed=Path(prepared['outside'])/'apple-package/installed'/apple.NAME
package=json.loads((previous/'package-04/CONTINUITY_APPLE_PACKAGE.json').read_text())
contents=json.loads((installed/apple.CONTENTS).read_text())
apple.verify_package(installed,contents,package['native'],(root/'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes())
for source in (root/'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity').glob('*.swift'):
    sdk.require(source.read_bytes()==(installed/'Sources/QPeriaptContinuity'/source.name).read_bytes(),'public Swift implementation differs')
outside=Path(tempfile.mkdtemp(prefix='qpc-apple-pending-cuts-')).resolve();consumer=outside/'consumer'
for name,digest in old['source_files'].items():
    source=Path(old['consumer'])/name;sdk.require(sdk.snapshot(source).sha256==digest,'accepted source changed')
    sdk.copy(source,consumer/name)
for name in ['PendingControl.h','PendingControl.c','PendingInterruption.swift']:sdk.copy(stage/name,consumer/'Sources'/name)
path=consumer/'Sources/USBRelay.h'
path.write_text(path.read_text()+'\n#include "PendingControl.h"\n')
path=consumer/'Sources/PendingCommands.swift';text=path.read_text()
text=text.replace('enrollment: ContinuityEnrollment) throws -> [UInt8] {','enrollment: ContinuityEnrollment) async throws -> [UInt8] {')
key='        switch mode {\n';sdk.require(text.count(key)==1,'pending dispatch shape')
text=text.replace(key,'''        if ["pending-confirm-inflight", "pending-confirm-process-cut", "pending-confirm-result-cut"].contains(mode) {
            return try await PendingInterruption.run(mode, input: input, enrollment: enrollment)
        }
'''+key);path.write_text(text)
path=consumer/'Sources/ReplacementCommands.swift';text=path.read_text()
text=text.replace('static func run(_ args: [String]) throws {','static func run(_ args: [String]) async throws {')
text=text.replace('        let outcome = Result {','        let operation = { () async throws -> [UInt8] in')
text=text.replace('return try PendingCommands.execute(mode, input:input, enrollment:enrollment)','return try await PendingCommands.execute(mode, input:input, enrollment:enrollment)')
text=text.replace('let selected = try witness(input.source,"signed",wrong:false)',
 'let carrier = String(bytes:try input.read("witness-carrier",16),encoding:.ascii)\n            guard let carrier, ["signed","tls"].contains(carrier) else { throw ClientError("witness carrier") }\n            let selected = try witness(input.source,carrier,wrong:false)')
key='        var failures: [String] = []';sdk.require(text.count(key)==1,'async cleanup boundary')
text=text.replace(key,'''        let outcome: Result<[UInt8], Error>
        do { outcome = .success(try await operation()) } catch { outcome = .failure(error) }
'''+key);path.write_text(text)
path=consumer/'Sources/USBOperation.swift';text=path.read_text()
text=text.replace('    let operation = Result {','    let operation: Result<Void, Error>\n    do {')
text=text.replace('        let routes = [("peer", peerSource.appendingPathComponent("connection-address")), ("witness", source.appendingPathComponent("witness-address"))]',
'''        var routes = [("peer", peerSource.appendingPathComponent("connection-address")), ("witness", source.appendingPathComponent("witness-address"))]
        if ["pending-confirm-inflight", "pending-confirm-process-cut"].contains(mode) {
            routes.append(("control", source.appendingPathComponent("cancel-control-address")))
        }''')
text=text.replace('        try ReplacementCommands.run(arguments)\n    }','        try await ReplacementCommands.run(arguments)\n        operation = .success(())\n    } catch { operation = .failure(error) }')
path.write_text(text)
path=consumer/'Sources/Runner.swift';text=path.read_text();text=text.replace('args[4]=="signed"','["signed","tls"].contains(args[4])');path.write_text(text)
project=json.loads((consumer/'project.json').read_text());bundle='dev.qperiapt.PendingInterruption.r'+secrets.token_hex(12)
project['packages']['Continuity']['path']=str(installed)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER']=bundle
(consumer/'project.json').write_text(json.dumps(project,indent=2)+'\n')
sdk.write_json(stage/'APP_SOURCE_01.json',{'consumer':str(consumer),'bundle':bundle,
 'source_files':{str(p.relative_to(consumer)):sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}})
host=json.loads((root/'target/continuity-android-pending-continuation/BUILD_18.json').read_text())
files={name:{'path':host[name],'sha256':host[name+'_sha256']} for name in ['harness','receiver','library']}
for record in files.values():sdk.require(sdk.snapshot(Path(record['path']),maximum=256*1024**2).sha256==record['sha256'],'host runtime changed')
sdk.write_json(stage/'PREPARED_01.json',{'source_commit':head,'sdk_source_commit':prepared['source_commit'],
 'outside':str(outside),'consumer':str(consumer),'installed':str(installed),'package_sha256':old['package_sha256'],
 'package_record':str(previous/'package-04/CONTINUITY_APPLE_PACKAGE.json'),'environment':prepared['environment'],
 'host_files':files,'changed_since_sdk_package':changed,'scope':'Same actual SDK package; new Swift public cancellation and process-cut consumer'})
for name in ['device_support.py','ios_client.py','usb_transport.py']:sdk.copy(accepted/name,stage/name)
(stage/'ios_client.py').chmod(0o700)
print('Fresh interruption consumer prepared from the accepted package and verified unchanged SDK source')
