from copy import deepcopy
from pathlib import Path
import json
import unittest
import census_review


class CensusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stage = Path(__file__).resolve().parent
        cls.arguments = [json.loads(path.read_text())['launchOptions']['arguments']
                         for path in sorted((cls.stage / 'device-execution').glob('*/PROCESS_RESULT.json'))]

    def test_complete_public_launches_match_each_phase(self):
        result = census_review.verify(self.arguments, self.stage / 'device-cases-04')
        self.assertEqual(result['physical_processes'], 90)

    def test_any_carrier_substitution_is_rejected(self):
        for index, args in enumerate(self.arguments):
            with self.subTest(mode=args[0], profile=args[1], carrier=args[4]):
                changed = deepcopy(self.arguments)
                changed[index][4] = 'tls' if args[4] == 'signed' else 'signed'
                with self.assertRaisesRegex(ValueError, 'census differs'):
                    census_review.verify(changed, self.stage / 'device-cases-04')

    def test_missing_extra_or_reused_run_cannot_pass(self):
        for changed in (self.arguments[:-1], self.arguments + [self.arguments[0]]):
            with self.assertRaises(ValueError):
                census_review.verify(changed, self.stage / 'device-cases-04')
        changed = deepcopy(self.arguments)
        changed[-1][3] = changed[0][3]
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            census_review.verify(changed, self.stage / 'device-cases-04')

    def test_profile_mode_or_case_substitution_cannot_pass(self):
        for index in (0, 1, 2):
            changed = deepcopy(self.arguments)
            changed[0][index] = 'substituted'
            with self.assertRaisesRegex(ValueError, 'census differs'):
                census_review.verify(changed, self.stage / 'device-cases-04')


if __name__ == '__main__':
    unittest.main()
