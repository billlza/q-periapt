from pathlib import Path
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / 'capture-17.py').read_text()
start = text.index('# Recipe source contains')
end = text.index('signing = json.loads', start)
text = text[:start] + '''from public_capture_check import contains_private_pem
for name, payload in files.items():
    if not name.startswith(('recipes/', 'source/', 'consumer/', 'preimages/')):
        sdk.require(not contains_private_pem(name, payload), 'private PEM data in capture')
''' + text[end:]
with (stage / 'capture-20.py').open('x') as stream:
    stream.write(text)
print('New capture uses tested plain-text and decoded-JSON PEM inspection')
