import json
import unittest
from public_capture_check import contains_private_pem


class PublicDataTests(unittest.TestCase):
    def test_pem_body_in_data_is_rejected(self):
        for prefix in ('', 'RSA ', 'EC ', 'ENCRYPTED ', 'OPENSSH '):
            payload = ('-----BEGIN ' + prefix + 'PRIVATE KEY-----\nAA==\n').encode()
            self.assertTrue(contains_private_pem('sample.stdout', payload))

    def test_nested_json_pem_is_rejected(self):
        for newline in ('\n', '\r\n'):
            payload = json.dumps({'nested': ['-----BEGIN PRIVATE KEY-----' + newline + 'AA==']}).encode()
            self.assertTrue(contains_private_pem('sample.json', payload))

    def test_source_literal_is_not_a_pem_record(self):
        self.assertFalse(contains_private_pem('failure.stderr', b"    test(b'-----BEGIN PRIVATE KEY-----\\nAA==')\n"))

    def test_malformed_json_cannot_skip_inspection(self):
        with self.assertRaises(json.JSONDecodeError):
            contains_private_pem('sample.json', b'{broken')


if __name__ == '__main__':
    unittest.main()
