from pathlib import Path
import sys
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root = Path.cwd()
stage = Path(__file__).resolve().parent
sys.path.insert(0, str(stage))
import census_review
state = json.loads((stage / 'RESULT_06.json').read_text())
app = json.loads((stage / 'APP.json').read_text())
prepared = json.loads((stage / 'PREPARED_01.json').read_text())
sdk.require(not state['completed'] and state['cleanup'] and not state['live_producer']
            and state['failure'] == "ValueError('physical route/mode census differs')", 'unexpected producer failure or live state')
sdk.require(json.loads((stage / 'device-driver-09.json').read_text())['returncode'] == 1, 'original failed producer record changed')
sdk.require(json.loads((stage / 'census-controls-12.json').read_text())['returncode'] == 0, 'offline census controls incomplete')
sdk.require(sdk.snapshot(Path(app['app']) / 'ContinuityIOSRunner', maximum=128*1024**2).sha256 == app['executable_sha256'], 'signed executable changed')
for name, digest in app['driver_files'].items():
    sdk.require(sdk.snapshot(stage / name).sha256 == digest, 'executed driver changed')
for name, digest in app['source_files'].items():
    sdk.require(sdk.snapshot(Path(app['consumer']) / name).sha256 == digest, 'executed app source changed')
package_path = Path(prepared['package_record'])
package = json.loads(package_path.read_text())
sdk.require(package['completed'] and sdk.snapshot(package_path.parent / package['archive']['file'], maximum=256*1024**2).sha256 == app['package_sha256'], 'package changed')

routes = [(kind, label) for kind in ('query-cancel', 'process-loss')
          for label in ('signed-fixed-unapplied', 'tls-recoverable-applied')]
launch_arguments = []
results = {}
pids = set()
cut_count = 0
for folder in (stage / 'device-execution').iterdir():
    sdk.require(folder.is_dir() and not folder.is_symlink(), 'unexpected execution entry')
    row = json.loads((folder / 'RESULT.json').read_text())
    usb = json.loads((folder / 'USB_TRANSPORT.json').read_text())
    process = json.loads((folder / 'PROCESS_RESULT.json').read_text())
    cut = row['mode'] in {'pending-confirm-process-cut', 'pending-confirm-result-cut'}
    exit_code = 77 if cut else 0
    sdk.require(row['completed'] and row['run'] == folder.name and row['app_exit'] == exit_code, 'operation result incomplete')
    sdk.require(usb['completed'] and usb['startup_admitted'], 'startup/transport incomplete')
    marker = f"QPC_IOS_REPLACEMENT_{'CUT' if cut else 'PASS'} mode={row['mode']} profile={row['profile']} run={row['run']}\n".encode()
    lines = (folder / 'launch.stdout').read_bytes().splitlines()
    sdk.require(lines.count(marker.strip()) == 1 and lines.count(f'The app terminated with the exit code {exit_code}.'.encode()) == 1, 'console termination differs')
    sdk.require((folder / 'launch.stderr').read_bytes() == b'' and (folder / 'receipt.txt').read_bytes() == marker, 'diagnostic or container receipt differs')
    sdk.require(sdk.snapshot(folder / 'public-result.bin').sha256 == row['public_result_sha256'], 'public output changed')
    sdk.require(process['terminationResult'] == {'exitCode': exit_code, 'wasCoreDumpCreated': False}, 'CoreDevice termination differs')
    args = process['launchOptions']['arguments']
    launch_arguments.append(args)
    sdk.require(len(args) == 6 and args[:4] == [row['mode'], row['profile'], row['case'], row['run']]
                and args[4] in {'signed', 'tls'} and args[5] == 'managed', 'launch arguments differ')
    sdk.require(process['launchOptions']['terminateExistingInstances'] is True, 'fresh launch flag absent')
    pid = process['process']['processIdentifier']
    sdk.require(isinstance(pid, int) and pid > 0 and pid not in pids, 'process reused')
    pids.add(pid)
    before = json.loads((folder / 'PRELAUNCH_PROCESSES.json').read_text())
    sdk.require(pid not in {item['processIdentifier'] for item in before}, 'prior process reused')
    sdk.require(json.loads((folder / 'postlaunch.status.json').read_text())['returncode'] == 0, 'post-exit query failed')
    if cut:
        readback = json.loads((folder / 'CONTAINER_READBACK.json').read_text())
        sdk.require(readback['completed'] and readback['run'] == row['run']
                    and readback['public_result_sha256'] == row['public_result_sha256'], 'deferred container readback missing')
        sdk.require((folder / 'container-public-result.bin').read_bytes() == (folder / 'public-result.bin').read_bytes(), 'cut record differs')
        cut_count += 1
for kind, label in routes:
    carrier, profile, outcome = label.split('-')
    flags = {'query_cancel': kind == 'query-cancel', 'process_loss': kind == 'process-loss'}
    full_label = label + '-' + kind
    command_prefix = stage / ('device-06-' + kind + '-' + label)
    sdk.require(json.loads(command_prefix.with_suffix('.json').read_text())['returncode'] == 0, 'native route did not finish successfully')
    stdout = command_prefix.with_suffix('.stdout').read_bytes()
    results.update(pending.verify_execution(stdout, stage / 'public-06', label, **flags))
sdk.require(state['completed_routes'] == [label + '-' + kind for kind, label in routes], 'route completion record differs')
census = census_review.verify(launch_arguments, stage / 'device-cases-04')
sdk.require(len(pids) == 90 and cut_count == 4, 'process census differs')

files = {}
def add(path, name):
    sdk.require(name not in files, 'duplicate capture entry')
    files[name] = sdk.snapshot(path, maximum=32*1024**2).data

for path in stage.iterdir():
    if path.is_file() and path.suffix in {'.py', '.c', '.h', '.swift'}:
        add(path, 'recipes/' + path.name)
    elif path.is_file() and path.suffix in {'.json', '.stdout', '.stderr'} and path.name != 'PREPARED_01.json':
        add(path, 'receipts/' + path.name)
files['receipts/PREPARED_01.json'] = (json.dumps({key: value for key, value in prepared.items() if key != 'environment'}, indent=2, sort_keys=True) + '\n').encode()
add(package_path, 'package/CONTINUITY_APPLE_PACKAGE.json')
for name in app['source_files']:
    add(Path(app['consumer']) / name, 'consumer/' + name)
for path in (stage / 'before-drain').iterdir():
    add(path, 'preimages/' + path.name)
for name in ['artifact/continuity_android_pending.py', 'artifact/continuity_android_contract.py',
             'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/flow.rs',
             'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/transport.rs',
             'bindings/c/ContinuityPackageConsumer/qpc_owner.h']:
    add(root / name, 'source/' + name)
for path in (root / 'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity').glob('*.swift'):
    add(path, 'source/' + path.relative_to(root).as_posix())
for kind, label in routes:
    full_label = label + '-' + kind
    flags = {'query_cancel': kind == 'query-cancel', 'process_loss': kind == 'process-loss'}
    for name in pending.public(label.endswith('-applied'), **flags):
        add(stage / 'public-06' / full_label / name, 'public/' + full_label + '/' + name)
for directory in ('device-control-06', 'device-execution'):
    for path in (stage / directory).rglob('*'):
        if path.is_file():
            sdk.require(path.suffix in {'.json', '.stdout', '.stderr', '.txt', '.bin'}, 'unexpected public evidence type')
            add(path, directory + '/' + path.relative_to(stage / directory).as_posix())
# This review opens only public receipts, source and build artifacts. Private
# runtime cohorts remain sealed. Capture construction explicitly excludes input
# directories, keys, owner stores, native binaries and provisioning profiles.
sdk.require(all(not name.endswith(('/tls-key', '/witness-tls-key', '.redb', '.mobileprovision'))
                and not name.startswith('device-cases-') for name in files), 'private file selected')
from public_capture_check import contains_private_pem
for name, payload in files.items():
    if not name.startswith(('recipes/', 'source/', 'consumer/', 'preimages/')):
        sdk.require(not contains_private_pem(name, payload), 'private PEM data in capture')
signing = json.loads((root / 'target/continuity-ios-device-preparation/SIGNING.json').read_text())
redactions = {state['device_sha256']: '<SELECTED_DEVICE_SHA256>', signing['identity']: '<EXISTING_SIGNING_IDENTITY>',
              signing['team']: '<EXISTING_SIGNING_TEAM>', signing['profile_uuid']: '<EXISTING_PROFILE_UUID>'}
for path in (stage / 'device-execution').glob('*/PROCESS_RESULT.json'):
    identity = json.loads(path.read_text()).get('deviceIdentifier')
    if identity:
        redactions[identity] = '<SELECTED_DEVICE>'
for name, data in list(files.items()):
    if name.endswith(('.json', '.stdout', '.stderr', '.py', '.txt')):
        for value, replacement in redactions.items():
            data = data.replace(value.encode(), replacement.encode())
        files[name] = data

output = root / 'research/sdk-alpha1/evidence/20261015-apple-pending-interruption'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, data)
manifest = {'format': 1, 'source_commit': prepared['source_commit'], 'sdk_source_commit': prepared['sdk_source_commit'],
    'apple_package_sha256': app['package_sha256'], 'ios_staticlib_sha256': app['native_slice_sha256'],
    'app_sha256': app['executable_sha256'], 'capture_sha256': sdk.snapshot(archive, maximum=32*1024**2).sha256,
    'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'physical_model': state['device_model'], 'physical_os': state['device_os'], 'physical_swift_processes': 90,
    'actual_process_cuts': 4, 'startup_admissions': 90, 'routes': 4, 'cleanup': True,
    'sdk_implementation_changed': False, 'protocol_or_storage_changed': False, 'release_claim_eligible': False, 'goal_active': True,
    'original_producer_completed': False, 'original_failure_retained': True,
    'offline_phase_census_completed': True, 'runtime_rerun_or_reopen': False, 'phase_census': census}
sdk.write_json(output / 'CAPTURE.json', manifest)
with tempfile.TemporaryDirectory(prefix='qpc-apple-pending-cuts-readback-') as temporary:
    extracted = Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist()) == set(files), 'archive inventory differs')
        for name, digest in manifest['members'].items():
            data = bundle.read(name)
            sdk.require(hashlib.sha256(data).hexdigest() == digest, 'archive member digest differs')
            if name.startswith('public/'):
                path = extracted / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        for kind, label in routes:
            flags = {'query_cancel': kind == 'query-cancel', 'process_loss': kind == 'process-loss'}
            stdout = bundle.read('receipts/device-06-' + kind + '-' + label + '.stdout')
            full_label = label + '-' + kind
            sdk.require(pending.verify_execution(stdout, extracted / 'public', label, **flags)[full_label] == results[full_label], 'archive public reread differs')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'members': len(files), 'capture_sha256': manifest['capture_sha256'],
    'private_keys_excluded': True, 'private_exclusion_method': 'explicit public file selection; no private runtime reopened',
    'original_producer_failure_preserved': True, 'phase_census_review_completed': True,
    'public_readers': 4, 'physical_process_census': 90, 'actual_process_cuts': 4})
sdk.write_json(stage / 'VERIFIED_14.json', {'completed': True, 'source_commit': prepared['source_commit'],
    'original_producer_completed': False, 'original_failure': state['failure'], 'runtime_rerun_or_reopen': False,
    'phase_census': census, 'actual_process_cuts': cut_count, 'cases': results,
    'capture_sha256': manifest['capture_sha256'], 'cleanup': True})
print('Physical Swift interruption archive and independent public/process readback passed')
