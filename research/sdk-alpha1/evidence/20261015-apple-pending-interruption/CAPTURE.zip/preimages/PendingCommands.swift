// SPDX-License-Identifier: Apache-2.0 OR MIT
import Foundation
import QPeriaptContinuity

enum PendingCommands {
    static func execute(_ mode: String, input: ReplacementInputs, enrollment: ContinuityEnrollment) async throws -> [UInt8] {
        if ["pending-confirm-inflight", "pending-confirm-process-cut", "pending-confirm-result-cut"].contains(mode) {
            return try await PendingInterruption.run(mode, input: input, enrollment: enrollment)
        }
        switch mode {
        case "pending-identity": return try enrollment.request()
        case "pending-request":
            let request = try enrollment.pendingWriteRecoveryRequest()
            try requireIOS(request.proposal.count == 393 && request.binding.count == 32 &&
                (569...8388608).contains(request.metadata.count) && (1...8192).contains(request.signedRequest.count),
                "complete public request bounds")
            return bigNumber(UInt32(request.metadata.count)) + bigNumber(UInt32(request.signedRequest.count)) +
                request.proposal + [0, 0, 0] + request.binding + request.metadata + request.signedRequest
        case "pending-request-absent":
            try expect(201) { _ = try enrollment.pendingWriteRecoveryRequest() }
            return bigNumber(UInt32(201))
        case "pending-activate-expired":
            try expect(104) { let device = try enrollment.activate(); try device.close() }
            return bigNumber(UInt32(104))
        case "pending-roster-unknown":
            let peer = input.source.appendingPathComponent("peer")
            let pin = try AccountPin(account: AccountID(bytes: exact(peer, "responder-account", 32)),
                root: exact(peer, "responder-root", 1985), family: input.fixed("family", 32),
                checkpoint: RosterCheckpoint(version: counter(input.fixed("remote-roster-version", 8)[...]),
                                             digest: input.fixed("remote-roster-digest", 32)))
            let roster = try input.read("remote-roster"), device = try enrollment.activate()
            let operation = Result { try expect(218) { _ = try device.admitPeerRoster(roster: roster, pin: pin) } }
            do { try device.close() } catch { throw ClientError("device cleanup: \(error); operation: \(operation)") }
            try operation.get()
            return bigNumber(UInt32(218))
        case "pending-confirm", "pending-confirm-damaged", "pending-confirm-unapproved", "pending-confirm-cancelled":
            let proposal = try input.fixed("pending-proposal", 393)
            var metadata = try input.read("pending-metadata", 8388608)
            if mode == "pending-confirm-damaged" { metadata[metadata.count - 1] ^= 1 }
            if mode == "pending-confirm-cancelled" { try enrollment.cancel() }
            let code: Int32 = mode == "pending-confirm-damaged" ? 102 :
                mode == "pending-confirm-unapproved" ? 103 : mode == "pending-confirm-cancelled" ? 302 : 0
            if code == 0 {
                try enrollment.confirmPendingWriteRecovery(approved: proposal, recordedMetadata: metadata)
                return [1]
            }
            try expect(code) { try enrollment.confirmPendingWriteRecovery(approved: proposal, recordedMetadata: metadata) }
            return bigNumber(UInt32(code))
        default: throw ClientError("unknown pending operation")
        }
    }
}
