// SPDX-License-Identifier: Apache-2.0 OR MIT
import Foundation
import Darwin
import QPeriaptContinuity

enum PendingInterruption {
    private static func send(_ descriptor: Int32, _ bytes: [UInt8]) throws {
        let code = bytes.withUnsafeBufferPointer {
            qpc_pending_control_send(descriptor, $0.baseAddress, $0.count)
        }
        guard code == 0 else { throw ClientError("control send errno=\(code)") }
    }

    private static func receive(_ descriptor: Int32, expected: Int32) throws {
        let value = qpc_pending_control_read(descriptor)
        guard value == expected else { throw ClientError("control reply \(value), expected \(expected)") }
    }

    private static func cut(binding: [UInt8], phase: UInt8) throws -> Never {
        let arguments = Array(CommandLine.arguments.dropFirst())
        try requireIOS(arguments.count == 6 && binding.count == 32 && (phase == 1 || phase == 2), "process cut arguments")
        let mode = arguments[0], profile = arguments[1], run = arguments[3]
        let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let record = Array("QPPCUT01".utf8) + [phase] + binding
        try durableIOS(record, documents.appendingPathComponent("result-" + run + ".bin").path)
        let marker = "QPC_IOS_REPLACEMENT_CUT mode=\(mode) profile=\(profile) run=\(run)\n"
        try durableIOS(Array(marker.utf8), documents.appendingPathComponent("receipt-" + run + ".txt").path)
        let encoded = record.map { String(format: "%02x", $0) }.joined()
        try FileHandle.standardOutput.write(contentsOf: Data(("QPC_IOS_CUT_RECORD run=\(run) data=\(encoded)\n" + marker).utf8))
        // Neither the busy owner nor the control socket is closed through its
        // language wrapper. The host separately observes actual process exit.
        _exit(77)
    }

    static func run(_ mode: String, input: ReplacementInputs, enrollment: ContinuityEnrollment) async throws -> [UInt8] {
        let proposal = try input.fixed("pending-proposal", 393)
        let metadata = try input.read("pending-metadata", 8388608)
        let request = try enrollment.pendingWriteRecoveryRequest()
        try requireIOS(request.proposal == proposal && request.metadata == metadata, "original interruption request")
        if mode == "pending-confirm-result-cut" {
            try enrollment.confirmPendingWriteRecovery(approved: proposal, recordedMetadata: metadata)
            // The API returned, but no successful application result was given.
            // This is a lost-result cut, not a database-internal interruption.
            try cut(binding: request.binding, phase: 2)
        }
        try requireIOS(["pending-confirm-inflight", "pending-confirm-process-cut"].contains(mode), "interruption mode")
        let token = try input.fixed("cancel-control-token", 32)
        guard let address = String(bytes: try input.read("cancel-control-address", 128), encoding: .ascii),
              address.hasPrefix("127.0.0.1:"), let port = UInt16(address.dropFirst(10)), port > 0,
              address == "127.0.0.1:\(port)" else { throw ClientError("control loopback endpoint") }
        let descriptor = qpc_pending_control_open(port)
        guard descriptor >= 0 else { throw ClientError("control connect errno=\(-descriptor)") }
        let outcome: Result<[UInt8], Error>
        do {
            try send(descriptor, Array("QPCCAN01".utf8) + token + request.binding)
            let worker = Task.detached {
                try enrollment.confirmPendingWriteRecovery(approved: proposal, recordedMetadata: metadata)
            }
            do {
                try receive(descriptor, expected: 1)
                try expect(3) { try enrollment.close() }
                if mode == "pending-confirm-process-cut" {
                    try send(descriptor, [4])
                    try cut(binding: request.binding, phase: 1)
                }
                let before = ContinuousClock.now
                let canceller = Task.detached { try enrollment.cancel() }
                try await canceller.value
                let completion = await worker.result
                try requireIOS(before.duration(to: .now) < .seconds(5), "cancellation completion exceeded observation bound")
                guard case .failure(let error) = completion, let native = error as? ContinuityFailure,
                      native.code == 218, !native.truncated,
                      native.message.hasSuffix("witness dispatch cancelled; reconcile original command") else {
                    throw ClientError("held Query did not retain native witness uncertainty: \(completion)")
                }
                try send(descriptor, [2])
                try receive(descriptor, expected: 3)
                try receive(descriptor, expected: 256)
            } catch {
                let original = error
                let cancellation = Result { try enrollment.cancel() }
                let completion = await worker.result
                throw ClientError("pending interruption: \(original); cancellation cleanup: \(cancellation); worker: \(completion)")
            }
            outcome = .success(bigNumber(UInt32(218)))
        } catch { outcome = .failure(error) }
        let closeStatus = qpc_pending_control_close(descriptor)
        guard closeStatus == 0 else { throw ClientError("control close errno=\(closeStatus); operation: \(outcome)") }
        return try outcome.get()
    }
}
