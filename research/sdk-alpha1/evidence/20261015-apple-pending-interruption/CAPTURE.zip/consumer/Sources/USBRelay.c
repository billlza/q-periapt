#include "USBRelay.h"
#include <arpa/inet.h>
#include <errno.h>
#include <poll.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int failure(void) { return errno == 0 ? EIO : errno; }
static int close_owned(int fd, int result) {
    if (fd >= 0 && close(fd) != 0 && result == 0) return failure();
    return result;
}
static int listener(uint16_t *port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in address = {0};
    address.sin_len = sizeof(address);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    socklen_t size = sizeof(address);
    if (bind(fd, (struct sockaddr *)&address, size) != 0 || listen(fd, 1) != 0 ||
        getsockname(fd, (struct sockaddr *)&address, &size) != 0) {
        int saved = failure();
        (void)close_owned(fd, saved);
        errno = saved;
        return -1;
    }
    *port = ntohs(address.sin_port);
    return fd;
}
int qpc_test_relay_prepare(int descriptors[4], uint16_t ports[2]) {
    descriptors[0] = listener(&ports[0]);
    if (descriptors[0] < 0) return failure();
    descriptors[1] = listener(&ports[1]);
    if (descriptors[1] < 0) {
        int result = close_owned(descriptors[0], failure());
        descriptors[0] = -1;
        return result;
    }
    int cancellation[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, cancellation) != 0) {
        int result = failure();
        result = close_owned(descriptors[0], result);
        result = close_owned(descriptors[1], result);
        descriptors[0] = descriptors[1] = -1;
        return result;
    }
    int one = 1;
    if (setsockopt(cancellation[0], SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0 ||
        setsockopt(cancellation[1], SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0) {
        int result = failure();
        result = close_owned(cancellation[0], result);
        result = close_owned(cancellation[1], result);
        result = close_owned(descriptors[0], result);
        result = close_owned(descriptors[1], result);
        descriptors[0] = descriptors[1] = -1;
        return result;
    }
    descriptors[2] = cancellation[0]; descriptors[3] = cancellation[1];
    return 0;
}
static int accept_bounded(int listener_fd) {
    struct pollfd descriptor = {.fd = listener_fd, .events = POLLIN};
    int ready = poll(&descriptor, 1, 30000);
    if (ready <= 0) { if (ready == 0) errno = ETIMEDOUT; return -1; }
    int fd = accept(listener_fd, NULL, NULL);
    if (fd < 0) return -1;
    int one = 1;
    struct timeval timeout = {.tv_sec = 5, .tv_usec = 0};
    if (setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) != 0) {
        int saved = failure(); (void)close_owned(fd, saved); errno = saved; return -1;
    }
    return fd;
}
static int send_all(int fd, const unsigned char *bytes, size_t length) {
    size_t used = 0;
    while (used < length) {
        ssize_t n = send(fd, bytes + used, length - used, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return failure();
        used += (size_t)n;
    }
    return 0;
}
static int transfer(int first, int second, int cancellation, bool control) {
    size_t forwarded_control = 0;
    int sockets[2] = {first, second};
    bool ended[2] = {false, false};
    unsigned char bytes[16384];
    struct timespec start, now;
    if (clock_gettime(CLOCK_MONOTONIC, &start) != 0) return failure();
    while (!ended[0] || !ended[1]) {
        if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return failure();
        if (now.tv_sec - start.tv_sec >= 30) return ETIMEDOUT;
        struct pollfd descriptors[2] = {
            {.fd = ended[0] ? -1 : sockets[0], .events = POLLIN},
            {.fd = ended[1] ? -1 : sockets[1], .events = POLLIN}
        };
        int ready = poll(descriptors, 2, 1000);
        if (ready < 0 && errno == EINTR) continue;
        if (ready < 0) return failure();
        for (size_t i = 0; i < 2; i++) {
            if (ended[i] || descriptors[i].revents == 0) continue;
            if (descriptors[i].revents & POLLNVAL) return EBADF;
            ssize_t n = recv(sockets[i], bytes, sizeof(bytes), 0);
            if (n < 0 && errno == EINTR) continue;
            if (n < 0) return failure();
            if (n == 0) {
                ended[i] = true;
                if (shutdown(sockets[1-i], SHUT_WR) != 0 && errno != ENOTCONN) return failure();
            } else {
                int result = send_all(sockets[1-i], bytes, (size_t)n);
                if (result != 0) return result;
                if (control && i == 1) {
                    if (forwarded_control > 73 || (size_t)n > 73 - forwarded_control) return EOVERFLOW;
                    forwarded_control += (size_t)n;
                    if (forwarded_control == 73 && bytes[n-1] == 4) {
                        const unsigned char drained = 73;
                        result = send_all(cancellation, &drained, 1);
                        if (result != 0) return result;
                    }
                }
            }
        }
    }
    return 0;
}
int qpc_test_relay_stop(int cancellation) {
    int one = 1;
    int result = setsockopt(cancellation, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) == 0 ? 0 : failure();
    const unsigned char stop = 1;
    if (result == 0 && send(cancellation, &stop, 1, 0) != 1) result = failure();
    return close_owned(cancellation, result);
}
static int serve_connections(int transport_listener, int local_listener, int cancellation,
    uint16_t port, const char *route, const char *run) {
    struct timespec start, now;
    if (clock_gettime(CLOCK_MONOTONIC, &start) != 0) return failure();
    for (unsigned int index = 1; ; index++) {
        int local = -1;
        while (local < 0) {
            if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return failure();
            if (now.tv_sec - start.tv_sec >= 60) return ETIMEDOUT;
            struct pollfd incoming[2] = {
                {.fd = cancellation, .events = POLLIN},
                {.fd = local_listener, .events = POLLIN}
            };
            int ready = poll(incoming, 2, 500);
            if (ready < 0 && errno == EINTR) continue;
            if (ready < 0) return failure();
            if (incoming[0].revents != 0) {
                unsigned char byte = 0;
                return recv(cancellation, &byte, 1, 0) == 1 && byte == 1 ? 0 : EIO;
            }
            if (incoming[1].revents != 0) local = accept_bounded(local_listener);
            if (incoming[1].revents != 0 && local < 0) return failure();
        }
        if (index > 64) return close_owned(local, EOVERFLOW);
        char marker[256];
        int length = snprintf(marker, sizeof(marker),
            "QPC_IOS_RELAY_NEXT run=%s route=%s port=%u index=%u\n", run, route, port, index);
        if (length <= 0 || (size_t)length >= sizeof(marker)) return close_owned(local, EOVERFLOW);
        size_t offset = 0;
        while (offset < (size_t)length) {
            ssize_t count = write(STDOUT_FILENO, marker + offset, (size_t)length - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) return close_owned(local, failure());
            offset += (size_t)count;
        }
        int transport = accept_bounded(transport_listener);
        int result = transport < 0 ? failure() : transfer(transport, local, cancellation, strcmp(route, "control") == 0);
        result = close_owned(transport, result);
        result = close_owned(local, result);
        if (result != 0) return result;
    }
    return EOVERFLOW;
}
int qpc_test_relay_run(int transport_listener, int local_listener, int cancellation,
    uint16_t transport_port, const char *route, const char *run) {
    int result = serve_connections(transport_listener, local_listener, cancellation, transport_port, route, run);
    result = close_owned(transport_listener, result);
    result = close_owned(local_listener, result);
    return close_owned(cancellation, result);
}

int qpc_test_relay_control_forwarded(int cancellation) {
    struct pollfd descriptor = {.fd = cancellation, .events = POLLIN};
    int ready = poll(&descriptor, 1, 3000);
    if (ready <= 0) return ready == 0 ? ETIMEDOUT : failure();
    unsigned char drained = 0;
    ssize_t count = recv(cancellation, &drained, 1, 0);
    if (count < 0) return failure();
    return count == 1 && drained == 73 ? 0 : EIO;
}
