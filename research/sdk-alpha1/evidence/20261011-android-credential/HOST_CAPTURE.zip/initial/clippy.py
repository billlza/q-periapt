from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-credential-qualified';s=json.loads((out/'STATE.json').read_text());assert s['completed'] and not s['live_producer'];env=s['environment'];source=Path(s['work'])/'c-consumer'
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--locked','--offline','--test','android','--test','first_configuration','-j','2','--','-D','warnings'],out/'clippy',source,environment=env)
print('Android and shared first-configuration Clippy passed',flush=True)
