from pathlib import Path
import json,shutil
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_jni as android
import continuity_android_credential as credential
root=Path.cwd();prior=root/'target/continuity-android-credential-qualified';out=root/'target/continuity-android-credential-recheck';out.mkdir()
s=json.loads((prior/'STATE.json').read_text());assert s['completed'] and not s['live_producer'];env=s['environment'];source=Path(s['work'])/'c-consumer'
result=json.loads((prior/'ANDROID_JNI_CONSUMER.json').read_text());assert result['completed']
for name,data in android.source_files().items():
 import hashlib
 assert hashlib.sha256(data).hexdigest()==result['source_hashes'][name]
for rel in ['tests/android.rs','tests/common/android_credential.rs']:shutil.copy2(root/'bindings/c/ContinuityPackageConsumer'/rel,source/rel)
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--locked','--offline','--test','android','--test','first_configuration','-j','2','--','-D','warnings'],out/'clippy',source,environment=env)
records={}
for profile in ['debug','release']:
 extra=['--release'] if profile=='release' else []
 built=sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json','-j','2',*extra],out/(profile+'-build'),source,environment=env)
 binary=c.built_artifact(built,source,Path(env['CARGO_TARGET_DIR'])/profile,library=False,test_name='android')
 argv=json.loads((prior/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];library=Path(next(a.split('=',1)[1] for a in argv if a.startswith('-Djava.library.path=')))
 cases=out/(profile+'-cases');runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(library/'driver'))
 stdout=sdk.command([str(binary),'--exact',credential.TEST,'--nocapture'],out/profile,source,environment=runtime)
 records[profile]=credential.verify_execution(stdout,cases)
sdk.write_json(out/'OUTCOMES.json',records);print('Checked-slice Clippy and exact credential target Debug/Release regressions passed',flush=True)
