from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_credential as credential
root=Path.cwd();out=root/'target/continuity-android-credential-device-current'
state=json.loads((root/'target/continuity-android-credential-qualified/STATE.json').read_text())
env=state['environment'];source=Path(state['work'])/'c-consumer'
qualified=root/'target/continuity-android-credential-qualified'
assert json.loads((qualified/'android-jni-debug-build.json').read_text())['returncode']==0
assert json.loads((qualified/'android-jni-debug-credential.json').read_text())['returncode']==0
original=c.built_artifact((qualified/'android-jni-debug-build.stdout').read_bytes(),source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
binary=out/'android-harness';c.sdk.copy(original,binary,maximum=c.MAX_BINARY);binary.chmod(0o700)
sdk.write_json(out/'HARNESS.json',{'source':str(original),'copied_sha256':sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256,'code_commit':'a55254444eddd151d7ff449db5e7d8dfc863f1c6'})
runtime=dict(env,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(out/'device-driver.py'))
def retire_owned_installation():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.credentialprobe20261011'
 for record in sorted(out.glob('device-*/STATE.json')):
  s=json.loads(record.read_text())
  if not s.get('installation_attempted') or s.get('cleanup'):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
  matches=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16']
  assert len(matches)==1,'selected device unavailable for owned cleanup'
  serial=matches[0].split()[0]
  def call(args):
   r=subprocess.run([adb,'-s',serial,*args],capture_output=True,text=True,timeout=60)
   assert r.returncode==0 and not r.stderr,'owned device cleanup failed'
   return r.stdout
  port=s.get('owned_reverse_port')
  if port is not None:call(['reverse','--remove','tcp:'+str(port)]);s['owned_reverse_port']=None
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():
   assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip()
  s['cleanup']=True;s['outer_cleanup']=True;record.write_text(json.dumps(s,indent=2)+'\n')
try:
 stdout=sdk.command([str(binary),'--exact',credential.TEST,'--nocapture'],out/'android-credential',source,environment=runtime)
 results=credential.verify_execution(stdout,out/'cases');sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:retire_owned_installation()
 except BaseException as cleanup:raise BaseExceptionGroup('credential qualification and owned cleanup failed',[original,cleanup])
 raise
print('Actual AAR Android same-key renewal passed on the accepted phone',flush=True)
