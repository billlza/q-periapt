from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import continuity_android_credential as credential
import continuity_android_jni as android
import rust_sdk_profile as sdk
root=Path.cwd();phone=root/'target/continuity-android-credential-device-current';host=root/'target/continuity-android-credential-qualified';recheck=root/'target/continuity-android-credential-recheck';aar=root/'target/continuity-android-credential-aar';out=root/'research/sdk-alpha1/evidence/20261011-android-credential';out.mkdir()
accepted=json.loads((phone/'VERIFIED.json').read_text());assert accepted['completed'];r=json.loads((recheck/'OUTCOMES.json').read_text());assert set(r)=={'debug','release'}
h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert h['completed'] and a['completed']
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==digest and a['source_sha256'][name]==digest
secrets=[]
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
for line in rows:
 if ' device ' in line:secrets.append(line.split()[0].encode())
for path in (phone/'cases').glob('*/inputs/witness-tls-key'):
 value=path.read_bytes();secrets.extend([value,base64.b64encode(value),value.hex().encode()])
def archive(filename,files):
 with zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED) as packed:
  for name,path in sorted(files.items()):
   data=path.read_bytes();assert not any(secret and secret in data for secret in secrets),'private value in capture '+name
   info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;packed.writestr(info,data)
 return hashlib.sha256((out/filename).read_bytes()).hexdigest()
files={}
for p in phone.iterdir():
 if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}:files[p.name]=p
for folder in ['device-*','agp-*']:
 for p in phone.glob(folder+'/*'):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for label in accepted['profiles']:
 for name in credential.PUBLIC:files['cases/'+label+'/'+name]=phone/'cases'/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
files['ANDROID_JNI_CONSUMER.json']=host/'ANDROID_JNI_CONSUMER.json'
for name in ['clippy.stderr','clippy.json','qualify.py','clippy.py','recheck.py']:files['initial/'+name]=host/name
for p in recheck.iterdir():
 if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files['recheck/'+p.name]=p
for profile in ['debug','release']:
 for label in r[profile]:
  for name in credential.PUBLIC:files['recheck/'+profile+'/'+label+'/'+name]=recheck/(profile+'-cases')/label/name
host_hash=archive('HOST_CAPTURE.zip',files)
files={p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
aar_hash=archive('AAR_BUILD_CAPTURE.zip',files)
code={('bindings/android/ContinuityPackageConsumer/'+name):hashlib.sha256(data).hexdigest() for name,data in android.source_files().items()}
for name in ['artifact/continuity_android_credential.py','artifact/continuity_android_jni.py','artifact/continuity_android_witness.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_witness.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs']:
 code[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
record={'kind':'qperiapt.android_credential_renewal_qualification','completed':True,'base_commit':'d4011da801c23a8de3ceed2478382ffba62646a9','android_code_commit':'a55254444eddd151d7ff449db5e7d8dfc863f1c6','art_harness':json.loads((phone/'HARNESS.json').read_text()),'code_sha256':code,'device_scope':{'accepted':True,'device_count':1,'api':37,'abi':'arm64-v8a','additional_api36_hardware_required':False},'art_processes':110,'profiles':accepted['profiles'],'host_jni':{'completed':True,'qualified_processes':430,'credential_processes':220,'boundary_processes':2,'local_lifecycle_processes':48,'managed_registry_processes':100,'witness_processes':60,'profiles':['debug','release'],'checked_slice_and_exact_target_recheck':True},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'AAR_BUILD_CAPTURE.zip':aar_hash},'limitations':['Credential route executes before original credential expiry.','Original-session traffic across renewal, expiry cleanup and independently approved cancellation require separate Android scenarios.','Same protocol engine at both endpoints; not an independent protocol implementation.','Android code in AAR matches current Java/JNI and instrumentation hashes; ART Rust driver is pinned separately at a5525444. Checked-slice and exact-target Rust changes subsequently pass both host profiles, and independent target checkpoints were also rechecked against ART outputs.'],'release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',record);print('Captured public AAR, ART and host evidence with current code hashes',flush=True)
