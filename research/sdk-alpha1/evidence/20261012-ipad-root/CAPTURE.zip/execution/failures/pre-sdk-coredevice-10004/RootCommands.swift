import Foundation
import QPeriaptContinuity

enum RootCommands {
    static func run(_ args:[String]) throws {
        let c=RootContext(args)
        try traceIOS("root-execute "+c.mode,output:c.output,run:c.run)
        let outcome=Result { try execute(c) }
        try traceIOS("root-cleanup "+c.mode,output:c.output,run:c.run)
        var failures:[String]=[]
        for close in c.disposals.reversed() { do { try close() } catch { failures.append(String(describing:error)) } }
        guard failures.isEmpty else { throw ClientError("root disposal \(failures); operation \(outcome)") }
        try durableIOS(outcome.get(),c.output)
    }
    private static func execute(_ c:RootContext) throws -> [UInt8] {
        let i=c.input,m=c.mode
        if ["root-target-create","root-target-prepare","root-original-target-create","root-original-target-prepare"].contains(m) {
            let input=c.target(m.hasPrefix("root-original-")),create=m.hasSuffix("-create"),enrollment=try c.enrollment(input,create:create)
            if create { return try enrollment.request() }
            let journal=try enrollment.accept(certificate:input.read("grant-certificate"),roster:input.read("grant-roster"),pin:input.account())
            guard case .requiresEnrollment(let genesis)=try enrollment.prepareStorage(),genesis.journal==journal else { throw ClientError("root target genesis") }
            return bigNumber(UInt32(2))+journal.bytes+genesis.subject+genesis.imageDigest
        }
        let root=try c.controller()
        if m=="root-begin-unknown" {
            let owner=try c.enrollment(i);try owner.selectAccountAuthority(root,checkpoint:i.checkpoint())
            let device=try owner.activate();c.disposals.append { try device.close() }
            let peer=try c.peer(device,i)
            try root.beginRootReplacement(device:device,scope:c.scope(),plan:c.plan())
            try expect(2) { _ = try c.status(peer,i) }
            try requireIOS(root.rootReplacementState() == .preparing,"root preparation")
            try expect(215) { _ = try root.retiredInventory() }
            try c.cut(root,bigNumber(try root.rootReplacementState().rawValue))
        }
        try c.resume(root)
        switch m {
        case "root-state": return bigNumber(try root.rootReplacementState().rawValue)
        case "root-freeze-bad":
            var corrupt=try i.read("root-freeze",131072);corrupt[corrupt.count-1] ^= 1
            try expect(102) { _ = try root.bindRootFreeze(receipt:corrupt) }
            try requireIOS(root.rootReplacementState() == .preparing,"bad freeze consumed preparation");return bigNumber(UInt32(102))
        case "root-freeze-unknown","root-freeze-original": try c.cut(root,root.bindRootFreeze(receipt:i.read("root-freeze",131072)).bytes)
        case "root-freeze-replay": return try root.bindRootFreeze(receipt:i.read("root-freeze",131072)).bytes
        case "root-retain-unknown": try c.cut(root,checkpointBytes(root.retainRootRetirement(receipt:i.fixed("root-retirement",3449))))
        case "root-retain-replay": return checkpointBytes(try root.retainRootRetirement(receipt:i.fixed("root-retirement",3449)))
        case "root-transition-unknown": try c.cut(root,root.transitionRoot(c.transition()).bytes)
        case "root-transition-replay": return try root.transitionRoot(c.transition()).bytes
        case "root-adopt-unknown": try c.cut(root,checkpointBytes(root.adoptRoot(c.adoption())))
        case "root-adopt-replay": return checkpointBytes(try root.adoptRoot(c.adoption()))
        case "root-cancel-preparing":
            try requireIOS(root.rootReplacementState() == .preparing,"cancel preparation state");try root.cancel()
            try expect(302) { _ = try root.rootReplacementState() };return bigNumber(UInt32(302))
        case "root-noncommit-bad":
            var bad=try i.fixed("root-noncommit",3449);bad[bad.count-1] ^= 1
            try expect(102) { _ = try root.retainRootNoncommit(receipt:bad) }
            try requireIOS(root.rootReplacementState() == .preparing,"bad noncommit changed preparation");return bigNumber(UInt32(102))
        case "root-noncommit-unknown":
            try requireIOS(root.retainRootNoncommit(receipt:i.fixed("root-noncommit",3449)) == .closed,"noncommit terminal")
            try c.cut(root,bigNumber(UInt32(4)))
        case "root-noncommit-replay":
            try requireIOS(root.rootReplacementState() == .closed,"closed state lost")
            try requireIOS(root.retainRootNoncommit(receipt:i.fixed("root-noncommit",3449)) == .closed,"noncommit replay")
            try expect(112) { _ = try root.bindRootFreeze(receipt:i.read("root-freeze",131072)) }
            try requireIOS(root.rootReplacementState() == .closed,"closed plan resumed");return bigNumber(UInt32(4))
        case "root-activate-unknown":
            let owner=try c.enrollment(c.target())
            try expect(218) { _ = try root.activateRootSuccessor(owner) }
            try expect(2) { _ = try root.rootReplacementState() };try expect(2) { _ = try owner.status() };return bigNumber(UInt32(218))
        default: break
        }
        try requireIOS(root.rootReplacementState() == .committed,"successor requires committed root")
        let device=try c.successor(root)
        switch m {
        case "root-activate": return [1]
        case "root-peer-connect","root-peer-uncertain","root-peer-retry":
            return try traffic(device,source:c.target().source,mode:m=="root-peer-connect" ? "connect" : m=="root-peer-uncertain" ? "uncertain-send" : "retry-send")
        case "root-ack-tampered":
            var report=try load(URL(fileURLWithPath:i.path),"root-host-report",8388608);report[report.count-1] ^= 1
            try expect(208) { _ = try root.prepareRetiredAcknowledgement(inventoryReceipt:i.read("root-inventory-receipt"),reportReceipt:i.read("root-report-receipt"),recordedReport:report) }
            try expect(2) { _ = try root.rootReplacementState() };try c.revoked(device);return bigNumber(UInt32(208))
        case "root-erase-wrong-purpose":
            try expect(102) { try root.eraseRetiredJournal(hostAcknowledgement:i.read("root-report-receipt")) }
            try expect(2) { _ = try root.rootReplacementState() };try c.revoked(device);return bigNumber(UInt32(102))
        case "root-close-revokes","root-cancel-successor":
            let peer=try c.peer(device,c.target());try requireIOS(c.status(peer,c.target()) == .acknowledged,"live successor status")
            if m=="root-close-revokes" {
                try c.closeController();try expect(202) { _ = try c.status(peer,c.target()) };return bigNumber(UInt32(202))
            }
            try root.cancel();try expect(302) { _ = try root.rootReplacementState() }
            try requireIOS(c.status(peer,c.target()) == .acknowledged,"cancel revoked successor");return bigNumber(UInt32(302))
        default: return try rootCleanup(c,root:root)
        }
    }
}
