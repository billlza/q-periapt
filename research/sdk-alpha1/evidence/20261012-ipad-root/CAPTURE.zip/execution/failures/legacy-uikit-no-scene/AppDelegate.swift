import UIKit
import Foundation

@main
@MainActor
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    private var started = false
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let view = UIViewController()
        view.view.backgroundColor = .systemBackground
        let label = UILabel()
        label.text = "Continuity validation in progress"
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.view.addSubview(label)
        NSLayoutConstraint.activate([label.centerXAnchor.constraint(equalTo:view.view.centerXAnchor),label.centerYAnchor.constraint(equalTo:view.view.centerYAnchor)])
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = view
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
    func applicationDidBecomeActive(_ application: UIApplication) {
        guard !started else { return }
        started = true
        Task { await ContinuityIOSRunner.execute() }
    }
}

func awaitHostAdmission(directory: URL, run: String) async throws {
    try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_READY run=\(run)\n".utf8))
    let path = directory.appendingPathComponent("admission-"+run+".txt")
    let clock = ContinuousClock(), deadline = clock.now.advanced(by:.seconds(20))
    while clock.now < deadline {
        if FileManager.default.fileExists(atPath:path.path) {
            let receipt = try Data(contentsOf:path)
            guard receipt == Data((run+"\n").utf8) else { throw ClientError("wrong host startup admission") }
            return
        }
        try await Task.sleep(for:.milliseconds(20))
    }
    throw ClientError("host startup admission timed out before SDK operation")
}
