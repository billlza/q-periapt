#include <mach/mach.h>
#include <mach/task_info.h>
#include <stdint.h>

int qpc_observer_memory(uint64_t values[2]) {
    task_vm_info_data_t info = {0};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (values == NULL) return KERN_INVALID_ARGUMENT;
    kern_return_t status = task_info(mach_task_self(), TASK_VM_INFO,
                                    (task_info_t)&info, &count);
    if (status != KERN_SUCCESS) return status;
    if (count < TASK_VM_INFO_REV1_COUNT) return KERN_FAILURE;
    values[0] = info.resident_size;
    values[1] = info.phys_footprint;
    return KERN_SUCCESS;
}
