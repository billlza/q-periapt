#include <mach/mach.h>
#include <mach/task_info.h>
#include <stdint.h>
#include <malloc/malloc.h>

int qpc_observer_memory(uint64_t values[6]) {
    task_vm_info_data_t info = {0};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (values == NULL) return KERN_INVALID_ARGUMENT;
    kern_return_t status = task_info(mach_task_self(), TASK_VM_INFO,
                                    (task_info_t)&info, &count);
    if (status != KERN_SUCCESS) return status;
    if (count < TASK_VM_INFO_REV1_COUNT) return KERN_FAILURE;
    values[0] = info.resident_size;
    values[1] = info.phys_footprint;
    malloc_statistics_t allocations = {0};
    malloc_zone_statistics(NULL, &allocations);
    values[2] = allocations.blocks_in_use;
    values[3] = allocations.size_in_use;
    values[4] = allocations.max_size_in_use;
    values[5] = allocations.size_allocated;
    return KERN_SUCCESS;
}
