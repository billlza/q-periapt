import json,os,subprocess,sys,tempfile,time
from pathlib import Path
out=Path(__file__).resolve().parent;repo=out.parent.parent;clone=out/'checkout'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert (clone/'.git').is_dir() and not (clone/'.git').is_symlink()
root=Path(tempfile.mkdtemp(prefix='qperiapt-sdk-authority-build-')).resolve();build=root/'build-venv';provider=repo/'target/independent-bootstrap-01/provider'
(out/'BUILD_LOCATION.json').write_text(json.dumps({'outside':str(root),'ordinary_clone':str(clone),'head':head},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('PYTHON','PIP_','DYLD_','LD_'))}
env['SOURCE_DATE_EPOCH']=subprocess.check_output(['git','show','-s','--format=%ct',head],cwd=clone,text=True).strip()
commands=[]
def run(name,args,cwd=clone,extra=None):
 command_env=env.copy()
 if extra:command_env.update(extra)
 start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
  p=subprocess.run(args,cwd=cwd,env=command_env,stdout=stdout,stderr=stderr,timeout=900)
 record={'step':name,'argv':args,'cwd':str(cwd),'exit':p.returncode,'seconds':round(time.monotonic()-start,2)}
 commands.append(record);(out/'BUILD_COMMANDS.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(record),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('venv',[sys.executable,'-I','-m','venv',str(build)])
run('backend',[str(build/'bin/python'),'-I','-m','pip','install','--isolated','--disable-pip-version-check','--no-index','--find-links',str(repo/'target/independent-python-install-01/build-inputs'),'--only-binary=:all:','--no-deps','--require-hashes','-r','research/continuity-openssl-peer/build-requirements.txt'])
run('wheel',[str(build/'bin/python'),'-I','-m','pip','wheel','--isolated','--disable-pip-version-check','--no-index','--no-deps','--no-build-isolation','--wheel-dir',str(out/'wheel'),'research/continuity-openssl-peer'])
run('qualify',['sh','artifact/python-run.sh','artifact/continuity_host_exchange.py','--wheel',str(out/'wheel/qperiapt_continuity_reference-0.0.0-py3-none-any.whl'),'--provider-root',str(provider),'--publisher',str(repo/'target/continuity-reference-app/release/q-periapt-policy-publisher'),'--sdk-authority',str(repo/'target/continuity-reference-app/release/q-periapt-sdk-policy-authority'),'--output','target/exchange-result'],extra={'QPERIAPT_PYTHON':sys.executable})
