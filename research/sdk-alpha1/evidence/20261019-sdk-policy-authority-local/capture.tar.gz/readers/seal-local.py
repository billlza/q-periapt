"""Capture public SDK-authority checks; private roots and ledgers remain local."""
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];out=repo/'target/sdk-policy-authority-01';installed=repo/'target/sdk-authority-installed-01';head='e13efcaf23d38fb88ea52fd9aefa79724b6967e2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
entries={}
for name in ('owner-tests','authority-tests','fmt-app-check','fmt-native','crypto-tests','crypto-clippy','app-clippy','app-tests','release-build','release-tests','actionlint','interop-01'):
 for suffix in ('.command.json','.stdout','.stderr'):entries['checks/'+name+suffix]=(out/(name+suffix)).read_bytes()
for name in ('owner-tests-02.stdout','owner-tests-02.stderr','CHECKS.json','FIXTURE_FAILURE.json','tests-before-private-fixture.rs'):
 entries['checks/'+name]=(out/name).read_bytes()
for name in ('CLONE_COMMANDS.json','BUILD_COMMANDS.json','BUILD_LOCATION.json','PUBLICATION_READBACK.json','installed.py'):
 entries['installed/'+name]=(installed/name).read_bytes()
for label in ('venv','backend','wheel','qualify'):
 for suffix in ('.stdout','.stderr'):entries['installed/'+label+suffix]=(installed/(label+suffix)).read_bytes()
public=installed/'checkout/target/exchange-result'
for path in public.rglob('*'):
 if path.is_file():entries['installed/result/'+path.relative_to(public).as_posix()]=path.read_bytes()
result=json.loads((public/'RESULT.json').read_text());assert result['completed'] and result['source_commit']==head and result['schema_version']==4
assert len(result['source_inputs'])==134 and result['native_policy_publication']['commands']==24 and result['native_policy_publication']['expected_refusals']==7
source_names=set(result['source_inputs'])|set(subprocess.check_output(['git','diff','--name-only',head+'^',head],cwd=repo,text=True).splitlines())
for name in sorted(source_names):
 data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
 if name in result['source_inputs']:assert hashlib.sha256(data).hexdigest()==result['source_inputs'][name]
 entries['source/'+name]=data
for name in ('readback.py','publisher_readback.py'):entries['readers/'+name]=(repo/'target/sdk-authority-hosted-01'/name).read_bytes()
entries['readers/seal-local.py']=Path(__file__).read_bytes()
assert all(not name.endswith(('.redb','.wrap','.signer','.pem')) for name in entries)
assert all(not any(part in ('private-inputs','private-native-policy','private-client','private-exchange') for part in Path(name).parts) for name in entries)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in entries.items()}
entries['PUBLIC_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
folder=repo/'research/sdk-alpha1/evidence/20261019-sdk-policy-authority-local';folder.mkdir();archive=folder/'capture.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
receipt={'source_commit':head,'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'checks':{'native_crypto_entries':16,'native_crypto_behavioral':14,'native_crypto_child_dispatchers':2,'reference_debug_entries':42,'reference_release_entries':42,'reference_behavioral':39,'reference_child_dispatchers':3,'new_sdk_authority_process_kill_cuts':8,'native_library_clippy':True,'reference_all_target_clippy':True,'fmt':True,'actionlint':True,'installed_adapter':8,'installed_client':16,'operator_commands':24,'expected_refusals':7,'sdk_versions':[1,2],'protocol_versions':[1,2,3],'source_inputs':134,'wheel_modules':50,'wheel_sha256':result['wheel_sha256']},'binaries_producer_observation':{'sdk_authority_sha256':result['sdk_authority_binary_sha256_producer_observation'],'protocol_publisher_sha256':result['publisher_binary_sha256_producer_observation']},'first_attempt':'Three native signer tests initially stopped before key creation because the fixture directory was0755. Failed empty directories and output were retained; the fixture now explicitly uses0700. No production admission guard changed. Subsequent focused and16-entry crypto checks passed.','scope':'Native protected SDK-root issuer and protocol publisher, exact SDK policy inputs, installed independent OpenSSL verification. No fixture SDK private key in the CLI flow. Historical public signatures reverified without clock overrides. Local operator trust is assumed; no live consumer activation, root recovery/replacement, real user/device authorization, deployed witness, secure erasure, power-loss, PCS or full0.2.0 admission.'}
(folder/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for name,row in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps(receipt,indent=2))
