"""Seal exact-source local joint renewal, regressions and labeled diagnostics."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=root/'target/independent-local-renewal-01';peer=root/'research/continuity-openssl-peer'
folder=root/'research/sdk-alpha1/evidence/20261018-independent-local-renewal';folder.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','LOCAL_RENEWAL','REPLY_RELEASE']
reports={name:json.loads((out/(name+'_READBACK.json')).read_text()) for name in labels};sources=reports['LOCAL_RENEWAL']['source_files']
assert len(sources)==70
for name,r in reports.items():
 if name!='REPLY_RELEASE':
  assert r['source_files']==sources and not r['source_continuity']['test_harness_only_changes']
  assert r['native_sha256']==reports['LOCAL_RENEWAL']['native_sha256']
runs=json.loads((out/'QUALIFIED_RUNS.json').read_text());assert len(runs)==14 and all(r['exit']==0 for r in runs)
entries={}
def public_tree(name,prefix=None):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink() and p.name not in {'head','intent','authority','.stage-head','configuration','signer','key','wrong-signer'}
  data=p.read_bytes();assert not data.startswith((b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPREFS01',b'QPREFS02',b'QPREFS03',b'QPREFS04',b'QPREFS05',b'QPREFS06',b'QPRFLC01',b'QPRFLI01'))
  entries[(prefix or name)+'/'+str(p.relative_to(out/name))]=data
for row in runs:
 name='qualified-'+row['lane'];assert not (out/(name+'.stderr')).read_bytes();public_tree(name)
 for ext in ['stdout','stderr']:entries[name+'.'+ext]=(out/(name+'.'+ext)).read_bytes()
for label in labels:
 name=label+'_READBACK.json';entries[name]=(out/name).read_bytes()
readers=['qualified-review-final-regressions','qualified-review-final-control','qualified-review-resolution','qualified-review-witness','qualified-review-peer-lifecycle','review-reply-release','review-local-renewal']
for stem in readers:
 for ext in ['py','stdout','stderr']:entries[stem+'.'+ext]=(out/(stem+'.'+ext)).read_bytes()
 assert not entries[stem+'.stderr']
for name in ['source_readback.py','QUALIFIED_RUNS.json','run-qualified.py','seal.py','VALIDATION.json']:
 entries[name]=(out/name).read_bytes()
for stem in ['build','clippy']:
 for ext in ['stdout','stderr']:entries[stem+'.'+ext]=(out/(stem+'.'+ext)).read_bytes()
for name,expected in sources.items():
 data=(peer/name).read_bytes();assert sha(data)==expected
 assert subprocess.check_output(['git','show',':research/continuity-openssl-peer/'+name])==data
 entries['source/'+name]=data
for name in ['README.md','STORAGE.md','LOCAL_RENEWAL.md']:entries['source/'+name]=(peer/name).read_bytes()
entries['repository/.github/workflows/independent-continuity.yml']=(root/'.github/workflows/independent-continuity.yml').read_bytes()
entries['counterpart']=(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
assert sha(entries['counterpart'])==reports['LOCAL_RENEWAL']['native_sha256']
# These failed startup/readback attempts did not change product semantics. The
# original private directories and complete development runs remain local.
public_tree('pending-01','diagnostics/pending-01')
for name in ['pending-probe.py','pending-01.stdout','pending-01.stderr','process-01.stdout','process-01.stderr',
             'qualified-review-final-control.old-source-count.py.txt','qualified-review-final-control.old-source-count.stderr',
             'qualified-review-resolution.old-source-count.py.txt','qualified-review-resolution.old-source-count.stderr',
             'review-local-renewal.before-ack-correction.py.txt','review-local-renewal.before-ack-correction.stderr']:
 entries['diagnostics/'+name]=(out/name).read_bytes()
entries['DIAGNOSTIC_LIMITS.json']=(json.dumps({
 'startup':'First process launcher imported peer.wire before admitting isolated cryptography; corrected import order. No runtime operation had begun.',
 'ordinary_pending':'Initial probe expected a signed conflicts result. Actual native witness refuses expired Advance without a signed response; final control requires the same exact original command, native status2 and retained unchanged intent/head, not just a transport exception.',
 'reader_source_counts':'Two copied public readers still expected63 rather than actual70 sources. Changed exact inventory checks; all final source hashes agree.',
 'reader_ACK':'Initial reader expected ACK Unavailable after pruning. Actual signed responses retain Acknowledged for exact ACK at floor; Status is Unavailable. Final reader checks that sequence and never treats Unavailable alone as Closed. Pending profile has9workers, not a provisional10.',
 'prototype':'smoke-01,process-02,process-03 are retained locally as development runs. Only qualified-* are the final exact70-source cohort.',
 'private_state':'All failed/interrupted private states remain local. Capture retains public path references but no private images, wrapping keys or signer files.',
 'source_contract':'No new full CodeQL scan or unchanged46-test source-contract suite rerun. Rust census/path gate remains725; prior receipt retained separately.'
},indent=2)+'\n').encode()
changed=subprocess.check_output(['git','diff','23280124','--name-only'],text=True).splitlines()
allowed={'ARTIFACT.md','artifact/codeql_rust_quality.py','artifact/test_codeql_rust_quality.py','.github/workflows/independent-continuity.yml','docs/SDK_0_2_RELEASE_READINESS.md'}
assert all(n.startswith(('research/continuity-openssl-peer/','research/sdk-alpha1/evidence/')) or n in allowed for n in changed)
entries['SOURCE_CONTINUITY.json']=(json.dumps({'from_head':'23280124efd2f0f3003d4ce85e3db665f6ec8a25','base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'changed_paths':changed,'product_candidate_bindings_toolchain_unchanged':True,'tracked_Rust':725},indent=2)+'\n').encode()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,data)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(entries) and z.testzip() is None
 for name,item in manifest.items():
  data=z.read(name);assert len(data)==item['bytes'] and sha(data)==item['sha256']
record={'readbacks':reports,'validation':json.loads(entries['VALIDATION.json']),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':'Independent required-witness joint local credential/head renewal only. Same original target and outcomes survive process cuts/replies/expiry; unrelated expired pending work stays blocked. Native traffic clock stays170. No local-only/same-account/policy/witness replacement, installed/cross-host lifecycle, witness rollback, power loss/erasure or PCS proof. Hosted verification pending.'}
(folder/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['capture']))
