from pathlib import Path
from types import SimpleNamespace
import sys
sys.path.append(str(Path.cwd()/'research/continuity-openssl-peer'))
from provider import load_provider
provider=Path('target/independent-bootstrap-01/provider')
load_provider(provider)
from local_renewal_checks import exercise
out=Path('target/independent-local-renewal-01/pending-01');out.mkdir()
print(exercise(SimpleNamespace(output=out,provider_root=provider,native=Path('target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart')),'pending-write'))
