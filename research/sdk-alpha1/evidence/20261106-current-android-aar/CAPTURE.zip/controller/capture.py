from pathlib import Path
import ast
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
TOOLS = REPO / 'target/continuity-android-tools-20261105'
DEST = REPO / 'research/sdk-alpha1/evidence/20261106-current-android-aar'
DEST.mkdir()
report = json.loads((ROOT / 'identity-02/READBACK.json').read_bytes())
assert all(value['release_binary_scan_passed'] is True for value in report['binaries'].values())
files = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(prefix, directory, excluded=()):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file() and not any(path.is_relative_to(directory / item) for item in excluded):
            name = prefix + '/' + path.relative_to(directory).as_posix()
            assert name not in files
            files[name] = path

for name in ('build-01', 'build-02'):
    tree(name, ROOT / name, ('native',))
for name in ('package-01', 'package-02'):
    tree(name, ROOT / name)
for name in ('identity-01', 'identity-02'):
    tree(name, ROOT / name, ('installed',))
files['controller/PATH_REMAP_FAILURE.json'] = ROOT / 'PATH_REMAP_FAILURE.json'
files['controller/capture.py'] = ROOT / 'capture.py'
drivers = ['build-android-native.py', 'build-android-native02.py', 'package-android-aar.py',
    'package-android-aar02.py', 'readback-android-aar.py', 'readback-android-aar02.py']
for name in drivers:
    files['controller/' + name] = SOURCE / 'target/current-rust-readback' / name
for label in ('android-native-build', 'android-native-build02', 'android-aar-package', 'android-aar-package02',
              'android-aar-readback', 'android-aar-readback02'):
    for suffix in ('stdout', 'stderr'):
        files['controller/' + label + '.' + suffix] = SOURCE.parent / (label + '.' + suffix)
for name in ('bindings/c/ContinuityPackageConsumer', 'bindings/android/ContinuityPackageConsumer'):
    tree('source/' + name, SOURCE / name)
queue = [SOURCE / 'target/current-rust-readback' / name for name in drivers]
seen = set()
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.is_relative_to(SOURCE / 'artifact'):
        files['source/' + path.relative_to(SOURCE).as_posix()] = path
    for node in ast.walk(ast.parse(path.read_bytes())):
        modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
        for module in modules:
            dependency = SOURCE / 'artifact' / (module.replace('.', '/') + '.py')
            if dependency.is_file():
                queue.append(dependency)
for name in ('python-run.sh', 'python-env.sh', 'python_bootstrap.py'):
    files['source/artifact/' + name] = SOURCE / 'artifact' / name
for name in ('DOWNLOAD_PLAN.json', 'ndk-DOWNLOAD.json', 'NDK_INSTALL.json', 'NDK_FILES.json',
             'RUST_ANDROID_INSTALL.json', 'RUST_ANDROID_FILES.json', 'rust_std-DOWNLOAD.json',
             'metadata.py', 'download.py', 'extract_ndk.py', 'stage_rust.py', 'retry_rust.py', 'inspect_rust_download.py',
             'repository2-3.xml', 'ndk-clang-file.txt', 'ndk-clang-version.txt',
             'download-ndk.stdout', 'download-ndk.stderr', 'download-rust_std.stdout', 'download-rust_std.stderr',
             'retry-rust.stdout', 'retry-rust.stderr', 'extract-ndk.stdout', 'extract-ndk.stderr',
             'stage-rust.stdout', 'stage-rust.stderr', 'rust-clone.stdout', 'rust-clone.stderr',
             'inspect-rust.stdout', 'inspect-rust.stderr'):
    files['tool-preparation/' + name] = TOOLS / name
for name in ('rust-mismatch-01', 'rust-retry-02'):
    tree('tool-preparation/' + name, TOOLS / name)
for name in ('NOTICE', 'NOTICE.toolchain'):
    files['tool-preparation/ndk/' + name] = TOOLS / 'ndk-install/android-ndk-r29' / name
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
        archive.writestr(name, data)
with zipfile.ZipFile(DEST / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
data = (DEST / 'CAPTURE.zip').read_bytes()
assert len(data) < 95 * 1024**2
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(DEST / 'READBACK.json').write_bytes((ROOT / 'identity-02/READBACK.json').read_bytes())
(DEST / 'PATH_REMAP_FAILURE.json').write_bytes((ROOT / 'PATH_REMAP_FAILURE.json').read_bytes())
summary = {'source_commit': report['source_commit'], 'members': len(manifest), 'bytes': len(data), 'sha256': sha(data),
    'successful_aar': report['aar'],
    'scope': 'Current arm64 candidate AAR build and independent static reread, original path-leakage package/failure, source/readers and private tool preparation receipts. No APK/ART/device qualification or product ABI2 admission.',
    'large_tool_archives_retained_locally': {name: {'path': str(TOOLS / name), 'bytes': (TOOLS / name).stat().st_size}
        for name in ('android-ndk-r29-darwin.zip', 'rust-std-1.98.1-aarch64-linux-android.tar.xz', 'rust-std-1.98.1-aarch64-linux-android.tar.xz.partial')},
    'release_claim_eligible': False}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
