from pathlib import Path
import hashlib
import io
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

import android_elf as elf
import continuity_android_jni as android
import continuity_c_consumer as c
import continuity_package as package
from continuity_package_archive import unpack
from release_binary_scan import scan_release_file
import rust_sdk_profile as sdk
import third_party_licenses as licenses

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
ROOT = REPO / 'target/continuity-current-android-aar-5678'
PACKAGE = ROOT / 'package-01'
OUT = ROOT / 'identity-01'
OUT.mkdir()
report = json.loads((PACKAGE / 'ANDROID_AAR_PACKAGE.json').read_bytes())
native = json.loads((ROOT / 'build-01/ANDROID_NATIVE_BUILD.json').read_bytes())
assert report['completed'] is True and native['completed'] is True and report['sources_unchanged'] is True
assert report['native_build_report_sha256'] == sdk.snapshot(ROOT / 'build-01/ANDROID_NATIVE_BUILD.json').sha256
assert report['source_commit'] == native['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert report['native_binaries'] == native['binaries']
for key in ('product_abi_admitted', 'aar_consumer_built', 'art_executed', 'physical_device_executed', 'publication_performed', 'release_claim_eligible'):
    assert report[key] is False
assert package.source_inputs() == native['source_inputs']
aar = PACKAGE / report['aar']['file']
data = aar.read_bytes()
assert len(data) == report['aar']['bytes'] and hashlib.sha256(data).hexdigest() == report['aar']['sha256']
installed = OUT / 'installed'
unpack(data, report['files'], installed)
assert len(report['files']) == report['aar']['members']
manifest = ET.fromstring((installed / 'AndroidManifest.xml').read_bytes())
assert manifest.tag == 'manifest' and manifest.attrib == {'package': 'dev.qperiapt.continuity.android'}
assert len(manifest) == 1 and manifest[0].tag == 'uses-sdk'
assert manifest[0].attrib == {'{http://schemas.android.com/apk/res/android}minSdkVersion': '23'}
assert (installed / 'R.txt').read_bytes() == b''
assert (installed / 'proguard.txt').read_bytes() == (android.SOURCE / 'consumer-rules.pro').read_bytes()
assert {p.name for p in (installed / 'jni').iterdir()} == {'arm64-v8a'}
assert {p.name for p in (installed / 'jni/arm64-v8a').iterdir()} == {v['file'] for v in native['binaries'].values()}
licenses.verify(installed / 'META-INF', expected_target='aarch64-linux-android', root_package=c.NAME)
with zipfile.ZipFile(installed / 'classes.jar') as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == report['classes']
    classes = {name: archive.read(name) for name in archive.namelist()}
assert all(name.endswith('.class') and name.startswith('dev/qperiapt/continuity/android/')
    and value[:8] == b'\xca\xfe\xba\xbe\x00\x00\x00\x37' for name, value in classes.items())
host_jar = SOURCE / 'target/continuity-installed-jni-release-current/continuity-android-classes.jar'
assert sdk.snapshot(host_jar).sha256 == report['host_jar_sha256']
with zipfile.ZipFile(host_jar) as archive:
    assert set(archive.namelist()) == set(classes) and all(archive.read(name) == value for name, value in classes.items())
ndk_record = json.loads((REPO / 'target/continuity-android-tools-20261105/NDK_INSTALL.json').read_bytes())
toolchain = elf.find_ndk_toolchain(Path(ndk_record['root']))
readelf = toolchain / 'bin/llvm-readelf'
nm = toolchain / 'bin/llvm-nm'
outside = Path(json.loads((ROOT / 'build-01/LOCATION.json').read_bytes())['path'])

def run(argv, label):
    return sdk.command(argv, OUT / label, SOURCE)

binaries = {}
for label, row in native['binaries'].items():
    path = installed / 'jni/arm64-v8a' / row['file']
    assert sdk.snapshot(path, maximum=c.MAX_BINARY).sha256 == row['sha256']
    elf.parse_elf_header(path, 'arm64-v8a')
    headers = run([str(readelf), '-l', '-W', str(path)], label + '-program-headers').decode()
    elf.verify_program_headers(headers, path)
    sections = run([str(readelf), '-S', '-W', str(path)], label + '-sections').decode()
    elf.verify_release_sections(sections, path)
    dynamic = run([str(readelf), '-d', '-W', str(path)], label + '-dynamic').decode()
    soname, needed, tags, values = elf.parse_dynamic_entries(dynamic, path)
    project = set() if label == 'c' else {native['binaries']['c']['file']}
    assert soname == path.name and needed - elf.SYSTEM_NEEDED_ALLOWLIST == project
    assert not tags.intersection({'TEXTREL', 'RPATH', 'RUNPATH'})
    assert 'BIND_NOW' in values.get('FLAGS', '') or re.search(r'(?:^|\s)NOW(?:\s|$)', values.get('FLAGS_1', ''))
    symbols = run([str(nm), '--dynamic', '--defined-only', '--extern-only', '--format=posix', str(path)], label + '-symbols').decode()
    exports = elf.parse_nm_exports(symbols, path)
    assert exports == (c.EXPORTS if label == 'c' else {'JNI_OnLoad'})
    notes = run([str(readelf), '--notes', '-W', str(path)], label + '-notes').decode()
    descriptions = re.findall(r'description data: ([0-9a-f ]+)\n', notes)
    assert len(descriptions) == 1 and 'NT_ANDROID_TYPE_IDENT' in notes
    note = bytes.fromhex(descriptions[0])
    assert len(note) == 132 and int.from_bytes(note[:4], 'little') == 23
    assert note[4:68].rstrip(b'\0') == b'r29' and note[68:].rstrip(b'\0') == b'14206865'
    scan_release_file(path, forbidden_text=(str(SOURCE), str(REPO), str(outside)))
    binaries[label] = {'sha256': row['sha256'], 'bytes': path.stat().st_size, 'exports': len(exports),
        'needed': sorted(needed), 'load_alignment_minimum': 16384, 'android_compile_api_note': 23,
        'ndk_note': 'r29/14206865', 'release_binary_scan_passed': True}
result = {'source_commit': report['source_commit'], 'aar': report['aar'], 'classes': len(classes),
    'native_methods': len(report['native_methods']), 'static_callbacks': report['static_callbacks'],
    'host_class_bytes_match': True, 'binaries': binaries, 'license_inventory_verified': True,
    'source_input_files_verified': len(native['source_inputs']['files']), 'product_abi_admitted': False,
    'aar_consumer_built': False, 'art_executed': False, 'physical_device_executed': False,
    'release_claim_eligible': False, 'scope': 'Independent reread of actual current-source AAR members, two Android ELF libraries and class/license/native-loader metadata. Build/static scope only; no APK/ART/device acceptance.'}
with (OUT / 'READBACK.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result))
