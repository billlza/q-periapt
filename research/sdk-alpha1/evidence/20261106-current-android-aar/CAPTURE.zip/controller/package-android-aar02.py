from pathlib import Path
import hashlib
import json
import os
import re
import sys
import zipfile

import continuity_android_jni as android
import continuity_c_consumer as c
import continuity_package as package
from continuity_package_archive import archive, unpack
import rust_sdk_profile as sdk
import third_party_licenses as licenses

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
STAGE = REPO / 'target/continuity-current-android-aar-5678'
BUILD = STAGE / 'build-02'
OUT = STAGE / 'package-02'
OUT.mkdir()
native = json.loads((BUILD / 'ANDROID_NATIVE_BUILD.json').read_bytes())
assert native['completed'] is True and native['sources_unchanged'] is True
assert native['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (native['source_commit'], False)
assert package.source_inputs() == native['source_inputs']
source = android.source_files()
assert {name: hashlib.sha256(data).hexdigest() for name, data in source.items()} == native['android_source']
outside = Path(json.loads((BUILD / 'LOCATION.json').read_bytes())['path'])
consumer = outside / 'c-consumer'
adapter = outside / 'android-source'
for name, data in source.items():
    assert (adapter / name).read_bytes() == data
java_home = REPO / 'target/continuity-jvm-tools/installed/jdk-25.0.5+8/Contents/Home'
java_identity = android.tool_identity(java_home)
prior_tools = json.loads((SOURCE.parent / 'JNI_RELEASE_PREFLIGHT.json').read_bytes())['java_tool_identity']
assert java_identity == prior_tools
env = {k: v for k, v in os.environ.items() if not k.startswith(('JAVA_', 'JDK_', 'GRADLE_', 'DYLD_', 'LD_', 'QPERIAPT_', 'QPC_'))}
for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'CLASSPATH'):
    env.pop(key, None)

def run(argv, label):
    print(label, flush=True)
    return sdk.command(argv, OUT / label, outside, environment=env)

result = {'completed': False, 'source_commit': native['source_commit'], 'sdk_report_sha256': native['sdk_report_sha256'],
    'native_build_report_sha256': sdk.snapshot(BUILD / 'ANDROID_NATIVE_BUILD.json').sha256,
    'abi': 'arm64-v8a', 'native_compile_api': 23, 'java_release': 11, 'ndk_revision': native['ndk_revision'],
    'product_abi_admitted': False, 'aar_consumer_built': False, 'art_executed': False,
    'physical_device_executed': False, 'publication_performed': False, 'release_claim_eligible': False,
    'scope': 'Current unpublished Android candidate AAR package bytes and static native/JNI/class/license verification. No minified APK, Android runtime, whole Android ABI matrix or product ABI2 admission.'}
try:
    classes = outside / 'android-aar-classes'
    classes.mkdir()
    javac = java_home / 'bin/javac'
    java_sources = sorted((adapter / 'src/main/java').rglob('*.java'))
    assert java_sources
    run([str(javac), '--release', '11', '-Xlint:all', '-Werror', '-d', str(classes), *map(str, java_sources)], 'javac')
    assert (OUT / 'javac.stderr').read_bytes() == b''
    class_files = {p.relative_to(classes).as_posix(): p.read_bytes() for p in classes.rglob('*.class')}
    assert class_files and all(data[:8] == b'\xca\xfe\xba\xbe\x00\x00\x00\x37' for data in class_files.values())
    assert all(name.startswith('dev/qperiapt/continuity/android/') for name in class_files)
    jar = OUT / 'classes.jar'
    with zipfile.ZipFile(jar, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
        for name, data in sorted(class_files.items()):
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, data)
    javap = run([str(java_home / 'bin/javap'), '-classpath', str(jar), '-s', '-private',
        'dev.qperiapt.continuity.android.Native'], 'javap').decode()
    bridge = source['jni/continuity_jni.c'].decode()
    registrations = re.findall(r'\{"([A-Za-z0-9_]+)",\s*"([^"]+)",\s*\(void \*\)', bridge)
    assert registrations and len(registrations) == len(dict(registrations))
    observed = re.findall(r'\bnative\s+[^\n]+?\s+([A-Za-z0-9_]+)\([^\n]*\);\s+descriptor:\s*(\S+)', javap)
    assert len(observed) == len(dict(observed)) and dict(observed) == dict(registrations)
    callbacks = re.findall(r'GetStaticMethodID\(env, local, "([^"]+)", "([^"]+)"\)', bridge)
    assert len(callbacks) == 3 and {name for name, _ in callbacks} == {'fail', 'validCommit', 'invokeCommit'}
    for name, descriptor in callbacks:
        assert re.search(r'\b' + re.escape(name) + r'\([^\n]*\);\s+descriptor:\s*' + re.escape(descriptor) + r'(?:\s|$)', javap)
    assert re.findall(r'System\.loadLibrary\("([^"]+)"\)', source['src/main/java/dev/qperiapt/continuity/android/Native.java'].decode()) == ['qperiapt_continuity_jni']
    expected_rules = b'# RegisterNatives and the native error callback depend on these exact names.\n-keep class dev.qperiapt.continuity.android.Native { *; }\n'
    assert source['consumer-rules.pro'] == expected_rules
    host_jar = SOURCE / 'target/continuity-installed-jni-release-current/continuity-android-classes.jar'
    with zipfile.ZipFile(host_jar) as zipped:
        assert len(zipped.namelist()) == len(class_files) and set(zipped.namelist()) == set(class_files)
        assert all(zipped.read(name) == data for name, data in class_files.items())
    notices = outside / 'android-aar-notices'
    notices.mkdir()
    metadata = json.loads((BUILD / 'metadata.stdout').read_bytes())
    licenses.collect(consumer, notices, 'aarch64-linux-android', root_package=c.NAME, resolved_metadata=metadata)
    licenses.verify(notices, expected_target='aarch64-linux-android', root_package=c.NAME)
    payload = {
        'AndroidManifest.xml': b'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.qperiapt.continuity.android"><uses-sdk android:minSdkVersion="23"/></manifest>\n',
        'classes.jar': jar.read_bytes(), 'R.txt': b'', 'proguard.txt': expected_rules,
        'META-INF/LICENSE': (SOURCE / 'LICENSE').read_bytes(),
        'META-INF/LICENSES/Apache-2.0.txt': (SOURCE / 'LICENSES/Apache-2.0.txt').read_bytes(),
        'META-INF/LICENSES/MIT.txt': (SOURCE / 'LICENSES/MIT.txt').read_bytes(),
        'META-INF/LICENSES/Rust-1.98.1-library.html': (SOURCE / 'LICENSES/Rust-1.98.1-library.html').read_bytes(),
    }
    for name, record in native['binaries'].items():
        data = (BUILD / 'native' / record['file']).read_bytes()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
        payload['jni/arm64-v8a/' + record['file']] = data
    for path in notices.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            name = 'META-INF/' + path.relative_to(notices).as_posix()
            assert name not in payload or payload[name] == path.read_bytes()
            payload[name] = path.read_bytes()
    for name in ('INVENTORY.sha256', 'LICENSE-INVENTORY.md', 'LICENSE.mlkem-native', 'PROVENANCE.md'):
        payload['META-INF/LICENSES/mlkem-native/' + name] = (SOURCE / 'crates/q-periapt-mlkem-native-sys/vendor' / name).read_bytes()
    hashes = {name: hashlib.sha256(data).hexdigest() for name, data in payload.items()}
    data = archive(payload)
    aar = OUT / 'q-periapt-continuity-android-0.0.0.aar'
    with aar.open('xb') as stream:
        stream.write(data)
    installed = outside / 'android-aar-installed'
    unpack(data, hashes, installed)
    licenses.verify(installed / 'META-INF', expected_target='aarch64-linux-android', root_package=c.NAME)
    assert android.source_files() == source and android.tool_identity(java_home) == java_identity
    assert package.source_inputs() == native['source_inputs']
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (native['source_commit'], False)
    result.update(completed=True, sources_unchanged=True, files=hashes, classes=len(class_files),
        java_sources=len(java_sources), native_methods=dict(registrations), static_callbacks=dict(callbacks),
        java_tools=java_identity, host_jar_sha256=sdk.snapshot(host_jar).sha256,
        classes_jar_sha256=sdk.snapshot(jar).sha256, host_class_bytes_match=True,
        aar={'file': aar.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'members': len(payload)},
        native_binaries=native['binaries'])
except BaseException as error:
    result.update(error_type=type(error).__name__, failure=str(error))
    raise
finally:
    sdk.write_json(OUT / 'ANDROID_AAR_PACKAGE.json', result)
print(json.dumps({'completed': result['completed'], 'aar': result.get('aar'), 'art_executed': False}), flush=True)
