from pathlib import Path
import hashlib
import json
import os
import re
import sys
import tempfile
import zipfile

import android_elf as elf
import continuity_android_jni as android
import continuity_c_abi as abi
import continuity_c_consumer as c
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report
from release_binary_scan import scan_release_file

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
TOOLS = REPO / 'target/continuity-android-tools-20261105'
STAGE = REPO / 'target/continuity-current-android-aar-5678'
OUT = STAGE / 'build-02'
OUT.mkdir(parents=True)
ndk_record = json.loads((TOOLS / 'NDK_INSTALL.json').read_bytes())
rust_record = json.loads((TOOLS / 'RUST_ANDROID_INSTALL.json').read_bytes())
assert ndk_record['completed'] and rust_record['completed']
ndk = Path(ndk_record['root'])
toolchain = Path(rust_record['private_toolchain'])
assert elf.verify_ndk_r29(ndk) == '29.0.14206865'
native_tools = elf.find_ndk_toolchain(ndk)
clang = native_tools / 'bin/aarch64-linux-android23-clang'
llvm_ar, llvm_nm, llvm_readelf, llvm_strip = [native_tools / 'bin' / name for name in ('llvm-ar', 'llvm-nm', 'llvm-readelf', 'llvm-strip')]
ndk_inventory = json.loads((TOOLS / 'NDK_FILES.json').read_bytes())
for name in (clang, llvm_ar, llvm_nm, llvm_readelf, llvm_strip):
    resolved = name.resolve(strict=True)
    key = 'android-ndk-r29/' + resolved.relative_to(ndk).as_posix()
    assert sdk.snapshot(resolved, maximum=512 * 1024**2).sha256 == ndk_inventory[key]['sha256']
for relative, expected in json.loads((TOOLS / 'RUST_ANDROID_FILES.json').read_bytes()).items():
    assert sdk.snapshot(toolchain / relative, maximum=512 * 1024**2).sha256 == expected['sha256']
commit, dirty = sdk.inspect_package_source(SOURCE, allow_dirty=False)
assert commit == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8' and not dirty
source_before = package.source_inputs()
outside = Path(tempfile.mkdtemp(prefix='qperiapt-android-current-')).resolve()
consumer = outside / 'c-consumer'
sdk.write_json(OUT / 'LOCATION.json', {'path': str(outside)})
for path in c.FIXTURE.rglob('*'):
    assert not path.is_symlink()
    if path.is_file():
        sdk.copy(path, consumer / path.relative_to(c.FIXTURE))
abi.load(consumer)
template_hashes = {p.relative_to(consumer).as_posix(): sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file()}
producer_path = SOURCE / 'target/sdk-020/RUST_SDK_PACKAGE.json'
pinned = sdk.snapshot(producer_path)
cohort = validate_report(pinned.data, '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d',
    pinned.sha256, sdk.source_identity()['rust_workspace_sha256'])
sdk.extract_recorded_crates(consumer, producer_path.parent, cohort['crates'])
candidate_root = SOURCE / 'target/continuity-installed-rust-current'
candidate_report = json.loads((candidate_root / 'CONTINUITY_PACKAGE.json').read_bytes())
assert candidate_report['completed'] and candidate_report['source_commit'] == commit
candidate_record = candidate_report['archive']
package.verify_candidate_archive(candidate_root, candidate_record)
candidate_files = package.validate_candidate(sdk.snapshot(candidate_root / candidate_record['file']).data, set(candidate_record['files']))
for relative, data in candidate_files.items():
    target = consumer / 'packages' / (package.NAME + '-' + package.VERSION) / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
with (consumer / 'Cargo.toml').open('a') as stream:
    stream.write(f'{package.NAME} = {{ path = "packages/{package.NAME}-{package.VERSION}" }}\n')
manifest_digest = sdk.snapshot(consumer / 'Cargo.toml').sha256
original_lock = (package.CANDIDATE / 'Cargo.lock').read_bytes()
(consumer / 'Cargo.lock').write_bytes(original_lock)
adapter_source = android.source_files()
adapter = outside / 'android-source'
for name, data in adapter_source.items():
    path = adapter / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
cache = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
assert not any((cache / name).exists() for name in ('config', 'config.toml', 'credentials', 'credentials.toml'))
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'JAVA_', 'JDK_', 'GRADLE_', 'ANDROID_', 'QPC_', 'QPERIAPT_'))}
for key in ('CC', 'CXX', 'AR', 'LD', 'CPP', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH',
            'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'OBJC_INCLUDE_PATH', 'LIBRARY_PATH', 'SDKROOT',
            'MACOSX_DEPLOYMENT_TARGET', 'OPENSSL_CONF', 'OPENSSL_CONF_INCLUDE', 'OPENSSL_MODULES',
            'OPENSSL_ENGINES', 'SSL_CERT_FILE', 'SSL_CERT_DIR', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'CLASSPATH'):
    env.pop(key, None)
account_root = Path.home().resolve()
remap_c = [flag + '=' + str(path) + '=' + replacement
    for path, replacement in ((outside, '/qperiapt/installed'), (account_root, '/qperiapt-build/user'))
    for flag in ('-ffile-prefix-map', '-fdebug-prefix-map', '-fmacro-prefix-map')]
env.update(CARGO_HOME=str(cache), CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR=str(outside / 'build'), CARGO=str(toolchain / 'bin/cargo'), RUSTC=str(toolchain / 'bin/rustc'),
    RUSTDOC=str(toolchain / 'bin/rustdoc'), RUSTFLAGS='-D warnings --remap-path-prefix=' + str(outside) + '=/qperiapt/installed --remap-path-prefix=' + str(account_root) + '=/qperiapt-build/user',
    RUSTDOCFLAGS='-D warnings', DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'),
    CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=str(clang), CC_aarch64_linux_android=str(clang),
    AR_aarch64_linux_android=str(llvm_ar),
    CFLAGS=' '.join(remap_c),
    PATH=str(toolchain / 'bin') + os.pathsep + env.get('PATH', os.defpath))

def run(argv, label, cwd=consumer):
    print(label, flush=True)
    return sdk.command(argv, OUT / label, cwd, environment=env)

result = {'completed': False, 'source_commit': commit, 'sdk_report_sha256': pinned.sha256,
    'driver_sha256': sdk.snapshot(Path(__file__)).sha256,
    'compile_environment': {key: env[key] for key in ('RUSTFLAGS', 'CFLAGS', 'RUSTC', 'CARGO', 'CARGO_TARGET_DIR',
        'CARGO_NET_OFFLINE', 'CC_aarch64_linux_android', 'AR_aarch64_linux_android', 'CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER')},
    'candidate_archive_sha256': candidate_record['sha256'], 'source_inputs': source_before,
    'android_source': {name: hashlib.sha256(data).hexdigest() for name, data in adapter_source.items()},
    'native_target': 'aarch64-linux-android', 'android_api': 23, 'ndk_revision': '29.0.14206865',
    'release_claim_eligible': False, 'art_executed': False, 'physical_device_executed': False,
    'scope': 'Current installed candidate C engine and Android JNI Release native build only; unpublished qpc-owner/1. No product ABI2 admission, AAR consumer or device runtime qualification.'}
try:
    result['rustc'] = run([str(toolchain / 'bin/rustc'), '-vV'], 'rustc').decode()
    result['clang'] = run([str(clang), '--version'], 'clang').decode()
    metadata = json.loads(run([str(toolchain / 'bin/cargo'), 'metadata', '--offline', '--format-version', '1',
        '--filter-platform', 'aarch64-linux-android'], 'metadata'))
    result['resolution'] = package.verify_resolution(metadata, consumer, (consumer / 'Cargo.lock').read_bytes(), original_lock,
        consumer_name=c.NAME, required_features=c.FEATURES)
    hardening = ['--no-undefined', '--fatal-warnings', '-z,relro', '-z,now', '-z,max-page-size=16384', '-z,common-page-size=16384']
    argv = [str(toolchain / 'bin/cargo'), 'rustc', '--lib', '--release', '--locked', '--offline',
        '--target', 'aarch64-linux-android', '--message-format=json', '-j', '2', '--']
    for flag in [*hardening, '-soname,libq_periapt_continuity_c_consumer.so']:
        argv += ['-C', 'link-arg=-Wl,' + flag]
    run(argv, 'native-build')
    native = OUT / 'native'
    native.mkdir()
    library = native / 'libq_periapt_continuity_c_consumer.so'
    built = outside / 'build/aarch64-linux-android/release' / library.name
    result['unstripped_c_library_sha256'] = sdk.snapshot(built, maximum=c.MAX_BINARY).sha256
    sdk.copy(built, library, maximum=c.MAX_BINARY)
    run([str(llvm_strip), '--strip-unneeded', str(library)], 'native-strip')
    bridge = native / 'libqperiapt_continuity_jni.so'
    run([str(clang), '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic', '-shared', '-fPIC', '-fvisibility=hidden', *remap_c,
        '-I' + str(consumer), '-I' + str(native_tools / 'sysroot/usr/include'),
        *map(str, sorted((adapter / 'jni').glob('*.c'))), '-L' + str(native), '-lq_periapt_continuity_c_consumer',
        *['-Wl,' + flag for flag in hardening], '-Wl,-soname,' + bridge.name, '-o', str(bridge)], 'jni-build')
    run([str(llvm_strip), '--strip-unneeded', str(bridge)], 'jni-strip')
    binaries = {}
    for path, exports, expected_project in ((library, c.EXPORTS, set()), (bridge, {'JNI_OnLoad'}, {library.name})):
        label = 'c' if path == library else 'jni'
        elf.parse_elf_header(path, 'arm64-v8a')
        headers = run([str(llvm_readelf), '-l', '-W', str(path)], label + '-program-headers').decode()
        dynamic = run([str(llvm_readelf), '-d', '-W', str(path)], label + '-dynamic').decode()
        symbols = run([str(llvm_nm), '--dynamic', '--defined-only', '--extern-only', '--format=posix', str(path)], label + '-symbols').decode()
        sections = run([str(llvm_readelf), '-S', '-W', str(path)], label + '-sections').decode()
        elf.verify_program_headers(headers, path)
        elf.verify_release_sections(sections, path)
        assert elf.parse_nm_exports(symbols, path) == set(exports)
        soname, needed, tags, values = elf.parse_dynamic_entries(dynamic, path)
        assert soname == path.name and needed - elf.SYSTEM_NEEDED_ALLOWLIST == expected_project
        assert not tags.intersection({'TEXTREL', 'RPATH', 'RUNPATH'})
        assert 'BIND_NOW' in values.get('FLAGS', '') or re.search(r'(?:^|\s)NOW(?:\s|$)', values.get('FLAGS_1', ''))
        scan_release_file(path, forbidden_text=(str(SOURCE), str(REPO), str(outside)))
        binaries[label] = {'file': path.name, 'sha256': sdk.snapshot(path, maximum=c.MAX_BINARY).sha256,
            'bytes': path.stat().st_size, 'exports': sorted(exports), 'needed': sorted(needed), 'soname': soname,
            'release_binary_scan_passed': True}
    result['binaries'] = binaries
    run([str(toolchain / 'bin/cargo-clippy'), 'clippy', '--lib', '--release', '--locked', '--offline',
        '--target', 'aarch64-linux-android', '-j', '2', '--', '-D', 'warnings'], 'clippy')
    sdk.verify_consumed_sources(consumer, producer_path.parent, cohort['crates'])
    for name, data in candidate_files.items():
        assert sdk.snapshot(consumer / 'packages' / (package.NAME + '-' + package.VERSION) / name).data == data
    for name, digest in template_hashes.items():
        if name != 'Cargo.toml':
            assert sdk.snapshot(consumer / name).sha256 == digest
    assert sdk.snapshot(consumer / 'Cargo.toml').sha256 == manifest_digest
    assert package.source_inputs() == source_before and android.source_files() == adapter_source
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (commit, dirty)
    sdk.copy(consumer / 'Cargo.lock', OUT / 'consumer-Cargo.lock')
    result.update(completed=True, sources_unchanged=True)
except BaseException as error:
    result.update(error_type=type(error).__name__, failure=str(error))
    raise
finally:
    sdk.write_json(OUT / 'ANDROID_NATIVE_BUILD.json', result)
print(json.dumps({'completed': result['completed'], 'native_target': result['native_target'], 'art_executed': False}), flush=True)
