from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import posixpath
import stat
import subprocess
import sys
import unicodedata
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
download = json.loads((ROOT / 'ndk-DOWNLOAD.json').read_bytes())
assert download['completed'] is True
archive_path = ROOT / download['file']
assert archive_path.stat().st_size == download['bytes']
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == download['sha256']
output = ROOT / 'ndk-install'
output.mkdir(mode=0o700)
inventory = {}
record = {'completed': False, 'archive_sha256': download['sha256'],
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Private project-local NDK extraction and tool checks; no global installation or Android runtime execution.'}
try:
    with zipfile.ZipFile(archive_path) as archive:
        rows = archive.infolist()
        assert len(rows) <= 200000 and sum(row.file_size for row in rows) <= 8 * 1024**3
        folded = set()
        names = set()
        links = {}
        for row in rows:
            name = row.filename.rstrip('/')
            path = PurePosixPath(name)
            assert name and not path.is_absolute() and path.parts[0] == 'android-ndk-r29'
            assert '..' not in path.parts and '.' not in path.parts and '\\' not in name and ':' not in name
            assert path.as_posix() == name and name not in names
            key = unicodedata.normalize('NFC', name).casefold()
            assert key not in folded, 'case-colliding NDK entries'
            folded.add(key)
            names.add(name)
            assert row.file_size <= 512 * 1024**2
            if stat.S_ISLNK(row.external_attr >> 16):
                target = archive.read(row).decode()
                assert target and not target.startswith('/') and '\\' not in target and '\x00' not in target
                resolved = PurePosixPath(posixpath.normpath(posixpath.join(path.parent.as_posix(), target)))
                assert resolved.parts[0] == 'android-ndk-r29' and '..' not in resolved.parts
                links[name] = target
            else:
                mode = stat.S_IFMT(row.external_attr >> 16)
                assert mode in (0, stat.S_IFREG, stat.S_IFDIR)
        for name in names:
            assert not any(parent.as_posix() in links for parent in PurePosixPath(name).parents), 'archive writes below a symlink'
        for row in rows:
            name = row.filename.rstrip('/')
            target = output / name
            if name in links:
                continue
            if row.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            data = archive.read(row)
            with target.open('xb') as stream:
                stream.write(data)
            mode = 0o755 if (row.external_attr >> 16) & 0o111 else 0o644
            target.chmod(mode)
            inventory[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode}
        for name, link in links.items():
            target = output / name
            target.parent.mkdir(parents=True, exist_ok=True)
            os.symlink(link, target)
            inventory[name] = {'link': link}
        for name in links:
            assert (output / name).resolve(strict=True).is_relative_to(output / 'android-ndk-r29')
    ndk = output / 'android-ndk-r29'
    properties = (ndk / 'source.properties').read_text()
    assert 'Pkg.Revision = 29.0.14206865' in properties
    compiler = ndk / 'toolchains/llvm/prebuilt/darwin-x86_64/bin/clang'
    identity = subprocess.run(['/usr/bin/file', str(compiler.resolve(strict=True))], check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert identity.stderr == b''
    version = subprocess.run([str(compiler), '--version'], check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert version.stderr == b''
    (ROOT / 'ndk-clang-file.txt').write_bytes(identity.stdout)
    (ROOT / 'ndk-clang-version.txt').write_bytes(version.stdout)
    record.update(completed=True, root=str(ndk), files=len(inventory), links=len(links),
        properties=properties, compiler_file=identity.stdout.decode(), compiler_version=version.stdout.decode())
except BaseException as error:
    record.update(error_type=type(error).__name__, failure=str(error), extracted_entries=len(inventory))
    raise
finally:
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (ROOT / 'NDK_FILES.json').open('x') as stream:
        stream.write(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
    with (ROOT / 'NDK_INSTALL.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
