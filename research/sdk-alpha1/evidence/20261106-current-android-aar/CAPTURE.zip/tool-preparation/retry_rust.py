from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'rust-retry-02'
OUT.mkdir()
plan = json.loads((ROOT / 'DOWNLOAD_PLAN.json').read_bytes())['rust_std']
diagnosis = json.loads((ROOT / 'rust-mismatch-01/DIAGNOSIS.json').read_bytes())
assert diagnosis['official_checksum_and_release_manifest_match_local_pin'] is True
assert diagnosis['expected_sha256'] == plan['sha256']
partial = OUT / (plan['file'] + '.partial')
final = ROOT / plan['file']
assert not final.exists()
argv = ['/usr/bin/curl', '--fail', '--location', '--silent', '--show-error', '--retry', '0',
    '--connect-timeout', '30', '--max-time', '240', '--max-filesize', str(128 * 1024**2),
    '--header', 'Accept-Encoding: identity', '--header', 'Cache-Control: no-cache',
    '--dump-header', str(OUT / 'headers.txt'), '--output', str(partial), plan['url']]
record = {'completed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'argv': argv, 'expected_sha256': plan['sha256'], 'reason': diagnosis['conclusion'],
    'attempt': 2, 'automatic_retries': 0, 'archive_installed_or_executed': False}
started = time.monotonic()
try:
    with (OUT / 'curl.stdout').open('xb') as stdout, (OUT / 'curl.stderr').open('xb') as stderr:
        result = subprocess.run(argv, stdout=stdout, stderr=stderr, timeout=250)
    record['returncode'] = result.returncode
    assert result.returncode == 0, 'fresh bounded Rust download failed'
    record['bytes'] = partial.stat().st_size
    record['sha256'] = hashlib.sha256(partial.read_bytes()).hexdigest()
    assert 0 < record['bytes'] <= 128 * 1024**2 and record['sha256'] == plan['sha256'], 'fresh Rust archive still differs from pinned digest'
    partial.rename(final)
    record.update(completed=True, file=final.name)
except BaseException as error:
    record.update(error_type=type(error).__name__, failure=str(error))
    raise
finally:
    record.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), seconds=time.monotonic() - started)
    with (OUT / 'RESULT.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
