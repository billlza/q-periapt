from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import subprocess
import sys
import tarfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
source = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
destination = ROOT / 'rust-1.98.1-android'
accepted = json.loads((ROOT / 'rust-retry-02/RESULT.json').read_bytes())
assert accepted['completed'] is True and accepted['sha256'] == accepted['expected_sha256']
archive_path = ROOT / accepted['file']
assert archive_path.stat().st_size == accepted['bytes'] and hashlib.sha256(archive_path.read_bytes()).hexdigest() == accepted['sha256']
assert not destination.exists() and not (source / 'lib/rustlib/aarch64-linux-android').exists()
pinned = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in
    ('bin/rustc', 'bin/cargo', 'lib/rustlib/multirust-channel-manifest.toml')}
record = {'completed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_toolchain': str(source), 'private_toolchain': str(destination), 'source_files': pinned,
    'archive_sha256': accepted['sha256'], 'global_toolchain_modified': False,
    'scope': 'Private filesystem clone with only the pinned Android standard-library component added. No rustup registration, default toolchain change or global installation.'}
installed = {}
try:
    with (ROOT / 'rust-clone.stdout').open('xb') as stdout, (ROOT / 'rust-clone.stderr').open('xb') as stderr:
        result = subprocess.run(['/bin/cp', '-cR', str(source), str(destination)], stdout=stdout, stderr=stderr, timeout=180)
    assert result.returncode == 0
    for name, digest in pinned.items():
        assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == digest
        assert (destination / name).stat().st_ino != (source / name).stat().st_ino
    prefix = 'rust-std-1.98.1-aarch64-linux-android/rust-std-aarch64-linux-android/'
    with tarfile.open(archive_path, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) <= 10000 and sum(m.size for m in members) <= 1024**3
        seen = set()
        for member in members:
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
            assert member.name not in seen and (member.isfile() or member.isdir())
            seen.add(member.name)
            if not member.name.startswith(prefix + 'lib/rustlib/aarch64-linux-android/') or not member.isfile():
                continue
            relative = member.name.removeprefix(prefix)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            stream = archive.extractfile(member)
            assert stream is not None and member.size <= 256 * 1024**2
            with stream:
                data = stream.read()
            assert len(data) == member.size
            with target.open('xb') as output:
                output.write(data)
            mode = 0o755 if member.mode & 0o111 else 0o644
            target.chmod(mode)
            installed[relative] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode}
    assert installed and any(Path(name).name.startswith('libstd-') for name in installed)
    for name, digest in pinned.items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
        assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == digest
    assert not (source / 'lib/rustlib/aarch64-linux-android').exists()
    for name, expected in installed.items():
        assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == expected['sha256']
    result = subprocess.run([str(destination / 'bin/rustc'), '--target', 'aarch64-linux-android', '--print', 'target-libdir'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=True)
    assert result.stderr == b'' and Path(result.stdout.decode().strip()) == destination / 'lib/rustlib/aarch64-linux-android/lib'
    version = subprocess.run([str(destination / 'bin/rustc'), '-vV'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=True)
    assert version.stderr == b'' and version.stdout.startswith(b'rustc 1.98.1 (48a229cea 2026-09-01)')
    record.update(completed=True, installed_files=len(installed), rustc=version.stdout.decode(),
        target_libdir=result.stdout.decode().strip())
except BaseException as error:
    record.update(error_type=type(error).__name__, failure=str(error))
    raise
finally:
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (ROOT / 'RUST_ANDROID_FILES.json').open('x') as stream:
        stream.write(json.dumps(installed, indent=2, sort_keys=True) + '\n')
    with (ROOT / 'RUST_ANDROID_INSTALL.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
