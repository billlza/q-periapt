from pathlib import Path
import datetime
import hashlib
import json
import sys
import tomllib
import urllib.request

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'rust-mismatch-01'
OUT.mkdir()
urls = {
    'archive.sha256': 'https://static.rust-lang.org/dist/2026-09-03/rust-std-1.98.1-aarch64-linux-android.tar.xz.sha256',
    'release.toml': 'https://static.rust-lang.org/dist/channel-rust-1.98.1.toml',
}
observations = {}
for name, url in urls.items():
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            content = response.read(8 * 1024**2 + 1)
            assert len(content) <= 8 * 1024**2
            observations[name] = {'url': url, 'final_url': response.url, 'status': response.status,
                'content_type': response.headers.get('Content-Type'), 'bytes': len(content),
                'sha256': hashlib.sha256(content).hexdigest()}
        with (OUT / name).open('xb') as stream:
            stream.write(content)
    except Exception as error:
        observations[name] = {'url': url, 'error_type': type(error).__name__, 'error': str(error)}
with (OUT / 'FETCH.json').open('x') as stream:
    stream.write(json.dumps(observations, indent=2) + '\n')
partial = ROOT / 'rust-std-1.98.1-aarch64-linux-android.tar.xz.partial'
actual = hashlib.sha256(partial.read_bytes()).hexdigest()
result = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'downloaded_bytes': partial.stat().st_size, 'downloaded_sha256': actual,
    'manifest_expected_sha256': json.loads((ROOT / 'DOWNLOAD_PLAN.json').read_bytes())['rust_std']['sha256'],
    'archive_installed_or_executed': False}
if 'error' not in observations['archive.sha256']:
    result['official_checksum_text'] = (OUT / 'archive.sha256').read_text()
if 'error' not in observations['release.toml']:
    manifest = tomllib.loads((OUT / 'release.toml').read_text())
    result['official_release_target'] = manifest['pkg']['rust-std']['target']['aarch64-linux-android']
with (OUT / 'COMPARISON.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
