from pathlib import Path
import datetime
import hashlib
import json
import sys
import tomllib
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
url = 'https://dl.google.com/android/repository/repository2-3.xml'
with urllib.request.urlopen(url, timeout=45) as response:
    assert response.status == 200 and urllib.parse.urlparse(response.url).netloc == 'dl.google.com'
    data = response.read(20 * 1024**2 + 1)
assert len(data) <= 20 * 1024**2 and b'<!DOCTYPE' not in data and b'<!ENTITY' not in data
with (ROOT / 'repository2-3.xml').open('xb') as stream:
    stream.write(data)
document = ET.fromstring(data)
matches = [node for node in document.findall('.//{*}remotePackage') if node.get('path') == 'ndk;29.0.14206865']
assert len(matches) == 1
package = matches[0]
archives = [node for node in package.findall('./{*}archives/{*}archive') if node.findtext('./{*}host-os') == 'macosx']
assert len(archives) == 1
complete = archives[0].find('./{*}complete')
assert complete is not None
name = complete.findtext('./{*}url')
size = int(complete.findtext('./{*}size'))
checksum = complete.find('./{*}checksum')
assert name == 'android-ndk-r29-darwin.zip' and 0 < size < 4 * 1024**3
assert checksum is not None and checksum.get('type') == 'sha1'
digest = checksum.text.strip()
assert len(digest) == 40 and all(c in '0123456789abcdef' for c in digest)
manifest_path = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib/rustlib/multirust-channel-manifest.toml')
manifest_data = manifest_path.read_bytes()
manifest = tomllib.loads(manifest_data.decode())
target = manifest['pkg']['rust-std']['target']['aarch64-linux-android']
assert target['available'] is True
assert target['xz_url'] == 'https://static.rust-lang.org/dist/2026-09-03/rust-std-1.98.1-aarch64-linux-android.tar.xz'
assert target['xz_hash'] == 'd7c4949bb77b007bed188c9b15b8267a3222dc9b9c517f05d1899f9e885fb79e'
record = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'android_repository': {'url': url, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
    'ndk': {'revision': '29.0.14206865', 'file': name, 'url': urllib.parse.urljoin(url, name),
        'bytes': size, 'publisher_sha1': digest, 'license_ref': package.find('./{*}uses-license').get('ref')},
    'rust_std': {'target': 'aarch64-linux-android', 'file': target['xz_url'].rsplit('/', 1)[1],
        'url': target['xz_url'], 'sha256': target['xz_hash'],
        'source_manifest_sha256': hashlib.sha256(manifest_data).hexdigest()},
    'scope': 'Pinned existing Android build contract; preparation under project target only. No global installation, device interaction, ABI admission or runtime qualification.'}
with (ROOT / 'DOWNLOAD_PLAN.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
