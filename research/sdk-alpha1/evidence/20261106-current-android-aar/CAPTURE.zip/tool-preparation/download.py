from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import urllib.parse
import urllib.request

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
kind = sys.argv[1]
assert kind in {'ndk', 'rust_std'}
plan = json.loads((ROOT / 'DOWNLOAD_PLAN.json').read_bytes())[kind]
partial = ROOT / (plan['file'] + '.partial')
final = ROOT / plan['file']
assert not partial.exists() and not final.exists()
limit = plan['bytes'] if kind == 'ndk' else 128 * 1024**2
record = {'kind': kind, 'url': plan['url'], 'completed': False,
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
started = time.monotonic()
size = 0
sha1 = hashlib.sha1()
sha256 = hashlib.sha256()
next_progress = 64 * 1024**2
try:
    with urllib.request.urlopen(plan['url'], timeout=45) as response, partial.open('xb') as stream:
        expected_host = 'dl.google.com' if kind == 'ndk' else 'static.rust-lang.org'
        assert response.status == 200 and urllib.parse.urlparse(response.url).netloc == expected_host
        while True:
            assert time.monotonic() - started < 1200, 'download exceeded bounded preparation interval'
            data = response.read(1024**2)
            if not data:
                break
            size += len(data)
            assert size <= limit, 'download exceeds recorded size/bound'
            stream.write(data)
            sha1.update(data)
            sha256.update(data)
            if size >= next_progress:
                print(json.dumps({'kind': kind, 'downloaded_bytes': size}), flush=True)
                next_progress += 64 * 1024**2
    if kind == 'ndk':
        assert size == plan['bytes'] and sha1.hexdigest() == plan['publisher_sha1']
    else:
        assert sha256.hexdigest() == plan['sha256']
    partial.rename(final)
    record.update(completed=True, file=final.name, bytes=size, sha1=sha1.hexdigest(), sha256=sha256.hexdigest())
except BaseException as error:
    record.update(failure=str(error), partial_file=partial.name, downloaded_bytes=size)
    raise
finally:
    record.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), seconds=time.monotonic() - started)
    with (ROOT / (kind + '-DOWNLOAD.json')).open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
