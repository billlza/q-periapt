//! Actual enrolled-owner state encoding with an isolated moving allocator.
#[path = "../../source/research/continuity-identity-candidate/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;
use q_periapt_continuity_identity_candidate as p;
use p::connection_transport::{ConnectionEndpoint, Consumption, Run, Submission};
use observer_peer::{Server, Task};
use serde_json::json;
use std::{fs, io::Write, path::PathBuf};
use zeroize::Zeroizing;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
fn check(value: bool, message: &str) -> Result<()> {
    if value { Ok(()) } else { Err(message.to_owned().into()) }
}

fn controls() -> Result<()> {
    let mut moving = Zeroizing::new(vec![0xa5; 32]);
    qpc_growth_hook::watch(&moving, 0, 32);
    moving.reserve_exact(4096);
    drop(moving);
    check(qpc_growth_hook::counters() == [1, 1, 1, 1, 0, 0], "moving positive control failed")?;
    qpc_growth_hook::reset();
    let mut fixed = Zeroizing::new(Vec::with_capacity(64));
    fixed.extend_from_slice(&[0xa5; 32]);
    qpc_growth_hook::watch(&fixed, 0, 32);
    fixed.extend_from_slice(&[0x5a; 32]);
    drop(fixed);
    check(qpc_growth_hook::counters() == [1, 0, 0, 1, 0, 0], "fixed-capacity negative control failed")?;
    qpc_growth_hook::reset();
    Ok(())
}

#[test]
fn observe_state_growth() -> Result<()> {
    controls()?;
    let output = PathBuf::from(std::env::var_os("QPC_GROWTH_OUTPUT").ok_or("output required")?);
    check(output.is_absolute() && !output.exists(), "fresh output required")?;
    let setup = fixture::setup_enrolled_with_witness(None)?;
    let mut client = fixture::Peer::open_with_witness(&setup.initiator, None)?;
    let endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
    let mut server = Server::start(setup.responder.clone(), None)?;
    server.begin(Task::Bootstrap)?;
    let name = client.peer_name.clone();
    let established = endpoint.establish(client.actor()?, p::InitiationId::generate()?, Run {
        address:server.address, server_name:&name, limits:fixture::limits(),
        cancel:&p::Cancellation::default(),
    }, fixture::now)?;
    check(server.finish_operation()?["established"] == json!(established.session), "bootstrap mismatch")?;
    let session = established.session;
    let message = client.service.stores()?.0.next_message_id(&client.context, session, fixture::now()?)?;
    let plaintext = b"controlled state growth observation";
    server.begin(Task::Message { fail_after_effect:false })?;
    let delivered = endpoint.send(client.actor()?, Submission { session, message,
        plaintext, associated_data:b"growth-observer" }, Run {
        address:server.address, server_name:&name,
        limits:p::connection_transport::RunLimits { exchanges:1, ..fixture::limits() },
        cancel:&p::Cancellation::default(),
    }, fixture::now)?;
    check(delivered.consumption == Consumption::Confirmed, "message not consumed")?;
    let effect = server.finish_operation()?;
    check(effect["calls"] == 1 && effect["effects"] == 1, "business effect mismatch")?;
    let server_summary = server.finish()?;
    client.close();
    drop(endpoint);
    drop(client);
    let counters = qpc_growth_hook::counters();
    check(counters[0] > 0 && counters[5] == 0, "missing or live state watches")?;
    let report = json!({"workload_completed":true,"controls_passed":true,
        "session":session,"message":message.as_bytes(),"server":server_summary,"server_open_ns":server.open_ns,
        "watched_state_buffers":counters[0],"moving_reallocations":counters[1],
        "nonzero_secret_ranges_at_reallocation_free":counters[2],
        "zeroed_secret_ranges_at_final_free":counters[3],
        "nonzero_secret_ranges_at_final_free":counters[4],"live_watches":counters[5],
        "scope":"Actual State::encode rekey field with moving System allocator wrapper; observer hook only in isolated clone. Not a native allocator residue or exploit measurement.",
        "release_claim_eligible":false});
    let mut file = fs::OpenOptions::new().create_new(true).write(true).open(output)?;
    file.write_all(&serde_json::to_vec_pretty(&report)?)?;
    file.sync_all()?;
    println!("SECRET_GROWTH_COUNTS {}", json!(counters));
    check(counters[2] == 0 && counters[4] == 0, "secret range was released without zeroization")
}
