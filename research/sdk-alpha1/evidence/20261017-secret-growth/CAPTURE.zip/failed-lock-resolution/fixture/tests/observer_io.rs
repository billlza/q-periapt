use super::{p, Result};
use mio::{Events, Interest, Poll, Token};
use std::{io, net::{SocketAddr, TcpListener, TcpStream}, time::{Duration, Instant}};

pub struct Listener {
    socket: TcpListener,
    registered: mio::net::TcpListener,
    poll: Poll,
    events: Events,
}
impl Listener {
    pub fn bind() -> Result<Self> {
        let socket=TcpListener::bind("127.0.0.1:0")?;
        socket.set_nonblocking(true)?;
        let mut registered=mio::net::TcpListener::from_std(socket.try_clone()?);
        let poll=Poll::new()?;
        poll.registry().register(&mut registered,Token(1),Interest::READABLE)?;
        Ok(Self{socket,registered,poll,events:Events::with_capacity(4)})
    }
    pub fn address(&self)->io::Result<SocketAddr>{self.socket.local_addr()}
    pub fn accept(&mut self,cancel:&p::Cancellation)->Result<TcpStream>{
        let deadline=Instant::now()+Duration::from_secs(20);
        loop {
            if cancel.is_cancelled(){return Err("listener cancelled".into());}
            match self.socket.accept(){
                Ok((stream,_))=>{stream.set_nonblocking(false)?;return Ok(stream)},
                Err(e) if e.kind()==io::ErrorKind::WouldBlock=>{},
                Err(e) if e.kind()==io::ErrorKind::Interrupted=>continue,
                Err(e)=>return Err(e.into()),
            }
            let left=deadline.checked_duration_since(Instant::now()).ok_or("listener deadline")?;
            self.poll.poll(&mut self.events,Some(left.min(Duration::from_millis(50))))?;
        }
    }
}
impl Drop for Listener {
    fn drop(&mut self){if let Err(e)=self.poll.registry().deregister(&mut self.registered){eprintln!("listener deregistration failed: {e}");}}
}

