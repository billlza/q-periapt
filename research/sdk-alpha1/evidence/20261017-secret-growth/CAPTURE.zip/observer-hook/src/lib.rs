//! Isolated allocator observer. Never linked into product distributions.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::{Mutex, MutexGuard};

#[derive(Clone, Copy)]
struct Watch {
    address: usize,
    offset: usize,
    length: usize,
}
const EMPTY: Watch = Watch { address: 0, offset: 0, length: 0 };
struct Book {
    watches: [Watch; 64],
    registered: usize,
    moves: usize,
    dirty_move_frees: usize,
    clean_drop_frees: usize,
    dirty_drop_frees: usize,
}
static BOOK: Mutex<Book> = Mutex::new(Book {
    watches: [EMPTY; 64], registered: 0, moves: 0,
    dirty_move_frees: 0, clean_drop_frees: 0, dirty_drop_frees: 0,
});
fn book() -> MutexGuard<'static, Book> {
    BOOK.lock().unwrap_or_else(|_| std::process::abort())
}

/// Register only an initialized range of an exclusively owned Vec allocation.
/// The isolated caller appends without removing or changing this range. No
/// pointer, contents or secret-derived digest is returned by this observer.
pub fn watch(bytes: &[u8], offset: usize, length: usize) {
    let field = bytes.get(offset..offset.checked_add(length).expect("range overflow"))
        .expect("observer range must be initialized");
    assert!(!field.is_empty() && field.iter().any(|b| *b != 0), "zero field cannot witness erasure");
    let address = bytes.as_ptr() as usize;
    let mut b = book();
    assert!(!b.watches.iter().any(|w| w.address == address), "duplicate watch");
    let slot = b.watches.iter().position(|w| w.address == 0).expect("watch capacity exceeded");
    b.watches[slot] = Watch { address, offset, length };
    b.registered += 1;
}

/// Return registration/move/dirty-move/clean-drop/dirty-drop/live counts.
pub fn counters() -> [usize; 6] {
    let b = book();
    [b.registered, b.moves, b.dirty_move_frees, b.clean_drop_frees,
        b.dirty_drop_frees, b.watches.iter().filter(|w| w.address != 0).count()]
}

/// Separate the observer controls from the real product-path experiment.
pub fn reset() {
    let mut b = book();
    assert!(b.watches.iter().all(|w| w.address == 0), "live watch at reset");
    b.registered = 0;
    b.moves = 0;
    b.dirty_move_frees = 0;
    b.clean_drop_frees = 0;
    b.dirty_drop_frees = 0;
}

struct Moving;
#[global_allocator]
static ALLOCATOR: Moving = Moving;

unsafe impl GlobalAlloc for Moving {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: preserve the allocator caller's layout contract.
        unsafe { System.alloc(layout) }
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        {
            let mut b = book();
            if let Some(slot) = b.watches.iter().position(|w| w.address == pointer as usize) {
                let w = b.watches[slot];
                if w.offset + w.length > layout.size() { std::process::abort(); }
                // SAFETY: watch received this live allocation's initialized range.
                // The instrumented append-only path never makes it uninitialized;
                // Zeroizing's drop overwrites it before this callback, if called.
                let bytes = unsafe { std::slice::from_raw_parts(pointer.add(w.offset), w.length) };
                if bytes.iter().any(|v| *v != 0) { b.dirty_drop_frees += 1; }
                else { b.clean_drop_frees += 1; }
                b.watches[slot] = EMPTY;
            }
        }
        // SAFETY: ownership and layout pass unchanged to the underlying allocator.
        unsafe { System.dealloc(pointer, layout) }
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let next_layout = match Layout::from_size_align(new_size, layout.align()) {
            Ok(value) => value,
            Err(_) => return std::ptr::null_mut(),
        };
        // Force a valid moving realloc to expose the release boundary. This is
        // a counterexample under an allowed allocator, not a native allocator
        // retention or exploit measurement. Raw copy preserves uninitialized
        // capacity without interpreting it; observations read only watched bytes.
        let next = unsafe { System.alloc(next_layout) };
        if next.is_null() { return next; }
        // SAFETY: distinct live allocations, each valid for this minimum size.
        unsafe { std::ptr::copy_nonoverlapping(pointer, next, layout.size().min(new_size)) };
        {
            let mut b = book();
            if let Some(slot) = b.watches.iter().position(|w| w.address == pointer as usize) {
                let w = b.watches[slot];
                if w.offset + w.length > layout.size() { std::process::abort(); }
                // SAFETY: same initialized-range guarantee as dealloc; old
                // allocation is still live and has not been returned to System.
                let bytes = unsafe { std::slice::from_raw_parts(pointer.add(w.offset), w.length) };
                b.moves += 1;
                if bytes.iter().any(|v| *v != 0) { b.dirty_move_frees += 1; }
                b.watches[slot] = if w.offset + w.length <= new_size {
                    Watch { address: next as usize, ..w }
                } else { EMPTY };
            }
        }
        // SAFETY: ownership transferred to next; release exactly the old layout.
        unsafe { System.dealloc(pointer, layout) };
        next
    }
}
