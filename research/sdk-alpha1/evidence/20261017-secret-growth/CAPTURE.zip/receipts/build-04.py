"""Build an isolated observer against the unchanged current enrolled-owner source."""
from pathlib import Path
import json, os, subprocess, tomllib
import rust_sdk_profile as sdk
from codeql_rust_profile import ProfileRun
root=Path.cwd(); stage=Path(__file__).resolve().parent; fixture=stage/'fixture'
tools=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
env=dict(os.environ, CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',
    CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_BUILD_JOBS='1',
    CARGO_TARGET_DIR=str(root/'target/continuity-session-cost-20261015/native-target-07'),
    PATH=str(tools/'bin')+':'+os.environ['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(tools/'lib'))
run=ProfileRun(root,stage/'build-04',root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
sdk.require(not run.command('clean',['git','status','--porcelain'],seconds=30),'product checkout dirty')
head=run.command('head',['git','rev-parse','HEAD'],seconds=30).decode().strip()
run.command('compiler',[str(tools/'bin/rustc'),'-vV'],seconds=30)
run.command('objcopy',[str(tools/'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'),'--version'],seconds=30)
run.command('clang',['/usr/bin/clang','--version'],seconds=30)
run.command('sdk',['/usr/bin/xcrun','--show-sdk-path'],seconds=30)
run.command('metadata',[str(tools/'bin/cargo'),'metadata','--format-version=1','--offline','--manifest-path',str(fixture/'Cargo.toml')],seconds=120)
def registry(path): return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
actual=registry(fixture/'Cargo.lock'); allowed=registry(root/'Cargo.lock')|registry(root/'research/continuity-identity-candidate/Cargo.lock')
sdk.require(actual<=allowed,'observer dependency drift: '+repr(actual-allowed))
files={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()}
clone=stage/'source'
hook=stage/'observer-hook'
source_patch=subprocess.check_output(['git','-C',str(clone),'diff'])
sdk.require(source_patch==(stage/'SOURCE_PATCH.diff').read_bytes(),'isolated source patch changed')
sdk.require(subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip()==head,'isolated source head differs')
hook_files={str(p.relative_to(hook)):sdk.snapshot(p).sha256 for p in hook.rglob('*') if p.is_file()}

sdk.write_json(stage/'BUILD_STARTED_04.json',{'pid':os.getpid(),'source_commit':head,'fixture_files':files,'hook_files':hook_files,'source_patch_sha256':sdk.snapshot(stage/'SOURCE_PATCH.diff').sha256,'source_unchanged':True})
raw=run.command('compile',[str(tools/'bin/cargo'),'test','--locked','--offline','--release','--no-run','--test','secret_growth',
    '--message-format=json','--manifest-path',str(fixture/'Cargo.toml')],seconds=900)
rows=[json.loads(line) for line in raw.splitlines()]
binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='secret_growth']
sdk.require(len(binaries)==1,'observer executable ambiguous')
sdk.require(files=={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()},'observer inputs changed')
sdk.require(source_patch==subprocess.check_output(['git','-C',str(clone),'diff']),'isolated source changed during build')
sdk.require(hook_files=={str(p.relative_to(hook)):sdk.snapshot(p).sha256 for p in hook.rglob('*') if p.is_file()},'allocator hook changed during build')
sdk.require(not run.command('final-clean',['git','status','--porcelain'],seconds=30),'product source changed')
sdk.require(run.command('final-head',['git','rev-parse','HEAD'],seconds=30).decode().strip()==head,'product head changed')
sdk.write_json(stage/'BUILD_OBSERVED_04.json',{'completed':True,'source_commit':head,'fixture_files':files,'hook_files':hook_files,'source_patch_sha256':sdk.snapshot(stage/'SOURCE_PATCH.diff').sha256,'binary':binaries[0],
    'binary_sha256':sdk.snapshot(Path(binaries[0]),maximum=256*1024**2).sha256,'tests_executed':False,
    'profile':'release opt-level=3 thin-LTO codegen-units=1 overflow-checks=true','release_claim_eligible':False})
print('Isolated growth observer built; expected-failure runtime remains pending.',flush=True)
