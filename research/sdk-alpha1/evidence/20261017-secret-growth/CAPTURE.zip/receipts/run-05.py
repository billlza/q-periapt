"""Check the isolated exact-capacity prototype under the same moving allocator."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
build = json.loads((stage / 'BUILD_OBSERVED_04.json').read_text())
binary = Path(build['binary'])
sdk.require(build['completed'] and sdk.snapshot(binary, maximum=256*1024**2).sha256 == build['binary_sha256'], 'observer executable differs')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain']), 'main source dirty')
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == build['source_commit'], 'source head changed')
sdk.require(sdk.snapshot(stage / 'SOURCE_PATCH.diff').sha256 == build['source_patch_sha256'], 'recorded patch differs')
sdk.require(subprocess.check_output(['git', '-C', str(stage/'source'), 'diff']) == (stage/'SOURCE_PATCH.diff').read_bytes(), 'isolated source patch differs')
for name, digest in build['fixture_files'].items():
    sdk.require(sdk.snapshot(stage/'fixture'/name).sha256 == digest, 'fixture changed')
for name, digest in build['hook_files'].items():
    sdk.require(sdk.snapshot(stage/'observer-hook'/name).sha256 == digest, 'allocator changed')
out = stage / 'candidate-state-encoding'
out.mkdir(mode=0o700)
env = {k:v for k,v in os.environ.items() if not k.startswith(('DYLD_', 'LD_', 'QPERIAPT_PUBLIC_SERVICE_', 'QPC_GROWTH_'))}
env.update(QPC_GROWTH_OUTPUT=str(out/'RESULT.json'), QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'runtime'), RUST_BACKTRACE='0')
argv = [str(binary), '--exact', 'observe_state_growth', '--nocapture', '--test-threads=1']
record = {'completed_observation':False, 'source_commit':build['source_commit'], 'binary_sha256':build['binary_sha256'],
          'argv':argv, 'maximum_seconds':180, 'expected_test_exit':0, 'release_claim_eligible':False}
started = time.monotonic()
try:
    result = subprocess.run(argv, env=env, capture_output=True, timeout=180, check=False)
    (out/'runtime.stdout').write_bytes(result.stdout)
    (out/'runtime.stderr').write_bytes(result.stderr)
    record['returncode'] = result.returncode
    sdk.require(result.returncode == 0 and b'test result: ok. 1 passed; 0 failed;' in result.stdout, 'native zeroization assertion failed')
    sdk.require(not result.stderr, 'unexpected native diagnostic')
    raw = (out/'RESULT.json').read_bytes()
    value = json.loads(raw)
    sdk.require(value['workload_completed'] and value['controls_passed'] and value['server']['closed'], 'workload or controls incomplete')
    sdk.require(value['watched_state_buffers'] > 0 and value['moving_reallocations'] == 0, 'empty observer')
    sdk.require(value['nonzero_secret_ranges_at_reallocation_free'] == 0, 'state encoding still released a secret through reallocation')
    sdk.require(value['nonzero_secret_ranges_at_final_free'] == value['live_watches'] == 0, 'unexpected final-drop or live-owner problem')
    sdk.require(value['zeroed_secret_ranges_at_final_free'] == value['watched_state_buffers'], 'final allocation census incomplete')
    effects = list((out/'runtime/responder/measured-effects').iterdir())
    sdk.require(len(effects) == 1 and effects[0].is_file() and not effects[0].is_symlink(), 'business file census differs')
    expected = bytes(value['session']) + bytes(value['message']) + b'controlled state growth observation'
    sdk.require(effects[0].name == bytes(value['message']).hex() and effects[0].read_bytes() == expected, 'business bytes differ')
    sdk.require(subprocess.check_output(['git', '-C', str(stage/'source'), 'diff']) == (stage/'SOURCE_PATCH.diff').read_bytes(), 'isolated source changed')
    sdk.require(not subprocess.check_output(['git', 'status', '--porcelain']), 'main source changed')
    record.update(completed_observation=True, observed_defect=False, native_assertion_passed=True,
                  result_sha256=hashlib.sha256(raw).hexdigest(), business_effects_checked=1)
except BaseException as error:
    record['failure'] = repr(error)
    raise
finally:
    record['elapsed_seconds'] = time.monotonic() - started
    sdk.write_json(out/'RUN.json', record)
print(json.dumps({'completed_observation':True, 'native_exit':result.returncode,
                  'watched_states':value['watched_state_buffers'],
                  'nonzero_reallocation_frees':value['nonzero_secret_ranges_at_reallocation_free'],
                  'zeroed_final_frees':value['zeroed_secret_ranges_at_final_free']}))
