from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path.cwd()
CONTROL = ROOT.parent
TOOLS = CONTROL.parents[1] / 'target/continuity-browser-tools'
NODE = TOOLS / 'node-v26.10.0-darwin-arm64/bin/node'
CLI = TOOLS / 'packages/node_modules/@playwright/cli/playwright-cli.js'
CHROME = TOOLS / 'chrome-156/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
PROVIDER = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
OPENSSL = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed')
RECEIPT = ROOT / 'target/sdk-wasm-current-llvm-ar/INSTALLED_CONSUMER.json'
OUT = ROOT / 'target/browser-current'
OUT.mkdir()
env = {k: v for k, v in os.environ.items()
       if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))
       and k not in ('NODE_OPTIONS', 'NODE_PATH', 'NPM_TOKEN', 'NODE_AUTH_TOKEN')
       and not k.lower().startswith('npm_config_')}
env.update(QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3',
    PATH=str(NODE.parent) + ':/Users/bhmq03@durham.ac.uk/.cargo/bin:' + env.get('PATH', os.defpath),
    CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
    CARGO_BUILD_JOBS='2', CI='true', PLAYWRIGHT_MCP_EXECUTABLE_PATH=str(CHROME),
    OPENSSL_DIR=str(OPENSSL), OPENSSL_STATIC='0')

def identity(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}

before = identity(OPENSSL)
assert before and CHROME.is_file() and PROVIDER.is_dir()
state = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'receipt_sha256': hashlib.sha256(RECEIPT.read_bytes()).hexdigest(),
    'openssl_root': str(OPENSSL), 'openssl_inputs_before': before,
    'browser_executable': str(CHROME), 'browser_executable_sha256': hashlib.sha256(CHROME.read_bytes()).hexdigest(),
    'commands': [], 'scope': 'Original current-source browser gates, installed current WASM archive, same-host source-built native reference peers; no outer supervisor deadline and no altered component limits.'}
(OUT / 'REQUEST.json').write_text(json.dumps(state, indent=2) + '\n')
python = ['sh', 'artifact/python-run.sh']
shared = ['--receipt', str(RECEIPT), '--node', str(NODE), '--cli', str(CLI)]
commands = [
    ('storage', [*python, 'artifact/wasm_browser_storage.py', *shared, '--output', str(OUT / 'storage')]),
    ('creation', [*python, 'artifact/continuity_browser_creation.py', *shared, '--output', str(OUT / 'creation')]),
    ('local-session', [*python, 'artifact/continuity_browser_session.py', *shared,
        '--output', str(OUT / 'local-session'), '--native-target', str(OUT / 'native-build'),
        '--provider-root', str(PROVIDER)]),
    ('required-witness', [*python, 'artifact/continuity_browser_session.py', *shared,
        '--output', str(OUT / 'required-witness'), '--native-target', str(OUT / 'native-build'),
        '--provider-root', str(PROVIDER), '--native-profile', 'release', '--required-witness']),
]
try:
    for label, argv in commands:
        started = time.monotonic()
        entry = {'label': label, 'argv': argv, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        (OUT / (label + '-request.json')).write_text(json.dumps(entry, indent=2) + '\n')
        with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr)
        entry.update(returncode=process.returncode, seconds=time.monotonic() - started,
            completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        state['commands'].append(entry)
        (OUT / (label + '-result.json')).write_text(json.dumps(entry, indent=2) + '\n')
        print(json.dumps({'label': label, 'returncode': process.returncode, 'seconds': entry['seconds']}), flush=True)
        if process.returncode:
            raise SystemExit(process.returncode)
    state['all_commands_returned_zero'] = True
finally:
    state['openssl_inputs_unchanged'] = identity(OPENSSL) == before
    state['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'RESULT.json').write_text(json.dumps(state, indent=2) + '\n')
    assert state['openssl_inputs_unchanged']
