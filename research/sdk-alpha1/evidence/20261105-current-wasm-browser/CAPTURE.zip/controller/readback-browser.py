from pathlib import Path
import datetime
import json
import re
import sys

import continuity_browser_creation as creation
import continuity_browser_session as session
import continuity_browser_session_records as records
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
root = creation.ROOT
control = root.parent
base = root / 'target/browser-current-02'
receipt = root / 'target/sdk-wasm-current-llvm-ar/INSTALLED_CONSUMER.json'
installed, binding = creation.installed_binding(receipt)
controller = json.loads((base / 'RESULT.json').read_text())
assert controller['all_commands_returned_zero'] and controller['openssl_inputs_unchanged']
assert controller['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert len(controller['commands']) == 3 and all(row['returncode'] == 0 for row in controller['commands'])
public = base / 'creation/public'
enrollment = json.loads((public / 'BROWSER_ENROLLMENT.json').read_text())
assert enrollment['completed'] and enrollment['release_claim_eligible'] is False
assert enrollment['source'] == creation.source_identity()
assert enrollment['installed_sdk'] == binding
assert enrollment['served_files'] == creation.web_identity(base / 'creation/web')
values = creation.cli_result((public / 'logs/browser-run.stdout').read_bytes())
assert values == enrollment['browser']
for phase, value in values.items():
    assert value == json.loads((public / phase / 'RESULT.json').read_text())
rows = []
for index, request in enumerate(creation.request_files(values['creation'], public / 'creation')):
    grant = public / 'native' / (request.stem + '.grant')
    data = (public / f'logs/verify-{index:02}.stdout').read_bytes()
    match = re.fullmatch(rb'request_sha256=([0-9a-f]{64}) signing_identity=([0-9a-f]{64}) '
                         rb'public_key_sha256=([0-9a-f]{64}) credential_sha256=([0-9a-f]{64})\n', data)
    assert match
    row = dict(zip(('request_sha256', 'signing_identity', 'public_key_sha256', 'credential_sha256'),
                   (part.decode() for part in match.groups())))
    assert row['request_sha256'] == sdk.snapshot(request).sha256
    assert row['credential_sha256'] == sdk.snapshot(grant).sha256
    assert json.loads((public / f'logs/verify-{index:02}.json').read_text())['returncode'] == 0
    rows.append(dict(request=request.name, **row))
assert rows == enrollment['native_verified'] and len(rows) == 19
assert len({r['signing_identity'] for r in rows}) == 7
assert len({r['public_key_sha256'] for r in rows}) == 7
binary = base / 'creation/build/debug/examples/browser_owned_enrollment'
assert sdk.snapshot(binary, maximum=256 * 1024**2).sha256 == enrollment['native_binary_sha256']
summaries = {}
source = session.source_identity()
for label, schema, profile in [('local-session', 5, 'debug'), ('required-witness', 6, 'release')]:
    public = base / label / 'public'
    value = json.loads((public / 'RESULT.json').read_text())
    assert value['schema_version'] == schema and value['completed']
    assert value['native_build_profile'] == profile
    assert value['source'] == source and value['installed_sdk'] == binding
    records.verify(value, public)
    for row in value['commands']:
        assert row['exit'] == row['expected_exit']
        for stream in ('stdout', 'stderr'):
            assert sdk.snapshot(public / 'logs' / (row['label'] + '.' + stream)).sha256 == row[stream + '_sha256']
    for name, expected in value['native_binary_sha256'].items():
        binary = base / 'native-build' / profile / name
        assert sdk.snapshot(binary, maximum=256 * 1024**2).sha256 == expected
    assert not value['relay_failures'] and not value.get('cleanup_failures')
    assert value['private_state_not_archived']
    summaries[label] = {'schema_version': schema, 'native_profile': profile,
        'report_sha256': sdk.snapshot(public / 'RESULT.json').sha256,
        'original_public_reader_passed': True, 'native_binaries_rechecked': len(value['native_binary_sha256']),
        'commands': len(value['commands']), 'peer_frames': len(value['frames']),
        'witness_frames': len(value.get('required_witness', {}).get('frames', [])),
        'provider': value['provider'], 'provider_openssl': value['provider_openssl'],
        'scope': value['scope']}
result = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': controller['source_commit'], 'installed_binding': binding,
    'enrollment': {'report_sha256': sdk.snapshot(base / 'creation/public/BROWSER_ENROLLMENT.json').sha256,
        'original_cli_reader_passed': True, 'native_verification_receipts': len(rows),
        'distinct_signing_identities': 7, 'native_binary_rechecked': True,
        'source_files': len(enrollment['source']['files'])},
    'sessions': summaries, 'session_source_files': len(source['files']),
    'scope': 'Independent byte and public-reader reread of original browser runs. Actual native binaries rechecked locally; capture inventory separately identifies exported bytes. No native or browser workload rerun and no independent protocol implementation claim.'}
with (control / 'BROWSER_READBACK.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'enrollment_receipts': len(rows), 'sessions': summaries}))
