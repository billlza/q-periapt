from pathlib import Path
import datetime
import hashlib
import json
import re
import sys

import wasm_sdk_package as package
import wasm_browser_storage as browser
from deterministic_archive import extract_tar_gz

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
root = package.ROOT
control = root.parent
producer = root / 'target/sdk-wasm-current-llvm-ar'
minimum = root / 'target/sdk-wasm-current-node24'
output = root / 'target/current-wasm-readback'
output.mkdir()
receipt = json.loads((producer / 'INSTALLED_CONSUMER.json').read_text())
archive = Path(receipt['archive'])
assert package.snapshot(archive).sha256 == receipt['sha256']
assert receipt['sha256'] == 'dea7351bd916d8bfc3c8e1bf3c2b0f8772864ddf48d175e1c8bea7d0af82970a'
assert receipt['manifest_sha256'] == '03e799c3429606d6918b66c678bb6f092befd955e261181b7e87972a07b6fd47'
extract_tar_gz(archive, output / 'archive', root_name='package', mtime=package.MTIME,
               expected_sha256=receipt['sha256'])
manifest = package.verify(output / 'archive/package', receipt['manifest_sha256'])
package.validate_consumer_source(manifest)
assert manifest['sources'] == package.sources()
assert manifest['sources'] == json.loads((producer / 'sources-before.json').read_text())
assert manifest['sources'] == json.loads((producer / 'sources-after.json').read_text())
payload = package.entries(output / 'archive/package')
runtimes = {}
commands = {}
for folder, version in ((producer, 'v26.10.0'), (minimum, 'v24.0.0')):
    value = json.loads((folder / 'INSTALLED_CONSUMER.json').read_text())
    assert (value['sha256'], value['manifest_sha256']) == (receipt['sha256'], receipt['manifest_sha256'])
    assert value['runtime']['version'] == version and value['source_bound'] and value['sources_unchanged']
    assert value['release_claim_eligible'] is False and value['browser_runtime'] == 'not-run'
    assert value['installed_node_tests'] == 'passed' and value['typescript'] == '7.0.2 strict NodeNext passed'
    if version == 'v24.0.0':
        assert value['expected_node_version'] == version
    installed = Path(value['installed'])
    assert installed.is_absolute() and not installed.is_relative_to(root)
    assert package.verify(installed, value['manifest_sha256']) == manifest
    assert package.entries(installed) == payload
    for name, digest in value['consumer_inputs'].items():
        assert package.snapshot(installed.parent.parent / name).sha256 == digest
        assert package.snapshot(package.CRATE / 'tests' / name).sha256 == digest
    observed_tools = package.runtime_inputs(Path(value['runtime_inputs']['node']['path']),
                                           Path(value['runtime_inputs']['npm_cli']['path']))
    assert observed_tools == value['runtime_inputs']
    for label, marker in [('consumer-product', 'WASM_PRODUCT_LIFECYCLE_POLICY_ROUNDTRIP_FAILURE_PASS'),
                          ('consumer-installed', 'WASM_INSTALLED_CJS_ESM_SINGLE_INSTANCE_PASS')]:
        assert (folder / (label + '.stdout')).read_text().strip() == marker
    for path in sorted(folder.glob('*.json')):
        row = json.loads(path.read_text())
        if 'argv' in row:
            assert row['returncode'] == 0, path
            commands[version + '/' + path.name] = package.snapshot(path).sha256
    runtimes[version] = {'receipt_sha256': package.snapshot(folder / 'INSTALLED_CONSUMER.json').sha256,
        'installed': str(installed), 'actual_payload_files': len(payload),
        'runtime_inputs_verified': True, 'consumer_inputs_verified': len(value['consumer_inputs']),
        'node_tests': 'both original consumer markers and zero exit receipts',
        'typescript': value['typescript']}
checks = root / 'target/wasm-current-checks'
for label, count in [('lean-node', 10), ('signed-policy-node', 11)]:
    assert json.loads((checks / (label + '.json')).read_text())['returncode'] == 0
    text = (checks / (label + '.stdout')).read_text()
    assert f'test result: ok. {count} passed; 0 failed; 0 ignored; 0 filtered out;' in text
    assert len(re.findall(r'^test .+ \.\.\. ok$', text, re.M)) == count
for label in ['candidate-wasm', 'fetch-node26', 'fetch-node24']:
    assert json.loads((checks / (label + '.json')).read_text())['returncode'] == 0
    if label.startswith('fetch-'):
        text = (checks / (label + '.stdout')).read_text()
        for field, count in [('tests', 7), ('pass', 7), ('fail', 0), ('cancelled', 0), ('skipped', 0), ('todo', 0)]:
            assert re.search(rf'^ℹ {field} {count}$', text, re.M)
storage = root / 'target/browser-current/storage'
storage_report = json.loads((storage / 'BROWSER_STORAGE.json').read_text())
assert storage_report['completed'] and storage_report['release_claim_eligible'] is False
assert (storage_report['archive_sha256'], storage_report['manifest_sha256']) == (receipt['sha256'], receipt['manifest_sha256'])
for label, marker in [('browser-acceptance.js', 'WASM_INSTALLED_BROWSER_PASS'),
                      ('storage-quota-acceptance.js', 'BROWSER_POLICY_QUOTA_PASS'),
                      ('storage-acceptance.js', 'BROWSER_POLICY_STORAGE_PASS'),
                      ('storage-deadline-acceptance.js', 'BROWSER_POLICY_DEADLINE_PASS')]:
    observed = browser.result((storage / (label + '.stdout')).read_bytes(), marker)
    assert observed == storage_report[label]
    assert json.loads((storage / (label + '.json')).read_text())['returncode'] == 0
assert storage_report['driver_sha256'] == package.snapshot(root / 'artifact/wasm_browser_storage.py').sha256
result = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8',
    'archive': {'bytes': archive.stat().st_size, 'sha256': receipt['sha256']},
    'manifest_sha256': receipt['manifest_sha256'],
    'sdk_root': manifest['sources']['rust_workspace_sha256'],
    'direct_source_inputs': len(manifest['sources']['inputs']),
    'payload_files': len(payload), 'license_packages': receipt['license_packages'],
    'runtimes': runtimes, 'successful_command_receipts': commands,
    'lean_node_tests': 10, 'signed_policy_node_tests': 11,
    'candidate_wasm_check': 'passed', 'fetch_tests_per_node_runtime': 7,
    'storage_public_readback': 'all four original readers matched',
    'storage_receipt_sha256': package.snapshot(storage / 'BROWSER_STORAGE.json').sha256,
    'scope': 'Independent byte/readback verification; no workload rerun, registry publication, additional browser engines, foreign devices, or overall release acceptance.'}
with (control / 'WASM_READBACK.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({k: result[k] for k in ('archive', 'sdk_root', 'direct_source_inputs', 'payload_files', 'license_packages')}))
