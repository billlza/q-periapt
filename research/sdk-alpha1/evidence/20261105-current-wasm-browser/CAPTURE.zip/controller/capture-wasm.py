from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

import wasm_sdk_package as package

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = package.ROOT
control = source.parent
repo = control.parents[1]
tools = repo / 'target/continuity-browser-tools'
producer = source / 'target/sdk-wasm-current-llvm-ar'
minimum = source / 'target/sdk-wasm-current-node24'
browser = source / 'target/browser-current-02'
dest = repo / 'research/sdk-alpha1/evidence/20261105-current-wasm-browser'
dest.mkdir()
wasm = json.loads((control / 'WASM_READBACK.json').read_text())
readback = json.loads((control / 'BROWSER_READBACK.json').read_text())
assert wasm['source_commit'] == readback['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
files = {}

def add_tree(prefix, root):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            name = prefix + '/' + path.relative_to(root).as_posix()
            assert name not in files
            files[name] = path

def add_records(prefix, root):
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr', '.tgz'):
            files[prefix + '/' + path.name] = path

for prefix, folder in [('producer', producer), ('node24', minimum),
                       ('checks', source / 'target/wasm-current-checks'),
                       ('storage', source / 'target/browser-current/storage'),
                       ('first-browser-controller', source / 'target/browser-current'),
                       ('browser-controller', browser),
                       ('failed-bsd-build', source / 'target/sdk-wasm-current')]:
    add_records(prefix, folder)
for label in ('creation', 'local-session', 'required-witness'):
    add_tree('browser/' + label + '/public', browser / label / 'public')
add_tree('first-browser-creation/public', source / 'target/browser-current/creation/public')
add_tree('archiver-diagnostic', control / 'wasm-archiver-diagnostic')
failed_build = source / 'target/sdk-wasm-current/cargo-target/wasm32-unknown-unknown/release/build/q-periapt-mlkem-native-sys-5d627bfa21416f11'
for leaf in ('output', 'stderr', 'out/ea708c7824d36062-mlkem_bridge_portable.o', 'out/libq_periapt_mlkem_native.a'):
    files['failed-bsd-build/native/' + leaf] = failed_build / leaf
for name in ('WASM_REQUEST.json', 'WASM_RESULT.json', 'WASM_REQUEST_02.json', 'WASM_RESULT_02.json',
             'wasm.stdout', 'wasm.stderr', 'wasm-02.stdout', 'wasm-02.stderr',
             'NODE24_REQUEST.json', 'NODE24_RESULT.json', 'node24.stdout', 'node24.stderr',
             'WASM_ARCHIVER_DIAGNOSTIC.json', 'WASM_TOOL_WARNINGS.json', 'WASM_TOOLS_READBACK.json', 'SOURCE_IMPACT.json',
             'WASM_READBACK.json', 'BROWSER_READBACK.json', 'wasm-readback.stdout', 'wasm-readback.stderr',
             'browser-readback.stdout', 'browser-readback.stderr',
             'browser-controller.stdout', 'browser-controller.stderr',
             'browser-controller-02.stdout', 'browser-controller-02.stderr'):
    files['controller/' + name] = control / name
for name in ('browser-current.py', 'browser-current-02.py', 'readback-wasm.py', 'readback-browser.py', 'capture-wasm.py'):
    files['controller/' + name] = Path(__file__).with_name(name)
for name in ('NODE_DOWNLOAD.json', 'NPM_INSTALL.json', 'TYPESCRIPT_CACHE.json', 'NODE24_DOWNLOAD.json', 'node24-SHASUMS256.txt'):
    files['tools/' + name] = tools / name
for name in ('INSTALL_REQUEST.json', 'INSTALL_READBACK.json', 'install.stdout', 'install.stderr',
             'BINDGEN_REQUEST.json', 'BINDGEN_RESULT.json', 'bindgen-install.stdout', 'bindgen-install.stderr',
             'build-bindgen/.future-incompat-report.json', 'binaryen/DOWNLOAD.json',
             'binaryen/binaryen-version_117-arm64-macos.tar.gz.sha256'):
    files['tools/wasm-local/' + name] = tools / 'wasm-local' / name
binary_paths = [browser / 'creation/build/debug/examples/browser_owned_enrollment']
for label in ('local-session', 'required-witness'):
    row = json.loads((browser / label / 'public/RESULT.json').read_text())
    binary_paths.extend(browser / 'native-build' / row['native_build_profile'] / name
                        for name in row['native_binary_sha256'])
assert len(binary_paths) == len(set(binary_paths)) == 8
for path in binary_paths:
    files['native-binaries/' + path.relative_to(browser).as_posix()] = path
names = set(package.sources()['inputs'])
for path in (browser / 'creation/public/BROWSER_ENROLLMENT.json', browser / 'local-session/public/RESULT.json'):
    names.update(json.loads(path.read_text())['source']['files'])
names.update(('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.github/workflows/ci.yml',
              'artifact/python-run.sh', 'artifact/python-env.sh', 'artifact/python_bootstrap.py',
              'artifact/wasm_browser_storage.py', 'artifact/test_witness_fetch.mjs'))
names.update(p.relative_to(source).as_posix() for p in (source / 'crates/q-periapt-sdk-wasm').rglob('*') if p.is_file())
for module in tuple(sys.modules.values()):
    filename = getattr(module, '__file__', None)
    if filename:
        path = Path(filename).resolve()
        if path.is_relative_to(source / 'artifact') and path.suffix == '.py':
            names.add(path.relative_to(source).as_posix())
for name in sorted(names):
    path = source / name
    assert path.read_bytes() == subprocess.check_output(['git', 'show', wasm['source_commit'] + ':' + name], cwd=source)
    files['source/' + name] = path
manifest = {}
with zipfile.ZipFile(dest / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.writestr(name, data)
with zipfile.ZipFile(dest / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    assert archive.testzip() is None
    for name, row in manifest.items():
        data = archive.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
for name, value in [('FILES.json', manifest), ('WASM_READBACK.json', wasm), ('BROWSER_READBACK.json', readback)]:
    with (dest / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
data = (dest / 'CAPTURE.zip').read_bytes()
summary = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'members': len(manifest),
    'source_commit': wasm['source_commit'], 'source_files': len(names),
    'wasm_archive_sha256': wasm['archive']['sha256'], 'wasm_manifest_sha256': wasm['manifest_sha256'],
    'native_binaries': len(binary_paths), 'native_binary_bytes': sum(p.stat().st_size for p in binary_paths),
    'scope': 'Actual installed current WASM package, both Node consumers, Chromium public storage/enrollment/session/Witness evidence, eight actual same-host reference executables, failed preparations, source and tool receipts. No private runtime state, registry publication or overall release qualification.'}
with (dest / 'CAPTURE.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary))
