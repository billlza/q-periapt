"""Verify public witness records of the final reentrant no-output control."""
from pathlib import Path
import hashlib,json,sys,re
root=Path.cwd();peer=Path(__file__).resolve().parent/'source';out=root/'target/independent-local-renewal-hosted-061-mac-01/public';folder=out/'peer-reply-release'
sys.path.append(str(peer))
LANES = {'owner': 'durable-rekey', 'storage': 'storage-cuts', 'base': 'session-recovery', 'maximum': 'resolution-capacity', 'disclosure': 'resolution-disclosure', 'capacity': 'capacity', 'control': 'control', 'resolution': 'resolution', 'rekey': 'rekey', 'exchange': 'exchange', 'witness': 'witness', 'peer-lifecycle': 'peer-lifecycle', 'peer-reply-release': 'peer-reply-release'}
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load,load_witness_pin
from peer.witness import Operation,commitment,verify
from peer.identity import roster

def read(p):return parse_strict_json_bytes(p.read_bytes(),label=str(p))
def check(v,why):
 if not v:raise ValueError(why)
def sha(data):return hashlib.sha256(data).hexdigest()
check(not (out/'peer-reply-release.stderr').read_bytes() and not (folder/'native/native.stderr').read_bytes(),'runtime diagnostics')
outcome=read(folder/'OUTCOME.json');check(outcome=={'released':False,'error':'peer authority changed during output admission','revoked':True},'withheld output observation')
commands=read(folder/'NATIVE.json');attempts=read(folder/'ATTEMPTS.json');check(len(commands)==54 and len(attempts)==50,'direct callback workload')
public=folder/'native/public';pin=load_witness_pin(public);_,_,ctx=load(public,150,witness_pin=pin)
native={}
for row in commands:
 name=row['case'];check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name),'case name')
 before=(folder/'native/cases'/(name+'.input')).read_bytes();after=(folder/'native/cases'/(name+'.output')).read_bytes()
 check(sha(before)==row['input_sha256'] and sha(after[1:])==row['output_sha256'] and after[0]==row['status'],'native record')
 check(name not in native,'duplicate case');native[name]=(before,after)
subject=native['trusted-enrollment'][0][:96]
check(subject[32:]==ctx.witness.owner+ctx.witness.policy,'original witness enrollment')
challenges=set();advanced=[]
for row in attempts:
 name=row['case'];wire=(folder/(name+'.request')).read_bytes();reply=(folder/(name+'.reply')).read_bytes()
 check(sha(wire)==row['request_sha256'] and sha(reply)==row['signed_reply_sha256'] and sha(reply)==row['transport_reply_sha256'],'witness hashes')
 check(native[name]==(wire,b'\1'+reply) and row['fault'] is None and row['delivery']=='sent','real unmodified witness result')
 body=ctx.initiator.open(wire,7,297);op=Operation(body[200],body[201:])
 check(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==commitment(b'COMMAND',pin.binding+subject+op.wire()),'request scope')
 check(body[168:200] not in challenges and body[168:200].hex()==row['challenge'],'fresh challenge');challenges.add(body[168:200])
 result=verify(pin,subject,op,body,reply)
 if result.outcome==2:advanced.append(result.head.revision)
# Final confirmation, activation, send reservation, send commit, then revocation.
check(advanced==[2,3,4,5,6],'actual committed local transitions')
target=(public/'pin-peer-revoked-target').read_bytes();revoked=roster(ctx.devices[1].pin,(public/'peer-revoked-roster').read_bytes(),expected=target)
check(not revoked.members,'root-signed empty roster')
summary={'native_commands':54,'witness_attempts':50,'signed_replies_verified':50,'unique_challenges':len(challenges),'observed_advance_revisions':advanced,'outcome':outcome,
 'scope':'Public signed/native bytes verify actual unchanged witness replies and monotonic advances. Reentrant host-call ordering and no returned ciphertext remain runtime assertions in the preserved executable scenario. This is not an arbitrary concurrent revocation lease.'}
(out.parent/'REPLY_RELEASE_READBACK.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
