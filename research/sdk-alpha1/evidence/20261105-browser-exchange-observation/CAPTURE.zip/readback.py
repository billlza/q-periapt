from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-browser-exchange-diagnostic'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-browser-exchange-observation'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda v: (json.dumps(v, indent=2, sort_keys=True) + '\n').encode()
payload = (BASE / 'artifact-13407418993.zip').read_bytes()
assert len(payload) == 3659134 and sha(payload) == '456935ecff7887382134de44e52b9f20e5097a6a4102d8f73b502fc46a50782e'
with zipfile.ZipFile(io.BytesIO(payload)) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 548 and z.testzip() is None
    local = json.loads(z.read('browser-native-session/public/RESULT.json'))
    report = json.loads(z.read('browser-required-witness/public/RESULT.json'))
    phase = json.loads(z.read('browser-required-witness/public/activate.json'))
    assert local['completed'] is True and len(local['frames']) == 8
    assert report['completed'] is False and len(report['frames']) == 6
    assert report['failure']['type'] == 'ValueError' and report['failure']['message'].startswith('expected lost response not observed')
    assert report['relay_failures'] == [] and 'cleanup_failures' not in report
    assert phase['http_errors'] == [] and phase['diagnostics'] == []
    assert phase['result']['failure']['code'] == 'PeerTransport'
    assert phase['result']['failure']['ownerClosed'] is True and phase['result']['failure']['closed'] is True
    assert len(phase['requests']) == len(phase['request_diagnostics']) == 3
    bound = []
    for request, detail in zip(phase['requests'], phase['request_diagnostics'], strict=True):
        assert request == {'url': detail['url'], 'failure': detail['failure']}
        body = bytes.fromhex(detail['body_hex'])
        matches = [row for row in report['frames'] if row['request_sha256'] == sha(body)]
        assert len(matches) == 1
        frame = matches[0]
        root = 'browser-required-witness/public/'
        assert z.read(root + f"{frame['sequence']:03}.request") == body
        response = z.read(root + f"{frame['sequence']:03}.response")
        assert sha(response) == frame['response_sha256']
        assert body[:8] == response[:8] == b'QPCXCH01' and body[8] == frame['kind'] and response[8] == frame['kind'] + 128
        bound.append({'url': detail['url'], 'failure': detail['failure'], 'http_response_status': detail['response_status'],
            'request_bytes': len(body), 'response_bytes_at_relay': len(response), 'sequence': frame['sequence'],
            'kind': frame['kind'], 'withheld': frame['withheld'], 'request_sha256': sha(body),
            'relay_response_sha256': sha(response), 'timing': detail['timing']})
    assert [row['sequence'] for row in bound] == [3, 5, 6]
    assert all(row['failure'] == {'errorText': 'net::ERR_ABORTED'} and row['http_response_status'] == 200
               and row['withheld'] is False for row in bound[:2])
    assert bound[2]['failure'] == {'errorText': 'net::ERR_EMPTY_RESPONSE'} and bound[2]['withheld'] is True
    assert len(phase['transport_receipts']) == 89
    assert all(row['url'] == report['browser_origin'] + '/witness' and row['result'] == 'fulfilled' for row in phase['transport_receipts'])
files = {'artifact-13407418993.zip': payload, 'job-127182901124.log': (BASE / 'job-127182901124.log').read_bytes(),
         'MEMBERS.json': (BASE / 'MEMBERS.json').read_bytes(), 'readback.py': Path(__file__).read_bytes()}
source_names = ['artifact/continuity_browser_session.py', 'artifact/continuity_browser_session_records.py',
    'artifact/test_continuity_browser_transport.py', 'artifact/test_continuity_browser_phase.py',
    'research/continuity-reference-app/tests/browser_session/transport-receipts.js',
    'research/continuity-reference-app/tests/browser_session/run.js',
    'research/continuity-reference-app/tests/browser_session/worker.js',
    'research/continuity-identity-candidate/src/browser/bounded-fetch.js']
for name in source_names:
    data = (ROOT / name).read_bytes()
    assert data == subprocess.check_output(['git', 'show', 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20:' + name])
    files['source/' + name] = data
observer = files['source/research/continuity-reference-app/tests/browser_session/transport-receipts.js'].decode()
assert 'if (profile === 1) attempts.set' in observer
transport = files['source/research/continuity-identity-candidate/src/browser/bounded-fetch.js'].decode()
success = transport.split('return { bytes: bytes.subarray(0, offset) };', 1)[1]
assert 'this.#controller.abort();' in success.split('finally {', 1)[0]
assert 'this.#controller.abort();' not in success.split('finally {', 1)[1]
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'readback_completed': True,
    'hosted_run': 42008993679, 'hosted_job': 127182901124, 'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
    'artifact_id': 13407418993, 'artifact_bytes': len(payload), 'artifact_sha256': sha(payload), 'artifact_members': 548,
    'local_policy_session_report_completed': True, 'required_witness_session_report_completed': False,
    'failed_phase': 'activate', 'browser': phase['browser'], 'correlated_observer_events': bound,
    'ordinary_exchange_client_receipts_present': False, 'fulfilled_witness_receipts': 89,
    'http_errors': [], 'console_or_page_diagnostics': [], 'relay_failures': [],
    'root_cause_confirmed': False, 'product_or_verifier_modified': False,
    'analysis': 'Two ERR_ABORTED observer events identify real ordinary exchanges with HTTP 200 and retained relay responses. Existing client telemetry records only Witness profile 1, so exact ordinary Fetch fulfillment/response-byte readback is missing. HTTP status and server bytes alone do not prove complete client receipt.',
    'hypothesis': 'Ordinary exchange observer cancellation can accompany a fulfilled bounded Fetch, as previously studied for Witness. This remains a hypothesis here.',
    'disallowed_shortcut': 'Do not drop arbitrary ERR_ABORTED events or remove controller.abort from actual error handling.',
    'next_evidence': 'Capture bounded profile-2 original Promise fulfillment/rejection and exact request/response hashes without changing SDK behavior; compare with retained relay frames before admitting any observer event.',
    'release_claim_eligible': False}
files['READBACK.json'] = encode(summary)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
capsule = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(capsule)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(n) == b for n, b in files.items())
checksums = {'bytes': len(capsule), 'members': len(files), 'sha256': sha(capsule), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, data in [('CAPTURE.zip', capsule), ('READBACK.json', files['READBACK.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(checksums))]:
    with (DEST / name).open('xb') as stream:
        stream.write(data)
print(json.dumps(checksums, indent=2), flush=True)
