from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[2]
source=root/'target/policy-recovery-ffi-current/source'
out=root/'target/native-linux-current/macos-connection-01';out.mkdir()
apple=source/'target/apple-recovery-cross-os-01/q-periapt-swift-0.2.0'
report=source/'target/registry-alias-rust-package-01/RUST_SDK_PACKAGE.json'
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
def sha(p):
 with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=source,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
env={k:os.environ[k] for k in ('HOME','USER','LOGNAME','TMPDIR') if k in os.environ}
env.update(PATH=str(tc/'bin')+':/Users/bill/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
command=['sh','artifact/python-run.sh','artifact/sdk_installed_connection.py','--output',str(source/'target/cross-os-macos-baseline-01'),'--swift-zip',str(apple/'QPeriapt-Swift-SDK-0.2.0.zip'),'--swift-sha256',sha(apple/'QPeriapt-Swift-SDK-0.2.0.zip'),'--swift-native-zip',str(apple/'CQPeriapt.xcframework.zip'),'--swift-native-sha256',sha(apple/'CQPeriapt.xcframework.zip'),'--rust-report',str(report),'--rust-report-sha256',sha(report),'--cargo-home',str(report.parent/'cargo-home'),'--toolchain-root',str(tc)]
start=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:r=subprocess.run(command,cwd=source,env=env,stdout=so,stderr=se)
record={'head':head,'source':str(source),'command':command,'returncode':r.returncode,'seconds':time.monotonic()-start,'head_unchanged':git('rev-parse','HEAD')==head,'source_clean':not git('status','--porcelain'),'stdout_sha256':sha(out/'stdout.log'),'stderr_sha256':sha(out/'stderr.log')};(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print((out/'stderr.log').read_text()[-5000:],flush=True);print((out/'stdout.log').read_text()[-2500:],flush=True);assert record['head_unchanged'] and record['source_clean'];r.check_returncode()
