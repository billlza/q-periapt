#!/opt/homebrew/opt/python@3.14/bin/python3.14 -ISB
"""Transport-only adapter for the native Linux reference peer; no TLS processing."""
from pathlib import Path
import base64, hashlib, ipaddress, json, os, re, signal, socket, subprocess, sys, threading, time

BASE = Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/native-linux-current')
CONFIG = json.loads((BASE/'cross-os-config.json').read_bytes())
DOCKER = ['/Users/bill/.cargo/bin/docker', '--host', CONFIG['docker_socket']]
ENV = {k:v for k,v in os.environ.items() if not k.startswith(('DOCKER_', 'DYLD_', 'LD_', 'PYTHON'))}
ENV['DOCKER_CONFIG'] = CONFIG['docker_config']
guest = CONFIG['guest_fixtures']
container = CONFIG['container']
binary = CONFIG['linux_binary']
fixture_dir, mode, count, action = sys.argv[1:]
assert mode in ('echo','delay','hold','stall','mismatch','measure')
assert action in ('provision','open') and count.isdigit() and 1 <= int(count) <= 8
inspection = json.loads(subprocess.check_output(DOCKER+['inspect',container,'--format','{{json .}}'],env=ENV,timeout=5))
assert inspection['Id'] == CONFIG['container_id'] and inspection['State']['Running']
address = inspection['NetworkSettings']['Networks']['bridge']['IPAddress']
assert ipaddress.ip_address(address).is_private and ipaddress.ip_address(address).version == 4
files = {}
for name in ('policy.toml','policy.sig','policy.vk','server.der','server.key.der','client.der'):
    path = Path(fixture_dir)/name
    assert path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= 65536
    files[name] = base64.b64encode(path.read_bytes()).decode('ascii')
transfer = '''from pathlib import Path
import base64,hashlib,json,os,stat,sys
p=Path(sys.argv[1]);b=Path(sys.argv[2]);expected=sys.argv[3]
assert os.getuid()==1000 and p.is_dir() and not p.is_symlink()
assert p.stat().st_uid==1000 and stat.S_IMODE(p.stat().st_mode)==0o700
with b.open('rb') as stream: assert hashlib.file_digest(stream,'sha256').hexdigest()==expected
files=json.load(sys.stdin)
assert set(files)=={'policy.toml','policy.sig','policy.vk','server.der','server.key.der','client.der'}
for name,encoded in files.items():
 target=p/name;assert not target.is_symlink()
 data=base64.b64decode(encoded,validate=True);assert 0<len(data)<=65536
 with target.open('wb') as stream:stream.write(data)
 target.chmod(0o600)
'''
subprocess.run(DOCKER+['exec','-i','--user','1000:1000',container,'python3','-I','-S','-B','-c',transfer,
                     guest,binary,CONFIG['linux_binary_sha256']],input=json.dumps(files).encode(),env=ENV,check=True,timeout=10)
record = {'mode':mode,'count':int(count),'action':action,'linux_binary_sha256':CONFIG['linux_binary_sha256'],
          'guest_address':address,'fixture_hashes':{n:hashlib.sha256(base64.b64decode(v)).hexdigest() for n,v in files.items()}}
peer = subprocess.Popen(DOCKER+['exec','-i','--user','1000:1000',container,'python3','-I','-S','-B',
    '/remote-supervisor.py',binary,guest,mode,count,action,'--listen',address+':0'],
    stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=None,env=ENV)
tunnel = None
def interrupted(signum, frame):
    raise InterruptedError(f'proxy received signal {signum}')
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
try:
    assert peer.stdout is not None
    for line in peer.stdout:
        if line.startswith(b'LISTEN '):
            assert tunnel is None
            match = re.fullmatch(rb'LISTEN ([0-9.]+):([0-9]+)\n',line)
            assert match and match[1].decode()==address
            remote_port = int(match[2]);assert 1 <= remote_port <= 65535
            with socket.socket() as reservation:
                reservation.bind(('127.0.0.1',0));local_port=reservation.getsockname()[1]
            tunnel = subprocess.Popen(['/usr/bin/ssh','-F',CONFIG['ssh_config'],
                '-o','ControlMaster=no','-o','ControlPath=none','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+CONFIG['known_hosts'],
                '-o','HostKeyAlgorithms=ssh-ed25519','-o','ForwardAgent=no','-o','IdentityAgent=none',
                '-o','ExitOnForwardFailure=yes','-o','ConnectTimeout=5','-o','ServerAliveInterval=2',
                '-o','ServerAliveCountMax=2','-N','-L',f'127.0.0.1:{local_port}:{address}:{remote_port}',
                'lima-colima-arm64'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=None,env=ENV)
            deadline=time.monotonic()+5
            while True:
                assert tunnel.poll() is None,'SSH forwarding process exited before readiness'
                observed=subprocess.run(['/usr/sbin/lsof','-nP','-a','-p',str(tunnel.pid),
                    '-iTCP:'+str(local_port),'-sTCP:LISTEN','-Fn'],capture_output=True,timeout=2)
                if observed.returncode==0 and f'n127.0.0.1:{local_port}\n'.encode() in observed.stdout:break
                if observed.returncode not in (0,1):raise RuntimeError(observed.stderr.decode())
                if time.monotonic()>=deadline:raise TimeoutError('SSH listener was not observed')
                time.sleep(.02)
            record.update(local_port=local_port,remote_port=remote_port,ssh_pid=tunnel.pid)
            # Only the TCP address announcement changes. Application output and
            # all encrypted bytes are forwarded from the actual native peer.
            sys.stdout.buffer.write(f'LISTEN 127.0.0.1:{local_port}\n'.encode());sys.stdout.buffer.flush()
        else:
            sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
    status = peer.wait(timeout=10)
    record['returncode'] = status
finally:
    try:
        if peer.stdin is not None:peer.stdin.close()
        if peer.poll() is None:
            # Closing stdin tells the guest supervisor to terminate its own child.
            peer.wait(timeout=4)
    finally:
        try:
            if tunnel is not None and tunnel.poll() is None:
                tunnel.terminate()
                tunnel.wait(timeout=2)
        finally:
            path = BASE/'cross-os-transfers-03.jsonl'
            with path.open('a',encoding='utf-8') as stream:stream.write(json.dumps(record)+'\n')
raise SystemExit(status)
