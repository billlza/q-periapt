from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'artifact'))
import sdk_installed_connection as installed
from sdk_connection_interop import StaticClientLinkage,run_boundary
base=root/'target/native-linux-current'
baseline=root/'target/policy-recovery-ffi-current/source/target/cross-os-macos-baseline-01'
old=json.loads((baseline/'INSTALLED_CONNECTION.json').read_bytes());assert old['completed']
manifest=json.loads((baseline/'boundary/manifest.json').read_bytes());paths=manifest['source_paths']
source=installed.source_inputs()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
controlled={name:sha(base/name) for name in ('linux-server-proxy.py','cross-os-config.json','remote-supervisor.py','known_hosts')}
assert sha(paths['client'])==old['swift_client']['sha256']
assert sha(paths['library'])==old['swift_client']['static_library_sha256']
link=StaticClientLinkage(Path(paths['library']),old['swift_client']['static_library_sha256'],baseline/'client-link.map','arm64')
start=time.monotonic()
out=base/'cross-os-01'
result=run_boundary(out,swift=Path(paths['client']),server=base/'linux-server-proxy.py',
                    fixtures_binary=Path(paths['fixtures']),static_linkage=link)
assert result['completed'] and len(result['observations'])==12
assert installed.source_inputs()==source
assert all(sha(base/name)==digest for name,digest in controlled.items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
report={'host_driver_commit':head,'guest_source_commit':'33ca8c5cd2455c43d1d3600cf0b065353644996d',
 'crate_source_commit':'de2c49e9e572972165a05411d2a11777f06e31b2','client_platform':'native macOS arm64',
 'server_platform':'native Linux aarch64 in local VZ VM/container, unprivileged UID 1000',
 'transport':'private loopback SSH TCP forwarding to the selected Linux container address; encrypted SDK bytes unchanged',
 'independent_physical_hosts':False,'independent_protocol_implementations':False,'cases':result['observations'],
 'seconds':time.monotonic()-start,'swift_client':old['swift_client'],
 'linux_peer':json.loads((base/'linux-peer-02/RESULT.json').read_bytes())['binaries']['connection_peer'],
 'driver_inputs':controlled,'boundary_manifest_sha256':sha(out/'manifest.json'),
 'sources_unchanged':True,'release_claim_eligible':False}
(out/'CROSS_OS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
