"""Tie one native peer's lifetime to its attached Docker stdin channel."""
import os, select, subprocess, sys

peer = subprocess.Popen(sys.argv[1:], stdin=subprocess.DEVNULL)

while peer.poll() is None:
    readable, _, _ = select.select([sys.stdin.fileno()], [], [], .05)
    if readable and os.read(sys.stdin.fileno(), 1) == b'':
        if peer.poll() is None:
            peer.terminate()
            try:
                peer.wait(timeout=2)
            except subprocess.TimeoutExpired:
                peer.kill()
                peer.wait(timeout=2)
        break
raise SystemExit(peer.wait())
