from pathlib import Path
import hashlib,json,os,sys
sys.path.insert(0,'/work/source/artifact')
import rust_sdk_profile as sdk
root=Path('/work/source');report=root/'target/rust-input/RUST_SDK_PACKAGE.json';data=json.loads(report.read_bytes())
assert os.getuid()==1000
assert data['source_inputs']['rust_workspace_sha256']==sdk.source_identity()['rust_workspace_sha256']
consumer=Path('/work/connection-consumer-02');consumer.mkdir()
output=root/'target/connection-consumer-linux-02';output.mkdir()
sdk.copy(root/'bindings/rust/SDKConnectionConsumer/Cargo.toml',consumer/'Cargo.toml')
sdk.extract_recorded_crates(consumer,report.parent,data['crates'])
sdk.copy(root/'Cargo.lock',consumer/'Cargo.lock')
tc=Path('/opt/qperiapt/rustup/toolchains/1.98.1-aarch64-unknown-linux-gnu')
env=dict(os.environ,CARGO_HOME='/opt/qperiapt/cargo-cache',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='/work/connection-build-02',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_BUILD_JOBS='2')
cargo=str(tc/'bin/cargo')
metadata=json.loads(sdk.command([cargo,'metadata','--offline','--format-version','1','--filter-platform','aarch64-unknown-linux-gnu'],output/'metadata',consumer,environment=env))
resolution=sdk.verify_consumer_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),(root/'Cargo.lock').read_bytes(),consumer_name='q-periapt-connection-package-consumer')
sdk.command([cargo,'build','--locked','--offline','--bins','-j','2'],output/'build',consumer,environment=env)
sdk.verify_consumed_sources(consumer,report.parent,data['crates'])
bins={name:{'path':f'/work/connection-build-02/debug/{name}','sha256':sdk.snapshot(Path('/work/connection-build-02/debug')/name).sha256} for name in ('connection_peer','standard_peer')}
sdk.write_json(output/'RESULT.json',{'consumer':str(consumer),'uid':os.getuid(),'resolution':resolution,'binaries':bins,'crate_source':data['base_commit'],'source_inputs_unchanged':True,'native_linux':True,'release_claim_eligible':False})
print(json.dumps(bins),flush=True)
