from pathlib import Path
import hashlib, importlib, json, sys
app, provider, repo, output = map(Path, sys.argv[1:])
sys.path.append(str(app))
from qperiapt_continuity_reference.provider import load_provider
crypto, backend = load_provider(provider)
package = app / "qperiapt_continuity_reference"
loaded = {}
for path in sorted(package.glob("*.py")):
    name = "qperiapt_continuity_reference" + ("" if path.name == "__init__.py" else "." + path.stem)
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve() == path.resolve()
    loaded[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
assert len(loaded) == 47
assert all(not name.startswith("peer.") and name != "peer" for name in sys.modules)
assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode
assert all(not Path(name).resolve().is_relative_to(repo) for name in sys.path)
assert not list(Path(sys.pycache_prefix).iterdir())
result = {"loaded_modules": loaded, "package_root": str(package), "sys_path": sys.path,
          "python": sys.version, "isolated": sys.flags.isolated, "no_site": sys.flags.no_site,
          "dont_write_bytecode": sys.flags.dont_write_bytecode, "pycache_prefix": sys.pycache_prefix,
          "cryptography": crypto.__version__, "openssl": backend.openssl_version_text()}
output.write_text(json.dumps(result, indent=2) + "\n")
print("Admitted installed modules:", len(loaded))
