"""Read a terminal job artifact and preserve its exact public bytes."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import subprocess
import zipfile

out = Path(__file__).resolve().parent
head = '9f7a2e7a8ce21996aeee6b401dbbef7620e8c435'
api = lambda path: subprocess.check_output(['gh', 'api', 'repos/billlza/q-periapt/' + path], timeout=60)
job = json.loads(api('actions/jobs/117732681912'))
assert job['head_sha'] == head and job['run_id'] == 39146975242
assert job['status'] == 'completed' and job['conclusion'] == 'success'
a = next(a for a in json.loads(api('actions/runs/39146975242/artifacts'))['artifacts']
         if a['name'] == 'independent-bootstrap-macos-15')
assert not a['expired'] and a['workflow_run']['head_sha'] == head and a['size_in_bytes'] < 16 * 1024**2
path = out / 'mac-9f7.zip'
if not path.exists():
    path.write_bytes(api('actions/artifacts/' + str(a['id']) + '/zip'))
data = path.read_bytes()
assert len(data) == a['size_in_bytes'] and 'sha256:' + hashlib.sha256(data).hexdigest() == a['digest']
(out / 'ARTIFACT.json').write_text(json.dumps(a, indent=2) + '\n')
(out / 'JOB.json').write_text(json.dumps(job, indent=2) + '\n')
folder = out / 'public'
folder.mkdir(exist_ok=False)
with zipfile.ZipFile(path) as z:
    items = z.infolist()
    assert len(items) == len({i.filename for i in items}) < 4000
    assert sum(i.file_size for i in items) < 128 * 1024**2
    assert z.read('source-head.txt').decode().strip() == head
    assert 'arm64' in z.read('host.txt').decode()
    assert z.read('rustc.txt').decode().startswith('rustc 1.98.1 ') and 'host: aarch64-apple-darwin' in z.read('rustc.txt').decode()
    for i in items:
        name = PurePosixPath(i.filename)
        assert not i.is_dir() and not name.is_absolute() and '..' not in name.parts
        assert str(name) == i.filename and '\\' not in i.filename and not i.flag_bits & 1
        assert not stat.S_ISLNK(i.external_attr >> 16)
        body = z.read(i)
        assert not body.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02', b'QPREFS03', b'QPREFS04'))
        if i.filename.endswith(('.stdout', '.stderr')):
            assert not re.search(rb'(?mi)^\s*(error:|warning:)', body), i.filename
        target = folder.joinpath(*name.parts)
        target.parent.mkdir(exist_ok=True, parents=True)
        with target.open('xb') as f:
            f.write(body)
print(json.dumps({'run': job['run_id'], 'job': job['id'], 'head': head, 'artifact_id': a['id'],
                  'artifact_bytes': len(data), 'artifact_digest': a['digest'], 'members': len(items)}))
