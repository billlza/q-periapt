from pathlib import Path
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DEST = REPO / 'research/sdk-alpha1/evidence/20261105-hosted-swift-pair'
DEST.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(files, prefix, folder):
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            key = prefix + '/' + path.relative_to(folder).as_posix()
            assert key not in files
            files[key] = path

def capture(label, files):
    manifest = {}
    with zipfile.ZipFile(DEST / (label + '.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
            archive.writestr(name, data)
    with zipfile.ZipFile(DEST / (label + '.zip')) as archive:
        assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
        assert archive.testzip() is None
        for name, expected in manifest.items():
            data = archive.read(name)
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
    (DEST / (label + '_FILES.json')).write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    data = (DEST / (label + '.zip')).read_bytes()
    assert len(data) < 95 * 1024**2, 'split evidence by scope before staging an oversized Git object'
    summary = {'members': len(manifest), 'bytes': len(data), 'sha256': sha(data)}
    print(json.dumps({label: summary}), flush=True)
    return summary

common = {}
source_inventory = json.loads((ROOT / 'READER_SOURCE.json').read_text())
for name, expected in source_inventory['files'].items():
    path = ROOT / 'source-232' / name
    assert sha(path.read_bytes()) == expected['sha256']
    common['source/' + name] = path
for name in ['prepare.py', 'prepare.stdout', 'prepare.stderr', 'READER_SOURCE.json',
             'PAIR.json', 'PUBLICATION_RETENTION_GAP.json', 'LOG_CONNECTOR_FAILURE.json', 'capture.py']:
    common['controller/' + name] = ROOT / name
common['controller/verify_packages.py'] = ROOT / 'source-232/target/verify_packages.py'
common['current-workflow/ci.yml'] = REPO / '.github/workflows/ci.yml'
common['sdk/13405394674.zip'] = REPO / 'target/continuity-android-debug-hosted-20261105/sdk-producer/13405394674.zip'
summary = {'source_commit': '232ace17915407596d66f3a5fd7c7765251a38cc', 'captures': {}}
summary['captures']['INPUTS'] = capture('INPUTS', common)
for profile, identifier, job in [('debug', 13457675209, 127187927379), ('release', 13429478114, 127187927229)]:
    base = ROOT / profile
    raw = base / 'expanded'
    files = {}
    for path in sorted(raw.iterdir()):
        if path.is_file() and (path.suffix in ('.json', '.stdout', '.stderr', '.zip', '.crate') or path.name.endswith('Cargo.lock')):
            files['artifact/' + path.name] = path
    for name in ['swift-public', 'swift-root-public', 'swift-minimum-root', 'c-witness-openssl-public', 'apple-package']:
        tree(files, 'artifact/' + name, raw / name)
    tree(files, 'independent-readback', base / 'identity-01')
    # Re-extracted package payloads duplicate the retained original package archives.
    files = {name: path for name, path in files.items() if not name.startswith((
        'independent-readback/swift-package/', 'independent-readback/minimum-swift-package/', 'independent-readback/apple/'))}
    for name in ['ARTIFACT_METADATA.json', 'DOWNLOAD.json', 'EXTRACTED_FILES.json',
                 'PACKAGE_READBACK.json', 'identity-01.stdout', 'identity-01.stderr',
                 f'job-{job}.log', f'job-{job}.raw.log', 'log-download.stderr', 'log-download-02.stderr']:
        files['controller/' + name] = base / name
    summary['captures'][profile.upper()] = capture(profile.upper(), files)
    data = (base / 'PACKAGE_READBACK.json').read_bytes()
    with (DEST / (profile.upper() + '_READBACK.json')).open('xb') as stream:
        stream.write(data)
for name in ['PAIR.json', 'PUBLICATION_RETENTION_GAP.json']:
    with (DEST / name).open('xb') as stream:
        stream.write((ROOT / name).read_bytes())
summary['scope'] = 'Original Swift pair: actual packages, three Apple slices, unit/minimum-root records, 17 selected public reader groups and three OpenSSL groups per profile. Complete original workflow ZIPs remain retained locally; selected capsules do not claim all remaining exported groups were independently replayed. Missing publication bytes remain missing; no current-source or whole-matrix acceptance.'
summary['original_archives_retained'] = {profile: {'path': str(ROOT / profile / f'artifact-{identifier}.zip'),
    **json.loads((ROOT / profile / 'DOWNLOAD.json').read_text())}
    for profile, identifier in [('debug', 13457675209), ('release', 13429478114)]}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
