from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import stat
import subprocess
import sys
import unicodedata
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
COMMIT = '232ace17915407596d66f3a5fd7c7765251a38cc'
SOURCE = ROOT / 'source-232'
SOURCE.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

inputs = {}
for profile, identifier in [('debug', 13457675209), ('release', 13429478114)]:
    folder = ROOT / profile
    metadata = json.loads((folder / 'ARTIFACT_METADATA.json').read_text())
    archive_path = folder / f'artifact-{identifier}.zip'
    data = archive_path.read_bytes()
    assert metadata['size_in_bytes'] == len(data) and metadata['digest'] == 'sha256:' + sha(data)
    assert metadata['workflow_run']['head_sha'] == COMMIT and metadata['workflow_run']['id'] == 42008993544
    expanded = folder / 'expanded'
    expanded.mkdir()
    inventory = {}
    with zipfile.ZipFile(archive_path) as archive:
        portable = set()
        for member in archive.infolist():
            name = member.filename
            path = PurePosixPath(name)
            folded = unicodedata.normalize('NFC', name).casefold()
            assert not member.is_dir() and not stat.S_ISLNK(member.external_attr >> 16)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
            assert folded not in portable and name not in inventory
            portable.add(folded)
            content = archive.read(member)
            write(expanded / name, content)
            inventory[name] = {'bytes': len(content), 'sha256': sha(content)}
    write(folder / 'EXTRACTED_FILES.json', (json.dumps(inventory, indent=2, sort_keys=True) + '\n').encode())
    report = json.loads((expanded / 'CONTINUITY_PACKAGE.json').read_text())
    assert report['source_commit'] == COMMIT and report['build_profiles'] == [profile]
    assert report['partition_completed'] is True and report['completed'] is False
    assert report['source_inputs'] == json.loads((expanded / 'sources-before.json').read_text())
    assert report['source_inputs'] == json.loads((expanded / 'sources-after.json').read_text())
    for name, digest in report['source_inputs']['files'].items():
        assert name not in inputs or inputs[name] == digest
        inputs[name] = digest
    for key, filename in [('c_consumer', 'C_CONSUMER.json'), ('swift_consumer', 'SWIFT_CONSUMER.json'),
                          ('apple_package', 'CONTINUITY_APPLE_PACKAGE.json')]:
        assert report[key] == json.loads((expanded / filename).read_text())
    print(json.dumps({'profile': profile, 'members': len(inventory),
                      'expanded_bytes': sum(v['bytes'] for v in inventory.values())}), flush=True)

available = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', COMMIT, 'artifact'], cwd=REPO, text=True).splitlines())
queue = ['artifact/continuity_swift_consumer.py', 'artifact/continuity_apple_package.py',
         'artifact/continuity_apple_consumer.py', 'artifact/continuity_swift_root_msrv.py',
         'artifact/continuity_package.py']
contents = {}
while queue:
    name = queue.pop()
    if name in contents:
        continue
    data = subprocess.check_output(['git', 'show', COMMIT + ':' + name], cwd=REPO)
    contents[name] = data
    for node in ast.walk(ast.parse(data)):
        modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
        for module in modules:
            candidate = 'artifact/' + module.replace('.', '/') + '.py'
            if candidate in available:
                queue.append(candidate)
names = sorted(set(inputs) | set(contents) | {'artifact/python-run.sh', 'artifact/python-env.sh', 'artifact/python_bootstrap.py'})
assert all('\n' not in name and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in names)
data = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO,
    input=''.join(COMMIT + ':' + name + '\n' for name in names).encode(),
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
cursor = 0
sources = {}
for name in names:
    end = data.index(b'\n', cursor)
    header = data[cursor:end].split()
    assert len(header) == 3 and header[1] == b'blob'
    size = int(header[2])
    start = end + 1
    value = data[start:start + size]
    cursor = start + size
    assert data[cursor:cursor + 1] == b'\n'
    cursor += 1
    digest = sha(value)
    assert name not in inputs or digest == inputs[name]
    assert name not in contents or value == contents[name]
    sources[name] = {'bytes': len(value), 'sha256': digest}
    write(SOURCE / name, value)
assert cursor == len(data)
write(ROOT / 'READER_SOURCE.json', (json.dumps({'commit': COMMIT, 'package_input_files': len(inputs),
    'static_reader_modules': len(contents), 'files': sources}, indent=2, sort_keys=True) + '\n').encode())
print(json.dumps({'source_commit': COMMIT, 'package_inputs': len(inputs),
                  'reader_modules': len(contents), 'source_files': len(sources)}))
