from pathlib import Path
import ast
import datetime
import hashlib
import json
import plistlib
import re
import struct
import sys
import zipfile

import rust_sdk_profile as sdk
import continuity_package as package
import continuity_c_consumer as c
import continuity_swift_consumer as swift
import continuity_swift_root as swift_root
import continuity_swift_root_msrv as minimum
import continuity_apple_package as apple
import continuity_apple_consumer as apple_consumer
import continuity_c_witness_openssl as openssl
import continuity_c_account as account
from continuity_package_archive import unpack
from deterministic_archive import extract_zip
from bounded_process import capture_output

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
SOURCE = package.ROOT
CONTROL = SOURCE.parent
REPO = CONTROL.parents[1]
PROFILE = sys.argv[1]
assert PROFILE in ('debug', 'release')
ROOT = CONTROL / PROFILE
RAW = ROOT / 'expanded'
OUT = ROOT / 'identity-01'
OUT.mkdir()
COMMIT = '232ace17915407596d66f3a5fd7c7765251a38cc'
SDK_ROOT = REPO / 'target/continuity-android-debug-hosted-20261105/sdk-producer'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def original(label, folder=RAW):
    assert load(folder / (label + '.json'))['returncode'] == 0, label
    return (folder / (label + '.stdout')).read_bytes()

report = load(RAW / 'CONTINUITY_PACKAGE.json')
foreign = load(RAW / 'SWIFT_CONSUMER.json')
native = load(RAW / 'C_CONSUMER.json')
ap = load(RAW / 'CONTINUITY_APPLE_PACKAGE.json')
assert report['source_commit'] == COMMIT and report['swift_consumer'] == foreign
assert report['c_consumer'] == native and report['apple_package'] == ap
for value in (report, foreign, native):
    assert value['build_profiles'] == [PROFILE] and value['partition_completed'] is True
    assert value['completed'] is False and value['release_claim_eligible'] is False
assert report['source_inputs'] == load(RAW / 'sources-before.json') == load(RAW / 'sources-after.json')
assert report['sources_unchanged'] and report['publication_performed'] is False
for name, digest in report['source_inputs']['files'].items():
    assert sha((SOURCE / name).read_bytes()) == digest
sdk_archive_path = SDK_ROOT / '13405394674.zip'
assert sha(sdk_archive_path.read_bytes()) == 'de332b6dde0a76159687b295e060c36438e5e52d079035703dd891b95c8a11f3'
sdk_archives = {}
with zipfile.ZipFile(sdk_archive_path) as archive:
    sdk_bytes = archive.read('sdk-rust-package/RUST_SDK_PACKAGE.json')
    cohort = json.loads(sdk_bytes)
    assert sha(sdk_bytes) == report['rust_report_sha256'] and cohort['base_commit'] == COMMIT
    assert cohort['source_inputs']['rust_workspace_sha256'] == report['source_inputs']['rust_workspace_sha256']
    for name, row in cohort['crates'].items():
        data = archive.read('sdk-rust-package/crates/' + row['file'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        members = sdk.archive_files(data, name)
        assert set(members) == set(row['files']) and len(members) == row['members']
        sdk_archives[name] = {'sha256': sha(data), 'bytes': len(data), 'members': len(members)}
candidate_bytes = (RAW / report['archive']['file']).read_bytes()
assert sha(candidate_bytes) == report['archive']['sha256'] and len(candidate_bytes) == report['archive']['bytes']
candidate = package.validate_candidate(candidate_bytes, set(report['archive']['files']))
for name, data in candidate.items():
    if name.startswith(('src/', 'tests/')):
        assert data == (SOURCE / 'research/continuity-identity-candidate' / name).read_bytes()
resolutions = {}
for label, lock_name, name, features, expected in (
    ('consumer-metadata', 'consumer-Cargo.lock', package.CONSUMER, frozenset({'connection-tls', 'control-tls'}), report['resolution']),
    ('c-metadata', 'c-consumer-Cargo.lock', c.NAME, c.FEATURES, native['resolution'])):
    metadata = load(RAW / (label + '.stdout'))
    root_package = next(p for p in metadata['packages'] if p['id'] == metadata['resolve']['root'])
    consumer = Path(root_package['manifest_path']).parent
    assert consumer.is_absolute() and consumer.parent.name.startswith('qperiapt-continuity-package-')
    assert root_package['name'] == name and Path(load(RAW / (label + '.json'))['cwd']) == consumer
    value = package.verify_resolution(metadata, consumer, (RAW / lock_name).read_bytes(),
        (SOURCE / 'research/continuity-identity-candidate/Cargo.lock').read_bytes(),
        consumer_name=name, required_features=features)
    assert value == expected
    resolutions[name] = value
text = original('consumer-' + PROFILE).decode()
assert set(re.findall(r'^test ([a-z_:]+) \.\.\. ok$', text, re.M)) == package.TESTS
assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in text
row = foreign['profiles'][PROFILE]
swift.verify_tests(original('swift-tests-' + PROFILE), (RAW / ('swift-tests-' + PROFILE + '.stderr')).read_bytes())
function = next(n for n in ast.parse((SOURCE / 'artifact/continuity_swift_consumer.py').read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == 'verify_tests')
test_names = ast.literal_eval(next(n.value for n in function.body if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == 'tests' for t in n.targets)))
data = (RAW / row['archive']).read_bytes()
assert sha(data) == row['archive_sha256']
installed = OUT / 'swift-package'
unpack(data, row['files'], installed)
swift.licenses.verify(installed, expected_target='aarch64-apple-darwin', root_package=c.NAME)
library = installed / 'native/lib' / swift.LIBRARY
assert sha(library.read_bytes()) == row['native_library_sha256'] == native['execution'][PROFILE]['binaries']['C_library']['sha256']
magic, cpu, subtype, kind = struct.unpack('<IIII', library.read_bytes()[:16])
assert magic == 0xfeedfacf and cpu == 0x0100000c and kind == 6
for name in row['files']:
    if name.startswith('Sources/') or name in ('Package.swift', 'README.md', 'ApplePackageREADME.md'):
        assert (installed / name).read_bytes() == (SOURCE / 'bindings/swift/ContinuityPackageConsumer' / name).read_bytes()
assert ap['completed'] and ap['sources_unchanged'] and ap['installed_members_verified']
assert ap['physical_device_execution'] is False and ap['simulator_execution'] is False
assert ap['publication_performed'] is False and ap['release_claim_eligible'] is False
archive_path = RAW / ap['archive']['file']
assert archive_path.stat().st_size == ap['archive']['bytes'] and sha(archive_path.read_bytes()) == ap['archive']['sha256']
extract_zip(archive_path, OUT / 'apple', root_name=apple.NAME, mtime=apple.MTIME,
    expected_sha256=ap['archive']['sha256'], limits=apple.LIMITS)
apple_root = OUT / 'apple' / apple.NAME
contents = load(apple_root / apple.CONTENTS)
apple.verify_package(apple_root, contents, ap['native'], (SOURCE / 'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes())
nm = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-nm')
assert sha(nm.read_bytes()) == ap['llvm_nm_sha256']
slices = {}
info = plistlib.loads((apple_root / 'CQPCOwner.xcframework/Info.plist').read_bytes())
for item in info['AvailableLibraries']:
    platform = (item['SupportedPlatform'], item.get('SupportedPlatformVariant'))
    target = next(k for k, v in apple.TARGETS.items() if v == platform)
    path = apple_root / 'CQPCOwner.xcframework' / item['LibraryIdentifier'] / item['LibraryPath']
    result = capture_output([str(nm), '--defined-only', '--extern-only', str(path)], timeout_seconds=900,
        maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2)
    (OUT / (target + '-nm.stdout')).write_bytes(result.stdout)
    (OUT / (target + '-nm.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0
    apple.verify_exports(result.stdout)
    slices[target] = {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
        'owner_exports': len(c.EXPORTS), 'original_tool_reused': True, 'nm_stdout_sha256': sha(result.stdout)}
    assert {k: slices[target][k] for k in ('bytes', 'sha256', 'owner_exports')} == ap['native'][target]
apple_output = RAW / 'apple-package'
assert original('consumer-macos-run', apple_output) == apple_consumer.MARKER
assert (apple_output / 'consumer-macos-run.stderr').read_bytes() == b''
for target in apple.TARGETS:
    assert original('consumer-arch-' + target, apple_output).strip() == b'arm64'
for label in ('consumer-macos-build', 'consumer-ios-build', 'consumer-simulator-build'):
    original(label, apple_output)
minimum.validate_versions(original('swift-minimum-rustc').decode(), original('swift-minimum-cargo').decode())
minimum.verify_native_tests(original('swift-minimum-native-root-tests'))
swift.verify_tests(original('swift-minimum-swift-tests'), (RAW / 'swift-minimum-swift-tests.stderr').read_bytes())
min_row = foreign['minimum_root']
assert min_row['completed'] and min_row['sources_unchanged'] and min_row['release_claim_eligible'] is False
min_bytes = (RAW / min_row['package']).read_bytes()
assert sha(min_bytes) == min_row['package_sha256']
unpack(min_bytes, min_row['package_files'], OUT / 'minimum-swift-package')
assert sha((OUT / 'minimum-swift-package/native/lib' / swift.LIBRARY).read_bytes()) == min_row['native_library_sha256']
public_results = {}

def finish(name, value, expected):
    assert value == expected, 'original public reader differs: ' + name
    public_results[name] = value
    (OUT / 'PUBLIC_REPLAY.json').write_text(json.dumps(public_results, indent=2) + '\n')
    print(json.dumps({'public_group': name, 'original_reader_matches': True}), flush=True)

for name, checker, label, folder, expected in (
    ('client', swift.verify_execution, 'trace', 'swift-public/' + PROFILE, row['execution']),
    ('server', swift.verify_server_execution, 'server-trace', 'swift-public/server/' + PROFILE, row['server_execution']),
    ('recovery', swift.verify_recovery_execution, 'recovery-trace', 'swift-public/recovery/' + PROFILE, row['recovery_execution']),
    ('restore', lambda data, path: c.verify_restore_execution(data, path, language='Swift'), 'restore-trace', 'swift-public/restore/' + PROFILE, row['restoration']['execution']),
    ('restore-opening', lambda data, path: swift.opening.verify_restore_execution(data, path, language='Swift'), 'restore-opening-trace', 'swift-public/restore-opening/' + PROFILE, row['restoration_opening']['execution']),
    ('account', lambda data, path: account.verify_execution(data, path, language='Swift'), 'account-trace', 'swift-public/account/' + PROFILE, row['account_owner']['execution'])):
    finish(name, checker(original('swift-' + label + '-' + PROFILE), RAW / folder), expected)
for label, module in [('opening', swift.opening), ('signed-tcp', swift.witness), ('mutual-tls', swift.witness_tls)]:
    finish('witness-' + label, module.verify_execution(original('swift-witness-' + label + '-' + PROFILE),
        RAW / 'swift-public' / ('witness-' + label) / PROFILE, language='Swift'), row['witnessed'][label]['execution'])
for prefix, selected, path, profile, record in (
    ('regular-root', 'swift-root-', RAW / 'swift-root-public', PROFILE, row['root_lifecycle']),
    ('minimum-root', 'swift-minimum-swift-root-', RAW / 'swift-minimum-root/swift-root-public', 'debug', min_row['Swift'])):
    for variant, expected in record['routes'].items():
        value = swift_root.verify_execution(original(selected + profile + '-' + variant), path / profile / variant, variant=variant)
        finish(prefix + '-' + variant, value, {k: v for k, v in expected.items() if k != 'exported_public_files'})
openssl_results = {}
for kind in ('server', 'client', 'rejections'):
    expected = native['execution'][PROFILE]['witness_openssl']['execution'][kind]
    value = openssl.verify_execution(kind, original('c-witness-openssl-' + kind + '-' + PROFILE),
        RAW / 'c-witness-openssl-public' / PROFILE / kind)
    assert value == {k: v for k, v in expected.items() if k != 'exported_public_files'}
    openssl_results[kind] = value
loaded = {}
for module in tuple(sys.modules.values()):
    filename = getattr(module, '__file__', None)
    if filename and Path(filename).is_relative_to(SOURCE / 'artifact'):
        path = Path(filename)
        loaded[path.relative_to(SOURCE).as_posix()] = sha(path.read_bytes())
current = load(REPO / 'target/continuity-current-sdk-5678/source/target/continuity-installed-rust-current/CONTINUITY_PACKAGE.json')
before, after = report['source_inputs']['files'], current['source_inputs']['files']
summary = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_commit': COMMIT,
    'profile': PROFILE, 'source_inputs': len(before), 'sdk_report_sha256': sha(sdk_bytes),
    'sdk_root': cohort['source_inputs']['rust_workspace_sha256'], 'sdk_archives': sdk_archives,
    'candidate_archive_sha256': sha(candidate_bytes), 'candidate_members': len(candidate),
    'installed_graphs': resolutions, 'swift_archive_sha256': row['archive_sha256'],
    'swift_package_members': len(row['files']), 'swift_named_unit_tests': len(test_names),
    'swift_native_library_bytes_verified': True, 'minimum_native_tests': len(minimum.ROOT_TESTS),
    'minimum_swift_named_unit_tests': len(test_names), 'minimum_package_sha256': min_row['package_sha256'],
    'apple_archive': ap['archive'], 'apple_slices': slices, 'macos_probe_marker_verified': True,
    'ios_and_simulator_build_receipts_verified': True, 'ios_or_simulator_runtime_claimed': False,
    'public_groups_verified': list(public_results), 'openssl_public_outcomes': openssl_results,
    'loaded_original_reader_modules': loaded,
    'current_source_commit': current['source_commit'],
    'source_changes': {'changed': [n for n in sorted(before.keys() & after.keys()) if before[n] != after[n]],
                       'added': sorted(after.keys() - before.keys()), 'removed': sorted(before.keys() - after.keys())},
    'scope': 'Exact original archives, source/graphs, actual packaged dylibs and three Apple static archives, original unit/root records and selected public readers. Native workloads are not rerun. Publication bytes are missing in the historical artifact; other public groups and absent standalone executable bytes are not declared independently reverified here. Not current-source or full foreign-matrix/release acceptance.'}
with (ROOT / 'PACKAGE_READBACK.json').open('x') as stream:
    json.dump(summary, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'profile': PROFILE, 'swift_tests': len(test_names), 'apple_slices': len(slices),
                  'public_groups': len(public_results), 'minimum_native_tests': len(minimum.ROOT_TESTS)}))
