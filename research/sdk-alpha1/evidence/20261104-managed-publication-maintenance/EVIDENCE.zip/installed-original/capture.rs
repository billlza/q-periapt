use q_periapt_host_store::filesystem::{publish_private_bytes, publish_private_directory, PrivatePublicationError};
use std::{fs,io,path::Path,process::Command,os::unix::fs::PermissionsExt};
fn run(binary:&Path, attempt:&Path, out:&Path, label:&str, entries:usize, expected:i32)->Vec<u8> {
 let output=Command::new(binary).arg("publication-reclaim").arg(attempt).args(["--max-entries",&entries.to_string(),"--max-depth","8","--max-bytes","1024"]).output().expect("installed command");
 fs::write(out.join(format!("{label}.stdout")),&output.stdout).expect("stdout capture");
 fs::write(out.join(format!("{label}.stderr")),&output.stderr).expect("stderr capture");
 fs::write(out.join(format!("{label}.exit")),format!("{}\n",output.status.code().expect("ordinary exit"))).expect("exit capture");
 assert_eq!(output.status.code(),Some(expected));
 if expected!=0 {assert!(output.stdout.is_empty());}
 output.stdout
}
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<_>=std::env::args_os().skip(1).collect(); assert_eq!(args.len(),2);
 let binary=Path::new(args.first().expect("binary"));let out=Path::new(args.get(1).expect("output"));
 let fixture=tempfile::Builder::new().prefix("qperiapt-original-publication-").permissions(fs::Permissions::from_mode(0o700)).tempdir()?.keep().canonicalize()?;
 fs::write(out.join("fixture-path.txt"),fixture.as_os_str().as_encoded_bytes())?;
 let formal=fixture.join("formal"); let value=b"original unpublished bytes";let mut selected=None;
 let result=publish_private_directory::<(),PrivatePublicationError>(&formal,|payload| {
  publish_private_bytes(&payload.join("key"),value)?;
  let attempt=payload.parent().expect("control").to_owned();
  run(binary,&attempt,out,"01-active",16,1);selected=Some(attempt);
  Err(io::Error::other("original capture fixture interruption").into())
 });
 assert_eq!(result.expect_err("abandoned attempt").operation().to_string(),"original capture fixture interruption");
 let attempt=selected.expect("original attempt");fs::write(out.join("attempt-path.txt"),attempt.as_os_str().as_encoded_bytes())?;
 let record=fs::read(attempt.join("record"))?;let lease=fs::read(attempt.join("lease"))?;
 fs::write(out.join("record.bin"),&record)?;fs::write(out.join("lease.bin"),&lease)?;fs::write(out.join("payload-before.bin"),fs::read(attempt.join("payload/key"))?)?;
 run(binary,&attempt,out,"02-budget",1,1);assert!(!attempt.join("cleanup.intent").exists());assert_eq!(fs::read(attempt.join("payload/key"))?,value);
 let first=run(binary,&attempt,out,"03-first",16,0);assert!(!formal.exists());assert!(!attempt.join("payload").exists());
 let intent=fs::read(attempt.join("cleanup.intent"))?;let done=fs::read(attempt.join("cleanup.done"))?;
 fs::write(out.join("intent.bin"),&intent)?;fs::write(out.join("receipt.bin"),&done)?;
 let retry=run(binary,&attempt,out,"04-retry",16,0);assert_eq!(first,retry);
 assert_eq!(fs::read(attempt.join("record"))?,record);assert_eq!(fs::read(attempt.join("lease"))?,lease);assert_eq!(fs::read(attempt.join("cleanup.intent"))?,intent);assert_eq!(fs::read(attempt.join("cleanup.done"))?,done);
 publish_private_bytes(&formal,value)?;run(binary,&formal,out,"05-formal",16,1);assert_eq!(fs::read(formal)?,value);
 fs::write(out.join("COMPLETE"),b"original-record-and-result-retained\n")?;
 Ok(())
}