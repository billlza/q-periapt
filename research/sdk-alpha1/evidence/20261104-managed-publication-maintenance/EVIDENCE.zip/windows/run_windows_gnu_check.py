import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
repo = base.parents[1]
mode, label = sys.argv[1:]
assert mode in ("check", "clippy")
toolchain = Path("/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin")
llvm = base / "gnu-extracted/llvm-mingw-20261104-ucrt-macos-universal"
target = "x86_64-pc-windows-gnu"
stem = base / ("cargo-" + mode + "-" + label)
assert not Path(str(stem) + "-inputs.json").exists()
assert (llvm / "bin/x86_64-w64-mingw32-clang").exists()
assert (base / "sysroot/lib/rustlib" / target / "lib").is_dir()

def now():
    return datetime.now(timezone.utc).isoformat()

def command_text(args):
    return subprocess.check_output(args, cwd=repo, text=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source():
    names = command_text(["rg", "--files", "crates", "-g", "*.rs", "-g", "*.toml", "-g", "*.c", "-g", "*.h", "-g", "*.S"]).splitlines()
    names += ["Cargo.toml", "Cargo.lock", "rust-toolchain.toml"]
    return {name: sha(repo / name) for name in sorted(set(names))}

overrides = {
    "CARGO_HOME": "/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo",
    "CARGO_TARGET_DIR": str(base / "build-gnu"),
    "RUSTC": str(toolchain / "bin/rustc"),
    "CARGO_TARGET_X86_64_PC_WINDOWS_GNU_RUSTFLAGS": "--sysroot " + str(base / "sysroot"),
    "CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER": str(llvm / "bin/x86_64-w64-mingw32-clang"),
    "CC_x86_64_pc_windows_gnu": str(llvm / "bin/x86_64-w64-mingw32-clang"),
    "AR_x86_64_pc_windows_gnu": str(llvm / "bin/llvm-ar"),
    "PATH": str(toolchain / "bin") + ":" + str(llvm / "bin") + ":" + os.environ["PATH"],
}
args = [str(toolchain / "bin/cargo"), mode, "--locked", "--offline", "-p", "q-periapt-host-store", "--lib", "--target", target, "-j", "2", "-vv"]
if mode == "clippy":
    args += ["--", "-D", "warnings"]
ambient_names = ["RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CC", "CFLAGS", "CXX", "AR", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER"]
inputs = {
    "command": args,
    "environment_overrides": overrides,
    "ambient_compiler_variables": {k: os.environ.get(k) for k in ambient_names},
    "started_utc": now(),
    "git_head": command_text(["git", "rev-parse", "HEAD"]).strip(),
    "git_diff_stat": command_text(["git", "diff", "--stat"]),
    "git_status_porcelain": command_text(["git", "status", "--porcelain"]),
    "source_before": source(),
    "global_manifest_before": sha(toolchain / "lib/rustlib/multirust-channel-manifest.toml"),
    "scope": "Actual Windows GNU target of unchanged real crate, including real C backend and Windows modules. Diagnostic only; neither Windows MSVC check nor a Windows execution or release qualification.",
}
Path(str(stem) + "-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
Path(str(stem) + "-host-store.diff").write_text(command_text(["git", "diff", "--", "crates/q-periapt-host-store"]))
env = os.environ.copy()
env.update(overrides)
with Path(str(stem) + ".stdout").open("wb") as out, Path(str(stem) + ".stderr").open("wb") as err:
    completed = subprocess.run(args, cwd=repo, env=env, stdout=out, stderr=err)
after = source()
result = {
    "returncode": completed.returncode,
    "finished_utc": now(),
    "source_after": after,
    "source_unchanged_during_check": inputs["source_before"] == after,
    "source_changes_during_check": [k for k in sorted(inputs["source_before"].keys() | after.keys()) if inputs["source_before"].get(k) != after.get(k)],
    "global_manifest_after": sha(toolchain / "lib/rustlib/multirust-channel-manifest.toml"),
}
Path(str(stem) + "-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k:v for k,v in result.items() if k != "source_after"}, indent=2))
print("Evidence:", stem)
sys.exit(completed.returncode)
