# Windows source validation, 2026-11-04

This task changed no product source. The two new build attempts both succeeded for `x86_64-pc-windows-gnu`, using the real crate, Windows modules, Windows standard library and portable native C build. They are diagnostic source type/lint evidence, not Windows MSVC, final linking, execution, installed-package, NTFS or release qualification.

Source base: `141500d153f814ef89d4b53739348cab6d952e35` plus the captured working-tree diff. Each command captured 278 Rust/C/configuration hashes before and after; no source changed during either command. The complete host-store source inventory and both commands' hashes are in [host-store-source-hashes-03-04.json](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/host-store-source-hashes-03-04.json). These identities must be compared against a later candidate before evidence reuse.

## Actual commands and complete logs

Both commands used the exact Rust 1.98.1 Cargo/rustc binaries, an isolated target directory, a task-private sysroot, and target-specific compiler/archive/linker overrides. Exact arguments, environment overrides, relevant ambient compiler variables, git diff summary/status and full captured source hashes are in each inputs JSON. No stub, cfg override, native-C disablement or custom warning suppression was used.

1. `cargo check --locked --offline -p q-periapt-host-store --lib --target x86_64-pc-windows-gnu -j 2 -vv`: exit 0; Cargo 22.99 s; UTC 17:46:15–17:46:38.
   - [Inputs JSON](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03-inputs.json)
   - [Result JSON](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03-result.json)
   - [Complete stdout](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03.stdout)
   - [Complete stderr](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03.stderr)
   - [Tracked host-store diff](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03-host-store.diff)
2. `cargo clippy --locked --offline -p q-periapt-host-store --lib --target x86_64-pc-windows-gnu -j 2 -vv -- -D warnings`: exit 0; Cargo 8.81 s; UTC 17:47:03–17:47:13.
   - [Inputs JSON](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-clippy-04-inputs.json)
   - [Result JSON](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-clippy-04-result.json)
   - [Complete stdout](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-clippy-04.stdout)
   - [Complete stderr](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-clippy-04.stderr)
   - [Tracked host-store diff](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-clippy-04-host-store.diff)

Registry dependency warnings remain visible: generic-array (6), winnow (1), rand_core (1). The primary host-store Clippy invocation used `-D warnings`; no changed-module warning was suppressed. Cargo's normal dependency cap-lints behavior is visible in the verbose commands.

The generated host-store dependency files include `windows_native.rs`, `windows_publication_ops.rs` and `maintenance/attempt.rs`. The native ML-KEM wrapper objects are actual Intel amd64 COFF objects, with a native archive. [Artifact observations after both commands](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/cargo-check-03-artifacts.json) record paths, sizes and hashes; that observation includes both check and Clippy outputs.

## Private tool sources and identity

- Rust compiler: existing `~/.rustup/toolchains/1.98.1-aarch64-apple-darwin`; commit `48a229ceaefd4985c50990b14116b6d856af0985`. The copied installed `multirust-channel-manifest.toml` specifies the exact 2026-09-03 distribution. [Official Windows GNU std archive](https://static.rust-lang.org/dist/2026-09-03/rust-std-1.98.1-x86_64-pc-windows-gnu.tar.xz): 27,397,568 bytes; SHA-256 `5bb599a541fcb9c0edc00e512570f60d2262623f1e2a19a44cce3a7a97208788`, matching that manifest. It is copied only under this directory's `sysroot/lib/rustlib/x86_64-pc-windows-gnu`.
- Genuine Windows GNU C toolchain: [LLVM-MinGW project release 20261104](https://github.com/mstorsjo/llvm-mingw/releases/tag/20261104), macOS universal archive, asset 710266817. 125,261,696 bytes; SHA-256 `66cbd5178c4a71b0d473e68ede172f8eb7d15d023e67f39201d0a69e21f6bf3c`, matching release metadata obtained through the GitHub connector. Clang/llvm-ar 23.1.5. [mingw-w64's official toolchain list](https://www.mingw-w64.org/downloads/#llvm-mingw) identifies this distribution as a complete toolchain. Full archive and extracted copyright/license files are retained privately.
- [GNU provisioning digest verification](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/gnu-provisioning-verification.json), [release metadata](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/llvm-mingw-release-input.json), [actual tool versions and executable hashes](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/gnu-tool-versions.json).
- Global toolchain manifest hash remained `e44f4ea0a633aa3e497e4dd161424419fbd7bdc203606ef840634fdd22dab9bf`; installed global targets still only `aarch64-apple-darwin`: [post-check target list](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/global-targets-after.txt). No `rustup target add` or global installation ran.

## Preserved MSVC/provisioning boundaries

The original `cargo-check-01` and `cargo-check-02` stdout/stderr and result/input files remain untouched. The MSVC target's real C compilation failed at vendor `common.h:191` because `string.h` was absent; it did not compile the new Windows host-store modules.

Additional Microsoft downloads were investigated but were not used in the successful GNU checks:

- [Microsoft Windows SDK CPP 10.0.26100.7705](https://www.nuget.org/packages/Microsoft.Windows.SDK.CPP/10.0.26100.7705) package: official NuGet SHA-512 and size verified. SHA-256 `ff455660bee071a744715a9665666fa29c07681579d3d815959a9eec5a556424`; [verification](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/windows-sdk-package-verification.json).
- Microsoft CRT Headers 14.44.35220 VSIX: actual SHA-256 `852382a9aa73502b7849c1bcadfb603ba7175c4e8b60e6aba03c7de711d4ece5` matches the official fixed URL and payload metadata; actual size 2,116,223 differs from metadata 2,128,977. The first verification combined digest/size in one boolean; [the separate follow-up fields](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/crt-package-verification-02.json) preserve and clarify that result. No failed record was replaced.
- Official VS 17 release and 17.12 LTSC manifest downloads did not match their channel-declared digest/size. Original bodies and verification JSON are retained. No claim of a fully verified channel-to-manifest chain is made.
- The actual [Build Tools license](https://visualstudio.microsoft.com/license-terms/vs2022-ga-diagnosticbuildtools/) was inspected. An applicable Visual Studio licensing context for this whole project's use was not established; the limited third-party open-source dependency clause was not assumed to cover the project's own C bridge. This does not assert that the user lacks a valid license. Microsoft CRT headers were not used to build.

## Requested native API recheck

[Native API review](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/native-api-review.json) records exact current source and windows-sys 0.61.2 hashes, line numbers and primary Microsoft definitions. No concrete parameter-type inconsistency was found.

- `windows_native.rs:478`: NtQueryDirectoryFile's HANDLE, APC option, pointer, u32 length, FILE_INFORMATION_CLASS (i32) and bool arguments match windows-sys; the two Microsoft BOOLEAN parameters are represented by the binding's bool and receive true/false only. FILE_NAMES_INFORMATION is the documented three ULONGs plus UTF-16 tail; the buffer is LONG-aligned and checked before forming a slice. [Microsoft query definition](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/nf-ntifs-ntquerydirectoryfile), [record layout](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_names_information).
- `windows_native.rs:423`: NtSetInformationFile receives the 4-byte FILE_DISPOSITION_INFORMATION_EX record, class 64, DELETE=1 and POSIX=2. Only the late DELETE handle is consumed and closed; the caller's pin and lease remain live. The adapter checks namespace absence. [Microsoft disposition definition and closing semantics](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntddk/ns-ntddk-_file_disposition_information_ex).
- `windows_native.rs:454`: ReOpenFile parameters match its binding. Actual NTFS behavior remains unexecuted. Microsoft describes the original object as created by CreateFile, whereas these pins originate in NtCreateFile; this is a documented/runtime interoperability point to exercise in the already required real Windows run, not an observed failure. [Microsoft ReOpenFile definition](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-reopenfile).

No further build attempts were made. The machine-readable result index is [FOLLOWUP-SUMMARY.json](/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/windows-typecheck-1.98.1-hn2792f5/FOLLOWUP-SUMMARY.json).
