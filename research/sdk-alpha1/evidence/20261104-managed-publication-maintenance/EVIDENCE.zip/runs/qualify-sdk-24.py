from pathlib import Path
import json,os,sys,time,hashlib
root=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt');out=root/'target/continuity-managed-maintenance'
source=out/'source-f560d803'
sys.path.insert(0,str(root/'artifact'))
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_'))}
env.update(QPERIAPT_PYTHON=sys.executable,PATH=str(chain/'bin')+':'+str(out/'audit-tools/bin')+':'+env['PATH'],RUSTC=str(chain/'bin/rustc'),RUSTDOC=str(chain/'bin/rustdoc'),DYLD_FALLBACK_LIBRARY_PATH=str(chain/'lib'))
argv=['sh','artifact/python-run.sh','artifact/rust_sdk_profile.py','--output',str(source/'target/managed-sdk-cohort')]
# The product driver bounds each component at its existing 900-second budget.
# This outer bound only covers the finite package/fetch/audit/consumer sequence.
receipt={'argv':argv,'cwd':str(source),'completed':False,'component_timeout_seconds':900}
os.chdir(source);t=time.monotonic()
try:
 with (out/'sdk-cohort-24.stdout').open('xb',buffering=0) as stdout, (out/'sdk-cohort-24.stderr').open('xb',buffering=0) as stderr:
  result=capture_output(argv,timeout_seconds=900,maximum_stdout_bytes=16*1024**2,maximum_stderr_bytes=16*1024**2,environment=env,stdout_sink=stdout.write,stderr_sink=stderr.write)
 receipt.update(completed=True,exit=result.returncode)
except Exception as e:
 receipt.update(error_type=type(e).__name__,error=str(e));raise
finally:
 receipt['elapsed_seconds']=time.monotonic()-t
 (out/'sdk-cohort-24.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(result.returncode)
