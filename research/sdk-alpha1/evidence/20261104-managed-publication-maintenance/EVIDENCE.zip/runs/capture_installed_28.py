from pathlib import Path
import json,os,hashlib,sys,tempfile,subprocess
root=Path.cwd();out=root/'target/continuity-managed-maintenance';source=out/'source-f560d803';cohort=source/'target/managed-sdk-cohort';sdk_report=json.loads((cohort/'RUST_SDK_PACKAGE.json').read_text());package=json.loads((source/'target/managed-native-maintenance-27/RESULT.json').read_text());installed=Path(package['installed']);binary=installed/'bin/qperiapt'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==package['binary_sha256']
consumer=Path(sdk_report['consumer']['path']);app=Path(tempfile.mkdtemp(prefix='qperiapt-publication-capture-')).resolve();result=out/'installed-original-capture-28';result.mkdir(mode=0o700)
manifest=(consumer/'Cargo.toml').read_text().replace('name = "q-periapt-sdk-package-consumer"','name = "q-periapt-publication-capture"')
manifest=manifest.replace('path = "packages/','path = "'+str(consumer/'packages')+'/')
(app/'Cargo.toml').write_text(manifest);(app/'Cargo.lock').write_bytes((consumer/'Cargo.lock').read_bytes());(app/'examples').mkdir()
code=r'''use q_periapt_host_store::filesystem::{publish_private_bytes, publish_private_directory, PrivatePublicationError};
use std::{fs,io,path::Path,process::Command,os::unix::fs::PermissionsExt};
fn run(binary:&Path, attempt:&Path, out:&Path, label:&str, entries:usize, expected:i32)->Vec<u8> {
 let output=Command::new(binary).arg("publication-reclaim").arg(attempt).args(["--max-entries",&entries.to_string(),"--max-depth","8","--max-bytes","1024"]).output().expect("installed command");
 fs::write(out.join(format!("{label}.stdout")),&output.stdout).expect("stdout capture");
 fs::write(out.join(format!("{label}.stderr")),&output.stderr).expect("stderr capture");
 fs::write(out.join(format!("{label}.exit")),format!("{}\n",output.status.code().expect("ordinary exit"))).expect("exit capture");
 assert_eq!(output.status.code(),Some(expected));
 if expected!=0 {assert!(output.stdout.is_empty());}
 output.stdout
}
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<_>=std::env::args_os().skip(1).collect(); assert_eq!(args.len(),2);
 let binary=Path::new(args.first().expect("binary"));let out=Path::new(args.get(1).expect("output"));
 let fixture=tempfile::Builder::new().prefix("qperiapt-original-publication-").permissions(fs::Permissions::from_mode(0o700)).tempdir()?.keep().canonicalize()?;
 fs::write(out.join("fixture-path.txt"),fixture.as_os_str().as_encoded_bytes())?;
 let formal=fixture.join("formal"); let value=b"original unpublished bytes";let mut selected=None;
 let result=publish_private_directory::<(),PrivatePublicationError>(&formal,|payload| {
  publish_private_bytes(&payload.join("key"),value)?;
  let attempt=payload.parent().expect("control").to_owned();
  run(binary,&attempt,out,"01-active",16,1);selected=Some(attempt);
  Err(io::Error::other("original capture fixture interruption").into())
 });
 assert_eq!(result.expect_err("abandoned attempt").operation().to_string(),"original capture fixture interruption");
 let attempt=selected.expect("original attempt");fs::write(out.join("attempt-path.txt"),attempt.as_os_str().as_encoded_bytes())?;
 let record=fs::read(attempt.join("record"))?;let lease=fs::read(attempt.join("lease"))?;
 fs::write(out.join("record.bin"),&record)?;fs::write(out.join("lease.bin"),&lease)?;fs::write(out.join("payload-before.bin"),fs::read(attempt.join("payload/key"))?)?;
 run(binary,&attempt,out,"02-budget",1,1);assert!(!attempt.join("cleanup.intent").exists());assert_eq!(fs::read(attempt.join("payload/key"))?,value);
 let first=run(binary,&attempt,out,"03-first",16,0);assert!(!formal.exists());assert!(!attempt.join("payload").exists());
 let intent=fs::read(attempt.join("cleanup.intent"))?;let done=fs::read(attempt.join("cleanup.done"))?;
 fs::write(out.join("intent.bin"),&intent)?;fs::write(out.join("receipt.bin"),&done)?;
 let retry=run(binary,&attempt,out,"04-retry",16,0);assert_eq!(first,retry);
 assert_eq!(fs::read(attempt.join("record"))?,record);assert_eq!(fs::read(attempt.join("lease"))?,lease);assert_eq!(fs::read(attempt.join("cleanup.intent"))?,intent);assert_eq!(fs::read(attempt.join("cleanup.done"))?,done);
 publish_private_bytes(&formal,value)?;run(binary,&formal,out,"05-formal",16,1);assert_eq!(fs::read(formal)?,value);
 fs::write(out.join("COMPLETE"),b"original-record-and-result-retained\n")?;
 Ok(())
}'''
(app/'examples/capture.rs').write_text(code);(result/'capture.rs').write_text(code);(result/'Cargo.toml').write_text(manifest)
sys.path.insert(0,str(source/'artifact'));import rust_sdk_profile as sdk
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_'))};env.update(CARGO_HOME=str(cohort/'cargo-home'),CARGO_TARGET_DIR=str(cohort/'consumer-target'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),PATH=str(chain)+':'+env['PATH'],RUSTFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'))
def command(label,argv):
 with (result/(label+'.stdout')).open('xb',buffering=0) as stdout,(result/(label+'.stderr')).open('xb',buffering=0) as stderr:
  r=capture_output(argv,timeout_seconds=600,maximum_stdout_bytes=4*1024**2,maximum_stderr_bytes=4*1024**2,environment=env,stdout_sink=stdout.write,stderr_sink=stderr.write)
 (result/(label+'.json')).write_text(json.dumps({'argv':argv,'cwd':str(app),'exit':r.returncode},indent=2)+'\n');assert r.returncode==0,label
 return r.stdout
sdk.verify_consumed_sources(consumer,cohort,sdk_report['crates'])
os.chdir(app)
meta=json.loads(command('metadata',[str(chain/'cargo'),'metadata','--offline','--format-version','1']))
local=[p for p in meta['packages'] if p['source'] is None]
assert {p['name'] for p in local}==set(sdk.CONSUMER_CRATES)|{'q-periapt-publication-capture'}
for p in local:
 if p['name']!='q-periapt-publication-capture': assert Path(p['manifest_path'])==consumer/'packages'/f"{p['name']}-0.2.0"/'Cargo.toml'
assert sdk.external_lock((app/'Cargo.lock').read_bytes())==sdk.external_lock((consumer/'Cargo.lock').read_bytes())
command('build',[str(chain/'cargo'),'build','--example','capture','--locked','--offline','-j','2'])
executable=cohort/'consumer-target/debug/examples/capture';command('run',[str(executable),str(binary),str(result)])
assert (result/'COMPLETE').read_text()=='original-record-and-result-retained\n'
first=json.loads((result/'03-first.stdout').read_bytes());again=json.loads((result/'04-retry.stdout').read_bytes());assert first==again and (result/'03-first.stdout').read_bytes()==(result/'04-retry.stdout').read_bytes()
attempt=Path((result/'attempt-path.txt').read_text());assert first=={'schema_version':1,'operation':'private-publication-reclaim/v2','attempt':attempt.name,'outcome':'reclaimed','entries':2,'bytes':26}
record=(result/'record.bin').read_bytes();lease=(result/'lease.bin').read_bytes();intent=(result/'intent.bin').read_bytes();receipt=(result/'receipt.bin').read_bytes()
assert len(record)==154 and record[:8]==b'QPSTG002' and record[-32:]==hashlib.sha256(record[:-32]).digest()
assert lease==b'QPSTGL02'+record[10:26] and attempt.name=='.private-attempt-v2-'+record[10:26].hex()
assert len(intent)==88 and intent[:8]==b'QPSTGC02' and intent[8:40]==hashlib.sha256(record).digest() and intent[-32:]==hashlib.sha256(intent[:-32]).digest()
assert int.from_bytes(intent[40:48],'big')==2 and int.from_bytes(intent[48:56],'big')==26
assert receipt==b'QPSTGD02'+hashlib.sha256(intent).digest()
assert hashlib.sha256(binary.read_bytes()).hexdigest()==package['binary_sha256'];sdk.verify_consumed_sources(consumer,cohort,sdk_report['crates'])
(result/'RESULT.json').write_text(json.dumps({'completed':True,'source_commit':sdk_report['base_commit'],'builder_commit':package['builder_commit'],'consumer':str(app),'binary_sha256':package['binary_sha256'],'application_sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),'command_count':5,'original_result':first,'record_sha256':hashlib.sha256(record).hexdigest(),'intent_sha256':hashlib.sha256(intent).hexdigest(),'receipt_sha256':hashlib.sha256(receipt).hexdigest(),'exact_result_replayed':True,'archive_packages_unchanged':True,'publication_performed':False},indent=2)+'\n')
print('INSTALLED_ORIGINAL_PUBLICATION_CAPTURE_COMPLETE')
