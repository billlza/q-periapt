from pathlib import Path
import json,os,sys,time
root=Path.cwd();out=root/'target/continuity-managed-maintenance';sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env=dict(os.environ);env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',CARGO_TARGET_DIR=str(out/'build'),CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),PATH=str(chain)+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),RUSTFLAGS='-D warnings')
commands=[('format',[str(chain/'rustfmt'),'--edition','2021',str(root/'crates/q-periapt-host-store/src/filesystem.rs')]),('check',[str(chain/'cargo'),'test','-p','q-periapt-host-store','--lib','complete_preflight_refuses_budget_and_live_payload_owner_before_deletion','--locked','--offline','--','--nocapture'])]
for name,argv in commands:
 t=time.monotonic();r=capture_output(argv,timeout_seconds=600,maximum_stdout_bytes=2*1024**2,maximum_stderr_bytes=2*1024**2,environment=env)
 (out/(name+'-05.stdout')).write_bytes(r.stdout);(out/(name+'-05.stderr')).write_bytes(r.stderr);(out/(name+'-05.json')).write_text(json.dumps({'argv':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-t},indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:print(r.stderr.decode()[-10000:]);sys.exit(r.returncode)
