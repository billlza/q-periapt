from pathlib import Path
import json,os,sys,time
root=Path.cwd();out=root/'target/continuity-managed-maintenance';sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env=dict(os.environ);env.update(CARGO_BUILD_JOBS='2',CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',CARGO_TARGET_DIR=str(out/'candidate-build'),CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),PATH=str(chain)+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),RUSTFLAGS='-D warnings')
commands=[("candidate-release-runtime",['/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/target/continuity-managed-maintenance/candidate-build/release/deps/q_periapt_continuity_identity_candidate-d3eb26eb6c704353',"--nocapture"])]
for name,argv in commands:
 t=time.monotonic(); receipt={'argv':argv,'timeout_seconds':600,'completed':False}
 try:
  with (out/(name+'-26.stdout')).open('xb',buffering=0) as stdout, (out/(name+'-26.stderr')).open('xb',buffering=0) as stderr:
   r=capture_output(argv,timeout_seconds=600,maximum_stdout_bytes=2*1024**2,maximum_stderr_bytes=2*1024**2,environment=env,stdout_sink=stdout.write,stderr_sink=stderr.write)
  receipt.update(exit=r.returncode,completed=True)
 except Exception as e:
  receipt.update(error_type=type(e).__name__,error=str(e)); raise
 finally:
  receipt['elapsed_seconds']=time.monotonic()-t
  (out/(name+'-26.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode: print(r.stderr.decode()[-10000:]);sys.exit(r.returncode)
 if name!='candidate-clippy' and b'test result: ok. 0 passed;' in r.stdout: raise RuntimeError('selected test body absent')
