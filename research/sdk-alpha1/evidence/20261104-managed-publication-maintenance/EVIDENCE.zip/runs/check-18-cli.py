from pathlib import Path
import json,os,sys,time
root=Path.cwd();out=root/'target/continuity-managed-maintenance';sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env=dict(os.environ);env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',CARGO_TARGET_DIR=str(out/'build'),CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),PATH=str(chain)+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),RUSTFLAGS='-D warnings')
commands=[('cli-format',[str(chain/'rustfmt'),'--edition','2021',str(root/'crates/q-periapt-cli/tests/publication_maintenance.rs')]),('cli-target-test',[str(chain/'cargo'),'test','-p','q-periapt-cli','--test','publication_maintenance','--features','policy-store-migration,publication-maintenance','--locked','--offline','--','--nocapture']),('cli-clippy',[str(chain/'cargo-clippy'),'clippy','-p','q-periapt-cli','--all-targets','--features','policy-store-migration,publication-maintenance','--locked','--offline','--','-D','warnings']),('cli-default',[str(chain/'cargo'),'check','-p','q-periapt-cli','--no-default-features','--locked','--offline'])]
for name,argv in commands:
 t=time.monotonic(); receipt={'argv':argv,'timeout_seconds':600,'completed':False}
 try:
  with (out/(name+'-18.stdout')).open('xb',buffering=0) as stdout, (out/(name+'-18.stderr')).open('xb',buffering=0) as stderr:
   r=capture_output(argv,timeout_seconds=600,maximum_stdout_bytes=2*1024**2,maximum_stderr_bytes=2*1024**2,environment=env,stdout_sink=stdout.write,stderr_sink=stderr.write)
  receipt.update(exit=r.returncode,completed=True)
 except Exception as e:
  receipt.update(error_type=type(e).__name__,error=str(e)); raise
 finally:
  receipt['elapsed_seconds']=time.monotonic()-t
  (out/(name+'-18.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode: print(r.stderr.decode()[-10000:]);sys.exit(r.returncode)
 if name=='cli-target-test' and b'test result: ok. 0 passed;' in r.stdout: raise RuntimeError('selected test body absent')
