from pathlib import Path
import hashlib,json,subprocess,zipfile,datetime,os
root=Path.cwd();raw=root/'target/continuity-managed-maintenance';source=raw/'source-f560d803';sdk=source/'target/managed-sdk-cohort';package=source/'target/managed-native-maintenance-27';windows=root/'target/windows-typecheck-1.98.1-hn2792f5';evidence=root/'research/sdk-alpha1/evidence/20261104-managed-publication-maintenance'
evidence.mkdir(mode=0o755,parents=True,exist_ok=False)
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
report=read(sdk/'RUST_SDK_PACKAGE.json');native=read(package/'RESULT.json');capture=read(raw/'installed-original-capture-28/RESULT.json');ci=read(raw/'ci-final.json')
assert report['base_commit']==native['source_commit']==capture['source_commit']=='f560d803c43a24fff222daa5e5e5bd623bfdf874'
assert report['sources_unchanged'] and not report['diagnostic_only'] and native['completed'] and capture['completed']
assert native['binary_sha256']==capture['binary_sha256'];assert native['builder_commit']=='7429f655bd48c1fb3997fc866d6ef048d7e758cf'
assert all(read(raw/n)['exit']==0 for n in ['check-13.json','host-release-13.json','clippy-13.json','candidate-installation-17.json','candidate-provisioning-17.json','candidate-import-cut-17.json','candidate-successive-import-cut-17.json','candidate-clippy-17.json','cli-target-test-19.json','cli-clippy-19.json','cli-default-19.json','sdk-cohort-24.json','maintenance-package-27.json'])
assert read(raw/'candidate-release-22.json')['error_type']=='BoundedProcessError' and read(raw/'candidate-release-runtime-26.json')['error_type']=='BoundedProcessError'
assert 'timed out after 600 seconds' in (raw/'candidate-check-13-driver.stderr').read_text()
# Independently re-read retained public metadata and compare its original scope.
c=raw/'installed-original-capture-28';attempt=Path((c/'attempt-path.txt').read_text());record=(c/'record.bin').read_bytes()
assert record[8:10]==bytes([1,2]);assert record[90:122]==hashlib.sha256(b'Q-PERIAPT-PRIVATE-PUBLICATION-DESTINATION/v2\0'+bytes([1])+b'formal').digest()
for offset,path in [(26,attempt.parent),(42,attempt),(58,attempt/'lease')]:
 st=path.stat();assert record[offset:offset+16]==st.st_dev.to_bytes(8,'little')+st.st_ino.to_bytes(8,'little')
assert (attempt/'record').read_bytes()==record and (attempt/'cleanup.intent').read_bytes()==(c/'intent.bin').read_bytes() and (attempt/'cleanup.done').read_bytes()==(c/'receipt.bin').read_bytes()
assert (attempt.parent/'formal').read_bytes()==b'original unpublished bytes' and not (attempt/'payload').exists()
assert (c/'03-first.stdout').read_bytes()==(c/'04-retry.stdout').read_bytes()
# One public checkpoint retains every unique local failure and its subsequent
# result. Large tool/source downloads remain in the private reproducibility tree.
items={}
def add_tree(base,prefix,recursive=False,maximum=8*1024**2):
 paths=base.rglob('*') if recursive else base.iterdir()
 for p in sorted(paths):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.py','.stdout','.stderr','.diff','.md','.txt','.bin','.exit','.rs','.toml'} and p.stat().st_size<=maximum:
   items[prefix+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
add_tree(raw,'runs');add_tree(raw/'reproduce-parallel','runs/reproduce-parallel');add_tree(c,'installed-original');add_tree(sdk,'sdk-cohort');add_tree(package,'maintenance-package');add_tree(package/'installed','maintenance-package/installed',True);add_tree(source/'target/managed-native-maintenance','maintenance-package-original-warning');add_tree(windows,'windows')
items['installed-original/COMPLETE']=(c/'COMPLETE').read_bytes()
items['maintenance-package/MANIFEST.json']=(Path(native['installed'])/'MANIFEST.json').read_bytes()
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',report['base_commit']],text=True).splitlines()
for name in changed: items['source/'+name]=subprocess.check_output(['git','show',report['base_commit']+':'+name])
items['source/documentation-followup.diff']=subprocess.check_output(['git','diff',report['base_commit'],native['builder_commit'],'--','docs/PRIVATE_PUBLICATION_MAINTENANCE.md','docs/continuity/UPGRADE_MAINTENANCE_V1.md'])
items['source/installed-capture-Cargo.lock']=(Path(capture['consumer'])/'Cargo.lock').read_bytes()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(items.items())}
archive=evidence/'EVIDENCE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(items.items()):
  info=zipfile.ZipInfo(name,(2026,11,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
(evidence/'FILES.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
result={'schema':'qperiapt.managed-publication-maintenance/2','implementation_commit':report['base_commit'],'documentation_builder_commit':native['builder_commit'],'host':read(raw/'HOST.json'),'source_validation':{'host_store_debug_cases':73,'host_store_release_cases':73,'host_store_clippy':True,'candidate_focused_cases':88,'candidate_all_target_clippy':True,'cli_publication_test':True,'cli_all_target_clippy':True,'cli_default_build':True,'python_quality_cases':67},'full_candidate_aggregates':{'debug_build_and_test_600_seconds':'timed_out_partial_log_not_retained','release_build_and_test_600_seconds':'timed_out_streams_retained','release_runtime_only_600_seconds':'timed_out_streams_retained','completed':False,'runtime_timeout_not_explained_by_compilation_alone':True},'sdk_archives':{'count':len(report['crates']),'report_sha256':sha((sdk/'RUST_SDK_PACKAGE.json').read_bytes()),'installed_consumer':report['consumer'],'source_inputs_unchanged':True},'native_maintenance_package':native,'original_public_capture':capture,'windows':{'gnu_check_and_clippy':True,'host_store_sources_rechecked':29,'msvc_check':'blocked_at_real_C_string_h_before_host_store','runtime_or_ntfs_execution':False},'ci':{'observed_utc':ci['observed_utc'],'counts':ci['counts'],'prs':ci['prs'],'remote_mutations':False},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members':len(items),'uncompressed_bytes':sum(map(len,items.values()))},'not_closed':['full candidate aggregate execution','Linux and actual Windows maintenance qualification','new Continuity installed-peer lifecycle with this SDK cohort','legacy or incomplete publication-control disposition','formal ABI and contract admission','final CI and supported platform gates','external security review','explicit final release authorization'],'publication_performed':False,'release_claim_eligible':False}
(evidence/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'evidence':str(evidence),'archive':result['archive'],'native_binary_sha256':native['binary_sha256']},indent=2))
