from pathlib import Path
import json,os,sys,time
root=Path.cwd();out=root/'target/continuity-managed-maintenance/reproduce-parallel';out.mkdir();sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
binary=root/'target/continuity-managed-maintenance/build/debug/deps/q_periapt_host_store-9ce356c282b22892'
for index in range(1,21):
 argv=[str(binary),'filesystem::maintenance::','--nocapture'];started=time.monotonic();r=capture_output(argv,timeout_seconds=60,maximum_stdout_bytes=1024**2,maximum_stderr_bytes=1024**2)
 name=f'{index:02}';(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);(out/(name+'.json')).write_text(json.dumps({'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-started,'purpose':'bounded diagnostic reproduction; no failed aggregate is superseded'},indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:
  print(r.stderr.decode());break
