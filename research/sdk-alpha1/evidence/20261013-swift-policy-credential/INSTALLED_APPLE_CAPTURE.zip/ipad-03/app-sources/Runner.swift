import Foundation
import Darwin
import QPeriaptContinuity

@main
struct ContinuityIOSRunner {
    static func main() async {
        do {
            // Qualification startup grace: let CoreDevice establish console/PID
            // observation before a short refusal or reopen path can exit.
            try await Task.sleep(for: .milliseconds(500))
            let argv = Array(CommandLine.arguments.dropFirst())
            guard argv.count == 6, argv.allSatisfy({ !$0.isEmpty && $0.utf8.count < 128 }),
                  ["fixed", "recoverable"].contains(argv[1]),
                  argv[2].count == 32, argv[2].allSatisfy({ "0123456789abcdef".contains($0) }),
                  argv[3].count == 32, argv[3].allSatisfy({ "0123456789abcdef".contains($0) }) else {
                throw ClientError("explicit operation/profile/case/run required")
            }
            let mode = argv[0], profile = argv[1], scenario = argv[2], run = argv[3]
            print("QPC_IOS_CLOCK run=\(run) seconds=\(Int64(Date().timeIntervalSince1970))")
            let carrier = argv[4], managed = argv[5] == "managed"
            guard ["none", "signed", "tls"].contains(carrier), ["managed", "unmanaged"].contains(argv[5]) else { throw ClientError("carrier/registry selection") }
            let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let input = documents.appendingPathComponent((mode == "policy-target-create" ? "policy-inputs-" : "inputs-") + scenario, isDirectory: true)
            let privateRoot = documents.appendingPathComponent("private-continuity", isDirectory: true)
            if !FileManager.default.fileExists(atPath: privateRoot.path) {
                try FileManager.default.createDirectory(at: privateRoot, withIntermediateDirectories: false,
                    attributes: [.posixPermissions: 0o700])
            }
            guard let resolved = realpath(privateRoot.path, nil) else {
                throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
            }
            let canonicalRoot = String(cString: resolved)
            free(resolved)
            let base = canonicalRoot + "/installation-" + scenario
            let target = URL(fileURLWithPath: base, isDirectory: true)
            let operationPath = mode == "policy-target-create" ? base + ".policy-target" : base
            let output = documents.appendingPathComponent("result-" + run + ".bin")
            if mode == "activate-expired" { try await waitUntilExpired(input: input, run: run) }
            if mode == "resume" {
                try storageBoundary(input: input.path, target: base, profile: profile, output: output.path + ".refused", run: run)
            }
            var arguments = ["ContinuityIOSRunner", mode, profile, input.path,
                mode == "cancel-create" || mode == "arc-capacity" ? base + "." + run : operationPath, output.path]
            if carrier != "none" { arguments.append(carrier) }
            if managed { arguments.insert(contentsOf: ["--registry", base + ".authority"], at: 1) }
            if mode == "activate" && FileManager.default.fileExists(atPath: input.appendingPathComponent("tamper-witness-cache").path) {
                guard try FileManager.default.contentsOfDirectory(atPath: target.path).allSatisfy({ !$0.hasPrefix("witness-") }) else {
                    throw ClientError("unexpected witness cache in original private installation")
                }
                for name in ["witness-id", "witness-public", "witness-tls-peer", "witness-tls-key"] {
                    try Data(repeating: 0, count: 32).write(to: target.appendingPathComponent(name), options: .withoutOverwriting)
                }
            }
            if mode == "authority-create" {
                guard managed else { throw ClientError("authority creation requires explicit selection") }
                try createRegistry(source: input, path: base + ".authority", output: output)
            } else if carrier != "none" || ["connect", "uncertain-send", "retry-send", "retry-credential", "retry-policy"].contains(mode) {
                try await usbOperation(arguments: arguments, source: input, mode: mode, run: run)
            } else {
                try ConfigurationCommands.run(arguments)
            }
            if ["create", "resume", "reconcile", "enroll-local"].contains(mode) {
                let required = ["wrap.key", "signer.key", "enrollment.redb"] + (mode == "enroll-local" ? ["installation.redb"] : [])
                guard required.allSatisfy({ FileManager.default.fileExists(atPath: target.appendingPathComponent($0).path) }) else {
                    throw ClientError("missing original private storage")
                }
            }
            let marker = "QPC_IOS_CONFIGURATION_PASS mode=\(mode) profile=\(profile) run=\(run)\n"
            let receipt = documents.appendingPathComponent("receipt-" + run + ".txt")
            try Data(marker.utf8).write(to: receipt, options: .withoutOverwriting)
            try FileHandle.standardOutput.write(contentsOf: Data(marker.utf8))
            exit(0)
        } catch {
            let message = "QPC_IOS_CONFIGURATION_FAIL \(error)\n"
            do {
                let args = Array(CommandLine.arguments.dropFirst())
                if args.count == 6, args[3].count == 32, args[3].allSatisfy({ "0123456789abcdef".contains($0) }) {
                    let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                    try Data(message.utf8).write(to: documents.appendingPathComponent("failure-" + args[3] + ".txt"), options: .withoutOverwriting)
                }
                try FileHandle.standardOutput.write(contentsOf: Data(message.utf8))
                try await Task.sleep(for: .milliseconds(500))
            } catch {
                print("QPC_IOS_DIAGNOSTIC_FAILURE \(error)")
                exit(74)
            }
            exit(1)
        }
    }
}

private func storageBoundary(input: String, target: String, profile: String, output: String, run: String) throws {
    let alias = target + ".alias-" + run
    guard symlink(target, alias) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let linkOutcome = Result { try expect(203) {
        try ConfigurationCommands.run(["ContinuityIOSRunner", "resume", profile, input, alias, output])
    } }
    guard unlink(alias) == 0 else { throw ClientError("test alias cleanup failed") }
    try linkOutcome.get()
    let permissions = try FileManager.default.attributesOfItem(atPath: target)[.posixPermissions] as? NSNumber
    guard permissions?.intValue == 0o700 else { throw ClientError("unexpected private target permissions") }
    guard chmod(target, 0o755) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let modeOutcome = Result { try expect(203) {
        try ConfigurationCommands.run(["ContinuityIOSRunner", "resume", profile, input, target, output])
    } }
    guard chmod(target, 0o700) == 0 else { throw ClientError("private permissions restoration failed") }
    try modeOutcome.get()
    guard !FileManager.default.fileExists(atPath: output) else { throw ClientError("refused path produced output") }
    print("QPC_IOS_STORAGE_BOUNDARY_PASS symlink=203 mode=203")
}

// Qualification barrier only: the SDK still verifies and rejects the signed expired policy.
private func waitUntilExpired(input: URL, run: String) async throws {
    let wire = try load(input, "protocol-policy", 8192)
    guard wire.count >= 68, Array(wire[4..<12]) == Array("QPSESP03".utf8) else {
        throw ClientError("fixture policy framing for expiration barrier")
    }
    let until = try counter(wire[60..<68])
    let deadline = ContinuousClock.now.advanced(by: .seconds(5))
    func now() throws -> UInt64 {
        let value = Date().timeIntervalSince1970
        guard value >= 0, value < Double(UInt64.max) else { throw ClientError("device clock range") }
        return UInt64(value)
    }
    while try now() < until {
        guard ContinuousClock.now < deadline else { throw ClientError("device clock has not reached signed expiry within five seconds") }
        try await Task.sleep(for: .milliseconds(100))
    }
    print("QPC_IOS_EXPIRY_CLOCK run=\(run) seconds=\(try now()) until=\(until)")
}
