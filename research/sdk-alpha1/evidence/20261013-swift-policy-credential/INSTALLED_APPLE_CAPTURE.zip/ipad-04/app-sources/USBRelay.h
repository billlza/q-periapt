#include <stdint.h>
/* Qualification-only opaque stream relay. All descriptors have explicit owners. */
int qpc_test_relay_prepare(int descriptors[4], uint16_t ports[2]);
int qpc_test_relay_run(int transport_listener, int local_listener, int cancellation,
    uint16_t transport_port, const char *route, const char *run);
int qpc_test_relay_stop(int cancellation);

/* Host must observe this run before any SDK operation may begin. */
int qpc_test_startup_wait(const char *run);
