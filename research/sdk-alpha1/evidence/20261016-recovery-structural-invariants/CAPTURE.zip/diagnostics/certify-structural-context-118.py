"""Discharge four structural facts using independently replayed certificates."""
from pathlib import Path
import importlib.util
import json
import re
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('counter_model_check', stage / 'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None, 'model checker missing')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
root_name = 'ready_root_is_initial_or_hashed'
state_name = 'produced_state_role_and_epoch_have_public_constructors'
counter = 'produced_counter_has_public_constructor'
application = 'application_counter_has_public_constructor'
state_record = json.loads((stage / 'STATE_SHAPE_CERTIFIED_113.json').read_text())
prepared = json.loads((stage / 'ROOT_INDEPENDENT_PREPARED_116.json').read_text())
replay = json.loads((stage / 'root-independent-replay-117-TERMINAL.json').read_text())
sdk.require(state_record['completed'], 'state context is unqualified')
sdk.require(replay['accepted'] and replay['returncode'] == 0 and not replay['timed_out'] and not replay['output_exceeded'], 'root independent replay failed')
sdk.require(replay['required_verified_lemmas'] == [root_name] and replay['results'] == {root_name: {'mode': 'all-traces', 'status': 'verified', 'steps': 8}}, 'root verdict inventory differs')
sdk.require(not any(arg.startswith(('--prove', '--oraclename')) for arg in replay['argv']), 'independent replay used search')
sdk.require(replay['input_sha256'] == prepared['output_sha256'] == sdk.snapshot(stage / 'root-independent-116.spthy').sha256, 'root input changed')
sdk.require(replay['output_sha256'] == sdk.snapshot(stage / 'root-independent-replay-117-proof.spthy').sha256, 'root certificate changed')
sdk.require(state_record['replay']['output_sha256'] == sdk.snapshot(stage / 'state-shape-replay-110-proof.spthy').sha256, 'state certificate changed')
sources = {
    'root': stage / 'root-independent-replay-117-proof.spthy',
    'state': stage / 'state-shape-replay-110-proof.spthy',
    'context': stage / 'root-shape-112-proof.spthy',
    'canonical': root / 'research/continuity-recovery-symbolic/multi-epoch.spthy',
}
parsed = {name: model.parsed('structural-'+name+'-118', path) for name, path in sources.items()}
operational = model.operational(parsed['canonical'])[0]
sdk.require(all(model.operational(value)[0] == operational for value in parsed.values()), 'proofs refer to different execution models')
queries = {name: model.queries(value) for name, value in parsed.items()}
sdk.require(queries['root'] == {root_name: queries['context'][root_name]}, 'complete root formula differs')
sdk.require({name: declaration for name, declaration in queries['context'].items() if name != root_name} == queries['state'], 'state proof context differs')
prior = dict(queries['state'])
del prior[state_name]
for name in (counter, application):
    sdk.require(prior[name].count('[use_induction, reuse]') == 1, 'counter annotation differs')
    prior[name] = prior[name].replace('[use_induction, reuse]', '[use_induction]')
sdk.require(prior == queries['canonical'], 'an original complete obligation changed')
sdk.require(next(iter(queries['state'])) == state_name and '[' not in queries['root'][root_name].split(':', 1)[0], 'an independent lemma acquired earlier premises')
sdk.require(not any('sources' in declaration.split(':', 1)[0] for declarations in queries.values() for declaration in declarations.values()), 'global sources premise')
summary = (stage / 'root-independent-replay-117.stdout').read_text().rsplit('summary of summaries:', 1)[-1]
rows = re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \(([1-9][0-9]*) steps\)', summary, re.M)
sdk.require(rows == [(root_name, 'all-traces', 'verified', '8')], 'raw root verdict differs')
sdk.require(re.search(r'(?im)^\s*(?:warning|error|fatal)\b', (stage / 'root-independent-replay-117.stderr').read_text()) is None, 'root replay diagnostic failure')
for label in ('state-shape-replay-110', 'root-shape-replay-114', 'root-independent-replay-117'):
    started = json.loads((stage / (label+'-STARTED.json')).read_text())
    process = subprocess.run(['/bin/ps', '-p', str(started['pid']), '-o', 'pid='], capture_output=True, text=True)
    sdk.require(process.returncode == 1 and not process.stdout.strip(), 'owned prover remains live')
oracle = sdk.snapshot(stage / 'root-oracle-111.jsonl')
records = [json.loads(line) for line in oracle.data.decode().splitlines()]
for record in records:
    numbers = [number for number, _ in record['goals']]
    sdk.require(len(set(numbers)) == len(numbers) and sorted(record['ranking']) == sorted(numbers), 'oracle omitted or duplicated a goal')
sdk.require(not (stage / 'root-oracle-111.failed').exists(), 'search oracle failed')
sdk.write_json(stage / 'STRUCTURAL_CONTEXT_CERTIFIED_118.json', {
    'completed': True,
    'verified_properties': {root_name: 8, state_name: 191, counter: 35, application: 17},
    'dependency_graph': {root_name: [], state_name: [], counter: [], application: [counter]},
    'certificate_sha256': {name: sdk.snapshot(path).sha256 for name, path in sources.items()},
    'receipts': {name: sdk.snapshot(stage / name).sha256 for name in ('STATE_SHAPE_CERTIFIED_113.json', 'state-shape-replay-110-TERMINAL.json', 'ROOT_INDEPENDENT_PREPARED_116.json', 'root-independent-replay-117-TERMINAL.json', 'root-shape-replay-114-TERMINAL.json')},
    'all_original_seven_complete_queries_preserved': True,
    'operational_model_identical_across_certificates': True,
    'global_sources_premises': [],
    'oracle_log_sha256': oracle.sha256,
    'oracle_used_only_for_search': True,
    'combined_replay_114_timed_out_and_is_not_accepted': True,
    'not_established': ['authentication', 'root entropy', 'root secrecy', 'generation-secret origin', 'multi-epoch recovery', 'SDK refinement'],
    'release_claim_eligible': False,
})
print('Four structural facts have complete independently replayed, acyclic proof dependencies')
