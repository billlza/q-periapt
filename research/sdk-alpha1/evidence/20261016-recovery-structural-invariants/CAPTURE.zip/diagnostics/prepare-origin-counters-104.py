"""Use both fully checked counter proofs for the unchanged epoch-origin query."""
from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
receipt=json.loads((stage/'COUNTER_BRIDGE_CERTIFIED_96.json').read_text())
sdk.require(receipt['completed'] and receipt['actual_missing_dependency_control_rejected'],'counter conjunction unqualified')
source=stage/'counter-bridge-replay-94-proof.spthy'
sdk.require(sdk.snapshot(source).sha256=='9200b7df1dcf78b91463d11182fb98ef86c76a33aabe73b87680e84a4279c2b3','checked source changed')
before=source.read_text()
old='lemma application_counter_has_public_constructor [use_induction]:'
new='lemma application_counter_has_public_constructor [use_induction, reuse]:'
sdk.require(before.count(old)==1,'application counter declaration differs')
after=before.replace(old,new,1)
sdk.require(after.replace(new,old,1)==before,'change beyond proof reuse')
output=stage/'origin-counters-104.spthy'
with output.open('x') as stream:stream.write(after)
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-origin-counters-104',root)
sdk.write_json(stage/'ORIGIN_COUNTERS_PREPARED_104.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'only_change':'Make the independently replayed application-counter property reusable; retain both complete 35/17-step proofs.',
 'all_seven_complete_formulas_and_operational_model_unchanged':True,
 'required_verified_lemmas':['produced_counter_has_public_constructor','application_counter_has_public_constructor','epoch_generation_secret_derivation_origin'],
 'new_assumption_restriction_or_round_bound':False,
})
print('Unchanged origin conjecture prepared with both checked counter dependencies')
