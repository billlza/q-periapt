"""Use only independently certified structural facts in a new origin search."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
receipt = json.loads((stage / 'STRUCTURAL_CONTEXT_CERTIFIED_118.json').read_text())
sdk.require(receipt['completed'], 'structural context unqualified')
source = stage / 'root-shape-112-proof.spthy'
snapshot = sdk.snapshot(source)
sdk.require(snapshot.sha256 == receipt['certificate_sha256']['context'], 'context changed')
text = snapshot.data.decode()
declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
matches = list(declaration.finditer(text))
sdk.require(len(matches) == 9, 'query inventory differs')
helpers = list(receipt['verified_properties'])
sdk.require(set(matches[index][1] for index in range(4)) == set(helpers), 'helpers are not first')
parts = [text[:matches[0].start()]]
for match in matches:
    entry = match.group()
    if match[1] in helpers and 'reuse' not in (match[2] or ''):
        if match[2]:
            entry = entry.replace('['+match[2]+']', '['+match[2]+', reuse]', 1)
        else:
            entry = entry.replace('lemma '+match[1]+':', 'lemma '+match[1]+' [reuse]:', 1)
    parts.append(entry+'\nby sorry\n\n')
after = ''.join(parts)+'end\n'
output = stage / 'origin-structural-119.spthy'
with output.open('x') as stream:
    stream.write(after)
sdk.write_json(stage / 'ORIGIN_STRUCTURAL_PREPARED_119.json', {
    'source_sha256': snapshot.sha256, 'output_sha256': sdk.snapshot(output).sha256,
    'structural_certificate_receipt_sha256': sdk.snapshot(stage / 'STRUCTURAL_CONTEXT_CERTIFIED_118.json').sha256,
    'helpers_require_external_proof_composition': helpers,
    'all_nine_complete_formulas_preserved': [match.group().split('"', 1)[1] for match in matches] == [match.group().split('"', 1)[1] for match in declaration.finditer(after)],
    'operational_prefix_preserved_verbatim': after[:after.index('\nlemma ')] == text[:text.index('\nlemma ')],
    'search_alone_cannot_establish_complete_conjunction': True,
    'release_claim_eligible': False,
})
print('Prepared a conditional origin search with four separately certified premises')
