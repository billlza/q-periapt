"""Add independently proved structural obligations to the unchanged epoch model."""
from pathlib import Path
import importlib.util
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == 'b2f42049999eba3f7dc27ae9d75207c90a0f9a33', 'integration base differs')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip(), 'uncommitted source changes')
qualified = json.loads((stage/'STRUCTURAL_CONTEXT_CERTIFIED_118.json').read_text())
sdk.require(qualified['completed'], 'structural proofs are incomplete')
canonical = root/'research/continuity-recovery-symbolic/multi-epoch.spthy'
old = sdk.snapshot(canonical)
sdk.require(old.sha256 == qualified['certificate_sha256']['canonical'], 'canonical source changed')
with (stage/'canonical-before-121.spthy').open('xb') as output:
    output.write(old.data)
addition = '''/* Independent certificates establish these structural properties without
   earlier reusable premises. They do not establish root secrecy or agreement. */
lemma ready_root_is_initial_or_hashed:
 "All s role epoch root parent #ready.
    ReadyState(s,role,epoch,root,parent)@ready
    ==> (epoch = 'zero') | (Ex material. root = h(material))"

lemma produced_state_role_and_epoch_have_public_constructors [use_induction]:
 "All s role epoch counter #produced.
    CounterState(s,role,epoch,counter)@produced
    ==> ((role = 'A') | (role = 'B'))
      & ((epoch = 'zero') | (Ex previous. epoch = succ(previous)))"

'''
before = old.data.decode()
anchor = '/* The two counter-constructor properties have complete checked proofs.'
sdk.require(before.count(anchor) == 1, 'insertion point differs')
after = before.replace(anchor, addition+anchor, 1)
sdk.require(after.replace(addition, '', 1) == before, 'an existing declaration changed')
canonical.write_text(after)
spec = importlib.util.spec_from_file_location('counter_model_check', stage/'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None, 'model checker missing')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
integrated = model.parsed('integrated-structural-121', canonical)
expected = (stage/'structural-context-118-parse-89.stdout').read_text()
queries = model.queries(expected)
for name in ('produced_counter_has_public_constructor', 'application_counter_has_public_constructor'):
    queries[name] = queries[name].replace('[use_induction, reuse]', '[use_induction]')
sdk.require(model.queries(integrated) == queries and model.operational(integrated)[0] == model.operational(expected)[0], 'integration changed the complete statements or execution model')
sdk.require(not any('reuse' in value.split(':', 1)[0] or 'sources' in value.split(':', 1)[0] for value in queries.values()), 'bare model has reusable assumptions')
sdk.command(['git', 'diff', '--check'], stage/'integrated-structural-diff-121', root)
sdk.write_json(stage/'STRUCTURAL_INTEGRATED_121.json', {'completed': True, 'base_commit': 'b2f42049999eba3f7dc27ae9d75207c90a0f9a33', 'previous_model_sha256': old.sha256, 'integrated_model_sha256': sdk.snapshot(canonical).sha256, 'qualified_receipt_sha256': sdk.snapshot(stage/'STRUCTURAL_CONTEXT_CERTIFIED_118.json').sha256, 'all_nine_complete_statements_match_qualified_context': True, 'old_seven_declarations_and_operational_model_unchanged': True, 'bare_model_has_reusable_assumptions': False, 'release_claim_eligible': False})
print('Integrated two independently proved structural obligations; original protocol and seven queries unchanged')
