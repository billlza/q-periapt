"""Independently check role/epoch shape with complete source and query identity."""
from pathlib import Path
import importlib.util
import json
import re
import subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('counter_model_check',stage/'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None,'model checker missing')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
search=json.loads((stage/'state-shape-109-TERMINAL.json').read_text())
replay=json.loads((stage/'state-shape-replay-110-TERMINAL.json').read_text())
prepared=json.loads((stage/'STATE_SHAPE_PREPARED_108.json').read_text())
theorem='produced_state_role_and_epoch_have_public_constructors'
verified={theorem:191,'produced_counter_has_public_constructor':35,'application_counter_has_public_constructor':17}
sdk.require(search['accepted'] and replay['accepted'] and replay['returncode']==0 and not replay['timed_out'] and not replay['output_exceeded'],'independent replay incomplete')
sdk.require(not any(arg.startswith('--prove') for arg in replay['argv']) and set(replay['required_verified_lemmas'])==set(verified),'replay scope or mode differs')
sdk.require(search['input_sha256']==prepared['output_sha256']==sdk.snapshot(stage/'state-shape-108.spthy').sha256,'search input changed')
sdk.require(replay['input_sha256']==search['output_sha256']==sdk.snapshot(stage/'state-shape-109-proof.spthy').sha256,'replay input changed')
sdk.require(replay['output_sha256']==sdk.snapshot(stage/'state-shape-replay-110-proof.spthy').sha256,'replay output changed')
source=model.parsed('state-source-113',stage/'state-shape-108.spthy')
checked=model.parsed('state-replay-113',stage/'state-shape-replay-110-proof.spthy')
canonical=model.parsed('state-canonical-113',root/'research/continuity-recovery-symbolic/multi-epoch.spthy')
queries=model.queries(source)
sdk.require(len(queries)==8 and next(iter(queries))==theorem,'independent query is not first')
sdk.require('[use_induction]:' in queries[theorem] and 'sources' not in '\n'.join(q.split(':',1)[0] for q in queries.values()),'unexpected source premise')
sdk.require(queries==model.queries(checked) and model.operational(source)[0]==model.operational(checked)[0]==model.operational(canonical)[0],'model or complete statements changed')
prior=dict(queries);del prior[theorem]
for name in ('produced_counter_has_public_constructor','application_counter_has_public_constructor'):
    sdk.require(prior[name].count('[use_induction, reuse]')==1,'counter reuse context differs')
    prior[name]=prior[name].replace('[use_induction, reuse]','[use_induction]')
sdk.require(prior==model.queries(canonical),'canonical seven complete obligations changed')
summary=(stage/'state-shape-replay-110.stdout').read_text().rsplit('summary of summaries:',1)[-1]
rows=re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \(([1-9][0-9]*) steps\)',summary,re.M)
sdk.require(len(rows)==8 and {r[0] for r in rows}==set(queries),'raw verdict inventory differs')
for name,mode,status,steps in rows:
    sdk.require((status,int(steps))==(('verified',verified[name]) if name in verified else ('analysis incomplete',1)),'raw verdict differs')
    sdk.require(mode==('exists-trace' if 'exists-trace' in queries[name].split('"',1)[0] else 'all-traces'),'raw quantifier differs')
sdk.require(re.search(r'(?im)^\s*(?:warning|error|fatal)\b',(stage/'state-shape-replay-110.stderr').read_text()) is None,'replay diagnostics failed')
started=json.loads((stage/'state-shape-replay-110-STARTED.json').read_text())
process=subprocess.run(['/bin/ps','-p',str(started['pid']),'-o','pid='],capture_output=True,text=True)
sdk.require(process.returncode==1 and not process.stdout.strip(),'replay process remains live')
sdk.write_json(stage/'STATE_SHAPE_CERTIFIED_113.json',{
 'completed':True,'new_independent_property':theorem,'verified_properties':verified,
 'replay':replay,'all_canonical_seven_complete_obligations_preserved':True,
 'no_operational_change_or_new_observation':True,'new_property_has_no_prior_reuse_or_sources_premise':True,
 'scope':'Every produced send state has role A or B and an epoch with outer form zero or succ.',
 'not_established':['role authentication','epoch uniqueness','key secrecy','multi-epoch recovery','SDK refinement'],
 'release_claim_eligible':False,
})
print('Role/epoch shape independently replayed with the complete original model and obligations retained')
