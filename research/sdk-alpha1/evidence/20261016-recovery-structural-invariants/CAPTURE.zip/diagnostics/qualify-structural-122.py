"""Bind the integrated structural statements to a clean standalone source gate."""
from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
sdk.require(len(sys.argv) == 2 and head == sys.argv[1], 'unexpected source commit')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip(), 'source checkout is dirty')
integration = json.loads((stage/'STRUCTURAL_INTEGRATED_121.json').read_text())
model = root/'research/continuity-recovery-symbolic/multi-epoch.spthy'
sdk.require(integration['completed'] and sdk.snapshot(model).sha256 == integration['integrated_model_sha256'], 'qualified model differs')
sdk.command([sys.executable, '-B', str(root/'artifact/python_bootstrap.py'), str(root/'artifact/source_results_assembler.py'), 'ci-source-gate', sdk.snapshot(root/'artifact/results.json').sha256, head, '--profile', 'sdk-020'], stage/'source-gate-122', root)
sdk.command(['git', 'diff', '--check'], stage/'source-diff-122', root)
sdk.write_json(stage/'STRUCTURAL_QUALIFIED_122.json', {'completed': True, 'head': head, 'source_gate_passed': True, 'model_sha256': sdk.snapshot(model).sha256, 'structural_conjunction_receipt_sha256': sdk.snapshot(stage/'STRUCTURAL_CONTEXT_CERTIFIED_118.json').sha256, 'sdk_runtime_source_changed': False, 'release_claim_eligible': False})
print('Integrated structural model passed the standalone source gate: '+head)
