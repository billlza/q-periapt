"""Isolate the first, premise-free root certificate for independent replay."""
from pathlib import Path
import importlib.util
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('counter_model_check', stage / 'verify-counter-model-89.py')
sdk.require(spec is not None and spec.loader is not None, 'model checker missing')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
source = stage / 'root-shape-112-proof.spthy'
snapshot = sdk.snapshot(source)
search = json.loads((stage / 'root-shape-112-TERMINAL.json').read_text())
failed_replay = json.loads((stage / 'root-shape-replay-114-TERMINAL.json').read_text())
sdk.require(search['accepted'] and search['output_sha256'] == snapshot.sha256, 'search certificate changed')
sdk.require(not failed_replay['accepted'] and failed_replay['timed_out'], 'combined replay record differs')
before = snapshot.data.decode()
declarations = list(re.finditer(r'(?m)^lemma\s+(\w+)', before))
sdk.require(len(declarations) == 9 and declarations[0][1] == 'ready_root_is_initial_or_hashed', 'root is not the first obligation')
output = stage / 'root-independent-116.spthy'
after = before[:declarations[1].start()] + '\nend\n'
with output.open('x') as stream:
    stream.write(after)
old = model.parsed('root-original-116', source)
new = model.parsed('root-independent-116', output)
old_queries, new_queries = model.queries(old), model.queries(new)
sdk.require(new_queries == {'ready_root_is_initial_or_hashed': old_queries['ready_root_is_initial_or_hashed']}, 'root formula changed')
sdk.require(model.operational(old)[0] == model.operational(new)[0], 'execution model changed')
sdk.require('[' not in next(iter(new_queries.values())).split(':', 1)[0], 'root premise attributes changed')
sdk.write_json(stage / 'ROOT_INDEPENDENT_PREPARED_116.json', {
    'source_sha256': snapshot.sha256, 'output_sha256': sdk.snapshot(output).sha256,
    'root_statement_and_proof_body_preserved_verbatim': True,
    'complete_execution_model_preserved': True,
    'earlier_lemmas_or_global_sources': [],
    'later_obligations_not_replayed_here': [item[1] for item in declarations[1:]],
    'combined_replay_timeout_retained': failed_replay,
    'release_claim_eligible': False,
})
print('Prepared a premise-free root certificate; other properties require their independent receipts')
