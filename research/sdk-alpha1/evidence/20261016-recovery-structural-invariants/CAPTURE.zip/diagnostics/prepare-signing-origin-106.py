"""Test the existing single-exchange signing-origin formula in the full epoch model."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
source=stage/'origin-counters-104.spthy'
prepared=json.loads((stage/'ORIGIN_COUNTERS_PREPARED_104.json').read_text())
sdk.require(sdk.snapshot(source).sha256==prepared['output_sha256'],'counter context changed')
before=source.read_text()
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"([^\"]*)"')
queries=list(decl.finditer(before))
sdk.require(len(queries)==7,'source inventory differs')
position=next(m.start() for m in queries if m.group(1)=='epoch_generation_secret_derivation_origin')
addition='''lemma signing_secret_derivation_origin [use_induction]:
 "All key #created #known.
    SigningSecret(key)@created & KU(key)@known
    ==> (Ex #leaked. IdentityKeyLeak(key)@leaked)"
by sorry

'''
existing=(root/'research/continuity-recovery-symbolic/key-scoped.spthy').read_text()
existing_formula=next(m.group(2) for m in decl.finditer(existing) if m.group(1)=='signing_secret_derivation_origin')
new_formula=next(decl.finditer(addition)).group(2)
sdk.require(re.sub(r'\s+','',existing_formula)==re.sub(r'\s+','',new_formula),'formula differs from existing signing-origin obligation')
after=before[:position]+addition+before[position:]
new_queries=list(decl.finditer(after))
sdk.require([m.group() for m in new_queries if m.group(1)!='signing_secret_derivation_origin']==[m.group() for m in queries],'previous complete queries changed')
sdk.require(after.replace(addition,'',1)==before,'other model or proof change')
output=stage/'signing-origin-106.spthy'
with output.open('x') as stream:stream.write(after)
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-signing-origin-106',root)
sdk.write_json(stage/'SIGNING_ORIGIN_PREPARED_106.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'only_addition':'An unproved signing-key derivation-origin query; it is not a reusable premise.',
 'complete_existing_seven_queries_and_proof_bodies_unchanged':True,
 'operational_model_and_disclosure_rules_unchanged':True,
 'single_exchange_result_does_not_establish_this_unbounded_epoch_obligation':True,
 'unproved_until_complete_terminal_and_independent_replay':True,
})
print('Signing-key derivation-origin obligation parsed in the unchanged multi-epoch protocol')
