"""Rank existing proof goals; retain the exact input and permutation for review."""
from pathlib import Path
import json
import re
import sys

stage = Path(__file__).resolve().parent
log = stage / "root-oracle-111.jsonl"
failure = stage / "root-oracle-111.failed"
try:
    raw = sys.stdin.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        raise ValueError("oracle input exceeds diagnostic bound")
    goals = []
    for line in raw.splitlines():
        match = re.match(r"^([0-9]+):\s*(.*)$", line)
        if not match:
            raise ValueError("unexpected goal encoding")
        goals.append((int(match[1]), match[2]))
    if len({number for number, _ in goals}) != len(goals):
        raise ValueError("duplicate goal inventory")

    def score(item):
        _, goal = item
        if re.match(r"!?(?:ReadyState|Final8|Final7|Receipt9|Response6|Response5)\(", goal):
            return 0
        if re.match(r"(?:SendState|SendPermit|Ready)\(", goal):
            return 8
        return 1

    ranked = sorted(goals, key=score)
    entry = json.dumps({"lemma": sys.argv[1:], "goals": goals,
                        "ranking": [number for number, _ in ranked]}, ensure_ascii=False) + "\n"
    if (log.stat().st_size if log.exists() else 0) + len(entry.encode()) > 4 * 1024**2:
        raise ValueError("oracle log exceeds diagnostic bound")
    with log.open("a") as stream:
        stream.write(entry)
    for number, _ in ranked:
        print(number)
except Exception as exc:
    failure.write_text(type(exc).__name__ + ": " + str(exc))
    raise
