"""Prove role and epoch shape before using them to prune disclosure branches."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
source=stage/'origin-counters-104.spthy'
prepared=json.loads((stage/'ORIGIN_COUNTERS_PREPARED_104.json').read_text())
sdk.require(sdk.snapshot(source).sha256==prepared['output_sha256'],'checked counter context changed')
before=source.read_text()
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
old=list(decl.finditer(before));sdk.require(len(old)==7,'source query inventory differs')
addition='''lemma produced_state_role_and_epoch_have_public_constructors [use_induction]:
 "All s role epoch counter #produced.
    CounterState(s,role,epoch,counter)@produced
    ==> ((role = 'A') | (role = 'B'))
      & ((epoch = 'zero') | (Ex previous. epoch = succ(previous)))"
by sorry

'''
position=old[0].start()
after=before[:position]+addition+before[position:]
sdk.require(after.replace(addition,'',1)==before,'existing rules, statements or proof bodies changed')
new=list(decl.finditer(after));sdk.require(len(new)==8 and [m.group() for m in new[1:]]==[m.group() for m in old],'complete query inventory changed')
output=stage/'state-shape-108.spthy'
with output.open('x') as stream:stream.write(after)
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-state-shape-108',root)
sdk.write_json(stage/'STATE_SHAPE_PREPARED_108.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'only_addition':'An unproved role/epoch constructor obligation over the existing CounterState observations.',
 'new_query_precedes_all_reuse_declarations':True,'no_reuse_or_sources_premise_for_new_query':True,
 'all_existing_operational_rules_eight_complete_queries_and_proof_bodies_retained':True,
 'new_restrictions_or_round_bounds':False,
 'reason':'Origin searches still expand SendState edges with unresolved role and epoch after counter shape is known.',
 'unproved_until_terminal_and_independent_replay':True,
})
print('Independent role/epoch shape obligation parsed without new protocol observations or assumptions')
