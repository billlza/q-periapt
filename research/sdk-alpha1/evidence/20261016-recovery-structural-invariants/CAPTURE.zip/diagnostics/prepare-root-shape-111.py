"""Prove a local root-constructor obligation without using any earlier lemma."""
from pathlib import Path
import json
import re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
source=stage/'state-shape-109-proof.spthy'
receipt=json.loads((stage/'state-shape-109-TERMINAL.json').read_text())
sdk.require(receipt['accepted'] and sdk.snapshot(source).sha256==receipt['output_sha256'],'shape search certificate changed')
before=source.read_text()
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^\"]*"')
old=list(decl.finditer(before));sdk.require(len(old)==8,'shape inventory differs')
addition='''lemma ready_root_is_initial_or_hashed:
 "All s role epoch root parent #ready.
    ReadyState(s,role,epoch,root,parent)@ready
    ==> (epoch = 'zero') | (Ex material. root = h(material))"
by sorry

'''
position=old[0].start();after=before[:position]+addition+before[position:]
sdk.require(after.replace(addition,'',1)==before,'existing model or proof body changed')
new=list(decl.finditer(after));sdk.require(len(new)==9 and [m.group() for m in new[1:]]==[m.group() for m in old],'complete previous queries changed')
output=stage/'root-shape-111.spthy'
with output.open('x') as stream:stream.write(after)

oracle=(stage/'oracle-64.py').read_text()
start=oracle.index('    def score(item):\n');end=oracle.index('    ranked = sorted(goals, key=score)',start)
ranking='''    def score(item):
        _, goal = item
        if re.match(r"!?(?:ReadyState|Final8|Final7|Receipt9|Response6|Response5)\\(", goal):
            return 0
        if re.match(r"(?:SendState|SendPermit|Ready)\\(", goal):
            return 8
        return 1

'''
oracle=(oracle[:start]+ranking+oracle[end:]).replace('oracle-64','root-oracle-111')
with (stage/'root-oracle-111.py').open('x') as stream:stream.write(oracle)
launcher=stage/'root-oracle-111.sh'
with launcher.open('x') as stream:stream.write((stage/'oracle-64.sh').read_text().replace('oracle-64','root-oracle-111'))
launcher.chmod(0o700)
with (stage/'root-run-111.py').open('x') as stream:stream.write((stage/'oracle-run-64.py').read_text().replace('oracle-64','root-oracle-111'))
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sdk.command([tools['tamarin'],'--with-maude='+tools['maude'],str(output),'--parse-only','--quit-on-warning'],stage/'parse-root-shape-111',root)
sdk.write_json(stage/'ROOT_SHAPE_PREPARED_111.json',{
 'source_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256,
 'oracle_sha256':sdk.snapshot(stage/'root-oracle-111.py').sha256,
 'runner_sha256':sdk.snapshot(stage/'root-run-111.py').sha256,
 'new_query_is_first_with_no_prior_reuse_or_sources_premise':True,
 'all_eight_previous_complete_queries_and_proof_bodies_unchanged':True,
 'operational_model_and_leakage_rules_unchanged':True,
 'oracle_behavior':'Only reorder the complete goal inventory, prioritizing the finite chain of facts carrying the newly constructed root.',
 'new_restriction_axiom_or_protocol_round_bound':False,
 'scope':'Root outer shape, not entropy, secrecy, agreement or initial-root confidentiality.',
 'unproved_until_terminal_and_independent_replay':True,
})
print('Independent root-constructor obligation parsed with an explicitly logged goal ordering')
