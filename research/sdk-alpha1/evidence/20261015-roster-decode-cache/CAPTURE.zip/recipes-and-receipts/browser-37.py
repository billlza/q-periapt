from pathlib import Path
import json, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
package = json.loads((stage / 'PACKAGE_26.json').read_text())
sdk.require(package['installed_node_tests'] == 'passed' and package['sources_unchanged'], 'installed package incomplete')
source = json.loads((stage / 'BROWSER_SOURCE_36.json').read_text())
harness = stage / 'browser-harness-36'
for name, digest in source['files'].items():
    sdk.require(sdk.snapshot(harness / name).sha256 == digest, 'prepared harness changed')
sdk.command([sys.executable, '-B', str(root / 'artifact/python_bootstrap.py'), str(harness / 'run-36.py'), 'run-37', 'unapplied', 'applied'], stage / 'browser-37', root)
value = json.loads((harness / 'run-37/RESULT.json').read_text())
sdk.require(value['completed'] and value['producer_unchanged'] and len(value['observations']) == 81, 'browser continuation census incomplete')
sys.path.insert(0, str(stage))
from browser_public_review import verify
checked = verify(value)
sdk.write_json(stage / 'BROWSER_FINAL.json', {'completed': True, 'source_commit': json.loads((stage / 'CLONE_SOURCE_24.json').read_text())['source_commit'], 'package_sha256': sdk.snapshot(Path(package['archive']), maximum=128*1024**2).sha256, 'harness': str(harness), 'run_label': 'run-37', 'result_sha256': sdk.snapshot(harness / 'run-37/RESULT.json').sha256, 'observations': 81, 'runtime_sealed': True, 'independent_implementation': False, 'review': checked, 'release_claim_eligible': False, 'prior_failure': 'BROWSER_FAILURE_30.json', 'paired_bootstrap_controls': 'BOOTSTRAP_CONTROLS_33.json', 'sdk_timeouts_changed': False, 'source_changed_after_first_browser_failure': False})
print('Installed optimized browser package completed both composed continuation flows; initial failure retained separately')
