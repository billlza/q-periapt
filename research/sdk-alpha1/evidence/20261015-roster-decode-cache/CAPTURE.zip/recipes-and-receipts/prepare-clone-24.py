from pathlib import Path
import json, subprocess, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
clone = root / 'target/continuity-browser-publication/source'
candidate = stage / 'candidate-04'
base = '0037d195e2342c0c03ced5653d30b9762a5528be'
for checkout in [root, clone]:
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip() == base and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout), 'owned checkout changed')
for name in ['TARGETED_04.json', 'LINT_13.json', 'PORTABLE_08.json', 'MSRV_19.json', 'IOS_19.json', 'SUMMARY_17.json', 'COUNTS_12.json']:
    sdk.require(json.loads((stage / name).read_text())['completed'], 'prototype validation incomplete: ' + name)
scope = json.loads((stage / 'SOURCE_01.json').read_text())
tested = json.loads((stage / 'TARGETED_04.json').read_text())['candidate_files']
sdk.require(tested == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'tested candidate changed')
branch = 'lza/roster-decode-cache-validation'
sdk.command(['git', 'switch', '-c', branch], stage / 'clone-branch-24', clone)
changes = []
prefix = 'research/continuity-identity-candidate/'
for name in scope['expected_changed_original_files'] + scope['new_files']:
    path = clone / prefix / name
    sdk.require(path.exists() == (name in scope['expected_changed_original_files']), 'unexpected destination')
    before = sdk.snapshot(path).sha256 if path.exists() else None
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(sdk.snapshot(candidate / name).data)
    changes.append({'path': prefix + name, 'before_sha256': before, 'after_sha256': sdk.snapshot(path).sha256})
edits = [
    ('artifact/codeql_rust_quality.py', 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 691', 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 693', 1),
    ('ARTIFACT.md', '691 tracked `.rs` files to be successfully extracted', '693 tracked `.rs` files to be successfully extracted', 1),
    ('artifact/test_codeql_rust_quality.py', '            "research/continuity-identity-candidate/src/durable/rosters/peer_roster.rs",', '            "research/continuity-identity-candidate/src/durable/rosters/peer_roster.rs",\n            "research/continuity-identity-candidate/src/durable/rosters/decode_cache.rs",\n            "research/continuity-identity-candidate/src/durable/rosters/decode_cache/tests.rs",', 2),
]
for name, old, new, count in edits:
    path = clone / name
    before = sdk.snapshot(path)
    text = before.data.decode()
    sdk.require(text.count(old) == count, 'inventory edit scope differs')
    path.write_text(text.replace(old, new))
    changes.append({'path': name, 'before_sha256': before.sha256, 'after_sha256': sdk.snapshot(path).sha256})
sdk.command(['git', 'diff', '--check'], stage / 'clone-whitespace-24', clone)
sdk.command(['git', 'add', '--', *[r['path'] for r in changes]], stage / 'clone-stage-24', clone)
sdk.command(['git', 'commit', '-m', 'Reuse verified roster decoding within journal images'], stage / 'clone-commit-24', clone)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip()
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'experimental commit left dirty source')
sdk.require(set(subprocess.check_output(['git', 'diff', '--name-only', base, head], cwd=clone, text=True).splitlines()) == {r['path'] for r in changes}, 'experimental commit scope differs')
sdk.write_json(stage / 'CLONE_SOURCE_24.json', {'completed': True, 'base_commit': base, 'source_commit': head, 'clone': str(clone), 'branch': branch, 'changes': changes, 'main_worktree_unchanged': True, 'full_native_regression_pending': True, 'published': False})
print(json.dumps({'validation_commit': head, 'main_worktree_unchanged': True, 'changes': len(changes)}), flush=True)
sdk.command([sys.executable, '-B', str(clone / 'artifact/python_bootstrap.py'), '-m', 'unittest', 'discover', '-s', 'artifact', '-p', 'test_*.py', '-v'], stage / 'full-artifact-tests-24', clone)
sdk.command([sys.executable, '-B', str(clone / 'artifact/python_bootstrap.py'), str(clone / 'artifact/source_results_assembler.py'), 'ci-source-gate', '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda', head, '--profile', 'sdk-020'], stage / 'source-gate-24', clone)
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == head and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'validation checkout changed')
sdk.write_json(stage / 'CLONE_VALIDATION_24.json', {'completed': True, 'source_commit': head, 'full_artifact_suite': True, 'source_gate': True, 'release_claim_eligible': False, 'hosted_ci': False})
print('Full artifact suite and exact experimental-source gate passed')
