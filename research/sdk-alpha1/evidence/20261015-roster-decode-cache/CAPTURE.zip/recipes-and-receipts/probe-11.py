from pathlib import Path
import json,os,re,subprocess,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;build=json.loads((stage/'BUILD_10.json').read_text());binary=Path(build['binary'])
label=sys.argv[1];sdk.require(re.fullmatch(r'[a-z0-9-]+',label) is not None,'fresh label')
output=stage/label;output.mkdir(mode=0o700);state={'completed':False,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],'variant':'optimized with timing counters','profiles':[]}
sys.path.insert(0,str(root/'target/continuity-session-cost-20261015'))
from public_review_12 import verify
try:
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product source dirty')
    sdk.require(sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'diagnostic executable changed')
    for profile in ['local','witness']:
        folder=output/profile;folder.mkdir(mode=0o700);environment={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPERIAPT_PUBLIC_SERVICE_','QPC_COST_'))}
        environment.update(QPC_COST_PROFILE=profile,QPC_COST_SAMPLES='16',QPC_COST_OUTPUT=str(folder/'RESULT.json'),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(folder/'runtime'),RUST_BACKTRACE='1')
        print(json.dumps({'profile':profile,'phase':'fresh instrumented runtime'}),flush=True)
        raw=sdk.command(['/usr/bin/time','-l','-o',str(folder/'time.txt'),str(binary),'--exact','measure_session_cost','--nocapture','--test-threads=1'],folder/'command',root,environment=environment)
        sdk.require(re.search(rb'test result: ok\. 1 passed; 0 failed; 0 ignored;',raw) is not None,'measurement did not run')
        value=json.loads((folder/'RESULT.json').read_text());checked=verify(value)
        for name,expected in checked['effects'].items():sdk.require(sdk.snapshot(folder/'runtime/responder/measured-effects'/name,maximum=32768).data==expected,'actual business output differs')
        sdk.require(not value['probe_totals']['overflow'],'diagnostic counter overflow')
        rows=[]
        for sample in value['samples']:
            before,after=sample['probe_before'],sample['probe_after'];sdk.require(not before['overflow'] and not after['overflow'],'diagnostic counter overflow')
            sdk.require([v['name'] for v in before['phases']]==[v['name'] for v in after['phases']],'diagnostic phase inventory changed')
            delta=[]
            for first,last in zip(before['phases'],after['phases']):
                sdk.require(first['calls']<=last['calls'] and first['nanos']<=last['nanos'],'diagnostic counters reversed')
                delta.append({'name':first['name'],'calls':last['calls']-first['calls'],'nanos':last['nanos']-first['nanos']})
            rows.append({'index':sample['index'],'total_ns':sample['total_ns'],'send_ns':sample['send_ns'],'phases':delta})
        record={'profile':profile,'completed':True,'result_sha256':sdk.snapshot(folder/'RESULT.json').sha256,'samples':rows,'runtime_sealed':True}
        state['profiles'].append(record)
        print(json.dumps({'profile':profile,'completed':True,'samples':len(rows)}),flush=True)
    for name,digest in build['files'].items():sdk.require(sdk.snapshot(stage/name).sha256==digest,'diagnostic sources changed')
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'],'product source changed')
    state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(output/'RUN.json',state)
print('Fixed-phase timing collection complete; all private runtime cohorts sealed')
