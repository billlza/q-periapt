from pathlib import Path
import copy, json, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'target/continuity-session-cost-20261015'))
from public_review_12 import verify, quantiles

folder = stage / 'paired-16'
comparison = json.loads((folder / 'COMPARISON.json').read_text())
sdk.require(comparison['completed'] and comparison['block_count'] == 3 and comparison['samples_per_run'] == 64 and len(comparison['runs']) == 12, 'paired comparison incomplete')
summary = {'completed': False, 'source_commit': comparison['source_commit'], 'hot_sends': 0, 'public_effects_verified': 0, 'sample_substitutions_rejected': 0, 'profiles': {}, 'blocks': [], 'release_claim_eligible': False, 'limitations': ['One native implementation and one uncontrolled macOS host.', 'Nearest-rank observed sample quantiles do not establish production tails or a non-regression guarantee.', 'Whole-process RSS includes both SDK peers, witness where required, and observer buffers.', 'No energy, independent implementation, packaged foreign consumer or physical-device performance claim.']}
pooled = {(profile, variant): [] for profile in ['local', 'witness'] for variant in ['baseline', 'optimized']}
seen_sessions = set()
for row in comparison['runs']:
    base = folder / row['folder']
    sdk.require(row['completed'] and row['runtime_sealed'] and sdk.snapshot(base / 'RESULT.json').sha256 == row['result_sha256'], 'runtime receipt differs')
    value = json.loads((base / 'RESULT.json').read_text())
    checked = verify(value)
    sdk.require(value['profile'] == row['profile'] and checked['samples'] == 64 and tuple(value['session']) not in seen_sessions, 'runtime scope or identity differs')
    seen_sessions.add(tuple(value['session']))
    effects = base / 'runtime/responder/measured-effects'
    sdk.require({p.name for p in effects.iterdir()} == set(checked['effects']), 'public effect-file census')
    for name, expected in checked['effects'].items():
        sdk.require(sdk.snapshot(effects / name, maximum=32768).data == expected, 'public effect bytes differ')
    expected_counts = {1: 20, 2: 5} if row['profile'] == 'witness' else {}
    sdk.require(all(c == expected_counts for c in checked['witness_per_sample']), 'witness traffic changed')
    for index in range(64):
        altered = copy.deepcopy(value)
        altered['samples'][index]['index'] = -1
        try:
            verify(altered)
        except ValueError as error:
            sdk.require('order' in str(error), 'unexpected substitution rejection')
        else:
            raise ValueError('reader accepted substituted sample')
        summary['sample_substitutions_rejected'] += 1
    pooled[(row['profile'], row['variant'])].extend(value['samples'])
    summary['blocks'].append({key: row[key] for key in ['block', 'profile', 'variant', 'send_ns', 'resources', 'load_before', 'load_after']})
    summary['hot_sends'] += 64
    summary['public_effects_verified'] += len(checked['effects'])
for profile in ['local', 'witness']:
    result = {}
    for variant in ['baseline', 'optimized']:
        samples = pooled[(profile, variant)]
        result[variant] = {'send_ns': quantiles([r['send_ns'] for r in samples]), 'slot_lookup_ns': quantiles([r['reserve_ns'] for r in samples]), 'status_ns': quantiles([r['status_ns'] for r in samples]), 'payloads': {str(size): quantiles([r['send_ns'] for r in samples if r['payload_bytes'] == size]) for size in [0, 64, 1024, 16384]}, 'max_rss_bytes': [r['resources']['max_rss_bytes'] for r in comparison['runs'] if r['profile'] == profile and r['variant'] == variant]}
    result['observed_p50_reduction_percent'] = 100 * (1 - result['optimized']['send_ns']['p50'] / result['baseline']['send_ns']['p50'])
    summary['profiles'][profile] = result
sdk.require(summary['hot_sends'] == 768 and summary['public_effects_verified'] == 780 and summary['sample_substitutions_rejected'] == 768, 'comparison census incomplete')
summary['completed'] = True
sdk.write_json(stage / 'SUMMARY_17.json', summary)
print(json.dumps({profile: {variant: value['send_ns'] for variant, value in result.items() if variant in ['baseline', 'optimized']} for profile, result in summary['profiles'].items()}))
