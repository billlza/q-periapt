from pathlib import Path
import json, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
sdk.require(json.loads((stage / 'BROWSER_FINAL.json').read_text())['completed'], 'full browser run incomplete')
sdk.command([sys.executable, '-B', str(root / 'artifact/python_bootstrap.py'), str(stage / 'test_browser_review_43.py'), '-v'], stage / 'browser-controls-43', root)
print('Six browser public-reader controls passed, including all 81 call substitutions')
