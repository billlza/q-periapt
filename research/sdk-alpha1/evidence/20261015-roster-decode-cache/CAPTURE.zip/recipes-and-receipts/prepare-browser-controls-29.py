from pathlib import Path
import ast
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-browser-pending-continuation'
sdk.copy(prior / 'public_review.py', stage / 'browser_public_review.py')
text = (prior / 'test_public_review.py').read_text()
sdk.require(text.count('from public_review import verify') == 1 and text.count('harness-06/run-08/RESULT.json') == 1, 'browser controls relocation')
text = text.replace('from public_review import verify', 'from browser_public_review import verify')
text = text.replace('harness-06/run-08/RESULT.json', 'browser-harness-27/run-28/RESULT.json')
ast.parse(text)
with (stage / 'test_browser_review_29.py').open('x') as output:
    output.write(text)
