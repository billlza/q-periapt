from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
record = json.loads((stage / 'BROWSER_FINAL.json').read_text())
sdk.require(record['completed'] and record['runtime_sealed'], 'browser producer incomplete')
harness = Path(record['harness'])
state = json.loads((harness / record['run_label'] / 'RESULT.json').read_text())
outputs = []
for row in state['cases']:
    keys = {v['case'] for v in state['observations'] if v['case'].endswith('-' + row['case'])}
    sdk.require(len(keys) == 1, 'exact public application scope')
    folder = harness / (record['run_label'] + '-private') / next(iter(keys)) / 'peer/effects'
    expected = {bytes(row['message']).hex(): bytes(row['session']) + bytes(row['message']) + b'browser to native', bytes(row['fresh_message']).hex(): bytes(row['session']) + bytes(row['fresh_message']) + b'after P'}
    sdk.require({path.name for path in folder.iterdir()} == set(expected), 'public effect file census')
    for name, payload in expected.items():
        actual = sdk.snapshot(folder / name, maximum=32768)
        sdk.require(actual.data == payload, 'actual business bytes differ')
        outputs.append({'case': row['case'], 'message': name, 'bytes': actual.size, 'sha256': actual.sha256})
sdk.write_json(stage / 'BROWSER_BUSINESS_44.json', {'completed': True, 'synthetic_business_files_verified': 4, 'outputs': outputs, 'only_explicit_application_effect_files_read': True, 'sdk_keys_or_journals_opened': False})
print('Four original/new browser-to-native business effects independently verified')
