from pathlib import Path
import json, os, shutil, tomllib
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
shutil.copytree(stage / 'candidate', candidate)
manifest = candidate / 'Cargo.toml'
before = sdk.snapshot(manifest)
text = before.data.decode()
old = 'path = "../../crates/q-periapt-sig"'
sdk.require(text.count(old) == 1, 'expected isolated dev-dependency path')
manifest.write_text(text.replace(old, f'path = "{root}/crates/q-periapt-sig"'))
sdk.write_json(stage / 'MANIFEST_REPAIR_04.json', {
    'before_sha256': before.sha256,
    'after_sha256': sdk.snapshot(manifest).sha256,
    'reason': 'Original isolated copy omitted the dev-dependency path relocation; previous metadata command failed before compilation.',
    'preserved_attempt': 'candidate and metadata-03.*',
})
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-04'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
cargo = str(toolchain / 'bin/cargo')
sdk.command([cargo, 'metadata', '--format-version', '1', '--offline', '--manifest-path', str(manifest)], stage / 'metadata-04', root, environment=environment)
def registry(path):
    return {(p['name'], p['version'], p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
allowed = registry(root / 'Cargo.lock') | registry(root / 'research/continuity-identity-candidate/Cargo.lock')
sdk.require(registry(candidate / 'Cargo.lock') <= allowed, 'dependency drift')
sources = {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}
sdk.write_json(stage / 'TEST_INPUTS_04.json', {'candidate_files': sources, 'base_commit': '0037d195e2342c0c03ced5653d30b9762a5528be'})
sdk.command([cargo, 'test', '--offline', '--locked', '--manifest-path', str(manifest), '--lib', '--all-features', 'durable::rosters::', '--', '--nocapture'], stage / 'roster-tests-04', root, environment=environment)
sdk.require(sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'source changed during test')
sdk.write_json(stage / 'TARGETED_04.json', {'completed': True, 'candidate_files': sources, 'product_worktree_modified': False})
print('Roster-focused tests passed')
