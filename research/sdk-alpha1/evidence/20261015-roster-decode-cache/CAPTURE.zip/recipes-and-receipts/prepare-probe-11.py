from pathlib import Path
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
value = (root / 'target/continuity-session-cost-breakdown-20261015/run-04.py').read_text()
sdk.require(value.count('BUILD_03.json') == 1 and value.count("'instrumentation_only':True") == 1, 'diagnostic runner scope')
value = value.replace('BUILD_03.json', 'BUILD_10.json')
value = value.replace("'instrumentation_only':True", "'variant':'optimized with timing counters'")
with (stage / 'probe-11.py').open('x') as stream:
    stream.write(value)
print('Fresh diagnostic runtime runner prepared; not executed')
