from pathlib import Path
import json, subprocess, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = json.loads((stage / 'CLONE_SOURCE_24.json').read_text())
clone = Path(source['clone'])
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == source['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'source gate checkout differs')
sdk.command([sys.executable, '-B', str(clone / 'artifact/python_bootstrap.py'), str(clone / 'artifact/source_results_assembler.py'), 'ci-source-gate', '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda', source['source_commit'], '--profile', 'sdk-020'], stage / 'source-gate-39', clone)
sdk.write_json(stage / 'SOURCE_GATE_39.json', {'completed': True, 'source_commit': source['source_commit'], 'release_claim_eligible': False, 'full_artifact_suite': 'pending serial rerun'})
print('Exact experimental-source gate passed; artifact suite remains separate')
