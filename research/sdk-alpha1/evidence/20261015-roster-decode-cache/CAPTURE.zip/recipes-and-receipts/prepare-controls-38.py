from pathlib import Path
import ast
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / 'test_browser_review_29.py').read_text()
old = 'browser-harness-27/run-28/RESULT.json'
sdk.require(text.count(old) == 1, 'full browser reader-control source')
text = text.replace(old, 'browser-harness-36/run-37/RESULT.json')
ast.parse(text)
with (stage / 'test_browser_review_38.py').open('x') as stream:
    stream.write(text)
