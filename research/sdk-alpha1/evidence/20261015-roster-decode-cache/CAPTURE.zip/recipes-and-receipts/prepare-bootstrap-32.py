from pathlib import Path
import ast
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
source = stage / 'browser-harness-27'
output = stage / 'bootstrap-harness-32'
output.mkdir()
for name in ['worker.js', 'controller.js', 'session-checks.js', 'server.py']:
    sdk.copy(source / name, output / name)
text = (source / 'run-27.py').read_text()
old = "package=root/'target/continuity-browser-publication/source/target/browser-roster-cache-package-26'"
sdk.require(text.count(old) == 1, 'diagnostic package input boundary')
text = text.replace(old, "package=Path(os.environ['QPC_BROWSER_DIAGNOSTIC_PACKAGE'])")
start = text.index("    established=success({**args,'action':'session','sessionAction':'establish'})")
line_end = text.index('\n', start)
end = text.index("  finally:browser(['close'],'close')", line_end)
line = text[start:line_end]
text = text[:start] + "    bootstrap_started=time.perf_counter_ns()\n" + line + "\n    row.update(completed=True,bootstrap_wall_ns=time.perf_counter_ns()-bootstrap_started,witness_records=witness_records[key],peer_records=peer_records[key])\n    print(json.dumps({'case':case,'bootstrap_completed':True,'bootstrap_wall_ns':row['bootstrap_wall_ns']}),flush=True)\n" + text[end:]
old_scope = "Installed browser exact ordinary pending R2 recovery across expiry, cancellation and Worker loss, bilateral P renewal, original ciphertext/control and bidirectional traffic; same Rust engine and loopback, not independent implementation/PCS/release"
sdk.require(text.count(old_scope) == 1, 'diagnostic scope')
text = text.replace(old_scope, 'Fresh installed-package bootstrap diagnostic only; six public Worker calls, unchanged 10-second caller deadline, no lifecycle acceptance claim')
ast.parse(text)
with (output / 'run-32.py').open('x') as stream:
    stream.write(text)
server = (output / 'server.py').read_text()
old = "                    with (folder/'native.stdout').open('xb') as out,(folder/'native.stderr').open('xb') as err:"
sdk.require(server.count(old) == 1, 'native interval start')
server = server.replace(old, "                    native_started_ns=time.monotonic_ns()\n" + old)
old = '                    record.update(native_dispatched=True,returncode=completed.returncode)'
sdk.require(server.count(old) == 1, 'native interval end')
server = server.replace(old, '                    record.update(native_dispatched=True,returncode=completed.returncode,native_elapsed_ns=time.monotonic_ns()-native_started_ns)')
ast.parse(server)
(output / 'server.py').write_text(server)
sdk.write_json(stage / 'BOOTSTRAP_SOURCE_32.json', {'files': {p.name: sdk.snapshot(p).sha256 for p in output.iterdir()}, 'scope': 'Two package versions, same native peer, fresh cohorts; diagnostic only, original timeout preserved'})
