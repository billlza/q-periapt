from pathlib import Path
import json, os
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
stopped = json.loads((stage / 'all-lib-tests-05.json').read_text())
sdk.require(stopped['returncode'] == -2, 'expected intentionally interrupted run')
sdk.write_json(stage / 'INTERRUPTED_05.json', {'completed': False, 'reason': 'The generic command wrapper had a 900-second ceiling, below the previously recorded 1209.05-second full-library run. Interrupted its verified process group with SIGINT and retained both output streams; no test assertion or SDK timeout was changed.', 'returncode': -2, 'complete_suite_pass_claim': False, 'source_changed': False, 'replacement_outer_deadline_seconds': 2700})
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-04'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
sdk.command([str(toolchain / 'bin/cargo'), 'clippy', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--all-targets', '--all-features', '--', '-D', 'warnings'], stage / 'clippy-13', root, environment=environment)
sources = json.loads((stage / 'TARGETED_04.json').read_text())['candidate_files']
sdk.require(sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'candidate changed')
sdk.write_json(stage / 'LINT_13.json', {'completed': True, 'all_targets_all_features': True, 'warnings_denied': True, 'candidate_files': sources})
print('Strict Clippy passed; the interrupted full run is retained as incomplete')
