from pathlib import Path
import json, os, subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = json.loads((stage / 'CLONE_SOURCE_24.json').read_text())
clone = Path(source['clone'])
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == source['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'package source changed')
helper = clone / 'target/browser-roster-cache-build-26.py'
sdk.copy(clone / 'target/browser-pending-recovery-build.py', helper)
output = clone / 'target/browser-roster-cache-package-26'
sdk.require(not output.exists(), 'fresh package output required')
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(RUSTUP_HOME=str(root / 'target/continuity-browser-credential-renewal/rustup'), RUSTUP_TOOLCHAIN='1.98.1-aarch64-apple-darwin', CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', CARGO_TARGET_DIR=str(stage / 'wasm-package-target-26'), CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang', RUSTFLAGS='-D warnings', QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14', PYTHONPATH='artifact')
environment['PATH'] = ':'.join([str(toolchain / 'bin'), str(root / 'target/browser-policy-tools/node_modules/.bin'), str(root / 'target/browser-policy-tools/wasm-bindgen/bin'), '/Users/bill/.cargo/bin', '/opt/homebrew/bin', environment['PATH']])
sdk.write_json(stage / 'PACKAGE_SOURCE_26.json', {'source_commit': source['source_commit'], 'clone': str(clone), 'helper_sha256': sdk.snapshot(helper).sha256, 'output': str(output), 'fresh_build_target': environment['CARGO_TARGET_DIR'], 'browser_runtime': 'not-run', 'main_worktree_unchanged': True})
sdk.command(['/bin/sh', str(clone / 'artifact/python-run.sh'), str(helper), '--output', str(output)], stage / 'package-26', clone, environment=environment)
record = json.loads((output / 'INSTALLED_CONSUMER.json').read_text())
sdk.require(record['installed_node_tests'] == 'passed' and record['sources_unchanged'] and record['source_bound'] and record['browser_runtime'] == 'not-run', 'installed package incomplete or browser overclaim')
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == source['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'package source changed during build')
sdk.write_json(stage / 'PACKAGE_26.json', record)
print('Experimental-source WASM archive built and installed; browser execution remains separate')
