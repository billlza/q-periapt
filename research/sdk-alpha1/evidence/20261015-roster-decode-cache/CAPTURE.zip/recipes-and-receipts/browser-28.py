from pathlib import Path
import json, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
package = json.loads((stage / 'PACKAGE_26.json').read_text())
sdk.require(package['installed_node_tests'] == 'passed' and package['sources_unchanged'], 'installed package incomplete')
source = json.loads((stage / 'BROWSER_SOURCE_27.json').read_text())
harness = stage / 'browser-harness-27'
for name, digest in source['files'].items():
    sdk.require(sdk.snapshot(harness / name).sha256 == digest, 'fresh harness source changed')
sdk.command([sys.executable, '-B', str(root / 'artifact/python_bootstrap.py'), str(harness / 'run-27.py'), 'run-28', 'unapplied', 'applied'], stage / 'browser-28', root)
value = json.loads((harness / 'run-28/RESULT.json').read_text())
sdk.require(value['completed'] and value['producer_unchanged'] and len(value['observations']) == 81, 'browser continuation census incomplete')
sys.path.insert(0, str(root / 'target/continuity-browser-pending-continuation'))
import public_review
checked = public_review.verify(value)
sdk.write_json(stage / 'BROWSER_28.json', {'completed': True, 'source_commit': source['browser_source_commit'], 'package_sha256': sdk.snapshot(Path(package['archive']), maximum=128*1024**2).sha256, 'result_sha256': sdk.snapshot(harness / 'run-28/RESULT.json').sha256, 'observations': 81, 'runtime_sealed': True, 'independent_implementation': False, 'review': checked, 'release_claim_eligible': False})
print('Installed new browser package completed both original-session recovery and continuation flows')
