from pathlib import Path
import contextlib, json, os, sys, time
from bounded_process import capture_output
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
harness = stage / 'bootstrap-harness-32'
source = json.loads((stage / 'BOOTSTRAP_SOURCE_32.json').read_text())
sdk.require(json.loads((stage / 'QUALIFIED_14.json').read_text())['completed'] and json.loads((stage / 'ARTIFACT_TIMEOUT_34.json').read_text())['original_process_absent'], 'prior heavy jobs must be terminal before diagnostic collection')
packages = {'baseline': root / 'target/continuity-browser-publication/source/target/browser-pending-continuation-package-01', 'optimized': root / 'target/continuity-browser-publication/source/target/browser-roster-cache-package-26'}
record = {'completed': False, 'all_bootstraps_passed': False, 'runs': [], 'scope': 'Four fresh bootstrap diagnostics, baseline/optimized/optimized/baseline order; same native helper and unchanged ten-second caller deadline', 'release_claim_eligible': False}
try:
    for index, variant in enumerate(['baseline', 'optimized', 'optimized', 'baseline']):
        label = f'control-33-{index:02}-{variant}'
        environment = dict(os.environ)
        environment['QPC_BROWSER_DIAGNOSTIC_PACKAGE'] = str(packages[variant])
        consumer = json.loads((packages[variant] / 'INSTALLED_CONSUMER.json').read_text())
        row = {'variant': variant, 'label': label, 'load_before': os.getloadavg(), 'started_unix': time.time(), 'package_sha256': consumer['sha256']}
        print(json.dumps({'variant': variant, 'label': label, 'phase': 'fresh bootstrap diagnostic'}), flush=True)
        argv = [sys.executable, '-B', str(root / 'artifact/python_bootstrap.py'), str(harness / 'run-32.py'), label, 'unapplied']
        with contextlib.chdir(root):
            result = capture_output(argv, timeout_seconds=180, maximum_stdout_bytes=8*1024**2, maximum_stderr_bytes=8*1024**2, environment=environment)
        prefix = stage / label
        with prefix.with_suffix('.stdout').open('xb') as stream:
            stream.write(result.stdout)
        with prefix.with_suffix('.stderr').open('xb') as stream:
            stream.write(result.stderr)
        sdk.write_json(prefix.with_suffix('.json'), {'argv': argv, 'returncode': result.returncode})
        value = json.loads((harness / label / 'RESULT.json').read_text())
        row.update(returncode=result.returncode, bootstrap_passed=value['completed'] and result.returncode == 0, failure=value.get('failure'), observations=len(value['observations']), cases=[{'case': r['case'], 'completed': r.get('completed', False), 'bootstrap_wall_ns': r.get('bootstrap_wall_ns')} for r in value['cases']], peer_records=value['peer_records'], fixture_failures=value['fixture_failures'], result_sha256=sdk.snapshot(harness / label / 'RESULT.json').sha256, load_after=os.getloadavg(), finished_unix=time.time(), runtime_sealed=True)
        sdk.require(len(value['observations']) == 6, 'diagnostic did not reach the intended public boundary')
        record['runs'].append(row)
        print(json.dumps({'variant': variant, 'passed': row['bootstrap_passed'], 'cases': row['cases']}), flush=True)
    for name, digest in source['files'].items():
        sdk.require(sdk.snapshot(harness / name).sha256 == digest, 'diagnostic source changed')
    record['completed'] = True
    record['all_bootstraps_passed'] = all(row['bootstrap_passed'] for row in record['runs'])
except BaseException as error:
    record['collection_failure'] = repr(error)
    raise
finally:
    sdk.write_json(stage / 'BOOTSTRAP_CONTROLS_33.json', record)
raise SystemExit(0 if record['all_bootstraps_passed'] else 1)
