from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
out = root / 'research/sdk-alpha1/evidence/20261015-roster-decode-cache'
summary = json.loads((out / 'SUMMARY.json').read_text())
capture = json.loads((out / 'CAPTURE.json').read_text())
qualification = json.loads((stage / 'QUALIFIED_14.json').read_text())
integration = json.loads((stage / 'INTEGRATED_20.json').read_text())
sdk.require(json.loads((out / 'READBACK.json').read_text())['completed'] and qualification['completed'], 'final evidence incomplete')
sdk.require(re.search(r'test result: ok\. 6 passed; 0 failed; 0 ignored;', (stage / 'msrv-tests-19.stdout').read_text()) is not None, 'minimum-compiler test census')
ms = lambda value: f'{value / 1e6:.2f}'
table = '| Protection | Baseline p50 / p95 (ms) | Cached p50 / p95 (ms) | Observed p50 reduction |\n| --- | --- | --- | --- |\n'
memory = '| Protection | Baseline process RSS range (MiB) | Cached process RSS range (MiB) |\n| --- | --- | --- |\n'
for profile in ['local', 'witness']:
    value = summary['profiles'][profile]
    before, after = value['baseline']['send_ns'], value['optimized']['send_ns']
    table += f'| {profile} | {ms(before["p50"])} / {ms(before["p95"])} | {ms(after["p50"])} / {ms(after["p95"])} | {value["observed_p50_reduction_percent"]:.1f}% |\n'
    b, a = value['baseline']['max_rss_bytes'], value['optimized']['max_rss_bytes']
    memory += f'| {profile} | {min(b)/2**20:.2f}–{max(b)/2**20:.2f} | {min(a)/2**20:.2f}–{max(a)/2**20:.2f} |\n'
readme = f'''# Reuse historical roster verification within one journal image

The current change reduces repeated signature work while keeping current
authorization in its existing operation paths. Base source is
`{capture['base_commit']}`; implementation commit is `{capture['source_commit']}`.
CAPTURE.json binds every integrated file by hash.
The uninstrumented measured variant is byte-identical to the promoted engine
files. No public API, wire encoding, storage schema, dependency or policy changes.

`VerifiedRoster::from_journal` remains the authoritative historical decoder.
Its successful results are memoized by complete encoded bytes, including account,
family, checkpoint, root and signed wire. Changed bytes run the full decoder;
invalid results are never cached. Current time, membership, monotonic/current-head
checks, record identity, journal/policy scope, credential renewal, retirement and
witness state remain outside the memo. Each Image starts with an empty cache and
drops it with that Image. The Active owner and stored journal contain no memo.

The cache bounds retained encoded inputs to 64 KiB and entries to 64. Parsed
public rosters and allocation overhead add memory beyond that input-byte bound.
A capacity miss performs the authoritative decode and preserves valid-input
admission. Signature verification occurs outside the mutex; poisoning returns
an explicit Corrupt error. The private implementation and its tests are separate
modules, and the record parser remains shared with the uncached historical path.

## Paired native observations

Three paired blocks alternate profile order and reverse baseline/variant order.
Every process starts fresh enrolled identities, stores and a session. Each sends
64 messages cycling through 0, 64, 1024 and 16384 bytes, with epoch-1 rekey halfway
through. Each send uses fresh pinned hybrid TLS, encrypted journal transitions,
an actual fsynced receiver business file and authenticated consumption. TLS
resumption and early data stay disabled; no sample is discarded.

The twelve processes execute 768 ordinary sends, twelve rekeys and twelve original
unknown-result recoveries. Each recovery closes/reopens both owners and retries
the exact message without a second business effect. Retired resend is refused.
Public-only readback independently verifies 780 business files and rejects all
768 individual sample substitutions. A preceding four-process pilot and two
fresh diagnostic profiles remain in the capture separately from the paired data.

{table}
Each distribution contains 192 observations and uses nearest-rank quantiles.
The host is Apple M1 Max (10 cores, 32 GiB), macOS 27.0.1 / 26A434, with Rust
1.98.1 Release, opt-level 3, thin LTO, one codegen unit and overflow checks. Host
load is recorded and uncontrolled; no task builds or broad tests overlap the
paired measurement. This two-peer workload does not establish production tails,
general non-regression, energy, independent implementation or foreign/device
performance. Savings may differ or disappear when the bounded cache is full.

{memory}
Each range contains three Darwin maximum-RSS observations. The process includes
both peers, the witness where required and observer buffers. These observations
retain the cache's memory cost and do not establish maximum-capacity SDK memory.

Separate timing-counter builds show roster-verification calls falling from 103
to 28 locally and from 109 to 28 with the witness per slot-lookup/send/status
group. Each such call verifies both signature components.
All measured durability, validation-stage and authority-check call counts remain
unchanged: ten instrumented journal write-intent database commits, five intent
commits and twenty current-state checks. Witness request/reply signatures remain
25 each. Independent network accounting still observes twenty Query and five
Advance exchanges, 183,525 framed bytes per group. The database counter covers
the instrumented write-intent commits; it excludes witness-store commits and the
host business-file fsync. Diagnostic durations are inclusive and do not supply
the speedup estimate; the optimized counter run overlapped native regression.

## Validation and retained failures

All **1025 native library tests** pass with all features, zero failures, ignored
tests or filtered tests. The same source passes 29 focused roster tests, strict
all-target/all-feature Clippy, canonical format, WASM library compilation, six
cache tests under Rust 1.90 and iOS arm64 compilation. The warmed-image policy
graft case still rejects authorization from another journal. The full artifact
suite passes {integration['full_artifact_tests']} tests with zero skips, and the
exact implementation-source gate passes.

The new installed WASM archive has SHA-256
`{capture['browser']['package_sha256']}`. Fresh actual Chrome/IndexedDB flows
execute 81 Worker calls, four Worker terminations and two held-Query cancellations.
Both unapplied and applied R2 recovery paths retain the original pending message
and rekey across real policy expiry. Independent P1 renewals then allow exact
control/ciphertext replay, epoch-1 completion, bidirectional consumption and new
work, with two native business effects per path. Six public-reader controls reject
all 81 call substitutions and altered termination, mutation and delivery outcomes.
The native peer uses the retained baseline executable with fresh identities and
stores; this is cross-version interoperability within the same implementation.
Physical-device qualification of the cache delta remains separate.

The first broad run was deliberately interrupted: its generic 900-second outer
deadline was shorter than a previously recorded 1209.05-second full-library run.
Its 613 passing records remain incomplete evidence. The successful replacement
uses the established 2700-second outer bound with fresh test state and unchanged
assertions and SDK timeouts. The failed manifest relocation and instrumentation
recipe preparation remain, together with their fixes; neither reached a product
runtime. Earlier REPORT_18.md is the explicitly pending experimental checkpoint.

The first new-package browser cohort stopped at establishment with Deadline and
closed its owner. Public receipt times show the unchanged native peer's first
response taking approximately 4.8 seconds, versus 1.3 seconds in the earlier
accepted baseline; native and artifact qualification jobs overlapped that attempt.
After those jobs were terminal, four fresh baseline/optimized/optimized/baseline
bootstrap controls all passed with the original ten-second deadline. Measured
outer call durations were 7.71–7.72 seconds for the baseline and 7.45–7.94 seconds
for the optimized package. These observations support
scheduling contention as a possible contributor, without identifying a unique
root cause or erasing the failed cohort. Its original stores remain sealed.

A second fresh run exposed an observer fence error: Python's fractional clock
passed the integer policy expiry while the Worker's whole-second observation
still equalled it. Both public pending results had runtimeCreated=false; the
first observedAt equalled until and the second was two seconds later. The test
wait now reaches until+1 before issuing recovery, preserving its original strict
observedAt>until assertion and all SDK deadlines. Three controls execute the
actual old/new wait AST, reproduce the old equal-second result and check the
corrected boundary. A subsequent entirely fresh composed run passes both paths
with the same SDK, timeout values and safety assertions. Both failed cohorts
remain sealed and their public records are retained.

The concurrent artifact attempt also hit its 900-second outer bound before a
terminal test report was retained. It contributes no test pass claim. The complete
serial rerun retains live stdout/stderr and a 2700-second outer deadline, with all
assertions unchanged. No SDK timeout, safety check or failure outcome was relaxed.

CAPTURE.zip SHA-256 is `{capture['capture_sha256']}` with {capture['members']}
members. Its inventory, public-result parsing and all 780 paired business effects
are read back from the archive. Private journals, keys and runtime directories
are excluded. The two new Rust source paths are added to the exact CodeQL
inventory and missing-source rejection controls; hosted validation remains open.

Current-source native foreign-package/device qualification, controlled tails and energy,
maximum-capacity memory, independent endpoints, full construction/recovery
analysis, maintenance/freeze and external review remain 0.2.0 release gates.
'''
with (out / 'README.md').open('x') as stream:
    stream.write(readme)
with (root / 'docs/SDK_PERFORMANCE.md').open('a') as stream:
    stream.write(f'''\n\n### Per-image historical roster decode reuse — 2026-10-15

The [source-bound paired experiment](../research/sdk-alpha1/evidence/20261015-roster-decode-cache/README.md)
adds a bounded exact-byte memo to each decoded journal Image. The authoritative
parser and all current-time, membership, policy, record-scope and witness checks
remain. Three paired blocks contain 768 actual TLS/durable sends and twelve
rekey/recovery flows, with 780 independently checked business files.

{table}
These are observed single-host, two-peer native distributions with 192 samples
per cell. Host load is uncontrolled; energy, production tails, maximum-capacity
memory and packaged/device performance remain open. Whole-process RSS ranges
and all raw samples, including outliers, are retained in the linked report.
Roster verifications fall from 103/109 to 28 per complete operation group;
instrumented write-intent database commits stay at ten and witnessed traffic
stays at twenty Query plus five Advance exchanges. The cache retains at most
64 KiB of encoded inputs plus parsed public values and overhead; full-cache
misses preserve the original decoder and valid-input admission. This measured
duplicate work, rather than file length, motivates the isolated private module.
''')
with (root / 'docs/SDK_0_2_RELEASE_READINESS.md').open('a') as stream:
    stream.write('''\n\n### Bounded historical roster decode reuse — 2026-10-15

The [paired optimization checkpoint](../research/sdk-alpha1/evidence/20261015-roster-decode-cache/README.md)
promotes an exact-byte, per-Image historical verification memo. All 1025 native
library tests pass with all features and zero ignored tests; strict Clippy,
formatting, six Rust 1.90 cache tests, WASM checking and iOS arm64 checking pass.
The full artifact suite and implementation-source gate pass. A fresh installed
browser archive executes 81 Worker calls, four Worker terminations and two Query
cancellations, then resumes original traffic across real policy expiry and P1
renewal; public-reader controls and archive readback validate both recovery paths.
The 768-send paired measurement independently verifies 780 business effects,
twelve rekeys and twelve original unknown-result recoveries. Observed send
medians decrease by 11.6% locally and 6.6% with the required witness on this one
uncontrolled native host. Current authority, time, scope, witness and durable
commit checks remain; complete encoded inputs identify cached historical results.
The original interrupted broad run and preparation failures remain recorded.
The exact CodeQL inventory includes both new Rust files and rejects their omission.
Current-source hosted CI and installed/device qualification of this implementation
delta remain open alongside the existing protocol, resource, maintenance and
external-review release gates. No merge or release is implied.
''')
print('Source-scoped optimization, validation and remaining admission gates documented')
