from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
state = json.loads((stage / 'browser-harness-36/run-37/RESULT.json').read_text())
row = state['cases'][0]
pending = [v['result']['value'] for v in state['observations'] if v['action'] == 'pending-request']
sdk.require(not state['completed'] and len(pending) == 2, 'failed expiry fixture scope')
report = {'completed': False, 'runtime_sealed': True, 'runtime_reopened': False, 'failure': state['failure'], 'real_expiry': row['real_expiry'], 'pending_requests': [{key: value[key] for key in ['runtimeCreated', 'observedAt']} for value in pending], 'fixture_failures': state['fixture_failures']}
sdk.require(all(value['runtimeCreated'] is False for value in pending), 'unexpected operational runtime')
sdk.require(pending[0]['observedAt'] == row['real_expiry']['policy_until'], 'boundary explanation not supported')
report['cause'] = 'The host wait exits once floating-point time is greater than the integer until; the Worker reports whole seconds, so until + a fraction is still observedAt == until. The retained assertion requires observedAt > until.'
sdk.write_json(stage / 'EXPIRY_FAILURE_40.json', report)
print(json.dumps(report))
