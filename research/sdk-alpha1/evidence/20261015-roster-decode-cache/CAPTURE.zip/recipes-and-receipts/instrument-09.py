from pathlib import Path
import json, os, shutil, tomllib
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
original = stage / 'candidate-04'
candidate = stage / 'instrumented-candidate-09'
fixture = stage / 'instrumented-fixture-09'
prior = root / 'target/continuity-session-cost-breakdown-20261015'
shutil.copytree(original, candidate)
changes = json.loads((prior / 'INSTRUMENTATION_02.json').read_text())['changes']
for change in changes:
    path = candidate / change['path']
    value = path.read_text()
    sdk.require(value.count(change['old']) == 1, 'diagnostic insertion anchor: ' + change['path'])
    path.write_text(value.replace(change['old'], change['new']))
sdk.copy(prior / 'candidate/src/cost_probe.rs', candidate / 'src/cost_probe.rs')
for name in {c['path'] for c in changes}:
    restored = (candidate / name).read_text()
    for change in reversed([c for c in changes if c['path'] == name]):
        sdk.require(restored.count(change['new']) == 1, 'diagnostic inverse anchor')
        restored = restored.replace(change['new'], change['old'])
    sdk.require(restored.encode() == (original / name).read_bytes(), 'instrumentation altered optimized behavior')
shutil.copytree(prior / 'fixture', fixture)
for name in ['Cargo.toml', 'tests/session_cost.rs']:
    path = fixture / name
    value = path.read_text()
    old = str(prior / 'candidate')
    sdk.require(value.count(old) == 1, 'fixture reference')
    path.write_text(value.replace(old, str(candidate)))
sdk.write_json(stage / 'INSTRUMENTATION_09.json', {'changes': changes, 'inverse_equals_tested_optimized_source': True, 'probe_source_sha256': sdk.snapshot(candidate / 'src/cost_probe.rs').sha256, 'scope': 'fixed public phase names and inclusive timing counters; no runtime input or key inspection'})
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'instrumented-target-09'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
cargo = str(toolchain / 'bin/cargo')
sdk.command([cargo, 'metadata', '--format-version', '1', '--offline', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'metadata-09', root, environment=environment)
def registry(path):
    return {(p['name'], p['version'], p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
sdk.require(registry(fixture / 'Cargo.lock') <= registry(root / 'Cargo.lock') | registry(root / 'research/continuity-identity-candidate/Cargo.lock'), 'dependency drift')
def files():
    return {str(p.relative_to(stage)): sdk.snapshot(p).sha256 for base in [candidate, fixture] for p in base.rglob('*') if p.is_file()}
sources = files()
sdk.write_json(stage / 'BUILD_INPUTS_09.json', {'files': sources, 'instrumented': True})
sdk.command([cargo, 'test', '--offline', '--locked', '--release', '--no-run', '--test', 'session_cost', '--message-format=json', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'compile-09', root, environment=environment)
records = [json.loads(row) for row in (stage / 'compile-09.stdout').read_text().splitlines() if row.startswith('{')]
binaries = [r['executable'] for r in records if r.get('reason') == 'compiler-artifact' and r.get('executable') and r['target']['name'] == 'session_cost']
sdk.require(len(binaries) == 1 and sources == files(), 'diagnostic identity changed')
sdk.write_json(stage / 'BUILD_09.json', {'completed': True, 'source_commit': '0037d195e2342c0c03ced5653d30b9762a5528be', 'binary': binaries[0], 'binary_sha256': sdk.snapshot(Path(binaries[0]), maximum=256*1024**2).sha256, 'files': sources, 'instrumented': True})
print('Optimized diagnostic counters compiled; public candidate remains uninstrumented')
