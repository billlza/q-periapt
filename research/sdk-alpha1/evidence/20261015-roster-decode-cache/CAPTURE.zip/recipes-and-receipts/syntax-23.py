from pathlib import Path
import ast, json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
names = []
for path in sorted(stage.glob('*.py')):
    ast.parse(path.read_text(), filename=str(path))
    names.append(path.name)
sdk.write_json(stage / 'RECIPE_SYNTAX_23.json', {'completed': True, 'files': names, 'bytecode_written': False})
print(json.dumps({'parsed_recipes': len(names)}))
