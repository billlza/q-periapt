from pathlib import Path
import json, re, subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = json.loads((stage / 'CLONE_SOURCE_24.json').read_text())
validation = json.loads((stage / 'CLONE_VALIDATION_24.json').read_text())
native = json.loads((stage / 'QUALIFIED_14.json').read_text())
sdk.require(native['completed'] and validation['completed'] and validation['source_commit'] == source['source_commit'], 'required full validation incomplete')
sdk.require(json.loads((stage / 'BROWSER_FINAL.json').read_text())['completed'], 'browser regression unresolved')
text = Path(validation['artifact_stderr']).read_text()
counts = re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$', text)
sdk.require(counts is not None and int(counts[1]) >= 2879, 'full artifact suite missing or skipped')
clone = Path(source['clone'])
for checkout, expected in [(root, source['base_commit']), (clone, source['source_commit'])]:
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip() == expected and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout), 'owned checkout changed')
candidate = stage / 'candidate-04'
sdk.require(native['source_inputs'] == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'tested prototype changed')
prefix = 'research/continuity-identity-candidate/'
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', prefix], cwd=clone).decode().split('\0')
for relative in [name for name in tracked if name.endswith('.rs')]:
    sdk.require(sdk.snapshot(clone / relative).sha256 == native['source_inputs'][relative[len(prefix):]], 'engine source differs from full native test')
sdk.command(['git', 'fetch', str(clone), source['branch']], stage / 'promote-fetch-25', root)
sdk.require(subprocess.check_output(['git', 'rev-parse', 'FETCH_HEAD'], cwd=root, text=True).strip() == source['source_commit'], 'fetched commit differs')
sdk.command(['git', 'merge', '--ff-only', source['source_commit']], stage / 'promote-ff-25', root)
for change in source['changes']:
    sdk.require(sdk.snapshot(root / change['path']).sha256 == change['after_sha256'], 'promoted file differs')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'promotion left uncommitted source')
sdk.write_json(stage / 'INTEGRATED_20.json', {'completed': True, 'base_commit': source['base_commit'], 'source_commit': source['source_commit'], 'changes': source['changes'], 'native_all_lib_tests': 1025, 'full_artifact_tests': int(counts[1]), 'full_artifact_seconds': float(counts[2]), 'new_codeql_paths': 2, 'source_gate': True, 'hosted_validation': False, 'packaged_device_validation_of_this_delta': False, 'release_claim_eligible': False, 'promotion': 'Exact validated local clone commit, fast-forward only; integrate-20.py remained an unused preparation recipe'})
print(json.dumps({'promoted_source': source['source_commit'], 'native_tests': 1025, 'artifact_tests': int(counts[1])}))
