from pathlib import Path
import datetime, json, os, re, signal, subprocess, time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
sources = json.loads((stage / 'TARGETED_04.json').read_text())['candidate_files']
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-04'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
def unchanged():
    return sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}
sdk.require(unchanged(), 'candidate changed before broad regression')
raw = sdk.command([str(toolchain / 'bin/cargo'), 'test', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--lib', '--all-features', '--no-run', '--message-format=json'], stage / 'qualified-compile-14', root, environment=environment)
records = [json.loads(row) for row in raw.decode().splitlines() if row.startswith('{')]
binaries = [Path(r['executable']) for r in records if r.get('reason') == 'compiler-artifact' and r.get('executable') and r['target']['name'] == 'q_periapt_continuity_identity_candidate']
sdk.require(len(binaries) == 1 and unchanged(), 'qualified executable identity')
binary = binaries[0]
digest = sdk.snapshot(binary, maximum=256*1024**2).sha256
record = {'completed': False, 'source_inputs': sources, 'executable': str(binary), 'executable_sha256': digest, 'timeout_seconds': 2700, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'qualification': 'Entire all-features native library test binary with fresh per-test runtime state; no prior runtime store is reopened'}
with (stage / 'all-lib-qualified-14.log').open('xb') as output:
    process = subprocess.Popen([str(binary)], cwd=root, env=environment, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    record['pid'] = process.pid
    sdk.write_json(stage / 'RUNNING_14.json', record)
    print(json.dumps({'pid': process.pid, 'executable_sha256': digest, 'timeout_seconds': 2700}), flush=True)
    deadline = time.monotonic() + 2700
    try:
        while True:
            try:
                status = process.wait(timeout=min(10, max(0.1, deadline-time.monotonic())))
                break
            except subprocess.TimeoutExpired:
                if time.monotonic() >= deadline:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                    record['timed_out'] = True
                    status = 124
                    break
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
record.update(exit_status=status, source_unchanged=unchanged(), executable_unchanged=sdk.snapshot(binary, maximum=256*1024**2).sha256 == digest, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
counts = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;', (stage / 'all-lib-qualified-14.log').read_text())
record['test_summaries'] = counts
record['completed'] = status == 0 and record['source_unchanged'] and record['executable_unchanged'] and bool(counts) and counts[-1] == ('1025', '0', '0')
sdk.write_json(stage / 'QUALIFIED_14.json', record)
print(json.dumps({key: record[key] for key in ['completed', 'exit_status', 'source_unchanged', 'executable_unchanged', 'test_summaries']}), flush=True)
raise SystemExit(0 if record['completed'] else 1)
