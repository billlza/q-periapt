from pathlib import Path
import subprocess
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
sdk.require(not (stage / 'full-artifact-tests-24.json').exists(), 'unexpected terminal artifact receipt')
process = subprocess.run(['ps', '-p', '19612', '-o', 'pid=,comm='], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
sdk.require(process.returncode == 1 and not process.stdout, 'original artifact process still present')
sdk.write_json(stage / 'ARTIFACT_TIMEOUT_34.json', {'completed': False, 'attempt': 'prepare-clone-24.py full artifact suite', 'outer_deadline_seconds': 900, 'observed_error': 'bounded_process.BoundedProcessError: command timed out after 900 seconds', 'full_suite_pass_claim': False, 'per_test_results_available': False, 'reason_per_test_results_unavailable': 'The generic sdk.command wrapper writes streams only after capture_output returns; the timeout raised before those files were written.', 'original_process_absent': True, 'native_full_suite_passed': True, 'next_collection': 'Serial full artifact rerun with bounded 2700-second outer process and live file output; assertions unchanged'})
