from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
summary = json.loads((stage / 'SUMMARY_17.json').read_text())
counts = json.loads((stage / 'COUNTS_12.json').read_text())
sdk.require(summary['completed'] and counts['completed'], 'readback incomplete')
ms = lambda value: f'{value / 1e6:.2f}'
rows = []
for profile in ['local', 'witness']:
    result = summary['profiles'][profile]
    before, after = result['baseline']['send_ns'], result['optimized']['send_ns']
    rows.append(f'| {profile} | {ms(before["p50"])} / {ms(before["p95"])} | {ms(after["p50"])} / {ms(after["p95"])} | {result["observed_p50_reduction_percent"]:.1f}% |')
table = '\n'.join(['| Profile | Baseline p50 / p95 (ms) | Memoized p50 / p95 (ms) | Observed p50 reduction |', '| --- | --- | --- | --- |', *rows])
report = f'''# Per-image roster decoding experiment

This isolated prototype starts from source `{summary['source_commit']}`.
It reuses successful historical `VerifiedRoster::from_journal` results only
within one authenticated journal image. Product source integration and the full
native regression are still pending at this report checkpoint.

## Change and security boundary

The original decoder remains authoritative. The memo key is the entire encoded
historical roster: account, policy family, checkpoint, root key and signed wire.
Only successful decodes enter the cache. Changed bytes take the full original
decoder, without a hash-only identity assumption. Current time, membership,
monotonic/current-head admission, record identity and scope, policy continuation,
credential renewal, account retirement and witness state remain outside the memo.
Each newly decoded Image starts empty; dropping the Image drops the memo.
Neither the Active owner nor storage carries cached authorization across calls.

The cache retains at most 64 entries and 64 KiB of encoded inputs. Parsed public
rosters and allocation overhead are additional memory, so this is not a 64-KiB
total-memory claim. Capacity exhaustion runs the authoritative decoder for a
miss and preserves admission behavior. Invalid inputs are not cached. The mutex
is released before signature verification, and poisoning remains an explicit
Corrupt error. No API, protocol bytes, storage schema, dependency, durability
boundary, witness exchange or security policy is changed.

The implementation adds a small private module and a separate test file. It
reuses the existing record decoder through an optional memo rather than creating
a parallel parser or adding caching throughout the operation state machine.

## Measured execution

The unchanged observer performs fresh pinned hybrid TLS for each send, encrypted
journal transitions, a real fsynced receiver business effect and authenticated
consumption. Three paired blocks reverse baseline/optimized order and alternate
local-only/required-witness order. Every run starts fresh enrolled devices,
original stores and a session. Each run sends 64 messages in a 0/64/1024/16384-byte
cycle and advances to epoch 1 halfway through. No sample is removed.

There are 768 ordinary sends across twelve processes, twelve rekeys and twelve
unknown-result recoveries. Each recovery closes/reopens both original owners,
replays the original message, creates no duplicate business effect and then
refuses a retired resend. Independent public readback checks all 780 business
files byte-for-byte and rejects all 768 individual sample substitutions.

{table}

Each cell pools 192 sends; quantiles use nearest rank. The machine is the same
Apple M1 Max/macOS host as the preceding baseline. These are uncontrolled native
single-host observations, not production tails, energy measurements, a general
non-regression guarantee, independent-implementation results or packaged/device
performance qualification. Both compared builds use Rust 1.98.1 Release,
optimization level 3, thin LTO, one codegen unit and overflow checks. Host load and
whole-process CPU/RSS remain in the raw receipts. Whole-process memory includes
both peers, the witness where required, and observer buffers.

Separately instrumented fresh runs show roster signature verification falling
from 103 to 28 calls locally and from 109 to 28 calls with the witness per full
slot-lookup/send/status group. All measured non-roster phase counts are unchanged:
ten database commits, five write-intent commits, twenty current-state checks,
and, on the witnessed path, twenty-five request and twenty-five reply signatures.
Public network readback still observes twenty Query and five Advance exchanges,
183,525 framed bytes per group. Instrumentation spans are inclusive; their
timings are not added or used for the speedup comparison. The optimized counter
run overlapped native regression and is used only for operation-count attribution.

## Validation status at this checkpoint

- 29 roster tests pass, including six new memo-specific tests: altered signature,
  changed pin/family, expiry and revocation, malformed record metadata, bounded
  capacity, and concurrent insertion. The existing warmed-image policy graft
  test continues to reject another journal's authorization.
- All-target/all-feature Clippy with warnings denied passes.
- Canonical formatting and the wasm32-unknown-unknown library compile pass.
  This is not a browser runtime qualification.
- The first full-library run was deliberately interrupted after its 900-second
  outer limit was recognized as shorter than a prior 1209.05-second full run.
  Its 613 passing records and interrupted command receipt remain; it is not a
  full-suite pass. The replacement runner uses the existing bounded 2700-second
  approach, fresh test state and unchanged assertions/SDK timeouts.
- Failed isolated manifest relocation and diagnostic insertion preparation are
  preserved. Neither failure reached a product runtime or changed product code.

The last accepted device/browser packages remain historical evidence for their
own source. This prototype does not replace their source identity or close the
remaining 0.2.0 construction, platform, maintenance/freeze or external-review gates.
'''
with (stage / 'REPORT_18.md').open('x') as output:
    output.write(report)
print('Bounded prototype report written; full native regression not claimed')
