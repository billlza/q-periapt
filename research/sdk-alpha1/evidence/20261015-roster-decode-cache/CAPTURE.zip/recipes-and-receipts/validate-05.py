from pathlib import Path
import json, os, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
inputs = json.loads((stage / 'TARGETED_04.json').read_text())
sdk.require(inputs['completed'], 'focused tests must pass')
sources = inputs['candidate_files']
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-04'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
cargo = str(toolchain / 'bin/cargo')
def unchanged():
    sdk.require(sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'source changed')
unchanged()
result = sdk.command([cargo, 'test', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--lib', '--all-features'], stage / 'all-lib-tests-05', root, environment=environment)
counts = re.findall(rb'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;', result)
sdk.require(len(counts) == 1 and counts[0][1:] == (b'0', b'0'), 'full test census')
unchanged()
sdk.command([cargo, 'clippy', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--all-targets', '--all-features', '--', '-D', 'warnings'], stage / 'clippy-05', root, environment=environment)
unchanged()
sdk.write_json(stage / 'VALIDATION_05.json', {'completed': True, 'all_lib_tests_passed': int(counts[0][0]), 'ignored': 0, 'strict_clippy_all_targets_all_features': True, 'candidate_files': sources})
print('Full native library regression and strict Clippy passed: ' + str(int(counts[0][0])))
