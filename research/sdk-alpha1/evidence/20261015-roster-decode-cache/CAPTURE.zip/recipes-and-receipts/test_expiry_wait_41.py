from pathlib import Path
import ast, copy, math, types, unittest

STAGE = Path(__file__).resolve().parent

def run_actual_wait(relative, start, until):
    tree = ast.parse((STAGE / relative).read_text())
    waits = [node for node in ast.walk(tree) if isinstance(node, ast.While) and 'policy_until' in ast.unparse(node.test)]
    if len(waits) != 1:
        raise AssertionError('one actual policy-expiry wait required')
    current = start
    delays = []
    def sleep(delay):
        nonlocal current
        if not 0 < delay <= 10 or len(delays) >= 4:
            raise AssertionError('bounded wait control failed')
        delays.append(delay)
        current += delay
    program = ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(waits[0])], type_ignores=[]))
    exec(compile(program, relative, 'exec'), {'time': types.SimpleNamespace(time=lambda: current, sleep=sleep), 'cfg': {'policy_until': until}})
    return math.floor(current), delays

class ExpiryWaitControls(unittest.TestCase):
    def test_old_wait_reproduces_equal_whole_second_observation(self):
        until = 1792041611
        for fraction in [.125, .5, .875]:
            observed, delays = run_actual_wait('browser-harness-36/run-36.py', until+fraction, until)
            self.assertEqual(observed, until)
            self.assertEqual(delays, [])

    def test_corrected_wait_preserves_strict_observed_at_assertion(self):
        until = 1792041611
        for fraction in [.125, .5, .875]:
            observed, delays = run_actual_wait('browser-harness-41/run-41.py', until+fraction, until)
            self.assertGreater(observed, until)
            self.assertEqual(len(delays), 1)

    def test_early_and_already_expired_clocks_keep_bounded_waiting(self):
        until = 1792041611
        observed, delays = run_actual_wait('browser-harness-41/run-41.py', until-20, until)
        self.assertGreater(observed, until)
        self.assertEqual(delays, [10, 10, 1])
        observed, delays = run_actual_wait('browser-harness-41/run-41.py', until+1, until)
        self.assertGreater(observed, until)
        self.assertEqual(delays, [])

if __name__ == '__main__':
    unittest.main()
