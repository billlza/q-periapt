from pathlib import Path
import ast, json, subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-browser-pending-continuation'
output = stage / 'browser-harness-27'
output.mkdir()
for name in ['worker.js', 'controller.js', 'session-checks.js', 'server.py']:
    sdk.copy(prior / 'harness-06' / name, output / name)
text = (prior / 'harness-06/run-07.py').read_text()
replacements = [
    ("package=root/'target/continuity-browser-publication/source/target/browser-pending-continuation-package-01'", "package=root/'target/continuity-browser-publication/source/target/browser-roster-cache-package-26'"),
    ("binary=stage.parent/'native-target-05/debug'", "binary=root/'target/continuity-browser-pending-continuation/native-target-05/debug'"),
]
for old, new in replacements:
    sdk.require(text.count(old) == 1, 'browser source relocation boundary')
    text = text.replace(old, new)
ast.parse(text)
with (output / 'run-27.py').open('x') as stream:
    stream.write(text)
native = json.loads((prior / 'NATIVE_BUILD_05.json').read_text())
for binary in native['binaries'].values():
    sdk.require(sdk.snapshot(Path(binary['path']), maximum=256*1024**2).sha256 == binary['sha256'], 'accepted native fixture binary changed')
code_delta = subprocess.check_output(['git', 'diff', '--name-only', 'a4c023bc52f00d0c2f630a6e18bc65ce55c7be25', '0037d195e2342c0c03ced5653d30b9762a5528be', '--', 'Cargo.toml', 'Cargo.lock', 'crates', 'research/continuity-identity-candidate'], cwd=root, text=True).splitlines()
sdk.require(all(Path(name).suffix == '.md' for name in code_delta), 'native peer implementation changed since its accepted baseline')
sdk.write_json(stage / 'BROWSER_SOURCE_27.json', {'files': {p.name: sdk.snapshot(p).sha256 for p in output.iterdir()}, 'native': native['binaries'], 'native_source_scope': 'Accepted prior implementation, unchanged executable bytes, used only with fresh identities and stores', 'browser_source_commit': json.loads((stage / 'CLONE_SOURCE_24.json').read_text())['source_commit'], 'private_runtime_reused': False, 'source_reference': str(prior / 'harness-06'), 'code_delta_since_native_baseline': code_delta})
print('Fresh browser continuation harness prepared; prior runtime stores remain unopened')
