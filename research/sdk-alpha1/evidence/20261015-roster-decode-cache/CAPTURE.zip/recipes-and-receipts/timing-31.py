from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
rows = []
for label, run, case in [('failed', stage / 'browser-harness-27/run-28', 'run-28-unapplied'), ('accepted-baseline', root / 'target/continuity-browser-pending-continuation/harness-06/run-08', 'run-08-unapplied')]:
    records = {}
    for leaf in ['logs/step-006.js', 'logs/step-006.stdout', f'peer/{case}/001/request.bin', f'peer/{case}/001/native.stderr', f'peer/{case}/001/native.stdout', f'peer/{case}/001/reply.bin', f'peer/{case}/001/RECORD.json']:
        path = run / leaf
        sdk.require(path.is_file(), 'public timing receipt missing: ' + str(path))
        records[leaf] = {'mtime_ns': path.stat().st_mtime_ns, 'bytes': path.stat().st_size}
    start = records['logs/step-006.js']['mtime_ns']
    rows.append({'label': label, 'scope': 'filesystem modification-time observation of emitted public receipts; approximate interval, not SDK internal timing', 'relative_mtime_ms': {name: (record['mtime_ns']-start)/1e6 for name, record in records.items()}, 'records': records})
sdk.write_json(stage / 'PUBLIC_TIMING_31.json', rows)
print(json.dumps([{k: v for k, v in row.items() if k != 'records'} for row in rows]))
