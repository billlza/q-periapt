from pathlib import Path
import json,os,subprocess,tomllib
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;candidate=stage/'candidate';fixture=stage/'fixture'
toolchain=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment=dict(os.environ);environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_TARGET_DIR=str(stage/'native-target-03'),PATH=str(toolchain/'bin')+':'+environment['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'))
scope=json.loads((stage/'SOURCE_01.json').read_text());selected=scope['expected_changed_original_files']+scope['new_files']
format_records=[]
for name in selected:
    path=candidate/name;before=sdk.snapshot(path)
    result=subprocess.run([str(toolchain/'bin/rustfmt'),'--edition','2021','--emit','stdout'],input=before.data,cwd=stage,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,check=False)
    sdk.require(result.returncode==0 and not result.stderr,'selected stdin formatting failed: '+result.stderr.decode())
    path.write_bytes(result.stdout);format_records.append({'path':name,'before_sha256':before.sha256,'after_sha256':sdk.snapshot(path).sha256})
sdk.write_json(stage/'FORMAT_03.json',{'files':format_records,'mode':'stdin/stdout; only selected files written'})
original=root/'research/continuity-identity-candidate'
unexpected=[]
for path in original.rglob('*.rs'):
    if 'target' in path.relative_to(original).parts:continue
    name=path.relative_to(original).as_posix();copy=candidate/name
    if copy.exists() and name not in selected and sdk.snapshot(copy).sha256!=sdk.snapshot(path).sha256:unexpected.append(name)
sdk.require(not unexpected,'unrelated source formatting: '+repr(unexpected))
cargo=str(toolchain/'bin/cargo')
sdk.command([str(toolchain/'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'),'--version'],stage/'objcopy-03',root,environment=environment)
sdk.command([cargo,'metadata','--format-version','1','--offline','--manifest-path',str(candidate/'Cargo.toml')],stage/'metadata-03',root,environment=environment)
def registry(path):return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
allowed=registry(root/'Cargo.lock')|registry(original/'Cargo.lock');sdk.require(registry(candidate/'Cargo.lock')<=allowed,'test dependencies changed')
sources={str(p.relative_to(candidate)):sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}
sdk.write_json(stage/'TEST_INPUTS_03.json',{'base_commit':scope['base_commit'],'candidate_files':sources})
sdk.command([cargo,'test','--offline','--locked','--manifest-path',str(candidate/'Cargo.toml'),'--lib','--all-features','durable::rosters::','--','--nocapture'],stage/'roster-tests-03',root,environment=environment)
sdk.require(sources=={str(p.relative_to(candidate)):sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()},'candidate source changed during tests')
sdk.write_json(stage/'TARGETED_03.json',{'completed':True,'base_commit':scope['base_commit'],'candidate_files':sources,'product_worktree_modified':False})
print('Exact-byte cache and existing roster policy/authority tests passed')
