from pathlib import Path
import json, os
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
inputs = json.loads((stage / 'TARGETED_04.json').read_text())
sources = inputs['candidate_files']
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'wasm-target-08'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'), CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang')
cargo = str(toolchain / 'bin/cargo')
sdk.command([cargo, 'fmt', '--manifest-path', str(candidate / 'Cargo.toml'), '--package', 'q-periapt-continuity-identity-candidate', '--', '--check'], stage / 'format-08', root, environment=environment)
sdk.command([cargo, 'check', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--lib', '--target', 'wasm32-unknown-unknown'], stage / 'wasm-08', root, environment=environment)
sdk.require(sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'source changed during portable check')
sdk.write_json(stage / 'PORTABLE_08.json', {'completed': True, 'candidate_files': sources, 'format_check': True, 'wasm_check': True, 'wasm_runtime_executed': False})
print('Canonical format and WASM target check passed')
