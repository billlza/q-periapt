from pathlib import Path
import hashlib, json, sys, zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
base_stage = root / 'target/continuity-session-cost-20261015'
diagnostic = root / 'target/continuity-session-cost-breakdown-20261015'
sys.path.insert(0, str(base_stage))
from public_review_12 import verify
sys.path.insert(0, str(root / 'target/continuity-apple-pending-continuation/attempt-12'))
from public_capture_check import contains_private_pem

qualification = json.loads((stage / 'QUALIFIED_14.json').read_text())
integration = json.loads((stage / 'INTEGRATED_20.json').read_text())
summary = json.loads((stage / 'SUMMARY_17.json').read_text())
sdk.require(qualification['completed'] and integration['completed'] and summary['completed'], 'required qualification incomplete')
for change in integration['changes']:
    sdk.require(sdk.snapshot(root / change['path']).sha256 == change['after_sha256'], 'integrated source changed')
entries = {}
def add(path, name):
    sdk.require(name not in entries and not path.is_symlink(), 'duplicate/symlink capture')
    entries[name] = sdk.snapshot(path, maximum=32*1024**2).data
for path in sorted(stage.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.json', '.stdout', '.stderr', '.log', '.md'}:
        add(path, 'recipes-and-receipts/' + path.name)
for name in ['public_review_12.py', 'BUILD_07.json']:
    add(base_stage / name, 'baseline/' + name)
for path in sorted((base_stage / 'fixture-06').rglob('*')):
    if path.is_file():
        add(path, 'baseline/fixture-06/' + path.relative_to(base_stage / 'fixture-06').as_posix())
for name in ['BUILD_03.json', 'INSTRUMENTATION_02.json', 'SOURCE_01.json', 'build-03.py', 'run-04.py']:
    add(diagnostic / name, 'baseline-diagnostic/' + name)
for directory in ['fixture-06', 'instrumented-fixture-10']:
    for path in sorted((stage / directory).rglob('*')):
        if path.is_file():
            add(path, directory + '/' + path.relative_to(stage / directory).as_posix())
scope = json.loads((stage / 'SOURCE_01.json').read_text())
for name in scope['expected_changed_original_files'] + scope['new_files']:
    add(stage / 'candidate-04' / name, 'optimized-engine/' + name)
instrumented = {c['path'] for c in json.loads((stage / 'INSTRUMENTATION_10.json').read_text())['changes']} | {'src/cost_probe.rs'}
for name in sorted(instrumented):
    add(stage / 'instrumented-candidate-10' / name, 'optimized-diagnostic/' + name)
    add(diagnostic / 'candidate' / name, 'baseline-diagnostic/candidate/' + name)
reference = root / 'research/continuity-identity-candidate/tests'
add(reference / 'owned_connection.rs', 'reference/owned_connection.rs')
for path in sorted((reference / 'owned_connection').rglob('*.rs')):
    add(path, 'reference/owned_connection/' + path.relative_to(reference / 'owned_connection').as_posix())

def add_runtime(folder, prefix):
    for name in ['command.json', 'command.stdout', 'command.stderr', 'time.txt', 'RESULT.json']:
        add(folder / name, prefix + '/' + name)
    checked = verify(json.loads((folder / 'RESULT.json').read_text()))
    for name, expected in checked['effects'].items():
        path = folder / 'runtime/responder/measured-effects' / name
        sdk.require(sdk.snapshot(path, maximum=32768).data == expected, 'public effect changed')
        add(path, prefix + '/public-effects/' + name)
for label in ['pilot-15', 'paired-16']:
    comparison = json.loads((stage / label / 'COMPARISON.json').read_text())
    sdk.require(comparison['completed'], 'comparison incomplete')
    add(stage / label / 'COMPARISON.json', label + '/COMPARISON.json')
    for row in comparison['runs']:
        sdk.require(row['completed'] and row['runtime_sealed'], 'runtime not terminal')
        add_runtime(stage / label / row['folder'], label + '/' + row['folder'])
for folder, label in [(stage / 'probe-11', 'optimized-probe-11'), (diagnostic / 'probe-04', 'baseline-probe-04')]:
    run = json.loads((folder / 'RUN.json').read_text())
    sdk.require(run['completed'], 'probe incomplete')
    add(folder / 'RUN.json', label + '/RUN.json')
    for row in run['profiles']:
        sdk.require(row['completed'] and row['runtime_sealed'], 'probe not terminal')
        add_runtime(folder / row['profile'], label + '/' + row['profile'])
browser = json.loads((stage / 'BROWSER_FINAL.json').read_text())
sdk.require(browser['completed'] and browser['runtime_sealed'] and json.loads((stage / 'browser-controls-43.json').read_text())['returncode'] == 0, 'browser qualification incomplete')
sys.path.insert(0, str(stage))
from browser_public_review import verify as verify_browser
harness = Path(browser['harness'])
browser_run = harness / browser['run_label']
browser_state = json.loads((browser_run / 'RESULT.json').read_text())
sdk.require(verify_browser(browser_state) == browser['review'], 'browser behavior readback differs')
for name, digest in {**browser_state['native'], **browser_state['producer']}.items():
    sdk.require(sdk.snapshot(Path(name), maximum=256*1024**2).sha256 == digest, 'browser producer changed')
for name, digest in browser_state['static_web'].items():
    sdk.require(sdk.snapshot(harness / (browser['run_label'] + '-web') / name).sha256 == digest, 'executed browser static input changed')
allowed = {'.py', '.rs', '.js', '.json', '.stdout', '.stderr', '.md', '.toml', '.lock', '.bin', '.request', '.reply'}
def public_tree(base, prefix):
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix in allowed:
            relative = path.relative_to(base)
            sdk.require(not any(part in {'__pycache__', 'node_modules', '.git', '.playwright'} or part.endswith('-private') for part in relative.parts), 'private browser path selected')
            add(path, prefix + '/' + relative.as_posix())
for path in harness.iterdir():
    if path.is_file() and path.suffix in allowed:
        add(path, 'browser/harness/' + path.name)
public_tree(browser_run, 'browser/run')
public_tree(harness / (browser['run_label'] + '-web') / 'inputs', 'browser/public-inputs')
browser_effects = {}
for row in browser_state['cases']:
    keys = {r['case'] for r in browser_state['observations'] if r['case'].endswith('-' + row['case'])}
    sdk.require(len(keys) == 1, 'browser public business scope')
    key = next(iter(keys))
    # These two specifically identified synthetic application outputs are the
    # only files read from this directory; no SDK key or journal is opened.
    effects = harness / (browser['run_label'] + '-private') / key / 'peer/effects'
    expected = {bytes(row['message']).hex(): bytes(row['session']) + bytes(row['message']) + b'browser to native', bytes(row['fresh_message']).hex(): bytes(row['session']) + bytes(row['fresh_message']) + b'after P'}
    sdk.require({p.name for p in effects.iterdir()} == set(expected), 'browser business file census')
    for name, payload in expected.items():
        sdk.require(sdk.snapshot(effects / name, maximum=32768).data == payload, 'browser business file differs')
        capture_name = 'browser/public-effects/' + row['case'] + '/' + name
        add(effects / name, capture_name)
        browser_effects[capture_name] = payload
failed = stage / 'browser-harness-27/run-28'
sdk.require(not json.loads((failed / 'RESULT.json').read_text())['completed'], 'failed browser attempt reclassified')
public_tree(failed, 'browser/failed-run-28')
public_tree(stage / 'browser-harness-27/run-28-web/inputs', 'browser/failed-public-inputs')
for path in (stage / 'browser-harness-27').iterdir():
    if path.is_file() and path.suffix in allowed:
        add(path, 'browser/failed-harness/' + path.name)
failed_expiry = stage / 'browser-harness-36/run-37'
sdk.require(not json.loads((failed_expiry / 'RESULT.json').read_text())['completed'], 'failed expiry attempt reclassified')
public_tree(failed_expiry, 'browser/failed-expiry-run-37')
public_tree(stage / 'browser-harness-36/run-37-web/inputs', 'browser/failed-expiry-inputs')
for path in (stage / 'browser-harness-36').iterdir():
    if path.is_file() and path.suffix in allowed:
        add(path, 'browser/failed-expiry-harness/' + path.name)
controls = json.loads((stage / 'BOOTSTRAP_CONTROLS_33.json').read_text())
sdk.require(controls['completed'] and controls['all_bootstraps_passed'], 'paired browser controls incomplete')
for path in (stage / 'bootstrap-harness-32').iterdir():
    if path.is_file() and path.suffix in allowed:
        add(path, 'browser/bootstrap-harness/' + path.name)
for row in controls['runs']:
    sdk.require(row['bootstrap_passed'] and row['runtime_sealed'], 'bootstrap diagnostic incomplete')
    public_tree(stage / 'bootstrap-harness-32' / row['label'], 'browser/bootstrap-controls/' + row['label'])
package = json.loads((stage / 'PACKAGE_26.json').read_text())
sdk.require(sdk.snapshot(Path(package['archive']), maximum=128*1024**2).sha256 == package['sha256'] == browser['package_sha256'], 'installed browser archive changed')
for path in Path(package['archive']).parent.iterdir():
    if path.is_file() and path.suffix in {'.json', '.stdout', '.stderr'}:
        add(path, 'browser/package/' + path.name)
for name, payload in entries.items():
    sdk.require(not any(part in {'runtime', 'node_modules', '.git', '__pycache__'} or part.endswith(('.redb', '.key')) for part in Path(name).parts), 'private runtime path selected')
    if not name.endswith(('.py', '.rs', '.toml', '.lock')):
        sdk.require(not contains_private_pem(name, payload), 'private PEM selected')
output = root / 'research/sdk-alpha1/evidence/20261015-roster-decode-cache'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, payload in sorted(entries.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, payload)
manifest = {'base_commit': summary['source_commit'], 'source_commit': integration['source_commit'], 'capture_sha256': sdk.snapshot(archive, maximum=128*1024**2).sha256, 'members': len(entries), 'files': {name: hashlib.sha256(payload).hexdigest() for name, payload in sorted(entries.items())}, 'integrated_files': integration['changes'], 'hot_sends': 768, 'public_effects': 780, 'full_native_tests': 1025, 'sample_substitutions_rejected': 768, 'browser': browser, 'private_runtime_stores_and_keys_excluded': True, 'release_claim_eligible': False}
sdk.write_json(output / 'CAPTURE.json', manifest)
sdk.copy(stage / 'SUMMARY_17.json', output / 'SUMMARY.json')
sdk.copy(stage / 'COUNTS_12.json', output / 'COUNTS.json')
with zipfile.ZipFile(archive) as bundle:
    sdk.require(set(bundle.namelist()) == set(entries) and len(bundle.namelist()) == len(entries), 'archive member census')
    for name, digest in manifest['files'].items():
        sdk.require(hashlib.sha256(bundle.read(name)).hexdigest() == digest, 'archive member digest')
    for row in json.loads(bundle.read('paired-16/COMPARISON.json'))['runs']:
        prefix = 'paired-16/' + row['folder'] + '/'
        checked = verify(json.loads(bundle.read(prefix + 'RESULT.json')))
        for name, expected in checked['effects'].items():
            sdk.require(bundle.read(prefix + 'public-effects/' + name) == expected, 'archive business effect differs')
    sdk.require(verify_browser(json.loads(bundle.read('browser/run/RESULT.json'))) == browser['review'], 'archived browser behavior differs')
    for name, payload in browser_effects.items():
        sdk.require(bundle.read(name) == payload, 'archived browser business effect differs')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'capture_sha256': manifest['capture_sha256'], 'members': len(entries), 'public_effects_verified': 780, 'private_runtime_opened': False})
print(json.dumps({'completed': True, 'members': len(entries), 'capture_sha256': manifest['capture_sha256']}))
