from pathlib import Path
import json, statistics
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
before = json.loads((root / 'target/continuity-session-cost-breakdown-20261015/probe-04/RUN.json').read_text())
after = json.loads((stage / 'probe-11/RUN.json').read_text())
sdk.require(before['completed'] and after['completed'], 'diagnostic runtimes incomplete')
result = {'completed': False, 'before_binary_sha256': before['binary_sha256'], 'after_binary_sha256': after['binary_sha256'], 'profiles': {}, 'timing_scope': 'Inclusive diagnostic spans, with concurrent native regression during optimized collection; call counts only are compared for attribution, not latency speedup.', 'release_claim_eligible': False}
for profile in ['local', 'witness']:
    variants = {}
    for label, capture in [('baseline', before), ('optimized', after)]:
        records = [r for r in capture['profiles'] if r['profile'] == profile]
        sdk.require(len(records) == 1 and records[0]['completed'] and records[0]['runtime_sealed'], 'diagnostic profile census')
        samples = records[0]['samples']
        phases = {}
        for row in samples:
            for phase in row['phases']:
                phases.setdefault(phase['name'], []).append(phase)
        variants[label] = {name: {'calls': sorted({v['calls'] for v in values}), 'median_inclusive_ns': statistics.median(v['nanos'] for v in values)} for name, values in phases.items()}
        sdk.require(variants[label]['DatabaseCommit']['calls'] == [10] and variants[label]['AnchorCheckCurrent']['calls'] == [20], 'durable/current-head checks changed')
        if profile == 'witness':
            sdk.require(variants[label]['VerifyAnchorRequest']['calls'] == [25] and variants[label]['VerifyAnchorReply']['calls'] == [25], 'witness signature checks changed')
    for name in ['ImageAttempt', 'ImageLoad', 'ImageUnseal', 'PersistAttempt', 'SealNextImage', 'SealEncrypt', 'ValidateCancellation', 'ValidatePrekeys', 'ValidateMessages', 'ValidateRosters', 'WriteIntentCommit', 'WriteIntentReserve', 'WriteIntentApply', 'AnchorCheckCurrent', 'SessionRelease', 'AccountAuthorityCheck', 'VerifyCredential', 'VerifySessionPolicy', 'VerifyAnchorRequest', 'VerifyAnchorReply', 'VerifyOther', 'DatabaseCommit']:
        sdk.require(variants['baseline'][name]['calls'] == variants['optimized'][name]['calls'], 'non-roster phase count changed: ' + name)
    sdk.require(max(variants['optimized']['VerifyRoster']['calls']) < min(variants['baseline']['VerifyRoster']['calls']), 'repeated roster verification did not fall')
    result['profiles'][profile] = variants
result['completed'] = True
sdk.write_json(stage / 'COUNTS_12.json', result)
print(json.dumps({profile: {variant: {phase: values[phase]['calls'] for phase in ['VerifyRoster', 'DatabaseCommit', 'AnchorCheckCurrent', 'VerifyAnchorRequest', 'VerifyAnchorReply']} for variant, values in variants.items()} for profile, variants in result['profiles'].items()}))
