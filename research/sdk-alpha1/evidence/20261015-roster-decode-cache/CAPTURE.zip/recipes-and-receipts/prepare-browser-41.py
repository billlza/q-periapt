from pathlib import Path
import ast
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
source = stage / 'browser-harness-36'
output = stage / 'browser-harness-41'
output.mkdir()
for name in ['worker.js', 'controller.js', 'session-checks.js', 'server.py']:
    sdk.copy(source / name, output / name)
text = (source / 'run-36.py').read_text()
old = "while time.time()<=cfg['policy_until']:"
new = "while time.time()<cfg['policy_until']+1:"
sdk.require(text.count(old) == 1, 'real expiry wait boundary')
text = text.replace(old, new)
sdk.require("pending['observedAt']>row['real_expiry']['policy_until']" in text, 'strict expiry assertion must remain')
ast.parse(text)
with (output / 'run-41.py').open('x') as stream:
    stream.write(text)
sdk.write_json(stage / 'BROWSER_SOURCE_41.json', {'files': {p.name: sdk.snapshot(p).sha256 for p in output.iterdir()}, 'old_wait': old, 'new_wait': new, 'strict_expiry_assertion_preserved': True, 'sdk_or_caller_timeout_changed': False, 'failed_runtime_reopened': False, 'source_commit': '9ed01d70143a6a90ab4ffc6bc1b6d1570c5fd9c6'})
runner = (stage / 'browser-37.py').read_text()
for old_value, new_value in [('BROWSER_SOURCE_36.json', 'BROWSER_SOURCE_41.json'), ('browser-harness-36', 'browser-harness-41'), ('run-36.py', 'run-41.py'), ('run-37', 'run-42'), ('browser-37', 'browser-42')]:
    sdk.require(old_value in runner, 'final runner relocation')
    runner = runner.replace(old_value, new_value)
runner = runner.replace("'prior_failure': 'BROWSER_FAILURE_30.json'", "'prior_failures': ['BROWSER_FAILURE_30.json', 'EXPIRY_FAILURE_40.json']")
runner = runner.replace("'source_changed_after_first_browser_failure': False", "'sdk_source_changed_after_first_browser_failure': False, 'test_fixture_wait_corrected': True")
ast.parse(runner)
with (stage / 'browser-42.py').open('x') as stream:
    stream.write(runner)
controls = (stage / 'test_browser_review_38.py').read_text()
sdk.require(controls.count('browser-harness-36/run-37/RESULT.json') == 1, 'reader-control relocation')
controls = controls.replace('browser-harness-36/run-37/RESULT.json', 'browser-harness-41/run-42/RESULT.json')
with (stage / 'test_browser_review_43.py').open('x') as stream:
    stream.write(controls)
