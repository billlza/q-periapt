from pathlib import Path
import json, os, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
mode = sys.argv[1]
sdk.require(mode in ['msrv', 'ios'], 'platform selection')
toolchain = Path('/Users/bill/.rustup/toolchains/1.90.0-aarch64-apple-darwin') if mode == 'msrv' else root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = {key: value for key, value in os.environ.items() if key not in {'CC', 'CXX', 'AR', 'LD', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'SDKROOT', 'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'OBJC_INCLUDE_PATH', 'LIBRARY_PATH'} and not key.startswith(('CC_', 'CXX_', 'AR_', 'CFLAGS_', 'CXXFLAGS_'))}
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / (mode + '-target-19')), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'), IPHONEOS_DEPLOYMENT_TARGET='16.0', MACOSX_DEPLOYMENT_TARGET='13.0')
cargo = str(toolchain / 'bin/cargo')
compiler = sdk.command([str(toolchain / 'bin/rustc'), '--version', '--verbose'], stage / (mode + '-compiler-19'), root, environment=environment).decode()
sdk.require(compiler.startswith('rustc 1.90.0 ' if mode == 'msrv' else 'rustc 1.98.1 '), 'compiler differs')
if mode == 'msrv':
    sdk.command([cargo, 'test', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--lib', '--all-features', 'durable::rosters::decode_cache::', '--', '--nocapture'], stage / 'msrv-tests-19', root, environment=environment)
else:
    sdk.command([cargo, 'check', '--offline', '--locked', '--manifest-path', str(candidate / 'Cargo.toml'), '--lib', '--all-features', '--target', 'aarch64-apple-ios'], stage / 'ios-check-19', root, environment=environment)
sources = json.loads((stage / 'TARGETED_04.json').read_text())['candidate_files']
sdk.require(sources == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'candidate source changed')
sdk.write_json(stage / (mode.upper() + '_19.json'), {'completed': True, 'mode': mode, 'compiler': compiler, 'candidate_files': sources, 'physical_device_execution': False})
print(mode + ' candidate validation passed')
