from pathlib import Path
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
text = (stage / 'instrument-09.py').read_text()
for old, new in [
    ('instrumented-candidate-09', 'instrumented-candidate-10'),
    ('instrumented-fixture-09', 'instrumented-fixture-10'),
    ('instrumented-target-09', 'instrumented-target-10'),
    ('INSTRUMENTATION_09.json', 'INSTRUMENTATION_10.json'),
    ('metadata-09', 'metadata-10'),
    ('compile-09', 'compile-10'),
    ('BUILD_INPUTS_09.json', 'BUILD_INPUTS_10.json'),
    ('BUILD_09.json', 'BUILD_10.json'),
]:
    sdk.require(old in text, 'recipe replacement anchor')
    text = text.replace(old, new)
old = '''for change in changes:
    path = candidate / change['path']
    value = path.read_text()
    sdk.require(value.count(change['old']) == 1, 'diagnostic insertion anchor: ' + change['path'])
    path.write_text(value.replace(change['old'], change['new']))'''
new = '''def instrument(name, value):
    for change in [c for c in changes if c['path'] == name]:
        sdk.require(value.count(change['old']) > 0, 'diagnostic insertion anchor: ' + name)
        count = 1 if change.get('selected_function') == 'PublicKey::verify' else value.count(change['old'])
        value = value.replace(change['old'], change['new'], count)
    return value
for name in {c['path'] for c in changes}:
    original_source = root / 'research/continuity-identity-candidate' / name
    sdk.require(instrument(name, original_source.read_text()).encode() == (prior / 'candidate' / name).read_bytes(), 'reconstructed baseline instrumentation differs: ' + name)
    path = candidate / name
    path.write_text(instrument(name, path.read_text()))'''
sdk.require(text.count(old) == 1, 'instrumentation recipe anchor')
text = text.replace(old, new)
text = text.replace("restored.count(change['new']) == 1", "restored.count(change['new']) > 0")
with (stage / 'instrument-10.py').open('x') as output:
    output.write(text)
sdk.write_json(stage / 'INSTRUMENTATION_FAILURE_09.json', {'completed': False, 'phase': 'source preparation before compilation or runtime', 'reason': 'Recipe assumed one match for each insertion; DatabaseCommit intentionally has multiple sites and the signature-purpose span is specific to PublicKey::verify.', 'preserved_source': 'instrumented-candidate-09', 'replacement': 'instrument-10.py reconstructs the already accepted diagnostic baseline bytes before applying the identical instrumentation to the optimized source'})
