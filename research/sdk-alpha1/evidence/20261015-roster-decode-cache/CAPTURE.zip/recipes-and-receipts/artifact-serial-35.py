from pathlib import Path
import datetime, json, os, re, signal, subprocess, sys, time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = json.loads((stage / 'CLONE_SOURCE_24.json').read_text())
clone = Path(source['clone'])
sdk.require(json.loads((stage / 'BROWSER_FINAL.json').read_text())['completed'], 'finish browser diagnostics and acceptance before serial artifact run')
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == source['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'artifact source changed')
argv = [sys.executable, '-B', str(clone / 'artifact/python_bootstrap.py'), '-m', 'unittest', 'discover', '-s', 'artifact', '-p', 'test_*.py', '-v']
stdout = stage / 'full-artifact-tests-35.stdout'
stderr = stage / 'full-artifact-tests-35.stderr'
record = {'completed': False, 'argv': argv, 'cwd': str(clone), 'source_commit': source['source_commit'], 'outer_deadline_seconds': 2700, 'maximum_stream_bytes': 16*1024**2, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_attempt': 'ARTIFACT_TIMEOUT_34.json', 'assertions_changed': False}
with stdout.open('xb') as output, stderr.open('xb') as errors:
    process = subprocess.Popen(argv, cwd=clone, stdin=subprocess.DEVNULL, stdout=output, stderr=errors, start_new_session=True)
    record['pid'] = process.pid
    sdk.write_json(stage / 'ARTIFACT_RUNNING_35.json', record)
    print(json.dumps({'pid': process.pid, 'source_commit': source['source_commit']}), flush=True)
    deadline = time.monotonic() + 2700
    try:
        while True:
            try:
                status = process.wait(timeout=min(10, max(.1, deadline-time.monotonic())))
                break
            except subprocess.TimeoutExpired:
                if time.monotonic() >= deadline or max(stdout.stat().st_size, stderr.stat().st_size) > 16*1024**2:
                    record['limit_failure'] = 'deadline' if time.monotonic() >= deadline else 'stream size'
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                    status = 124
                    break
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
record.update(returncode=status, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == source['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone))
summary = re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$', stderr.read_text())
record['completed'] = status == 0 and record['source_unchanged'] and summary is not None and int(summary[1]) >= 2879
if summary is not None:
    record.update(test_count=int(summary[1]), test_seconds=float(summary[2]), skipped=0)
sdk.write_json(stage / 'ARTIFACT_35.json', record)
sdk.require(record['completed'], 'full artifact suite incomplete or failed; inspect live-retained streams')
source_gate = json.loads((stage / 'SOURCE_GATE_39.json').read_text())
sdk.require(source_gate['completed'] and source_gate['source_commit'] == source['source_commit'], 'exact source gate missing')
sdk.write_json(stage / 'CLONE_VALIDATION_24.json', {'completed': True, 'source_commit': source['source_commit'], 'full_artifact_suite': True, 'artifact_receipt': 'ARTIFACT_35.json', 'artifact_stderr': str(stderr), 'source_gate': True, 'source_gate_receipt': 'source-gate-39.json', 'release_claim_eligible': False, 'hosted_ci': False})
print(json.dumps({'completed': True, 'test_count': record['test_count'], 'test_seconds': record['test_seconds'], 'source_gate': True}))
