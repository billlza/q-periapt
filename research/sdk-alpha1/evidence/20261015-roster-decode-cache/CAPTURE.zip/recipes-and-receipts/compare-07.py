from pathlib import Path
import json, os, platform, re, subprocess, sys, time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
baseline_stage = root / 'target/continuity-session-cost-20261015'
baseline = json.loads((baseline_stage / 'BUILD_07.json').read_text())
optimized = json.loads((stage / 'BUILD_06.json').read_text())
sdk.require(optimized['completed'] and not optimized['instrumented'], 'optimized build incomplete')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
sdk.require(head == optimized['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'product source changed')
# The old executable remains eligible only when its SDK sources are identical.
sdk.require(not subprocess.check_output(['git', 'diff', '--name-only', baseline['source_commit'], head, '--', 'Cargo.toml', 'Cargo.lock', 'crates', 'research/continuity-identity-candidate'], cwd=root), 'baseline product source drift')
sys.path.insert(0, str(baseline_stage))
from public_review_12 import verify, quantiles

label = sys.argv[1]
samples = int(sys.argv[2])
blocks = int(sys.argv[3])
sdk.require(re.fullmatch(r'[a-z0-9-]+', label) is not None and 8 <= samples <= 128 and samples % 4 == 0 and 1 <= blocks <= 5, 'bounded fresh comparison')
output = stage / label
output.mkdir(mode=0o700)
state = {'completed': False, 'source_commit': head, 'samples_per_run': samples, 'block_count': blocks, 'runs': [], 'machine': platform.machine(), 'os_release': platform.release(), 'release_claim_eligible': False, 'host_controls': 'Uncontrolled host; paired reversed order, no concurrent task builds started by this runner', 'memory_scope': 'Whole observer process with both SDK peers, optional witness and fixture buffers; Darwin maxrss bytes', 'energy_measured': False}
seen_sessions = set()

def verify_sources():
    for name, digest in baseline['fixture_files'].items():
        sdk.require(sdk.snapshot(baseline_stage / 'fixture-06' / name).sha256 == digest, 'baseline fixture changed')
    for name, digest in optimized['files'].items():
        sdk.require(sdk.snapshot(stage / name).sha256 == digest, 'optimized sources changed')
    for build in [baseline, optimized]:
        sdk.require(sdk.snapshot(Path(build['binary']), maximum=256*1024**2).sha256 == build['binary_sha256'], 'measured executable changed')

try:
    verify_sources()
    for block in range(blocks):
        profiles = ['local', 'witness'] if block % 2 == 0 else ['witness', 'local']
        for profile in profiles:
            variants = ['baseline', 'optimized'] if (block + (profile == 'witness')) % 2 == 0 else ['optimized', 'baseline']
            for variant in variants:
                build = baseline if variant == 'baseline' else optimized
                folder = output / f'{block:02}-{profile}-{variant}'
                folder.mkdir(mode=0o700)
                environment = {k: v for k, v in os.environ.items() if not k.startswith(('DYLD_', 'LD_', 'QPERIAPT_PUBLIC_SERVICE_', 'QPC_COST_'))}
                environment.update(QPC_COST_PROFILE=profile, QPC_COST_SAMPLES=str(samples), QPC_COST_OUTPUT=str(folder / 'RESULT.json'), QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(folder / 'runtime'), RUST_BACKTRACE='1')
                row = {'block': block, 'profile': profile, 'variant': variant, 'folder': folder.name, 'completed': False, 'binary_sha256': build['binary_sha256'], 'load_before': os.getloadavg(), 'started_unix': time.time()}
                state['runs'].append(row)
                print(json.dumps({'block': block, 'profile': profile, 'variant': variant, 'phase': 'fresh runtime'}), flush=True)
                raw = sdk.command(['/usr/bin/time', '-l', '-o', str(folder / 'time.txt'), build['binary'], '--exact', 'measure_session_cost', '--nocapture', '--test-threads=1'], folder / 'command', root, environment=environment)
                sdk.require(re.search(rb'test result: ok\. 1 passed; 0 failed; 0 ignored;', raw) is not None, 'actual measurement missing')
                value = json.loads((folder / 'RESULT.json').read_text())
                sdk.require(value['profile'] == profile and value['samples_per_block'] == samples, 'observed workload differs from requested profile')
                checked = verify(value)
                sdk.require(tuple(value['session']) not in seen_sessions, 'session identity reused')
                seen_sessions.add(tuple(value['session']))
                effects = folder / 'runtime/responder/measured-effects'
                sdk.require({p.name for p in effects.iterdir()} == set(checked['effects']), 'public business file census')
                for name, expected in checked['effects'].items():
                    sdk.require(sdk.snapshot(effects / name, maximum=32768).data == expected, 'actual public business effect differs')
                expected_counts = {1: 20, 2: 5} if profile == 'witness' else {}
                sdk.require(all(c == expected_counts for c in checked['witness_per_sample']), 'witness query/advance contract changed')
                resources = (folder / 'time.txt').read_text()
                cpu = re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys', resources)
                rss = re.search(r'^\s*(\d+)\s+maximum resident set size\s*$', resources, re.M)
                sdk.require(cpu is not None and rss is not None, 'resource output missing')
                row.update(completed=True, runtime_sealed=True, result_sha256=sdk.snapshot(folder / 'RESULT.json').sha256, public_effects_verified=len(checked['effects']), samples=len(value['samples']), send_ns=quantiles([r['send_ns'] for r in value['samples']]), resources={'real_seconds': float(cpu[1]), 'user_seconds': float(cpu[2]), 'system_seconds': float(cpu[3]), 'max_rss_bytes': int(rss[1])}, load_after=os.getloadavg(), finished_unix=time.time())
                print(json.dumps({k: row[k] for k in ['block', 'profile', 'variant', 'completed', 'send_ns', 'resources']}), flush=True)
    verify_sources()
    sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) and subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head, 'product source changed during comparison')
    state['completed'] = True
except BaseException as error:
    state['failure'] = repr(error)
    raise
finally:
    sdk.write_json(output / 'COMPARISON.json', state)
print('Fresh paired comparison complete; every runtime cohort sealed')
