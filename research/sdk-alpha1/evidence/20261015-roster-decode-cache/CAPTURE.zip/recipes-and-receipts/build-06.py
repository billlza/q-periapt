from pathlib import Path
import json, os, shutil, subprocess, tomllib
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
fixture = stage / 'fixture-06'
focused = json.loads((stage / 'TARGETED_04.json').read_text())
sdk.require(focused['completed'], 'focused tests incomplete')
shutil.copytree(stage / 'fixture', fixture)
for name in ['Cargo.toml', 'tests/session_cost.rs']:
    path = fixture / name
    text = path.read_text()
    old = str(stage / 'candidate')
    sdk.require(text.count(old) == 1, 'expected isolated candidate reference')
    path.write_text(text.replace(old, str(candidate)))
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-06'), PATH=str(toolchain / 'bin') + ':' + environment['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'))
cargo = str(toolchain / 'bin/cargo')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'product source dirty')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
sdk.command([str(toolchain / 'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'), '--version'], stage / 'objcopy-06', root, environment=environment)
sdk.command([cargo, 'metadata', '--format-version', '1', '--offline', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'metadata-06', root, environment=environment)
def registry(path):
    return {(p['name'], p['version'], p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
actual = registry(fixture / 'Cargo.lock')
allowed = registry(root / 'Cargo.lock') | registry(root / 'research/continuity-identity-candidate/Cargo.lock')
sdk.require(actual <= allowed, 'observer dependency drift')
def files():
    return {str(p.relative_to(stage)): sdk.snapshot(p).sha256 for base in [candidate, fixture] for p in base.rglob('*') if p.is_file()}
sources = files()
sdk.require(focused['candidate_files'] == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'candidate differs from focused test inputs')
sdk.write_json(stage / 'BUILD_INPUTS_06.json', {'source_commit': head, 'files': sources, 'canonical_registry_dependencies': sorted(actual), 'instrumented': False})
sdk.command([cargo, 'test', '--offline', '--locked', '--release', '--no-run', '--test', 'session_cost', '--message-format=json', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'compile-06', root, environment=environment)
records = [json.loads(row) for row in (stage / 'compile-06.stdout').read_text().splitlines() if row.startswith('{')]
binaries = [r['executable'] for r in records if r.get('reason') == 'compiler-artifact' and r.get('executable') and r['target']['name'] == 'session_cost']
sdk.require(len(binaries) == 1 and sources == files(), 'observer identity/source changed')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) and subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head, 'product source changed')
sdk.write_json(stage / 'BUILD_06.json', {'completed': True, 'source_commit': head, 'binary': binaries[0], 'binary_sha256': sdk.snapshot(Path(binaries[0]), maximum=256*1024**2).sha256, 'files': sources, 'instrumented': False, 'profile': 'release opt-level=3 thin-LTO codegen-units=1 overflow-checks=true'})
print('Uninstrumented optimized observer compiled')
