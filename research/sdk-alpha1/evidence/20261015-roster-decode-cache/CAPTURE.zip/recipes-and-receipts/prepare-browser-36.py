from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
controls = json.loads((stage / 'BOOTSTRAP_CONTROLS_33.json').read_text())
sdk.require(controls['completed'] and controls['all_bootstraps_passed'], 'paired bootstrap diagnostics incomplete')
source = stage / 'browser-harness-27'
output = stage / 'browser-harness-36'
output.mkdir()
for name in ['worker.js', 'controller.js', 'session-checks.js']:
    sdk.copy(source / name, output / name)
sdk.copy(stage / 'bootstrap-harness-32/server.py', output / 'server.py')
sdk.copy(source / 'run-27.py', output / 'run-36.py')
sdk.write_json(stage / 'BROWSER_SOURCE_36.json', {'files': {p.name: sdk.snapshot(p).sha256 for p in output.iterdir()}, 'change_from_failed_harness': 'Only native peer elapsed-time observations added to the test server; fresh output roots and temporary browser session. SDK, inputs generation, caller deadlines and assertions unchanged.', 'previous_failed_runtime': 'browser-harness-27/run-28', 'previous_runtime_reopened': False})
