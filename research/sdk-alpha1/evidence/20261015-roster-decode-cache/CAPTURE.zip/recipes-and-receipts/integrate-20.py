from pathlib import Path
import json, subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
candidate = stage / 'candidate-04'
base = '0037d195e2342c0c03ced5653d30b9762a5528be'
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'product checkout changed; do not overwrite unrelated work')
for name in ['TARGETED_04.json', 'QUALIFIED_14.json', 'LINT_13.json', 'PORTABLE_08.json', 'MSRV_19.json', 'IOS_19.json', 'SUMMARY_17.json', 'COUNTS_12.json']:
    sdk.require(json.loads((stage / name).read_text())['completed'], 'required local gate incomplete: ' + name)
source = json.loads((stage / 'SOURCE_01.json').read_text())
names = source['expected_changed_original_files'] + source['new_files']
tested = json.loads((stage / 'QUALIFIED_14.json').read_text())['source_inputs']
sdk.require(tested == {str(p.relative_to(candidate)): sdk.snapshot(p).sha256 for p in candidate.rglob('*') if p.is_file()}, 'tested source changed')
prefix = 'research/continuity-identity-candidate/'
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', prefix], cwd=root).decode().split('\0')
for relative in [p for p in tracked if p.endswith('.rs')]:
    name = relative[len(prefix):]
    if name not in names:
        sdk.require(sdk.snapshot(root / relative).sha256 == tested[name], 'unselected engine source differs')
changes = []
for name in names:
    path = root / prefix / name
    sdk.require(path.exists() == (name in source['expected_changed_original_files']), 'unexpected integration destination')
    old = sdk.snapshot(path).sha256 if path.exists() else None
    data = sdk.snapshot(candidate / name).data
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    changes.append({'path': prefix + name, 'before_sha256': old, 'after_sha256': sdk.snapshot(path).sha256})
edits = [
    ('artifact/codeql_rust_quality.py', 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 691', 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 693', 1),
    ('ARTIFACT.md', '691 tracked `.rs` files to be successfully extracted', '693 tracked `.rs` files to be successfully extracted', 1),
    ('artifact/test_codeql_rust_quality.py', '            "research/continuity-identity-candidate/src/durable/rosters/peer_roster.rs",', '            "research/continuity-identity-candidate/src/durable/rosters/peer_roster.rs",\n            "research/continuity-identity-candidate/src/durable/rosters/decode_cache.rs",\n            "research/continuity-identity-candidate/src/durable/rosters/decode_cache/tests.rs",', 2),
]
for name, old, new, count in edits:
    path = root / name
    before = sdk.snapshot(path)
    text = before.data.decode()
    sdk.require(text.count(old) == count, 'exact inventory edit differs: ' + name)
    path.write_text(text.replace(old, new))
    changes.append({'path': name, 'before_sha256': before.sha256, 'after_sha256': sdk.snapshot(path).sha256})
sdk.write_json(stage / 'INTEGRATED_20.json', {'completed': True, 'base_commit': base, 'changes': changes, 'native_all_lib_tests': 1025, 'new_codeql_paths': 2, 'hosted_validation': False, 'packaged_device_validation_of_this_delta': False, 'release_claim_eligible': False})
print('Locally validated roster memo integrated with both new CodeQL source paths')
