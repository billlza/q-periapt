from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
path = stage / 'browser-harness-27/run-28/RESULT.json'
state = json.loads(path.read_text())
summary = {'completed': state['completed'], 'failure': state.get('failure'), 'fixture_failures': state['fixture_failures'], 'worker_actions': [{'action': r['action'], 'error': r['result'].get('error')} for r in state['observations']], 'witness': state['witness_records'], 'peer': state['peer_records'], 'runtime_sealed': True, 'runtime_reopened': False}
sdk.write_json(stage / 'BROWSER_FAILURE_30.json', summary)
print(json.dumps(summary))
