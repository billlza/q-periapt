from pathlib import Path
import copy
import json
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from browser_public_review import verify


class PublicReviewControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = json.loads((Path(__file__).parent / 'browser-harness-27/run-28/RESULT.json').read_text())

    def test_complete_producer(self):
        result = verify(self.original)
        self.assertEqual(set(result), {'applied', 'unapplied'})
        self.assertEqual(sum(v['worker_terminations'] for v in result.values()), 4)

    def test_every_call_substitution_is_rejected(self):
        for index in range(len(self.original['observations'])):
            with self.subTest(index=index):
                state = copy.deepcopy(self.original)
                state['observations'][index]['action'] = 'substituted-action'
                with self.assertRaises(ValueError):
                    verify(state)

    def test_applied_target_cannot_claim_query_only_after_controller(self):
        state = copy.deepcopy(self.original)
        state['cases'][1]['pending_recovery']['controller_invoked'] = True
        with self.assertRaisesRegex(ValueError, 'approval'):
            verify(state)

    def test_missing_actual_worker_termination(self):
        state = copy.deepcopy(self.original)
        state['cases'][0]['pending_recovery']['interruptions'][1]['workerTerminatedBeforeConfirmation'] = False
        with self.assertRaisesRegex(ValueError, 'Worker terminations'):
            verify(state)

    def test_ciphertext_substitution(self):
        state = copy.deepcopy(self.original)
        key = next(iter(state['peer_records']))
        rows = [row for row in state['peer_records'][key] if row['kind'] == 3]
        rows[1]['request_sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'ciphertext'):
            verify(state)

    def test_extra_unknown_business_effect(self):
        state = copy.deepcopy(self.original)
        state['cases'][0]['native_effects'] += 1
        with self.assertRaisesRegex(ValueError, 'effect'):
            verify(state)


if __name__ == '__main__':
    unittest.main()
