from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=Path(__file__).resolve().parent;package=root/'target/continuity-browser-publication/source/target/browser-roster-cache-package-26'
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Pending recovery and original session continuation</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-pending-continuation/native-target-05/debug';authority=binary/'witness';provisioner=binary/'seed';roster=binary/'issuer';peer=binary/'peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
producer={str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [node,cli,Path(__file__),stage/'worker.js',stage/'controller.js',stage/'session-checks.js',stage/'server.py']}
state={'completed':False,'release_claim_eligible':False,'producer':producer,'scope':'Installed browser exact ordinary pending R2 recovery across expiry, cancellation and Worker loss, bilateral P renewal, original ciphertext/control and bidirectional traffic; same Rust engine and loopback, not independent implementation/PCS/release','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,provisioner,roster,peer]},'cases':[],'observations':[]}
allowed={'unapplied','applied'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster session result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'result':value['result']});sdk.require(value['result'].get('cleanupErrors',[])==[],'Worker cleanup failure');return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def native_trace(case,name):
 trace=out/'native'/case/name;trace.mkdir(mode=0o700,parents=True);return trace
def peer_result(args,label):return parse_strict_json_bytes(native(peer,args,label),label=label)

def recover_pending(args,case,directory,row,records,inputs,out,witness):
    base={**args,'historicalOnly':True}; observed=len(records[args['case']])
    pending=success({**base,'action':'pending-request'})
    repeated=success({**base,'action':'pending-request'})
    for field in ['proposal','metadata','document','binding']:sdk.require(pending[field]==repeated[field],'original retained input changed')
    sdk.require(not pending['runtimeCreated'] and pending['observedAt']>row['real_expiry']['policy_until'],'operational permission used during recovery')
    sdk.require(len(records[args['case']])==observed,'public pending request sent witness traffic')
    folder=out/'accounting'/case;folder.mkdir(parents=True,mode=0o700)
    def retain(name,value):
        path=folder/name
        with path.open('xb') as stream:stream.write(value);stream.flush();os.fsync(stream.fileno())
        fd=os.open(folder,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
        sdk.require(path.read_bytes()==value,'retained public input readback');return path
    proposal=retain('proposal.bin',bytes(pending['proposal']));metadata=retain('metadata.bin',bytes(pending['metadata']));signed=retain('signed.bin',bytes(pending['signed']))
    retain('inspection.json',pending['document'].encode());session=retain('session.bin',bytes(args['session']));message=retain('message.bin',bytes(args['message']))
    review=folder/'independent-review.json'
    native(witness,['inspect-pending',directory,proposal,metadata,inputs/(args['case']+'-peer.json'),inputs/(args['case']+'-r2.json'),session,message,review],case+'-inspect-pending')
    independent=json.loads(review.read_text());sdk.require(independent['verified'] and not independent['mutated_witness'] and independent['proposal_binding']==pending['binding'],'independent exact-delta review failed')
    confirm={**base,'action':'pending-confirm','approved':pending['proposal'],'metadata':pending['metadata']}
    if case=='unapplied':
        rejected(confirm,'Scope')
    damaged=list(pending['metadata']);damaged[-1]^=1;before=len(records[args['case']])
    rejected({**confirm,'metadata':damaged},'Authentication')
    sdk.require(len(records[args['case']])==before,'modified metadata reached witness')
    result={'proposal':pending['proposal'],'metadata':pending['metadata'],'binding':pending['binding'],'inspection':independent,'interruptions':[],'controller_invoked':False}
    if case=='unapplied':
        completion=folder/'controller.json'
        native(witness,['complete-pending-write',directory,proposal,metadata,signed,completion],case+'-complete-exact-pending')
        record=json.loads(completion.read_text());sdk.require(record['confirmed'] and record['proposal_binding']==pending['binding'] and record['at']>row['real_expiry']['policy_until'],'wrong independently completed intent')
        result['controller_invoked']=True;result['controller']=record
    before=len(records[args['case']])
    cancel=invoke({**confirm,'mode':'hold-query','cut':'10','cancelAfterQuery':True})
    sdk.require(cancel.get('code')=='Cancelled' and cancel.get('ownerClosed') is True and cancel.get('closeReceipt')=={'closeComplete':True,'closed':True},'held-query cancellation failed')
    result['interruptions'].append(cancel)
    for field in ['proposal','metadata']:sdk.require(success({**base,'action':'pending-request'})[field]==pending[field],'cancellation changed original intent')
    cut=invoke({**confirm,'mode':'hold-query','cut':'20','killAfterQuery':True})
    sdk.require(cut.get('workerTerminatedBeforeConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual pre-confirmation Worker termination')
    result['interruptions'].append(cut)
    retained=success({**base,'action':'pending-request'})
    sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'Worker loss changed original intent')
    cut=invoke({**confirm,'killAfterLocalConfirmation':True})
    sdk.require(cut.get('workerTerminatedAfterConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual post-confirmation Worker termination')
    result['interruptions'].append(cut)
    rejected({**base,'action':'pending-request'},'Absent')
    for _ in range(2):sdk.require(success(confirm)['confirmed'],'exact repeated confirmation failed')
    tags=[r['request_tag'] for r in records[args['case']][before:]]
    sdk.require(tags==[1,1,1,1,1],'confirmation did not remain Query-only')
    result.update(confirmation_request_tags=tags,public_retained={p.name:sdk.snapshot(p).sha256 for p in folder.iterdir() if p.is_file()})
    print(json.dumps({'case':case,'phase':'original pending write recovered','controller_invoked':result['controller_invoked'],'worker_terminations':2}),flush=True)
    return result

try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_session_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_session_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    print(json.dumps({'case':case,'phase':'fresh enrollment'}),flush=True)
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(provisioner,['prepare-expiring-policy',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(provisioner,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace(case,'prepare')],case+'-peer-prepare')
    peer_data=json.loads((inputs/(key+'-peer.json')).read_text())
    args['requestId']=success({**args,'action':'session','sessionAction':'new-request'})['requestId']
    established=success({**args,'action':'session','sessionAction':'establish'});args['session']=established['session'];row['session']=args['session'];row['requestId']=args['requestId'];(directory/'peer/session.json').write_text(json.dumps(args['session']))
    args['message']=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['message']=args['message']
    row['pending_delivery']=rejected({**args,'action':'session','sessionAction':'send','peerMode':'drop-ack'},'PeerTransport')
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'lost application ACK not retained')
    session_file=out/(case+'-session.json');session_file.write_text(json.dumps(args['session']));reverse=inputs/(key+'-reverse.bin')
    reverse_prepared=peer_result(['send-prepare',directory,session_file,reverse,native_trace(case,'reverse-prepare')],case+'-reverse-prepare');sdk.require(reverse_prepared['original_dispatched'] and not reverse_prepared['consumption_confirmed'] and reverse_prepared['owner_closed'],'native pending outcome');row['reverse_prepared']=reverse_prepared;args['reverseMessage']=reverse_prepared['message']
    row['pending_rekey']=rejected({**args,'action':'session','sessionAction':'drive-rekey','target':1,'peerMode':'control-drop-first'},'PeerTransport')
    pending=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(pending['confirmed']=='0' and pending['pending']=='1','original pending control absent');row['progress_before']=pending
    args['operationId']=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']
    target_file=inputs/(key+'-r2.json')
    native(peer,['peer-target',directory,2,'member',target_file],case+'-peer-r2')
    mode='drop-advance' if case=='applied' else 'drop-before-advance'
    row['ordinary_cut']=rejected({**args,'action':'session','sessionAction':'peer-roster','targetFile':target_file.name,'mode':mode,'cut':'1'},'WitnessTransport')
    fault=[r for r in witness_records[key] if r['mode']==mode and r['cut']=='1' and r['trigger']]
    sdk.require(len(fault)==1 and fault[0]['request_tag']==2 and fault[0]['dispatched']==(case=='applied'),'incorrect R2 write cut')
    row['ordinary_fault']=fault[0]

    if case in allowed:
     row['real_expiry']={'policy_until':cfg['policy_until'],'credentials_until':cfg['until'],'pending_at':int(time.time())}
     sdk.require(time.time()<cfg['policy_until']<cfg['until'],'wrong expiry baseline')
     print(json.dumps({'case':case,'waiting_until':cfg['policy_until']+1}),flush=True)
     while time.time()<cfg['policy_until']+1:time.sleep(min(10,max(0.1,cfg['policy_until']+1-time.time())))
     row['real_expiry']['renew_at']=int(time.time())
    row['pending_recovery']=recover_pending(args,case,directory,row,witness_records,inputs,out,authority)
    request=success({**args,'action':'policy-request','historicalOnly':True});row['request']=request
    request_file=out/(case+'-request.json');sdk.write_json(request_file,request['requestValue']);renewal=inputs/(key+'-approval.json')
    row['issued']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,renewal,'required'],case+'-policy-issuer'),label='policy issuer')
    row['staged']=success({**args,'action':'p-stage','historicalOnly':True})
    created=success({**args,'action':'p-prepare','historicalOnly':True});row['prepared']=created;args['proposal']=created['proposal']
    proposal=out/(case+'-proposal.bin');proposal.write_bytes(bytes(created['proposal']))
    row['witness_preparation']=parse_strict_json_bytes(native(roster,[directory,grant,request_file,renewal,'required',proposal],case+'-policy-witness'),label='witness preparation')
    if case in ['drop-commit','drop-ack','cancel']:
     mode={'drop-commit':'drop-after-advance','drop-ack':'drop-ack','cancel':'hold-after-advance'}[case]
     row['policy_loss']=rejected({**args,'action':'p-commit','historicalOnly':True,'mode':mode,'cancelOnAdvance':case=='cancel'},'Cancelled' if case=='cancel' else 'WitnessTransport')
     row['interrupted']=success({**args,'action':'p-status','historicalOnly':True})
     if case=='drop-ack':sdk.require(row['interrupted']['progress']['stage']==2 and not row['interrupted']['progress']['retired'],'missing terminal before ACK')
     if case=='cancel':sdk.require(row['policy_loss']['cancellationRequested'],'no actual cancellation')
     row['committed']=success({**args,'action':'p-reconcile','historicalOnly':True})
    else:row['committed']=success({**args,'action':'p-commit','historicalOnly':True})
    sdk.require(row['committed']['remote']==2 and row['committed']['progress']['retired'],'P commit/retirement incomplete')
    row['active']=success({**args,'action':'p-activate','historicalOnly':True})
    sdk.require(row['active']['journal']==original['journal'] and row['active']['status']['phase']==3,'policy replaced original journal or not committed')
    row['native_policy']=peer_result(['renew-policy',directory,renewal,native_trace(case,'renew-policy')],case+'-native-policy')
    sdk.require(row['native_policy']['policy_renewed'] and row['native_policy']['same_original_journal'] and row['native_policy']['session']==args['session'] and row['native_policy']['original_policy_expired']is True,'native policy continuation failed')
    late=invoke({**args,'action':'pending-confirm','historicalOnly':True,'approved':row['pending_recovery']['proposal'],'metadata':row['pending_recovery']['metadata']})
    sdk.require(late.get('code')=='Conflict','advanced P head accepted stale pending-write confirmation')
    args.update(continued=True,historicalOnly=True)
    row['legacy_refused']=rejected({**args,'action':'session','sessionAction':'rekey-progress','legacyReopen':True},'Conflict')
    after=success({**args,'action':'session','sessionAction':'rekey-progress'});sdk.require(after==pending,'P changed original rekey');row['progress_after']=after
    sdk.require(success({**args,'action':'session','sessionAction':'status'})=={'status':2},'G lost original application outbox')
    completed=success({**args,'action':'session','sessionAction':'drive-rekey','target':1});sdk.require(completed['epoch']=='1','original rekey incomplete');row['rekey']=completed
    control_frames=[r for r in peer_records[key] if r['kind']==4];sdk.require(len(control_frames)>=2 and control_frames[0]['trigger'] and control_frames[0]['request_sha256']==control_frames[1]['request_sha256'],'P changed first control replay')
    delivery=success({**args,'action':'session','sessionAction':'send'});sdk.require(delivery=={'consumption':1,'status':3},'original application not acknowledged');row['delivery']=delivery
    message_frames=[r['request_sha256'] for r in peer_records[key] if r['kind']==3];sdk.require(len(message_frames)==2 and len(set(message_frames))==1,'P changed original ciphertext')
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(args['session'])+bytes(args['message'])+b'browser to native','native effect duplicated/changed')
    received=success({**args,'action':'session','sessionAction':'receive'});sdk.require(received['application']['calls']==1 and received['application']['effects']==1,'browser original effect');row['received']=received
    duplicate=success({**args,'action':'session','sessionAction':'receive'});sdk.require(not duplicate['callbackInvoked'] and duplicate['reply']==received['reply'] and duplicate['application']==received['application'],'duplicate released plaintext or changed ACK');row['duplicate']=duplicate
    ack=out/(case+'-reverse-ack.bin');ack.write_bytes(bytes(received['reply']));row['reverse_finished']=peer_result(['send-finish',directory,reverse,ack,native_trace(case,'reverse-finish')],case+'-reverse-finish')
    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;sdk.require(fresh!=args['message'],'new work reused original message identity');sdk.require(success({**args,'action':'session','sessionAction':'send','message':fresh,'plaintext':'after P'})=={'consumption':1,'status':3},'fresh post-P message failed')
    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==2,'new message did not create exactly one new effect');row['completed']=True;row['native_effects']=len(effects)
    row['witness_records']=witness_records[key];row['peer_records']=peer_records[key];sdk.require(not failures,'fixture failures: '+json.dumps(failures));print(json.dumps({'case':case,'passed':True,'witness_requests':len(row['witness_records']),'peer_requests':len(row['peer_records'])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 for n,d in producer.items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'producer drift')
 state['producer_unchanged']=True;state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:
 state['witness_records']=witness_records if 'witness_records' in globals() else {};state['peer_records']=peer_records if 'peer_records' in globals() else {};state['fixture_failures']=failures if 'failures' in globals() else [];sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
