from pathlib import Path
import contextlib,json,os,sys,uuid,shutil,time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=Path(__file__).resolve().parent;package=Path(os.environ['QPC_BROWSER_DIAGNOSTIC_PACKAGE'])
installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=stage/sys.argv[1];out.mkdir(mode=0o700);logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True);(web/'creation').mkdir(exist_ok=True)
for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Pending recovery and original session continuation</title><script type="module" src="./controller.js"></script>')
session='qpc-roster-session-'+uuid.uuid4().hex;node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-pending-continuation/native-target-05/debug';authority=binary/'witness';provisioner=binary/'seed';roster=binary/'issuer';peer=binary/'peer'
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')
producer={str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [node,cli,Path(__file__),stage/'worker.js',stage/'controller.js',stage/'session-checks.js',stage/'server.py']}
state={'completed':False,'release_claim_eligible':False,'producer':producer,'scope':'Fresh installed-package bootstrap diagnostic only; six public Worker calls, unchanged 10-second caller deadline, no lifecycle acceptance claim','source':json.loads((package/'sources-before.json').read_text()),'static_web':static,'native':{str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [authority,provisioner,roster,peer]},'cases':[],'observations':[]}
allowed={'unapplied','applied'}
sdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0
def browser(args,label):
 with contextlib.chdir(out):r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr);sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode});sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure');return r.stdout
def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}';script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode();sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='roster session result');sdk.require(value['diagnostics']==[],'browser diagnostics');state['observations'].append({'case':args['case'],'action':args.get('sessionAction',args['action']),'result':value['result']});sdk.require(value['result'].get('cleanupErrors',[])==[],'Worker cleanup failure');return value['result']
def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
def rejected(args,code):
 value=invoke(args);sdk.require(value.get('code')==code and value.get('ownerClosed') is True,'wrong failure: '+json.dumps(value));return value
def native(binary,args,label):return sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))
def native_trace(case,name):
 trace=out/'native'/case/name;trace.mkdir(mode=0o700,parents=True);return trace
def peer_result(args,label):return parse_strict_json_bytes(native(peer,args,label),label=label)

def recover_pending(args,case,directory,row,records,inputs,out,witness):
    base={**args,'historicalOnly':True}; observed=len(records[args['case']])
    pending=success({**base,'action':'pending-request'})
    repeated=success({**base,'action':'pending-request'})
    for field in ['proposal','metadata','document','binding']:sdk.require(pending[field]==repeated[field],'original retained input changed')
    sdk.require(not pending['runtimeCreated'] and pending['observedAt']>row['real_expiry']['policy_until'],'operational permission used during recovery')
    sdk.require(len(records[args['case']])==observed,'public pending request sent witness traffic')
    folder=out/'accounting'/case;folder.mkdir(parents=True,mode=0o700)
    def retain(name,value):
        path=folder/name
        with path.open('xb') as stream:stream.write(value);stream.flush();os.fsync(stream.fileno())
        fd=os.open(folder,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
        sdk.require(path.read_bytes()==value,'retained public input readback');return path
    proposal=retain('proposal.bin',bytes(pending['proposal']));metadata=retain('metadata.bin',bytes(pending['metadata']));signed=retain('signed.bin',bytes(pending['signed']))
    retain('inspection.json',pending['document'].encode());session=retain('session.bin',bytes(args['session']));message=retain('message.bin',bytes(args['message']))
    review=folder/'independent-review.json'
    native(witness,['inspect-pending',directory,proposal,metadata,inputs/(args['case']+'-peer.json'),inputs/(args['case']+'-r2.json'),session,message,review],case+'-inspect-pending')
    independent=json.loads(review.read_text());sdk.require(independent['verified'] and not independent['mutated_witness'] and independent['proposal_binding']==pending['binding'],'independent exact-delta review failed')
    confirm={**base,'action':'pending-confirm','approved':pending['proposal'],'metadata':pending['metadata']}
    if case=='unapplied':
        rejected(confirm,'Scope')
    damaged=list(pending['metadata']);damaged[-1]^=1;before=len(records[args['case']])
    rejected({**confirm,'metadata':damaged},'Authentication')
    sdk.require(len(records[args['case']])==before,'modified metadata reached witness')
    result={'proposal':pending['proposal'],'metadata':pending['metadata'],'binding':pending['binding'],'inspection':independent,'interruptions':[],'controller_invoked':False}
    if case=='unapplied':
        completion=folder/'controller.json'
        native(witness,['complete-pending-write',directory,proposal,metadata,signed,completion],case+'-complete-exact-pending')
        record=json.loads(completion.read_text());sdk.require(record['confirmed'] and record['proposal_binding']==pending['binding'] and record['at']>row['real_expiry']['policy_until'],'wrong independently completed intent')
        result['controller_invoked']=True;result['controller']=record
    before=len(records[args['case']])
    cancel=invoke({**confirm,'mode':'hold-query','cut':'10','cancelAfterQuery':True})
    sdk.require(cancel.get('code')=='Cancelled' and cancel.get('ownerClosed') is True and cancel.get('closeReceipt')=={'closeComplete':True,'closed':True},'held-query cancellation failed')
    result['interruptions'].append(cancel)
    for field in ['proposal','metadata']:sdk.require(success({**base,'action':'pending-request'})[field]==pending[field],'cancellation changed original intent')
    cut=invoke({**confirm,'mode':'hold-query','cut':'20','killAfterQuery':True})
    sdk.require(cut.get('workerTerminatedBeforeConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual pre-confirmation Worker termination')
    result['interruptions'].append(cut)
    retained=success({**base,'action':'pending-request'})
    sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'Worker loss changed original intent')
    cut=invoke({**confirm,'killAfterLocalConfirmation':True})
    sdk.require(cut.get('workerTerminatedAfterConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual post-confirmation Worker termination')
    result['interruptions'].append(cut)
    rejected({**base,'action':'pending-request'},'Absent')
    for _ in range(2):sdk.require(success(confirm)['confirmed'],'exact repeated confirmation failed')
    tags=[r['request_tag'] for r in records[args['case']][before:]]
    sdk.require(tags==[1,1,1,1,1],'confirmation did not remain Query-only')
    result.update(confirmation_request_tags=tags,public_retained={p.name:sdk.snapshot(p).sha256 for p in folder.iterdir() if p.is_file()})
    print(json.dumps({'case':case,'phase':'original pending write recovered','controller_invoked':result['controller_invoked'],'worker_terminations':2}),flush=True)
    return result

try:
 with serving(web,out,private,authority,peer) as (origin,witness_records,peer_records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => {await page.waitForFunction(()=>typeof globalThis.invoke === "function");await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="roster_session_probe=present; path=/; SameSite=Strict";if(!document.cookie.includes("roster_session_probe=present"))throw Error("cookie control");addEventListener("error",e=>diagnostics.push(e.message));addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));});return {ready:true};}');browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    print(json.dumps({'case':case,'phase':'fresh enrollment'}),flush=True)
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700);row={'case':case};state['cases'].append(row)
    native(provisioner,['prepare-expiring-policy',directory],case+'-authority');cfg=json.loads((directory/'PUBLIC.json').read_text())
    shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:8],'id':uuid.uuid4().hex+uuid.uuid4().hex,'profile':'required'}
    success({**args,'action':'create'});grant=inputs/(key+'-grant.json');native(provisioner,['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue');grant_data=json.loads(grant.read_text())
    success({**args,'action':'accept'});prepared=success({**args,'action':'prepare'});sdk.require(prepared['phase']=='requires-witness-enrollment','required witness omitted');native(authority,['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    original=success({**args,'action':'activate'});row['original']=original
    native(peer,['prepare',directory,grant,inputs/(key+'-peer.json'),native_trace(case,'prepare')],case+'-peer-prepare')
    peer_data=json.loads((inputs/(key+'-peer.json')).read_text())
    args['requestId']=success({**args,'action':'session','sessionAction':'new-request'})['requestId']
    bootstrap_started=time.perf_counter_ns()
    established=success({**args,'action':'session','sessionAction':'establish'});args['session']=established['session'];row['session']=args['session'];row['requestId']=args['requestId'];(directory/'peer/session.json').write_text(json.dumps(args['session']))
    row.update(completed=True,bootstrap_wall_ns=time.perf_counter_ns()-bootstrap_started,witness_records=witness_records[key],peer_records=peer_records[key])
    print(json.dumps({'case':case,'bootstrap_completed':True,'bootstrap_wall_ns':row['bootstrap_wall_ns']}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'fixture failures')
 for n,d in static.items():sdk.require(sdk.snapshot(web/n).sha256==d,'static input drift')
 for n,d in state['native'].items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'native binary drift')
 for n,d in producer.items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'producer drift')
 state['producer_unchanged']=True;state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:
 state['witness_records']=witness_records if 'witness_records' in globals() else {};state['peer_records']=peer_records if 'peer_records' in globals() else {};state['fixture_failures']=failures if 'failures' in globals() else [];sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
