// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Fresh witness admission at the real encrypted journal transaction boundary.
use super::*;
use crate::{
    AnchorClient, AnchorClientError, AnchorHead, AnchorOperation, AnchorOutcome, AnchorSubject,
    VerifiedSessionPolicy,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum Protection {
    Local,
    Required {
        policy: [u8; 32],
        witness: [u8; 32],
        fence: u64,
    },
}
impl Protection {
    pub(super) fn encode(self, bytes: &mut Vec<u8>) {
        match self {
            Self::Local => bytes.extend_from_slice(&[0; 73]),
            Self::Required {
                policy,
                witness,
                fence,
            } => {
                bytes.push(1);
                bytes.extend_from_slice(&policy);
                bytes.extend_from_slice(&witness);
                bytes.extend_from_slice(&fence.to_be_bytes());
            }
        }
    }
    pub(super) fn decode(d: &mut Decoder<'_>) -> Result<Self, DurableError> {
        let [mode] = d.array()?;
        let policy = d.array()?;
        let witness = d.array()?;
        let fence = d.u64()?;
        match mode {
            0 if policy == [0; 32] && witness == [0; 32] && fence == 0 => Ok(Self::Local),
            1 if policy != [0; 32] && witness != [0; 32] && fence != 0 && fence != u64::MAX => {
                Ok(Self::Required {
                    policy,
                    witness,
                    fence,
                })
            }
            _ => Err(DurableError::Corrupt),
        }
    }
    pub(super) fn check_policy(
        self,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
    ) -> Result<(), DurableError> {
        let policy = policy.as_ref();
        match (self, policy.anchor_requirement().binding()) {
            (Self::Local, None) => Ok(()),
            (
                Self::Required {
                    policy: saved,
                    witness,
                    ..
                },
                Some(binding),
            ) if saved == policy.checkpoint().digest() && witness == binding => Ok(()),
            (Self::Local, Some(_)) => Err(DurableError::AnchorRequired),
            _ => Err(DurableError::Conflict),
        }
    }
    pub(super) fn head(self, revision: u64, digest: [u8; 32]) -> Result<AnchorHead, DurableError> {
        let Self::Required { fence, .. } = self else {
            return Err(DurableError::AnchorRequired);
        };
        Ok(AnchorHead::from_trusted_state(fence, revision, digest)?)
    }
}

pub(super) struct AttachedAnchor {
    client: AnchorClient,
    subject: AnchorSubject,
}
pub(super) fn cleanup_signer_binding(key: &crate::PublicKey) -> [u8; 32] {
    digest(
        b"Q-PERIAPT-CONTINUITY-ARCHIVED-CLOSURE-SIGNER/v1",
        &key.encode(),
    )
}
#[cfg_attr(
    not(all(target_arch = "wasm32", target_os = "unknown")),
    maybe_async::must_be_sync
)]
impl Active {
    // Only an authenticated local archive may supply this original signer binding.
    // This attaches the unchanged witness subject, not renewed session authority.
    pub(super) fn attach_closure_archive(
        &mut self,
        client: AnchorClient,
        signer: [u8; 32],
    ) -> Result<(), DurableError> {
        if signer != cleanup_signer_binding(&client.signer_public_key()?) {
            return Err(DurableError::Conflict);
        }
        self.attach_retained_cleanup_subject(client)
    }
    // The pinned witness authenticates the original enrolled signing owner.
    // This path can only attach to a subject from an already authenticated image.
    pub(super) fn attach_retained_cleanup_subject(
        &mut self,
        client: AnchorClient,
    ) -> Result<(), DurableError> {
        let Protection::Required {
            policy, witness, ..
        } = self.protection
        else {
            return Err(DurableError::AnchorRequired);
        };
        if witness != client.pin().binding() {
            return Err(DurableError::Conflict);
        }
        let mut bytes = self.id.to_vec();
        bytes.extend_from_slice(&self.owner);
        bytes.extend_from_slice(&policy);
        let subject = AnchorSubject::from_trusted_state(&bytes)?;
        self.anchor = Some(AttachedAnchor { client, subject });
        Ok(())
    }

    fn attach(
        &mut self,
        device: &VerifiedDevice,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        client: AnchorClient,
    ) -> Result<(), DurableError> {
        let policy = policy.as_ref();
        self.protection.check_policy(policy)?;
        let Protection::Required { witness, .. } = self.protection else {
            return Err(DurableError::AnchorRequired);
        };
        if witness != client.pin().binding() || self.owner != bootstrap::storage_owner(device) {
            return Err(DurableError::Conflict);
        }
        client.check_device(device)?;
        policy.check_external_signer(client.pin().public_key())?;
        if client
            .pin()
            .public_key()
            .shares_component(&device.authority_key)
        {
            return Err(Error::Scope.into());
        }
        let subject = AnchorSubject::for_device(JournalIdentity(self.id), device, policy)?;
        self.anchor = Some(AttachedAnchor { client, subject });
        Ok(())
    }
    pub(super) async fn check_current(&mut self, image: &Image) -> Result<(), DurableError> {
    let _cost_span = crate::cost_probe::enter(crate::cost_probe::Phase::AnchorCheckCurrent);
        if self.protection == Protection::Local {
            return Ok(());
        }
        let expected = self.protection.head(image.revision, image.digest)?;
        let anchor = self.anchor.as_mut().ok_or(DurableError::AnchorRequired)?;
        let reply = anchor
            .client
            .exchange(anchor.subject, AnchorOperation::query())
            .await?;
        if reply.outcome() != AnchorOutcome::Current || reply.observed_head() != expected {
            return Err(AnchorClientError::Conflict.into());
        }
        Ok(())
    }
    pub(super) async fn advance_anchor(
        &mut self,
        revision: u64,
        digest: [u8; 32],
        next_digest: [u8; 32],
    ) -> Result<(), DurableError> {
        if self.protection == Protection::Local {
            return Ok(());
        }
        let expected = self.protection.head(revision, digest)?;
        let next = self.protection.head(
            revision.checked_add(1).ok_or(DurableError::Capacity)?,
            next_digest,
        )?;
        let operation = AnchorOperation::advance(expected, next_digest)?;
        let anchor = self.anchor.as_mut().ok_or(DurableError::AnchorRequired)?;
        let reply = anchor.client.exchange(anchor.subject, operation).await?;
        // Verification already binds the complete request and exact command ID.
        if !matches!(
            reply.outcome(),
            AnchorOutcome::Advanced | AnchorOutcome::AlreadyAppliedExact
        ) || reply.applied_head()? != next
        {
            return Err(AnchorClientError::Conflict.into());
        }
        Ok(())
    }
}

#[cfg_attr(
    not(all(target_arch = "wasm32", target_os = "unknown")),
    maybe_async::must_be_sync
)]
impl DeviceJournal {
    // Fresh G/T or independent-P admission is an operational release fence. Historical queries,
    // terminal reconciliation and metadata cleanup deliberately keep check_release.
    pub(super) async fn check_operational_release(
        &mut self,
        image: &Image,
        policy: &VerifiedSessionPolicy,
        now: u64,
    ) -> Result<(), DurableError> {
        let result = self
            .check_operational_release_attempt(image, policy, now)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn check_operational_release_attempt(
        &mut self,
        image: &Image,
        policy: &VerifiedSessionPolicy,
        now: u64,
    ) -> Result<(), DurableError> {
        self.active
            .as_ref()
            .ok_or(DurableError::Closed)?
            .check_account_authority(image)?;
        let Some((operation, current)) = rosters::continued_witness_admission(image, policy, now)?
        else {
            return self.check_release(image).await;
        };
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        let expected = active.protection.head(image.revision, image.digest)?;
        let anchor = active.anchor.as_mut().ok_or(DurableError::AnchorRequired)?;
        let reply = anchor.client.exchange(anchor.subject, operation).await?;
        if reply.observed_head() != expected {
            return Err(AnchorClientError::Conflict.into());
        }
        match reply.outcome() {
            AnchorOutcome::AuthorityCurrent => {}
            AnchorOutcome::AuthorityDenied => return Err(AnchorClientError::AuthorityDenied.into()),
            _ => return Err(Error::State.into()),
        }
        policy.check_device(&current, now)?;
        crate::installation::admit_policy(policy, now)?;
        self.active
            .as_ref()
            .ok_or(DurableError::Closed)?
            .check_account_authority(image)?;
        Ok(())
    }

    pub(super) async fn check_release(&mut self, image: &Image) -> Result<(), DurableError> {
        let result = self.check_release_attempt(image).await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn check_release_attempt(&mut self, image: &Image) -> Result<(), DurableError> {
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        active.check_account_authority(image)?;
        active.check_current(image).await?;
        active.check_account_authority(image)
    }

    pub(super) fn check_policy(
        &self,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
    ) -> Result<(), DurableError> {
        let policy = policy.as_ref();
        self.active
            .as_ref()
            .ok_or(DurableError::Closed)?
            .protection
            .check_policy(policy)
    }
    /// Provision an inactive required-witness journal. Export its genesis for
    /// explicit trusted enrollment, then activate before performing any work.
    /// Durably retain the fresh journal identity before this call, just as for
    /// local provisioning; an unknown creation result never authorizes replacement.
    pub async fn provision_anchored(
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        identity: JournalIdentity,
        now: u64,
    ) -> Result<Self, DurableError> {
        Self::provision_anchored_with_storage(
            crate::storage::Storage::native()?,
            path,
            key,
            device,
            policy,
            identity,
            now,
        )
        .await
    }
    pub(crate) async fn provision_anchored_with_storage(
        store: crate::storage::Storage,
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        identity: JournalIdentity,
        now: u64,
    ) -> Result<Self, DurableError> {
        policy.check_device(device, now)?;
        // A disabled/closed policy may be reconciled, but cannot create a new owner.
        let mode = [
            crate::PrekeyQuality::OneTimeBoth,
            crate::PrekeyQuality::ReusableBoth,
            crate::PrekeyQuality::SignedClassicalOneTimePq,
            crate::PrekeyQuality::OneTimeClassicalLastResortPq,
        ]
        .into_iter()
        .find(|mode| policy.allowed_modes().permits(*mode))
        .ok_or(Error::PolicyDenied)?;
        policy.check_mode(mode, now)?;
        let witness = policy
            .anchor_requirement()
            .binding()
            .ok_or(DurableError::AnchorRequired)?;
        let journal = Self::provision_with_protection(
            store,
            path,
            key,
            device,
            identity,
            Protection::Required {
                policy: policy.checkpoint().digest(),
                witness,
                fence: 1,
            },
        )
        .await?;
        // Publication adds durable I/O after initial admission. A close during
        // that work withholds the new owner but retains its original genesis.
        policy.check_device(device, now)?;
        policy.check_mode(mode, now)?;
        Ok(journal)
    }
    /// Recover only the public enrollment metadata after an unknown creation result.
    /// Requires the independently retained creation identity and exact original
    /// device/policy. This reads an authenticated, empty revision-1 required-witness
    /// image with no pending intent. It never applies a journal transition, returns an operational
    /// journal, or proves enrollment/currentness; enroll this exact genesis explicitly,
    /// then use `open_anchored` with the original witness for fresh admission.
    pub async fn recover_anchor_genesis(
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        expected_id: JournalIdentity,
    ) -> Result<crate::AnchorGenesis, DurableError> {
        Self::recover_anchor_genesis_with_storage(
            crate::storage::Storage::native()?,
            path,
            key,
            device,
            policy,
            expected_id,
        )
        .await
    }
    pub(crate) async fn recover_anchor_genesis_with_storage(
        store: crate::storage::Storage,
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        expected_id: JournalIdentity,
    ) -> Result<crate::AnchorGenesis, DurableError> {
        let db = store.open_database(path).await?;
        let image = load(&db, &key, bootstrap::storage_owner(device))?;
        let witness = policy
            .anchor_requirement()
            .binding()
            .ok_or(DurableError::AnchorRequired)?;
        if image.id != expected_id.0
            || image.local_account != device.account_id()
            || image.protection
                != (Protection::Required {
                    policy: policy.checkpoint().digest(),
                    witness,
                    fence: 1,
                })
            || image.revision != 1
            || !rosters::is_genesis(&image, device)?
        {
            return Err(DurableError::Conflict);
        }
        Ok(crate::AnchorGenesis::from_journal(
            expected_id,
            device,
            policy,
            image.digest,
        )?)
    }
    /// Activate only the exact enrolled genesis using a fresh authenticated query.
    /// Enrollment and signer provisioning remain explicit independent actions.
    pub async fn activate_anchor(
        &mut self,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        client: AnchorClient,
    ) -> Result<(), DurableError> {
        let result = self.activate_anchor_attempt(device, policy, client).await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn activate_anchor_attempt(
        &mut self,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        client: AnchorClient,
    ) -> Result<(), DurableError> {
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        let image = load(&active.db, &active.key, active.owner)?;
        if image.id != active.id
            || image.protection != active.protection
            || image.revision != 1
            || !rosters::is_genesis(&image, device)?
            || active.anchor.is_some()
        {
            return Err(DurableError::Conflict);
        }
        active.attach(device, policy, client)?;
        active.check_current(&image).await
    }

    // Enrollment release requires more than a head query: an exact signed
    // observation that the witness has independently adopted this current roster.
    // Cleanup and historical intent reconciliation retain their separate queries.
    pub(crate) async fn check_enrollment_authority(
        &mut self,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        now: u64,
    ) -> Result<(), DurableError> {
        let result = self
            .check_enrollment_authority_attempt(device, policy, now)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn check_enrollment_authority_attempt(
        &mut self,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        now: u64,
    ) -> Result<(), DurableError> {
        self.check_policy(policy)?;
        policy.check_device(device, now)?;
        let image = self.image().await?;
        rosters::authorize_device(&image, device, now)?;
        if rosters::current(&image, &device.account_id())?.checkpoint()
            != device.roster().checkpoint()
        {
            return Err(DurableError::Conflict);
        }
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        if active.protection != Protection::Local {
            let expected = active.protection.head(image.revision, image.digest)?;
            let anchor = active.anchor.as_mut().ok_or(DurableError::AnchorRequired)?;
            let reply = anchor
                .client
                .exchange(
                    anchor.subject,
                    AnchorOperation::admit_authority(device.authority_binding())?,
                )
                .await?;
            if reply.observed_head() != expected {
                return Err(AnchorClientError::Conflict.into());
            }
            match reply.outcome() {
                AnchorOutcome::AuthorityCurrent => {}
                AnchorOutcome::AuthorityDenied => {
                    return Err(AnchorClientError::AuthorityDenied.into())
                }
                _ => return Err(Error::State.into()),
            }
        }
        policy.check_device(device, now)?;
        self.active
            .as_ref()
            .ok_or(DurableError::Closed)?
            .check_account_authority(&image)?;
        Ok(())
    }

    /// Reconcile only the saved command against the independently pinned witness.
    /// A different head or writer fence never authorizes local recovery or output.
    pub async fn open_anchored(
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &VerifiedSessionPolicy,
        expected_id: JournalIdentity,
        client: AnchorClient,
    ) -> Result<Self, DurableError> {
        Self::open_anchored_retained(path, key, device, policy.historical(), expected_id, client)
            .await
    }
    pub(crate) async fn open_anchored_retained(
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &crate::HistoricalSessionPolicy,
        expected_id: JournalIdentity,
        client: AnchorClient,
    ) -> Result<Self, DurableError> {
        Self::open_anchored_admitted(
            path,
            key,
            device,
            policy,
            expected_id,
            client,
            AccountAuthorityOpen::Existing(None),
        )
        .await
    }
    pub(crate) async fn open_anchored_admitted(
        path: &Path,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &crate::HistoricalSessionPolicy,
        expected_id: JournalIdentity,
        client: AnchorClient,
        admission: AccountAuthorityOpen,
    ) -> Result<Self, DurableError> {
        let db = crate::storage::Storage::native()?
            .open_database(path)
            .await?;
        Self::open_anchored_database_admitted(
            db,
            key,
            device,
            policy,
            expected_id,
            client,
            admission,
        )
        .await
    }
    // Platform admission must already own this database. The shared recovery
    // authenticates the original image/intent before any witness reconciliation.
    // Keep the seam private: arbitrary public StorageBackend injection would
    // bypass the platform's durability and exclusive-owner requirements.
    pub(crate) async fn open_anchored_database_admitted(
        db: Database,
        key: JournalKey,
        device: &VerifiedDevice,
        policy: &crate::HistoricalSessionPolicy,
        expected_id: JournalIdentity,
        client: AnchorClient,
        admission: AccountAuthorityOpen,
    ) -> Result<Self, DurableError> {
        let owner = bootstrap::storage_owner(device);
        let (image, pending) = write_intent::load_snapshot(&db, &key, owner)?;
        if image.id != expected_id.0 || image.local_account != device.account_id() {
            return Err(DurableError::Conflict);
        }
        let account_authority = admission.admit(&image, pending.as_ref(), &key)?;
        let mut active = Active {
            db,
            key,
            owner,
            id: image.id,
            protection: image.protection,
            anchor: None,
            account_authority,
            enrollment_completion: None,
        };
        active.attach(device, policy, client)?;
        if let Some(pending) = pending {
            write_intent::reconcile(&mut active, &pending).await?;
        }
        let current = load(&active.db, &active.key, owner)?;
        active.check_current(&current).await?;
        active.check_account_authority(&current)?;
        Ok(Self {
            active: Some(active),
        })
    }
}

#[cfg(all(test, unix))]
mod tests;
