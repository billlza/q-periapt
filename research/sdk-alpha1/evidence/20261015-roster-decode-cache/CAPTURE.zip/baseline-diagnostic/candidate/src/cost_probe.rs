// Diagnostic-only counters in an isolated source copy. No input/key bytes.
//! Bounded inclusive phase timings for this private diagnostic build only.
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::Instant;
struct Counter { calls: AtomicU64, nanos: AtomicU64 }
impl Counter { const fn new()->Self { Self{calls:AtomicU64::new(0),nanos:AtomicU64::new(0)} } }
static OVERFLOW: AtomicBool=AtomicBool::new(false);
static C_IMAGEATTEMPT: Counter=Counter::new();
static C_IMAGELOAD: Counter=Counter::new();
static C_IMAGEUNSEAL: Counter=Counter::new();
static C_PERSISTATTEMPT: Counter=Counter::new();
static C_SEALNEXTIMAGE: Counter=Counter::new();
static C_SEALENCRYPT: Counter=Counter::new();
static C_VALIDATECANCELLATION: Counter=Counter::new();
static C_VALIDATEPREKEYS: Counter=Counter::new();
static C_VALIDATEMESSAGES: Counter=Counter::new();
static C_VALIDATEROSTERS: Counter=Counter::new();
static C_WRITEINTENTCOMMIT: Counter=Counter::new();
static C_WRITEINTENTRESERVE: Counter=Counter::new();
static C_WRITEINTENTAPPLY: Counter=Counter::new();
static C_ANCHORCHECKCURRENT: Counter=Counter::new();
static C_SESSIONRELEASE: Counter=Counter::new();
static C_ACCOUNTAUTHORITYCHECK: Counter=Counter::new();
static C_DUALSIGNATUREVERIFY: Counter=Counter::new();
static C_PUBLICKEYDECODE: Counter=Counter::new();
static C_P256KEYDECODE: Counter=Counter::new();
static C_P256SIGNATUREVERIFY: Counter=Counter::new();
static C_MLDSASIGNATUREVERIFY: Counter=Counter::new();
static C_VERIFYCREDENTIAL: Counter=Counter::new();
static C_VERIFYROSTER: Counter=Counter::new();
static C_VERIFYSESSIONPOLICY: Counter=Counter::new();
static C_VERIFYANCHORREQUEST: Counter=Counter::new();
static C_VERIFYANCHORREPLY: Counter=Counter::new();
static C_VERIFYOTHER: Counter=Counter::new();
static C_DATABASECOMMIT: Counter=Counter::new();
#[derive(Clone,Copy)]
pub(crate) enum Phase { ImageAttempt,ImageLoad,ImageUnseal,PersistAttempt,SealNextImage,SealEncrypt,ValidateCancellation,ValidatePrekeys,ValidateMessages,ValidateRosters,WriteIntentCommit,WriteIntentReserve,WriteIntentApply,AnchorCheckCurrent,SessionRelease,AccountAuthorityCheck,DualSignatureVerify,PublicKeyDecode,P256KeyDecode,P256SignatureVerify,MldsaSignatureVerify,VerifyCredential,VerifyRoster,VerifySessionPolicy,VerifyAnchorRequest,VerifyAnchorReply,VerifyOther,DatabaseCommit }
impl Phase {
fn counter(self)-> &'static Counter {match self {
Self::ImageAttempt=>&C_IMAGEATTEMPT,
Self::ImageLoad=>&C_IMAGELOAD,
Self::ImageUnseal=>&C_IMAGEUNSEAL,
Self::PersistAttempt=>&C_PERSISTATTEMPT,
Self::SealNextImage=>&C_SEALNEXTIMAGE,
Self::SealEncrypt=>&C_SEALENCRYPT,
Self::ValidateCancellation=>&C_VALIDATECANCELLATION,
Self::ValidatePrekeys=>&C_VALIDATEPREKEYS,
Self::ValidateMessages=>&C_VALIDATEMESSAGES,
Self::ValidateRosters=>&C_VALIDATEROSTERS,
Self::WriteIntentCommit=>&C_WRITEINTENTCOMMIT,
Self::WriteIntentReserve=>&C_WRITEINTENTRESERVE,
Self::WriteIntentApply=>&C_WRITEINTENTAPPLY,
Self::AnchorCheckCurrent=>&C_ANCHORCHECKCURRENT,
Self::SessionRelease=>&C_SESSIONRELEASE,
Self::AccountAuthorityCheck=>&C_ACCOUNTAUTHORITYCHECK,
Self::DualSignatureVerify=>&C_DUALSIGNATUREVERIFY,
Self::PublicKeyDecode=>&C_PUBLICKEYDECODE,
Self::P256KeyDecode=>&C_P256KEYDECODE,
Self::P256SignatureVerify=>&C_P256SIGNATUREVERIFY,
Self::MldsaSignatureVerify=>&C_MLDSASIGNATUREVERIFY,
Self::VerifyCredential=>&C_VERIFYCREDENTIAL,
Self::VerifyRoster=>&C_VERIFYROSTER,
Self::VerifySessionPolicy=>&C_VERIFYSESSIONPOLICY,
Self::VerifyAnchorRequest=>&C_VERIFYANCHORREQUEST,
Self::VerifyAnchorReply=>&C_VERIFYANCHORREPLY,
Self::VerifyOther=>&C_VERIFYOTHER,
Self::DatabaseCommit=>&C_DATABASECOMMIT,
}}
fn name(self)-> &'static str {match self {
Self::ImageAttempt=>"ImageAttempt",
Self::ImageLoad=>"ImageLoad",
Self::ImageUnseal=>"ImageUnseal",
Self::PersistAttempt=>"PersistAttempt",
Self::SealNextImage=>"SealNextImage",
Self::SealEncrypt=>"SealEncrypt",
Self::ValidateCancellation=>"ValidateCancellation",
Self::ValidatePrekeys=>"ValidatePrekeys",
Self::ValidateMessages=>"ValidateMessages",
Self::ValidateRosters=>"ValidateRosters",
Self::WriteIntentCommit=>"WriteIntentCommit",
Self::WriteIntentReserve=>"WriteIntentReserve",
Self::WriteIntentApply=>"WriteIntentApply",
Self::AnchorCheckCurrent=>"AnchorCheckCurrent",
Self::SessionRelease=>"SessionRelease",
Self::AccountAuthorityCheck=>"AccountAuthorityCheck",
Self::DualSignatureVerify=>"DualSignatureVerify",
Self::PublicKeyDecode=>"PublicKeyDecode",
Self::P256KeyDecode=>"P256KeyDecode",
Self::P256SignatureVerify=>"P256SignatureVerify",
Self::MldsaSignatureVerify=>"MldsaSignatureVerify",
Self::VerifyCredential=>"VerifyCredential",
Self::VerifyRoster=>"VerifyRoster",
Self::VerifySessionPolicy=>"VerifySessionPolicy",
Self::VerifyAnchorRequest=>"VerifyAnchorRequest",
Self::VerifyAnchorReply=>"VerifyAnchorReply",
Self::VerifyOther=>"VerifyOther",
Self::DatabaseCommit=>"DatabaseCommit",
}}
}
pub(crate) struct Span { counter: &'static Counter, started: Instant }
pub(crate) fn enter(phase:Phase)->Span { Span{counter:phase.counter(),started:Instant::now()} }
fn add(counter:&AtomicU64,value:u64){if counter.fetch_update(Ordering::Relaxed,Ordering::Relaxed,|old|old.checked_add(value)).is_err(){OVERFLOW.store(true,Ordering::Relaxed);}}
impl Drop for Span {fn drop(&mut self){
 let elapsed=self.started.elapsed().as_nanos();
 match u64::try_from(elapsed){Ok(value)=>{add(&self.counter.nanos,value);add(&self.counter.calls,1);},Err(_)=>OVERFLOW.store(true,Ordering::Relaxed)}
}}
/// One fixed diagnostic phase; elapsed times can contain child phases.
pub struct Sample {
 /// Fixed source phase name, never runtime input.
 pub name: &'static str,
 /// Completed spans from this process, including all SDK threads.
 pub calls:u64,
 /// Inclusive monotonic nanoseconds accumulated across spans.
 pub nanos:u64,
}
/// Read-only timing observation; it grants no SDK authority.
pub struct Snapshot {
 /// True invalidates the measurement instead of wrapping a counter.
 pub overflow:bool,
 /// Fixed bounded phase inventory.
 pub phases:Vec<Sample>,
}
/// Observe counters after the caller's own operation-completion barriers.
pub fn snapshot()->Snapshot {Snapshot{overflow:OVERFLOW.load(Ordering::Relaxed),phases:[
Phase::ImageAttempt,Phase::ImageLoad,Phase::ImageUnseal,Phase::PersistAttempt,Phase::SealNextImage,Phase::SealEncrypt,Phase::ValidateCancellation,Phase::ValidatePrekeys,Phase::ValidateMessages,Phase::ValidateRosters,Phase::WriteIntentCommit,Phase::WriteIntentReserve,Phase::WriteIntentApply,Phase::AnchorCheckCurrent,Phase::SessionRelease,Phase::AccountAuthorityCheck,Phase::DualSignatureVerify,Phase::PublicKeyDecode,Phase::P256KeyDecode,Phase::P256SignatureVerify,Phase::MldsaSignatureVerify,Phase::VerifyCredential,Phase::VerifyRoster,Phase::VerifySessionPolicy,Phase::VerifyAnchorRequest,Phase::VerifyAnchorReply,Phase::VerifyOther,Phase::DatabaseCommit].into_iter().map(|phase|{let c=phase.counter();Sample{name:phase.name(),calls:c.calls.load(Ordering::Relaxed),nanos:c.nanos.load(Ordering::Relaxed)}}).collect()}}
