from pathlib import Path
import json,os,subprocess,tomllib
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;fixture=stage/'fixture';candidate=stage/'candidate'
toolchain=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
environment=dict(os.environ);environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_TARGET_DIR=str(stage/'native-target-03'),PATH=str(toolchain/'bin')+':'+environment['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'))
sdk.require(Path(environment['CARGO_HOME']).joinpath('registry').is_dir(),'original registry absent')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product checkout dirty')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
sdk.command([str(toolchain/'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'),'--version'],stage/'objcopy-03',root,environment=environment)
cargo=str(toolchain/'bin/cargo')
sdk.command([cargo,'metadata','--format-version','1','--offline','--manifest-path',str(fixture/'Cargo.toml')],stage/'metadata-03',root,environment=environment)
def registry(path):return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
actual=registry(fixture/'Cargo.lock');allowed=registry(root/'Cargo.lock')|registry(root/'research/continuity-identity-candidate/Cargo.lock')
sdk.require(actual<=allowed,'diagnostic dependency drift')
sources={str(p.relative_to(stage)):sdk.snapshot(p).sha256 for base in [candidate,fixture] for p in base.rglob('*') if p.is_file()}
sdk.write_json(stage/'BUILD_INPUTS_03.json',{'source_commit':head,'files':sources,'canonical_registry_dependencies':sorted(actual),'environment':{k:environment[k] for k in ['CARGO_HOME','RUSTFLAGS','CARGO_TARGET_DIR','PATH','DYLD_FALLBACK_LIBRARY_PATH']}})
sdk.command([cargo,'test','--offline','--locked','--release','--no-run','--test','session_cost','--message-format=json','--manifest-path',str(fixture/'Cargo.toml')],stage/'compile-03',root,environment=environment)
records=[json.loads(row) for row in (stage/'compile-03.stdout').read_text().splitlines() if row.startswith('{')]
binaries=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='session_cost']
sdk.require(len(binaries)==1,'diagnostic binary census')
sdk.require(sources=={str(p.relative_to(stage)):sdk.snapshot(p).sha256 for base in [candidate,fixture] for p in base.rglob('*') if p.is_file()},'diagnostic source changed during build')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head,'product source changed')
sdk.write_json(stage/'BUILD_03.json',{'completed':True,'source_commit':head,'binary':binaries[0],'binary_sha256':sdk.snapshot(Path(binaries[0]),maximum=256*1024**2).sha256,'files':sources,'instrumentation_only':True})
print('Diagnostic counter build complete; original product source unchanged')
