from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent;repo=out.parent.parent
head='e942693b99bf51df85f27e61a554fa06e7aa9eb7'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
result=json.loads((out/'checkout/target/exchange-result/RESULT.json').read_text())
assert result['source_commit']==head and result['completed'] is True
assert result['client_execution']['tests']==16 and result['exchange_execution']['tests']==8
assert result['client_execution']['successful'] is True and result['exchange_execution']['successful'] is True
markers=list(Path(result['client_execution']['private_fixtures_retained']).glob('*.cut-*'));assert len(markers)==14
red=json.loads((out/'red.stdout').read_text());assert red['successful'] is False and red['errors']==1 and red['failures']==0
assert 'MissingState: no original creation intent' in (out/'red.stderr').read_text()
native=json.loads((out/'native-registration/RESULT.json').read_text())
assert native['local']=={'workers':42,'native_commands':15,'process_kills':10}
assert native['witness']=={'workers':50,'native_commands':232,'process_kills':11}
assert json.loads((out/'NATIVE_EXIT.json').read_text())['exit']==0
host=repo/'target/reference-client-hosted-01'
rows=json.loads((host/'READBACK_ubuntu-24.04-macos-15.json').read_text());assert len(rows)==2
entries={}
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in {'.stdout','.stderr','.json','.py'}:entries['local/'+p.name]=p.read_bytes()
for p in sorted((out/'pre-fix').iterdir()):
 assert p.is_file() and p.suffix=='.py';entries['local/pre-fix/'+p.name]=p.read_bytes()
for p in sorted((out/'checkout/target/exchange-result').iterdir()):
 assert p.is_file() and p.suffix in {'.json','.stdout','.stderr','.txt','.whl'};entries['local/installed/'+p.name]=p.read_bytes()
for name in ['INPUTS.json','RESULT.json']:entries['local/native-registration/'+name]=(out/'native-registration'/name).read_bytes()
source_inputs=dict(result['source_inputs'])
for name,digest in native['source_files'].items():source_inputs['research/continuity-openssl-peer/'+name]=digest
for name,digest in source_inputs.items():
 data=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
 assert hashlib.sha256(data).hexdigest()==digest
 entries['source/'+head+'/'+name]=data
entries['source/'+head+'/research/continuity-openssl-peer/REGISTRATION.md']=subprocess.check_output(['git','show',head+':research/continuity-openssl-peer/REGISTRATION.md'],cwd=repo)
for row in rows:
 assert row['head']=='32692f3d617413bb63c62080e87a207c48781d31' and row['members']==40
 folder=host/row['platform'];payload=(folder/'upstream.zip').read_bytes()
 assert len(payload)==row['artifact_bytes'] and 'sha256:'+hashlib.sha256(payload).hexdigest()==row['artifact_sha256']
 for name in ['upstream.zip','JOB.json','ARTIFACT.json']:entries['hosted/'+row['platform']+'/'+name]=(folder/name).read_bytes()
for name in ['COHORT.json','RUN_OBSERVED.json','READBACK_ubuntu-24.04-macos-15.json','readback.py','readback.stdout','readback.stderr']:entries['hosted/'+name]=(host/name).read_bytes()
hosthead=rows[0]['head'];hr=json.loads((host/'ubuntu-24.04/public/exchange/RESULT.json').read_text())
paths=set(hr['source_inputs']);paths.update(subprocess.check_output(['git','ls-tree','-r','--name-only',hosthead,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines())
for name in paths:entries['source/'+hosthead+'/'+name]=subprocess.check_output(['git','show',hosthead+':'+name],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-registration-creation-recovery';dest.mkdir()
a=dest/'CAPTURE.zip'
with zipfile.ZipFile(a,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None and len(z.infolist())==len(entries) and set(z.namelist())==set(entries)
 for n,v in manifest.items():
  b=z.read(n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
checks={'head':head,'installed':result,'installed_client_process_kills':len(markers),'native_registration':{k:native[k] for k in ['native_sha256','provider','local','witness']},'native_scope':json.loads((out/'NATIVE_INPUT.json').read_text()),'old_state':json.loads((out/'EXISTING_STATE_COMPATIBILITY.json').read_text()),'prior_hosted_client':rows,'capture':{'bytes':a.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'scope':'Recover only the original authenticated complete reserved registration creation intent. Partial/malformed/arbitrary/advanced state remains refused. Source and installed checks, frozen-native fixture interoperability and old-state reopen are distinct from actual host authorization, power-loss, erasure, PCS or full release qualification.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text("""# Original device creation recovery

Source `e942693b99bf51df85f27e61a554fa06e7aa9eb7` repairs the process interruption
between syncing a complete initial device transaction and its formal rename.
Registration alone opts into one reserved `.stage-initial-intent` slot. Recovery
verifies its original scope, MAC, zero predecessor and revision-one target before
publishing the exact original bytes. Active readers and session/configuration
creation retain their prior contract; no private seed is copied to configuration.

The regression first failed with `MissingState` on the previous random staging
layout. That source and failed state are preserved. Current source and a separately
built/installed wheel pass client16 and adapter8 checks. The installed client
executes14 real SIGKILL cuts, including repeated initial-publication recovery
without allocating new orphans. It also refuses corruption, truncation, wrong
key/identity, arbitrary authenticated orphans, repeated provision and advanced
transactions placed in the initial slot. Tests and failures are not skipped.

The same retained Accepted client from the previous installed f0b861e2 package
was opened with its original key/ID by the old package and new source. Public
identity and all state-file hashes remained identical. This was historical-state
compatibility, not a new permission or backdated acceptance.

Related registration/session integration passed42 local workers/10 process kills
and50 witness workers/11 kills against the retained native counterpart with
SHA256 `60c66db3973b9e1d8aabc22e3a87345b49e0a6d5ea080b1e855c6bbaf1e553fa`.
That binary comes from qualified build b89eb724 against SDK base23280124; its
native fixture sources still match. This is a frozen native reference endpoint,
not a new native build. It verifies original enrollment, traffic, rekey, renewal,
pending recovery and lifetime behavior with fixture authority/time controls.

The earlier [hosted client run39214488459](https://github.com/billlza/q-periapt/actions/runs/39214488459)
completed at32692f3d on Linuxx86_64 and AppleSilicon. Both terminal40-member
artifacts were checked against GitHub digests,67 source inputs and the installed
50-module wheel. Both passed client10/adapter8, Node17 and Rust26 debug/release
entries. Those hosted checks precede this recovery fix and do not qualify it.
No live CI logs or downloaded executable were read/run during artifact readback.

The capture includes source, public check outputs, old/new regression results,
local inspected wheel and earlier hosted archives. Private fixtures, wrapping
keys and encrypted device/session images remain outside it. Hashes identify the
retained original files without exposing their contents.

A crash before any complete original device record exists remains an explicit
failure. Truncated records and older random staging files are not regenerated or
silently migrated. Authorized abandonment/restart, operational policy publication,
real host-to-installed-client authorization, full session CLI, power-loss/erasure/
PCS analysis and remaining0.2.0 release requirements stay open.
""")
print(json.dumps(checks['capture']))
