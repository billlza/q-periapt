from pathlib import Path
import json
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
clone=root/'target/continuity-browser-publication/source'
old=json.loads((stage/'SOURCE_OVERLAY.json').read_text())
for name,digest in old['overlay'].items(): sdk.require(sdk.snapshot(clone/name).sha256==digest,'prior clone overlay drift')
test='research/continuity-identity-candidate/src/enrollment/witness_recovery_renewal_tests.rs'
for name,digest in old['overlay'].items():
    if name!=test: sdk.require(sdk.snapshot(root/name).sha256==digest,'unrelated input drift')
for name,digest in json.loads((stage/'INPUTS_05.json').read_text()).items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'tested input drift')
sdk.require(json.loads((stage/'boundary-05.json').read_text())['returncode']==0,'terminal boundary failure')
lines=[line for line in (stage/'boundary-05.stderr').read_text().splitlines() if line.startswith('EXPIRED_CLEANUP_')]
sdk.require(len(lines)==6 and len(set(lines))==6,'six exact outcomes required')
sdk.require('2 passed; 0 failed;' in (stage/'boundary-05.stdout').read_text(),'both tests required')
(clone/test).write_bytes((root/test).read_bytes())
sdk.command(['git','add','--',test],stage/'main-stage-test-final',root)
sdk.command(['git','add','--',test],stage/'clone-stage-test-final',clone)
inputs={name:sdk.snapshot(root/name).sha256 for name in old['overlay']}
sdk.write_json(stage/'SOURCE_OVERLAY_02.json',dict(old,overlay=inputs))
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
cargo=Path(env['RUSTC']).parent/'cargo'
sdk.command([str(cargo),'clippy','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','-D','warnings'],stage/'clippy-02',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'verification source drift')
sdk.write_json(stage/'VERIFIED.json',{'inputs':inputs,'boundary_tests':2,'cohorts':6,'outcomes':lines,
 'clippy':'passed','workflow_lint':'two unchanged baseline runner-label errors; no new diagnostics',
 'artifact_controls':'60 passed in owned real clone with staged 659-file source overlay; only test assertion syntax changed afterward',
 'prior_controls_failure':'Main is a linked worktree, correctly refused by real-.git release provenance guard. Guard unchanged.',
 'prior_clippy_failure':'New test used panic macro forbidden by project lint; replaced with explicit Result and expect, preserving assertion. No lint suppression.',
 'ci_failure':'direct GitHub annotation confirms 105-minute job timeout',
 'product_fix':False,'browser_retirement_qualified':False,'goal_complete':False})
print('Six fresh boundary cohorts and strict Clippy passed; 60 inventory/package controls passed; no new workflow diagnostics')
