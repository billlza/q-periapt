from pathlib import Path
import json
import os
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
clone=root/'target/continuity-browser-publication/source'
inputs=json.loads((stage/'VERIFICATION_INPUTS.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
head=sdk.command(['git','rev-parse','HEAD'],stage/'clone-base',clone).decode().strip()
sdk.require(head=='9e26591673017743dab0ee70602ce7cd1e94f569','clone moved')
sdk.require(not sdk.command(['git','status','--porcelain'],stage/'clone-before',clone),'clone dirty')
for name in inputs:
    path=clone/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes((root/name).read_bytes())
sdk.command(['git','add','--',*inputs],stage/'clone-stage',clone)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(clone/name).sha256==digest,'clone source differs')
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':head,'source':str(clone),'overlay':inputs})
control_env=dict(os.environ)
control_env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PYTHONPATH='artifact')
sdk.command(['sh','artifact/python-run.sh','-m','unittest','artifact.test_codeql_rust_quality','artifact.test_continuity_package'],stage/'controls-02',clone,environment=control_env)
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
cargo=Path(env['RUSTC']).parent/'cargo'
sdk.command([str(cargo),'clippy','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','-D','warnings'],stage/'clippy',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==sdk.snapshot(clone/name).sha256==digest,'verification source drift')
lines=[line for line in (stage/'boundary-04.stderr').read_text().splitlines() if line.startswith('EXPIRED_CLEANUP_')]
sdk.require(len(lines)==6 and len(set(lines))==6,'six distinct outcomes')
sdk.write_json(stage/'VERIFIED.json',{'inputs':inputs,'boundary_tests':2,'cohorts':6,'outcomes':lines,
 'clippy':'passed','workflow_lint':'two unchanged baseline runner-label errors; no new diagnostics',
 'artifact_controls':'60 passed in owned real clone with staged 659-file source overlay',
 'prior_controls_failure':'Main is a linked worktree, correctly refused by real-.git release provenance guard. Guard unchanged; exact overlay tested in real clone.',
 'ci_failure':'direct GitHub annotation confirms 105-minute job timeout',
 'product_fix':False,'browser_retirement_qualified':False,'goal_complete':False})
print('Six boundary cohorts, strict Clippy and 60 controls passed; workflow retains two baseline label diagnostics')
