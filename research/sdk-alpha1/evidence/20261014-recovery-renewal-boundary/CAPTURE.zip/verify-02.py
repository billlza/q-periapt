from pathlib import Path
import json
import os
import rust_sdk_profile as sdk
from bounded_process import capture_output

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
inputs=json.loads((stage/'VERIFICATION_INPUTS.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
baseline=stage/'baseline-ci.yml'
baseline.write_bytes(sdk.command(['git','show','HEAD:.github/workflows/ci.yml'],stage/'baseline-workflow-source',root))
diagnostics=[]
for label,path in [('baseline',baseline),('current',root/'.github/workflows/ci.yml')]:
    args=['/opt/homebrew/bin/actionlint','-format','{{json .}}',str(path)]
    result=capture_output(args,timeout_seconds=60,maximum_stdout_bytes=65536,maximum_stderr_bytes=65536)
    (stage/f'workflow-{label}.stdout').write_bytes(result.stdout)
    (stage/f'workflow-{label}.stderr').write_bytes(result.stderr)
    sdk.write_json(stage/f'workflow-{label}.json',{'argv':args,'returncode':result.returncode})
    sdk.require(result.returncode==1 and not result.stderr,'unexpected workflow lint result')
    data=json.loads(result.stdout)
    for item in data: item.pop('filepath',None)
    diagnostics.append(data)
sdk.require(diagnostics[0]==diagnostics[1] and len(diagnostics[0])==2,'new workflow diagnostic')
sdk.require(all(item['kind']=='runner-label' and 'ubuntu-26.04' in item['message'] for item in diagnostics[0]),'unexplained baseline diagnostics')
sdk.write_json(stage/'WORKFLOW_DIFFERENTIAL.json',{'lint_passed':False,'new_diagnostics':0,'unchanged_diagnostics':diagnostics[0],
 'limitation':'Installed actionlint1.7.12 does not recognize existing ubuntu-26.04 runner labels. Actual GitHub job ran on that runner. No flags/config suppress those errors.'})
control_env=dict(os.environ)
control_env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PYTHONPATH='artifact')
sdk.command(['sh','artifact/python-run.sh','-m','unittest','artifact.test_codeql_rust_quality','artifact.test_continuity_package'],stage/'controls',root,environment=control_env)
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
cargo=Path(env['RUSTC']).parent/'cargo'
sdk.command([str(cargo),'clippy','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','-D','warnings'],stage/'clippy',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'verification source drift')
lines=[line for line in (stage/'boundary-04.stderr').read_text().splitlines() if line.startswith('EXPIRED_CLEANUP_')]
sdk.require(len(lines)==6 and len(set(lines))==6,'six distinct outcomes')
sdk.write_json(stage/'VERIFIED.json',{'inputs':inputs,'boundary_tests':2,'cohorts':6,'outcomes':lines,
 'clippy':'passed','workflow_lint':'two unchanged baseline runner-label errors; no new diagnostics',
 'artifact_controls':'passed','ci_failure':'direct GitHub annotation confirms 105-minute job timeout',
 'product_fix':False,'browser_retirement_qualified':False,'goal_complete':False})
print('Six boundary cohorts, strict Clippy, inventory/package controls passed; workflow retains two baseline label diagnostics')
