from pathlib import Path
import json
import re
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
destination=root/'research/sdk-alpha1/evidence/20261014-recovery-renewal-boundary'
verified=json.loads((stage/'VERIFIED.json').read_text())
sdk.require(verified['clippy']=='passed' and verified['cohorts']==6,'qualification incomplete')
for name,digest in verified['inputs'].items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
controls=(stage/'controls-02.stderr').read_text()
sdk.require(re.search(r'Ran 60 tests in [0-9.]+s\s+OK',controls),'60 passing controls required')
sdk.require(json.loads((stage/'clippy-02.json').read_text())['returncode']==0,'Clippy not terminal success')
files={p.name:p for p in stage.iterdir() if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.rs','.py','.yml')}
files['README.md']=destination/'README.md'
for name in verified['inputs']: files['source/'+name]=root/name
archive=destination/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()): z.writestr(name,sdk.snapshot(path,maximum=16*1024**2).data)
snap=sdk.snapshot(archive,maximum=32*1024**2)
with zipfile.ZipFile(archive) as z: sdk.require(z.testzip() is None and set(z.namelist())==set(files),'capture verification failed')
sdk.write_json(destination/'CHECKS.json',dict(verified,
    completed=True,release_claim_eligible=False,base_commit='9e26591673017743dab0ee70602ce7cd1e94f569',
    archive={'sha256':snap.sha256,'bytes':len(snap.data),'members':len(files)},
    changes='Two native regression tests, explicit admission boundary, exact source inventory and installed CI total budget. Product runtime unchanged.',
    private_state_included=False))
print(json.dumps({'archive':snap.sha256,'bytes':len(snap.data),'members':len(files),'cohorts':6,'product_fix':False}))
