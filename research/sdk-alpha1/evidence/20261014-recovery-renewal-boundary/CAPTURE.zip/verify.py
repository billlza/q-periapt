from pathlib import Path
import json
import os
import re
import subprocess
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
expected=['.github/workflows/ci.yml','ARTIFACT.md','artifact/codeql_rust_quality.py','artifact/test_codeql_rust_quality.py',
 'docs/continuity/PRODUCT_ADMISSION.md','research/continuity-identity-candidate/CREDENTIAL_RENEWAL.md',
 'research/continuity-identity-candidate/src/enrollment/witness_renewal_tests.rs',
 'research/continuity-identity-candidate/src/enrollment/witness_recovery_renewal_tests.rs']
sdk.require(not subprocess.run(['git','diff','--cached','--name-only'],check=True,capture_output=True,text=True).stdout,'unexpected pre-existing index')
actual=set(subprocess.run(['git','diff','--name-only'],check=True,capture_output=True,text=True).stdout.splitlines()) | set(subprocess.run(['git','ls-files','--others','--exclude-standard'],check=True,capture_output=True,text=True).stdout.splitlines())
sdk.require(actual==set(expected),'unexpected source scope')
sdk.command(['git','add','--',*expected],stage/'source-stage',root)
inputs={name:sdk.snapshot(root/name).sha256 for name in expected}
sdk.write_json(stage/'VERIFICATION_INPUTS.json',inputs)
original=json.loads((stage/'INPUTS_04.json').read_text())
for name,digest in original.items(): sdk.require(inputs[name]==digest,'terminal boundary source changed')
out=(stage/'boundary-04.stdout').read_text(); err=(stage/'boundary-04.stderr').read_text()
sdk.require(re.search(r'^test result: ok\. 2 passed; 0 failed;',out,re.MULTILINE),'two tests actually passed')
lines=[line for line in err.splitlines() if line.startswith('EXPIRED_CLEANUP_')]
sdk.require(len(lines)==6 and len(set(lines))==6,'six distinct terminal cohort outcomes required')
annotations=sdk.command(['gh','api','repos/billlza/q-periapt/check-runs/115767948387/annotations'],stage/'ci-annotations',root)
parsed=json.loads(annotations)
sdk.require(any(item['message']=='The job has exceeded the maximum execution time of 1h45m0s' for item in parsed),'direct timeout annotation required')
sdk.command(['/opt/homebrew/bin/actionlint','-color','.github/workflows/ci.yml'],stage/'workflow',root)
control_env=dict(os.environ)
control_env.update(QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14',PYTHONPATH='artifact')
sdk.command(['sh','artifact/python-run.sh','-m','unittest','artifact.test_codeql_rust_quality','artifact.test_continuity_package'],stage/'controls',root,environment=control_env)
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR',None); env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings'
cargo=Path(env['RUSTC']).parent/'cargo'
base=[str(cargo),'clippy','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','-D','warnings']
sdk.command(base,stage/'clippy',root,environment=env)
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'verification source drift')
sdk.write_json(stage/'VERIFIED.json',{'inputs':inputs,'boundary_tests':2,'cohorts':6,'outcomes':lines,
 'clippy':'passed','workflow_lint':'passed','artifact_controls':'passed','ci_failure':'confirmed 105-minute job timeout',
 'product_fix':False,'browser_retirement_qualified':False,'goal_complete':False})
print('Six boundary cohorts, strict Clippy, workflow lint and inventory/package controls verified')
