from pathlib import Path
import json
import re
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
archive=stage/'installed-rust-ci-978.zip'
snap=sdk.snapshot(archive,maximum=80*1024**2)
sdk.require(snap.sha256=='d017cfee812a5350389d4e5fb96e18e0f5780c0eddddd6ba07d64bef834cf1c7','artifact drift')
with zipfile.ZipFile(archive) as z:
    names=set(z.namelist()); commands=[]
    for info in z.infolist():
        if '/' in info.filename or not info.filename.endswith('.json') or info.file_size>4096: continue
        data=json.loads(z.read(info))
        if not isinstance(data,dict) or set(data)!= {'argv','cwd','returncode'}: continue
        prefix=info.filename[:-5]
        output=z.read(prefix+'.stdout').decode() if prefix+'.stdout' in names else ''
        durations=[float(x) for x in re.findall(r'finished in ([0-9.]+)s',output)]
        commands.append({'name':prefix,'returncode':data['returncode'],'completed_zip_timestamp':info.date_time,'rust_test_seconds':sum(durations)})
    byname={c['name']:c for c in commands}
    selected=[byname[name] for name in ('consumer-debug','consumer-release','c-compile-debug','c-trace-debug','c-witnessed-policy-cancellation-debug','c-witness-openssl-rejections-debug','c-compile-release','c-trace-release','c-witnessed-policy-continuation-release') if name in byname]
    result={'head':'978e405f64b92999677e34be6ea3a36bd3471956','run':38537722025,'job':115767948387,
        'artifact_id':11886532804,'artifact_sha256':snap.sha256,'retained_commands':len(commands),
        'nonzero_command_receipts':[c for c in commands if c['returncode']!=0],
        'selected_terminal_receipts':selected,
        'longest_rust_test_commands':sorted(commands,key=lambda c:c['rust_test_seconds'],reverse=True)[:12],
        'final_aggregate_present':{name:name in names for name in ('CONTINUITY_PACKAGE.json','C_CONTINUITY_CONSUMER.json')},
        'job_started_utc':'2026-10-14T08:56:42Z','step_canceled_utc':'2026-10-14T10:42:04Z',
        'configured_job_timeout_minutes':105,'completed':False,
        'interpretation':'Job cancellation matches its 105-minute wall-clock budget. Last retained command succeeded 52 seconds before cancellation; exact cancelled Rust child has no terminal receipt. No aggregate success is claimed.'}
sdk.write_json(stage/'CI_978_INSTALLED_RUST.json',result)
print(json.dumps(result,indent=2))
