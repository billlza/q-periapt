from pathlib import Path
import json
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
path=stage/'installed-rust-ci-978.zip'
snap=sdk.snapshot(path,maximum=80*1024**2)
sdk.require(snap.sha256=='d017cfee812a5350389d4e5fb96e18e0f5780c0eddddd6ba07d64bef834cf1c7','uploaded artifact identity mismatch')
with zipfile.ZipFile(path) as archive:
    files=[info for info in archive.infolist() if not info.is_dir()]
    direct=[info for info in files if '/' not in info.filename]
    print(json.dumps({'members':len(files),'aggregate_present':{name:name in archive.namelist() for name in ('CONTINUITY_PACKAGE.json','C_CONTINUITY_CONSUMER.json')},
        'recent_root_files':[(info.filename,info.date_time,info.file_size) for info in sorted(direct,key=lambda i:i.date_time)[-8:]]}))
    for name in ['consumer-debug.json','consumer-release.json','c-witnessed-commit-error-release.json','c-witnessed-policy-continuation-release.json']:
        print(name,archive.read(name).decode())
