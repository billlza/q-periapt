// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Generic cleanup intent versus independently authorized renewal after expiry.
use super::*;
use crate::enrollment::tests::policy_continuation::{joint, policy, scope};
use crate::{BootstrapContext, CredentialRenewalId, InitiationId};

fn session(f: Fixture) -> (Fixture, [u8; 32]) {
    use super::policy_transaction::sessions::{bundle, endpoint, requirements};
    let peer = fixture_on_witness(
        Arc::clone(&f._witness_dir),
        f.pin.clone(),
        f.carrier.clone(),
        Some(f.c.policy.validity().until()),
    );
    let mut a = endpoint(f);
    let mut b = endpoint(peer);
    let bundle = bundle(&a, &mut b);
    let context = |f: &Fixture| -> Arc<BootstrapContext> {
        Arc::new(
            bundle
                .verify(
                    Arc::new(policy(&f.c, 1, f.c.policy.validity().until(), 150)),
                    requirements(&a, &b),
                    150,
                )
                .expect("original context"),
        )
    };
    let ci = context(&a.f);
    let cr = context(&b.f);
    let initiation = InitiationId::generate().expect("original initiation");
    let (service, signer, _) = a.owner.parts().expect("sender");
    let (peer, peer_signer, _) = b.owner.parts().expect("recipient");
    let (sender, archives) = service.stores().expect("sender stores");
    let receiver = peer.stores().expect("recipient stores").0;
    let initial = sender
        .initiate(Arc::clone(&ci), initiation, signer, 150)
        .expect("initial");
    let reply = receiver
        .respond_from_inventory(Arc::clone(&cr), &initial, peer_signer, 150)
        .expect("reply");
    let done = sender
        .accept_reply(Arc::clone(&ci), initiation, &reply, 150)
        .expect("final");
    let session = done.session_id();
    receiver
        .finish(cr, &initial, done.final_message(), 150)
        .expect("confirmed");
    sender
        .activate_initiator_messages(Arc::clone(&ci), initiation, 150)
        .expect("original message state");
    let archive = sender
        .archive_session_closure(&ci, session)
        .expect("original archive");
    archives
        .retain(sender, &ci, session, &archive)
        .expect("retained original archive");
    let message = sender.next_message_id(&ci, session, 150).expect("ID");
    sender
        .send_message(&ci, session, message, b"unconfirmed original", b"", 150)
        .expect("real pending delivery");
    a.owner.close();
    b.owner.close();
    (a.f, session)
}

fn request(
    f: &Fixture,
    id: CredentialRenewalId,
) -> Result<crate::CredentialRenewalRequest, DurableError> {
    let mut owner = open(&f.c);
    let anchor = owner.credential_renewal_request_anchor_client(
        f.c.policy.historical(),
        f.pin.clone(),
        Box::new(f.carrier.clone()),
        Duration::from_secs(3),
    )?;
    owner.witnessed_credential_renewal_request(id, f.c.policy.historical(), anchor)
}

#[test]
fn expired_cleanup_intent_distinguishes_applied_reply_loss_from_blocked_renewal() {
    for policy_expired in [false, true] {
        for applied in [false, true] {
            let (f, session) = session(fixture_with_policy_expiry(Some(if policy_expired {
                160
            } else {
                200
            })));
            let mut cleanup = open(&f.c)
                .recover_session(
                    session,
                    f.c.policy.historical(),
                    Some((
                        f.pin.clone(),
                        Box::new(f.carrier.clone()),
                        Duration::from_secs(3),
                    )),
                )
                .expect("original restricted owner");
            // Actual ordinary Advance (opcode 2), cut before or after the store.
            *f.carrier.cut.lock().expect("cut") = Some((2, applied));
            assert!(matches!(
                cleanup.session().expect("session").begin(),
                Err(DurableError::Anchor(_))
            ));
            assert!(f.carrier.cut.lock().expect("cut consumed").is_none());
            cleanup.close();
            let before = disk(&f);
            assert_eq!(
                before.1.as_deref().and_then(|p| p.get(..8)),
                Some(b"QPWINT01".as_slice())
            );
            f.carrier.clock.store(170, Ordering::SeqCst);
            let operation = CredentialRenewalId::generate().expect("original renewal ID");
            if applied {
                let snapshot = request(&f, operation)
                    .expect("exact applied cleanup can reconcile after expiry");
                assert_eq!(snapshot.journal(), f.id);
                assert_eq!(
                    snapshot.previous_device().credential_digest(),
                    f.original.credential_digest()
                );
                let after = disk(&f);
                assert!(after.1.is_none());
                assert_ne!(after.0, before.0);
                assert_eq!(
                    request(&f, operation).expect("same request").operation(),
                    operation
                );
                assert_eq!(disk(&f), after);
            } else {
                for _ in 0..2 {
                    assert!(matches!(
                        request(&f, operation),
                        Err(DurableError::Anchor(_))
                    ));
                    assert_eq!(
                        disk(&f),
                        before,
                        "failed renewal must retain the exact generic intent"
                    );
                }
                // Even an already available independent G/T grant cannot replace
                // an unrelated pending cleanup intent with its own sealed target.
                let grant = grant(&f, &f.original, 2, 190);
                let target = policy(&f.c, 2, 200, 170);
                let continuation = joint(
                    &f.c,
                    &grant,
                    &scope(&f.c, &grant, f.id),
                    &f.c.policy,
                    &target,
                );
                let mut owner = open(&f.c);
                owner
                    .stage_policy_continuation(
                        &grant,
                        &continuation,
                        grant.operation(),
                        &target,
                        170,
                    )
                    .expect("independent approval may be staged");
                let anchor = client(&f, &mut owner, 170);
                f.carrier.requests.lock().expect("requests").clear();
                assert!(matches!(
                    owner.prepare_witnessed_policy_continuation(
                        f.c.policy.historical(),
                        &target,
                        170,
                        anchor
                    ),
                    Err(DurableError::Conflict)
                ));
                assert!(matches!(owner.status(), Err(DurableError::Closed)));
                assert!(f.carrier.requests.lock().expect("no dispatch").is_empty());
                assert_eq!(disk(&f), before);
            }
            eprintln!("EXPIRED_CLEANUP_RENEWAL policy_expired={policy_expired} applied={applied} request_available={applied} original_intent_preserved={}", !applied);
        }
    }
}
