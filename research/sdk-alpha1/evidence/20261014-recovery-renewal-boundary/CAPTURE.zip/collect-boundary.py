from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root=Path.cwd(); stage=root/'target/continuity-recovery-renewal-boundary'
inputs=json.loads((stage/'INPUTS_02.json').read_text())
for name,digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256==digest,'source drift')
out=(stage/'boundary-02.stdout').read_text(); err=(stage/'boundary-02.stderr').read_text()
sdk.require(re.search(r'^test result: ok\. 1 passed; 0 failed;',out,re.MULTILINE),'terminal Rust result required')
lines=[line for line in err.splitlines() if line.startswith('EXPIRED_CLEANUP_RENEWAL ')]
expected={f'EXPIRED_CLEANUP_RENEWAL policy_expired={policy} applied={applied} request_available={applied} original_intent_preserved={str(applied=="false").lower()}' for policy in ('false','true') for applied in ('false','true')}
sdk.require(len(lines)==4 and set(lines)==expected,'four exact stderr outcomes required')
sdk.write_json(stage/'BOUNDARY_02.json',{'passed':True,'cohorts':4,'inputs':inputs,'outcomes':lines,
 'product_fix':False,'native_same_host_test_clock':True,'original_session_handle':82756,
 'collector_correction':'check-02.py checked stdout only; Rust terminal passed and eprintln outcomes are retained in stderr. No test rerun or accepted cohort reopen.',
 'fixture_failure':'boundary-01 failed because false-policy-expired target did not strictly extend validity; target now extends 200 to220. Original failure/source-01 retained.'})
print('Validated original terminal Rust result and all four stderr outcomes; no rerun')
