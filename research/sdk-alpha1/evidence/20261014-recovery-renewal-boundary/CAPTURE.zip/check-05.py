from pathlib import Path
import json
import re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-recovery-renewal-boundary'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['RUSTFLAGS'] = env.get('RUSTFLAGS', '') + ' -D warnings'
toolchain = Path(env['RUSTC']).parent
files = ['research/continuity-identity-candidate/src/enrollment/' + name for name in
    ('witness_renewal_tests.rs', 'witness_recovery_renewal_tests.rs')]
sdk.command([str(toolchain / 'rustfmt'), '--edition', '2021', '--config', 'skip_children=true',
    *files], stage / 'format-05', root, environment=env)
inputs = {name: sdk.snapshot(root/name).sha256 for name in files}
sdk.write_json(stage/'INPUTS_05.json', inputs)
sdk.copy(root/files[1], stage/'source-05.rs')
output = sdk.command([str(toolchain/'cargo'), 'test', '--locked', '--offline', '--manifest-path',
    'research/continuity-identity-candidate/Cargo.toml', '--all-features', '--lib',
    'expired_cleanup_intent', '--target-dir', str(root/'target/continuity-browser-fanout/native-target'),
    '-j', '2', '--', '--nocapture'], stage/'boundary-05', root, environment=env).decode()
sdk.require(re.search(r'^test result: ok\. 2 passed; 0 failed;', output, re.MULTILINE), 'one actual boundary test required')
sdk.require((stage/'boundary-05.stderr').read_text().count('EXPIRED_CLEANUP_RENEWAL ') == 4, 'all four fresh cohorts required')
for name, digest in inputs.items(): sdk.require(sdk.snapshot(root/name).sha256 == digest, 'source drift')
sdk.write_json(stage/'BOUNDARY_05.json', {'passed': True, 'cohorts': 4, 'inputs': inputs,
    'product_fix': False, 'same_host_native_test_clock': True})
print('Four fresh actual-journal/witness boundary cases passed', flush=True)
