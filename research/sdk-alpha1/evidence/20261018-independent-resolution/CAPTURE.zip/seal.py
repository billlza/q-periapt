"""Seal final public lanes and exact source/reader evidence, excluding private state."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
out = root / 'target/independent-resolution-01'
peer = root / 'research/continuity-openssl-peer'
folder = root / 'research/sdk-alpha1/evidence/20261018-independent-resolution'
folder.mkdir(exist_ok=False)
def sha(data):
    return hashlib.sha256(data).hexdigest()

resolution = json.loads((out / 'RESOLUTION_READBACK.json').read_text())
control = json.loads((out / 'CONTROL_READBACK.json').read_text())
regressions = json.loads((out / 'REGRESSION_READBACK.json').read_text())
assert resolution['source_files'] == control['source_files'] == regressions['source_files']
entries = {}
lanes = ['resolution', 'maximum', 'disclosure', 'capacity', 'control', 'owner', 'storage', 'base', 'rekey', 'exchange']
for lane in lanes:
    name = 'final-' + lane
    assert not (out / (name + '.stderr')).read_bytes()
    for p in sorted((out / name).rglob('*')):
        if not p.is_file():
            continue
        assert not p.is_symlink() and p.name not in {'head', 'intent', '.stage-head', 'configuration', 'signer', 'wrong-signer', 'key'}
        data = p.read_bytes()
        assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02', b'QPREFS03', b'QPREFS04'))
        entries[str(p.relative_to(out))] = data
    for suffix in ['stdout', 'stderr']:
        entries[name + '.' + suffix] = (out / (name + '.' + suffix)).read_bytes()
for name in ['RESOLUTION_READBACK.json', 'CONTROL_READBACK.json', 'REGRESSION_READBACK.json', 'seal.py',
             'quality-inputs.json', 'quality.stdout', 'quality.stderr']:
    entries[name] = (out / name).read_bytes()
for stem in ['review-resolution', 'review-final-control', 'review-final-regressions', 'build', 'clippy', 'fmt', 'actionlint']:
    for suffix in (['py', 'stdout', 'stderr'] if stem.startswith('review-') else ['stdout', 'stderr']):
        entries[stem + '.' + suffix] = (out / (stem + '.' + suffix)).read_bytes()
for name, expected in resolution['source_files'].items():
    data = (peer / name).read_bytes()
    assert sha(data) == expected
    entries['source/' + name] = data
for name in ['README.md', 'STORAGE.md']:
    entries['source/' + name] = (peer / name).read_bytes()
for name in ['.github/workflows/independent-continuity.yml', 'ARTIFACT.md',
             'artifact/codeql_rust_quality.py', 'artifact/test_codeql_rust_quality.py']:
    entries['repository/' + name] = (root / name).read_bytes()
entries['counterpart'] = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
assert sha(entries['counterpart']) == resolution['native_sha256']
quality = json.loads(entries['quality-inputs.json'])
assert quality['Rust_files'] == 723 and len(quality['files']) == 1123
for name, expected in quality['files'].items():
    assert sha((root / name).read_bytes()) == expected
assert b'Ran 46 tests' in entries['quality.stderr'] and entries['quality.stderr'].rstrip().endswith(b'OK')
changed = subprocess.check_output(['git', 'diff', '23280124', '--name-only'], text=True).splitlines()
allowed = {'ARTIFACT.md', 'artifact/codeql_rust_quality.py', 'artifact/test_codeql_rust_quality.py',
           '.github/workflows/independent-continuity.yml', 'docs/SDK_0_2_RELEASE_READINESS.md'}
assert all(n.startswith(('research/continuity-openssl-peer/', 'research/sdk-alpha1/evidence/')) or n in allowed for n in changed)
entries['SOURCE_CONTINUITY.json'] = (json.dumps({'from_head': '23280124efd2f0f3003d4ce85e3db665f6ec8a25',
    'working_base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'changed_tracked_paths': changed, 'product_candidate_bindings_toolchain_unchanged': True,
    'Rust_inventory': 723, 'new_Rust_source': 'research/continuity-openssl-peer/native/src/resolution.rs'}, indent=2) + '\n').encode()
manifest = {n: {'bytes': len(d), 'sha256': sha(d)} for n, d in sorted(entries.items())}
entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = folder / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, d in sorted(entries.items()):
        item = zipfile.ZipInfo(n, (2026, 10, 18, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        z.writestr(item, d)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(entries) and z.testzip() is None
    for n, item in manifest.items():
        data = z.read(n)
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
report = {'resolution': resolution, 'control': control, 'regressions': regressions,
          'validation': {'strict_release_build': True, 'strict_all_target_clippy': True, 'rustfmt': True,
                         'actionlint': True, 'Python_AST': True, 'source_contract_tests': 46,
                         'quality_snapshot_files': 1123, 'tracked_Rust_files': 723, 'new_CodeQL_database_scan': False},
          'capture': {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())},
          'scope': 'Final ten local ARM64 lanes on the exact 48-source closure. Hosted verification pending. No full release/PCS/physical-erasure/hardware-power-loss/global-application-atomicity claim.',
          'private_state': 'Original and interrupted private fixtures remain outside the capture; only public path references are included. Intermediate successful runs and pre-input-guard source remain local.'}
(folder / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['capture']))
