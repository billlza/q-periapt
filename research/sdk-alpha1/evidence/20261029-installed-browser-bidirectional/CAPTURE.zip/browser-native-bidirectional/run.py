from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();base=Path(__file__).resolve().parent
name=sys.argv[1];assert name in ('run01','run02','run03','run04')
command=['sh','artifact/python-run.sh','artifact/continuity_browser_session.py',
 '--receipt','target/installed-browser-716/product-03/INSTALLED_CONSUMER.json',
 '--node','/opt/homebrew/bin/node','--cli','target/wasm-browser-tools-716/node_modules/@playwright/cli/playwright-cli.js',
 '--provider-root',str(root/'target/independent-bootstrap-01/provider'),
 '--native-target',str(root/'target/continuity-reference-app'),'--output',str(base/name)]
start=time.monotonic()
with (base/(name+'.stdout')).open('xb') as out,(base/(name+'.stderr')).open('xb') as err:
 process=subprocess.run(command,cwd=root,stdout=out,stderr=err,
  env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14'))
record={'argv':command,'exit_code':process.returncode,'seconds':time.monotonic()-start,
 'stdout_sha256':hashlib.sha256((base/(name+'.stdout')).read_bytes()).hexdigest(),
 'stderr_sha256':hashlib.sha256((base/(name+'.stderr')).read_bytes()).hexdigest()}
(base/(name+'-TERMINAL.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(process.returncode)
