from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;mode=sys.argv[1];sdk.require(mode in ('baseline','expanded'),'invalid mode')
base=(stage/'derive-13.spthy').read_text()
if mode=='expanded':
 sdk.require(base.count('[no_precomp]')==2,'premise annotation inventory changed')
 data=base.replace('[no_precomp]','')
else:data=base
source=stage/(mode+'-precompute-17.spthy')
with source.open('x') as f:f.write(data)
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--precompute-only','--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False
with (stage/(mode+'-precompute-17.stdout')).open('xb') as out,(stage/(mode+'-precompute-17.stderr')).open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/(mode+'-PRECOMPUTE_STARTED_17.json'),{'pid':p.pid,'argv':argv,'maximum_seconds':180,'input_sha256':hashlib.sha256(data.encode()).hexdigest(),'only_change':'none' if mode=='baseline' else 'remove two no_precomp search annotations, retaining both premises'})
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
sdk.write_json(stage/(mode+'-PRECOMPUTE_TERMINAL_17.json'),{'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'proof_accepted':False,'precomputation_only':True})
print(json.dumps({'mode':mode,'returncode':code,'timed_out':timed_out}),flush=True)
print((stage/(mode+'-precompute-17.stdout')).read_text()[-2400:])
