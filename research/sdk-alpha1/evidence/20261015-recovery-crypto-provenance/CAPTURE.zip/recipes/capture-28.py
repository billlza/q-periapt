"""Freeze the proved crypto obligations, rejected controls and failed searches."""
from pathlib import Path
import hashlib, json, re, subprocess, zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
base_commit = 'b5e38b7e345997804dd826003cd7520020967a7a'
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base_commit, 'source changed')
replays = json.loads((stage / 'REPLAYS_23.json').read_text())
semantics = json.loads((stage / 'SEMANTICS_27.json').read_text())
controls = json.loads((stage / 'CONTROLS_VERIFIED_08.json').read_text())
sdk.require(replays['completed'] and replays['missing_dependency_rejected_despite_exit_zero'], 'replay group incomplete')
sdk.require(semantics['completed'] and controls['completed'], 'semantic/control checks incomplete')
proof = stage / 'composed-16-proof.spthy'
sdk.require(replays['results']['independent-23']['input_sha256'] == sdk.snapshot(proof).sha256, 'replayed certificate changed')
failed_names = ['encapsulation-05-TERMINAL.json', 'key-frames-19-TERMINAL.json',
                'message-22-TERMINAL.json', 'root-observer-25-TERMINAL.json']
failed = {name: json.loads((stage / name).read_text()) for name in failed_names}
sdk.require(all(row['timed_out'] and not row['accepted'] for row in failed.values()), 'failed proof admitted')
starts = sorted(stage.glob('*STARTED*.json'))
processes = subprocess.check_output(['ps', '-axo', 'pid=,pgid=,command='], text=True).splitlines()
groups = {int(line.split(None, 2)[1]) for line in processes if len(line.split(None, 2)) == 3}
owned = {}
for path in starts:
    row = json.loads(path.read_text())
    pid = row['pid']
    sdk.require(pid not in groups, 'owned proof group still present')
    owned[path.name] = {'pid': pid, 'process_group_absent': True}
sdk.write_json(stage / 'CLEANUP_28.json', {'completed': True, 'owned': owned})
sdk.write_json(stage / 'FAILED_CHECKS_28.json', {
    'completed': True,
    'initial_control_checker': 'Expected actionless Reveal_Identity in simplified JSON; corrected checker uses the checked proof case and exact SigningSecret/K binding.',
    'semantics_26': 'Rejected different informational builtin/function declarations between bare input and tool-closed export. Check 27 compares bare input with bare original and closed certificate with the original closed certificate.',
    'main_secrecy_verified': False,
})
files = {}
for path in sorted(stage.iterdir()):
    sdk.require(path.is_file(), 'unexpected evidence directory')
    suffix = path.suffix
    folder = 'proof' if suffix == '.spthy' else 'recipes' if suffix == '.py' else 'receipts'
    sdk.require(suffix in ('.spthy', '.py', '.json', '.stdout', '.stderr'), 'unexpected evidence member')
    files[folder + '/' + path.name] = sdk.snapshot(path, maximum=32 * 1024**2).data
prior = root / 'target/continuity-recovery-symbolic-20261015'
for name in ('TOOLS_08.json', 'tool-contract-09.json', 'tool-contract-09.stdout', 'tool-contract-09.stderr'):
    files['toolchain/' + name] = sdk.snapshot(prior / name).data
for name in ('protected-state.spthy', 'README.md'):
    files['source/' + name] = sdk.snapshot(root / 'research/continuity-recovery-symbolic' / name).data
files['source/RECOVERY_DEPENDENCIES_V1.md'] = sdk.snapshot(root / 'docs/continuity/RECOVERY_DEPENDENCIES_V1.md').data
files['proof/original-export.spthy'] = sdk.snapshot(root / 'target/continuity-recovery-disclosure-20261015/export-36.spthy').data
output = root / 'research/sdk-alpha1/evidence/20261015-recovery-crypto-provenance'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, data)
verified = {name: row['steps'] for name, row in replays['results']['independent-23']['results'].items()
            if row['status'] == 'verified'}
manifest = {'format': 1, 'base_commit': base_commit,
    'capture_sha256': sdk.snapshot(archive, maximum=64 * 1024**2).sha256,
    'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'certificate_sha256': sdk.snapshot(proof).sha256,
    'canonical_sha256': semantics['inputs']['canonical'], 'verified_crypto_obligations': verified,
    'signing_leak_executable_witness_steps': 6, 'countermodel_falsified_steps': 5,
    'original_five_declarations_unchanged': True, 'observer_actions': 3,
    'observer_erasure_semantics_identical': True, 'independent_replay_without_search': True,
    'missing_dependency_rejected_despite_exit_zero': True,
    'failed_search_receipts': failed_names, 'owned_process_groups_terminal': True,
    'main_secrecy_verified': False, 'canonical_model_changed': False,
    'production_code_changed': False, 'release_claim_eligible': False}
sdk.write_json(output / 'CAPTURE.json', manifest)
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(set(zipped.namelist())) == len(files), 'archive inventory differs')
    for name, digest in manifest['members'].items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, 'archive member differs')
    for name in ('REPLAYS_23.json', 'SEMANTICS_27.json', 'CONTROLS_VERIFIED_08.json', 'CLEANUP_28.json'):
        sdk.require(json.loads(zipped.read('receipts/' + name))['completed'], 'archived check incomplete')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'members': len(files),
    'capture_sha256': manifest['capture_sha256'], 'replayed_helper_count': len(verified),
    'main_secrecy_verified': False, 'private_sdk_runtime_data_selected': False})
print(json.dumps({'members': len(files), 'capture_sha256': manifest['capture_sha256'],
                  'verified_crypto_obligations': verified, 'main_secrecy_verified': False}))
