from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent;record=json.loads((stage/'composed-16-TERMINAL.json').read_text());assert record['accepted']
base=(stage/'composed-16-proof.spthy').read_text()
lemmas='''lemma pending_root_derivation_requires_session_leak [use_induction,reuse]:
 "All s peer coins old digest #reserved #known.
    EncapsulationSecret(s,peer,coins)@reserved
  & KU(h(<'pending-root',old,coins,digest>))@known
    ==> (Ex role #x. IdentityLeak(s,role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

lemma traffic_key_derivation_requires_session_leak [use_induction,reuse]:
 "All s peer coins old digest role transcript #reserved #known.
    EncapsulationSecret(s,peer,coins)@reserved
  & KU(h(<'traffic',s,role,h(<'pending-root',old,coins,digest>),transcript>))@known
    ==> (Ex leaked_role #x. IdentityLeak(s,leaked_role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

'''
marker='lemma recovery_is_executable:';assert base.count(marker)==1
variant=base.replace(marker,lemmas+marker)
with (stage/'key-frames-18.spthy').open('x') as f:f.write(variant)
with (stage/'KEY_FRAMES_18.json').open('x') as f:json.dump({'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'added_obligations':['pending_root_derivation_requires_session_leak','traffic_key_derivation_requires_session_leak'],'original_K_queries_unchanged':True,'new_observer_labels':0,'new_primitives_or_equations':False,'operational_rules_unchanged':True,'proof_model':'existing ideal hash and KEM algebra; no computational secrecy claim'},f,indent=2)
print('Prepared root and traffic-key provenance obligations over the existing constructors; no model rules changed')
