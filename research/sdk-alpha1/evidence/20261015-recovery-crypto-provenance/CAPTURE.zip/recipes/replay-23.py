"""Independently replay checked crypto helpers and reject a missing dependency."""
from pathlib import Path
import json, re, sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
source = stage / 'composed-16-proof.spthy'
expected = {
    'signing_secret_derivation_origin': 356,
    'generation_secret_derivation_origin': 187,
    'signing_secret_origin': 3,
    'generation_secret_origin': 7,
    'encapsulation_uses_authenticated_generation': 163,
    'encapsulation_derivation_requires_session_leak': 204,
}
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
original = source.read_text()
matches = list(decl.finditer(original))
sdk.require(len(matches) == 13, 'unexpected lemma inventory')
sdk.require(matches[0].group(1) == 'signing_secret_derivation_origin', 'wrong first dependency')
control = original[:matches[0].end()] + '\nby sorry\n\n' + original[matches[1].start():]
sdk.require([m.group() for m in decl.finditer(control)] == [m.group() for m in matches], 'declaration changed')
missing = stage / 'missing-dependency-23.spthy'
with missing.open('x') as output:
    output.write(control)

# Use the already exercised streaming/deadline runner; this separate variant
# requests no automatic proof search and retains exactly the same strict gate.
runner = (stage / 'run-09.py').read_text()
old = "*['--prove='+n for n in selected],"
sdk.require(runner.count(old) == 1, 'runner shape changed')
runner = runner.replace(old, '')
replay_runner = stage / 'run-replay-23.py'
with replay_runner.open('x') as output:
    output.write(runner)
results = {}
for label, model in [('independent-23', source), ('missing-dependency-23', missing)]:
    sdk.command([sys.executable, '-B', str(root / 'artifact/python_bootstrap.py'),
                 str(replay_runner), model.name, label, '600', *expected],
                stage / (label + '-driver'), root)
    terminal = json.loads((stage / (label + '-TERMINAL.json')).read_text())
    sdk.require(terminal['returncode'] == 0 and not terminal['timed_out'], 'replay did not complete')
    actual = {name: result['steps'] for name, result in terminal['results'].items()
              if result['status'] == 'verified'}
    if label == 'independent-23':
        sdk.require(actual == expected and terminal['accepted'], 'checked helper set differs')
    else:
        sdk.require(terminal['results']['signing_secret_derivation_origin']['status'] == 'analysis incomplete', 'control dependency unexpectedly proved')
        sdk.require(not terminal['accepted'], 'incomplete dependency admitted')
    results[label] = terminal
    print(json.dumps({'label': label, 'verified': actual, 'accepted': terminal['accepted']}), flush=True)
sdk.write_json(stage / 'REPLAYS_23.json', {
    'completed': True, 'proof_search_requested': False, 'results': results,
    'missing_dependency_rejected_despite_exit_zero': True,
    'original_main_secrecy_proof_accepted': False, 'release_claim_eligible': False,
})
