from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
summary=(stage/'untracked-leak-07.stdout').read_text().rsplit('summary of summaries:',1)[-1]
rows=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':status,'steps':int(count)} for n,status,count in rows}
sdk.require(len(results)==9 and results['signing_secret_origin']=={'status':'falsified - found trace','steps':5},'countermodel result not established')
sdk.require(not json.loads((stage/'untracked-leak-07-TERMINAL.json').read_text())['accepted'],'countermodel incorrectly accepted')
graphs=json.loads((stage/'untracked-leak-07-traces.json').read_text())['graphs'];sdk.require(len(graphs)==1,'countermodel trace inventory changed')
nodes=graphs[0]['jgNodes'];labels=[n['jgnLabel'] for n in nodes]
acts=[a['jgnFactName'] for n in nodes for a in n.get('jgnMetadata',{}).get('jgnActs',[])]
proof=(stage/'untracked-leak-07-proof.spthy').read_text()
block=proof.split('lemma signing_secret_origin',1)[1].split('lemma generation_secret_origin',1)[0]
sdk.require('Setup' in labels and 'SigningSecret' in acts and 'K' in acts and 'IdentityLeak' not in acts and 'case Reveal_Identity' in block and 'SOLVED' in block,'counterexample path or knowledge event differs')
known=[a['jgnFactTerms'][0] for n in nodes for a in n.get('jgnMetadata',{}).get('jgnActs',[]) if a['jgnFactName']=='K']
signers=[a['jgnFactTerms'][-1] for n in nodes for a in n.get('jgnMetadata',{}).get('jgnActs',[]) if a['jgnFactName']=='SigningSecret']
sdk.require(len(known)==1 and known[0] in signers,'known key does not match the observed signing key')
sdk.require(json.loads((stage/'signing-witness-07-TERMINAL.json').read_text())['accepted'],'ordinary identity-leak witness not checked')
sdk.write_json(stage/'CONTROLS_VERIFIED_08.json',{'completed':True,'ordinary_leak_witness_steps':6,'countermodel_status':results['signing_secret_origin'],'countermodel_trace_labels':labels,'countermodel_proof_case':'Reveal_Identity','trace_rendering_note':'The simplified JSON graph omits the actionless Reveal_Identity node; the checked proof script records that case and the graph binds K to the SigningSecret key.','countermodel_has_signing_secret_action':True,'countermodel_has_identity_leak_action':False,'countermodel_rejected_despite_exit_zero':True,'product_vulnerability_claim':False,'initial_runner_diagnostic_limitation':'The initial status regex omitted the falsified - found trace text. Its inventory check still rejected the result; this decoder records the full terminal status.'})
base=(stage/'signing-03-proof.spthy').read_text()
lemma='''lemma encapsulation_uses_authenticated_generation [use_induction,reuse]:
 "All s peer coins #reserved.
    EncapsulationSecret(s,peer,coins)@reserved
  & not (Ex #leaked. IdentityLeak(s,'A')@leaked)
  ==> (Ex key #generated. GenerationSecret(s,key)@generated
                         & peer = kempk(key) & generated < reserved)"

'''
marker='lemma recovery_is_executable:';sdk.require(base.count(marker)==1,'insertion point changed')
variant=base.replace(marker,lemma+marker)
with (stage/'auth-offer-08.spthy').open('x') as f:f.write(variant)
sdk.write_json(stage/'AUTH_INPUT_08.json',{'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'only_added_obligation':'encapsulation_uses_authenticated_generation','same_operational_rules':True,'original_formulas_unchanged':True,'forbids_only_target_initiator_identity_leak':True,'other_session_leaks_allowed':True,'assumed_verified':False})
runner=(stage/'run-02.py').read_text();old='verified|falsified|analysis incomplete';new='verified|falsified - found trace|analysis incomplete';sdk.require(runner.count(old)==1,'status parser source differs')
with (stage/'run-09.py').open('x') as f:f.write(runner.replace(old,new))
print('Leak witness verified in 6 steps; countermodel falsified in 5 and rejected; authenticated-key obligation prepared')
