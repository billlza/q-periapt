from pathlib import Path
import hashlib,json
root=Path.cwd();stage=Path(__file__).resolve().parent;prior=root/'target/continuity-recovery-secrecy-20261015'
canonical=(root/'research/continuity-recovery-symbolic/protected-state.spthy').read_text()
assert canonical==(prior/'original-01.spthy').read_text(),'canonical model changed'
base=(prior/'helpers-03.spthy').read_text();variant=base
changes=[('Setup(~sid)','Setup(~sid), SigningSecret(~sid,\'A\',~sa), SigningSecret(~sid,\'B\',~sb)'),('EncapReserved(s), Saved(s,~rev,\'4\')','EncapReserved(s), EncapsulationSecret(s,peer,~coins), Saved(s,~rev,\'4\')')]
for old,new in changes:
 assert variant.count(old)==1
 variant=variant.replace(old,new)
projection=variant
for old,new in reversed(changes):projection=projection.replace(new,old)
assert projection==base
signer='''lemma signing_secret_origin [use_induction,reuse]:
 "All s role key #created #known.
    SigningSecret(s,role,key)@created & K(key)@known
    ==> (Ex #leaked. IdentityLeak(s,role)@leaked)"

'''
encap='''lemma encapsulation_secret_requires_session_leak [use_induction,reuse]:
 "All s peer coins #reserved #known.
    EncapsulationSecret(s,peer,coins)@reserved & K(coins)@known
    ==> (Ex role #x. IdentityLeak(s,role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

'''
variant=variant.replace('lemma generation_secret_origin [use_induction]:',signer+'lemma generation_secret_origin [use_induction]:').replace('lemma clean_reservation_recovers_symbolic_message_secrecy:',encap+'lemma clean_reservation_recovers_symbolic_message_secrecy:')
with (stage/'crypto-01.spthy').open('x') as f:f.write(variant)
with (stage/'INPUTS_01.json').open('x') as f:json.dump({'base_commit':'b5e38b7e345997804dd826003cd7520020967a7a','canonical_sha256':hashlib.sha256(canonical.encode()).hexdigest(),'base_helper_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'observer_labels_added':3,'observer_erasure_byte_identical':True,'original_security_conditions_changed':False,'other_session_leakage_restricted':False,'replication_restricted':False,'new_obligations':['signing_secret_origin','encapsulation_secret_requires_session_leak'],'assumed_verified':False},f,indent=2)
print('Prepared signing-key and encapsulation-secret obligations with removable observation labels')
