"""Bind a root-provenance obligation to the actual response computation."""
from pathlib import Path
import hashlib, json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
base = (stage / 'composed-16-proof.spthy').read_text()
sdk.require(json.loads((stage / 'composed-16-TERMINAL.json').read_text())['accepted'], 'base proofs unverified')
old = "--[ Saved( s, ~rev, '5' ) ]->"
new = "--[ Saved( s, ~rev, '5' ), ResponseRoot(s,h(<'pending-root',old,coins,h(<'response',s,h(offer),kemct(peer,coins)>)>)) ]->"
sdk.require(base.count(old) == 1, 'unexpected response-computation action')
observed = base.replace(old, new)
sdk.require(observed.replace(new, old) == base, 'observer erasure differs')
lemma = '''lemma computed_root_derivation_requires_session_leak [use_induction,reuse]:
 "All s root #computed #known.
    ResponseRoot(s,root)@computed & KU(root)@known
    ==> (Ex role #x. IdentityLeak(s,role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

'''
marker = 'lemma recovery_is_executable:'
sdk.require(observed.count(marker) == 1, 'lemma insertion ambiguous')
variant = observed.replace(marker, lemma + marker)
with (stage / 'root-observer-24.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'ROOT_OBSERVER_24.json', {
    'base_sha256': hashlib.sha256(base.encode()).hexdigest(),
    'input_sha256': hashlib.sha256(variant.encode()).hexdigest(),
    'added_observation': 'ResponseRoot', 'observer_erasure_byte_identical': True,
    'new_operational_state_or_io': False, 'other_session_leakage_restricted': False,
    'failed_key_frame_or_message_obligations_used': False,
    'original_K_queries_unchanged': True, 'release_claim_eligible': False,
})
