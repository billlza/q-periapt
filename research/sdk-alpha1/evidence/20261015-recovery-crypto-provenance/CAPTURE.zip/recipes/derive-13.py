from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent;base=(stage/'crypto-01.spthy').read_text()
lemmas='''lemma signing_secret_derivation_origin [use_induction,reuse]:
 "All s role key #created #known.
    SigningSecret(s,role,key)@created & KU(key)@known
    ==> (Ex #leaked. IdentityLeak(s,role)@leaked)"

lemma generation_secret_derivation_origin [use_induction,reuse]:
 "All s key #created #known.
    GenerationSecret(s,key)@created & KU(key)@known
    ==> (Ex #x. EntropyLeak(s,'generation')@x)
      | (Ex #x. CapturedPhase(s,'A','1')@x)
      | (Ex #x. CapturedPhase(s,'A','2')@x)
      | (Ex #x. CapturedPhase(s,'A','3')@x)"

'''
marker='lemma signing_secret_origin [use_induction,reuse]:';assert base.count(marker)==1
variant=base.replace(marker,lemmas+marker)
with (stage/'derive-13.spthy').open('x') as f:f.write(variant)
with (stage/'DERIVATION_13.json').open('x') as f:json.dump({'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'added_obligations':['signing_secret_derivation_origin','generation_secret_derivation_origin'],'old_K_queries_unchanged':True,'operational_rules_unchanged':True,'KU_helpers_require_independent_proofs':True,'new_restrictions':False,'sources':['https://tamarin-prover.com/manual/master/book/009_precomputation.html','https://groups.google.com/g/tamarin-prover/c/SRGy-nK9DNM']},f,indent=2)
print('Added KU provenance obligations; all existing K properties and operational rules unchanged')
