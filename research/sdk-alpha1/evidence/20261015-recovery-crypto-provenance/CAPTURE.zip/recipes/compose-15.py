from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent
assert json.loads((stage/'derive-14-TERMINAL.json').read_text())['accepted']
assert json.loads((stage/'auth-offer-10-TERMINAL.json').read_text())['accepted']
base=(stage/'derive-14-proof.spthy').read_text()
lemmas='''lemma encapsulation_uses_authenticated_generation [use_induction,reuse]:
 "All s peer coins #reserved.
    EncapsulationSecret(s,peer,coins)@reserved
  & not (Ex #leaked. IdentityLeak(s,'A')@leaked)
  ==> (Ex key #generated. GenerationSecret(s,key)@generated
                         & peer = kempk(key) & generated < reserved)"

lemma encapsulation_derivation_requires_session_leak [use_induction,reuse]:
 "All s peer coins #reserved #known.
    EncapsulationSecret(s,peer,coins)@reserved & KU(coins)@known
    ==> (Ex role #x. IdentityLeak(s,role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

'''
marker='lemma recovery_is_executable:';assert base.count(marker)==1
variant=base.replace(marker,lemmas+marker)
with (stage/'compose-15.spthy').open('x') as f:f.write(variant)
with (stage/'COMPOSE_15.json').open('x') as f:json.dump({'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'new_obligation':'encapsulation_derivation_requires_session_leak','recheck_authentication_lemma_in_combined_context':True,'original_K_queries_unchanged':True,'operational_rules_unchanged':True,'unproved_helpers_not_admitted':True},f,indent=2)
print('Composed checked KU origins with the authentication obligation; encapsulation derivation still requires proof')
