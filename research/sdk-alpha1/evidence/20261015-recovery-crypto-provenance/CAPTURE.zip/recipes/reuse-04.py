from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent
assert json.loads((stage/'signing-03-TERMINAL.json').read_text())['accepted']
base=(stage/'signing-03-proof.spthy').read_text();old='lemma generation_secret_origin [use_induction]:';new='lemma generation_secret_origin [use_induction, reuse]:'
assert base.count(old)==1
variant=base.replace(old,new)
assert variant.replace(new,old)==base
with (stage/'crypto-reuse-04.spthy').open('x') as f:f.write(variant)
with (stage/'REUSE_04.json').open('x') as f:json.dump({'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'only_change':'reuse annotation on the existing generation_secret_origin lemma','rules_equations_restrictions_and_formulas_changed':False,'acceptance_requires_generation_lemma_verified_in_same_result':True,'assumed_verified':False},f,indent=2)
print('Prepared explicit generation-lemma reuse; acceptance requires its checked proof and all other dependencies')
