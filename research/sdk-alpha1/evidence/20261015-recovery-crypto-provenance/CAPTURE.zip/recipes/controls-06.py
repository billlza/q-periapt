from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent;source=(stage/'crypto-01.spthy').read_text()
witness='''lemma signing_identity_leak_is_executable:
 exists-trace
 "Ex s key #created #leaked #known.
    SigningSecret(s,'A',key)@created & IdentityLeak(s,'A')@leaked & K(key)@known
  & created < leaked & leaked < known"

'''
assert source.count('lemma signing_secret_origin [use_induction,reuse]:')==1
with (stage/'signing-witness-06.spthy').open('x') as f:f.write(source.replace('lemma signing_secret_origin [use_induction,reuse]:',witness+'lemma signing_secret_origin [use_induction,reuse]:'))
old="[ !Signer(s,role,key) ] --[ IdentityLeak(s,role) ]-> [ Out(key) ]";new="[ !Signer(s,role,key) ] --> [ Out(key) ]"
assert source.count(old)==1
changed=source.replace(old,new)
with (stage/'untracked-leak-06.spthy').open('x') as f:f.write(changed)
with (stage/'CONTROLS_06.json').open('x') as f:json.dump({'original_input_sha256':hashlib.sha256(source.encode()).hexdigest(),'witness_adds_only_an_existential_query':True,'untracked_leak_control_change':'Remove the IdentityLeak action from Reveal_Identity while preserving its key output. This is a counterfactual model, not a product finding.','expected_countermodel_property_status':'falsified','canonical_model_changed':False},f,indent=2)
print('Prepared explicit leak reachability and isolated untracked-leak countermodel')
