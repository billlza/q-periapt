from pathlib import Path
import json
stage=Path(__file__).resolve().parent
for graph in json.loads((stage/'untracked-leak-07-traces.json').read_text())['graphs']:
 for node in graph['jgNodes']:
  print(json.dumps({'label':node.get('jgnLabel'),'type':node.get('jgnType'),'keys':list(node),'metadata_keys':list(node.get('jgnMetadata',{})),'actions':node.get('jgnMetadata',{}).get('jgnActs',[])},ensure_ascii=False))
