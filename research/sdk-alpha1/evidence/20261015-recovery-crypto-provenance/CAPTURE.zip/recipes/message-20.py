from pathlib import Path
import hashlib,json
stage=Path(__file__).resolve().parent
assert json.loads((stage/'composed-16-TERMINAL.json').read_text())['accepted']
base=(stage/'composed-16-proof.spthy').read_text()
lemma='''lemma message_derivation_requires_session_leak [use_induction,reuse]:
 "All s role key payload #created #known.
    Message(s,role,key,payload)@created & KU(payload)@known
    ==> (Ex leaked_role #x. IdentityLeak(s,leaked_role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"

'''
marker='lemma recovery_is_executable:';assert base.count(marker)==1
variant=base.replace(marker,lemma+marker)
with (stage/'message-20.spthy').open('x') as f:f.write(variant)
with (stage/'MESSAGE_20.json').open('x') as f:json.dump({'base_sha256':hashlib.sha256(base.encode()).hexdigest(),'input_sha256':hashlib.sha256(variant.encode()).hexdigest(),'added_obligation':'message_derivation_requires_session_leak','original_K_queries_unchanged':True,'failed_key_frame_obligations_not_used':True,'operational_rules_unchanged':True,'maximum_heap_mib':8192,'host_memory_bytes':34359738368,'new_security_assumptions':False},f,indent=2)
runner=(stage/'run-09.py').read_text();assert runner.count("'-M4G'")==1
with (stage/'run-21.py').open('x') as f:f.write(runner.replace("'-M4G'","'-M8G'"))
print('Prepared message-level KU provenance on the checked KEM helpers; original recovery condition remains unchanged')
