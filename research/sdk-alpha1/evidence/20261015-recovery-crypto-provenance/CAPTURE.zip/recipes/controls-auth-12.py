from pathlib import Path
stage=Path(__file__).resolve().parent
source=(stage/'inspect-controls-08.py').read_text()
old="sdk.require('Setup' in labels and 'Reveal_Identity' in labels and 'SigningSecret' in acts and 'IdentityLeak' not in acts,'counterexample does not follow the untracked disclosure route')"
new="""proof=(stage/'untracked-leak-07-proof.spthy').read_text()
block=proof.split('lemma signing_secret_origin',1)[1].split('lemma generation_secret_origin',1)[0]
sdk.require('Setup' in labels and 'SigningSecret' in acts and 'K' in acts and 'IdentityLeak' not in acts and 'case Reveal_Identity' in block and 'SOLVED' in block,'counterexample path or knowledge event differs')
known=[a['jgnFactTerms'][0] for n in nodes for a in n.get('jgnMetadata',{}).get('jgnActs',[]) if a['jgnFactName']=='K']
signers=[a['jgnFactTerms'][-1] for n in nodes for a in n.get('jgnMetadata',{}).get('jgnActs',[]) if a['jgnFactName']=='SigningSecret']
sdk.require(len(known)==1 and known[0] in signers,'known key does not match the observed signing key')"""
assert source.count(old)==1
patched=source.replace(old,new).replace("'countermodel_trace_labels':labels,","'countermodel_trace_labels':labels,'countermodel_proof_case':'Reveal_Identity','trace_rendering_note':'The simplified JSON graph omits the actionless Reveal_Identity node; the checked proof script records that case and the graph binds K to the SigningSecret key.',")
with (stage/'inspect-controls-fixed-12.py').open('x') as f:f.write(patched)
print('Prepared a checker for the actual proof script and simplified graph format; earlier failed checker retained')
