"""Compare actual parsed proof inputs against the original semantic declarations."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sources = {
    'canonical': root / 'research/continuity-recovery-symbolic/protected-state.spthy',
    'observed': stage / 'crypto-01.spthy',
    'original-export': root / 'target/continuity-recovery-disclosure-20261015/export-36.spthy',
    'combined-input': stage / 'compose-15.spthy',
    'combined-proof': stage / 'composed-16-proof.spthy',
}
texts = {}
for label, source in sources.items():
    texts[label] = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(source), '--parse-only'], stage / (label + '-parse-27'), root).decode()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
rows = {label: {m.group(1): m.group() for m in decl.finditer(text)}
        for label, text in texts.items()}
original = rows['canonical']
sdk.require(len(original) == 5, 'original property inventory changed')
for label, declarations in rows.items():
    sdk.require(all(declarations.get(name) == value for name, value in original.items()),
                'original complete property changed in ' + label)
sdk.require(rows['combined-input'] == rows['combined-proof'], 'combined query declarations changed')

def semantic_prefix(text):
    prefix = text.split('\nlemma ', 1)[0]
    # Ignore presentation comments and spacing only. Predicates, terms, state,
    # restrictions and equations remain literal tokens in the comparison.
    prefix = re.sub(r'/\*.*?\*/', '', prefix, flags=re.S)
    prefix = re.sub(r'//[^\n]*', '', prefix)
    return re.sub(r'\s+', '', prefix)

canonical_prefix = semantic_prefix(texts['canonical'])
export_prefix = semantic_prefix(texts['original-export'])
observations = [",SigningSecret(~sid,'A',~sa)", ",SigningSecret(~sid,'B',~sb)",
                ',EncapsulationSecret(s,peer,~coins)']
projected = {}
for label in ('observed', 'combined-input', 'combined-proof'):
    prefix = semantic_prefix(texts[label])
    for observation in observations:
        sdk.require(prefix.count(observation) == 1, 'observer inventory differs in ' + label)
        prefix = prefix.replace(observation, '')
    sdk.require(prefix == (canonical_prefix if label == 'observed' else export_prefix), 'operational/equational projection differs in ' + label)
    projected[label] = True
sdk.require(sdk.snapshot(sources['canonical']).sha256 == '7802d0a937cd3f1afd75cb256c4cadc17b714f042f4894f4d471b3ea3d7bf902', 'canonical model changed')
sdk.write_json(stage / 'SEMANTICS_27.json', {
    'completed': True, 'inputs': {n: sdk.snapshot(p).sha256 for n, p in sources.items()},
    'original_five_full_declarations_unchanged': True,
    'combined_input_and_certificate_all_declarations_identical': True,
    'observer_erasure_operational_equational_restriction_identity': projected,
    'canonical_input_and_tool_export_compared_separately': True,
    'earlier_check_26_failure': 'bare builtins and closed theory export have different informational function declarations; compare each against the corresponding original representation',
    'observer_actions': 3, 'new_operational_state_or_io': False,
    'other_session_leakage_restricted': False, 'replication_restricted': False,
    'main_secrecy_verified': False,
})
print('Original five declarations and operational semantics agree after erasing three observation actions')
