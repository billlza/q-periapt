from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
output = root / 'research/sdk-alpha1/evidence/20261015-apple-pending-continuation'
manifest = json.loads((output / 'CAPTURE.json').read_text())
readback = json.loads((output / 'READBACK.json').read_text())
result = json.loads((stage / 'RESULT_06.json').read_text())
sdk.require(result['completed'] and result['cleanup'] and not result['live_producer'] and readback['completed']
            and readback['capture_sha256'] == manifest['capture_sha256'], 'continuation is not accepted and terminal')
document = f'''# Physical Swift recovery through renewed traffic

The offered {manifest['physical_model']} running iPadOS {manifest['physical_os']}
completed two fresh flows through the actual Apple binary package. Recovery of an
original pending write is followed by independently approved policy renewal,
current-authority activation, confirmation of the original message, epoch 1 rekey
and a distinct newly consumed business message in the same session.

| Witness / SDK trust / original write | Recovery calls | Renewal and traffic calls | Real process exits |
| --- | --- | --- | --- |
| Signed TCP / fixed / unapplied | 24 | 37 | 2 |
| Mutual TLS / recoverable / already applied | 23 | 37 | 2 |

All 121 invocations use distinct application processes, explicit startup
admissions, structured exit results and public container readbacks. Four deliberate
exits return 77; the remaining 117 return zero. As in the native fixture, each
route's first three identity, authority and genesis preparation calls use the
signed setup carrier. The TLS route selects mutual TLS before activation and
keeps it for subsequent traffic and maintenance. Exact per-phase carrier and mode
counts are checked, including the 74 renewal/traffic calls.

Each installation generates its own identity through public configuration.
An original message commits one receiver business effect before its delivery
result is lost. The R2 roster write and complete original recovery request are
retained before real P0 policy expiry. Fresh processes preserve the original
request and metadata through pre-call cancellation, a held Query process exit,
and a second exit after confirmation returns but before an application success
result is published. Exact retries authenticate the same target. The completed
old operation still cannot activate expired P0.

The same enrollment then emits its original policy-renewal request. The independent
account and policy roots approve P1 against that exact request. Modified approval
signatures, a substituted operation and cancellation are refused; each refusal is
followed by unchanged original request/status readback. Staging and its retry retain
the same approvals. Witness preparation, lost commit response, historical
reconciliation, close-after-application and exact commit replay preserve one
policy operation. Missing target selection and missing live registry are refused.
The receiver separately adopts P1; sender recovery does not change peer authority.

After permitted activation, the sender retries the original message and the
receiver confirms its existing effect. The original identity, journal, session,
message and effect remain linked. Both ends then complete rekey epoch 1. A fresh
message uses a different message ID, receives confirmed consumption and is
durably acknowledged. Each receiver has exactly two effects: the unchanged
original effect and the new payload `continued after pending recovery`.

The native fixture and public-record readers are shared with the
[Android continuation checkpoint](../20261015-android-pending-continuation/README.md).
Its historical Android names identify fixture code, not the execution platform:
these are physical Swift calls to the packaged iOS slice. The new Swift consumer
adapts typed public request/status fields to the fixture's explicit big-endian
interchange; that test format is not an SDK protocol or an authorization proof.
All signature, policy, witness and storage decisions remain in the unchanged SDK.

Source is `{manifest['source_commit']}`. The actual package was produced at
`{manifest['sdk_source_commit']}`; preparation checks the intervening changes,
package contents, current Swift binding bytes and the native reference artifacts.
The fresh application uses independent source/build/signing paths, strict Release
compilation, exact iOS native-slice identity and link-map verification. The earlier
sealed cohorts are not reopened. The owned app is removed after this run.

| Artifact | SHA-256 |
| --- | --- |
| Apple binary package | `{manifest['apple_package_sha256']}` |
| Packaged iOS static library | `{manifest['ios_staticlib_sha256']}` |
| Signed physical application | `{manifest['app_sha256']}` |
| Public capture | `{manifest['capture_sha256']}` |

`CAPTURE.zip` contains {readback['members']} public members. Independent extraction
checks every member hash, both full continuation readers, the exact phase census,
121 distinct process IDs and all four deferred cut-container records. Capture
selection excludes private keys and runtime stores; PEM data inspection includes
decoded JSON values. Hardware/signing identifiers are redacted. No on-device
private key or journal is exported, and no package is publicly released here.

The first cohort stopped at its rekey call after 58 successful application
results. Its SDK operation returned success, but the qualification relay reported
errors 54 and 22 and the app exited 1. The failed cohort was cleaned and sealed;
its sources, signed executable identity, public records and failure remain intact.
No fresh-message success is attributed to that cohort.

The relay treated one connection reset as fatal to its whole listener, then
attempted to stop the already-ended relay. Eight real loopback TCP controls
reproduce the same error pair for both reset directions and compare the original
and corrected relay. The correction closes both sides of that connection, records
the reset and preserves the bounded listener. It creates no response, retries no
SDK call and leaves the native protocol result authoritative. A truncated frame
still fails, and a later independent connection and explicit stop both succeed.
Normal half-close behavior is retained. Other relay errors remain failures.
The original device reset initiator was not captured and is not inferred from
this reproduction; a separate simple shutdown control did not reproduce a reset.
The accepted app records each reset's route, connection index and direction.
Its capture contains {len(manifest['connection_resets'])} such observations.

This demonstrates actual post-recovery traffic, beyond successful confirmation
or packaging. It does not establish post-compromise secrecy: rekey progress is
not a measurement of attacker knowledge. Storage-internal crash cuts, physical
power loss, background/Data Protection behavior, remaining cross-binding lifecycle
composition, independent/Linux interoperability, performance/energy/tail costs,
maintenance/freeze and external review retain their own 0.2.0 gates. The accepted
single Android phone remains sufficient for its recorded scope. No Intel Mac
slice or release-readiness claim is added.
'''
with (output / 'README.md').open('x') as stream:
    stream.write(document)
path = root / 'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md'
text = path.read_text()
old = '''remain intact. Apple post-recovery policy renewal, rekey and fresh traffic remain
separate from these recovery and earlier ABI/owner checks.
'''
new = '''remain intact. The [physical Swift continuation checkpoint](../sdk-alpha1/evidence/20261015-apple-pending-continuation/README.md)
then composes recovery with independently approved policy renewal, current-authority
activation, original-message confirmation, epoch 1 rekey and a distinct consumed
message. Its two fresh routes execute 121 app processes and four real exits;
each native receiver retains exactly the original and new business effects.
This confirms continued traffic, not post-compromise secrecy or power-loss recovery.
'''
sdk.require(text.count(old) == 1, 'pending recovery document boundary changed')
path.write_text(text.replace(old, new))
print('Documented physical Swift recovered renewal, rekey and distinct consumed traffic')
