from pathlib import Path
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
previous = stage.parent / 'continuity-apple-pending-interruption'
sdk.copy(previous / 'public_capture_check.py', stage / 'public_capture_check.py')
text = (previous / 'capture-10.py').read_text()


def replace(old, new):
    global text
    sdk.require(text.count(old) == 1, 'continuation capture boundary changed: ' + old[:60])
    text = text.replace(old, new)


replace('import base64\n', 'import sys\n')
replace('import continuity_android_pending as pending\n', 'import continuity_android_continuation as continued\n')
replace('stage = Path(__file__).resolve().parent\n',
        'stage = Path(__file__).resolve().parent\nsys.path.insert(0, str(stage))\nimport census_review\nfrom public_capture_check import contains_private_pem\n')
replace("device-driver-09.json", "device-driver-04.json")
replace("routes = [(kind, label) for kind in ('query-cancel', 'process-loss')\n          for label in ('signed-fixed-unapplied', 'tls-recoverable-applied')]", 'routes = list(continued.TESTS)')
replace('observed = {}\n', 'launch_arguments = []\n')
replace("    args = process['launchOptions']['arguments']\n", "    args = process['launchOptions']['arguments']\n    launch_arguments.append(args)\n")
start = text.index("    observed.setdefault((row['case'], row['profile'], args[4]), []).append(row['mode'])")
end = text.index('files = {}', start)
text = text[:start] + '''for label in routes:
    prefix = stage / ('device-06-' + label)
    sdk.require(json.loads(prefix.with_suffix('.json').read_text())['returncode'] == 0, 'native continuation route incomplete')
    stdout = prefix.with_suffix('.stdout').read_bytes()
    sdk.require(continued.verify_execution(stdout, stage / 'public-06', label)[label + '-continuation']
                == state['cases'][label + '-continuation'], 'public continuation reread differs')
census = census_review.verify(launch_arguments, stage / 'device-cases-04')
sdk.require(len(pids) == 121 and cut_count == 4, 'physical continuation process/cut census differs')

''' + text[end:]
replace("for path in (stage / 'before-drain').iterdir():\n    add(path, 'preimages/' + path.name)\n", '')
replace("for name in ['artifact/continuity_android_pending.py', 'artifact/continuity_android_contract.py',",
    "for name in ['artifact/continuity_android_pending.py', 'artifact/continuity_android_contract.py',\n             'artifact/continuity_android_continuation.py', 'artifact/continuity_android_policy_renewal.py',\n             'artifact/continuity_first_configuration.py', 'artifact/continuity_c_witness.py',\n             'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/flow.rs',\n             'bindings/c/ContinuityPackageConsumer/tests/common/android_pending_write/transport.rs',\n             'bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/continuation.rs',")
start = text.index('for kind, label in routes:\n    full_label =')
end = text.index("for directory in ('device-control-06'", start)
text = text[:start] + '''for label in routes:
    full_label = label + '-continuation'
    for name in continued.public(label):
        add(stage / 'public-06' / full_label / name, 'public/' + full_label + '/' + name)
''' + text[end:]
start = text.index('for kind, label in routes:\n    inputs =')
end = text.index('signing = json.loads', start)
text = text[:start] + '''sdk.require(all(not name.endswith(('/tls-key', '/witness-tls-key', '.redb', '.mobileprovision'))
                and not name.startswith('device-cases-') for name in files), 'private file selected')
for name, payload in files.items():
    if not name.startswith(('recipes/', 'source/', 'consumer/')):
        sdk.require(not contains_private_pem(name, payload), 'private PEM data in capture')
''' + text[end:]
replace("research/sdk-alpha1/evidence/20261015-apple-pending-interruption", "research/sdk-alpha1/evidence/20261015-apple-pending-continuation")
replace("'physical_swift_processes': 90,", "'physical_swift_processes': 121,")
replace("'actual_process_cuts': 4, 'startup_admissions': 90, 'routes': 4, 'cleanup': True,",
        "'actual_process_cuts': 4, 'startup_admissions': 121, 'routes': 2, 'cleanup': True,\n    'phase_census': census, 'rekey_epoch': 1, 'business_effects_per_route': 2,")
start = text.index('        for kind, label in routes:')
end = text.index("sdk.write_json(output / 'READBACK.json'", start)
text = text[:start] + '''        for label in routes:
            stdout = bundle.read('receipts/device-06-' + label + '.stdout')
            full_label = label + '-continuation'
            sdk.require(continued.verify_execution(stdout, extracted / 'public', label)[full_label]
                        == state['cases'][full_label], 'archive continuation reread differs')
''' + text[end:]
replace("'private_keys_excluded': True, 'public_readers': 4, 'physical_process_census': 90, 'actual_process_cuts': 4})",
        "'private_keys_excluded': True, 'private_exclusion_method': 'explicit public file selection and PEM data inspection',\n    'public_readers': 2, 'physical_process_census': 121, 'actual_process_cuts': 4})")
replace("print('Physical Swift interruption archive and independent public/process readback passed')",
        "print('Physical Swift continuation archive and independent public/process readback passed')")
replace('from collections import Counter\n', '')
with (stage / 'capture-08.py').open('x') as stream:
    stream.write(text)
print('Positive continuation capture requires terminal execution, cleanup, 121 processes and both full public readers')
