"""Real loopback TCP controls for the test relay, without SDK/runtime state."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import ctypes
import errno
import json
import socket
import struct
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
output = stage / 'relay-lifecycle-13'
output.mkdir()
old = json.loads((stage / 'APP.json').read_text())
new = json.loads((stage / 'attempt-12/APP_SOURCE_01.json').read_text())


def load_library(record, name):
    source = Path(record['consumer']) / 'Sources/USBRelay.c'
    sdk.require(sdk.snapshot(source).sha256 == record['source_files']['Sources/USBRelay.c'], 'relay source changed')
    path = output / (name + '.dylib')
    sdk.command(['xcrun', '--sdk', 'macosx', 'clang', '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic',
                 '-dynamiclib', str(source), '-o', str(path)], output / (name + '-compile'), root)
    library = ctypes.CDLL(str(path))
    library.qpc_test_relay_prepare.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint16)]
    library.qpc_test_relay_run.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint16, ctypes.c_char_p, ctypes.c_char_p]
    library.qpc_test_relay_stop.argtypes = [ctypes.c_int]
    return library


def exact(stream, length):
    result = b''
    while len(result) < length:
        block = stream.recv(length - len(result))
        if not block:
            raise EOFError('truncated frame')
        result += block
    return result


def frame(stream):
    length = int.from_bytes(exact(stream, 4), 'big')
    sdk.require(0 < length <= 16, 'frame length')
    return exact(stream, length)


def reset(stream):
    stream.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
    stream.close()


def pair(ports):
    return (socket.create_connection(('127.0.0.1', ports[1]), timeout=2),
            socket.create_connection(('127.0.0.1', ports[0]), timeout=2))


def orderly(ports):
    client, upstream = pair(ports)
    try:
        client.sendall(b'Q')
        sdk.require(exact(upstream, 1) == b'Q', 'request changed')
        upstream.sendall(b'\0\0\0\1R')
        sdk.require(frame(client) == b'R', 'response changed')
        client.shutdown(socket.SHUT_WR)
        upstream.shutdown(socket.SHUT_WR)
        sdk.require(client.recv(1) == upstream.recv(1) == b'', 'ordinary half-close failed')
    finally:
        client.close()
        upstream.close()


def scenario(library, implementation, kind):
    descriptors = (ctypes.c_int * 4)()
    ports = (ctypes.c_uint16 * 2)()
    sdk.require(library.qpc_test_relay_prepare(descriptors, ports) == 0, 'relay preparation')
    row = {'implementation': implementation, 'scenario': kind, 'sdk_opened': False}
    with ThreadPoolExecutor(max_workers=1) as executor:
        worker = executor.submit(library.qpc_test_relay_run, *descriptors[:3], ports[0], b'peer', b'1'*32)
        try:
            if kind == 'normal':
                orderly(ports)
                row['complete_response'] = True
            else:
                client, upstream = pair(ports)
                try:
                    client.sendall(b'Q')
                    sdk.require(exact(upstream, 1) == b'Q', 'request changed')
                    if kind == 'truncated-upstream-reset':
                        upstream.sendall(b'\0\0\0\4x')
                        reset(upstream)
                        try:
                            frame(client)
                        except (EOFError, ConnectionResetError):
                            row['truncation_rejected'] = True
                        else:
                            raise ValueError('truncated response was accepted')
                    else:
                        upstream.sendall(b'\0\0\0\1R')
                        sdk.require(frame(client) == b'R', 'complete response changed')
                        row['complete_response'] = True
                        reset(client if kind == 'local-reset' else upstream)
                        remaining = upstream if kind == 'local-reset' else client
                        try:
                            sdk.require(remaining.recv(1) == b'', 'reset manufactured data')
                        except ConnectionResetError:
                            pass  # The opposite endpoint observed the transport failure.
                finally:
                    client.close()
                    upstream.close()
                if implementation == 'old':
                    row['relay_result_before_stop'] = worker.result(timeout=5)
                    sdk.require(row['relay_result_before_stop'] == errno.ECONNRESET, 'old relay did not fail on reset')
                else:
                    orderly(ports)
                    row['next_independent_connection_passed'] = True
        finally:
            row['stop_result'] = library.qpc_test_relay_stop(descriptors[3])
        row['relay_result'] = worker.result(timeout=5)
    if implementation == 'old' and kind != 'normal':
        sdk.require([row['stop_result'], row['relay_result']] == [errno.EINVAL, errno.ECONNRESET], 'original failure pair differs')
    else:
        sdk.require(row['stop_result'] == row['relay_result'] == 0, 'listener/descriptor cleanup failed')
    return row


rows = []
for implementation, record in [('old', old), ('new', new)]:
    library = load_library(record, implementation)
    for kind in ('normal', 'local-reset', 'upstream-reset', 'truncated-upstream-reset'):
        rows.append(scenario(library, implementation, kind))
sdk.write_json(output / 'RESULT.json', {'completed': True, 'controls': rows,
    'old_device_error_pair_reproduced': True, 'truncation_remains_failure': True,
    'new_listener_survives_connection_reset': True, 'device_reset_initiator_not_inferred': True})
print('Eight real TCP controls passed: original failure reproduced, reset propagated, truncation rejected, next connection and cleanup preserved')
