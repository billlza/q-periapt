from pathlib import Path
import json
import secrets
import tempfile
import rust_sdk_profile as sdk

parent = Path(__file__).resolve().parent
stage = parent / 'attempt-12'
stage.mkdir()
old = json.loads((parent / 'APP.json').read_text())
prepared = json.loads((parent / 'PREPARED_01.json').read_text())
terminal = json.loads((parent / 'RESULT_06.json').read_text())
sdk.require(not terminal['completed'] and terminal['cleanup'] and not terminal['live_producer'], 'original run not terminal/cleaned')
outside = Path(tempfile.mkdtemp(prefix='qpc-apple-continued-relay-')).resolve()
consumer = outside / 'consumer'
for name, digest in old['source_files'].items():
    path = Path(old['consumer']) / name
    sdk.require(sdk.snapshot(path).sha256 == digest, 'failed source changed')
    sdk.copy(path, consumer / name)
path = consumer / 'Sources/USBRelay.c'
text = path.read_text()


def replace(old_text, new_text):
    global text
    sdk.require(text.count(old_text) == 1, 'relay boundary changed: ' + old_text[:60])
    text = text.replace(old_text, new_text)


replace('static int transfer(int first, int second, int cancellation, bool control) {',
        'static int transfer(int first, int second, int cancellation, bool control, int *reset_side) {\n    *reset_side = -1;')
replace('            if (n < 0) return failure();', '            if (n < 0) { *reset_side = (int)i; return failure(); }')
replace('                if (shutdown(sockets[1-i], SHUT_WR) != 0 && errno != ENOTCONN) return failure();',
        '                if (shutdown(sockets[1-i], SHUT_WR) != 0 && errno != ENOTCONN) { *reset_side = 1-(int)i; return failure(); }')
replace('                if (result != 0) return result;\n                if (control && i == 1)',
        '                if (result != 0) { *reset_side = 1-(int)i; return result; }\n                if (control && i == 1)')
helper = '''static int record_reset(const char *route, const char *run, unsigned int index, int side) {
    char marker[256];
    int length = snprintf(marker, sizeof(marker),
        "QPC_IOS_RELAY_RESET run=%s route=%s index=%u side=%s errno=%d\\n",
        run, route, index, side == 0 ? "upstream" : "local", ECONNRESET);
    if (length <= 0 || (size_t)length >= sizeof(marker)) return EOVERFLOW;
    size_t offset = 0;
    while (offset < (size_t)length) {
        ssize_t count = write(STDOUT_FILENO, marker + offset, (size_t)length - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) return failure();
        offset += (size_t)count;
    }
    return 0;
}
'''
replace('static int serve_connections(', helper + 'static int serve_connections(')
old_transfer = '''        int result = transport < 0 ? failure() : transfer(transport, local, cancellation, strcmp(route, "control") == 0);
        result = close_owned(transport, result);
        result = close_owned(local, result);
        if (result != 0) return result;'''
new_transfer = '''        int reset_side = -1;
        int result = transport < 0 ? failure() : transfer(transport, local, cancellation, strcmp(route, "control") == 0, &reset_side);
        int transport_close = close_owned(transport, 0);
        int local_close = close_owned(local, 0);
        if (transport_close != 0) return transport_close;
        if (local_close != 0) return local_close;
        if (result == ECONNRESET && reset_side >= 0) {
            // A reset terminates this byte stream and closes its opposite side.
            // Keep the bounded listener available; the SDK alone decides whether
            // it received a complete authenticated result. Never invent bytes or
            // retry an SDK operation. Report the exact observed transport event.
            result = record_reset(route, run, index, reset_side);
        }
        if (result != 0) return result;'''
replace(old_transfer, new_transfer)
path.write_text(text)
project = json.loads((consumer / 'project.json').read_text())
bundle = 'dev.qperiapt.PendingContinuation.r' + secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER'] = bundle
(consumer / 'project.json').write_text(json.dumps(project, indent=2) + '\n')
prepared.update(outside=str(outside), consumer=str(consumer))
sdk.write_json(stage / 'PREPARED_01.json', prepared)
sdk.write_json(stage / 'APP_SOURCE_01.json', {'consumer': str(consumer), 'bundle': bundle,
    'source_files': {str(path.relative_to(consumer)): sdk.snapshot(path).sha256 for path in consumer.rglob('*') if path.is_file()}})
for name in ('device_support.py', 'ios_client.py', 'usb_transport.py', 'relay_forward.py', 'run-cases-06.py', 'census_review.py'):
    sdk.require(sdk.snapshot(parent / name).sha256 == old['driver_files'][name], 'failed driver changed')
    sdk.copy(parent / name, stage / name)
(stage / 'ios_client.py').chmod(0o700)
path = stage / 'usb_transport.py'
text = path.read_text()
replace('messages=queue.Queue();observed=[];reader_errors=[];exchanges=[]',
        'messages=queue.Queue();observed=[];reader_errors=[];exchanges=[];resets=[]')
key = "      if match:messages.put((match[1].decode(),int(match[2]),int(match[3])))\n"
replace(key, key + """      reset=re.fullmatch(rb'QPC_IOS_RELAY_RESET run='+run.encode()+rb' route=(peer|witness|control) index=([0-9]+) side=(upstream|local) errno=54\\r?\\n',line)
      if reset:resets.append({'route':reset[1].decode(),'index':int(reset[2]),'side':reset[3].decode(),'errno':54})
""")
replace("   if not admitted:raise RuntimeError('SDK operation lacked host startup admission')",
    """   if not admitted:raise RuntimeError('SDK operation lacked host startup admission')
   reset_keys=[(row['route'],row['index']) for row in resets]
   if len(set(reset_keys))!=len(reset_keys) or any(route not in counts or not 1<=index<=counts[route] for route,index in reset_keys):raise RuntimeError('unbound relay reset record')""")
replace("   outcome['startup_admitted']=admitted", "   outcome['startup_admitted']=admitted\n   outcome['connection_resets']=resets")
path.write_text(text)
sdk.copy(parent / 'build-app-05.py', stage / 'build-app-05.py')
sdk.write_json(stage / 'RELAY_CHANGE_12.json', {'scope': 'test transport connection lifecycle only',
    'old_source_sha256': old['source_files']['Sources/USBRelay.c'],
    'new_source_sha256': sdk.snapshot(consumer / 'Sources/USBRelay.c').sha256,
    'sdk_changed': False, 'runtime_reopened': False, 'reset_observable': True,
    'reset_scope': 'one connection; opposite endpoint closed; original listener/time/connection bounds retained',
    'protocol_acceptance': 'unchanged native SDK plus full original fixture/public readers',
    'device_reset_initiator_before_instrumentation': 'not established'})
print('Fresh continuation cohort prepared with observable per-connection reset handling; all protocol checks retained')
