from pathlib import Path
import json
import secrets
import subprocess
import tempfile
import rust_sdk_profile as sdk
import continuity_apple_package as apple

root = Path.cwd()
stage = Path(__file__).resolve().parent
previous = root / 'target/continuity-apple-pending-interruption'
old = json.loads((previous / 'APP.json').read_text())
prior = json.loads((previous / 'PREPARED_01.json').read_text())
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain']), 'clean qualification source required')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only', prior['sdk_source_commit'], head], text=True).splitlines()
allowed = {'.github/workflows/codeql-memory-control.yml', 'artifact/codeql_memory_control.py',
    'artifact/test_codeql_memory_control.py', 'artifact/test_continuity_android_root.py',
    'artifact/test_continuity_android_jni.py', 'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md'}
sdk.require(all(name in allowed or name.startswith(('research/sdk-alpha1/evidence/20261015-apple-pending-recovery/',
    'research/sdk-alpha1/evidence/20261015-apple-pending-interruption/')) for name in changed), 'SDK source differs from package')
installed = Path(prior['installed'])
package = json.loads(Path(prior['package_record']).read_text())
apple.verify_package(installed, json.loads((installed / apple.CONTENTS).read_text()), package['native'],
                     (root / 'bindings/c/ContinuityPackageConsumer/qpc_owner.h').read_bytes())
for path in (root / 'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity').glob('*.swift'):
    sdk.require(path.read_bytes() == (installed / 'Sources/QPeriaptContinuity' / path.name).read_bytes(), 'public binding changed')
outside = Path(tempfile.mkdtemp(prefix='qpc-apple-pending-continued-')).resolve()
consumer = outside / 'consumer'
for name, digest in old['source_files'].items():
    path = Path(old['consumer']) / name
    sdk.require(sdk.snapshot(path).sha256 == digest, 'prior consumer source changed')
    sdk.copy(path, consumer / name)
for name in ('PolicyContinuationCommands.swift', 'ContinuedTraffic.swift'):
    sdk.copy(stage / name, consumer / 'Sources' / name)
request = (root / 'bindings/swift/ContinuityPackageConsumer/Sources/ContinuityConsumerFixtures/IndependentRequest.swift').read_text()
request = request.replace('// Same-host public fixture records; not a portable network or SDK API.',
    '// Public test interchange uses the existing native fixture big-endian fields; not a protocol or SDK API.')
request = request.replace('IndependentRequestFixture', 'PortablePolicyRequest')
for width in (32, 64):
    old_read = f'try take({width//8}).withUnsafeBytes {{ $0.loadUnaligned(as: UInt{width}.self) }}'
    sdk.require(request.count(old_read) == 1, 'request integer decoder shape')
    request = request.replace(old_read, f'try take({width//8}).reduce(UInt{width}(0)) {{ ($0 << 8) | UInt{width}($1) }}')
sdk.require(request.count('var value = value;') == 1, 'request integer encoder shape')
request = request.replace('var value = value;', 'var value = value.bigEndian;')
with (consumer / 'Sources/PortablePolicyRequest.swift').open('x') as stream:
    stream.write(request)
path = consumer / 'Sources/ReplacementCommands.swift'
text = path.read_text()
start = '        let operation = { () async throws -> [UInt8] in\n'
sdk.require(text.count(start) == 1, 'dispatch shape')
text = text.replace(start, start + '''            if mode == "policy-target-create" {
                return try PolicyContinuationCommands.createTarget(input, recoverable: profile == "recoverable")
            }
''')
old_registry = '''            let registry = try ContinuityAccountAuthority.prepareOpen(path:input.registryPath,trust:input.registryTrust())
            cleanup.append { try registry.close() }; try registry.finishOpen()
            try enrollment.selectAccountAuthority(registry,checkpoint:input.checkpoint())
'''
sdk.require(text.count(old_registry) == 1, 'registry selection shape')
text = text.replace(old_registry, '''            if mode != "policy-activate-unmanaged" {
''' + old_registry + '''            }
            if mode.hasPrefix("policy-") {
                return try PolicyContinuationCommands.execute(mode, input: input, enrollment: enrollment, recoverable: recoverable)
            }
''')
path.write_text(text)
project = json.loads((consumer / 'project.json').read_text())
bundle = 'dev.qperiapt.PendingContinuation.r' + secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER'] = bundle
project['packages']['Continuity']['path'] = str(installed)
(consumer / 'project.json').write_text(json.dumps(project, indent=2) + '\n')
sdk.write_json(stage / 'APP_SOURCE_01.json', {'consumer': str(consumer), 'bundle': bundle,
    'source_files': {str(path.relative_to(consumer)): sdk.snapshot(path).sha256 for path in consumer.rglob('*') if path.is_file()}})
host = json.loads((root / 'target/continuity-android-pending-continuation/BUILD_18.json').read_text())
files = {name: {'path': host[name], 'sha256': host[name + '_sha256']} for name in ('harness', 'receiver', 'library', 'target_client')}
for record in files.values():
    sdk.require(sdk.snapshot(Path(record['path']), maximum=256*1024**2).sha256 == record['sha256'], 'host artifact changed')
sdk.write_json(stage / 'PREPARED_01.json', {'source_commit': head, 'sdk_source_commit': prior['sdk_source_commit'],
    'outside': str(outside), 'consumer': str(consumer), 'installed': str(installed),
    'package_record': prior['package_record'], 'package_sha256': old['package_sha256'],
    'host_files': files, 'environment': prior['environment'], 'changed_since_sdk_package': changed})
for name in ('device_support.py', 'ios_client.py', 'usb_transport.py', 'relay_forward.py'):
    sdk.require(sdk.snapshot(previous / name).sha256 == old['driver_files'][name], 'prior helper changed')
    sdk.copy(previous / name, stage / name)
(stage / 'ios_client.py').chmod(0o700)
build = (previous / 'build-app-05.py').read_text().replace("APP_SOURCE_04.json", "APP_SOURCE_01.json")
build = build.replace("'relay_forward.py']", "'relay_forward.py','census_review.py']")
with (stage / 'build-app-05.py').open('x') as stream:
    stream.write(build)
print('Fresh Apple continuation consumer prepared; original SDK package and sealed runtimes unchanged')
