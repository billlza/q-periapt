from pathlib import Path
import rust_sdk_profile as sdk

parent = Path(__file__).resolve().parent
stage = parent / 'attempt-12'
sdk.copy(parent / 'public_capture_check.py', stage / 'public_capture_check.py')
text = (parent / 'capture-08.py').read_text()
key = "sdk.require(all(not name.endswith(('/tls-key', '/witness-tls-key', '.redb', '.mobileprovision'))"
sdk.require(text.count(key) == 1, 'capture selection boundary changed')
addition = '''parent = stage.parent
failed = json.loads((parent / 'RESULT_06.json').read_text())
old_app = json.loads((parent / 'APP.json').read_text())
sdk.require(not failed['completed'] and failed['cleanup'] and not failed['live_producer'], 'failed producer not terminal/cleaned')
sdk.require(json.loads((parent / 'relay-lifecycle-14/RESULT.json').read_text())['completed'], 'relay controls incomplete')
for path in parent.iterdir():
    if not path.is_file():
        continue
    if path.name == 'PREPARED_01.json':
        value = {key: value for key, value in json.loads(path.read_text()).items() if key != 'environment'}
        files['failed/receipts/PREPARED_01.json'] = (json.dumps(value, indent=2, sort_keys=True) + '\\n').encode()
    elif path.suffix in {'.py', '.swift'}:
        add(path, 'recipes/original/' + path.name)
    elif path.suffix in {'.json', '.stdout', '.stderr'}:
        add(path, 'failed/receipts/' + path.name)
for name, digest in old_app['source_files'].items():
    path = Path(old_app['consumer']) / name
    sdk.require(sdk.snapshot(path).sha256 == digest, 'failed consumer source changed')
    add(path, 'consumer/original/' + name)
for directory in ('device-control-06', 'device-execution', 'relay-reset-10', 'relay-reset-11', 'relay-lifecycle-13', 'relay-lifecycle-14'):
    for path in (parent / directory).rglob('*'):
        if path.is_file() and path.suffix in {'.json', '.stdout', '.stderr', '.txt', '.bin'}:
            add(path, 'failed/' + directory + '/' + path.relative_to(parent / directory).as_posix())
missing = []
for name in continued.public('signed-fixed-unapplied'):
    path = parent / 'device-cases-04/signed-fixed-unapplied-continuation' / name
    if path.exists():
        add(path, 'failed/public/signed-fixed-unapplied-continuation/' + name)
    else:
        missing.append(name)
files['failed/MISSING_PUBLIC_RECORDS.json'] = (json.dumps(missing, indent=2) + '\\n').encode()
'''
text = text.replace(key, addition + key)
text = text.replace("for path in (stage / 'device-execution').glob('*/PROCESS_RESULT.json'):",
    "for path in [* (stage / 'device-execution').glob('*/PROCESS_RESULT.json'), * (parent / 'device-execution').glob('*/PROCESS_RESULT.json')]:")
key = "'sdk_implementation_changed': False, 'protocol_or_storage_changed': False, 'release_claim_eligible': False, 'goal_active': True}"
sdk.require(text.count(key) == 1, 'manifest scope boundary')
text = text.replace(key, """'sdk_implementation_changed': False, 'protocol_or_storage_changed': False, 'release_claim_eligible': False, 'goal_active': True,
    'failed_original_cohort_retained': True, 'failed_original_successful_app_results': 58,
    'original_reset_initiator_established': False, 'relay_controls': 8,
    'connection_resets': [dict(json.loads((path.parent/'RESULT.json').read_text()), reset=reset)
        for path in (stage/'device-execution').glob('*/USB_TRANSPORT.json')
        for reset in json.loads(path.read_text())['connection_resets']]}""")
with (stage / 'capture-08.py').open('x') as stream:
    stream.write(text)
sdk.copy(parent / 'document-09.py', stage / 'document-09.py')
print('Fresh capture will preserve the entire failed public cohort and actual TCP controls without reopening runtime state')
