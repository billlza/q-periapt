from pathlib import Path
import rust_sdk_profile as sdk
import continuity_android_continuation as continued

stage = Path(__file__).resolve().parent
previous = stage.parent / 'continuity-apple-pending-interruption'
path = stage / 'ios_client.py'
text = path.read_text()
modes = sorted({mode for _, mode in continued.cases('signed')})
new = 'MODES |= ' + repr(set(modes)) + '\n'
position = 'PEER={'
sdk.require(text.count(position) == 1, 'driver peer boundary')
text = text.replace(position, new + "ALLOWED |= {'renewal-operation','renewal-request','renewal-approvals','renewal-statement','renewal-proposal'}\n" +
    "POLICY={'sdk-policy','sdk-signature','sdk-root','family','policy-root','tls-cert','tls-key','recovery-scope','recovery-root','recovery-enrollment','policy-version','policy-digest','protocol-policy'}\n" + position)
old = "  elif not f.is_file() or f.is_symlink() or f.name not in ALLOWED"
sdk.require(text.count(old) == 1, 'driver input validation boundary')
text = text.replace(old, """  elif f.name=='policy-target' and f.is_dir() and not f.is_symlink():
   if any(not p.is_file() or p.is_symlink() or p.name not in POLICY or p.stat().st_size>65536 for p in f.iterdir()):raise RuntimeError('policy target input boundary')
""" + old)
path.write_text(text)
text = (previous / 'run-cases-06.py').read_text()


def replace(old, new):
    global text
    sdk.require(text.count(old) == 1, 'continuation runner boundary changed: ' + old[:60])
    text = text.replace(old, new)


replace('import continuity_android_pending as pending\n',
        'import continuity_android_pending as pending\nimport continuity_android_continuation as continued\n')
replace('from device_support import APP, BUNDLE, selected, command, installed\n',
        'from device_support import APP, BUNDLE, selected, command, installed\nimport census_review\n')
replace("ROUTES = [(kind, label) for kind in ('query-cancel', 'process-loss')\n          for label in ('signed-fixed-unapplied', 'tls-recoverable-applied')]",
        "ROUTES = ('signed-fixed-unapplied', 'tls-recoverable-applied')")
replace('    observed = {}\n', '    launch_arguments = []\n')
replace("        args = process['launchOptions']['arguments']\n", "        args = process['launchOptions']['arguments']\n        launch_arguments.append(args)\n")
start = text.index("        key = (row['case'], row['profile'], args[4])")
end = text.index("    return {'physical_swift_processes'", start)
text = text[:start] + """    census_review.verify(launch_arguments, cases)
    sdk.require(len(pids) == sum(record['foreign_processes'] for record in results.values()) == 121 and cuts == 4, 'physical continuation process/cut census differs')
""" + text[end:]
replace("QPC_CONFIGURATION_RECEIVER=prepared['host_files']['receiver']['path'])",
        "QPC_CONFIGURATION_RECEIVER=prepared['host_files']['receiver']['path'],\n               QPC_CONFIGURATION_TARGET_CLIENT=prepared['host_files']['target_client']['path'])")
start = text.index('    for kind, label in ROUTES:')
end = text.index('    census = verify_processes(results)', start)
text = text[:start] + """    for label in ROUTES:
        stdout = sdk.command([harness, '--exact', continued.TESTS[label], '--nocapture'], stage / ('device-06-' + label), root, environment=env)
        readback_cuts(device)
        result = continued.verify_execution(stdout, cases, label)
        result_label = label + '-continuation'
        for name in continued.public(label):
            sdk.copy(cases / result_label / name, public / result_label / name)
        sdk.require(continued.verify_execution(stdout, public, label) == result, 'continued public copy differs')
        results.update(result)
        state['completed_routes'].append(result_label)
        progress()
        print('Physical Swift recovered continuation passed: ' + result_label, flush=True)
""" + text[end:]
replace("print('Physical Swift Query cancellation and process loss passed: 90 processes, 4 cuts; owned app removed')",
        "print('Physical Swift recovered renewal/rekey/fresh traffic passed: 121 processes, 4 cuts; owned app removed')")
with (stage / 'run-cases-06.py').open('x') as stream:
    stream.write(text)
print('Continuation dispatch, bounded nested inputs and exact 121-process phase census prepared')
