"""Plain TCP reproduction only; no SDK owner, key, journal or device is opened."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import ctypes
import errno
import json
import socket
import sys
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
app = json.loads((stage / 'APP.json').read_text())
source = Path(app['consumer']) / 'Sources/USBRelay.c'
sdk.require(sdk.snapshot(source).sha256 == app['source_files']['Sources/USBRelay.c'], 'executed relay source changed')
output = stage / 'relay-reset-11'
output.mkdir()
library_path = output / 'old-relay.dylib'
sdk.command(['xcrun', '--sdk', 'macosx', 'clang', '-std=c11', '-Wall', '-Wextra', '-Werror', '-Wpedantic',
             '-dynamiclib', str(source), '-o', str(library_path)], output / 'compile', Path.cwd())
library = ctypes.CDLL(str(library_path))
library.qpc_test_relay_prepare.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint16)]
library.qpc_test_relay_run.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint16, ctypes.c_char_p, ctypes.c_char_p]
library.qpc_test_relay_stop.argtypes = [ctypes.c_int]
descriptors = (ctypes.c_int * 4)()
ports = (ctypes.c_uint16 * 2)()
sdk.require(library.qpc_test_relay_prepare(descriptors, ports) == 0, 'relay setup failed')


def exact(stream, length):
    data = b''
    while len(data) < length:
        block = stream.recv(length - len(data))
        sdk.require(block, 'unexpected EOF')
        data += block
    return data


with ThreadPoolExecutor(max_workers=1) as executor:
    worker = executor.submit(library.qpc_test_relay_run, *descriptors[:3], ports[0], b'peer', b'0'*32)
    with socket.create_connection(('127.0.0.1', ports[1]), timeout=2) as client:
        with socket.create_connection(('127.0.0.1', ports[0]), timeout=2) as upstream:
            client.sendall(b'Q')
            sdk.require(exact(upstream, 1) == b'Q', 'request changed')
            upstream.sendall(b'R' + b'unread-close-trailer')
            sdk.require(exact(client, 1) == b'R', 'completed response changed')
            sdk.require(client.recv(len(b"unread-close-trailer"), socket.MSG_PEEK) == b'unread-close-trailer', 'trailer not demonstrably queued')
            # Match NativeChannel::drop: the application already has its response
            # and closes both directions without consuming the later trailer.
            client.shutdown(socket.SHUT_RDWR)
            client.close()
            relay_result = worker.result(timeout=5)
            stop_result = library.qpc_test_relay_stop(descriptors[3])
sdk.write_json(output / 'OBSERVATION.json', {'plain_tcp_only': True, 'sdk_runtime_opened': False,
    'original_source_sha256': sdk.snapshot(source).sha256, 'complete_response_received': True,
    'unread_trailer_confirmed': True, 'relay_result': relay_result, 'stop_result': stop_result,
    'matches_device_pair': [stop_result, relay_result] == [errno.EINVAL, errno.ECONNRESET]})
sdk.require(relay_result == errno.ECONNRESET and stop_result == errno.EINVAL, 'device reset pair was not reproduced')
print('Old relay reproduced exact [EINVAL, ECONNRESET] after a complete response and owned local shutdown')
