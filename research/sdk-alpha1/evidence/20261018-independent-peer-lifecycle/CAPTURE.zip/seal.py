"""Seal final current-source runs and explicitly labeled failed development evidence."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=root/'target/independent-peer-lifecycle-01';peer=root/'research/continuity-openssl-peer'
folder=root/'research/sdk-alpha1/evidence/20261018-independent-peer-lifecycle';folder.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
reports={name:json.loads((out/(name+'_READBACK.json')).read_text()) for name in ['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE']}
sources=reports['PEER_LIFECYCLE']['source_files'];assert len(sources)==63
for name,r in reports.items():
 if name!='REPLY_RELEASE':
  assert r['source_files']==sources and not r['source_continuity']['test_harness_only_changes']
  assert r['native_sha256']==reports['PEER_LIFECYCLE']['native_sha256']
runs=json.loads((out/'QUALIFIED_RUNS.json').read_text());assert len(runs)==13 and all(r['exit']==0 for r in runs)
entries={}
def public_tree(name,prefix=None):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink() and p.name not in {'head','intent','.stage-head','configuration','signer','key','wrong-signer'}
  data=p.read_bytes();assert not data.startswith((b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPREFS01',b'QPREFS02',b'QPREFS03',b'QPREFS04',b'QPREFS05'))
  entries[(prefix or name)+'/'+str(p.relative_to(out/name))]=data
for row in runs:
 name='qualified-'+row['lane'];assert not (out/(name+'.stderr')).read_bytes()
 public_tree(name)
 for ext in ['stdout','stderr']:entries[name+'.'+ext]=(out/(name+'.'+ext)).read_bytes()
for name in reports:
 filename=name+'_READBACK.json';entries[filename]=(out/filename).read_bytes()
readers=['qualified-review-final-regressions','qualified-review-final-control','qualified-review-resolution','qualified-review-witness','qualified-review-peer-lifecycle','review-reply-release']
for stem in readers:
 for ext in ['py','stdout','stderr']:entries[stem+'.'+ext]=(out/(stem+'.'+ext)).read_bytes()
 assert not entries[stem+'.stderr']
for name in ['source_readback.py','QUALIFIED_RUNS.json','run-qualified.py','seal.py','quality-inputs.json','quality.stdout','quality.stderr']:
 entries[name]=(out/name).read_bytes()
for stem in ['build','clippy','fmt','actionlint']:
 for ext in ['stdout','stderr']:entries[stem+'.'+ext]=(out/(stem+'.'+ext)).read_bytes()
for name,expected in sources.items():
 data=(peer/name).read_bytes();assert sha(data)==expected;assert subprocess.check_output(['git','show',':research/continuity-openssl-peer/'+name])==data
 entries['source/'+name]=data
for name in ['README.md','STORAGE.md']:entries['source/'+name]=(peer/name).read_bytes()
for name in ['.github/workflows/independent-continuity.yml','ARTIFACT.md','artifact/codeql_rust_quality.py','artifact/test_codeql_rust_quality.py']:
 entries['repository/'+name]=(root/name).read_bytes()
entries['counterpart']=(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
assert sha(entries['counterpart'])==reports['PEER_LIFECYCLE']['native_sha256']
quality=json.loads(entries['quality-inputs.json']);assert quality['Rust_files']==725 and len(quality['files'])==1125
for name,expected in quality['files'].items():assert sha((root/name).read_bytes())==expected
assert b'Ran 46 tests' in entries['quality.stderr'] and entries['quality.stderr'].rstrip().endswith(b'OK')
for name in ['red-release','green-release','red-reply-release','green-reply-release']:
 public_tree(name,'diagnostics/'+name)
 for ext in ['stdout','stderr']:entries['diagnostics/'+name+'.'+ext]=(out/(name+'.'+ext)).read_bytes()
for name in ['release-counterexample.py','before-release-guard-durable.py.txt','before-release-guard-control.py.txt','before-release-guard-peer_owner.py.txt',
             'before-witness-reply-guard-durable.py.txt','before-witness-reply-guard-peer_owner.py.txt','build-initial.stderr',
             'before-format-five-offsets-durability_checks.py.txt','before-format-five-offsets-durable_rekey_checks.py.txt',
             'final-base.stderr','final-owner.stderr','readback-prefix-error.stderr','readback-prefix-error.py.txt','readback-transition-count-error.stderr']:
 entries['diagnostics/'+name]=(out/name).read_bytes()
entries['DIAGNOSTIC_LIMITS.json']=(json.dumps({
 'first_bug':'Actual142byte ciphertext returned after reentrant protocol observer committed remote revocation; red-release fails, same scenario green-release passes after durable current-authority check.',
 'second_bug':'Actual150byte ciphertext returned after final witness-transport callback committed revocation; red-reply-release fails, green-reply-release and qualified peer-reply-release withhold output after in-process generation guard.',
 'prototype_counter':'green-release/RESULT.json predates computed kill counts and incorrectly says4; its worker records show3. Only final qualified per-profile computed counts are used for qualification.',
 'source_boundary':'The diagnostic scripts and relevant pre-fix sources are retained, not represented as a separate fully committed historical source tree.',
 'other_errors':'Initial native fixture called a nonexistent accessor. Two older mutation controls retained format4 offsets; corrected exact field positions and version expectation without weakening refusal checks. One adapted reader accidentally changed a hash label while renaming output directories; another expected six transitions instead of actual five. Final readers pass unchanged runtime outputs.',
 'private_state':'All original interrupted private directories and other prototype/failed public runs remain local. Captures omit private keys and images; public private-fixture-path references are retained.'
},indent=2)+'\n').encode()
changed=subprocess.check_output(['git','diff','23280124','--name-only'],text=True).splitlines()
allowed={'ARTIFACT.md','artifact/codeql_rust_quality.py','artifact/test_codeql_rust_quality.py','.github/workflows/independent-continuity.yml','docs/SDK_0_2_RELEASE_READINESS.md'}
assert all(n.startswith(('research/continuity-openssl-peer/','research/sdk-alpha1/evidence/')) or n in allowed for n in changed)
entries['SOURCE_CONTINUITY.json']=(json.dumps({'from_head':'23280124efd2f0f3003d4ce85e3db665f6ec8a25','base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'changed_paths':changed,'product_candidate_bindings_toolchain_unchanged':True,'tracked_Rust':725},indent=2)+'\n').encode()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,data)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(entries) and z.testzip() is None
 for name,item in manifest.items():
  data=z.read(name);assert len(data)==item['bytes'] and sha(data)==item['sha256']
report={'readbacks':reports,'validation':{'runtime_lanes':13,'source_files':63,'strict_release_build':True,'strict_all_target_clippy':True,'rustfmt':True,'actionlint':True,'Python_AST':True,'source_contract_tests':46,'tracked_Rust':725,'new_CodeQL_database':False},
 'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},
 'scope':'Unpublished independent remote peer authority on original local/witnessed sessions, exact format upgrade and revoked output denial. Native protocol counterpart remains at170 while independent peer tests210/310. Not full local enrollment renewal, same-account coordination, installed/cross-host lifecycle, power-loss/erasure or PCS proof. Hosted verification pending.'}
(folder/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['capture']))
