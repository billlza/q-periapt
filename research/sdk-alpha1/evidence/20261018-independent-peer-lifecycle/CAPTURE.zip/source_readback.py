"""Allow only the two retained schema-aware regression harness corrections."""
from pathlib import Path
import hashlib
import json

ROOT=Path.cwd();PEER=ROOT/'research/continuity-openssl-peer';OUT=Path(__file__).resolve().parent
HARNESS={'durability_checks.py','durable_rekey_checks.py'}
def sha(data):return hashlib.sha256(data).hexdigest()
def source_bytes(name,expected):
    data=(PEER/name).read_bytes()
    if sha(data)!=expected:
        if name not in HARNESS:raise ValueError('runtime source changed: '+name)
        data=(OUT/('before-format-five-offsets-'+name+'.txt')).read_bytes()
        if sha(data)!=expected:raise ValueError('unrecognized harness source: '+name)
    return data

def normalized(sources):
    for name,expected in sources.items():source_bytes(name,expected)
    return {name:sha((PEER/name).read_bytes()) for name in sources}


def continuity(sources):
    current=normalized(sources)
    return {'executed_source_files':sources,'current_source_files':current,
            'test_harness_only_changes':{n:{'executed':sources[n],'current':current[n]} for n in sources if sources[n]!=current[n]},
            'runtime_sources_identical':True}
