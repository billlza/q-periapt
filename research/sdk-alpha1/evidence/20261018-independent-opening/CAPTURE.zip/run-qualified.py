from pathlib import Path
import concurrent.futures
import json
import os
import subprocess
root=Path.cwd(); out=root/'target/independent-opening-01'
lanes={'exchange':'run.py','rekey':'rekey_checks.py','storage':'storage_checks.py','base':'durability_checks.py',
       'owner':'durable_rekey_checks.py','capacity':'capacity_checks.py','control':'control_checks.py',
       'resolution':'resolution_checks.py','maximum':'resolution_capacity_checks.py','disclosure':'resolution_disclosure_checks.py','witness':'witness_checks.py','peer-lifecycle':'peer_lifecycle_checks.py','peer-reply-release':'peer_reply_release_checks.py','local-renewal':'local_renewal_checks.py'}
def run(row):
 name,script=row
 command=['sh','artifact/python-run.sh','research/continuity-openssl-peer/'+script,
          '--provider-root','target/independent-bootstrap-01/provider','--output',str(out/('qualified-'+name))]
 if name!='storage':command += ['--native','target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart']
 env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14')
 with (out/('qualified-'+name+'.stdout')).open('xb') as stdout, (out/('qualified-'+name+'.stderr')).open('xb') as stderr:
  code=subprocess.run(command,env=env,stdout=stdout,stderr=stderr).returncode
 record={'lane':name,'exit':code};print(json.dumps(record),flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,lanes.items()))
(out/'QUALIFIED_RUNS.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit'] for r in results):raise SystemExit(1)
