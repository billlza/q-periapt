"""Require exact current executed source bytes, with no historical fallback."""
from pathlib import Path
import hashlib
PEER=Path.cwd()/'research/continuity-openssl-peer'
def source_bytes(name,expected):
    data=(PEER/name).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('source changed: '+name)
    return data
def normalized(sources):
    for name,expected in sources.items():source_bytes(name,expected)
    return dict(sources)
def continuity(sources):
    current=normalized(sources)
    return {'executed_source_files':sources,'current_source_files':current,'test_harness_only_changes':{},'runtime_sources_identical':True}
