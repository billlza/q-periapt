"""Read actual public witness attempts, outputs and worker cuts; no private keys."""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys
root=Path.cwd();peer=root/'research/continuity-openssl-peer';out=root/'target/independent-opening-01';folder=out/'qualified-witness'
sys.path.append(str(peer))
sys.path.append(str(out))
from source_readback import source_bytes, normalized, continuity
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load,load_witness_pin
from peer.witness import Operation,commitment,verify
from peer.rekey import RekeyScope,genesis
from peer.bootstrap import digest as bootstrap_digest

def check(value,message):
 if not value:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return parse_strict_json_bytes(path.read_bytes(),label=str(path))
def worker(name):return read(folder/(name+'.stdout'))['result']
def case(name):
 check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name),'case path')
 return folder/'native/cases'/name
r=read(folder/'RESULT.json');sources=r['source_files']
files=[*sorted((peer/'peer').glob('*.py')),*sorted(peer.glob('*.py')),*sorted((peer/'native/src').glob('*.rs')),peer/'native/Cargo.toml',peer/'native/Cargo.lock',peer/'requirements.txt']
check(len(sources)==70 and set(sources)=={str(p.relative_to(peer)) for p in files},'source inventory')
for name,expected in sources.items():
 data=source_bytes(name,expected);check(sha(data)==expected,'source identity')
 if name.endswith('.py'):ast.parse(data,name)
binary=(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
check(sha(binary)==r['native_sha256'] and binary[:4]==b'\xcf\xfa\xed\xfe' and int.from_bytes(binary[4:8],'little')==0x100000c,'actual ARM64 binary')
check(not (out/'qualified-witness.stderr').read_bytes() and not (folder/'native/native.stderr').read_bytes(),'runtime diagnostics')
check(len(r['worker_operations'])==36 and r['process_kills']==3 and len(r['native_commands'])==266 and len(r['witness_attempts'])==244 and len(r['refusals'])==47,'workload identity')
native={}
for row in r['native_commands']:
 prefix=case(row['case']);before=prefix.with_suffix('.input').read_bytes();after=prefix.with_suffix('.output').read_bytes()
 check(sha(before)==row['input_sha256'] and sha(after[1:])==row['output_sha256'] and after[0]==row['status'],'native bytes')
 check(row['case'] not in native,'duplicate native case');native[row['case']]=(before,after,row['command'])
 if row['status']==2:check(after[1:].decode()==row['error'],'native refusal')
kills=0
for row in r['worker_operations']:
 name=row['case'];case(name)
 request=read(folder/(name+'.request.json'));value=(folder/(name+'.stdout')).read_bytes();error=(folder/(name+'.stderr')).read_text()
 check(request['action']==row['action'],'worker action')
 if 'signal' in row:
  kills+=1;check(row['signal']=='SIGKILL' and read(folder/(name+'.stdout'))=={'pid':row['worker_pid'],'stage':row['cut']} and not error,'worker actual cut')
 elif 'refused' in row:check(not value and row['refused'] in error,'worker refused without output')
 else:check(sha(value)==row['stdout_sha256'] and not error,'worker output')
check(kills==3,'kill count')
check(r['opening_request_kinds']==[1],'single authenticated opening query')
pin=load_witness_pin(folder/'native/public');_,_,ctx=load(folder/'native/public',150,witness_pin=pin)
genesis_wire=bytes.fromhex(r['genesis']);subject=genesis_wire[:96]
check(len(genesis_wire)==128 and genesis_wire.hex()==worker('recover-original-genesis')==worker('repeat-original-genesis'),'exact recovered genesis')
check(subject[32:]==ctx.witness.owner+ctx.witness.policy,'enrolled genuine owner/policy')
check(native['trusted-enrollment'][0]==native['trusted-enrollment-exact-retry'][0]==genesis_wire,'trusted exact enrollment')
challenges=set();groups={};outcomes={};faults=[];signed=0
for row in r['witness_attempts']:
 name=row['case'];case(name)
 request=(folder/(name+'.request')).read_bytes();check(len(request)==3674 and sha(request)==row['request_sha256'],'request file')
 body=ctx.initiator.open(request,7,297);operation=Operation(body[200],body[201:])
 check(body[:136]==b'QPANRQ01'+pin.binding+subject and operation.kind==row['kind'],'request scope')
 command=commitment(b'COMMAND',pin.binding+subject+operation.wire())
 check(body[136:168]==command and command.hex()==row['command_id'] and body[168:200].hex()==row['challenge'] and any(body[168:200]),'request command/challenge')
 check(body[168:200] not in challenges,'reused challenge');challenges.add(body[168:200])
 groups.setdefault(command,[]).append(row)
 if row['fault']:faults.append(row)
 if row['delivery']=='not_dispatched_by_fixture':
  check(name not in native and row['fault']=='before','before-dispatch fault')
  continue
 check(native[name][0]==request and native[name][2]==31,'native request dispatch')
 response=native[name][1];check(response[0]==row['native_status'],'native response status')
 if response[0]==2:
  check(row['delivery']=='native_rejected_no_signed_reply' and response[1:].decode()==row['error'],'native refusal classification')
  continue
 reply=(folder/(name+'.reply')).read_bytes();check(response[1:]==reply and sha(reply)==row['signed_reply_sha256'],'actual signed reply')
 result=verify(pin,subject,operation,body,reply);signed+=1
 outcomes[result.outcome]=outcomes.get(result.outcome,0)+1
 row['verified_outcome']=result.outcome
 if row['delivery']=='sent':check(sha(reply)==row['transport_reply_sha256'],'transport bytes')
 elif row['delivery']=='corrupted_by_fixture':check(sha(reply[:-1]+bytes([reply[-1]^1]))==row['transport_reply_sha256'],'exact corrupted output')
 else:check(row['delivery']=='signed_reply_withheld_by_fixture' and row['fault']=='after','lost reply scope')
direct, response, command_number = native['close-during-exchange']
check(command_number==31 and response[0]==1,'direct close control provider result')
body=ctx.initiator.open(direct,7,297)
check(body[:136]==b'QPANRQ01'+pin.binding+subject and body[200:]==Operation.query().wire(),'direct query scope')
check(body[168:200] not in challenges and any(body[168:200]),'direct fresh challenge');challenges.add(body[168:200])
check(verify(pin,subject,Operation.query(),body,response[1:]).outcome==1,'valid reply during client close');signed+=1;outcomes[1]=outcomes.get(1,0)+1
check(len(faults)==3 and sorted(x['fault'] for x in faults)==['after','before','corrupt'],'three bounded transport faults')
for row in faults:
 if row['kind']==2:
  group=groups[bytes.fromhex(row['command_id'])]
  check(len(group)>=2 and any(x.get('verified_outcome') in (2,3) and x['case']!=row['case'] for x in group),'same command recovered after missing reply')
  if row['fault']=='after':check(row['verified_outcome']==2 and any(x.get('verified_outcome')==3 for x in group),'exact applied receipt after loss')
check(outcomes.get(3,0)>=3 and outcomes.get(6,0)>=1,'exact replay and current-authority refusal')
check(worker('expired-exact-recovery-status')=='Reserved' and worker('original-send-resume')==worker('original-send-replay'),'historical recovery retains original send')
check(worker('acknowledged-after-witness-reopen')=='Acknowledged' and native['reopen-actual-witness'][1]==b'\1witness reopened','actual witness reopen')
check(native['native-receive'][1]==b'\1original unknown send' and native['second-receive'][1]==b'\1not dispatched','actual native plaintext')
check(worker('reverse-receive')[1]==b'native witnessed reply'.hex(),'independent receive plaintext')
session=bytes.fromhex(r['session'])
initial=bytes.fromhex(worker('initial'));reply=native['bootstrap-response'][1][1:];final=bytes.fromhex(worker('original-final-recovery'))
check(native['bootstrap-response'][0]==initial and native['bootstrap-complete'][0]==final,'actual handshake transport')
check(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest,'required initial scope')
check(ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+bootstrap_digest(b'initial-wire',initial),'required response scope')
check(final[:104]==b'QPBSF001'+ctx.digest+bootstrap_digest(b'initial-wire',initial)+bootstrap_digest(b'reply-wire',reply)
      and session==bootstrap_digest(b'session-id',final[:104]),'required bootstrap transcript')
check(worker('activation-recovery')==session.hex() and native['bootstrap-complete'][1]==b'\1'+session,'original required session')
parent=genesis(session,ctx.digest)
for epoch in range(1,4):
 tag='rekey-'+str(epoch)
 if epoch%2:
  flights=[bytes.fromhex(worker(tag+'-offer')),native[tag+'-response'][1][1:],bytes.fromhex(worker(tag+'-final')),native[tag+'-receipt'][1][1:]]
 else:
  flights=[native[tag+'-offer'][1][1:],bytes.fromhex(worker(tag+'-response')),native[tag+'-final'][1][1:],bytes.fromhex(worker(tag+'-receipt'))]
 parent=RekeyScope(ctx,session,epoch-1,parent).public_completed(*flights)
 check(worker(tag+'-progress')==[epoch,epoch,epoch,0],'confirmed rekey target')
refusals={x['case']:x for x in r['refusals']}
for name in ['restored-old-image','local-reader-required-image','fence-before-output','fenced-original-reopen','closed-during-valid-reply']:
 check(name in refusals,'missing boundary refusal')
check([x['mode'] for x in r['transport_controls']]==['oversized','truncated','trickle'],'TCP controls')
report={'base_head':'b50307247c23adea0180999c1ae365462bf378b8','source_files':sources,'source_continuity':continuity(sources),'native_sha256':r['native_sha256'],
 'opening_request_kinds':r['opening_request_kinds'],'native_architecture':'MachO64 ARM64','workers':36,'native_commands':266,'process_kills':3,'refusals':47,'witness_attempts':244,
 'direct_client_attempts':1,'signed_witness_replies':signed,'witness_outcomes':outcomes,'unique_challenges':len(challenges),'epochs':3,'signed_rekey_flights':12,
 'scope':'Public source/binary/PID/command/dual-signature/attempt/epoch/original-output readback. No private image or MAC/AEAD key loaded. Rollback/fence/no-output, close and deadline controls remain actual runtime assertions. Not whole-witness rollback resistance, independent deployment, renewal/revocation/migration, physical erasure, power loss or PCS proof.'}
(out/'WITNESS_READBACK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['source_files','scope']}))
