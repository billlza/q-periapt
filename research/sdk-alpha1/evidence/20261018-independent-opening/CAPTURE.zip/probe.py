from pathlib import Path
import argparse,hashlib,json,os,sys,tempfile
root=Path.cwd();sys.path.append(str(root/'research/continuity-openssl-peer'))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from run import Counterpart
from fixture_inputs import load,load_witness_pin
from witness_fixture import Bridge
from peer.wire import SigningKey,require
from peer.journal import Scope
from peer.durable import owner_binding
from peer.witness import Client,TcpTransport
from peer.witness_session import WitnessSession
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--queries',type=int,required=True);args=p.parse_args()
out=args.output;out.mkdir();(out/'native').mkdir();native=Counterpart((root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart'),out/'native',required_witness=True)
private=Path(tempfile.mkdtemp(prefix='qperiapt-opening-')).resolve();(out/'private-fixture-path').write_text(str(private)+'\n')
bridge=None;owner=None
try:
 signer=SigningKey();require(native.transfer(signer.public().raw)==b'\1ready','ready')
 public=out/'native/public';pin=load_witness_pin(public);_,_,ctx=load(public,150,witness_pin=pin)
 path=private/'session';path.mkdir(mode=0o700);key=os.urandom(32);scope=Scope(os.urandom(32),owner_binding(ctx),ctx.digest)
 genesis=WitnessSession.provision(path,scope,key,ctx,signer,150)
 bridge=Bridge(native,out);bridge.call('trusted-enrollment',30,genesis.wire(),b'enrolled')
 client=Client(pin,ctx.witness.subject(scope.identity),signer,TcpTransport(bridge.address))
 owner=WitnessSession.open(path,scope,key,ctx,client=client)
 require([r['kind'] for r in bridge.records]==[1]*args.queries,'exact opening query count')
 owner.close();owner=None
 report={'queries':len(bridge.records),'expected':args.queries,'native_commands':native.commands,'witness_attempts':bridge.records,'sources':{n:hashlib.sha256((root/'research/continuity-openssl-peer'/n).read_bytes()).hexdigest() for n in ['peer/durable.py','peer/journal.py','peer/witness_session.py','peer/witness_journal.py']},'scope':'Real required witness and authenticated version-five image. Counts opening requests only, not latency/energy; no traffic result is released.'}
 (out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'queries':report['queries'],'scope':report['scope']}))
finally:
 if owner:owner.close()
 if bridge:
  (out/'ATTEMPTS.json').write_text(json.dumps(bridge.records,indent=2)+'\n');bridge.close()
 native.close()
