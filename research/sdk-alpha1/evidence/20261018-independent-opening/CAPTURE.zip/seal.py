"""Capture measured opening reduction and the unchanged-contract regressions."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;peer=root/'research/continuity-openssl-peer';folder=root/'research/sdk-alpha1/evidence/20261018-independent-opening';folder.mkdir()
def sha(data):return hashlib.sha256(data).hexdigest()
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','LOCAL_RENEWAL','REPLY_RELEASE','OPENING']
reports={n:json.loads((out/(n+'_READBACK.json')).read_text()) for n in labels};sources=reports['LOCAL_RENEWAL']['source_files'];assert len(sources)==70
for name,r in reports.items():
 if name not in ('REPLY_RELEASE','OPENING'):
  assert r['source_files']==sources and not r['source_continuity']['test_harness_only_changes'] and r['native_sha256']==reports['LOCAL_RENEWAL']['native_sha256']
runs=json.loads((out/'QUALIFIED_RUNS.json').read_text());assert len(runs)==14 and all(r['exit']==0 for r in runs)
entries={}
def tree(name):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink() and p.name not in {'head','intent','authority','configuration','signer','key','wrong-signer'} and not p.name.startswith('.stage-')
  data=p.read_bytes();assert not data.startswith((b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPREFS01',b'QPREFS02',b'QPREFS03',b'QPREFS04',b'QPREFS05',b'QPREFS06',b'QPRFLC01',b'QPRFLI01'))
  entries[name+'/'+str(p.relative_to(out/name))]=data
for name in ['qualified-'+r['lane'] for r in runs]+['before','after']:
 tree(name)
 for ext in ['stdout','stderr']:entries[name+'.'+ext]=(out/(name+'.'+ext)).read_bytes()
 assert not entries[name+'.stderr']
for n in labels:entries[n+'_READBACK.json']=(out/(n+'_READBACK.json')).read_bytes()
readers=['qualified-review-final-regressions','qualified-review-final-control','qualified-review-resolution','qualified-review-witness','qualified-review-peer-lifecycle','review-reply-release','review-local-renewal','review-opening']
for n in readers:
 for ext in ['py','stdout','stderr']:entries[n+'.'+ext]=(out/(n+'.'+ext)).read_bytes()
 assert not entries[n+'.stderr']
for n in ['source_readback.py','QUALIFIED_RUNS.json','run-qualified.py','probe.py','seal.py','VALIDATION.json']:entries[n]=(out/n).read_bytes()
for n,h in sources.items():
 data=(peer/n).read_bytes();assert sha(data)==h and subprocess.check_output(['git','show',':research/continuity-openssl-peer/'+n])==data;entries['source/'+n]=data
for n in ['README.md','STORAGE.md','LOCAL_RENEWAL.md']:entries['source/'+n]=(peer/n).read_bytes()
for n,h in reports['OPENING']['profiles']['before']['source_files'].items():
 data=subprocess.check_output(['git','show','b50307247c23adea0180999c1ae365462bf378b8:research/continuity-openssl-peer/'+n]);assert sha(data)==h;entries['baseline-source/'+n]=data
entries['repository/.github/workflows/independent-continuity.yml']=(root/'.github/workflows/independent-continuity.yml').read_bytes()
entries['counterpart']=(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes();assert sha(entries['counterpart'])==reports['LOCAL_RENEWAL']['native_sha256']
entries['SCOPE.json']=(json.dumps({'baseline_head':reports['OPENING']['baseline_head'],'runtime_change':'Internal journal factory transfers its recovered/authenticated opening snapshot into session construction; constructor still validates local control and retains no cache/output permit. Every business operation keeps original fresh state/current authority/release checks. Raw Journal.create/open return contract unchanged.','comparison':'Before3Query/after1Query,14682framedbytesremoved peropening, independently signed replies verified. Freshrandomfixtures; no latency/energy improvement measured. Before/after probes expected measured counts and are not product red/green failure tests.','regressions':'All14lanes and8readerspass; full raw public runs retained. Missing/corrupt local control, typed intent, process/lostreply recovery, expiry/cancellation/revocation and output guards retained.','native':'Same nativeRust sources and906ae3b3executable from061ff030; no native rebuild or unchangedquality/prover/benchmark rerun.','limits':'Independent reference only; no installed/network/fullidentity lifecycle, physical erasure,powerloss,witness rollback or construction-wide PCS claim. Private states preserved locally and excluded from this capture.'},indent=2)+'\n').encode()
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):
  i=zipfile.ZipInfo(n,(2026,10,18,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(entries) and z.testzip() is None
 for n,v in manifest.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
result={'readbacks':reports,'validation':json.loads(entries['VALIDATION.json']),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':json.loads(entries['SCOPE.json'])}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
