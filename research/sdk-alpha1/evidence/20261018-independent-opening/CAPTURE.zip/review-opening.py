"""Check genuine signed opening exchanges before and after direct snapshot transfer."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;peer=root/'research/continuity-openssl-peer';sys.path.append(str(peer))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load,load_witness_pin
from peer.witness import Operation,commitment,verify

def read(path):return parse_strict_json_bytes(path.read_bytes(),label=str(path))
def sha(data):return hashlib.sha256(data).hexdigest()
def check(value,reason):
 if not value:raise ValueError(reason)
profiles={};baseline='b50307247c23adea0180999c1ae365462bf378b8'
for label,count in [('before',3),('after',1)]:
 folder=out/label;r=read(folder/'RESULT.json');check(not (out/(label+'.stderr')).read_bytes() and not (folder/'native/native.stderr').read_bytes(),'probe diagnostics')
 check(r['queries']==r['expected']==len(r['witness_attempts'])==count,'actual opening request count')
 for name,expected in r['sources'].items():
  data=subprocess.check_output(['git','show',baseline+':research/continuity-openssl-peer/'+name]) if label=='before' else (peer/name).read_bytes()
  check(sha(data)==expected,'measured implementation source')
 pin=load_witness_pin(folder/'native/public');_,_,ctx=load(folder/'native/public',150,witness_pin=pin)
 native={}
 for row in r['native_commands']:
  name=row['case'];before=(folder/'native/cases'/(name+'.input')).read_bytes();after=(folder/'native/cases'/(name+'.output')).read_bytes()
  check(sha(before)==row['input_sha256'] and sha(after[1:])==row['output_sha256'] and after[0]==row['status']==1,'actual native transcript')
  check(name not in native,'duplicate native case');native[name]=(before,after)
 enrollment=native['trusted-enrollment'][0];subject=enrollment[:96]
 check(native['trusted-enrollment'][1]==b'\1enrolled' and subject[32:]==ctx.witness.owner+ctx.witness.policy,'genuine enrolled authority')
 commands=set();challenges=set();request_bytes=reply_bytes=0
 for row in r['witness_attempts']:
  request=(folder/(row['case']+'.request')).read_bytes();response=(folder/(row['case']+'.reply')).read_bytes()
  check(row['kind']==1 and row['fault'] is None and row['delivery']=='sent' and native[row['case']]==(request,b'\1'+response),'real unmodified Query')
  check(sha(request)==row['request_sha256'] and sha(response)==row['signed_reply_sha256']==row['transport_reply_sha256'],'query wire hashes')
  body=ctx.initiator.open(request,7,297);op=Operation(body[200],body[201:]);check(op==Operation.query(),'query grammar')
  command=commitment(b'COMMAND',pin.binding+subject+op.wire())
  check(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==command and command.hex()==row['command_id'],'original query binding');commands.add(command)
  check(body[168:200] not in challenges and any(body[168:200]) and body[168:200].hex()==row['challenge'],'fresh query challenge');challenges.add(body[168:200])
  result=verify(pin,subject,op,body,response);check(result.outcome==1 and result.head.fence==result.head.revision==1 and result.head.digest==enrollment[96:],'exact current original head')
  request_bytes+=len(request)+4;reply_bytes+=len(response)+4
 check(len(commands)==1 and len(challenges)==count,'one logical query with independent attempts')
 profiles[label]={'queries':count,'signed_replies':count,'unique_challenges':len(challenges),'framed_request_bytes':request_bytes,'framed_response_bytes':reply_bytes,'source_files':r['sources']}
result={'baseline_head':baseline,'profiles':profiles,'queries_removed_per_open':2,'framed_bytes_removed_per_open':sum(profiles['before'][k]-profiles['after'][k] for k in ['framed_request_bytes','framed_response_bytes']),'scope':'Same real required-witness opening profile with fresh independently generated fixture inputs. Direct request-count comparison, not latency/energy benchmarking. Signed genesis queries authenticate exact original heads. Final14lane suite covers pending/missing control, cancellation and business-output checks; this probe releases no traffic.'}
(out/'OPENING_READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
