#![forbid(unsafe_code)]
use qpc::{AccountPin,DeviceDescription,DeviceSigningKey,RootSigningKey,Validity,MonotonicInstant};
use std::time::Duration;
use wasm_bindgen::prelude::*;
fn error(e:impl std::fmt::Display)->JsError{JsError::new(&e.to_string())}
#[wasm_bindgen]
pub fn identity_fixture()->Result<String,JsError>{
 let mut root=RootSigningKey::generate().map_err(error)?;
 let mut signer=DeviceSigningKey::generate().map_err(error)?;
 let validity=Validity::new(100,200).map_err(error)?;
 let description=DeviceDescription::new([5;16],1,[6;32],validity).map_err(error)?;
 let certificate=root.issue_device(description,signer.public_key().map_err(error)?).map_err(error)?;
 let roster=root.issue_roster(1,validity,&[root.roster_entry(&certificate).map_err(error)?]).map_err(error)?;
 let account=root.account_id().map_err(error)?; let public=root.public_key().map_err(error)?;
 let pin=AccountPin::new(account,public.clone(),roster.checkpoint(),[6;32]).map_err(error)?;
 let device=pin.verify_device(&certificate,roster.as_bytes(),150).map_err(error)?;
 for offset in [1,65] {let mut changed=certificate.clone();let index=changed.len().checked_sub(offset).ok_or_else(||error("signature width"))?;*changed.get_mut(index).ok_or_else(||error("signature offset"))?^=1;
  if pin.verify_device(&changed,roster.as_bytes(),150).err()!=Some(qpc::Error::Authentication){return Err(error("modified signature component accepted"))}
 }
 let fixture=serde_json::json!({"root":public.encode(),"account":account,"family":([6u8;32].to_vec()),"credential":certificate,"roster":roster.as_bytes(),"rosterVersion":roster.checkpoint().version(),"rosterDigest":roster.checkpoint().digest(),"authority":device.authority_binding(),"signatureRefusals":2});
 root.close();if root.issue_device(description,signer.public_key().map_err(error)?).err()!=Some(qpc::Error::Closed){return Err(error("closed root accepted"))}
 signer.close();if signer.public_key().err()!=Some(qpc::Error::Closed){return Err(error("closed device signer accepted"))}
 if !matches!(qpc::JournalKey::open(std::path::Path::new("no-native-file-on-browser")),Err(qpc::DurableError::PrivateFile)){return Err(error("native private-file path admitted"))}
 Ok(fixture.to_string())
}
#[wasm_bindgen]
pub struct DeadlineProbe{start:MonotonicInstant,deadline:MonotonicInstant}
#[wasm_bindgen]
impl DeadlineProbe{
 #[wasm_bindgen(constructor)]
 pub fn new(milliseconds:u32)->Result<Self,JsError>{if milliseconds==0||milliseconds>1000{return Err(error("test deadline range"))}let start=MonotonicInstant::now();let deadline=start.checked_add(Duration::from_millis(milliseconds as u64)).ok_or_else(||error("deadline overflow"))?;Ok(Self{start,deadline})}
 pub fn expired(&self)->bool{MonotonicInstant::now()>=self.deadline}
 pub fn elapsed_millis(&self)->f64{self.start.elapsed().as_secs_f64()*1000.0}
}
