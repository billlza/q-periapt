async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.waitForFunction(()=>typeof window.runProbe==='function');
 const rows=await page.evaluate(()=>window.runProbe());
 return {status:errors.length===0&&rows.length===2&&rows.every(x=>x.status==='passed')?'passed':'failed',version:page.context().browser().version(),rows,pageErrors:errors};
}
