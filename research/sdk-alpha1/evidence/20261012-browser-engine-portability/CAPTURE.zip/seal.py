import datetime,hashlib,json,pathlib,platform,re,subprocess,zipfile
root=pathlib.Path.cwd(); stage=root/'target/continuity-browser-engine';out=root/'research/sdk-alpha1/evidence/20261012-browser-engine-portability'
sha=lambda b:hashlib.sha256(b).hexdigest()
def result(name):return json.loads((stage/name).read_text().split('### Result\n',1)[1].split('\n### ',1)[0])
r=result('browser-result.stdout');assert r['status']=='passed' and r['version']=='154.0.8037.99' and not r['pageErrors']
assert {x['realm'] for x in r['rows']}=={'window','worker'}
for row in r['rows']:assert row['signatureRefusals']==2 and row['clock']['expired'] and row['clock']['elapsedMs']>=200 and row['credentialBytes']==5474 and row['rosterBytes']==3499
native=(stage/'native-verify.stdout').read_text().splitlines();assert len(native)==2 and all(x.startswith('native-verified-browser-identity-and-both-signature-refusals: ') for x in native)
for prefix,count in [('native-tcp',3),('native-connect',9),('native-publication',13)]:assert f'test result: ok. {count} passed; 0 failed;' in (stage/(prefix+'.stdout')).read_text()
for log in ['check1.stderr','native-clippy.stderr','wasm-clippy.stderr','probe-build4.stderr','native-verify.stderr','native-tcp.stderr','native-connect.stderr','native-publication.stderr']:
 text=(stage/log).read_text();assert 'Finished ' in text and 'warning:' not in text and '\nerror' not in text,log
assert 'This wasm target is unsupported by mio.' in (stage/'baseline.stderr').read_text()
def diagnostics(name):return [re.sub(r'^.*?:\d+:\d+: ','',x) for x in (stage/name).read_text().splitlines()]
a=diagnostics('actionlint-current.stdout');b=diagnostics('actionlint-baseline.stdout');assert a==b and len(a)==2 and all('ubuntu-26.04' in x for x in a)
old=(stage/'transport-before.rs').read_text();new=(root/'research/continuity-identity-candidate/src/anchor/transport.rs').read_text();tcp=(root/'research/continuity-identity-candidate/src/anchor/transport/tcp.rs').read_text()
normalize=lambda s:re.sub(r'\s+','',s)
assert normalize(old[old.index('/// Missing or invalid witness evidence'):old.index('#[cfg(test)]')])==normalize(new[new.index('/// Missing or invalid witness evidence'):])
body=old[old.index('/// Reference TCP carrier:'):old.index('fn remaining(')]+old[old.index('pub(super) fn checked_remaining'):old.index('/// Missing or invalid witness evidence')]+old[old.index('#[cfg(test)]'):]
body=body.replace('pub(super) fn checked_remaining','pub(in crate::anchor) fn checked_remaining')
# rustfmt wrapped this longer restricted visibility and added the parameter-list comma.
body=body.replace('fn checked_remaining(deadline: Instant, cancel: &Cancellation)', 'fn checked_remaining(deadline: Instant, cancel: &Cancellation,)')
assert normalize(body)==normalize(tcp[tcp.index('/// Reference TCP carrier:'):])
assert 'closed' in (stage/'browser-close.stdout').read_text().lower()
p=subprocess.run(['ps','-p','81901','-o','command='],capture_output=True,text=True);assert p.returncode==1 and not p.stdout.strip()
files={}
for p in sorted((stage/'probe').rglob('*')):
 if p.is_file():files[str(p.relative_to(stage))]=p.read_bytes()
for p in sorted(stage.iterdir()):
 if p.is_file():files[p.name]=p.read_bytes()
changed=subprocess.check_output(['git','diff','--binary']);files['source/changes.patch']=changed
paths=['research/continuity-identity-candidate/src/anchor/transport/tcp.rs','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock','research/continuity-identity-candidate/src/anchor.rs','research/continuity-identity-candidate/src/anchor/transport.rs','research/continuity-identity-candidate/src/durable/publication.rs','research/continuity-identity-candidate/src/lib.rs']
for path in paths:files['source/'+path]=(root/path).read_bytes()
assert len(files)<100,len(files)
out.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,body in sorted(files.items()):z.writestr(name,body)
with zipfile.ZipFile(out/'CAPTURE.zip') as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name,body in files.items():assert z.read(name)==body
record={'schema':'qpc-browser-engine-portability/1','status':'shared-engine-portability-passed','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':platform.platform(),'architecture':platform.machine(),'capture':{'path':'CAPTURE.zip','sha256':sha((out/'CAPTURE.zip').read_bytes()),'members':len(files)},'files':{n:sha(b) for n,b in sorted(files.items())},'nativeVerifierSha256':sha((stage/'rust-target/debug/verify').read_bytes()),'nativeTests':{'tcp':3,'connect':9,'publication':13},'clippy':['native-all-features','wasm32-unknown-unknown'],'transportBodyAndTestsPreserved':True,'actionlint':'Two unchanged pre-existing ubuntu-26.04 label diagnostics; not an actionlint pass','browserContinuityAdmitted':False,'cleanup':{'ownedBrowserClosed':True,'ownedServerTerminal':143,'ownedServerPidAbsent':81901}}
for name,value in [('CHECKS.json',record),('RESULT.json',r)]:
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({k:record[k] for k in ['status','architecture','capture','nativeTests','clippy','transportBodyAndTestsPreserved','cleanup']},indent=2))
