from pathlib import Path
root=Path.cwd();p=root/'research/continuity-identity-candidate/src/anchor/transport.rs';old=p.read_text();(root/'target/continuity-browser-engine/transport-before.rs').write_text(old)
tcp_start=old.index('/// Reference TCP carrier:');remaining_start=old.index('fn remaining(');checked_start=old.index('pub(super) fn checked_remaining(');error_start=old.index('/// Missing or invalid witness evidence');tests_start=old.index('#[cfg(test)]\nmod tests {')
remaining=old[remaining_start:checked_start]
native=old[tcp_start:remaining_start]+old[checked_start:error_start]
# checked_remaining is shared by the native TCP and TLS carriers only.
native=native.replace('pub(super) fn checked_remaining(', 'pub(in crate::anchor) fn checked_remaining(')
tests=old[tests_start:]
start='// SPDX-License-Identifier: Apache-2.0 OR MIT\nuse super::{remaining, AnchorTransport};\nuse crate::{Cancellation, MonotonicInstant as Instant};\nuse std::{io::{self, Read, Write}, net::{SocketAddr, TcpStream}, time::Duration};\n\n'
tcp=p.parent/'transport'/'tcp.rs';tcp.parent.mkdir(exist_ok=True);tcp.write_text(start+native+tests)
imports='// SPDX-License-Identifier: Apache-2.0 OR MIT\nuse super::*;\nuse crate::MonotonicInstant as Instant;\nuse std::{io, time::Duration};\n\n#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]\nmod tcp;\n#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]\npub use tcp::AnchorTcpTransport;\n#[cfg(feature = "anchor-tls")]\npub(super) use tcp::checked_remaining;\n\n'
trait=old[old.index('/// Untrusted byte carrier.'):tcp_start]
p.write_text(imports+trait+remaining+'\n'+old[error_start:tests_start])
p=root/'research/continuity-identity-candidate/src/lib.rs';s=p.read_text().replace('mod connect;','#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]\nmod connect;').replace('    AnchorTcpTransport, AnchorTransport, RosterRefreshId, RosterRefreshScope,','    AnchorTransport, RosterRefreshId, RosterRefreshScope,')
s=s.replace('mod account_authority;', '''/// Monotonic deadline clock. Native targets retain `std::time::Instant`; browser
/// targets use the platform performance clock. This is not credential wall time.
#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
pub use std::time::Instant as MonotonicInstant;
/// Monotonic deadline clock backed by the browser performance clock.
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
pub use web_time::Instant as MonotonicInstant;
#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
pub use anchor::AnchorTcpTransport;

mod account_authority;''',1);p.write_text(s)
p=root/'research/continuity-identity-candidate/src/anchor.rs';s=p.read_text().replace('pub use transport::{AnchorClient, AnchorClientError, AnchorTcpTransport, AnchorTransport};','pub use transport::{AnchorClient, AnchorClientError, AnchorTransport};\n#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]\npub use transport::AnchorTcpTransport;');p.write_text(s)
p=root/'research/continuity-identity-candidate/src/durable/publication.rs';s=p.read_text().replace('use std::time::Instant;','use crate::MonotonicInstant as Instant;');p.write_text(s)
p=root/'research/continuity-identity-candidate/Cargo.toml';s=p.read_text();line='mio = { version = "=1.2.3", default-features = false, features = ["net", "os-poll"] }\n';assert s.count(line)==1;s=s.replace(line,'');s=s.replace('[features]', '''# Raw sockets are a native carrier, not a protocol or browser dependency.
[target.'cfg(not(all(target_arch = "wasm32", target_os = "unknown")))'.dependencies]
'''+line+'''
[target.'cfg(all(target_arch = "wasm32", target_os = "unknown"))'.dependencies]
web-time = "=1.1.0"

[features]''');p.write_text(s)
