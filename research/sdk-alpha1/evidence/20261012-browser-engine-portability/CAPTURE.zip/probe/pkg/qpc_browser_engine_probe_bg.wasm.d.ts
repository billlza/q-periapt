/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_deadlineprobe_free: (a: number, b: number) => void;
export const deadlineprobe_elapsed_millis: (a: number) => number;
export const deadlineprobe_expired: (a: number) => number;
export const deadlineprobe_new: (a: number) => [number, number, number];
export const identity_fixture: () => [number, number, number, number];
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
