import init,{identity_fixture,DeadlineProbe} from './pkg/qpc_browser_engine_probe.js';
export async function exercise(realm){
 await init();const fixture=JSON.parse(identity_fixture());
 if(fixture.signatureRefusals!==2)throw new Error('signature controls missing');
 const d=new DeadlineProbe(200);let clock;
 try{if(d.expired())throw new Error('fresh deadline expired');await new Promise(r=>setTimeout(r,250));clock={expired:d.expired(),elapsedMs:d.elapsed_millis()};if(!clock.expired||clock.elapsedMs<200)throw new Error('deadline failed')}finally{d.free()}
 const response=await fetch('/capture-'+realm,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(fixture)});
 if(response.status!==201)throw new Error('capture failed '+response.status);
 return {status:'passed',realm,clock,signatureRefusals:fixture.signatureRefusals,credentialBytes:fixture.credential.length,rosterBytes:fixture.roster.length};
}
