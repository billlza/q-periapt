const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const routes=new Map([['/','index.html'],['/worker.mjs','worker.mjs'],['/acceptance.mjs','acceptance.mjs'],['/pkg/qpc_browser_engine_probe.js','pkg/qpc_browser_engine_probe.js'],['/pkg/qpc_browser_engine_probe_bg.wasm','pkg/qpc_browser_engine_probe_bg.wasm']]);
const server=http.createServer((req,res)=>{const route=new URL(req.url,'http://127.0.0.1').pathname;
 if(req.method==='POST'&&['/capture-window','/capture-worker'].includes(route)){
  let length=0,chunks=[];req.on('data',b=>{length+=b.length;if(length>256*1024){req.destroy();return}chunks.push(b)});req.on('end',()=>{try{const data=Buffer.concat(chunks);JSON.parse(data);fs.writeFileSync(path.join(__dirname,route.slice(1)+'.json'),data,{flag:'wx',mode:0o600});res.writeHead(201);res.end('captured')}catch(e){console.error(e);res.writeHead(500);res.end('capture failed')}});return;
 }
 const file=routes.get(route);if(req.method!=='GET'||!file){res.writeHead(404);res.end('not found');return}
 try{res.writeHead(200,{'Content-Type':file.endsWith('.wasm')?'application/wasm':file.endsWith('.html')?'text/html':'application/javascript','Cache-Control':'no-store'});res.end(fs.readFileSync(path.join(__dirname,file)))}catch(e){console.error(e);res.writeHead(500);res.end('read failed')}
});server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port+'/',pid:process.pid})));
