import {exercise} from './acceptance.mjs';
try{if(!(self instanceof DedicatedWorkerGlobalScope))throw new Error('wrong realm');postMessage(await exercise('worker'))}catch(e){postMessage({status:'failed',error:String(e)})}finally{self.close()}
