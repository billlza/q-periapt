from pathlib import Path
import hashlib,json,re
import rust_sdk_profile as sdk
root=Path.cwd(); stage=Path(__file__).resolve().parent
source=root/'research/continuity-recovery-symbolic/protected-state.spthy'
sdk.require(sdk.snapshot(source).sha256=='7802d0a937cd3f1afd75cb256c4cadc17b714f042f4894f4d471b3ea3d7bf902','canonical changed')
base=source.read_text(); start=base.index('rule Setup:'); end=base.index('\nrule Cut:',start)
setup='''rule Identity_Pair:
 [ Fr(~owner), Fr(~sa), Fr(~sb) ]
 --[ SigningSecret(~owner,'A',~sa), SigningSecret(~owner,'B',~sb) ]->
 [ !IdentityPair(~owner,~sa,~sb), Out(<~owner,pk(~sa),pk(~sb)>) ]

rule Setup:
 [ !IdentityPair(owner,sa,sb), Fr(~sid), Fr(~old), Fr(~wa), Fr(~wb) ]
 --[ Setup(~sid), SessionOwner(~sid,owner) ]->
 [ !Signer(~sid,'A',sa), !Signer(~sid,'B',sb)
 , !Pinned(~sid,'A',pk(sa)), !Pinned(~sid,'B',pk(sb))
 , !Wrap(~sid,'A',~wa), !Wrap(~sid,'B',~wb)
 , !SignerFile(~sid,'A',sa), !SignerFile(~sid,'B',sb)
 , OfferStart(~sid,~old), ResponseStart(~sid,~old), CutPermit(~sid)
 , Out(<~sid,~old,pk(sa),pk(sb)>) ]
'''
changed=base[:start]+setup+base[end:]
changed=changed.replace('theory ContinuityRecoveryTransition','theory ContinuitySharedIdentityTransition',1)
queries='''lemma other_session_identity_leak_breaks_session_scoped_recovery:
 exists-trace
 "Ex s other owner key payload #target #sibling #leak #c #g #e #m #known.
    SessionOwner(s,owner)@target & SessionOwner(other,owner)@sibling
  & not (s = other) & IdentityLeak(other,'B')@leak
  & Cut(s)@c & KeyReserved(s)@g & EncapReserved(s)@e
  & Message(s,'A',key,payload)@m & K(payload)@known
  & c < g & c < e & leak < m
  & (All any_session role #extra. IdentityLeak(any_session,role)@extra
       ==> any_session = other & role = 'B' & #extra = #leak)
  & not (Ex any_session kind #x. EntropyLeak(any_session,kind)@x)
  & not (Ex any_session revision #x. Snapshot(any_session,revision)@x)"

lemma shared_identity_key_origin [use_induction]:
 "All owner role key #created #known.
    SigningSecret(owner,role,key)@created & KU(key)@known
    ==> (Ex s #setup #leaked.
          SessionOwner(s,owner)@setup & IdentityLeak(s,role)@leaked)"

'''
changed=changed.replace('lemma generation_secret_origin',queries+'lemma generation_secret_origin',1)
path=stage/'shared-identity-01.spthy'
with path.open('x') as stream:stream.write(changed)
declaration=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
original={m.group(1):m.group() for m in declaration.finditer(base)}
current={m.group(1):m.group() for m in declaration.finditer(changed)}
sdk.require(len(original)==5 and all(current[n]==q for n,q in original.items()),'original formulas changed')
sdk.require(changed[changed.index('rule Cut:'):changed.index('lemma other_session')]==base[base.index('rule Cut:'):base.index('lemma generation_secret_origin')],'non-setup rules changed')
sdk.write_json(stage/'PREPARED_01.json',{'canonical_sha256':sdk.snapshot(source).sha256,'model_sha256':sdk.snapshot(path).sha256,'changes':['share signing keys across independently initialized sessions','add SessionOwner and SigningSecret proof observations','add two queries; original five full declarations unchanged'],'wrapping_keys_still_per_session':True,'non_setup_rules_equations_restrictions_unchanged':True,'release_claim_eligible':False})
print('Shared signing identities prepared; all post-setup transitions and original five queries unchanged')
