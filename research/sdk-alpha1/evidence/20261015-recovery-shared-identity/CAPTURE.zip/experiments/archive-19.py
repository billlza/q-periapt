from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
verified=json.loads((stage/'VERIFIED_15.json').read_text())
locale=json.loads((stage/'utf8-replay-16/RESULT.json').read_text())
checkpoint=json.loads((stage/'CHECKPOINT_18.json').read_text())
sdk.require(verified['completed'] and locale['accepted'] and checkpoint['source_gate'] and checkpoint['clean_clone_regressions'],'missing terminal evidence')
sdk.require(locale['gate_sha256']==sdk.snapshot(root/'artifact/continuity_recovery_proof.py').sha256,'locale gate changed')
sdk.require(len(locale['groups']['positive']['verified'])==20 and len(locale['groups']['witnesses']['verified'])==3,'locale group incomplete')
failed=json.loads((stage/'original-query-08-TERMINAL.json').read_text())
sdk.require(failed['timed_out'] and not failed['accepted'],'direct search history differs')
ci=json.loads((stage/'ci-artifact-14/RESULT.json').read_text())
sdk.require(not ci['accepted'] and ci['error']=='positive prover exited 1','CI failure differs')
sdk.require('cannot decode byte sequence starting from 226' in (stage/'ci-artifact-14/positive.stderr').read_text(),'CI decoding root cause not found')
sdk.require('Ran 190 tests' in (stage/'tests-18.stderr').read_text() and (stage/'tests-18.stderr').read_text().endswith('OK\n'),'related regressions not complete')
public=root/'research/sdk-alpha1/evidence/20261015-recovery-shared-identity'
public.mkdir()
files={}
for path in stage.iterdir():
 if path.is_file() and path.suffix in ('.py','.spthy','.json','.stdout','.stderr','.log','.yml'):
  files['experiments/'+path.name]=sdk.snapshot(path,maximum=64*1024**2).data
for directory in ('ci-artifact-14','utf8-replay-16'):
 for path in (stage/directory).iterdir():
  sdk.require(path.is_file() and not path.is_symlink(),'unexpected child')
  files[directory+'/'+path.name]=sdk.snapshot(path,maximum=64*1024**2).data
for relative in ('research/continuity-recovery-symbolic/protected-state.spthy','research/continuity-identity-candidate/src/enrollment.rs','research/continuity-identity-candidate/src/durable/initiator.rs','research/continuity-identity-candidate/src/durable/messages/rekey.rs','research/continuity-identity-candidate/src/durable/messages/rekey/response.rs','research/continuity-identity-candidate/src/durable/messages/tests/fanout.rs','artifact/continuity_recovery_proof.py','artifact/test_continuity_recovery_proof.py'):
 files['source/'+relative]=sdk.snapshot(root/relative,maximum=64*1024**2).data
archive=public/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  out.writestr(info,data)
digests={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
with zipfile.ZipFile(archive) as zipped:
 sdk.require(len(zipped.namelist())==len(digests) and set(zipped.namelist())==set(digests),'archive inventory changed')
 for name,digest in digests.items():sdk.require(hashlib.sha256(zipped.read(name)).hexdigest()==digest,'archive readback changed')
sdk.write_json(public/'CAPTURE.json',{'capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,'members':digests,'proofs':verified,'locale_fix_source':checkpoint['head'],'source_gate':True,'related_regression_tests':190,'local_utf8_replay':locale,'hosted_linux_utf8_fix_not_yet_run':True,'release_claim_eligible':False})
sdk.write_json(public/'READBACK.json',{'completed':True,'capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,'members':len(digests),'all_members_rehashed':True,'symbolic_witness_and_provenance_replayed':True,'private_sdk_data_selected':False,'local_utf8_replay_passed':True,'linux_utf8_replay_pending':True,'release_claim_eligible':False})
model=root/'research/continuity-recovery-symbolic/shared-identity.spthy'
with model.open('xb') as out:out.write((stage/'shared-identity-01.spthy').read_bytes())
print(json.dumps({'members':len(files),'archive_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,'model_sha256':sdk.snapshot(model).sha256}))
