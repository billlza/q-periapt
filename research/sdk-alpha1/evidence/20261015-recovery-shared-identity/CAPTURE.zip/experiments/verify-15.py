from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
witness='other_session_identity_leak_breaks_session_scoped_recovery'; provenance='shared_identity_key_origin'
checks={}
for initial,replay,name in [('identity-witness-03','identity-witness-replay-06',witness),('identity-provenance-04','identity-provenance-replay-07',provenance)]:
 a=json.loads((stage/(initial+'-TERMINAL.json')).read_text());b=json.loads((stage/(replay+'-TERMINAL.json')).read_text())
 sdk.require(a['accepted'] and b['accepted'] and not any(x.startswith('--prove') for x in b['argv']),'missing independent proof')
 sdk.require(a['output_sha256']==b['input_sha256']==sdk.snapshot(stage/(initial+'-proof.spthy')).sha256,'certificate changed')
 sdk.require(b['output_sha256']==sdk.snapshot(stage/(replay+'-proof.spthy')).sha256,'checked output changed')
 checks[name]={'search_steps':a['results'][name]['steps'],'replay_steps':b['results'][name]['steps'],'replay_seconds':b['elapsed_seconds'],'certificate_sha256':b['output_sha256']}
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
paths={'canonical':root/'research/continuity-recovery-symbolic/protected-state.spthy','input':stage/'shared-identity-01.spthy','witness':stage/'identity-witness-replay-06-proof.spthy','provenance':stage/'identity-provenance-replay-07-proof.spthy'}
parsed={name:sdk.command([t['tamarin'],'--with-maude='+t['maude'],str(path),'--parse-only'],stage/(name+'-parse-15'),root).decode() for name,path in paths.items()}
decl=re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
queries={label:{m.group(1):m.group() for m in decl.finditer(text)} for label,text in parsed.items()}
sdk.require(queries['input']==queries['witness']==queries['provenance'],'complete declarations changed')
sdk.require(all(queries['input'][n]==q for n,q in queries['canonical'].items()),'original five queries changed')
def prefix(text):
    text = text.split('\nlemma ', 1)[0]
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    signature = re.search(r'(?s)functions:\s*(.*?)\nequations:', text)
    sdk.require(signature is not None, 'expanded function signature missing')
    functions = dict((name, int(arity)) for name, arity in re.findall(r'(\w+)/(\d+)', signature.group(1)))
    info = re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$', text)
    for name, args, result in info:
        types = [arg.strip() for arg in args.split(',') if arg.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {'Any'} and result == 'Any', 'informational function declaration differs')
    sdk.require({name for name, _, _ in info} in ({'kempk', 'kemct', 'decap'}, set(functions)), 'unexpected informational inventory')
    builtins = re.findall(r'(?m)^builtin\s+(\S+)\s*$', text)
    sdk.require(set(builtins) in (set(), {'hashing', 'signing', 'symmetric-encryption'}), 'unexpected builtin summary')
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$', '', text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$', '', text)
    return re.sub(r'\s+', '', text)

sdk.require(prefix(parsed['input'])==prefix(parsed['witness'])==prefix(parsed['provenance']),'certificate model changed')
graphs=json.loads((stage/'identity-witness-replay-06-traces.json').read_text())['graphs'];sdk.require(len(graphs)==1,'unexpected witness graphs')
g=graphs[0]; acts=[(n,a) for n in g['jgNodes'] for a in n.get('jgnMetadata',{}).get('jgnActs',[])]
def tree(t):
 if 'jgnConst' in t:return ('constant',t['jgnConst'])
 sdk.require('jgnFunct' in t and 'jgnParams' in t,'malformed term')
 return (t['jgnFunct'],tuple(tree(p) for p in t['jgnParams']))
def one(name,node=None):
 rows=[(n,a) for n,a in acts if a['jgnFactName']==name and (node is None or n['jgnId']==node)]
 sdk.require(len(rows)==1,'unexpected '+name+' events')
 n,a=rows[0];return n,tuple(map(tree,a['jgnFactTerms']))
_,target=one('SessionOwner','#target');_,sibling=one('SessionOwner','#sibling')
leaknode,leak=one('IdentityLeak');_,message=one('Message');_,knowledge=one('K','#known')
sdk.require(target[0]!=sibling[0] and target[1]==sibling[1],'sessions do not share exactly the selected owner')
sdk.require(leak==(sibling[0],('constant',"'B'")) and leaknode['jgnLabel']=='Reveal_Identity','wrong leak source')
sdk.require(message[0]==target[0] and message[1]==('constant',"'A'") and message[-1]==knowledge[0],'known plaintext differs')
for name in ('Cut','KeyReserved','EncapReserved'):sdk.require(one(name)[1]==(target[0],),'reservation or cut not in target')
sdk.require(not any(a['jgnFactName'] in ('Snapshot','EntropyLeak') for n,a in acts),'additional leak')
edges={}
for edge in g['jgEdges']:
 a=edge['jgeSource'].split(':',1)[0];b=edge['jgeTarget'].split(':',1)[0]
 edges.setdefault(a,set()).add(b)
def precedes(a,b):
 pending=list(edges.get(a,()));seen=set()
 while pending:
  n=pending.pop()
  if n==b:return True
  if n not in seen:seen.add(n);pending.extend(edges.get(n,()))
 return False
for a,b in (('#c','#g'),('#c','#e'),('#leak','#m'),('#m','#known')):sdk.require(precedes(a,b),'missing causal relation '+a+' < '+b)
sdk.write_json(stage/'VERIFIED_15.json',{'completed':True,'proofs':checks,'witness':{'distinct_sessions_same_identity_owner':True,'exactly_one_sibling_responder_identity_leak':True,'target_generation_and_encapsulation_reserved_after_cut':True,'no_snapshot_or_entropy_disclosure':True,'same_message_payload_known_to_attacker':True,'causal_edges_checked':True},'all_original_queries_unchanged':True,'certificate_operational_prefixes_equal':True,'no_reusable_helpers_or_additional_restrictions':True,'protected_state_model_unchanged':True,'shared_identity_recovery_secrecy_not_proved':True,'actual_sdk_decryption_not_claimed':True,'release_claim_eligible':False})
print(json.dumps({'witness_replay_steps':checks[witness]['replay_steps'],'provenance_replay_steps':checks[provenance]['replay_steps'],'trace_checked':True}))
