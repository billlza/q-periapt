from pathlib import Path
import json,os,re,signal,subprocess,sys,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
filename,label,mode,lemma=sys.argv[1:]
sdk.require(re.fullmatch(r'[a-z0-9-]+\.spthy',filename) and re.fullmatch(r'[a-z0-9-]+',label),'invalid identity')
sdk.require(mode in ('search','replay') and re.fullmatch(r'[a-z_]+',lemma),'invalid mode/query')
source=stage/filename; content=source.read_text(); inventory=re.findall(r'(?m)^lemma\s+(\w+)',content)
sdk.require(lemma in inventory and len(set(inventory))==len(inventory),'query inventory differs')
sdk.require(not re.search(r'(?m)^lemma[^\n]*\[(?:[^\]]*\b(?:reuse|sources)\b)',content),'unexpected reusable premise')
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
output=stage/(label+'-proof.spthy')
argv=[tools['tamarin'],'--with-maude='+tools['maude'],str(source),'--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(output),'--output-json='+str(stage/(label+'-traces.json'))]
if mode=='search':argv+=['--prove='+lemma]
argv+=['+RTS','-N2','-M4G','-s','-RTS']
sdk.require(not output.exists(),'existing proof output')
start=time.monotonic(); timed_out=False; exceeded=False
with (stage/(label+'.stdout')).open('xb') as out,(stage/(label+'.stderr')).open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/(label+'-STARTED.json'),{'pid':p.pid,'argv':argv,'maximum_seconds':300,'input_sha256':sdk.snapshot(source).sha256})
 while p.poll() is None:
  timed_out=time.monotonic()-start>=300;exceeded=max(out.tell(),err.tell())>32*1024**2
  if timed_out or exceeded:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   break
  time.sleep(.2)
 code=p.wait(timeout=5)
summary=(stage/(label+'.stdout')).read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'mode':m,'status':s,'steps':int(k)} for n,m,s,k in parsed}
accepted=code==0 and not timed_out and not exceeded and len(parsed)==len(inventory) and set(results)==set(inventory) and results[lemma]['status']=='verified' and output.is_file()
receipt={'argv':argv,'returncode':code,'timed_out':timed_out,'output_exceeded':exceeded,'elapsed_seconds':time.monotonic()-start,'results':results,'selected':lemma,'accepted':accepted,'input_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256 if output.is_file() else None,'release_claim_eligible':False}
sdk.write_json(stage/(label+'-TERMINAL.json'),receipt)
print(json.dumps(receipt),flush=True)
