from pathlib import Path
import json,subprocess,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;base='74cbb2c00e2e953beb843d0db1f257714eac0756'
allowed={'artifact/continuity_recovery_proof.py','artifact/test_continuity_recovery_proof.py','research/continuity-recovery-symbolic/README.md'}
def git(*args,cwd=root):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
sdk.require(git('rev-parse','HEAD')==base and git('branch','--show-current')=='lza/continuity-policy-roster','head/branch changed')
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True)
sdk.require({x[3:] for x in status.splitlines()}==allowed and not git('diff','--cached','--name-only'),'unrelated changes')
sdk.command(['git','diff','--check'],stage/'diff-18',root)
sdk.command(['git','add','--',*sorted(allowed)],stage/'stage-18',root)
sdk.command(['git','commit','-m','Use UTF-8 for recovery proof subprocesses'],stage/'commit-18',root)
head=git('rev-parse','HEAD');clone=root/'target/continuity-browser-publication/source'
sdk.require(git('rev-parse','HEAD',cwd=clone)==base and not git('status','--porcelain',cwd=clone),'clone changed')
sdk.command(['git','fetch',str(root),head],stage/'fetch-18',clone)
sdk.command(['git','merge','--ff-only',head],stage/'merge-18',clone)
sdk.command([sys.executable,'-B',str(clone/'artifact/python_bootstrap.py'),'-m','unittest','-v','artifact.test_continuity_recovery_proof','artifact.test_formal_toolchain_contract','artifact.test_formal_tool_asset','artifact.test_bounded_process','artifact.test_proof_to_byte_release'],stage/'tests-18',clone)
sdk.command([sys.executable,'-B',str(clone/'artifact/python_bootstrap.py'),str(clone/'artifact/source_results_assembler.py'),'ci-source-gate','9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],stage/'source-gate-18',clone)
sdk.require(not git('status','--porcelain') and not git('status','--porcelain',cwd=clone),'dirty source')
sdk.write_json(stage/'CHECKPOINT_18.json',{'head':head,'base':base,'source_gate':True,'clean_clone_regressions':True,'pushed':False,'linux_replay_still_required':True,'release_claim_eligible':False})
print(json.dumps({'head':head,'source_gate':True,'regressions':True,'pushed':False}))
