from pathlib import Path
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
old=(stage/'verify-09.py').read_text()
prior=(root/'target/continuity-recovery-root-isolation-20261015/semantics-25.py').read_text()
normalizer=prior[prior.index('def prefix(text):'):prior.index('\nexpected_observers')]
needle="prefix=lambda text:text.split('\\nlemma ',1)[0]"
sdk.require(old.count(needle)==1,'prefix selector differs')
updated=old.replace(needle,normalizer).replace('-parse-09','-parse-15').replace('VERIFIED_09.json','VERIFIED_15.json')
with (stage/'verify-15.py').open('x') as out:out.write(updated)
sdk.write_json(stage/'VERIFIER_CORRECTION_15.json',{'failure':'verify-09 rejected equal expanded signatures because source builtin metadata becomes individual function metadata in exported certificates','correction':'reuse the prior validated metadata normalization; compare complete expanded signatures, equations, rules and restrictions unchanged','old_attempt_retained':True,'proof_inputs_unchanged':True})
