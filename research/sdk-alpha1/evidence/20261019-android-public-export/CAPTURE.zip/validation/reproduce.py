"""Exercise actual old public manifest and exact workflow upload patterns."""
from pathlib import Path
import json,sys,tempfile
root=Path.cwd();sys.path.insert(0,str(root/'artifact'))
import continuity_android_local_credential as local
import continuity_android_jni as android
import rust_sdk_profile as sdk
from test_continuity_android_local_credential import fixture
out=Path(__file__).resolve().parent
records={}
with tempfile.TemporaryDirectory(prefix='android-public-export-')as temp:
 base=Path(temp);source=base/'source';source.mkdir();stdout=fixture(source)
 # Additional retained opaque grant fields are not interpreted by this reader.
 for trust in ['fixed','recoverable']:
  for name,value in [('inputs/local-first-version',(2).to_bytes(8,'big')),('inputs/local-first-digest',b'k'*32),('inputs/local-first-grant',b'synthetic first grant'),('inputs/local-second-grant',b'synthetic second grant')]:
   (source/trust/name).write_bytes(value)
 selected=tuple(local.PUBLIC)+tuple(name+'.'+suffix for name,_ in android.CASES for suffix in ['stdout','stderr'])
 exported=base/'export';replay=base/'replay'
 for trust in ['fixed','recoverable']:
  for name in selected:
   public=exported/f'android-jni-debug-{trust}-{name}.public';sdk.copy(source/trust/name,public);sdk.copy(public,replay/trust/name)
 try:local.verify_execution(stdout,replay)
 except (ValueError,OSError)as error:records['manifest_replay']={'passed':False,'error':str(error)}
 else:records['manifest_replay']={'passed':True}
 text=(root/'.github/workflows/ci.yml').read_text();part=text.split('name: continuity-installed-${{ matrix.consumer }}-${{ matrix.profile }}',1)[1].split('          path: |',1)[1].split('\n\n',1)[0]
 prefix='target/continuity-installed-swift/'
 patterns=[line.strip()[len(prefix):]for line in part.splitlines()if line.strip().startswith(prefix+'android-jni-')]
 published={p.relative_to(exported).as_posix()for pattern in patterns for p in exported.glob(pattern)if p.is_file()}
 all_files={p.relative_to(exported).as_posix()for p in exported.rglob('*')if p.is_file()}
 records['upload_inventory']={'passed':published==all_files,'missing':sorted(all_files-published),'patterns':patterns}
(out/'RED.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'manifest_pass':records['manifest_replay']['passed'],'upload_pass':records['upload_inventory']['passed'],'missing':len(records['upload_inventory']['missing'])}))
assert all(row['passed']for row in records.values())
