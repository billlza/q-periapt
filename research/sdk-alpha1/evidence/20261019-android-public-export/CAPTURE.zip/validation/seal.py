from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;foreign=root/'target/foreign-installed-2328-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head=='f7a79e80b0e76f797072d76b3b659768d7628ef8'
import sys
sys.path.insert(0,str(root/'artifact'))
import continuity_android_local_credential as local
rows=[];entries={}
for profile in ['debug','release']:
 folder=foreign/('android-'+profile);a=json.loads((folder/'ARTIFACT.json').read_text());path=folder/'terminal.zip'
 assert 'sha256:'+sha(path.read_bytes())==a['digest']
 with zipfile.ZipFile(path)as z:
  inventory={i.filename:{'bytes':i.file_size,'crc32':i.CRC}for i in z.infolist()}
  expected={f'android-jni-{profile}-{trust}-{n}.public'for trust in ['fixed','recoverable']for n in local.PUBLIC}
  missing=sorted(expected-set(inventory));assert len(missing)==50
  rows.append({'profile':profile,'artifact_id':a['id'],'artifact_bytes':a['size_in_bytes'],'artifact_digest':a['digest'],'expected_local_public_files':len(expected),'missing':missing})
  entries[profile+'/INVENTORY.json']=(json.dumps(inventory,indent=2)+'\n').encode()
 for name in ['ARTIFACT.json','JOB.json','CONTINUITY_PACKAGE.json','sources-before.json','sources-after.json']:
  entries[profile+'/'+name]=(folder/name).read_bytes()
(out/'MISSING_PUBLIC.json').write_text(json.dumps(rows,indent=2)+'\n')
for p in out.iterdir():
 if p.is_file():entries['validation/'+p.name]=p.read_bytes()
for name in ['review-android.py','review-android.stdout','review-android.stderr','verify-sources.py','verify-sources-android-debug.stdout','verify-sources-android-debug.stderr','download-attempt-01.py.txt','download-attempt-01.stderr.txt','DOWNLOAD_REPAIR.json']:
 entries['terminal-readback/'+name]=(foreign/name).read_bytes()
files=['.github/workflows/ci.yml','artifact/continuity_android_jni.py','artifact/continuity_android_local_credential.py','artifact/test_continuity_android_local_credential.py']
for name in files:entries['source/'+name]=(root/name).read_bytes()
entries['CHANGE.patch']=subprocess.check_output(['git','diff','--',*files])
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
folder=root/'research/sdk-alpha1/evidence/20261019-android-public-export';folder.mkdir()
archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(entries.items()):
  i=zipfile.ZipInfo(n,(2026,10,19,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for n,item in manifest.items():assert sha(z.read(n))==item['sha256']and len(z.read(n))==item['bytes']
checks={'base_head':head,'source_files':{n:sha((root/n).read_bytes())for n in files},'terminal_archives':rows,'quality':json.loads((out/'QUALITY.json').read_text()),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':'Corrected public evidence export and workflow selection; runtime/ABI unchanged.102 synthetic helper tests and exact pre/post manifest/upload reproduction. Old successful host JNI runs retain their original missing-public-data boundary; no new hosted runtime result claimed. Raw68.9MB/69.0MB terminal archives remain locally retained and addressable by artifact IDs/digests; capture holds their inventories/receipts, not the full archives.'}
(folder/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks['capture']))
