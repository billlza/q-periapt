from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys,signal
base=Path(__file__).resolve().parent
main=base.parent.parent
sys.path.insert(0,str(main/"artifact"))
import continuity_swift_consumer as swift_contract
meta=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text())
root=Path(meta["outside"])
profile=sys.argv[1];assert profile in ("debug","release")
consumer=root/("swift-authority-"+profile)
consumer.mkdir(mode=0o700, exist_ok=True)
for path in (main/"bindings/swift/ContinuityPackageConsumer").rglob("*"):
 if path.is_file():
  assert not path.is_symlink()
  target=consumer/path.relative_to(main/"bindings/swift/ContinuityPackageConsumer")
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
include=consumer/"native/include";include.mkdir(parents=True, exist_ok=True)
shutil.copyfile(main/"bindings/c/ContinuityPackageConsumer/qpc_owner.h",include/"qpc_owner.h")
lib=consumer/"native/lib";lib.mkdir(exist_ok=True)
shutil.copyfile(root/("enrollment-current-installed-"+profile)/swift_contract.LIBRARY,lib/swift_contract.LIBRARY)
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file() and not any(part in (".build", ".swiftpm") for part in p.relative_to(consumer).parts)}
output=base/("unit-"+profile+("-"+sys.argv[2] if len(sys.argv)>2 else ""));output.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(("DYLD","LD_","QPERIAPT","QPC","SWIFT","CARGO","RUST","PYTHON"))}
env.update(DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer",PATH="/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin")
swift,compiler=swift_contract.compiler_command(subprocess.check_output(["/usr/bin/xcrun","--find","swift"],env=env).decode())
args=[str(swift),"test","--package-path",str(consumer),"--configuration",profile,"-j","2","-Xswiftc","-warnings-as-errors","-Xcc","-I"+str(include),"-Xlinker","-L"+str(lib),"-Xlinker","-rpath","-Xlinker",str(lib)]
r=dict(consumer=str(consumer),profile=profile,command=args,compiler=compiler,scope="Swift registry component against the immutable installed native archive; not complete installed Swift qualification",native_archive=meta["candidate_archive"],source_sha256=files,completed=False)
(output/"START.json").write_text(json.dumps(r,indent=2)+"\n")
start=time.monotonic()
with (output/"stdout").open("wb") as so,(output/"stderr").open("wb") as se:
 p=subprocess.Popen(args,cwd=consumer,env=env,stdout=so,stderr=se,start_new_session=True)
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);raise
r.update(returncode=code,seconds=time.monotonic()-start,inputs_unchanged=all(hashlib.sha256((consumer/name).read_bytes()).hexdigest()==value for name,value in files.items()))
(output/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
if code:
 print((output/"stderr").read_text()[-6500:]);raise SystemExit(code)
swift_contract.verify_tests((output/"stdout").read_bytes(),(output/"stderr").read_bytes())
r["completed"]=r["inputs_unchanged"]
(output/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps(dict(completed=r["completed"],seconds=r["seconds"],profile=profile,consumer=str(consumer))))
