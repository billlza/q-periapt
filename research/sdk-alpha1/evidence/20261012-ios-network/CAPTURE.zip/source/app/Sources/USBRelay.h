#include <stdint.h>
/* Qualification transport only: copies opaque end-to-end TLS bytes over USB. */
int qpc_test_relay_prepare(int descriptors[2], uint16_t ports[2]);
int qpc_test_relay_run(int transport_listener, int local_listener);
