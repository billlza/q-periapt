import Foundation
import Darwin

func usbOperation(arguments: [String], source: URL, mode: String, run: String) async throws {
    var descriptors: [Int32] = [-1, -1]
    var ports: [UInt16] = [0, 0]
    let code = qpc_test_relay_prepare(&descriptors, &ports)
    guard code == 0 else { throw ClientError("USB relay preparation errno=\(code)") }
    let transport = descriptors[0], local = descriptors[1]
    let bridge = Task.detached { qpc_test_relay_run(transport, local) }
    let operation = Result {
        try Data("127.0.0.1:\(ports[1])".utf8).write(to: source.appendingPathComponent("connection-address"), options: .atomic)
        try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_RELAY_READY run=\(run) port=\(ports[0])\n".utf8))
        try ConfigurationCommands.run(arguments)
    }
    let status = await bridge.value
    print("QPC_IOS_RELAY_EXIT status=\(status)")
    // An intentional remote process exit may reset the transport. The host fixture
    // must separately observe exit 77, retained effect and exact-message recovery.
    guard status == 0 || (mode == "uncertain-send" && [ECONNRESET, EPIPE].contains(status)) else {
        throw ClientError("USB relay errno=\(status); SDK outcome=\(operation)")
    }
    try operation.get()
}
