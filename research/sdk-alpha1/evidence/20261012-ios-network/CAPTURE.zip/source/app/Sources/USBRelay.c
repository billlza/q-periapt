#include "USBRelay.h"
#include <arpa/inet.h>
#include <errno.h>
#include <poll.h>
#include <stdbool.h>
#include <stddef.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int failure(void) { return errno == 0 ? EIO : errno; }
static int close_owned(int fd, int result) {
    if (fd >= 0 && close(fd) != 0 && result == 0) return failure();
    return result;
}
static int listener(uint16_t *port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in address = {0};
    address.sin_len = sizeof(address);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    socklen_t size = sizeof(address);
    if (bind(fd, (struct sockaddr *)&address, size) != 0 || listen(fd, 1) != 0 ||
        getsockname(fd, (struct sockaddr *)&address, &size) != 0) {
        int saved = failure();
        (void)close_owned(fd, saved);
        errno = saved;
        return -1;
    }
    *port = ntohs(address.sin_port);
    return fd;
}
int qpc_test_relay_prepare(int descriptors[2], uint16_t ports[2]) {
    descriptors[0] = listener(&ports[0]);
    if (descriptors[0] < 0) return failure();
    descriptors[1] = listener(&ports[1]);
    if (descriptors[1] < 0) {
        int result = close_owned(descriptors[0], failure());
        descriptors[0] = -1;
        return result;
    }
    return 0;
}
static int accept_bounded(int listener_fd) {
    struct pollfd descriptor = {.fd = listener_fd, .events = POLLIN};
    int ready = poll(&descriptor, 1, 30000);
    if (ready <= 0) { if (ready == 0) errno = ETIMEDOUT; return -1; }
    int fd = accept(listener_fd, NULL, NULL);
    if (fd < 0) return -1;
    int one = 1;
    struct timeval timeout = {.tv_sec = 5, .tv_usec = 0};
    if (setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) != 0) {
        int saved = failure(); (void)close_owned(fd, saved); errno = saved; return -1;
    }
    return fd;
}
static int send_all(int fd, const unsigned char *bytes, size_t length) {
    size_t used = 0;
    while (used < length) {
        ssize_t n = send(fd, bytes + used, length - used, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return failure();
        used += (size_t)n;
    }
    return 0;
}
static int transfer(int first, int second) {
    int sockets[2] = {first, second};
    bool ended[2] = {false, false};
    unsigned char bytes[16384];
    struct timespec start, now;
    if (clock_gettime(CLOCK_MONOTONIC, &start) != 0) return failure();
    while (!ended[0] || !ended[1]) {
        if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return failure();
        if (now.tv_sec - start.tv_sec >= 30) return ETIMEDOUT;
        struct pollfd descriptors[2] = {
            {.fd = ended[0] ? -1 : sockets[0], .events = POLLIN},
            {.fd = ended[1] ? -1 : sockets[1], .events = POLLIN}
        };
        int ready = poll(descriptors, 2, 1000);
        if (ready < 0 && errno == EINTR) continue;
        if (ready < 0) return failure();
        for (size_t i = 0; i < 2; i++) {
            if (ended[i] || descriptors[i].revents == 0) continue;
            if (descriptors[i].revents & POLLNVAL) return EBADF;
            ssize_t n = recv(sockets[i], bytes, sizeof(bytes), 0);
            if (n < 0 && errno == EINTR) continue;
            if (n < 0) return failure();
            if (n == 0) {
                ended[i] = true;
                if (shutdown(sockets[1-i], SHUT_WR) != 0 && errno != ENOTCONN) return failure();
            } else {
                int result = send_all(sockets[1-i], bytes, (size_t)n);
                if (result != 0) return result;
            }
        }
    }
    return 0;
}
int qpc_test_relay_run(int transport_listener, int local_listener) {
    int transport = accept_bounded(transport_listener);
    int result = transport < 0 ? failure() : 0;
    int local = result == 0 ? accept_bounded(local_listener) : -1;
    if (result == 0 && local < 0) result = failure();
    result = close_owned(transport_listener, result);
    result = close_owned(local_listener, result);
    if (result == 0) result = transfer(transport, local);
    result = close_owned(transport, result);
    return close_owned(local, result);
}
