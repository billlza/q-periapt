"""Replay the unique observed chain goal at each captured open leaf."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-payload-wire-frontiers-711'
terminal = json.loads((parent / 'payload-wire-frontiers-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
assert not (parent / 'initial-send-oracle.failed').exists()
source = parent / 'payload-wire-frontiers-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
assert 'invalid proof step' not in value
frames = sorted((parent / 'initial-send-oracle-frames').glob('*.json'))
assert 0 < len(frames) <= 32 and len(frames) == main.count('by sorry')
methods, records = [], []
for frame in frames:
    row = json.loads(frame.read_text())
    data = (frame.parent / row['captured_input']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['input_sha256']
    matches = re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$', data.decode())
    assert len(matches) == 1, (frame.name, matches)
    methods.append(matches[0])
    records.append({'frame': row['captured_input'], 'sha256': row['input_sha256'], 'unique_chain': matches[0]})
iterator = iter(methods)
main, count = re.subn(r'by sorry(?: /\* Oracle ranked no proof methods \*/)?',
                      lambda _: 'by solve( ' + next(iterator) + ' )', main)
assert count == len(methods) and next(iterator, None) is None
candidate = value[:start] + main + value[stop:]
candidate = candidate.replace('by sorry /* Oracle ranked no proof methods */', 'by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', candidate) == re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage = root / 'target/p0-origin-payload-wire-chain-replay-711'
stage.mkdir()
(stage / 'model.spthy').write_text(candidate)
shutil.copy2(root / 'target/p0-wire-scope-replay-704/run.py', stage / 'run.py')
record = {'parent_sha256': terminal['output_sha256'], 'input_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'all29_queries_and_operational_prefix_unchanged': True,
    'observed_methods_in_oracle_callback_order': records,
    'mapping': 'N1 capture callback order matched to generated main-proof open-leaf order; each method must be checked by the independent replay.',
    'independent_replay_has_no_search_or_oracle': True, 'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'stage': str(stage), 'methods': len(methods), 'input_sha256': record['input_sha256']}))
