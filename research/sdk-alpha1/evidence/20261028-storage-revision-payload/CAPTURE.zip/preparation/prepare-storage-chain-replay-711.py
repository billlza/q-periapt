"""Use the recorded knowledge-chain method in each remaining Stored producer."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-storage-frontiers-711'
terminal = json.loads((parent / 'storage-frontiers-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['output_exceeded']
assert not terminal['accepted'] and not (parent / 'initial-send-oracle.failed').exists()
source = parent / 'storage-frontiers-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
assert 'INVALID' not in value
stage = root / 'target/p0-origin-storage-chain-replay-711'
stage.mkdir()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
pattern = re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks = {match[1]: match[0] for match in pattern.finditer(main)}
assert len(blocks) == 18
assert set(name for name, block in blocks.items() if 'by sorry' in block) == {
    'Final_Commit_8', 'Offer_Commit_3_case_1', 'Receipt_Commit_0',
    'Response_Commit_6', 'Snapshot_case_4', 'Snapshot_case_5'}
folder = parent / 'initial-send-oracle-frames'
assert len(list(folder.glob('*.json'))) == 26
records = []
method = '(#vr.7, 0) ~~> (#known, 0)'
for index in range(4, 26):
    metadata = json.loads((folder / f'{index:04}.json').read_text())
    raw = (folder / metadata['captured_input']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == metadata['input_sha256']
    assert raw.decode().splitlines()[0] == '0: ' + method
    records.append({'frame': metadata['captured_input'], 'sha256': metadata['input_sha256'], 'method': method})
for name in ('Snapshot_case_4', 'Snapshot_case_5'):
    block = blocks[name]
    assert block.count('by sorry') == 11
    updated, count = re.subn(r'by sorry(?: /\* Oracle ranked no proof methods \*/)?', 'by solve( ' + method + ' )', block)
    assert count == 11
    main = main.replace(block, updated, 1)
candidate = value[:start] + main + value[stop:]
candidate = candidate.replace('by sorry /* Oracle ranked no proof methods */', 'by sorry')
def declarations(text):
    return re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', text)
assert len(declarations(candidate)) == 29 and declarations(candidate) == declarations(value)
prefix = candidate[:candidate.index('lemma ')]
assert hashlib.sha256(prefix.encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
(stage / 'model.spthy').write_text(candidate)
shutil.copy2(root / 'target/p0-wire-scope-replay-704/run.py', stage / 'run.py')
record = {'parent_sha256': terminal['output_sha256'], 'model_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
          'observed_methods': records, 'only_changed_source_cases': ['Snapshot_case_4', 'Snapshot_case_5'],
          'all29_queries_and_operational_prefix_unchanged': True,
          'proof_mode': 'Independent no-search replay of exact observed chain methods; no oracle',
          'hypothesis_to_check': 'Revision freshness closes the revision source; plaintext subcomponents require further analysis.',
          'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'stage': str(stage), 'methods': len(records), 'model_sha256': record['model_sha256']}))
