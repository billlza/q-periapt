"""Restore only two previously observed source subtrees; keep every query."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
stage = root / 'target/p0-origin-storage-frontiers-711'
stage.mkdir()
current = root / 'target/p0-origin-storage-role-direct-708/storage-role-direct-proof.spthy'
parent = root / 'target/p0-origin-storage-fields-707/storage-fields-replay-proof.spthy'
assert hashlib.sha256(current.read_bytes()).hexdigest() == '6abc57adbf5518606053af6cfc81f12e59e98d9f9ec868cd1e1a2f3d82f42340'
assert hashlib.sha256(parent.read_bytes()).hexdigest() == '4736abef8fc97eed60f45dd532e82c15a83118021b50eb57ee2a0da40ac53188'
text, prior = current.read_text(), parent.read_text()
def main_span(value):
    start = value.index('lemma epoch_generation_secret_derivation_origin ')
    stop = value.index('\nlemma ', start)
    return start, stop, value[start:stop]
start, stop, main = main_span(text)
_, _, prior_main = main_span(prior)
pattern = re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
original = {match[1]: match[0] for match in pattern.finditer(main)}
previous = {match[1]: match[0] for match in pattern.finditer(prior_main)}
assert len(original) == len(previous) == 18
assert sum('by sorry' in block for block in original.values()) == 6
for name in ('Snapshot_case_4', 'Snapshot_case_5'):
    assert original[name].count('by sorry') == 1
    assert previous[name].count('by sorry') == 11
    main = main.replace(original[name], previous[name], 1)
candidate = text[:start] + main + text[stop:]
def declarations(value):
    return re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', value)
assert len(declarations(text)) == 29
assert declarations(candidate) == declarations(text)
prefix = candidate[:candidate.index('lemma ')]
assert hashlib.sha256(prefix.encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
new_blocks = {match[1]: match[0] for match in pattern.finditer(main)}
assert set(new_blocks) == set(original)
assert main.count('by sorry') == 26
for name, block in original.items():
    assert new_blocks[name] == (previous[name] if name in ('Snapshot_case_4', 'Snapshot_case_5') else block)
(stage / 'model.spthy').write_text(candidate)
base = root / 'target/p0-origin-source-frontiers-705'
for name in ('run.py', 'initial-send-oracle.py', 'initial-send-oracle.sh'):
    shutil.copy2(base / name, stage / name)
shell = stage / 'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(base), str(stage)))
(stage / 'initial-send-oracle-frames').mkdir()
record = {'current': str(current), 'parent': str(parent),
          'model_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
          'operational_prefix_sha256': hashlib.sha256(prefix.encode()).hexdigest(),
          'all29_queries_unchanged': True, 'all18_root_cases_retained': True,
          'only_changes': ['Snapshot_case_4', 'Snapshot_case_5'],
          'unchanged_closed_root_cases': 12, 'initial_open_leaves': 26,
          'existing_search_prefix': 3, 'remaining_search_bound': 13,
          'oracle_capture_limit': 32, 'capture_selects_no_search_step': True,
          'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
