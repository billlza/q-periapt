"""Capture payload projections and observed wire-shape splits at fixed depth."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path.cwd()
parent = root / 'target/p0-origin-storage-chain-replay-711'
terminal = json.loads((parent / 'storage-chain-TERMINAL.json').read_text())
assert terminal['returncode'] == 0 and not terminal['timed_out'] and not terminal['accepted']
source = parent / 'storage-chain-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest() == terminal['output_sha256']
value = source.read_text()
start = value.index('lemma epoch_generation_secret_derivation_origin ')
stop = value.index('\nlemma ', start)
main = value[start:stop]
pattern = re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks = {match[1]: match[0] for match in pattern.finditer(main)}
assert len(blocks) == 18 and sum('by sorry' not in b for b in blocks.values()) == 13
stage = root / 'target/p0-origin-payload-wire-frontiers-711'
stage.mkdir()
frames = root / 'target/p0-origin-storage-frontiers-711/initial-send-oracle-frames'
mapping = ['Final_Commit_8', 'Offer_Commit_3_case_1', 'Receipt_Commit_0', 'Response_Commit_6']
records = []
for index, name in enumerate(mapping):
    metadata = json.loads((frames / f'{index:04}.json').read_text())
    data = (frames / metadata['captured_input']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == metadata['input_sha256']
    method = data.decode().splitlines()[0].removeprefix('0: ').strip()
    assert method.startswith('(∃ ') and "h(material)" in method and ' ∥ ' in method
    assert blocks[name] == f'    case {name}\n    by sorry\n'
    main = main.replace(blocks[name], f'    case {name}\n    by solve( {method} )\n', 1)
    records.append({'source_case': name, 'frame': metadata['captured_input'], 'sha256': metadata['input_sha256'], 'method': method})
candidate = value[:start] + main + value[stop:]
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', candidate) == re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)', value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest() == '3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
(stage / 'model.spthy').write_text(candidate)
base = root / 'target/p0-origin-source-frontiers-705'
for name in ('run.py', 'initial-send-oracle.py', 'initial-send-oracle.sh'):
    shutil.copy2(base / name, stage / name)
driver = stage / 'run.py'
assert driver.read_text().count('--bound=13') == 1
driver.write_text(driver.read_text().replace('--bound=13', '--bound=12'))
shell = stage / 'initial-send-oracle.sh'
shell.write_text(shell.read_text().replace(str(base), str(stage)))
(stage / 'initial-send-oracle-frames').mkdir()
record = {'parent_sha256': terminal['output_sha256'], 'input_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'wire_methods': records, 'all29_queries_and_operational_prefix_unchanged': True,
    'all18_source_cases_retained': True, 'closed_sources_retained': 13,
    'open_payload_leaves': 22, 'wire_cases_at_most': 8,
    'existing_prefix_maximum': 4, 'remaining_search_bound': 12, 'total_search_depth_limit': 16,
    'oracle_capture_limit': 32, 'capture_selects_no_search_step': True, 'release_claim_eligible': False}
(stage / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'stage': str(stage), 'input_sha256': record['input_sha256'], 'prefix': 4, 'bound': 12}))
