"""Seal previously verified terminal reference artifacts at their exact source head."""
import hashlib,io,json,subprocess,tarfile,zipfile
from pathlib import Path
out=Path(__file__).resolve().parent;repo=out.parents[1]
head='ad3568427a0f22739b940bb17015c6d254acddce';run=39216522760
reports=json.loads((out/'READBACK_ubuntu-24.04-macos-15.json').read_text())
assert len(reports)==2 and {r['platform'] for r in reports}=={'ubuntu-24.04','macos-15'}
entries={}
for name in ('COHORT.json','READBACK_ubuntu-24.04-macos-15.json','RUN_OBSERVED.json','readback.py','readback.stdout','readback.stderr','seal.py'):
 entries[name]=(out/name).read_bytes()
assert entries['readback.stderr']==b''
source_names=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app'],cwd=repo,text=True).splitlines())
for r in reports:
 assert r['head']==head and r['run']==run and r['members']==40
 folder=out/r['platform'];job=json.loads((folder/'JOB.json').read_text());meta=json.loads((folder/'ARTIFACT.json').read_text())
 assert job['status']=='completed' and job['conclusion']=='success' and job['head_sha']==head and job['run_id']==run
 data=(folder/'upstream.zip').read_bytes();assert len(data)==meta['size_in_bytes']==r['artifact_bytes']
 assert 'sha256:'+hashlib.sha256(data).hexdigest()==meta['digest']==r['artifact_sha256']
 for name in ('JOB.json','ARTIFACT.json','upstream.zip'):entries[r['platform']+'/'+name]=(folder/name).read_bytes()
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None and len(z.infolist())==40
  result=json.loads(z.read('exchange/RESULT.json'));assert result['source_commit']==head and result['completed'] is True
  assert len(result['source_inputs'])==67
  for path,digest in result['source_inputs'].items():
   body=subprocess.check_output(['git','show',head+':'+path],cwd=repo);assert hashlib.sha256(body).hexdigest()==digest;source_names.add(path)
for name in sorted(source_names):entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
entries['PUBLIC_MANIFEST.json']=(json.dumps({n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in entries.items()},indent=2)+'\n').encode()
destination=repo/'research/sdk-alpha1/evidence/20261019-hosted-registration-creation-recovery';destination.mkdir()
archive=destination/'capture.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
receipt={'source_commit':head,'run':run,'platforms':reports,'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'scope':'Previously terminal reference-account CI at ad356, including installed client initial-record recovery; distinct from later native policy publisher at85a18. Exact terminal metadata, artifact hashes, source closure, Rust26, Node17, installed adapter8/client16. No new CI execution and no full lifecycle or release claim.'}
(destination/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'capture':receipt['capture'],'source_commit':head,'platforms':[r['platform'] for r in reports]}))
