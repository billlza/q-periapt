
/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qperiapt-account-owner-tjvakd4h/managed-current-installed-debug/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000015a610 <__RINvMs_NtCshgaZoQMnI69_31q_periapt_continuity_c_consumer5ownerNtB5_10Activation6reopenNCNvMs0_B5_NtB5_5Owner4open0EB7_>:
  15a610: a9be6ffc     	stp	x28, x27, [sp, #-0x20]!
  15a614: a9017bfd     	stp	x29, x30, [sp, #0x10]
  15a618: 910043fd     	add	x29, sp, #0x10
  15a61c: d1402be9     	sub	x9, sp, #0xa, lsl #12   ; =0xa000
  15a620: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  15a624: f90003ff     	str	xzr, [sp]
  15a628: eb2963ff     	cmp	sp, x9
  15a62c: 54ffffa1     	b.ne	0x15a620 <__RINvMs_NtCshgaZoQMnI69_31q_periapt_continuity_c_consumer5ownerNtB5_10Activation6reopenNCNvMs0_B5_NtB5_5Owner4open0EB7_+0x10>
  15a630: d11b43ff     	sub	sp, sp, #0x6d0
  15a634: f90003ff     	str	xzr, [sp]
  15a638: 914027e9     	add	x9, sp, #0x9, lsl #12   ; =0x9000
  15a63c: 9115c129     	add	x9, x9, #0x570
  15a640: f90057e9     	str	x9, [sp, #0xa8]
  15a644: 914023e9     	add	x9, sp, #0x8, lsl #12   ; =0x8000
  15a648: 91339529     	add	x9, x9, #0xce5
  15a64c: f9005be9     	str	x9, [sp, #0xb0]
  15a650: 914013ea     	add	x10, sp, #0x4, lsl #12  ; =0x4000
  15a654: 9105c14a     	add	x10, x10, #0x170
  15a658: f9005fea     	str	x10, [sp, #0xb8]
  15a65c: f90063e8     	str	x8, [sp, #0xc0]
  15a660: f90067e0     	str	x0, [sp, #0xc8]
  15a664: f9006be1     	str	x1, [sp, #0xd0]
  15a668: aa0203e1     	mov	x1, x2
  15a66c: 3900053f     	strb	wzr, [x9, #0x1]
  15a670: 3900013f     	strb	wzr, [x9]
