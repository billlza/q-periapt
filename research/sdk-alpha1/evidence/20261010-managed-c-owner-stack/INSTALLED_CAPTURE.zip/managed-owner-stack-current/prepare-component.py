from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,sys,tempfile,time
out=Path(__file__).resolve().parent
main=out.parent.parent
source=main/"target/peer-account-retirement-process-current/source"
sys.path.insert(0,str(source/"artifact"))
import continuity_package as package
import continuity_c_consumer as consumer_contract
from rust_sdk_msrv import validate_report
sdk=package.sdk
pinned=json.loads((main/"target/installed-reopen-stack-current/SDK_VERIFIED.json").read_text())
report=sdk.snapshot(Path(pinned["report"]))
inputs=package.source_inputs()
cohort=validate_report(report.data,pinned["report_sha256"],report.sha256,inputs["rust_workspace_sha256"])
previous=json.loads((main/"target/foreign-account-owner-current/RESULT.json").read_text())
root=Path(previous["outside"])
assert not subprocess.check_output(["git","status","--porcelain"],cwd=source).strip()

assert not root.is_relative_to(source)
producer=root/"source-current"
consumer=root/"c-consumer-current"
tc=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin")
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON","JAVA","GRADLE","KOTLIN"))}
env.update(CARGO_HOME="/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e",CARGO_NET_OFFLINE="true",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(root/"build"),RUSTC=str(tc/"bin/rustc"),RUSTDOC=str(tc/"bin/rustdoc"),RUSTFLAGS="-D warnings",RUSTDOCFLAGS="-D warnings",PATH=str(tc/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_FALLBACK_LIBRARY_PATH=str(tc/"lib"))
record={"base_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip(),"source":str(source),"outside":str(root),"consumer":str(consumer),"sdk_report_sha256":report.sha256,"scope":"Development C ABI component against installed candidate and SDK archives; not complete C/Swift/Kotlin installed qualification.","source_inputs":inputs,"runs":[],"completed":False}
(out/"START.json").write_text(json.dumps(record,indent=2)+"\n")
def run(args,label,cwd):
    start=time.monotonic()
    with (out/(label+".stdout")).open("wb") as so,(out/(label+".stderr")).open("wb") as se:
        p=subprocess.Popen(args,cwd=cwd,env=env,stdout=so,stderr=se,start_new_session=True)
        try:code=p.wait(timeout=1200)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    record["runs"].append({"label":label,"argv":args,"cwd":str(cwd),"returncode":code,"seconds":time.monotonic()-start})
    (out/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
    print(label+" exit="+str(code),flush=True)
    if code:raise RuntimeError(label+" failed; inspect its retained stderr")
    return (out/(label+".stdout")).read_bytes()
cargo=[str(tc/"bin/cargo")]
metadata=json.loads(run(cargo+["metadata","--locked","--offline","--no-deps","--format-version","1"],"workspace-metadata",source))
packages=sdk.classify(metadata)
for name in sdk.CONSUMER_CRATES:
    item=cohort["crates"][name]
    members=sdk.validate_archive(sdk.snapshot(report.path.parent/"crates"/item["file"]).data,name,packages[name],set(item["files"]))
    for path,data in members.items():
        target=producer/"crates"/name/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
candidate=producer/package.CANDIDATE.relative_to(package.ROOT)
for path in package.CANDIDATE.rglob("*"):
    if path.is_file():sdk.copy(path,candidate/path.relative_to(package.CANDIDATE))
for path in consumer_contract.FIXTURE.rglob("*"):
    assert not path.is_symlink()
    if path.is_file():sdk.copy(path,consumer/path.relative_to(consumer_contract.FIXTURE))
record["consumer_source_sha256"]={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob("*") if p.is_file()}
(out/"FROZEN_CONSUMER.json").write_text(json.dumps(record["consumer_source_sha256"],indent=2)+"\n")
sdk.extract_recorded_crates(consumer,report.path.parent,cohort["crates"])
patches=[]
for name in sdk.CONSUMER_CRATES:patches.extend(["--config","patch.crates-io."+name+".path="+json.dumps(str(producer/"crates"/name))])
args=cargo+["package","--manifest-path",str(candidate/"Cargo.toml"),"--locked","--offline","--all-features",*patches]
listed=run(args+["--list"],"package-list",producer).decode().splitlines();assert len(listed)==len(set(listed))
run(args+["-j","2"],"package",producer)
sdk.validate_cargo_package_completion(package.NAME,[(out/("package."+suffix)).read_text() for suffix in ("stdout","stderr")])
archive=sdk.snapshot(root/"build/package"/(package.NAME+"-"+package.VERSION+".crate"));members=package.validate_candidate(archive.data,set(listed))
record["candidate_archive"]={"sha256":archive.sha256,"bytes":archive.size,"members":len(members)}
for path,data in members.items():
    target=consumer/"packages"/(package.NAME+"-"+package.VERSION)/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
with (consumer/"Cargo.toml").open("a") as f:f.write(package.NAME+' = { path = "packages/'+package.NAME+'-'+package.VERSION+'" }\n')
original=(candidate/"Cargo.lock").read_bytes();(consumer/"Cargo.lock").write_bytes(original)
metadata=json.loads(run(cargo+["metadata","--offline","--format-version","1"],"consumer-metadata",consumer))
record["resolution"]=package.verify_resolution(metadata,consumer,(consumer/"Cargo.lock").read_bytes(),original,consumer_name=consumer_contract.NAME,required_features=consumer_contract.FEATURES)
run(cargo+["test","--lib","--locked","--offline","-j","2","--","--nocapture","--test-threads=1"],"consumer-lib",consumer)
record["completed"]=True
(out/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"completed":True,"outside":str(root),"archive":record["candidate_archive"]}),flush=True)
