
target/foreign-account-owner-current/restore-box-green-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000029f54c <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy23HistoricalSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_>:
  29f54c: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
  29f550: a90167fa     	stp	x26, x25, [sp, #0x10]
  29f554: a9025ff8     	stp	x24, x23, [sp, #0x20]
  29f558: a90357f6     	stp	x22, x21, [sp, #0x30]
  29f55c: a9044ff4     	stp	x20, x19, [sp, #0x40]
  29f560: a9057bfd     	stp	x29, x30, [sp, #0x50]
  29f564: 910143fd     	add	x29, sp, #0x50
  29f568: d1401be9     	sub	x9, sp, #0x6, lsl #12   ; =0x6000
  29f56c: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  29f570: f90003ff     	str	xzr, [sp]
  29f574: eb2963ff     	cmp	sp, x9
  29f578: 54ffffa1     	b.ne	0x29f56c <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy23HistoricalSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_+0x20>
  29f57c: d10403ff     	sub	sp, sp, #0x100
  29f580: aa0403f5     	mov	x21, x4
  29f584: aa0303f7     	mov	x23, x3
  29f588: aa0203f8     	mov	x24, x2
  29f58c: aa0103f4     	mov	x20, x1
  29f590: aa0003f3     	mov	x19, x0
  29f594: aa0803f6     	mov	x22, x8
  29f598: f90017e1     	str	x1, [sp, #0x28]
  29f59c: 9100c3e0     	add	x0, sp, #0x30
  29f5a0: aa0403e1     	mov	x1, x4
  29f5a4: 52820e02     	mov	w2, #0x1070             ; =4208
  29f5a8: 94101c5d     	bl	0x6a671c <dyld_stub_binder+0x6a671c>
  29f5ac: 396182e8     	ldrb	w8, [x23, #0x860]
