
target/foreign-account-owner-current/restore-stack-control-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000002ee4dc <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy21VerifiedSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_>:
  2ee4dc: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
  2ee4e0: a90167fa     	stp	x26, x25, [sp, #0x10]
  2ee4e4: a9025ff8     	stp	x24, x23, [sp, #0x20]
  2ee4e8: a90357f6     	stp	x22, x21, [sp, #0x30]
  2ee4ec: a9044ff4     	stp	x20, x19, [sp, #0x40]
  2ee4f0: a9057bfd     	stp	x29, x30, [sp, #0x50]
  2ee4f4: 910143fd     	add	x29, sp, #0x50
  2ee4f8: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2ee4fc: f90003ff     	str	xzr, [sp]
  2ee500: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2ee504: f90003ff     	str	xzr, [sp]
  2ee508: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2ee50c: f90003ff     	str	xzr, [sp]
  2ee510: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2ee514: f90003ff     	str	xzr, [sp]
  2ee518: d11f83ff     	sub	sp, sp, #0x7e0
  2ee51c: f90003ff     	str	xzr, [sp]
  2ee520: aa0403f5     	mov	x21, x4
  2ee524: aa0303f7     	mov	x23, x3
  2ee528: aa0203f8     	mov	x24, x2
  2ee52c: aa0103f4     	mov	x20, x1
  2ee530: aa0003f3     	mov	x19, x0
  2ee534: aa0803f6     	mov	x22, x8
  2ee538: f9000fe1     	str	x1, [sp, #0x18]
  2ee53c: 910083e0     	add	x0, sp, #0x20
