
target/foreign-account-owner-current/restore-stack-control-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000145440 <__RINvMs_NtCshgaZoQMnI69_31q_periapt_continuity_c_consumer5ownerNtB5_10Activation6reopenNCNvMs0_B5_NtB5_5Owner4open0EB7_>:
  145440: a9be6ffc     	stp	x28, x27, [sp, #-0x20]!
  145444: a9017bfd     	stp	x29, x30, [sp, #0x10]
  145448: 910043fd     	add	x29, sp, #0x10
  14544c: d14077e9     	sub	x9, sp, #0x1d, lsl #12  ; =0x1d000
  145450: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  145454: f90003ff     	str	xzr, [sp]
  145458: eb2963ff     	cmp	sp, x9
  14545c: 54ffffa1     	b.ne	0x145450 <__RINvMs_NtCshgaZoQMnI69_31q_periapt_continuity_c_consumer5ownerNtB5_10Activation6reopenNCNvMs0_B5_NtB5_5Owner4open0EB7_+0x10>
  145460: d12443ff     	sub	sp, sp, #0x910
  145464: f90003ff     	str	xzr, [sp]
  145468: d102c3a9     	sub	x9, x29, #0xb0
  14546c: f90057e9     	str	x9, [sp, #0xa8]
  145470: 914067e9     	add	x9, sp, #0x19, lsl #12  ; =0x19000
  145474: 912fe129     	add	x9, x9, #0xbf8
  145478: f9005be9     	str	x9, [sp, #0xb0]
  14547c: 914067e9     	add	x9, sp, #0x19, lsl #12  ; =0x19000
  145480: 910db529     	add	x9, x9, #0x36d
  145484: f9005fe9     	str	x9, [sp, #0xb8]
  145488: 914057ea     	add	x10, sp, #0x15, lsl #12 ; =0x15000
  14548c: 913ee14a     	add	x10, x10, #0xfb8
  145490: f90063ea     	str	x10, [sp, #0xc0]
  145494: 91404bea     	add	x10, sp, #0x12, lsl #12 ; =0x12000
  145498: 910c814a     	add	x10, x10, #0x320
  14549c: f90067ea     	str	x10, [sp, #0xc8]
  1454a0: 91403fea     	add	x10, sp, #0xf, lsl #12  ; =0xf000
