#include <pthread.h>
#include <stdio.h>
static void *inspect(void *unused) {
    (void)unused;
    printf("default_pthread_stack_bytes=%zu\n", pthread_get_stacksize_np(pthread_self()));
    return NULL;
}
int main(void) {
    pthread_t worker;
    int error = pthread_create(&worker, NULL, inspect, NULL);
    if (error) return error;
    return pthread_join(worker, NULL);
}
