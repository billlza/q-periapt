
target/foreign-account-owner-current/restore-stack-control-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000002eeda4 <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy23HistoricalSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_>:
  2eeda4: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
  2eeda8: a90167fa     	stp	x26, x25, [sp, #0x10]
  2eedac: a9025ff8     	stp	x24, x23, [sp, #0x20]
  2eedb0: a90357f6     	stp	x22, x21, [sp, #0x30]
  2eedb4: a9044ff4     	stp	x20, x19, [sp, #0x40]
  2eedb8: a9057bfd     	stp	x29, x30, [sp, #0x50]
  2eedbc: 910143fd     	add	x29, sp, #0x50
  2eedc0: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2eedc4: f90003ff     	str	xzr, [sp]
  2eedc8: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2eedcc: f90003ff     	str	xzr, [sp]
  2eedd0: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2eedd4: f90003ff     	str	xzr, [sp]
  2eedd8: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  2eeddc: f90003ff     	str	xzr, [sp]
  2eede0: d11f83ff     	sub	sp, sp, #0x7e0
  2eede4: f90003ff     	str	xzr, [sp]
  2eede8: aa0403f5     	mov	x21, x4
  2eedec: aa0303f7     	mov	x23, x3
  2eedf0: aa0203f8     	mov	x24, x2
  2eedf4: aa0103f4     	mov	x20, x1
  2eedf8: aa0003f3     	mov	x19, x0
  2eedfc: aa0803f6     	mov	x22, x8
  2eee00: f9000fe1     	str	x1, [sp, #0x18]
  2eee04: 910083e0     	add	x0, sp, #0x20
