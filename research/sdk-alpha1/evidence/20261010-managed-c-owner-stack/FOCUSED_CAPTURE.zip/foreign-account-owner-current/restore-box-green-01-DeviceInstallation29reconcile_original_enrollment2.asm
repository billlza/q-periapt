
target/foreign-account-owner-current/restore-box-green-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000029ec58 <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy21VerifiedSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_>:
  29ec58: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
  29ec5c: a90167fa     	stp	x26, x25, [sp, #0x10]
  29ec60: a9025ff8     	stp	x24, x23, [sp, #0x20]
  29ec64: a90357f6     	stp	x22, x21, [sp, #0x30]
  29ec68: a9044ff4     	stp	x20, x19, [sp, #0x40]
  29ec6c: a9057bfd     	stp	x29, x30, [sp, #0x50]
  29ec70: 910143fd     	add	x29, sp, #0x50
  29ec74: d1401be9     	sub	x9, sp, #0x6, lsl #12   ; =0x6000
  29ec78: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  29ec7c: f90003ff     	str	xzr, [sp]
  29ec80: eb2963ff     	cmp	sp, x9
  29ec84: 54ffffa1     	b.ne	0x29ec78 <__RINvMs0_NtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installationNtB6_18DeviceInstallation29reconcile_original_enrollmentNtNtB8_14session_policy21VerifiedSessionPolicyNtNtB6_9admission21InstallationAdmissionEB8_+0x20>
  29ec88: d10403ff     	sub	sp, sp, #0x100
  29ec8c: aa0403f5     	mov	x21, x4
  29ec90: aa0303f7     	mov	x23, x3
  29ec94: aa0203f8     	mov	x24, x2
  29ec98: aa0103f4     	mov	x20, x1
  29ec9c: aa0003f3     	mov	x19, x0
  29eca0: aa0803f6     	mov	x22, x8
  29eca4: f90017e1     	str	x1, [sp, #0x28]
  29eca8: 9100c3e0     	add	x0, sp, #0x30
  29ecac: aa0403e1     	mov	x1, x4
  29ecb0: 52820e02     	mov	w2, #0x1070             ; =4208
  29ecb4: 94101e9a     	bl	0x6a671c <dyld_stub_binder+0x6a671c>
  29ecb8: 3961a2e8     	ldrb	w8, [x23, #0x868]
