
target/foreign-account-owner-current/restore-stack-control-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000001a68c8 <__RINvMs3_NtNtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installation6reopenNtB8_18DeviceInstallation14reopen_sessionNtNtB8_9admission21InstallationAdmissionECshgaZoQMnI69_31q_periapt_continuity_c_consumer>:
  1a68c8: a9be6ffc     	stp	x28, x27, [sp, #-0x20]!
  1a68cc: a9017bfd     	stp	x29, x30, [sp, #0x10]
  1a68d0: 910043fd     	add	x29, sp, #0x10
  1a68d4: d14063e9     	sub	x9, sp, #0x18, lsl #12  ; =0x18000
  1a68d8: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
  1a68dc: f90003ff     	str	xzr, [sp]
  1a68e0: eb2963ff     	cmp	sp, x9
  1a68e4: 54ffffa1     	b.ne	0x1a68d8 <__RINvMs3_NtNtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installation6reopenNtB8_18DeviceInstallation14reopen_sessionNtNtB8_9admission21InstallationAdmissionECshgaZoQMnI69_31q_periapt_continuity_c_consumer+0x10>
  1a68e8: d12843ff     	sub	sp, sp, #0xa10
  1a68ec: f90003ff     	str	xzr, [sp]
  1a68f0: d10127a9     	sub	x9, x29, #0x49
  1a68f4: f900b3e9     	str	x9, [sp, #0x160]
  1a68f8: 91405bea     	add	x10, sp, #0x16, lsl #12 ; =0x16000
  1a68fc: 9112414a     	add	x10, x10, #0x490
  1a6900: f900b7ea     	str	x10, [sp, #0x168]
  1a6904: 91405be9     	add	x9, sp, #0x16, lsl #12  ; =0x16000
  1a6908: 910e1d29     	add	x9, x9, #0x387
  1a690c: f900bbe9     	str	x9, [sp, #0x170]
  1a6910: 914043eb     	add	x11, sp, #0x10, lsl #12 ; =0x10000
  1a6914: 912c816b     	add	x11, x11, #0xb20
  1a6918: f900bfeb     	str	x11, [sp, #0x178]
  1a691c: 914007eb     	add	x11, sp, #0x1, lsl #12  ; =0x1000
  1a6920: 9116e16b     	add	x11, x11, #0x5b8
  1a6924: f900c3eb     	str	x11, [sp, #0x180]
  1a6928: 914007eb     	add	x11, sp, #0x1, lsl #12  ; =0x1000
