
target/foreign-account-owner-current/restore-box-green-01/installed/libq_periapt_continuity_c_consumer.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000c2880 <__RINvMs3_NtNtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installation6reopenNtB8_18DeviceInstallation14reopen_sessionNtNtB8_9admission21InstallationAdmissionECshgaZoQMnI69_31q_periapt_continuity_c_consumer>:
   c2880: a9be6ffc     	stp	x28, x27, [sp, #-0x20]!
   c2884: a9017bfd     	stp	x29, x30, [sp, #0x10]
   c2888: 910043fd     	add	x29, sp, #0x10
   c288c: d14037e9     	sub	x9, sp, #0xd, lsl #12   ; =0xd000
   c2890: d14007ff     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
   c2894: f90003ff     	str	xzr, [sp]
   c2898: eb2963ff     	cmp	sp, x9
   c289c: 54ffffa1     	b.ne	0xc2890 <__RINvMs3_NtNtCs4MKHmOGq0yz_39q_periapt_continuity_identity_candidate12installation6reopenNtB8_18DeviceInstallation14reopen_sessionNtNtB8_9admission21InstallationAdmissionECshgaZoQMnI69_31q_periapt_continuity_c_consumer+0x10>
   c28a0: d12bc3ff     	sub	sp, sp, #0xaf0
   c28a4: f90003ff     	str	xzr, [sp]
   c28a8: 91402be9     	add	x9, sp, #0xa, lsl #12   ; =0xa000
   c28ac: 913b7d29     	add	x9, x9, #0xedf
   c28b0: f9009fe9     	str	x9, [sp, #0x138]
   c28b4: 914023ea     	add	x10, sp, #0x8, lsl #12  ; =0x8000
   c28b8: 9122e14a     	add	x10, x10, #0x8b8
   c28bc: f900a3ea     	str	x10, [sp, #0x140]
   c28c0: 914023e9     	add	x9, sp, #0x8, lsl #12   ; =0x8000
   c28c4: 911ec129     	add	x9, x9, #0x7b0
   c28c8: f900a7e9     	str	x9, [sp, #0x148]
   c28cc: 914007eb     	add	x11, sp, #0x1, lsl #12  ; =0x1000
   c28d0: 9116216b     	add	x11, x11, #0x588
   c28d4: f900abeb     	str	x11, [sp, #0x150]
   c28d8: 914007eb     	add	x11, sp, #0x1, lsl #12  ; =0x1000
   c28dc: 9108996b     	add	x11, x11, #0x226
   c28e0: f900afeb     	str	x11, [sp, #0x158]
