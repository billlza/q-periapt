use hkdf::Hkdf;
use hmac::{Hmac, KeyInit, Mac};
use sha2::{block_api::compress256, Sha256};

const IV: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];
const DOMAIN: &[u8] = include_bytes!("../domain.bin");
const LABEL: &[u8] = include_bytes!("../label.bin");

fn bytes(words: [u32; 8]) -> [u8; 32] {
    let mut result = [0; 32];
    for (chunk, word) in result.chunks_exact_mut(4).zip(words) {
        chunk.copy_from_slice(&word.to_be_bytes());
    }
    result
}

fn padded(message: &[u8], prior: u64) -> Vec<[u8; 64]> {
    let length = u64::try_from(message.len()).expect("fixture length");
    let bits = prior.checked_add(length).expect("length sum").checked_mul(8).expect("bit length");
    let mut result = message.to_vec();
    result.push(0x80);
    while result.len() % 64 != 56 {
        result.push(0);
    }
    result.extend_from_slice(&bits.to_be_bytes());
    result.chunks_exact(64).map(|x| x.try_into().expect("whole block")).collect()
}

fn manual_hmac(key: &[u8; 32], message: &[u8], prior: u64) -> ([u8; 32], usize) {
    let mut inner_pad = [0x36; 64];
    let mut outer_pad = [0x5c; 64];
    for index in 0..32 {
        inner_pad[index] ^= key[index];
        outer_pad[index] ^= key[index];
    }
    let mut inner = IV;
    compress256(&mut inner, &[inner_pad]);
    let inner_blocks = padded(message, prior);
    compress256(&mut inner, &inner_blocks);
    let mut outer = IV;
    compress256(&mut outer, &[outer_pad]);
    let outer_blocks = padded(&bytes(inner), prior);
    compress256(&mut outer, &outer_blocks);
    (bytes(outer), 2 + inner_blocks.len() + outer_blocks.len())
}

fn library_hmac(key: &[u8; 32], message: &[u8]) -> [u8; 32] {
    let mut mac = <Hmac<Sha256> as KeyInit>::new_from_slice(key).expect("32-byte key");
    mac.update(message);
    mac.finalize().into_bytes().into()
}

fn hex(value: [u8; 32]) -> String {
    value.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn main() {
    assert_eq!(DOMAIN.len(), 40);
    assert_eq!(LABEL.len(), 25);
    let mut ascending = [0; 32];
    for (index, byte) in ascending.iter_mut().enumerate() {
        *byte = u8::try_from(index).expect("fixture index");
    }
    let values = [[0; 32], [0xff; 32], ascending, [0xa5; 32]];
    let mut cases = 0;
    let mut wrong_extract_padding = 0;
    let mut wrong_expand_padding = 0;
    let mut wrong_expand_counter = 0;
    let mut rows = Vec::new();
    for (salt_index, salt) in values.iter().enumerate() {
        for (secret_index, secret) in values.iter().enumerate() {
            for (digest_index, digest) in values.iter().enumerate() {
                let mut info = [DOMAIN, LABEL].concat();
                info.extend_from_slice(digest);
                assert_eq!(info.len(), 97);
                let mut message = info.clone();
                message.push(1);
                assert_eq!(message.len(), 98);
                let blocks = padded(&message, 64);
                assert_eq!(blocks.len(), 2);
                assert_eq!(&blocks[1][56..], &1296_u64.to_be_bytes());
                let (prk, extract_calls) = manual_hmac(salt, secret, 64);
                assert_eq!(extract_calls, 4);
                let (library_prk, _) = Hkdf::<Sha256>::extract(Some(salt), secret);
                assert_eq!(library_prk.as_slice(), prk);
                let (root, expand_calls) = manual_hmac(&prk, &message, 64);
                assert_eq!(expand_calls, 5);
                let mut actual = [0; 32];
                Hkdf::<Sha256>::new(Some(salt), secret).expand(&info, &mut actual).expect("one output block");
                assert_eq!(actual, root);
                assert_eq!(actual, library_hmac(&prk, &message));
                assert_ne!(actual, manual_hmac(&manual_hmac(salt, secret, 0).0, &message, 64).0);
                wrong_extract_padding += 1;
                assert_ne!(actual, manual_hmac(&prk, &message, 0).0);
                wrong_expand_padding += 1;
                *message.last_mut().expect("counter byte") = 0;
                assert_ne!(actual, manual_hmac(&prk, &message, 64).0);
                wrong_expand_counter += 1;
                cases += 1;
                rows.push(format!("{{\"salt\":{salt_index},\"secret\":{secret_index},\"core_digest\":{digest_index},\"root\":\"{}\"}}",hex(root)));
            }
        }
    }
    println!("{{\"cases\":{cases},\"wrong_extract_padding_rejected\":{wrong_extract_padding},\"wrong_expand_padding_rejected\":{wrong_expand_padding},\"wrong_expand_counter_rejected\":{wrong_expand_counter},\"info_bytes\":97,\"expand_message_bytes\":98,\"manual_extract_compressions\":4,\"manual_expand_compressions\":5,\"rows\":[{}]}}",rows.join(","));
}
