from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tomllib
import zipfile

import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-root-qrom'
OLD = ROOT / 'target/continuity-hmac-joint-reduction'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
FIXTURE = BASE / 'encoding-check'
PORTABLE = BASE / 'portable-encoding'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-root-extraction-qrom'
PRIMITIVE = ROOT / 'research/sdk-alpha1/evidence/20261104-shared-root-hmac/CAPTURE.zip'
PRIMITIVE_SHA = 'f496ddcd4c93c58955f638c543344d2224dde93776c2be054adc8bb812545743'


def sha(data): return hashlib.sha256(data).hexdigest()
def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()
def obj(path): return json.loads(read(path))
def encode(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(body)


assert not DEST.exists() and not PORTABLE.exists()
original = obj(BASE / 'ENCODING_RESULT.json')
inputs = obj(BASE / 'ENCODING_INPUTS.json')
assert original['completed'] and original['product_sources_unchanged'] and original['vendor_sources_unchanged']
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (original['source_commit'], False)
assert sha(read(PRIMITIVE)) == PRIMITIVE_SHA
assert sha(read(OLD / 'ENCODING_INPUTS.json')) == inputs['reused_vendor_inputs_sha256']
vendor_inputs = obj(OLD / 'ENCODING_INPUTS.json')['dependency_sources']
files = {}
for name in ['DERIVATION.md', 'SOURCE.json', 'check_encoding.py', 'encoding-main.rs',
             'ENCODING_INPUTS.json', 'ENCODING_OBSERVED.json', 'ENCODING_RESULT.json',
             'encoding-driver.stdout', 'encoding-driver.stderr', 'encoding-lock.json',
             'encoding-lock.stdout', 'encoding-lock.stderr', 'encoding-run.json',
             'encoding-run.stdout', 'encoding-run.stderr', 'seal.py']:
    files['original/' + name] = read(BASE / name)
for name in ['Cargo.toml', 'Cargo.lock', 'src/main.rs', '.cargo/config.toml', 'domain.bin', 'label.bin']:
    files['original/fixture/' + name] = read(FIXTURE / name)
    if name != '.cargo/config.toml':
        files['fixture/' + name] = read(FIXTURE / name)
files['fixture/.cargo/config.toml'] = b'[source.crates-io]\nreplace-with = "vendored-sources"\n\n[source.vendored-sources]\ndirectory = "vendor"\n'
locked = tomllib.loads(read(FIXTURE / 'Cargo.lock').decode())['package']
packages = [row for row in locked if 'source' in row]
assert len(packages) == 14
for row in packages:
    name = row['name'] + '-' + row['version']
    expected = vendor_inputs[name]
    assert row['checksum'] == expected['package_sha256']
    source = OLD / 'encoding-check/vendor' / name
    assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == set(expected['files']) | {'.cargo-checksum.json'}
    for relative, expected_sha in expected['files'].items():
        body = read(source / relative)
        assert sha(body) == expected_sha
        files['fixture/vendor/' + name + '/' + relative] = body
    checksum = read(source / '.cargo-checksum.json')
    assert json.loads(checksum) == {'package': expected['package_sha256'], 'files': expected['files']}
    files['fixture/vendor/' + name + '/.cargo-checksum.json'] = checksum
for name, expected in inputs['source_files'].items():
    body = read(SOURCE / name)
    assert sha(body) == expected and read(ROOT / name) == body
    files['source/' + name] = body
for name in ['LICENSE', 'LICENSE-APACHE', 'LICENSE-MIT']:
    files['source/licenses/' + name] = read(SOURCE / 'research/continuity-identity-candidate' / name)
for name in ['SHARED_ROOT_HMAC_V1.md', 'ROOT_EXTRACTION_QROM_V1.md']:
    files['notes/' + name] = read(ROOT / 'docs/continuity' / name)
with zipfile.ZipFile(PRIMITIVE) as archive:
    review_names = [name for name in archive.namelist() if name.endswith('/REVIEW.md') or name == 'REVIEW.md']
    assert len(review_names) == 1
    prior_review = archive.read(review_names[0])
    assert prior_review == read(OLD / 'REVIEW.md')
files['primitive/REVIEW.md'] = prior_review
files['primitive/IDENTITY.json'] = encode({'archive_sha256': PRIMITIVE_SHA, 'review_sha256': sha(prior_review),
    'scope': 'Independent internal review of the upstream single-root primitive calculation, not of this new root corollary.'})

portable_files = {name.removeprefix('fixture/'): body for name, body in files.items() if name.startswith('fixture/')}
for name, body in portable_files.items(): write(PORTABLE / name, body)
environment = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
environment.update(PATH=str(CHAIN / 'bin') + os.pathsep + environment.get('PATH', os.defpath),
                   CARGO_HOME=str(PORTABLE / 'cargo-home'), CARGO_TARGET_DIR=str(PORTABLE / 'target'),
                   CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0',
                   RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
                   RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings')
sdk.validate_no_registry_credentials(environment)
for name, expected in inputs['tools'].items(): assert sha(read(CHAIN / 'bin' / name)) == expected
output = sdk.command([str(CHAIN / 'bin/cargo'), 'run', '--locked', '--offline'], BASE / 'portable-run', PORTABLE, environment=environment)
assert output == read(BASE / 'encoding-run.stdout')
assert json.loads(output) == original['observed']
for name, body in portable_files.items(): assert read(PORTABLE / name) == body
for name, expected in inputs['tools'].items(): assert sha(read(CHAIN / 'bin' / name)) == expected
for name, expected in inputs['source_files'].items():
    assert sha(read(SOURCE / name)) == expected and sha(read(ROOT / name)) == expected
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (original['source_commit'], False)
for suffix in ['json', 'stdout', 'stderr']:
    files['portable/run.' + suffix] = read(BASE / ('portable-run.' + suffix))
readback = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Conditional mathematical corollary and pinned finite encoding checks, not a completed protocol theorem or release qualification.',
    'source_commit': original['source_commit'], 'source_files': inputs['source_files'],
    'primitive_archive_sha256': PRIMITIVE_SHA,
    'note_sha256': sha(files['notes/ROOT_EXTRACTION_QROM_V1.md']),
    'original_encoding_result_sha256': sha(read(BASE / 'ENCODING_RESULT.json')),
    'positive_cases': 64, 'negative_comparisons': 192, 'vendored_packages': len(packages),
    'portable_inputs_unchanged': True, 'portable_output_identical': True,
    'original_binary_sha256': original['fixture_binary_sha256'],
    'portable_binary_sha256': sha(read(PORTABLE / 'target/debug/continuity-root-encoding-check')),
    'tamarin_invoked': False, 'product_sources_modified': False,
    'external_review_completed': False, 'machine_checked_computational_proof': False}
files['READBACK.json'] = encode(readback)
manifest = {name: {'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        item = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        item.create_system = 3
        item.external_attr = (stat.S_IFREG | 0o644) << 16
        item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, body)
data = buffer.getvalue()
assert len(data) < 100 * 1024**2
with zipfile.ZipFile(io.BytesIO(data)) as archive:
    assert len(archive.infolist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    for name, body in files.items(): assert archive.read(name) == body
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', data), ('FILES.json', files['FILES.json']), ('READBACK.json', files['READBACK.json'])]:
    write(DEST / name, body)
summary = {'bytes': len(data), 'sha256': sha(data), 'members': len(files)}
write(DEST / 'SHA256.json', encode(summary))
print(json.dumps(summary), flush=True)
