# Conditional Extract/Expand corollary in the same compression QROM

Working derivation, 2026-11-05. This is not yet a reviewed protocol theorem.
It applies the retained single-root HMAC reduction twice; it does not supply
the actual ContextBound/ML-KEM accepted-prefix premise or change the product's
security assumptions. No source or protocol changes are proposed.

## Restricted experiment

Use exactly the compression oracle and HMAC encoding from
`docs/continuity/SHARED_ROOT_HMAC_V1.md`. The joint initialization of the entire
procedure is `unif(h) x unif(S) x sigma_aux`. All oracle-dependent preparation
is executed and counted, not supplied as free correlated advice. S has 32 bytes
and is unavailable outside one Extract call, including no auxiliary raw-S,
reservation, state, or ciphertext-disclosure channel.

The preparation, which has no access to S, chooses a 32-byte salt r and an
Expand message m. They may depend on counted h queries and ordinary auxiliary
data. The procedure computes

    p = HMAC_h(r, S)
    R = HMAC_h(p, m)

and continues using R. The continuation never receives S or p except through
this dependency; all its ordinary h calls are included in the reductions.
Repeated execution of the same original operation reuses its recorded result.
There is only one distinct target Extract/Expand pair in this experiment.
No multi-root or multi-epoch conclusion follows by naming this one target.

For the pinned candidate `derive_root` call, m is exactly
`REKEY_DOMAIN || "pending-root/HKDF-SHA256/" || hash("response-core", core)
 || 0x01`. Its component lengths are 40 + 25 + 32 + 1 = 98 bytes.
Thus the row continuation needs `ell = 1 + ceil((98+9)/64) = 3` compression
calls after its two key-pad calls. The message is not 32 bytes, so it cannot
equal the secret 32-byte p in the cross-interface exceptional-pair condition.

## First application: replace Extract

Instantiate the existing Real-to-independent-table-I reduction with hidden
value S, C=1 and T=0. The column gives `V(Gamma(r))`, where V is independent of
h and Gamma retains the exact public pad-state pair. Do not replace the whole
column family by V(r). For this single query, however, the returned value is
fresh uniform independently of h and the prior preparation, even when the
selected Gamma(r) depends on h. There was no earlier query to this V table.

Therefore the game may sample a fresh p instead of evaluating the Extract.
Sampling p before the preparation and withholding it until this point gives
the same observable experiment because the preparation does not depend on p.
The optional computation of Gamma(r) may be retained for query accounting.
The subsequent Expand and continuation are simulated from the returned p;
their ordinary compression calls count toward q_ext.

With the existing conservative C+2 private-call bound, the distinguishing
error is at most

    eps_ext = min(1, DFH(3, q_ext+3) + E_F1(1, q_ext+2)).

Here `DFH(k,Q) = 4 sqrt(2 k^2 Q / 2^256)
                    + 4 sqrt(2 Q^2 k / 2^256)`.
The NMAC replacement is omitted because no row interface was called. E_F1
has exactly the Proposition 4 parameters and query regime already recorded in
the HMAC note. This deliberately retains an upper bound of three private
calls; it does not claim all three calls occurred in the row-free execution.

## Second application: replace Expand

In the first ideal game p is uniform and independent at initialization, with
all prior h-dependent work still executed inside the counted preparation.
There is no remaining raw use of S or a later Extract-table call. Apply the
same Real-to-I reduction to hidden value p, with C=0, T=1 and L=98. The row
answer is an independent table U(m). A single fresh U query returns a uniform
R independent of h and the prefix; equivalent sampling before the preparation
again withholds R until it is used. Later values must be recomputed from R.

The distinguishing error is at most

    eps_exp = min(1, DFH(2, q_exp+3) + E_NMAC(1, q_exp, 3)).

The F1 replacement is omitted because the column was never called. This uses
independent-table I; no I-to-J correction is needed for this experiment.
The retained padding offset and NMAC theorem conditions still apply.

For any allowed final output bit, the real two-call procedure and its
uniform-root continuation therefore differ by at most
`min(1, eps_ext + eps_exp)`. If an independently justified prefix/combiner
replacement changes the actual S to the required independent uniform value
with advantage eps_K, triangle inequality adds eps_K. Each q is the complete
ordinary-query budget of its own constructed reduction, including honest
simulation. A shared smaller q is not asserted without a separate inventory.

The random-oracle models, published asymptotic constants and query regimes are
unchanged. This gives neither concrete security bits nor a theorem for concrete
SHA-256. It is a corollary to a conditional primitive calculation, not evidence
that the implementation already meets its input-distribution or disclosure
premises. The entire multi-epoch transcript/authority/state interface remains
to be composed, and external review remains outstanding.

## References and next checks

- Frozen internal reduction and applicability review:
  `research/sdk-alpha1/evidence/20261104-shared-root-hmac/`.
- Don, Fehr and Huang, Theorem 2:
  https://arxiv.org/pdf/2206.08132.
- Hosoyamada and Iwata, Propositions 4 and 6:
  https://eprint.iacr.org/2021/774.pdf.
- Actual source: candidate `contract.rs`, `messages/rekey.rs` and
  `messages/rekey/response.rs`, on qualification source ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20.

Before admitting this corollary to the review package, separately check the
single-query resampling with counted correlated prefixes, the continuation's
absence of raw S/p channels, and the exact q_ext/q_exp simulation costs. A
finite HMAC encoding comparison alone cannot verify these distribution claims.
