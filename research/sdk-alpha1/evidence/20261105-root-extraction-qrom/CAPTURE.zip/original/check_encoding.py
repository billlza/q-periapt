from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import time
import tomllib

import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-root-qrom'
OLD = ROOT / 'target/continuity-hmac-joint-reduction'
FIXTURE = BASE / 'encoding-check'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
VENDOR = OLD / 'encoding-check/vendor'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2); stream.write('\n')


previous = json.loads((OLD / 'ENCODING_INPUTS.json').read_bytes())
previous_result = json.loads((OLD / 'ENCODING_RESULT.json').read_bytes())
assert previous_result['completed'] and previous_result['source_commit'] == 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'


def check_vendor():
    expected_packages = previous['dependency_sources']
    assert {p.name for p in VENDOR.iterdir()} == set(expected_packages)
    for name, record in expected_packages.items():
        directory = VENDOR / name
        expected = record['files']
        assert not any(p.is_symlink() for p in directory.rglob('*'))
        actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
        assert actual == set(expected) | {'.cargo-checksum.json'}
        for relative, sha in expected.items():
            assert digest(directory / relative) == sha
        assert json.loads((directory / '.cargo-checksum.json').read_bytes()) == {
            'files': expected, 'package': record['package_sha256']}


state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'scope': 'Finite comparison of the source-derived 98-byte Expand input and two HMAC compression encodings against pinned real HKDF/HMAC/SHA-256 libraries. No protocol or distribution theorem is tested.',
         'source_commit': previous_result['source_commit'], 'command_timeout_seconds': 900,
         'network_access_required': False, 'product_sources_modified': False}
started = time.monotonic()
try:
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (state['source_commit'], False)
    check_vendor()
    names = ['Cargo.toml', 'Cargo.lock', 'src/contract.rs', 'src/durable/messages/rekey.rs',
             'src/durable/messages/rekey/response.rs', 'src/durable/messages/rekey/completion.rs']
    source_files = {f'research/continuity-identity-candidate/{name}': digest(SOURCE / 'research/continuity-identity-candidate' / name) for name in names}
    assert all(digest(ROOT / name) == expected for name, expected in source_files.items())
    contract = (SOURCE / 'research/continuity-identity-candidate/src/contract.rs').read_text()
    response = (SOURCE / 'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs').read_text()
    domain = re.findall(r'pub const REKEY_DOMAIN: &\[u8\] = b"([^"\\]+)";', contract)
    function = response[response.index('pub(super) fn derive_root('):response.index('\nfn confirmation(')]
    label = re.findall(r'\[DOMAIN, b"([^"\\]+)"\]\.concat\(\)', function)
    assert len(domain) == len(label) == 1
    assert 'info.extend_from_slice(&hash(b"response-core", core));' in function
    assert 'Hkdf::<Sha256>::new(Some(previous.as_bytes()), shared.as_bytes())' in function
    assert '.expand(&info, root.as_mut_bytes())' in function
    assert len(domain[0].encode()) == 40 and len(label[0].encode()) == 25
    FIXTURE.mkdir(exist_ok=False)
    (FIXTURE / 'src').mkdir()
    (FIXTURE / '.cargo').mkdir()
    with (FIXTURE / 'src/main.rs').open('xb') as stream:
        stream.write((BASE / 'encoding-main.rs').read_bytes())
    for name, value in [('domain.bin', domain[0].encode()), ('label.bin', label[0].encode())]:
        with (FIXTURE / name).open('xb') as stream: stream.write(value)
    manifest = (OLD / 'encoding-check/Cargo.toml').read_text().replace('continuity-hmac-encoding-check', 'continuity-root-encoding-check')
    with (FIXTURE / 'Cargo.toml').open('x') as stream: stream.write(manifest)
    with (FIXTURE / '.cargo/config.toml').open('x') as stream:
        stream.write('[source.crates-io]\nreplace-with = "vendored-sources"\n\n[source.vendored-sources]\ndirectory = ' + json.dumps(str(VENDOR)) + '\n')
    tools = {name: digest(CHAIN / 'bin' / name) for name in ['cargo', 'rustc', 'rustfmt']}
    assert tools == previous['tools']
    inputs = {'source_files': source_files, 'tools': tools,
              'reused_vendor_inputs_sha256': digest(OLD / 'ENCODING_INPUTS.json'),
              'reused_vendor_packages': len(previous['dependency_sources']),
              'driver_sha256': digest(Path(__file__)), 'fixture_sources': {
                  name: digest(FIXTURE / name) for name in ['Cargo.toml', 'src/main.rs', '.cargo/config.toml', 'domain.bin', 'label.bin']}}
    write(BASE / 'ENCODING_INPUTS.json', inputs)
    environment = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    environment.update(PATH=str(CHAIN / 'bin') + os.pathsep + environment.get('PATH', os.defpath),
                       CARGO_HOME=str(FIXTURE / 'cargo-home'), CARGO_TARGET_DIR=str(FIXTURE / 'target'),
                       CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0',
                       RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
                       RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings')
    sdk.validate_no_registry_credentials(environment)
    sdk.command([str(CHAIN / 'bin/cargo'), 'generate-lockfile', '--offline'], BASE / 'encoding-lock', FIXTURE, environment=environment)
    output = sdk.command([str(CHAIN / 'bin/cargo'), 'run', '--locked', '--offline'], BASE / 'encoding-run', FIXTURE, environment=environment)
    observed = json.loads(output)
    assert observed['cases'] == 64 and len(observed['rows']) == 64
    assert all(observed[name] == 64 for name in ['wrong_extract_padding_rejected', 'wrong_expand_padding_rejected', 'wrong_expand_counter_rejected'])
    assert observed['expand_message_bytes'] == 98 and observed['info_bytes'] == 97
    assert observed['manual_extract_compressions'] == 4 and observed['manual_expand_compressions'] == 5
    for package in tomllib.loads((FIXTURE / 'Cargo.lock').read_text())['package']:
        if 'source' in package:
            record = previous['dependency_sources'][package['name'] + '-' + package['version']]
            assert package['checksum'] == record['package_sha256']
    check_vendor()
    assert all(digest(SOURCE / name) == expected and digest(ROOT / name) == expected for name, expected in source_files.items())
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (state['source_commit'], False)
    assert {name: digest(CHAIN / 'bin' / name) for name in tools} == tools
    assert all(digest(FIXTURE / name) == expected for name, expected in inputs['fixture_sources'].items())
    write(BASE / 'ENCODING_OBSERVED.json', observed)
    state.update(completed=True, observed=observed, product_sources_unchanged=True, tools_unchanged=True,
                 vendor_sources_unchanged=True, fixture_lock_sha256=digest(FIXTURE / 'Cargo.lock'),
                 fixture_binary_sha256=digest(FIXTURE / 'target/debug/continuity-root-encoding-check'))
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    write(BASE / 'ENCODING_RESULT.json', state)
    print(json.dumps({'completed': state['completed'], 'elapsed_seconds': state['elapsed_seconds'], 'error': state.get('error')}), flush=True)
