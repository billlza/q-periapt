# Independent review of the proposed joint HMAC reduction

Reviewed 2026-11-04 UTC. Input: DRAFT.md, SHA-256
839074528e9e972289838ad18b13be5891e6beba232488c08b3cd233055b309b.
Only this review file was written. No product source, build, SDK or CI was
changed or run. This reviews applicability and composition of the cited results;
it does not independently reprove their full compressed-oracle appendices.

## Verdict

For the stated classical Row/Col interfaces, the proposed sequence does give
the stated output-probability bound, conditional on a genuinely ideal single
compression oracle and the initialization and length conditions below. I found
no counterexample to this restricted claim. In particular, the second interface
need not be dropped in either Hosoyamada–Iwata reduction, and no independence
assumption about the public salts Gamma(a) is necessary.

Two boundary statements should be made explicit before promotion:

1. The initial joint state must be unif(h) x unif(R) x sigma_aux. Every query
   producing oracle-related auxiliary state then belongs to the counted
   execution. R being independent of the pair (h,aux) alone would not license
   uncounted advice about h. The draft's preparation-query sentence should be
   read with this product initialization, not as a proof of the actual prefix.
2. The HMAC message limit is 8*(64+L) < 2^64, including the key-pad block.
   For integral byte lengths this is L <= 2^61-65, not merely L < 2^61.
   At L=2^61-64 the draft's BE64 field would attempt to encode 2^64 bits.

These clarify the finite experiment; they are not new cryptographic assumptions
or findings about product behavior. With the paper bounds represented by E_NMAC
and E_F1, and in their applicable regimes, the result is

    Adv(Real,J) <= min(1, E1 + E_NMAC(T,q+3C,ell)
                           + E_F1(C,q+2C) + T/2^256).

The independent-table ideal I is already reached after the first three terms.
The last term is the additional I-to-J equality repair. The target ideal should
be named explicitly alongside the displayed bound.

## Primary-source checks

The following specific passages were read in the original papers:

- [Don–Fehr–Huang, Section 4.2, Theorem 2 and (6)–(7)](https://arxiv.org/pdf/2206.08132):
  classical keyed queries, quantum public queries, pointwise entropy and
  freshness for every key; the displayed adaptive bound already includes the
  compiler loss. Section 4.3 was also checked for that loss.
- [Hosoyamada–Iwata, Section 4, Proposition 4](https://eprint.iacr.org/2021/774.pdf#page=20):
  F1(u,v)=h(v,f(u)), with private independent f; q=max(Q,qh), q=o(2^(n/3)),
  advantage O(sqrt(q^3/2^n)). The proof explicitly covers m'=0.
- [Hosoyamada–Iwata, Section 5, Proposition 6](https://eprint.iacr.org/2021/774.pdf#page=25):
  NMAC with independent keys, injective length-suffix padding, and a padded
  block bound; advantage O(sqrt((qh+Q)^3 ell^5/2^n)). Appendix D's one-block
  outer-hash case and Appendix E's shifted suffix were checked.
- Their Sections 2.1–2.3 specify query-information-theoretic adversaries,
  oracle-independent starting states, output-bit advantage and multiple-oracle
  scheduling. These points matter for the interpretation of the reductions.

The direct ePrint PDF fetch returned 403, but opening its search-index hit
returned the original indexed text (6951 lines). The statements and referenced
proof passages above were read there. This is not a claim that a current PDF
binary was downloaded and hashed, or that the entire 71-page proof was audited.

## Exact block and padding correspondence (draft lines 23–52)

Write s=|m| in bytes. The padding used after one already-compressed key-pad
block is

    pad64(m) = m || 0x80 || 0^z(s) || BE64(8*(64+s)),
    z(s) = (55-s) mod 64, chosen in {0,...,63}.

Its byte length is 64*ceil((s+9)/64). Adding the full 64-byte offset changes
the length field but not z(s). For a 32-byte digest or message, z=23 and the
length field is BE64(768), exactly the P in B(x)=x||P. Thus both Col's inner
and outer message compressions use B, and Row's two iterations use pad64.

The suffix depends only on s. On the permitted length domain, equality of two
padded strings forces equality of their final length fields, hence equal s;
their message prefixes must then be equal. This proves injectivity. A byte-only
domain is a restriction of the allowed message space. If a total bit-string
padding function is desired for the formal theorem, extend to bit lengths using
the same 512-bit offset and a length field modulo 2^64. It remains injective:
equal padded output lengths force original lengths to differ by less than 512,
while equal length fields force their difference to be a multiple of 2^64.
This mathematical extension is never an authorization for over-limit SHA input.

Accordingly, Proposition 6 is applied to MD with this particular padding,
not by pretending that shifted and unshifted NMAC are byte-identical. For the
outer 256-bit digest, pad64 has one 512-bit block, matching the one-block case
checked in Appendix D. There is no missing length-offset collision term.

The tails of I(x), O(x), B(x) are respectively 0x36^32, 0x5c^32 and P; P
starts with 0x80. Their ranges are disjoint, and each map is injective. These
are deterministic properties, including for zero keys and accidental selectors
equal to R. For a row message, the ordinary post-key-pad compressions number

    ceil((|m|+9)/64) + 1 <= ell := 1+ceil((L+9)/64).

This ell also safely bounds the padded-message blocks required by Proposition 6.
The draft's Rust dependency/source statements at lines 54–59 were not rechecked
in this task; the calculation here concerns the specified HMAC/SHA-256 shape.

## Hybrid 1: a valid DFH adversary with both interfaces present

Let Enc(r,(tag,s))=(tau_tag(r),s), with tau_in=I, tau_out=O and tau_message=B.
For a fixed (tag,s) and fixed compression input w, at most one r maps to w.
Therefore the entropy parameter in DFH (6) is epsilon=2^-256.

For two distinct (tag,s) values, either the tags differ and their block tails
are disjoint, or the tags agree and their chaining values differ. Hence their
encodings differ for every r, as required by DFH (7). A cache indexed by the
entire (tag,s) pair ensures that only distinct pairs are queried to the DFH
private oracle. Caching just the external salt a would not be the same argument:
different salts can produce equal alpha(a).

The DFH reduction never needs R itself. It implements a row by obtaining the
two cached private answers at (in,IV),(out,IV), then iterating ordinary h with
the supplied message. It implements a column by computing alpha(a),beta(a)
through h, obtaining the cached private answer at (message,alpha(a)), and
making the outer h call. It forwards the caller's quantum h queries unchanged.
It can make all these private queries classically because Row and Col are
classical. Its resources are

    q_O <= C+2,
    q_H <= Q1 := q+3C+ell*T.

All dependencies on previous answers, including adaptively selected salts and
messages, are inside this single reduction. Guesses a=R or m=R are permitted;
collisions between its public h queries and the hidden inputs are exactly what
the theorem bounds. They are not excluded by the freshness condition on
private queries. The resulting loss is precisely the draft's E1:

    min(1, 4 sqrt(2*(C+2)^2*Q1/2^256)
             +4 sqrt(2*Q1^2*(C+2)/2^256)).

In the ideal endpoint, restrictions of the one private random table to the
three disjoint tag domains give independent A,D,f. A,D are fixed across all
row calls; f is cached by chaining value. They are jointly independent of h.
The endpoint formulas at draft line 86 follow exactly. This independence is
an endpoint of the reduction, not an assumption about real HMAC midstates.

## Hybrid 2: replacing Row keeps the full column

Give the reduction a Proposition 6 challenge NMAC_{A,D}^{pad64} or U and the
same public h. The reduction owns a separate independent classical f table.
For every Col(a), it computes alpha(a), beta(a), looks up f(alpha(a)), and
returns h(B(f(alpha(a))),beta(a)). It sends each Row(m) to its challenge.
It does not need the challenge's secret A or D to implement Col.

This simulates the whole first-hybrid experiment at one endpoint and the
Row=U experiment at the other. Query counts are

    Q = T,                 q_h <= q+3C.

There is no extra ell*T in q_h here: the NMAC challenge now implements its
internal compression calls, which Proposition 6 already accounts for. Counting
them again would be safe but unnecessary. The three calls per simulated column
are real classical basis queries to h. The result supplies the draft's E_NMAC.

Because f is independent and only its final column effect is exposed, privately
sampling that table is an allowed local computation of the reduction. If f's
midstates or the challenge's NMAC keys were exposed through another interface,
this would no longer describe the claimed experiment.

## Hybrid 3: a single full-domain permutation, with both interfaces present

For the original input block x=y||t and chaining value s, define

    h_tilde(t||s,y) = h(y||t,s).

This permutes all three 256-bit input fields. It is a bijection on the full
768-bit input domain, not a restriction or independent oracle. One quantum
query in either representation is exactly one query in the other, surrounded
by wire permutations. The public alpha/beta computations become, explicitly,

    alpha(a) = h_tilde(0x36^32||IV, a xor 0x36^32),
    beta(a)  = h_tilde(0x5c^32||IV, a xor 0x5c^32).

The column outer call is h_tilde(P||beta(a), f(alpha(a))). Thus it is exactly
a Proposition 4 call with u=alpha(a), v=P||beta(a), n=256,m=512,m'=0.
The reduction computes alpha,beta with its public challenge h_tilde, makes
one F1/RF challenge call, and returns that answer. It simulates every Row
locally through an independent cached U table. It does not know or query f
separately; the challenge owns f. Its resources are

    Q = C,                 q_h <= q+2C,
    q_star = max(C,q+2C).

Classical Col inputs matter for these exact counts: no coherent computation
and uncomputation of alpha/beta is required. The original quantum public queries
are forwarded through the same full-domain permutation. Adaptive ordering is
allowed; the HI scheduling normalization only affects its unspecified constants.
No second public compression oracle has been introduced.

At the RF endpoint, restrict the independent challenge table to inputs
(u,P||s) and call that restriction V(u,s). This is a random function on pairs,
independent of h and U. It gives Col(a)=V(Gamma(a)). If Gamma(a)=Gamma(a'), the
same RF input is used, so the answers must coincide. If only one component
collides, the actual pairs still determine the table lookup. No injectivity of
Gamma or independence of Gamma from h is needed: computing these adaptively
through h is part of the reduction that Proposition 4 quantifies over.

This establishes E_F1 in its stated q_star=o(2^(256/3)) regime. An asymptotic
bound with an unspecified constant is not a calibrated finite security level.

## The I/J equality repair

I has Row(m)=U(m), Col(a)=V(Gamma(a)), and public h. Its entire execution has
no dependence on the unused uniform R. Let H be its complete classical list
of row queries, and S(H) the distinct 32-byte entries. Then

    Pr_I[Bad] = E_H |S(H)|/2^256 <= T/2^256,
    Bad := a row query equals R.

This uses the whole list's independence, not a claim of uniformity after
conditioning on earlier missed guesses. Repeats and adaptive stopping are
therefore included.

Construct J's exceptional value V(Gamma(R)) lazily at the first Bad call.
Before it, I and J use exactly the same public h, column function, and row
answers. An absorbing flag on the already-classical row input gives identical
unnormalized good states tau_good, even with a quantum workspace and quantum
public queries. Both bad components have trace p=Pr_I[Bad]. Thus

    rho_I = tau_good + tau_bad,I,
    rho_J = tau_good + tau_bad,J,
    D(rho_I,rho_J) <= p <= T/2^256.

There is no measurement of public quantum-query inputs. Gamma collisions do
not change this bound: they can change J's exceptional answer only on the
already-marked row m=R. The repaired cross-interface input pair is precisely
(a,R)=(R,m), which requires a=R and m=R.

Apply the output-probability triangle inequality to the three reductions and
this coupling to obtain the verdict's bound. Retaining R privately for this
last coupling does not strengthen DFH/HI into a whole-chain bound revealing R.
For example, if R were disclosed, a distinguisher could compute HMAC(a,R) with
four public h calls and compare it to one Col answer: Real matches always,
whereas I or J with T=0 matches with probability 2^-256. The draft correctly
excludes that stronger interface.

## Exact remaining conditions and stopping point

The proof applies to a classical choice of Row/Col interface and classical
selectors, 32-byte keys/salts, the stated message-length bound, a single ideal
compression oracle, complete ordinary-query accounting, and no extra raw-root
or midstate interface. Oracle-independent quantum auxiliary states can be
purified and absorbed into local initial preparation in a query-only model;
this does not admit oracle-correlated advice without its preparation queries.

The actual prefix must still establish the required joint state. The actual
selected implementation must still match these encodings and expose only the
modeled interfaces. The experiment must still be mapped to any protocol
continuation before claiming anything about later leakage or multiple epochs.
Concrete SHA-256 has not been proved to be the ideal compression function.
None of those obligations is discharged by this review. No new primitive,
product assumption, release gate, or model restriction is adopted here.

The requested finite applicability check is complete; no build, CI run or
broader protocol proof was attempted.
