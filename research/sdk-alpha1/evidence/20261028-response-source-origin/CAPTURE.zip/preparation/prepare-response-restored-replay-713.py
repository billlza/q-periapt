"""Check the recorded encapsulation chain in the complete source tree."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root=Path.cwd();parent=root/'target/p0-origin-response-frontier-713'
terminal=json.loads((parent/'response-frontier-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out'] and not terminal['accepted']
source=parent/'response-frontier-proof.spthy'
assert hashlib.sha256(source.read_bytes()).hexdigest()==terminal['output_sha256']
value=source.read_text();start=value.index('lemma epoch_generation_secret_derivation_origin ');stop=value.index('\nlemma ',start)
main=value[start:stop];pattern=re.compile(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)')
blocks={m[1]:m[0] for m in pattern.finditer(main)}
assert len(blocks)==18 and main.count('by sorry')==2
row=json.loads((parent/'initial-send-oracle-frames/0000.json').read_text())
raw=(parent/'initial-send-oracle-frames'/row['captured_input']).read_bytes()
assert hashlib.sha256(raw).hexdigest()==row['input_sha256']
goals=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',raw.decode())
assert len(goals)==1
marker='by sorry /* Oracle ranked no proof methods */'
assert blocks['Response_Commit_6'].count(marker)==1
main=main.replace(blocks['Response_Commit_6'],blocks['Response_Commit_6'].replace(marker,'by solve( '+goals[0]+' )',1),1)
full=root/'target/p0-origin-restored-replay-712/restored-origin-proof.spthy'
assert hashlib.sha256(full.read_bytes()).hexdigest()=='121d2751b4fc076aa5b84138d7c20afc0b7867cab98c34dad37c0e2315a1948e'
full_text=full.read_text();full_main=full_text.split('lemma epoch_generation_secret_derivation_origin ',1)[1].split('\nlemma ',1)[0]
snapshot=next(m[0] for m in pattern.finditer(full_main) if m[1]=='Snapshot_case_5')
recorded=json.loads((parent/'PREPARATION.json').read_text())
assert snapshot.count('by sorry')==36 and hashlib.sha256(snapshot.encode()).hexdigest()==recorded['full_snapshot_subtree_sha256']
main=main.replace(blocks['Snapshot_case_5'],snapshot,1)
candidate=value[:start]+main+value[stop:];candidate=candidate.replace(marker,'by sorry')
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',full_text)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-response-restored-713';stage.mkdir()
(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'actual_chain_method':goals[0],'frame_sha256':row['input_sha256'],
    'all29_queries_and_operational_prefix_unchanged':True,'all18_source_cases_retained':True,
    'full_snapshot_subtree_restored_byte_identical':True,'snapshot_subtree_sha256':hashlib.sha256(snapshot.encode()).hexdigest(),
    'snapshot_open_leaves_restored':36,'independent_no_search_replay':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
