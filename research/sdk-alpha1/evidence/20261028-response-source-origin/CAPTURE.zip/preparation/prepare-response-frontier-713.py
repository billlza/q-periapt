"""Capture the remaining response leaf without discarding stored-state progress."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

root=Path.cwd()
source=root/'target/p0-origin-restored-replay-712/restored-origin-proof.spthy'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='121d2751b4fc076aa5b84138d7c20afc0b7867cab98c34dad37c0e2315a1948e'
archive=root/'research/sdk-alpha1/evidence/20261028-wire-and-parent-origins/CAPTURE.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='60ec078cf090c36e96c54d73761768ab03f04f59c91025a82ed1cccf320cf188'
with zipfile.ZipFile(archive) as bundle:
    assert bundle.read('experiments/p0-origin-restored-replay-712/restored-origin-proof.spthy')==data
value=data.decode();start=value.index('lemma epoch_generation_secret_derivation_origin ');stop=value.index('\nlemma ',start)
main=value[start:stop]
blocks={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(blocks)==18 and sum('by sorry' not in b for b in blocks.values())==16
assert blocks['Response_Commit_6'].count('by sorry')==1 and blocks['Snapshot_case_5'].count('by sorry')==36
snapshot=blocks['Snapshot_case_5']
main=main.replace(snapshot,'    case Snapshot_case_5\n    by sorry\n',1)
candidate=value[:start]+main+value[stop:]
assert main.count('by sorry')==2
assert re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',candidate)==re.findall(r'(?ms)^lemma\s+.*?(?=^/\*)',value)
assert hashlib.sha256(candidate[:candidate.index('lemma ')].encode()).hexdigest()=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-response-frontier-713';stage.mkdir()
(stage/'model.spthy').write_text(candidate)
base=root/'target/p0-origin-source-frontiers-705'
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):
    shutil.copy2(base/name,stage/name)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1
driver.write_text(driver.read_text().replace('--bound=13','--bound=7'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)))
(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(source),'full_parent_sha256':hashlib.sha256(data).hexdigest(),
    'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
    'all18_sources_and29_queries_retained':True,'all16_closed_sources_retained':True,
    'snapshot_obligation_explicitly_open':True,'full_snapshot_subtree_sha256':hashlib.sha256(snapshot.encode()).hexdigest(),
    'snapshot_open_leaves_preserved_in_parent':36,'must_restore_full_snapshot_before_final_replay':True,
    'existing_open_prefix_maximum':9,'remaining_search_bound':7,'total_depth_limit':16,
    'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
