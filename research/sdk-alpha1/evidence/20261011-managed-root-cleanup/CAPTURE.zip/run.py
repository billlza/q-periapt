from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
out=Path(__file__).resolve().parent
root=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/peer-account-retirement-process-current/source')
label,mode,*patterns=sys.argv[1:]
run=out/label;run.mkdir()
version='1.90.0' if mode.startswith('msrv') else '1.98.1'
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/(version+'-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/peer-account-retirement-process-current')/('build-msrv' if mode.startswith('msrv') else 'build')),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
command='clippy' if mode.endswith('clippy') else 'test'
args=[str(tc/'bin/cargo'),command,'--manifest-path',str(root/'research/continuity-identity-candidate/Cargo.toml'),'--all-features','--locked','--offline','-j','2']
if command=='clippy':args+=['--all-targets']
else:
 args+=['--lib']
 if mode=='release':args+=['--release']
 args+=[patterns[0] if patterns else ('enrollment::account_root::tests' if mode.endswith('root') else 'managed_root_'), '--','--nocapture','--test-threads=1']
 if len(patterns)>1:
  assert patterns[1:] == ['exact']
  args+=['--exact']
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'research/continuity-identity-candidate/src').rglob('*.rs')}
r={'command':args,'mode':mode,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':files,'completed':False}
(run/'START.json').write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
with (run/'stdout').open('wb') as so,(run/'stderr').open('wb') as se:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=so,stderr=se,start_new_session=True)
 try:code=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise
r.update(returncode=code,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in files.items()))
r['completed']=code==0 and r['source_unchanged'];(run/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='source_sha256'}));print((run/'stdout').read_text()[-1700:]);print((run/'stderr').read_text()[-2500:]);raise SystemExit(0 if r['completed'] else 1)
