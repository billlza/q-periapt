from pathlib import Path
import hashlib,json,re,zipfile
out=Path(__file__).resolve().parent
root=out.parent.parent
implementation='3539694a01000d4beb1ad7fa2c1ea864449534f2'
labels=['current-root','current-retired','current-clippy','current-release','current-msrv-root','current-msrv-clippy']+[f'current-enrollment-{i:02d}' for i in range(16)]
validation=[]
for label in labels:
 record=json.loads((out/label/'RESULT.json').read_text())
 assert record['completed'] and record['source_unchanged'] and record['head']==implementation,label
 for path,digest in record['source_sha256'].items():
  assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,(label,path)
 output=(out/label/'stdout').read_text()
 match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',output)
 validation.append({'label':label,'command':record['command'],'seconds':record['seconds'],'tests':int(match[1]) if match else None,'completed':True,'source_matches_implementation_commit':True})
artifact=json.loads((out/'ARTIFACT_CHECKS.json').read_text())
assert all(record['returncode']==0 and record['head']==implementation for record in artifact)
assert 'Ran 44 tests' in (out/'codeql-inventory.log').read_text()
red=json.loads((out/'callback-unwind-red/RESULT.json').read_text())
green=json.loads((out/'callback-unwind-green/RESULT.json').read_text())
assert red['returncode']!=0 and green['completed']
assert 'state=Ok(Committed), successor_released=true' in (out/'callback-unwind-red/stderr').read_text()
for label in ['current-root','current-msrv-root','current-release']:
 assert (out/label/'stderr').read_text().count('MANAGED_ROOT_CLEANUP_PROCESS action=')==8,label
assert 'SDK_SOURCE_READINESS_PASS' in (out/'source-gate.log').read_text()
evidence=root/'research/sdk-alpha1/evidence/20261011-managed-root-cleanup';evidence.mkdir(parents=True,exist_ok=True)
assert not (evidence/'CAPTURE.zip').exists()
files=[p for p in out.rglob('*') if p.is_file() and p.name!='STATE.json' and (p.suffix in ('.json','.log','.patch','.py') or p.name in ('stdout','stderr'))]
manifest=[]
with zipfile.ZipFile(evidence/'CAPTURE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();name=str(p.relative_to(out));z.writestr(name,data)
  manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=(evidence/'CAPTURE.zip').read_bytes()
checks={'schema':1,'implementation_commit':implementation,'release_claim_eligible':False,
'scope':'Native managed account-root cleanup ownership, historical recovery and successor lifetime. No installed foreign root-lifecycle or full release claim.',
'behavior':[
'One private Original variant owns preparing enrollment, fenced root recovery or retired enrollment; each successful cleanup step retains the same registry.',
'Native historical cleanup remains bound to the original paths, intent, witness and committed proposal/checkpoint. Successful old-signer erasure reopens only that original historical parent.',
'Ordinary preparation, alternate-target and committed-winner adoption resume after journal/signer erasure. Retries preserve revision 2, old-root fencing and independent current successor admission.',
'Preparing/Pending refuse the callback. Missing originals are not recreated. Callback/storage errors close the controller and revoke cached successor access.',
'Operation scope owns the controller until success. Callback unwind drops it and revokes delegated owners while propagating the original panic.',
'Expired successor credentials still refuse activation; independently authorized historical accounting/erasure remains available.'
],
'validation':validation,'artifact_checks':artifact,'source_gate':(out/'source-gate.log').read_text().strip(),'tracked_rust_sources':534,
'new_process_loss_cuts':['inventory/cleanup-parent-before','inventory/cleanup-parent-after','inventory/managed-cleanup-parent-after','inventory/managed-cleanup-return-after','journal/journal-before','journal/journal-after','signer/managed-cleanup-owner-closed-after','signer/managed-cleanup-return-after'],
'process_profiles':'Each of current Debug, minimum Debug and current Release executes all eight new owned-process termination cuts. Existing root/adoption/transition cuts remain in the full root suites.',
'red_green':{'case':'managed_root_cleanup_callback_unwind_revokes_controller_and_cached_successor','red_observation':'The new callback prototype retained state=Ok(Committed) and successor_released=true after the host caught an unwind.','cause':'The shared operation helper borrowed the live controller rather than owning it for the operation scope.','green':'Take the controller into local ownership and restore it only on Ok. Err/unwind drops its registry and old parent. Panic is not swallowed or converted to success.','scope':'Observed on the new callback prototype; not a claim that every older transport panic path was independently reproduced.'},
'maintainability':{'production_rust_added':357,'production_rust_removed':163,'test_rust_added':538,'test_rust_removed':3,'notes':'Reuse the native cleanup engine, model mutually exclusive original owners explicitly, and share original-file admission without granting ordinary access. No new storage format or product C ABI; no throughput, stack-size or energy claim.'},
'iterations_retained':['The first process-test attempt referenced a nonexistent JournalAccountAuthority checkpoint getter. It was replaced with the existing authenticated idempotent receipt result, without adding a product API for a test.','The callback unwind test failed on the actual prototype, then passed after scoped controller ownership was implemented.'],
'limits':['Fresh same-host macOS arm64 fixtures and controlled logical times, not deployed control-plane transport, independent protocol implementation or physical/minimum-device qualification.','958 native library tests exist in this source; this record covers the selected suites, not a new full-library run. Counts include subprocess helpers.','16 direct ordinary enrollment tests were individually selected with --exact; nested renewal suites were not rerun in full. Historical retirement tests cover the reused cleanup path.','The 2719 artifact tests passed on prior 69a807ef; this change reruns the relevant 44 inventory tests and current source gate, not that complete artifact suite.','Installed C/Swift/Kotlin root lifecycle still needs consuming ownership/admission integration and actual package qualification.','Logical erasure excludes retained pages, backups, wrapping keys and previously copied signing owners.','The remote 3b654771 CodeQL run is observed separately. Local validation is not current-head CI or a completed external security review.'],
'archive':{'path':'CAPTURE.zip','bytes':len(archive),'sha256':hashlib.sha256(archive).hexdigest(),'members':manifest}}
(evidence/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
with zipfile.ZipFile(evidence/'CAPTURE.zip') as z:
 assert z.testzip() is None
 for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
print(json.dumps({'evidence':str(evidence),'bytes':len(archive),'sha256':checks['archive']['sha256'],'members':len(manifest)},indent=2))
