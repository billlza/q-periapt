from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent
root=out.parent.parent
binary=root/'target/peer-account-retirement-process-current/build/debug/deps/q_periapt_continuity_identity_candidate-bfa6d97d9902ee7a'
lines=subprocess.check_output([str(binary),'--list'],text=True).splitlines()
tests=[line[:-6] for line in lines if line.startswith('enrollment::tests::') and line.endswith(': test') and len(line.split('::'))==3]
assert len(tests)==16,tests
(out/'DIRECT_ENROLLMENT_SELECTION.json').write_text(json.dumps({'selection':'Only the 16 direct enrollment tests; nested renewal suites are separately scoped. No test was disabled.','tests':tests},indent=2)+'\n')
for index,test in enumerate(tests):
 subprocess.run([sys.executable,'-B',str(out/'run.py'),f'current-enrollment-{index:02d}','focused',test,'exact'],check=True)
print('DIRECT_ENROLLMENT_PASS count=16')
