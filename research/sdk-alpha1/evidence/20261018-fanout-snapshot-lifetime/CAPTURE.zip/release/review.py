from pathlib import Path
import csv,hashlib,json,re,statistics,sys
out=Path(__file__).resolve().parent;root=out.parents[1]
record=json.loads((out/'PAIRED_EXECUTION.json').read_text());assert len(record['sequence'])==10
pattern=re.compile(r'^fanout_path_sample same_account=(false|true) sample=(\d+) plaintext=(\d+) ad=(\d+) recipients=(\d+) elapsed_ns=(\d+) rust_live_before=(\d+) rust_live_after=(\d+) rust_peak=(\d+) rust_before_resume=(\d+)$',re.M)
for variant in ('baseline','release-snapshots'):
 log=(root/'target/fanout-snapshot-measure-01'/(variant+'-optimized-fixed.stderr')).read_text()
 assert not re.search(r'(?mi)^\s*(warning:|error:)',log)
 assert 'Finished `release` profile [optimized]' in log
 probe=(root/'target/fanout-snapshot-measure-01'/(variant+'-objcopy.stdout')).read_text()
 assert '22.1.8-rust-1.98.1-stable' in probe
rows=[]
for item in record['sequence']:
 label=f"block-{item['block']}-{item['variant']}"
 stdout=(out/(label+'.stdout')).read_bytes();stderr=(out/(label+'.stderr')).read_text()
 assert stdout.count(b'1 passed; 0 failed; 0 ignored; 0 measured; 1036 filtered out;')==1
 assert not re.search(r'(?mi)^\s*(warning:|error:)',stderr)
 found=pattern.findall(stderr);assert len(found)==12
 for index,values in enumerate(found):
  same=values[0];sample,payload,ad,recipients,elapsed,before,after,peak,before_resume=map(int,values[1:])
  assert same==('false' if index<6 else 'true') and sample==index%6
  assert (payload,ad)==((0,0),(1024,32),(16384,1024))[sample%3] and recipients==2 and elapsed>0
  assert peak>=max(before,after,before_resume)>0
  rows.append(dict(block=item['block'],variant=item['variant'],same_account=same=='true',sample=sample,plaintext=payload,ad=ad,recipients=recipients,elapsed_ns=elapsed,live_before=before,live_after=after,peak_requested=peak,peak_growth=peak-before,before_resume=before_resume))
with (out/'SAMPLES.csv').open('x',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary=[]
for same in (False,True):
 for sample in range(6):
  base=[r for r in rows if r['same_account']==same and r['sample']==sample and r['variant']=='baseline']
  new=[r for r in rows if r['same_account']==same and r['sample']==sample and r['variant']=='modified']
  assert len(base)==len(new)==5
  for left,right in zip(base,new):
   assert left['block']==right['block'] and left['live_before']==right['live_before'] and left['live_after']==right['live_after']
  b=statistics.median(r['peak_growth'] for r in base);n=statistics.median(r['peak_growth'] for r in new)
  released=statistics.median(l['before_resume']-r['before_resume'] for l,r in zip(base,new))
  summary.append({'same_account':same,'sample':sample,'plaintext':base[0]['plaintext'],'ad':base[0]['ad'],'baseline_peak_growth_median_bytes':b,'modified_peak_growth_median_bytes':n,'peak_growth_reduction_bytes':b-n,'peak_growth_reduction_percent':100*(b-n)/b,'earlier_release_before_resume_bytes':released,'baseline_peak_growth_range':[min(r['peak_growth'] for r in base),max(r['peak_growth'] for r in base)],'modified_peak_growth_range':[min(r['peak_growth'] for r in new),max(r['peak_growth'] for r in new)]})
for name,digest in record['binary_sha256'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
expected=json.loads((root/'target/fanout-snapshot-measure-01/ORIGINAL_SOURCE.json').read_text())['files']
source=root/'target/windows-installed-445-01/input/packages/q-periapt-continuity-identity-candidate-0.0.0'
for name,digest in expected.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
report={'source_head':record['source_head'],'scope':'Isolated Release/all-features native DeviceJournal two-recipient fanout allocation observation; requested Rust allocator bytes only. No process RSS/C allocator/latency/foreign/device performance claim; no product change adopted.','profile':'release all-features','blocks':5,'variants':2,'samples_per_variant':60,'same_account_modes':2,'recipients':2,'all_original_ciphertext_AD_restart_assertions_passed':True,'live_before_and_after_match_each_pair':True,'binary_sha256':record['binary_sha256'],'source_delta':'Only drop(batch),drop(selected),drop(image) after successful reservation persistence and before original resume call; identical test instrumentation and dependency manifests/locks. Current worktree unchanged.','rejected_attempts':['First optimized builds passed tests but emitted rust-objcopy strip warnings because libLLVM.dylib was not found; excluded from the paired comparison. The same pinned toolchain now passes its objcopy probe with the correct process-local DYLD_FALLBACK_LIBRARY_PATH, and both affected targets were rebuilt. Rejected binaries and logs are retained in the Debug experiment directory.'],'samples':summary,'remaining':'Need existing fanout failure/concurrency/managed/witness regressions, async/WASM checks and retry-existing-batch lifetime assessment before adopting. No benchmark- or observer-specific code may enter product path.'}
with (out/'REVIEW.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'rows':len(rows),'peak_growth_reduction_percent_range':[min(r['peak_growth_reduction_percent'] for r in summary),max(r['peak_growth_reduction_percent'] for r in summary)],'earlier_release_bytes_range':[min(r['earlier_release_before_resume_bytes'] for r in summary),max(r['earlier_release_before_resume_bytes'] for r in summary)],'product_changed':False}))
