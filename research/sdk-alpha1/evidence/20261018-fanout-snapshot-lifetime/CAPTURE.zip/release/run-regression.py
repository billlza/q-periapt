from pathlib import Path
import hashlib,json,re,subprocess
out=Path(__file__).resolve().parent;binary=out/'modified.bin';digest=hashlib.sha256(binary.read_bytes()).hexdigest()
record=json.loads((out/'PAIRED_EXECUTION.json').read_text());assert digest==record['binary_sha256']['modified.bin']
listing=subprocess.run([str(binary),'--list'],capture_output=True,timeout=30,check=False)
(out/'test-catalog.stdout').write_bytes(listing.stdout);(out/'test-catalog.stderr').write_bytes(listing.stderr)
assert listing.returncode==0 and not listing.stderr
prefix='durable::messages::tests::fanout::'
expected={line.removesuffix(': test') for line in listing.stdout.decode().splitlines() if line.startswith(prefix) and line.endswith(': test')}
assert expected
argv=[str(binary),prefix,'--nocapture','--test-threads=1']
with (out/'regression.stdout').open('xb') as stdout,(out/'regression.stderr').open('xb') as stderr:
 result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=600,check=False)
with (out/'REGRESSION_COMMAND.json').open('x') as f:json.dump({'argv':argv,'returncode':result.returncode,'expected_tests':sorted(expected),'binary_sha256':digest},f,indent=2);f.write('\n')
assert result.returncode==0
stdout=(out/'regression.stdout').read_text();passed=re.findall(r'^test (\S+) \.\.\. ok$',stdout,re.M)
assert len(passed)==len(expected) and set(passed)==expected
assert re.search(rf'test result: ok\. {len(expected)} passed; 0 failed; 0 ignored;',stdout)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
print(json.dumps({'passed':len(expected),'all_original_fanout_tests':True,'profile':'release all-features instrumented','product_changed':False}))
