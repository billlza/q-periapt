from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[1];sys.path.insert(0,str(root/'artifact'))
from installed_rust_graph import external_lock
log=(out/'candidate-isolated.stderr').read_text();assert not re.search(r'(?mi)^\s*(warning:|error:)',log)
source=Path(re.search(r'Running unittests src/lib.rs \(([^\n]+)\)',log).group(1));source=source if source.is_absolute() else root/source
shutil.copyfile(out/'baseline-observer',out/'baseline.bin');shutil.copyfile(source,out/'modified.bin')
for name in ('baseline.bin','modified.bin'):(out/name).chmod(0o755)
identities={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ('baseline.bin','modified.bin')}
assert len(set(identities.values()))==2,'candidate reused baseline binary'
assert (out/'baseline/Cargo.toml').read_bytes()==(out/'release-snapshots/Cargo.toml').read_bytes()
assert (out/'baseline/Cargo.lock').read_bytes()==(out/'release-snapshots/Cargo.lock').read_bytes()
original=external_lock((root/'target/windows-installed-445-01/input/packages/q-periapt-continuity-identity-candidate-0.0.0/Cargo.lock').read_bytes())
resolved=external_lock((out/'release-snapshots/Cargo.lock').read_bytes())
assert all(original.get(k)==v for k,v in resolved.items())
a=(out/'baseline/src/durable/messages/fanout.rs').read_text();b=(out/'release-snapshots/src/durable/messages/fanout.rs').read_text()
assert b.replace('        drop(batch);\n        drop(selected);\n        drop(image);\n','')==a
for path in (out/'baseline/src').rglob('*.rs'):
 other=out/'release-snapshots/src'/path.relative_to(out/'baseline/src')
 if path.name!='fanout.rs' or path.parent.name!='messages':assert path.read_bytes()==other.read_bytes(),path
sequence=[];test='durable::messages::tests::fanout::account_fanout_payload_boundaries_match_individual_traffic_and_restart'
for block in range(5):
 order=('baseline','modified') if block%2==0 else ('modified','baseline')
 for variant in order:
  label=f'block-{block}-{variant}';argv=[str(out/(variant+'.bin')),'--exact',test,'--nocapture','--test-threads=1']
  with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
   result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=90,check=False)
  assert result.returncode==0,(label,result.returncode)
  assert b'1 passed; 0 failed; 0 ignored; 0 measured; 986 filtered out;' in (out/(label+'.stdout')).read_bytes()
  sequence.append({'block':block,'variant':variant,'argv':argv,'returncode':result.returncode})
  print(label+' passed',flush=True)
assert identities=={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in identities}
with (out/'PAIRED_EXECUTION.json').open('x') as f:json.dump({'source_head':'44528b0ef2edfc5fc933129801c0fc2633f0d8b4','profile':'dev','instrumentation':'Rust requested allocation bytes only; not C allocator, RSS, latency or release/device qualification','binary_sha256':identities,'sequence':sequence},f,indent=2);f.write('\n')
