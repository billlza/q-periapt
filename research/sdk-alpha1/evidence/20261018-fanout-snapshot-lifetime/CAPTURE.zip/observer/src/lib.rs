use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static BEFORE_RESUME: AtomicUsize = AtomicUsize::new(0);
pub struct Observer;
fn add(bytes: usize) {
    let now = LIVE.fetch_add(bytes, SeqCst) + bytes;
    PEAK.fetch_max(now, SeqCst);
}
// Test-only allocator observation. Every operation forwards unchanged to System;
// no foreign pointer is dereferenced or allocated layout replaced.
unsafe impl GlobalAlloc for Observer {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) };
        LIVE.fetch_sub(layout.size(), SeqCst);
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let result = unsafe { System.realloc(ptr, layout, size) };
        if !result.is_null() {
            if size >= layout.size() { add(size-layout.size()); }
            else { LIVE.fetch_sub(layout.size()-size, SeqCst); }
        }
        result
    }
}
pub fn begin() -> usize {
    let live=LIVE.load(SeqCst); PEAK.store(live,SeqCst); BEFORE_RESUME.store(0,SeqCst); live
}
pub fn mark_resume() { BEFORE_RESUME.store(LIVE.load(SeqCst),SeqCst); }
pub fn snapshot() -> (usize,usize,usize) {
    (LIVE.load(SeqCst),PEAK.load(SeqCst),BEFORE_RESUME.load(SeqCst))
}
