# Fanout snapshot lifetime review

This isolated uninstrumented candidate starts from the archive verified against
44528b0ef2edfc5fc933129801c0fc2633f0d8b4. Its 372 other Rust source files and all
original tests are unchanged. The working tree product source is unchanged.

`send_account_message` loads and validates an Image. For a new batch it selects
recipient states, records every SendPlan, and awaits successful persist before
calling resume, which reloads and reauthorizes the journal. The candidate drops
Batch, Selected states and Image immediately before that existing resume call.
The original test crash marker remains before these drops. All persist failures
still return through the original error path; there is no early success.

On the existing-batch branch, account and exact original intent comparisons stay
before dropping Batch and Image. Resume still reloads the current journal and
performs the original full recipient/roster/authority/release checks. No permission
or decoded snapshot is cached across resume.

Image owns decoded records and a verification cache. It holds cloned authority
access and enrollment-completion Arcs. Active retains their originals along with
the database, journal key, owner and anchor. Selected owns decoded cryptographic
state and borrows context/device references. Batch owns its intent and member
vector. These types have no custom Drop that commits or unlocks a database.
Earlier destruction releases decoded buffers and invokes their existing zeroizing
destructors; it does not close Active, change the journal schema, or promise
physical/cryptographic erasure of retained database pages or backups.

Code locations in the unchanged archive: durable.rs Image/Active at 582/617,
image_attempt at 845 and persist at 862; durable/account_authority.rs attach at
127; account_authority/runtime.rs AccountAuthorityAccess at 69;
durable/messages/fanout.rs Selected at 168; durable/messages.rs State at 173;
durable/messages/fanout/codec.rs Batch at 23.

The prior paired allocation experiment measured only the new-batch branch on
native macOS, with an identical test-only allocator observer in both variants.
The additional retry drop is not covered by that numerical performance claim.
This candidate instead reuses the unchanged 56-test native fanout regression and
checks the real WASM async target. Compilation is not browser execution.
