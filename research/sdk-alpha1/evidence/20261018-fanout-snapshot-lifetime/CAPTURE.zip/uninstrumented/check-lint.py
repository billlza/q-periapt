from pathlib import Path
import json,os,re,subprocess,time
out=Path(__file__).resolve().parent
src=out/'source'
toolchain=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env=dict(os.environ)
env.update(PATH=str(toolchain/'bin')+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'),CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_TARGET_DIR=str(out/'build-native'),CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings')
args=['cargo','clippy','--offline','--locked','--release','--all-features','--lib','--','-D','warnings']
start=time.monotonic()
with (out/'clippy.stdout').open('xb') as stdout,(out/'clippy.stderr').open('xb') as stderr:
 proc=subprocess.run(args,cwd=src,env=env,stdout=stdout,stderr=stderr,timeout=600,check=False)
(out/'CLIPPY_COMMAND.json').write_text(json.dumps({'argv':args,'cwd':str(src),'returncode':proc.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
assert proc.returncode==0
assert not re.search(r'(?mi)^\s*(warning:|error:)',(out/'clippy.stdout').read_text()+(out/'clippy.stderr').read_text())
print('Uninstrumented release/all-features library Clippy passed')
