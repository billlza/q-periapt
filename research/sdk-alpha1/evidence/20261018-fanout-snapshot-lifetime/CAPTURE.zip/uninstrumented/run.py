from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time
out=Path(__file__).resolve().parent
root=out.parents[1]
src=out/'source'
toolchain=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env=dict(os.environ)
env.update(PATH=str(toolchain/'bin')+':'+env['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'), CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never', CC_wasm32_unknown_unknown='/opt/homebrew/opt/llvm/bin/clang')
mode=sys.argv[1]
env['CARGO_TARGET_DIR']=str(out/('build-'+mode))
def run(label,args,timeout):
 start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
  proc=subprocess.run(args,cwd=src,env=env,stdout=stdout,stderr=stderr,timeout=timeout,check=False)
 receipt={'argv':args,'cwd':str(src),'returncode':proc.returncode,'seconds':time.monotonic()-start}
 (out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 assert proc.returncode==0,receipt
 streams=(out/(label+'.stdout')).read_text()+(out/(label+'.stderr')).read_text()
 assert not re.search(r'(?mi)^\s*(warning:|error:)',streams),label
 print(label+' passed',flush=True)
 return streams
if mode=='prepare':
 run('objcopy-probe',[str(toolchain/'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'),'--version'],30)
 run('metadata',['cargo','metadata','--offline','--format-version','1'],180)
 sys.path.insert(0,str(root/'artifact'))
 from installed_rust_graph import external_lock
 original=external_lock((root/'target/windows-installed-445-01/input/packages/q-periapt-continuity-identity-candidate-0.0.0/Cargo.lock').read_bytes())
 actual=external_lock((src/'Cargo.lock').read_bytes())
 assert original==actual,'external lock changed'
 run('format',['rustfmt','--check','--edition','2021','src/durable/messages/fanout.rs'],30)
 (out/'LOCK_REVIEW.json').write_text(json.dumps({'external_lock_exact':True,'external_packages':len(actual),'lock_sha256':hashlib.sha256((src/'Cargo.lock').read_bytes()).hexdigest()},indent=2)+'\n')
elif mode=='native':
 log=run('native-build',['cargo','test','--offline','--locked','--release','--all-features','--lib','--no-run'],900)
 binary=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]+)\)',log).group(1))
 if not binary.is_absolute():binary=src/binary
 digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 catalog=run('test-catalog',[str(binary),'--list'],30)
 prefix='durable::messages::tests::fanout::'
 expected={line.removesuffix(': test') for line in catalog.splitlines() if line.startswith(prefix) and line.endswith(': test')}
 assert len(expected)==56
 result=run('regression',[str(binary),prefix,'--nocapture','--test-threads=1'],600)
 passed=re.findall(r'^test (\S+) \.\.\. ok$',result,re.M)
 assert len(passed)==len(expected) and set(passed)==expected
 assert re.search(r'test result: ok\. 56 passed; 0 failed; 0 ignored;',result)
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
 (out/'NATIVE_REVIEW.json').write_text(json.dumps({'passed':56,'profile':'release all-features','binary':str(binary),'sha256':digest,'instrumentation':False,'changed_source':'src/durable/messages/fanout.rs','original_tests_unchanged':True},indent=2)+'\n')
elif mode=='wasm':
 run('wasm-check',['cargo','check','--offline','--locked','--lib','--target','wasm32-unknown-unknown'],900)
else:raise ValueError(mode)
