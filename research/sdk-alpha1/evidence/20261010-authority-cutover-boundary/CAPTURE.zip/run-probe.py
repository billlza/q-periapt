from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

base = Path(__file__).resolve().parent
source = base / 'source'
start_record = json.loads((base / 'START.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == start_record['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source).strip()
rust = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
subprocess.run([str(rust / 'bin/rustfmt'), '--edition', '2021', str(base / 'PROBE.rs')], check=True)
probe = (base / 'PROBE.rs').read_bytes()
test_file = source / 'research/continuity-identity-candidate/src/tests.rs'
original = test_file.read_bytes()
test_file.write_bytes(original + b'\n' + probe)
out = base / 'probe-01'
out.mkdir(mode=0o700)
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO', 'RUST', 'QPERIAPT', 'QPC', 'DYLD', 'LD_', 'JAVA', 'GRADLE', 'KOTLIN', 'PYTHON'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(base / 'build'), RUSTC=str(rust / 'bin/rustc'), RUSTDOC=str(rust / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings', PATH=str(rust / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', DYLD_FALLBACK_LIBRARY_PATH=str(rust / 'lib'))
record = dict(start_record, completed=False, probe_sha256=hashlib.sha256(probe).hexdigest(), original_test_file_sha256=hashlib.sha256(original).hexdigest(), instrumented_test_file_sha256=hashlib.sha256(test_file.read_bytes()).hexdigest(), runs=[])
(out / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
common = [str(rust / 'bin/cargo'), 'test', '--manifest-path', str(source / 'research/continuity-identity-candidate/Cargo.toml'), '--locked', '--offline', '--release', '--all-features', '--lib', '-j', '2']
for label, test, expected in [('authority-boundaries', 'authority_cutover_probe_', 5), ('pinned-root-control', 'attacker_self_signature_cannot_replace_the_pinned_root', 1)]:
    argv = common + [test, '--', '--nocapture', '--test-threads=1']
    started = time.monotonic()
    timed_out = False
    with (out / (label + '.stdout')).open('wb') as stdout, (out / (label + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=source, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            result = process.wait(timeout=900)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                result = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                result = process.wait()
    log = (out / (label + '.stdout')).read_text()
    check = {'label': label, 'command': argv, 'returncode': result, 'timed_out': timed_out, 'seconds': time.monotonic() - started, 'expected_tests': expected, 'expected_summary_present': f'test result: ok. {expected} passed; 0 failed; 0 ignored;' in log}
    record['runs'].append(check)
    (out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(check), flush=True)
    if result or timed_out or not check['expected_summary_present']:
        raise SystemExit(1)
assert test_file.read_bytes() == original + b'\n' + probe
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=source, text=True).splitlines()
assert changed == ['research/continuity-identity-candidate/src/tests.rs']
record.update(completed=True, only_isolated_test_module_changed=True)
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print('Authority boundary experiment complete; no root-replacement implementation or full restart claim.', flush=True)
