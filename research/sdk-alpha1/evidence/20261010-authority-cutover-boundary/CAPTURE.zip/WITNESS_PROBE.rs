// Composition counterexample, not an unauthorized enrollment: every enrollment
// below is an explicit trusted-control-plane call on the actual persistent store.
#[test]
fn authority_cutover_probe_device_retirement_and_new_root_enrollment_are_not_root_retirement() {
    let mut c = required_case();
    let next = fresh(&c, 2, 2, 180);
    let proposal = first_proposal(&mut c, &next);
    assert_eq!(
        commit(&mut c, &proposal, &next, 150).unwrap(),
        State::Committed
    );
    assert_retired(&mut c, AnchorOperation::query());

    let policy = c
        .peer
        .responder
        .current_policy()
        .expect("unchanged required witness policy");
    let old = c.peer.responder.inventory_inputs().unwrap().1;
    let root = crate::RootSigningKey::deterministic([191; 32], [192; 32]).unwrap();
    let signer = DeviceSigningKey::deterministic([193; 32], [194; 32]).unwrap();
    let certificate = root
        .issue_device(old.description.clone(), signer.public_key().unwrap())
        .unwrap();
    let member = root.roster_entry(&certificate).unwrap();
    let roster = root
        .issue_roster(1, old.roster_validity, &[member])
        .unwrap();
    let target_pin = crate::AccountPin::new(
        root.account_id().unwrap(),
        root.public_key().unwrap(),
        roster.checkpoint(),
        old.description.family,
    )
    .unwrap();
    let device = target_pin
        .verify_device(&certificate, roster.as_bytes(), 150)
        .unwrap();
    assert_ne!(device.account_id(), old.account_id());
    let new_root = fresh_journal(&c, policy, device, signer, 195);
    c.store
        .enroll(&new_root.genesis, &new_root.device, policy, 150)
        .expect("independently approved different account can enroll");

    // The old root can still describe a new device under that old account.
    // This explicit control-plane call deliberately retains old-root trust.
    let mut description = old.description.clone();
    description.id = [213; 16];
    let (device, signer) = signed_device(old, description, 3, 196, &[]);
    assert_eq!(device.account_id(), old.account_id());
    assert_ne!(device.device_id(), old.device_id());
    let unseen = fresh_journal(&c, policy, device, signer, 198);
    c.store
        .enroll(&unseen.genesis, &unseen.device, policy, 150)
        .expect("device retirement does not create an account-wide root floor");
    assert_eq!(query(&mut c, &new_root).outcome(), AnchorOutcome::Current);
    assert_eq!(query(&mut c, &unseen).outcome(), AnchorOutcome::Current);
    assert_retired(&mut c, AnchorOperation::query());
    c.store.close();
    c.store = reopen(&c.server);
    assert_eq!(query(&mut c, &new_root).outcome(), AnchorOutcome::Current);
    assert_eq!(query(&mut c, &unseen).outcome(), AnchorOutcome::Current);
    assert_retired(&mut c, AnchorOperation::query());
    println!("AUTHORITY_CUTOVER_WITNESS original_device_retired=true new_root_current=true unseen_old_root_device_current=true actual_database_reopened=true trusted_control_plane=true");
}
