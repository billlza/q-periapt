// Isolated construction probe; appended only to the frozen source copy's tests module.
fn cutover_successor() -> Fixture {
    let root = RootSigningKey::deterministic([21; 32], [22; 32]).expect("new root");
    let signer = DeviceSigningKey::deterministic([3; 32], [4; 32]).expect("same device key");
    let validity = Validity::new(100, 300).expect("new validity");
    let description = DeviceDescription::new([5; 16], 1, [6; 32], validity).expect("description");
    let certificate = root
        .issue_device(description, signer.public_key().expect("device public"))
        .expect("new certificate");
    let entry = root.roster_entry(&certificate).expect("new membership");
    let roster = root
        .issue_roster(2, validity, &[entry])
        .expect("new roster");
    let pin = AccountPin::new(
        root.account_id().expect("new account"),
        root.public_key().expect("new root public"),
        roster.checkpoint(),
        [6; 32],
    )
    .expect("independent target pin");
    Fixture {
        root,
        signer,
        certificate,
        roster,
        pin,
    }
}

#[test]
fn authority_cutover_probe_root_change_changes_account_namespace() {
    let old = fixture();
    let new = cutover_successor();
    assert!(old.signer.public_key().unwrap() == new.signer.public_key().unwrap());
    assert_ne!(
        old.root.account_id().unwrap(),
        new.root.account_id().unwrap()
    );
    fail(
        AccountPin::new(
            old.root.account_id().unwrap(),
            new.root.public_key().unwrap(),
            new.roster.checkpoint(),
            [6; 32],
        ),
        Error::Scope,
    );
    let target = device(&new);
    assert_eq!(target.account_id(), new.root.account_id().unwrap());
    println!("AUTHORITY_CUTOVER namespace_changed=true same_device_key=true old_account_new_root_refused=true");
}

#[test]
fn authority_cutover_probe_new_pin_and_signer_close_do_not_revoke_old_trust() {
    let mut old = fixture();
    let new = cutover_successor();
    let original = device(&old);
    let saved = original.roster().journal_bytes();
    let target = device(&new);
    assert_ne!(original.account_id(), target.account_id());
    old.root.close();
    assert!(matches!(old.root.public_key(), Err(Error::Closed)));
    old.pin
        .verify_device(&old.certificate, old.roster.as_bytes(), 150)
        .expect("an immutable old pin is still an independently trusted input");
    original
        .roster()
        .authorize_device(&original, 150)
        .expect("cached original authorization remains valid");
    let restored =
        VerifiedRoster::from_journal(&saved).expect("original authenticated roster bytes");
    restored
        .authorize_device(&original, 150)
        .expect("old roster decoding does not consult an account replacement registry");
    assert_eq!(restored.journal_bytes(), saved);
    println!("AUTHORITY_CUTOVER new_pin_valid=true root_signer_closed=true old_pin_valid=true cached_roster_valid=true original_roster_decoder_valid=true");
}

#[test]
fn authority_cutover_probe_storage_and_roster_bindings_cannot_be_relabelled() {
    let old = device(&fixture());
    let new = device(&cutover_successor());
    assert_ne!(
        crate::bootstrap::storage_owner(&old),
        crate::bootstrap::storage_owner(&new)
    );
    fail(new.roster().authorize_device(&old, 150), Error::Scope);
    fail(old.roster().authorize_device(&new, 150), Error::Scope);
    old.roster()
        .authorize_device(&old, 150)
        .expect("old control");
    new.roster()
        .authorize_device(&new, 150)
        .expect("new control");
    println!("AUTHORITY_CUTOVER storage_owner_changed=true crossed_rosters_refused=true matched_rosters_accepted=true");
}

#[test]
fn authority_cutover_probe_same_key_credential_renewal_cannot_change_root() {
    let old = fixture();
    let new = cutover_successor();
    let authorization = CredentialRenewalAuthorization {
        operation: CredentialRenewalId::from_trusted_state([71; 32]).unwrap(),
        previous: old.roster.checkpoint(),
        policy_digest: [72; 32],
    };
    let materials = || CredentialRenewalMaterials {
        original_credential: &old.certificate,
        previous_credential: &old.certificate,
        successor_credential: &new.certificate,
        previous_roster: old.roster.as_bytes(),
        successor_roster: new.roster.as_bytes(),
    };
    fail(
        old.root
            .issue_credential_renewal(materials(), &authorization, &new.pin, 150),
        Error::Scope,
    );
    fail(
        new.root
            .issue_credential_renewal(materials(), &authorization, &new.pin, 150),
        Error::Authentication,
    );
    println!(
        "AUTHORITY_CUTOVER old_issuer_new_pin_refused=true new_issuer_old_credential_refused=true"
    );
}

#[test]
fn authority_cutover_probe_witness_key_change_changes_exact_authority_binding() {
    use crate::anchor::{AnchorIdentity, AnchorPin};
    let identity = AnchorIdentity::from_trusted_state([81; 32]).unwrap();
    let old = AnchorSigningKey::deterministic([82; 32], [83; 32]).unwrap();
    let new = AnchorSigningKey::deterministic([84; 32], [85; 32]).unwrap();
    let old_pin = AnchorPin::new(identity, old.public_key().unwrap());
    let new_pin = AnchorPin::new(identity, new.public_key().unwrap());
    assert_eq!(old_pin.identity(), new_pin.identity());
    assert_ne!(old_pin.binding(), new_pin.binding());
    assert_eq!(
        old_pin.binding(),
        AnchorPin::new(identity, old.public_key().unwrap()).binding()
    );
    println!("AUTHORITY_CUTOVER witness_instance_unchanged=true witness_key_binding_changed=true");
}
