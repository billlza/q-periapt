"""Retain only public execution records and the isolated diagnostic history."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
import io

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "artifact"))
import continuity_package_archive as archives
import continuity_c_witness_openssl as openssl
import continuity_c_witness_tls as tls

work = Path(__file__).resolve().parent
destination = ROOT / "research/sdk-alpha1/evidence/20261104-openssl-witness-census"
destination.mkdir()
data = {}
for name in ("original-verifier.py", "run_installed_01.py", "run_installed.py", "continue_installed.py",
             "capture_evidence.py", "repair.patch", "red.stdout", "red.stderr", "red-configured.stdout",
             "red-configured.stderr", "green.stdout", "green.stderr", "installed-driver.stdout",
             "installed-driver.stderr", "installed-driver-02.stdout", "installed-driver-02.stderr",
             "installed-driver-03.stdout", "installed-driver-03.stderr"):
    data["diagnostic/" + name] = (work / name).read_bytes()
for attempt in ("installed-01", "installed-02", "installed-03"):
    for path in sorted((work / attempt).iterdir()):
        if path.is_file() and (path.suffix in (".json", ".stdout", ".stderr", ".events", ".crate")
                               or path.name == "consumer-Cargo.lock"):
            data[attempt + "/" + path.name] = path.read_bytes()
    for path in sorted((work / attempt / "public").rglob("*")):
        if path.is_file():
            data[attempt + "/" + path.relative_to(work / attempt).as_posix()] = path.read_bytes()
for name in ("artifact/continuity_c_witness_openssl.py", "artifact/continuity_c_witness_tls.py",
             "artifact/test_continuity_c_witness_openssl.py", "bindings/c/ContinuityPackageConsumer/tests/witness/openssl.rs",
             "bindings/c/ContinuityPackageConsumer/tests/common/openssl_host.rs",
             "research/continuity-identity-candidate/src/connection_transport/server.rs",
             "research/continuity-identity-candidate/src/connection_transport/client.rs",
             "research/continuity-identity-candidate/src/durable/messages/acknowledgement.rs",
             "research/continuity-identity-candidate/src/durable.rs",
             "research/continuity-identity-candidate/src/durable/anchoring.rs",
             "research/continuity-identity-candidate/src/durable/rosters.rs"):
    data["source/" + name] = (ROOT / name).read_bytes()
final = json.loads((work / "installed-03/RESULT.json").read_bytes())
assert final["completed"] is True
summary = {"schema": "qperiapt-openssl-witness-census/1", "completed": True,
           "source_base": final["source_commit"], "source_patch_sha256": hashlib.sha256(data["diagnostic/repair.patch"]).hexdigest(),
           "scope": final["scope"], "release_claim_eligible": False,
           "full_package_qualified": False, "host": "macOS Apple Silicon",
           "sdk_input": {"run": 41791854684, "job": 126446831250, "artifact": 13304914186,
                         "archive_sha256": final["sdk_zip_sha256"], "source_commit": final["source_commit"]},
           "regression_tests": {"passed": 24, "ignored": 0, "red_retained": True},
           "execution": {}, "failed_attempts_retained": [
               "Python entrypoint without explicit interpreter refused before tests",
               "original verifier red regression: correct 146 rejected and old 142 accepted",
               "isolated diagnostic 01: exclusive result writer used twice; no product test executed",
               "isolated diagnostic 02: three Debug OpenSSL tests passed; native TLS then rejected explicit C language environment",
           ], "continuation": "03 rechecks exact prepared inputs and Debug public exports; uses default C environment; completes Debug native TLS and all Release scenarios"}
for profile in ("debug", "release"):
    root = work / ("installed-02" if profile == "debug" else "installed-03")
    rows = {}
    for kind in openssl.TESTS:
        stdout = (root / (profile + "-" + kind + ".stdout")).read_bytes()
        checked = openssl.verify_execution(kind, stdout, root / "public" / profile / kind)
        rows[kind] = {k: checked[k] for k in ("completed", "witness_exchanges", "exchanges", "outcomes", "cases", "store_calls") if k in checked}
    root = work / "installed-03"
    checked = tls.verify_execution((root / (profile + "-native-tls.stdout")).read_bytes(), root / "public" / profile / "native-tls")
    rows["native_tls"] = {"completed": checked["completed"], "witness_exchanges": checked["witness_exchanges"]}
    rows["old_verifier_rejected_same_server_bytes"] = final["execution"][profile]["original_verifier"]
    summary["execution"][profile] = rows
blob = archives.archive(data)
with zipfile.ZipFile(io.BytesIO(blob)) as zipped:
    assert set(zipped.namelist()) == set(data)
    assert all(zipped.read(name) == value for name, value in data.items())
(destination / "CAPTURE.zip").write_bytes(blob)
summary["capture"] = {"sha256": hashlib.sha256(blob).hexdigest(), "bytes": len(blob), "members": len(data),
                      "all_members_read_back": True}
(destination / "VERIFICATION.json").write_text(json.dumps(summary, indent=2) + "\n")
(destination / "MEMBERS.json").write_text(json.dumps({name: hashlib.sha256(value).hexdigest() for name, value in data.items()}, indent=2) + "\n")
print(json.dumps(summary, indent=2))
