"""Focused installed C/Rust/OpenSSL regression using the existing package helpers.

This runs the three existing OpenSSL tests in both profiles, not full package qualification.
Private generated owners remain in a fresh private installation outside the checkout.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tempfile
import time
import types
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "artifact"))
import continuity_c_consumer as c
import continuity_c_witness_openssl as openssl
import continuity_c_witness_tls as tls
import continuity_package as package
import continuity_process_failure as process
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report, tool_identity

OUTPUT = Path(__file__).resolve().parent / "installed-02"
OUTPUT.mkdir(mode=0o700)
OUTSIDE = Path(tempfile.mkdtemp(prefix="qperiapt-openssl-census-")).resolve()
TOOLCHAIN = Path("/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin")
CACHE = Path("/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo")
OPENSSL = Path("/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed")
ZIP = ROOT / "research/sdk-alpha1/evidence/20261104-ci-audit/rust-sdk-package-6084f3bf.zip"
BASE = "6084f3bfb09333f6b66291b38809ed512296a27b"
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("CARGO_", "RUST", "DYLD_", "LD_", "QPERIAPT_", "QPC_", "OPENSSL_"))
       and key not in ("CC", "CXX", "AR", "LD", "CPP", "CFLAGS", "CXXFLAGS", "CPPFLAGS", "LDFLAGS",
                       "CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "OBJC_INCLUDE_PATH", "LIBRARY_PATH",
                       "SDKROOT", "MACOSX_DEPLOYMENT_TARGET", "SSL_CERT_FILE", "SSL_CERT_DIR")}
env.update(CARGO_HOME=str(CACHE), CARGO_NET_OFFLINE="true", CARGO_TERM_COLOR="never",
           CARGO_HTTP_MULTIPLEXING="false", CARGO_INCREMENTAL="0",
           RUSTC=str(TOOLCHAIN / "bin/rustc"), RUSTDOC=str(TOOLCHAIN / "bin/rustdoc"),
           RUSTFLAGS="-D warnings", RUSTDOCFLAGS="-D warnings",
           DYLD_FALLBACK_LIBRARY_PATH=str(TOOLCHAIN / "lib"),
           PATH=str(TOOLCHAIN / "bin") + os.pathsep + env.get("PATH", os.defpath))
cargo = [str(TOOLCHAIN / "bin/cargo")]
result = dict(completed=False, source_commit=BASE, working_verifier_change=True,
              release_claim_eligible=False, outside_checkout=str(OUTSIDE),
              scope="same-host Apple Silicon installed archives and C owners; independent OpenSSL TLS carrier; shared native witness engine; Debug/Release selected tests only",
              execution={}, commands=[])

def run(argv, label, cwd=ROOT, *, env_override=None, env=None, runtime=None):
    selected = runtime if runtime is not None else env if env is not None else env_override
    if selected is None:
        selected = globals()["env"]
    started = time.monotonic()
    try:
        return process.command(argv, OUTPUT / label, cwd, environment=selected)
    finally:
        result["commands"].append(dict(label=label, elapsed_seconds=time.monotonic() - started))
        print(label, flush=True)

try:
    sdk.require(not OUTSIDE.is_relative_to(ROOT), "consumer must be outside checkout")
    sdk.require(all(not (CACHE / name).exists() for name in ("config", "config.toml", "credentials", "credentials.toml")),
                "offline cache contains overrides")
    result["source_inputs"] = package.source_inputs()
    result["tools"] = tool_identity(TOOLCHAIN)
    result["driver_sha256"] = sdk.snapshot(Path(__file__)).sha256
    zipped = sdk.snapshot(ZIP)
    sdk.require(zipped.sha256 == "342d7db5d8d180eb395517a76576f3be4850193758186cd5866f5c0361a44e54", "SDK artifact changed")
    result["sdk_zip_sha256"] = zipped.sha256
    with zipfile.ZipFile(ZIP) as archive:
        names = archive.namelist()
        sdk.require(len(names) == len(set(names)) and len(names) < 1000, "SDK ZIP inventory")
        sdk.require(sum(item.file_size for item in archive.infolist()) < 128 * 1024**2, "SDK ZIP size")
        for item in archive.infolist():
            path = PurePosixPath(item.filename)
            sdk.require(not path.is_absolute() and ".." not in path.parts and "\\" not in item.filename, "SDK ZIP path")
            if item.is_dir():
                continue
            target = OUTPUT / "sdk" / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(item))
    sdk_output = OUTPUT / "sdk/sdk-rust-package"
    report_bytes = sdk.snapshot(sdk_output / "RUST_SDK_PACKAGE.json")
    cohort = validate_report(report_bytes.data, report_bytes.sha256, report_bytes.sha256,
                             result["source_inputs"]["rust_workspace_sha256"])
    sdk.require(cohort["base_commit"] == BASE and cohort["git_dirty"] is False
                and cohort["diagnostic_only"] is False, "SDK producer lineage differs")
    metadata = json.loads(run([*cargo, "metadata", "--locked", "--offline", "--no-deps", "--format-version", "1"], "workspace-metadata"))
    result["archive"], files = package.package_candidate(cargo, OUTSIDE / "producer", OUTSIDE / "producer-build",
        sdk_output, cohort, sdk.classify(metadata), OUTPUT, run, env)
    consumer = OUTSIDE / "c-consumer"
    for path in c.FIXTURE.rglob("*"):
        sdk.require(not path.is_symlink(), "consumer symlink")
        if path.is_file():
            sdk.copy(path, consumer / path.relative_to(c.FIXTURE))
    template = {p.relative_to(consumer).as_posix(): sdk.snapshot(p).sha256 for p in consumer.rglob("*") if p.is_file()}
    result["consumer_template"] = template
    sdk.extract_recorded_crates(consumer, sdk_output, cohort["crates"])
    candidate = consumer / "packages" / f"{package.NAME}-{package.VERSION}"
    for relative, data in files.items():
        target = candidate / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    with (consumer / "Cargo.toml").open("a") as stream:
        stream.write(f'{package.NAME} = {{ path = "packages/{package.NAME}-{package.VERSION}" }}\n')
    lock = sdk.snapshot(package.CANDIDATE / "Cargo.lock").data
    (consumer / "Cargo.lock").write_bytes(lock)
    env["CARGO_TARGET_DIR"] = str(OUTSIDE / "build")
    metadata = json.loads(run([*cargo, "metadata", "--offline", "--format-version", "1"], "consumer-metadata", consumer))
    result["resolution"] = package.verify_resolution(metadata, consumer, (consumer / "Cargo.lock").read_bytes(),
        lock, consumer_name=c.NAME, required_features=c.FEATURES)
    sdk.copy(consumer / "Cargo.lock", OUTPUT / "consumer-Cargo.lock")
    cc = Path(run(["/usr/bin/xcrun", "--sdk", "macosx", "--find", "clang"], "cc-path").decode().strip()).resolve(strict=True)
    platform_sdk = run(["/usr/bin/xcrun", "--sdk", "macosx", "--show-sdk-path"], "sdk-path").decode().strip()
    flags = ["-isysroot", platform_sdk]
    original = types.ModuleType("original_openssl_verifier")
    old_path = OUTPUT.parent / "original-verifier.py"
    exec(compile(old_path.read_bytes(), str(old_path), "exec"), original.__dict__)
    result["original_verifier_sha256"] = sdk.snapshot(old_path).sha256
    for profile in ("debug", "release"):
        extra = ["--release"] if profile == "release" else []
        build = OUTSIDE / "build" / profile
        built = run([*cargo, "rustc", "--locked", "--offline", "--lib", "--message-format=json", "-j", "2", *extra,
                     "--", "-C", "link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib"], "library-" + profile, consumer)
        library = c.built_artifact(built, consumer, build, library=True)
        helper_build = run([*cargo, "test", "--locked", "--offline", "--test", "witness", "--no-run", "--message-format=json", "-j", "2", *extra], "helper-" + profile, consumer)
        helper = c.built_artifact(helper_build, consumer, build, library=False, test_name="witness")
        installed = OUTSIDE / ("installed-" + profile)
        installed.mkdir(mode=0o700)
        sdk.copy(library, installed / library.name, maximum=c.MAX_BINARY)
        executable = installed / "qpc-c-client"
        run([str(cc), *flags, "-std=c11", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-pthread",
             *(["-O2"] if profile == "release" else ["-O0", "-g"]),
             *[str(consumer / n) for n in ("client.c", "recovery_client.c", "opening_client.c")],
             "-I", str(consumer), "-L", str(installed), "-l" + c.LIBRARY,
             "-Wl,-rpath,@loader_path", "-o", str(executable)], "c-client-" + profile, consumer)
        dependencies = run(["/usr/bin/otool", "-L", str(executable)], "c-dependencies-" + profile).decode()
        loader = run(["/usr/bin/otool", "-l", str(executable)], "c-loader-" + profile).decode()
        c.verify_linkage(dependencies, loader, library.name, darwin=True)
        peer, identity = openssl.build_peer(OPENSSL, cc, flags, consumer, installed, run, darwin=True, profile=profile)
        runtime = dict(env, QPERIAPT_C_OWNER_CLIENT=str(executable), QPERIAPT_INSTALLED_CLIENT_LANGUAGE="C",
                       QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(installed / library.name), QPERIAPT_WITNESS_OPENSSL_PEER=str(peer))
        result["execution"][profile] = {"peer": identity, "tests": {}, "binaries":
            {n: {"path": str(p), "sha256": sdk.snapshot(p, maximum=c.MAX_BINARY).sha256}
             for n, p in (("C", executable), ("library", installed / library.name), ("Rust", helper))}}
        for kind, test in openssl.TESTS.items():
            private = OUTSIDE / (profile + "-" + kind)
            runtime["QPERIAPT_PUBLIC_SERVICE_EVIDENCE"] = str(private)
            stdout = run([str(helper), "--exact", test, "--nocapture"], profile + "-" + kind, consumer, runtime=runtime)
            if kind == "server":
                try:
                    original.verify_execution(kind, stdout, private)
                except ValueError as error:
                    sdk.require("server exchange census differs" in str(error), "old verifier rejected another property")
                    result["execution"][profile]["original_verifier"] = {"rejected": True, "reason": str(error)}
                else:
                    raise ValueError("old verifier unexpectedly accepted actual server trace")
            checked = openssl.verify_execution(kind, stdout, private)
            checked["exported_public_files"] = openssl.export_public(kind, stdout, private, OUTPUT / "public" / profile / kind)
            result["execution"][profile]["tests"][kind] = checked
        native = OUTSIDE / (profile + "-native-tls")
        runtime["QPERIAPT_PUBLIC_SERVICE_EVIDENCE"] = str(native)
        stdout = run([str(helper), "--exact", tls.TEST, "--nocapture"], profile + "-native-tls", consumer, runtime=runtime)
        checked = tls.verify_execution(stdout, native)
        checked["exported_public_files"] = tls.export_public(stdout, native, OUTPUT / "public" / profile / "native-tls")
        result["execution"][profile]["native_tls"] = checked
        openssl.verify_dependencies(identity["dependency_files"])
    sdk.verify_consumed_sources(consumer, sdk_output, cohort["crates"])
    package.verify_candidate_archive(OUTPUT, result["archive"])
    for relative, data in files.items():
        sdk.require((candidate / relative).read_bytes() == data, "installed candidate changed")
    sdk.require(result["source_inputs"] == package.source_inputs(), "selected source closure changed during run")
    sdk.require(result["tools"] == tool_identity(TOOLCHAIN), "toolchain changed during run")
    result["completed"] = True
except Exception as error:
    result["failure"] = str(error)
    raise
finally:
    sdk.write_json(OUTPUT / "RESULT.json", result)
