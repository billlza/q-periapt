"""Continue the exact prepared installation after correcting diagnostic environment.

The original partial run and its failed native-TLS command remain unchanged.
Only its three completed Debug OpenSSL scenarios are reused, with byte rechecks.
"""
import json
import os
from pathlib import Path
import sys
import time
import types

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "artifact"))
import continuity_c_consumer as c
import continuity_c_witness_openssl as openssl
import continuity_c_witness_tls as tls
import continuity_package as package
import continuity_process_failure as process
import rust_sdk_profile as sdk
from rust_sdk_msrv import tool_identity

PRIOR = Path(__file__).resolve().parent / "installed-02"
OUTPUT = Path(__file__).resolve().parent / "installed-03"
OUTPUT.mkdir(mode=0o700)
prior = json.loads((PRIOR / "RESULT.json").read_text())
OUTSIDE = Path(prior["outside_checkout"])
consumer = OUTSIDE / "c-consumer"
TOOLCHAIN = Path(prior["tools"]["cargo"]["path"]).parent.parent
CACHE = Path("/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo")
OPENSSL = Path("/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed")
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("CARGO_", "RUST", "DYLD_", "LD_", "QPERIAPT_", "QPC_", "OPENSSL_"))
       and key not in ("CC", "CXX", "AR", "LD", "CPP", "CFLAGS", "CXXFLAGS", "CPPFLAGS", "LDFLAGS",
                       "CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "OBJC_INCLUDE_PATH", "LIBRARY_PATH",
                       "SDKROOT", "MACOSX_DEPLOYMENT_TARGET", "SSL_CERT_FILE", "SSL_CERT_DIR")}
env.update(CARGO_HOME=str(CACHE), CARGO_NET_OFFLINE="true", CARGO_TERM_COLOR="never",
           CARGO_HTTP_MULTIPLEXING="false", CARGO_INCREMENTAL="0", CARGO_TARGET_DIR=str(OUTSIDE / "build"),
           RUSTC=str(TOOLCHAIN / "bin/rustc"), RUSTDOC=str(TOOLCHAIN / "bin/rustdoc"),
           RUSTFLAGS="-D warnings", RUSTDOCFLAGS="-D warnings",
           DYLD_FALLBACK_LIBRARY_PATH=str(TOOLCHAIN / "lib"),
           PATH=str(TOOLCHAIN / "bin") + os.pathsep + env.get("PATH", os.defpath))
cargo = [str(TOOLCHAIN / "bin/cargo")]
result = {k: prior[k] for k in ("scope", "source_commit", "working_verifier_change", "release_claim_eligible",
                               "outside_checkout", "source_inputs", "tools", "sdk_zip_sha256", "archive",
                               "consumer_template", "resolution", "original_verifier_sha256")}
result.update(completed=False, execution={}, commands=[],
              retained_partial_result={"path": str(PRIOR / "RESULT.json"), "sha256": sdk.snapshot(PRIOR / "RESULT.json").sha256,
                  "completed": prior["completed"], "failure": prior["failure"]},
              correction="Use the existing C consumer default by omitting QPERIAPT_INSTALLED_CLIENT_LANGUAGE; no product changes or timeout changes.",
              driver_sha256=sdk.snapshot(Path(__file__)).sha256)

def run(argv, label, cwd=consumer, *, runtime=None):
    started = time.monotonic()
    try:
        return process.command(argv, OUTPUT / label, cwd, environment=env if runtime is None else runtime)
    finally:
        result["commands"].append(dict(label=label, elapsed_seconds=time.monotonic() - started))
        print(label, flush=True)

def check_inputs():
    sdk.require(prior["source_inputs"] == package.source_inputs(), "source closure changed")
    sdk.require(prior["tools"] == tool_identity(TOOLCHAIN), "toolchain changed")
    sdk_output = PRIOR / "sdk/sdk-rust-package"
    cohort = json.loads((sdk_output / "RUST_SDK_PACKAGE.json").read_text())
    sdk.verify_consumed_sources(consumer, sdk_output, cohort["crates"])
    package.verify_candidate_archive(PRIOR, prior["archive"])
    files = package.validate_candidate(sdk.snapshot(PRIOR / prior["archive"]["file"]).data, set(prior["archive"]["files"]))
    candidate = consumer / "packages" / f"{package.NAME}-{package.VERSION}"
    for name, value in files.items():
        sdk.require((candidate / name).read_bytes() == value, "installed candidate changed")
    sdk.require((consumer / "Cargo.lock").read_bytes() == (PRIOR / "consumer-Cargo.lock").read_bytes(), "consumer lock changed")
    for name, expected in prior["consumer_template"].items():
        if name != "Cargo.toml":
            sdk.require(sdk.snapshot(consumer / name).sha256 == expected, "consumer source changed")

try:
    check_inputs()
    cc = Path((PRIOR / "cc-path.stdout").read_text().strip()).resolve(strict=True)
    flags = ["-isysroot", (PRIOR / "sdk-path.stdout").read_text().strip()]
    original = types.ModuleType("original_openssl_verifier")
    old_path = PRIOR.parent / "original-verifier.py"
    exec(compile(old_path.read_bytes(), str(old_path), "exec"), original.__dict__)
    for profile in ("debug", "release"):
        installed = OUTSIDE / ("installed-" + profile)
        if profile == "debug":
            result["execution"][profile] = prior["execution"][profile]
            for row in result["execution"][profile]["binaries"].values():
                sdk.require(sdk.snapshot(Path(row["path"]), maximum=c.MAX_BINARY).sha256 == row["sha256"], "Debug binary changed")
            helper = Path(result["execution"][profile]["binaries"]["Rust"]["path"])
            for kind in openssl.TESTS:
                stdout = (PRIOR / (profile + "-" + kind + ".stdout")).read_bytes()
                openssl.verify_execution(kind, stdout, PRIOR / "public" / profile / kind)
            identity = result["execution"][profile]["peer"]
            peer = Path(identity["path"])
        else:
            build = OUTSIDE / "build/release"
            built = run([*cargo, "rustc", "--locked", "--offline", "--lib", "--message-format=json", "-j", "2", "--release",
                         "--", "-C", "link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib"], "library-release")
            library = c.built_artifact(built, consumer, build, library=True)
            built = run([*cargo, "test", "--locked", "--offline", "--test", "witness", "--no-run", "--message-format=json", "-j", "2", "--release"], "helper-release")
            helper = c.built_artifact(built, consumer, build, library=False, test_name="witness")
            installed.mkdir(mode=0o700)
            sdk.copy(library, installed / library.name, maximum=c.MAX_BINARY)
            executable = installed / "qpc-c-client"
            run([str(cc), *flags, "-std=c11", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-pthread", "-O2",
                 *[str(consumer / n) for n in ("client.c", "recovery_client.c", "opening_client.c")],
                 "-I", str(consumer), "-L", str(installed), "-l" + c.LIBRARY,
                 "-Wl,-rpath,@loader_path", "-o", str(executable)], "c-client-release")
            dependencies = run(["/usr/bin/otool", "-L", str(executable)], "c-dependencies-release").decode()
            loader = run(["/usr/bin/otool", "-l", str(executable)], "c-loader-release").decode()
            c.verify_linkage(dependencies, loader, library.name, darwin=True)
            peer, identity = openssl.build_peer(OPENSSL, cc, flags, consumer, installed, run, darwin=True, profile=profile)
            result["execution"][profile] = {"peer": identity, "tests": {}, "binaries":
                {n: {"path": str(p), "sha256": sdk.snapshot(p, maximum=c.MAX_BINARY).sha256}
                 for n, p in (("C", executable), ("library", installed / library.name), ("Rust", helper))}}
        runtime = {k: v for k, v in env.items() if not k.startswith(("DYLD_", "LD_"))}
        runtime.update(QPERIAPT_C_OWNER_CLIENT=str(installed / "qpc-c-client"), QPERIAPT_WITNESS_OPENSSL_PEER=str(peer))
        if profile == "release":
            for kind, test in openssl.TESTS.items():
                private = OUTSIDE / (profile + "-" + kind)
                runtime["QPERIAPT_PUBLIC_SERVICE_EVIDENCE"] = str(private)
                stdout = run([str(helper), "--exact", test, "--nocapture"], profile + "-" + kind, runtime=runtime)
                if kind == "server":
                    try:
                        original.verify_execution(kind, stdout, private)
                    except ValueError as error:
                        sdk.require("server exchange census differs" in str(error), "old verifier rejected another property")
                        result["execution"][profile]["original_verifier"] = {"rejected": True, "reason": str(error)}
                    else:
                        raise ValueError("old verifier accepted actual server trace")
                checked = openssl.verify_execution(kind, stdout, private)
                checked["exported_public_files"] = openssl.export_public(kind, stdout, private, OUTPUT / "public" / profile / kind)
                result["execution"][profile]["tests"][kind] = checked
        private = OUTSIDE / (profile + "-native-tls-correct-environment")
        runtime["QPERIAPT_PUBLIC_SERVICE_EVIDENCE"] = str(private)
        stdout = run([str(helper), "--exact", tls.TEST, "--nocapture"], profile + "-native-tls", runtime=runtime)
        checked = tls.verify_execution(stdout, private)
        checked["exported_public_files"] = tls.export_public(stdout, private, OUTPUT / "public" / profile / "native-tls")
        result["execution"][profile]["native_tls"] = checked
        openssl.verify_dependencies(identity["dependency_files"])
    check_inputs()
    for profile in result["execution"].values():
        for row in profile["binaries"].values():
            sdk.require(sdk.snapshot(Path(row["path"]), maximum=c.MAX_BINARY).sha256 == row["sha256"], "executed binary changed")
    result["completed"] = True
except Exception as error:
    result["failure"] = str(error)
    raise
finally:
    sdk.write_json(OUTPUT / "RESULT.json", result)
