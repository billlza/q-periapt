#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import os,sys,json
out=Path(__file__).resolve().parent;root=out.parents[1];s=json.loads((root/'target/continuity-android-current/jni-05/STATE.json').read_text());jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
mode,profile,inputs,target,output=sys.argv[1:];probe='PeerProbe' if mode.startswith('peer-') else 'EnrollmentProbe'
cmd=[str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+s['host'],'-cp',str(out/'cancellation-03/classes')+':'+s['classes'],'dev.qperiapt.continuity.android.tests.'+probe,inputs,target,profile,mode,output]
os.execv(cmd[0],cmd)
