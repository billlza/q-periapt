from pathlib import Path
import json,os,sys
out=Path(__file__).resolve().parent;root=out.parents[1];sys.path.insert(0,str(root/'artifact'));import rust_sdk_profile as sdk
s=json.loads((out/'STATE.json').read_text());work=Path(s['work']);source=Path(s['source']);base=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244');tc=base/'rustup/toolchains/1.98.1-aarch64-apple-darwin'
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO','QPERIAPT','QPC','DYLD','LD_','CC','CXX','AR'))};env.update(CARGO_HOME=str(base/'apple-cargo-home-ff4a153e'),CARGO_TARGET_DIR=str(work/'build'),CARGO_NET_OFFLINE='true',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),QPC_ENROLLMENT_CASES=str(work/'cases-cancel-03'),QPC_ENROLLMENT_DRIVER=str(out/'host-driver-cancel-03.py'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
sdk.command([str(tc/'bin/cargo'),'test','--locked','--offline','--test','android_enrollment','android_enrollment_lifecycle','-j','2','--','--exact','--nocapture'],out/'host-cancel-03',source,environment=env)
