import java.security.MessageDigest
plugins { id("com.android.application") }
android {
 namespace = "dev.qperiapt.continuity.android.tests"
 compileSdk = 36
 buildToolsVersion = "36.0.0"
 defaultConfig {
  applicationId = "dev.qperiapt.continuity.peerprobe20261011"
  minSdk = 36
  targetSdk = 36
  versionCode = 1
  versionName = "qualification"
 }
 buildTypes {
  getByName("release") {
   isDebuggable = false
   isMinifyEnabled = true
   vcsInfo.include = false
   proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
  }
 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { buildConfig = false }
 packaging.jniLibs {
  useLegacyPackaging = false
  keepDebugSymbols += setOf("**/libq_periapt_continuity_c_consumer.so", "**/libqperiapt_continuity_jni.so")
 }
}
dependencies { implementation(files(rootProject.file("libs/continuity.aar"))) }
tasks.withType<JavaCompile>().configureEach {
 options.compilerArgs.addAll(listOf("-Xlint:all", "-Werror"))
 doFirst {
  file("compile-inputs.txt").writeText(source.files.map { it.canonicalPath }.sorted().joinToString("\n", postfix="\n"))
  file("compiler-home.txt").writeText(javaCompiler.get().metadata.installationPath.asFile.canonicalPath + "\n")
 }
}
