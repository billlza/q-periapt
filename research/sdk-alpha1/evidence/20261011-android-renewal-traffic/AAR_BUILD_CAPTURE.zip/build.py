from pathlib import Path
import hashlib,json,os,shutil,zipfile
import rust_sdk_profile as sdk
import third_party_licenses as licenses
root=Path.cwd();out=root/'target/continuity-android-renewal-traffic-aar';source=out/'source';shutil.copytree(root/'bindings/android/ContinuityPackageConsumer',source)
fixed=json.loads((root/'target/continuity-android-current/FIXED-02.json').read_text());assert fixed['completed'] and not fixed['live_producer'];engine=Path(fixed['library']);native=out/'native';native.mkdir();shutil.copy2(engine,native/engine.name)
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');ndk=Path('/Users/bill/Library/Android/sdk/ndk/29.0.14206865');compiler=ndk/'toolchains/llvm/prebuilt/darwin-x86_64/bin/aarch64-linux-android23-clang'
state=json.loads((root/'target/continuity-android-authority-retry/STATE.json').read_text());assert state['completed'] and not state['live_producer'];env=state['environment'];classes=out/'classes';classes.mkdir()
sdk.command([str(jdk/'bin/javac'),'--release','11','-Xlint:all','-Werror','-d',str(classes),*[str(p) for p in sorted((source/'src/main/java').rglob('*.java'))]],out/'javac',root,environment=env)
sdk.command([str(compiler),'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-I'+str(root/'bindings/c/ContinuityPackageConsumer'),'-fPIC','-shared',*[str(p) for p in sorted((source/'jni').glob('*.c'))],'-L'+str(native),'-lq_periapt_continuity_c_consumer','-Wl,--no-undefined','-Wl,-soname,libqperiapt_continuity_jni.so','-Wl,-z,max-page-size=16384','-o',str(native/'libqperiapt_continuity_jni.so')],out/'jni',root,environment=env)
jar=out/'classes.jar'
def archive(path,items):
 with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for name,data in sorted(items.items()):
   info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
archive(jar,{p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob('*.class')})
consumer=Path(fixed['source']);cargo=Path(env['RUSTC']).parent/'cargo';metadata=json.loads(sdk.command([str(cargo),'metadata','--locked','--offline','--format-version','1','--filter-platform','aarch64-linux-android'],out/'native-license-metadata',consumer,environment=env));notices=out/'notices';notices.mkdir();licenses.collect(consumer,notices,'aarch64-linux-android',root_package='q-periapt-continuity-c-consumer',resolved_metadata=metadata);licenses.verify(notices,expected_target='aarch64-linux-android',root_package='q-periapt-continuity-c-consumer')
files={'classes.jar':jar.read_bytes(),'proguard.txt':(source/'consumer-rules.pro').read_bytes(),'AndroidManifest.xml':b'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.qperiapt.continuity.android"><uses-sdk android:minSdkVersion="23"/></manifest>\n'}
for p in native.glob('*.so'):files['jni/arm64-v8a/'+p.name]=p.read_bytes()
for p in notices.rglob('*'):
 if p.is_file():files['META-INF/native-notices/'+p.relative_to(notices).as_posix()]=p.read_bytes()
for name in ['Apache-2.0.txt','MIT.txt','Rust-1.98.1-library.html']:files['META-INF/LICENSES/'+name]=(root/'LICENSES'/name).read_bytes()
for name in ['INVENTORY.sha256','LICENSE-INVENTORY.md','LICENSE.mlkem-native','PROVENANCE.md']:files['META-INF/LICENSES/mlkem-native/'+name]=(root/'crates/q-periapt-mlkem-native-sys/vendor'/name).read_bytes()
aar=out/'q-periapt-continuity-android-0.0.0.aar';archive(aar,files)
record={'completed':True,'aar':str(aar),'aar_sha256':hashlib.sha256(aar.read_bytes()).hexdigest(),'source':str(source),'native_engine_sha256':hashlib.sha256(engine.read_bytes()).hexdigest(),'jni_sha256':hashlib.sha256((native/'libqperiapt_continuity_jni.so').read_bytes()).hexdigest(),'source_sha256':{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()},'members_sha256':{name:hashlib.sha256(data).hexdigest() for name,data in files.items()},'release_claim_eligible':False};(out/'PACKAGE.json').write_text(json.dumps(record,indent=2)+'\n');print('New Android credential renewal AAR built with target-specific dependency notices',flush=True)
