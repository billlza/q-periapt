#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import base64,hashlib,json,os,re,subprocess,sys,zipfile
out=Path(__file__).resolve().parent;mode,profile,inputs,target,output=sys.argv[1:];inputs=Path(inputs);output=Path(output);variant=inputs.parent.name
assert profile in ['fixed','recoverable'] and variant in ['signed-fixed','signed-recoverable','tls-fixed','tls-recoverable']
assert mode.startswith('credential-') or mode in ['authority-create','authority-reopen','authority-peer-associate','managed-witness-create','managed-witness-wrong','managed-witness-resume','managed-witness-prepare','managed-witness-missing','managed-witness-bad-receipt','managed-witness-activate','managed-witness-active-reopen','managed-unselected','managed-closed-registry','managed-cancelled-registry']
operation=mode[8:] if mode.startswith('managed-') else mode
label=output.name;assert re.fullmatch(r'[a-z][a-z0-9.-]{0,63}',label);run=out/('device-'+variant);run.mkdir(mode=0o700,exist_ok=True);state_path=run/'STATE.json';s=json.loads(state_path.read_text()) if state_path.exists() else {'completed':False,'cleanup':False,'cases':[]};secrets=[]
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.renewaltraffic20261011'
lines=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();matches=[line for line in lines if ' device ' in line and hashlib.sha256(line.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(matches)==1;transport=re.search(r'transport_id:(\d+)',matches[0]).group(1)
def safe(text):
 for secret in secrets:text=text.replace(secret,'<redacted test TLS credential>')
 return text

def command(name,args,expected=0,timeout=30):
 cmd=[adb,'-t',transport]+args;r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout);stdout,stderr=safe(r.stdout),safe(r.stderr)
 (run/(label+'-'+name+'.stdout')).write_text(stdout);(run/(label+'-'+name+'.stderr')).write_text(stderr);(run/(label+'-'+name+'.json')).write_text(json.dumps({'command':[safe(x) for x in cmd],'exit_code':r.returncode},indent=2)+'\n')
 assert r.returncode==expected and not stderr,(name,r.returncode,stderr);return stdout

def clear_maps():
 for selected in list(s.get('owned_reverse_ports',[])):
  command('reverse-remove-'+str(selected),['reverse','--remove','tcp:'+str(selected)])
  s['owned_reverse_ports'].remove(selected);state_path.write_text(json.dumps(s,indent=2)+'\n')

def cleanup():
 clear_maps()
 assert command('uninstall',['uninstall',pkg],timeout=60).strip()=='Success'
 assert not command('uninstalled',['shell','pm','list','packages','--user','0',pkg]).strip();s['cleanup']=True
try:
 if operation=='witness-create':
  assert not s.get('installation_attempted') and not command('preexisting',['shell','pm','list','packages','--user','0',pkg]).strip()
  assert command('api',['shell','getprop','ro.build.version.sdk']).strip()=='37'
  assert command('abi',['shell','getprop','ro.product.cpu.abi']).strip()=='arm64-v8a'
  with (run/'build.stdout').open('wb') as stdout,(run/'build.stderr').open('wb') as stderr:r=subprocess.run([sys.executable,str(out/'build-consumer.py'),str(inputs),variant],stdout=stdout,stderr=stderr,timeout=900)
  assert r.returncode==0,'AGP build'
  build=json.loads((out/('agp-'+variant)/'STATE.json').read_text());assert build['completed'];project=Path(build['project']);compiled=(project/'app/compile-inputs.txt').read_text().splitlines()
  assert sorted(Path(p).name for p in compiled)==['AuthorityProbe.java','CancellationProbe.java','ConfigurationInstrumentation.java','ConfigurationProbe.java','CredentialProbe.java','EnrollmentProbe.java','PeerInputs.java','PeerProbe.java','WitnessInputs.java','WitnessProbe.java']
  assert all(Path(p).is_relative_to(project/'app/src/main/java') for p in compiled)
  assert 'dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:' in (project/'app/build/outputs/mapping/release/mapping.txt').read_text()
  package=json.loads((out/'PACKAGE.json').read_text())
  with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(build['unsigned_apk']) as apk:
   for name in ['libqperiapt_continuity_jni.so','libq_periapt_continuity_c_consumer.so']:assert aar.read('jni/arm64-v8a/'+name)==apk.read('lib/arm64-v8a/'+name)
  jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home');bt=Path('/Users/bill/Library/Android/sdk/build-tools/36.0.0');env=dict(os.environ,JAVA_HOME=str(jdk),PATH=str(jdk/'bin')+':/usr/bin:/bin')
  def local(name,cmd):
   r=subprocess.run([str(x) for x in cmd],env=env,capture_output=True,text=True,timeout=60);(run/(name+'.stdout')).write_text(r.stdout);(run/(name+'.stderr')).write_text(r.stderr);assert r.returncode==0,(name,r.stderr)
  local('keytool',[jdk/'bin/keytool','-genkeypair','-keystore',run/'qualification.p12','-storepass','qualification-only','-alias','qualification','-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Local Continuity Qualification','-noprompt']);(run/'qualification.p12').chmod(0o600)
  local('sign',[bt/'apksigner','sign','--ks',run/'qualification.p12','--ks-pass','pass:qualification-only','--out',run/'consumer.apk',build['unsigned_apk']]);local('signature',[bt/'apksigner','verify','--verbose',run/'consumer.apk'])
  s.update(apk_sha256=hashlib.sha256((run/'consumer.apk').read_bytes()).hexdigest(),aar_sha256=package['aar_sha256'],installation_attempted=True);state_path.write_text(json.dumps(s,indent=2)+'\n')
  assert command('install',['install','--no-incremental','-t',str(run/'consumer.apk')],timeout=90).splitlines().count('Success')==1
 else:assert s['installation_attempted'] and not s['cleanup']
 args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation',mode,'-e','label',label]
 names=['witness-id','witness-public','witness-address','witness-carrier']
 if operation=='witness-prepare' or mode=='authority-create':names+=['grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest']
 if operation not in ['witness-create','witness-wrong','witness-resume']:
  names+=['authority-id','authority-application']
  if mode!='authority-create':names+=['authority-checkpoint']
 if (inputs/'witness-carrier').read_bytes()==b'tls':names+=['witness-tls-cert','witness-tls-key','witness-tls-peer','witness-tls-name']
 if mode.startswith('credential-') and not mode.startswith('credential-peer-') and mode not in ['credential-identity','credential-status']:names+=['credential-operation','credential-statement','renewal-version','renewal-digest','credential-renewal']
 peer_mode=mode.removeprefix('credential-') if mode.startswith('credential-peer-') else None
 if mode=='authority-peer-associate':names+=['authority-peer-application','peer-approved-certificate','peer-approved-roster']
 if peer_mode:
  names+=['peer-'+p.name for p in sorted((inputs/'peer').iterdir()) if p.is_file()]
  if peer_mode!='peer-unassociated':names+=['connection-address','connection-initiation' if peer_mode=='peer-connect' else 'connection-session']
  if peer_mode=='peer-retry':names+=['connection-message']
 address=(inputs/'witness-address').read_text();match=re.fullmatch(r'127\.0\.0\.1:(\d+)',address);assert match;port=int(match.group(1));assert 1<=port<=65535
 for name in names:
  path=inputs/'peer'/name[5:] if name.startswith('peer-') else inputs/name
  value=base64.b64encode(path.read_bytes()).decode('ascii')
  if name=='witness-tls-key':secrets.append(value)
  args+=['-e',name,value]
 args+=[pkg+'/dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation']
 ports=[] if mode.startswith('authority-') else [port]
 if peer_mode and peer_mode!='peer-unassociated':
  endpoint=(inputs/'connection-address').read_text();peer_match=re.fullmatch(r'127\.0\.0\.1:(\d+)',endpoint);assert peer_match
  peer_port=int(peer_match.group(1));assert 1<=peer_port<=65535 and peer_port not in ports;ports.append(peer_port)
 try:
  for selected in ports:
   assert command('reverse-create-'+str(selected),['reverse','--no-rebind','tcp:'+str(selected),'tcp:'+str(selected)]).strip()==str(selected)
   s.setdefault('owned_reverse_ports',[]).append(selected);state_path.write_text(json.dumps(s,indent=2)+'\n')
  result=command('instrument',args,timeout=90)
 finally:clear_maps()
 expected=profile+':'+mode+':passed';assert 'INSTRUMENTATION_RESULT: result='+expected+'\n' in result,result
 assert result.rstrip().endswith('INSTRUMENTATION_CODE: -1') and 'INSTRUMENTATION_RESULT: apk_sha256='+s['apk_sha256']+'\n' in result,result
 pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',result,re.M).group(1));assert pid not in [case['pid'] for case in s['cases']]
 payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',result,re.M).group(1),validate=True);assert 1<=len(payload)<=8192
 with output.open('xb') as destination:destination.write(payload)
 command('stop',['shell','am','force-stop',pkg]);assert not command('process-absent',['shell','pidof',pkg],expected=1).strip()
 s['cases'].append({'mode':mode,'label':label,'pid':pid,'result_sha256':hashlib.sha256(payload).hexdigest(),'installed_apk_sha256':s['apk_sha256'],'process_absent_after_stop':True})
 if mode=='credential-peer-retry':cleanup();s['completed']=True
 state_path.write_text(json.dumps(s,indent=2)+'\n');print(expected)
except BaseException:
 if s.get('installation_attempted') and not s.get('cleanup'):cleanup()
 state_path.write_text(json.dumps(s,indent=2)+'\n');raise
