from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import continuity_android_credential as credential
import continuity_android_jni as android
import rust_sdk_profile as sdk
root=Path.cwd();phone=root/'target/continuity-android-renewal-traffic-device';host=root/'target/continuity-android-renewal-traffic-qualified';aar=root/'target/continuity-android-renewal-traffic-aar';out=root/'research/sdk-alpha1/evidence/20261011-android-renewal-traffic'
accepted=json.loads((phone/'VERIFIED.json').read_text());assert accepted['completed']
h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert h['completed'] and a['completed']
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==digest and a['source_sha256'][name]==digest
host_cases={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];library=Path(next(a.split('=',1)[1] for a in argv if a.startswith('-Djava.library.path=')))
 cases=library/'credential-cases';fresh=credential.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),cases)
 assert fresh==h['profiles'][profile]['credential_outcomes'];host_cases[profile]=cases
 assert sdk.snapshot(library/'qpc-c-client',maximum=512*1024*1024).sha256==h['profiles'][profile]['receiver_sha256']
secrets=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
for line in rows:
 if ' device ' in line:secrets.append(line.split()[0].encode())
for path in (phone/'cases').glob('*/inputs/witness-tls-key'):
 value=path.read_bytes();secrets.extend([value,base64.b64encode(value),value.hex().encode()])
out.mkdir()
def archive(filename,files):
 with zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED) as packed:
  for name,path in sorted(files.items()):
   data=path.read_bytes();assert not any(secret and secret in data for secret in secrets),'private value in capture '+name
   info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;packed.writestr(info,data)
 return hashlib.sha256((out/filename).read_bytes()).hexdigest()
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for folder in ['device-*','agp-*']:
 for p in phone.glob(folder+'/*'):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for label in accepted['profiles']:
 for name in credential.PUBLIC:files['cases/'+label+'/'+name]=phone/'cases'/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
files['ANDROID_JNI_CONSUMER.json']=host/'ANDROID_JNI_CONSUMER.json'
for name in ['clippy.stderr','clippy.stdout','clippy.json','artifact-tests.stdout','artifact-tests.stderr','qualify.py','clippy.py']:files[name]=host/name
for profile,cases in host_cases.items():
 for label in h['profiles'][profile]['credential_outcomes']:
  for name in credential.PUBLIC:files['cases/'+profile+'/'+label+'/'+name]=cases/label/name
initial=root/'target/continuity-android-renewal-traffic-host'
for name in ['android-jni-debug-credential.stderr','android-jni-debug-credential.stdout','android-jni-debug-credential.json','ANDROID_JNI_CONSUMER.json']:files['initial-unassociated/'+name]=initial/name
host_hash=archive('HOST_CAPTURE.zip',files)
a_hash=archive('AAR_BUILD_CAPTURE.zip',{p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}})
code={('bindings/android/ContinuityPackageConsumer/'+name):hashlib.sha256(data).hexdigest() for name,data in android.source_files().items()}
for name in ['artifact/continuity_android_credential.py','artifact/continuity_android_jni.py','artifact/continuity_android_witness.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_witness.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential_traffic.rs']:
 code[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
record={'kind':'qperiapt.android_credential_renewal_traffic_qualification','completed':True,'base_commit':'8feb304068539a9527e84e8e880b8c4dc806f5ab','code_commit':'9971f197355cb748f91471fd01c2c1a94671781e','art_harness':json.loads((phone/'HARNESS.json').read_text()),'code_sha256':code,'device_scope':{'accepted':True,'device_count':1,'api':37,'abi':'arm64-v8a','additional_api36_hardware_required':False},'art_processes':130,'native_receiver_processes_per_platform_run':16,'profiles':accepted['profiles'],'host_jni':{'completed':True,'qualified_java_processes':470,'credential_java_processes':260,'boundary_processes':2,'local_lifecycle_processes':48,'managed_registry_processes':100,'witness_processes':60,'profiles':['debug','release'],'receiver_sha256':{p:h['profiles'][p]['receiver_sha256'] for p in ['debug','release']}},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'AAR_BUILD_CAPTURE.zip':a_hash},'scope':['Actual minified AAR consumer uses the original session and message across locally witnessed credential renewal.','Native C receiver commits its original deduplicated application effect before exiting with 77; retry returns the original IDs and preserves exactly one unchanged effect file.','Unassociated peer admission is refused with 201; independently verified peer association enables the same public preparation path.','Current public Java/JNI library bytes are unchanged from the prior AAR. New qualification exercises existing interfaces rather than weakening account admission.'],'initial_failure':'Initial traffic harness omitted peer account association. The existing managed registry correctly refused peer creation; an explicit peer association and a retained negative control repair the harness.','limitations':['Credential route executes before original credential expiry.','Android remote-peer renewal admission, expiry cleanup and independently approved cancellation remain separate integration scenarios.','Counterparty is an installed native C consumer on the Mac host. This is not independent protocol implementation or a native Linux endpoint qualification.'],'release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',record);print('Captured original-session Android renewal traffic evidence',flush=True)
