from pathlib import Path
import sys,os,json,hashlib,time,subprocess,shutil
b=Path(__file__).resolve().parent;source=b/'consumer';sys.path.insert(0,str(b/'source/artifact'))
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_first_configuration as configuration
profile=sys.argv[1];sdk.require(profile in {'debug','release'},'profile');out=b/('native-'+profile);out.mkdir(mode=0o700);outside=out/'outside';outside.mkdir(mode=0o700);installed=outside/'installed';installed.mkdir(mode=0o700)
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin');build=b.parent/'installed-account-readiness-current/consumer-build-noincremental'
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','QPC','PYTHON'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_TARGET_DIR=str(build),CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()};record={'profile':profile,'source':str(source),'inputs':inputs,'completed':False};(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
def run(argv,label,*,runtime=None):return sdk.command(argv,out/label,source,environment=env if runtime is None else runtime)
try:
 filename='libq_periapt_continuity_c_consumer.dylib';lib=b/'swift-consumer/native'/profile/filename;shutil.copyfile(lib,installed/filename)
 cc=Path(run(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],'clang').decode().strip());platform_sdk=run(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],'sdk').decode().strip();flags=['-isysroot',platform_sdk];receiver=installed/'qpc-c-client'
 run([str(cc),*flags,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread',('-O2' if profile=='release' else '-O0'),*[str(source/name) for name in ('client.c','recovery_client.c','opening_client.c')],'-I',str(source),'-L',str(installed),'-l'+c.LIBRARY,'-Wl,-rpath,@loader_path','-o',str(receiver)],'receiver-build')
 names={line.split()[-1].removeprefix('_') for line in run(['/usr/bin/nm','-gU',str(installed/filename)],'native-exports').decode().splitlines() if line.strip()};sdk.require(names==c.EXPORTS,'native export set changed')
 record['result']=configuration.qualify_native(outside,out,source,build/profile,[str(tc/'bin/cargo')],env,cc,flags,installed,filename,profile,run,receiver=receiver)
 record['native_library']={'path':str(installed/filename),'sha256':sha(installed/filename)};record['completed']=True
finally:
 record['seconds']=time.monotonic()-start;record['source_unchanged']=inputs=={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()};(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('inputs','result')}));sdk.require(record['source_unchanged'],'consumer changed during validation')
