from pathlib import Path
import os,sys,json,hashlib,subprocess,shlex,time
b=Path(__file__).resolve().parent;sys.path.insert(0,str(b/'source/artifact'))
import rust_sdk_profile as sdk
import continuity_first_configuration as configuration
import continuity_swift_consumer as swift_reader
language,profile,*args=sys.argv[1:];collector=args[0] if args else '';sdk.require(language in {'Swift','Kotlin'} and profile in {'debug','release'},'scope')
label=language.lower()+'-'+profile+('-'+collector if collector else '');out=b/('execution-'+label);out.mkdir(mode=0o700);outside=out/'outside';outside.mkdir(mode=0o700)
native_result=json.loads((b/('native-'+profile)/'RESULT.json').read_text());sdk.require(native_result['completed'] and native_result['source_unchanged'],'native incomplete');first=native_result['result'];native={'first_configuration':first,'binaries':{'C_client':first['binaries']['receiver']}}
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','QPC','PYTHON','SWIFT','JAVA','JDK','GRADLE','KOTLIN')) and k not in ('_JAVA_OPTIONS','CLASSPATH')};env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
lib=b/'swift-consumer/native'/profile/'libq_periapt_continuity_c_consumer.dylib';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binaries={str(lib):sha(lib)}
def run(argv,label,*,runtime=None):return sdk.command(argv,out/label,outside,environment=env if runtime is None else runtime)
if language=='Swift':
 sdk.require(not collector,'Swift collector');client=b/f'swift-build-{profile}/out/Products'/profile.capitalize()/'FirstConfigurationClient';binaries[str(client)]=sha(client)
 deps=run(['/usr/bin/otool','-L',str(client)],'dependencies').decode();loader=run(['/usr/bin/otool','-l',str(client)],'loader').decode();swift_reader.verify_linkage(deps,loader,lib.parent)
 probe=subprocess.run([str(client)],env=dict(env,DYLD_PRINT_LIBRARIES='1'),capture_output=True);(out/'native-image.stdout').write_bytes(probe.stdout);(out/'native-image.stderr').write_bytes(probe.stderr);sdk.require(probe.returncode==1 and b'argument count' in probe.stderr,'loader probe did not reach argument check');lines=[line for line in probe.stderr.decode().splitlines() if line.rstrip().endswith('/'+lib.name)];sdk.require(len(lines)==1 and lines[0].rstrip().endswith(str(lib)),'Swift native image differs')
else:
 sdk.require(collector in {'g1','serial'},'Kotlin collector');build=json.loads((b/'kotlin-build-01/RESULT.json').read_text());sdk.require(build['completed'],'Kotlin incomplete');java=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home/bin/java');jars=sorted((Path(build['outside'])/'consumer/build/install/continuity-installed-consumer/lib').glob('*.jar'));sdk.require(len(jars)==4 and all(sha(Path(n))==v for n,v in build['distribution'].items()),'Kotlin installed distribution changed');client=out/'client';client.write_text('#!/bin/sh\nexec '+shlex.join([str(java),'-Xms32m','-Xmx128m','-XX:+Use'+('G1GC' if collector=='g1' else 'SerialGC'),'--enable-native-access=ALL-UNNAMED','--illegal-native-access=deny','-Dqperiapt.continuity.lib='+str(lib),'-cp',':'.join(map(str,jars)),'configuration.FirstConfigurationClientKt'])+' "$@"\n');client.chmod(0o700);binaries.update({str(p):sha(p) for p in [java,client,*jars]})
record={'language':language,'profile':profile,'collector':collector,'binaries':binaries,'completed':False,'scope':'Current first-use policy composition through mandatory collector; protocol-policy only; shared native engine'};(out/'START.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
try:
 record['result']=configuration.qualify_foreign(outside,out,profile,env,native,run,client,language=language,collector=({'g1':'G1','serial':'Serial'}[collector] if collector else ''));record['completed']=True
finally:
 record.update(seconds=time.monotonic()-start,binaries_unchanged=all(sha(Path(n))==h for n,h in binaries.items()));(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('binaries','result')}));sdk.require(record['binaries_unchanged'],'binary changed during validation')
