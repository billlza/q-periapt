from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime,sys
b=Path(__file__).resolve().parent;root=b.parents[1];sys.path.insert(0,str(b/'source/artifact'));import continuity_first_configuration as reader
sha=lambda data:hashlib.sha256(data).hexdigest();files={};profiles=[];operations=set();source=json.loads((b/'SOURCE_ALIGNMENT.json').read_text())
for name,digest in source['current_files'].items():
 if sha((root/name).read_bytes())!=digest:raise ValueError('Main source changed: '+name)
for run in [b/'native-debug',b/'native-release',*sorted(b.glob('execution-*'))]:
 result=json.loads((run/'RESULT.json').read_text())
 if result['completed'] is not True or result.get('source_unchanged',result.get('binaries_unchanged')) is not True:raise ValueError('Incomplete run '+run.name)
 checked=result['result'];language=checked['language'];profile=result['profile'];collector=checked['collector'];public=run/'configuration-public'/language.lower()/profile/(collector.lower() if collector else 'default')
 label='configuration-'+language.lower()+'-'+profile+('-'+collector.lower() if collector else '')
 stdout=(run/(label+'.stdout')).read_bytes();reread=reader.verify_execution(stdout,public,language=language)
 for key,value in reread.items():
  if checked[key]!=value:raise ValueError('Readback changed '+run.name+'/'+key)
 if len(checked['public_readbacks'])!=166:raise ValueError('Public inventory count differs')
 for relative,digest in checked['public_readbacks'].items():
  data=(public/relative).read_bytes()
  if sha(data)!=digest:raise ValueError('Public data changed')
  files['public/'+run.name+'/'+relative]=data
 for scenario in public.iterdir():operations.add((scenario/'policy-request.bin').read_bytes()[:32])
 profiles.append({'run':run.name,'language':language,'profile':profile,'collector':collector,'scenarios':len(checked['scenarios']),'public_files':len(checked['public_readbacks']),'seconds':result['seconds']})
 for f in run.iterdir():
  if f.is_file() and f.suffix in ('.json','.stdout','.stderr'):files['runs/'+run.name+'/'+f.name]=f.read_bytes()
if len(profiles)!=8 or len(operations)!=48 or sum(p['scenarios'] for p in profiles)!=48:raise ValueError('Execution matrix differs')
validation={}
for label in ['swift-debug-01','swift-release-01','kotlin-build-01','clippy-01','msrv-01','enrollment-regression-01']:
 row=json.loads((b/label/'RESULT.json').read_text())
 if row.get('returncode',0)!=0 or row.get('completed',True) is not True or row.get('source_unchanged',True) is not True:raise ValueError(label)
 for step in row.get('runs',[]):
  if step['returncode']!=0:raise ValueError(label+'/'+step['label'])
 validation[label]={k:v for k,v in row.items() if k not in ('inputs','repository_files','distribution','swift')}
 for f in (b/label).iterdir():
  if f.is_file() and f.suffix in ('.json','.log','.stdout','.stderr'):files['validation/'+label+'/'+f.name]=f.read_bytes()
for label,count in [('codeql-unit',44),('configuration-unit',16),('package-unit',15)]:
 text=(b/(label+'.stderr')).read_text()
 if f'Ran {count} tests' not in text or not text.rstrip().endswith('OK'):raise ValueError(label)
 for suffix in ('.stdout','.stderr'):files['validation/'+label+suffix]=(b/(label+suffix)).read_bytes()
 validation[label]={'tests':count,'passed':True}
for name in ['SOURCE.json','SOURCE_ALIGNMENT.json','NATIVE_REUSE.json','KOTLIN_LIBRARY_REUSE.json','CURRENT_PUBLIC_CONTROLS.json','PUBLIC_REPLAY.json','INTEGRATION.patch']:files['analysis/'+name]=(b/name).read_bytes()
for f in b.glob('*.py'):files['drivers/'+f.name]=f.read_bytes()
for p in [b/'source/artifact/continuity_first_configuration.py',b/'source/artifact/continuity_configuration_policy.py']:
 files['readers/'+p.name]=p.read_bytes()
files['patches/INTEGRATED.patch']=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root)
dest=root/'research/sdk-alpha1/evidence/20261010-first-configuration-policy-integration';dest.mkdir();archive=dest/'PUBLIC_CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None or len(z.namelist())!=len(files):raise ValueError('Archive failed')
 for name,data in files.items():
  if z.read(name)!=data:raise ValueError('Archive roundtrip failed')
record={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':source['base_head'],'scope':'Current installed public owner consumers: first-use configuration and original registration/session/message recovery across independently approved protocol-policy renewal; same-host macOS arm64, shared native engine','source':source,'profiles':profiles,'scenarios':48,'unique_policy_operations':48,'public_files':1328,'reader_controls':106,'validation':validation,'contracts':['fresh host-supplied trust and locally generated private installation','original application effect occurs before policy update and before sender ACK','tampered approval refused with unchanged original request','independent account/policy root approval; request/stage/commit or witness proposal exact replay','P0 to P1 with unchanged credential, roster and SDK policy','original session/message retried after explicit current target selection; one receiver effect','mandatory 18 scenario markers and 166 public records per profile; missing/duplicate evidence refused','native signature verification, public reader grammar/linkage only','132 candidate C exports and product ABI 2 unchanged'],'remaining':['expired-policy first-use recovery','SDK-policy replacement composition','complete corrected-commit installed package pipeline and CI','independent implementation, physical/minimum-OS and other 0.2.0 release requirements'],'release_claim_eligible':False,'publication_performed':False,'capture':{'file':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),'selection':'Only exact public readbacks, test/build diagnostics, source identities, patches and drivers; private runtime directories and installed binaries excluded'}}
(dest/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['capture']))
