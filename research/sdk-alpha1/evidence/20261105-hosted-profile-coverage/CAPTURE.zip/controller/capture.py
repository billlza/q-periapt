from pathlib import Path
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-swift-hosted-20261105/source-232'
DEST = REPO / 'research/sdk-alpha1/evidence/20261105-hosted-profile-coverage'
DEST.mkdir()
result = json.loads((ROOT / 'identity-01/READBACK.json').read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

files = {}
for path in sorted((ROOT / 'identity-01').rglob('*')):
    assert not path.is_symlink()
    if path.is_file():
        files['readback/' + path.relative_to(ROOT / 'identity-01').as_posix()] = path
for name in result['loaded_original_modules']:
    files['source/' + name] = SOURCE / name
for name in ['python-run.sh', 'python-env.sh', 'python_bootstrap.py']:
    files['source/artifact/' + name] = SOURCE / 'artifact' / name
files['source/target/verify_coverage.py'] = SOURCE / 'target/verify_coverage.py'
for name in ['READER_SOURCE.json', 'coverage-readback.stdout', 'coverage-readback.stderr']:
    files['controller/' + name] = SOURCE.parent / name
for name in ['JOBS.json', 'capture.py']:
    files['controller/' + name] = ROOT / name
for name in ['ARTIFACT.json', 'DOWNLOAD.json', '13460680435.zip', 'job-127583678438.log']:
    files['coverage/' + name] = ROOT / 'coverage' / name
for profile in ['debug', 'release']:
    for name in ['ARTIFACT.json', 'DOWNLOAD.json']:
        files['artifacts/kotlin-' + profile + '/' + name] = ROOT / ('kotlin-' + profile) / name
    files['artifacts/swift-' + profile + '/ARTIFACT.json'] = SOURCE.parent / profile / 'ARTIFACT_METADATA.json'
    files['artifacts/android-' + profile + '/ARTIFACT.json'] = REPO / ('target/continuity-android-' + profile + '-hosted-20261105/ARTIFACT.json')
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
        archive.writestr(name, data)
with zipfile.ZipFile(DEST / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    assert archive.testzip() is None
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
for name, source in [('READBACK.json', ROOT / 'identity-01/READBACK.json'),
                     ('COVERAGE.json', ROOT / 'identity-01/HOSTED_COVERAGE.json'), ('JOBS.json', ROOT / 'JOBS.json')]:
    with (DEST / name).open('xb') as stream:
        stream.write(source.read_bytes())
summary = {'source_commit': result['source_commit'], 'members': len(manifest),
    'bytes': (DEST / 'CAPTURE.zip').stat().st_size, 'sha256': sha((DEST / 'CAPTURE.zip').read_bytes()),
    'scope': result['scope'], 'source_bytes_dependency': '../20261105-hosted-swift-pair/INPUTS.zip',
    'source_bytes_dependency_sha256': '9a46fb9d761588cb6da670168d140838a94a17a222608a05aac54447c8e119cd'}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary))
