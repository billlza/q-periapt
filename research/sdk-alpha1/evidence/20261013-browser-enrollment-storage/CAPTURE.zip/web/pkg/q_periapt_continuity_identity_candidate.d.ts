/* tslint:disable */
/* eslint-disable */

/**
 * Experiment owner with explicit creation versus exact original reopening.
 */
export class BrowserEnrollmentProbe {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Close all descendants and await actual release of the browser storage lease.
     */
    close(): Promise<void>;
    /**
     * Create fresh browser-owned vault, wrapping key and original enrollment intent.
     */
    static create(name: string, id: string, root: Uint8Array, description: Uint8Array): Promise<BrowserEnrollmentProbe>;
    /**
     * Reopen existing original state. No error creates or replaces an object.
     */
    static open(name: string, id: string, root: Uint8Array, description: Uint8Array): Promise<BrowserEnrollmentProbe>;
    /**
     * Return the exact committed original request; concurrent use is refused.
     */
    request(now: bigint): Promise<Uint8Array>;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_browserenrollmentprobe_free: (a: number, b: number) => void;
    readonly browserenrollmentprobe_close: (a: number) => any;
    readonly browserenrollmentprobe_create: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly browserenrollmentprobe_open: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly browserenrollmentprobe_request: (a: number, b: bigint) => any;
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___bool__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: number) => [number, number];
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___q_periapt_continuity_identity_candidate_4c9cec294764ac23___storage__browser__HostSecret__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___wasm_bindgen_5ef15f9c59dd1dc3___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
