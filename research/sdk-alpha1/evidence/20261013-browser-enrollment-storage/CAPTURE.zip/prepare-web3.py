from pathlib import Path
import hashlib,shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;web=stage/'web3';shutil.copytree(stage/'web2',web)
wasm=root/'target/continuity-browser-engine/rust-target/wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
sdk.command([str(root/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(web/'pkg'),str(wasm)],stage/'bindgen3',root)
run=(web/'run.js').read_text().replace("import {StorageRoot}","import init,{path_observation} from './pkg/q_periapt_continuity_identity_candidate.js';\nimport {StorageRoot}")
run=run.replace(" const session=id().slice(0,12)"," await init();\n const lexical=['/qpc/test/'+'a'.repeat(64)+'/wrap.key','relative','/a/../b','/a//b','/'];\n const observations=lexical.map(path=>({path,observation:path_observation(path)}));\n require(observations[0].observation.includes('admitted=Ok(())')&&observations.slice(1).every(row=>row.observation.includes('admitted=Err(PrivateFile)')),'logical path admission');results.push({case:'logical-path-admission',observations});\n const session=id().slice(0,12)")
(web/'run.js').write_text(run)
server=(stage/'serve.py').read_text().replace('import json,re','import json,re,threading').replace("output=stage/'browser1'","output=stage/'browser3'").replace("web=stage/'web'","web=stage/'web3'")
server=server.replace("    def do_POST(self):\n","    def do_POST(self):\n        if self.path=='/shutdown' and self.headers.get('Origin')==origin:\n            self.send_response(200);self.end_headers();threading.Thread(target=server.shutdown,daemon=True).start();return\n")
with (stage/'serve3.py').open('x') as output:output.write(server)
sdk.write_json(stage/'WEB3.json',{'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'web_sha256':{p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()}})
