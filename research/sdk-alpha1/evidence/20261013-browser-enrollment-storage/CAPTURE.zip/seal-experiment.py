"""Retain the isolated prototype and public experiment outputs after producers stop."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

stage = Path(__file__).resolve().parent
source = stage / 'source'
repo = stage.parent.parent
out = stage / 'sealed-experiment-01'

def digest(body):
    return hashlib.sha256(body).hexdigest()

suite = json.loads((stage / 'NATIVE_SUITE.json').read_text())
msrv = json.loads((stage / 'MSRV_CHECK.json').read_text())
assert suite['completed'] and not suite['live_producer'] and suite['returncode'] == 0
assert msrv['completed']
suite_output = (stage / 'native-suite.stdout').read_text()
assert 'test result: ok. 959 passed; 0 failed; 0 ignored;' in suite_output
for name, expected in suite['inputs_sha256'].items():
    assert digest((source / name).read_bytes()) == expected, name
assert msrv['input_inventory_sha256'] == digest(json.dumps(suite['inputs_sha256'], sort_keys=True).encode())

browser = json.loads((stage / 'browser3/RESULT.json').read_text())
native = json.loads((stage / 'native-verification3/RESULT.json').read_text())
late = json.loads((stage / 'deadline1/RESULT.json').read_text())
assert browser['completed'] and len(browser['cases']) == 13
assert native['completed'] and native['native_requests_verified'] == 5 and native['distinct_browser_generated_signers'] == 4
assert late['completed'] and {row['mode'] for row in late['cases']} == {'decrypt', 'handle'}
for row in late['cases']:
    assert row['recovered_identically'] and 'CommitUnknown' in row['error'] and 'ClosePending' in row['error']
    assert 'Busy' in row['held_until_completion'] and row['elapsed_ms'] >= 20000
for row in native['requests']:
    request = stage / 'browser3' / row['request']
    assert request.stat().st_size == 5506 and digest(request.read_bytes()) == row['request_sha256']
    credential = stage / 'native-verification3' / (request.stem + '.credential')
    assert digest(credential.read_bytes()) == row['credential_sha256']
web_records = {'web': 'WEB.json', 'web2': 'WEB2.json', 'web3': 'WEB3.json', 'web-deadline': 'DEADLINE_WEB.json'}
for directory, metadata in web_records.items():
    manifest = json.loads((stage / metadata).read_text())
    for name, expected in manifest['web_sha256'].items():
        assert digest((stage / directory / name).read_bytes()) == expected, (directory, name)
web3 = json.loads((stage / 'WEB3.json').read_text())
assert native['wasm_sha256'] == web3['wasm_sha256']
raw_wasm = repo / 'target/continuity-browser-engine/rust-target/wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
assert digest(raw_wasm.read_bytes()) == web3['wasm_sha256']
metadata = json.loads((stage / 'WEB.json').read_text())
assert digest(Path(metadata['native_binary']).read_bytes()) == metadata['native_binary_sha256']

members = {}
def add(path, name=None):
    key = name or path.relative_to(stage).as_posix()
    assert key not in members and not key.startswith('/') and '..' not in Path(key).parts
    assert 'private-issuer' not in Path(key).parts
    members[key] = path.read_bytes()

for filename in (
    'NATIVE_SUITE.json', 'MSRV_CHECK.json', 'WEB.json', 'WEB2.json', 'WEB3.json', 'DEADLINE_WEB.json',
    'native-suite.py', 'native-suite.stdout', 'native-suite.stderr', 'native-suite-driver.stdout', 'native-suite-driver.stderr',
    'msrv-check.py', 'msrv-check.json', 'msrv-check.stdout', 'msrv-check.stderr', 'cargo-msrv-isolated.sh',
    'native-prepare.json', 'native-prepare.stdout', 'native-prepare.stderr',
    'browser-storage-before-import-fix.rs', 'fix-import.py', 'verify-browser3.py', 'verify3.stdout', 'verify3.stderr',
    'prepare-web.py', 'prepare-web2.py', 'prepare-web3.py', 'prepare-deadline.py', 'prepare-diagnostic.py',
    'serve.py', 'serve2.py', 'serve3.py', 'serve-deadline.py', 'serve-diagnostic.py',
    'browser-close1.stdout', 'browser-close1.stderr', 'browser-close2.stdout', 'browser-close2.stderr',
    'browser-close3.stdout', 'browser-close3.stderr', 'browser-close-deadline.stdout', 'browser-close-deadline.stderr',
    'browser-close-diagnostic.stdout', 'browser-close-diagnostic.stderr',
    'seal-experiment.py',
):
    add(stage / filename)
for path in stage.iterdir():
    if path.is_file() and re.fullmatch(r'(check[1-8]|native-check[12]|native-clippy1|wasm-clippy1|wasm-build[234]?|wasm-diagnostic|native-fixture)\.(jsonl|stderr)', path.name):
        add(path)
for directory in ('browser1', 'browser2', 'browser3', 'diagnostic1', 'native-verification3', 'deadline1', 'web3'):
    for path in sorted((stage / directory).rglob('*')):
        if path.is_file():
            add(path)
for directory in ('web', 'web2', 'web-diagnostic'):
    # Preserve the failed import and path admissions without private browser state.
    for path in sorted((stage / directory).rglob('*')):
        if path.is_file() and path.suffix in ('.js', '.ts', '.html'):
            add(path)
for filename in ('index.html', 'deadline-worker.js'):
    add(stage / 'web-deadline' / filename)
add(raw_wasm, 'build/raw-cargo-output.wasm')
changed = subprocess.check_output(['git','diff','--name-only'], cwd=source, text=True).splitlines()
untracked = subprocess.check_output(['git','ls-files','--others','--exclude-standard'], cwd=source, text=True).splitlines()
assert len(changed + untracked) == len(set(changed + untracked))
for name in changed + untracked:
    assert name.startswith('research/continuity-identity-candidate/')
    add(source / name, 'source-overlay/' + name)
members['source.patch'] = subprocess.check_output(['git','diff','--binary'], cwd=source)
members['SCOPE.txt'] = (
    'Isolated browser-owned enrollment storage prototype; not integrated into the product entry.\n'
    'Apply source.patch to base 7290c6f02b0fdebbaaed5b2916dc68904267710a and copy source-overlay to reconstruct source.\n'
    'All exposed inputs/requests/credentials are public. Private issuer keys, browser profiles and private journals are excluded.\n'
    'The native verifier uses the same Rust protocol implementation; this is not independent-implementation interoperability.\n'
    'The two late completion cases inject scheduling delays into actual WebCrypto and OPFS operations.\n'
    'Native/MSRV compilation does not establish installed-package qualification. The browser backend still includes a repository-relative private module.\n'
    'Initial creation interruption, activation/grants, full lifecycle, authenticated catalogue, public errors/cancellation, HTTPS and package admission remain open.\n'
).encode()
out.mkdir(mode=0o700)
archive_path = out / 'CAPTURE.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, body in sorted(members.items()):
        archive.writestr(name, body)
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(members)
    for name, body in members.items():
        assert archive.read(name) == body
record = {
    'schema_version': 1, 'source_base': suite['source_base'], 'product_integrated': False,
    'native_suite': {'passed': 959, 'failed': 0, 'ignored': 0, 'inputs_unchanged': True},
    'native_msrv': {'toolchain': msrv['toolchain'], 'tests_and_examples_all_features_compiled': True},
    'browser': {'cases': 13, 'requests_native_verified': 5, 'distinct_generated_signers': 4,
                'raw_cargo_wasm_sha256': web3['wasm_sha256'],
                'served_bindgen_wasm_sha256': web3['web_sha256']['pkg/q_periapt_continuity_identity_candidate_bg.wasm'],
                'real_worker_cut': 'after committed original request, before its reply reached host'},
    'late_completion': {'cases': 2, 'lock_held_until_real_resource_completion': True, 'fault_injection': True},
    'retained_failures': ['initial HostRoot import mismatch', 'wasm Path::is_absolute rejected a valid logical rooted path'],
    'scope_file': 'SCOPE.txt', 'release_claim_eligible': False,
    'capture': {'file': archive_path.name, 'sha256': digest(archive_path.read_bytes()),
                'bytes': archive_path.stat().st_size, 'members': len(members),
                'member_sha256': {name: digest(body) for name, body in sorted(members.items())}},
}
(out / 'CHECKS.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('source_base','native_suite','native_msrv','browser','late_completion','release_claim_eligible')}))
print(json.dumps({key: record['capture'][key] for key in ('sha256','bytes','members')}))
