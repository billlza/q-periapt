import init,{BrowserEnrollmentProbe} from './pkg/q_periapt_continuity_identity_candidate.js';
import {lease} from './pkg/policy-database.js';
await init();
const hex=bytes=>[...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
const sha=async bytes=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)));
const publicBytes=async path=>{const response=await fetch('/inputs/'+path);if(!response.ok)throw Error('public input fetch failed');return new Uint8Array(await response.arrayBuffer())};
const originalRoot=await publicBytes('root.bin'),originalDescription=await publicBytes('description.bin');
const failed=(condition,message)=>{if(!condition)throw Error(message)};
async function observed(promise){try{return {ok:true,value:await promise}}catch(error){return {ok:false,error:String(error)}}}
async function database(name){return new Promise((resolve,reject)=>{const request=indexedDB.open('qperiapt-continuity-storage/1/'+name,1);
 request.onupgradeneeded=()=>{request.transaction.abort();reject(Error('fixture root absent'))};request.onerror=()=>reject(request.error);request.onsuccess=()=>resolve(request.result);
})}
async function image(db,mutate){return new Promise((resolve,reject)=>{const tx=db.transaction(['root','files'],'readwrite',{durability:'strict'});let root,rows,keys;
 failed(tx.durability==='strict','strict fixture transaction');tx.onabort=()=>reject(tx.error??Error('fixture transaction aborted'));tx.onerror=()=>reject(tx.error);tx.oncomplete=()=>resolve({root,rows,keys});
 const a=tx.objectStore('root').get('current'),b=tx.objectStore('files').getAll(),c=tx.objectStore('files').getAllKeys();let count=0;
 const ready=()=>{if(++count!==3)return;root=a.result;rows=b.result;keys=c.result;if(mutate)mutate(tx,root,rows,keys)};
 for(const request of [a,b,c])request.onsuccess=ready;
})}
async function inspect(name,id,operation){
 const release=await lease('qperiapt-continuity-storage/1/'+name);let db;
 try{
  db=await database(name);const before=await image(db);failed(before.root.id===id,'fixture root identity');
  const keyIndex=before.keys.indexOf('/qpc/'+name+'/'+id+'/wrap.key');failed(keyIndex>=0,'wrapping entry absent');
  const ciphertext=before.rows[keyIndex].data;const wrapHash=await sha(ciphertext);
  if(operation==='vault'){
   const exported=await observed(crypto.subtle.exportKey('raw',before.root.key));
   failed(!exported.ok&&!before.root.key.extractable,'vault key export admitted');
   return {files:before.rows.length,extractable:before.root.key.extractable,exportError:exported.error,wrapHash,ciphertextBytes:ciphertext.length};
  }
  if(operation==='corrupt-wrap'){
   await image(db,(tx,_root,rows,keys)=>{const index=keys.indexOf('/qpc/'+name+'/'+id+'/wrap.key'),changed=rows[index].data.slice();changed[0]^=1;tx.objectStore('files').put({...rows[index],data:changed},keys[index])});
   const after=await image(db);return {before:wrapHash,after:await sha(after.rows[keyIndex].data)};
  }
  if(operation==='truncate-database'){
   const row=before.rows.find(row=>row.kind==='database');failed(!!row,'original database absent');
   const parent=await navigator.storage.getDirectory(),directory=await parent.getDirectoryHandle('qpc-'+name+'-'+id);
   const file=await directory.getFileHandle('db-'+row.id),handle=await file.createSyncAccessHandle();
   try{const length=handle.getSize();failed(length>16,'original database width');handle.truncate(8);handle.flush();return {beforeBytes:length,afterBytes:handle.getSize()}}finally{handle.close()}
  }
  throw Error('unknown fixture mutation');
 }finally{db?.close();await release()}
}
self.onmessage=async({data})=>{
 let owner,output;
 try{
  const {name,id,operation}=data;failed(/^[a-z0-9-]+$/.test(name)&&/^[0-9a-f]{64}$/.test(id),'test scope');
  if(['vault','corrupt-wrap','truncate-database'].includes(operation)){output={done:true,value:await inspect(name,id,operation)};return}
  const description=originalDescription.slice();if(data.wrongIntent)description[0]^=1;
  owner=await BrowserEnrollmentProbe[data.create?'create':'open'](name,id,originalRoot,description);
  const now=()=>BigInt(Math.floor(Date.now()/1000));let wire,detail={};
  if(operation==='busy'){
   const pending=owner.request(now()),other=await observed(owner.request(now()));wire=await pending;
   failed(!other.ok&&other.error.includes('WouldBlock'),'simultaneous owner request not refused');
   const rootBusy=await observed(BrowserEnrollmentProbe.open(name,id,originalRoot,description));
   failed(!rootBusy.ok&&rootBusy.error.includes('Busy'),'second storage owner admitted');detail={concurrent:other.error,rootBusy:rootBusy.error};
  }else if(operation==='cancel'){
   const pending=observed(owner.request(now()));await Promise.resolve();await owner.close();const result=await pending;
   failed(!result.ok,'cancelled owner returned request');detail={cancelled:result.error};
   const later=await observed(owner.request(now()));failed(!later.ok&&later.error.includes('Closed'),'closed owner reused');
   output={done:true,value:detail};return;
  }else wire=await owner.request(now());
  const original=wire.slice();failed(original.length===5506,'request shape');
  const digest=await sha(original);
  if(operation==='kill-request'){
   postMessage({stage:'committed-request',sha256:digest});await new Promise(()=>{});return;
  }
  const repeated=await owner.request(now());failed(await sha(repeated)===digest,'committed request changed');
  await owner.close();const refusal=await observed(owner.request(now()));failed(!refusal.ok,'closed owner not fenced');
  output={done:true,value:{request:[...original],sha256:digest,...detail}};
 }catch(error){output={done:true,error:String(error)}}
 finally{
  if(owner){try{await owner.close();owner.free()}catch(error){output={done:true,error:(output?.error??'operation completed')+'; cleanup: '+String(error)}}}
  if(output)postMessage(output);
 }
};
postMessage({ready:true});
