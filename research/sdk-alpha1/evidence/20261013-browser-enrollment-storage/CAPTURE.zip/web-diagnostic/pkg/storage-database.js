// SPDX-License-Identifier: Apache-2.0 OR MIT
import {QPeriaptStorageError} from './policy-database.js';
export const fail=(code,cause)=>new QPeriaptStorageError(code,cause);
export const ioError=e=>e instanceof QPeriaptStorageError?e:fail(e?.name==='QuotaExceededError'?'QuotaExceeded':e?.name==='ConstraintError'?'Exists':'Storage',e);
export function validateRoot(value,id){
 if(!value||Object.keys(value).sort().join(',')!=='id,key,phase,schema'||value.schema!==1||value.id!==id||!['creating','live'].includes(value.phase)
  ||!(value.key instanceof CryptoKey)||value.key.type!=='secret'||value.key.extractable||value.key.algorithm.name!=='AES-GCM'||value.key.algorithm.length!==256
  ||[...value.key.usages].sort().join(',')!=='decrypt,encrypt')throw fail('Corrupt');
 return value;
}
export function openDatabase(name,initial){
 return new Promise((resolve,reject)=>{
  let settled=false,created=false,failure;const request=indexedDB.open(name,1);
  const timer=setTimeout(()=>finish(fail('OpenUnknown')),10000);
  function finish(error,db){if(settled){db?.close();return}settled=true;clearTimeout(timer);if(error){db?.close();reject(error)}else resolve(db)}
  request.onblocked=()=>finish(fail('Busy'));
  request.onupgradeneeded=event=>{
   if(settled||!initial||event.oldVersion!==0){failure=fail(initial?'Exists':'Absent');request.transaction.abort();return}
   created=true;request.transaction.onerror=e=>{failure??=ioError(e.target.error??request.transaction.error)};
   try{const db=request.result;db.createObjectStore('root').add(initial,'current');db.createObjectStore('files')}catch(e){failure=ioError(e);request.transaction.abort()}
  };
  request.onerror=()=>finish(failure??ioError(request.error));
  request.onsuccess=()=>{
   const db=request.result;
   if(initial&&!created){finish(fail('Exists'),db);return}
   if(db.version!==1||[...db.objectStoreNames].sort().join(',')!=='files,root'){finish(fail('Corrupt'),db);return}
   finish(undefined,db);
  };
 });
}
// A strict transaction also seals read/reopen observations. Missing is an explicit
// result from a completed transaction, never a substitute for an I/O failure.
export function transact(db,id,signal,operation){
 return new Promise((resolve,reject)=>{
  let tx,result,ready=false,settled=false,failure;
  function finish(error){if(settled)return;settled=true;clearTimeout(timer);signal.removeEventListener('abort',cancel);error?reject(error):ready?resolve(result):reject(fail('Corrupt'))}
  function abort(error){failure??=error;try{tx?.abort()}catch(cause){failure=fail('CommitUnknown',new AggregateError([failure,cause]))}finish(failure)}
  function cancel(){abort(fail('CommitUnknown'))}
  const timer=setTimeout(()=>abort(fail('CommitUnknown')),10000);
  if(signal.aborted){finish(fail('Closed'));return}signal.addEventListener('abort',cancel,{once:true});
  try{
   tx=db.transaction(['root','files'],'readwrite',{durability:'strict'});
   tx.oncomplete=()=>finish(failure);tx.onabort=()=>finish(failure??ioError(tx.error??new DOMException('transaction aborted','AbortError')));
   tx.onerror=e=>{failure??=ioError(e.target.error??tx.error)};
   if(tx.durability!=='strict'){abort(fail('Unavailable'));return}
   const roots=tx.objectStore('root'),files=tx.objectStore('files');
   if(roots.keyPath!==null||files.keyPath!==null||roots.autoIncrement||files.autoIncrement){abort(fail('Corrupt'));return}
   const keys=roots.getAllKeys(undefined,2);keys.onsuccess=()=>{
    if(settled)return;if(keys.result.length!==1||keys.result[0]!=='current'){abort(fail('Corrupt'));return}
    const request=roots.get('current');request.onsuccess=()=>{
     if(settled)return;
     try{
      const root=validateRoot(request.result,id),count=files.count();count.onsuccess=()=>{
       if(settled)return;
       try{
        if(count.result>256||(root.phase==='creating'?count.result!==0:count.result===0))throw fail('Corrupt');
        const done=(value,published=false)=>{result=value;ready=true;roots.put(published?{...root,phase:'live'}:root,'current')};
        const checked=callback=>event=>{if(settled)return;try{callback(event)}catch(e){abort(ioError(e))}};
        operation(files,root,count.result,done,checked);
       }catch(e){abort(ioError(e))}
      };
     }catch(e){abort(ioError(e))}
    };
   };
  }catch(e){abort(ioError(e))}
 });
}
