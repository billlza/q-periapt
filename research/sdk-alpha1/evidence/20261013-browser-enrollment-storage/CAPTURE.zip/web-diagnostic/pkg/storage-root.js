// SPDX-License-Identifier: Apache-2.0 OR MIT
import {lease} from './policy-database.js';
import {fail,ioError,openDatabase,transact} from './storage-database.js';
const token=Symbol('owned-browser-storage');const MAX_DB=64*1024*1024,MAX_BYTES=65536;
const hex=bytes=>[...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
const identifier=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
function deadline(task,code,onTimeout){
 return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{onTimeout?.();reject(fail(code))},10000);
  task.then(value=>{clearTimeout(timer);resolve(value)},error=>{clearTimeout(timer);reject(error)});
 });
}
function record(value){
 if(value===undefined)return null;
 if(!value||!/^([a-f0-9]{64})$/.test(value.id)||!Number.isSafeInteger(value.revision)||value.revision<1)throw fail('Corrupt');
 if(value.kind==='database'){
  if(Object.keys(value).sort().join(',')!=='id,kind,revision'||value.revision!==1)throw fail('Corrupt');
 }else if(value.kind==='bytes'){
  if(Object.keys(value).sort().join(',')!=='data,id,iv,kind,length,revision'||!(value.iv instanceof Uint8Array)||value.iv.length!==12
   ||!(value.data instanceof Uint8Array)||!Number.isSafeInteger(value.length)||value.length<1||value.length>MAX_BYTES||value.data.length!==value.length+16)throw fail('Corrupt');
 }else throw fail('Corrupt');return value;
}
function rootInputs(name,id){
 if(!isSecureContext||typeof DedicatedWorkerGlobalScope!=='function'||!(self instanceof DedicatedWorkerGlobalScope)||!crypto.subtle||!navigator.storage?.getDirectory)throw fail('Unavailable');
 if(typeof name!=='string'||!/^[a-zA-Z0-9_-]{1,96}$/.test(name)||typeof id!=='string'||!/^[a-f0-9]{64}$/.test(id)||/^0+$/.test(id))throw new TypeError('Invalid storage identity');
 return {name:'qperiapt-continuity-storage/1/'+name,id};
}
function extent(offset,length){if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset<0||length<0||offset+length>MAX_DB)throw fail('Capacity')}
export class SecretLease{
 #bytes;#release;
 constructor(t,bytes,release){if(t!==token)throw new TypeError('Owned secret lease');this.#bytes=new Uint8Array(bytes);this.#release=release}
 bytes(){if(!this.#bytes)throw fail('Closed');return this.#bytes}
 close(){if(this.#bytes){this.#bytes.fill(0);this.#bytes=undefined;this.#release(this)}}
}
export class DatabaseLease{
 #root;#handle;#path;#id;#published;
 constructor(t,root,handle,path,id,published){if(t!==token)throw new TypeError('Owned database lease');this.#root=root;this.#handle=handle;this.#path=path;this.#id=id;this.#published=published}
 #check(){if(!this.#handle)throw fail('Closed');this.#root.check()}
 getSize(){this.#check();const n=this.#handle.getSize();extent(0,n);return n}
 read(offset,out){this.#check();if(!(out instanceof Uint8Array))throw new TypeError('read buffer');extent(offset,out.length);return this.#handle.read(out,{at:offset})}
 write(offset,bytes){this.#check();if(!(bytes instanceof Uint8Array))throw new TypeError('write buffer');extent(offset,bytes.length);return this.#handle.write(bytes,{at:offset})}
 resize(size){this.#check();extent(0,size);this.#handle.truncate(size)}
 flush(){this.#check();this.#handle.flush()}
 identity(){this.#check();return this.#id}
 publication(root,path){this.#check();if(root!==this.#root||path!==this.#path||this.#published)throw fail('Conflict');return this.#id}
 markPublished(){this.#check();this.#published=true}
 close(){if(this.#handle){const h=this.#handle;this.#handle=undefined;try{h.close()}finally{this.#root.released(this,this.#path)}}}
}
export class StorageRoot{
 #db;#directory;#name;#id;#key;#release;#signal=new AbortController();#closed=false;#busy=false;#pending;#closing;#closeError;
 #children=new Set();#paths=new Set();
 constructor(t,db,directory,name,id,key,release){if(t!==token)throw new TypeError('Use create/open');this.#db=db;this.#directory=directory;this.#name=name;this.#id=id;this.#key=key;this.#release=release;
  const invalidate=()=>{this.close().catch(e=>{this.#closeError=e})};db.onversionchange=invalidate;db.onclose=invalidate;
 }
 static async create(name,id){return StorageRoot.#open(name,id,true)}
 static async open(name,id){return StorageRoot.#open(name,id,false)}
 static async #open(name,id,create){
  const selected=rootInputs(name,id),release=await lease(selected.name);let db;
  try{
   const initial=create?{schema:1,id,key:await deadline(crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']),'OpenUnknown'),phase:'creating'}:undefined;
   db=await openDatabase(selected.name,initial);const signal=new AbortController();
   const meta=await transact(db,id,signal.signal,(_files,root,_count,done)=>done(root));
   const parent=await deadline(navigator.storage.getDirectory(),'OpenUnknown');let directory;
   try{directory=await deadline(parent.getDirectoryHandle('qpc-'+name+'-'+id,{create:meta.phase==='creating'}),'OpenUnknown')}catch(e){throw e instanceof DOMException?fail(e.name==='NotFoundError'?'Absent':'Storage',e):ioError(e)}
   return new StorageRoot(token,db,directory,name,id,meta.key,release);
  }catch(e){db?.close();await release();throw ioError(e)}
 }
 prefix(){this.check();return '/qpc/'+this.#name+'/'+this.#id+'/'}
 check(){if(this.#closed)throw fail('Closed',this.#closeError)}
 #path(path){this.check();const prefix=this.prefix();if(typeof path!=='string'||!path.startsWith(prefix)||path.length>4096)throw new TypeError('Invalid scoped path');
  const name=path.slice(prefix.length);if(!/^[a-zA-Z0-9_./-]{1,1024}$/.test(name)||name.split('/').some(p=>!p||p==='.'||p==='..'))throw new TypeError('Invalid scoped path');return path;
 }
 #aad(path,value){return new TextEncoder().encode(JSON.stringify(['QPC-BROWSER-PRIVATE-BYTES/v1',this.#id,path,value.id,value.revision,value.length]))}
 #transaction(operation){return transact(this.#db,this.#id,this.#signal.signal,operation)}
 async #run(operation){
  this.check();if(this.#busy)throw fail('Busy');this.#busy=true;
  const task=(async()=>{try{const result=await operation();this.check();return result}catch(e){throw ioError(e)}finally{this.#busy=false;this.#pending=undefined}})();
  this.#pending=task;
  return deadline(task,'CommitUnknown',()=>{
   this.#closed=true;this.#signal.abort();
   Promise.allSettled([task]).then(()=>this.#finishClose()).catch(error=>{this.#closeError=error});
  });
 }
 async #lookup(path){return this.#transaction((files,_root,_count,done,checked)=>{const r=files.get(path);r.onsuccess=checked(()=>done(record(r.result)))})}
 async missing(path){path=this.#path(path);return this.#run(async()=>await this.#lookup(path)===null)}
 async publishSecret(path,bytes){
  path=this.#path(path);if(!(bytes instanceof Uint8Array)||bytes.length<1||bytes.length>MAX_BYTES)throw new TypeError('Secret file width');const copy=bytes.slice();
  try{return await this.#run(async()=>{
   if(await this.#lookup(path)!==null)throw fail('Exists');
   const value={kind:'bytes',id:identifier(),revision:1,length:copy.length,iv:crypto.getRandomValues(new Uint8Array(12))};
   const data=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:value.iv,additionalData:this.#aad(path,value)},this.#key,copy));this.check();
   await this.#transaction((files,_root,count,done)=>{if(count>=256)throw fail('Capacity');files.add({...value,data},path);done(undefined,true)});
  })}finally{copy.fill(0)}
 }
 async readSecret(path){path=this.#path(path);return this.#run(async()=>{
  const value=await this.#lookup(path);if(!value)throw fail('Absent');if(value.kind!=='bytes')throw fail('Corrupt');let plain;
  try{plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:value.iv,additionalData:this.#aad(path,value)},this.#key,value.data)}catch(e){throw fail('Authentication',e)}
  if(this.#closed){new Uint8Array(plain).fill(0);throw fail('Closed')}
  const result=new SecretLease(token,plain,x=>this.#children.delete(x));this.#children.add(result);return result;
 })}
 released(child,path){this.#children.delete(child);if(path)this.#paths.delete(path)}
 async stageDatabase(path){path=this.#path(path);return this.#run(async()=>{
  if(await this.#lookup(path)!==null)throw fail('Exists');if(this.#paths.has(path))throw fail('Busy');if(this.#children.size>=64)throw fail('Capacity');
  let id,file;
  for(let attempt=0;attempt<4;attempt++){
   id=identifier();try{await this.#directory.getFileHandle('db-'+id)}catch(e){if(e.name!=='NotFoundError')throw e;file=await this.#directory.getFileHandle('db-'+id,{create:true});break}
  }
  if(!file)throw fail('Capacity');const handle=await file.createSyncAccessHandle();const result=new DatabaseLease(token,this,handle,path,id,false);this.#children.add(result);this.#paths.add(path);
  try{if(result.getSize()!==0)throw fail('Corrupt');return result}catch(e){result.close();throw e}
 })}
 async openDatabase(path){path=this.#path(path);return this.#run(async()=>{
  if(this.#paths.has(path))throw fail('Busy');if(this.#children.size>=64)throw fail('Capacity');
  const value=await this.#lookup(path);if(!value)throw fail('Absent');if(value.kind!=='database')throw fail('Corrupt');
  let file;try{file=await this.#directory.getFileHandle('db-'+value.id)}catch(e){throw fail(e.name==='NotFoundError'?'Absent':'Storage',e)}
  const handle=await file.createSyncAccessHandle();const result=new DatabaseLease(token,this,handle,path,value.id,true);this.#children.add(result);this.#paths.add(path);
  try{if(result.getSize()<16)throw fail('Corrupt');return result}catch(e){result.close();throw e}
 })}
 async publishDatabase(path,file){path=this.#path(path);return this.#run(async()=>{
  if(!(file instanceof DatabaseLease)||!this.#children.has(file))throw fail('Conflict');const id=file.publication(this,path);if(file.getSize()<16)throw fail('Corrupt');file.flush();
  await this.#transaction((files,_root,count,done)=>{if(count>=256)throw fail('Capacity');files.add({kind:'database',id,revision:1},path);done(undefined,true)});
  file.markPublished();
 })}
 async #finishClose(){
  if(this.#closing)return this.#closing;
  this.#closing=(async()=>{let failure;for(const child of [...this.#children]){try{child.close()}catch(e){failure??=e}}this.#key=undefined;this.#db.close();await this.#release();if(failure)throw ioError(failure)})();
  return this.#closing;
 }
 async close(){
  this.#closed=true;this.#signal.abort();
  const finish=(async()=>{if(this.#pending)await Promise.allSettled([this.#pending]);return this.#finishClose()})();
  return deadline(finish,'ClosePending');
 }
 beginClose(){this.close().catch(error=>{this.#closeError=error})}
}
