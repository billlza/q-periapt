import {StorageRoot} from './pkg/storage-root.js';
const results=[],workers=new Set();const require=(value,message)=>{if(!value)throw Error(message)};
const id=()=>[...crypto.getRandomValues(new Uint8Array(32))].map(x=>x.toString(16).padStart(2,'0')).join('');
async function save(name,bytes){const response=await fetch('/capture/'+name,{method:'POST',body:bytes});require(response.ok,'capture '+name)}
function run(data,kill=false){return new Promise((resolve,reject)=>{
 const worker=new Worker('./worker.js',{type:'module'});workers.add(worker);const timer=setTimeout(()=>finish(Error('Worker deadline')),45000);
 function finish(error,value){clearTimeout(timer);worker.terminate();workers.delete(worker);error?reject(error):resolve(value)}
 worker.onerror=e=>finish(Error('Worker failure: '+e.message));worker.onmessage=({data:message})=>{
  if(message.ready){worker.postMessage(data);return}
  if(message.cleanupError){finish(Error(message.cleanupError));return}
  if(message.stage){if(kill&&message.stage==='committed-request')finish(undefined,{cut:message.sha256});else finish(Error('unexpected stage'));return}
  if(message.done)finish(undefined,message);
 };
})}
async function request(name,identity,create=false,operation='request'){
 const value=await run({name,id:identity,create,operation});require(!value.error,value.error);
 const bytes=new Uint8Array(value.value.request);await save(name+'-'+operation+'-'+(create?'create':'open')+'.bin',bytes);return value.value;
}
async function rejected(data,pattern){const result=await run(data);require(result.error&&pattern.test(result.error),'expected refusal '+JSON.stringify(result));return result.error}
try{
 const session=id().slice(0,12),scope='owned-'+session,identity=id();
 let windowError;try{await StorageRoot.create('window-'+session,id())}catch(error){windowError=error.code}
 require(windowError==='Unavailable','Window OPFS admission changed');results.push({case:'window-refused',error:windowError});
 const missing=await rejected({name:'absent-'+session,id:id(),operation:'request'},/Absent/);results.push({case:'missing-refused',error:missing});
 const created=await request(scope,identity,true,'busy');
 const reopened=await request(scope,identity);require(created.sha256===reopened.sha256,'Worker restart changed request');
 results.push({case:'generated-and-reopened',name:scope,id:identity,sha256:created.sha256,concurrent:created.concurrent,rootBusy:created.rootBusy});
 results.push({case:'duplicate-create',error:await rejected({name:scope,id:identity,create:true,operation:'request'},/Exists/)});
 results.push({case:'wrong-id',error:await rejected({name:scope,id:id(),operation:'request'},/Corrupt/)});
 results.push({case:'wrong-intent',error:await rejected({name:scope,id:identity,wrongIntent:true,operation:'request'},/Authentication|Conflict/)});
 const restored=await run({name:scope,id:identity,operation:'request'});require(!restored.error&&restored.value.sha256===created.sha256,'refusal changed original request');
 const vault=await run({name:scope,id:identity,operation:'vault'});require(!vault.error&&vault.value.files===3&&vault.value.ciphertextBytes===56,'browser vault shape');results.push({case:'vault',...vault.value});
 const namespace='other-'+session;const independent=await request(namespace,identity,true);require(independent.sha256!==created.sha256,'different named root reused identity');
 const originalAgain=await run({name:scope,id:identity,operation:'request'});require(!originalAgain.error&&originalAgain.value.sha256===created.sha256,'same-id namespaces interfered');results.push({case:'name-isolation',name:namespace,id:identity,sha256:independent.sha256});
 const cutName='cut-'+session,cutId=id();const cut=await run({name:cutName,id:cutId,create:true,operation:'kill-request'},true);
 require(!!cut.cut,'committed request cut absent');const resumed=await request(cutName,cutId);require(resumed.sha256===cut.cut,'termination changed original committed request');results.push({case:'actual-worker-cut',name:cutName,id:cutId,sha256:cut.cut});
 const cancelledName='cancel-'+session,cancelledId=id();const cancelled=await run({name:cancelledName,id:cancelledId,create:true,operation:'cancel'});require(!cancelled.error,cancelled.error);
 const afterCancel=await request(cancelledName,cancelledId);results.push({case:'cancel-and-reopen',name:cancelledName,id:cancelledId,sha256:afterCancel.sha256,...cancelled.value});
 const damaged=await run({name:namespace,id:identity,operation:'corrupt-wrap'});require(!damaged.error&&damaged.value.before!==damaged.value.after,'corruption control absent');
 const refusal=await rejected({name:namespace,id:identity,operation:'request'},/Authentication/);const noReplace=await rejected({name:namespace,id:identity,create:true,operation:'request'},/Exists/);
 results.push({case:'damaged-key-refused',error:refusal,replacement:noReplace,...damaged.value});
 const shortened=await run({name:cutName,id:cutId,operation:'truncate-database'});require(!shortened.error&&shortened.value.afterBytes===8,'truncation control absent');
 const first=await rejected({name:cutName,id:cutId,operation:'request'},/Corrupt/),second=await rejected({name:cutName,id:cutId,operation:'request'},/Corrupt/);
 results.push({case:'short-database-no-handle-leak',...shortened.value,first,second});
 const result={completed:true,scope:'isolated real browser-owned enrollment storage; native issuer still verifies captured requests',browser:navigator.userAgent,cases:results};
 await save('RESULT.json',JSON.stringify(result,null,2));globalThis.result=result;document.querySelector('#result').textContent=JSON.stringify(result,null,2);
}catch(error){const result={completed:false,error:String(error),cases:results};globalThis.result=result;document.querySelector('#result').textContent=JSON.stringify(result,null,2);await save('FAILED.json',JSON.stringify(result,null,2))}
finally{for(const worker of workers)worker.terminate();workers.clear()}
