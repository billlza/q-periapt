from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;web=stage/'web-diagnostic';shutil.copytree(stage/'web2',web)
wasm=root/'target/continuity-browser-engine/rust-target/wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
sdk.command([str(root/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(web/'pkg'),str(wasm)],stage/'bindgen-diagnostic',root)
(web/'index.html').write_text('''<!doctype html><title>Browser lexical path diagnostic</title><pre id="result"></pre><script type="module">
import init,{path_observation} from './pkg/q_periapt_continuity_identity_candidate.js';
await init();const paths=['/qpc/test/'+ 'a'.repeat(64)+'/wrap.key','/tmp/test','relative','/a/../b','/a//b'];
const result=paths.map(path=>({path,observation:path_observation(path)}));globalThis.result=result;document.querySelector('#result').textContent=JSON.stringify(result,null,2);
const response=await fetch('/capture/DIAG.json',{method:'POST',body:JSON.stringify(result,null,2)});if(!response.ok)throw Error('diagnostic capture failed');
</script>''')
server=(stage/'serve.py').read_text().replace("output=stage/'browser1'","output=stage/'diagnostic1'").replace("web=stage/'web'","web=stage/'web-diagnostic'")
with (stage/'serve-diagnostic.py').open('x') as output:output.write(server)
