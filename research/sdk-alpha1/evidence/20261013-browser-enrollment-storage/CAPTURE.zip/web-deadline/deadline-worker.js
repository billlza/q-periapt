import init,{BrowserEnrollmentProbe} from './pkg/q_periapt_continuity_identity_candidate.js';
await init();
const require=(value,message)=>{if(!value)throw Error(message)};
const id=()=>[...crypto.getRandomValues(new Uint8Array(32))].map(x=>x.toString(16).padStart(2,'0')).join('');
const fetchBytes=async path=>{const response=await fetch('/inputs/'+path);require(response.ok,'fixture fetch');return new Uint8Array(await response.arrayBuffer())};
const root=await fetchBytes('root.bin'),description=await fetchBytes('description.bin'),results=[];
const observed=async task=>{try{return {ok:true,value:await task}}catch(error){return {ok:false,error:String(error)}}};
const sha=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
async function acquireReceipt(lockName){
 const until=performance.now()+5000;
 while(performance.now()<until){const locks=await navigator.locks.query();if(!locks.held.some(lock=>lock.name===lockName))return;await new Promise(resolve=>setTimeout(resolve,20))}
 throw Error('original browser storage lease not released');
}
try{
 for(const mode of ['decrypt','handle']){
  postMessage({progress:'Testing late '+mode+' completion'});
  const name='late-'+mode+'-'+id().slice(0,10),identity=id(),now=()=>BigInt(Math.floor(Date.now()/1000));
  let initial=await BrowserEnrollmentProbe.create(name,identity,root,description);const original=await sha(await initial.request(now()));await initial.close();initial.free();initial=undefined;
  let release,entered=false;const gate=new Promise(resolve=>{release=resolve});
  const prototype=mode==='decrypt'?SubtleCrypto.prototype:FileSystemFileHandle.prototype;
  const method=mode==='decrypt'?'decrypt':'createSyncAccessHandle',originalMethod=prototype[method];
  const descriptor=Object.getOwnPropertyDescriptor(prototype,method);require(!!descriptor&&descriptor.writable,'injectable browser completion');
  Object.defineProperty(prototype,method,{...descriptor,value:async function(...args){
   const pending=originalMethod.apply(this,args);
   if(entered)return pending;entered=true;const value=await pending;await gate;return value;
  }});
  let row;
  try{
   const start=performance.now(),attempt=await observed(BrowserEnrollmentProbe.open(name,identity,root,description)),elapsed=performance.now()-start;
   require(entered&&!attempt.ok&&attempt.error.includes('CommitUnknown')&&attempt.error.includes('ClosePending'),'late operation reported success or lost uncertain cleanup');
   require(elapsed>=19000&&elapsed<35000,'two unchanged deadline bounds were not observed');
   const conflict=await observed(BrowserEnrollmentProbe.open(name,identity,root,description));require(!conflict.ok&&conflict.error.includes('Busy'),'lease released before actual resource completion');
   row={mode,elapsed_ms:elapsed,error:attempt.error,held_until_completion:conflict.error};
  }finally{Object.defineProperty(prototype,method,descriptor);release()}
  await acquireReceipt('qperiapt-continuity-storage/1/'+name);
  const reopened=await BrowserEnrollmentProbe.open(name,identity,root,description);
  try{const recovered=await sha(await reopened.request(now()));require(recovered===original,'late cleanup changed original request');row.original_request_sha256=original;row.recovered_identically=true}
  finally{await reopened.close();reopened.free()}
  results.push(row);
 }
 postMessage({completed:true,scope:'scheduler-injected late completion over actual browser crypto and file handles; unchanged 10-second operation and cleanup deadlines',cases:results});
}catch(error){postMessage({completed:false,error:String(error),cases:results})}
