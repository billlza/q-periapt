from pathlib import Path
import shutil
stage=Path(__file__).resolve().parent
path=stage/'source/research/continuity-identity-candidate/src/storage/browser.rs'
shutil.copy2(path,stage/'browser-storage-before-import-fix.rs')
text=path.read_text();assert 'type HostRoot;' in text
path.write_text(text.replace('HostRoot','StorageRoot'))
shutil.copytree(stage/'web',stage/'web2')
server=(stage/'serve.py').read_text().replace("output=stage/'browser1'","output=stage/'browser2'").replace("web=stage/'web'","web=stage/'web2'")
with (stage/'serve2.py').open('x') as output:output.write(server)
