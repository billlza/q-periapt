from pathlib import Path
import hashlib,json,os,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;output=stage/'native-verification3';output.mkdir(mode=0o700)
result=json.loads((stage/'browser3/RESULT.json').read_text());assert result['completed']
expected={'logical-path-admission','window-refused','missing-refused','generated-and-reopened','duplicate-create','wrong-id','wrong-intent','vault','name-isolation','actual-worker-cut','cancel-and-reopen','damaged-key-refused','short-database-no-handle-leak'}
assert len(result['cases'])==len(expected) and {c['case'] for c in result['cases']}==expected
web=json.loads((stage/'WEB3.json').read_text())
for name,digest in web['web_sha256'].items():assert hashlib.sha256((stage/'web3'/name).read_bytes()).hexdigest()==digest,name
metadata=json.loads((stage/'WEB.json').read_text());binary=Path(metadata['native_binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==metadata['native_binary_sha256']
env=dict(os.environ,DYLD_FALLBACK_LIBRARY_PATH='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
requests=sorted((stage/'browser3').glob('*.bin'));assert len(requests)==5
verified=[]
for path in requests:
    wire=path.read_bytes();assert len(wire)==5506
    stdout=sdk.command([str(binary),'verify',str(stage/'private-issuer'),str(path),str(output/(path.stem+'.credential'))],output/path.stem,root,environment=env)
    match=re.fullmatch(rb'request_sha256=([0-9a-f]{64}) signing_identity=([0-9a-f]{64}) public_key_sha256=([0-9a-f]{64}) credential_sha256=([0-9a-f]{64})\n',stdout);assert match
    digest,identity,public,credential=[x.decode() for x in match.groups()]
    assert digest==hashlib.sha256(wire).hexdigest() and credential==hashlib.sha256((output/(path.stem+'.credential')).read_bytes()).hexdigest()
    verified.append({'request':path.name,'request_sha256':digest,'signing_identity':identity,'public_key_sha256':public,'credential_sha256':credential})
owned=[row for row in verified if row['request'].startswith('owned-')];assert len(owned)==2 and owned[0]['request_sha256']==owned[1]['request_sha256'] and owned[0]['signing_identity']==owned[1]['signing_identity']
assert len({r['signing_identity'] for r in verified})==4 and len({r['public_key_sha256'] for r in verified})==4
for case in result['cases']:
    if 'sha256' in case:assert case['sha256'] in {r['request_sha256'] for r in verified}
proof={'completed':True,'cases':len(expected),'native_requests_verified':len(verified),'distinct_browser_generated_signers':4,'requests':verified,'browser':result['browser'],'wasm_sha256':web['wasm_sha256'],'scope':'real Chrome Worker/IndexedDB/OPFS generated keys and original enrollment requests; same Rust cryptographic implementation; creation-interruption reconciliation, operational grants and full browser lifecycle still unadmitted'}
sdk.write_json(output/'RESULT.json',proof)
print(json.dumps({key:proof[key] for key in ('completed','cases','native_requests_verified','distinct_browser_generated_signers','browser','wasm_sha256')}))
