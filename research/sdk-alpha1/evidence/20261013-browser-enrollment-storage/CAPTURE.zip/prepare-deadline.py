from pathlib import Path
import hashlib,shutil
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent;web=stage/'web-deadline';shutil.copytree(stage/'web3',web)
shutil.copy2(stage/'deadline-worker.js',web/'deadline-worker.js')
(web/'index.html').write_text('''<!doctype html><title>Browser late completion ownership</title><pre id="result">Running deadline controls…</pre><script type="module">
const worker=new Worker('./deadline-worker.js',{type:'module'});const timer=setTimeout(()=>{worker.terminate();globalThis.result={completed:false,error:'overall deadline'};document.querySelector('#result').textContent=JSON.stringify(globalThis.result)},75000);
worker.onmessage=async({data})=>{if(data.progress){document.querySelector('#result').textContent=data.progress;return}clearTimeout(timer);globalThis.result=data;document.querySelector('#result').textContent=JSON.stringify(data,null,2);const response=await fetch('/capture/RESULT.json',{method:'POST',body:JSON.stringify(data,null,2)});if(!response.ok)throw Error('deadline capture failed');worker.terminate()};
worker.onerror=event=>{clearTimeout(timer);globalThis.result={completed:false,error:String(event.message)};document.querySelector('#result').textContent=JSON.stringify(globalThis.result);worker.terminate()};
</script>''')
server=(stage/'serve3.py').read_text().replace("output=stage/'browser3'","output=stage/'deadline1'").replace("web=stage/'web3'","web=stage/'web-deadline'")
with (stage/'serve-deadline.py').open('x') as output:output.write(server)
sdk.write_json(stage/'DEADLINE_WEB.json',{'web_sha256':{p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()},'scope':'injected late completion over real WebCrypto/OPFS; production timeout values unchanged'})
