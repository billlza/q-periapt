from pathlib import Path
import hashlib
import json
import os
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
repo = stage.parent.parent
source = stage / 'source'
suite = json.loads((stage / 'NATIVE_SUITE.json').read_text())
inputs = suite['inputs_sha256']
for name, digest in inputs.items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
old = repo / 'target/continuity-browser-network/cargo-msrv.sh'
wrapper = stage / 'cargo-msrv-isolated.sh'
text = old.read_text().replace(
    str(repo / 'target/continuity-browser-engine/rust-target'),
    str(stage / 'msrv-target'),
)
assert text != old.read_text()
with wrapper.open('x') as handle:
    handle.write(text)
record = {'completed': False, 'source_base': suite['source_base'],
          'input_inventory_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest(),
          'toolchain': '1.90.0-aarch64-apple-darwin', 'target_directory': str(stage / 'msrv-target')}
try:
    sdk.command(['sh', str(wrapper), 'check', '--manifest-path',
                 'research/continuity-identity-candidate/Cargo.toml',
                 '--all-features', '--tests', '--examples', '--locked', '--offline'],
                stage / 'msrv-check', source, environment=dict(os.environ))
    for name, digest in inputs.items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
    record['completed'] = True
finally:
    sdk.write_json(stage / 'MSRV_CHECK.json', record)
print(json.dumps(record))
