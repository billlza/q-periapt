from pathlib import Path
import hashlib
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;web=stage/'web2'
wasm=root/'target/continuity-browser-engine/rust-target/wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
sdk.command([str(root/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(web/'pkg'),str(wasm)],stage/'bindgen2',root)
assert "import { StorageRoot } from './storage-root.js';" in (web/'pkg/q_periapt_continuity_identity_candidate.js').read_text()
sdk.write_json(stage/'WEB2.json',{'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'web_sha256':{p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()}})
