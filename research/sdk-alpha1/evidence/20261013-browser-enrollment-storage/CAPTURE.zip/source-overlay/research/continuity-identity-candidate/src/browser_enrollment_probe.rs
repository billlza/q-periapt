//! Isolated first-use storage experiment; not the admitted product browser entry.
use crate::{
    codec::Decoder, storage::Storage, DeviceDescription, DeviceEnrollment, DurableError,
    EnrollmentIntent, EnrollmentPaths, InstallationPaths, PublicKey, Validity,
};
use std::{
    cell::{Cell, RefCell},
    path::Path,
};
use wasm_bindgen::prelude::*;

fn js(error: DurableError) -> JsValue {
    js_sys::Error::new(&format!("{error:?}")).into()
}
fn intent(root: &[u8], description: &[u8]) -> Result<EnrollmentIntent, DurableError> {
    let mut decoder = Decoder::new(description);
    let device = decoder.array()?;
    let generation = u64::from_be_bytes(decoder.array()?);
    let family = decoder.array()?;
    let from = u64::from_be_bytes(decoder.array()?);
    let until = u64::from_be_bytes(decoder.array()?);
    decoder.finish()?;
    Ok(EnrollmentIntent::new(
        PublicKey::decode(root)?,
        DeviceDescription::new(device, generation, family, Validity::new(from, until)?)?,
    ))
}
fn paths(storage: &Storage) -> Result<EnrollmentPaths, DurableError> {
    let prefix = storage.prefix()?;
    EnrollmentPaths::new(
        Path::new(&(prefix.clone() + "wrap.key")),
        Path::new(&(prefix.clone() + "signer.key")),
        Path::new(&(prefix.clone() + "enrollment.redb")),
        InstallationPaths::new(
            Path::new(&(prefix.clone() + "installation.redb")),
            Path::new(&(prefix.clone() + "journal.redb")),
            Path::new(&(prefix + "archives.redb")),
        )?,
    )
}

/// Isolated diagnostic of Rust's target-specific lexical path interpretation.
#[wasm_bindgen]
pub fn path_observation(path: String) -> String {
    let value = Path::new(&path);
    format!("absolute={} filename={:?} components={:?} normalized={:?} admitted={:?}",
        value.is_absolute(),value.file_name(),value.components().collect::<Vec<_>>(),
        value.components().collect::<std::path::PathBuf>(),crate::installation::validate_paths(&[value]))
}

/// Experiment owner with explicit creation versus exact original reopening.
#[wasm_bindgen]
pub struct BrowserEnrollmentProbe {
    enrollment: RefCell<Option<DeviceEnrollment>>,
    storage: Storage,
    closed: Cell<bool>,
}
#[wasm_bindgen]
impl BrowserEnrollmentProbe {
    /// Create fresh browser-owned vault, wrapping key and original enrollment intent.
    pub async fn create(
        name: String,
        id: String,
        root: Vec<u8>,
        description: Vec<u8>,
    ) -> Result<Self, JsValue> {
        let intent = intent(&root, &description).map_err(js)?;
        let storage = Storage::create(&name, &id).await.map_err(js)?;
        let result = Self::create_enrollment(&storage, intent).await;
        match result {
            Ok(owner) => Ok(Self {
                enrollment: RefCell::new(Some(owner)),
                storage,
                closed: Cell::new(false),
            }),
            Err(primary) => {
                let cleanup = storage.close().await;
                Err(js_with_cleanup(primary, cleanup))
            }
        }
    }
    /// Reopen existing original state. No error creates or replaces an object.
    pub async fn open(
        name: String,
        id: String,
        root: Vec<u8>,
        description: Vec<u8>,
    ) -> Result<Self, JsValue> {
        let intent = intent(&root, &description).map_err(js)?;
        let storage = Storage::open(&name, &id).await.map_err(js)?;
        let result = Self::open_enrollment(&storage, intent).await;
        match result {
            Ok(owner) => Ok(Self {
                enrollment: RefCell::new(Some(owner)),
                storage,
                closed: Cell::new(false),
            }),
            Err(primary) => {
                let cleanup = storage.close().await;
                Err(js_with_cleanup(primary, cleanup))
            }
        }
    }
    /// Return the exact committed original request; concurrent use is refused.
    pub async fn request(&self, now: u64) -> Result<Vec<u8>, JsValue> {
        if self.closed.get() {
            return Err(js(DurableError::Closed));
        }
        let mut owner = self
            .enrollment
            .borrow_mut()
            .take()
            .ok_or_else(|| js(DurableError::Io(std::io::ErrorKind::WouldBlock.into())))?;
        let result = owner.request(now).await;
        match result {
            Ok(bytes) if !self.closed.get() => {
                *self.enrollment.borrow_mut() = Some(owner);
                Ok(bytes)
            }
            other => {
                self.closed.set(true);
                owner.close();
                let cleanup = self.storage.close().await;
                Err(js_with_cleanup(
                    other.err().unwrap_or(DurableError::Closed),
                    cleanup,
                ))
            }
        }
    }
    /// Close all descendants and await actual release of the browser storage lease.
    pub async fn close(&self) -> Result<(), JsValue> {
        self.closed.set(true);
        self.enrollment.borrow_mut().take();
        self.storage.close().await.map_err(js)
    }
}
impl BrowserEnrollmentProbe {
    async fn create_enrollment(
        storage: &Storage,
        intent: EnrollmentIntent,
    ) -> Result<DeviceEnrollment, DurableError> {
        let prefix = storage.prefix()?;
        storage
            .provision_key(Path::new(&(prefix + "wrap.key")))
            .await?;
        DeviceEnrollment::provision_with_storage(storage.clone(), paths(storage)?, intent).await
    }
    async fn open_enrollment(
        storage: &Storage,
        intent: EnrollmentIntent,
    ) -> Result<DeviceEnrollment, DurableError> {
        DeviceEnrollment::open_with_storage(storage.clone(), paths(storage)?, intent).await
    }
}
impl Drop for BrowserEnrollmentProbe {
    fn drop(&mut self) {
        self.closed.set(true);
        self.enrollment.get_mut().take();
        self.storage.begin_close();
    }
}
fn js_with_cleanup(primary: DurableError, cleanup: Result<(), DurableError>) -> JsValue {
    match cleanup {
        Ok(()) => js(primary),
        Err(cleanup) => js_sys::Error::new(&format!("{primary:?}; cleanup: {cleanup:?}")).into(),
    }
}
