from pathlib import Path
import hashlib,json,os,shutil,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;web=stage/'web';pkg=web/'pkg';pkg.mkdir()
target=root/'target/continuity-browser-engine/rust-target'
wasm=target/'wasm32-unknown-unknown/release/q_periapt_continuity_identity_candidate.wasm'
assert wasm.is_file()
sdk.command([str(root/'target/browser-policy-tools/wasm-bindgen/bin/wasm-bindgen'),'--target','web','--out-dir',str(pkg),str(wasm)],stage/'bindgen',root)
for name in ('policy-database.js','storage-database.js','storage-root.js'):shutil.copy2(web/name,pkg/name)
issuer=stage/'private-issuer';issuer.mkdir(mode=0o700)
binary=target/'debug/examples/browser_owned_enrollment'
env=dict(os.environ,DYLD_FALLBACK_LIBRARY_PATH='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
sdk.command([str(binary),'prepare',str(issuer)],stage/'native-prepare',root,environment=env)
inputs=web/'inputs';inputs.mkdir()
for name in ('root.bin','description.bin'):shutil.copy2(issuer/name,inputs/name)
sdk.write_json(stage/'WEB.json',{'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'native_binary':str(binary),'native_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'web_sha256':{p.relative_to(web).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in web.rglob('*') if p.is_file()},'scope':'browser-generated secrets and original enrollment, private experimental facade'})
print('Browser module and public native enrollment inputs prepared')
