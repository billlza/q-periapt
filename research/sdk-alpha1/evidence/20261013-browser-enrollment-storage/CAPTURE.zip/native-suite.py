from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess
stage=Path(__file__).resolve().parent;source=stage/'source';root=stage.parents[1]
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','crates','research/continuity-identity-candidate'],cwd=source,text=True).splitlines()
assert len(files)==len(set(files))
inputs={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files if (source/name).is_file()}
state={'completed':False,'live_producer':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'inputs_sha256':inputs}
def save():(stage/'NATIVE_SUITE.json').write_text(json.dumps(state,indent=2)+'\n')
command=['sh',str(root/'target/continuity-browser-engine/cargo.sh'),'test','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--lib','--all-features','--offline','--locked','--','--test-threads=4']
state['argv']=command;save()
try:
    with (stage/'native-suite.stdout').open('xb') as out,(stage/'native-suite.stderr').open('xb') as err:
        process=subprocess.Popen(command,cwd=source,stdout=out,stderr=err,start_new_session=True);state['pid']=process.pid;save()
        try:state['returncode']=process.wait(timeout=2400)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
            state['returncode']=process.returncode;raise
    if state['returncode']!=0:raise RuntimeError('full native suite failed')
    for name,digest in inputs.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
    state['completed']=True
finally:
    state.update(live_producer=False,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print('Full native suite terminal success with frozen source')
