"""Read only public publication artifacts; verify historical signatures, not live authority."""
import base64
import json
import re
import sys

PROTOCOL_LABELS = ('init', 'prepare', 'authority', 'refuse-anchor-fields', 'issue-first',
          'retrieve-first', 'retry-first', 'refuse-overwrite', 'refuse-retarget',
          'issue-witnessed', 'issue-disabled', 'refuse-issued-cancel', 'original-after-updates')
EXPORTS = ('export-first', 'export-retrieved', 'export-retry', 'export-witnessed',
           'export-disabled', 'export-original-after-updates')
REFUSALS = {'refuse-anchor-fields':'unknown field', 'refuse-overwrite':'Export directory must be empty',
            'refuse-retarget':'Original policy request differs', 'refuse-issued-cancel':'Issued policy cannot be cancelled'}


SDK_LABELS = ('sdk-init','sdk-prepare','sdk-authority','sdk-refuse-version','sdk-issue-first',
              'sdk-retrieve-first','sdk-retry-first','sdk-refuse-retarget','sdk-issue-second',
              'sdk-original-after-updates','sdk-refuse-issued-cancel')
LABELS = SDK_LABELS[:8] + PROTOCOL_LABELS + SDK_LABELS[8:]
SDK_EXPORTS = ('sdk-export-first','sdk-export-retrieved','sdk-export-retry','sdk-export-second',
               'sdk-export-original-after-updates')
REFUSALS.update({'sdk-refuse-version':'next allocated version',
                 'sdk-refuse-retarget':'Original SDK policy document differs',
                 'sdk-refuse-issued-cancel':'Issued SDK policy cannot be cancelled'})


def check_publications(data, report, repo):
    sys.path.insert(0, str(repo/'research/continuity-openssl-peer'))
    from qperiapt_continuity_reference.provider import load_provider
    provider, backend = load_provider(repo/'target/independent-bootstrap-01/provider')
    from qperiapt_continuity_reference.enrollment_exchange import PolicyInputs
    from qperiapt_continuity_reference.authority import verify_sdk, SUITE
    from qperiapt_continuity_reference.wire import Reader, Interval, digest
    prefix = 'exchange/native-policy-public/'
    parse = lambda name: json.loads(data[prefix+name])
    observed = parse('RESULT.json')
    assert observed == report['native_policy_publication'] == json.loads(data['exchange/native-policy.stdout'])
    assert observed['completed'] is True and observed['commands'] == 24 and observed['expected_refusals'] == 7
    assert observed['policy_versions'] == [1,2,3] and observed['provider'] == '48.0.1'
    assert observed['independent_implementation'] == report['outside_root']+'/installed/qperiapt_continuity_reference/enrollment_exchange.py'
    assert re.fullmatch('[0-9a-f]{64}', observed['native_sha256'])
    assert observed['native_sha256'] == report['publisher_binary_sha256_producer_observation']
    executed = json.loads(data['exchange/native-policy.json'])
    assert executed['exit'] == 0 and data['exchange/native-policy.stderr'] == b''
    binary = executed['argv'][executed['argv'].index('--publisher')+1]
    sdk_binary = executed['argv'][executed['argv'].index('--sdk-authority')+1]
    assert observed['sdk_policy_versions'] == [1,2]
    assert re.fullmatch('[0-9a-f]{64}', observed['sdk_authority_sha256'])
    assert observed['sdk_authority_sha256'] == report['sdk_authority_binary_sha256_producer_observation']
    commands = parse('COMMANDS.json')
    assert tuple(command['label'] for command in commands) == LABELS
    for command in commands:
        label = command['label']
        expected_tool = 'sdk' if label.startswith('sdk-') else 'protocol'
        assert command['tool'] == expected_tool
        assert command['argv'][0] == (sdk_binary if expected_tool == 'sdk' else binary)
        stdout, stderr = data[prefix+label+'.stdout'], data[prefix+label+'.stderr']
        if label in REFUSALS:
            assert command['exit'] != 0 and stdout == b'' and REFUSALS[label].encode() in stderr
        else:
            assert command['exit'] == 0 and stderr == b''
    authority = parse('init.stdout')
    assert authority == parse('prepare.stdout') == parse('authority.stdout')
    sdk_root_info = parse('sdk-init.stdout')
    assert sdk_root_info['allocated_version'] == 0 and sdk_root_info['pending'] is None
    assert sdk_root_info == parse('sdk-prepare.stdout') == parse('sdk-authority.stdout')
    assert sdk_root_info['root'] == authority['sdk_root']
    first_sdk = parse('sdk-issue-first.stdout')
    assert first_sdk == parse('sdk-retrieve-first.stdout') == parse('sdk-retry-first.stdout') == parse('sdk-original-after-updates.stdout')
    for folder in ('sdk-export-retrieved','sdk-export-retry','sdk-export-original-after-updates'):
        for name in ('sdk-root','sdk-state','sdk-document','sdk-signature'):
            assert data[prefix+folder+'/'+name] == data[prefix+'sdk-export-first/'+name]
    from cryptography.hazmat.primitives.asymmetric import mldsa
    import hashlib
    sdk_publications = []
    for folder,label,version in [('sdk-export-first','sdk-issue-first',1),('sdk-export-second','sdk-issue-second',2)]:
        publication = parse(label+'.stdout')
        assert publication['version'] == version
        values = {name:data[prefix+folder+'/sdk-'+name] for name in ('root','state','document','signature')}
        encoded = {name:base64.urlsafe_b64encode(value).rstrip(b'=').decode() for name,value in values.items()}
        assert encoded == publication['input'] and encoded['root'] == sdk_root_info['root']
        assert values['state'] == version.to_bytes(4,'big') + hashlib.sha3_256(values['document']).digest()
        message = b'Q-PERIAPT-SIGNED-POLICY/v1' + len(values['document']).to_bytes(8,'big') + values['document']
        mldsa.MLDSA65PublicKey.from_public_bytes(values['root']).verify(values['signature'],message)
        sdk_publications.append({'version':version,'document_sha3_256':hashlib.sha3_256(values['document']).hexdigest(),'signature_verified':True})
    assert first_sdk['input']['state'] == authority['sdk_state']
    for command in commands:
        if command['label'] not in REFUSALS and command['argv'][1] in ('issue','result'):
            publication = parse(command['label']+'.stdout')
            assert bytes(publication['operation']) == base64.urlsafe_b64decode(command['argv'][4]+'==')
    first = parse('issue-first.stdout')
    assert first == parse('retrieve-first.stdout') == parse('retry-first.stdout') == parse('original-after-updates.stdout')
    for folder in ('export-retrieved','export-retry','export-original-after-updates'):
        for name in ('authority.json','policy-pins.json','policy-materials.json'):
            assert data[prefix+folder+'/'+name] == data[prefix+'export-first/'+name]
    publications = []
    for folder, label, version, mode in [('export-first','issue-first',1,2),
                                         ('export-witnessed','issue-witnessed',2,2),
                                         ('export-disabled','issue-disabled',3,0)]:
        output = parse(label+'.stdout')
        assert output['version'] == version and output['request']['bootstrap_mode'] == ('disabled' if mode == 0 else 'reusable_both')
        assert parse(folder+'/authority.json') == authority
        p = PolicyInputs.from_trusted(data[prefix+folder+'/policy-pins.json'],data[prefix+folder+'/policy-materials.json'])
        assert p.pins.sdk_root == base64.urlsafe_b64decode(authority['sdk_root']+'==')
        assert p.pins.sdk_state == base64.urlsafe_b64decode(authority['sdk_state']+'==')
        assert p.pins.policy_root.raw == base64.urlsafe_b64decode(authority['policy_root']+'==')
        assert p.materials.policy == base64.urlsafe_b64decode(output['policy']+'==')
        sdk = verify_sdk(p.pins,p.materials)
        body = p.pins.policy_root.open(p.materials.policy,4,200)
        assert digest(b'SESSION-POLICY',body) == p.pins.policy_digest == bytes(output['digest'])
        r = Reader(body)
        assert r.take(8) == b'QPSESP03' and r.take(32) == bytes(authority['family']) == digest(b'POLICY-AUTHORITY',p.pins.policy_root.raw)
        assert r.integer(8) == p.pins.policy_version == version
        interval = Interval.read(r)
        assert interval.start == output['request']['valid_from'] and interval.end == output['request']['valid_until']
        assert r.take(32) == SUITE and r.take(68) == sdk.wire() and r.integer(1) == mode
        anchor_mode, binding = r.integer(1),r.take(32)
        if version == 2:
            assert anchor_mode == 1 and binding == p.witness.binding
            assert output['request']['anchor'] == dict(kind='required',**parse(folder+'/policy-pins.json')['witness'])
            assert not p.witness.key.shares_component(p.pins.policy_root) and p.witness.key.raw[:1952] != p.pins.sdk_root
        else:
            assert anchor_mode == 0 and binding == bytes(32) and p.witness is None
            assert output['request']['anchor'] == {'kind':'local_only'}
        assert r.integer(2) == output['request']['send_budget'];r.finish()
        publications.append({'version':version,'digest':p.pins.policy_digest.hex(),'dual_signature':True,'sdk_signature':True})
    return {'commands':24,'expected_refusals':7,'public_files':88,'sdk_publications':sdk_publications,
            'sdk_authority_sha256_producer_observation':observed['sdk_authority_sha256'],'historical_publications':publications,
            'native_sha256_producer_observation':observed['native_sha256'],
            'readback_provider':provider.__version__,'readback_openssl':backend.openssl_version_text(),
            'scope':'Historical signatures and original operation/export consistency only; no clock override or live activation, and no authentication of the operator trust channel.'}
