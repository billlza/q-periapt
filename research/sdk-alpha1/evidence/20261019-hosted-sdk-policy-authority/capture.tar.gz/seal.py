"""Seal previously verified terminal reference artifacts at their exact source head."""
import hashlib,io,json,subprocess,tarfile,zipfile
from pathlib import Path
out=Path(__file__).resolve().parent;repo=out.parents[1]
head='e13efcaf23d38fb88ea52fd9aefa79724b6967e2';run=39237096750
reports=json.loads((out/'READBACK_ubuntu-24.04-macos-15.json').read_text())
assert len(reports)==2 and {r['platform'] for r in reports}=={'ubuntu-24.04','macos-15'}
entries={}
for name in ('COHORT.json','READBACK_ubuntu-24.04-macos-15.json','RUN_OBSERVED.json','readback.py','publisher_readback.py','READBACK_EXIT.json','readback.stdout','readback.stderr','seal.py'):
 entries[name]=(out/name).read_bytes()
assert entries['readback.stderr']==b''
source_names=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app'],cwd=repo,text=True).splitlines())
for r in reports:
 assert r['head']==head and r['run']==run and r['members']==137
 folder=out/r['platform'];job=json.loads((folder/'JOB.json').read_text());meta=json.loads((folder/'ARTIFACT.json').read_text())
 assert job['status']=='completed' and job['conclusion']=='success' and job['head_sha']==head and job['run_id']==run
 data=(folder/'upstream.zip').read_bytes();assert len(data)==meta['size_in_bytes']==r['artifact_bytes']
 assert 'sha256:'+hashlib.sha256(data).hexdigest()==meta['digest']==r['artifact_sha256']
 for name in ('JOB.json','ARTIFACT.json','upstream.zip'):entries[r['platform']+'/'+name]=(folder/name).read_bytes()
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None and len(z.infolist())==137
  result=json.loads(z.read('exchange/RESULT.json'));assert result['source_commit']==head and result['completed'] is True
  assert len(result['source_inputs'])==134
  for path,digest in result['source_inputs'].items():
   body=subprocess.check_output(['git','show',head+':'+path],cwd=repo);assert hashlib.sha256(body).hexdigest()==digest;source_names.add(path)
for name in sorted(source_names):entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
entries['PUBLIC_MANIFEST.json']=(json.dumps({n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in entries.items()},indent=2)+'\n').encode()
destination=repo/'research/sdk-alpha1/evidence/20261019-hosted-sdk-policy-authority';destination.mkdir()
archive=destination/'capture.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
receipt={'source_commit':head,'run':run,'platforms':reports,'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'scope':'Terminal reference CI for protected native SDK and protocol authorities at e13efcaf on Apple Silicon/macOS and Linux x86_64. Each137-member artifact checked against134 exact source inputs. Rust42 entries in debug/release, native signing16 entries, Node17, installed adapter8/client16 and operator24 commands/7 refusals. Two SDK and three protocol publications independently reverified. No fixture SDK signing key in CLI flow; witness remains a test pin. Local operator trust assumed; no real user/device authorization, live consumer activation, authority replacement, full lifecycle or release admission. Other e13efcaf CI workflows are separate.'}
(destination/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'capture':receipt['capture'],'source_commit':head,'platforms':[r['platform'] for r in reports]}))
