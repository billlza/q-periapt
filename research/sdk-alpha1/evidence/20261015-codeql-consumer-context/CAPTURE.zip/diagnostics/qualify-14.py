"""Run the source-bound qualification in the standalone validation checkout."""
from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
sdk.require(head.startswith("5377b8e4") and not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "unexpected qualification source")
argv = [sys.executable, "-B", str(root / "artifact/python_bootstrap.py")]
sdk.command([*argv, "-m", "unittest", "artifact.test_codeql_consumer_context", "artifact.test_rust_sdk_profile",
    "artifact.test_codeql_rust_quality",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_codeql_covers_all_detected_languages_with_real_builds",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_rust_codeql_analysis_has_a_fail_closed_database_quality_gate",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_rust_codeql_compatibility_and_upload_boundary_is_documented"], stage / "tests-14", root)
sdk.command(["actionlint", ".github/workflows/codeql.yml"], stage / "actionlint-14", root)
sdk.command([*argv, str(root / "artifact/source_results_assembler.py"), "ci-source-gate",
    sdk.snapshot(root / "artifact/results.json").sha256, head, "--profile", "sdk-020"], stage / "source-gate-14", root)
sdk.command(["git", "diff", "--check"], stage / "diff-14", root)
sdk.require(not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "qualification changed source")
sdk.write_json(stage / "QUALIFIED_14.json", {"head": head, "targeted_tests_passed": 73,
    "source_gate_passed": True, "actionlint_passed": True, "clean": True,
    "actual_extraction_still_unverified": True})
print("73 targeted tests, actionlint and source gate passed on clean source")
