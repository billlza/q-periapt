"""Capture terminal consumer-context diagnostics and qualification only."""
from pathlib import Path
import hashlib
import json
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
qualified = json.loads((stage / "QUALIFIED_14.json").read_text())
integration = json.loads((stage / "INTEGRATION_12.json").read_text())
sdk.require(integration["accepted"] and integration["cleanup_verified"], "integration incomplete")
sdk.require(sdk.snapshot(root / "artifact/codeql_consumer_context.py").sha256 == integration["helper_sha256"], "helper changed")
sdk.require(sdk.snapshot(root / "artifact/rust_sdk_profile.py").sha256 == integration["fixture_helper_sha256"], "fixture helper changed")
patterns = ["probe-01.py", "PROBE_01.json", "*-targets-01.*", "*-resolve-01.*",
    "check-06.py", "*-check-06.*", "context-09.py", "CONTEXT_09.json", "*-metadata-09.*", "*-check-09.*",
    "context-11.py", "CONTEXT_11.json", "*-metadata-11.*", "*-check-11.*",
    "integration-12.py", "INTEGRATION_12.json", "qualify-13.py", "tests-13.*",
    "qualify-14.py", "QUALIFIED_14.json", "*-14.stdout", "*-14.stderr", "*-14.json",
    "UPSTREAM_04.json", "UPSTREAM_05.json", "ra-ap-toolchain-04.crate", "ra-ap-project-model-05.crate",
    "capture-16.py"]
files = {"diagnostics/" + path.name: path for pattern in patterns for path in stage.glob(pattern) if path.is_file()}
files.update({"integration/" + path.name: path for path in (stage / "prepared-12").iterdir() if path.is_file()})
for name in ("artifact/codeql_consumer_context.py", "artifact/test_codeql_consumer_context.py",
             "artifact/rust_sdk_profile.py", ".github/workflows/codeql.yml"):
    files["source/" + name] = root / name
public = root / "research/sdk-alpha1/evidence/20261015-codeql-consumer-context"
public.mkdir()
archive = public / "CAPTURE.zip"
members = {}
expanded = 0
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(files.items()):
        data = sdk.snapshot(path).data
        expanded += len(data)
        sdk.require(expanded <= 16 * 1024**2, "capture exceeds bound")
        entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(entry, data)
        members[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(members), "archive inventory differs")
    for name, digest in members.items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, "capture readback failed")
sdk.write_json(public / "CAPTURE.json", {
    "archive_sha256": sdk.snapshot(archive).sha256, "members": members,
    "expanded_bytes": expanded, "source_qualification": qualified,
    "integration": integration, "consumer_source_base": "e860b55e020566931345468b29743da6a11392d0",
    "local_compiler": "1.98.1", "hosted_compatibility_compiler_1_97_0_verified": False,
    "codeql_extraction_verified": False, "query_timeout_cause_established": False,
    "private_device_state_included": False, "release_claim_eligible": False,
})
print(json.dumps({"archive_bytes": archive.stat().st_size, "members": len(members),
                  "sha256": sdk.snapshot(archive).sha256, "expanded_bytes": expanded}))
