"""Qualify temporary Cargo analysis inputs without changing installed consumers."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
main = stage.parents[1]
root = main / "target/continuity-browser-publication/source"
head = "e860b55e020566931345468b29743da6a11392d0"
qualified = json.loads((stage / "SHADOW_03.json").read_text())
environment = dict(os.environ)
environment.update({"RUSTUP_AUTO_INSTALL": "0", "RUSTFLAGS": "-D warnings",
                    "CARGO_BUILD_JOBS": "2", "CARGO_TARGET_DIR": str(stage / "check-target-09")})
receipt = {"accepted": False, "source_head": head, "consumers": {},
           "codeql_extraction_verified": False, "private_runtime_executed": False}
owned = []

def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()

def identity(path):
    info = path.lstat()
    value = {"inode": info.st_ino, "device": info.st_dev, "mode": info.st_mode}
    if stat.S_ISLNK(info.st_mode):
        value["link"] = os.readlink(path)
    elif stat.S_ISREG(info.st_mode):
        value["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    elif not stat.S_ISDIR(info.st_mode):
        raise ValueError("unexpected analysis input type")
    return value

def remember(path):
    owned.append((path, identity(path)))

def directory(path):
    path.mkdir()
    remember(path)

def file(path, data):
    with path.open("xb") as stream:
        stream.write(data)
    remember(path)

sdk.require(git("rev-parse", "HEAD") == head and not git("status", "--porcelain"), "unexpected clone state")
try:
    for label, relative in (("continuity-c", "bindings/c/ContinuityPackageConsumer"),
                            ("sdk-rust", "bindings/rust/SDKPackageConsumer")):
        consumer = root / relative
        source_manifest = sdk.snapshot(consumer / "Cargo.toml")
        original = json.loads((stage / (label + "-targets-01.stdout")).read_text())["packages"][0]
        expected_targets = json.loads(json.dumps(original["targets"]).replace(str(main), str(root)))
        bindings = qualified["consumers"][label]["local_provider_manifests"]
        config = "[patch.crates-io]\n"
        for name, manifest in sorted(bindings.items()):
            provider = root / Path(manifest).relative_to(main).parent
            config += name + " = { path = " + json.dumps(str(provider)) + " }\n"
        directory(consumer / ".cargo")
        file(consumer / ".cargo/config.toml", config.encode())
        lock = consumer / "Cargo.lock"
        lock_data = (stage / "shadow-03" / label / "Cargo.lock").read_bytes()
        sdk.require(hashlib.sha256(lock_data).hexdigest() == qualified["consumers"][label]["lock_sha256"], "prototype lock changed")
        file(lock, lock_data)
        if label == "continuity-c":
            directory(consumer / "packages")
            alias = consumer / "packages/q-periapt-continuity-identity-candidate-0.0.0"
            alias.symlink_to(root / "research/continuity-identity-candidate", target_is_directory=True)
            remember(alias)
        prefix = stage / (label + "-metadata-09")
        sdk.command(["cargo", "+1.98.1", "metadata", "--format-version", "1", "--all-features", "--locked", "--offline"], prefix, consumer, environment=environment)
        metadata = json.loads(prefix.with_suffix(".stdout").read_text())
        own = [package for package in metadata["packages"] if package["name"] == original["name"]]
        sdk.require(len(own) == 1 and own[0]["targets"] == expected_targets, "original targets changed")
        for package in metadata["packages"]:
            if package["name"].startswith("q-periapt") and package["name"] != original["name"]:
                expected = root / Path(bindings[package["name"]]).relative_to(main)
                sdk.require(package["source"] is None and package["manifest_path"] == str(expected), "incorrect provider")
        sdk.command(["cargo", "+1.98.1", "check", "--all-targets", "--all-features", "--locked", "--offline"], stage / (label + "-check-09"), consumer, environment=environment)
        sdk.require(sdk.snapshot(consumer / "Cargo.toml").sha256 == source_manifest.sha256, "consumer manifest changed")
        receipt["consumers"][label] = {"targets": len(expected_targets), "metadata_passed": True,
                                       "all_targets_compiled": True, "warnings_denied": True,
                                       "lock_sha256": hashlib.sha256(lock_data).hexdigest()}
    receipt["accepted"] = True
except Exception as exc:
    receipt["error"] = str(exc)
    raise
finally:
    receipt["temporary_inputs"] = {str(path.relative_to(root)): before for path, before in owned}
    changed = [str(path) for path, before in owned if not path.exists() and not path.is_symlink() or identity(path) != before]
    receipt["changed_temporary_inputs"] = changed
    if not changed:
        for path, before in reversed(owned):
            path.rmdir() if stat.S_ISDIR(before["mode"]) else path.unlink()
    receipt["cleanup_completed"] = not changed and not git("status", "--porcelain")
    sdk.write_json(stage / "CONTEXT_09.json", receipt)
    sdk.require(receipt["cleanup_completed"], "analysis context changed; preserved for inspection")
print(json.dumps(receipt["consumers"], sort_keys=True))
