"""Retain targeted tooling checks for the consumer analysis preparation."""
from pathlib import Path
import sys
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
sdk.command([sys.executable, "-B", str(root / "artifact/python_bootstrap.py"), "-m", "unittest",
    "artifact.test_codeql_consumer_context", "artifact.test_rust_sdk_profile",
    "artifact.test_codeql_rust_quality",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_codeql_covers_all_detected_languages_with_real_builds",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_rust_codeql_analysis_has_a_fail_closed_database_quality_gate",
    "artifact.test_proof_to_byte_release.BoundVerifierWiringTests.test_rust_codeql_compatibility_and_upload_boundary_is_documented"], stage / "tests-13", root)
sdk.command(["actionlint", ".github/workflows/codeql.yml"], stage / "actionlint-13", root)
sdk.command(["git", "diff", "--check"], stage / "diff-13", root)
print("Targeted tooling and existing CodeQL quality checks passed")
