"""Exercise the production context helper against the unchanged source clone."""
from pathlib import Path
import json
import codeql_consumer_context as context
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
root = stage.parents[1] / "target/continuity-browser-publication/source"
output = stage / "prepared-12"
context.prepare(root, output, ["1.98.1"])
state = json.loads((output / "STATE.json").read_text())
context.check_tree(root, state)
context.remove_owned(root, state["owned"])
sdk.require(not context.run_git_bytes(root, ["status", "--porcelain"]), "clone not restored")
sdk.write_json(stage / "INTEGRATION_12.json", {
    "accepted": True, "consumers": state["consumers"], "cleanup_verified": True,
    "codeql_extraction_verified": False, "compatibility_toolchain_verified": False,
    "helper_sha256": sdk.snapshot(Path(context.__file__)).sha256,
    "fixture_helper_sha256": sdk.snapshot(Path(sdk.__file__)).sha256,
})
print("Production context helper: metadata, full compilation and cleanup passed")
