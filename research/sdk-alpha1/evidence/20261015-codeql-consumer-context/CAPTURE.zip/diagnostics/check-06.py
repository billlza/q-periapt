"""Compile all original consumer targets through the qualified analysis manifests."""
from pathlib import Path
import hashlib
import json
import os
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
qualified = json.loads((stage / "SHADOW_03.json").read_text())
sdk.require(qualified["completed"], "metadata prototype incomplete")
environment = dict(os.environ)
environment.update({"RUSTUP_AUTO_INSTALL": "0", "RUSTFLAGS": "-D warnings",
                    "CARGO_BUILD_JOBS": "2", "CARGO_TARGET_DIR": str(stage / "check-target-06")})
for label, identity in qualified["consumers"].items():
    manifest = stage / "shadow-03" / label / "Cargo.toml"
    lock = manifest.with_name("Cargo.lock")
    sdk.require(sdk.snapshot(manifest).sha256 == identity["manifest_sha256"] and sdk.snapshot(lock).sha256 == identity["lock_sha256"], "analysis input changed")
    sdk.command(["cargo", "+1.98.1", "check", "--manifest-path", str(manifest), "--all-targets", "--all-features", "--locked", "--offline"],
                stage / (label + "-check-06"), root, environment=environment)
    sdk.require(sdk.snapshot(manifest).sha256 == identity["manifest_sha256"] and sdk.snapshot(lock).sha256 == identity["lock_sha256"], "analysis input mutated")
sdk.write_json(stage / "CHECKS_06.json", {
    "completed": True, "toolchain": "1.98.1", "all_targets": True, "all_features": True,
    "warnings_denied": True, "locked_offline": True,
    "target_count": sum(item["target_count"] for item in qualified["consumers"].values()),
    "source_head": qualified["source_head"], "codeql_extraction_still_unverified": True,
})
print("All 19 original targets compile through unchanged analysis inputs; actual CodeQL extraction remains required")
