"""Reproduce unresolved consumer metadata without changing source or lock files."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
paths = {
    "continuity-c": root / "bindings/c/ContinuityPackageConsumer/Cargo.toml",
    "sdk-rust": root / "bindings/rust/SDKPackageConsumer/Cargo.toml",
}
watched = [path for manifest in paths.values() for path in (manifest, manifest.with_name("Cargo.lock"))]
def identities():
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None for path in watched}
before = identities()
environment = dict(os.environ)
environment["RUSTUP_AUTO_INSTALL"] = "0"
environment["CARGO_TARGET_DIR"] = str(stage / "cargo-target")
records = {}
for label, manifest in paths.items():
    records[label] = {}
    for mode in ("targets", "resolve"):
        argv = ["cargo", "+1.98.1", "metadata", "--manifest-path", str(manifest), "--format-version", "1", "--frozen"]
        if mode == "targets":
            argv.append("--no-deps")
        process = subprocess.run(argv, cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120, check=False)
        sdk.require(max(len(process.stdout), len(process.stderr)) <= 4 * 1024**2, "metadata output exceeds bound")
        for suffix, data in (("stdout", process.stdout), ("stderr", process.stderr)):
            with (stage / (label + "-" + mode + "-01." + suffix)).open("xb") as stream:
                stream.write(data)
        record = {"argv": argv, "returncode": process.returncode}
        if mode == "targets":
            sdk.require(process.returncode == 0, "no-dependency target discovery failed")
            metadata = json.loads(process.stdout)
            sdk.require(len(metadata["packages"]) == 1 and metadata["packages"][0]["manifest_path"] == str(manifest), "consumer target identity differs")
            record["targets"] = [{key: target[key] for key in ("name", "kind", "src_path", "edition", "crate_types")}
                                 for target in metadata["packages"][0]["targets"]]
        else:
            record["stderr"] = process.stderr.decode("utf-8")
        records[label][mode] = record
sdk.require(identities() == before, "source manifests or lockfiles changed")
sdk.require(records["continuity-c"]["resolve"]["returncode"] != 0 and "q-periapt-continuity-identity-candidate" in records["continuity-c"]["resolve"]["stderr"], "hosted dependency failure was not reproduced")
sdk.write_json(stage / "PROBE_01.json", {
    "completed": True, "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "toolchain": "1.98.1", "hosted_toolchain_still_requires_separate_verification": "1.97.0",
    "source_and_lockfiles_unchanged": before, "records": records,
    "private_candidate_registry_resolution_failure_reproduced": True,
    "not_a_proof_of_summarystats_timeout_cause": True,
})
print(json.dumps({name: {"targets": len(value["targets"]["targets"]), "resolve_returncode": value["resolve"]["returncode"],
                        "diagnostic": value["resolve"]["stderr"][:1000]} for name, value in records.items()}))
