from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
base=Path(__file__).resolve().parent
source=base/'source'; head='a30b572c252da88a48750de4c9bcb9623c4ed08e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
full=source/'target/continuity-reopen-stack-a30b572c'
original=json.loads((base/'full-installed-01/RESULT.json').read_text())
assert original['runs'][-1]['returncode']==1 and not original['completed']
probe=json.loads((base/'kotlin-resolution-diagnostic-01/RESULT.json').read_text())
assert probe['returncode']==0 and not probe['timed_out']
out=base/'kotlin-continuation-02'; out.mkdir(mode=0o700)
outside=Path(json.loads((full/'location.json').read_text())['path'])
assert outside==Path('/private/tmp/qperiapt-continuity-package-8qzagd77')
native_file=full/'C_CONSUMER.json'; native_bytes=native_file.read_bytes(); native=json.loads(native_bytes); assert native['completed']
retained=outside/'kotlin-resolution-attempt-01'; retained.mkdir(mode=0o700)
for name in ('kotlin-source','kotlin-gradle-home'):
 (outside/name).rename(retained/name)
record={'source_commit':head,'source':str(source),'outside':str(outside),'output':str(out),'original_result':str(base/'full-installed-01/RESULT.json'),'original_full_pipeline_completed':False,'native_report_sha256':hashlib.sha256(native_bytes).hexdigest(),'retained_original_inputs':str(retained),'fresh_gradle_cache':True,'reason':'Original plugin resolution failed; one subsequent bounded diagnostic resolved the identical version without dependency or verification changes. This is one component rerun, not a successful original full run.','release_claim_eligible':False,'completed':False,'copied_native_build_logs':{}}
for profile in ('debug','release'):
 for name in ('enrollment','enrollment-witness','retirement'):
  filename=f'c-{name}-build-{profile}.stdout'; data=(full/filename).read_bytes(); (out/filename).write_bytes(data); record['copied_native_build_logs'][filename]=hashlib.sha256(data).hexdigest()
(out/'START.json').write_text(json.dumps(record,indent=2)+'\n')
sys.path.insert(0,str(source/'artifact'))
import continuity_kotlin_consumer as kotlin
assert kotlin.package.ROOT==source
rust=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
tools=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON','JAVA','JDK','GRADLE','KOTLIN','SWIFT')) and k not in ('_JAVA_OPTIONS','CLASSPATH')}
env.update(CARGO_HOME=str(outside/'cargo-home'),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_HTTP_MULTIPLEXING='false',CARGO_TARGET_DIR=str(outside/'build'),CARGO_INCREMENTAL='0',RUSTC=str(rust/'bin/rustc'),RUSTDOC=str(rust/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(rust/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(rust/'lib'),DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',TMPDIR='/private/tmp')
start=time.monotonic(); print('Starting isolated-cache Kotlin component continuation on unchanged a30b native packages',flush=True)
try:
 result=kotlin.qualify_kotlin(outside,out,native,env,tools/'jdk-25.0.4.1+1/Contents/Home',tools/'gradle-9.8.0')
 record['completed']=result['completed']
except Exception as error:
 record['failure']=str(error)
 raise
finally:
 record['seconds']=time.monotonic()-start
 record['native_report_unchanged']=native_file.read_bytes()==native_bytes
 record['source_clean']=not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
 record['head_unchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
 (out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k] for k in ('completed','seconds','native_report_unchanged','source_clean','head_unchanged')}),flush=True)
 assert record['native_report_unchanged'] and record['source_clean'] and record['head_unchanged']
