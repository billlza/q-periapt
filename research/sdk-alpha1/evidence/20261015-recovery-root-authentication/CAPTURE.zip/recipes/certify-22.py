"""Bind the accepted complete replay, dependency control and semantic checks."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
result = json.loads((stage / 'composed-13-TERMINAL.json').read_text())
missing = json.loads((stage / 'missing-authentication-19-TERMINAL.json').read_text())
expected = {'signing_secret_derivation_origin': 356, 'generation_secret_derivation_origin': 187,
    'signing_secret_origin': 3, 'generation_secret_origin': 7,
    'encapsulation_uses_authenticated_generation': 163,
    'encapsulation_derivation_requires_session_leak': 204,
    'accepted_root_has_authenticated_origin': 313, 'message_root_has_authenticated_origin': 6}
sdk.require(result['accepted'] and result['returncode'] == 0 and not result['timed_out'], 'complete replay did not pass')
sdk.require({n: row['steps'] for n, row in result['results'].items() if row['status'] == 'verified'} == expected, 'verified inventory differs')
sdk.require(not any(arg.startswith('--prove') for arg in result['argv']), 'fresh replay requested search')
sdk.require(result['input_sha256'] == sdk.snapshot(stage / 'composed-06.spthy').sha256
            and result['output_sha256'] == sdk.snapshot(stage / 'composed-13-proof.spthy').sha256, 'replay input/output changed')
sdk.require(missing['returncode'] == 0 and not missing['accepted'], 'missing dependency incorrectly admitted')
sdk.require(missing['results']['accepted_root_has_authenticated_origin']['status'] == 'analysis incomplete'
            and missing['results']['message_root_has_authenticated_origin'] == {'status': 'verified', 'steps': 6}, 'missing-dependency control differs')
sdk.require({n: row['steps'] for n, row in missing['results'].items() if row['status'] == 'verified'}
            == {n: steps for n, steps in expected.items() if n != 'accepted_root_has_authenticated_origin'}, 'control verified inventory differs')
semantics = json.loads((stage / 'SEMANTICS_16.json').read_text())
sdk.require(semantics['completed'] and semantics['inputs']['composed'] == result['input_sha256'], 'semantic input identity differs')
parsed = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
    str(stage / 'composed-13-proof.spthy'), '--parse-only'], stage / 'certificate-parse-22', root).decode()
before = (stage / 'composed-parse-16.stdout').read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
sdk.require([m.group() for m in decl.finditer(before)] == [m.group() for m in decl.finditer(parsed)], 'final certificate declarations differ')
sdk.require(before.split('\nlemma ', 1)[0] == parsed.split('\nlemma ', 1)[0], 'final certificate semantics differ')
calls = [json.loads(line) for line in (stage / 'oracle-calls-08.jsonl').read_text().splitlines()]
for i, call in enumerate(calls, 1):
    ids = [index for index, _ in call['goals']]
    sdk.require(call['call'] == i and len(ids) == len(set(ids)), 'oracle call inventory differs')
    if call['diagnostic_stop']:
        sdk.require(i > 64 and call['ranked'] == [], 'oracle stopping rule differs')
    else:
        sdk.require(i <= 64 and sorted(ids) == sorted(call['ranked']), 'oracle altered goal inventory')
sdk.write_json(stage / 'CERTIFIED_22.json', {
    'completed': True, 'certificate_sha256': result['output_sha256'],
    'input_sha256': result['input_sha256'], 'verified_obligations': expected,
    'independent_process_replay_without_search': True,
    'missing_authentication_dependency_rejected_despite_exit_zero': True,
    'final_certificate_declarations_and_operational_prefix_match_checked_input': True,
    'oracle_actual_calls': len(calls), 'oracle_rankings_are_permutations': True,
    'main_message_secrecy_proved': False, 'release_claim_eligible': False,
})
print('Eight proof obligations admitted; missing-dependency group rejected; final certificate identity checked')
