"""Archive the complete correspondence proof group and its honest witness."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
certified = json.loads((stage / 'CERTIFIED_22.json').read_text())
witness = json.loads((stage / 'WITNESS_24.json').read_text())
semantics = json.loads((stage / 'SEMANTICS_16.json').read_text())
sdk.require(certified['completed'] and witness['completed'] and semantics['completed'], 'proof checks incomplete')
sdk.require(certified['certificate_sha256'] == sdk.snapshot(stage / 'composed-13-proof.spthy').sha256, 'certificate changed')
groups = {int(line.split(None, 2)[1]) for line in subprocess.check_output(['ps', '-axo', 'pid=,pgid=,command='], text=True).splitlines() if len(line.split(None, 2)) == 3}
owned = {}
for path in sorted(stage.glob('*STARTED*.json')):
    row = json.loads(path.read_text())
    sdk.require(row['pid'] not in groups, 'owned process group still present')
    owned[path.name] = {'pid': row['pid'], 'process_group_absent': True}
sdk.write_json(stage / 'CLEANUP_25.json', {'completed': True, 'owned': owned})
failed_names = ['root-conditional-03-TERMINAL.json', 'composed-07-TERMINAL.json',
    'frontier-09-TERMINAL.json', 'contents-root-11-TERMINAL.json', 'untracked-identity-17-TERMINAL.json']
for name in failed_names:
    sdk.require(not json.loads((stage / name).read_text())['accepted'], 'incomplete experiment admitted')
files = {}
def add(path, name):
    sdk.require(name not in files, 'duplicate archive name')
    files[name] = sdk.snapshot(path, maximum=32 * 1024**2).data
for path in sorted(stage.iterdir()):
    sdk.require(path.is_file(), 'unexpected evidence directory')
    suffix = path.suffix
    sdk.require(suffix in ('.py', '.sh', '.spthy', '.json', '.jsonl', '.stdout', '.stderr'), 'unexpected evidence file')
    folder = 'proof' if suffix == '.spthy' else 'recipes' if suffix in ('.py', '.sh') else 'diagnostics' if suffix == '.jsonl' else 'receipts'
    add(path, folder + '/' + path.name)
prior = root / 'target/continuity-recovery-crypto-provenance-20261015'
for name in ('crypto-01.spthy', 'root-observer-24.spthy', 'message-20.spthy', 'composed-16-proof.spthy', 'REPLAYS_23.json'):
    add(prior / name, 'prior/' + name)
add(root / 'target/continuity-recovery-secrecy-20261015/contents-proof-12.spthy', 'prior/contents-proof-12.spthy')
toolchain = root / 'target/continuity-recovery-symbolic-20261015'
for name in ('TOOLS_08.json', 'tool-contract-09.json', 'tool-contract-09.stdout', 'tool-contract-09.stderr'):
    add(toolchain / name, 'toolchain/' + name)
add(root / 'research/continuity-recovery-symbolic/protected-state.spthy', 'source/protected-state.spthy')
output = root / 'research/sdk-alpha1/evidence/20261015-recovery-root-authentication'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, data)
manifest = {'format': 1, 'base_commit': 'e7daa11dee9801664be7ab6ff2e543daf883b43b',
    'capture_sha256': sdk.snapshot(archive, maximum=64 * 1024**2).sha256,
    'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'certificate_sha256': certified['certificate_sha256'],
    'verified_obligations': certified['verified_obligations'],
    'honest_witness': witness,
    'original_five_property_declarations_unchanged': True,
    'total_observer_actions_in_accepted_extension': 6,
    'observer_erasure_preserves_rules_equations_restriction': True,
    'missing_authentication_dependency_rejected': True,
    'source_semantic_mutations_rejected': list(semantics['semantic_mutations_rejected']),
    'failed_attempts_retained': failed_names,
    'owned_process_groups_terminal': True, 'main_secrecy_verified': False,
    'canonical_model_changed': False, 'product_code_changed': False,
    'release_claim_eligible': False}
sdk.write_json(output / 'CAPTURE.json', manifest)
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(set(zipped.namelist())) == len(files), 'archive inventory differs')
    for name, digest in manifest['members'].items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, 'archive member differs')
    for name in ('CERTIFIED_22.json', 'SEMANTICS_16.json', 'WITNESS_24.json', 'CLEANUP_25.json'):
        sdk.require(json.loads(zipped.read('receipts/' + name))['completed'], 'archived check incomplete')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'members': len(files),
    'capture_sha256': manifest['capture_sha256'], 'checked_obligations': 8,
    'honest_witness_independently_replayed': True, 'main_secrecy_verified': False,
    'private_sdk_runtime_data_selected': False})
print(json.dumps({'members': len(files), 'capture_sha256': manifest['capture_sha256'],
    'certificate_sha256': manifest['certificate_sha256'], 'checked_obligations': 8,
    'honest_witness_independently_replayed': True, 'main_secrecy_verified': False}))
