"""Check complete declarations, equations and observer-erased operational rules."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
sources = {
    'original': root / 'research/continuity-recovery-symbolic/protected-state.spthy',
    'observed': stage / 'authentication-04.spthy',
    'conditional-proof': stage / 'authentication-05-proof.spthy',
    'composed': stage / 'composed-06.spthy',
}
texts = {label: sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
    str(path), '--parse-only'], stage / (label + '-parse-16'), root).decode()
    for label, path in sources.items()}
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
declarations = {label: {m.group(1): m.group() for m in decl.finditer(text)}
                for label, text in texts.items()}
original = declarations['original']
sdk.require(len(original) == 5, 'original inventory differs')
for label, value in declarations.items():
    sdk.require(all(value.get(name) == block for name, block in original.items()), 'original property changed: ' + label)
sdk.require(declarations['observed'] == declarations['conditional-proof'] == declarations['composed'], 'composed property declarations differ')

def prefix(text):
    text = text.split('\nlemma ', 1)[0]
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    signature = re.search(r'(?s)functions:\s*(.*?)\nequations:', text)
    sdk.require(signature is not None, 'expanded function signature missing')
    functions = dict((name, int(arity)) for name, arity in re.findall(r'(\w+)/(\d+)', signature.group(1)))
    info = re.findall(r'(?m)^function:\s*(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)\s*$', text)
    for name, args, result in info:
        types = [arg.strip() for arg in args.split(',') if arg.strip()]
        sdk.require(name in functions and functions[name] == len(types) and set(types) <= {'Any'} and result == 'Any', 'informational function declaration differs')
    sdk.require({name for name, _, _ in info} in ({'kempk', 'kemct', 'decap'}, set(functions)), 'unexpected informational inventory')
    builtins = re.findall(r'(?m)^builtin\s+(\S+)\s*$', text)
    sdk.require(set(builtins) in (set(), {'hashing', 'signing', 'symmetric-encryption'}), 'unexpected builtin summary')
    text = re.sub(r'(?m)^function:\s*\w+\s*\([^)]*\)\s*:\s*\w+\s*$', '', text)
    text = re.sub(r'(?m)^builtin\s+\S+\s*$', '', text)
    return re.sub(r'\s+', '', text)

expected_observers = {'SigningSecret': 2, 'EncapsulationSecret': 1,
                      'ResponseRoot': 1, 'AcceptedRoot': 1, 'TrafficInput': 1}
def erase(value):
    for name, expected in expected_observers.items():
        needle = ',' + name + '('
        sdk.require(value.count(needle) == expected, 'observer count differs: ' + name)
        while needle in value:
            start = value.index(needle)
            cursor = start + len(needle)
            depth = 1
            while depth:
                sdk.require(cursor < len(value), 'unclosed observer term')
                if value[cursor] == '(':
                    depth += 1
                elif value[cursor] == ')':
                    depth -= 1
                cursor += 1
            value = value[:start] + value[cursor:]
    return value

canonical = prefix(texts['original'])
for label in ('observed', 'conditional-proof', 'composed'):
    sdk.require(erase(prefix(texts[label])) == canonical, 'operational/equational projection differs: ' + label)
raw = sources['original'].read_text()
changes = {
    'equation': ('decap(x,kemct(kempk(x),y)) = y', 'decap(x,kemct(kempk(x),y)) = x'),
    'output': ('Out(plaintext)', "Out(<plaintext,'extra'>)"),
    'restriction': ('Eq(x,y)@i ==> x = y', 'Eq(x,y)@i ==> x = x'),
}
mutations = {}
for name, (before, after) in changes.items():
    sdk.require(raw.count(before) == 1, 'control mutation ambiguous')
    modified = raw.replace(before, after)
    path = stage / (name + '-mutation-16.spthy')
    with path.open('x') as output:
        output.write(modified)
    parsed = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(path), '--parse-only'], stage / (name + '-mutation-parse-16'), root).decode()
    sdk.require(prefix(parsed) != canonical, 'semantic mutation incorrectly admitted')
    mutations[name] = {'source_sha256': sdk.snapshot(path).sha256, 'pinned_parser_ran': True, 'rejected_by_same_prefix_comparison': True}
sdk.write_json(stage / 'SEMANTICS_16.json', {
    'completed': True, 'inputs': {label: sdk.snapshot(path).sha256 for label, path in sources.items()},
    'original_five_complete_declarations_unchanged': True,
    'all_composed_declarations_match': True,
    'six_observer_actions_erase_to_original_rules_equations_restriction': True,
    'expanded_function_signature_and_equations_compared': True,
    'informational_function_metadata_validated_against_expanded_signature': True,
    'semantic_mutations_rejected': mutations,
    'earlier_check_14_mutation_limit': 'Initial control mutated normalized strings only; this check mutates source, runs the pinned parser, and applies the same semantic comparison.',
    'other_session_leakage_restricted': False, 'replication_restricted': False,
    'main_secrecy_verified': False,
})
print('Full declarations and observer-erased semantics agree; three semantic mutations rejected')
