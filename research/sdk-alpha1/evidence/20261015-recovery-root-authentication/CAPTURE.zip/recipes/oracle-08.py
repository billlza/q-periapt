"""Bounded proof-search diagnostic; reorder actual goals, never alter the theory."""
from pathlib import Path
import fcntl,json,re,sys
stage=Path(__file__).resolve().parent
raw=sys.stdin.read(1024*1024+1)
if len(raw)>1024*1024:raise ValueError('oracle input exceeds limit')
rows=[]
for line in raw.splitlines():
 if not line.strip():continue
 match=re.fullmatch(r'\s*(\d+):(.*)',line)
 if match is None:raise ValueError('invalid goal line')
 rows.append((int(match.group(1)),match.group(2).strip()))
if len({i for i,t in rows})!=len(rows):raise ValueError('duplicate goal index')
names=('ResponseRoot','AcceptedRoot','TrafficInput','EncapsulationSecret','Final8','Receipt9','Final7','Response6','Response5','Response4','Offer3','Offer2','Offer1','OfferStart','ResponseStart','CanSend','Signer','Wrap','CutPermit','Stored','SignerFile','Entropy','CapturedRecord','CapturedSigner','WrappingExposed','Pinned','Confirmed','Message','Cut','KeyReserved','EncapReserved','Saved','Snapshot','CapturedPhase','GenerationSecret')
def priority(row):
 index,text=row
 if any(re.match(r'!?'+name+r'\s*\(',text) for name in names):rank=0
 elif re.match(r'!?KU\(\s*sign\(',text):rank=1
 elif text.startswith(('splitEqs(', 'disjunction(')):rank=2
 elif re.match(r'!?KU\(\s*~(?:sa|sb|key|coins)(?:[. ]|\))',text):rank=3
 elif '~payload' in text:rank=6
 elif '~~>' in text:rank=5
 else:rank=4
 return rank,index
with (stage/'oracle-calls-08.jsonl').open('a+') as log:
 fcntl.flock(log,fcntl.LOCK_EX);log.seek(0);prior=log.read()
 if len(prior)>8*1024*1024:raise ValueError('oracle log exceeds limit')
 count=len(prior.splitlines());ranked=[] if count>=64 else [i for i,t in sorted(rows,key=priority)]
 if ranked and sorted(ranked)!=sorted(i for i,t in rows):raise ValueError('ranking is not a permutation')
 log.write(json.dumps({'call':count+1,'lemma':sys.argv[1:],'goals':rows,'ranked':ranked,'diagnostic_stop':count>=64})+'\n');log.flush()
for index in ranked:print(index)
