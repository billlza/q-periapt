"""Expose already-computed roots to prove response and message correspondence."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-recovery-crypto-provenance-20261015'
bare = (prior / 'crypto-01.spthy').read_text()
prefix = bare.split('\nlemma ', 1)[0]
replacements = [
    ("--[ Saved(s,~rev,'5') ]->", "--[ Saved(s,~rev,'5'), ResponseRoot(s,root) ]->"),
    ("Saved(s,~rev,'7') ]->", "Saved(s,~rev,'7'), AcceptedRoot(s,root) ]->"),
    ('--[ Message(s,role,key,~payload) ]->', '--[ Message(s,role,key,~payload), TrafficInput(s,role,root,key) ]->'),
]
observed = prefix
for old, new in replacements:
    sdk.require(observed.count(old) == 1, 'observer insertion ambiguous')
    observed = observed.replace(old, new)
erased = observed
for old, new in reversed(replacements):
    erased = erased.replace(new, old)
sdk.require(erased == prefix, 'observer erasure differs')
conditional = (stage / 'root-conditional-01.spthy').read_text()
declarations = '\nlemma ' + conditional.split('\nlemma ', 1)[1]
marker = 'lemma computed_root_derivation_requires_session_leak'
new_lemmas = '''lemma accepted_root_has_authenticated_origin [use_induction,reuse]:
 "All s root #accepted.
    AcceptedRoot(s,root)@accepted
  & not (Ex #leaked. IdentityLeak(s,'B')@leaked)
  ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < accepted)"
by sorry

lemma message_root_has_authenticated_origin [reuse]:
 "All s role root key #message.
    TrafficInput(s,role,root,key)@message
  & not (Ex #leaked. IdentityLeak(s,'B')@leaked)
  ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < message)"
by sorry

'''
sdk.require(declarations.count(marker) == 1, 'new obligation placement ambiguous')
variant = observed + declarations.replace(marker, new_lemmas + marker)
with (stage / 'authentication-04.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'AUTHENTICATION_04.json', {
    'input_sha256': sdk.snapshot(stage / 'authentication-04.spthy').sha256,
    'base_bare_observed_sha256': sdk.snapshot(prior / 'crypto-01.spthy').sha256,
    'new_observer_labels': 3, 'observer_erasure_byte_identical': True,
    'new_operational_state_io_equation_or_restriction': False,
    'conditional_only_until_all_dependencies_replayed': True,
    'original_positive_recovery_query_unchanged': True,
    'release_claim_eligible': False,
})
