"""Compose the checked content-source observation with crypto correspondence."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-recovery-secrecy-20261015'
base = (stage / 'authentication-04.spthy').read_text()
variant = base
rows = [('Key_Reservation_1','A','1','<old,~key>'),('Offer_Signing_2','A','2','<old,key>'),('Offer_Commit_3','A','3','<old,key,wire>'),('Response_Reservation_4','B','4','<old,wire,~coins>'),('Response_Compute_5','B','5','<old,offer,core,root>'),('Response_Commit_6','B','6','<old,offer,wire,root>'),('Final_Reservation_7','A','7','<old,offer,response,root>'),('Final_Commit_8','A','8','<root,offer,response,final>'),('Receipt_Reservation_9','B','9','<old,root,offer,response,final>'),('Receipt_Commit_0','B','0','<root,offer,response,final,receipt>'),('Receipt_Accept_0','A','0','<root,offer,response,final,receipt>')]
added = []
for name, role, phase, value in rows:
    start = variant.index('rule ' + name + ':')
    match = re.search(r'\n(?:rule|restriction|lemma) ', variant[start + 1:])
    sdk.require(match is not None, 'rule boundary missing')
    end = start + 1 + match.start()
    block = variant[start:end]
    saved = "Saved(s,~rev,'" + phase + "')"
    stored = "!Stored(s,'" + role + "','" + phase + "',~rev," + value + ')'
    sdk.require(block.count(saved) == block.count(stored) == 1, 'writer correspondence differs')
    tag = "StoredContents(s,'" + role + "','" + phase + "',~rev," + value + ')'
    added.append(tag)
    variant = variant[:start] + block.replace(saved, saved + ', ' + tag) + variant[end:]
tag = 'ReadContents(s,role,phase,revision,plaintext)'
added.append(tag)
sdk.require(variant.count('CapturedPhase(s,role,phase)') == 1, 'reader observation ambiguous')
variant = variant.replace('CapturedPhase(s,role,phase)', 'CapturedPhase(s,role,phase), ' + tag)
erased = variant
for tag in added:
    sdk.require(erased.count(', ' + tag) == 1, 'new observer repeated')
    erased = erased.replace(', ' + tag, '')
sdk.require(erased == base, 'content observer erasure differs')
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
source_certificate = (prior / 'contents-proof-12.spthy').read_text()
matches = list(decl.finditer(source_certificate))
sdk.require(matches[0].group(1) == 'captured_contents_have_stored_origin', 'source lemma not first')
source_block = source_certificate[matches[0].start():matches[1].start()]
marker = 'lemma signing_secret_derivation_origin'
sdk.require(variant.count(marker) == 1, 'source insertion ambiguous')
variant = variant.replace(marker, source_block + marker)
with (stage / 'contents-10.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'CONTENTS_10.json', {
    'input_sha256': sdk.snapshot(stage / 'contents-10.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'authentication-04.spthy').sha256,
    'source_certificate_sha256': sdk.snapshot(prior / 'contents-proof-12.spthy').sha256,
    'content_observers_added': 12, 'observer_erasure_byte_identical': True,
    'source_proof_requires_replay_on_extended_model': True,
    'conditional_only_until_all_dependencies_replayed': True,
    'release_claim_eligible': False,
})
