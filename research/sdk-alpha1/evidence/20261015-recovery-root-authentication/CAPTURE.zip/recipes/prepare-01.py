"""Isolate new proof search; conditional results remain unaccepted until replay."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-recovery-crypto-provenance-20261015'
certificate = prior / 'composed-16-proof.spthy'
sdk.require(sdk.snapshot(certificate).sha256 == '789cbbdcc2ee6c172c190d5d4330f0fa781ba3772a272cfc9b911837e1690770', 'checked certificate differs')
replay = json.loads((prior / 'REPLAYS_23.json').read_text())
sdk.require(replay['completed'] and replay['results']['independent-23']['accepted'], 'prior dependency group not verified')
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
sources = {'root': prior / 'root-observer-24.spthy', 'message': prior / 'message-20.spthy'}
inputs = {}
for label, source in sources.items():
    text = source.read_text()
    matches = list(decl.finditer(text))
    sdk.require(len(matches) == 14 and text.rstrip().endswith('end'), 'input inventory differs')
    prepared = text[:matches[0].start()] + ''.join(m.group() + '\nby sorry\n\n' for m in matches) + 'end\n'
    sdk.require([m.group() for m in matches] == [m.group() for m in decl.finditer(prepared)], 'declaration changed')
    sdk.require(prepared.split('\nlemma ', 1)[0] == text.split('\nlemma ', 1)[0], 'operational prefix changed')
    path = stage / (label + '-conditional-01.spthy')
    with path.open('x') as output:
        output.write(prepared)
    inputs[label] = {'original_sha256': sdk.snapshot(source).sha256,
                    'conditional_sha256': sdk.snapshot(path).sha256,
                    'removed_proof_methods_only': True}
with (stage / 'run-02.py').open('x') as output:
    output.write((prior / 'run-09.py').read_text())
sdk.write_json(stage / 'INPUTS_01.json', {
    'base_commit': 'e7daa11dee9801664be7ab6ff2e543daf883b43b', 'inputs': inputs,
    'dependency_certificate_sha256': sdk.snapshot(certificate).sha256,
    'prior_independent_replay_seconds': replay['results']['independent-23']['elapsed_seconds'],
    'conditional_proof_may_not_be_accepted': True,
    'acceptance_requires_restored_dependencies_and_complete_fresh_replay': True,
    'main_secrecy_verified': False, 'release_claim_eligible': False,
})
print('Prepared identical formulas and rules with proof bodies deferred for conditional search only')
