"""Restore checked dependencies before admitting the new correspondence proofs."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-recovery-crypto-provenance-20261015'
record = json.loads((stage / 'authentication-05-TERMINAL.json').read_text())
sdk.require(record['returncode'] == 0 and not record['accepted'], 'conditional outcome differs')
for name, steps in [('accepted_root_has_authenticated_origin', 313), ('message_root_has_authenticated_origin', 6)]:
    sdk.require(record['results'][name] == {'status': 'verified', 'steps': steps}, 'new conditional proof missing')
dependency = (prior / 'composed-16-proof.spthy').read_text()
candidate = (stage / 'authentication-05-proof.spthy').read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def blocks(text):
    matches = list(decl.finditer(text))
    return {m.group(1): (m, text[m.start(): matches[i + 1].start() if i + 1 < len(matches) else text.rfind('\nend')])
            for i, m in enumerate(matches)}
prior_blocks = blocks(dependency)
current_blocks = blocks(candidate)
expected = json.loads((prior / 'REPLAYS_23.json').read_text())['results']['independent-23']['results']
replacements = {}
for name, result in expected.items():
    if result['status'] != 'verified':
        continue
    before = prior_blocks[name]
    after = current_blocks[name]
    sdk.require(re.sub(r'\s+', '', before[0].group()) == re.sub(r'\s+', '', after[0].group()), 'dependency declaration differs: ' + name)
    replacements[name] = before[1]
output = candidate[:next(iter(current_blocks.values()))[0].start()]
output += ''.join(replacements.get(name, block) for name, (_, block) in current_blocks.items()) + '\nend\n'
sdk.require([re.sub(r'\s+', '', m.group()) for m in decl.finditer(candidate)]
            == [re.sub(r'\s+', '', m.group()) for m in decl.finditer(output)], 'query declarations changed while composing')
with (stage / 'composed-06.spthy').open('x') as file:
    file.write(output)
runner = (stage / 'run-02.py').read_text()
needle = "*['--prove='+n for n in selected],"
sdk.require(runner.count(needle) == 1, 'runner shape differs')
with (stage / 'replay-06.py').open('x') as file:
    file.write(runner.replace(needle, ''))
sdk.write_json(stage / 'COMPOSE_06.json', {
    'restored_dependencies': sorted(replacements),
    'input_sha256': sdk.snapshot(stage / 'composed-06.spthy').sha256,
    'candidate_sha256': record['output_sha256'],
    'dependency_certificate_sha256': sdk.snapshot(prior / 'composed-16-proof.spthy').sha256,
    'all_property_declarations_unchanged': True,
    'fresh_complete_group_replay_required': True,
    'release_claim_eligible': False,
})
