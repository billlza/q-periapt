"""Read back the honest root-use witness without mistaking step counts for scope."""
from pathlib import Path
import hashlib, json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
initial = json.loads((stage / 'honest-root-21-TERMINAL.json').read_text())
replay = json.loads((stage / 'honest-root-replay-23-TERMINAL.json').read_text())
name = 'honest_authenticated_root_is_used'
sdk.require(initial['accepted'] and replay['accepted'] and replay['results'][name]['status'] == 'verified', 'witness not independently verified')
sdk.require(not any(arg.startswith('--prove') for arg in replay['argv']), 'witness replay requested search')
sdk.require(replay['input_sha256'] == initial['output_sha256'] == sdk.snapshot(stage / 'honest-root-21-proof.spthy').sha256, 'witness identity differs')
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
texts = {}
for label, source in [('input', 'honest-root-20.spthy'), ('certificate', 'honest-root-21-proof.spthy'), ('replay', 'honest-root-replay-23-proof.spthy')]:
    texts[label] = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(stage / source), '--parse-only'], stage / ('witness-' + label + '-parse-24'), root).decode()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
rows = {label: {m.group(1): m.group() for m in decl.finditer(text)} for label, text in texts.items()}
sdk.require(rows['input'] == rows['certificate'] == rows['replay'], 'witness declaration changed')
sdk.require(list(rows['input'])[0] == name, 'witness has preceding dependencies')
sdk.require(texts['certificate'].split('\nlemma ', 1)[0] == texts['replay'].split('\nlemma ', 1)[0], 'replay model changed')
graph = json.loads((stage / 'honest-root-replay-23-traces.json').read_text())['graphs']
sdk.require(len(graph) == 1, 'witness trace inventory differs')
acts = [act for node in graph[0]['jgNodes'] for act in node.get('jgnMetadata', {}).get('jgnActs', [])]
def tree(term):
    if 'jgnConst' in term:
        return ('constant', term['jgnConst'])
    sdk.require('jgnFunct' in term and 'jgnParams' in term, 'unexpected symbolic term')
    return (term['jgnFunct'], tuple(tree(value) for value in term['jgnParams']))
selected = {}
for label in ('ResponseRoot', 'AcceptedRoot', 'TrafficInput'):
    matches = [act for act in acts if act['jgnFactName'] == label]
    sdk.require(len(matches) == 1, 'witness event inventory differs')
    selected[label] = [tree(term) for term in matches[0]['jgnFactTerms']]
sdk.require(selected['ResponseRoot'] == selected['AcceptedRoot'], 'computed and accepted roots differ')
sdk.require(selected['TrafficInput'][0] == selected['ResponseRoot'][0]
            and selected['TrafficInput'][1] == ('constant', "'A'")
            and selected['TrafficInput'][2] == selected['ResponseRoot'][1], 'message root differs')
sdk.require(not any(act['jgnFactName'] in ('IdentityLeak', 'EntropyLeak', 'Snapshot') for act in acts), 'unexpected witness leakage')
sdk.write_json(stage / 'WITNESS_24.json', {
    'completed': True, 'property': name, 'initial_checked_steps': initial['results'][name]['steps'],
    'independent_replay_checked_steps': replay['results'][name]['steps'],
    'replay_without_automatic_search': True, 'full_declarations_unchanged': True,
    'witness_has_no_preceding_reusable_or_source_lemma': True,
    'same_session_and_root_at_computation_acceptance_and_message': True,
    'no_identity_entropy_or_snapshot_leak': True,
    'trace_sha256': sdk.snapshot(stage / 'honest-root-replay-23-traces.json').sha256,
    'scope': 'Honest initiator message using an accepted root; no Cut or both-peer receipt-completion assertion.',
    'main_secrecy_verified': False, 'release_claim_eligible': False,
})
print('Honest root-use trace independently replayed; exact root/session correspondence and absent leaks checked')
