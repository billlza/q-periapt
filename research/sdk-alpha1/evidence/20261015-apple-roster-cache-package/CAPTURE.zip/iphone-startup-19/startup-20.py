from pathlib import Path
import hashlib
import json
import secrets
import sys
import time
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))
from device_support import APP,BUNDLE,selected,command,installed
import usb_transport

out=stage/'startup-only-20';out.mkdir(mode=0o700);device=selected()
sdk.require(not installed(device,out/'before'),'diagnostic bundle already installed')
state={'completed':False,'cleanup':False,'sdk_called':False,'attempts':[]}
try:
    command(device,['device','install','app',APP['app']],out/'install',timeout=60)
    for index in [1]:
        capture=out/str(index);capture.mkdir()
        _,lock=command(device,['device','info','lockState'],capture/'lock-before')
        sdk.write_json(capture/'LOCK.json',{k:v for k,v in lock['result'].items() if k!='deviceIdentifier'})
        run=secrets.token_hex(16)
        result=usb_transport.launch(device,BUNDLE,'startup-only','fixed',secrets.token_hex(16),run,capture,{},'signed',True)
        marker=('QPC_IOS_STARTUP_ONLY_PASS run='+run+'\n').encode()
        sdk.require(result.stdout.splitlines().count(marker.strip())==1,'startup-only marker absent')
        domain=['--domain-type','appDataContainer','--domain-identifier',BUNDLE]
        command(device,['device','copy','from','--source','Documents/startup-'+run+'.txt','--destination',str(capture/'receipt.txt'),*domain],capture/'receipt')
        sdk.require((capture/'receipt.txt').read_bytes()==marker,'startup-only container result differs')
        state['attempts'].append({'index':index,'completed':True,'run':run,'sdk_called':False})
        print('Pre-SDK diagnostic startup '+str(index)+' completed',flush=True)
    state['completed']=True
except BaseException as error:
    state['failure']=repr(error);raise
finally:
    try:
        if installed(device,out/'cleanup-before'):command(device,['device','uninstall','app',BUNDLE],out/'uninstall',timeout=60)
        state['cleanup']=not installed(device,out/'cleanup-after');sdk.require(state['cleanup'],'diagnostic cleanup unresolved')
    finally:sdk.write_json(out/'RESULT.json',state)
print('Cold network iPhone startup passed; SDK protocol was not invoked')
