//! Operation observations using actual installed owners; no frozen resource budget.
#[path = "../packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;

use observer_peer::{Server, Task};
use p::connection_transport::{ConnectionEndpoint, Consumption, Error, Run, Submission};
use q_periapt_continuity_identity_candidate as p;
use q_periapt_core::Xof256;
use serde_json::{json, Value};
use std::{fs, io::Write, path::PathBuf, sync::Arc, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;

fn check(value: bool, message: &str) -> Result<()> {
    if value { Ok(()) } else { Err(message.to_owned().into()) }
}
fn body(index: usize, length: usize) -> Vec<u8> {
    (0..length).map(|offset| ((index + offset) % 251) as u8).collect()
}
fn digest(bytes: &[u8]) -> [u8; 32] {
    let mut hash = q_periapt_backends::Sha3_256Xof::new();
    hash.absorb_public(bytes);
    hash.squeeze32()
}
unsafe extern "C" { fn qpc_observer_memory(values: *mut u64) -> i32; }
fn memory(stage: &str, initiator: &std::path::Path, responder: &std::path::Path) -> Result<Value> {
    let mut values = [0u64; 6];
    let status = unsafe { qpc_observer_memory(values.as_mut_ptr()) };
    check(status == 0, &format!("task_info failed: {status}"))?;
    Ok(json!({"stage":stage,"resident_bytes":values[0],"physical_footprint_bytes":values[1],
        "malloc_blocks_in_use":values[2],"malloc_size_in_use_bytes":values[3],
        "malloc_max_size_in_use_bytes":values[4],"malloc_size_allocated_bytes":values[5],
        "initiator_database_bytes":fs::metadata(initiator.join("journal.redb"))?.len(),
        "responder_database_bytes":fs::metadata(responder.join("journal.redb"))?.len()}))
}
fn cpu() -> Result<[u64; 2]> {
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    if unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    let usage = unsafe { usage.assume_init() };
    let convert = |value: libc::timeval| -> Result<u64> {
        let seconds = u64::try_from(value.tv_sec)?;
        let micros = u64::try_from(value.tv_usec)?;
        check(micros < 1_000_000, "invalid CPU microseconds")?;
        seconds.checked_mul(1_000_000).and_then(|n| n.checked_add(micros)).ok_or_else(|| "CPU counter overflow".into())
    };
    Ok([convert(usage.ru_utime)?, convert(usage.ru_stime)?])
}
fn witness_snapshot(witness: Option<&observer_io::Witness>) -> Result<Value> {
    match witness {
        Some(witness) => witness.snapshot(),
        None => Ok(json!({"requests":0,"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0})),
    }
}
fn measure(witness: Option<&observer_io::Witness>, name: &str, action: impl FnOnce() -> Result<Value>) -> Result<Value> {
    let before = witness_snapshot(witness)?;
    let cpu_before = cpu()?;
    let start = Instant::now();
    let outcome = action()?;
    let elapsed_ns = start.elapsed().as_nanos();
    let cpu_after = cpu()?;
    let after = witness_snapshot(witness)?;
    let delta = [cpu_after[0].checked_sub(cpu_before[0]).ok_or("user CPU moved backwards")?,
        cpu_after[1].checked_sub(cpu_before[1]).ok_or("system CPU moved backwards")?];
    Ok(json!({"operation":name,"elapsed_ns":elapsed_ns,"cpu_user_us":delta[0],"cpu_system_us":delta[1],
        "witness_before":before,"witness_after":after,"outcome":outcome}))
}

#[test]
fn measure_installed_lifecycle() -> Result<()> {
    let profile = std::env::var("QPC_JOURNAL_PROFILE")?;
    check(matches!(profile.as_str(), "local" | "witness"), "unknown profile")?;
    let output = PathBuf::from(std::env::var_os("QPC_JOURNAL_OUTPUT").ok_or("output required")?);
    let private = PathBuf::from(std::env::var_os("QPERIAPT_PUBLIC_SERVICE_EVIDENCE").ok_or("private root required")?);
    check(output.is_absolute() && !output.exists() && private.is_absolute() && !private.exists(), "fresh absolute paths required")?;
    let mut witness = if profile == "witness" { Some(observer_io::Witness::start(&private.with_extension("witness"))?) } else { None };
    let pin = witness.as_ref().map(|w| &w.configured);
    let mut spans = Vec::new();
    let mut setup_result = None;
    spans.push(measure(witness.as_ref(), "provision_two_owners", || {
        setup_result = Some(fixture::setup_enrolled_with_witness(pin)?);
        Ok(json!({"owners":2}))
    })?);
    let setup = setup_result.ok_or("provisioning result missing")?;
    let mut client_result = None;
    spans.push(measure(witness.as_ref(), "open_initiator", || {
        client_result = Some(fixture::Peer::open_with_witness(&setup.initiator, pin)?);
        Ok(json!({"opened":true}))
    })?);
    let mut client = client_result.ok_or("initiator missing")?;
    let mut endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
    let server_witness = pin.map(|w| fixture::WitnessFixture { store:Arc::clone(&w.store), address:w.address });
    let mut server_result = None;
    spans.push(measure(witness.as_ref(), "open_responder", || {
        server_result = Some(Server::start(setup.responder.clone(), server_witness)?);
        Ok(json!({"opened":true}))
    })?);
    let mut server = server_result.ok_or("responder missing")?;
    let mut session_result = None;
    spans.push(measure(witness.as_ref(), "establish", || {
        server.begin(Task::Bootstrap)?;
        let name = client.peer_name.clone();
        let established = endpoint.establish(client.actor()?, p::InitiationId::generate()?, Run {
            address:server.address, server_name:&name, limits:fixture::limits(), cancel:&p::Cancellation::default()
        }, fixture::now)?;
        let peer = server.finish_operation()?;
        check(peer["established"] == json!(established.session), "bootstrap identities differ")?;
        session_result = Some(established.session);
        Ok(json!({"session":established.session,"exchanges":established.exchanges,"peer":peer}))
    })?);
    let session = session_result.ok_or("session missing")?;
    let mut resources = vec![memory("established", &setup.initiator, &setup.responder)?];
    let payloads = [(64usize, 0usize), (1024, 32), (16384, 1024)];
    let mut effects = Vec::new();
    for epoch in 0..=1u64 {
        for round in 0..8 {
            for offset in 0..payloads.len() {
                let (length, ad_length) = payloads[(round + offset) % payloads.len()];
                let index = effects.len();
                let plaintext = body(index, length);
                let ad = body(index + 73, ad_length);
                let mut next = None;
                spans.push(measure(witness.as_ref(), "next_message_id", || {
                    let id = client.service.stores()?.0.next_message_id(&client.context, session, fixture::now()?)?;
                    next = Some(id);
                    Ok(json!({"index":index,"epoch":epoch,"message":id.as_bytes()}))
                })?);
                let id = next.ok_or("message ID missing")?;
                spans.push(measure(witness.as_ref(), "send_confirmed", || {
                    server.begin(Task::Message { fail_after_effect:false })?;
                    let name = client.peer_name.clone();
                    let delivered = endpoint.send(client.actor()?, Submission { session, message:id, plaintext:&plaintext, associated_data:&ad }, Run {
                        address:server.address, server_name:&name,
                        limits:p::connection_transport::RunLimits { exchanges:1, ..fixture::limits() },
                        cancel:&p::Cancellation::default()
                    }, fixture::now)?;
                    let peer = server.finish_operation()?;
                    check(delivered.consumption == Consumption::Confirmed && delivered.message == id, "delivery was not confirmed")?;
                    check(peer["calls"] == 1 && peer["effects"] == 1 && peer["duplicate"] == false, "new message effect count differs")?;
                    Ok(json!({"index":index,"epoch":epoch,"payload_bytes":length,"associated_data_bytes":ad_length,
                        "message":id.as_bytes(),"exchanges":delivered.exchanges,"peer":peer}))
                })?);
                check(client.service.stores()?.0.message_status(&client.context, session, id)? == p::MessageStatus::Acknowledged, "ACK not durable")?;
                effects.push((id, plaintext));
            }
        }
        resources.push(memory(&format!("epoch-{epoch}-delivered"), &setup.initiator, &setup.responder)?);
        if epoch == 0 {
            spans.push(measure(witness.as_ref(), "traffic_independent_rekey", || {
                server.begin(Task::Rekey { session, target:1 })?;
                let control = p::control_transport::ControlEndpoint::client(&client.context, session, client.credentials(), fixture::tls_limits())?;
                let (service, signer) = client.service.parts()?;
                let (journal, _) = service.stores()?;
                let done = control.run(p::control_transport::Session { journal, context:&client.context, signer }, p::control_transport::Run {
                    target:1,address:server.address,server_name:&client.peer_name,limits:fixture::limits(),cancel:&p::Cancellation::default()
                }, fixture::now)?;
                let peer = server.finish_operation()?;
                check(done.epoch == 1 && peer["epoch"] == 1, "independent control did not confirm epoch one")?;
                Ok(json!({"epoch":1,"exchanges":done.exchanges,"application_effects_before":effects.len(),"peer":peer}))
            })?);
        }
    }
    let id = client.service.stores()?.0.next_message_id(&client.context, session, fixture::now()?)?;
    let plaintext = body(effects.len(), 1024);
    let ad = body(73, 32);
    spans.push(measure(witness.as_ref(), "effect_committed_result_lost", || {
        server.begin(Task::Message { fail_after_effect:true })?;
        let name = client.peer_name.clone();
        let result = endpoint.send(client.actor()?, Submission { session, message:id, plaintext:&plaintext, associated_data:&ad }, Run {
            address:server.address,server_name:&name,limits:p::connection_transport::RunLimits { exchanges:1,..fixture::limits() },
            cancel:&p::Cancellation::default()
        }, fixture::now);
        let error = match result {
            Err(Error::RetryExhausted { attempts:1, last }) => format!("{last:?}"),
            other => return Err(format!("expected one exhausted network attempt, observed {other:?}").into()),
        };
        let peer = server.finish_operation()?;
        check(peer["application_result_lost"] == true && peer["effects"] == 1 && peer["calls"] == 1, "unknown result did not follow one effect")?;
        Ok(json!({"message":id.as_bytes(),"attempts":1,"last_error":error,"peer":peer}))
    })?);
    check(client.service.stores()?.0.message_status(&client.context, session, id)? == p::MessageStatus::Committed, "uncertain message no longer committed")?;
    let original = client.service.stores()?.0.send_message(&client.context, session, id, &plaintext, &ad, fixture::now()?)?;
    spans.push(measure(witness.as_ref(), "reopen_original_owners", || {
        server.begin(Task::Reopen)?;
        endpoint.close();
        client.close();
        client = fixture::Peer::open_with_witness(&setup.initiator, witness.as_ref().map(|w| &w.configured))?;
        endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
        let peer = server.finish_operation()?;
        check(peer["reopened"] == true, "responder did not reopen")?;
        Ok(json!({"original_message":id.as_bytes(),"peer":peer}))
    })?);
    let replay = client.service.stores()?.0.send_message(&client.context, session, id, &plaintext, &ad, fixture::now()?)?;
    check(original == replay, "original ciphertext changed after reopen")?;
    spans.push(measure(witness.as_ref(), "retry_original_after_reopen", || {
        server.begin(Task::Message { fail_after_effect:false })?;
        let name = client.peer_name.clone();
        let delivered = endpoint.send(client.actor()?, Submission { session, message:id, plaintext:&plaintext, associated_data:&ad }, Run {
            address:server.address,server_name:&name,limits:p::connection_transport::RunLimits { exchanges:1,..fixture::limits() },
            cancel:&p::Cancellation::default()
        }, fixture::now)?;
        let peer = server.finish_operation()?;
        check(delivered.consumption == Consumption::Confirmed && peer["effects"] == 0 && peer["calls"] == 1, "exact retry duplicated the effect")?;
        Ok(json!({"message":id.as_bytes(),"wire_sha3_256":digest(&replay),"wire_bytes":replay.len(),"peer":peer}))
    })?);
    effects.push((id, plaintext));
    let next = client.service.stores()?.0.next_message_id(&client.context, session, fixture::now()?)?;
    spans.push(measure(witness.as_ref(), "pre_cancelled_send", || {
        let cancellation = p::Cancellation::default();
        cancellation.cancel();
        let name = client.peer_name.clone();
        let result = endpoint.send(client.actor()?, Submission { session, message:next, plaintext:b"not admitted", associated_data:b"" }, Run {
            address:server.address,server_name:&name,limits:fixture::limits(),cancel:&cancellation
        }, fixture::now);
        check(matches!(result, Err(Error::Cancelled)), "pre-cancelled send had another outcome")?;
        Ok(json!({"cancelled":true,"message":next.as_bytes()}))
    })?);
    check(client.service.stores()?.0.message_status(&client.context, session, next)? == p::MessageStatus::Absent, "cancelled send reserved a message")?;
    check(client.service.stores()?.0.next_message_id(&client.context, session, fixture::now()?)? == next, "cancellation changed the original next ID")?;
    resources.push(memory("recovered-and-cancelled", &setup.initiator, &setup.responder)?);
    let server_summary = server.finish()?;
    check(server_summary["effects"] == effects.len() && server_summary["calls"] == effects.len() + 1, "business count differs")?;
    let mut public_effects = Vec::new();
    for (id, plaintext) in &effects {
        let filename = id.as_bytes().iter().map(|b| format!("{b:02x}")).collect::<String>();
        let actual = fs::read(setup.responder.join("measured-effects").join(&filename))?;
        let mut expected = session.to_vec();
        expected.extend_from_slice(id.as_bytes());
        expected.extend_from_slice(plaintext);
        check(actual == expected, "durable effect bytes differ")?;
        public_effects.push(json!({"file":filename,"bytes":actual.len(),"sha3_256":digest(&actual)}));
    }
    spans.push(measure(witness.as_ref(), "close_initiator", || {
        endpoint.close();
        client.close();
        check(client.actor().is_err(), "closed owner still grants an actor")?;
        Ok(json!({"closed":true}))
    })?);
    let final_witness = witness_snapshot(witness.as_ref())?;
    let witness_record = match witness.as_mut() {
        Some(witness) => witness.finish()?,
        None => json!({"rows":[],"closed":true,"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0}),
    };
    drop(endpoint);
    drop(client);
    drop(witness);
    resources.push(memory("owners-closed", &setup.initiator, &setup.responder)?);
    let result = json!({"schema_version":1,"kind":"qperiapt.installed_operation_resources","completed":true,
        "profile":profile,"session":session,"ordinary_sends":48,"effects":public_effects,"server":server_summary,
        "spans":spans,"resources":resources,"witness":witness_record,"final_witness_snapshot":final_witness,
        "payload_matrix":[[64,0],[1024,32],[16384,1024]],"samples_per_payload_per_epoch":8,"epochs":[0,1],
        "scope":"Two owners and optional signed-TCP Witness in one process; real installed hybrid TLS and durable effects. CPU/memory are whole process; only Witness framed bytes are counted. Exact original-operation reopen, not a process crash or physical power loss. No revocation, device-replacement, fanout, mobile-energy or frozen-budget claim.",
        "release_claim_eligible":false});
    let mut file = fs::OpenOptions::new().create_new(true).write(true).open(output)?;
    file.write_all(&serde_json::to_vec_pretty(&result)?)?;
    file.sync_all()?;
    println!("OPERATION_RESOURCE_COMPLETE profile={profile} ordinary=48 effects=49");
    Ok(())
}
