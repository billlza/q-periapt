from pathlib import Path
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
DEST = REPO / 'research/sdk-alpha1/evidence/20261105-installed-operation-observer'
DEST.mkdir()
build = json.loads((ROOT / 'build-02/OBSERVER_BUILD.json').read_bytes())
assert build['completed'] and build['sources_unchanged']
outside = Path(json.loads((ROOT / 'build-02/LOCATION.json').read_bytes())['path'])
files = {}

def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            name = prefix + '/' + path.relative_to(directory).as_posix()
            assert name not in files
            files[name] = path

def sha(data):
    return hashlib.sha256(data).hexdigest()

for label in ('build-01', 'build-02', 'failed-observer-01'):
    tree(label, ROOT / label)
for name, digest in build['observer_source'].items():
    path = outside / 'observer' / name
    assert sha(path.read_bytes()) == digest
    files['observer/' + name] = path
binary = Path(build['binary'])
assert sha(binary.read_bytes()) == build['binary_sha256']
files['binary/journal_lifecycle'] = binary
for name, record in build['archives'].items():
    version = '0.0.0' if name == 'q-periapt-continuity-identity-candidate' else '0.2.0'
    directory = SOURCE / ('target/continuity-installed-rust-current' if version == '0.0.0' else 'target/sdk-020/crates')
    path = directory / (name + '-' + version + '.crate')
    assert path.stat().st_size == record['bytes'] and sha(path.read_bytes()) == record['sha256']
    files['archives/' + path.name] = path
files['archives/RUST_SDK_PACKAGE.json'] = SOURCE / 'target/sdk-020/RUST_SDK_PACKAGE.json'
files['archives/CONTINUITY_PACKAGE.json'] = SOURCE / 'target/continuity-installed-rust-current/CONTINUITY_PACKAGE.json'
for label in ('validation-local-01', 'validation-witness-01'):
    run = json.loads((ROOT / label / 'RUN.json').read_bytes())
    assert run['completed'] and run['performance_qualified'] is False
    tree('cohorts/' + label, ROOT / label)
for name in ('readback.py', 'capture.py', 'readback-local-01.stdout', 'readback-local-01.stderr',
             'readback-witness-01.stdout', 'readback-witness-01.stderr'):
    files['controller/' + name] = ROOT / name
for name in ('build-operation-observer.py', 'rebuild-operation-observer.py', 'run-operation-smoke.py'):
    files['controller/' + name] = SOURCE / 'target/current-rust-readback' / name
for name in ('operation-observer-build', 'operation-observer-build02', 'operation-validation-local-01', 'operation-validation-witness-01'):
    for suffix in ('stdout', 'stderr'):
        files['controller/' + name + '.' + suffix] = SOURCE.parent / (name + '.' + suffix)
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
        archive.writestr(name, data)
with zipfile.ZipFile(DEST / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
for label in ('local', 'witness'):
    (DEST / (label.upper() + '_READBACK.json')).write_bytes((ROOT / ('validation-' + label + '-01/READBACK.json')).read_bytes())
for name in ('readback.py',):
    (DEST / name).write_bytes((ROOT / name).read_bytes())
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
summary = {'source_commit': build['source_commit'], 'sdk_report_sha256': build['sdk_report_sha256'],
    'observer_binary_sha256': build['binary_sha256'], 'bytes': (DEST / 'CAPTURE.zip').stat().st_size,
    'sha256': sha((DEST / 'CAPTURE.zip').read_bytes()), 'members': len(manifest),
    'scope': 'Actual installed operation observer and functional validation only; includes original failed observer build, corrected source, strict checks, ten installed archives, binary, complete public spans and 98 synthetic durable business effects. No private keys/stores or controlled performance/resource-budget claim.',
    'performance_qualified': False, 'release_claim_eligible': False}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
