from pathlib import Path
import hashlib
import json
import os
import sys

import continuity_package as package
import rust_sdk_profile as sdk
from installed_rust_graph import external_lock, verify_resolution

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
STAGE = REPO / 'target/continuity-operation-resources-20261105'
OUT = STAGE / 'build-02'
OUT.mkdir()
previous = json.loads((STAGE / 'build-01/OBSERVER_BUILD.json').read_bytes())
assert previous['completed'] is False and previous['tests_executed'] is False
outside = Path(json.loads((STAGE / 'build-01/LOCATION.json').read_bytes())['path'])
consumer = outside / 'observer'
sdk.write_json(OUT / 'LOCATION.json', {'path': str(outside)})
for name, digest in previous['observer_source'].items():
    path = consumer / name
    assert sdk.snapshot(path).sha256 == digest
    sdk.copy(path, STAGE / 'failed-observer-01' / name)
changed = 'tests/journal_lifecycle.rs'
with (consumer / changed).open('wb') as stream:
    stream.write((STAGE / 'observer' / changed).read_bytes())
before = {name: sdk.snapshot(consumer / name).sha256 for name in previous['observer_source']}
assert {name for name in before if before[name] != previous['observer_source'][name]} == {changed}
commit, dirty = sdk.inspect_package_source(SOURCE, allow_dirty=False)
assert commit == previous['source_commit'] and not dirty
known = {}
for lock in (SOURCE / 'Cargo.lock', package.CANDIDATE / 'Cargo.lock'):
    for identity, value in external_lock(lock.read_bytes()).items():
        assert identity not in known or known[identity] == value
        known[identity] = value
original = 'version = 4\n'
for (name, version), (registry, checksum) in sorted(known.items()):
    original += '\n[[package]]\nname=' + json.dumps(name) + '\nversion=' + json.dumps(version) + '\nsource=' + json.dumps(registry) + '\nchecksum=' + json.dumps(checksum) + '\n'
versions = {name: sdk.VERSION for name in sdk.CONSUMER_CRATES}
versions[package.NAME] = package.VERSION
members_by_package = {}
for name in versions:
    base = SOURCE / ('target/continuity-installed-rust-current' if name == package.NAME else 'target/sdk-020/crates')
    data = sdk.snapshot(base / (name + '-' + versions[name] + '.crate'))
    assert data.sha256 == previous['archives'][name]['sha256'] and data.size == previous['archives'][name]['bytes']
    members_by_package[name] = sdk.archive_files(data.data, name, version=versions[name])

def verify_packages():
    for name, members in members_by_package.items():
        folder = consumer / 'packages' / (name + '-' + versions[name])
        assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()} == set(members)
        for relative, data in members.items():
            assert sdk.snapshot(folder / relative).data == data

verify_packages()
toolchain = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
assert not any((cache / name).exists() for name in ('config', 'config.toml', 'credentials', 'credentials.toml'))
env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPC_', 'QPERIAPT_'))}
for key in ('CC', 'CXX', 'AR', 'LD', 'CPP', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH',
            'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'OBJC_INCLUDE_PATH', 'LIBRARY_PATH', 'SDKROOT',
            'MACOSX_DEPLOYMENT_TARGET', 'OPENSSL_CONF', 'OPENSSL_CONF_INCLUDE', 'OPENSSL_MODULES',
            'OPENSSL_ENGINES', 'SSL_CERT_FILE', 'SSL_CERT_DIR'):
    env.pop(key, None)
env.update(CARGO_HOME=str(cache), CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR=str(outside / 'build'), CARGO=str(toolchain / 'bin/cargo'), RUSTC=str(toolchain / 'bin/rustc'),
    RUSTDOC=str(toolchain / 'bin/rustdoc'), RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
    DYLD_FALLBACK_LIBRARY_PATH=str(toolchain / 'lib'), PATH=str(toolchain / 'bin') + os.pathsep + env.get('PATH', os.defpath))

def run(argv, label):
    print(label, flush=True)
    return sdk.command(argv, OUT / label, consumer, environment=env)

result = dict(previous, completed=False, observer_source=before,
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    preceding_build='build-01', correction='Record the existing responder-open counter and emit completed spans immediately; preserve the original -D warnings failure.')
try:
    cc = Path(run(['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'clang'], 'clang-path').decode().strip()).resolve()
    sdkroot = Path(run(['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path'], 'sdk-path').decode().strip()).resolve()
    assert sdk.snapshot(cc, maximum=256 * 1024**2).sha256 == previous['clang']['sha256']
    assert sdk.snapshot(sdkroot / 'SDKSettings.json').sha256 == previous['clang']['sdk_settings_sha256']
    env.update(CC=str(cc), CFLAGS='-isysroot ' + str(sdkroot))
    assert run([str(toolchain / 'bin/rustc'), '-vV'], 'rustc').decode() == previous['rustc']
    metadata = json.loads(run([str(toolchain / 'bin/cargo'), 'metadata', '--locked', '--offline', '--format-version', '1'], 'metadata'))
    result['resolution'] = verify_resolution(metadata, consumer, (consumer / 'Cargo.lock').read_bytes(), original.encode(),
        consumer_name='q-periapt-continuity-operation-observer', versions=versions)
    assert metadata['workspace_members'] == metadata['workspace_default_members'] == [metadata['resolve']['root']]
    raw = run([str(toolchain / 'bin/cargo'), 'test', '--release', '--locked', '--offline', '--test', 'journal_lifecycle',
        '--no-run', '--message-format=json', '-j', '2'], 'compile')
    rows = [json.loads(line) for line in raw.splitlines()]
    binaries = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'journal_lifecycle']
    assert len(binaries) == 1
    binary = Path(binaries[0]['executable'])
    assert binary.parent == outside / 'build/release/deps'
    result['binary'] = str(binary)
    result['binary_sha256'] = sdk.snapshot(binary, maximum=256 * 1024**2).sha256
    run([str(toolchain / 'bin/cargo-clippy'), 'clippy', '--release', '--locked', '--offline', '--test', 'journal_lifecycle',
        '-j', '2', '--', '-D', 'warnings'], 'clippy')
    assert before == {name: sdk.snapshot(consumer / name).sha256 for name in before}
    verify_packages()
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (commit, dirty)
    result.update(completed=True, sources_unchanged=True)
finally:
    sdk.write_json(OUT / 'OBSERVER_BUILD.json', result)
