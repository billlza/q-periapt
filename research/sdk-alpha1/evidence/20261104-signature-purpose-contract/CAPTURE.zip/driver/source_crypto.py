from pathlib import Path
import os,json,sys,hashlib
sys.path.insert(0,str(Path.cwd()/'artifact'))
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/contract-purpose-admission/source-crypto';out.mkdir()
source=root/'target/contract-purpose-admission/source-current'
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_','QPC_'))}
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(source/'target/crypto-regression-build'),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
paths=['research/continuity-identity-candidate/src/crypto.rs','research/continuity-identity-candidate/src/contract.rs']
before={p:sdk.snapshot(source/p).sha256 for p in paths}
assert before=={p:sdk.snapshot(root/p).sha256 for p in paths}
sdk.command([str(tc/'bin/cargo'),'test','--release','--locked','--offline','--manifest-path',str(source/'research/continuity-identity-candidate/Cargo.toml'),'--lib','-j','2','crypto::','--','--nocapture'],out/'crypto-tests',source,environment=env)
assert before=={p:sdk.snapshot(source/p).sha256 for p in paths}
(out/'ORIGIN.json').write_text(json.dumps({'source_commit':'21e00e9c3cfd193b9f51491888347f583620dfe0','changed_source_hashes':before,'scope':'Source-workspace private crypto regression. The separate installed consumer preserves exclusion of dependency crates as workspace test members.','release_claim_eligible':False},indent=2)+'\n')
print('source crypto regression complete')
