from pathlib import Path
import os,json,subprocess,sys
sys.path.insert(0,str(Path.cwd()/'artifact'))
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/contract-purpose-admission/old';out.mkdir()
base=root/'target/installed-independent-qualification/source/target/independent-installed-current-02'
build=json.loads((base/'INSTALLED_COUNTERPART.json').read_text());outside=Path(json.loads((base/'LOCATION.json').read_text())['path'])
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_','QPC_'))}
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(outside/'consumer-build'),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
argv=[str(tc/'bin/cargo'),'build','--release','--locked','--offline','-p','q-periapt-continuity-identity-candidate','--example','contract_report','-j','2']
sdk.command(argv,out/'build',outside/'counterpart',environment=env)
binary=outside/'consumer-build/release/examples/contract_report'
sdk.copy(binary,out/'contract_report');(out/'contract_report').chmod(0o700)
sdk.command([str(out/'contract_report')],out/'run',outside/'counterpart',environment=env)
d=json.loads((out/'run.stdout').read_bytes());assert 'signature_purposes' not in d and d['schema_version']==1
(out/'ORIGIN.json').write_text(json.dumps({'source_commit':build['source_commit'],'candidate_archive_sha256':build['candidate_archive']['sha256'],'binary_sha256':sdk.snapshot(binary).sha256,'descriptor_schema':d['schema_version'],'signature_purposes_present':False,'product_crates_installed':True},indent=2)+'\n')
print('original installed contract descriptor omits signature purposes')
