from pathlib import Path
import os,json,sys,hashlib
sys.path.insert(0,str(Path.cwd()/'artifact'))
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/contract-purpose-admission/new';out.mkdir()
source=root/'target/contract-purpose-admission/source-current'
base=source/'target/contract-purpose-installed'
record=json.loads((base/'INSTALLED_COUNTERPART.json').read_text());assert record['completed'] is True
outside=Path(json.loads((base/'LOCATION.json').read_text())['path'])
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_','QPC_'))}
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(outside/'consumer-build'),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
manifest=outside/'counterpart'
name='q-periapt-continuity-identity-candidate'
args=['--release','--locked','--offline','-p',name,'--example','contract_report','-j','2']
sdk.command([str(tc/'bin/cargo'),'build',*args],out/'build',manifest,environment=env)
sdk.command([str(tc/'bin/cargo-clippy'),'clippy',*args,'--','-D','warnings'],out/'clippy',manifest,environment=env)
binary=outside/'consumer-build/release/examples/contract_report'
sdk.copy(binary,out/'contract_report');(out/'contract_report').chmod(0o700)
sdk.command([str(out/'contract_report')],out/'run',manifest,environment=env)
actual=json.loads((out/'run.stdout').read_bytes());expected=json.loads((root/'docs/continuity/BUDGETS_V1.json').read_text())
assert actual==expected and len(actual['signature_purposes'])==39
(out/'ORIGIN.json').write_text(json.dumps({'source_commit':record['source_commit'],'candidate_archive_sha256':record['candidate_archive']['sha256'],'native_sha256':record['native_sha256'],'binary_sha256':sdk.snapshot(binary).sha256,'descriptor_schema':actual['schema_version'],'signature_purpose_count':len(actual['signature_purposes']),'product_crates_installed':True},indent=2)+'\n')
sdk.command([sys.executable,'-I','-S','-B',str(root/'artifact/python_bootstrap.py'),str(root/'artifact/continuity_contract.py'),'--consumer',str(out/'contract_report'),'--output',str(out/'qualified')],out/'contract-gate',root,environment=env)
sdk.command([str(tc/'bin/cargo'),'test','--release','--locked','--offline','-p',name,'--lib','-j','2','crypto::','--','--nocapture'],out/'crypto-tests',manifest,environment=env)
print('new installed contract descriptor and crypto regressions complete')
