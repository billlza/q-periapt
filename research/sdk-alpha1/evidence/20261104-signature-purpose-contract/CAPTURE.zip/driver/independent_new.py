from pathlib import Path
import json,hashlib,sys,os
sys.path.insert(0,str(Path.cwd()/'artifact'))
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/contract-purpose-admission/independent';out.mkdir()
old=root/'target/installed-independent-qualification/source/target/independent-installed-lifecycle-01'
old_report=json.loads((old/'PYTHON_INSTALLATION.json').read_text())
location=Path(json.loads((old/'LOCATION.json').read_text())['path'])
application=location/'research/continuity-openssl-peer'
package=application/'qperiapt_continuity_reference'
def modules():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')}
assert modules()==old_report['modules']
base=root/'target/contract-purpose-admission/source-current/target/contract-purpose-installed'
b=json.loads((base/'INSTALLED_COUNTERPART.json').read_text());native=base/'counterpart'
assert b['completed'] is True and sdk.snapshot(native).sha256==b['native_sha256']
provider=Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
interpreter=[sys.executable,'-I','-S','-B',str(location/'artifact/python_bootstrap.py')]
sdk.command([*interpreter,str(application/'one_time_publication_checks.py'),'--provider-root',str(provider),'--native',str(native),'--output',str(out/'one-time-publication')],out/'one-time-publication',location)
sdk.command([*interpreter,str(application/'directory_lease_checks.py'),'--provider-root',str(provider),'--native',str(native),'--publication-case',str(out/'one-time-publication/PUBLIC_CASE.bin'),'--output',str(out/'directory-lease')],out/'directory-lease',location)
lease=json.loads((out/'directory-lease/RESULT.json').read_text())
assert lease['native_sha256']==b['native_sha256'] and lease['rust_signed_receipts_verified']==3 and lease['rust_canonical_conflict_matched'] is True
assert lease['historical_only'] is True and lease['private_keys_exported'] is False
assert modules()==old_report['modules'] and sdk.snapshot(native).sha256==b['native_sha256']
(out/'ORIGIN.json').write_text(json.dumps({'native_source_commit':b['source_commit'],'native_sha256':b['native_sha256'],'wheel_sha256':old_report['wheel_sha256'],'installed_python_modules_unchanged':True,'module_count':len(old_report['modules']),'rust_signed_receipts_verified':3,'rust_canonical_conflict_matched':True,'scope':'Focused installed-native/installed-wheel signature and directory regression; not a repeat of the complete 25-command lifecycle cohort.','release_claim_eligible':False},indent=2)+'\n')
print('installed independent signature and directory readback complete')
