from pathlib import Path
import json
import os
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_package as candidate
import continuity_c_consumer as c
import continuity_android_jni as android
import continuity_android_contract as contract
import continuity_android_pending as pending

root=Path.cwd();stage=root/'target/continuity-android-pending-recovery'
core=root/'target/continuity-browser-publication/source/target/pending-inspection-package-10'
archives=json.loads((core/'CORE_ARCHIVES.json').read_text());sdk.require(archives['completed'],'package incomplete')
outside=Path(tempfile.mkdtemp(prefix='qpc-pending-installed-current-')).resolve();consumer=outside/'c-consumer'
fixture=root/'bindings/c/ContinuityPackageConsumer';source_files={}
for path in fixture.rglob('*'):
    if path.is_file():
        sdk.copy(path,consumer/path.relative_to(fixture));source_files[str(path.relative_to(root))]=sdk.snapshot(path).sha256
sdk.extract_recorded_crates(consumer,core,archives['crates'])
record=archives['candidate'];archive=sdk.snapshot(core/record['file']);sdk.require(archive.sha256==record['sha256'],'candidate digest')
for name,data in candidate.validate_candidate(archive.data,set(record['files'])).items():
    path=consumer/'packages/q-periapt-continuity-identity-candidate-0.0.0'/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(data)
with (consumer/'Cargo.toml').open('a') as stream:stream.write('q-periapt-continuity-identity-candidate = { path = "packages/q-periapt-continuity-identity-candidate-0.0.0" }\n')
sdk.copy(root/'research/continuity-identity-candidate/Cargo.lock',consumer/'Cargo.lock')
env=json.loads((stage/'ENVIRONMENT_01.json').read_text());cargo=str(Path(env['RUSTC']).parent/'cargo');target=outside/'build'
original=(consumer/'Cargo.lock').read_bytes()
metadata=json.loads(sdk.command([cargo,'metadata','--offline','--format-version','1'],stage/'installed-metadata-11',consumer,environment=env))
resolution=candidate.verify_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),original,consumer_name=c.NAME,required_features=c.FEATURES)
sdk.write_json(stage/'INSTALLED_RESOLUTION_11.json',resolution)
cfg={'outside':str(outside),'consumer':str(consumer),'source_commit':archives['source_commit'],
     'candidate_sha256':record['sha256'],'source_files':source_files,'scope':'Actual Cargo archives outside checkout, configured public Java/JNI owner; same-host endpoints; physical ART separate'}
sdk.write_json(stage/'INSTALLED_11.json',cfg)
baseline=json.loads((root/'target/continuity-controller-pending-inspection/EXTERNAL_06.json').read_text())
client=outside/'controller';(client/'src').mkdir(parents=True)
probe=Path(baseline['client'])/'src/lib.rs';sdk.require(sdk.snapshot(probe).sha256==baseline['source_sha256'],'external baseline source changed')
sdk.copy(probe,client/'src/lib.rs')
manifest=(Path(baseline['client'])/'Cargo.toml').read_text().split('[patch.crates-io]')[0]+'[patch.crates-io]\n'
for name in [*sdk.CONSUMER_CRATES,candidate.NAME]:
    version='0.0.0' if name==candidate.NAME else '0.2.0'
    manifest+=name+' = { path = '+json.dumps(str(consumer/'packages'/(name+'-'+version)))+' }\n'
(client/'Cargo.toml').write_text(manifest);sdk.copy(Path(baseline['client'])/'Cargo.lock',client/'Cargo.lock')
sdk.command([cargo,'check','--locked','--offline','--lib','--target-dir',str(target),'-j','2'],stage/'external-api-green-11',client,environment=env)
output=sdk.command([cargo,'test','--locked','--offline','--test','android','--no-run','--message-format=json',
                   '--target-dir',str(target),'-j','2'],stage/'installed-harness-11',consumer,environment=env)
rows=[json.loads(line) for line in output.splitlines() if line.startswith(b'{')]
tests=[row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='android']
sdk.require(len(tests)==1,'harness identity')
contract.verify_catalog(sdk.command([tests[0],'--list'],stage/'installed-catalog-11',consumer,environment=env))
sdk.command([cargo,'rustc','--locked','--offline','--lib','--target-dir',str(target),'-j','2','--',
             '-C','link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib'],stage/'installed-library-11',consumer,environment=env)
runtime=outside/'runtime';runtime.mkdir();library=runtime/'libq_periapt_continuity_c_consumer.dylib'
sdk.copy(target/'debug'/library.name,library,maximum=256*1024**2)
symbols=sdk.command(['/usr/bin/nm','-gU',str(library)],stage/'installed-exports-11',outside).decode()
sdk.require({line.split()[-1].removeprefix('_') for line in symbols.splitlines() if line.strip()}==c.EXPORTS,'exports differ')
builder=outside/'android-source'
for name,data in android.source_files().items():
    path=builder/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(data)
java=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
classes=outside/'classes';classes.mkdir();test_classes=outside/'tests';test_classes.mkdir()
sdk.command([str(java/'bin/javac'),'--release','11','-Xlint:all','-Werror','-d',str(classes),*map(str,sorted((builder/'src/main/java').rglob('*.java')))],stage/'installed-java-11',outside,environment=env)
jar=runtime/'continuity-android.jar'
with zipfile.ZipFile(jar,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(classes.rglob('*.class')):
        info=zipfile.ZipInfo(path.relative_to(classes).as_posix());info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        bundle.writestr(info,sdk.snapshot(path).data)
sdk.command([str(java/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(test_classes),
             *map(str,sorted((builder/'src/test/java').glob('*.java')))],stage/'installed-java-tests-11',outside,environment=env)
clang=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],stage/'installed-clang-11',outside).decode().strip()
platform=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],stage/'installed-platform-11',outside).decode().strip()
flags=[clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,
       '-I'+str(consumer),'-L'+str(runtime),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path']
receiver=runtime/'qpc-c-client'
sdk.command([*flags,'-pthread','-O0','-g',str(consumer/'client.c'),str(consumer/'recovery_client.c'),str(consumer/'opening_client.c'),'-o',str(receiver)],stage/'installed-receiver-11',outside,environment=env)
bridge=runtime/'libqperiapt_continuity_jni.dylib'
sdk.command([*flags,'-fvisibility=hidden','-I'+str(java/'include'),'-I'+str(java/'include/darwin'),'-dynamiclib',
             *map(str,sorted((builder/'jni').glob('*.c'))),'-o',str(bridge)],stage/'installed-jni-11',outside,environment=env)
driver=android._driver(runtime,java/'bin/java',jar,test_classes,runtime)
paths={'harness':Path(tests[0]),'driver':driver,'receiver':receiver,'library':library,'jar':jar,'bridge':bridge}
cfg.update({name:str(path) for name,path in paths.items()});cfg.update({name+'_sha256':sdk.snapshot(path,maximum=256*1024**2).sha256 for name,path in paths.items()})
cfg['test_classes']={str(path.relative_to(test_classes)):sdk.snapshot(path).sha256 for path in test_classes.rglob('*.class')}
runtime_env={k:env[k] for k in ['HOME','LANG','LC_ALL','USER','LOGNAME','PATH','TMPDIR'] if k in env}
cfg['environment']=runtime_env;cfg['built']=True;sdk.write_json(stage/'INSTALLED_BUILD_11.json',cfg)
cases=stage/'installed-cases-11'
output=sdk.command([str(paths['harness']),'--exact',pending.TEST,'--nocapture'],stage/'installed-run-11',consumer,
    environment=dict(runtime_env,QPC_ANDROID_DRIVER=str(driver),QPC_ANDROID_CASES=str(cases),QPC_CONFIGURATION_RECEIVER=str(receiver)))
result=pending.verify_execution(output,cases)
for name,path in paths.items():sdk.require(sdk.snapshot(path,maximum=256*1024**2).sha256==cfg[name+'_sha256'],'runtime changed')
for name,digest in source_files.items():sdk.require(sdk.snapshot(root/name).sha256==digest,'source changed')
sdk.write_json(stage/'INSTALLED_RESULT_11.json',{'completed':True,'cases':result,'scope':cfg['scope'],
    'physical_ART':False,'source_commit':cfg['source_commit'],'candidate_sha256':cfg['candidate_sha256'],
    'external_api_red_green':True,'release_claim_eligible':False})
print('Exact installed archives: external public API and complete configured Java/JNI pending recovery passed')
