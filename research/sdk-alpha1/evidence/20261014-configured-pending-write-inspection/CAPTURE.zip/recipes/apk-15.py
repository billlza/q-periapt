from pathlib import Path
import json
import os
import subprocess
import tempfile
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=root/'target/continuity-android-pending-recovery';out=stage/'physical-12'
package=json.loads((out/'PACKAGE.json').read_text());sdk.require(package['completed'],'AAR incomplete')
sdk.require(not subprocess.check_output(['git','status','--porcelain']),'APK source not clean')
source=root/'bindings/android/ContinuityPackageConsumer';receipt=out/'agp-15';receipt.mkdir()
project=Path(tempfile.mkdtemp(prefix='qpc-pending-art-')).resolve();template=root/'artifact/android-agp-consumer'
for name in ['gradlew','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties',
             'settings.gradle.kts','build.gradle.kts','gradle.properties']:sdk.copy(template/name,project/name)
(project/'gradlew').chmod(0o700);sdk.copy(Path(package['aar']),project/'libs/continuity.aar',maximum=256*1024**2)
app=project/'app';java=app/'src/main/java/dev/qperiapt/continuity/android/tests';java.mkdir(parents=True)
probe_names=['ConfigurationProbe', 'EnrollmentProbe', 'PeerProbe', 'PeerRenewalProbe', 'CancellationProbe', 'WitnessProbe', 'AuthorityProbe', 'CredentialProbe', 'CredentialTerminalProbe', 'CredentialLocalProbe', 'CredentialPolicyExpiryProbe', 'PolicyProbe', 'PolicyProbeRecords', 'PolicyCredentialProbe', 'JointPolicyProbe', 'JointWitnessProbe', 'RosterProbe', 'RosterProbeRecords', 'RosterWitnessProbe', 'RosterPeerProbe', 'RetiredOwnedProbe', 'RootOwnedProbe', 'RootRecovery', 'RootControls', 'PendingWriteProbe']
inputs=[source/"src/test/java"/(name+".java") for name in probe_names]+sorted((source/"src/androidTest/java").rglob("*.java"))
source_hashes={str(path.relative_to(root)):sdk.snapshot(path).sha256 for path in inputs}
sdk.require(len({path.name for path in inputs})==len(inputs),'duplicate Java source')
for path in inputs:sdk.copy(path,java/path.name)
pkg='dev.qperiapt.continuity.pending20261014'
(app/'src/main/AndroidManifest.xml').write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:allowBackup="false" android:label="Continuity qualification"/><instrumentation android:name="dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation" android:targetPackage="'+pkg+'"/></manifest>')
(app/'build.gradle.kts').write_text('''plugins { id("com.android.application") }
android {
 namespace = "dev.qperiapt.continuity.android.tests"
 compileSdk = 36
 buildToolsVersion = "36.0.0"
 defaultConfig {
  applicationId = "dev.qperiapt.continuity.pending20261014"
  minSdk = 36
  targetSdk = 36
  versionCode = 1
  versionName = "qualification"
 }
 buildTypes {
  getByName("release") {
   isDebuggable = false
   isMinifyEnabled = true
   vcsInfo.include = false
   proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
  }
 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { buildConfig = false }
 packaging.jniLibs {
  useLegacyPackaging = false
  keepDebugSymbols += setOf("**/libq_periapt_continuity_c_consumer.so", "**/libqperiapt_continuity_jni.so")
 }
}
dependencies { implementation(files(rootProject.file("libs/continuity.aar"))) }
tasks.withType<JavaCompile>().configureEach {
 options.compilerArgs.addAll(listOf("-Xlint:all", "-Werror"))
 doFirst {
  file("compile-inputs.txt").writeText(source.files.map { it.canonicalPath }.sorted().joinToString("\\n", postfix="\\n"))
  file("compiler-home.txt").writeText(javaCompiler.get().metadata.installationPath.asFile.canonicalPath + "\\n")
 }
}
''')
jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home')
env={key:os.environ[key] for key in ['HOME','TMPDIR','USER','LOGNAME'] if key in os.environ}
env.update(JAVA_HOME=str(jdk),ANDROID_HOME='/Users/bill/Library/Android/sdk',GRADLE_USER_HOME='/Users/bill/.gradle',
 PATH=str(jdk/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',LANG='C.UTF-8',LC_ALL='C.UTF-8')
record={'completed':False,'project':str(project),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_sha256':source_hashes,'aar_sha256':package['aar_sha256'],'package':pkg,'release_claim_eligible':False}
sdk.write_json(receipt/'STATE.json',record)
sdk.command([str(project/'gradlew'),'--project-dir',str(project),'--offline','--no-daemon','--no-build-cache',
 '--no-configuration-cache','--max-workers=2','--warning-mode=fail','--console=plain',
 '-Dorg.gradle.java.home='+str(jdk),':app:assembleRelease'],receipt/'build',root,environment=env)
compiled=(project/'app/compile-inputs.txt').read_text().splitlines()
sdk.require(sorted(Path(p).name for p in compiled)==sorted(path.name for path in inputs)
 and all(Path(p).is_relative_to(java) for p in compiled),'APK source inventory differs')
sdk.require('dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:' in
 (app/'build/outputs/mapping/release/mapping.txt').read_text(),'JNI keep rules missing')
unsigned=app/'build/outputs/apk/release/app-release-unsigned.apk'
with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(unsigned) as apk:
    for name in ['libqperiapt_continuity_jni.so','libq_periapt_continuity_c_consumer.so']:
        sdk.require(aar.read('jni/arm64-v8a/'+name)==apk.read('lib/arm64-v8a/'+name),'APK native member differs')
bt=Path('/Users/bill/Library/Android/sdk/build-tools/36.0.0')
key=out/'qualification-15.p12';apk=out/'consumer-15.apk'
sdk.require(not key.exists() and not apk.exists(),'signing output already exists')
sdk.command([str(jdk/'bin/keytool'),'-genkeypair','-keystore',str(key),'-storepass','qualification-only','-alias','qualification',
 '-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Local Continuity Qualification','-noprompt'],receipt/'keytool',root,environment=env)
key.chmod(0o600)
sdk.command([str(bt/'apksigner'),'sign','--ks',str(key),'--ks-pass','pass:qualification-only','--out',str(apk),str(unsigned)],receipt/'sign',root,environment=env)
sdk.command([str(bt/'apksigner'),'verify','--verbose',str(apk)],receipt/'signature',root,environment=env)
for name,digest in source_hashes.items():sdk.require(sdk.snapshot(root/name).sha256==digest,'APK source changed')
record.update(completed=True,apk=str(apk),apk_sha256=sdk.snapshot(apk,maximum=256*1024**2).sha256,signed=True,
              native_members_equal=True,compiled_sources=sorted(path.name for path in inputs))
sdk.write_json(out/'PREPARED_APK_15.json',record)
print('Fresh non-debuggable R8 Android APK signed; exact AAR native members and source inventory verified')
