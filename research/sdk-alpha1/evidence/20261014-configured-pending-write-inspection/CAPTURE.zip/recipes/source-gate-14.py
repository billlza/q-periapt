from pathlib import Path
import subprocess
import sys
import rust_sdk_profile as sdk

root=Path.cwd();stage=root/'target/continuity-android-pending-recovery';clone=root/'target/continuity-browser-publication/source'
head='af3cc37c8d251a88cc010352253cf5a01e7b0d9d'
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain']),'main source changed')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=clone),'owned clone not clean')
sdk.command(['git','fetch',str(root),head],stage/'clone-fetch-14',clone)
sdk.command(['git','checkout','--detach',head],stage/'clone-checkout-14',clone)
sdk.command([sys.executable,'-B',str(clone/'artifact/python_bootstrap.py'),str(clone/'artifact/source_results_assembler.py'),
 'ci-source-gate','9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',head,'--profile','sdk-020'],
 stage/'source-gate-14',clone)
print('Final qualification source clean-clone gate passed')
