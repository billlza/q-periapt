from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=root/'target/continuity-android-pending-recovery'
controller=root/'target/continuity-controller-pending-inspection'
clone=root/'target/continuity-browser-publication/source'
package=clone/'target/pending-inspection-package-10';device=stage/'physical-12'
host=json.loads((stage/'INSTALLED_RESULT_11.json').read_text());physical=json.loads((device/'run-15/RESULT.json').read_text())
state=json.loads((device/'device-15/STATE.json').read_text())
sdk.require(host['completed'] and physical['completed'] and physical['cleanup'] and state['completed'] and state['cleanup']
    and not state.get('owned_reverse_ports'),'qualification not terminal')
out=root/'research/sdk-alpha1/evidence/20261014-configured-pending-write-inspection';out.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'duplicate captured path');files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(base,prefix,destination):
    for suffix in ['json','stdout','stderr']:add(base/(prefix+'.'+suffix),destination+'.'+suffix)
for name in ['inspection-tests-04','real-pending-tests-04','strict-clippy-04','portability-msrv-07',
             'portability-wasm-07','product-wasm-clippy-08','red-api-06']:
    logs(controller,name,'controller/'+name)
for name in ['INPUTS_04.json','EXTERNAL_06.json']:add(controller/name,'controller/'+name)
for name in ['android-harness-clippy-07','integration-controls-07','integration-controls-08','art-javac-08','art-javac-13',
 'external-api-green-11','installed-harness-11','installed-catalog-11','installed-library-11','installed-exports-11',
 'installed-java-11','installed-java-tests-11','installed-receiver-11','installed-jni-11','installed-run-11','host-run-05',
 'host-run-06','source-gate-14']:
    logs(stage,name,'host/'+name)
for name in ['SOURCE_09.json','SOURCE_COMMIT_09.json','ART_COMMIT_13.json','ART_SOURCE_13.json',
 'INSTALLED_RESULT_11.json','INSTALLED_BUILD_11.json','INSTALLED_RESOLUTION_11.json','RESULT_06.json','failed-scenario-05.rs']:
    add(stage/name,'host/'+name)
for name in pending.PUBLIC:add(stage/'installed-cases-11'/pending.LABEL/name,'host/public/'+pending.LABEL+'/'+name)
for name in ['candidate-list','candidate-package']:logs(package,name,'package/'+name)
add(package/'CORE_ARCHIVES.json','package/CORE_ARCHIVES.json')
for name in ['source-gate','controls']:logs(clone/'target/pending-inspection-source-10',name,'source/'+name)
for name in ['native-build','native-exports','javac','jni','engine-segments','bridge-segments']:logs(device,name,'android/'+name)
for name in ['PACKAGE.json','PREPARED_APK_15.json']:add(device/name,'android/'+name)
for attempt in ['agp-13','agp-15']:
    logs(device/attempt,'build','android/'+attempt+'/build')
    add(device/attempt/'STATE.json','android/'+attempt+'/STATE.json')
for name in ['keytool','sign','signature']:logs(device/'agp-15',name,'android/agp-15/'+name)
logs(device/'run-15','execution','device/execution')
logs(device/'run-15','catalog','device/catalog')
add(device/'run-15/RESULT.json','device/RESULT.json')
for path in sorted((device/'device-15').iterdir()):
    sdk.require(path.is_file() and path.suffix in {'.json','.stdout','.stderr'},'unexpected device capture')
    add(path,'device/commands/'+path.name)
for name in pending.PUBLIC:add(device/'run-15/public'/pending.LABEL/name,'device/public/'+pending.LABEL+'/'+name)
for name in ['installed-11.py','android-package-12.py','apk-13.py','apk-15.py','device-driver-15.py','run-device-15.py',
             'source-gate-14.py','capture-16.py']:add(stage/name,'recipes/'+name)
data=(device/'run-15/cases'/pending.LABEL/'inputs/tls-key').read_bytes()
for payload in files.values():sdk.require(data not in payload and base64.b64encode(data) not in payload,'private test TLS credential in capture')
# The local producers remain byte-for-byte intact. Only human hardware selectors
# in retained textual recipes are redacted; runtime input hashes retain identity.
for name,payload in list(files.items()):
    files[name]=payload.replace(b'<SELECTED_ANDROID_DEVICE>',b'<SELECTED_ANDROID_DEVICE>').replace(
        b'<SELECTED_ANDROID_DEVICE_SHA256>',b'<SELECTED_ANDROID_DEVICE_SHA256>')
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        bundle.writestr(info,data)
manifest={'format':1,'source_commit':physical['source_commit'],'engine_source_commit':host['source_commit'],
 'archive_sha256':sdk.snapshot(archive,maximum=32*1024**2).sha256,'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'candidate_sha256':host['candidate_sha256'],'aar_sha256':physical['aar_sha256'],'apk_sha256':physical['apk_sha256'],
 'host_foreign_processes':18,'physical_ART_processes':18,'physical_API':37,'release_claim_eligible':False,
 'recipe_hardware_selectors_redacted':True}
sdk.write_json(out/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-pending-capture-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(archive) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'capture inventory')
        for name,digest in manifest['members'].items():
            data=bundle.read(name);sdk.require(hashlib.sha256(data).hexdigest()==digest,'capture member changed')
            if '/public/' in name:
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        sdk.require(pending.verify_execution(bundle.read('host/installed-run-11.stdout'),extracted/'host/public')==host['cases'],'host readback differs')
        sdk.require(pending.verify_execution(bundle.read('device/execution.stdout'),extracted/'device/public')==physical['result'],'device readback differs')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256'],
 'host_and_device_public_readers':True,'private_test_key_excluded':True})
print(json.dumps({'completed':True,'members':len(files),'archive_sha256':manifest['archive_sha256']}))
