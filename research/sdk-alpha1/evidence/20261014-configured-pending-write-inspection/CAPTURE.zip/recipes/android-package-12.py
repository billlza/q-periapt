from pathlib import Path
import json
import zipfile
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import third_party_licenses as licenses

root=Path.cwd();stage=root/'target/continuity-android-pending-recovery';out=stage/'physical-12';out.mkdir()
installed=json.loads((stage/'INSTALLED_11.json').read_text());consumer=Path(installed['consumer'])
env=json.loads((stage/'ENVIRONMENT_01.json').read_text())
tool=root/'target/android-physical-current/rustup/toolchains/1.98.1-aarch64-apple-darwin'
ndk=Path('/Users/bill/Library/Android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/darwin-x86_64/bin')
env.update(RUSTC=str(tool/'bin/rustc'),RUSTDOC=str(tool/'bin/rustdoc'),
 PATH=str(tool/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tool/'lib'),
 CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=str(ndk/'aarch64-linux-android23-clang'),
 CC_aarch64_linux_android=str(ndk/'aarch64-linux-android23-clang'),AR_aarch64_linux_android=str(ndk/'llvm-ar'),
 RUSTFLAGS='-D warnings -C link-arg=-Wl,-z,max-page-size=16384')
target=Path(installed['outside'])/'android-build';cargo=str(tool/'bin/cargo')
source=root/'bindings/android/ContinuityPackageConsumer';builder=out/'source';hashes={}
for path in [*(source/'src/main/java').rglob('*.java'),*(source/'jni').glob('*'),source/'consumer-rules.pro']:
    if path.is_file():
        sdk.copy(path,builder/path.relative_to(source));hashes[str(path.relative_to(source))]=sdk.snapshot(path).sha256
state={'completed':False,'source_commit':installed['source_commit'],'candidate_sha256':installed['candidate_sha256'],
       'consumer':str(consumer),'source':str(builder),'source_sha256':hashes,'environment':env,'release_claim_eligible':False}
sdk.write_json(out/'STATE.json',state)
sdk.command([cargo,'build','--release','--lib','--target','aarch64-linux-android','--target-dir',str(target),
             '--locked','--offline','-j','2'],out/'native-build',consumer,environment=env)
native=out/'native';native.mkdir();engine=native/'libq_periapt_continuity_c_consumer.so'
sdk.copy(target/'aarch64-linux-android/release'/engine.name,engine,maximum=256*1024**2)
symbols=sdk.command([str(ndk/'llvm-nm'),'-D','--defined-only',str(engine)],out/'native-exports',root,environment=env).decode()
sdk.require({line.split()[-1] for line in symbols.splitlines() if line.strip()}==c.EXPORTS,'Android C exports differ')
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
classes=out/'classes';classes.mkdir()
sdk.command([str(jdk/'bin/javac'),'--release','11','-Xlint:all','-Werror','-d',str(classes),
 *map(str,sorted((builder/'src/main/java').rglob('*.java')))],out/'javac',root,environment=env)
bridge=native/'libqperiapt_continuity_jni.so'
sdk.command([str(ndk/'aarch64-linux-android23-clang'),'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic',
 '-fvisibility=hidden','-I'+str(consumer),'-fPIC','-shared',*map(str,sorted((builder/'jni').glob('*.c'))),
 '-L'+str(native),'-lq_periapt_continuity_c_consumer','-Wl,--no-undefined','-Wl,-soname,libqperiapt_continuity_jni.so',
 '-Wl,-z,max-page-size=16384','-o',str(bridge)],out/'jni',root,environment=env)
for file,label in [(engine,'engine'),(bridge,'bridge')]:
    text=sdk.command([str(ndk/'llvm-readelf'),'--program-headers','--wide',str(file)],out/(label+'-segments'),root,environment=env).decode()
    rows=[line.split() for line in text.splitlines() if line.strip().startswith('LOAD ')]
    sdk.require(rows and all(int(row[-1],16)>=16384 for row in rows),'Android 16KiB load alignment')
def archive(path,items):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
        for name,data in sorted(items.items()):
            info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            bundle.writestr(info,data)
jar=out/'classes.jar';archive(jar,{p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob('*.class')})
metadata=json.loads(sdk.command([cargo,'metadata','--locked','--offline','--format-version','1','--filter-platform','aarch64-linux-android'],out/'license-metadata',consumer,environment=env))
notices=out/'notices';notices.mkdir();licenses.collect(consumer,notices,'aarch64-linux-android',root_package=c.NAME,resolved_metadata=metadata)
licenses.verify(notices,expected_target='aarch64-linux-android',root_package=c.NAME)
files={'classes.jar':jar.read_bytes(),'proguard.txt':(builder/'consumer-rules.pro').read_bytes(),
 'AndroidManifest.xml':b'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.qperiapt.continuity.android"><uses-sdk android:minSdkVersion="23"/></manifest>\n'}
for path in [engine,bridge]:files['jni/arm64-v8a/'+path.name]=path.read_bytes()
for path in notices.rglob('*'):
    if path.is_file():files['META-INF/native-notices/'+path.relative_to(notices).as_posix()]=path.read_bytes()
for name in ['Apache-2.0.txt','MIT.txt','Rust-1.98.1-library.html']:files['META-INF/LICENSES/'+name]=(root/'LICENSES'/name).read_bytes()
for name in ['INVENTORY.sha256','LICENSE-INVENTORY.md','LICENSE.mlkem-native','PROVENANCE.md']:
    files['META-INF/LICENSES/mlkem-native/'+name]=(root/'crates/q-periapt-mlkem-native-sys/vendor'/name).read_bytes()
aar=out/'q-periapt-continuity-android-0.0.0.aar';archive(aar,files)
for name,digest in hashes.items():sdk.require(sdk.snapshot(source/name).sha256==digest,'Android library source drift')
state.update(completed=True,aar=str(aar),aar_sha256=sdk.snapshot(aar,maximum=256*1024**2).sha256,
 native_engine_sha256=sdk.snapshot(engine,maximum=256*1024**2).sha256,jni_sha256=sdk.snapshot(bridge).sha256,exports=len(c.EXPORTS),
 members_sha256={name:__import__('hashlib').sha256(data).hexdigest() for name,data in files.items()})
sdk.write_json(out/'PACKAGE.json',state)
print('Current installed archives produced Android release AAR with exact exports, 16KiB segments and licenses')
