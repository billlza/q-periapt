"""Rank all witness goals; ordinary inputs remain in the prover trace."""
from pathlib import Path
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
import re
import sys
import time

MAXIMUM_INPUT_CHARACTERS = 16 * 1024 * 1024
RANKING_INPUT_CHARACTERS = 4 * 1024 * 1024
MAXIMUM_RETAINED_BYTES = 32 * 1024 * 1024
MAXIMUM_CALLBACKS = 128
MAXIMUM_DIAGNOSTIC_CALLBACKS = 128

def rank(raw):
    if len(raw) > MAXIMUM_INPUT_CHARACTERS:
        raise ValueError("oracle capture input bound exceeded")
    goals = []
    for line in raw.splitlines():
        match = re.match(r"^([0-9]+):\s*(.*)$", line)
        if not match:
            raise ValueError("unexpected goal encoding")
        goals.append((int(match[1]), match[2]))
    if len({number for number, _ in goals}) != len(goals):
        raise ValueError("duplicate goal inventory")

    if len(raw) > RANKING_INPUT_CHARACTERS:
        return goals, []

    # The current corrected model's frontier loops through unchanged SendState
    # outputs from Final_Reservation_7. Follow deduction edges and the actual
    # positioned protocol state before unrolling another SendState producer.
    def priority(item):
        goal = item[1]
        if re.match(r"!?KU\(\s*~key(?:\.[0-9]+)?\s*\)\s*@\s*#known$", goal):
            return 0
        if re.search(r"last\(#known(?:\.[0-9]+)?\)", goal):
            return 1
        if '~~>' in goal:
            return 2
        if goal.startswith(('PositionedPhaseState(', 'ReadyState(')):
            return 3
        if goal.startswith(('!Entropy(', '!IdentityKey(', '!StorageKey(', '!Signer(', '!SignerFile(', '!Pinned(', '!Peers(', '!Context(', '!Wrap(')):
            return 4
        if goal.startswith('SendState('):
            return 7
        if '∥' in goal:
            return 6
        return 5

    return goals, [number for number, _ in sorted(goals, key=priority)]

@contextmanager
def serialized_capture(path):
    with path.open('a') as lock:
        deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('oracle capture lock timed out after five seconds')
                time.sleep(0.01)
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)

def main():
    stage = Path(__file__).resolve().parent
    folder = stage / 'initial-send-oracle-frames'
    raw = None
    try:
        if sys.argv[1:] != ['epoch_generation_secret_derivation_origin']:
            raise ValueError('unexpected lemma sent to witness oracle')
        raw = sys.stdin.read(MAXIMUM_INPUT_CHARACTERS + 1)
        goals, ranking = rank(raw)
        stopped = len(raw) > RANKING_INPUT_CHARACTERS
        payload = raw.encode()
        with serialized_capture(stage / 'initial-send-oracle.lock'):
            existing = sorted(folder.glob('*.json'))
            records = [json.loads(p.read_text()) for p in existing]
            diagnostic_count = sum(entry['diagnostic_stop'] for entry in records)
            ordinary_count = len(records) - diagnostic_count
            marker = stage / 'initial-send-oracle.diagnostic-stop'
            latched_reason = marker.read_text().strip() if marker.exists() else None
            if diagnostic_count and latched_reason is None:
                raise ValueError('diagnostic marker missing after retained stop')
            if latched_reason not in (None, 'callback-budget', 'input-size'):
                raise ValueError('invalid diagnostic stop reason')
            if ordinary_count > MAXIMUM_CALLBACKS or diagnostic_count >= MAXIMUM_DIAGNOSTIC_CALLBACKS:
                raise ValueError('diagnostic callback bound reached')
            stop_reason = latched_reason or ('callback-budget' if ordinary_count == MAXIMUM_CALLBACKS else 'input-size' if stopped else None)
            if stop_reason is not None:
                ranking = []
                stopped = True
            stem = f'{len(existing):04}'
            capture_name = stem + '.txt' if stopped else None
            entry = {'input_sha256': hashlib.sha256(payload).hexdigest(),
                'input_characters': len(raw), 'input_bytes': len(payload),
                'goal_numbers': [number for number, _ in goals], 'ranking': ranking,
                'selected_prefix': dict(goals)[ranking[0]][:1024] if ranking else None,
                'diagnostic_stop': stopped, 'stop_reason': stop_reason, 'captured_input': capture_name,
                'full_input_in_capture_file': stopped, 'input_was_complete': True,
                'ordinary_input_retention': 'Complete input is emitted by the prover oracle trace.'}
            encoded = (json.dumps(entry, ensure_ascii=False) + '\n').encode()
            needed = len(encoded) + (len(payload) if stopped else 0)
            if sum(p.stat().st_size for p in folder.iterdir() if p.is_file()) + needed > MAXIMUM_RETAINED_BYTES:
                raise ValueError('retained capture bound reached')
            if capture_name is not None:
                with (folder / capture_name).open('xb') as f:
                    f.write(payload)
            with (folder / (stem + '.json')).open('xb') as f:
                f.write(encoded)
            if stopped and latched_reason is None:
                with marker.open('x') as f:
                    f.write(stop_reason + '\n')
        for number in ranking:
            print(number)
    except Exception as exc:
        # Exactly one failing callback owns the bounded failure capture. Other
        # failures still raise and remain in stderr; none returns success.
        claim = stage / 'initial-send-oracle.failure-owner'
        try:
            fd = os.open(claim, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise RuntimeError('additional oracle failure; first capture already owned') from exc
        os.close(fd)
        record = {'error': type(exc).__name__ + ': ' + str(exc), 'input_available': raw is not None}
        if raw is not None:
            payload = raw.encode()
            with (stage / 'initial-send-oracle-failed-input.txt').open('xb') as f:
                f.write(payload)
            record.update(characters=len(raw), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
                complete_input=len(raw) <= MAXIMUM_INPUT_CHARACTERS)
        with (stage / 'initial-send-oracle-failed-input.json').open('x') as f:
            json.dump(record, f)
        with (stage / 'initial-send-oracle.failed').open('x') as f:
            f.write(record['error'] + '\n')
        raise

if __name__ == '__main__':
    main()
