from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-requests';package=root/'target/continuity-browser-publication/source/target/policy-request-package-01'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={n:load(stage/n/'RESULT.json') for n in ['run01','run03','run05']};assert all(r['completed'] for r in reports.values())
cases={c['case']:c for n in ['run01','run05'] for c in reports[n]['cases']};assert set(cases)=={'local','required','expired-required','no-local-fallback','wrong-witness','read-loss','cancel'}
for name,c in cases.items():
 r=c['request'];i=c['issuer'];v=r['requestValue'];assert not r['runtimeCreated'] and r['status']==c['original']['status'] and v['journal']==c['original']['journal']
 assert i['issued_and_verified'] and i['unchanged_credential_and_roster'] and i['negative_controls']==2 and i['operation']==v['operation'] and i['previous_policy_expired']==(name=='expired-required')
 assert v['original_credential']==v['current_credential'] and v['original_roster']==v['current_roster'] and v['original_credential_digest']==v['current_credential_digest'] and v['previous_policy_authorization'] is None
 assert v['original_policy_digest']==v['previous_policy_digest'] and v['original_policy_version']==v['previous_policy_version']
 if name=='local':assert not c['witness_records']
 if name in ['read-loss','cancel']:
  assert c['rejection']['code']==('WitnessTransport' if name=='read-loss' else 'Cancelled') and c['rejection']['ownerClosed']
  fault=[x for x in c['witness_records'] if x['trigger']];assert len(fault)==1 and not fault[0]['changed']
 if name=='cancel':assert c['rejection']['cancellationRequested']
 if name=='no-local-fallback':assert c['rejection']['code']=='AnchorRequired' and c['rejection']['ownerClosed']
 if name=='wrong-witness':assert c['rejection']['code']=='Conflict' and c['rejection']['ownerClosed']
e=cases['expired-required'];assert e['real_expiry']['activated_at']<e['real_expiry']['valid_until']<e['real_expiry']['request_at'] and e['expired_activation']['code']=='Validity'
g={c['case']:c for c in reports['run03']['cases']};assert set(g)=={'local','applied'}
for c in g.values():assert c['final']['phase']==4 and c['current']['journal']==c['original']['journal'] and c['current']['prekey']==c['original']['prekey']
p=g['local']['policy_request_after_g'];v=p['requestValue'];assert not p['runtimeCreated'] and v['original_credential']!=v['current_credential'] and v['current_credential']==g['local']['actual_predecessor']['previous_credential'] and v['current_roster']==g['local']['actual_predecessor']['previous_roster']
assert g['applied']['policy_request_refusal']['code']=='Conflict' and g['applied']['policy_request_refusal']['ownerClosed']
failed=load(stage/'run02/RESULT.json');assert not failed['completed'] and 'Protocol(Validity)' in failed['failure']
failed_owner=load(stage/'run04/RESULT.json');assert not failed_owner['completed'] and 'wrong failure' in failed_owner['failure'] and 'Protocol(Validity)' in failed_owner['failure']
for n,num in [('native-request-tests.log',7),('native-witness-tests.log',67)]:assert f'{num} passed; 0 failed' in (stage/n).read_text()
assert 'Ran 53 tests' in (stage/'controls-02.log').read_text() and (stage/'controls-02.log').read_text().rstrip().endswith('OK')
for n in ['wasm-clippy.log','wasm-msrv.log','authority-build-04.log','issuer-build-02.log']:
 t=(stage/n).read_text();assert 'Finished' in t and 'error:' not in t and 'warning:' not in t
assert not (stage/'format.log').read_text()
base=load(stage/'base10/RESULT.json');assert base['completed'] and len(base['report']['cases'])==10
receipt=load(package/'INSTALLED_CONSUMER.json');assert receipt['source_bound'] and receipt['sources_unchanged'] and receipt['sha256']==sha(package/'q-periapt-sdk-wasm-0.2.0.tgz')
source=load(stage/'SOURCE_OVERLAY.json')
for n,d in source['overlay'].items():assert sha(root/n)==d,n
installed=Path(load(package/'consumer-location.json')['path'])
for run,r in reports.items():
 for n,d in r['native'].items():assert sha(Path(n))==d,n
 for n,d in r['source']['inputs'].items():assert sha(root/n)==d,n
 for n,d in r['static_web'].items():
  assert sha(stage/(run+'-web')/n)==d,n
  if not n.startswith('creation/'):assert sha(installed/n)==d,n
members={};raw={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members
 assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts)
 members[n]=p
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.js','.json','.log','.txt','.sh'] and p.name not in ['seal.log','finalize.log','HANDOFF.json']:add(p,'driver/'+p.name)
for d in ['authority','issuer']:
 for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/d/n,d+'/'+n)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','witness/authority.rs')
add(root/'target/continuity-browser-credential-commit/authority/src/main.rs','credential-issuer/main.rs')
for run in ['run01','run02','run03','run04','run05','base10']:
 folder=stage/run
 for p in sorted(folder.iterdir()):
  if p.is_file():add(p,run+'/'+p.name)
 for part in ['logs','captures']:
  for p in sorted((folder/part).rglob('*')):
   if p.is_file():add(p,run+'/'+p.relative_to(folder).as_posix())
 for p in sorted((folder/'witness').rglob('*')):
  if p.is_file():raw[run+'/'+p.relative_to(folder).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted((folder/'witness').rglob('RECORDS.json')):
  add(p,run+'/'+p.relative_to(folder).as_posix())
  for r in load(p):
   if r['trigger']:
    for q in sorted(p.parent.glob(f"{r['number']:03}.*")):
     if q.is_file():add(q,run+'/'+q.relative_to(folder).as_posix())
 for p in sorted((stage/(run+'-web')/'inputs').glob('*')):
  if p.is_file():add(p,'public-inputs/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json']:add(package/n,'package/'+n)
raw_bytes=(json.dumps(raw,sort_keys=True,indent=2)+'\n').encode();manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())};manifest['FULL_RAW_TRACE_MANIFEST.json']={'sha256':hashlib.sha256(raw_bytes).hexdigest(),'bytes':len(raw_bytes)};encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-policy-requests';dest.mkdir();archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('FULL_RAW_TRACE_MANIFEST.json',raw_bytes);z.writestr('MANIFEST.json',encoded)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256'] and len(z.read(n))==m['bytes']
checks={'completed':True,'release_claim_eligible':False,'source':source,'case_count':9,'issuer_cases':sorted(cases),'post_g_cases':{'local':'actual successor metadata','required':'Conflict before witness dispatch; original G remains active'},'validation':{'native_policy_request':7,'native_independent_policy':67,'base_browser':10,'artifact_controls':53,'wasm_clippy':'-D warnings passed','wasm_msrv':'1.90 passed','format':'passed','browser':base['report']['browser']},'real_policy_expiry':e['real_expiry'],'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged']},'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(encoded).hexdigest()},'scope':'Original installed browser public P issuer requests, independently held native account/policy approvals and exact predecessor checks. Same Rust engine and loopback. Required P after G explicitly unsupported; browser P adoption/activation/cleanup, independent implementation, devices/performance/PCS and full release remain open.'}
sdk.write_json(dest/'CHECKS.json',checks);print(json.dumps(checks['capture']))
