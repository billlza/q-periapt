from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-policy-requests';clone=root/'target/continuity-browser-publication/source';old=root/'target/continuity-browser-credential-renewal'
paths=sdk.command(['git','ls-files','-m','-o','--exclude-standard'],stage/'overlay-paths',root).decode().splitlines();overlay={}
for n in paths:
 p=root/n;overlay[n]=sdk.snapshot(p).sha256;dest=clone/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
sdk.command(['git','add','--',*paths],stage/'overlay-stage',clone)
sdk.write_json(stage/'SOURCE_OVERLAY.json',{'base_commit':'0dabeb7411cea486ff11b3e2370b88bdea55b54d','overlay':overlay,'source':str(clone)})
(stage/'build-package.sh').write_text((root/'target/continuity-browser-peer-credential/build-package.sh').read_text().replace('peer-credential-package-01','policy-request-package-01'))
(stage/'base-browser.py').write_text((old/'base-browser.py').read_text().replace('continuity-browser-credential-renewal','continuity-browser-policy-requests').replace('credential-request-package-01','policy-request-package-01'))
for n in ['server.py','controller.js']:shutil.copyfile(old/n,stage/n)
s=(old/'worker.js').read_text().replace('new-credential-operation','new-policy-operation').replace('credential-request','policy-request').replace('QPeriaptContinuityCredentialRequest','QPeriaptContinuityPolicyRequest').replace('.credential_renewal_request(','.policy_renewal_request(').replace('.witnessed_credential_renewal_request(','.witnessed_policy_renewal_request(')
s=s.replace("['journal','original_owner','original_policy_digest','current_policy_digest','original_roster_digest','previous_roster_digest','original_credential','original_roster','previous_credential','previous_roster']","['journal','original_owner','original_credential_digest','current_credential_digest','current_roster_digest','original_policy_digest','previous_policy_digest','original_credential','original_roster','current_credential','current_roster']")
s=s.replace("['current_policy_version','original_roster_version','previous_roster_version','previous_valid_from','previous_valid_until']","['current_roster_version','original_policy_version','previous_policy_version']").replace('current_policy_authorization','previous_policy_authorization')
(stage/'worker.js').write_text(s)
s=(old/'run.py').read_text().replace('continuity-browser-credential-renewal','continuity-browser-policy-requests').replace('credential-request-package-01','policy-request-package-01').replace('q-periapt-browser-credential-authority','q-periapt-browser-policy-request-issuer').replace('examples/browser_activation_authority','q-periapt-browser-policy-request-authority').replace('new-credential-operation','new-policy-operation').replace('credential-request','policy-request')
s=s.replace("native(authority,['prepare',directory],case+'-authority')", "native(authority,['prepare-expiring-policy' if case=='expired-required' else 'prepare',directory],case+'-authority')")
start=s.index("    if case=='expired-required':");end=s.index("    shutil.copyfile",start);s=s[:start]+s[end:]
s=s.replace("cfg['until']","cfg['policy_until']")
s=s.replace("issued['same_key_and_generation']", "issued['unchanged_credential_and_roster']").replace("issued['previous_expired']", "issued['previous_policy_expired']")
s=s.replace('public credential renewal requests','public policy renewal requests').replace('not renewal commit','not policy adoption').replace("renewal=out/(case+'-renewal.json')", "renewal=out/(case+'-approval.json')")
s=s.replace("web=Path(json.loads((package/'consumer-location.json').read_text())['path']);", "installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));")
needle="state={'completed':False";s=s.replace(needle,"sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')\n"+needle)
(stage/'run.py').write_text(s)
authority=stage/'authority';(authority/'src').mkdir(parents=True)
source=root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs'
s=source.read_text();s=s.replace('"prepare" => {','"prepare" | "prepare-expiring-policy" => {')
oldline='let authority=p::PolicySigningKey::provision(&dir.join("private-policy.key"),&wrap,p::SigningKeyId::generate()?)?;'
assert s.count(oldline)==1;s=s.replace(oldline,'let policy_id=p::SigningKeyId::generate()?;publish_private_bytes(&dir.join("policy-id.bin"),policy_id.as_bytes())?;let authority=p::PolicySigningKey::provision(&dir.join("private-policy.key"),&wrap,policy_id)?;')
s=s.replace('let validity=p::Validity::new(at-1,at+3600)?;','let policy_until=at+if mode=="prepare-expiring-policy"{90}else{3600};let validity=p::Validity::new(at-1,policy_until)?;')
s=s.replace('"policy_root":authority.public_key()?.encode(),','"policy_until":policy_until,"policy_root":authority.public_key()?.encode(),')
(authority/'src/main.rs').write_text(s)
manifest=(old/'authority/Cargo.toml').read_text().replace('q-periapt-browser-credential-authority','q-periapt-browser-policy-request-authority')
extra=''.join(n+' = { path = "'+str(root/'crates'/n)+'" }\n' for n in ['q-periapt-backends','q-periapt-policy','q-periapt-sig'])+'getrandom = "0.4"\nzeroize = "1"\n'
manifest=manifest.replace('[profile.dev.package.',extra+'[profile.dev.package.')
(authority/'Cargo.toml').write_text(manifest)
issuer=stage/'issuer';(issuer/'src').mkdir(parents=True);(issuer/'Cargo.toml').write_text((old/'authority/Cargo.toml').read_text().replace('q-periapt-browser-credential-authority','q-periapt-browser-policy-request-issuer'))
header=(old/'authority/src/main.rs').read_text().split('fn main()')[0];(issuer/'src/main.rs').write_text(header+(stage/'issuer-main.rs.txt').read_text())
