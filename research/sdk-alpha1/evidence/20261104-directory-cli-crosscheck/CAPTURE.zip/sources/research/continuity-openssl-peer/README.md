# Independent Continuity interoperability peer

This unpublished Python endpoint implements a first, deliberately bounded part
of the candidate protocol independently of the Q-Periapt engine. It constructs
and authenticates real protocol flights; it does not call the Rust candidate to
parse, verify, derive, encapsulate or finish its own operation. Cryptographic
primitives use `cryptography 48.0.1` with OpenSSL. PyCA's own provider bindings
contain Rust, but contain no Q-Periapt protocol implementation.

The separate `native` executable is the actual Rust **responder** and a test
enrollment authority. It issues fresh credentials for the Python-owned signing
public key and independently owned Rust responder. Its public-only files supply
explicit test trust pins and untrusted signed material through separate inputs.
This is controlled enrollment for the experiment, not a network registration or
trust-distribution protocol. No private key or KEM secret crosses the control
pipe. Three-flight payloads use the unchanged candidate bytes.

The current supported profiles use reusable-both prekeys, a two-leaf manifest,
and the stated fixed SDK algorithm policy. Local-only sessions and sessions with
one explicitly pinned required witness have separate creation/opening APIs.
Local and volatile entry points reject required-witness policies. One-time modes
and other manifests/policies fail instead of selecting a weaker mode.
The peer independently verifies SDK and protocol policy, both
identity chains, exact roster heads, validity, key separation, the manifest and
both leaf proofs. It constructs the canonical selection and role-ordered context
before doing the policy-bound hybrid KEM and confirmation schedule.

The protocol code is in `qperiapt_continuity_reference`, including `wire.py`,
`authority.py`, `kem.py`, `bootstrap.py`, `traffic.py`, and `rekey.py`.
The [host enrollment exchange adapter](ENROLLMENT_EXCHANGE.md) accepts public
invitations and issued results against separately supplied host, current-roster
and signed-policy expectations using the original protected registration owner.
The bounded runner and Rust test counterpart are separate.
The [`publication` adapter](../continuity-reference-app/NATIVE_SESSION.md) also
consumes public advertisements from the native enrollment CLI without a built-in
issuer. It authenticates through the same independent verifier and prepares the
original `EnrollmentClient`. The native reference serves bootstrap, durable inbox
delivery and rekey control over file and explicit TCP carriers. The independent
[session CLI](SESSION_CLI.md) sends and receives on that original confirmed
connection, with durable host inbox commands and process recovery. Opposing
application sends release local owners during network I/O and revalidate their
original operation on completion. Simultaneous rekey and cross-host deployment
remain separate acceptance gates.
Failed replies leave the original operation pending. Successful replies pin the
exact bytes; identical replay returns the same final, and a conflicting reply
fails. Bootstrap owner operations check the supplied trusted time. Close is idempotent
and prevents future operations.

## Run

Use the repository-pinned Rust toolchain and the committed separate lockfile:

```sh
cargo build --release --locked \
  --manifest-path research/continuity-openssl-peer/native/Cargo.toml
sh artifact/python-run.sh research/continuity-openssl-peer/run.py \
  --provider-root /absolute/path/to/site-packages \
  --native /absolute/path/to/q-periapt-independent-peer-counterpart \
  --output /absolute/path/to/new-result-directory
```

The explicitly supplied provider directory must contain the pinned
`requirements.txt` dependencies. The CI workflow installs only hash-pinned
CPython 3.14 wheels into a new job-local directory, using `--no-deps` and
`--require-hashes`. The hardened repository launcher remains in use;
the runner does not process `.pth` files, import `site`, or use `PYTHONPATH`.
Nothing is installed globally. This first control-pipe runner supports POSIX.
Each control exchange has a 30-second deadline and a 32768-byte response cap.
Failures terminate the owned native process group and remain failures.

`RESULT.json` records actual versions, loaded provider/source hashes, the native
binary hash, canonical-byte agreement, real native responses and rejected cases.
Public signed input files and the three successful protocol flights are retained.
The controls exercise each signature component, malformed envelopes, pin and
validity violations, invalid confirmation with valid signatures, exact replay,
conflicting replay and closed owners. The native invalid-ciphertext control is
re-signed with the real initiator key so it reaches KEM confirmation.

### Install the Python reference

`pyproject.toml` builds the unpublished `qperiapt-continuity-reference` wheel.
Its import namespace is `qperiapt_continuity_reference`; the generic `peer`
namespace is no longer used. The wheel contains the protocol and explicit
provider loader, without the test issuer, native process driver or private
fixtures. The reference version is `0.0.0`, with CPython 3.14 and the pinned
provider below. Current qualification is for the stated POSIX profiles; the
pure-Python wheel tag does not qualify other operating systems.

From this directory, build in a dedicated virtual environment:

```sh
python3.14 -m venv /absolute/path/to/build-environment
/absolute/path/to/build-environment/bin/python -I -m pip install \
  --no-deps --require-hashes -r build-requirements.txt
/absolute/path/to/build-environment/bin/python -I -m pip wheel \
  --no-index --no-deps --no-build-isolation --wheel-dir /absolute/path/to/dist .
```

In a separate consumer environment, install the fixed provider requirements and
the produced wheel:

```sh
python3.14 -m venv /absolute/path/to/consumer-environment
/absolute/path/to/consumer-environment/bin/python -I -m pip install \
  --no-deps --require-hashes -r requirements.txt
/absolute/path/to/consumer-environment/bin/python -I -m pip install \
  --no-index --no-deps /absolute/path/to/dist/qperiapt_continuity_reference-0.0.0-py3-none-any.whl
```

Select the provider before importing protocol modules:

```python
from pathlib import Path
import sysconfig
from qperiapt_continuity_reference.provider import load_provider

load_provider(Path(sysconfig.get_path("platlib")))
from qperiapt_continuity_reference.registration import Registration
```

`Registration` still requires the separately approved intent and protected local
state described in [REGISTRATION.md](REGISTRATION.md). Installation does not
choose trust roots or turn a received bundle into account authentication.
The qualification consumer runs with `-I -S -B`, a private empty cache prefix,
and explicit installed/provider directories; normal virtual-environment use
does not by itself promise that stronger import-path isolation.

The CI consumer uses `artifact/continuity_independent_python_run.py` to inspect
the wheel, install it with pip into a fresh directory outside the checkout, and
run the existing registered-owner scenario there. Only the test harness and
inventory inputs are copied; current protocol modules must come from the wheel. The
probe records every loaded module and checks isolated import paths. Installed
files, original wheel, native binary and selected source bytes are checked again
after execution. The helper uses the existing Git provenance boundary and
requires an ordinary checkout with a real `.git` directory. Failed states stay
available for diagnosis; a missing or failed installation is never treated as
a successful source-tree run.
The installation runner also requires local and witnessed policy renewal,
full-store expiry/recovery, and sequential policy/credential/roster composition
ending with removal of the real traffic peer. Schema10 retains all four 3/32-device
composition profiles using installed protocol modules and the selected native
counterpart; source-only results cannot satisfy them. See
[POLICY_RENEWAL.md](POLICY_RENEWAL.md) for the retained-history boundary.
It also requires `--directory-cli-public`, a closed set of public artifacts from
the actual reference directory CLI test. The test commits an allocation before
losing its output, recovers the exact original wire, rejects a changed request,
checks each algorithm's reservation before and after cancellation, and issues a
fresh pair. A separate test ledger with the same test signer deliberately issues
a conflicting allocation. `directory_cli_checks.py` verifies the same original
receipt and canonical conflict bytes using the independent Python/OpenSSL
implementation, including bad-signature, service-pin and public-key controls.

The fixture export is enabled only with an absolute, new
`QPERIAPT_DIRECTORY_PUBLIC_OUTPUT` directory. The export uses a file whitelist;
neither the database, signing/wrapping keys nor current policy is exported or
read by the historical verifier. Signed publication variants used to isolate
the two reservation checks are test constructions, admitted by the actual CLI;
they do not claim the honest publication owner reused inventory. Historical
verification authenticates signed statements, not current authorization,
cancellation state or consumption. Cancellation/occupancy results come from the
separately checked CLI execution trace. The workflow's directory CLI is built
from source; installing the Python wheel does not qualify an installed Rust
counterpart or a complete directory-backed session lifecycle.
The archived migration scenario additionally copies the declared old-writer
capture and its manifest, bound to the selected commit. It loads that writer in
a separate namespace, then uses the installed current package to continue the
same journal. Only the known capture has a 32-MiB input allowance; normal
qualification inputs and protocol limits retain their existing bounds.

### Counterpart built from installed archives

The native fixture can also be built outside the checkout from a separately
hash-pinned SDK package report and a freshly packaged current Continuity crate:

```sh
sh artifact/python-run.sh artifact/continuity_independent_package.py \
  --report /absolute/path/to/sdk-rust-package/RUST_SDK_PACKAGE.json \
  --report-sha256 EXPECTED_REPORT_SHA256 \
  --toolchain-root /absolute/path/to/rust-1.98.1-toolchain \
  --output target/independent-installed-new
```

This checks current source against the crate contents, builds and lints the
original counterpart with eight installed SDK crates plus Continuity, and
requires the original external dependencies and complete lockfile unchanged.
Only the counterpart is a workspace member. The output contains the generated
manifest, Cargo graph, binary and `INSTALLED_COUNTERPART.json`. The public
bootstrap importer example is also built and linted from the installed Continuity
crate in the same dependency graph; its executable is `importer`. Both executable
hashes are recorded. A new registry
cache is used by default; `--cargo-home` may explicitly select a cache without
configuration or credentials. Supported hosts are Apple Silicon and Linux x86_64.

Pass `target/independent-installed-new/counterpart` as `--native` to the existing
drivers, including `registration_checks.py`, and pass the sibling `importer` as
`--importer` to `public_input_checks.py`. A successful build report explicitly
has `runtime_qualified: false`; execution receipts must name that binary's hash.
This archive boundary does not establish a deployed issuer, an independently
installed Python distribution, a cross-host network carrier or release admission.

Source qualification uses the SDK packaging provenance check and requires a clean
ordinary checkout with a real `.git` directory. Linked worktrees should be copied
to a clean checkout at the same commit for this entry point.

The independent CI workflow accepts optional `sdk_run_id` and
`sdk_report_sha256` dispatch inputs. Supplying both builds the counterpart from
that same-repository SDK artifact, including the public importer, before running the protocol checks;
the report and crate bytes must still match current SDK sources. Supplying only
one input fails. The default workflow retains direct-source qualification.

## Limits and next integration

The second experiment transfers a confirmed root into independent epoch-zero
traffic and exchanges real application ciphertext with a Rust `DeviceJournal`.
It covers both directions, empty/ordinary/16-KiB plaintext, up to 1-KiB application
AD, reordered delivery, rejected tags/AD, skipped keys, exact outbox replay,
contiguous consumption ACKs and retired IDs. Five Rust journal close/reopen
boundaries retain reply, completed bootstrap, skipped keys, outbox and ACK state.
Traffic runs at trusted time 170 after the prekey advertisement expires at 160;
the credentials, rosters and policy remain valid until 200. An authenticated stale
ACK leaves the current higher floor unchanged. This is interoperability evidence
for the root/traffic schedule, not merely agreement on the public session ID.

`qperiapt_continuity_reference/traffic.py` is explicitly **volatile**: it does not supply commit-before-
release or independent persistence. `traffic_checks.py` contains the separate
experiment driver. Rust enrollment, control framing and durable operations are
separate modules. Private Rust fixture files stay outside the public artifact
directory and are retained, including on failure; only their path is recorded.
No wrapping key or encrypted private image is uploaded. Reopen here is within
the original process; it is not a process-crash or power-loss experiment.

The [independent storage/session implementation](STORAGE.md) now separately
persists waiting bootstrap, confirmed roots, traffic epochs, exact send reservations,
four-flight rekey and consumption. It reopens the original material in fresh OS processes and tests
real process interruption before results are returned. Identity signing keys stay
outside the session journal. `storage_checks.py` covers the file transaction;
`durability_checks.py` covers persisted protocol recovery against the Rust peer.
The separate `rekey_checks.py` lane now computes all four signed rekey flights
with independent KEM, root/confirmation and epoch traffic/ACK derivations. Eight
alternating exchanges interoperate with real Rust journal cutovers, including
asymmetric progress after final, cached control replay and bidirectional traffic.
The computational lane remains volatile. The subsequent `durable_rekey_checks.py`
uses the journal-owned `Session`, an explicit upgrade from `QPREFS01`,
separate directional cutovers, exact control outboxes and the aggregate unconfirmed
send budget. It retains unsettled epochs and resumes after process loss.
`control_checks.py` exercises signed progress requests and one-step control driving
without dummy application traffic. `QPREFS03` adds the retained request; both older
formats remain readable without implicit migration. The new driver requires
explicit upgrade, including when a version-two send or rekey is already pending.
Control calls select one target, replay committed output and distinguish local
confirmation from delivery of the final receipt. The host bounds retries and
continues servicing peer controls. The following outcome-reporting lane adds
`QPREFS04`: an explicit freeze of a closed epoch, an immutable report and the host's
separate durable acknowledgement. Unconfirmed sends then remain `DeliveryUnknown`;
the original acknowledgement floor is preserved. Frozen old operations cannot
release traffic, while new epochs remain usable. Versions one through three stay
readable without implicit migration. Network transport/scheduling and full identity
lifecycle remain required.
No completed exchange count asserts post-compromise security.
The earlier volatile class remains a cryptographic core, not a durable facade.

The next state format, `QPREFS05`, retains independently approved remote same-key
credential renewals and signed peer roster changes for the original established
session. Exact predecessor, retained original lineage, full key, operation, policy and
target checkpoint must match. Committed peer revocation denies cached output,
new traffic and rekey; a later roster cannot revive the observed old generation.
The original transcript, keys, outbox IDs and ciphertexts remain unchanged.
The local owner still needs current authority. Same-account updates require the
separate local account coordinator; this entry cannot bypass that joint workflow.

An already established peer session may have started with an intermediate
credential `C1`. It can adopt a root grant naming `C0, C1 -> C2` when the retained
current credential and roster match that exact predecessor. Peer verification
checks the complete pinned identity and the grant's retained-established
permission; subsequent grants must preserve the first admitted original lineage.
Local installation renewal still requires its exact original credential and
storage owner. `peer_intermediate_checks.py` exercises real C1 bootstrap, a
process kill during G2 adoption, original ciphertext/plaintext recovery, rekey,
and revocation with both local and required-witness stores. Its explicit fixture
clocks are not a real-time expiry or complete same-account lifecycle test.

The `AccountState` model keeps one account roster, up to 256 retained device
generation records, and the root grants that justify same-generation credential
changes. `AccountRequest` serializes the complete local-and-companion collection
and compares requests by signed statement identity. The owning coordinator must
retain the first saved bytes when a semantically identical request is retried. The
local verifier continues to require the exact original installation credential;
verifying a companion grant does not grant a local owner.
`account_state_checks.py` exercises native-signed three- and 32-member changes,
lineage substitution, incomplete collections, root-signed resurrection and
generation rollback, and canonical account/request decoding. Its native example
is a source-built test authority even when the traffic counterpart uses installed
SDK crates. Those model checks establish pure transitions only.

Registered common-account sessions use `QPREFS09`: the unchanged version-five
business image plus one bounded common account and its renewal record.
`stage_account` under a local-only policy and `prepare_account` under a required
witness accept the complete local-and-companion collection. Every changed active
credential must have its root grant; a single-role update cannot silently split
the roster. Both roles derive authority from that one authenticated account.
The first saved request bytes, original signing key, session, reserved sends and
outboxes survive retries and process cuts. See [common-account renewal](SHARED_ACCOUNT.md)
for the conditional formats, recovery and qualification boundaries.
Same-credential shared roster changes use the original registered
[roster coordinator](ROSTER_REFRESH.md), selecting conditional format ten and
its exact witness transition. The generic peer-only owner cannot bypass it.

An independent [joint local credential coordinator](LOCAL_RENEWAL.md) now binds
the original required-witness head transition to the actual root grant. It retains
the exact sealed target and terminal before ACK, permits historical cleanup, and
reopens the same session under its adopted local authority. `QPREFS06` is selected
only for that explicit separate-account transition; separate-account creation and
generic upgrade stay at five. Common-account creation selects nine.

For an original local-only policy, [LocalCredentialRenewal](LOCAL_CREDENTIAL.md)
retains Pending, current local authority, abandonment and a time floor in the
same journal. Conditional `QPREFS08` preserves the original session and outbox
while coordinating expiry and exact-target recovery. It refuses required-witness
contexts and preflights capacity for the completed identity before staging.
Its bounded lifecycle allocation permits renewal of a full original business
store after credential expiry. Version seven remains readable with its original
limits; an already Pending operation completes in that version.

This is not an admitted independent Continuity product implementation.
Policy renewal and retirement, account fanout,
the complete installation/migration
lifecycle, network carriers and installed-package qualification remain required.
`resolution_checks.py` exercises process interruption, exact report recovery,
application accounting and subsequent history collection. `resolution_capacity_checks.py`
uses the direct host API for all 64 retained 16-KiB plaintexts; the bounded test
pipe is not an application report transport. `resolution_disclosure_checks.py`
gives an isolated forge function only one old sending chain. A real Rust peer
consumes two forged old messages and emits an out-of-range ACK; the independent
sender refuses it and retains its genuine outbox. Explicit unknown-outcome
accounting allows the same later rekey offer to proceed. This does not establish
post-compromise confidentiality or undo effects of old forged traffic.

The Rust side is
a separate Cargo consumer of the current source graph. Root transfer into the
volatile experiment is one-use and adds no root-export hook to the Rust SDK.
The synthetic confirmation control changes a test verification key directly;
that context is never passed to the real Rust counterpart.

Python bytes and provider temporaries do not provide the Rust SDK's zeroizing
owner guarantee; dropping references does not prove erasure. Private session state
is sealed in its store; public artifacts omit wrapping keys and private images.
The peer's original policy and local identity snapshot do not implement
concurrent policy replacement. Explicit peer authority changes are now retained
separately from the immutable bootstrap inputs. Local-only stores have no whole-store rollback
protection. Required-witness stores reject a local image that differs from the
live witness, assuming the witness retains its own state independently.
Deployment and the remaining lifecycle still need integration before this lane
can close the independent implementation requirement.

`witness_checks.py` exercises the required profile against an actual Rust
`AnchorStore` and an actual required-witness Rust session journal. Explicit
inactive provisioning exports only an operator-approved genesis; normal peer
requests cannot register it. Fresh challenged queries and authority checks gate
ordinary outputs, and exact signed advancement precedes local publication.
At operational result release, one fresh authority reply checks both the recovered
head and current permission; it replaces a separate Query immediately followed
by the same head check. Historical release still queries the head. Recovery of
the exact pending intent, signed response validation, permission checks and
owner closure on failure remain required. The release controls include a real
signed reply with current permission but a different fenced head.
Three real process cuts cover creation intent, remote advancement and local
publication. Lost replies preserve the original intent, even when an already
committed transition must be reconciled after expiry. Cached output still needs
current authority. Restored client backups and a changed writer fence fail.
The loopback TCP bridge is test orchestration for the signed witness byte carrier;
it is not a separately deployed witness or an application network carrier.

`peer_lifecycle_checks.py` covers local and required-witness owners, an actual
archived version-four writer, two chained remote grants, original traffic/rekey,
process cuts, explicit revocation and refused reappearance. Its independent
operations cross the peer's signed expiry at test times 210 and 310; the native
protocol counterpart retains its fixture time 170. It therefore qualifies this
remote acceptance/recovery path, not the native peer's local enrollment renewal.
`peer_reply_release_checks.py` verifies that a host witness callback committing
revocation cannot release a result under the earlier permission. Both callback
cases have preserved failing pre-fix runs and passing repaired runs.
`local_renewal_checks.py` verifies original joint targets across real process
cuts, lost Commit/Close/ACK replies, two local grants and policy-expired cleanup.
It also preserves the refusal to replace unrelated expired pending work.
`local_credential_checks.py` exercises the separate local-only contract with
29 real process cuts, original reserved sends, expiry floors and combined peer
metadata. `local_credential_capacity_checks.py` checks the full 123-row business
boundary across two renewals after original expiry, original seven-to-eight
continuation and independent metadata/file limits. It preserves messages and
does not perform unknown-outcome cleanup to make room. Physical disk or directory
quota exhaustion still fails explicitly.

The independent [pending-write recovery](PENDING_WRITE_RECOVERY.md) owner prepares
complete public views without replaying an expired ordinary write. Its separate
controller approval and fresh Query confirmation preserve the original sealed
target and leave renewal and traffic authorization separate.

The byte-oriented [public input API](PUBLIC_INPUTS.md) accepts the existing
QPBNDL01 container with separate trust expectations. Original-state reconstruction
uses the retained context digest and current trusted time, without a fixed fixture
admission time or a new operational grant.

The [protected registration owner](REGISTRATION.md) now retains its own identity,
original proof-of-possession request, accepted authority and original child
installation. Borrowed session and recovery owners share that lifetime; the
reference does not require a cleartext test signer file for these operations.

The [local enrollment client](ENROLLMENT_CLIENT.md) coordinates original host
configuration, request export, credential acceptance and reopen through an
installed CLI. Its authorization inputs are supplied by the embedding host;
it introduces no account signup requirement. The same API now borrows the
registered session, rekey, credential renewal and pending recovery under the
client lifetime. Full session CLI integration and the documented pre-publication
first-use recovery boundary remain open.

The [account-root statement verifier and registry](ACCOUNT_ROOT_PROTOCOL.md) independently
reconstructs approved plans and verifies complete signed freezes, retirement
and distinct plan/decision closures. Its installed-wheel tests consume public
native operator outputs and check both signature components and exact target
bindings. `AccountAuthority` now retains application/root mappings, original
approvals, closures and retirement in a separately bound private journal, with
revocable per-application leases and real process-cut recovery checks. New
`EnrollmentClient` associations bind the original registration and child journal
to that registry. Normal opens and outputs require its live lease; restricted
original-parent recovery remains available after preparation. An internal child
journal adoption step now retains the original payload under that live binding,
using the existing exact-target transaction and required witness. Normal reopen
can finish an authenticated retained binding intent; it cannot start adoption.
Installed-wheel checks cover process cuts, preserved ciphertext and pending
rekey contributions, unknown witness results before/after commit, and same-key
renewal after expiry. `EnrollmentClient.begin_root_adoption` now owns existing
parent/child migration through `RootAdoption`, with explicit same-state reopening
and pending-write recovery. It returns a normal client only after the child,
registration and configuration agree. Finishing those records after expiry does
not grant traffic permission. Once preparation suspends the original root,
`RootRecovery.inspect_child` reads its authenticated witnessed head, pending
ordinary/G/R/P targets and retained terminal phases without replay or network
access. Partial parent migration and unknown delivery retain their original
state. The client also borrows active roster maintenance through `roster_refresh`.
`RootRecovery` also retains signed retirement in both original stores before
selecting the successor in the registry. The original encrypted head and pending
work remain unchanged, and normal owners reject the retained root fence.
`activate_successor` admits the exact prepared target through current registry,
device, policy and witness checks, including recovery of interrupted binding.
Until it returns successfully, the recovery owner also owns the target,
migration owner and new client. Closing it from a publication callback closes
the current child before further publication or witness requests. The original
intent remains available for explicit recovery. A successfully returned client
has its own lifetime, while its supplied account registry must remain alive.
It returns the normal client without emitting a peer handshake. The successor
peer fixture then uses this client for authenticated handshake, two-way traffic,
reopening and rekey against the original native journal. The endpoint receives
its approved root through explicit test control, never from session bytes.
`enrollment_session_checks.py --root-successor-cuts` exercises 41 actual
`SIGKILL` boundaries: the eight publication stages in configuration preparation,
child binding, registration binding, configuration readiness and activation,
plus the witness-committed/local-unpublished child boundary. Each fresh worker
uses the installed package and original keys. Recovery resumes that same target,
preserves unconsumed staged files and completes the native peer exchange and
rekey. The native peer and witness remain running during these independent-owner
cuts. Historical proofs alone do not grant traffic permission.
`--root-successor-cancellation` checks closure of the recovery owner and registry
at six activation boundaries each, then resumes the same target and completes
peer traffic. It also checks that closing the recovery owner after successful
return leaves the returned client usable.

`--root-successor-process-restart peer` separately kills and reaps the whole
native process at ten boundaries: approved target, reply, final, activation,
received message, retained outbox, consumed acknowledgement, rekey response,
rekey receipt and epoch-one receive. Each new process opens the original witness
and device signing owners, sealed reusable prekey reservation and journal. The
controller replays the exact authenticated handshake to recover its session
selection; it never provisions another device, journal or witness. Current
successor approval is rechecked against the original signed retirement, and
the old operational controller and changed target are refused after restart.
The reference controller writes and synchronizes the complete approval and
original-journal pointer in a staging directory, publishes that directory with
one rename, then changes its in-memory peer. An unpublished staging directory
does not authorize traffic. After an interruption before publication, resume
mode waits for the explicit controller to resend the signed request and checks
the original witness retirement again. The same ordering applies to a later
successor and to the metadata-only record for a never-activated predecessor.
An existing final directory with missing or changed files is refused, including
partial records produced by older experimental controllers. These public
records do not replace the original private journal or its exclusive owner.
If publication returns an error, this single-fixture test process reports the
failure and exits before accepting another control request. Resume mode then
uses the original storage and exact approved request; an I/O error after rename
must not leave the running controller serving its previous in-memory peer.
The continuation CI cohort also runs twenty publication SIGKILL cases and
twenty returned-I/O-error cases, pairing at most two processes at a time. The
instrumenter builds a separate source copy and retains both native binaries;
the recovery driver reopens the original stores with the unmodified binary.
The five boundaries cover staging creation, the first written file, the complete
staging directory, rename and parent-directory synchronization for first, later
and never-activated-root histories. Source and binary identities are checked
before and after each case. The build/readback tools require the ordinary Git
checkout used by CI, and a successful fault build alone is not runtime evidence.
The `peer-credential`, `peer-before` and `peer-after` variants cover retained
credential preparation and unknown sends on either side of witness dispatch.
The latter two restart the witness before recovering the original send intent.
PID, terminal `SIGKILL` status, original-file hashes and public protocol frames
are retained in `PROCESS_RESTARTS.json` and `NATIVE.json`. These fixed-clock,
POSIX process tests do not establish power-loss, mobile or PCS guarantees;
cross-platform qualification remains separate. For a closed bound replacement,
`RootRecovery.transition_after_noncommit` consumes the original recovery owner
and moves its existing fences to a fresh independently approved plan with the
same signed freeze. After an uncertain result, use `RootRecovery.resume_transition`
with the original storage, keys and exact approval/proofs. Neither method revives
old-root traffic or resets a missing fence. The `replan-plan` and `replan-decision`
scenarios check both closure types through successor traffic; their process-cut
groups exercise the registry and parent/child publication boundaries.

When another independently approved result has already committed, construct
`CommittedAdoption` from the exact original plan, approved winner and both signed
outcomes, then use `adopt_committed_winner` or `resume_adoption`. The original
installation retains its state and records an explicit adoption intent instead
of inventing a local preparation. Existing registry images remain canonical
`QPRFAA01`; adoption records use `QPRFAA02`, which older readers reject. The
`--root-winner-adoption` scenarios exercise bound/unbound originals, fresh or
previously inactive targets, cross-application refusal and current-permission
expiry. `--root-winner-cuts` and `--root-winner-cancellation` exercise original-state
recovery and resumed native traffic at the publication boundaries. Power-loss,
physical-device and arbitrary thread-schedule qualification remain separate.
The `bound-reuse-continue` adoption mode then replaces that selected root again;
`bound-reuse-restart` also restarts the native peer across both selected roots.
Old adoption history must preserve the newer selection and cannot restore permission.
If a committed successor expires before establishing its first session,
`RootRecovery.retire_unactivated_successor` retains a restricted retirement
association for a separately approved next root. It keeps the original stores
and requires actual witness retirement; it does not renew or activate expired
credentials. See the account-root protocol for exact retry and remaining gates.

`--root-successor peer-root-revocation` then prepares a separately approved third
root after actual successor traffic and rekey. The cached session and a fresh
process both refuse further traffic under the suspended registry mapping, while
restricted recovery still reads the same child. Original files and witness
request counts stay unchanged after suspension. Historical first-root retirement
replay cannot restore permission or replace the later preparation. This is a
local registry preparation check, not a third-root witness commit or a global
revocation result.

`--root-successor peer-root-replacement` continues the same chain through native
witness retirement and admission of the original prepared third-root client.
The native controller requires the exact committed predecessor, and historical
first-root replies cannot replace the current third-root selection. The
`--root-successor-later-cuts` groups exercise 28 actual process boundaries in the
second-root registry and retirement fences, preserving original keys and business
state. Reserved staged fences must be published byte-for-byte; they are distinct
from unrelated orphan files. `--root-successor peer-root-continuation` additionally
uses the third root for actual mutual handshake, two-way messages, replay,
consumption, reopening and rekey against that same native journal. Old controllers
and a second-root ciphertext are refused while third-root traffic remains usable.
Original native persisted keys and prior approvals stay unchanged; this fixture
keeps its prekey in memory. The opt-in
`--root-successor-process-restart peer-root-continuation` variant persists the
original sealed prekey and executes ten actual native process restarts for each
successive peer. It advances past the predecessor advertisement's expiry before
preparing the third root, requires fresh handshake materials, and refuses old
controllers after restarting. Power loss, general expiry recovery and PCS
remain separate qualifications.

`enrollment_extension_session.py` exercises the explicit preinstallation extension
through the installed client and a native durable peer. The original credential
and policy expire at fixture time160. The native issuer retains those signed
materials, extends the same device key, and issues a separately pinned policy.
Both peers bootstrap at210, exchange bidirectional traffic and complete one PQ
rekey at220, then reopen their owners and recover the original ciphertext. Local
and required-witness profiles refuse expired original policy, retargeting after
child preparation, and use after the extended credential expires. The witness
profile uses the real native store through a bounded loopback bridge.

This separate fixture requires `--registration --registration-extension` and
cannot be mixed with the older local/peer renewal fixtures. Its bootstrap,
traffic and initial witness clocks are explicit; the existing fixtures keep
their original clock contracts. Installed Python receipt schema2 requires this
additional workload and its selected binary/module identities. It does not prove
real account approval, a deployed TLS channel, physical power-loss recovery or
credential renewal of the newly extended bilateral session.

The byte contract is [WIRE_V1](../../docs/continuity/WIRE_V1.md), with the
[bootstrap KDF graph](../continuity-identity-candidate/BOOTSTRAP.md#three-flights)
and SDK purpose schedule in `crates/q-periapt-sdk/src/purpose.rs`. Provider API
references are the official [ML-KEM](https://cryptography.io/en/48.0.0/hazmat/primitives/asymmetric/mlkem/)
and [ML-DSA](https://cryptography.io/en/48.0.0/hazmat/primitives/asymmetric/mldsa/)
documentation; the executed package and OpenSSL versions are recorded per run.

`policy_renewal_proof_checks.py` verifies the native two-root policy-only approval
format independently. Its native producer derives both request scopes from the
same original enrollment and journal, including a second policy adoption and a
separate case following real same-key credential renewal. Both root signatures,
the exact original owner, current credential/roster, previous authorization and
unchanged policy profile are mandatory. Historical signature verification grants
no current permission. This is a proof interoperability prerequisite: independent
durable policy adoption, witness admission and post-expiry session continuation
are not provided by this verifier alone. The separate
[original policy coordinator](POLICY_RENEWAL.md) connects the proof and record to
the registered original journal and existing session. Its required-witness path
uses a separately typed P transaction and fresh policy admission before work and
output. Its full-store driver covers expired targets and original-state recovery;
installed witness qualification and G/R composition after P retain their own
acceptance boundaries.

`policy_record_checks.py` reuses those exact native inputs to check bounded
Pending/Committed/ExpiredUncommitted metadata and sequential predecessor binding.
It preserves the first signatures on retries, refuses another pending operation,
and keeps historical completion separate from current permission. This record
model is also used by the local coordinator; the record tests themselves do not
establish durable or session behavior.

## Explicit one-time publication selection

`one_time_publication.OneTimePublication.decode` accepts only the separate
`qperiapt-native-one-time-publication/1` advertisement: exactly four roles
(signed classical, one-time classical, last-resort PQ and one-time PQ), with
the producer's fixed plan order and canonical Merkle proof order kept distinct.
Its `verify_selection` requires independently supplied policy pins, policy
materials, responder device pin, directory checkpoint, current time, a required
immutable `OneTimePublicationExpectation(journal, publication, validity)` and explicit
`required_quality=1`. The expectation must come from the caller's retained original
operation and plan; no missing value defaults to the received advertisement.
Exact journal, operation ID and plan interval are checked before returning a result.
It verifies current signatures, scope, all four leaves,
policy permission, generated-plan intent and inventory identities, and exact-public-key
separation before deriving the existing
492-byte OneTimeBoth selection and its digest.

This is a public read-only result. It does not issue or validate a directory lease,
consume a key, create a bootstrap Context or enter an EnrollmentClient. The
existing Publication, BootstrapBundle and retained QPREGIN1 input admission remain
reusable-both; their closed schemas have not been widened. Policy verification
defaults also retain reusable-both selection unless a caller explicitly supplies
another quality. Witness-required policy still needs its independently pinned
witness; selection verification performs no witness or storage operation.

The standalone `one_time_publication_checks.py` uses the pinned OpenSSL provider
to generate real account/device/policy signatures and fresh ML-KEM/X25519 public
keys. Controls include signed public-key aliases, signed noncanonical Merkle order,
policy prohibition, explicit-mode downgrade, wrong journal/operation/plan expectations,
scope/expiry and malformed inputs.
The fixture follows the producer's exact SDK/policy/scope/plan intent and generated
inventory identities. Its independently retained expectations are created before
public fixture production or decoding and supply both verifier calls. The real Rust
counterpart reads that same bounded public fixture through `--verify-one-time-publication`, calls the public plan verifier,
and must return the identical 492-byte selection and 32-byte digest. The existing
independent interoperability workflow invokes this source check on both native
architectures; the installed-wheel runner repeats it outside the checkout and
verifies its module and counterpart hashes. Only public fixtures and results are
retained. These checks qualify publication selection, not one-time session traffic.

## Independent historical directory lease evidence

`directory_lease.DirectoryPin` takes a separately provisioned service identity
and exact ML-DSA-65/P-256 verification key. Its
`verify_historical_lease` verifies purpose-39 signatures over the complete
`QPDLSE01` statement, exact 5,173-byte envelope, typed scope and SDK fields,
finite half-open interval, suite, full public keys and algorithm-tagged
fingerprints. Historical verification deliberately takes no current time,
device handle or live policy: expired authorization does not erase a signed
service assertion. It grants no current use and proves neither requester
authentication nor durable allocation or receiver consumption.

`DirectoryLeaseConflict.verify(pin, first, second)` verifies both receipts under
one independent service pin. The immutable allocation bodies must differ, and
at least one algorithm must have the same fingerprint and the same complete
one-time public-key bytes. Exact replay and randomized signatures of the same
body are not conflicts. Different epochs, manifests or disjoint validity
windows do not make an assigned key reusable. Fingerprints cover exact public
bytes; this reader does not claim primitive-key validation or mathematical
equivalence detection.

The pair verifier orders receipts by statement digest and then full signed
bytes. The archival `QPDLCF01` decoder requires that exact canonical order and
the exact 10,354-byte container; reversed, duplicate, trailing or malformed
containers are refused.

The source and installed-wheel workflows run `directory_lease_checks.py` after
the explicit one-time publication check. The existing Rust counterpart imports
that same Python-signed publication, verifies its independently retained inputs
and produces three public Rust-signed leases: two deliberately conflicting
assignments and a randomized re-signing of the first body. The independent
OpenSSL reader checks those signatures, compares the statement digest and
canonical conflict bytes, and exercises its own real-signature positive and
negative controls. The deliberately equivocating fixture is not a production
allocator. Additional controls cover single-algorithm reuse, different keys and
services, signature-purpose separation, corrupted signatures, typed fields,
key fingerprints and historical intervals. Only public fixtures and results
are exported; private signing owners remain in their processes. These checks
qualify historical receipt and conflict interoperability, not a directory
service lifecycle or one-time session traffic.
