from pathlib import Path
import sys,json
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-pending-recovery-public'
mode,prefix=sys.argv[1:3]
paths=sorted((root/'research/continuity-identity-candidate/src').rglob('*.rs'))
paths += [root/'research/continuity-identity-candidate/Cargo.toml', root/'research/continuity-identity-candidate/Cargo.lock']
inputs={str(p.relative_to(root)):sdk.snapshot(p).sha256 for p in paths}
sdk.write_json(stage/(prefix+'-inputs.json'),inputs)
for name in list(json.loads((stage/'INPUTS_03.json').read_text()))+['research/continuity-identity-candidate/src/enrollment/witness_pending_write_policy_tests.rs','research/continuity-identity-candidate/src/enrollment/witness_independent_policy_operational_tests.rs']:sdk.copy(root/name,stage/(prefix+'-source')/name)
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';tool=Path(env['RUSTC']).parent
args=[str(tool/'cargo')]
if mode=='wasm':
 env['CC_wasm32_unknown_unknown']='/opt/homebrew/opt/llvm/bin/clang'
 args+=['clippy','--locked','--offline','-p','q-periapt-sdk-wasm','--features','browser-continuity','--lib','--target','wasm32-unknown-unknown','--target-dir',str(root/'target/continuity-browser-fanout/wasm-target'),'-j','2','--','-D','warnings']
else:
 args += ['clippy' if mode=='lint' else 'test','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2']
 if mode=='lint':args+=['--all-targets','--','-D','warnings']
 else:args+=['--lib',sys.argv[3],'--','--nocapture']
try:sdk.command(args,stage/prefix,root,environment=env)
except ValueError:
 result=json.loads((stage/(prefix+'.json')).read_text())
 err=(stage/(prefix+'.stderr')).read_text()
 sdk.require(mode=='red' and result['returncode']==101 and (sys.argv[4] if len(sys.argv)>4 else 'generic original intent remains inspectable with local staged G/T: Suspended') in err,'unexpected failure')
 print('Expected original-state counterexample reproduced')
else:sdk.require(mode!='red','counterexample unexpectedly passed');print(prefix+' passed')
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
