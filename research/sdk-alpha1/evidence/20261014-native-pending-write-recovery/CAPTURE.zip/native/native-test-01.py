from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-pending-recovery-public';inputs=json.loads((stage/'INPUTS_03.json').read_text());env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';tool=Path(env['RUSTC']).parent
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
output=sdk.command([str(tool/'cargo'),'test','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features','--lib','public_pending_write_recovery','--target-dir',str(root/'target/continuity-browser-fanout/native-target'),'-j','2','--','--nocapture'],stage/'native-test-01',root,environment=env).decode()
sdk.require(re.search(r'test result: ok. 1 passed; 0 failed;',output),'public test missing')
sdk.require((stage/'native-test-01.stderr').read_text().count('PUBLIC_PENDING_RECOVERY ')==4,'four cohorts missing')
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
sdk.write_json(stage/'NATIVE_01.json',{'completed':True,'cohorts':4,'inputs':inputs,'public_api':True,'release_claim_eligible':False})
print('Four public native recovery/G-T/closure cohorts passed')
