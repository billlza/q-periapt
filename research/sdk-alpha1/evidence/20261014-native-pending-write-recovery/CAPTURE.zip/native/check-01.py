from pathlib import Path
import sys,json
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-pending-recovery-public';env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';tool=Path(env['RUSTC']).parent;mode=sys.argv[1];inputs=json.loads((stage/'INPUTS_01.json').read_text())
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
args=[str(tool/'cargo'),'clippy','--locked','--offline','--manifest-path','research/continuity-identity-candidate/Cargo.toml','--all-features']
if mode=='native':args+=['--all-targets','--target-dir',str(root/'target/continuity-browser-fanout/native-target')]
elif mode=='wasm':args+=['--lib','--target','wasm32-unknown-unknown','--target-dir',str(root/'target/continuity-browser-fanout/wasm-target')]
else:raise ValueError(mode)
args+=['-j','2','--','-D','warnings']
sdk.command(args,stage/(mode+'-01'),root,environment=env)
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
print(mode+' strict Clippy passed')
