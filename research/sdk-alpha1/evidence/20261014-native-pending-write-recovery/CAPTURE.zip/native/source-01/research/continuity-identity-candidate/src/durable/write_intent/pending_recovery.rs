// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Inspect the original MAC-bound generic intent without replay or mutation.
use super::*;
use crate::durable::pending_recovery::{
    PendingRecoveryLineage, PendingRecoverySnapshot, PendingWriteRecoveryView,
};

impl DeviceJournal {
    pub(crate) fn pending_write_recovery_in_database(
        db: &Database,
        key: &JournalKey,
        expected: JournalIdentity,
        lineage: &PendingRecoveryLineage<'_>,
        archives: &mut crate::SessionArchiveStore,
    ) -> Result<PendingRecoverySnapshot, DurableError> {
        let owner = bootstrap::storage_owner(lineage.scope.original_device);
        let (image, pending) = load_pending_snapshot(db, key, owner, SnapshotAdmission::Ordinary)?;
        if image.id != *expected.as_bytes() {
            return Err(DurableError::Conflict);
        }
        let pending = match pending {
            Some(PendingIntent::Write(pending)) => pending,
            Some(PendingIntent::Cancellation(_)) => return Err(DurableError::Suspended),
            None => return Err(DurableError::Absent),
        };
        if pending.binding.is_some() {
            return Err(DurableError::Suspended);
        }
        let target = pending.authenticated_target(key, owner)?;
        let source_scope = lineage.inspect(&image)?;
        let target_scope = lineage.inspect(&target)?;
        if source_scope.journal != target_scope.journal
            || source_scope.original_owner != target_scope.original_owner
            || source_scope.current_device.authority_binding()
                != target_scope.current_device.authority_binding()
            || source_scope.current_policy != target_scope.current_policy
            || source_scope.current_policy_authorization
                != target_scope.current_policy_authorization
        {
            return Err(DurableError::Conflict);
        }
        let Protection::Required {
            witness, policy, ..
        } = image.protection
        else {
            return Err(DurableError::AnchorRequired);
        };
        let mut subject = image.id.to_vec();
        subject.extend_from_slice(&image.owner);
        subject.extend_from_slice(&policy);
        let scope = crate::anchor::PendingWriteRecoveryScope {
            witness,
            subject: crate::AnchorSubject::from_trusted_state(&subject)?,
            expected: image.protection.head(image.revision, image.digest)?,
            target: target.protection.head(target.revision, target.digest)?,
            authority: source_scope.current_device.authority_binding(),
            policy: source_scope.current_policy.digest(),
            policy_authorization: source_scope.current_policy_authorization,
            intent: digest(
                b"Q-PERIAPT-CONTINUITY-PENDING-WRITE-INTENT/v1",
                &pending.wire,
            ),
        };
        let source = pending_view(&image, key, archives)?;
        let target = pending_view(&target, key, archives)?;
        Ok(PendingRecoverySnapshot {
            scope,
            source,
            target,
        })
    }
}
fn pending_view(
    image: &Image,
    key: &JournalKey,
    archives: &mut crate::SessionArchiveStore,
) -> Result<PendingWriteRecoveryView, DurableError> {
    Ok(PendingWriteRecoveryView {
        head: image.protection.head(image.revision, image.digest)?,
        local_account: image.local_account,
        next_fanout_ordinal: image.next_fanout,
        records: super::super::retired_report::project_records(image, key, archives)?,
    })
}
