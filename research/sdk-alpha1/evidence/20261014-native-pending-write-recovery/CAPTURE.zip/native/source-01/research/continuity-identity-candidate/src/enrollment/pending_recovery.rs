// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Read-only original enrollment, installation, archive and pending-journal scope.
use super::*;
use crate::{
    DeviceJournal, HistoricalSessionPolicy, PendingWriteRecoveryRequest,
    RetainedInstallationAuthority, SessionArchiveStore,
};

#[cfg_attr(
    not(all(target_arch = "wasm32", target_os = "unknown")),
    maybe_async::must_be_sync
)]
impl DeviceEnrollment {
    /// Prepare complete metadata and the original device's historical signature
    /// for independent approval of this exact retained ordinary write. This does
    /// not replay, cancel, replace or reserve any journal state and creates no
    /// Runtime. Missing state is refused; it is not proof of prior completion.
    ///
    /// The independently configured witness must remain the original one. Pending
    /// G/T/P/R coordination, root replacement and permanent retirement use their
    /// own flows. The operator must approve the intended effect independently of
    /// this old-device signature and durably retain all original request inputs.
    /// Use existing reconciliation/renewal after the control-plane completion.
    pub async fn pending_write_recovery_request(
        &mut self,
        original_policy: &HistoricalSessionPolicy,
        pin: &AnchorPin,
    ) -> Result<PendingWriteRecoveryRequest, DurableError> {
        let result = self
            .pending_write_recovery_request_attempt(original_policy, pin)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn pending_write_recovery_request_attempt(
        &mut self,
        original_policy: &HistoricalSessionPolicy,
        pin: &AnchorPin,
    ) -> Result<PendingWriteRecoveryRequest, DurableError> {
        let image = self.renewal_request_image(original_policy)?;
        let Phase::Accepted { admission, .. } = &image.phase else {
            return Err(DurableError::Corrupt);
        };
        let original = self.original_device_metadata(&image)?;
        if original_policy.anchor_requirement().binding() != Some(pin.binding())
            || pin.public_key().shares_component(&original.authority_key)
            || pin.public_key().shares_component(&original.key)
        {
            return Err(DurableError::Conflict);
        }
        original_policy.check_external_signer(pin.public_key())?;
        let current = self.historical_device_metadata(
            &admission.certificate,
            &admission.roster,
            admission.checkpoint,
        )?;
        let completed = self.completed_policy_approval(&image)?;
        let joint = image
            .renewal
            .as_ref()
            .and_then(LocalRenewal::policy_predecessor)
            .map(|p| self.retained_policy(p))
            .transpose()?;
        let authority =
            RetainedInstallationAuthority::active_installation(&original, original_policy);
        let lineage = crate::durable::PendingRecoveryLineage {
            scope: crate::installation::PolicyScope {
                authority: &authority,
                original_policy,
                original_device: &original,
            },
            current: &current,
            completed: completed.as_ref(),
            joint: joint.as_ref(),
            witnessed_completion: image
                .renewal
                .as_ref()
                .filter(|r| r.witnessed())
                .and_then(|r| r.completed.as_ref()),
        };
        let _installation = self
            .witness_lease(&original, original_policy, admission.journal)
            .await?;
        let mut archives = SessionArchiveStore::open_with_storage(
            self.storage.clone(),
            self.paths.installation.files()[2],
            admission.journal,
        )
        .await?;
        let journal = self
            .storage
            .open_database(self.paths.installation.files()[1])
            .await?;
        let key = self.key().await?;
        let snapshot = DeviceJournal::pending_write_recovery_in_database(
            &journal,
            &key,
            admission.journal,
            &lineage,
            &mut archives,
        )?;
        let signer = self.signer(image.identity, false).await?;
        if signer.public_key()? != original.key {
            return Err(DurableError::Conflict);
        }
        snapshot.sign(&signer)
    }
}
