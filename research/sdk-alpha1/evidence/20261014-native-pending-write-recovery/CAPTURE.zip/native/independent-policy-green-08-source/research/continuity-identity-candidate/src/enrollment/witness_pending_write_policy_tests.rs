// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Ordinary pending recovery must retain the original independent P completion.
use super::super::super::recovery_renewal::{
    pending_write_recovery::{confirm, retain},
    session,
};
use super::*;
use crate::AnchorPendingWriteRecoveryProposal;

#[test]
fn public_pending_write_recovery_preserves_independent_policy_completion() {
    for expired in [false, true] {
        for applied in [false, true] {
            let (f, id) = session(fixture_with_policy_expiry(Some(160)));
            let a = approved_at(&f, &f.c.policy, 2, if expired { 159 } else { 220 }, 155);
            let p = prepared_at(&f, &a, &f.c.policy, 155);
            applied_at(&f, &a, p, 155);
            activate(&f, &a.target, 155)
                .expect("actual original P active")
                .close();
            let mut cleanup = open(&f.c)
                .recover_session(
                    id,
                    f.c.policy.historical(),
                    Some((
                        f.pin.clone(),
                        Box::new(f.carrier.clone()),
                        Duration::from_secs(3),
                    )),
                )
                .expect("historical cleanup");
            *f.carrier.cut.lock().expect("cut") = Some((2, applied));
            assert!(matches!(
                cleanup.session().expect("session").begin(),
                Err(DurableError::Anchor(_))
            ));
            cleanup.close();
            f.carrier.clock.store(170, Ordering::SeqCst);
            f.c.policy.close();
            a.target.close();
            let before = journal(&f);
            let mut owner = open(&f.c);
            let pending = owner
                .pending_write_recovery_request(f.c.policy.historical(), &f.pin)
                .expect("authenticated original independent P completion remains inspectable");
            owner.close();
            assert_eq!(journal(&f), before);
            assert_eq!(
                pending.proposal().expected_policy_digest(),
                a.target.checkpoint().digest()
            );
            assert_eq!(
                pending.proposal().expected_policy_authorization(),
                Some(a.proof.statement_digest())
            );
            let dir = f.c.paths.wrapping.parent().expect("host directory");
            let approved = AnchorPendingWriteRecoveryProposal::from_trusted_state(&retain(
                dir,
                "approved-proposal",
                &pending.proposal().to_bytes(),
            ))
            .expect("exact proposal");
            let metadata = retain(dir, "approved-metadata", pending.metadata());
            let signed = retain(dir, "original-request", pending.signed_request());
            f.carrier
                .store
                .lock()
                .expect("independent controller")
                .complete_pending_write_recovery(&approved, &signed, &metadata, 170)
                .expect("exact expired C completion with retained P");
            for _ in 0..2 {
                assert_eq!(
                    confirm(&f, &approved, &metadata).expect("original target confirmed"),
                    approved.target_head()
                );
            }
            assert!(journal(&f).1.is_none());
            let mut owner = open(&f.c);
            let client = owner
                .credential_renewal_request_anchor_client(
                    f.c.policy.historical(),
                    f.pin.clone(),
                    Box::new(f.carrier.clone()),
                    Duration::from_secs(3),
                )
                .expect("historical client");
            let next = owner
                .witnessed_credential_renewal_request(
                    crate::CredentialRenewalId::generate().expect("next G"),
                    f.c.policy.historical(),
                    client,
                )
                .expect("next request preserves actual P");
            assert_eq!(next.current_policy(), a.target.checkpoint());
            assert_eq!(
                next.current_policy_authorization(),
                Some(a.proof.statement_digest())
            );
            owner.close();
            eprintln!("PUBLIC_PENDING_INDEPENDENT_POLICY policy_expired={expired} originally_applied={applied} historical_completion_retained=true original_target_confirmed=true");
        }
    }
}
