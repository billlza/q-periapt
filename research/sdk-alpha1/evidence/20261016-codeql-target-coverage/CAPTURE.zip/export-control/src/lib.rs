#[unsafe(export_name = concat!("analysis_", "attribute_emit"))]
pub fn emit(input: &str) -> String {
    format!("bound:{input}")
}
