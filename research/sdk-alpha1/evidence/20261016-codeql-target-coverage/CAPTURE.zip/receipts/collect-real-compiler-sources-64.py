"""Exercise production source collection against current Cargo JSON artifacts."""
from pathlib import Path
import json
import os
import re
import time
from bounded_process import capture_output
from codeql_compiler_sources import collect_compiled_sources
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent
source=stage/'source-14'
toolchain=json.loads((stage/'WASM_TOOLCHAIN_29.json').read_text())
inputs=json.loads((stage/'REPOSITORY_EXTRACTED_24.json').read_text())['tracked_rust_sources']
sdk.require(all(sdk.snapshot(source/path).sha256==digest for path,digest in inputs.items()),'source bytes changed')
results={}
for label,cwd,build,home,private,args in [
    ('native-root',source,'canonical-build-23',False,False,['--workspace','--all-targets','--features','q-periapt-sdk/sealed-operations,q-periapt-cli/policy-store-migration']),
    ('native-engine',source/'research/continuity-identity-candidate','engine-native-check-53',True,True,['--all-targets','--all-features']),
    ('wasm-sdk',source,'wasm-package-check-31',True,False,['-p','q-periapt-sdk-wasm','--target','wasm32-unknown-unknown','--features','browser-continuity']),
    ('wasm-legacy',source,'legacy-wasm-test-check-55',True,True,['-p','q-periapt-wasm','--target','wasm32-unknown-unknown','--tests','--all-features']),
]:
    environment=dict(os.environ,RUSTUP_TOOLCHAIN='1.98.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(stage/build),RUSTFLAGS='-D warnings')
    if home:environment['RUSTUP_HOME']=toolchain['rustup_directory']
    if private:environment['CARGO_HOME']=str(stage/'cargo-home-42')
    if label.startswith('wasm'):environment['CC_wasm32_unknown_unknown']=toolchain['clang']
    argv=['cargo','+1.98.1','check',*args,'--locked','--offline','--message-format=json-render-diagnostics']
    os.chdir(cwd)
    started=time.monotonic()
    result=capture_output(argv,timeout_seconds=900,maximum_stdout_bytes=32*1024**2,maximum_stderr_bytes=8*1024**2,environment=environment)
    for stream in ('stdout','stderr'):
        with (stage/(label+'-compiler-64.'+stream)).open('xb') as output:output.write(getattr(result,stream))
    sdk.write_json(stage/(label+'-compiler-64.json'),{'argv':argv,'cwd':str(cwd),'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started})
    sdk.require(result.returncode==0 and re.search(rb'(?im)^\s*(?:warning|error|fatal)\b',result.stderr) is None,'actual compile failed: '+label)
    paths=collect_compiled_sources(source,cwd,result.stdout,inputs)
    results[label]={'compiled_sources':paths,'cargo_stdout_sha256':sdk.snapshot(stage/(label+'-compiler-64.stdout')).sha256}
    sdk.write_json(stage/(label+'-sources-64.json'),results[label])
    print(label+' compiler-bound sources='+str(len(paths)),flush=True)
sdk.write_json(stage/'COMPILER_SOURCES_COLLECTED_64.json',{'completed':True,'source_commit':'6c13c486e9aa3a1ac852f2127fc4cbb30c5e63d5','profiles':results,'runtime_cohorts_executed':False})
