"""Validate the checker with real compiler profiles and real CodeQL censuses."""
from pathlib import Path
import dataclasses
import json
from codeql_target_coverage import MacroProfile, parse_macro_calls, validate_macro_profiles
from codeql_rust_quality import CodeQLRustQualityError
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
query=json.loads((stage/'TARGET_CENSUS_QUERIED_63.json').read_text())
sdk.require(query['completed'] and sdk.snapshot(root/'artifact/codeql-rust-quality/MacroCalls.ql').sha256==query['query_sha256'],'census query changed')
compiled=json.loads((stage/'COMPILER_SOURCES_COLLECTED_64.json').read_text())
sdk.require(compiled['completed'],'compiler collection incomplete')
source=json.loads((stage/'REPOSITORY_EXTRACTED_24.json').read_text())['tracked_rust_sources']
profiles=[]
for target,names,metric_file in [('native',('native-root','native-engine'),'repository-Metrics-25.json'),('wasm',('wasm-sdk','wasm-legacy'),'wasm-Metrics-51.json')]:
    active=set().union(*(compiled['profiles'][name]['compiled_sources'] for name in names))
    calls=parse_macro_calls(json.loads((stage/(target+'-census-63.json')).read_text())['#select']['tuples'])
    metrics=dict(json.loads((stage/metric_file).read_text())['#select']['tuples'])
    profiles.append(MacroProfile(target,source,frozenset(active),calls,metrics['source_macro_calls'],metrics['unresolved_source_macro_calls']))
try:
    validate_macro_profiles(profiles)
except CodeQLRustQualityError as error:
    expected_failure=str(error)
else:
    raise ValueError('Mac/WASM profiles unexpectedly qualified the Linux-only source')
sdk.require('has 2 failure(s)' in expected_failure and 'policy_store_upgrade/tests.rs' in expected_failure,'unexpected remaining coverage failure')

fixture=json.loads((stage/'ATTRIBUTE_PROBE_CERTIFIED_59.json').read_text())
sdk.require(fixture['completed'],'compiler export and data-flow control missing')
fixture_source={path:digest for path,digest in fixture['source'].items() if path.endswith('.rs')}
controls=[]
for target in ('native','wasm'):
    calls=parse_macro_calls(json.loads((stage/('control-'+target+'-census-63.json')).read_text())['#select']['tuples'])
    controls.append(MacroProfile(target,fixture_source,frozenset(fixture_source),calls,3,1))
control_results=validate_macro_profiles(controls)
sdk.require(all(result=={'expanded':2,'compiler_export_metadata':1,'inactive_with_compiled_peer':0} for result in control_results.values()),'real export control was misclassified')
changed=list(controls[0].calls)
index=next(index for index,call in enumerate(changed) if call.expanded and call.context=='code')
changed[index]=dataclasses.replace(changed[index],expanded=False)
negative=dataclasses.replace(controls[0],calls=tuple(changed),unresolved_macro_count=2)
try:
    validate_macro_profiles([negative,controls[1]])
except CodeQLRustQualityError as error:
    negative_failure=str(error)
else:
    raise ValueError('peer success masked an active macro failure')
sdk.require('active macro has no expansion' in negative_failure,'negative control failed at wrong boundary')
sdk.write_json(stage/'TARGET_VALIDATOR_VERIFIED_65.json',{'completed':True,'real_compiler_and_query_data_used':True,'query_sha256':query['query_sha256'],'validator_sha256':sdk.snapshot(root/'artifact/codeql_target_coverage.py').sha256,'compiler_collector_sha256':sdk.snapshot(root/'artifact/codeql_compiler_sources.py').sha256,'compiled_sources':{p.target:len(p.compiled_sources) for p in profiles},'repository_mac_wasm_result':'rejected','repository_rejection':expected_failure,'real_attribute_control_results':control_results,'active_failure_negative_control':negative_failure,'linux_profile_still_required':True,'production_CI_changed':False,'full_suite_qualified':False})
print(json.dumps({'repository_rejection':expected_failure,'real_attribute_control':control_results,'active_failure_negative_control_rejected':True}),flush=True)
