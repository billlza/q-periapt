"""Run the proposed production census over real repository and control databases."""
from pathlib import Path
import json
import re
import time
from bounded_process import capture_output
import rust_sdk_profile as sdk

root=Path.cwd()
stage=Path(__file__).resolve().parent
repository=stage/'target-census-repository-63'
pack=repository/'probes'
pack.mkdir(parents=True)
for name in ('qlpack.yml','codeql-pack.lock.yml'):
    (pack/name).write_bytes((stage/'target-query-repository-32/probes'/name).read_bytes())
query=sdk.snapshot(root/'artifact/codeql-rust-quality/MacroCalls.ql')
(pack/'MacroCalls.ql').write_bytes(query.data)
for label,args in [('init',['init','-b','lza/target-macro-census']),('add',['add','--','probes']),('commit',['commit','-m','Validate target-specific macro coverage query'])]:
    sdk.command(['git','-C',str(repository),*args],stage/(label+'-census-63'),root)
cli=str(stage/'tools-03/codeql/codeql')
def run(label,args):
    argv=[cli,*args,'--common-caches='+str(stage/'cache-07')]
    started=time.monotonic()
    result=capture_output(argv,timeout_seconds=600,maximum_stdout_bytes=8*1024**2,maximum_stderr_bytes=8*1024**2)
    for stream in ('stdout','stderr'):
        with (stage/(label+'.'+stream)).open('xb') as output:output.write(getattr(result,stream))
    sdk.write_json(stage/(label+'.json'),{'argv':argv,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started})
    sdk.require(result.returncode==0 and re.search(rb'(?im)^\s*(?:warning|error|fatal)\b',result.stderr) is None,'census query failed: '+label)
    print(label+' complete',flush=True)

run('census-pack-ci-63',['pack','ci',str(pack)])
results={}
for name,database,expected in [('native','repository-database-24',27996),('wasm','repository-database-45',21631),('control-native','native-target-database-57',3),('control-wasm','wasm-target-database-57',3)]:
    bqrs=stage/(name+'-census-63.bqrs');decoded=stage/(name+'-census-63.json')
    run(name+'-census-query-63',['query','run',str(pack/'MacroCalls.ql'),'--database='+str(stage/database),'--output='+str(bqrs),'--warnings=error','--threads=2','--ram=8192'])
    run(name+'-census-decode-63',['bqrs','decode',str(bqrs),'--format=json','--output='+str(decoded)])
    rows=json.loads(decoded.read_text())['#select']['tuples']
    sdk.require(len(rows)==expected,'query lost source macro entities')
    results[name]={'entities':len(rows),'unresolved_code':sum(row[4]=='unresolved' and row[5]=='code' for row in rows),'unresolved_export_metadata':sum(row[4]=='unresolved' and row[5]=='export_name' for row in rows),'rows_sha256':sdk.snapshot(decoded).sha256}
sdk.require(sdk.snapshot(root/'artifact/codeql-rust-quality/MacroCalls.ql').sha256==query.sha256,'production query changed')
sdk.write_json(stage/'TARGET_CENSUS_QUERIED_63.json',{'completed':True,'query_sha256':query.sha256,'results':results,'production_gate_integrated':False})
print(json.dumps(results),flush=True)
