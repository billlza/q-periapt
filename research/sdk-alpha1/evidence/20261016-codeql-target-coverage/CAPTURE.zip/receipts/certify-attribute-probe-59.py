"""Distinguish compiler-resolved export metadata from executable data flow."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

stage=Path(__file__).resolve().parent
probe=json.loads((stage/'ATTRIBUTE_PROBE_RESULTS_57.json').read_text())
sdk.require(probe['completed'],'attribute probe incomplete')
for name in ('native','wasm'):
    rows=probe['profiles'][name]['results']
    metrics=dict(rows['Metrics'])
    sdk.require(rows['CapturedFormatFlow']==[['src/lib.rs']],'captured formatting data flow missing')
    sdk.require(sorted(rows['MacroCoverage'])==sorted([
        ['src/lib.rs',1,24,'concat!...','unresolved'],
        ['src/lib.rs',3,5,'format!...','expanded'],
        ['src/lib.rs',3,13,'...::format_args!...','expanded'],
    ]),'macro context differs from the fixture source')
    sdk.require(metrics['source_macro_calls']==3 and metrics['unresolved_source_macro_calls']==1,'macro census mismatch')
    for metric in ('extraction_errors','extraction_warnings','unextracted_elements','ast_inconsistencies','cfg_inconsistencies','ssa_inconsistencies','dataflow_inconsistencies'):
        sdk.require(metrics[metric]==0,'unexpected extraction/integrity diagnostic')

wasm=stage/'target-fixture-build-57/wasm32-unknown-unknown/debug/attribute_expansion_probe.wasm'
snapshot=sdk.snapshot(wasm,maximum=16*1024**2)
blob=snapshot.data
sdk.require(blob[:8]==b'\x00asm\x01\x00\x00\x00','invalid Wasm module header')
def unsigned(offset,limit):
    value=0
    for index in range(5):
        sdk.require(offset<limit,'truncated Wasm integer')
        byte=blob[offset];offset+=1
        sdk.require(index<4 or byte<16,'Wasm u32 overflow')
        value|=(byte&0x7f)<<(7*index)
        if not byte&0x80:
            return value,offset
    raise ValueError('unterminated Wasm integer')

offset=8
exports=None
while offset<len(blob):
    section=blob[offset];offset+=1
    size,offset=unsigned(offset,len(blob))
    end=offset+size
    sdk.require(end<=len(blob),'Wasm section exceeds module')
    if section==7:
        sdk.require(exports is None,'duplicate export section')
        count,offset=unsigned(offset,end)
        sdk.require(count<=100,'unexpected export count')
        exports=[]
        for _ in range(count):
            length,offset=unsigned(offset,end)
            sdk.require(length<=256 and offset+length<end,'invalid export name boundary')
            name=blob[offset:offset+length].decode();offset+=length
            kind=blob[offset];offset+=1
            index,offset=unsigned(offset,end)
            exports.append({'name':name,'kind':kind,'index':index})
        sdk.require(offset==end,'unconsumed export section')
    offset=end
sdk.require(exports is not None and sum(item['name']=='analysis_attribute_emit' and item['kind']==0 for item in exports)==1,'compiler-resolved export is missing')
native=stage/'target-fixture-build-57/aarch64-apple-darwin/debug/libattribute_expansion_probe.dylib'
native_symbols=sdk.command(['/usr/bin/nm','-gU',str(native)],stage/'native-export-symbols-59',Path.cwd())
sdk.require(sum(line.split()[-1:] == [b'_analysis_attribute_emit'] for line in native_symbols.splitlines())==1,'native compiler-resolved export is missing')
sdk.require(all(sdk.snapshot(stage/'attribute-fixture-57'/path).sha256==digest for path,digest in probe['source_files'].items()),'attribute fixture source changed')
sdk.write_json(stage/'ATTRIBUTE_PROBE_CERTIFIED_59.json',{'completed':True,'source':probe['source_files'],'native_export_sha256':sdk.snapshot(native).sha256,'wasm_sha256':snapshot.sha256,'wasm_exports':exports,'both_compilers_resolve_export_name':True,'both_codeql_targets_preserve_parameter_to_return_flow':True,'both_codeql_targets_leave_one_export_attribute_macro_without_expansion':True,'strict_all_macro_zero_rule_rejects_this_valid_control':True,'production_quality_gate_changed':False,'complete_sdk_analysis_qualified':False})
print('Native and Wasm exported symbol names and executable data flow independently verified',flush=True)
