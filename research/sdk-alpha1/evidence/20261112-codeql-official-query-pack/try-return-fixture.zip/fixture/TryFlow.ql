import rust
import codeql.rust.dataflow.DataFlow
import codeql.rust.dataflow.TaintTracking
import codeql.rust.dataflow.FlowSink

bindingset[name]
predicate callTargetName(CallExpr call, string name) {
  call.getFunction().(PathExpr).getPath().getText().matches(name + "%")
}

module Config implements DataFlow::ConfigSig {
  predicate isSource(DataFlow::Node source) { callTargetName(source.asExpr(), "source") }

  predicate isSink(DataFlow::Node sink) {
    any(CallExpr call | callTargetName(call, "sink")).getASyntacticArgument() = sink.asExpr()
    or
    sinkNode(sink, "test-sink")
  }
}

module Flow = TaintTracking::Global<Config>;

from DataFlow::Node source, DataFlow::Node sink
where Flow::flow(source, sink)
select source.asExpr().(Call).getPositionalArgument(0).toString()
