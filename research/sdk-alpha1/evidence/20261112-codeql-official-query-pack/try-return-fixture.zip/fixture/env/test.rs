fn source(id: i64) -> i64 { id }
fn source_option(id: i64) -> Option<i64> { Some(id) }
fn sink<T>(_: T) {}

fn unwrapped_value_not_returned() -> Option<i64> {
    let _a = Some(source(50))?;
    Some(0)
}

fn unwrapped_value_returned() -> Result<i64, i64> {
    let a: Result<Result<i64, i64>, i64> = Ok(Ok(source(51)));
    a?
}

fn pass_sink_option(_f: impl FnOnce(()) -> Option<i64>) {}

pub fn exercise() {
    sink(unwrapped_value_not_returned().unwrap());
    sink(unwrapped_value_returned().unwrap());
    sink(source(52));
    pass_sink_option(|_| {
        let _a = Some(source(100))?;
        Some(0)
    });
    pass_sink_option(|_| {
        let a: Option<Option<i64>> = Some(source_option(101));
        a?
    });
}
