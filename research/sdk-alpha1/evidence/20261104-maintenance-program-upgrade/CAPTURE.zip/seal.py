from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import runpy
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT/'target/continuity-maintenance-program-upgrade'
OUT = BASE/'run-01'
DEST = ROOT/'research/sdk-alpha1/evidence/20261104-maintenance-program-upgrade'

def sha(body): return hashlib.sha256(body).hexdigest()
def encode(value): return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()

def main():
    readback=json.loads((BASE/'READBACK.json').read_bytes())
    controls=json.loads((BASE/'CONTROLS.json').read_bytes())
    assert readback['completed'] and controls['completed'] and controls['rejected_controls']==18
    assert not (BASE/'readback.stderr').read_bytes() and not (BASE/'controls.stderr').read_bytes()
    files={}
    def add(name,path):
        assert name not in files and path.is_file() and not path.is_symlink()
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        files[name]=path.read_bytes()
    for name,row in readback['verified_public_read_files'].items():
        add(name,BASE/name)
        assert sha(files[name])==row['sha256'] and len(files[name])==row['bytes']
    for path in sorted(OUT.iterdir()):
        if path.is_file() and path.suffix in {'.json','.stdout','.stderr','.py','.whl','.txt'}:
            name='run-01/'+path.name
            if name not in files: add(name,path)
    for path in sorted((OUT/'programs').iterdir()):
        name='run-01/programs/'+path.name
        if name not in files: add(name,path)
    for name in ['READBACK.json','CONTROLS.json','CANDIDATE_ARCHIVE_COMPARISON.json',
                 'review.py','review_controls.py','readback.py','readback.stdout','readback.stderr','controls.stderr','seal.py']:
        add(name,BASE/name)
    outside=Path(json.loads((OUT/'LOCATION.json').read_bytes())['path'])
    inputs=json.loads((OUT/'CONTROLLER_INPUTS.json').read_bytes())
    for rel,digest in inputs['files'].items():
        name='controllers/'+rel
        add(name,outside/rel)
        assert sha(files[name])==digest
    manifest={name:{'bytes':len(body),'sha256':sha(body)} for name,body in sorted(files.items())}
    files['FILES.json']=encode(manifest)
    assert len(files)<4096 and sum(map(len,files.values()))<64*1024**2
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,body in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,4,0,0,0))
            info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,body)
    payload=buffer.getvalue()
    reviewer=runpy.run_path(str(BASE/'review.py'),run_name='archive_upgrade_review')['review']
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))==len(files)
        assert set(archive.namelist())==set(files)
        assert all(archive.read(name)==body for name,body in files.items())
        reviewed=reviewer(archive.read)
        assert reviewed==readback['original_runtime_results']
    rows=reviewed['scenarios']
    summary={'schema_version':1,'completed':True,'release_claim_eligible':False,
             'publication_performed':False,'sealed_utc':datetime.now(timezone.utc).isoformat(),
             'scope':'One current same-format installed native-program replacement edge on macOS arm64; fresh independent wheel; original-state exact recovery; no physical power loss or final release claim.',
             'controller_commit':inputs['commit'],'before_source':'21e00e9c3cfd193b9f51491888347f583620dfe0',
             'after_source':'4effa8b2b25e7403ab912b65894a7d1e73695542',
             'before_sdk':'6084f3bfb09333f6b66291b38809ed512296a27b',
             'after_sdk':'f560d803c43a24fff222daa5e5e5bd623bfdf874',
             'native_commands':sum(r['native_commands'] for r in rows),
             'witness_attempts':sum(r['witness_attempts'] for r in rows),
             'process_cuts':sum(r['process_cuts'] for r in rows),
             'program_switches':sum(r['program_switches'] for r in rows),
             'scenarios':rows,'rejected_controls':18,'installed_modules':105,
             'installed_wheel_files':113,'copied_controller_files_in_application':101,
             'original_driver_exit':1,'original_final_inventory_check_failed':True,
             'corrected_exact_union_readback':True,'runtime_rerun':False,
             'archive':{'file':'CAPTURE.zip','sha256':sha(payload),'bytes':len(payload),'members':len(files)},
             'member_manifest_sha256':sha(files['FILES.json']),
             'archive_only_runtime_readback_completed':True,
             'private_fixture_state_included':False}
    DEST.mkdir(parents=True,exist_ok=False)
    for name,body in [('CAPTURE.zip',payload),('FILES.json',files['FILES.json']),('RESULT.json',encode(summary))]:
        with (DEST/name).open('xb') as stream:stream.write(body)
    assert sha((DEST/'CAPTURE.zip').read_bytes())==summary['archive']['sha256']
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
