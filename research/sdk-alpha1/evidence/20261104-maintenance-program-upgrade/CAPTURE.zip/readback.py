from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import runpy

from continuity_independent_python import PACKAGE, inspect_wheel, verify_installation
from continuity_independent_python_run import installed_files
from evidence_io import read_regular_snapshot

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-maintenance-program-upgrade'
OUT = BASE / 'run-01'
SOURCE = ROOT / 'research/continuity-openssl-peer'

def sha(body):
    return hashlib.sha256(body).hexdigest()

def data(path, maximum=32*1024**2):
    return read_regular_snapshot(path, maximum=maximum, label='maintenance program-replacement readback').data

def obj(path):
    return json.loads(data(path))

def main():
    report = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'runtime_rerun': False, 'release_claim_eligible': False,
              'original_driver_exit': 1,
              'original_driver_failure': 'Final wheel-only inventory check included the separately recorded copied test controllers. All three runtime commands and both import probes had completed before that check.',
              'original_driver_sha256': sha(data(OUT/'run.py')),
              'original_driver_stderr_sha256': sha(data(OUT/'driver.stderr')),
              'readback_sha256': sha(data(Path(__file__)))}
    try:
        assert b'ValueError: reference installation inventory differs' in data(OUT/'driver.stderr')
        location = obj(OUT/'LOCATION.json')
        outside = Path(location['path'])
        assert outside.is_absolute() and outside.resolve(strict=True) == outside
        application = outside/'research/continuity-openssl-peer'
        inputs = obj(OUT/'CONTROLLER_INPUTS.json')
        expected = obj(OUT/'EXPECTED_MODULES.json')
        installed_before = obj(OUT/'INSTALLED_FILES.json')
        helpers = {}
        for name, digest in inputs['files'].items():
            assert sha(data(ROOT/name)) == sha(data(outside/name)) == digest
            prefix = 'research/continuity-openssl-peer/'
            if name.startswith(prefix):
                relative = name.removeprefix(prefix)
                assert '/' not in relative and relative.endswith('.py')
                helpers[relative] = digest
        current = installed_files(application)
        assert not (set(installed_before) & set(helpers))
        assert set(current) == set(installed_before) | set(helpers), 'unexplained installed/controller file'
        for name, digest in installed_before.items():
            assert sha(current[name]) == digest, name
        for name, digest in helpers.items():
            assert sha(current[name]) == digest, name
        wheel = OUT/(PACKAGE+'-0.0.0-py3-none-any.whl')
        wheel_body = data(wheel)
        assert sha(wheel_body) == '596bba62781296558a64d768a12ed618043b8cf3e14070cdf81c2ed423d3a094'
        modules = {p.name: data(p) for p in sorted((SOURCE/PACKAGE).glob('*.py'))}
        assert {name:sha(body) for name,body in modules.items()} == expected
        wheel_files = inspect_wheel(wheel_body,modules,{n:data(SOURCE/n) for n in ('LICENSE-APACHE','LICENSE-MIT')},data(SOURCE/'README.md'))
        verify_installation({n:current[n] for n in installed_before},wheel_files,wheel_url=wheel.as_uri(),digest=sha(wheel_body))
        before, after = obj(OUT/'PROVENANCE_BEFORE.json'), obj(OUT/'PROVENANCE_AFTER.json')
        assert before == after and before['modules'] == expected
        provider = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
        assert {p.relative_to(provider).as_posix():sha(data(p,512*1024**2)) for p in provider.rglob('*') if p.is_file()} == obj(OUT/'PROVIDER_FILES.json')
        commands = []
        for name in ['install','probe-before','peer','peer-before','peer-after','probe-after']:
            receipt = obj(OUT/(name+'.json'))
            assert receipt['completed'] and receipt['exit'] == 0 and receipt['timeout_seconds'] == 900
            assert receipt['maximum_stdout_bytes'] == 4*1024**2 and receipt['maximum_stderr_bytes'] == 1024**2
            assert receipt['stdout_sha256'] == sha(data(OUT/(name+'.stdout')))
            assert receipt['stderr_sha256'] == sha(data(OUT/(name+'.stderr'))) and not data(OUT/(name+'.stderr'))
            commands.append({'name':name,'elapsed_seconds':receipt['elapsed_seconds']})
        read_files = {}
        def read(name):
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            body = data(BASE/relative)
            read_files[name] = {'sha256':sha(body),'bytes':len(body)}
            return body
        reviewed = runpy.run_path(str(BASE/'review.py'),run_name='current_upgrade_review')['review'](read)
        assert reviewed['completed']
        report.update(completed=True, controller_commit=inputs['commit'],
                      original_runtime_results=reviewed, commands=commands,
                      installed_module_count=len(expected), installed_wheel_files=len(installed_before),
                      copied_controller_files=len(helpers), exact_installation_union_verified=True,
                      provider_files_unchanged=True, outside_installation=str(outside),
                      wheel_sha256=sha(wheel_body), verified_public_read_files=read_files,
                      source_and_installed_controllers_unchanged=True,
                      scope='Current same-format installed-program edge, including committed and uncommitted Witness reply loss. This readback preserves the failed outer inventory check; it does not rerun or relabel its exit status.')
    except BaseException as error:
        report.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with (BASE/'READBACK.json').open('x') as stream:
            json.dump(report,stream,indent=2)
            stream.write('\n')
    print(json.dumps({k:report[k] for k in ['completed','installed_module_count','installed_wheel_files','copied_controller_files','original_runtime_results']},indent=2))

if __name__ == '__main__':
    main()
