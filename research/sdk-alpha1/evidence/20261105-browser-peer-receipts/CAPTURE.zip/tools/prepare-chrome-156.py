from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import base64
import hashlib
import json
import stat
import time
import urllib.request
import zipfile

from bounded_process import capture_output

BASE = Path(__file__).resolve().parent
manifest = json.loads((BASE / 'chrome-156-official-manifest.json').read_bytes())
assert manifest['version'] == '156.0.8078.80'
rows = [row for row in manifest['downloads']['chrome'] if row['platform'] == 'mac-arm64']
assert len(rows) == 1
url = rows[0]['url']
assert url == 'https://storage.googleapis.com/chrome-for-testing-public/156.0.8078.80/mac-arm64/chrome-mac-arm64.zip'
archive = BASE / 'chrome-mac-arm64-156.0.8078.80.zip'
destination = BASE / 'chrome-156'
state = {'completed': False, 'url': url, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'maximum_download_seconds': 180, 'maximum_bytes': 400 * 1024**2}
started = time.monotonic()
try:
    sha, md5, size = hashlib.sha256(), hashlib.md5(), 0
    with urllib.request.urlopen(url, timeout=30) as response, archive.open('xb') as out:
        declared = int(response.headers['Content-Length'])
        assert 0 < declared <= state['maximum_bytes']
        expected_md5 = [part.strip()[4:] for part in response.headers['x-goog-hash'].split(',')
                        if part.strip().startswith('md5=')]
        assert len(expected_md5) == 1
        while chunk := response.read(1024 * 1024):
            size += len(chunk)
            assert size <= declared and time.monotonic() - started <= 180
            sha.update(chunk); md5.update(chunk); out.write(chunk)
    assert size == declared and base64.b64encode(md5.digest()).decode() == expected_md5[0]
    state.update(bytes=size, sha256=sha.hexdigest(), transfer_md5=expected_md5[0])
    with zipfile.ZipFile(archive) as packed:
        assert packed.testzip() is None
        members = packed.infolist()
        assert len({row.filename for row in members}) == len(members)
        assert sum(row.file_size for row in members) < 2 * 1024**3
        for row in members:
            relative = PurePosixPath(row.filename)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert relative.parts[0] == 'chrome-mac-arm64'
            if stat.S_ISLNK(row.external_attr >> 16):
                target = packed.read(row).decode()
                assert not Path(target).is_absolute()
                assert (destination / row.filename).parent.joinpath(target).resolve().is_relative_to(destination.resolve())
        state['members'] = len(members)
    destination.mkdir()
    commands = [
        ('extract', ['/usr/bin/ditto', '-x', '-k', str(archive), str(destination)]),
        ('codesign', ['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(destination / 'chrome-mac-arm64/Google Chrome for Testing.app')]),
        ('identity', ['/usr/bin/codesign', '-dv', '--verbose=2', str(destination / 'chrome-mac-arm64/Google Chrome for Testing.app')]),
        ('version', [str(destination / 'chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'), '--version']),
    ]
    state['commands'] = []
    for label, argv in commands:
        result = capture_output(argv, timeout_seconds=120, maximum_stdout_bytes=1024**2, maximum_stderr_bytes=1024**2)
        for stream in ('stdout', 'stderr'):
            (BASE / ('chrome-156-' + label + '.' + stream)).open('xb').write(getattr(result, stream))
        state['commands'].append({'label': label, 'argv': argv, 'returncode': result.returncode})
        assert result.returncode == 0, label
        if label == 'identity':
            assert b'TeamIdentifier=EQHXZ8M8AV' in result.stderr
        if label == 'version':
            assert b'156.0.8078.80' in result.stdout
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    with (BASE / 'CHROME_156_PREPARATION.json').open('x') as out:
        json.dump(state, out, indent=2); out.write('\n')
    print(json.dumps(state), flush=True)
