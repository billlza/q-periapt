"""Retain public browser observations and independently read back successful transcripts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import plistlib
import subprocess
import tempfile
import zipfile

from continuity_browser_session_records import verify, transport_requests

ROOT = Path.cwd()
WORK = Path('/Users/bhmq03@durham.ac.uk/.codex/worktrees/browser-exchange-observation/Q-periapt')
BASE = WORK / 'target'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-browser-peer-receipts'
TOOLS = ROOT / 'target/continuity-browser-tools'
files = {}
sha = lambda data: hashlib.sha256(data).hexdigest()

def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), (name, path)
    data = path.read_bytes()
    assert len(data) <= 16 * 1024**2, path
    files[name] = data

cases = []
for number in range(1, 11):
    label = f'{number:02}'
    base = BASE / ('exchange-observation-' + label)
    driver = json.loads((base / 'DRIVER_RESULT.json').read_bytes())
    for path in sorted(base.iterdir()):
        if path.is_file(): add('cases/' + label + '/' + path.name, path)
    driver_path = BASE / ('exchange-observation-driver.py' if number == 1 else 'exchange-observation-driver-' + label + '.py')
    add('drivers/' + driver_path.name, driver_path)
    outputs = [path for path in base.iterdir() if path.is_dir() and (path / 'public').is_dir()]
    assert len(outputs) == 1
    output = outputs[0]
    for path in sorted((output / 'public').rglob('*')):
        if path.is_file(): add('cases/' + label + '/public/' + path.relative_to(output / 'public').as_posix(), path)
    for path in sorted(output.glob('*.js')):
        add('cases/' + label + '/phase-code/' + path.name, path)
    for name in ('initial.json', 'grant.json', 'worker.js', 'run.js', 'effects.js', 'transport-receipts.js', 'index.html'):
        path = output / 'web' / name
        if path.exists(): add('cases/' + label + '/web/' + name, path)
    report_path = output / 'public/RESULT.json'
    record = {'case': label, 'driver_returncode': driver.get('browser_returncode'),
              'driver_qualification_passed': driver['qualification_passed']}
    if report_path.exists():
        report = json.loads(report_path.read_bytes())
        record.update(completed=report['completed'], failure=report.get('failure'))
        assert not report.get('cleanup_failures')
        if number in (7, 8, 9):
            verify(report, output / 'public')
            assert report['completed'] and driver['qualification_passed'] and driver['browser_returncode'] == 0
            for name, expected in report['native_binary_sha256'].items():
                assert sha((BASE / 'exchange-observation-native/release' / name).read_bytes()) == expected
            record.update(schema=report['schema_version'], original_readback=True,
                          frames=len(report['frames']), reverse_frames=len(report['reverse_application']['frames']))
        else: assert not report['completed'] and driver['qualification_passed'] is False
        phase_path = output / 'public/activate.json'
        if phase_path.exists():
            value = json.loads(phase_path.read_bytes())
            remaining = transport_requests(value, output / 'public', report['browser_origin'],
                                           report.get('required_witness', {}).get('frames', []), report['frames'])
            assert remaining == [{'url': report['browser_origin'] + '/exchange/drop-once',
                                  'failure': {'errorText': 'net::ERR_EMPTY_RESPONSE'}}]
            record.update(browser=value['browser'], peer_client_wire_readback=True,
                          normal_peer_aborts=sum(row['url'] == report['browser_origin'] + '/exchange'
                                                for row in value['requests']))
    cases.append(record)
assert cases[4]['normal_peer_aborts'] == 4 and cases[5]['normal_peer_aborts'] == 0
assert json.loads((BASE / 'exchange-observation-10/DRIVER_RESULT.json').read_bytes())['startup_refusal_cleanup_verified']

installed = BASE / 'exchange-observation-01/installed-consumer'
for path in sorted(installed.iterdir()):
    if path.is_file(): add('installed-consumer/' + path.name, path)
add('sdk/q-periapt-sdk-wasm-0.2.0.tgz', ROOT / 'target/continuity-browser-exchange-diagnostic/wasm-input/q-periapt-sdk-wasm-0.2.0.tgz')
for path in sorted((BASE / 'exchange-observation-checks').iterdir()):
    if path.is_file(): add('checks/' + path.name, path)
tests = json.loads((BASE / 'exchange-observation-checks/TEST_RESULT.json').read_bytes())
assert tests['returncode'] == 0 and b'Ran 71 tests' in files['checks/tests.stderr']
for path in sorted(TOOLS.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr', '.py'):
        add('tools/' + path.name, path)
add('tools/node-SHASUMS256.txt', ROOT / 'target/continuity-browser-exchange-diagnostic/node-SHASUMS256.txt')
for name in ('q-periapt-native-device', 'q-periapt-native-session', 'q-periapt-native-outgoing', 'q-periapt-continuity-witness'):
    add('native/' + name, BASE / 'exchange-observation-native/release' / name)
changed = subprocess.run(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', '4807d0d9a39fdbf842003562e4420f6c03e201c9'],
                         check=True, text=True, capture_output=True).stdout.splitlines()
assert len(changed) == 8
for name in changed:
    assert (ROOT / name).read_bytes() == (WORK / name).read_bytes()
    add('source/' + name, ROOT / name)
add('source/INTEGRATION_SOURCE_IMPACT.json', ROOT / 'target/continuity-browser-exchange-diagnostic/INTEGRATION_SOURCE_IMPACT.json')
add('source/seal-observation.py', Path(__file__))
plist = plistlib.loads(Path('/Applications/Google Chrome.app/Contents/Info.plist').read_bytes())
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'release_claim_eligible': False,
           'fixture_commit': '4807d0d9a39fdbf842003562e4420f6c03e201c9',
           'main_integration_commit': '7bc5a4333e2bafdca2ff1620dece446064060aec',
           'sdk_source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
           'cases': cases, 'regression_tests': 71,
           'installed_chrome_version_observed_after_execution': plist['CFBundleShortVersionString'],
           'upstream_reference': 'https://github.com/microsoft/playwright/issues/42742',
           'limits': 'macOS arm64 only; original ff072 SDK archive; no Linux rerun, current Windows-fixed root SDK qualification, complete security proof or release acceptance.'}
files['READBACK.json'] = (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()
DEST.mkdir()
archive = DEST / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for name, data in sorted(files.items()):
        entry = zipfile.ZipInfo(name, (2000, 1, 1, 0, 0, 0))
        entry.external_attr = 0o100644 << 16
        entry.compress_type = zipfile.ZIP_DEFLATED
        packed.writestr(entry, data)
with zipfile.ZipFile(archive) as packed:
    assert packed.testzip() is None and set(packed.namelist()) == set(files)
    for name, data in files.items(): assert packed.read(name) == data
    with tempfile.TemporaryDirectory(prefix='qpc-browser-receipt-readback-') as temp:
        exported = Path(temp)
        for name, data in files.items():
            if name.startswith(tuple('cases/' + label + '/public/' for label in ('07', '08', '09'))):
                path = exported / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        for label in ('07', '08', '09'):
            public = exported / 'cases' / label / 'public'
            verify(json.loads((public / 'RESULT.json').read_bytes()), public)
index = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
         'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())},
         'exported_full_transcripts_verified': ['07', '08', '09']}
for name, value in [('CAPTURE.json', index), ('READBACK.json', summary)]:
    with (DEST / name).open('x') as out: json.dump(value, out, indent=2, sort_keys=True); out.write('\n')
print(json.dumps({'destination': str(DEST), 'bytes': index['archive_bytes'], 'sha256': index['archive_sha256'],
                  'members': len(files), 'exported_full_transcripts_verified': index['exported_full_transcripts_verified']}), flush=True)
