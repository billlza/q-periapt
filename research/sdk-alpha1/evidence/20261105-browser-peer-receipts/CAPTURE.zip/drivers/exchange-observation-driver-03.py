from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import time

from bounded_process import capture_output, TimeoutPolicy

ROOT = Path.cwd()
MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
BASE = ROOT / 'target/exchange-observation-03'
BASE.mkdir()
TOOLS = MAIN / 'target/continuity-browser-tools'
NODE = TOOLS / 'node-v26.10.0-darwin-arm64/bin/node'
NPM = TOOLS / 'packages/node_modules/npm/bin/npm-cli.js'
CLI = TOOLS / 'packages/node_modules/@playwright/cli/playwright-cli.js'
ARCHIVE = MAIN / 'target/continuity-browser-exchange-diagnostic/wasm-input/q-periapt-sdk-wasm-0.2.0.tgz'
PYTHON = ['/bin/sh', 'artifact/python-run.sh']
environment = {key: value for key, value in os.environ.items()
               if key not in ('NODE_OPTIONS', 'NODE_PATH', 'NPM_TOKEN', 'NODE_AUTH_TOKEN')
               and not key.lower().startswith('npm_config_')}
environment.update(
    QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3',
    PATH=str(NODE.parent) + ':/Users/bhmq03@durham.ac.uk/.cargo/bin:' + environment.get('PATH', os.defpath),
    CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
    CARGO_BUILD_JOBS='2',
    CI='true',
    OPENSSL_DIR='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed',
    OPENSSL_STATIC='0',
)
openssl_root = Path(environment['OPENSSL_DIR'])
def openssl_identity():
    return {str(p.relative_to(openssl_root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(openssl_root.rglob('*')) if p.is_file() and not p.is_symlink()}
openssl_before = openssl_identity()

state = {'source_commit': 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20',
         'scope': 'macOS Chrome diagnostic; original WASM archive; profile 2 fixture observation; unchanged validator',
         'qualification_passed': False, 'openssl_dir': str(openssl_root),
         'openssl_inputs_before': openssl_before, 'openssl_static': '0', 'CI': 'true',
         'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
         'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

def command(label, argv, seconds):
    entry = {'label': label, 'argv': [str(value) for value in argv],
             'timeout_seconds': seconds, 'started_utc': datetime.now(timezone.utc).isoformat()}
    state['commands'].append(entry)
    started = time.monotonic()
    try:
        with (BASE / (label + '.stdout')).open('xb', buffering=0) as stdout, \
             (BASE / (label + '.stderr')).open('xb', buffering=0) as stderr:
            result = capture_output(entry['argv'], timeout_seconds=seconds,
                timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
                maximum_stdout_bytes=16 * 1024**2, maximum_stderr_bytes=16 * 1024**2,
                environment=environment, stdout_sink=stdout.write, stderr_sink=stderr.write)
        entry['returncode'] = result.returncode
        return result.returncode
    finally:
        entry['elapsed_seconds'] = time.monotonic() - started
        entry['finished_utc'] = datetime.now(timezone.utc).isoformat()
        for stream in ('stdout', 'stderr'):
            entry[stream + '_sha256'] = hashlib.sha256((BASE / (label + '.' + stream)).read_bytes()).hexdigest()
        print(json.dumps(entry), flush=True)

try:
    rc = command('browser', [*PYTHON, 'artifact/continuity_browser_session.py',
        '--receipt', ROOT / 'target/exchange-observation-01/installed-consumer/INSTALLED_CONSUMER.json',
        '--output', BASE / 'required-witness', '--native-target', ROOT / 'target/exchange-observation-native',
        '--native-profile', 'release', '--required-witness', '--node', NODE, '--cli', CLI,
        '--provider-root', '/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider'], 1800)
    state['browser_returncode'] = rc
    if rc:
        raise RuntimeError('Diagnostic browser run did not pass qualification; inspect preserved phase and response receipts')
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    for name in ('kind', 'cleanup_ambiguous', 'signal_number'):
        if hasattr(error, name):
            state[name] = getattr(error, name)
    raise
finally:
    state['openssl_inputs_unchanged'] = openssl_identity() == openssl_before
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    with (BASE / 'DRIVER_RESULT.json').open('x') as stream:
        json.dump(state, stream, indent=2)
        stream.write('\n')
