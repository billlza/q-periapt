async page => {
          const phase = "create";
          const origin = "http://127.0.0.1:62211";
          const details = null;
          const diagnostics=[], requests=[], httpErrors=[];
          const phaseStarted=Date.now(), responseStatus=new WeakMap(), requestDiagnostics=[];
          let lostResponseObserved=false, lostResponseNotify=null, lostResponseTimer;
          const onPageError=error=>diagnostics.push({type:'pageerror',message:String(error)});
          const onConsole=message=>{if(['error','warning'].includes(message.type()))diagnostics.push({type:message.type(),message:message.text(),location:message.location()});};
          const onRequestFailed=request=>{
            requests.push({url:request.url(),failure:request.failure()});
            // These are isolated fixture frames, also retained by the relay.
            // Bind cancellation diagnostics to the exact request, not just its URL.
            requestDiagnostics.push({url:request.url(),failure:request.failure(),timing:request.timing(),
              body_hex:request.postDataBuffer()?.toString('hex')??null,
              response_status:responseStatus.get(request)??null,observed_ms:Date.now()});
            if(phase==='activate' && request.url()===origin+'/exchange/drop-once') {
              lostResponseObserved=true;
              if(lostResponseNotify)lostResponseNotify();
            }
          };
          const onResponse=response=>{
            responseStatus.set(response.request(),response.status());
            if(response.status()>=400)httpErrors.push({url:response.url(),status:response.status()});
          };
          const listeners=[['pageerror',onPageError],['console',onConsole],
            ['requestfailed',onRequestFailed],['response',onResponse]];
          try {
            for(const [event,listener] of listeners)page.on(event,listener);
            await page.waitForFunction(()=>globalThis.fixtureReady===true,undefined,{timeout:15000});
            const result=await page.evaluate(({phase,details})=>globalThis.runPhase(phase,details),{phase,details});
            // Worker completion can precede delivery of the DevTools failure event.
            // Keep the exact expected observer event mandatory, with a bounded wait.
            if(phase==='activate' && !lostResponseObserved) {
              await new Promise((resolve,reject)=>{
                lostResponseNotify=()=>{clearTimeout(lostResponseTimer);resolve();};
                lostResponseTimer=setTimeout(()=>reject(Error('lost response observer deadline '+JSON.stringify({
                  request_count:requests.length,http_error_count:httpErrors.length,
                  requests:requests.slice(0,8).map(row=>({url:row.url.slice(0,256),
                    reason:String(row.failure?.errorText??'').slice(0,256)}))}))),5000);
              });
            }
            const state=await page.evaluate(()=>({browser:navigator.userAgent,transport_receipts:globalThis.readTransportReceipts()}));
            return {status:'INSTALLED_SESSION_PHASE',phase,result,diagnostics,requests,http_errors:httpErrors,
              request_diagnostics:requestDiagnostics,phase_started_ms:phaseStarted,...state};
          } finally {
            clearTimeout(lostResponseTimer);
            lostResponseNotify=null;
            // The CLI reuses this Page across phases. Preserve unrelated listeners.
            for(const [event,listener] of listeners)page.off(event,listener);
          }
        }