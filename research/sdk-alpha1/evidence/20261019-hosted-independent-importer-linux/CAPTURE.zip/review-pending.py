"""Verify public recovery bytes/signatures, complete views and original operations."""
from pathlib import Path
import ast,hashlib,importlib.util,json,re,sys
root=Path.cwd();out=Path(__file__).resolve().parent;peer=out/'source';base=out/'public/pending-recovery'
sys.path.extend([str(peer),str(out)])
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from source_readback import normalized
from fixture_inputs import load,load_witness_pin
from peer.wire import require,ldh
from peer.pending_recovery_protocol import Proposal
from peer.witness import Operation,verify,commitment
from peer.bootstrap import digest
from peer.rekey import RekeyScope,genesis
from peer.resolution import ciphertext_digest
from peer.renewal import verify as grant_verify
from peer.local_renewal_protocol import Proposal as Renewal
from peer.traffic import message_id
spec=importlib.util.spec_from_file_location('public_inspection',out/'inspect-public.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
top=read(base/'RESULT.json');normalized(top['source_files']);require(len(top['source_files'])==99,'source count')
require(sha((out/'public/counterpart').read_bytes())==top['native_sha256'] and not (out/'public/pending-recovery.stderr').read_bytes(),'native/runtime identity')
profiles={}
for label in ['unapplied','already-applied','expired-policy','cancelled','two-cycles']:
 folder=base/label;r=read(folder/'RESULT.json');native={};workers={};kills=0
 require(not (folder/'native/native.stderr').read_bytes(),'native diagnostics')
 for row in r['native_commands']:
  name=row['case'];require(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name)is not None and name not in native,'native case identity')
  before=(folder/'native/cases'/(name+'.input')).read_bytes();after=(folder/'native/cases'/(name+'.output')).read_bytes()
  require(sha(before)==row['input_sha256'] and sha(after[1:])==row['output_sha256'] and after[0]==row['status'],'native raw bytes')
  if after[0]==2:require(after[1:].decode()==row['error'],'native refusal')
  native[name]=(before,after,row['command'])
 for row in r['worker_operations']:
  name=row['case'];request=read(folder/(name+'.request.json'));raw=(folder/(name+'.stdout')).read_bytes();error=(folder/(name+'.stderr')).read_text()
  require(name not in workers and request['action']==row['action'],'worker identity');workers[name]=request
  if 'signal'in row:
   kills+=1;require(row['signal']=='SIGKILL'and json.loads(raw)=={'pid':row['worker_pid'],'stage':row['cut']}and not error,'actual process cut')
  elif 'refused'in row:require(not raw and row['refused']in error,'no output on refusal')
  else:require(not error and sha(raw)==row['stdout_sha256'],'worker output bytes')
 require(kills==r['process_kills']==(6 if label=='two-cycles'else 5),'actual SIGKILL count')
 def result(name):return read(folder/(name+'.stdout'))['result']
 def wire(name):return bytes.fromhex(result(name))
 public=folder/'native/public';pin=load_witness_pin(public);_,_,ctx=load(public,150,witness_pin=pin)
 subject=native['enrollment'][0][:96];require(native['enrollment'][0].hex()==result('provision'),'genesis')
 initial,reply,final=wire('initial'),native['bootstrap-reply'][1][1:],wire('finish')
 require(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest and ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',initial),'initial signatures')
 require(final[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',initial)+digest(b'reply-wire',reply),'original transcript')
 session=digest(b'session-id',final[:104]);require(native['complete'][1]==b'\1'+session and wire('activate')==session,'original session')
 proposals={};metadata_sizes=[]
 for name in ['original-request','second-original-request']:
  if not (folder/(name+'.proposal')).exists():continue
  data,metadata,signed=((folder/(name+'.'+kind)).read_bytes()for kind in ['proposal','metadata','signed'])
  p=Proposal.decode(data);views=p.check_metadata(metadata);require(ctx.initiator.open(signed,26,393)==data,'actual historical signature')
  require(p.witness==pin.binding and p.subject==subject and p.policy==ctx.policy_digest and p.authorization is None,'original scope')
  parsed=[module.inspect(v,ctx)for v in views]
  require(parsed[0][0]==p.expected and parsed[1][0]==p.target,'complete view heads')
  for _,records,states in parsed:
   b=next(x['body']for x in records if x['tag']==1);s=next(x['body']for x in records if x['tag']==3)
   require(b['request']==subject[:32] and s['source']==b['source'] and s['session']==session,'projected original identity')
   require(b['flights']==[digest(b'initial-wire',initial),digest(b'reply-wire',reply),digest(b'final-wire',final),session],'original bootstrap flight digests')
   from peer.wire import digest as authority_digest
   authority=authority_digest(b'AUTHORITY',states[0].original.pin.account+states[0].listing.checkpoint()+ctx.family)
   require(authority==p.authority,'original current authority')
  source=next(x['body']for x in parsed[0][1]if x['tag']==3);target=next(x['body']for x in parsed[1][1]if x['tag']==3)
  if name=='original-request':
   require(len(source['epochs'])==len(target['epochs'])==1,'initial live epoch')
   for s in (source,target):require(s['epochs'][0]['unknown']==[(wire('original-id'),ciphertext_digest(wire('original-send')))],'unknown original delivery retained')
   require(source['epochs'][0]['reservation']is None and target['epochs'][0]['reservation']==(wire('pending-id'),len(b'original reserved message'),len(b'recovery'),None),'exact target reservation')
   require(sha(data)==r['proposal_sha256']and len(metadata)==r['metadata_bytes'],'original metadata report')
  else:require(len(metadata)==r['second_metadata_bytes']and len(metadata)>32768,'large complete public metadata')
  proposals[name]=(p,metadata);metadata_sizes.append(len(metadata))
  summary=result(name)
  for kind,value in [('proposal',data),('metadata',metadata),('signed',signed)]:require(summary[kind]=={'bytes':len(value),'sha256':sha(value)},'retained request summary')
 p,metadata=proposals['original-request'];target=p.target.wire();require((folder/'semantic-request-retry.proposal').read_bytes()==p.wire()and(folder/'semantic-request-retry.metadata').read_bytes()==metadata,'same request meaning')
 require(wire('confirmed-original')==wire('confirmed-retry-without-intent')==target,'exact confirmed original result')
 if label=='already-applied':require(not any(command==36 and response[0]==1 for _,response,command in native.values()),'no independent approval of applied write')
 else:
  require(native['live-authority-cannot-use-recovery-exception'][1][0]==2,'expired-only exception')
  for name in ['independent-pre-expiry-approval','independent-retained-approval']:
   require(native[name]==(p.wire()+metadata,b'\1'+ldh(b'Q-PERIAPT-CONTINUITY-PENDING-WRITE-RECOVERY/v1',p.wire())+(4).to_bytes(8,'big')*2,36),'native complete-view inspection and retained approval')
  for name in ['independent-exact-completion','independent-completion-retry']:require(native[name][1]==b'\1'+target,'exact native completion')
 challenges=set();signed_count=0;confirmed=0;last_mismatches=0
 for row in r['witness_attempts']:
  name=row['case'];data=(folder/(name+'.request')).read_bytes();require(sha(data)==row['request_sha256'],'witness request hash')
  body=ctx.initiator.open(data,7,297);operation=Operation(body[200],body[201:]);command=commitment(b'COMMAND',pin.binding+subject+operation.wire())
  require(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==command and command.hex()==row['command_id']and operation.kind==row['kind'],'witness original scope')
  challenge=body[168:200];require(any(challenge)and challenge not in challenges and challenge.hex()==row['challenge'],'fresh challenged request');challenges.add(challenge)
  if row['delivery']=='not_dispatched_by_fixture':require(name not in native and row['fault']=='before','lost dispatch');continue
  require(native[name][0]==data and native[name][2]==31,'actual signed handler')
  response=native[name][1];require(response[0]==row['native_status'],'actual witness status')
  if response[0]==2:require(response[1:].decode()==row['error'],'witness refusal');continue
  reply=(folder/(name+'.reply')).read_bytes();require(reply==response[1:]and sha(reply)==row['signed_reply_sha256'],'signed reply raw bytes')
  verified=verify(pin,subject,operation,body,reply);signed_count+=1
  if row['delivery']=='sent':require(sha(reply)==row['transport_reply_sha256'],'transport identity')
  else:require(row['delivery']=='signed_reply_withheld_by_fixture'and row['fault']=='after','actual lost reply')
  if operation.kind==1:
   for prop,_ in proposals.values():
    expected=commitment(b'COMMAND',pin.binding+subject+Operation.advance(prop.expected,prop.target.digest).wire())
    if verified.head==prop.target and verified.last==expected:prop.confirm(verified);confirmed+=1
   forged=folder/'forged-renewal-as-ordinary.proposal'
   if forged.exists():
    false=Proposal.decode(forged.read_bytes())
    if verified.head==false.target and verified.last!=commitment(b'COMMAND',pin.binding+subject+Operation.advance(false.expected,false.target.digest).wire()):last_mismatches+=1
 require(confirmed>=r['query_only_confirmation_attempts'],'fresh exact original confirmation count')
 require(native['ordinary-handler-refuses-purpose-26'][1][0]==2 and native['signature-alone-is-not-independent-approval'][1][0]==2 and native['native-inspector-refuses-unknown-record'][1][0]==2,'separate controller/refused malformed inspection')
 if label!='expired-policy':
  require(last_mismatches>=1 and wire('original-outbox-replayed')==wire('original-send'),'renewal is not an ordinary write/original outbox')
  require(native['receive-reserved-original'][1]==b'\1original reserved message'and native['receive-new-current'][1]==b'\1new after exact recovery','actual original and new native plaintext')
  for index,tag,now in [(1,'first-renewal',210)]+([(2,'second-renewal',310)]if label=='two-cycles'else[]):
   grant=grant_verify((public/f'local-renewal-{index}').read_bytes(),ctx.devices[0],ctx.family,ctx.policy_digest,(public/f'pin-local-renewal-{index}-target').read_bytes(),now=now)
   renewal=Renewal.decode(wire(tag+'-prepare'));require(renewal.operation==grant.operation and renewal.statement==grant.statement and result(tag+'-commit')=='Applied','genuine independent current renewal')
  flights=[wire('renewed-rekey-offer'),native['renewed-rekey-response'][1][1:],wire('renewed-rekey-final'),native['renewed-rekey-receipt'][1][1:]]
  RekeyScope(ctx,session,0,genesis(session,ctx.digest)).public_completed(*flights);require(result('renewed-rekey-confirm')==1,'same-session rekey')
 profiles[label]={'workers':len(workers),'native_commands':len(native),'signed_witness_replies':signed_count,'unique_challenges':len(challenges),'actual_SIGKILL':kills,'metadata_bytes':metadata_sizes,'exact_query_observations':confirmed,'negative_controls':len(r['refusals'])}
summary={'head':'54eda5836d42ed39f01e4957d4bec971cd1e8198','source_files':top['source_files'],'native_sha256':top['native_sha256'],'profiles':profiles,'scope':'Public raw bytes, signatures, roots, complete projected metadata, fresh Query history and PID cuts independently read. Original private MAC/AEAD and no-reseal/unchanged-state assertions remain runtime observations. Separate fixture approval is not deployed account authentication; not physical erasure, power-loss, whole-peer lifecycle or PCS.'}
(out/'PENDING_READBACK.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(profiles))
