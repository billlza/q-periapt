"""Public original-session, root-grant, witness and revocation readback."""
from pathlib import Path
import hashlib
import json
import re
import sys
root=Path.cwd();peer=Path(__file__).resolve().parent/'source';out=root/'target/independent-installed-hosted-54ed-01/linux/public';folder=out/'peer-lifecycle'
sys.path.extend([str(peer),str(out.parent)])
from source_readback import source_bytes,continuity
LANES = {'owner': 'durable-rekey', 'storage': 'storage-cuts', 'base': 'session-recovery', 'maximum': 'resolution-capacity', 'disclosure': 'resolution-disclosure', 'capacity': 'capacity', 'control': 'control', 'resolution': 'resolution', 'rekey': 'rekey', 'exchange': 'exchange', 'witness': 'witness', 'peer-lifecycle': 'peer-lifecycle', 'peer-reply-release': 'peer-reply-release'}
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load,load_witness_pin
from peer.renewal import verify as grant_verify
from peer.identity import roster
from peer.witness import verify as witness_verify,Operation,commitment
from peer.bootstrap import digest as bootstrap_digest
from peer.rekey import RekeyScope,genesis

def check(value,reason):
 if not value:raise ValueError(reason)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return parse_strict_json_bytes(path.read_bytes(),label=str(path))
def safe(name):check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name),'case path')
r=read(folder/'RESULT.json');sources=r['source_files']
check(len(sources)==99,'source inventory')
for name,expected in sources.items():check(sha(source_bytes(name,expected))==expected,'source identity')
binary=(out/'counterpart').read_bytes()
check(sha(binary)==r['native_sha256'] and binary[:6]==b'\x7fELF\x02\x01' and int.from_bytes(binary[18:20],'little')==62,'actual native ELF x86_64')
check(not (out/'peer-lifecycle.stderr').read_bytes(),'runtime diagnostics')
profiles={}
for name,counts in {'local':(40,11,4,0,31),'witness':(40,243,4,230,31),'local-release':(39,11,3,0,32),'witness-release':(39,262,3,249,32)}.items():
 path=folder/name;row=read(path/'RESULT.json');native={};workers={};kills=0
 check(not (path/'native/native.stderr').read_bytes(),'native diagnostics')
 check((len(row['worker_operations']),len(row['native_commands']),row['process_kills'],len(row['witness_attempts']),len(row['direct_refusals']))==counts,'profile workload')
 for command in row['native_commands']:
  label=command['case'];safe(label);prefix=path/'native/cases'/label
  before=prefix.with_suffix('.input').read_bytes();after=prefix.with_suffix('.output').read_bytes()
  check(sha(before)==command['input_sha256'] and sha(after[1:])==command['output_sha256'] and after[0]==command['status'],'native trace')
  check(label not in native,'duplicate native label');native[label]=(before,after,command['command'])
  if after[0]==2:check(after[1:].decode()==command['error'],'native refusal')
 for item in row['worker_operations']:
  label=item['case'];safe(label);request=read(path/(label+'.request.json'))
  value=(path/(label+'.stdout')).read_bytes();error=(path/(label+'.stderr')).read_text()
  check(request['action']==item['action'],'worker action')
  if 'signal' in item:
   kills+=1;check(item['signal']=='SIGKILL' and read(path/(label+'.stdout'))=={'pid':item['worker_pid'],'stage':item['cut']} and not error,'actual child cut')
  elif 'refused' in item:check(not value and item['refused'] in error,'refusal without result')
  else:
   check(sha(value)==item['stdout_sha256'] and not error,'worker output');workers[label]=read(path/(label+'.stdout'))['result']
 check(kills==counts[2],'actual kill count')
 public=path/'native/public';pin=load_witness_pin(public) if row['witnessed'] else None
 _,_,ctx=load(public,150,witness_pin=pin)
 session=bytes.fromhex(row['session']);check(ctx.digest.hex()==row['original_context'],'original context')
 initial=bytes.fromhex(workers['initial']);reply=native['bootstrap-response'][1][1:];final=bytes.fromhex(workers['final'])
 check(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest,'initial signature')
 check(ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+bootstrap_digest(b'initial-wire',initial),'response signature')
 check(final[:104]==b'QPBSF001'+ctx.digest+bootstrap_digest(b'initial-wire',initial)+bootstrap_digest(b'reply-wire',reply)
       and session==bootstrap_digest(b'session-id',final[:104]) and native['bootstrap-complete'][1]==b'\1'+session,'original transcript/session')
 grants=[]
 for index,now in [(1,210),(2,310)]:
  wire=(public/f'peer-renewal-{index}').read_bytes();target=(public/f'pin-peer-renewal-{index}-target').read_bytes()
  grant=grant_verify(wire,ctx.devices[1],ctx.family,ctx.policy_digest,target,now=now)
  check(grant.statement==(public/f'peer-renewal-{index}-statement').read_bytes()
        and grant.operation==(public/f'peer-renewal-{index}-operation').read_bytes(),'native/independent root statement')
  grants.append(grant)
 check(grants[0].successor.digest==grants[1].previous.digest and grants[0].successor_roster.checkpoint()==grants[1].predecessor_roster.checkpoint(),'two original lineage transitions')
 resigned=grant_verify((public/'peer-renewal-1-resigned').read_bytes(),ctx.devices[1],ctx.family,ctx.policy_digest,grants[0].successor_roster.checkpoint(),now=210)
 check(resigned.statement==grants[0].statement and resigned.operation==grants[0].operation,'semantic signed retry')
 check(workers['renewal-original-retry']==workers['renewal-resigned-retry']==grants[0].successor_roster.checkpoint().hex(),'first grant target')
 check(workers['second-renewal-retry']==grants[1].successor_roster.checkpoint().hex(),'second grant target')
 check(read(path/'upgrade-kill.request.json')['now']==210,'metadata upgrade after remote expiry')
 check(workers['upgrade-recovered']==5 and workers['same-original-ciphertext']==workers['old-send'],'original cached ciphertext after explicit upgrade/renewal')
 check(workers['same-original-plaintext']==workers['old-reverse-receive'] and workers['same-original-plaintext'][1]==b'original native reply'.hex(),'original plaintext retained')
 check(native['native-original-receive'][1]==b'\1original retained send' and native['native-renewed-receive'][1]==b'\1new independent message','native application plaintext')
 for label in ['same-original-ciphertext','same-original-plaintext','renewed-send','renewed-offer']:
  check(read(path/(label+'.request.json'))['now']==210,'actual independent post-expiry time')
 check(read(path/'second-renewal-retry.request.json')['now']==310,'second actual expiry interval')
 flights=[bytes.fromhex(workers['renewed-offer']),native['renewed-response'][1][1:],bytes.fromhex(workers['renewed-final']),native['renewed-receipt'][1][1:]]
 RekeyScope(ctx,session,0,genesis(session,ctx.digest)).public_completed(*flights)
 check(workers['renewed-confirm']==1,'actual renewed control completion')
 revoked=roster(ctx.devices[1].pin,(public/'peer-revoked-roster').read_bytes(),expected=(public/'pin-peer-revoked-target').read_bytes())
 check(not revoked.members and workers['revocation-exact-retry']==revoked.checkpoint().hex(),'signed empty revocation')
 status=workers['revoked-metadata'];check(status[0]==revoked.checkpoint().hex() and status[1]==grants[1].successor.digest.hex() and status[2]==grants[1].operation.hex() and status[3] is False,'retained revoked target')
 check(status==workers['expired-all-metadata'],'historical metadata unchanged')
 if row['reentrant']:check(any(x['case']=='reentrant-revocation-withholds-result' for x in row['direct_refusals']),'reentrant negative control')
 signed=0;challenges=set()
 if pin:
  enrolled=native['trusted-enrollment'][0];subject=enrolled[:96]
  check(len(enrolled)==128 and subject[32:]==ctx.witness.owner+ctx.witness.policy,'original witness subject')
  for attempt in row['witness_attempts']:
   label=attempt['case'];safe(label)
   request=(path/(label+'.request')).read_bytes();reply=(path/(label+'.reply')).read_bytes()
   check(sha(request)==attempt['request_sha256'] and sha(reply)==attempt['signed_reply_sha256'],'witness file hashes')
   check(native[label][0]==request and native[label][1]==b'\1'+reply and attempt['delivery']=='sent' and attempt['fault'] is None,'actual witness exchange')
   body=ctx.initiator.open(request,7,297);operation=Operation(body[200],body[201:])
   check(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==commitment(b'COMMAND',pin.binding+subject+operation.wire()),'witness signed scope')
   check(body[168:200].hex()==attempt['challenge'] and body[168:200] not in challenges,'unique challenged attempt');challenges.add(body[168:200])
   result=witness_verify(pin,subject,operation,body,reply);check(result.outcome in (1,2,3,5),'witness admits only expected outcomes');signed+=1
  check(native['witness-original-reopen'][1]==b'\1witness reopened','actual witness original reopen')
 profiles[name]={'workers':counts[0],'native_commands':counts[1],'actual_SIGKILL':kills,'direct_controls':counts[4],
                 'witness_signed_replies':signed,'unique_challenges':len(challenges),'root_grants_verified':3,'signed_rekey_flights':4,
                 'original_context':ctx.digest.hex(),'original_session':session.hex(),'revoked_checkpoint':status[0]}
report={'head':'54eda5836d42ed39f01e4957d4bec971cd1e8198','source_files':sources,'source_continuity':continuity(sources),
        'native_sha256':r['native_sha256'],'profiles':profiles,
        'scope':'Public exact wire/source/binary/PID/root-grant/target/operation/signature/original-output checks. Private codec, durable unchanged-head, direct reentrant no-output controls remain runtime assertions. Independent times210/310 are not the native counterparts fixed170 clock. Not local enrollment renewal, same-account joint authority, full installed/cross-host lifecycle, physical erasure, power-loss or PCS proof.'}
(out.parent/'PEER_LIFECYCLE_READBACK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(profiles))
