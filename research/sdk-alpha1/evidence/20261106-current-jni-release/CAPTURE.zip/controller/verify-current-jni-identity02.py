from pathlib import Path
import hashlib
import json
import os
import re
import sys
import zipfile

import continuity_android_contract as contract
import continuity_android_jni as jni
import continuity_c_consumer as c
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
PROFILE = sys.argv[1]
assert PROFILE in ['debug', 'release']
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
RAW = SOURCE / f'target/continuity-installed-jni-{PROFILE}-current'
OUT = REPO / 'target/continuity-current-jni-readback-5678' / PROFILE
prefix = 'android-jni-' + PROFILE + '-'
report = json.loads((RAW / 'CONTINUITY_PACKAGE.json').read_bytes())
android = json.loads((RAW / 'ANDROID_JNI_CONSUMER.json').read_bytes())
native = json.loads((RAW / 'C_CONSUMER.json').read_bytes())
assert report['android_jni_consumer'] == android and report['c_consumer'] == native
assert report['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (report['source_commit'], False)
assert report['kind'] == 'qperiapt.continuity_candidate_package_partition'
assert report['requested_consumers'] == ['Rust', 'C', 'AndroidJNI']
assert report['host_os'] == 'Darwin' and report['host_arch'] == 'arm64'
for value in [report, android, native]:
    assert value['build_profiles'] == [PROFILE] and value['partition_completed'] is True and value['completed'] is False
    assert value['release_claim_eligible'] is False
assert report['publication_performed'] is False and report['sources_unchanged'] is True
assert report['source_inputs'] == json.loads((RAW / 'sources-before.json').read_bytes()) == json.loads((RAW / 'sources-after.json').read_bytes())
assert package.source_inputs() == report['source_inputs']
assert {name: hashlib.sha256(data).hexdigest() for name, data in jni.source_files().items()} == android['source_hashes']
producer = SOURCE / 'target/sdk-020'
producer_snapshot = sdk.snapshot(producer / 'RUST_SDK_PACKAGE.json')
cohort = validate_report(producer_snapshot.data, report['rust_report_sha256'], producer_snapshot.sha256,
    report['source_inputs']['rust_workspace_sha256'])
package.verify_candidate_archive(RAW, report['archive'])
candidate_files = package.validate_candidate(sdk.snapshot(RAW / report['archive']['file']).data, set(report['archive']['files']))
outside = Path(json.loads((RAW / 'location.json').read_bytes())['path'])
assert not outside.is_relative_to(SOURCE)
resolutions = {}
for label, directory, lock_name, consumer_name, features, expected in [
    ('consumer-metadata', 'consumer', 'consumer-Cargo.lock', package.CONSUMER, frozenset({'connection-tls','control-tls'}), report['resolution']),
    ('c-metadata', 'c-consumer', 'c-consumer-Cargo.lock', c.NAME, c.FEATURES, native['resolution'])]:
    metadata = json.loads((RAW / (label + '.stdout')).read_bytes())
    consumer = outside / directory
    value = package.verify_resolution(metadata, consumer, (RAW / lock_name).read_bytes(),
        (package.CANDIDATE / 'Cargo.lock').read_bytes(), consumer_name=consumer_name, required_features=features)
    assert value == expected
    package.verify_candidate_files(consumer / 'packages' / f'{package.NAME}-{package.VERSION}', candidate_files)
    sdk.verify_consumed_sources(consumer, producer, cohort['crates'])
    resolutions[directory] = value
jar = RAW / 'continuity-android-classes.jar'
assert sdk.snapshot(jar).sha256 == android['jar_sha256']
with zipfile.ZipFile(jar) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == 131
    assert all(name.endswith('.class') and archive.read(name)[:8] == b'\xca\xfe\xba\xbe\x00\x00\x00\x37' for name in names)
assert jni.tool_identity(Path(android['tools']['root'])) == android['tools']

def command(label):
    row = json.loads((RAW / (prefix + label + '.json')).read_bytes())
    assert row['returncode'] == 0
    return row

boundary = command('boundary')['argv']
library_flags = [arg[len('-Djava.library.path='):] for arg in boundary if arg.startswith('-Djava.library.path=')]
assert len(library_flags) == 1
installed = Path(library_flags[0])
assert installed.is_relative_to(outside) and installed.name == PROFILE
row = android['profiles'][PROFILE]
target_command = command('policy-target-client')['argv']
assert target_command.count('-o') == 1
paths = {
    'native': installed / 'libq_periapt_continuity_c_consumer.dylib',
    'bridge': installed / 'libqperiapt_continuity_jni.dylib',
    'receiver': installed / 'qpc-c-client',
    'test': Path(command('execution')['argv'][0]),
    'policy_target_client': Path(target_command[target_command.index('-o') + 1]),
    'account_witness': Path(command('recovery-witness-0')['argv'][0]),
    'enrollment': Path(command('recovery-results')['argv'][0]),
}
binaries = {}
for label, path in paths.items():
    assert path.is_relative_to(outside)
    expected = row[label + '_sha256'] if label + '_sha256' in row else row['recovery_outcomes']['binaries'][label]
    actual = sdk.snapshot(path, maximum=c.MAX_BINARY)
    assert actual.sha256 == expected
    binaries[label] = {'path': str(path), 'bytes': actual.size, 'sha256': actual.sha256}
assert binaries['native']['sha256'] == native['execution'][PROFILE]['binaries']['C_library']['sha256']
assert binaries['receiver']['sha256'] == native['execution'][PROFILE]['binaries']['C_client']['sha256']
cp_index = boundary.index('-cp') + 1
classpath = boundary[cp_index].split(os.pathsep)
assert len(classpath) == 2 and Path(classpath[0]) == jar
test_classes = Path(classpath[1])
assert test_classes.is_relative_to(outside)
class_files = {p.relative_to(test_classes).as_posix(): sdk.snapshot(p).sha256 for p in test_classes.rglob('*.class')}
assert 'dev/qperiapt/continuity/android/BridgeProbe.class' in class_files
assert 'dev/qperiapt/continuity/android/CredentialBridgeProbe.class' in class_files
contract.verify_catalog((RAW / (prefix + 'test-catalog.stdout')).read_bytes())
observed_tests = []
invocations = []
for path in sorted(RAW.glob(prefix + '*.json')):
    value = json.loads(path.read_bytes())
    if 'argv' not in value or not value['argv'] or value['argv'][0] != str(paths['test']) or value['argv'][1:] == ['--list']:
        continue
    assert value['returncode'] == 0
    stdout = path.with_suffix('.stdout').read_text()
    passed = re.findall(r'^test (\S+) \.\.\. ok$', stdout, re.M)
    summary = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; (\d+) filtered out;', stdout, re.M)
    assert len(summary) == 1 and int(summary[0][0]) == len(passed) and int(summary[0][0]) + int(summary[0][1]) == len(contract.TESTS)
    observed_tests.extend(passed)
    invocations.append({'command': path.name, 'tests': passed})
shared = {name for name in contract.TESTS if name.startswith('fixture::')}
assert len(shared) == 3 and len(observed_tests) == len(set(observed_tests)) == 67
assert set(observed_tests) == contract.TESTS - shared and len(invocations) == 36
sdk.write_json(OUT / 'TEST_CLASSES.json', {'directory': str(test_classes), 'files': class_files})
result = {'identity_readback_passed': True, 'source_commit': report['source_commit'], 'profile': PROFILE,
    'final_report_sha256': sdk.snapshot(RAW / 'CONTINUITY_PACKAGE.json').sha256,
    'jni_report_sha256': sdk.snapshot(RAW / 'ANDROID_JNI_CONSUMER.json').sha256,
    'source_input_files': len(report['source_inputs']['files']), 'jni_source_files': len(android['source_hashes']),
    'sdk_report_sha256': report['rust_report_sha256'], 'candidate_archive_sha256': report['archive']['sha256'],
    'candidate_members': len(candidate_files), 'installed_graphs': resolutions, 'installed_sdk_trees_per_consumer': len(sdk.CONSUMER_CRATES),
    'jar_sha256': android['jar_sha256'], 'jar_classes': 131, 'test_class_files': len(class_files),
    'native_binaries': binaries, 'all_seven_native_binary_bytes_verified': True,
    'jni_harness_tests_passed': len(observed_tests), 'jni_harness_invocations': invocations,
    'shared_fixture_tests_excluded_from_jni_census': sorted(shared), 'boundary_checks': True,
    'full_debug_release_aggregate': False, 'art_executed': False, 'physical_device_executed': False,
    'release_claim_eligible': False, 'scope': 'Current completed installed host JNI profile source/package/graph/JAR/native-byte identity and exact test census; distinct from independent public replay, another profile and Android runtime/device.'}
sdk.write_json(OUT / 'IDENTITY.json', result)
print(json.dumps({k: result[k] for k in ['identity_readback_passed','source_input_files','jni_source_files','candidate_members','jar_classes','test_class_files','all_seven_native_binary_bytes_verified','jni_harness_tests_passed']}))
