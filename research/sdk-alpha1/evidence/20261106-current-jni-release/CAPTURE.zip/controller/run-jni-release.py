from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = Path.cwd()
control = source.parent
preflight = json.loads((control / 'JNI_RELEASE_PREFLIGHT.json').read_text())
assert preflight['source_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
assert preflight['git_dirty'] is False and preflight['previous_java_manifest_matched']
report = source / 'target/sdk-020/RUST_SDK_PACKAGE.json'
digest = hashlib.sha256(report.read_bytes()).hexdigest()
assert digest == '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d'
argv = ['sh', 'artifact/python-run.sh', 'artifact/continuity_package.py',
    '--report', str(report), '--report-sha256', digest,
    '--toolchain-root', '/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin',
    '--output', 'target/continuity-installed-jni-release-current',
    '--build-profile', 'release', '--with-c-consumer', '--with-android-jni-consumer',
    '--android-java-home', preflight['java_home'],
    '--witness-openssl-prefix', preflight['openssl_prefix']]
env = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3')
request = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'argv': argv, 'cwd': str(source), 'source_commit': preflight['source_commit'],
    'sdk_report_sha256': digest, 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'Original current-source installed Rust/C/host-JNI Release partition. No custom filtering, outer deadline, component-limit change, Android ART/device claim or full six-partition acceptance. Earlier failed ff072 aggregate remains failed and separate.'}
with (control / 'JNI_RELEASE_REQUEST.json').open('x') as stream:
    json.dump(request, stream, indent=2)
    stream.write('\n')
started = time.monotonic()
with (control / 'jni-release.stdout').open('xb') as stdout, (control / 'jni-release.stderr').open('xb') as stderr:
    result = subprocess.run(argv, cwd=source, env=env, stdout=stdout, stderr=stderr)
record = {'returncode': result.returncode, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'seconds': time.monotonic() - started,
    'stdout_sha256': hashlib.sha256((control / 'jni-release.stdout').read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256((control / 'jni-release.stderr').read_bytes()).hexdigest()}
with (control / 'JNI_RELEASE_RESULT.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
