from pathlib import Path
import ast
import hashlib
import json
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'target/continuity-current-sdk-5678/source'
RAW = SOURCE / 'target/continuity-installed-jni-release-current'
CHECKS = ROOT / 'release'
DEST = REPO / 'research/sdk-alpha1/evidence/20261106-current-jni-release'
DEST.mkdir()
identity = json.loads((CHECKS / 'IDENTITY.json').read_bytes())
replay = json.loads((CHECKS / 'replay-01/RESULT.json').read_bytes())
assert identity['identity_readback_passed'] and identity['all_seven_native_binary_bytes_verified']
assert replay['public_trace_readback_completed'] and len(replay['public_outcome_fields_replayed']) == 20
files = {}

def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), name
    files[name] = path

def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            add(prefix + '/' + path.relative_to(directory).as_posix(), path)

for name in ['CONTINUITY_PACKAGE.json', 'ANDROID_JNI_CONSUMER.json', 'ANDROID_RECOVERY_RELEASE.json',
             'C_CONSUMER.json', 'sources-before.json', 'sources-after.json', 'consumer-metadata.json',
             'consumer-metadata.stdout', 'consumer-metadata.stderr', 'consumer-Cargo.lock', 'c-metadata.json',
             'c-metadata.stdout', 'c-metadata.stderr', 'c-consumer-Cargo.lock', 'continuity-android-classes.jar']:
    add('raw/' + name, RAW / name)
for path in sorted(RAW.glob('android-jni-*')):
    if path.is_file() and path.suffix in ['.json', '.stdout', '.stderr']:
        add('raw/' + path.name, path)
copied = json.loads((CHECKS / 'replay-01/COPIED.json').read_bytes())
for row in copied.values():
    path = RAW / row['source']
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    name = 'raw/' + row['source']
    if name not in files:
        add(name, path)
prefix = 'android-jni-release-'
labels = ['retirement', 'roster-local', 'roster-peer', 'roster-witness', 'policy-roster',
    'recovery-first-use-public', 'recovery-witness-calls', 'recovery-result-calls']
labels += ['root-' + route for route in ['original', 'transition', 'bound_transition', 'adoption', 'noncommit']]
labels += ['policy-credential-' + carrier + '-' + trust for carrier in ['local', 'signed', 'tls'] for trust in ['fixed', 'recoverable']]
labels += ['joint-policy-' + trust + '-' + outcome for trust in ['fixed', 'recoverable'] for outcome in ['applied', 'pending']]
labels += ['witness-joint-' + carrier + '-' + trust + '-' + outcome for carrier in ['signed', 'tls'] for trust in ['fixed', 'recoverable'] for outcome in ['applied', 'closed']]
labels += ['joint-cycle-' + carrier + '-' + trust for carrier in ['local', 'signed', 'tls'] for trust in ['fixed', 'recoverable']]
labels += ['recovery-oracle-' + str(index) for index in range(4)]
for label in labels:
    directory = RAW / (prefix + label)
    assert directory.is_dir(), label
    tree('raw/' + directory.name, directory)
for label, row in identity['native_binaries'].items():
    path = Path(row['path'])
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    add('binaries/' + label + '/' + path.name, path)
tests = json.loads((CHECKS / 'TEST_CLASSES.json').read_bytes())
for name, expected in tests['files'].items():
    path = Path(tests['directory']) / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    add('test-classes/' + name, path)
for name in ['IDENTITY.json', 'TEST_CLASSES.json']:
    add('readback/' + name, CHECKS / name)
for name in ['RESULT.json', 'COPIED.json', 'REPLAYED.json']:
    add('readback/replay-01/' + name, CHECKS / 'replay-01' / name)
tree('diagnostic-failure/identity-attempt-01', CHECKS / 'identity-attempt-01')
for name in ['READER_SOURCE.json', 'MAPPER_PROVENANCE.json']:
    add('readback/' + name, ROOT / name)
for name in ['JNI_RELEASE_PREFLIGHT.json', 'JNI_RELEASE_REQUEST.json', 'JNI_RELEASE_RESULT.json']:
    add('controller/' + name, SOURCE.parent / name)
for label in ['jni-release', 'jni-release-controller', 'jni-release-replay', 'jni-release-identity', 'jni-release-identity02']:
    for extension in ['stdout', 'stderr']:
        add('controller/' + label + '.' + extension, SOURCE.parent / (label + '.' + extension))
report = json.loads((RAW / 'CONTINUITY_PACKAGE.json').read_bytes())
add('inputs/' + report['archive']['file'], RAW / report['archive']['file'])
producer = SOURCE / 'target/sdk-020'
sdk_report = json.loads((producer / 'RUST_SDK_PACKAGE.json').read_bytes())
add('inputs/RUST_SDK_PACKAGE.json', producer / 'RUST_SDK_PACKAGE.json')
names = ['q-periapt-mlkem-native-sys', 'q-periapt-core', 'q-periapt-backends', 'q-periapt-kem', 'q-periapt-sig',
    'q-periapt-policy', 'q-periapt-sdk', 'q-periapt-rustls', 'q-periapt-host-store']
for name in names:
    row = sdk_report['crates'][name]
    path = producer / 'crates' / row['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    add('inputs/' + row['file'], path)
tree('source/bindings/android/ContinuityPackageConsumer', SOURCE / 'bindings/android/ContinuityPackageConsumer')
tree('source/bindings/c/ContinuityPackageConsumer', SOURCE / 'bindings/c/ContinuityPackageConsumer')
drivers = ['replay-current-jni.py', 'verify-current-jni-identity.py', 'verify-current-jni-identity02.py', 'run-jni-release.py']
for name in drivers:
    add('controller/' + name, SOURCE / 'target/current-rust-readback' / name)
add('controller/capture-release.py', ROOT / 'capture-release.py')
queue = [SOURCE / 'target/current-rust-readback' / name for name in drivers]
seen = set()
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.is_relative_to(SOURCE / 'artifact'):
        add('source/' + path.relative_to(SOURCE).as_posix(), path)
    for node in ast.walk(ast.parse(path.read_bytes())):
        modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
        for module in modules:
            dependency = SOURCE / 'artifact' / (module.replace('.', '/') + '.py')
            if dependency.is_file():
                queue.append(dependency)
for name in ['python-run.sh', 'python-env.sh', 'python_bootstrap.py']:
    key = 'source/artifact/' + name
    if key not in files:
        add(key, SOURCE / 'artifact' / name)
manifest = {}
with zipfile.ZipFile(DEST / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.writestr(name, data)
with zipfile.ZipFile(DEST / 'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
data = (DEST / 'CAPTURE.zip').read_bytes()
assert len(data) < 95 * 1024**2
(DEST / 'FILES.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(DEST / 'IDENTITY.json').write_bytes((CHECKS / 'IDENTITY.json').read_bytes())
(DEST / 'PUBLIC_READBACK.json').write_bytes((CHECKS / 'replay-01/RESULT.json').read_bytes())
summary = {'source_commit': identity['source_commit'], 'profile': 'release', 'members': len(manifest), 'bytes': len(data),
    'sha256': hashlib.sha256(data).hexdigest(), 'source_inputs': identity['source_input_files'],
    'jni_harness_tests_passed': identity['jni_harness_tests_passed'], 'public_outcome_fields_replayed': 20,
    'all_seven_native_binary_bytes_retained': True, 'all_members_reread': True,
    'whole_debug_release_aggregate': False, 'art_executed': False, 'physical_device_executed': False,
    'release_claim_eligible': False,
    'scope': 'Current completed Release installed host JNI partition; source, actual archive/native/JAR/test-class identities, 20 original public readbacks and preserved diagnostic enum failure. No Debug join, native replay from capsule or Android runtime claim.'}
(DEST / 'CAPTURE.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
