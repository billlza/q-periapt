"""Apply only the fully tested candidate Rust files to the product worktree."""
from pathlib import Path
import hashlib
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
clone = stage/'source'
units = json.loads((stage/'unit-batches-15/RUN.json').read_text())
native = json.loads((stage/'NATIVE_READBACK_16.json').read_text())
sdk.require(units['completed'] and units['passed']==1015 and units['unexecuted']==0, 'complete unit qualification required')
sdk.require(native['completed'] and native['business_effects_checked']==250 and native['negative_controls_rejected']==260, 'native recovery qualification required')
patch = subprocess.check_output(['git','-C',str(clone),'diff'])
digest = hashlib.sha256(patch).hexdigest()
sdk.require(digest==units['source_patch_sha256']==native['source_patch_sha256'], 'qualified source patches differ')
sdk.require(not subprocess.check_output(['git','status','--porcelain']), 'preserve existing main worktree changes')
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base = units['source_base']
since = subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
sdk.require(all(p.startswith('research/sdk-alpha1/evidence/') for p in since), 'main product diverged from candidate base')
names = subprocess.check_output(['git','-C',str(clone),'diff','--name-only'],text=True).splitlines()
sdk.require(names and all(p.startswith('research/continuity-identity-candidate/src/') and p.endswith('.rs') for p in names), 'candidate includes files outside reviewed Rust scope')
sources = {name:(clone/name).read_bytes() for name in names}
sdk.require(all(b'qpc_growth_hook' not in data and b'observer_bytes' not in data for data in sources.values()), 'diagnostic hook must not enter product')
new_files = subprocess.check_output(['git','-C',str(clone),'diff','--diff-filter=A','--name-only'],text=True).splitlines()
sdk.require(len(new_files)==3 and set(new_files)<=set(names), 'unexpected new Rust file inventory')
for name,data in sources.items():
    target = root/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
quality = root/'artifact/codeql_rust_quality.py'
before = quality.read_text()
needle = 'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 695'
sdk.require(before.count(needle)==1, 'tracked-source inventory contract changed')
quality.write_text(before.replace(needle,'EXPECTED_TRACKED_RUST_SOURCE_COUNT = 698'))
subprocess.run(['git','add','--intent-to-add',*new_files],check=True)
tracked = subprocess.check_output(['git','ls-files','*.rs'],text=True).splitlines()
sdk.require(len(tracked)==698, 'actual tracked Rust inventory differs')
sdk.require(all((root/n).read_bytes()==data for n,data in sources.items()), 'admitted source differs from tested candidate')
subprocess.run(['git','diff','--check'],check=True)
sdk.write_json(stage/'ADMITTED_17.json',{'completed':True,'main_parent':head,'tested_source_base':base,
    'tested_source_patch_sha256':digest,'admitted_files':{n:hashlib.sha256(data).hexdigest() for n,data in sources.items()},
    'new_rust_files':new_files,'tracked_rust_files':698,'proof_input_mapping_unchanged':True,
    'unit_tests':1015,'native_business_effects':250,'release_claim_eligible':False})
print(json.dumps({'completed':True,'admitted_rust_files':len(names),'tracked_rust_files':698}))
