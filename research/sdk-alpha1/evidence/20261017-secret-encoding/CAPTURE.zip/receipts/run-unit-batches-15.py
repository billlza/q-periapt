"""Execute the entire frozen library inventory in disjoint bounded processes."""
from pathlib import Path
import json
import os
import re
import signal
import subprocess
import time
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
build = json.loads((stage/'UNIT_BUILD_OBSERVED_13.json').read_text())
binary = Path(build['binary'])
sdk.require(sdk.snapshot(binary, maximum=256*1024**2).sha256 == build['binary_sha256'], 'unit executable changed')
patch = (stage/'SOURCE_PATCH.diff').read_bytes()
sdk.require(sdk.snapshot(stage/'SOURCE_PATCH.diff').sha256 == build['source_patch_sha256'], 'candidate patch changed')
sdk.require(subprocess.check_output(['git','-C',str(stage/'source'),'diff']) == patch, 'candidate source changed')
out = stage/'unit-batches-15'
out.mkdir(mode=0o700)
listed = subprocess.run([str(binary),'--list'], capture_output=True, check=True, timeout=30)
(out/'inventory.txt').write_bytes(listed.stdout)
names = [line.removesuffix(': test') for line in listed.stdout.decode().splitlines() if line.endswith(': test')]
sdk.require(len(names) == len(set(names)) == 1015, 'complete library inventory differs')
batches = [names[i:i+16] for i in range(0,len(names),16)]
sdk.write_json(out/'INVENTORY.json', {'tests':names,'batches':batches,'source_patch_sha256':build['source_patch_sha256'],
                                    'binary_sha256':build['binary_sha256'],'filters_are_exact':True})
finished = []
started = time.monotonic()
summary = {'completed':False,'source_base':build['source_base'],'source_patch_sha256':build['source_patch_sha256'],
           'binary_sha256':build['binary_sha256'],'expected_tests':len(names),'batch_count':len(batches),
           'maximum_seconds_per_batch':900,'release_claim_eligible':False}

def progress(value):
    temporary = out/'.progress.tmp'
    temporary.write_text(json.dumps(value,indent=2)+'\n')
    os.replace(temporary,out/'PROGRESS.json')

try:
    for number, selected in enumerate(batches, 1):
        folder = out/f'batch-{number:02}'
        folder.mkdir()
        argv = [str(binary),'--test-threads=2','--exact',*selected]
        record = {'completed':False,'batch':number,'argv':argv,'tests':selected,'maximum_seconds':900}
        begin = time.monotonic()
        try:
            with (folder/'stdout').open('xb') as stdout, (folder/'stderr').open('xb') as stderr:
                with subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True) as process:
                    record['pid'] = process.pid
                    sdk.write_json(folder/'STARTED.json',record)
                    progress({'running_batch':number,'pid':process.pid,'passed_tests':len(finished),'total_tests':len(names)})
                    try:
                        code = process.wait(timeout=900)
                    except subprocess.TimeoutExpired:
                        record['timed_out'] = True
                        os.killpg(process.pid,signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid,signal.SIGKILL)
                            process.wait(timeout=5)
                        raise
            record['returncode'] = code
            # Child-process tests can print their own summaries. The final
            # summary is the parent invocation, whose exact filter set is sealed.
            results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
                                 (folder/'stdout').read_text())
            sdk.require(code == 0 and bool(results), 'native batch failed; raw output retained')
            sdk.require(tuple(map(int,results[-1])) == (len(selected),0,0,0,len(names)-len(selected)), 'batch inventory incomplete')
            sdk.require(subprocess.check_output(['git','-C',str(stage/'source'),'diff']) == patch, 'candidate changed during tests')
            finished.extend(selected)
            record.update(completed=True,passed=len(selected),failed=0,ignored=0)
        except BaseException as error:
            record['failure'] = repr(error)
            raise
        finally:
            record['elapsed_seconds'] = time.monotonic()-begin
            sdk.write_json(folder/'RUN.json',record)
        progress({'completed_batch':number,'passed_tests':len(finished),'total_tests':len(names)})
        print(json.dumps({'batch':number,'passed':len(finished),'total':len(names),'elapsed_seconds':record['elapsed_seconds']}),flush=True)
    sdk.require(finished == names and len(set(finished)) == len(names), 'complete suite union differs')
    summary.update(completed=True,passed=len(finished),failed=0,ignored=0,unexecuted=0)
except BaseException as error:
    summary['failure'] = repr(error)
    raise
finally:
    summary.update(elapsed_seconds=time.monotonic()-started,completed_tests=len(finished))
    sdk.write_json(out/'RUN.json',summary)
print(json.dumps({'completed':True,'passed':len(finished),'elapsed_seconds':summary['elapsed_seconds']}),flush=True)
