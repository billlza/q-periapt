"""Check the admitted product source without altering compiler or lint contracts."""
from pathlib import Path
import json
import os
import subprocess
import rust_sdk_profile as sdk
from codeql_rust_profile import ProfileRun

root = Path.cwd()
stage = Path(__file__).resolve().parent
admitted = json.loads((stage/'ADMITTED_17.json').read_text())
for name,digest in admitted['admitted_files'].items():
    sdk.require(sdk.snapshot(root/name).sha256==digest,'admitted source changed before checks')
before = subprocess.check_output(['git','diff'])
toolchain = root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
env = {k:v for k,v in os.environ.items() if k not in {'RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS'}}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',
           CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_BUILD_JOBS='1',
           CARGO_TARGET_DIR=str(root/'target/continuity-session-cost-20261015/native-target-07'),
           PATH=str(toolchain/'bin')+':'+os.environ['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(toolchain/'lib'))
manifest = root/'research/continuity-identity-candidate/Cargo.toml'
run = ProfileRun(root,stage/'main-checks-18',root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
run.command('compiler',[str(toolchain/'bin/rustc'),'-vV'],seconds=30)
run.command('format',[str(toolchain/'bin/cargo'),'fmt','--manifest-path',str(manifest),'--','--check'],seconds=90)
run.command('clippy',[str(toolchain/'bin/cargo'),'clippy','--locked','--offline','--all-targets','--all-features',
                     '--manifest-path',str(manifest),'--','-D','warnings'],seconds=900)
minimum = Path('/Users/bill/.rustup/toolchains/1.90.0-aarch64-apple-darwin')
env.update(PATH=str(minimum/'bin')+':'+os.environ['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(minimum/'lib'),
           CARGO_TARGET_DIR=str(stage/'minimum-target-18'))
msrv = ProfileRun(root,stage/'minimum-checks-18',root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
version = msrv.command('compiler',[str(minimum/'bin/rustc'),'-vV'],seconds=30)
sdk.require(version.startswith(b'rustc 1.90.0 '),'minimum compiler differs')
msrv.command('check',[str(minimum/'bin/cargo'),'check','--locked','--offline','--all-features','--lib',
                      '--manifest-path',str(manifest)],seconds=900)
sdk.require(subprocess.check_output(['git','diff'])==before,'source changed during checks')
sdk.write_json(stage/'MAIN_CHECKED_18.json',{'completed':True,'admitted_source_patch_sha256':admitted['tested_source_patch_sha256'],
    'source_files':admitted['admitted_files'],'format':True,'clippy_all_targets_all_features':True,
    'minimum_rust':'1.90.0','minimum_all_features_lib':True,'release_claim_eligible':False})
print('Admitted source formatting, strict Clippy and Rust1.90 all-feature library check passed.',flush=True)
