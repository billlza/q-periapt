"""Build an isolated observer against the unchanged current enrolled-owner source."""
from pathlib import Path
import json, os, subprocess, tomllib
import rust_sdk_profile as sdk
from codeql_rust_profile import ProfileRun
root=Path.cwd(); stage=Path(__file__).resolve().parent; fixture=stage/'native-fixture'
tools=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin'
env=dict(os.environ, CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',
    CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_BUILD_JOBS='1',
    CARGO_TARGET_DIR=str(root/'target/continuity-session-cost-20261015/native-target-07'),
    PATH=str(tools/'bin')+':'+os.environ['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(tools/'lib'))
clone=stage/'source'
run=ProfileRun(root,stage/'native-build-12',root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
sdk.require(not run.command('main-clean',['git','status','--porcelain'],seconds=30),'main dirty')
main_head=run.command('main-head',['git','rev-parse','HEAD'],seconds=30).decode().strip()
head=run.command('source-base',['git','-C',str(clone),'rev-parse','HEAD'],seconds=30).decode().strip()
changed=run.command('main-since-base',['git','diff','--name-only',head,main_head],seconds=30).decode().splitlines()
sdk.require(all(p.startswith('research/sdk-alpha1/evidence/') for p in changed),'main product diverged from isolated base')
fixture_files={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()}
patch=subprocess.check_output(['git','-C',str(clone),'diff'])
sdk.require(patch==(stage/'SOURCE_PATCH.diff').read_bytes(),'source patch differs')
run.command('compiler',[str(tools/'bin/rustc'),'-vV'],seconds=30)
run.command('metadata',[str(tools/'bin/cargo'),'metadata','--locked','--offline','--format-version=1','--manifest-path',str(fixture/'Cargo.toml')],seconds=120)
def registry(path): return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
sdk.require(registry(fixture/'Cargo.lock') <= registry(root/'Cargo.lock') | registry(root/'research/continuity-identity-candidate/Cargo.lock'),'native observer registry drift')
sdk.write_json(stage/'NATIVE_BUILD_STARTED_12.json',{'pid':os.getpid(),'source_base':head,'main_head':main_head,'fixture_files':fixture_files,'source_patch_sha256':sdk.snapshot(stage/'SOURCE_PATCH.diff').sha256})
raw=run.command('compile',[str(tools/'bin/cargo'),'test','--locked','--offline','--release','--test','journal_capacity','--no-run','--message-format=json','--manifest-path',str(fixture/'Cargo.toml')],seconds=900)
rows=[json.loads(line) for line in raw.splitlines()]
binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='journal_capacity']
sdk.require(len(binaries)==1,'library test executable ambiguous')
sdk.require(fixture_files=={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()},'native observer changed')
sdk.require(patch==subprocess.check_output(['git','-C',str(clone),'diff']),'source changed during build')
sdk.require(not run.command('final-main-clean',['git','status','--porcelain'],seconds=30),'main changed')
sdk.require(run.command('final-main-head',['git','rev-parse','HEAD'],seconds=30).decode().strip()==main_head,'main head changed')
sdk.write_json(stage/'NATIVE_BUILD_OBSERVED_12.json',{'completed':True,'source_base':head,'main_head':main_head,'fixture_files':fixture_files,'source_patch_sha256':sdk.snapshot(stage/'SOURCE_PATCH.diff').sha256,'binary':binaries[0],'binary_sha256':sdk.snapshot(Path(binaries[0]),maximum=256*1024**2).sha256,'tests_executed':False,'release_claim_eligible':False})
print('Native capacity observer built; runtime remains pending.',flush=True)
