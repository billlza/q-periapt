"""Apply one observed Ready-fork or generation-origin method per MAIN leaf."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

W = Path(__file__).resolve().parent
stage, out = (Path(p).resolve() for p in sys.argv[1:])
assert not out.exists()
cap = json.loads((stage / 'CAPTURE.json').read_text())
assert cap['failure'] is None and cap['method_lists_complete']
source = (stage / 'model.spthy').read_bytes()
rows = []
for page, row in enumerate(cap['reads']):
    methods = [' '.join(m['text'].split()) for m in row['methods']]
    ready = []
    pattern = r"^solve\( PositionedPhaseState\( [^,]+, ~sid, '(?P<role>[AB])', %n, 'Ready', .* ▶₀ (?P<node>#[A-Za-z_0-9.]+) \)$"
    for index, method in enumerate(methods, 1):
        match = re.fullmatch(pattern, method)
        if match is not None:
            ready.append((index, match['role'], match['node']))
    e = [item for item in ready if item[2] == '#e']
    assert len(e) == 1
    counterparts = [item for item in ready if item[1] == e[0][1] and item[2] != '#e']
    if counterparts:
        index = e[0][0]
        reason = 'source the response Ready token sharing a role and epoch with a generation Ready token'
        counterpart_indices = [item[0] for item in counterparts]
    else:
        origins = [i for i, method in enumerate(methods, 1)
                   if method.startswith('solve( (∃ #leaked.')
                   and "EntropyLeak( ~sid, (%n%+%1), 'generation' )" in method
                   and 'CapturedPhase( ~sid,' in method]
        assert len(origins) == 1
        assert len(ready) == 2 and {item[2] for item in ready} == {'#g', '#e'}
        index = origins[0]
        reason = 'expand generation-secret origin after the actual generation event has aligned with post-cut g'
        counterpart_indices = []
    method = methods[index - 1]
    rows.append({'page_index': page, 'method_index': index,
                 'case_path': row['case_path'],
                 'method_sha256': hashlib.sha256(method.encode()).hexdigest(),
                 'reason': reason, 'same_role_ready_counterpart_indices': counterpart_indices})
assert 1 <= len(rows) <= 32
spec = {'target': 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy',
        'input_sha256': hashlib.sha256(source).hexdigest(), 'selected': rows}
selection = out.with_suffix('.selection.json')
with selection.open('x') as handle:
    handle.write(json.dumps(spec, indent=2) + '\n')
result = subprocess.run([sys.executable, str(W / 'apply_observed_proof_methods.py'),
                         str(stage), str(selection), str(out)], check=False)
if result.returncode:
    raise SystemExit(result.returncode)
print(json.dumps({'selected': len(rows), 'reasons': {
    reason: sum(row['reason'] == reason for row in rows)
    for reason in sorted({row['reason'] for row in rows})}}))
