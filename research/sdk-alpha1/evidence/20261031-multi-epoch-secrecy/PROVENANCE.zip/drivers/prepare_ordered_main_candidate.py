"""Assemble the full proof chain for its first independent joint acceptance check."""
from pathlib import Path
import hashlib
import json
import re
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory, uncomment, _TOKEN
from continuity_proof_fragments import _lemma_span, case_spans, _is_hole

ORDERED = 'no_strictly_ordered_duplicate_local_phase'
PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
MAIN = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
ordered_stage = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
assert not output.exists()

def closed(stage, target):
    report = json.loads((stage / 'RESULT.json').read_text())
    assert 'failure' not in report and report['returncode'] == 0
    assert report['results'][target]['status'] == 'verified'
    raw = (stage / 'output.spthy').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == report['output_sha256']
    assert b'invalid proof step' not in raw
    text = raw.decode()
    assert not any(_is_hole(text[a:z]) for a, z in case_spans(raw, target).values())
    return raw, report

ordered_preparation = json.loads((ordered_stage / 'PREPARATION.json').read_text())
assert ordered_preparation['source_kind'] == 'unaccepted assembled proof candidate'
assert not ordered_preparation['security_proof_verified']
ordered = (ordered_stage / 'candidate.spthy').read_bytes()
assert hashlib.sha256(ordered).hexdigest() == ordered_preparation['candidate_sha256']
assert b'invalid proof step' not in ordered
assert not any(_is_hole(ordered.decode()[a:z]) for a, z in case_spans(ordered, ORDERED).values())
ordered_state = {'mode': 'all-traces', 'status': 'unaccepted assembled proof candidate'}
phase, phase_report = closed(W / 'phase-from-ordered-diagnostic-03', PHASE)
assert phase_report['results'][PHASE]['steps'] == 4
main, main_report = closed(W / 'main-phase-integration-diagnostic-12', MAIN)
assert main_report['results'][MAIN]['steps'] == 508
assert theory(ordered) == theory(phase)
source = (W / 'proof/main-phase-closed-full-01.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == '8f0f5d379076e9b8184cc82f2e75ee673949e23629eb50108604effa7dcf0390'
old = theory(source)
assert len(old.queries) == 39 and old.queries[0].name == PHASE
assert old.prefix == theory(ordered).prefix
text = source.decode()
starts = [(q.name, re.search(r'^lemma ' + q.name + r'\b', text, re.M).start()) for q in old.queries]
end = re.search(r'^end\s*$', text, re.M).start()
blocks = {name: text[pos:starts[i + 1][1] if i + 1 < len(starts) else end]
          for i, (name, pos) in enumerate(starts)}
for name, block in list(blocks.items()):
    if name == PHASE:
        a, z = _lemma_span(text, name)
        offset = dict(starts)[name]
        a, z = a - offset, z - offset
        assert 0 <= a < z <= len(block)
        p, q = _lemma_span(phase.decode(), name)
        blocks[name] = block[:a] + phase.decode()[p:q] + block[z:]
        continue
    header = re.match(r'^(lemma\s+' + name + r')\s*(\[[^]]*\])?\s*:', block)
    assert header is not None
    attrs = header[2][1:-1] if header[2] else ''
    attrs += (', ' if attrs else '') + 'hide_lemma=' + ORDERED
    blocks[name] = 'lemma ' + name + ' [' + attrs + ']:' + block[header.end():]
ot = ordered.decode()
begin = re.search(r'^lemma ' + ORDERED + r'\b', ot, re.M).start()
stop = re.search(r'^lemma ' + PHASE + r'\b', ot, re.M).start()
assert begin < stop
full = text[:starts[0][1]] + ot[begin:stop] + ''.join(blocks[q.name] for q in old.queries) + text[end:]
contract = theory(full.encode())
assert contract.prefix == old.prefix and len(contract.queries) == 40
assert contract.queries[0] == theory(ordered).by_name[ORDERED]
assert [q.name for q in contract.queries[1:]] == [q.name for q in old.queries]
assert sum(q.reusable for q in contract.queries) == 24
for query in old.queries:
    current = contract.by_name[query.name]
    assert (current.mode, current.formula) == (query.mode, query.formula)
    extra = ((',',) if query.attributes else ()) + ('hide_lemma', '=', ORDERED)
    assert current.attributes == (query.attributes if query.name == PHASE else query.attributes + extra)
    if query.name == PHASE:
        continue
    a, z = _lemma_span(text, query.name)
    p, q = _lemma_span(full, query.name)
    assert _TOKEN.findall(uncomment(text[a:z])) == _TOKEN.findall(uncomment(full[p:q]))
for target in [ORDERED, PHASE, MAIN]:
    assert not any(_is_hole(full[a:z]) for a, z in case_spans(full.encode(), target).values())
with output.open('xb') as handle:
    handle.write(full.encode())
record = {'ordered_stage': str(ordered_stage),
          'ordered_result': ordered_state,
          'ordered_sha256': hashlib.sha256(ordered).hexdigest(),
          'phase_result': phase_report['results'][PHASE],
          'phase_sha256': hashlib.sha256(phase).hexdigest(),
          'main_result': main_report['results'][MAIN],
          'main_sha256': hashlib.sha256(main).hexdigest(),
          'full_input_sha256': hashlib.sha256(full.encode()).hexdigest(),
          'query_count': 40, 'reusable_count': 24,
          'old_39_formulas_modes_and_relative_order_preserved': True,
          'other_38_full_proof_command_sequences_preserved': True,
          'phase_proof_factored_from_292_to_4': True,
          'ordered_visible_only_to_phase': True,
          'phase_visible_to_main_and_specific_ready': True,
          'operational_model_unchanged': True,
          'complete_joint_replay_required': True, 'main_theorem_verified': False,
          'goal_complete': False}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
