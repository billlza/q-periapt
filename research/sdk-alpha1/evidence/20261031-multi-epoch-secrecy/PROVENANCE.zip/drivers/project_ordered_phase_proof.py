"""Test thirteen explicit projections of an existing proof under an ordered goal.

This creates an unaccepted candidate only. The original uniqueness query and
complete original proof are retained. The fixed prover must check the new
induction obligation and every projected branch; no acceptance guard changes.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import _lemma_span

PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
ORDERED = 'no_strictly_ordered_duplicate_local_phase'
old = (W / 'local-phase-unique-diagnostic-19/output.spthy').read_bytes()
assert hashlib.sha256(old).hexdigest() == '3b5361acba2066b9f0974e3cdb404457e46513689da661e59e60ca11026d01ff'
t = old.decode()
a, z = _lemma_span(t, PHASE)
body = t[a:z]
body = body[body.index('\ninduction\n') + 1:]
lines = body.splitlines(keepends=True)
edits = []
for start, line in enumerate(lines):
    if 'solve( (last(' not in line:
        continue
    indent = len(line) - len(line.lstrip())
    assert line.strip() in (
        'solve( (last(#right))  ∥ (last(#left))  ∥ (#left = #right) )',
        'solve( (last(#left))  ∥ (last(#right)) )')
    end = next(i for i in range(start + 1, len(lines))
               if lines[i] == ' ' * indent + 'qed\n')
    alternatives = [i for i in range(start + 1, end)
                    if re.fullmatch(' ' * (indent + 2) + r'case case_[123]\n', lines[i])]
    desired = 1 if line.strip().startswith('solve( (last(#right))') else 2
    chosen = next(i for i in alternatives if lines[i].strip() == f'case case_{desired}')
    stop = next((i for i in range(chosen + 1, end)
                 if lines[i] == ' ' * indent + 'next\n'), end)
    selected = lines[chosen + 1:stop]
    assert selected and all(not s.strip() or s.startswith(' ' * (indent + 2)) for s in selected)
    replacement = ''.join(s[2:] if s.strip() else s for s in selected)
    edits.append((start, end + 1, replacement,
                  {'original_line': start + 1, 'selected_case': desired,
                   'original_method': line.strip(),
                   'selected_last_event': '#right',
                   'retained_subtree_sha256': hashlib.sha256(''.join(selected).encode()).hexdigest()}))
assert len(edits) == 13 and len(edits) <= 32
assert all(edits[i][1] <= edits[i + 1][0] for i in range(len(edits) - 1))
for start, end, replacement, _ in reversed(edits):
    lines[start:end] = [replacement]
projected = ''.join(lines)
assert 'solve( (last(' not in projected
assert 'by sorry' not in projected
source = (W / 'ordered-phase-diagnostic-06/output.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == '860795e889f94a8083e74d77824be730812d50d89e9c38fdb1ab8c18c1c94dc9'
text = source.decode()
a, z = _lemma_span(text, ORDERED)
new = (text[:a] + '\n' + projected + '\n' + text[z:]).encode()
assert theory(new) == theory(source)
for query in theory(source).queries:
    if query.name == ORDERED:
        continue
    i, j = _lemma_span(text, query.name)
    x, y = _lemma_span(new.decode(), query.name)
    assert text[i:j] == new.decode()[x:y]
output = W / 'proof/ordered-phase-projection-01.spthy'
with output.open('xb') as handle:
    handle.write(new)
record = {'original_closed_diagnostic_sha256': hashlib.sha256(old).hexdigest(),
          'current_ordered_input_sha256': hashlib.sha256(source).hexdigest(),
          'candidate_sha256': hashlib.sha256(new).hexdigest(),
          'projections': [row for _, _, _, row in edits],
          'old_query_and_full_proof_retained': True,
          'current_40_query_contracts_and_model_unchanged': True,
          'other_39_diagnostic_proof_bodies_unchanged': True,
          'new_proof_methods_invented': False,
          'unverified_hypothesis': 'In the ordered counterexample left < right, only right can be the last event; the projected old induction bodies may suffice for the new induction hypothesis.',
          'fixed_prover_replay_required': True,
          'resource_limits_unchanged': True, 'security_proof_verified': False}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'candidate_sha256': record['candidate_sha256'],
                  'explicit_case_projections': len(edits),
                  'verified': False}))
