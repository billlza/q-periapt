"""Isolate an ordered duplicate-phase candidate; retain all existing propositions."""
from pathlib import Path
import hashlib
import json
import re
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory, uncomment, _TOKEN
from continuity_proof_fragments import _lemma_span

TARGET = 'no_strictly_ordered_duplicate_local_phase'
PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
source = (W / 'proof/local-phase-factored-full-01.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == '945fedc5ab8d79cee77c67d0302516f4d9e8db9bf6443f6a46d5a3f7ec121806'
old = theory(source)
assert len(old.queries) == 39 and TARGET not in old.by_name
text = source.decode()
starts = [(q.name, re.search(r'^lemma ' + q.name + r'\b', text, re.M).start()) for q in old.queries]
end = re.search(r'^end\s*$', text, re.M).start()
blocks = {name: text[pos:starts[i + 1][1] if i + 1 < len(starts) else end]
          for i, (name, pos) in enumerate(starts)}
hidden = [q.name for q in old.queries if q.reusable]
assert len(hidden) == 23
attrs = 'reuse, use_induction, ' + ', '.join('hide_lemma=' + name for name in hidden)
addition = '''lemma TARGET [ATTRS]:
  all-traces
  "∀ owner_left owner_right s role %epoch phase #left #right.
    ((PhaseMarker(owner_left, s, role, %epoch, phase) @ #left) ∧
     (PhaseMarker(owner_right, s, role, %epoch, phase) @ #right)) ⇒
    ¬ (#left < #right)"
by induction

'''.replace('TARGET', TARGET).replace('ATTRS', attrs)
for name, block in list(blocks.items()):
    if name == PHASE:
        continue
    header = re.match(r'^(lemma\s+' + name + r')\s*(\[[^]]*\])?\s*:', block)
    assert header is not None
    attrs = header[2][1:-1] if header[2] else ''
    attrs += (', ' if attrs else '') + 'hide_lemma=' + TARGET
    blocks[name] = 'lemma ' + name + ' [' + attrs + ']:' + block[header.end():]
full = text[:starts[0][1]] + addition + ''.join(blocks[q.name] for q in old.queries) + text[end:]
contract = theory(full.encode())
assert contract.prefix == old.prefix and len(contract.queries) == 40
assert [q.name for q in contract.queries[1:]] == [q.name for q in old.queries]
for query in old.queries:
    new = contract.by_name[query.name]
    assert (new.mode, new.formula) == (query.mode, query.formula)
    a, z = _lemma_span(text, query.name)
    x, y = _lemma_span(full, query.name)
    assert _TOKEN.findall(uncomment(text[a:z])) == _TOKEN.findall(uncomment(full[x:y]))
template = W / 'proof/ordered-phase-full-template-01.spthy'
with template.open('xb') as handle:
    handle.write(full.encode())
for query in reversed(old.queries):
    a, z = _lemma_span(full, query.name)
    full = full[:a] + '\nby sorry\n\n' + full[z:]
assert theory(full.encode()) == contract
output = W / 'proof/ordered-phase-diagnostic-01.spthy'
with output.open('xb') as handle:
    handle.write(full.encode())
record = {'source_sha256': hashlib.sha256(source).hexdigest(),
          'output_sha256': hashlib.sha256(full.encode()).hexdigest(),
          'full_template_sha256': hashlib.sha256(template.read_bytes()).hexdigest(),
          'new_unproved_candidate': TARGET, 'existing_phase_proposition_retained': PHASE,
          'query_count': 40, 'old_39_formulas_modes_and_relative_order_unchanged': True,
          'operational_model_unchanged': True, 'old_proofs_retained_in_template': True,
          'ordered_candidate_hidden_from_all_old_queries_except': PHASE,
          'ordered_candidate_has_no_visible_reusable_dependencies': True,
          'hypothesis': 'Orienting the counterexample left < right may avoid mirrored last-event branches; deriving the existing phase uniqueness proposition remains mandatory.',
          'diagnostic_only': True, 'complete_joint_replay_required': True,
          'main_theorem_verified': False, 'resource_limits_unchanged': True}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
