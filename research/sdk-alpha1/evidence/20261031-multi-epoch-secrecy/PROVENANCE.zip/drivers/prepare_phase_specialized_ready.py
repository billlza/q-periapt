"""Prepare a same-formula derivation of the old specific Ready lemma from phase uniqueness."""
from pathlib import Path
import hashlib
import json
import re
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory, uncomment, _TOKEN
from continuity_proof_fragments import _lemma_span

PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
TARGET = 'first_responder_ready_event_is_unique'
source = (W / 'proof/local-phase-unique-full-01.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == 'fe34821e546c4d64fbec12068b8c3e1e29f0d7e8818409981e8be5c8013c6f32'
phase_result = json.loads((W / 'local-phase-unique-diagnostic-19/RESULT.json').read_text())
assert phase_result['returncode'] == 0 and phase_result['results'][PHASE]['status'] == 'verified'
assert phase_result['output_sha256'] == '3b5361acba2066b9f0974e3cdb404457e46513689da661e59e60ca11026d01ff'
old = theory(source)
assert len(old.queries) == 39 and old.queries[-1].name == PHASE
text = source.decode()
starts = [(q.name, re.search(r'^lemma ' + q.name + r'\b', text, re.M).start()) for q in old.queries]
end = re.search(r'^end\s*$', text, re.M).start()
blocks = {name: text[pos:starts[i + 1][1] if i + 1 < len(starts) else end]
          for i, (name, pos) in enumerate(starts)}
hidden = []
for name, block in list(blocks.items()):
    if name not in (PHASE, TARGET):
        header = re.match(r'^(lemma\s+' + name + r')\s*(\[[^]]*\])?\s*:', block)
        assert header is not None
        attrs = header[2][1:-1] if header[2] else ''
        attrs += (', ' if attrs else '') + 'hide_lemma=' + PHASE
        blocks[name] = 'lemma ' + name + ' [' + attrs + ']:' + block[header.end():]
        hidden.append(name)
order = [PHASE] + [q.name for q in old.queries if q.name != PHASE]
full = text[:starts[0][1]] + ''.join(blocks[name] for name in order) + text[end:]
contract = theory(full.encode())
assert contract.prefix == old.prefix
assert {q.name: (q.mode, q.formula) for q in contract.queries} == {q.name: (q.mode, q.formula) for q in old.queries}
assert [q.name for q in contract.queries if q.name != PHASE] == [q.name for q in old.queries if q.name != PHASE]
assert contract.by_name[PHASE] == old.by_name[PHASE] and contract.by_name[TARGET] == old.by_name[TARGET]
for q in old.queries:
    a, z = _lemma_span(text, q.name)
    x, y = _lemma_span(full, q.name)
    assert _TOKEN.findall(uncomment(text[a:z])) == _TOKEN.findall(uncomment(full[x:y]))
template = W / 'proof/phase-specialized-ready-full-template.spthy'
with template.open('xb') as stream:
    stream.write(full.encode())
for query in reversed(contract.queries):
    start, stop = _lemma_span(full, query.name)
    full = full[:start] + ('\nby simplify\n\n' if query.name == TARGET else '\nby sorry\n\n') + full[stop:]
assert theory(full.encode()) == contract
output = W / 'proof/phase-specialized-ready-diagnostic-01.spthy'
with output.open('xb') as stream:
    stream.write(full.encode())
record = {
    'source_sha256': hashlib.sha256(source).hexdigest(),
    'output_sha256': hashlib.sha256(full.encode()).hexdigest(),
    'full_template_sha256': hashlib.sha256(template.read_bytes()).hexdigest(),
    'query_count': 39, 'all_formulas_modes_and_operational_model_unchanged': True,
    'phase_moved_before_all_old_queries': True,
    'phase_has_no_visible_prior_reuse': True,
    'phase_hidden_from_all_old_queries_except': TARGET,
    'explicitly_hidden_from': hidden,
    'all_old_38_relative_query_order_preserved': True,
    'all_proof_programs_retained_in_template': True,
    'old_285_step_specific_proof_retained': True,
    'diagnostic_omits_non_target_proof_bodies': True,
    'complete_joint_replay_required': True,
    'main_secrecy_proved': False,
    'reason': 'Factor the existing special-case Ready argument through the stronger phase invariant; no new proposition, rule, assumption or larger resource budget.',
}
with output.with_suffix('.preparation.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'explicitly_hidden_from'}))
