"""Assemble the last temporal case from its captured method and symmetric donor.

The UI navigated to the next lemma after the final application, so the session
guard stopped before its last download. This remains an unaccepted candidate
and must pass the unchanged full dependency checker.
"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import case_spans, _is_hole

TARGET = 'no_strictly_ordered_duplicate_local_phase'
stage = W / 'ordered-phase-temporal-session-01'
report = json.loads((stage / 'RESULT.json').read_text())
assert report['failure']['type'] == 'AssertionError'
assert len(report['requests']) == 48 and len(report['mutations']) == 15
source = (stage / 'candidate.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == '8c4a62296df83687d7882349e58eac55759196e10fc976872351f9747b9e166f'
assert source == (stage / 'response-45.raw').read_bytes()
for i in [45, 46, 47]:
    assert hashlib.sha256((stage / f'response-{i:02}.raw').read_bytes()).hexdigest() == report['requests'][i]['raw_sha256']
redirect = json.loads((stage / 'response-47.raw').read_text())['redirect']
assert redirect == '/thy/trace/17/overview/proof/local_phase_event_is_unique_per_role_epoch_and_phase'

class Methods(HTMLParser):
    def __init__(self):
        super().__init__()
        self.items, self.current = [], None
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and 'proof-method' in attrs.get('class', '').split():
            self.current = {'href': attrs['href'], 'text': ''}
    def handle_data(self, data):
        if self.current is not None:
            self.current['text'] += data
    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.items.append(self.current)
            self.current = None

methods = Methods()
methods.feed(json.loads((stage / 'response-46.raw').read_text())['html'])
selected = [m for m in methods.items if m['href'] == report['requests'][47]['path']]
assert len(selected) == 1
method = ' '.join(selected[0]['text'].split())
assert method == 'solve( (#vr.6 = #vr.5) ∥ (#vr.5 < #vr.6) )'
text = source.decode()
spans = case_spans(source, TARGET)
pending = [p for p, (a, z) in spans.items() if _is_hole(text[a:z])]
assert len(pending) == 1
path = pending[0]
assert path.count('Setup_case_2') == 1
donor = tuple('Setup_case_1' if part == 'Setup_case_2' else part for part in path)
a, z = spans[donor]
body = text[a:z]
assert ' '.join(body.splitlines()[0].split()) == method
assert body.count('by contradiction') == 2 and 'sorry' not in body
x, y = spans[path]
candidate = (text[:x] + body + text[y:]).encode()
assert theory(candidate) == theory(source)
assert b'invalid proof step' not in candidate
assert not any(_is_hole(candidate.decode()[a:z]) for a, z in case_spans(candidate, TARGET).values())
out = W / 'ordered-phase-final-candidate'
out.mkdir(exist_ok=False)
(out / 'candidate.spthy').write_bytes(candidate)
record = {'source_kind': 'unaccepted assembled proof candidate',
          'source_session': stage.name, 'source_sha256': hashlib.sha256(source).hexdigest(),
          'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
          'last_observed_method': method, 'last_method_href': selected[0]['href'],
          'last_observed_navigation': redirect,
          'remaining_case': list(path), 'kernel_generated_symmetric_donor': list(donor),
          'donor_body_sha256': hashlib.sha256(body.encode()).hexdigest(),
          'candidate_open_cases': 0,
          'explanation': 'The sixteenth UI method navigated to the next lemma; a target-only redirect assertion stopped the harness before download. Preserve that failure. The final candidate copies the identical temporal method and two contradiction branches from the checked symmetric sibling. This is a candidate, not an accepted certificate.',
          'model_and_all_query_contracts_unchanged': True,
          'security_proof_verified': False, 'independent_complete_replay_required': True}
(out / 'PREPARATION.json').write_text(json.dumps(record, indent=2) + '\n')
(stage / 'FAILURE_CLASSIFICATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'candidate_sha256': record['candidate_sha256'], 'accepted': False, 'open_cases': 0}))
