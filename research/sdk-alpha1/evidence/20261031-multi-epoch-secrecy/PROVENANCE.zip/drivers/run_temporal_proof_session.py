"""Bounded interactive application of observed temporal cases and contradictions.

Every mutation comes from the current kernel method list. Every downloaded
candidate is checked against the unchanged model/query contract. This does
not accept a certificate: the ordinary independent replay remains mandatory.
"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

W = Path(__file__).resolve().parent
REPO = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0, str(REPO / 'artifact'))
from continuity_recovery_proof import prover_environment
from continuity_multi_epoch_search import theory, uncomment, _TOKEN
from continuity_proof_fragments import case_spans, _is_hole, _lemma_span
from bounded_proof_methods import RESPONSE_BOUND, extract_complete_methods

source, stage = (Path(p).resolve() for p in sys.argv[1:3])
TARGET = sys.argv[3]
data = source.read_bytes()
assert b'invalid proof step' not in data
contract = theory(data)
assert TARGET in contract.by_name
stage.mkdir(exist_ok=False)
(stage / 'model.spthy').write_bytes(data)
tools = W / 'tools'
for name, expected in [('tamarin-prover', 'd6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f'),
                       ('maude', '266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf')]:
    assert hashlib.sha256((tools / name).read_bytes()).hexdigest() == expected
env = prover_environment()
env['PATH'] = str(tools) + os.pathsep + env['PATH']
with socket.socket() as sock:
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
origin = 'http://127.0.0.1:' + str(port)
argv = [str(tools / 'tamarin-prover'), 'interactive', '--interface=127.0.0.1',
        '--port=' + str(port), '--with-maude=' + str(tools / 'maude'),
        '--derivcheck-timeout=60', '--quit-on-warning', str(stage),
        '+RTS', '-N1', '-M12G', '-c30', '-s', '-RTS']

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self.current = [], None
    def handle_starttag(self, tag, attributes):
        if tag == 'a':
            attrs = dict(attributes)
            self.current = {'href': attrs.get('href'), 'classes': attrs.get('class', ''), 'text': ''}
    def handle_data(self, value):
        if self.current is not None:
            self.current['text'] += value
    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.rows.append(self.current)
            self.current = None

def holes(raw):
    text = raw.decode()
    a, z = _lemma_span(text, TARGET)
    prefix = tuple('_' for _ in re.findall(r'^simplify\s*$', uncomment(text[a:z]), re.M))
    return [prefix + path for path, (i, j) in case_spans(raw, TARGET).items() if _is_hole(text[i:j])]

def check_candidate(raw):
    assert b'invalid proof step' not in raw
    assert theory(raw) == contract
    for query in contract.queries:
        if query.name == TARGET:
            continue
        a, z = _lemma_span(data.decode(), query.name)
        x, y = _lemma_span(raw.decode(), query.name)
        assert _TOKEN.findall(uncomment(data.decode()[a:z])) == _TOKEN.findall(uncomment(raw.decode()[x:y]))

start = time.monotonic()
requests, mutations = [], []
failure, stop_reason = None, None
current, theory_id = data, '1'
process = None

def request(path, *, method_page=False):
    assert re.fullmatch(r'/thy/trace/[1-9][0-9]*/[^\r\n]*', path)
    assert len(requests) < 64
    assert process.poll() is None
    remaining = 900 - (time.monotonic() - start)
    assert remaining > 0, 'session deadline reached'
    with urllib.request.urlopen(origin + path, timeout=min(600, remaining)) as response:
        raw = response.read(RESPONSE_BOUND + 1)
        kind = response.headers.get_content_type()
    number = len(requests)
    leaf = f'response-{number:02}.raw'
    (stage / leaf).write_bytes(raw)
    complete = len(raw) <= RESPONSE_BOUND
    extracted = None
    if not complete:
        assert method_page, 'non-method response exceeded complete-response bound'
        raw, extracted = extract_complete_methods(raw)
        (stage / f'response-{number:02}.methods.json').write_bytes(raw)
    record = {'path': path, 'file': leaf, 'content_type': kind,
              'complete_response': complete,
              'raw_sha256': hashlib.sha256((stage / leaf).read_bytes()).hexdigest(),
              'parsed_payload_sha256': hashlib.sha256(raw).hexdigest()}
    requests.append(record)
    return raw, record, extracted

with (stage / 'server.stdout').open('xb') as out, (stage / 'server.stderr').open('xb') as err:
    process = subprocess.Popen(argv, cwd=REPO, env=env, stdout=out, stderr=err, start_new_session=True)
    (stage / 'STARTED.json').write_text(json.dumps({'pid': process.pid, 'argv': argv,
        'input_sha256': hashlib.sha256(data).hexdigest(), 'target': TARGET,
        'maximum_seconds': 900, 'maximum_requests': 64,
        'maximum_applied_methods': 20, 'response_read_bound': RESPONSE_BOUND,
        'complete_independent_replay_required': True}, indent=2) + '\n')
    try:
        while True:
            assert process.poll() is None
            assert time.monotonic() - start < 900
            try:
                with urllib.request.urlopen(origin + '/', timeout=5) as response:
                    (stage / 'index.html').write_bytes(response.read(1024 * 1024))
                break
            except urllib.error.URLError as error:
                if not isinstance(error.reason, ConnectionRefusedError):
                    raise
                time.sleep(.25)
        raw, _, _ = request('/thy/trace/1/overview/help')
        links = Links()
        links.feed(raw.decode())
        downloads = [row['href'] for row in links.rows
                     if row.get('href') and re.fullmatch(r'/thy/trace/1/download/[^/]+\.spthy', row['href'])]
        assert len(set(downloads)) == 1
        download_suffix = downloads[0].split('/download/', 1)[1]
        for number in range(20):
            pending = holes(current)
            if not pending:
                stop_reason = 'no open named cases; independent replay still required'
                break
            case_path = pending[0]
            path = '/thy/trace/' + theory_id + '/main/proof/' + TARGET + '/' + '/'.join(case_path)
            raw, page_record, extracted = request(path, method_page=True)
            html = json.loads(raw)['html']
            assert 'No such lemma or proof path.' not in html
            links = Links()
            links.feed(html)
            methods = [row for row in links.rows if 'proof-method' in row['classes'].split()]
            if extracted is not None:
                assert methods == extracted
            choices = []
            for method in methods:
                text = ' '.join(method['text'].split())
                if text.startswith('contradiction'):
                    choices.append((0, len(text), method))
                elif re.fullmatch(r'solve\( \(#[A-Za-z_0-9.]+ = #[A-Za-z_0-9.]+\) ∥ \(#[A-Za-z_0-9.]+ < #[A-Za-z_0-9.]+\) \)', text):
                    choices.append((1, len(text), method))
            if not choices:
                stop_reason = 'unsupported frontier; retained for inspection'
                break
            method = min(choices, key=lambda row: row[:2])[2]
            method_text = ' '.join(method['text'].split())
            assert method['href'].startswith('/thy/trace/' + theory_id + '/main/method/' + TARGET + '/')
            response, mutation_record, _ = request(method['href'])
            redirect = json.loads(response)['redirect']
            match = re.match(r'^/thy/trace/([1-9][0-9]*)/overview/proof/' + TARGET + r'(?:/|$)', redirect)
            assert match is not None
            theory_id = match[1]
            candidate, download_record, _ = request('/thy/trace/' + theory_id + '/download/' + download_suffix)
            check_candidate(candidate)
            current = candidate
            record = {'case_path': list(case_path), 'method': method_text,
                      'offered_page_sha256': page_record['parsed_payload_sha256'],
                      'method_href': method['href'], 'redirect': redirect,
                      'candidate_file': download_record['file'],
                      'candidate_sha256': hashlib.sha256(current).hexdigest(),
                      'remaining_open_cases': len(holes(current))}
            mutations.append(record)
            (stage / 'PROGRESS.json').write_text(json.dumps(mutations, indent=2) + '\n')
            print(json.dumps({'applied_methods': len(mutations),
                              'open_cases': record['remaining_open_cases'],
                              'method': method_text}), flush=True)
        else:
            stop_reason = '20-method bound reached; candidate retained for independent replay'
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        if mutations:
            (stage / 'candidate.spthy').write_bytes(current)
        report = {'requests': requests, 'mutations': mutations, 'failure': failure,
                  'stop_reason': stop_reason, 'process_returncode': process.returncode,
                  'elapsed_seconds': time.monotonic() - start,
                  'candidate_sha256': hashlib.sha256(current).hexdigest() if mutations else None,
                  'complete_independent_replay_required': True,
                  'conditional_diagnostic_only': True, 'security_proof_verified': False}
        (stage / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k: v for k, v in report.items() if k not in ('requests', 'mutations')}), flush=True)
if failure:
    raise SystemExit(1)
