"""Run up to four bounded MAIN captured-phase increments; retain and stop on any failure."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

WORK = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_proof_fragments import case_spans, _is_hole

TARGET = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
diagnostic_index, frontier_index, count = map(int, sys.argv[1:])
assert 1 <= count <= 4
stage = WORK / f'main-phase-integration-cycle-batch-{diagnostic_index:02}'
stage.mkdir(exist_ok=False)
records = []
began = time.monotonic()
try:
    for offset in range(count):
        index, frontier_number = diagnostic_index + offset, frontier_index + offset
        previous = WORK / f'main-phase-integration-diagnostic-{index:02}'
        report = json.loads((previous / 'RESULT.json').read_text())
        assert report['returncode'] == 0 and 'failure' not in report
        assert report['results'][TARGET]['status'] == 'analysis incomplete'
        source = previous / 'output.spthy'
        assert hashlib.sha256(source.read_bytes()).hexdigest() == report['output_sha256']
        frontier = WORK / f'main-phase-integration-frontier-{frontier_number:02}'
        candidate = WORK / f'proof/main-phase-integration-guided-{frontier_number:02}.spthy'
        replay = WORK / f'main-phase-integration-diagnostic-{index + 1:02}'
        assert not candidate.exists() and not replay.exists()
        commands = []
        if frontier.exists():
            assert offset == 0
            capture = json.loads((frontier / 'CAPTURE.json').read_text())
            assert capture['failure'] is None
            assert (frontier / 'model.spthy').read_bytes() == source.read_bytes()
        else:
            commands.append([sys.executable, str(WORK / 'capture_selected_frontier-v5.py'),
                             str(source), str(frontier), TARGET])
        commands.extend([
            [sys.executable, str(WORK / 'advance_main_phase_captured.py'), str(frontier), str(candidate)],
            [sys.executable, str(WORK / 'run_selected_proof.py'), str(candidate), str(replay), 'diagnostic', TARGET],
        ])
        for number, command in enumerate(commands):
            with (stage / f'{index:02}-{number}.stdout').open('xb') as out, (stage / f'{index:02}-{number}.stderr').open('xb') as err:
                completed = subprocess.run(command, stdout=out, stderr=err, check=False)
            records.append({'argv': command, 'returncode': completed.returncode,
                            'stdout': f'{index:02}-{number}.stdout', 'stderr': f'{index:02}-{number}.stderr'})
            if completed.returncode != 0:
                raise RuntimeError(f'Increment {index}, command {number} failed with {completed.returncode}.')
        result = json.loads((replay / 'RESULT.json').read_text())
        assert 'failure' not in result
        raw = (replay / 'output.spthy').read_bytes()
        text = raw.decode()
        row = result['results'][TARGET]
        progress = {'diagnostic_index': index + 1, 'target_result': row,
                    'open_case_count': sum(_is_hole(text[a:z]) for a, z in case_spans(raw, TARGET).values()),
                    'output_sha256': result['output_sha256'], 'joint_replay_accepted': False,
                    'main_theorem_verified': False}
        (stage / f'progress-{index + 1:02}.json').write_text(json.dumps(progress, indent=2) + '\n')
        print(json.dumps(progress), flush=True)
        assert row['status'] in ('verified', 'analysis incomplete')
        if row['status'] == 'verified':
            break
except BaseException as error:
    (stage / 'FAILURE.json').write_text(json.dumps({'type': type(error).__name__, 'message': str(error)}, indent=2) + '\n')
    raise
finally:
    (stage / 'RESULT.json').write_text(json.dumps({'commands': records, 'maximum_cycles': count,
        'maximum_methods_per_cycle': 32, 'elapsed_seconds': time.monotonic() - began,
        'main_theorem_verified': False, 'full_dependency_restoration_and_joint_replay_required': True}, indent=2) + '\n')
