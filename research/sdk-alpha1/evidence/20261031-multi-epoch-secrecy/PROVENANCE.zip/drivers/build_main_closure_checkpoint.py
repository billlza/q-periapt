"""Package MAIN only after a successful, complete dependency replay.

Diagnostic closure, a hole-free candidate, and a zero process exit are not
acceptance conditions on their own. Preserve the original formulas and all
unfinished reachability obligations, along with rejected and timed-out work.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

W = Path(__file__).resolve().parent
R = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
OUT = W.parents[1] / 'outputs'
sys.path.insert(0, str(R / 'artifact'))
from continuity_multi_epoch_search import theory, inventory, uncomment, _TOKEN
from continuity_proof_fragments import _lemma_span, case_spans, _is_hole

MAIN = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
ORDERED = 'no_strictly_ordered_duplicate_local_phase'
PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
READY = 'first_responder_ready_event_is_unique'
stage = W / 'main-phase-temporal-joint-01'
sha = lambda data: hashlib.sha256(data).hexdigest()
result = json.loads((stage / 'RESULT.json').read_text())
assert 'failure' not in result and result['returncode'] == 0
assert result['mode'] == 'complete' and result['streams_complete']
assert result['complete_replay_accepted'] and result['selected_theorem_verified']
assert result['main_secrecy_verified'] and not result['release_claim_eligible']
source, current = ((stage / name).read_bytes() for name in ('input.spthy', 'output.spthy'))
assert sha(source) == result['input_sha256'] == 'd056c6d4eeb453d7a944debd48ad6b109bb6963bd2335b7b6b4eb872da7414d2'
assert sha(current) == result['output_sha256']
assert b'invalid proof step' not in current
contract = theory(current)
assert theory(source) == contract and len(contract.queries) == 40
terminal = inventory((stage / 'stdout').read_bytes(), stage / 'input.spthy', stage / 'output.spthy', contract)
assert terminal == result['results']
for stream in ('stdout', 'stderr'):
    raw = (stage / stream).read_bytes()
    assert result[stream] == {'bytes': len(raw), 'sha256': sha(raw)}
assert not re.search(rb'warning|invalid proof|wellformedness check failed', (stage / 'stderr').read_bytes(), re.I)
assert terminal[MAIN] == {'mode': 'all-traces', 'status': 'verified', 'steps': 508}
assert terminal[PHASE] == {'mode': 'all-traces', 'status': 'verified', 'steps': 4}
assert terminal[READY] == {'mode': 'all-traces', 'status': 'verified', 'steps': 6}
reusable = [q.name for q in contract.queries if q.reusable]
assert len(reusable) == 24
assert all(terminal[name]['status'] == 'verified' for name in reusable)
original = (W / 'proof/original.spthy').read_bytes()
baseline = (W / 'main-response-reservation-joint-replay-01/output.spthy').read_bytes()
assert sha(original) == 'd21fa9256a72a5b7ad7ddc159762a10d14451bb0492b727f7d0a50428351bc72'
assert sha(baseline) == 'c36862ecbcbd479c7873be71fb0c386c8ec7aac90107c13e149ab3ed12aa5fad'
comparisons = {}
for label, raw, count in [('original_35', original, 35), ('accepted_main517_38', baseline, 38)]:
    prior = theory(raw)
    assert len(prior.queries) == count and prior.prefix == contract.prefix
    attributes = {}
    for q in prior.queries:
        after = contract.by_name[q.name]
        assert (q.formula, q.mode) == (after.formula, after.mode)
        if q.attributes != after.attributes:
            attributes[q.name] = {'before': q.attributes, 'after': after.attributes}
    comparisons[label] = {'formulas_modes_and_operational_model_unchanged': True,
                          'attribute_changes': attributes,
                          'old_order': [q.name for q in prior.queries],
                          'retained_order': [q.name for q in contract.queries if q.name in prior.by_name]}
assert comparisons['accepted_main517_38']['old_order'] == comparisons['accepted_main517_38']['retained_order']

def commands(raw, name):
    text = raw.decode()
    a, z = _lemma_span(text, name)
    return _TOKEN.findall(uncomment(text[a:z]))

for q in contract.queries:
    assert commands(source, q.name) == commands(current, q.name)
for q in theory(baseline).queries:
    if q.name not in (MAIN, READY):
        assert commands(baseline, q.name) == commands(current, q.name)
assert not any(_is_hole(current.decode()[a:z]) for a, z in case_spans(current, MAIN).values())
unfinished = {n: r for n, r in terminal.items() if r['status'] != 'verified'}
unfinished_exists = {n: r for n, r in unfinished.items() if r['mode'] == 'exists-trace'}
assert len(unfinished_exists) == 11
assert terminal['initial_epoch_traffic_advances_counter_is_executable'] == {'mode': 'exists-trace', 'status': 'verified', 'steps': 414}

files = {}
def add(member, path):
    assert path.is_file() and not path.is_symlink()
    assert member not in files
    files[member] = path

patterns = ('main-phase-integration-*', 'main-phase-temporal-joint-01',
            'ordered-phase-*', 'phase-from-ordered-*',
            'local-phase-unique-diagnostic-19', 'local-phase-unique-joint-replay-01',
            'local-phase-factored-joint-replay-01', 'phase-specialized-ready-*')
for pattern in patterns:
    for directory in sorted(W.glob(pattern)):
        if directory.is_dir():
            for path in sorted(directory.rglob('*')):
                if path.is_file():
                    add('runs/' + path.relative_to(W).as_posix(), path)
for pattern in ('main-phase-*', 'main-ordered-joint-01*', 'ordered-phase-*', 'phase-from-ordered-*',
                'local-phase-factored-full-01*', 'phase-specialized-ready-*'):
    for path in sorted((W / 'proof').glob(pattern)):
        if path.is_file():
            add('preparations/' + path.name, path)
for name in ('run_main_dependency_replay.py', 'run_selected_proof.py',
             'capture_selected_frontier-v5.py', 'bounded_proof_methods.py',
             'apply_observed_proof_methods.py', 'advance_main_phase_frontier.py',
             'run_main_phase_cycles.py', 'advance_main_phase_ready_or_origin.py',
             'advance_main_phase_counterpart.py', 'advance_main_phase_captured.py',
             'run_main_phase_captured_cycles.py', 'restore_main_phase_closed_dependencies.py',
             'prepare_ordered_phase_candidate.py', 'project_ordered_phase_proof.py',
             'reopen_ordered_projection_failures.py', 'run_temporal_proof_session.py',
             'assemble_last_ordered_case.py', 'prepare_phase_from_ordered.py',
             'prepare_ordered_main_candidate.py', 'prepare_phase_specialized_ready.py',
             'restore_phase_factored_dependencies.py', 'build_main_closure_checkpoint.py'):
    add('drivers/' + name, W / name)
for name in ('continuity_multi_epoch_search.py', 'continuity_proof_fragments.py',
             'bounded_process.py', 'formal_toolchain_contract.py', 'continuity_recovery_proof.py'):
    add('checker-source/' + name, R / 'artifact' / name)
add('history/original-35.spthy', W / 'proof/original.spthy')
add('history/accepted-main517.spthy', W / 'main-response-reservation-joint-replay-01/output.spthy')
add('history/accepted-main517-RESULT.json', W / 'main-response-reservation-joint-replay-01/RESULT.json')
add('history/accepted-main517-checkpoint.json', OUT / 'Q-periapt-main-proof-checkpoint-v4.json')
tool_ids = {'tamarin-prover': {'version': '1.12.0', 'sha256': 'd6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f'},
            'maude': {'version': '3.5.1', 'sha256': '266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf'}}
for name, identity in tool_ids.items():
    assert sha((W / 'tools' / name).read_bytes()) == identity['sha256']

document = '''主多 epoch 消息保密性命题通过完整依赖联合回放：MAIN 为 508 步，全部 24 个可复用辅助引理均在同一个固定工具进程中验证。此前局部诊断与未接受候选不再单独承担这个结论。完整日志、输入输出、终态查询清单和工具摘要保留在归档中。

证明结构增加两个辅助命题：同一会话、角色、epoch 和阶段不能发生严格先后的重复事件；由此得到阶段事件唯一性，再用于 MAIN 和原有第一轮响应方 Ready 唯一性。后者从 285 步因式分解为 6 步，阶段唯一性从 292 步变为 4 步加新的前提证明。原始 35 个查询及后来 38 查询基线的全部公式、量词模式和协议执行模型均保留；新增依赖、隐藏属性和历史顺序调整逐项列明。

结论严格限于当前符号模型：指定会话的 Cut 泄露两方包装密钥；目标 epoch 的生成及封装预约都在 Cut 之后；两方身份私钥不泄露，目标 epoch 的预约熵不泄露，攻击者没有获得 Cut 之后保存的该会话记录。在这些条件下，目标业务消息的明文不可由模型中的攻击者导出。它不是对持续控制宿主、任意回滚或后续持久记录泄露的保护承诺，也不是计算安全或全部 Rust/FFI 实现的机器证明。

全部 40 个查询均保留，但并非全部验证：11 个多轮执行见证仍未完成，初始业务流量见证仍为已验证的 414 步。MAIN 的全称证明与多轮非空执行证据分开记账。主定理闭合不意味着整个 SDK、产品 ABI 2 准入、最终平台资格、外部安全审查或正式发行已经完成。

原有 MAIN517 的八个开放分支、292 步阶段证明、两次完整阶段回放超时、投影候选中 16 个被拒绝的证明步骤及其重新开放记录、交互导出导航失败均保留。检查器未放宽，未删除原始查询或改变协议规则。工具界限保持每进程 900 秒、12 GiB RTS 堆、-N1、-c30 和 60 秒推导检查；RTS 堆界限不等于进程 RSS。

归档中每个成员有 SHA-256 和字节数，写入后逐字节回读。历史驱动保留实际本地路径；本包是可审阅证据，尚不是仓库正式 CI 发布证书。
'''
generated = {'README.md': document.encode(),
             'current/unfinished-queries.json': (json.dumps(unfinished, indent=2) + '\n').encode()}
rows = {}
for member, path in files.items():
    raw = path.read_bytes()
    rows[member] = {'bytes': len(raw), 'sha256': sha(raw)}
for member, raw in generated.items():
    rows[member] = {'bytes': len(raw), 'sha256': sha(raw)}
metadata = {'schema_version': 1, 'main_result': terminal[MAIN], 'main_theorem_verified': True,
            'complete_dependency_joint_replay_accepted': True, 'query_count': 40,
            'verified_reusable_premises': reusable, 'all_results': terminal,
            'unfinished_queries': unfinished, 'comparison_to_baselines': comparisons,
            'other_36_baseline_proof_command_sequences_unchanged': True,
            'input_output_all_proof_command_sequences_equal': True,
            'input_sha256': sha(source), 'output_sha256': sha(current),
            'elapsed_seconds': result['elapsed_seconds'], 'tool_identities': tool_ids,
            'bounds': {'seconds': 900, 'rts_heap_gib': 12, 'capabilities': 1, 'compaction_threshold': 30, 'derivation_check_seconds': 60},
            'source_baseline_commit': '4ae5f77ad6e81dce956be24511d7f5e429924bde',
            'research_changes_committed': False, 'release_claim_eligible': False,
            'goal_complete': False, 'members': rows}
manifest = (json.dumps(metadata, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
stem = 'Q-periapt-main-proof-closure'
archive, receipt, note = (OUT / (stem + suffix) for suffix in ('.zip', '.json', '.md'))
assert not any(path.exists() for path in (archive, receipt, note))
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as writer:
    for name, path in sorted(files.items()):
        writer.write(path, name)
    for name, raw in generated.items():
        writer.writestr(name, raw)
    writer.writestr('MANIFEST.json', manifest)
with zipfile.ZipFile(archive) as reader:
    assert len(reader.namelist()) == len(set(reader.namelist())) == len(rows) + 1
    assert reader.read('MANIFEST.json') == manifest
    for name, expected in rows.items():
        raw = reader.read(name)
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
metadata['archive'] = {'file': archive.name, 'bytes': archive.stat().st_size,
                       'sha256': sha(archive.read_bytes()), 'members': len(rows) + 1,
                       'all_members_read_back': True}
with receipt.open('x') as stream:
    stream.write(json.dumps(metadata, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
with note.open('x') as stream:
    stream.write(document)
print(json.dumps(metadata['archive']))
