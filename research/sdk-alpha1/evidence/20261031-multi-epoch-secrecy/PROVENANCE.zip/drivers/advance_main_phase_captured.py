"""Source captured generation phases and their linear Ready predecessors."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

W = Path(__file__).resolve().parent
stage, out = (Path(p).resolve() for p in sys.argv[1:])
assert not out.exists()
cap = json.loads((stage / 'CAPTURE.json').read_text())
assert cap['failure'] is None and cap['method_lists_complete']
source = (stage / 'model.spthy').read_bytes()
selected = []
for page, row in enumerate(cap['reads']):
    choices = []
    for index, item in enumerate(row['methods'], 1):
        method = ' '.join(item['text'].split())
        if method.startswith('contradiction'):
            priority, reason = 0, 'kernel-offered contradiction'
        elif method.startswith('solve( !Wrap(') and re.search(r'▶₁ #captured(?:\.[0-9]+)? \)$', method):
            priority, reason = 1, 'bind captured generation-record role to exact session setup'
        elif method.startswith('solve( PositionedPhaseState(') and re.search(r'▶₀ #vr(?:\.[0-9]+)? \)$', method):
            if ", 'Offer2'," in method:
                priority, reason = 2, 'source the captured committed-offer predecessor'
            elif ", 'Offer1'," in method:
                priority, reason = 3, 'source the captured offer-signing predecessor'
            elif ", 'Ready'," in method:
                priority, reason = 4, 'source the captured generation reservation Ready token'
            else:
                continue
        elif method.startswith('solve( PositionedPhaseState(') and ", 'Ready'," in method and method.endswith('▶₀ #e )'):
            priority, reason = 5, 'source the post-cut response Ready counterpart'
        else:
            continue
        choices.append((priority, index, method, reason))
    if choices:
        priority, index, method, reason = min(choices, key=lambda item: item[:2])
        selected.append((priority, {'page_index': page, 'method_index': index,
            'case_path': row['case_path'],
            'method_sha256': hashlib.sha256(method.encode()).hexdigest(), 'reason': reason}))
assert selected, 'No supported captured-phase method; inspect the frontier.'
rows = [row for _, row in sorted(selected, key=lambda item: (item[0], item[1]['page_index']))[:32]]
spec = {'target': 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy',
        'input_sha256': hashlib.sha256(source).hexdigest(), 'selected': rows}
selection = out.with_suffix('.selection.json')
with selection.open('x') as handle:
    handle.write(json.dumps(spec, indent=2) + '\n')
result = subprocess.run([sys.executable, str(W / 'apply_observed_proof_methods.py'),
                         str(stage), str(selection), str(out)], check=False)
if result.returncode:
    raise SystemExit(result.returncode)
print(json.dumps({'selected': len(rows), 'reasons': {
    reason: sum(row['reason'] == reason for row in rows)
    for reason in sorted({row['reason'] for row in rows})}}))
