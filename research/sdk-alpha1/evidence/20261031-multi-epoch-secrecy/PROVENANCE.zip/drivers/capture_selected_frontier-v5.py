"""Capture kernel-offered proof methods from the unchanged complete certificate."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

REPO = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / 'artifact'))
from continuity_recovery_proof import prover_environment
from continuity_proof_fragments import case_spans, _is_hole, _lemma_span
from continuity_multi_epoch_search import ORIGIN, theory, uncomment
from bounded_proof_methods import RESPONSE_BOUND, extract_complete_methods

source = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
ORIGIN = sys.argv[3]
stage.mkdir(exist_ok=False)
data = source.read_bytes()
assert b'invalid proof step' not in data
contract = theory(data)
text = data.decode()
holes = [p for p, (s, e) in case_spans(data, ORIGIN).items() if _is_hole(text[s:e])]
proof_start, proof_end = _lemma_span(text, ORIGIN)
body = uncomment(text[proof_start:proof_end]).strip()
linear_prefix = tuple('_' for _ in re.findall(r'^simplify\s*$', body, re.M))
if not holes:
    assert re.fullmatch(r'(?:simplify\s+)*by sorry', body), 'unsupported unnamed proof continuation'
    holes = [linear_prefix]
else:
    holes = [linear_prefix + path for path in holes]
(stage / 'model.spthy').write_bytes(data)
tools = WORK / 'tools'
for leaf, expected in [('tamarin-prover', 'd6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f'),
                       ('maude', '266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf')]:
    assert hashlib.sha256((tools / leaf).read_bytes()).hexdigest() == expected
env = prover_environment()
env['PATH'] = str(tools) + os.pathsep + env['PATH']
with socket.socket() as sock:
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
origin = 'http://127.0.0.1:' + str(port)
argv = [str(tools / 'tamarin-prover'), 'interactive', '--interface=127.0.0.1',
        '--port=' + str(port), '--with-maude=' + str(tools / 'maude'),
        '--derivcheck-timeout=60', '--quit-on-warning', str(stage),
        '+RTS', '-N1', '-M12G', '-c30', '-s', '-RTS']

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self.current = [], None
    def handle_starttag(self, tag, attributes):
        if tag == 'a':
            attrs = dict(attributes)
            self.current = {'href': attrs.get('href'), 'classes': attrs.get('class', ''), 'text': ''}
    def handle_data(self, value):
        if self.current is not None:
            self.current['text'] += value
    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.rows.append(self.current)
            self.current = None

start = time.monotonic()
reads, failure = [], None
with (stage / 'server.stdout').open('xb') as out, (stage / 'server.stderr').open('xb') as err:
    process = subprocess.Popen(argv, cwd=REPO, env=env, stdout=out, stderr=err, start_new_session=True)
    (stage / 'STARTED.json').write_text(json.dumps({
        'pid': process.pid, 'argv': argv, 'port': port, 'maximum_seconds': 900,
        'input_sha256': hashlib.sha256(data).hexdigest(), 'query_count': len(contract.queries),
    }, indent=2) + '\n')
    try:
        while True:
            assert process.poll() is None, 'prover stopped before readiness'
            assert time.monotonic() - start < 900, 'session deadline reached'
            try:
                with urllib.request.urlopen(origin + '/', timeout=5) as response:
                    (stage / 'index.html').write_bytes(response.read(1024 * 1024))
                break
            except urllib.error.URLError as error:
                if not isinstance(error.reason, ConnectionRefusedError):
                    raise
                time.sleep(.25)
        for number, path in enumerate(holes):
            assert process.poll() is None
            remaining = 900 - (time.monotonic() - start)
            assert remaining > 0
            target = '/thy/trace/1/main/proof/' + ORIGIN + ('/' + '/'.join(path) if path else '')
            with urllib.request.urlopen(origin + target, timeout=min(600, remaining)) as response:
                raw = response.read(10 * 1024**2 + 1)
            response_complete = len(raw) <= RESPONSE_BOUND
            prefix_file = None
            extracted_methods = None
            if response_complete:
                payload = raw
                page = stage / f'page-{number:02}.json'
            else:
                prefix_file = stage / f'page-{number:02}.response-prefix.json.partial'
                prefix_file.write_bytes(raw)
                payload, extracted_methods = extract_complete_methods(raw)
                page = stage / f'page-{number:02}.methods.json'
            page.write_bytes(payload)
            parser = Links()
            html = json.loads(payload)['html']
            assert 'No such lemma or proof path.' not in html, 'proof-state route did not resolve'
            parser.feed(html)
            methods = [row for row in parser.rows if 'proof-method' in row['classes'].split()]
            if extracted_methods is not None:
                assert methods == extracted_methods, 'method-list extraction changed offered methods'
            reads.append({'case_path': path, 'target': target, 'page': page.name,
                          'sha256': hashlib.sha256(payload).hexdigest(), 'methods': methods,
                          'response_complete': response_complete,
                          'representation': 'complete-page' if response_complete else 'complete-method-list-only',
                          'raw_response_prefix': None if prefix_file is None else prefix_file.name,
                          'raw_response_prefix_sha256': None if prefix_file is None else hashlib.sha256(raw).hexdigest(),
                          'raw_response_prefix_bytes': None if prefix_file is None else len(raw)})
            print(json.dumps({'number': number, 'method_count': len(methods)}), flush=True)
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        record = {'reads': reads, 'failure': failure, 'process_returncode': process.returncode,
                  'elapsed_seconds': time.monotonic() - start, 'proof_modified': False,
                  'security_proof_verified': False, 'release_claim_eligible': False,
                  'full_pages_retained': all(row['response_complete'] for row in reads),
                  'method_lists_complete': failure is None and len(reads) == len(holes),
                  'response_read_bound': RESPONSE_BOUND}
        (stage / 'CAPTURE.json').write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({k: v for k, v in record.items() if k != 'reads'}), flush=True)
    if failure:
        raise SystemExit(1)
