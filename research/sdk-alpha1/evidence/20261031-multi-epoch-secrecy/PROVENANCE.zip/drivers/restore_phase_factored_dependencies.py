"""Restore all 39 proofs around the six-step derivation of the existing Ready lemma."""
from pathlib import Path
import hashlib
import json
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory, uncomment, _TOKEN
from continuity_proof_fragments import _lemma_span, case_spans, _is_hole

TARGET = 'first_responder_ready_event_is_unique'
PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
S = W / 'phase-specialized-ready-diagnostic-04'
report = json.loads((S / 'RESULT.json').read_text())
assert 'failure' not in report and report['returncode'] == 0
assert report['results'][TARGET] == {'mode': 'all-traces', 'status': 'verified', 'steps': 6}
diagnostic = (S / 'output.spthy').read_bytes()
assert hashlib.sha256(diagnostic).hexdigest() == report['output_sha256'] == 'c40b3e7cc1aaa8294b732b211ec39463b7ffb8c92695469897ab73975b129e21'
template = (W / 'proof/phase-specialized-ready-full-template.spthy').read_bytes()
assert hashlib.sha256(template).hexdigest() == '3fd5a8648724b9c9a4af9ea103e1a57ee064484ecac2c7e3fbe39ff00185dfb9'
assert theory(template) == theory(diagnostic)
old = template.decode()
new = diagnostic.decode()
a, z = _lemma_span(old, TARGET)
x, y = _lemma_span(new, TARGET)
full = old[:a] + new[x:y] + old[z:]
contract = theory(template)
assert theory(full.encode()) == contract and len(contract.queries) == 39
assert contract.queries[0].name == PHASE
assert sum(q.reusable for q in contract.queries) == 23
for query in contract.queries:
    if query.name == TARGET:
        continue
    p, q = _lemma_span(full, query.name)
    i, j = _lemma_span(old, query.name)
    assert full[p:q] == old[i:j]
assert not any(_is_hole(full[p:q]) for p, q in case_spans(full.encode(), TARGET).values())
assert not any(_is_hole(full[p:q]) for p, q in case_spans(full.encode(), PHASE).values())
output = W / 'proof/local-phase-factored-full-01.spthy'
with output.open('xb') as stream:
    stream.write(full.encode())
record = {
    'input_template_sha256': hashlib.sha256(template).hexdigest(),
    'diagnostic_sha256': report['output_sha256'],
    'output_sha256': hashlib.sha256(full.encode()).hexdigest(),
    'target': TARGET, 'target_conditional_steps': 6, 'old_target_steps': 285,
    'query_count': 39, 'reusable_queries': 23,
    'contract_unchanged_from_reordered_template': True,
    'all_other_38_proof_bodies_restored_byte_for_byte': True,
    'phase_first_with_no_visible_prior_reuse': True,
    'phase_hidden_from_main_and_all_others_except_specific_ready': True,
    'all_original_formulas_modes_and_model_retained': True,
    'joint_replay_required': True, 'main_theorem_verified': False,
    'resource_limits_unchanged': True,
}
with output.with_suffix('.preparation.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
