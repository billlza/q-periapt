"""Restore full dependencies around the closed conditional MAIN proof."""
from pathlib import Path
import hashlib
import json
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import _lemma_span, case_spans, _is_hole

MAIN = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
stage = W / 'main-phase-integration-diagnostic-12'
report = json.loads((stage / 'RESULT.json').read_text())
assert 'failure' not in report and report['returncode'] == 0
assert report['mode'] == 'diagnostic' and not report['complete_replay_accepted']
assert report['results'][MAIN] == {'mode': 'all-traces', 'status': 'verified', 'steps': 508}
diagnostic = (stage / 'output.spthy').read_bytes()
assert hashlib.sha256(diagnostic).hexdigest() == report['output_sha256'] == 'a2e2a61f355083b2de3167d02760c3528d92e4ca17a38f83a755fe9c467f2749'
template = (W / 'proof/main-phase-integration-full-template-01.spthy').read_bytes()
assert hashlib.sha256(template).hexdigest() == 'c8f31dbcb8d2a5c1cb9214e28de819d9a0ce6cc0a06fe221b0a982b53e1f1665'
assert theory(template) == theory(diagnostic)
old = template.decode()
body = diagnostic.decode()
a, z = _lemma_span(old, MAIN)
x, y = _lemma_span(body, MAIN)
full = old[:a] + body[x:y] + old[z:]
contract = theory(template)
assert theory(full.encode()) == contract and len(contract.queries) == 39
for query in contract.queries:
    if query.name == MAIN:
        continue
    i, j = _lemma_span(old, query.name)
    p, q = _lemma_span(full, query.name)
    assert old[i:j] == full[p:q]
assert not any(_is_hole(full[p:q]) for p, q in case_spans(full.encode(), MAIN).values())
baseline = (W / 'main-response-reservation-joint-replay-01/output.spthy').read_bytes()
original = (W / 'proof/original.spthy').read_bytes()
assert hashlib.sha256(original).hexdigest() == 'd21fa9256a72a5b7ad7ddc159762a10d14451bb0492b727f7d0a50428351bc72'
for prior in [theory(baseline), theory(original)]:
    assert prior.prefix == contract.prefix
    assert (prior.by_name[MAIN].mode, prior.by_name[MAIN].formula) == (contract.by_name[MAIN].mode, contract.by_name[MAIN].formula)
    for query in prior.queries:
        current = contract.by_name[query.name]
        assert (query.mode, query.formula) == (current.mode, current.formula)
output = W / 'proof/main-phase-closed-full-01.spthy'
with output.open('xb') as handle:
    handle.write(full.encode())
record = {'template_sha256': hashlib.sha256(template).hexdigest(),
          'conditional_main_output_sha256': report['output_sha256'],
          'full_input_sha256': hashlib.sha256(full.encode()).hexdigest(),
          'main_conditional_steps': 508, 'main_open_leaves': 0,
          'query_count': 39, 'all_other_38_proof_bodies_restored_byte_for_byte': True,
          'original_35_and_later_38_formulas_modes_preserved': True,
          'operational_model_unchanged': True,
          'phase_dependency_visible_to_main': True,
          'full_replay_executed': False, 'complete_joint_replay_required': True,
          'main_theorem_verified': False, 'goal_complete': False,
          'next_step': 'Complete ordered-phase factorization before a new full replay; two earlier full phase replays hit the fixed deadline.'}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
