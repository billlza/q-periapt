"""Bounded standalone replay of a complete or explicitly diagnostic proof tree."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import time

REPO = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / 'artifact'))
from bounded_process import capture_output, BoundedProcessError
from continuity_recovery_proof import prover_environment
from continuity_multi_epoch_search import theory, inventory, ORIGIN
from formal_toolchain_contract import verify_installed

ORIGIN = sys.argv[4]
source = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
assert mode in ('diagnostic', 'complete')
stage.mkdir(exist_ok=False)
data = source.read_bytes()
contract = theory(data)
tools = WORK / 'tools'
for leaf, expected in [('tamarin-prover', 'd6e6d38366501f51c2b417dab9fd1dbb1ac43f4b4dd701d9c152e3f7a2f1188f'),
                       ('maude', '266eed04679fde6029a18e5e2b1828223d4a7169ac55503aa15d67e126792fbf')]:
    assert hashlib.sha256((tools / leaf).read_bytes()).hexdigest() == expected
environment = prover_environment()
environment['PATH'] = str(tools) + os.pathsep + environment['PATH']
verify_installed('tamarin', path_environment=environment['PATH'])
input_path = stage / 'input.spthy'
input_path.write_bytes(data)
output_path = stage / 'output.spthy'
argv = [str(tools / 'tamarin-prover'), '--with-maude=' + str(tools / 'maude'),
        str(input_path), '--derivcheck-timeout=60', '--quit-on-warning',
        '--output=' + str(output_path), '+RTS', '-N1', '-M12G', '-c30', '-s', '-RTS']
report = {'mode': mode, 'argv': argv, 'input_sha256': hashlib.sha256(data).hexdigest(),
          'query_count': len(contract.queries), 'maximum_seconds': 900,
          'release_claim_eligible': False, 'main_secrecy_verified': False,
          'streams_complete': False, 'complete_replay_accepted': False}
(stage / 'STARTED.json').write_text(json.dumps(report, indent=2) + '\n')
start = time.monotonic()
try:
    with (stage / 'stdout').open('xb', buffering=0) as out, (stage / 'stderr').open('xb', buffering=0) as err:
        def retain(stream, chunk):
            if stream.write(chunk) != len(chunk):
                raise OSError('short proof diagnostic write')
        result = capture_output(argv, timeout_seconds=900, maximum_stdout_bytes=16*1024**2,
                                maximum_stderr_bytes=16*1024**2, environment=environment,
                                stdout_sink=lambda chunk: retain(out, chunk),
                                stderr_sink=lambda chunk: retain(err, chunk))
    report.update(returncode=result.returncode, streams_complete=True)
    assert result.returncode == 0, 'prover failed'
    assert not re.search(rb'warning|invalid proof|wellformedness check failed', result.stderr, re.I)
    output = output_path.read_bytes()
    assert b'invalid proof step' not in output
    assert input_path.read_bytes() == data
    assert theory(output) == contract
    report['output_sha256'] = hashlib.sha256(output).hexdigest()
    if mode == 'complete':
        report['results'] = inventory(result.stdout, input_path, output_path, contract)
        report['complete_replay_accepted'] = True
        main_name = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
        report['main_secrecy_verified'] = report['results'][main_name]['status'] == 'verified'
    else:
        rows = re.findall(r'^  (\w+) \((all-traces|exists-trace)\): (verified|analysis incomplete|falsified - found trace) \(([1-9][0-9]*) steps\)$', result.stdout.decode(), re.M)
        assert len(rows) == len(contract.queries)
        assert {r[0] for r in rows} == set(contract.by_name)
        report['results'] = {n: {'mode': m, 'status': s, 'steps': int(c)} for n, m, s, c in rows}
    report['selected_theorem_verified'] = mode == 'complete' and report['results'][ORIGIN]['status'] == 'verified'
except BaseException as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)}
    if isinstance(error, BoundedProcessError):
        report['failure'].update(kind=error.kind, cleanup_ambiguous=error.cleanup_ambiguous)
finally:
    report['elapsed_seconds'] = time.monotonic() - start
    for name in ('stdout', 'stderr'):
        path = stage / name
        if path.exists():
            retained = path.read_bytes()
            report[name] = {'bytes': len(retained), 'sha256': hashlib.sha256(retained).hexdigest()}
    (stage / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('argv', 'results')}))
    if 'results' in report:
        print(json.dumps({'origin': report['results'][ORIGIN], 'verified_queries': [n for n,r in report['results'].items() if r['status']=='verified']}))
if 'failure' in report:
    raise SystemExit(1)
if mode == 'complete' and not report.get('selected_theorem_verified'):
    # A valid partial certificate is retained progress, not a proved theorem.
    raise SystemExit(2)
