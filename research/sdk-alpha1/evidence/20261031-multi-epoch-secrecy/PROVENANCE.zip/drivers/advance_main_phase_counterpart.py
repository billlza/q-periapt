"""Complete each captured Ready-fork pair, or source its captured generation record."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

W = Path(__file__).resolve().parent
stage, out = (Path(p).resolve() for p in sys.argv[1:])
assert not out.exists()
cap = json.loads((stage / 'CAPTURE.json').read_text())
assert cap['failure'] is None and cap['method_lists_complete']
prior = json.loads((W / 'main-phase-integration-frontier-05/CAPTURE.json').read_text())
choices = json.loads((W / 'proof/main-phase-integration-guided-05.selection.json').read_text())
assert choices['input_sha256'] == hashlib.sha256((W / 'main-phase-integration-frontier-05/model.spthy').read_bytes()).hexdigest()
source = (stage / 'model.spthy').read_bytes()
rows = []
for page, row in enumerate(cap['reads']):
    methods = [' '.join(m['text'].split()) for m in row['methods']]
    contradiction = [i for i, m in enumerate(methods, 1) if m.startswith('contradiction')]
    if contradiction:
        assert len(contradiction) == 1
        index, reason = contradiction[0], 'kernel-offered contradiction'
    else:
        parents = [s for s in choices['selected']
                   if row['case_path'][:len(s['case_path'])] == s['case_path']]
        assert len(parents) == 1
        parent = parents[0]
        counterparts = parent['same_role_ready_counterpart_indices']
        if counterparts:
            assert len(counterparts) == 1
            prior_method = ' '.join(prior['reads'][parent['page_index']]['methods'][counterparts[0] - 1]['text'].split())
            match = re.search(r'▶₀ (#[A-Za-z_0-9.]+) \)$', prior_method)
            assert match is not None
            node = match[1]
            candidates = [i for i, m in enumerate(methods, 1)
                          if m.startswith('solve( PositionedPhaseState(')
                          and ", 'Ready'," in m and m.endswith('▶₀ ' + node + ' )')]
            assert len(candidates) == 1, (page, node, candidates)
            index, reason = candidates[0], 'source the other Ready token in the previously observed same-role same-epoch pair'
        else:
            candidates = [i for i, m in enumerate(methods, 1)
                          if m.startswith('solve( !Stored(')
                          and re.search(r'▶₀ #captured(?:\.[0-9]+)? \)$', m)]
            assert len(candidates) == 1
            index, reason = candidates[0], 'source the exact captured generation-phase record'
    rows.append({'page_index': page, 'method_index': index, 'case_path': row['case_path'],
                 'method_sha256': hashlib.sha256(methods[index - 1].encode()).hexdigest(), 'reason': reason})
assert 1 <= len(rows) <= 32
spec = {'target': 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy',
        'input_sha256': hashlib.sha256(source).hexdigest(), 'selected': rows}
selection = out.with_suffix('.selection.json')
with selection.open('x') as handle:
    handle.write(json.dumps(spec, indent=2) + '\n')
result = subprocess.run([sys.executable, str(W / 'apply_observed_proof_methods.py'),
                         str(stage), str(selection), str(out)], check=False)
if result.returncode:
    raise SystemExit(result.returncode)
print(json.dumps({'selected': len(rows), 'reasons': {
    reason: sum(row['reason'] == reason for row in rows)
    for reason in sorted({row['reason'] for row in rows})}}))
