"""Apply a bounded, explicit method selection to exact retained kernel pages."""
from pathlib import Path
import hashlib,json,re,sys
sys.path.insert(0,'/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import case_spans,_is_hole
stage,selection,out=(Path(p).resolve() for p in sys.argv[1:]);assert not out.exists()
spec=json.loads(selection.read_text());raw=(stage/'model.spthy').read_bytes();assert hashlib.sha256(raw).hexdigest()==spec['input_sha256'];target=spec['target']
cap=json.loads((stage/'CAPTURE.json').read_text());assert cap['failure'] is None
spans=case_spans(raw,target);text=raw.decode();edits=[];applied=[]
assert 0<len(spec['selected'])<=32
for choice in spec['selected']:
 row=cap['reads'][choice['page_index']];assert row['case_path']==choice['case_path']
 page=(stage/row['page']).read_bytes();assert hashlib.sha256(page).hexdigest()==row['sha256']
 method=' '.join(row['methods'][choice['method_index']-1]['text'].split());assert hashlib.sha256(method.encode()).hexdigest()==choice['method_sha256']
 if method.startswith('contradiction'):method='contradiction'
 path=tuple(p for p in row['case_path'] if p!='_');a,z=spans[path];assert _is_hole(text[a:z]);indent=re.search(r'(?m)^( *)by sorry',text[a:z])[1]
 edits.append((a,z,indent+'by '+method+'\n'));applied.append({**choice,'method':method,'page':row['page'],'page_sha256':row['sha256']})
assert len(set(a for a,z,s in edits))==len(edits)
for a,z,s in sorted(edits,reverse=True):text=text[:a]+s+text[z:]
assert theory(text.encode())==theory(raw)
with out.open('xb') as f:f.write(text.encode())
r={'target':target,'input_sha256':hashlib.sha256(raw).hexdigest(),'output_sha256':hashlib.sha256(text.encode()).hexdigest(),'maximum_methods':32,'selected':applied,'query_contract_and_operational_model_unchanged':True,'main_theorem_verified':False,'kernel_replay_required':True}
out.with_suffix('.preparation.json').write_text(json.dumps(r,indent=2)+'\n');print('applied',len(applied))
