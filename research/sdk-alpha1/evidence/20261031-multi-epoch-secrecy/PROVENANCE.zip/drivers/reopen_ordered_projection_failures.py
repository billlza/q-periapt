"""Retain each rejected projected branch as an explicit open obligation."""
from pathlib import Path
import hashlib
import json
import re
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import case_spans, _is_hole

TARGET = 'no_strictly_ordered_duplicate_local_phase'
stage = W / 'ordered-phase-projection-diagnostic-01'
report = json.loads((stage / 'RESULT.json').read_text())
assert report['failure']['type'] == 'AssertionError' and not report['complete_replay_accepted']
source = (stage / 'output.spthy').read_bytes()
text = source.decode()
assert theory(source) == theory((stage / 'input.spthy').read_bytes())
markers = list(re.finditer(r'sorry /\* invalid proof step encountered \*/', text))
assert len(markers) == 16
spans = case_spans(source, TARGET)
selected = {}
for marker in markers:
    eligible = [(len(path), path, start, end) for path, (start, end) in spans.items()
                if start <= marker.start() < marker.end() <= end]
    assert eligible
    _, path, start, end = max(eligible, key=lambda row: row[0])
    assert path not in selected
    failed_body = text[start:end]
    line = next(line for line in failed_body.splitlines() if line.strip() and not line.lstrip().startswith('/*'))
    indent = len(line) - len(line.lstrip())
    selected[path] = (start, end, ' ' * indent + 'by sorry\n', failed_body)
assert len(selected) == 16 and len(selected) <= 32
ordered = sorted(selected.values())
assert all(ordered[i][1] <= ordered[i + 1][0] for i in range(len(ordered) - 1))
new = text
for start, end, replacement, _ in reversed(ordered):
    new = new[:start] + replacement + new[end:]
assert 'invalid proof step' not in new
assert theory(new.encode()) == theory(source)
holes = [path for path, (a, z) in case_spans(new.encode(), TARGET).items() if _is_hole(new[a:z])]
assert set(holes) == set(selected)
output = W / 'proof/ordered-phase-projection-open-02.spthy'
with output.open('x') as handle:
    handle.write(new)
record = {'failed_output_sha256': hashlib.sha256(source).hexdigest(),
          'new_input_sha256': hashlib.sha256(new.encode()).hexdigest(),
          'classification': 'Sixteen projected old proof methods were rejected under the ordered induction goal. The rejected replay is not accepted proof evidence.',
          'reopened_branches': [{'case_path': list(path),
                                  'failed_body_sha256': hashlib.sha256(body.encode()).hexdigest()}
                                 for path, (_, _, _, body) in selected.items()],
          'failed_original_input_output_and_all_branches_retained': True,
          'query_contracts_and_operational_model_unchanged': True,
          'no_failed_branch_deleted': True, 'checker_unchanged': True,
          'new_bounded_replay_required': True, 'security_proof_verified': False}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
with (stage / 'FAILURE_CLASSIFICATION.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'reopened_branches': len(holes), 'new_input_sha256': record['new_input_sha256']}))
