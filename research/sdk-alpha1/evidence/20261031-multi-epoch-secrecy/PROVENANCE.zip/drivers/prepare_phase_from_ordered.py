"""Check the unchanged equality proposition using only the ordered helper."""
from pathlib import Path
import hashlib
import json
import sys

W = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt/artifact')
from continuity_multi_epoch_search import theory
from continuity_proof_fragments import _lemma_span

PHASE = 'local_phase_event_is_unique_per_role_epoch_and_phase'
ORDERED = 'no_strictly_ordered_duplicate_local_phase'
source = (W / 'proof/ordered-phase-full-template-02.spthy').read_bytes()
assert hashlib.sha256(source).hexdigest() == 'd39a36574d036fb3a56bc85338106f2287ffbd1d7aad49cf32146f5f1f4f6a79'
contract = theory(source)
assert len(contract.queries) == 40
assert contract.queries[0].name == ORDERED and contract.queries[1].name == PHASE
text = source.decode()
for query in reversed(contract.queries):
    a, z = _lemma_span(text, query.name)
    text = text[:a] + ('\nby simplify\n\n' if query.name == PHASE else '\nby sorry\n\n') + text[z:]
assert theory(text.encode()) == contract
output = W / 'proof/phase-from-ordered-diagnostic-01.spthy'
with output.open('xb') as handle:
    handle.write(text.encode())
record = {'input_template_sha256': hashlib.sha256(source).hexdigest(),
          'output_sha256': hashlib.sha256(text.encode()).hexdigest(),
          'query_count': 40, 'all_query_contracts_and_model_unchanged': True,
          'target': PHASE, 'only_visible_prior_reusable_dependency': ORDERED,
          'ordered_candidate_not_yet_proved': True,
          'diagnostic_only': True, 'joint_replay_required': True}
with output.with_suffix('.preparation.json').open('x') as handle:
    handle.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
