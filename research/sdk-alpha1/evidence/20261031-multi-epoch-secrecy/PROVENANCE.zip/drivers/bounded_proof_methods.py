"""Extract the complete Tamarin method list from a bounded JSON response prefix.

The rendered constraint body is not needed to select an offered proof method.
The original response prefix must be retained separately and marked partial.
An incomplete method container is an error, never an empty successful result.
"""
from html.parser import HTMLParser
import json

RESPONSE_BOUND = 10 * 1024**2


class MethodList(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.current = None
        self.div_depth = 0
        self.method_depth = None
        self.containers = 0
        self.closed = False

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'div':
            self.div_depth += 1
            if set(attrs.get('class', '').split()) == {'preformatted', 'methods'}:
                if self.containers:
                    raise ValueError('Multiple method containers in the retained prefix')
                self.containers += 1
                self.method_depth = self.div_depth
        if tag == 'a' and 'proof-method' in attrs.get('class', '').split():
            if self.method_depth is None or self.closed or self.current is not None:
                raise ValueError('Proof method outside the single complete method container')
            self.current = {'href': attrs.get('href'), 'classes': attrs.get('class', ''), 'text': ''}

    def handle_data(self, value):
        if self.current is not None:
            self.current['text'] += value

    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.rows.append(self.current)
            self.current = None
        if tag == 'div':
            if self.method_depth == self.div_depth:
                if self.current is not None:
                    raise ValueError('Unterminated method link')
                self.closed = True
                self.method_depth = None
            self.div_depth -= 1
            if self.div_depth < 0:
                raise ValueError('Unbalanced method container')


def extract_complete_methods(raw: bytes) -> tuple[bytes, list[dict]]:
    if not 0 < len(raw) <= RESPONSE_BOUND + 1:
        raise ValueError('Response prefix is outside the unchanged bounded-read contract')
    if not raw.startswith(b'{"html":"<h3>Applicable Proof Methods:'):
        raise ValueError('Unexpected response prefix; cannot identify the method container')
    end = raw.find(b'</div>')
    if end < 0:
        raise ValueError('Complete method container is absent from the retained prefix')
    # This exact prefix ends inside the first JSON string, at a complete HTML
    # element boundary. JSON decoding still validates every original escape.
    html = json.loads(raw[:end + len(b'</div>')] + b'"}')['html']
    parser = MethodList()
    parser.feed(html)
    parser.close()
    if parser.containers != 1 or not parser.closed or parser.current is not None:
        raise ValueError('The retained HTML does not contain one complete method list')
    if parser.div_depth != 0 or not parser.rows:
        raise ValueError('Unbalanced or empty offered method list')
    if html.count('proof-method') != len(parser.rows):
        raise ValueError('Method-link count does not match the parsed complete container')
    for row in parser.rows:
        if not isinstance(row['href'], str) or not row['href'].startswith('/thy/trace/'):
            raise ValueError('Unexpected method link destination')
        if not row['text'].strip():
            raise ValueError('Empty proof method')
    extracted = json.dumps({'html': html, 'representation': 'complete-method-list-only'}, ensure_ascii=False).encode()
    return extracted, parser.rows
