from pathlib import Path
import importlib.util,json
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',stage/'client-02.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
_,links,_=c.decode((stage/'transcript-18-state.response').read_bytes())
rows=[(p,t) for p,t in links if '/main/proof/later_storage_access_defeats_fresh_reservations/' in p and p.endswith('/c_h')]
print(json.dumps(rows))
