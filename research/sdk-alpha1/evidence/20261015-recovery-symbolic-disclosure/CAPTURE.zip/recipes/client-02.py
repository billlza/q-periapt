from pathlib import Path
from urllib.request import urlopen
from html.parser import HTMLParser
import json,re,sys
STAGE=Path(__file__).resolve().parent
BASE=json.loads((STAGE/'SERVER_01.json').read_text())['url']
class Page(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.parts=[];self.current=None
 def handle_starttag(self,tag,attrs):
  if tag=='a':self.current=[dict(attrs).get('href',''),'']
 def handle_endtag(self,tag):
  if tag=='a' and self.current is not None:self.links.append(self.current);self.current=None
 def handle_data(self,data):
  self.parts.append(data)
  if self.current is not None:self.current[1]+=data

def decode(raw):
 try:value=json.loads(raw)
 except json.JSONDecodeError:value={'html':raw.decode()}
 if not isinstance(value,dict):raise ValueError('unexpected response')
 page=Page();page.feed(value.get('html',''))
 return value,[(p,re.sub(r'\s+',' ',t).strip()) for p,t in page.links],re.sub(r'\s+',' ',' '.join(page.parts)).strip()

def fetch(path,label):
 if path!='/' and not path.startswith('/thy/trace/'):raise ValueError('outside owned theory route')
 if any(x in path for x in ('/edit/','/delete/','/add/','/reload','/get_and_append/')):raise ValueError('model editing forbidden')
 with (STAGE/(label+'.request.json')).open('x') as f:json.dump({'path':path,'url':BASE+path},f)
 with urlopen(BASE+path,timeout=45) as response:raw=response.read(8*1024*1024+1)
 if len(raw)>8*1024*1024:raise ValueError('response exceeds bound')
 with (STAGE/(label+'.response')).open('xb') as out:out.write(raw)
 return decode(raw)

def show(value,links,text):
 print(json.dumps({'title':value.get('title'),'redirect':value.get('redirect'),'links':[(p,t[:340]) for p,t in links if any(x in p for x in ('/method/','/proof/','/download/','/overview/'))]},ensure_ascii=False))
 print(text.split('Applicable Proof Methods:',1)[-1][:3000])
if __name__=='__main__':show(*fetch(*sys.argv[1:]))
