from pathlib import Path
import importlib.util,json,hashlib,re
stage=Path(__file__).resolve().parent;root=Path.cwd()
spec=importlib.util.spec_from_file_location('client',stage/'client-02.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
_,links,_=c.decode((stage/'solved-35-state.response').read_bytes())
paths=list(dict.fromkeys(p for p,t in links if '/download/' in p))
if len(paths)!=1:raise ValueError('download link ambiguous')
c.fetch(paths[0],'export-36')
with (stage/'export-36.spthy').open('xb') as f:f.write((stage/'export-36.response').read_bytes())
a=(stage/'baseline-21.spthy').read_text();b=(stage/'export-36.spthy').read_text()
DECL=re.compile(r'(?ms)^lemma\s+\w+(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
EXPECTED=('generation_secret_origin','recovery_is_executable','clean_reservation_recovers_symbolic_message_secrecy','pre_cut_generation_reservation_remains_exposed','later_storage_access_defeats_fresh_reservations')
def check(candidate):
 if a.split('\nlemma ',1)[0]!=candidate.split('\nlemma ',1)[0]:raise ValueError('theory prefix changed')
 if len(DECL.findall(a))!=5 or DECL.findall(a)!=DECL.findall(candidate):raise ValueError('full lemma declarations changed')
 if tuple(re.findall(r'(?m)^lemma\s+(\w+)',candidate))!=EXPECTED:raise ValueError('lemma inventory changed')
 if re.search(r'(?m)^(rule|restriction|equations|functions|builtins)\b',candidate.split('\nlemma ',1)[1]):raise ValueError('extra theory declarations')
check(b)
mutations={
 'renamed_lemma':b.replace('lemma pre_cut_generation_reservation_remains_exposed:', 'lemma renamed:'),
 'changed_quantifier':b.replace('lemma pre_cut_generation_reservation_remains_exposed:\n  exists-trace','lemma pre_cut_generation_reservation_remains_exposed:\n  all-traces'),
 'added_reuse':b.replace('[use_induction]', '[use_induction,reuse]'),
 'changed_signature_equation':b.replace('verify(sign(x.1, x.2), x.1, pk(x.2)) = true','verify(sign(x.1, x.2), x.1, pk(x.2)) = x.1'),
 'changed_leak_condition':b.replace('IdentityLeak( any_session, r )', 'SignerFileCaptured( any_session, r )'),
 'extra_lemma':b.replace('\nend','\nlemma extra: "T" by sorry\nend')}
rejected=[]
for label,changed in mutations.items():
 if changed==b:raise ValueError('mutation not applied: '+label)
 try:check(changed)
 except ValueError:rejected.append(label)
 else:raise ValueError('semantic mutation accepted: '+label)
blocks={re.match(r'lemma\s+(\w+)',m.group()).group(1):m for m in DECL.finditer(b)}
missing=b
for index in (4,3):
 name=EXPECTED[index];start=blocks[name].end();end=blocks[EXPECTED[index+1]].start() if index<4 else b.rfind('\nend')
 missing=missing[:start]+'\nby sorry\n\n'+missing[end:]
check(missing)
with (stage/'missing-proof-36.spthy').open('x') as f:f.write(missing)
canonical=root/'research/continuity-recovery-symbolic/protected-state.spthy'
canonical_hash=hashlib.sha256(canonical.read_bytes()).hexdigest()
if canonical_hash!=json.loads((stage/'SERVER_01.json').read_text())['canonical_sha256']:raise ValueError('canonical source changed')
with (stage/'SEMANTICS_36.json').open('x') as f:json.dump({'completed':True,'canonical_sha256':canonical_hash,'full_lemma_declarations_unchanged':5,'rules_equations_restrictions_unchanged':True,'certificate_sha256':hashlib.sha256(b.encode()).hexdigest(),'semantic_substitutions_rejected':rejected,'missing_proofs_semantically_unchanged':True},f,indent=2)
print('Exported both disclosure proofs; unchanged semantics; 6 substitutions rejected; proof-removal control prepared')
