from pathlib import Path
import json,os,re,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
source=stage/'export-36.spthy';argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS']
start=time.monotonic();timed_out=False
with (stage/'isolate-42.stdout').open('xb') as out,(stage/'isolate-42.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/'ISOLATE_STARTED_42.json',{'argv':argv,'pid':p.pid,'maximum_seconds':300,'theory_sha256':sdk.snapshot(source).sha256})
 try:code=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
receipt={'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'theory_sha256':sdk.snapshot(source).sha256,'proof_search_requested':False,'completed':False,'accepted':False}
sdk.write_json(stage/'ISOLATE_TERMINAL_42.json',receipt)
sdk.require(code==0 and not timed_out,'isolated replay lacks successful terminal result')
summary=(stage/'isolate-42.stdout').read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|analysis incomplete) \((\d+) steps\)',summary,re.M)
sdk.require(len(parsed)==5,'missing exact terminal summary')
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
sdk.require(results['recovery_is_executable']=={'status':'verified','steps':59},'honest witness changed')
sdk.require(results['later_storage_access_defeats_fresh_reservations']=={'status':'verified','steps':45},'later witness changed')
sdk.require(results['pre_cut_generation_reservation_remains_exposed']['status']=='verified','precut witness incomplete')
sdk.require(all(results[n]=={'status':'analysis incomplete','steps':1} for n in ('generation_secret_origin','clean_reservation_recovers_symbolic_message_secrecy')),'unexpected result')
sdk.write_json(stage/'ISOLATE_VERIFIED_42.json',dict(receipt,completed=True,accepted=True,results=results))
print(json.dumps({'completed':True,'results':results,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
