from pathlib import Path
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.command(['gh','run','view','38692152632','--repo','billlza/q-periapt','--json','status,conclusion,headSha,jobs,url','--jq','{status,conclusion,headSha,url,jobs:[.jobs[]|{name,status,conclusion,startedAt,completedAt}]}'],stage/'codeql-39',root)
print((stage/'codeql-39.stdout').read_text())
