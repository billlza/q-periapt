from pathlib import Path
import json,re,sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;mode=sys.argv[1]
sdk.require(mode in ('combined','missing'),'unknown verification mode')
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
source=stage/('export-36.spthy' if mode=='combined' else 'missing-proof-36.spthy')
args=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--derivcheck-timeout=60','--quit-on-warning']
if mode=='combined':args+=['--prove=generation_secret_origin','--heuristic=s']
args+=['+RTS','-N2','-M2G','-RTS'];prefix=stage/(mode+'-38')
sdk.command(args,prefix,root)
text=prefix.with_suffix('.stdout').read_text();summary=text.rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|analysis incomplete) \((\d+) steps\)',summary,re.M)
sdk.require(len(parsed)==5,'missing exact terminal summary')
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
sdk.require(results['recovery_is_executable']=={'status':'verified','steps':59},'previous honest witness changed')
positive='clean_reservation_recovers_symbolic_message_secrecy';precut='pre_cut_generation_reservation_remains_exposed';later='later_storage_access_defeats_fresh_reservations'
sdk.require(results[positive]=={'status':'analysis incomplete','steps':1},'unexpected recovery-secrecy result')
if mode=='combined':
 sdk.require(results['generation_secret_origin']=={'status':'verified','steps':182},'provenance proof changed')
 sdk.require(results[later]=={'status':'verified','steps':45},'later-snapshot proof changed')
 sdk.require(results[precut]['status']=='verified','pre-cut witness incomplete')
else:
 sdk.require(all(results[n]=={'status':'analysis incomplete','steps':1} for n in ('generation_secret_origin',precut,later)),'missing proof incorrectly accepted')
sdk.write_json(stage/(mode.upper()+'_38.json'),{'completed':True,'theory_sha256':sdk.snapshot(source).sha256,'results':results,'new_disclosure_proofs_accepted':mode=='combined','removed_proofs_rejected':mode=='missing','release_claim_eligible':False})
print(json.dumps({'mode':mode,'results':results}),flush=True)
