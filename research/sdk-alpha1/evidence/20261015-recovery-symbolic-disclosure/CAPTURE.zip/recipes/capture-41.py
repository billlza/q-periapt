from pathlib import Path
import hashlib,json,re,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
verified=json.loads((stage/'COMBINED_VERIFIED_44.json').read_text());semantic=json.loads((stage/'SEMANTICS_36.json').read_text());missing=json.loads((stage/'MISSING_38.json').read_text())
isolated=json.loads((stage/'ISOLATE_VERIFIED_42.json').read_text())
sdk.require(isolated['completed'] and isolated['accepted'] and isolated['theory_sha256']==verified['theory_sha256'],'independent witness replay incomplete')
sdk.require(json.loads((stage/'combined-38.json').read_text())['returncode']==251 and 'Heap exhausted' in (stage/'combined-38.stderr').read_text(),'initial heap failure not retained')
results=verified['results'];accepted={n:r['steps'] for n,r in results.items() if r['status']=='verified'};unproved=[n for n,r in results.items() if r['status']=='analysis incomplete']
sdk.require(verified['completed'] and len(accepted)==4 and unproved==['clean_reservation_recovers_symbolic_message_secrecy'],'combined proof results differ')
sdk.require(semantic['completed'] and len(semantic['semantic_substitutions_rejected'])==6 and semantic['full_lemma_declarations_unchanged']==5,'semantic checks incomplete')
sdk.require(missing['completed'] and missing['removed_proofs_rejected'] and not missing['new_disclosure_proofs_accepted'],'missing-proof control not enforced')
sdk.require(json.loads((stage/'CLEANUP_37.json').read_text())['completed'],'owned server cleanup incomplete')
sdk.require(sdk.snapshot(stage/'export-36.spthy').sha256==verified['theory_sha256']==semantic['certificate_sha256'],'proof certificate changed')
sdk.require(sdk.snapshot(root/'research/continuity-recovery-symbolic/protected-state.spthy').sha256==semantic['canonical_sha256'],'canonical model changed')
requests=[json.loads(p.read_text()) for p in stage.glob('*.request.json')]
mutations=[row['path'] for row in requests if '/main/method/' in row['path']]
counts={n:sum('/method/'+n+'/' in p for p in mutations) for n in ('pre_cut_generation_reservation_remains_exposed','later_storage_access_defeats_fresh_reservations')}
sdk.require(len(mutations)==sum(counts.values())==67 and sorted(counts.values())==[24,43],'unexpected proof-method actions')
sdk.require(all(re.fullmatch(r'/thy/trace/[0-9]+/main/method/(?:pre_cut_generation_reservation_remains_exposed|later_storage_access_defeats_fresh_reservations)/[0-9]+(?:/.*)?',p) for p in mutations),'unexpected proof method route')
sdk.require(not any(any(part in row['path'] for part in ('/edit/','/delete/','/add/','/reload','/get_and_append/')) for row in requests),'model editing action present')
files={}
def add(path,name):
 sdk.require(name not in files,'duplicate archive member');files[name]=sdk.snapshot(path,maximum=16*1024**2).data
for path in stage.iterdir():
 if not path.is_file():continue
 if path.suffix=='.spthy':folder='proof/'
 elif path.suffix=='.py':folder='recipes/'
 elif path.suffix in ('.response','.html'):folder='interactive/'
 elif path.suffix in ('.json','.stdout','.stderr'):folder='receipts/'
 elif path.suffix=='.txt':folder='diagnostics/'
 else:raise ValueError('unexpected top-level evidence file: '+path.name)
 add(path,folder+path.name)
add(stage/'model/transition.spthy','proof/initial-certificate.spthy')
add(root/'research/continuity-recovery-symbolic/protected-state.spthy','source/protected-state.spthy')
add(root/'target/continuity-recovery-interactive-20261015/baseline-21.spthy','proof/prior-bare-export.spthy')
add(root/'research/continuity-recovery-symbolic/README.md','source/research-README.md')
add(root/'docs/continuity/RECOVERY_DEPENDENCIES_V1.md','source/RECOVERY_DEPENDENCIES_V1.md')
prior=root/'target/continuity-recovery-symbolic-20261015'
for name in ['TOOLS_08.json','tool-contract-09.json','tool-contract-09.stdout','tool-contract-09.stderr']:add(prior/name,'toolchain/'+name)
output=root/'research/sdk-alpha1/evidence/20261015-recovery-symbolic-disclosure';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'format':1,'base_commit':'232ca85a32c555f8769deeba1fb14c455195ac2c','capture_sha256':sdk.snapshot(archive,maximum=64*1024**2).sha256,
 'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},'canonical_source_sha256':semantic['canonical_sha256'],'certificate_sha256':verified['theory_sha256'],
 'verified_lemmas':accepted,'unproved_lemmas':unproved,'interactive_proof_method_actions':counts,'rules_equations_restrictions_unchanged':True,'all_five_lemma_declarations_unchanged':True,
 'semantic_mutations_rejected':6,'missing_proofs_rejected_despite_exit_zero':True,'owned_server_closed':True,'production_code_changed':False,'release_claim_eligible':False}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as z:
 sdk.require(len(z.namelist())==len(set(z.namelist()))==len(files),'archive inventory differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(z.read(name)).hexdigest()==digest,'archive member digest differs')
 sdk.require(hashlib.sha256(z.read('proof/export-36.spthy')).hexdigest()==manifest['certificate_sha256'],'archived certificate differs')
 for record in ['receipts/REPLAY_22.json','receipts/COMBINED_VERIFIED_44.json','receipts/ISOLATE_VERIFIED_42.json','receipts/MISSING_38.json','receipts/CLEANUP_37.json']:sdk.require(json.loads(z.read(record))['completed'],'archived final check incomplete')
sdk.write_json(output/'READBACK.json',{'completed':True,'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemma_count':4,'unproved_lemma_count':1,'private_sdk_runtime_data_selected':False})
print(json.dumps({'capture_sha256':manifest['capture_sha256'],'members':len(files),'verified_lemmas':accepted,'unproved_lemmas':unproved}))
