from pathlib import Path
import importlib.util,json,contextlib,io
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('advance',stage/'advance-05.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
source='later-05-state.response'
for index in range(8):
 _,links,_=a.client.decode((stage/source).read_bytes())
 choices=[t for p,t in links if '/main/method/' in p and t.startswith(('solve( CutPermit(', 'solve( !Wrap(', 'solve( OfferStart(', 'solve( ResponseStart(', 'solve( !Pinned('))]
 if not choices:raise ValueError('setup stopped early')
 with contextlib.redirect_stdout(io.StringIO()):source,summary,text=a.advance(source,choices[0],'setup-06-'+str(index))
 print('Applied: '+choices[0],flush=True)
print(json.dumps({'source':source,'methods':summary['next_methods']},ensure_ascii=False))
