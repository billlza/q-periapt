from pathlib import Path
import hashlib,json,os,signal,socket,subprocess,time
root=Path.cwd();stage=Path(__file__).resolve().parent;model=stage/'model';model.mkdir()
source=root/'target/continuity-recovery-interactive-20261015/export-19.spthy'
canonical=root/'research/continuity-recovery-symbolic/protected-state.spthy'
(model/'transition.spthy').write_bytes(source.read_bytes())
tools=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
with socket.socket() as listener:
 listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
argv=[tools['tamarin'],'interactive','--interface=127.0.0.1','--port='+str(port),'--with-maude='+tools['maude'],'--derivcheck-timeout=60','--quit-on-warning',str(model),'+RTS','-N2','-M2G','-RTS']
start=time.monotonic();timed_out=False
with (stage/'server-01.stdout').open('xb') as out,(stage/'server-01.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 (stage/'SERVER_01.json').write_text(json.dumps({'pid':p.pid,'port':port,'url':'http://127.0.0.1:'+str(port),'argv':argv,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'canonical_sha256':hashlib.sha256(canonical.read_bytes()).hexdigest(),'maximum_seconds':1200},indent=2)+'\n')
 print('Owned local proof server started: '+str(port),flush=True)
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
 (stage/'SERVER_TERMINAL_01.json').write_text(json.dumps({'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
 print('Owned local proof server terminal: '+str(code),flush=True)
