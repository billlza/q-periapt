from pathlib import Path
import importlib.util,json,hashlib,re
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',stage/'client-02.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
for state,label in [('overview-03.response','baseline-21'),('transcript-18-state.response','export-21')]:
 _,links,_=c.decode((stage/state).read_bytes())
 paths=list(dict.fromkeys(p for p,t in links if '/download/' in p))
 if len(paths)!=1:raise ValueError('download link ambiguous')
 c.fetch(paths[0],label)
 with (stage/(label+'.spthy')).open('xb') as f:f.write((stage/(label+'.response')).read_bytes())
a=(stage/'baseline-21.spthy').read_text();b=(stage/'export-21.spthy').read_text()
pattern=r'(?ms)^lemma\s+\w+(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"'
if a.split('\nlemma ',1)[0]!=b.split('\nlemma ',1)[0]:raise ValueError('theory prefix changed')
if len(re.findall(pattern,a))!=5 or re.findall(pattern,a)!=re.findall(pattern,b):raise ValueError('full lemma declarations changed')
prior=stage.parent/'continuity-recovery-interactive-20261015/baseline-21.spthy'
p=prior.read_text()
if p.split('\nlemma ',1)[0]!=a.split('\nlemma ',1)[0] or re.findall(pattern,p)!=re.findall(pattern,a):raise ValueError('closed theory differs from prior bare-model export')
with (stage/'SEMANTICS_21.json').open('x') as f:json.dump({'completed':True,'canonical_model_unchanged':True,'full_lemma_declarations_unchanged':5,'rules_equations_restrictions_unchanged':True,'certificate_sha256':hashlib.sha256(b.encode()).hexdigest()},f,indent=2)
print('Exported current witness; full theory semantics and all 5 declarations unchanged')
