from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
verified=json.loads((stage/'COMBINED_VERIFIED_44.json').read_text());sdk.require(verified['completed'] and verified['accepted'],'combined proof not verified')
precut=verified['results']['pre_cut_generation_reservation_remains_exposed']['steps']
path=root/'research/continuity-recovery-symbolic/README.md';old=path.read_text()
sdk.require(old.startswith('# Continuity recovery transition research\n\nStatus: **two checked statements:'),'research status changed')
start=old.index('## Modeled boundaries')
intro=f'''# Continuity recovery transition research

Status: **four checked statements: generated-key provenance, an honest execution
witness, and two specified disclosure witnesses.** The all-traces recovery-secrecy
claim remains unproved. This directory is not a release proof gate; the full
0.2.0 construction, shared-device lifecycle, computational argument and external
review remain open.

[`protected-state.spthy`](protected-state.spthy) is an unchanged symbolic projection
of one identity-authenticated rekey exchange. `generation_secret_origin` is
verified by Tamarin 1.12.0 / Maude 3.5.1 using induction: 182 steps. It gives a
necessary condition for knowing an honest generated decapsulation key: modeled
generation-entropy leakage or acquisition of a phase-1/2/3 record. It is not a
causal timing bound or a recovery-secrecy theorem. The lemma is not marked
`reuse`; no unproved lemma is imported as an assumption.

The checked existential statements are:

| Statement | Checked steps | What the trace establishes |
| --- | ---: | --- |
| `recovery_is_executable` | 59 | Cut precedes both fresh reservations; both peers confirm before an application event, with no additional leakage. |
| `pre_cut_generation_reservation_remains_exposed` | {precut} | One phase-1 capture precedes Cut; after wrapping-key exposure and a fresh response, the captured generation key permits decryption after both peers confirm. |
| `later_storage_access_defeats_fresh_reservations` | 45 | Both reservations follow Cut; one phase-8 capture after the application event exposes the new root and permits decryption. |

Each disclosure witness permits exactly one Snapshot globally and excludes
additional identity/entropy leaks. The pre-cut trace does not obtain a later
root snapshot: it obtains the generation key from the earlier record, decapsulates
the public response and reconstructs the root. These are two distinct failures of
insufficient recovery conditions, not proofs of recovery under sufficient ones.
They also do not establish a multi-epoch exposure bound for the actual SDK.

The [disclosure checkpoint](../sdk-alpha1/evidence/20261015-recovery-symbolic-disclosure/README.md)
retains 67 proof-method applications, unchanged rules/equations/restrictions and
all five full lemma declarations. A fresh process verifies all four statements
on the same exported input; only provenance uses automatic proof search. The
2 GiB combined attempt failed with heap exhaustion and is retained. Verification
uses a 4 GiB heap limit without changing the model or weakening a query. Removing
both disclosure proof scripts leaves their queries incomplete despite exit zero;
six substitutions of semantic declarations are also rejected.

`clean_reservation_recovers_symbolic_message_secrecy` remains **analysis
incomplete**, and is not accepted. The historical
[execution checkpoint](../sdk-alpha1/evidence/20261015-recovery-symbolic-execution/README.md)
and [initial checkpoint](../sdk-alpha1/evidence/20261015-recovery-symbolic/README.md)
retain their earlier results and failed searches. Generated certificates contain
placeholders for unselected lemmas and unused existential branches. Acceptance
uses exact terminal lemma results, not exit zero or a search for a word. The bare
model remains editable source; the certificate is evidence.

'''
new=intro+old[start:]
new=new.replace('extract `proof/export-19.spthy` from the execution\ncheckpoint\'s `CAPTURE.zip` and replay it:', 'extract `proof/export-36.spthy` from the disclosure\ncheckpoint\'s `CAPTURE.zip` and replay the stored proof methods:')
new=new.replace('export-19.spthy --derivcheck-timeout=60 --quit-on-warning', 'export-36.spthy --derivcheck-timeout=60 --quit-on-warning').replace('+RTS -N2 -M2G -RTS', '+RTS -N2 -M4G -RTS')
new=new.replace('Adding `--prove=generation_secret_origin --heuristic=s` also verifies provenance\non the same input. Neither accepted invocation uses a proof-depth bound.', 'The accepted combined invocation adds\n`--prove=generation_secret_origin --heuristic=s` to verify provenance on the same\ninput. It uses no proof-depth bound. See the checkpoint for separate replay and\nresource-limited attempt outcomes.')
path.write_text(new)
path=root/'docs/continuity/RECOVERY_DEPENDENCIES_V1.md';old=path.read_text()
start=old.index('A [symbolic research projection]')
sdk.require('the two specified symbolic disclosure witnesses remain unproved' in old[start:],'dependency status changed')
path.write_text(old[:start]+f'''A [symbolic research projection](../../research/continuity-recovery-symbolic/README.md)
now has four checked statements under explicit ideal-primitive and protected-state
assumptions: generated-key provenance (182 steps), honest execution (59), pre-cut
generation-record disclosure ({precut}), and later phase-8 disclosure (45). Both
disclosure traces permit exactly one Snapshot and exclude extra identity or
entropy leakage. They show why retained generation material and continued access
to new records require distinct recovery conditions; they do not prove that the
positive conditions suffice. All rules and five complete declarations remain
unchanged. The all-traces recovery-secrecy query is still unproved. Independent
instances do not model shared-device journals, and these results do not close the
construction-specific recovery argument required above.
''')
print('Updated current research status from terminal proof results; all-traces secrecy remains open')
