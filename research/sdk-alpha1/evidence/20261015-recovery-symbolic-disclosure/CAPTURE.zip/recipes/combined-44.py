from pathlib import Path
import json,os,re,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
previous=json.loads((stage/'combined-38.json').read_text());sdk.require(previous['returncode']==251 and 'Heap exhausted' in (stage/'combined-38.stderr').read_text(),'previous resource failure not established')
source=stage/'export-36.spthy';argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--derivcheck-timeout=60','--quit-on-warning','--prove=generation_secret_origin','--heuristic=s','+RTS','-N2','-M4G','-s','-RTS']
start=time.monotonic();timed_out=False
with (stage/'combined-44.stdout').open('xb') as out,(stage/'combined-44.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/'COMBINED_STARTED_44.json',{'argv':argv,'pid':p.pid,'maximum_seconds':600,'theory_sha256':sdk.snapshot(source).sha256,'previous_heap_limit_mib':2048,'heap_limit_mib':4096})
 try:code=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
receipt={'argv':argv,'returncode':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'theory_sha256':sdk.snapshot(source).sha256,'heap_limit_mib':4096,'accepted':False}
sdk.write_json(stage/'COMBINED_TERMINAL_44.json',receipt)
sdk.require(code==0 and not timed_out,'combined replay lacks successful terminal result')
summary=(stage/'combined-44.stdout').read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|analysis incomplete) \((\d+) steps\)',summary,re.M)
sdk.require(len(parsed)==5,'missing exact terminal summary')
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
sdk.require(results['generation_secret_origin']=={'status':'verified','steps':182},'provenance changed')
sdk.require(results['recovery_is_executable']=={'status':'verified','steps':59},'honest witness changed')
sdk.require(results['later_storage_access_defeats_fresh_reservations']=={'status':'verified','steps':45},'later witness changed')
sdk.require(results['pre_cut_generation_reservation_remains_exposed']['status']=='verified','precut witness incomplete')
sdk.require(results['clean_reservation_recovers_symbolic_message_secrecy']=={'status':'analysis incomplete','steps':1},'unexpected recovery-secrecy result')
sdk.write_json(stage/'COMBINED_VERIFIED_44.json',dict(receipt,completed=True,accepted=True,results=results,model_semantics_changed=False,previous_failed_attempt_retained=True,release_claim_eligible=False))
print(json.dumps({'completed':True,'results':results,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
