from pathlib import Path
import importlib.util,json,sys
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',stage/'client-02.py');client=importlib.util.module_from_spec(spec);spec.loader.exec_module(client)
def advance(source,selector,label,mode='method'):
 _,links,_=client.decode((stage/source).read_bytes())
 if mode=='method':choices=[(p,t) for p,t in links if '/main/method/' in p and selector in t]
 elif mode=='branch':choices=list(dict.fromkeys((p,t) for p,t in links if '/main/proof/' in p and p.endswith(selector) and t=='sorry'))
 else:raise ValueError('invalid mode')
 if len(choices)!=1:raise ValueError('selector must match one observed choice: '+repr(choices))
 path,method=choices[0]
 with (stage/(label+'-attempt.json')).open('x') as f:json.dump({'path':path,'method':method,'source':source,'mode':mode},f)
 value,links,text=client.fetch(path,label+'-apply')
 if 'redirect' in value:value,links,text=client.fetch(value['redirect'],label+'-state')
 else:
  with (stage/(label+'-state.response')).open('xb') as f:f.write((stage/(label+'-apply.response')).read_bytes())
 summary={'method':method,'next_methods':[(p,t) for p,t in links if '/main/method/' in p], 'branches':list(dict.fromkeys((p,t) for p,t in links if '/main/proof/later_storage_access_defeats_fresh_reservations/' in p and t in ('sorry','SOLVED'))),'downloads':[(p,t) for p,t in links if '/download/' in p]}
 with (stage/(label+'-summary.json')).open('x') as f:json.dump(summary,f,indent=2)
 print(json.dumps({'method':method[:180],'next_methods':[(p,t[:280]) for p,t in summary['next_methods']],'branches':summary['branches'][-10:]},ensure_ascii=False))
 print(text.split('Applicable Proof Methods:',1)[-1][:1400])
 return label+'-state.response',summary,text
if __name__=='__main__':advance(*sys.argv[1:])
