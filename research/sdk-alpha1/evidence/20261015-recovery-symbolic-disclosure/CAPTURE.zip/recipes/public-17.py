from pathlib import Path
import importlib.util,json,contextlib,io
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('advance',stage/'advance-05.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
source='chain-16-state.response'
for index in range(5):
 _,links,_=a.client.decode((stage/source).read_bytes())
 choices=[t for p,t in links if '/main/method/' in p and t.startswith('solve( !KU(') and "h(<'traffic-transcript'" not in t]
 if not choices:raise ValueError('public goals stopped early')
 chosen=min(choices,key=len)
 with contextlib.redirect_stdout(io.StringIO()):source,summary,text=a.advance(source,chosen,'public-17-'+str(index))
 print('Applied: '+chosen[:140],flush=True)
print(json.dumps({'source':source,'methods':summary['next_methods']},ensure_ascii=False))
