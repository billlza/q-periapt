from pathlib import Path
import importlib.util,json,contextlib,io,sys
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('advance',stage/'precut-24.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
source,prefix,*selectors=sys.argv[1:]
if not 1<=len(selectors)<=32:raise ValueError('step bound invalid')
for index,selector in enumerate(selectors):
 if selector=='setup':
  _,links,_=a.client.decode((stage/source).read_bytes())
  choices=[t for p,t in links if '/main/method/'+a.TARGET+'/' in p and t.startswith(('solve( CutPermit(', 'solve( !Wrap(', 'solve( OfferStart(', 'solve( ResponseStart(', 'solve( !Pinned('))]
  if not choices:raise ValueError('no setup goal')
  selector=choices[0]
 with contextlib.redirect_stdout(io.StringIO()):source,summary,text=a.advance(source,selector,prefix+'-'+str(index))
 print('Applied: '+summary['method'][:110],flush=True)
print(json.dumps({'source':source,'methods':[(p,t[:260]) for p,t in summary['next_methods']],'branches':summary['branches'][-3:]},ensure_ascii=False))
