from pathlib import Path
import json,re
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
args=[t['tamarin'],'--with-maude='+t['maude'],str(stage/'export-21.spthy'),'--derivcheck-timeout=60','--quit-on-warning','+RTS','-N2','-M2G','-RTS']
sdk.command(args,stage/'replay-22',root)
text=(stage/'replay-22.stdout').read_text();summary=text.rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|analysis incomplete) \((\d+) steps\)',summary,re.M)
sdk.require(len(parsed)==5,'missing exact terminal summary')
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
sdk.require(results['recovery_is_executable']=={'status':'verified','steps':59},'previous honest witness changed')
sdk.require(results['later_storage_access_defeats_fresh_reservations']['status']=='verified','later snapshot witness incomplete')
sdk.require(all(results[n]['status']=='analysis incomplete' for n in ('generation_secret_origin','clean_reservation_recovers_symbolic_message_secrecy','pre_cut_generation_reservation_remains_exposed')),'unexpected extra proof result')
sdk.write_json(stage/'REPLAY_22.json',{'completed':True,'theory_sha256':sdk.snapshot(stage/'export-21.spthy').sha256,'results':results,'proof_search_requested':False,'release_claim_eligible':False})
print(json.dumps(results),flush=True)
