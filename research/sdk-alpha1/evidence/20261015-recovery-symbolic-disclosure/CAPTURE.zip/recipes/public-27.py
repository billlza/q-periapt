from pathlib import Path
import importlib.util,json,contextlib,io
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('advance',stage/'precut-24.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
source='confirmation-26-8-state.response'
for index in range(10):
 _,links,_=a.client.decode((stage/source).read_bytes())
 choices=[t for p,t in links if '/main/method/'+a.TARGET+'/' in p and t.startswith('solve( !KU(') and '~payload' not in t]
 if not choices:raise ValueError('public goals stopped early')
 chosen=min(choices,key=len)
 with contextlib.redirect_stdout(io.StringIO()):source,summary,text=a.advance(source,chosen,'public-27-'+str(index))
 print('Applied: '+chosen[:100],flush=True)
print(json.dumps({'source':source,'methods':summary['next_methods']},ensure_ascii=False))
