from pathlib import Path
import json,os,signal,socket,subprocess,time
stage=Path(__file__).resolve().parent;meta=json.loads((stage/'SERVER_01.json').read_text())
cmd=subprocess.check_output(['ps','-p',str(meta['pid']),'-o','command='],text=True)
if meta['argv'][0] not in cmd or '--port='+str(meta['port']) not in cmd:raise ValueError('owned process identity mismatch')
os.killpg(meta['pid'],signal.SIGINT)
end=time.monotonic()+10
while time.monotonic()<end:
 result=subprocess.run(['ps','-p',str(meta['pid']),'-o','pid='],text=True,capture_output=True)
 if result.returncode==1:break
 if result.returncode!=0:raise ValueError('process inspection failed')
 time.sleep(0.1)
else:raise ValueError('owned server still live')
with socket.socket() as connection:
 connection.settimeout(1)
 try:connection.connect(('127.0.0.1',meta['port']))
 except ConnectionRefusedError:pass
 else:raise ValueError('owned port still accepts connections')
with (stage/'CLEANUP_37.json').open('x') as f:json.dump({'completed':True,'owned_pid_absent':True,'owned_port_refused':True,'termination':'intentional SIGINT after proof export','private_sdk_state_accessed':False},f,indent=2)
print('Owned symbolic server closed after export; no private SDK state accessed')
