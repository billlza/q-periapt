from pathlib import Path
import hashlib,json,runpy,subprocess,sys,zipfile
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
stage=ROOT/'target/continuity-installed-resource-baseline'
destination=ROOT/'research/sdk-alpha1/evidence/20261104-installed-resource-baseline';destination.mkdir()
build=json.loads((stage/'build-03/OBSERVER_BUILD.json').read_bytes())
readback=json.loads((stage/'READBACK.json').read_bytes())
assert build['completed'] and readback['completed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==build['source_commit']
assert not subprocess.check_output(['git','diff','HEAD','--','crates','research/continuity-identity-candidate'],cwd=ROOT)
files={}
for path in stage.rglob('*'):
    if not path.is_file():continue
    relative=path.relative_to(stage).as_posix()
    if path.name=='archive.py':continue
    # Public synthetic effects have extensionless original message IDs. No
    # private installation tree is below stage; those remain outside checkout.
    if relative.startswith('public-effects/') or path.suffix in ('.json','.stdout','.stderr','.py','.toml','.lock','.rs','.c','.txt'):
        files[relative]=path.read_bytes()
files['driver/archive.py']=Path(__file__).read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
with zipfile.ZipFile(destination/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16
        info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,data)
reader=runpy.run_path(str(stage/'review.py'))
with zipfile.ZipFile(destination/'CAPTURE.zip') as archive:
    assert archive.namelist()==sorted(files)
    for name,row in manifest.items():
        data=archive.read(name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    for label,profile in reader['CASES']:
        value=json.loads(archive.read(label+'/RESULT.json'));run=json.loads(archive.read(label+'/RUN.json'))
        stdout=archive.read(label+'/runtime.stdout').decode()
        prefix='public-effects/'+label+'/effects/'
        effects={name[len(prefix):]:archive.read(name) for name in archive.namelist() if name.startswith(prefix)}
        reader['validate'](value,run,stdout,effects,profile)
sdk.write_json(destination/'SHA256.json',manifest)
sdk.write_json(destination/'SUMMARY.json',readback)
sdk.write_json(destination/'CHECKS.json',{
    'source_commit':build['source_commit'],'candidate_source_commit':build['candidate_source_commit'],
    'candidate_archive_sha256':build['candidate_archive_sha256'],'sdk_report_sha256':build['sdk_report_sha256'],
    'observer_binary_sha256':build['binary_sha256'],'installed_resolution':build['resolution'],
    'completed_runtime_cohorts':4,'business_effects_checked':500,'negative_controls_rejected':548,
    'strict_build_and_clippy':True,'product_code_changed':False,
    'original_capacity_reader_reused_without_weakened_assertions':True,
    'failed_build_attempts_retained':['build-01','build-02'],
    'build02_report_name_collided_with_compile_receipt_on_case_insensitive_filesystem':True,
    'build03_completed':True,'all_archive_members_reread':True,'all_four_business_and_resource_censuses_revalidated_from_archive':True,
    'hardware':'Apple M4 Max, 16 logical CPUs, 48 GiB RAM','macos_version':'26.7.2',
    'allocator_environment':'inherited MallocNanoZone=0 observed during the collection; earlier runs lack separate per-process environment receipts',
    'formal_resource_budget_qualified':False,'cross_host_qualified':False,'device_energy_qualified':False,
    'capture_members':len(files),'capture_uncompressed_bytes':sum(map(len,files.values())),
    'capture_sha256':sdk.snapshot(destination/'CAPTURE.zip').sha256,
    'release_claim_eligible':False,'publication_performed':False})
print(json.dumps({'members':len(files),'bytes':sum(map(len,files.values())),
                  'sha256':sdk.snapshot(destination/'CAPTURE.zip').sha256}))
