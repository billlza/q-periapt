"""Read back the fixed installed capacity workload and its public observations."""
from pathlib import Path
import copy,hashlib,json,math,re,runpy,sys
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
from evidence_io import parse_strict_json_bytes
stage=ROOT/'target/continuity-installed-resource-baseline'
original=runpy.run_path(str(stage/'historical/receipts/review-native-16.py'))
require=sdk.require
CASES=(('local-01','local'),('witness-01','witness'),('witness-02','witness'),('local-02','local'))

def validate(value,run,stdout,effects,profile):
    summary=original['validate'](value,run,stdout,effects)
    require(value['profile']==run['profile']==profile,'policy profile differs')
    page_sizes=set()
    for row in value['resources']:
        page=row['vm_page_size_bytes']
        require(type(page) is int and page>0 and page & (page-1)==0,'invalid page unit')
        page_sizes.add(page)
        for field in ('malloc_blocks_in_use','malloc_size_in_use_bytes','malloc_max_size_in_use_bytes','malloc_size_allocated_bytes'):
            require(type(row[field]) is int and row[field]>=0,'invalid malloc counter')
        tags=row['vm_tags']
        require(type(tags) is list and tags and any(t['resident_pages']>0 for t in tags),'empty VM observation')
        require([t['tag'] for t in tags]==sorted({t['tag'] for t in tags}),'duplicate or unordered VM tag')
        for tag in tags:
            require(type(tag['tag']) is int and 0<=tag['tag']<256,'invalid VM tag')
            for field in ('regions','virtual_bytes','resident_pages','dirty_pages','swapped_pages','reusable_pages',
                          'external_resident_pages','internal_pager_resident_pages'):
                require(type(tag[field]) is int and tag[field]>=0,'invalid VM count')
            require(tag['regions']>0 and tag['virtual_bytes']>0,'empty published tag')
            require(tag['external_resident_pages']+tag['internal_pager_resident_pages']==tag['resident_pages'],
                    'VM pager partition differs')
    require(len(page_sizes)==1 and 'pressure_probe' not in value,'page size changed or unexpected intervention')
    witness=value['witness'];capacity=value['witness_at_capacity']
    require(witness['closed'] is True,'witness worker did not close')
    if profile=='local':
        require(witness=={'closed':True,'rows':[]} and capacity=={'requests':0},'local profile has unexpected witness activity')
        witness_bytes=0;witness_requests=0
    else:
        rows=witness['rows'];require(type(rows) is list and 0<len(rows)<=16384,'witness census absent or exceeds observer bound')
        require(set(witness)=={'closed','rows','handle_ns','read_ns','write_ns','framed_bytes'},'witness result fields differ')
        for row in rows:
            require(set(row)=={'request_tag','reply_tag','read_ns','handle_ns','write_ns'},'witness observation fields differ')
            for field in ('request_tag','reply_tag'):
                require(type(row[field]) is int and 0<=row[field]<=255,'witness tag type differs')
            for field in ('read_ns','handle_ns','write_ns'):
                require(type(row[field]) is int and row[field]>0,'invalid witness interval')
        for field in ('read_ns','handle_ns','write_ns'):
            require(witness[field]==sum(row[field] for row in rows),'witness duration sum differs')
        require(witness['framed_bytes']==len(rows)*7341,'witness frame accounting differs')
        n=capacity['requests'];require(type(n) is int and 0<n<=len(rows),'capacity witness prefix differs')
        require(set(capacity)=={'requests','read_ns','handle_ns','write_ns','framed_bytes'},'capacity witness fields differ')
        for field in ('read_ns','handle_ns','write_ns'):
            require(capacity[field]==sum(row[field] for row in rows[:n]),'capacity witness prefix sum differs')
        require(capacity['framed_bytes']==n*7341,'capacity witness byte prefix differs')
        witness_bytes=witness['framed_bytes'];witness_requests=len(rows)
    for key in ('real_seconds','user_seconds','system_seconds'):
        require(type(run['resources'][key]) in (int,float) and math.isfinite(run['resources'][key])
                and run['resources'][key]>0,'invalid external process interval')
    sample_times=sorted(row['commit_ns'] for row in value['samples'])
    summary.update(witness_requests=witness_requests,witness_framed_bytes=witness_bytes,
        commit_samples=len(sample_times),observed_commit_p50_ns=sample_times[math.ceil(.50*len(sample_times))-1],
        observed_commit_p95_ns=sample_times[math.ceil(.95*len(sample_times))-1],
        process_resources=run['resources'],page_size_bytes=next(iter(page_sizes)),
        selected_memory={row['stage']:{key:row[key] for key in
            ('resident_bytes','physical_footprint_bytes','malloc_size_in_use_bytes','journal_file_bytes')}
            for row in value['resources'] if row['stage'] in
            ('established','before-aggregate-refusal','all-owners-closed','closed-idle-15s')})
    return summary

def rejected(call):
    try:call()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('reader accepted altered public evidence')

def main():
    build= parse_strict_json_bytes((stage/'build-03/OBSERVER_BUILD.json').read_bytes(),label='resource observer build')
    reports=[];sessions=set();controls=0;public={}
    for label,profile in CASES:
        folder=stage/label
        run=parse_strict_json_bytes((folder/'RUN.json').read_bytes(),label='resource execution')
        raw=(folder/'RESULT.json').read_bytes();value=parse_strict_json_bytes(raw,label='capacity observations')
        require(run['binary_sha256']==build['binary_sha256'] and run['source_commit']==build['source_commit'],'source/binary join differs')
        require(run['build_report_sha256']==sdk.snapshot(stage/'build-03/OBSERVER_BUILD.json').sha256,'build report changed')
        require(hashlib.sha256(raw).hexdigest()==run['result_sha256'],'observations changed')
        stdout=(folder/'runtime.stdout').read_text()
        require(re.search(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out;',stdout,re.M),
                'capacity test did not complete')
        command=parse_strict_json_bytes((folder/'runtime.json').read_bytes(),label='resource command')
        require(command['returncode']==0 and command['argv']==['/usr/bin/time','-l','-o',str(folder/'time.txt'),
            build['binary'],'--exact','measure_journal_capacity','--nocapture','--test-threads=1'],'actual command differs')
        runtime=Path(run['runtime_root'])/'installation/responder/measured-effects'
        effects={}
        for path in runtime.iterdir():
            require(re.fullmatch('[0-9a-f]{64}',path.name) is not None,'unexpected business filename')
            effects[path.name]=sdk.snapshot(path,maximum=16384+64).data
        summary=validate(value,run,stdout,effects,profile)
        session=bytes(value['session']);require(session not in sessions,'fresh cohort reused a session');sessions.add(session)
        reports.append(dict(case=label,**summary))
        for name,data in effects.items():public[label+'/effects/'+name]=data
        for index in range(125):
            changed=copy.deepcopy(value);changed['samples'][index]['epoch_index']+=1
            rejected(lambda:validate(changed,run,stdout,effects,profile));controls+=1
        mutations=[]
        for flag in ('persist_capacity_closes_journal','original_owners_reopened_at_capacity','old_epoch_ack_reclaimed_capacity'):
            changed=copy.deepcopy(value);changed[flag]=False;mutations.append(changed)
        changed=copy.deepcopy(value);changed['rejected_message']=changed['samples'][0]['message'];mutations.append(changed)
        changed=copy.deepcopy(value);changed['resources'][-1]['vm_tags']=[];mutations.append(changed)
        changed=copy.deepcopy(value);changed['resources'][-1]['vm_page_size_bytes']=3;mutations.append(changed)
        changed=copy.deepcopy(value);changed['resources'][-1]['vm_tags'].append(changed['resources'][-1]['vm_tags'][0]);mutations.append(changed)
        changed=copy.deepcopy(value);changed['resources'][-1]['vm_tags'][0]['internal_pager_resident_pages']+=1;mutations.append(changed)
        changed=copy.deepcopy(value);changed['resources'].pop();mutations.append(changed)
        if profile=='witness':
            for field in ('framed_bytes','handle_ns'):
                changed=copy.deepcopy(value);changed['witness'][field]+=1;mutations.append(changed)
            changed=copy.deepcopy(value);changed['witness_at_capacity']['requests']-=1;mutations.append(changed)
        else:
            changed=copy.deepcopy(value);changed['witness']['rows']=[{}];mutations.append(changed)
        for changed in mutations:
            rejected(lambda:validate(changed,run,stdout,effects,profile));controls+=1
        changed_effects=dict(effects);name=next(iter(changed_effects));changed_effects[name]+=b'changed'
        rejected(lambda:validate(value,run,stdout,changed_effects,profile));controls+=1
    public_root=stage/'public-effects';public_root.mkdir()
    hashes={}
    for name,data in sorted(public.items()):
        path=public_root/name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(data)
        hashes[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    sdk.write_json(stage/'PUBLIC_EFFECTS.json',hashes)
    result={'completed':True,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],
        'cases':reports,'business_effects_checked':len(public),'negative_controls_rejected':controls,
        'observation_plan':json.loads((stage/'OBSERVATION_PLAN.json').read_bytes()),
        'allocator_environment_observation':json.loads((stage/'HOST_ALLOCATOR_ENVIRONMENT.json').read_bytes()),
        'scope':'Four fresh installed-engine Apple Silicon capacity/recovery observations. Shared process includes both peers, witness when selected and observer. No controlled performance comparison, final product budget, mobile energy, isolated SDK cost or release claim.',
        'release_claim_eligible':False}
    sdk.write_json(stage/'READBACK.json',result)
    print(json.dumps({'completed':True,'effects':len(public),'negative_controls':controls,'cases':[
        {'case':r['case'],'peak_rss_mib':round(r['whole_process_peak_rss_bytes']/2**20,3),
         'closed_15s_footprint_mib':round(r['selected_memory']['closed-idle-15s']['physical_footprint_bytes']/2**20,3),
         'witness_requests':r['witness_requests']} for r in reports]},indent=2))

if __name__=='__main__':main()
