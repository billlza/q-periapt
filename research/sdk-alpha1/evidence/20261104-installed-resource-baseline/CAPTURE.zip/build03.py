from pathlib import Path
import hashlib,json,os,subprocess,sys,tomllib
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
from installed_rust_graph import external_lock,verify_resolution
from rust_sdk_msrv import validate_report
stage=ROOT/'target/continuity-installed-resource-baseline';out=stage/'build-03';out.mkdir()
outside=Path(json.loads((stage/'build-02/LOCATION.json').read_bytes())['path']);consumer=outside/'observer'
sdk.write_json(out/'LOCATION.json',{'path':str(outside)})
versions={n:sdk.VERSION for n in sdk.CONSUMER_CRATES};versions[package.NAME]=package.VERSION
report=ROOT/'target/openssl-witness-census/installed-02/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json'
pinned=sdk.snapshot(report)
cohort=validate_report(pinned.data,'d9cd990bf3dc6a731ec09b659fdc38f3f3cbc17b2f035b09e5e61094cbc11885',
                      pinned.sha256,sdk.source_identity()['rust_workspace_sha256'])
packages={}
for name in sdk.CONSUMER_CRATES:
    row=cohort['crates'][name];archive=sdk.snapshot(report.parent/'crates'/row['file'])
    assert archive.sha256==row['sha256'];packages[name]=sdk.archive_files(archive.data,name)
base=ROOT/'target/contract-purpose-admission/source-current/target/contract-purpose-installed'
producer=json.loads((base/'INSTALLED_COUNTERPART.json').read_bytes());assert producer['completed'] is True
record=producer['candidate_archive'];package.verify_candidate_archive(base,record)
packages[package.NAME]=package.validate_candidate(sdk.snapshot(base/record['file']).data,set(record['files']))
def verify_packages():
    for name,files in packages.items():
        folder=consumer/'packages'/f'{name}-{versions[name]}'
        assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}==set(files)
        for relative,data in files.items():assert sdk.snapshot(folder/relative).data==data,(name,relative)
verify_packages()
source_record={p.relative_to(consumer).as_posix():sdk.snapshot(p).sha256 for p in consumer.rglob('*')
               if p.is_file() and not p.is_relative_to(consumer/'packages')}
known={}
for lock in (ROOT/'Cargo.lock',package.CANDIDATE/'Cargo.lock'):
    for identity,value in external_lock(lock.read_bytes()).items():
        assert identity not in known or known[identity]==value;known[identity]=value
original='version = 4\n'
for (name,version),(registry,checksum) in sorted(known.items()):
    original+='\n[[package]]\nname='+json.dumps(name)+'\nversion='+json.dumps(version)+'\nsource='+json.dumps(registry)+'\nchecksum='+json.dumps(checksum)+'\n'
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
assert not any((cache/name).exists() for name in ('config','config.toml','credentials','credentials.toml'))
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPC_','QPERIAPT_'))}
for key in ('CC','CXX','AR','LD','CPP','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH',
            'CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','LIBRARY_PATH','SDKROOT','MACOSX_DEPLOYMENT_TARGET',
            'OPENSSL_CONF','OPENSSL_CONF_INCLUDE','OPENSSL_MODULES','OPENSSL_ENGINES','SSL_CERT_FILE','SSL_CERT_DIR'):
    env.pop(key,None)
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR=str(outside/'build'),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),
    RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),
    PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
def run(argv,label):
    print(label,flush=True);return sdk.command(argv,out/label,consumer,environment=env)
result={'completed':False,'tests_executed':False,'release_claim_eligible':False,
        'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'candidate_source_commit':producer['source_commit'],'candidate_archive_sha256':record['sha256'],
        'sdk_report_sha256':pinned.sha256,'observer_source':source_record,'product_versions':versions}
try:
    cc=Path(run(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],'clang-path').decode().strip()).resolve()
    sdkroot=Path(run(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()).resolve()
    env.update(CC=str(cc),CFLAGS='-isysroot '+str(sdkroot))
    result['rustc']=run([str(tc/'bin/rustc'),'-vV'],'rustc').decode()
    result['clippy']=run([str(tc/'bin/cargo-clippy'),'--version'],'clippy-version').decode()
    result['clang']={'path':str(cc),'sha256':sdk.snapshot(cc,maximum=256*1024**2).sha256,
                    'version':run([str(cc),'--version'],'clang-version').decode(),
                    'sdk_settings_sha256':sdk.snapshot(sdkroot/'SDKSettings.json').sha256}
    metadata=json.loads(run([str(tc/'bin/cargo'),'metadata','--locked','--offline','--format-version','1'],'metadata'))
    result['resolution']=verify_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),original.encode(),
        consumer_name='q-periapt-continuity-resource-observer',versions=versions)
    assert metadata['workspace_members']==metadata['workspace_default_members']==[metadata['resolve']['root']]
    raw=run([str(tc/'bin/cargo'),'test','--release','--locked','--offline','--test','journal_capacity',
             '--no-run','--message-format=json','-j','2'],'compile')
    rows=[json.loads(line) for line in raw.splitlines()]
    selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='journal_capacity']
    assert len(selected)==1
    binary=Path(selected[0]['executable']);assert binary.parent==outside/'build/release/deps'
    assert Path(selected[0]['target']['src_path'])==consumer/'tests/journal_capacity.rs'
    result['binary']=str(binary);result['binary_sha256']=sdk.snapshot(binary,maximum=256*1024**2).sha256
    run([str(tc/'bin/cargo-clippy'),'clippy','--release','--locked','--offline','--test','journal_capacity',
         '-j','2','--','-D','warnings'],'clippy')
    assert source_record=={name:sdk.snapshot(consumer/name).sha256 for name in source_record}
    verify_packages();result['sources_unchanged']=True;result['completed']=True
except BaseException as error:
    result['failure']=str(error);raise
finally:sdk.write_json(out/'OBSERVER_BUILD.json',result)
