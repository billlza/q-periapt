"""Build the retained capacity observer using verified installed crate archives."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,tomllib
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
from rust_sdk_msrv import validate_report
from installed_rust_graph import external_lock,verify_resolution

stage=ROOT/'target/continuity-installed-resource-baseline'
out=stage/'build-01';out.mkdir()
outside=Path(tempfile.mkdtemp(prefix='qperiapt-resource-installed-')).resolve()
consumer=outside/'observer';consumer.mkdir()
sdk.write_json(out/'LOCATION.json',{'path':str(outside)})
historical=stage/'historical/native-fixture'
source_record={}
for path in historical.rglob('*'):
    if not path.is_file() or path.name in ('Cargo.toml','Cargo.lock'):continue
    relative=path.relative_to(historical)
    data=path.read_bytes()
    if relative.as_posix()=='tests/journal_capacity.rs':
        text=data.decode();old=text.splitlines()[1]
        assert old.startswith('#[path = ')
        text=text.replace(old,'#[path = "../packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs"]',1)
        data=text.encode()
    target=consumer/relative;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data);source_record[relative.as_posix()]=hashlib.sha256(data).hexdigest()
old_manifest=tomllib.loads((historical/'Cargo.toml').read_text())
name='q-periapt-continuity-resource-observer'
versions={n:sdk.VERSION for n in sdk.CONSUMER_CRATES};versions[package.NAME]=package.VERSION
manifest='[package]\nname='+json.dumps(name)+'\nversion="0.0.0"\nedition="2021"\npublish=false\nautotests=false\n'
manifest+='[workspace]\nexclude='+json.dumps([f'packages/{n}-{v}' for n,v in sorted(versions.items())])+'\n'
manifest+='[features]\ndefault=["connection-tls","control-tls"]\nconnection-tls=["q-periapt-continuity-identity-candidate/connection-tls"]\ncontrol-tls=["q-periapt-continuity-identity-candidate/control-tls"]\n[dependencies]\n'
for dep,value in old_manifest['dependencies'].items():
    if dep.startswith('q-periapt'):
        manifest+=dep+'={version='+json.dumps('='+versions[dep])+',path='+json.dumps(f'packages/{dep}-{versions[dep]}')
        if isinstance(value,dict) and 'features' in value:manifest+=',features='+json.dumps(value['features'])
        manifest+='}\n'
    elif isinstance(value,str):manifest+=dep+'='+json.dumps(value)+'\n'
    else:
        assert set(value)=={'version','features'}
        manifest+=dep+'={version='+json.dumps(value['version'])+',features='+json.dumps(value['features'])+'}\n'
manifest+='[profile.release]\nopt-level=3\nlto="thin"\ncodegen-units=1\noverflow-checks=true\n[[test]]\nname="journal_capacity"\npath="tests/journal_capacity.rs"\n[build-dependencies]\ncc="=1.5.1"\n'
(consumer/'Cargo.toml').write_text(manifest)
report=ROOT/'target/openssl-witness-census/installed-02/sdk/sdk-rust-package/RUST_SDK_PACKAGE.json'
pinned=sdk.snapshot(report)
cohort=validate_report(pinned.data,'d9cd990bf3dc6a731ec09b659fdc38f3f3cbc17b2f035b09e5e61094cbc11885',pinned.sha256,sdk.source_identity()['rust_workspace_sha256'])
sdk.extract_recorded_crates(consumer,report.parent,cohort['crates'])
base=ROOT/'target/contract-purpose-admission/source-current/target/contract-purpose-installed'
producer=json.loads((base/'INSTALLED_COUNTERPART.json').read_bytes());assert producer['completed'] is True
record=producer['candidate_archive'];package.verify_candidate_archive(base,record)
candidate=package.validate_candidate(sdk.snapshot(base/record['file']).data,set(record['files']))
for relative,data in candidate.items():
    path=consumer/'packages'/f'{package.NAME}-{package.VERSION}'/relative
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
with (consumer/'Cargo.toml').open('a') as stream:
    stream.write(f'{package.NAME} = {{ path = "packages/{package.NAME}-{package.VERSION}" }}\n')
source_record['Cargo.toml']=sdk.snapshot(consumer/'Cargo.toml').sha256
known={}
for lock in (ROOT/'Cargo.lock',package.CANDIDATE/'Cargo.lock'):
    for identity,checksum in external_lock(lock.read_bytes()).items():
        assert identity not in known or known[identity]==checksum
        known[identity]=checksum
original='version = 4\n'
for (package_name,version),checksum in sorted(known.items()):
    original+='\n[[package]]\nname='+json.dumps(package_name)+'\nversion='+json.dumps(version)+'\nsource="registry+https://github.com/rust-lang/crates.io-index"\nchecksum='+json.dumps(checksum)+'\n'
(consumer/'Cargo.lock').write_text(original)
sdk.write_json(out/'ORIGINAL_LOCK_IDENTITY.json',{'root':sdk.snapshot(ROOT/'Cargo.lock').sha256,
    'candidate':sdk.snapshot(package.CANDIDATE/'Cargo.lock').sha256,'combined_entries':len(known),
    'external_union_sha256':hashlib.sha256(original.encode()).hexdigest()})
tc=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
cache=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPC_','QPERIAPT_'))}
for key in ('CC','CXX','AR','LD','CPP','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH',
            'CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','LIBRARY_PATH','SDKROOT','MACOSX_DEPLOYMENT_TARGET',
            'OPENSSL_CONF','OPENSSL_CONF_INCLUDE','OPENSSL_MODULES','OPENSSL_ENGINES','SSL_CERT_FILE','SSL_CERT_DIR'):
    env.pop(key,None)
env.update(CARGO_HOME=str(cache),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR=str(outside/'build'),CARGO=str(tc/'bin/cargo'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),
    RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),
    PATH=str(tc/'bin')+os.pathsep+env.get('PATH',os.defpath))
def run(argv,label):
    print(label,flush=True);return sdk.command(argv,out/label,consumer,environment=env)
result={'completed':False,'tests_executed':False,'release_claim_eligible':False,
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'candidate_source_commit':producer['source_commit'],'candidate_archive_sha256':record['sha256'],
    'sdk_report_sha256':pinned.sha256,'observer_source':source_record,'product_versions':versions}
try:
    cc=Path(run(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],'clang-path').decode().strip()).resolve()
    sdkroot=Path(run(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()).resolve()
    env.update(CC=str(cc),CFLAGS='-isysroot '+str(sdkroot))
    result['rustc']=run([str(tc/'bin/rustc'),'-vV'],'rustc').decode()
    result['clippy']=run([str(tc/'bin/cargo-clippy'),'--version'],'clippy-version').decode()
    result['clang']={'path':str(cc),'sha256':sdk.snapshot(cc,maximum=256*1024**2).sha256,
                     'version':run([str(cc),'--version'],'clang-version').decode(),
                     'sdk_settings_sha256':sdk.snapshot(sdkroot/'SDKSettings.json').sha256}
    metadata=json.loads(run([str(tc/'bin/cargo'),'metadata','--offline','--format-version','1'],'metadata'))
    result['resolution']=verify_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),original.encode(),
                                           consumer_name=name,versions=versions)
    assert metadata['workspace_members']==metadata['workspace_default_members']==[metadata['resolve']['root']]
    source_record['Cargo.lock']=sdk.snapshot(consumer/'Cargo.lock').sha256
    sdk.copy(consumer/'Cargo.toml',out/'Cargo.toml');sdk.copy(consumer/'Cargo.lock',out/'Cargo.lock')
    built=run([str(tc/'bin/cargo'),'test','--release','--locked','--offline','--test','journal_capacity',
               '--no-run','--message-format=json','-j','2'],'build')
    artifacts=[json.loads(line) for line in built.splitlines()]
    selected=[row for row in artifacts if row.get('reason')=='compiler-artifact' and row.get('executable')
              and row['target']['name']=='journal_capacity']
    assert len(selected)==1
    binary=Path(selected[0]['executable']);assert binary.parent==outside/'build/release/deps'
    assert Path(selected[0]['target']['src_path'])==consumer/'tests/journal_capacity.rs'
    result['binary']=str(binary);result['binary_sha256']=sdk.snapshot(binary,maximum=256*1024**2).sha256
    run([str(tc/'bin/cargo-clippy'),'clippy','--release','--locked','--offline','--test','journal_capacity',
         '-j','2','--','-D','warnings'],'clippy')
    assert source_record=={name:sdk.snapshot(consumer/name).sha256 for name in source_record}
    result['sources_unchanged']=True;result['completed']=True
except BaseException as error:
    result['failure']=str(error);raise
finally:sdk.write_json(out/'BUILD.json',result)
