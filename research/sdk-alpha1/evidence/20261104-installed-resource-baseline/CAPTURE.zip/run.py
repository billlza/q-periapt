"""Fresh installed-owner capacity cohorts; never reuse private runtime state."""
from pathlib import Path
import json,os,platform,re,subprocess,sys,time
ROOT=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
sys.path.insert(0,str(ROOT/'artifact'))
import rust_sdk_profile as sdk
stage=ROOT/'target/continuity-installed-resource-baseline'
label,profile=sys.argv[1:]
sdk.require(re.fullmatch('[a-z0-9-]+',label) is not None and profile in {'local','witness'},'unknown cohort')
build_file=stage/'build-03/OBSERVER_BUILD.json';build=json.loads(build_file.read_bytes())
sdk.require(build['completed'] is True and build['sources_unchanged'] is True,'observer build incomplete')
outside=Path(json.loads((stage/'build-03/LOCATION.json').read_bytes())['path']);consumer=outside/'observer'
binary=Path(build['binary'])
sdk.require(platform.system()=='Darwin' and platform.machine()=='arm64','Apple Silicon observation required')
sdk.require(sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'observer binary changed')
for name,digest in build['observer_source'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'observer source changed')
out=stage/label;out.mkdir(mode=0o700)
runtime=outside/(label+'-private');runtime.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPC_','QPERIAPT_'))}
env.update(QPC_JOURNAL_PROFILE=profile,QPC_JOURNAL_OUTPUT=str(out/'RESULT.json'),
           QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(runtime/'installation'),RUST_BACKTRACE='1')
record={'completed':False,'source_commit':build['source_commit'],
        'build_report_sha256':sdk.snapshot(build_file).sha256,'binary_sha256':build['binary_sha256'],
        'profile':profile,'runtime_root':str(runtime),'machine':platform.machine(),
        'os_release':platform.release(),'macos_version':platform.mac_ver()[0],
        'started_unix':time.time(),'load_before':os.getloadavg(),
        'host_controls':'No task build or broad test overlaps runtime; other applications and power settings are uncontrolled and unchanged.',
        'release_claim_eligible':False}
try:
    sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==build['source_commit'],'source head changed')
    sdk.require(subprocess.check_output(['git','diff','HEAD','--','crates','research/continuity-identity-candidate'],cwd=ROOT)==b'','product source changed')
    hardware=sdk.command(['/usr/sbin/sysctl','hw.model','hw.ncpu','hw.memsize','machdep.cpu.brand_string'],out/'hardware',ROOT,environment=env)
    record['hardware']=hardware.decode()
    print(json.dumps({'cohort':label,'profile':profile,'phase':'running original installed capacity workload'}),flush=True)
    stdout=sdk.command(['/usr/bin/time','-l','-o',str(out/'time.txt'),str(binary),'--exact','measure_journal_capacity',
                        '--nocapture','--test-threads=1'],out/'runtime',consumer,environment=env)
    text=stdout.decode()
    sdk.require(re.search(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out;',text,re.M),
                'selected capacity workload did not complete')
    result=json.loads((out/'RESULT.json').read_bytes());count=result['total_retained_at_refusal']
    sdk.require(result['completed'] is True and result['profile']==profile,'capacity result differs')
    sdk.require(64<count<128 and result['epoch_one_retained']==count-64,'aggregate and epoch bounds are conflated')
    sdk.require(re.findall(r'JOURNAL_CAPACITY_STAGE capacity_error total=(\d+) epoch_one=(\d+)',text)==[(str(count),str(count-64))],
                'independent runtime capacity trace differs')
    sdk.require(len(result['samples'])==len(result['deliveries'])==result['server']['effects']==count+1,'effect census differs')
    for key in ('persist_capacity_closes_journal','aggregate_refused_before_epoch_capacity','capacity_refused_without_reservation',
                'original_owners_reopened_at_capacity','old_epoch_ack_reclaimed_capacity','all_replays_exact',
                'all_business_effects_verified','sdk_and_server_closed'):
        sdk.require(result[key] is True,'missing capacity/recovery outcome: '+key)
    stats=(out/'time.txt').read_text()
    rss=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',stats,re.M)
    cpu=re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys',stats)
    sdk.require(rss is not None and cpu is not None,'Darwin process counters absent')
    for name,digest in build['observer_source'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'observer source changed during runtime')
    sdk.require(sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'runtime executable changed')
    record.update(completed=True,result_sha256=sdk.snapshot(out/'RESULT.json',maximum=32*1024**2).sha256,
        total_retained_at_refusal=count,effects=count+1,
        resources={'max_rss_bytes':int(rss[1]),'real_seconds':float(cpu[1]),'user_seconds':float(cpu[2]),'system_seconds':float(cpu[3])})
except BaseException as error:
    record['failure']=str(error);raise
finally:
    record.update(finished_unix=time.time(),load_after=os.getloadavg(),private_runtime_preserved=True)
    sdk.write_json(out/'RUN.json',record)
print(json.dumps({'completed':True,'profile':profile,'retained':record['total_retained_at_refusal'],
                  'effects':record['effects'],'resources':record['resources']}),flush=True)
