globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', { type: 'module' });
  let stopped = false;
  const finish = async (error, result) => {
    if (stopped) return;
    stopped = true; clearTimeout(timer); worker.terminate();
    try {
      if (result?.workerTerminatedAfterJournalFlush) {
        const name='qperiapt-continuity-storage/2/'+args.name;
        const before=await navigator.locks.query(), started=performance.now();
        await navigator.locks.request(name,{mode:'exclusive',signal:AbortSignal.timeout(30000)},()=>{});
        result.terminationRelease={heldBefore:before.held.filter(lock=>lock.name===name).length,
          waitedMs:performance.now()-started, originalRootReleased:true};
      }
      if (error) reject(error); else resolve(result);
    } catch (failure) { reject(failure); }
  };
  const timer = setTimeout(() => finish(Error('joint worker deadline')), args.action === 'expiry-held' ? 210000 : 45000);
  worker.onerror = event => finish(Error(event.message));
  worker.onmessage = async ({ data }) => {
    try {
      if (data.journalBoundaryObserved) {
        if(!args.killAfterJournalFlush || data.boundary!=='retired-bytes-flushed')throw Error('unexpected journal cut');
        finish(undefined,{done:true,workerTerminatedAfterJournalFlush:true,marker:data});return;
      } else if (data.signerCommitObserved) {
        if (!args.killAfterSignerCommit || data.revision!==2) throw Error('unexpected signer commit cut');
        finish(undefined,{done:true,workerTerminatedAfterSignerCommit:true,marker:data}); return;
      } else if (data.ready) {
        worker.postMessage(args);
        if (args.killAfterPeerResult) {
          while (!stopped) {
            const response = await fetch('/peer-status/' + args.case, { credentials: 'omit', cache: 'no-store' });
            if (!response.ok) throw Error('witness observation failed');
            const records = await response.json();
            if (records.some(row => row.trigger && row.kind === 3 && row.slot === args.selected && row.returncode === 0)) {
              finish(undefined, { done: true, workerTerminatedAfterPeerResult: true }); break;
            }
            await new Promise(resolve => setTimeout(resolve, 20));
          }
        }
      } else if (data.done) {
        if (args.action === 'create' && data.value?.request) {
          const response = await fetch('/capture/' + args.case + '.bin', { method: 'POST', body: new Uint8Array(data.value.request) });
          if (!response.ok) throw Error('enrollment capture failed');
          delete data.value.request;
        }
        if (data.value?.phase === 'requires-witness-enrollment') {
          const response = await fetch('/capture/' + args.case + '-genesis.json', { method: 'POST', body: JSON.stringify(data.value) });
          if (!response.ok) throw Error('genesis capture failed');
        }
        finish(undefined, data);
      }
    } catch (error) { finish(error); }
  };
});
