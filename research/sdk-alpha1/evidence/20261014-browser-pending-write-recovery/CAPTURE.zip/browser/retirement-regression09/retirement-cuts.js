// Fixture-only boundaries through actual browser storage APIs.
import { StorageRoot, DatabaseLease } from '../node_modules/q-periapt-sdk-wasm/web/storage-root.js';
export function interruptJournalFlush() {
  const journals=new WeakSet(), written=new WeakSet();
  const open=StorageRoot.prototype.openDatabase, write=DatabaseLease.prototype.write, flush=DatabaseLease.prototype.flush;
  const tag=new TextEncoder().encode('QPRJER01'); let signalled=false;
  StorageRoot.prototype.openDatabase=function(path) {
    return open.call(this,path).then(file=>{if(path.endsWith('/journal.redb'))journals.add(file);return file;});
  };
  DatabaseLease.prototype.write=function(offset,bytes) {
    const result=write.call(this,offset,bytes);
    if(journals.has(this))for(let i=0;i+tag.length<=bytes.length;i++) {
      if(tag.every((value,j)=>bytes[i+j]===value)){written.add(this);break;}
    }
    return result;
  };
  DatabaseLease.prototype.flush=function() {
    const result=flush.call(this);
    if(journals.has(this)&&written.has(this)&&!signalled) {
      signalled=true;postMessage({journalBoundaryObserved:true,boundary:'retired-bytes-flushed'});
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10000);
      throw Error('parent did not stop Worker at journal boundary');
    }
    return result;
  };
}
const outcome=error=>({error:String(error),code:error?.code,ownerClosed:error?.ownerClosed});
export async function cancelSignerCommit(owner,reopen,name) {
  const put=IDBObjectStore.prototype.put;
  let completed, release, released=false, other, closeSettled=false;
  const observed=new Promise(resolve=>{completed=resolve;});
  IDBObjectStore.prototype.put=function(value,key) {
    const request=put.call(this,value,key);
    if(this.name==='files'&&value?.kind==='bytes'&&value.revision===2&&value.length===8&&String(key).endsWith('/signer.key')) {
      const tx=this.transaction, callback=tx.oncomplete;
      tx.oncomplete=event=>{
        release=()=>{if(!released){released=true;callback.call(tx,event);}};
        completed({identity:value.id,revision:value.revision});
      };
    }
    return request;
  };
  try {
    const erasure=owner.erase_retired_signer().then(()=>({success:true}),error=>({success:false,...outcome(error)}));
    const marker=await Promise.race([observed,erasure.then(result=>{throw Error('erasure finished before held commit: '+JSON.stringify(result));})]);
    const closing=owner.close().then(()=>{closeSettled=true;return {success:true};},error=>{closeSettled=true;return {success:false,...outcome(error)};});
    await new Promise(resolve=>setTimeout(resolve,25));
    const contender=await reopen().then(value=>{other=value;return {success:true};},error=>({success:false,...outcome(error)}));
    const locks=await navigator.locks.query();
    const before={closeSettled,closed:owner.is_closed(),held:locks.held.filter(lock=>lock.name==='qperiapt-continuity-storage/2/'+name).length,contender};
    release();
    const [result,closed]=await Promise.all([erasure,closing]);
    if(other)throw Error('contender obtained original root before receipt settlement');
    other=await reopen(); const recovered=await other.retired_signer_erasure_status();
    return {marker,before,erasure:result,close:closed,recovered};
  } finally {
    IDBObjectStore.prototype.put=put;
    if(release&&!released)release();
    if(other){try{await other.close();}finally{other.free();}}
  }
}
