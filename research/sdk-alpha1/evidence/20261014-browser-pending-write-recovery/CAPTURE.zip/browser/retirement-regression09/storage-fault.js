// Fixture-only mutation of owned persisted state, never a product bypass.
import { unsealState, sealState, validateState, secretAAD, encryptSecret, describe, matches, equal, hex } from '../node_modules/q-periapt-sdk-wasm/web/storage-catalogue.js';
import { openDatabase, transaction, admitSnapshot } from '../node_modules/q-periapt-sdk-wasm/web/storage-database.js';
const bytes=value=>new Uint8Array(value);
async function receipt(operation) {try{return await operation.result;}finally{await operation.settled;}}
export async function tweakSigner(name,id,cfg,mode) {
  if(!['inspect','missing','swapped'].includes(mode))throw Error('fixture storage mode');
  return navigator.locks.request('qperiapt-continuity-storage/2/'+name,{mode:'exclusive'},async()=>{
    const db=await receipt(openDatabase('qperiapt-continuity-storage/2/'+name));
    let plain;
    try {
      const signal=new AbortController().signal, path='/qpc/'+name+'/'+id+'/signer.key';
      const snapshot=await receipt(transaction(db,signal,({root,paths,files,checked,done})=>{
        const query=files.get(path); query.onsuccess=checked(()=>done({root,paths,record:query.result}));
      },false));
      const prefix=new TextEncoder().encode('QPC-BROWSER-ENROLLMENT-INITIAL/v2');
      const binding=new Uint8Array(prefix.length+cfg.root.length+cfg.description.length);
      binding.set(prefix);binding.set(bytes(cfg.root),prefix.length);binding.set(bytes(cfg.description),prefix.length+cfg.root.length);
      const state=await unsealState(snapshot.root,name,id,binding);
      admitSnapshot(snapshot.root,snapshot.paths,snapshot.root,state);
      const expected=new Map(state.files).get(path);
      if(snapshot.record===undefined) {
        if(mode!=='inspect'||expected!==undefined)throw Error('unexpected missing fixture record');
        return {present:false};
      }
      const original=matches(snapshot.record,expected);
      if(original.kind!=='bytes')throw Error('wrong fixture secret kind');
      plain=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:original.iv,additionalData:secretAAD(id,path,original)},snapshot.root.key,original.data));
      const fingerprint=hex(new Uint8Array(await crypto.subtle.digest('SHA-256',plain)));
      const before={present:true,identity:original.id,revision:original.revision,length:original.length,innerFileSha256:fingerprint};
      if(mode==='inspect')return before;
      if(original.revision!==1||new TextDecoder().decode(plain.subarray(0,8))!=='QPSIGN01')throw Error('expected original signer');
      const replacement=mode==='swapped'?await encryptSecret(snapshot.root.key,id,path,plain):null;
      if(replacement?.id===original.id)throw Error('replacement retained original object ID');
      const next={...state,revision:state.revision+1,files:replacement
        ?state.files.map(pair=>pair[0]===path?[path,describe(replacement)]:pair)
        :state.files.filter(pair=>pair[0]!==path)};
      validateState(next,name,id,binding);
      const meta=await sealState(snapshot.root.key,name,id,next);
      await receipt(transaction(db,signal,({root,paths,roots,files,checked,done})=>{
        admitSnapshot(root,paths,snapshot.root,state);
        const query=files.get(path);query.onsuccess=checked(()=>{
          const current=matches(query.result,expected);
          if(!equal(current.iv,original.iv)||!equal(current.data,original.data))throw Error('fixture concurrent replacement');
          if(replacement)files.put(replacement,path);else files.delete(path);
          roots.put(meta,'current');done();
        });
      }));
      return {before,after:replacement?{present:true,identity:replacement.id,revision:1,length:replacement.length,innerFileSha256:fingerprint}:{present:false}};
    } finally {plain?.fill(0);db.close();}
  });
}
