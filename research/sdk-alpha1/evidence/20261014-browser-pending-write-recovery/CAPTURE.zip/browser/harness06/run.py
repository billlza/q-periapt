from pathlib import Path
import contextlib
import json
import os
import shutil
import sys
import uuid
import time
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery/harness06'
prior = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'cancel-query','worker-before-confirmation','worker-after-confirmation'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-pending-recovery-package-01'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for source, name in (('worker.js','worker.js'), ('controller.js','controller.js')): shutil.copyfile(stage / source, web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><title>Original account recovery</title><script type="module" src="./controller.js"></script>')
(web / 'creation/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#183047"/><circle cx="16" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/></svg>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
browser_session = 'qpc-pending-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage.parent / ('native-target-03/debug/qpc-fanout-' + name) for name in ('seed','witness','peer')}
binaries['issuer']=stage.parent/'native-target-03/debug/qpc-pending-issuer'
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker.js', stage / 'controller.js', stage / 'server.py']}
run_state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Installed browser exact original pending write recovery, independent control plane, G/T renewal and complete original loss accounting; same engine on one host', 'cases': []}
sequence = 0

def browser(args, name, timeout=80):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', browser_session, *args], timeout_seconds=timeout,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name, 240 if args['action']=='expiry-held' else 80).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    run_state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

try:
    with serving(web, output, private, binaries['witness'], binaries['peer']) as (origin, records, peers, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.waitForFunction(()=>performance.getEntriesByType("resource").some(e=>e.name.endsWith("/creation/favicon.svg"))); await page.evaluate(()=>{globalThis.diagnostics=[]; document.cookie="fanout_probe=present; path=/; SameSite=Strict"; if(!document.cookie.includes("fanout_probe=present"))throw Error("cookie control"); addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            console = browser(['console', 'warning'], 'startup-console').decode()
            sdk.require(console == '### Result\nTotal messages: 0 (Errors: 0, Warnings: 0)\n\n', 'startup console error')
            run_state['startup_console_clean'] = True
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case':case, 'calls':[], 'completed':False}; run_state['cases'].append(row)
                profile = 'local' if case == 'local' else 'required'
                native('seed', ['prepare-expiring-all',directory], case + '-seed')
                cfg = json.loads((directory / 'PUBLIC.json').read_text()); cfg['profile'] = profile
                (directory / 'PUBLIC.json').write_text(json.dumps(cfg))
                shutil.copyfile(directory / 'PUBLIC.json',inputs / (key + '.json'))
                args = {'case':key,'name':key+'-'+uuid.uuid4().hex[:8], 'id':uuid.uuid4().hex+uuid.uuid4().hex, 'profile':profile}
                success(dict(args,action='create'))
                grant_path = inputs / (key + '-grant.json')
                trace = output / (case + '-native-prepare'); trace.mkdir(mode=0o700)
                native('peer',['prepare-group',directory,output/'captures'/(key+'.bin'),grant_path,inputs,trace],case+'-group-prepare')
                grant = json.loads(grant_path.read_text())
                for slot in range(2):
                    peer = json.loads((inputs / (key + f'-peer-{slot}.json')).read_text())
                    sdk.require(peer['account'] == cfg['account'] and peer['root'] == cfg['root'] and peer['roster'] == grant['roster'] and peer['digest'] == grant['digest'], 'independent group roster mismatch')
                accepted = success(dict(args,action='accept')); prepared = success(dict(args,action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness',['enroll',directory,grant_path,output/'captures'/(key+'-genesis.json')],case+'-witness-enroll')
                active = success(dict(args,action='activate')); sdk.require(active['journal'] == prepared['journal'], 'activation identity')
                row['journal'] = active['journal']
                sessions = []
                for slot in range(2):
                    established = success(dict(args,action='establish',slot=slot,requestId=list(os.urandom(32))))
                    sdk.require(established['journal'] == row['journal'], 'per-peer owner replaced original journal')
                    sessions.append(established['session'])
                    sdk.write_json(directory/'recipients'/str(slot)/'peer/session.json',established['session'])
                sdk.require(sessions[0] != sessions[1], 'different members share a session')
                args['sessions'] = sessions; row['sessions'] = sessions
                operation = success(dict(args,action='account-next'))['operation']; args['operation'] = operation; row['operation'] = operation
                original_slots = success(dict(args,action='session-slots'))['messages']; row['original_messages'] = original_slots
                lost=invoke(dict(args,action='account-deliver',selected=0,mode='drop-ack'))
                sdk.require(lost.get('code')=='PeerTransport' and lost.get('ownerClosed') is True,'original ACK loss not established')
                members=success(dict(args,action='cleanup-account-members'))['members']
                sdk.require([v['message'] for v in members]==original_slots and [v['phase'] for v in members]==[1,1],'original aggregate not fully committed')
                data_frames=[r for r in peers.get(key,[]) if r['kind']==3]
                sdk.require(len(data_frames)==1,'unexpected original data dispatch')
                effects=list((directory/'recipients/0/peer/effects').iterdir())
                sdk.require(len(effects)==1 and effects[0].read_bytes()==bytes(sessions[0])+bytes(original_slots[0])+b'all account devices','original business effect')
                effect=effects[0]; stat=effect.stat(); row['effect_before']=[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]
                staged=case.startswith('staged-');applied=case in {'applied','staged-applied'}
                grant['journal']=row['journal'];grant_path.write_text(json.dumps(grant))
                args['renewalOperation']=list(os.urandom(32))
                request_path=output/(case+'-renewal-request.json');issued_path=inputs/(key+'-joint-1.json')
                def stage_renewal():
                    r=success(dict(args,action='renewal-request'))['credentialRequest'];sdk.write_json(request_path,r)
                    native('issuer',['issue',directory,grant_path,'-',request_path,issued_path,'required'],case+'-issue-joint')
                    issued=json.loads(issued_path.read_text());row['joint_operation']=issued['operation'];row['joint_statement']=issued['transaction']
                    status=success(dict(args,action='renewal-stage'))['status']
                    sdk.require(status=={'phase':2,'operation':issued['operation'],'statement':issued['transaction']},'original joint stage')
                    return issued
                issued=stage_renewal() if staged else None
                mode='drop-advance' if applied else 'drop-before-advance'
                cut=invoke(dict(args,action='cleanup-session-begin',session=sessions[0],witnessMode=mode,cut='1'))
                sdk.require(cut.get('code')=='WitnessTransport' and cut.get('ownerClosed') is True,'original generic intent cut missing')
                fault=[v for v in records.get(key,[]) if v['mode']==mode and v['trigger']]
                sdk.require(len(fault)==1 and fault[0]['dispatched']==applied,'wrong witness cut')
                until=max(cfg['until'],cfg['policy_until']);sdk.require(int(time.time())<until,'cut was not before expiry')
                print(json.dumps({'case':case,'phase':'waiting for actual signed expiry','until':until}),flush=True)
                while int(time.time())<=until:time.sleep(min(5,max(0.05,until+1-time.time()+0.1)))
                row['expiry']={'until':until,'observed':int(time.time())}
                calls=len(records.get(key,[]))
                pending=success(dict(args,action='pending-request'));repeated=success(dict(args,action='pending-request'))
                sdk.require(not pending['runtimeCreated'] and pending['observedAt']>until,'historical preparation permission')
                sdk.require(len(records.get(key,[]))==calls,'metadata preparation sent network')
                for field in ['proposal','metadata','document','binding']:sdk.require(pending[field]==repeated[field],'original metadata changed')
                document=json.loads(pending['document']);row['pending']=document
                sdk.require(document['schema']==1 and document['proposal']==bytes(pending['proposal']).hex() and document['binding']==bytes(pending['binding']).hex(),'metadata scope')
                source,target=document['source'],document['target']
                sdk.require('role' not in source and 'role' not in target,'invented committed view role')
                sdk.require(source['local_account']==target['local_account']==bytes(cfg['account']).hex(),'original account')
                sdk.require(source['head']['fence']==target['head']['fence'] and int(target['head']['revision'])==int(source['head']['revision'])+1,'original ordinary target shape')
                sdk.require([r['id'] for r in source['records']]==[r['id'] for r in target['records']],'record loss in projection')
                def sessions_in(view):return {r['metadata']['session']['session']:r['metadata']['session'] for r in view['records'] if r['metadata']['kind']=='session'}
                before_sessions,after_sessions=sessions_in(source),sessions_in(target)
                sdk.require(set(before_sessions)==set(after_sessions)=={bytes(x).hex() for x in sessions},'incomplete original sessions')
                for slot in range(2):
                    sk=bytes(sessions[slot]).hex();a,b=before_sessions[sk],after_sessions[sk]
                    sdk.require(a['state']['kind']==b['state']['kind']=='live' and a['progress']==b['progress'],'session state changed')
                    aa=[e['accounting'] for e in a['state']['epochs']];bb=[e['accounting'] for e in b['state']['epochs']]
                    sdk.require(aa==bb and len(aa)==1 and len(aa[0]['unconfirmed'])==1 and aa[0]['unconfirmed'][0]['message']==bytes(original_slots[slot]).hex(),'unknown message accounting changed')
                original_closure=after_sessions[bytes(sessions[0]).hex()]['state']['previous_closure'];sdk.require(original_closure is not None,'original closure omitted')
                def retain(name,data):
                    folder=output/'accounting'/key;folder.mkdir(parents=True,exist_ok=True);path=folder/name
                    with path.open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
                    fd=os.open(folder,os.O_RDONLY)
                    try:os.fsync(fd)
                    finally:os.close(fd)
                    sdk.require(path.read_bytes()==data,'host readback');row.setdefault('host_accounting',[]).append({'path':str(path.relative_to(output)),'sha256':sdk.snapshot(path).sha256});return path
                approved_path=retain('approved.bin',bytes(pending['proposal']));metadata_path=retain('metadata.bin',bytes(pending['metadata']));signed_path=retain('signed.bin',bytes(pending['signed']));retain('inspection.json',pending['document'].encode())
                confirm_args=dict(args,action='pending-confirm',approved=pending['proposal'],metadata=pending['metadata'])
                if not applied:
                    refused=invoke(confirm_args);sdk.require(refused.get('code')=='Scope' and refused.get('ownerClosed') is True,'unapplied source falsely confirmed')
                damaged=list(pending['metadata']);damaged[-1]^=1;calls=len(records.get(key,[]))
                refused=invoke(dict(confirm_args,metadata=damaged));sdk.require(refused.get('code')=='Authentication' and refused.get('ownerClosed') is True,'modified retained metadata accepted')
                sdk.require(len(records.get(key,[]))==calls,'modified metadata contacted witness')
                again=success(dict(args,action='pending-request'));sdk.require(again['proposal']==pending['proposal'] and again['metadata']==pending['metadata'],'failed confirmation altered original intent')
                result_path=output/(case+'-controller.json')
                native('witness',['complete-pending-write',directory,approved_path,metadata_path,signed_path,result_path],case+'-controller')
                controlled=json.loads(result_path.read_text());sdk.require(controlled['confirmed'] and controlled['proposal_binding']==pending['binding'] and controlled['at']>until,'independent exact completion')
                if case=='cancel-query':
                    result=invoke(dict(confirm_args,witnessMode='hold-query',cut='30',cancelAfterQuery=True))
                    sdk.require(result.get('code')=='WitnessTransport' and result.get('ownerClosed') is True and result.get('closeReceipt')=={'closeComplete':True,'closed':True},'cancelled query released success or incomplete close')
                    retained=success(dict(args,action='pending-request'));sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'cancellation replaced original pending state')
                elif case=='worker-before-confirmation':
                    result=invoke(dict(confirm_args,witnessMode='hold-query',cut='30',killAfterQuery=True))
                    sdk.require(result.get('workerTerminatedBeforeConfirmation') is True and result.get('rootHeldBefore')==1,'missing actual Worker interruption')
                    retained=success(dict(args,action='pending-request'));sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'interruption changed original pending state')
                else:
                    result=invoke(dict(confirm_args,killAfterLocalConfirmation=True))
                    sdk.require(result.get('workerTerminatedAfterConfirmation') is True and result.get('rootHeldBefore')==1,'missing commit before host-result loss')
                    absent=invoke(dict(args,action='pending-request'));sdk.require(absent.get('code')=='Absent' and absent.get('ownerClosed') is True,'local commit was not durable after Worker loss')
                row['interruption']=result
                calls=len(records.get(key,[]))
                for _ in range(2):sdk.require(success(confirm_args)['confirmed'],'exact fresh confirmation')
                sdk.require([r['request_tag'] for r in records[key][calls:]]==[1,1],'confirmation performed fresh Advance')
                missing=invoke(dict(args,action='pending-request'));sdk.require(missing.get('code')=='Absent' and missing.get('ownerClosed') is True,'missing intent presented as a request')
                if not staged:issued=stage_renewal()
                status=success(dict(args,action='renewal-status'))['status'];sdk.require(status=={'phase':2,'operation':issued['operation'],'statement':issued['transaction']},'staged G/T changed during recovery')
                prepared=success(dict(args,action='renewal-prepare'))['proposal'];proposal_path=retain('joint-proposal.bin',bytes(prepared))
                native('issuer',['approve',directory,grant_path,'-',request_path,issued_path,'required',proposal_path],case+'-joint-approve')
                committed=success(dict(args,action='renewal-commit',proposal=prepared))['status'];sdk.require(committed=={'phase':4,'operation':issued['operation'],'statement':issued['transaction']},'original G/T not completed')
                late=invoke(confirm_args);sdk.require(late.get('code')=='Conflict','advanced head accepted as exact retry')
                for slot,session_id in enumerate(sessions):
                    value=success(dict(args,action='cleanup-session-begin',session=session_id));report=json.loads(value['document'])
                    expected=after_sessions[bytes(session_id).hex()];sdk.require(report['epochs']==[e['accounting'] for e in expected['state']['epochs']] and report['session']==bytes(session_id).hex(),'complete original report changed')
                    if slot==0:sdk.require(bytes(value['report']).hex()==original_closure,'original closure ID replaced')
                    retain('session-'+str(slot)+'-report.json',value['document'].encode())
                    ack=success(dict(args,action='cleanup-session-ack',session=session_id,report=value['report']));sdk.require(ack['status']['phase']==2 and ack['status']['report']==value['report'],'actual report ACK missing')
                members=success(dict(args,action='cleanup-account-members'))['members'];sdk.require([v['message'] for v in members]==original_slots and [v['phase'] for v in members]==[4,4],'unknown outcomes promoted to delivery')
                sdk.require(success(dict(args,action='cleanup-account-retire'))['status']['phase']==5,'original aggregate not retired')
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==len(data_frames),'recovery sent application traffic')
                stat=effect.stat();sdk.require(row['effect_before']==[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns],'original peer effect changed')
                for receipt in row['host_accounting']:sdk.require(sdk.snapshot(output/receipt['path']).sha256==receipt['sha256'],'host accounting changed')
                sdk.require(not failures,'fixture failed: '+json.dumps(failures))
                row.update(completed=True,original_intent_confirmed=True,joint_preserved=True,cleanup_complete=True)
                print(json.dumps({'case':case,'completed':True,'calls':len(row['calls']),'original_intent_confirmed':True,'joint_preserved':True,'cleanup_complete':True}),flush=True)
            run_state['witness_records']=records;run_state['peer_records']=peers
        except BaseException as error:
            run_state['protocol_failure']=repr(error);raise
        finally:
            run_state['witness_records']=records;run_state['peer_records']=peers;run_state['fixture_failures']=failures
            browser(['close'],'close')
    for name,digest in producer.items():sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web package drift')
    run_state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    run_state['failure']=repr(error);raise
finally:
    sdk.write_json(output/'RESULT.json',run_state)
print(json.dumps({'completed':True,'cases':cases,'scope':run_state['scope']}))
