from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
checks = clone / 'target/pending-recovery-browser-checks'
source = json.loads((stage / 'SOURCE_COMMIT_12.json').read_text())
head = source['source_commit']
tested = json.loads((stage / 'INPUTS_02.json').read_text())
sdk.require(all(source['files'][name] == digest for name, digest in tested.items()), 'tested implementation changed')
sdk.require(set(source['files']) - set(tested) == {
    'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md',
    'research/continuity-identity-candidate/README.md',
    'crates/q-periapt-sdk-wasm/PackageREADME.md',
}, 'unqualified final implementation input')
for checkout in [root, clone]:
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip() == head, 'source head changed')
    sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout), 'source checkout changed')
    for name, digest in source['files'].items():
        sdk.require(sdk.snapshot(checkout / name).sha256 == digest, 'final source changed')
for base, names in [(stage, ['wasm-clippy-01', 'msrv-check-06', 'fixture-build-04', 'format-10', 'diff-10', 'final-diff-11', 'package-13']),
                    (checks, ['package-inventory-01', 'source-gate-13'])]:
    for name in names:
        sdk.require(json.loads((base / (name + '.json')).read_text())['returncode'] == 0, 'failed check: ' + name)
run_paths = ['harness05/run05', 'harness05/run08', 'harness07/run07', 'retirement-regression09/run09']
runs = []
for relative in run_paths:
    path = stage / relative / 'RESULT.json'
    result = json.loads(path.read_text())
    sdk.require(result['completed'] and result['producer_unchanged'] and not result['fixture_failures'], 'incomplete browser run')
    cases = [{'case': row['case'], 'calls': len(row['calls']), 'completed': row['completed'], 'cleanup_complete': row['cleanup_complete']}
             for row in result['cases']]
    sdk.require(all(row['completed'] and row['cleanup_complete'] for row in cases), 'incomplete cohort')
    runs.append({'path': relative, 'sha256': sdk.snapshot(path).sha256, 'cases': cases})
sdk.require(sum(len(run['cases']) for run in runs) == 8, 'cohort count')
sdk.require(sum(row['calls'] for run in runs for row in run['cases']) == 263, 'Worker call count')
comparison = json.loads((stage / 'INSTALLED_COMPARISON_13.json').read_text())
sdk.require(set(comparison['changed_files']) <= {'README.md', 'PACKAGE_CONTENTS.json'}, 'installed executable drift')
packages = [clone / ('target/browser-pending-recovery-package-' + number) for number in ['01', '02']]
receipts = [json.loads((package / 'INSTALLED_CONSUMER.json').read_text()) for package in packages]
for receipt in receipts:
    sdk.require(receipt['installed_node_tests'] == 'passed' and receipt['source_bound'] and receipt['sources_unchanged'], 'installed consumer failed')
    sdk.require(sdk.snapshot(Path(receipt['archive'])).sha256 == receipt['sha256'], 'package archive changed')
out = root / 'research/sdk-alpha1/evidence/20261014-browser-pending-write-recovery'
out.mkdir()
sdk.write_json(out / 'QUALIFICATION.json', {
    'source_commit': head, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_files': source['files'], 'runs': runs, 'successful_cohorts': 8, 'worker_calls': 263,
    'pending_recovery_cohorts': 7, 'retirement_regression_cohorts': 1,
    'installed_packages': [{'sha256': receipt['sha256'], 'manifest_sha256': receipt['manifest_sha256'],
                            'installed_node_tests': receipt['installed_node_tests'], 'typescript': receipt['typescript']}
                           for receipt in receipts],
    'browser_runs_package': receipts[0]['sha256'], 'final_documented_package': receipts[1]['sha256'],
    'installed_package_comparison': comparison, 'package_inventory_tests': 53,
    'tracked_rust_sources': 676, 'strict_product_wasm_clippy': True, 'rust_1_90_wasm_check': True,
    'exact_clean_source_gate': True, 'release_claim_eligible': False, 'publication': False,
    'scope': 'Real installed Chromium Worker, IndexedDB/OPFS and independently invoked native controller; same implementation on one host',
    'remaining': ['new-entry storage failures', 'C/Swift/Kotlin exposure', 'mobile browser qualification',
                  'independent implementation and host qualification', 'PCS and complete release admission'],
    'retained_failures': ['harness06 cancellation assertion expected WitnessTransport instead of contracted Cancelled',
                          'fixture-lock-03 attempted rustls update, but the non-TLS fixture has no such package; lock unchanged'],
})
allowed = {'.py', '.sh', '.rs', '.js', '.json', '.stdout', '.stderr', '.md', '.toml', '.lock', '.bin', '.request', '.reply'}
entries = {}
def add(path, name):
    sdk.require(not path.is_symlink(), 'symlink in evidence')
    sdk.require(name not in entries, 'duplicate archive name')
    entries[name] = sdk.snapshot(path, maximum=64 * 1024**2).data
def tree(base, prefix):
    for path in sorted(base.rglob('*')):
        if not path.is_file() or path.suffix not in allowed:
            continue
        relative = path.relative_to(base)
        sdk.require(not any(part in {'__pycache__', 'node_modules', '.git'} or part.endswith('-private') for part in relative.parts), 'private/generated tree selected')
        add(path, prefix + '/' + relative.as_posix())
for path in sorted(stage.iterdir()):
    if path.is_file() and path.suffix in allowed and path.name != 'HANDOFF_CURRENT.json':
        add(path, 'work/' + path.name)
for name in ['source-01', 'source-02', 'source-11', 'ci-10']:
    tree(stage / name, 'work/' + name)
for name in ['Cargo.toml', 'Cargo.lock']:
    add(stage / 'fixture-03' / name, 'fixture/' + name)
tree(stage / 'fixture-03/src', 'fixture/src')
for harness, labels in [('harness05', ['run05', 'run08']), ('harness06', ['run06']),
                        ('harness07', ['run07']), ('retirement-regression09', ['run09'])]:
    folder = stage / harness
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in allowed:
            add(path, 'browser/' + harness + '/' + path.name)
    for label in labels:
        tree(folder / label, 'browser/' + harness + '/' + label)
        tree(folder / (label + '-web') / 'inputs', 'browser/' + harness + '/' + label + '-public-inputs')
tree(checks, 'real-clone/checks')
for index, package in enumerate(packages, 1):
    for path in sorted(package.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.stdout', '.stderr'}:
            add(path, f'package-{index}/' + path.name)
with zipfile.ZipFile(out / 'CAPTURE.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
data = (out / 'CAPTURE.zip').read_bytes()
sdk.write_json(out / 'CAPTURE.json', {
    'source_commit': head, 'archive_sha256': hashlib.sha256(data).hexdigest(), 'archive_bytes': len(data),
    'members': len(entries), 'files': {name: hashlib.sha256(value).hexdigest() for name, value in sorted(entries.items())},
    'excluded': 'Private owners, databases and signing keys; browser profiles; generated caches; package/compiler outputs; mutable handoff',
})
with zipfile.ZipFile(out / 'CAPTURE.zip') as archive:
    sdk.require(archive.testzip() is None, 'archive CRC failure')
    for name, original in entries.items():
        sdk.require(archive.read(name) == original, 'archive readback mismatch')
print(json.dumps({'evidence': str(out), 'members': len(entries), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}))
