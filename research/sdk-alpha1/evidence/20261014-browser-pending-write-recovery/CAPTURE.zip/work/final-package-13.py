from pathlib import Path
import json
import os
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
source = json.loads((stage / 'SOURCE_COMMIT_12.json').read_text())
for name, digest in source['files'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest and sdk.snapshot(clone / name).sha256 == digest,
                'final package source drift')
qualification = clone / 'target/pending-recovery-browser-checks'
sdk.command([sys.executable, '-B', 'artifact/python_bootstrap.py', 'artifact/source_results_assembler.py',
             'ci-source-gate', '9974f5a3d2cb754817aa857a10859582d329c97edd61a44d41a2fb701d564bda',
             source['source_commit'], '--profile', 'sdk-020'], qualification / 'source-gate-13', clone)
shell = (stage / 'build-package-02.sh').read_text()
sdk.require(shell.count('browser-pending-recovery-package-01') == 1, 'package output marker')
path = stage / 'build-package-13.sh'
path.write_text(shell.replace('browser-pending-recovery-package-01', 'browser-pending-recovery-package-02'))
sdk.command(['sh', str(path)], stage / 'package-13', root, environment=dict(os.environ))
old = json.loads((clone / 'target/browser-pending-recovery-package-01/INSTALLED_CONSUMER.json').read_text())
new = json.loads((clone / 'target/browser-pending-recovery-package-02/INSTALLED_CONSUMER.json').read_text())
def contents(receipt):
    installed = Path(receipt['installed'])
    return {p.relative_to(installed).as_posix(): sdk.snapshot(p).sha256 for p in installed.rglob('*') if p.is_file()}
a, b = contents(old), contents(new)
sdk.require(set(a) == set(b), 'installed package file set changed')
changed = [name for name in a if a[name] != b[name]]
sdk.write_json(stage / 'INSTALLED_COMPARISON_13.json', {
    'source_commit': source['source_commit'], 'old_archive': old['sha256'], 'new_archive': new['sha256'],
    'changed_files': changed, 'unchanged_files': {name: b[name] for name in b if a[name] == b[name]},
    'old': {name: a[name] for name in changed}, 'new': {name: b[name] for name in changed},
})
sdk.require(set(changed) <= {'README.md', 'PACKAGE_CONTENTS.json'}, 'unexpected executable or dependency artifact difference')
print(json.dumps({'source_gate': True, 'new_archive': new['sha256'], 'changed_files': changed,
                  'installed_node_tests': new['installed_node_tests'], 'typescript': new['typescript']}))
