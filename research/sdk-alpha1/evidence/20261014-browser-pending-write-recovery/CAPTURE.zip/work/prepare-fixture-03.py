from pathlib import Path
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery';old=root/'target/continuity-browser-retirement/group-fixture-02';work=s/'fixture-03'
for p in [old/'Cargo.toml',old/'Cargo.lock',*sorted((old/'src').rglob('*.rs'))]:sdk.copy(p,work/p.relative_to(old))
sdk.copy(root/'target/continuity-browser-joint/authority/src/bin/qpc-joint-issuer.rs',work/'src/bin/qpc-pending-issuer.rs')
p=work/'src/bin/qpc-pending-issuer.rs';v=p.read_text();needle='        let roster = root.issue_roster(';sdk.require(v.count(needle)==1,'issuer roster marker')
v=v.replace(needle,'''        let mut entries = vec![root.roster_entry(&certificate)?];
        for slot in 0..2 {
            let retained = load(&dir.join(format!("recipients/{slot}/peer/PUBLIC.json")))?;
            let certificate = bytes(&retained, "certificate")?;
            let peer = pin(&cfg, prior)?.verify_historical_device(&certificate, &bytes(prior, "roster")?)?;
            if peer.device_id() == current.device_id() { return Err("peer selected renewing device".into()); }
            entries.push(root.roster_entry(&certificate)?);
        }
        let roster = root.issue_roster(''').replace('&[root.roster_entry(&certificate)?],','&entries,');p.write_text(v)
p=work/'src/bin/qpc-fanout-witness.rs';v=p.read_text().replace('fn main() -> Result<()> {','#[path = "pending/control.rs"]\nmod pending;\nfn main() -> Result<()> {');needle='        "retire-device" | "retain-inventory" | "retain-report" | "ack-report" => {';sdk.require(v.count(needle)==1,'controller routing marker');v=v.replace(needle,'''        "complete-pending-write" => pending::run(dir, &cfg, &args, now)?,
'''+needle);p.write_text(v)
p=work/'src/bin/pending/control.rs';p.parent.mkdir();p.write_text('''//! Privileged fixture controller; never dispatched from the ordinary HTTP endpoint.
use super::*;
fn bounded(path: &str, limit: usize) -> Result<Vec<u8>> {
    let mut bytes = Vec::new(); fs::File::open(path)?.take((limit + 1) as u64).read_to_end(&mut bytes)?;
    if bytes.len() > limit { return Err("controller input limit".into()); } Ok(bytes)
}
pub(super) fn run(dir: &Path, cfg: &Value, args: &[String], now: u64) -> Result<()> {
    if args.len() != 7 { return Err("complete-pending-write directory approved metadata signed-request result".into()); }
    let approved = p::AnchorPendingWriteRecoveryProposal::from_trusted_state(&bounded(&args[3], p::AnchorPendingWriteRecoveryProposal::ENCODED_BYTES)?)?;
    let metadata = bounded(&args[4], 4 * p::contract::MAX_JOURNAL_IMAGE_BYTES)?;
    let signed = bounded(&args[5], 8192)?;
    let mut witness = store(dir, cfg)?;
    let head = witness.complete_pending_write_recovery(&approved, &signed, &metadata, now)?;
    witness.close();
    publish_private_bytes(Path::new(&args[6]), &serde_json::to_vec_pretty(&json!({"confirmed":true,"proposal_binding":approved.binding(),"at":now,"head":{"fence":head.fence().to_string(),"revision":head.revision().to_string(),"digest":head.digest()}}))?)?;
    println!("independently approved original pending target confirmed"); Ok(())
}
''')
print('Fresh source-only fixture prepared; retained peer roster entries, separate privileged CLI')
