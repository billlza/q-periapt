from pathlib import Path
import json
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
base = '8358ef7ddcf5cbfa4cbe28899c711bc01645c90a'
inputs = json.loads((stage / 'INPUTS_02.json').read_text())
for relative in ['harness05/run05', 'harness05/run08', 'harness07/run07', 'retirement-regression09/run09']:
    value = json.loads((stage / relative / 'RESULT.json').read_text())
    sdk.require(value['completed'] and value['producer_unchanged'] and not value['fixture_failures'],
                'incomplete producer: ' + relative)
for checkout in [root, clone]:
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip() == base,
                'unexpected source head')
    changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=checkout, text=True).splitlines())
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=checkout, text=True).splitlines()
    sdk.require(changed == set(inputs) and not untracked, 'unowned source changes')
    for name, digest in inputs.items():
        sdk.require(sdk.snapshot(checkout / name).sha256 == digest, 'source drift: ' + name)
sdk.command([sys.executable, '-B', 'artifact/python_bootstrap.py', str(stage / 'document-10.py')],
            stage / 'document-11', root)
docs = ['research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md',
        'research/continuity-identity-candidate/README.md',
        'crates/q-periapt-sdk-wasm/PackageREADME.md']
final = {name: sdk.snapshot(root / name).sha256 for name in sorted([*inputs, *docs])}
for name in final:
    sdk.copy(root / name, stage / 'source-11' / name)
sdk.write_json(stage / 'FINAL_SOURCE_11.json', final)
sdk.command(['git', 'diff', '--check', 'HEAD'], stage / 'final-diff-11', root)
print('All browser producers terminal; final source and documentation prepared for review')
