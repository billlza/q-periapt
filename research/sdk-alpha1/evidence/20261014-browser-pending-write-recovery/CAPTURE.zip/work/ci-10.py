from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
out = root / 'target/continuity-browser-pending-recovery/ci-10'
out.mkdir()
for run in [38598459588, 38598486405, 38598486408, 38585131481, 38585160303]:
    sdk.command(['gh', 'run', 'view', str(run), '--repo', 'billlza/q-periapt',
                 '--json', 'headSha,status,conclusion,jobs,url'], out / str(run), root)
    value = json.loads((out / (str(run) + '.stdout')).read_text())
    print(json.dumps({'run': run, 'head': value['headSha'], 'status': value['status'],
                      'installed_rust': [{k: row[k] for k in ['databaseId', 'conclusion', 'startedAt', 'completedAt']}
                                         for row in value['jobs'] if row['name'] == 'continuity-installed-rust']}), flush=True)
