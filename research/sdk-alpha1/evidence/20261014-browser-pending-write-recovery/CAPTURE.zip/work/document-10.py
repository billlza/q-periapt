from pathlib import Path
import rust_sdk_profile as sdk

root = Path.cwd()
p = root / 'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md'
source = p.read_text()
before = '''Installed browser/foreign bindings, asynchronous cancellation and storage-failure
qualification for this new entry point remain open. Native tests and WASM
compilation do not establish those results or complete the 0.2.0 release gates.
'''
after = '''The browser `QPeriaptContinuityDevice` exposes the same preparation and exact
confirmation through its existing asynchronous operation owner. Preparation
returns `QPeriaptContinuityPendingWriteRequest`: retain `proposal()`, `metadata()`
and `signed_request()` before independent approval. Its `to_json()` supplies the
complete source and target views under schema 1; neither view is labeled committed.
Hexadecimal IDs and decimal-string u64 values preserve the original metadata.
`confirm_pending_write_recovery` takes the exact proposal, complete metadata,
original historical policy and independent witness pin. It creates no runtime.

Installed Chromium Worker checks use actual IndexedDB/OPFS, signed witness
requests, real authority expiry and a separate native control process. They cover
unapplied/already-applied writes, locally staged G/T, cancellation during Query,
Worker loss before confirmation and loss of the host result after local commit.
Each successful cohort retains original unknown-message accounting through G/T
completion and explicit report acknowledgement. Explicit cancellation returns
`Cancelled`; transport failure and cancellation are distinct outcomes. Both
require retaining the original approval and metadata after a missing result.

These are same-engine loopback checks on one host. They do not establish an
independent implementation, mobile-browser or power-loss equivalence. Targeted
storage-failure qualification and C/Swift/Kotlin exposure of this new entry point
remain open, alongside the wider 0.2.0 release gates.
'''
sdk.require(source.count(before) == 1, 'original evidence boundary')
p.write_text(source.replace(before, after))
p = root / 'research/continuity-identity-candidate/README.md'
source = p.read_text()
before = '''lifecycle flow; installed bindings for this new candidate entry remain open.'''
after = '''lifecycle flow. The browser owner exposes this flow without creating traffic
permission; foreign native bindings and broader platform qualification remain open.'''
sdk.require(source.count(before) == 1, 'original introduction boundary')
p.write_text(source.replace(before, after))
p = root / 'crates/q-periapt-sdk-wasm/PackageREADME.md'
source = p.read_text()
before = '''A reserved batch is abandoned as a whole: call `begin_account_abandonment`,'''
after = '''If an ordinary pending write remains after witness authority expiry, open the
original device and call `pending_write_recovery_request(originalPolicy, witness)`.
The returned `QPeriaptContinuityPendingWriteRequest` provides the exact proposal,
complete source/target metadata, signed request and a schema-1 JSON inspection.
Retain `proposal()`, `metadata()` and `signed_request()` durably before an
independent controller authorizes that exact effect. Historical device signatures
alone cannot grant this approval. Source and target descriptions are not proof
that either committed; metadata includes account/device linkage and needs private
host storage.

After the controller completes the original intent at the witness, call
`confirm_pending_write_recovery(proposal, metadata, originalPolicy, witness)`.
This performs a fresh signed read-only Query and applies only the exact original
sealed target. It creates no runtime, extends no validity and acknowledges no
loss report. Retain the same inputs after cancellation, Worker loss or any missing
result; reopen the original owner and confirm the exact target again. An absent
pending record alone is not success, and an intervening head advance conflicts.
Staged renewal approvals remain intact. Continue the existing independently
authorized renewal or cleanup workflow after confirmation. This flow cannot
resolve bound G/T/P/R intents, account-root fences or missing original storage.

A reserved batch is abandoned as a whole: call `begin_account_abandonment`,'''
sdk.require(source.count(before) == 1, 'original cleanup introduction')
source = source.replace(before, after)
before = '''This device-retirement flow does not implement managed account-root cutover or
repair the separate in-place renewal gap caused by an unapplied ordinary intent
after required-witness authorization expires.'''
after = '''This device-retirement flow does not implement managed account-root cutover.
An expired ordinary pending write uses the separate independent approval and
exact confirmation flow above; retirement itself cannot renew that authority.'''
sdk.require(source.count(before) == 1, 'original retirement scope')
p.write_text(source.replace(before, after))
print('Documented original pending-write recovery and remaining qualification boundaries')
