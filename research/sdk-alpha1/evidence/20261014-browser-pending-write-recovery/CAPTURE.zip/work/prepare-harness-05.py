from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery';h=s/'harness05';h.mkdir()
base=root/'target/continuity-browser-retirement/harness06'
sdk.copy(base/'server.py',h/'server.py');sdk.copy(base/'controller.js',h/'controller.js')
v=(root/'target/continuity-browser-recovery/worker-live.js').read_text();marker="    } else if (data.action.startsWith('cleanup-')) {";sdk.require(v.count(marker)==1,'worker marker')
branch='''    } else if (data.action.startsWith('pending-') || data.action.startsWith('renewal-')) {
      owner = await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);
      const p0=cfg.policies.required;
      const historical = p => own(new sdk.QPeriaptContinuityHistoricalPolicy(bytes(cfg.policy_root),bytes(cfg.family),BigInt(p.version),bytes(p.digest),bytes(p.wire)));
      const original=historical(p0), pin=witness();
      if(data.action==='pending-request') {
        const r=own(await owner.pending_write_recovery_request(original,pin));
        value={proposal:[...r.proposal()],binding:[...r.binding()],metadata:[...r.metadata()],signed:[...r.signed_request()],document:r.to_json()};
      } else if(data.action==='pending-confirm') {
        await owner.confirm_pending_write_recovery(bytes(data.approved),bytes(data.metadata),original,pin); value={confirmed:true};
      } else {
        const state=async()=>{const s=own(await owner.credential_renewal_status());return {phase:s.phase(),operation:s.operation_id()===undefined?null:[...s.operation_id()],statement:s.statement()===undefined?null:[...s.statement()]};};
        const request=async()=>own(await owner.witnessed_credential_renewal_request(bytes(data.renewalOperation),original,pin));
        if(data.action==='renewal-request') {
          const r=await request(), result={};
          for(const key of ['operation_id','journal','original_owner','original_policy_digest','current_policy_digest','original_roster_digest','previous_roster_digest','original_credential','original_roster','previous_credential','previous_roster']) result[key==='operation_id'?'operation':key]=[...r[key]()];
          for(const key of ['current_policy_version','original_roster_version','previous_roster_version','previous_valid_from','previous_valid_until'])result[key]=String(r[key]());
          result.current_policy_authorization=r.current_policy_authorization()===undefined?null:[...r.current_policy_authorization()];
          value={credentialRequest:result,status:await state()};
        } else if(data.action==='renewal-status') value={status:await state()};
        else {
          const issued=await get(data.case+'-joint-1.json');
          const runtime=own(new sdk.QPeriaptRuntime(bytes(cfg.sdk_policy),bytes(cfg.sdk_signature),bytes(cfg.sdk_root),bytes(cfg.sdk_state),32,4));runtimeCreated=true;
          const target=own(new sdk.QPeriaptContinuityPolicy(runtime,bytes(cfg.policy_root),bytes(cfg.family),BigInt(issued.policy.version),bytes(issued.policy.digest),bytes(issued.policy.wire),at()));
          if(data.action==='renewal-stage') {
            const r=await request(), account=own(new sdk.QPeriaptContinuityAccountTrust(bytes(cfg.account),bytes(cfg.root),BigInt(issued.version),bytes(issued.digest),bytes(cfg.family)));
            const g=own(new sdk.QPeriaptContinuityCredentialGrant(bytes(issued.grant),account,original,at()));
            const t=own(new sdk.QPeriaptContinuityPolicyContinuation(bytes(issued.joint),r,g,original,original,target,at()));
            own(await owner.stage_policy_continuation(g,t,bytes(issued.operation),target,at())); value={status:await state()};
          } else if(data.action==='renewal-prepare') {
            const p=own(await owner.prepare_witnessed_credential_renewal(original,target,pin,at())); value={proposal:[...p.bytes()],status:await state()};
          } else if(data.action==='renewal-commit') {
            const p=own(new sdk.QPeriaptContinuityCredentialProposal(bytes(data.proposal)));
            own(await owner.commit_witnessed_credential_renewal(p,original,target,pin,at()));value={status:await state()};
          } else throw Error('unknown renewal action');
        }
      }
      value.runtimeCreated=runtimeCreated;value.observedAt=Number(at());
'''
v=v.replace(marker,branch+marker);(h/'worker.js').write_text(v)
v=(base/'run.py').read_text();v=v[:v.index('                expired=case.startswith')]
v=v.replace("stage = root / 'target/continuity-browser-retirement/harness06'", "stage = root / 'target/continuity-browser-pending-recovery/harness05'")
v=v.replace("allowed = {'expired-unapplied','expired-applied'}", "allowed = {'unapplied','applied','staged-unapplied','staged-applied'}")
# The source selection was explicit and may use spaced literals.
a=v.index('allowed = ');b=v.index('\n',a);v=v[:a]+"allowed = {'unapplied','applied','staged-unapplied','staged-applied'}"+v[b:]
v=v.replace('browser-retirement-package-01','browser-pending-recovery-package-01').replace('qpc-retirement-','qpc-pending-')
v=v.replace("('worker.js','worker.js'), ('controller.js','controller.js'), ('storage-fault.js','storage-fault.js')", "('worker.js','worker.js'), ('controller.js','controller.js')")
v=v.replace(", stage / 'storage-fault.js'",'')
v=v.replace("stage.parent / ('group-target-02/debug/qpc-fanout-' + name)", "stage.parent / ('native-target-03/debug/qpc-fanout-' + name)")
v=v.replace("static = {", "binaries['issuer']=stage.parent/'native-target-03/debug/qpc-pending-issuer'\nstatic = {")
v=v.replace("['prepare-expiring-all' if case.startswith('expired-') else 'prepare',directory]", "['prepare-expiring-all',directory]")
v=v.replace("'Installed browser original permanent retirement and complete host accounting; native independent control plane, original two-recipient account and same shared engine on one host'", "'Installed browser exact original pending write recovery, independent control plane, G/T renewal and complete original loss accounting; same engine on one host'")
v+='''                staged=case.startswith('staged-');applied=case in {'applied','staged-applied'}
                grant['journal']=row['journal'];grant_path.write_text(json.dumps(grant))
                args['renewalOperation']=list(os.urandom(32))
                request_path=output/(case+'-renewal-request.json');issued_path=inputs/(key+'-joint-1.json')
                def stage_renewal():
                    r=success(dict(args,action='renewal-request'))['credentialRequest'];sdk.write_json(request_path,r)
                    native('issuer',['issue',directory,grant_path,'-',request_path,issued_path,'required'],case+'-issue-joint')
                    issued=json.loads(issued_path.read_text());row['joint_operation']=issued['operation'];row['joint_statement']=issued['transaction']
                    status=success(dict(args,action='renewal-stage'))['status']
                    sdk.require(status=={'phase':2,'operation':issued['operation'],'statement':issued['transaction']},'original joint stage')
                    return issued
                issued=stage_renewal() if staged else None
                mode='drop-advance' if applied else 'drop-before-advance'
                cut=invoke(dict(args,action='cleanup-session-begin',session=sessions[0],witnessMode=mode,cut='1'))
                sdk.require(cut.get('code')=='WitnessTransport' and cut.get('ownerClosed') is True,'original generic intent cut missing')
                fault=[v for v in records.get(key,[]) if v['mode']==mode and v['trigger']]
                sdk.require(len(fault)==1 and fault[0]['dispatched']==applied,'wrong witness cut')
                until=max(cfg['until'],cfg['policy_until']);sdk.require(int(time.time())<until,'cut was not before expiry')
                print(json.dumps({'case':case,'phase':'waiting for actual signed expiry','until':until}),flush=True)
                while int(time.time())<=until:time.sleep(min(5,max(0.05,until+1-time.time()+0.1)))
                row['expiry']={'until':until,'observed':int(time.time())}
                calls=len(records.get(key,[]))
                pending=success(dict(args,action='pending-request'));repeated=success(dict(args,action='pending-request'))
                sdk.require(not pending['runtimeCreated'] and pending['observedAt']>until,'historical preparation permission')
                sdk.require(len(records.get(key,[]))==calls,'metadata preparation sent network')
                for field in ['proposal','metadata','document','binding']:sdk.require(pending[field]==repeated[field],'original metadata changed')
                document=json.loads(pending['document']);row['pending']=document
                sdk.require(document['schema']==1 and document['proposal']==bytes(pending['proposal']).hex() and document['binding']==bytes(pending['binding']).hex(),'metadata scope')
                source,target=document['source'],document['target']
                sdk.require('role' not in source and 'role' not in target,'invented committed view role')
                sdk.require(source['local_account']==target['local_account']==bytes(cfg['account']).hex(),'original account')
                sdk.require(source['head']['fence']==target['head']['fence'] and int(target['head']['revision'])==int(source['head']['revision'])+1,'original ordinary target shape')
                sdk.require([r['id'] for r in source['records']]==[r['id'] for r in target['records']],'record loss in projection')
                def sessions_in(view):return {r['metadata']['session']['session']:r['metadata']['session'] for r in view['records'] if r['metadata']['kind']=='session'}
                before_sessions,after_sessions=sessions_in(source),sessions_in(target)
                sdk.require(set(before_sessions)==set(after_sessions)=={bytes(x).hex() for x in sessions},'incomplete original sessions')
                for slot in range(2):
                    sk=bytes(sessions[slot]).hex();a,b=before_sessions[sk],after_sessions[sk]
                    sdk.require(a['state']['kind']==b['state']['kind']=='live' and a['progress']==b['progress'],'session state changed')
                    aa=[e['accounting'] for e in a['state']['epochs']];bb=[e['accounting'] for e in b['state']['epochs']]
                    sdk.require(aa==bb and len(aa)==1 and len(aa[0]['unconfirmed'])==1 and aa[0]['unconfirmed'][0]['message']==bytes(original_slots[slot]).hex(),'unknown message accounting changed')
                original_closure=after_sessions[bytes(sessions[0]).hex()]['state']['previous_closure'];sdk.require(original_closure is not None,'original closure omitted')
                def retain(name,data):
                    folder=output/'accounting'/key;folder.mkdir(parents=True,exist_ok=True);path=folder/name
                    with path.open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
                    fd=os.open(folder,os.O_RDONLY)
                    try:os.fsync(fd)
                    finally:os.close(fd)
                    sdk.require(path.read_bytes()==data,'host readback');row.setdefault('host_accounting',[]).append({'path':str(path.relative_to(output)),'sha256':sdk.snapshot(path).sha256});return path
                approved_path=retain('approved.bin',bytes(pending['proposal']));metadata_path=retain('metadata.bin',bytes(pending['metadata']));signed_path=retain('signed.bin',bytes(pending['signed']));retain('inspection.json',pending['document'].encode())
                confirm_args=dict(args,action='pending-confirm',approved=pending['proposal'],metadata=pending['metadata'])
                if not applied:
                    refused=invoke(confirm_args);sdk.require(refused.get('code')=='Scope' and refused.get('ownerClosed') is True,'unapplied source falsely confirmed')
                damaged=list(pending['metadata']);damaged[-1]^=1;calls=len(records.get(key,[]))
                refused=invoke(dict(confirm_args,metadata=damaged));sdk.require(refused.get('code')=='Authentication' and refused.get('ownerClosed') is True,'modified retained metadata accepted')
                sdk.require(len(records.get(key,[]))==calls,'modified metadata contacted witness')
                again=success(dict(args,action='pending-request'));sdk.require(again['proposal']==pending['proposal'] and again['metadata']==pending['metadata'],'failed confirmation altered original intent')
                result_path=output/(case+'-controller.json')
                native('witness',['complete-pending-write',directory,approved_path,metadata_path,signed_path,result_path],case+'-controller')
                controlled=json.loads(result_path.read_text());sdk.require(controlled['confirmed'] and controlled['proposal_binding']==pending['binding'] and controlled['at']>until,'independent exact completion')
                calls=len(records.get(key,[]))
                for _ in range(2):sdk.require(success(confirm_args)['confirmed'],'exact fresh confirmation')
                sdk.require([r['request_tag'] for r in records[key][calls:]]==[1,1],'confirmation performed fresh Advance')
                missing=invoke(dict(args,action='pending-request'));sdk.require(missing.get('code')=='Absent' and missing.get('ownerClosed') is True,'missing intent presented as a request')
                if not staged:issued=stage_renewal()
                status=success(dict(args,action='renewal-status'))['status'];sdk.require(status=={'phase':2,'operation':issued['operation'],'statement':issued['transaction']},'staged G/T changed during recovery')
                prepared=success(dict(args,action='renewal-prepare'))['proposal'];proposal_path=retain('joint-proposal.bin',bytes(prepared))
                native('issuer',['approve',directory,grant_path,'-',request_path,issued_path,'required',proposal_path],case+'-joint-approve')
                committed=success(dict(args,action='renewal-commit',proposal=prepared))['status'];sdk.require(committed=={'phase':4,'operation':issued['operation'],'statement':issued['transaction']},'original G/T not completed')
                late=invoke(confirm_args);sdk.require(late.get('code')=='Conflict','advanced head accepted as exact retry')
                for slot,session_id in enumerate(sessions):
                    value=success(dict(args,action='cleanup-session-begin',session=session_id));report=json.loads(value['document'])
                    expected=after_sessions[bytes(session_id).hex()];sdk.require(report['epochs']==[e['accounting'] for e in expected['state']['epochs']] and report['session']==bytes(session_id).hex(),'complete original report changed')
                    if slot==0:sdk.require(bytes(value['report']).hex()==original_closure,'original closure ID replaced')
                    retain('session-'+str(slot)+'-report.json',value['document'].encode())
                    ack=success(dict(args,action='cleanup-session-ack',session=session_id,report=value['report']));sdk.require(ack['status']['phase']==2 and ack['status']['report']==value['report'],'actual report ACK missing')
                members=success(dict(args,action='cleanup-account-members'))['members'];sdk.require([v['message'] for v in members]==original_slots and [v['phase'] for v in members]==[4,4],'unknown outcomes promoted to delivery')
                sdk.require(success(dict(args,action='cleanup-account-retire'))['status']['phase']==5,'original aggregate not retired')
                sdk.require(len([r for r in peers.get(key,[]) if r['kind']==3])==len(data_frames),'recovery sent application traffic')
                stat=effect.stat();sdk.require(row['effect_before']==[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns],'original peer effect changed')
                for receipt in row['host_accounting']:sdk.require(sdk.snapshot(output/receipt['path']).sha256==receipt['sha256'],'host accounting changed')
                sdk.require(not failures,'fixture failed: '+json.dumps(failures))
                row.update(completed=True,original_intent_confirmed=True,joint_preserved=True,cleanup_complete=True)
                print(json.dumps({'case':case,'completed':True,'calls':len(row['calls']),'original_intent_confirmed':True,'joint_preserved':True,'cleanup_complete':True}),flush=True)
            run_state['witness_records']=records;run_state['peer_records']=peers
        except BaseException as error:
            run_state['protocol_failure']=repr(error);raise
        finally:
            run_state['witness_records']=records;run_state['peer_records']=peers;run_state['fixture_failures']=failures
            browser(['close'],'close')
    for name,digest in producer.items():sdk.require(sdk.snapshot(Path(name),maximum=256*1024**2).sha256==digest,'producer drift')
    for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web package drift')
    run_state.update(completed=True,producer_unchanged=True)
except BaseException as error:
    run_state['failure']=repr(error);raise
finally:
    sdk.write_json(output/'RESULT.json',run_state)
print(json.dumps({'completed':True,'cases':cases,'scope':run_state['scope']}))
'''
ast.parse(v);(h/'run.py').write_text(v)
print('Fresh real-expiry browser harness prepared; no old cohort data copied')
