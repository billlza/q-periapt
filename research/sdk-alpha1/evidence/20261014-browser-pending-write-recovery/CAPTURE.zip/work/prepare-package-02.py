from pathlib import Path
import subprocess,json
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery';clone=root/'target/continuity-browser-publication/source'
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p)
base='8358ef7ddcf5cbfa4cbe28899c711bc01645c90a'
sdk.require(git(root,'rev-parse','HEAD').decode().strip()==base and git(clone,'rev-parse','HEAD').decode().strip()==base,'base moved')
sdk.require(not git(clone,'status','--porcelain'),'clone not clean')
new=sorted(git(root,'ls-files','--others','--exclude-standard').decode().splitlines());sdk.require(len(new)==2 and all(p.endswith('/pending_recovery.rs') for p in new),'new module scope')
for name,old,updated in [('ARTIFACT.md','676 tracked `.rs` files','676 tracked `.rs` files')]:pass
for name,old,updated in [('ARTIFACT.md','674 tracked `.rs` files','676 tracked `.rs` files'),('artifact/codeql_rust_quality.py','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 674','EXPECTED_TRACKED_RUST_SOURCE_COUNT = 676')]:
 p=root/name;v=p.read_text();sdk.require(v.count(old)==1,'inventory marker');p.write_text(v.replace(old,updated))
p=root/'artifact/test_codeql_rust_quality.py';v=p.read_text();marker='            "research/continuity-identity-candidate/src/enrollment/witness_pending_write_recovery_tests.rs",';sdk.require(v.count(marker)==2,'positive/negative controls');p.write_text(v.replace(marker,marker+'\n'+'\n'.join('            '+json.dumps(n)+',' for n in new)))
paths=sorted(set(git(root,'diff','HEAD','--name-only').decode().splitlines())|set(new));inputs={p:sdk.snapshot(root/p).sha256 for p in paths};sdk.write_json(s/'INPUTS_02.json',inputs)
for p in paths:
 sdk.copy(root/p,s/'source-02'/p)
 target=clone/p;target.parent.mkdir(parents=True,exist_ok=True)
 if p in new:sdk.require(not target.exists(),'unexpected new clone file')
 else:sdk.require(target.read_bytes()==git(clone,'show','HEAD:'+p),'clone preimage changed')
 target.write_bytes((root/p).read_bytes())
git(clone,'add','--',*paths);git(root,'add','--',*new)
sdk.copy(clone/'target/browser-retirement-build.py',clone/'target/browser-pending-recovery-build.py')
shell=(root/'target/continuity-browser-retirement/build-package.sh').read_text().replace('browser-retirement-build.py','browser-pending-recovery-build.py').replace('browser-retirement-package-01','browser-pending-recovery-package-01')
(s/'build-package-02.sh').write_text(shell)
sdk.write_json(s/'CLONE_OVERLAY_02.json',{'base':base,'files':inputs,'new_rust':new})
print('Exact browser source overlay staged; 676 Rust files, package build ready')
