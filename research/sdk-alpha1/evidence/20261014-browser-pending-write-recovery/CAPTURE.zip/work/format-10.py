from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery'
inputs = json.loads((stage / 'INPUTS_02.json').read_text())
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
environment = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
toolchain = Path(environment['RUSTC']).parent
sdk.command([str(toolchain / 'cargo'), 'fmt', '--all', '--', '--check'],
            stage / 'format-10', root, environment=environment)
sdk.command(['git', 'diff', '--check', 'HEAD'], stage / 'diff-10', root)
for name, digest in inputs.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift')
print('Workspace formatting and diff checks passed')
