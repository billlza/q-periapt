from pathlib import Path
import json,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery'
files=set(subprocess.check_output(['git','diff','HEAD','--name-only']).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines())
inputs={p:sdk.snapshot(root/p).sha256 for p in sorted(files)};sdk.write_json(s/'INPUTS_01.json',inputs)
for p in inputs:sdk.copy(root/p,s/'source-01'/p)
env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';env['CC_wasm32_unknown_unknown']='/opt/homebrew/opt/llvm/bin/clang';tool=Path(env['RUSTC']).parent
sdk.command([str(tool/'cargo'),'clippy','--locked','--offline','-p','q-periapt-sdk-wasm','--features','browser-continuity','--lib','--target','wasm32-unknown-unknown','--target-dir',str(root/'target/continuity-browser-fanout/wasm-target'),'-j','2','--','-D','warnings'],s/'wasm-clippy-01',root,environment=env)
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'source drift')
print('Shared owner and actual browser product entry strict Clippy passed')
