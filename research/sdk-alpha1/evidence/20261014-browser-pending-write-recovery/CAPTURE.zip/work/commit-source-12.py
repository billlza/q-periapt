from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-pending-recovery'
clone = root / 'target/continuity-browser-publication/source'
base = '8358ef7ddcf5cbfa4cbe28899c711bc01645c90a'
files = json.loads((stage / 'FINAL_SOURCE_11.json').read_text())
overlay = json.loads((stage / 'INPUTS_02.json').read_text())
for name, digest in files.items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'final main source changed')
for name, digest in overlay.items():
    sdk.require(sdk.snapshot(clone / name).sha256 == digest, 'owned clone overlay changed')
for checkout, expected in [(root, set(files)), (clone, set(overlay))]:
    sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip() == base, 'head changed')
    changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=checkout, text=True).splitlines())
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=checkout, text=True).splitlines()
    sdk.require(changed == expected and not untracked, 'unowned source changes')
sdk.command(['git', 'add', '--', *files], stage / 'stage-source-12', root)
sdk.command(['git', 'diff', '--cached', '--check'], stage / 'staged-diff-12', root)
sdk.command(['git', 'commit', '-m', 'Add browser recovery for expired pending writes'], stage / 'commit-source-12', root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD^'], cwd=root, text=True).strip() == base, 'unexpected commit parent')
# The exact owned overlay is now committed above and saved under source-02/11.
# Restore only those previously verified paths, then adopt the committed source.
sdk.command(['git', 'restore', '--source=HEAD', '--staged', '--worktree', '--', *overlay], stage / 'restore-owned-clone-12', clone)
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'clone not clean after owned overlay integration')
sdk.command(['git', 'fetch', str(root), head], stage / 'fetch-source-12', clone)
sdk.command(['git', 'switch', '--detach', head], stage / 'checkout-source-12', clone)
for name, digest in files.items():
    sdk.require(sdk.snapshot(clone / name).sha256 == digest, 'committed clone source changed')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'final clone not clean')
sdk.write_json(stage / 'SOURCE_COMMIT_12.json', {'source_commit': head, 'base': base, 'files': files, 'clone_clean': True})
print(json.dumps({'source_commit': head, 'paths': len(files), 'clone_clean': True}))
