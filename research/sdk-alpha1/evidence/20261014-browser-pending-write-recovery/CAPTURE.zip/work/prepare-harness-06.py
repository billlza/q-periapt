from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery';old=s/'harness05';new=s/'harness06';new.mkdir()
for name in ['worker.js','controller.js','server.py','run.py']:sdk.copy(old/name,new/name)
p=new/'server.py';v=p.read_text();v=v.replace("'drop-before-advance')", "'drop-before-advance', 'hold-query')")
v=v.replace("trigger = mode != 'normal' and key not in faulted and record['advance_applied_reply']", "trigger = key not in faulted and ((mode == 'hold-query' and record['request_tag'] == 1) or (mode not in ('normal','hold-query') and record['advance_applied_reply']))")
v=v.replace("if mode == 'hold-advance': time.sleep(7)", "if mode in ('hold-advance','hold-query'): time.sleep(7)")
sdk.require("'hold-query')" in v and "mode == 'hold-query' and record['request_tag'] == 1" in v,'query fault markers');ast.parse(v);p.write_text(v)
p=new/'worker.js';v=p.read_text();v=v.replace('onmessage = async ({data}) => {', '''let liveOwner;
onmessage = async ({data}) => {
  if(data.controlClose) {
    try {
      if(!liveOwner) throw Error('no original owner to cancel');
      await liveOwner.close();
      postMessage({closeComplete:true,closed:liveOwner.is_closed()});
    } catch(error) { postMessage({closeComplete:true,error:String(error),code:error?.code}); }
    return;
  }''')
needle="      owner = await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);\n      const p0=cfg.policies.required;";sdk.require(v.count(needle)==1,'owner marker');v=v.replace(needle,needle.replace('\n      const p0=', '\n      liveOwner=owner;\n      const p0='))
needle="await owner.confirm_pending_write_recovery(bytes(data.approved),bytes(data.metadata),original,pin); value={confirmed:true};";sdk.require(v.count(needle)==1,'confirmation marker');v=v.replace(needle,"""await owner.confirm_pending_write_recovery(bytes(data.approved),bytes(data.metadata),original,pin);
        if(data.killAfterLocalConfirmation) { postMessage({localConfirmationObserved:true}); await new Promise(()=>{}); }
        value={confirmed:true};""")
p.write_text(v)
p=new/'controller.js';p.write_text('''globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', {type:'module'});
  let stopped=false, outcome, closeReceipt;
  const finish=(error,result)=>{if(stopped)return;stopped=true;clearTimeout(timer);worker.terminate();if(error)reject(error);else resolve(result);};
  const timer=setTimeout(()=>finish(Error('pending recovery Worker deadline')),45000);
  const interrupt=async marker=>{
    const before=await navigator.locks.query();
    if(before.held.length!==1)throw Error('original root lease missing before Worker interruption');
    const name=before.held[0].name,start=performance.now();worker.terminate();
    for(;;){const after=await navigator.locks.query();if(!after.held.some(v=>v.name===name))break;if(performance.now()-start>10000)throw Error('original root lease release deadline');await new Promise(r=>setTimeout(r,20));}
    finish(undefined,{done:true,...marker,rootHeldBefore:1,releaseWaitMs:performance.now()-start});
  };
  worker.onerror=e=>finish(Error(e.message));
  worker.onmessage=async({data})=>{
    try {
      if(data.ready){
        worker.postMessage(args);
        if(args.cancelAfterQuery || args.killAfterQuery){
          for(;;){if(stopped)return;const response=await fetch('/status/'+args.case,{credentials:'omit',cache:'no-store'});if(!response.ok)throw Error('query observation');const records=await response.json();
            if(records.some(r=>r.mode==='hold-query' && r.cut===args.cut && r.trigger && r.request_tag===1)){
              if(args.killAfterQuery)await interrupt({workerTerminatedBeforeConfirmation:true});else worker.postMessage({controlClose:true});break;
            }
            await new Promise(r=>setTimeout(r,20));
          }
        }
      }else if(data.localConfirmationObserved){
        if(!args.killAfterLocalConfirmation)throw Error('unexpected local confirmation marker');
        await interrupt({workerTerminatedAfterConfirmation:true});
      }else if(data.closeComplete){
        closeReceipt=data;if(data.error || data.closed!==true)throw Error('original cancellation close failed');
        if(outcome)finish(undefined,{...outcome,closeReceipt});
      }else if(data.done){
        if(args.action==='create' && data.value?.request){const response=await fetch('/capture/'+args.case+'.bin',{method:'POST',body:new Uint8Array(data.value.request)});if(!response.ok)throw Error('enrollment capture');delete data.value.request;}
        if(data.value?.phase==='requires-witness-enrollment'){const response=await fetch('/capture/'+args.case+'-genesis.json',{method:'POST',body:JSON.stringify(data.value)});if(!response.ok)throw Error('genesis capture');}
        if(args.cancelAfterQuery){outcome=data;if(closeReceipt)finish(undefined,{...outcome,closeReceipt});}else finish(undefined,data);
      }
    }catch(error){finish(error);}
  };
});
''')
p=new/'run.py';v=p.read_text().replace('harness05','harness06');a=v.index('allowed = ');b=v.index('\n',a);v=v[:a]+"allowed = {'cancel-query','worker-before-confirmation','worker-after-confirmation'}"+v[b:]
needle="                calls=len(records.get(key,[]))\n                for _ in range(2):sdk.require(success(confirm_args)['confirmed'],'exact fresh confirmation')";sdk.require(v.count(needle)==1,'fault insertion marker')
v=v.replace(needle,'''                if case=='cancel-query':
                    result=invoke(dict(confirm_args,witnessMode='hold-query',cut='30',cancelAfterQuery=True))
                    sdk.require(result.get('code')=='WitnessTransport' and result.get('ownerClosed') is True and result.get('closeReceipt')=={'closeComplete':True,'closed':True},'cancelled query released success or incomplete close')
                    retained=success(dict(args,action='pending-request'));sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'cancellation replaced original pending state')
                elif case=='worker-before-confirmation':
                    result=invoke(dict(confirm_args,witnessMode='hold-query',cut='30',killAfterQuery=True))
                    sdk.require(result.get('workerTerminatedBeforeConfirmation') is True and result.get('rootHeldBefore')==1,'missing actual Worker interruption')
                    retained=success(dict(args,action='pending-request'));sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'interruption changed original pending state')
                else:
                    result=invoke(dict(confirm_args,killAfterLocalConfirmation=True))
                    sdk.require(result.get('workerTerminatedAfterConfirmation') is True and result.get('rootHeldBefore')==1,'missing commit before host-result loss')
                    absent=invoke(dict(args,action='pending-request'));sdk.require(absent.get('code')=='Absent' and absent.get('ownerClosed') is True,'local commit was not durable after Worker loss')
                row['interruption']=result
                calls=len(records.get(key,[]))
                for _ in range(2):sdk.require(success(confirm_args)['confirmed'],'exact fresh confirmation')''')
ast.parse(v);p.write_text(v)
print('Independent fault cohorts prepared: query cancellation, pre-confirmation Worker kill, committed-result loss')
