from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

stage = Path.cwd() / 'target/continuity-browser-pending-recovery'
old, new = stage / 'harness06', stage / 'harness07'
result = json.loads((old / 'run06/RESULT.json').read_text())
observed = result['cases'][0]['calls'][-1]['result']
sdk.require(observed['code'] == 'Cancelled' and observed['ownerClosed'] is True,
            'original cancellation observation changed')
sdk.require(observed['closeReceipt'] == {'closeComplete': True, 'closed': True}
            and observed['cleanupErrors'] == [], 'original close receipt changed')
new.mkdir()
for name in ['worker.js', 'controller.js', 'server.py', 'run.py']:
    sdk.copy(old / name, new / name)
p = new / 'run.py'
source = p.read_text().replace('harness06', 'harness07')
before = "result.get('code')=='WitnessTransport' and result.get('ownerClosed') is True and result.get('closeReceipt')"
sdk.require(source.count(before) == 1, 'specific cancellation assertion marker')
source = source.replace(before, before.replace('WitnessTransport', 'Cancelled'))
ast.parse(source)
p.write_text(source)
sdk.write_json(stage / 'CANCELLATION_FIXTURE_CORRECTION_07.json', {
    'failed_run': 'harness06/run06/RESULT.json',
    'failed_run_sha256': sdk.snapshot(old / 'run06/RESULT.json').sha256,
    'observed': observed,
    'contract': 'browser/errors.rs maps Interrupted to Cancelled; browser/http.rs maps explicit transport cancellation to Interrupted',
    'change': 'Only the explicit cancellation error expectation changed; close, cleanup, original intent, real Query and complete accounting assertions retained.',
    'product_changed': False,
    'original_cohort_reopened': False,
})
print('Fresh harness07 prepared with exact Cancelled contract')
