from pathlib import Path
import ast
import rust_sdk_profile as sdk

root = Path.cwd()
old = root / 'target/continuity-browser-retirement/harness07'
new = root / 'target/continuity-browser-pending-recovery/retirement-regression09'
new.mkdir()
for name in ['worker.js', 'controller.js', 'server.py', 'run.py', 'storage-fault.js', 'retirement-cuts.js']:
    sdk.copy(old / name, new / name)
p = new / 'run.py'
source = p.read_text()
for before, after in [
    ('target/continuity-browser-retirement/harness07', 'target/continuity-browser-pending-recovery/retirement-regression09'),
    ('browser-retirement-package-01', 'browser-pending-recovery-package-01'),
    ('group-target-02/debug/', 'native-target-03/debug/'),
]:
    sdk.require(source.count(before) == 1, 'original regression input marker: ' + before)
    source = source.replace(before, after)
ast.parse(source)
p.write_text(source)
print('Source-only retirement regression uses fresh owners and current installed package/native binaries')
