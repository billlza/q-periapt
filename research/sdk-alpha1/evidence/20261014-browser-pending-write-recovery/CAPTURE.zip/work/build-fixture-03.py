from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();s=root/'target/continuity-browser-pending-recovery';work=s/'fixture-03';env=json.loads((root/'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text());env.pop('CARGO_TARGET_DIR',None);env['RUSTFLAGS']=env.get('RUSTFLAGS','')+' -D warnings';tool=Path(env['RUSTC']).parent
sdk.copy(work/'Cargo.lock',s/'fixture-original-03.lock')
sdk.command([str(tool/'cargo'),'update','--offline','-p','rustls','--precise','0.23.46'],s/'fixture-lock-03',work,environment=env)
sdk.command([str(tool/'rustfmt'),'--edition','2021',*[str(p) for p in sorted((work/'src').rglob('*.rs'))]],s/'fixture-format-03',root,environment=env)
inputs={str(p.relative_to(root)):sdk.snapshot(p).sha256 for p in [work/'Cargo.toml',work/'Cargo.lock',*sorted((work/'src').rglob('*.rs'))]};sdk.write_json(s/'FIXTURE_INPUTS_03.json',inputs)
sdk.command([str(tool/'cargo'),'build','--locked','--offline','--bins','--message-format=json','--target-dir',str(s/'native-target-03'),'-j','2'],s/'fixture-build-03',work,environment=env)
for p,h in inputs.items():sdk.require(sdk.snapshot(root/p).sha256==h,'fixture drift')
print('Fresh witness/issuer/peer fixture built against current native engine')
