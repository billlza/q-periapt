from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

import continuity_package as package

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-publication-export'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-publication-export'
C_OUTPUT = ROOT / 'target/continuity-managed-maintenance/source-f560d803/target/c-managed-qualification/result-01'
encode = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
sha = lambda body: hashlib.sha256(body).hexdigest()
before = (BASE / 'ci-before.yml').read_bytes()
after = (ROOT / '.github/workflows/ci.yml').read_bytes()
android_before = (BASE / 'android-before.yml').read_bytes()
android_after = (ROOT / '.github/workflows/continuity-android-installed.yml').read_bytes()
assert after == (BASE / 'ci-after.yml').read_bytes()
assert android_after == (BASE / 'android-after.yml').read_bytes()
red = (BASE / 'red-complete.stderr').read_text()
green = (BASE / 'green.stderr').read_text()
assert 'FAILED (failures=3)' in red
assert len(re.findall(r'^FAIL: test_installed_publication_bytes_survive_artifact_selection', red, re.M)) == 3
assert re.search(r'Ran 14 tests in [0-9.]+s\n\nOK\n$', green)


def selection(workflow):
    block = workflow.decode().split('\n  continuity-installed-rust:\n', 1)[1].split('\n  continuity-installed-swift:\n', 1)[0]
    patterns = re.findall(r'^\s+target/continuity-installed-rust/(.+)$', block, re.M)
    selected = set()
    for pattern in patterns:
        if pattern.endswith('/**'):
            for directory in C_OUTPUT.glob(pattern[:-3]):
                selected.update(path for path in directory.rglob('*') if path.is_file())
        else:
            selected.update(path for path in C_OUTPUT.glob(pattern) if path.is_file())
    return selected


foundation = json.loads((C_OUTPUT / 'CONTINUITY_PACKAGE.json').read_bytes())
assert foundation['completed'] and foundation['sources_unchanged']
old_selection, new_selection = selection(before), selection(after)
all_files = {path for path in C_OUTPUT.rglob('*') if path.is_file()}
publication_files = {path for path in (C_OUTPUT / 'c-publication-public').rglob('*') if path.is_file()}
assert len(publication_files) == 168
assert all_files - old_selection == new_selection - old_selection == publication_files
assert new_selection == all_files
current = package.source_inputs()
previous = foundation['source_inputs']
assert current.keys() == previous.keys()
assert all(current[key] == previous[key] for key in current if key != 'files')
assert current['files'].keys() == previous['files'].keys()
changed = {name: {'before': expected, 'after': current['files'][name]}
           for name, expected in previous['files'].items() if current['files'][name] != expected}
assert changed == {'.github/workflows/ci.yml': {'before': sha(before), 'after': sha(after)}}
result = {'completed': True, 'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'problem': 'CI retained publication summary receipts but omitted their raw public export directories.',
    'scope': 'Two workflows, three upload configurations, five explicit public-directory additions.',
    'regression_before': {'exitcode': 1, 'failed_upload_subtests': 3},
    'regression_after': {'exitcode': 0, 'tests': 14, 'warnings_or_skips_suppressed': False},
    'real_c_output_selection': {'files_total': len(all_files), 'omitted_before': 168, 'omitted_after': 0,
        'newly_retained': {path.relative_to(C_OUTPUT).as_posix(): sha(path.read_bytes()) for path in sorted(publication_files)}},
    'source_input_changes_from_completed_c_cohort': changed,
    'runtime_source_commit': foundation['source_commit'],
    'runtime_input_files_unchanged': True,
    'whole_package_source_inputs_identical_after_patch': False,
    'meaning': 'Only CI artifact selection differs in the captured input inventory. The completed Rust/C receipt remains pinned to its original source; this is not a new-source hosted pass.',
    'focused_android_workflow': {'before_sha256': sha(android_before), 'after_sha256': sha(android_after)},
    'postprocess_note': 'An initial diagnostic counted the assertion message twice per failure (traceback line and exception line). The retained unittest itself correctly reports three failures; readback uses its three FAIL headers.',
    'runtime_reexecuted_for_this_path_fix': False, 'new_wave_started': False,
    'remote_workflow_changed': False, 'push_performed': False}
files = {name: (BASE / name).read_bytes() for name in [
    'ci-before.yml', 'ci-after.yml', 'android-before.yml', 'android-after.yml',
    'red.stdout', 'red.stderr', 'red-complete.stdout', 'red-complete.stderr',
    'green.stdout', 'green.stderr', 'planned.patch']}
files['test_continuity_workflow_partitions.py'] = (ROOT / 'artifact/test_continuity_workflow_partitions.py').read_bytes()
files['RESULT.json'] = encode(result)
files['seal.py'] = Path(__file__).read_bytes()
manifest = {name: {'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(name) == body for name, body in files.items())
DEST.mkdir(parents=True, exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']), ('RESULT.json', files['RESULT.json'])]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
with (DEST / 'SHA256.json').open('xb') as stream:
    stream.write(encode(summary))
print(json.dumps(summary))
