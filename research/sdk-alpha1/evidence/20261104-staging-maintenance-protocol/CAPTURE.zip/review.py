"""Preserve the failed aggregate while checking the narrower observed facts."""
from pathlib import Path
import json
import sys
VALUE=b'synthetic original unpublished fixture payload'
BASE_CASES=['pinned-directory-negative-control','file-written','file-published','directory-written','directory-published','partial-manifest','changed-parent','changed-payload','symlink','hardlink','extra-entry','before-manifest']
def require(ok,message):
    if not ok:raise ValueError(message)
def verify(read):
    obj=lambda name:json.loads(read(name))
    lines=lambda name:[json.loads(line) for line in read(name).decode().splitlines() if line]
    first=lines('runtime-01.stdout');failed=lines('runtime-02.stdout');separate=lines('runtime-03.stdout')
    require(obj('RUNTIME_01.json')['exit']==0 and not read('runtime-01.stderr'),'basic runtime status')
    require([r['case'] for r in first[:-1]]==BASE_CASES and first[-1]['completed'] is True,'basic exact census')
    require(first[0]['formal_child_deleted_by_hypothetical_cleaner'] is True and first[0]['product_cleanup_exists'] is False,'negative control scope')
    pids=[r['old_pid'] for r in first if 'old_pid' in r]
    require(len(pids)==len(set(pids))==11 and all(type(p) is int and p>0 for p in pids),'real owner PID census')
    for row in first[1:5]:
        require(row['signal']==9 and row['active_owner_refused'] is True and row['control_retained'] is True,'lease/process receipt')
        require(row['outcome']==('NoPayload' if row['case'].endswith('published') else 'Reclaimed'),'bounded outcome')
        base='fixtures-01/'+row['case']
        require(len(read(base+'/attempt/manifest'))==79 and read(base+'/attempt/lease')==b'QPSTGL01','retained metadata')
        if row['case'].endswith('published'):
            path=base+'/formal'+('/value' if row['case'].startswith('directory') else '')
            require(read(path)==VALUE,'original published value')
    for row in first[5:-2]:require(row['refused'] is True and row['payload_unchanged'] is True,'substitution refused')
    require(first[-2]['residue_retained'] is True and first[-2]['no_application_bytes'] is True,'pre-metadata scope')
    require(read('fixtures-01/before-manifest/attempt/payload')==b'','pre-metadata bytes')
    require(obj('RUNTIME_02.json')['exit']==1 and failed==[first[0]] and b'PrivateFileError' in read('runtime-02.stderr'),'failed aggregate retained')
    prefix='fixtures-02/file-after-manifest'
    manifest=read(prefix+'/attempt/manifest')
    require(len(manifest)==79 and manifest[:9]==b'QPSTG001\x01' and read(prefix+'/attempt/payload')==b'','empty-payload failure boundary')
    inode=obj('FIXTURE_INODES.json')
    for i,name in enumerate([prefix,prefix+'/attempt',prefix+'/attempt/lease',prefix+'/attempt/payload']):
        row=inode[name];expected=row['dev'].to_bytes(8,'little')+row['ino'].to_bytes(8,'little')
        require(manifest[9+i*16:25+i*16]==expected,'failed attempt retains bound original inode')
    require(obj('RUNTIME_03.json')['exit']==0 and not read('runtime-03.stderr') and len(separate)==1,'separate control status')
    require(separate[0]['case']=='active-lease-replaced' and separate[0]['refused'] is True and separate[0]['payload_unchanged'] is True,'replacement lease refusal')
    require(separate[0]['old_pid'] not in pids,'separate actual owner')
    require(read('fixtures-03/active-lease-replaced/attempt/payload')==VALUE,'live original payload retained')
    return {'evidence_verified':True,'basic_run_completed':True,'basic_case_count':12,'basic_recorded_owner_cuts':11,
        'separate_active_lease_replacement_control_passed':True,'extended_aggregate_passed':False,
        'extended_aggregate_failure':'existing operational file opener refuses a valid empty unpublished payload',
        'product_maintenance_implemented':False,'legacy_orphan_cleanup_qualified':False,'general_recursive_cleanup_qualified':False,
        'other_platforms_qualified':False,'release_claim_eligible':False}
if __name__=='__main__':
    root=Path(sys.argv[1])
    print(json.dumps(verify(lambda name:(root/name).read_bytes()),indent=2))
