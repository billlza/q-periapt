from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt');out=root/'target/continuity-staging-maintenance';outside=Path(json.loads((out/'LOCATION.json').read_text())['path']);consumer=outside/'consumer'
sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env=dict(os.environ);env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',CARGO_TARGET_DIR=str(outside/'build'),CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),PATH=str(chain)+':'+env['PATH'])
logs=out/'build-05';logs.mkdir()
env.update(DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),RUSTFLAGS='-D warnings')
(out/'TOOL_LIBRARY_FIX.json').write_text(json.dumps({'selected_library':str(chain.parent/'lib/libLLVM.dylib'),'library_sha256':hashlib.sha256((chain.parent/'lib/libLLVM.dylib').read_bytes()).hexdigest(),'scope':'child-process-only dynamic loader search for the selected toolchain; no global toolchain change','warnings_denied':True},indent=2)+'\n')
commands=[('objcopy',[str(chain.parent/'lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy'),'--version']),('rustfmt',[str(chain/'rustfmt'),'--edition','2021',str(consumer/'src/bin/staging_maintenance.rs')]),('build',[str(chain/'cargo'),'build','--manifest-path',str(consumer/'Cargo.toml'),'--release','--bin','staging_maintenance','--locked','--offline']),('clippy',[str(chain/'cargo-clippy'),'clippy','--manifest-path',str(consumer/'Cargo.toml'),'--release','--bin','staging_maintenance','--locked','--offline','--','-D','warnings'])]
for name,cmd in commands:
 start=time.monotonic();r=capture_output(cmd,timeout_seconds=600,maximum_stdout_bytes=2*1024**2,maximum_stderr_bytes=2*1024**2,environment=env)
 (logs/(name+'.stdout')).write_bytes(r.stdout);(logs/(name+'.stderr')).write_bytes(r.stderr)
 (logs/(name+'.json')).write_text(json.dumps({'argv':cmd,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode: print(r.stderr.decode()[-6000:]);sys.exit(r.returncode)
(out/'staging_maintenance.rs').write_bytes((consumer/'src/bin/staging_maintenance.rs').read_bytes())
(out/'BUILD_RESULT.json').write_text(json.dumps({'completed':True,'binary':str(outside/'build/release/staging_maintenance'),'sha256':hashlib.sha256((outside/'build/release/staging_maintenance').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((out/'staging_maintenance.rs').read_bytes()).hexdigest()},indent=2)+'\n')
