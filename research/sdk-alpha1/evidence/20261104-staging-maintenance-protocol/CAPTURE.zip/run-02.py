from pathlib import Path
import hashlib,json,os,sys,time
root=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt');out=root/'target/continuity-staging-maintenance';build=json.loads((out/'BUILD_RESULT.json').read_text());binary=Path(build['binary']);outside=binary.parents[2]
sys.path.append(str(root/'artifact'))
from bounded_process import capture_output
cmd=[str(binary),'run',str(outside/'fixtures-02')];start=time.monotonic()
r=capture_output(cmd,timeout_seconds=120,maximum_stdout_bytes=1024**2,maximum_stderr_bytes=1024**2)
(out/'runtime-02.stdout').write_bytes(r.stdout);(out/'runtime-02.stderr').write_bytes(r.stderr);(out/'RUNTIME_02.json').write_text(json.dumps({'argv':cmd,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'fixtures':str(outside/'fixtures-02')},indent=2)+'\n')
print(r.stdout.decode());print(r.stderr.decode());sys.exit(r.returncode)
