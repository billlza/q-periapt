//! Isolated POSIX protocol experiment, not a product maintenance API.
use q_periapt_host_store::filesystem::{
    open_private_file, provision_private_file, publish_private_bytes, publish_private_directory,
    LockedFileBackend, OwnedPrivateDirectory,
};
use rustix::fs::{open, renameat_with, unlinkat, AtFlags, Mode, OFlags, RenameFlags};
use std::{
    error::Error,
    fs::{self, File},
    io::{self, Write},
    os::unix::{
        fs::{DirBuilderExt, MetadataExt},
        process::ExitStatusExt,
    },
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::mpsc,
    thread,
    time::{Duration, Instant},
};
type Result<T = ()> = std::result::Result<T, Box<dyn Error + Send + Sync>>;
const VALUE: &[u8] = b"synthetic original unpublished fixture payload";
const MANIFEST_BYTES: usize = 79;
fn require(ok: bool, message: &str) -> Result {
    if ok {
        Ok(())
    } else {
        Err(message.to_owned().into())
    }
}
fn private_directory(path: &Path) -> Result {
    fs::DirBuilder::new().mode(0o700).create(path)?;
    OwnedPrivateDirectory::open(path)?;
    Ok(())
}
fn directory(path: &Path) -> Result<File> {
    OwnedPrivateDirectory::open(path)?;
    Ok(File::from(open(
        path,
        OFlags::RDONLY | OFlags::DIRECTORY | OFlags::NOFOLLOW | OFlags::CLOEXEC,
        Mode::empty(),
    )?))
}
fn identity(file: &File) -> Result<[u8; 16]> {
    let m = file.metadata()?;
    let mut out = [0; 16];
    out.get_mut(..8)
        .ok_or("identity prefix")?
        .copy_from_slice(&m.dev().to_le_bytes());
    out.get_mut(8..)
        .ok_or("identity suffix")?
        .copy_from_slice(&m.ino().to_le_bytes());
    Ok(out)
}
fn payload(path: &Path, kind: &str) -> Result<File> {
    if kind == "file" {
        Ok(open_private_file(path, false)?)
    } else {
        directory(path)
    }
}
fn contents(root: &Path, kind: &str) -> Result<Vec<u8>> {
    Ok(fs::read(if kind == "file" {
        root.to_path_buf()
    } else {
        root.join("value")
    })?)
}
fn ready(root: &Path) -> Result {
    publish_private_bytes(&root.join("ready"), b"ready")?;
    loop {
        thread::sleep(Duration::from_millis(50));
    }
}
fn owner(root: &Path, kind: &str, phase: &str) -> Result {
    let control = root.join("attempt");
    private_directory(&control)?;
    let mut lease = provision_private_file(&control.join("lease"), Into::into, Ok)?;
    let probe = lease.try_clone()?;
    let _owner = LockedFileBackend::new(lease.try_clone()?)?;
    lease.write_all(b"QPSTGL01")?;
    lease.sync_all()?;
    let staged = control.join("payload");
    let mut data = if kind == "file" {
        provision_private_file(&staged, Into::into, Ok)?
    } else {
        private_directory(&staged)?;
        directory(&staged)?
    };
    if phase == "before-manifest" {
        return ready(root);
    }
    let parent = directory(root)?;
    let pinned = directory(&control)?;
    let mut manifest = b"QPSTG001".to_vec();
    manifest.push(if kind == "file" { 1 } else { 2 });
    for file in [&parent, &pinned, &probe, &data] {
        manifest.extend_from_slice(&identity(file)?);
    }
    manifest.extend_from_slice(b"formal");
    require(manifest.len() == MANIFEST_BYTES, "manifest shape")?;
    publish_private_bytes(&control.join("manifest"), &manifest)?;
    pinned.sync_all()?;
    parent.sync_all()?;
    if phase == "after-manifest" {
        return ready(root);
    }
    if kind == "file" {
        data.write_all(VALUE)?;
        data.sync_all()?;
    } else {
        publish_private_bytes(&staged.join("value"), VALUE)?;
        data.sync_all()?;
    }
    if phase == "published" {
        renameat_with(
            &pinned,
            "payload",
            &parent,
            "formal",
            RenameFlags::NOREPLACE,
        )?;
        parent.sync_all()?;
        pinned.sync_all()?;
    }
    ready(root)
}
#[derive(Debug, Eq, PartialEq)]
enum Observation {
    Reclaimed,
    NoPayload,
}
fn cleanup(root: &Path, kind: &str) -> Result<Observation> {
    let parent = directory(root)?;
    let control_path = root.join("attempt");
    let control = directory(&control_path)?;
    let lease = open_private_file(&control_path.join("lease"), false)?;
    let probe = lease.try_clone()?;
    let _owner = LockedFileBackend::new(lease)?;
    require(
        fs::read(control_path.join("lease"))? == b"QPSTGL01",
        "lease marker",
    )?;
    let manifest = fs::read(control_path.join("manifest"))?;
    require(manifest.len() == MANIFEST_BYTES, "manifest size")?;
    require(
        manifest.get(..8) == Some(b"QPSTG001")
            && manifest.get(8) == Some(&if kind == "file" { 1 } else { 2 }),
        "manifest version or kind",
    )?;
    require(manifest.get(73..) == Some(b"formal"), "manifest target")?;
    for (i, file) in [&parent, &control, &probe].into_iter().enumerate() {
        let start = 9 + i * 16;
        require(
            manifest.get(start..start + 16) == Some(identity(file)?.as_slice()),
            "original control scope",
        )?;
    }
    let names: Vec<_> = fs::read_dir(&control_path)?
        .map(|e| e.map(|e| e.file_name()))
        .collect::<io::Result<_>>()?;
    require(
        names
            .iter()
            .all(|n| n == "lease" || n == "manifest" || n == "payload"),
        "unexpected control entry",
    )?;
    let staged = control_path.join("payload");
    match fs::symlink_metadata(&staged) {
        Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(Observation::NoPayload),
        Err(e) => return Err(e.into()),
        Ok(m) => require(!m.file_type().is_symlink(), "payload symlink")?,
    }
    let original = payload(&staged, kind)?;
    require(
        manifest.get(57..73) == Some(identity(&original)?.as_slice()),
        "original payload identity",
    )?;
    if kind == "file" {
        require(original.metadata()?.nlink() == 1, "payload link count")?;
        unlinkat(&control, "payload", AtFlags::empty())?;
    } else {
        // Closed one-file tree for this protocol experiment only. This is not
        // an implementation or claim of a general recursive product sweeper.
        let children: Vec<_> = fs::read_dir(&staged)?
            .map(|e| e.map(|e| e.file_name()))
            .collect::<io::Result<_>>()?;
        require(
            children == [std::ffi::OsString::from("value")],
            "unadmitted tree shape",
        )?;
        let value = open_private_file(&staged.join("value"), false)?;
        require(value.metadata()?.nlink() == 1, "child link count")?;
        unlinkat(&original, "value", AtFlags::empty())?;
        original.sync_all()?;
        unlinkat(&control, "payload", AtFlags::REMOVEDIR)?;
    }
    control.sync_all()?;
    // The control record and its lease stay in place. Removing/recreating the
    // lock file, retry receipts and pre-manifest residues need a separate rule.
    Ok(Observation::Reclaimed)
}
fn wait_ready(child: &mut Child, root: &Path) -> Result {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        require(
            child.try_wait()?.is_none(),
            "owner exited before requested cut",
        )?;
        if root.join("ready").exists() {
            require(fs::read(root.join("ready"))? == b"ready", "ready bytes")?;
            return Ok(());
        }
        require(Instant::now() < deadline, "owner ready deadline")?;
        thread::sleep(Duration::from_millis(5));
    }
}
fn launch(root: &Path, kind: &str, phase: &str) -> Result<Child> {
    Ok(Command::new(std::env::current_exe()?)
        .args(["owner", root.to_str().ok_or("fixture path")?, kind, phase])
        .stdin(Stdio::null())
        .stdout(File::create(root.join("owner.stdout"))?)
        .stderr(File::create(root.join("owner.stderr"))?)
        .spawn()?)
}
fn reap(child: &mut Child) -> Result {
    let killed = child.kill();
    let waited = child.wait();
    killed?;
    let result = waited?;
    require(
        result.signal() == Some(9),
        "owner did not terminate by SIGKILL",
    )?;
    Ok(())
}
fn killed_owner(root: &Path, kind: &str, phase: &str) -> Result<u32> {
    let mut child = launch(root, kind, phase)?;
    let pid = child.id();
    let ready_result = wait_ready(&mut child, root);
    let cleanup_result = if ready_result.is_ok() {
        cleanup(root, kind)
            .map(|_| ())
            .and_then(|()| Err("active lease unexpectedly admitted cleanup".into()))
    } else {
        Ok(())
    };
    let busy = cleanup_result.as_ref().err().map(|e| e.to_string());
    let reaped = reap(&mut child);
    ready_result?;
    reaped?;
    require(
        busy.as_deref().is_some_and(|s| s.contains("already open")),
        "active owner was not refused by real database lease",
    )?;
    require(
        fs::read(root.join("owner.stderr"))?.is_empty(),
        "owner stderr",
    )?;
    Ok(pid)
}
fn pinned_descriptor_counterexample(root: &Path) -> Result {
    let formal = root.join("formal");
    let (send, receive) = mpsc::channel();
    let (resume, paused) = mpsc::channel();
    thread::scope(|scope| -> Result {
        let destination = formal.clone();
        let writer = scope.spawn(move || -> Result {
            publish_private_directory::<_, Box<dyn Error + Send + Sync>>(&destination, |staged| {
                publish_private_bytes(&staged.join("value"), VALUE)?;
                send.send(staged.to_path_buf())?;
                paused.recv_timeout(Duration::from_secs(10))?;
                Ok(())
            })?;
            Ok(())
        });
        let staged = receive.recv_timeout(Duration::from_secs(10))?;
        let held = directory(&staged)?;
        let before = identity(&held)?;
        resume.send(())?;
        writer.join().map_err(|_| "publisher panicked")??;
        require(
            !staged.exists() && identity(&directory(&formal)?)? == before,
            "directory was not actually published",
        )?;
        require(
            contents(&formal, "directory")? == VALUE,
            "published original before unsafe control",
        )?;
        unlinkat(&held, "value", AtFlags::empty())?;
        require(
            !formal.join("value").exists(),
            "negative control did not delete through original inode pin",
        )?;
        Ok(())
    })?;
    println!("{{\"case\":\"pinned-directory-negative-control\",\"formal_child_deleted_by_hypothetical_cleaner\":true,\"product_cleanup_exists\":false}}");
    Ok(())
}
fn run(out: &Path) -> Result {
    private_directory(out)?;
    let negative = out.join("pinned-counterexample");
    private_directory(&negative)?;
    pinned_descriptor_counterexample(&negative)?;
    for kind in ["file", "directory"] {
        for phase in ["written", "published"] {
            let root = out.join(format!("{kind}-{phase}"));
            private_directory(&root)?;
            let pid = killed_owner(&root, kind, phase)?;
            let manifest = fs::read(root.join("attempt/manifest"))?;
            let observation = cleanup(&root, kind)?;
            require(
                observation
                    == if phase == "published" {
                        Observation::NoPayload
                    } else {
                        Observation::Reclaimed
                    },
                "cleanup outcome",
            )?;
            require(
                !root.join("attempt/payload").exists(),
                "unpublished payload retained",
            )?;
            if phase == "published" {
                require(
                    contents(&root.join("formal"), kind)? == VALUE,
                    "formal state changed",
                )?;
            } else {
                require(
                    !root.join("formal").exists(),
                    "cleanup created formal state",
                )?;
            }
            require(
                fs::read(root.join("attempt/manifest"))? == manifest,
                "original record changed",
            )?;
            require(
                cleanup(&root, kind)? == Observation::NoPayload,
                "explicit no-payload retry",
            )?;
            println!("{{\"case\":\"{kind}-{phase}\",\"old_pid\":{pid},\"signal\":9,\"active_owner_refused\":true,\"outcome\":\"{observation:?}\",\"control_retained\":true}}");
        }
    }
    for change in [
        "partial-manifest",
        "changed-parent",
        "changed-payload",
        "symlink",
        "hardlink",
        "extra-entry",
    ] {
        let root = out.join(change);
        private_directory(&root)?;
        let pid = killed_owner(&root, "file", "written")?;
        let control = root.join("attempt");
        let staged = control.join("payload");
        match change {
            "partial-manifest" => fs::write(control.join("manifest"), b"QPSTG001")?,
            "changed-parent" => {
                let mut m = fs::read(control.join("manifest"))?;
                let b = m.get_mut(9).ok_or("scope byte")?;
                *b ^= 1;
                fs::write(control.join("manifest"), m)?;
            }
            "changed-payload" => {
                fs::rename(&staged, root.join("saved"))?;
                publish_private_bytes(&staged, b"different payload")?;
            }
            "symlink" => {
                fs::rename(&staged, root.join("saved"))?;
                std::os::unix::fs::symlink(root.join("saved"), &staged)?;
            }
            "hardlink" => fs::hard_link(&staged, root.join("alias"))?,
            "extra-entry" => publish_private_bytes(&control.join("unknown"), b"unclassified")?,
            _ => return Err("unknown control".into()),
        }
        let before = fs::read(&staged)?;
        let error = cleanup(&root, "file").expect_err("changed private fixture must be refused");
        require(
            fs::read(&staged)? == before,
            "refused cleanup changed payload",
        )?;
        println!("{{\"case\":\"{change}\",\"old_pid\":{pid},\"refused\":true,\"payload_unchanged\":true,\"error\":\"{error}\"}}");
    }
    let incomplete = out.join("before-manifest");
    private_directory(&incomplete)?;
    let pid = killed_owner(&incomplete, "file", "before-manifest")?;
    require(
        !incomplete.join("attempt/manifest").exists()
            && fs::read(incomplete.join("attempt/payload"))?.is_empty(),
        "data written before complete metadata",
    )?;
    require(
        cleanup(&incomplete, "file").is_err(),
        "incomplete attempt accepted",
    )?;
    require(
        incomplete.join("attempt/payload").exists(),
        "incomplete attempt removed",
    )?;
    println!("{{\"case\":\"before-manifest\",\"old_pid\":{pid},\"refused\":true,\"no_application_bytes\":true,\"residue_retained\":true}}");
    println!("{{\"completed\":true,\"scope\":\"isolated POSIX attempt protocol experiment; not product cleanup or general recursive maintenance\"}}");
    Ok(())
}
fn main() -> Result {
    let args: Vec<_> = std::env::args_os().collect();
    match args.get(1).and_then(|a| a.to_str()) {
        Some("owner") => owner(
            Path::new(args.get(2).ok_or("root")?),
            args.get(3).and_then(|a| a.to_str()).ok_or("kind")?,
            args.get(4).and_then(|a| a.to_str()).ok_or("phase")?,
        ),
        Some("run") => run(&PathBuf::from(args.get(2).ok_or("output")?)),
        _ => Err("expected run OUTPUT or owner ROOT KIND PHASE".into()),
    }
}
