from pathlib import Path
import hashlib,json,re,subprocess,shutil
import rust_sdk_profile as sdk
root=Path.cwd();out=Path(__file__).resolve().parent
work=root/'target/continuity-android-retired-next'
native=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())
saved=json.loads((work/'owned-harness-v1/STATE.json').read_text())
qualified=json.loads((work/'owned-runtime-v2/STATE.json').read_text())
assert saved['completed'] and not saved['live_producer'] and qualified['completed'] and not qualified['live_producer']
source=Path(saved['source']);env=native['environment'];binary=out/'android-harness'
assert not binary.exists();shutil.copy2(saved['binary'],binary)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==saved['binary_sha256']==qualified['harness_sha256']
assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==digest for name,digest in qualified['rust_sources'].items())
h={'copied_sha256':saved['binary_sha256'],'test_sources':qualified['rust_sources'],'receiver':native['native']['execution']['debug']['binaries']['C_client']['path']}
sdk.write_json(out/'EXECUTABLE.json',h)
package=json.loads((out/'PACKAGE.json').read_text())
for name,digest in package['source_sha256'].items():assert hashlib.sha256((Path(package['source'])/name).read_bytes()).hexdigest()==digest
def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.retired20261012'
 for path in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(path.read_text())
  if not state.get('installation_attempted') or (state.get('cleanup') and not state.get('owned_reverse_ports')):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1;transport=re.search(r'transport_id:(\d+)',selected[0]).group(1)
  def call(args):
   result=subprocess.run([adb,'-t',transport,*args],capture_output=True,text=True,timeout=60);assert result.returncode==0 and not result.stderr;return result.stdout
  for port in list(state.get('owned_reverse_ports',[])):
   call(['reverse','--remove','tcp:'+str(port)]);state['owned_reverse_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;path.write_text(json.dumps(state,indent=2)+'\n')
try:
 cases=out/'cases';runtime=dict(env,QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(out/'device-driver.py'),QPC_CONFIGURATION_RECEIVER=h['receiver'])
 stdout=sdk.command([str(binary),'--exact','android_retirement::original_android_retirement','--nocapture'],out/'execution',source,environment=runtime)
 assert stdout.count(b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 24 filtered out;')==1
 results={}
 for trust in ['fixed','recoverable']:
  case=cases/('signed-'+trust)
  assert (case/'process-count').read_bytes()==(21).to_bytes(8,'big')
  assert (case/'retirement-complete-report').read_bytes()==(case/'retirement-verified').read_bytes()
  assert (case/'roster-effect-before').read_bytes()==(case/'retirement-effect-after').read_bytes()
  device=json.loads((out/('device-signed-'+trust)/'STATE.json').read_text())
  assert device['completed'] and device['cleanup'] and not device.get('owned_reverse_ports')
  assert len(device['cases'])==21
  cuts=[c for c in device['cases'] if c.get('actual_cut_observed')]
  assert len(cuts)==3
  results[trust]={'foreign_processes':21,'actual_process_cuts':3,'case':str(case),'device_label':'signed-'+trust}
 sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('remote roster qualification and owned cleanup failed',[original,failure])
 raise
print('42 ART retirement calls and 6 actual process cuts passed; owned installations and mappings removed',flush=True)
