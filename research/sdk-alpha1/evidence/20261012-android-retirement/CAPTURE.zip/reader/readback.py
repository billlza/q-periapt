"""Read only archived public retirement bindings, without claiming MAC verification."""
import hashlib
import json
import zipfile


def commit(domain, data):
    return hashlib.sha3_256(len(domain).to_bytes(8, 'big') + domain
                           + len(data).to_bytes(8, 'big') + data).digest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def route(read):
    def fixed(name, length):
        value = read(name)
        require(len(value) == length, 'width: ' + name)
        return value

    def envelope(name, expected):
        wire = fixed('inputs/' + name, 4 + len(expected) + 3373)
        require(int.from_bytes(wire[:4], 'big') == len(expected)
                and wire[4:-3373] == expected, 'receipt binding: ' + name)

    require(fixed('process-count', 8) == (21).to_bytes(8, 'big'), 'process census')
    witness = fixed('inputs/witness-id', 32) + fixed('inputs/witness-public', 1985)
    binding = commit(b'Q-PERIAPT-CONTINUITY-ANCHOR-AUTHORITY/v1', witness)
    subject = fixed('inputs/witness-subject', 96)
    replacement = read('inputs/retirement-proposal')
    require(replacement.startswith(b'QPDRPL01' + binding), 'replacement authority')
    replacement_id = commit(b'Q-PERIAPT-CONTINUITY-DEVICE-REPLACEMENT-CANDIDATE/v1', replacement)
    receipt = fixed('inputs/retirement-receipt', 3754)
    body = receipt[4:-3373]
    require(int.from_bytes(receipt[:4], 'big') == 377
            and body.startswith(b'QPDRTR01' + binding + replacement_id + subject), 'retirement authority')
    inventory = fixed('retirement-inventory', 313)
    require(inventory.startswith(b'QPRCLP01' + binding + replacement_id + subject)
            and inventory[168:200] == body[249:281] and inventory[200:248] == body[168:216]
            and inventory[280] in (0, 1), 'original frozen inventory')
    envelope('retirement-inventory-receipt', inventory)
    proposal = fixed('retirement-report-proposal', 353)
    require(proposal.startswith(b'QPRRPT01' + inventory) and any(proposal[321:]), 'report proposal')
    require(read('inputs/retirement-report-proposal') == proposal
            and read('retirement-ack-proposal') == proposal, 'original report proposal changed')
    envelope('retirement-report-receipt', proposal)
    envelope('retirement-ack', b'QPRACK01' + proposal[8:])
    report = read('retirement-complete-report')
    require(323 <= len(report) <= 8388608 and report[:8] in (b'QPRDMD01', b'QPRDMD02')
            and report[8:321] == inventory, 'complete report inventory')
    require(read('retirement-verified') == report, 'complete report changed across erasure')
    require(read('retirement-report-reopened') == proposal[321:] + (1).to_bytes(4, 'big') + report,
            'reopened complete report')
    for name in ('report', 'journal', 'signer'):
        require(fixed('retirement-' + name + '-unknown', 32) == proposal[321:], 'cut report identity')
    for name, code in (('cancelled', 302), ('tampered-report', 208), ('wrong-purpose', 102), ('operational-denied', 215)):
        require(fixed('retirement-' + name, 4) == code.to_bytes(4, 'big'), 'refusal: ' + name)
    require(read('original.request') == read('activated.request'), 'original request changed')
    identity = fixed('original.identity', 64)
    prepared = fixed('prepared', 164)
    require(prepared[:4] == (2).to_bytes(4, 'big') and identity[32:] == prepared[4:36]
            and prepared[36:132] == subject, 'original journal or subject changed')
    require(fixed('inputs/successor-journal', 32) != identity[32:]
            and fixed('inputs/successor-subject', 96) != subject, 'generation replacement reused original state')
    effect = read('roster-effect-before')
    require(bool(effect) and read('retirement-effect-after') == effect, 'original business effect changed')
    return {'processes': 21, 'process_cuts': 3, 'report_bytes': len(report),
            'report_sha256': hashlib.sha256(report).hexdigest(), 'report_id': proposal[321:].hex(),
            'complete_report_preserved': True, 'old_business_effect_preserved': True}


def archive(path):
    with zipfile.ZipFile(path) as captured:
        names = captured.namelist()
        require(len(names) == len(set(names)), 'duplicate archive member')
        manifest = json.loads(captured.read('MANIFEST.json'))
        require(set(names) == set(manifest) | {'MANIFEST.json'}, 'archive inventory')
        for name, digest in manifest.items():
            require(hashlib.sha256(captured.read(name)).hexdigest() == digest, 'archive hash: ' + name)
        results = {}
        for lane in ('host/debug', 'host/release', 'art'):
            for trust in ('fixed', 'recoverable'):
                prefix = lane + '/cases/signed-' + trust + '/'
                results[lane + '/' + trust] = route(lambda name: captured.read(prefix + name))
        apk = json.loads(captured.read('art/PREPARED_APK.json'))
        pids = []
        for trust in ('fixed', 'recoverable'):
            state = json.loads(captured.read('art/device-signed-' + trust + '/STATE.json'))
            require(state['completed'] and state['cleanup'] and not state['owned_reverse_ports'], 'device cleanup')
            require(len(state['cases']) == 21, 'ART process census')
            cuts = [case for case in state['cases'] if case['actual_cut_observed']]
            require({case['mode'] for case in cuts} == {'retired-owned-' + n + '-unknown'
                    for n in ('report', 'journal', 'signer')} and len(cuts) == 3, 'ART actual process cuts')
            for case in state['cases']:
                require(case['process_absent_after_operation']
                        and case['installed_apk_sha256'] == apk['apk_sha256'], 'ART source identity or stop')
                pids.append(case['pid'])
                payload = captured.read('art/cases/signed-' + trust + '/' + case['label'])
                require(hashlib.sha256(payload).hexdigest() == case['result_sha256'], 'ART payload binding')
            for case in cuts:
                output = captured.read('art/device-signed-' + trust + '/' + case['label'] + '-instrument.stdout')
                require(b'INSTRUMENTATION_STATUS: stage=retirement-cut\n' in output
                        and b'INSTRUMENTATION_RESULT: shortMsg=Process crashed.' in output
                        and b'INSTRUMENTATION_RESULT: result=' not in output, 'ART expected interruption trace')
        require(all(type(pid) is int and pid > 0 for pid in pids) and len(set(pids)) == 42, 'ART process identities')
        return {'completed': True, 'archive_members': len(manifest), 'routes': results,
                'host_processes': 84, 'host_process_cuts': 12, 'ART_processes': 42, 'ART_process_cuts': 6,
                'agreed_physical_device_gate': 'passed', 'additional_phone_required': False,
                'scope': 'Archived public framing and binding readback. Native runtime, not this reader, verifies signatures and secret report MAC. Fresh Android-created old identity; native successor activation; no fresh Android successor traffic or physical erasure claim.'}
