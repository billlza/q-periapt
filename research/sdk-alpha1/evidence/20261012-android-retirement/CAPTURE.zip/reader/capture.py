from pathlib import Path
import hashlib
import json
import zipfile
import importlib.util

root = Path.cwd()
device = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retirement_public_readback', device / 'readback.py')
readback = importlib.util.module_from_spec(spec)
spec.loader.exec_module(readback)
work = root / 'target/continuity-android-retired-next'
out = root / 'research/sdk-alpha1/evidence/20261012-android-retirement'
out.mkdir()
host = json.loads((work / 'owned-runtime-v2/STATE.json').read_text())
package = json.loads((device / 'PACKAGE.json').read_text())
assert host['completed'] and not host['live_producer'] and package['completed']
assert json.loads((device / 'execution.json').read_text())['returncode'] == 0
assert all(hashlib.sha256((work / 'source' / n).read_bytes()).hexdigest() == d
           for n, d in host['source_sha256'].items())
assert all(hashlib.sha256((Path(package['source']) / n).read_bytes()).hexdigest() == d
           for n, d in package['source_sha256'].items())
assert all(hashlib.sha256((work / 'c-consumer' / n).read_bytes()).hexdigest() == d
           for n, d in host['rust_sources'].items())

records = '''activated.request authority-created original.identity original.request prepared process-count
retirement-ack-proposal retirement-cancelled retirement-complete-report retirement-effect-after
retirement-inventory retirement-journal-unknown retirement-operational-denied retirement-report-proposal
retirement-report-reopened retirement-report-unknown retirement-signer-unknown retirement-tampered-report
retirement-verified retirement-wrong-purpose roster-connected roster-effect-before roster-peer-associated
roster-peer-unassociated roster-unknown'''.split()
inputs = '''witness-id witness-public witness-subject witness-carrier retirement-proposal retirement-receipt
retirement-inventory-receipt retirement-report-proposal retirement-report-receipt retirement-ack
successor-request successor-certificate successor-roster successor-journal successor-subject
grant-certificate grant-roster trusted-account trusted-roster-version trusted-roster-digest
authority-id authority-application authority-checkpoint family policy-root policy-version policy-digest
protocol-policy sdk-policy sdk-signature sdk-root enrollment-root enrollment-intent
connection-session connection-message'''.split()
members = {}


def add(name, path):
    assert name not in members and path.is_file() and not path.is_symlink()
    members[name] = path.read_bytes()


def cases(prefix, directory):
    for trust in ('fixed', 'recoverable'):
        case = directory / ('signed-' + trust)
        target = prefix + '/cases/signed-' + trust + '/'
        for name in records:
            add(target + name, case / name)
            for suffix in ('.stdout', '.stderr'):
                path = case / (name + suffix)
                if path.exists():
                    add(target + name + suffix, path)
        for name in inputs:
            add(target + 'inputs/' + name, case / 'inputs' / name)


for profile in ('debug', 'release'):
    source = work / 'owned-runtime-v2' / profile
    cases('host/' + profile, source / 'cases')
    for name in ('execution.json', 'execution.stdout', 'execution.stderr', 'driver.py'):
        add('host/' + profile + '/' + name, source / name)
cases('art', device / 'cases')
for trust in ('fixed', 'recoverable'):
    directory = device / ('device-signed-' + trust)
    for path in directory.iterdir():
        add('art/' + directory.name + '/' + path.name, path)
for name in ('execution.json', 'execution.stdout', 'execution.stderr', 'OUTCOMES.json', 'EXECUTABLE.json',
             'PREPARED_APK.json', 'PACKAGE.json', 'run.py', 'device-driver.py', 'build-consumer.py',
             'prepare-apk.py', 'signature.stdout', 'signature.stderr'):
    add('art/' + name, device / name)
for name in host['source_sha256']:
    add('source/android/' + name, work / 'source' / name)
for name in host['rust_sources']:
    add('source/c-consumer/' + name, work / 'c-consumer' / name)
for name in ('STATE.json',):
    add('host/' + name, work / 'owned-runtime-v2' / name)
for name in ('readback.py', 'capture.py'):
    add('reader/' + name, device / name)
archive = out / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as captured:
    for name, data in sorted(members.items()):
        captured.writestr(name, data)
    captured.writestr('MANIFEST.json', json.dumps({n: hashlib.sha256(b).hexdigest()
                        for n, b in sorted(members.items())}, indent=2) + '\n')
result = readback.archive(archive)
result.update(capture_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
              integrated=False, native_engine_modified=False,
              private_device_keys_or_journals_archived=False,
              apk_sha256=json.loads((device / 'PREPARED_APK.json').read_text())['apk_sha256'],
              aar_sha256=package['aar_sha256'])
(out / 'CHECKS.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('completed', 'archive_members', 'host_processes', 'ART_processes', 'ART_process_cuts', 'capture_sha256')}))
