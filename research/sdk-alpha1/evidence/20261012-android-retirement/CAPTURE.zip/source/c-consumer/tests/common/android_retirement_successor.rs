// SPDX-License-Identifier: Apache-2.0 OR MIT
//! The independent issuer authorizes a fresh native successor using public old-device scope.
use crate::{fixture, p, Result};
use q_periapt_host_store::filesystem::publish_private_bytes;
use std::{fs, os::unix::fs::DirBuilderExt, path::Path, time::Duration};

pub(crate) struct Scope<'a> {
    pub(crate) root: &'a p::RootSigningKey,
    pub(crate) previous: &'a p::VerifiedDevice,
    pub(crate) previous_subject: p::AnchorSubject,
    pub(crate) policy: &'a p::VerifiedSessionPolicy,
    pub(crate) validity: p::Validity,
    pub(crate) witness: &'a fixture::WitnessFixture,
}
pub(crate) fn replace(inputs: &Path, directory: &Path, scope: Scope<'_>) -> Result<()> {
    let Scope {
        root,
        previous,
        previous_subject,
        policy,
        validity,
        witness,
    } = scope;
    fs::DirBuilder::new().mode(0o700).create(directory)?;
    p::JournalKey::provision(&directory.join("wrap.key"))?;
    let paths = p::EnrollmentPaths::new(
        &directory.join("wrap.key"),
        &directory.join("signer.key"),
        &directory.join("enrollment.redb"),
        p::InstallationPaths::new(
            &directory.join("installation.redb"),
            &directory.join("journal.redb"),
            &directory.join("archives.redb"),
        )?,
    )?;
    let intent = p::EnrollmentIntent::new(
        root.public_key()?,
        p::DeviceDescription::new(
            previous.device_id(),
            previous
                .generation()
                .checked_add(1)
                .ok_or("generation exhausted")?,
            policy.family(),
            validity,
        )?,
    );
    let mut enrollment = p::DeviceEnrollment::provision(paths, intent.clone())?;
    let request = enrollment.request(fixture::now()?)?;
    let verified = p::VerifiedEnrollmentRequest::verify(&request, &intent, fixture::now()?)?;
    let certificate = root.issue_enrollment(&verified, fixture::now()?)?;
    let issued = root.issue_roster(
        previous
            .roster()
            .checkpoint()
            .version()
            .checked_add(1)
            .ok_or("roster exhausted")?,
        validity,
        &[root.roster_entry(&certificate)?],
    )?;
    let account = p::AccountPin::new(
        root.account_id()?,
        root.public_key()?,
        issued.checkpoint(),
        policy.family(),
    )?;
    let device = account.verify_device(&certificate, issued.as_bytes(), fixture::now()?)?;
    assert_eq!(device.device_id(), previous.device_id());
    assert!(device.generation() > previous.generation());
    assert_ne!(device.credential_digest(), previous.credential_digest());
    let journal = enrollment.accept(
        &certificate,
        issued.as_bytes(),
        &account,
        policy,
        fixture::now()?,
    )?;
    let p::InstallationPreparation::RequiresEnrollment(genesis) =
        enrollment.prepare(policy, fixture::now()?)?
    else {
        return Err("replacement lost required witness".into());
    };
    assert_ne!(genesis.subject(), previous_subject);
    let (pin, proposal, receipt) = {
        let mut controller = witness.store.lock().map_err(|_| "replacement witness")?;
        let proofs = [(
            previous_subject,
            previous.roster().checkpoint(),
            policy.historical(),
        )];
        let proposal = controller.device_replacement_proposal(
            &genesis,
            &device,
            policy,
            &proofs,
            fixture::now()?,
        )?;
        assert_eq!(
            controller.replace_device(
                &proposal,
                &genesis,
                &device,
                policy,
                &proofs,
                fixture::now()?
            )?,
            p::AnchorDeviceReplacementState::Committed
        );
        let receipt = controller.retired_subject_receipt(&proposal, previous_subject)?;
        (controller.pin()?, proposal, receipt)
    };
    assert_eq!(
        pin.verify_retired_subject(&proposal, previous_subject, &receipt)?
            .subject(),
        previous_subject
    );
    let client = enrollment.anchor_client(
        policy,
        fixture::now()?,
        pin,
        Box::new(p::AnchorTcpTransport::new(witness.address)),
        Duration::from_secs(3),
    )?;
    let mut successor = enrollment.activate(policy, fixture::now()?, Some(client))?;
    successor.parts()?;
    successor.close();
    for (name, bytes) in [
        ("retirement-proposal", proposal.to_bytes()?),
        ("retirement-receipt", receipt),
        ("successor-request", request),
        ("successor-certificate", certificate),
        ("successor-roster", issued.as_bytes().to_vec()),
        ("successor-journal", journal.as_bytes().to_vec()),
        ("successor-subject", genesis.subject().to_bytes().to_vec()),
    ] {
        publish_private_bytes(&inputs.join(name), &bytes)?;
    }
    Ok(())
}
