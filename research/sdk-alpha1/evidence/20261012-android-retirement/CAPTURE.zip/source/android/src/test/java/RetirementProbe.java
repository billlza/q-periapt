// SPDX-License-Identifier: Apache-2.0 OR MIT
package dev.qperiapt.continuity.android.tests;

import dev.qperiapt.continuity.android.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Arrays;
import java.util.EnumSet;

/** Fresh, owned fixture consumer using the public Android retirement interface. */
public final class RetirementProbe {
    private static final int ENCODING = 101, AUTHENTICATION = 102;
    private RetirementProbe() { }
    private static void require(boolean condition, String reason) { if (!condition) throw new AssertionError(reason); }
    private static byte[] read(Path path, String name, int maximum) throws Exception {
        try (java.io.InputStream input = Files.newInputStream(path.resolve(name))) {
            java.io.ByteArrayOutputStream result = new java.io.ByteArrayOutputStream(); byte[] chunk = new byte[4096]; int count;
            while ((count = input.read(chunk)) != -1) {
                require(result.size() <= maximum - count, "retirement input exceeds bound: " + name); result.write(chunk, 0, count);
            }
            require(result.size() > 0, "empty retirement input: " + name); return result.toByteArray();
        }
    }
    private static byte[] exact(Path path, String name, int length) throws Exception {
        byte[] bytes = read(path, name, length); require(bytes.length == length, "retirement input width: " + name); return bytes;
    }
    private static void publish(Path path, String name, byte[] bytes) throws Exception {
        try (FileChannel output = FileChannel.open(path.resolve(name),
                EnumSet.of(StandardOpenOption.WRITE, StandardOpenOption.CREATE_NEW),
                PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")))) {
            ByteBuffer remaining = ByteBuffer.wrap(bytes);
            while (remaining.hasRemaining()) output.write(remaining);
            output.force(true);
        }
        try (FileChannel directory = FileChannel.open(path, StandardOpenOption.READ)) { directory.force(true); }
    }
    private static Counter64 counter(ByteBuffer bytes) { return new Counter64(Long.toUnsignedString(bytes.getLong())); }
    private static ContinuityRetiredEnrollment open(Path path) throws Exception {
        ByteBuffer validity = ByteBuffer.wrap(exact(path, "enrollment-validity", 16));
        EnrollmentIntent intent = new EnrollmentIntent(exact(path, "local-root", 1985), exact(path, "local-device", 16),
            counter(ByteBuffer.wrap(exact(path, "local-generation", 8))), exact(path, "family", 32), counter(validity), counter(validity));
        RetiredEnrollmentAuthority authority = new RetiredEnrollmentAuthority(exact(path, "witness-id", 32),
            exact(path, "witness-public", 1985), read(path, "retirement-proposal", 57794),
            exact(path, "witness-subject", 96), exact(path, "retirement-receipt", 3754));
        ContinuityRetiredEnrollment owner = ContinuityRetiredEnrollment.prepareOpen(path.toString(), intent, authority);
        try { owner.finishOpen(); return owner; }
        catch (Throwable failure) {
            try { owner.close(); } catch (Throwable cleanup) { failure.addSuppressed(cleanup); }
            throw failure;
        }
    }
    private static void failure(int expected, Runnable operation) {
        try { operation.run(); }
        catch (ContinuityFailure failure) { require(failure.code() == expected,
            "expected retirement code " + expected + ", got " + failure.code() + ": " + failure); return; }
        throw new AssertionError("retirement failure became success");
    }
    private static void sameProposal(Path path, RetiredReportProposal proposal) throws Exception {
        require(proposal != null && Arrays.equals(proposal.encoded(), exact(path, "retirement-report-proposal", 353)), "original retirement proposal changed");
    }
    private static void prepareAck(Path path, ContinuityRetiredEnrollment owner) throws Exception {
        sameProposal(path, owner.prepareAcknowledgement(exact(path, "retirement-inventory-receipt", 3690),
            exact(path, "retirement-report-receipt", 3730), read(path, "retirement-host-report", 8388608)));
        sameProposal(path, owner.acknowledgementProposal());
    }
    public static void main(String[] args) throws Exception {
        require(args.length == 3, "retirement arguments");
        run(Path.of(args[0]), args[1], Long.parseLong(args[2]));
    }
    public static void run(Path path, String mode, long process) throws Exception {
        require(process > 0 && Arrays.asList("inventory", "prepare-report", "report", "report-reopen", "prepare-ack", "erase-journal", "erase-signer", "verify").contains(mode), "retirement stage");
        publish(path, "retirement-process-" + mode, ByteBuffer.allocate(8).putLong(process).array());
        if (mode.equals("inventory")) {
            try (ContinuityRetiredEnrollment owner = open(path)) {
                publish(path, "retirement-inventory", owner.inventory().encoded());
                try { owner.prepareReport(new byte[3689]); throw new AssertionError("short receipt admitted"); }
                catch (IllegalArgumentException expected) { require(owner.inventory().encoded().length == 313, "preflight consumed owner"); }
                failure(ENCODING, () -> owner.prepareReport(new byte[3690]));
                failure(2, owner::inventory);
            }
            try (ContinuityRetiredEnrollment owner = open(path)) { owner.cancel(); failure(302, owner::inventory); }
        } else if (mode.equals("erase-journal")) {
            byte[] wrongPurpose = exact(path, "retirement-report-receipt", 3730);
            try (ContinuityRetiredEnrollment owner = open(path)) {
                failure(AUTHENTICATION, () -> owner.eraseJournal(wrongPurpose)); failure(2, owner::journalState);
            }
            try (ContinuityRetiredEnrollment owner = open(path)) {
                require(owner.journalState() == RetiredErasureState.RETAINED, "wrong purpose erased journal");
                owner.eraseJournal(exact(path, "retirement-ack", 3730)); Runtime.getRuntime().halt(77);
            }
        } else try (ContinuityRetiredEnrollment owner = open(path)) {
            switch (mode) {
                case "prepare-report":
                    RetiredReportProposal proposal = owner.prepareReport(exact(path, "retirement-inventory-receipt", 3690));
                    publish(path, "retirement-report-proposal", proposal.encoded()); sameProposal(path, owner.reportProposal()); break;
                case "report": case "report-reopen":
                    RetiredDeviceReport report = owner.loadReport(exact(path, "retirement-inventory-receipt", 3690), exact(path, "retirement-report-receipt", 3730));
                    require(report.viewCount() == 1 && Arrays.equals(report.report().encoded(), Arrays.copyOfRange(exact(path, "retirement-report-proposal", 353), 321, 353)), "report identity changed");
                    if (mode.equals("report")) { publish(path, "retirement-host-report", report.canonicalBytes()); Runtime.getRuntime().halt(77); }
                    require(Arrays.equals(report.canonicalBytes(), read(path, "retirement-host-report", 8388608)), "reopened report changed");
                    publish(path, "retirement-report-reopened", report.report().encoded()); break;
                case "prepare-ack": prepareAck(path, owner); break;
                case "erase-signer":
                    require(owner.journalState() == RetiredErasureState.ERASED, "journal retained before signer erasure");
                    owner.prepareSignerErasure(exact(path, "retirement-ack", 3730));
                    require(owner.signerState() == RetiredErasureState.RETAINED, "signer was not retained");
                    owner.eraseSigner(); Runtime.getRuntime().halt(77); break;
                case "verify":
                    prepareAck(path, owner); publish(path, "retirement-host-report-verified", read(path, "retirement-host-report", 8388608));
                    require(owner.journalState() == RetiredErasureState.ERASED && owner.signerState() == RetiredErasureState.ERASED, "erasure terminal missing");
                    owner.eraseSigner(); failure(2, owner::signerState);
                    publish(path, "retirement-verified", Arrays.copyOfRange(exact(path, "retirement-report-proposal", 353), 321, 353)); break;
                default: throw new AssertionError("unknown retirement stage");
            }
        }
        System.out.println("retirement-stage-pass:" + mode);
    }
}
