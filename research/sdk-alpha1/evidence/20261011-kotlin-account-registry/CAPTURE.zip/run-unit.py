from pathlib import Path
import hashlib,json,os,subprocess,shutil,time,sys,signal
out=Path(__file__).resolve().parent
main=out.parent.parent
sys.path.insert(0,str(main/"artifact"))
import continuity_kotlin_consumer as k
import jvm_sdk_package as jvm
meta=json.loads((main/"target/managed-enrollment-current/RESULT.json").read_text())
root=Path(meta["outside"])
base=Path("/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed")
java=base/"jdk-25.0.4.1+1/Contents/Home";gradle=base/"gradle-9.8.0"
cache=main/"target/foreign-device-retirement-current/kotlin-gradle-home";assert cache.is_dir()
profile=sys.argv[1];label=sys.argv[2];assert profile in ("debug","release")
run=out/label;run.mkdir()
builder_root=root/"kotlin-authority-source"
builder=builder_root/"bindings/kotlin/ContinuityPackageConsumer"
source=k.source_files()
for name,data in source.items():
 p=builder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for name,path in jvm.NOTICE_PATHS.items():
 p=builder_root/"LICENSES"/Path(name).name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,p)
env={a:v for a,v in os.environ.items() if not a.startswith(("JAVA","JDK","GRADLE","KOTLIN","CARGO","RUST","QPERIAPT","QPC","DYLD","LD_","PYTHON")) and a not in ("_JAVA_OPTIONS","CLASSPATH")}
env.update(JAVA_HOME=str(java),GRADLE_USER_HOME=str(cache),PATH=str(java/"bin")+":/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin")
library=root/("enrollment-current-installed-"+profile)/"libq_periapt_continuity_c_consumer.dylib"
flags=[str(gradle/"bin/gradle"),"--no-daemon","--offline","--warning-mode","fail","--dependency-verification","strict","--max-workers","2","-Dorg.gradle.java.installations.auto-download=false","-Pkotlin.compiler.execution.strategy=in-process","-Dorg.gradle.java.home="+str(java)]
args=flags+["--project-dir",str(builder),"test","publishContinuityPublicationToCandidateRepository","-Pqperiapt.continuity.lib="+str(library)]
hashes={name:hashlib.sha256(data).hexdigest() for name,data in source.items()}
r=dict(command=args,profile=profile,builder=str(builder),tools={"java":k.tool_identity(java),"gradle":k.tool_identity(gradle)},native_archive=meta["candidate_archive"],native_library={"path":str(library),"sha256":hashlib.sha256(library.read_bytes()).hexdigest()},source_sha256=hashes,scope="Kotlin registry component using the immutable installed C/native archive; not full Kotlin package qualification",completed=False)
(run/"START.json").write_text(json.dumps(r,indent=2)+"\n")
start=time.monotonic()
with (run/"stdout").open("wb") as so,(run/"stderr").open("wb") as se:
 p=subprocess.Popen(args,cwd=builder_root,env=env,stdout=so,stderr=se,start_new_session=True)
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);raise
r.update(returncode=code,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((builder/name).read_bytes()).hexdigest()==value for name,value in hashes.items()),library_unchanged=hashlib.sha256(library.read_bytes()).hexdigest()==r["native_library"]["sha256"])
(run/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
if code:
 print((run/"stdout").read_text()[-5000:]);print((run/"stderr").read_text()[-5000:]);raise SystemExit(code)
r["owner_tests"]=k.retain_test_reports(builder/"build/test-results/test",run)
contract=k.maven_contract();selected=run/"maven"
for path in (builder/"build/candidate-maven"/contract.path).iterdir():k.sdk.copy(path,selected/contract.path/path.name)
r["maven"]=jvm.verify_maven(selected,contract=contract)
r["completed"]=r["source_unchanged"] and r["library_unchanged"]
(run/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps({x:r[x] for x in ("profile","completed","seconds","owner_tests")}))
