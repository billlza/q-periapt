// SPDX-License-Identifier: Apache-2.0 OR MIT
import dev.qperiapt.continuity.ContinuityAccountAuthority;
public final class RawAccountAuthorityProbe {
    public static void main(String[] args) { new ContinuityAccountAuthority(null); }
}
