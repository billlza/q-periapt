report=target/continuity-sdk-input/sdk-rust-package/RUST_SDK_PACKAGE.json
report_sha256=$(shasum -a 256 "$report" | cut -d' ' -f1)
case "$CONTINUITY_CONSUMER" in
  swift)
    consumer_args=(--with-swift-consumer)
    ;;
  kotlin)
    gradle_home=$(sh artifact/python-run.sh -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve(strict=True).parent.parent)' "$(command -v gradle)")
    consumer_args=(--with-kotlin-consumer --kotlin-java-home "$JAVA_HOME" --kotlin-gradle-home "$gradle_home")
    ;;
  *)
    echo "Unsupported Continuity consumer: $CONTINUITY_CONSUMER" >&2
    exit 1
    ;;
esac
sh artifact/python-run.sh artifact/continuity_package.py \
  --report "$report" --report-sha256 "$report_sha256" \
  --toolchain-root "$(rustc +1.98.1 --print sysroot)" \
  --with-c-consumer "${consumer_args[@]}" \
  --witness-openssl-prefix "$(brew --prefix openssl@3)" \
  --output target/continuity-installed-swift
