"""Read only public publication artifacts; verify historical signatures, not live authority."""
import base64
import json
import re
import sys

LABELS = ('init', 'prepare', 'authority', 'refuse-anchor-fields', 'issue-first',
          'retrieve-first', 'retry-first', 'refuse-overwrite', 'refuse-retarget',
          'issue-witnessed', 'issue-disabled', 'refuse-issued-cancel', 'original-after-updates')
EXPORTS = ('export-first', 'export-retrieved', 'export-retry', 'export-witnessed',
           'export-disabled', 'export-original-after-updates')
REFUSALS = {'refuse-anchor-fields':'unknown field', 'refuse-overwrite':'Export directory must be empty',
            'refuse-retarget':'Original policy request differs', 'refuse-issued-cancel':'Issued policy cannot be cancelled'}


def check_publications(data, report, repo):
    sys.path.insert(0, str(repo/'research/continuity-openssl-peer'))
    from qperiapt_continuity_reference.provider import load_provider
    provider, backend = load_provider(repo/'target/independent-bootstrap-01/provider')
    from qperiapt_continuity_reference.enrollment_exchange import PolicyInputs
    from qperiapt_continuity_reference.authority import verify_sdk, SUITE
    from qperiapt_continuity_reference.wire import Reader, Interval, digest
    prefix = 'exchange/native-policy-public/'
    parse = lambda name: json.loads(data[prefix+name])
    observed = parse('RESULT.json')
    assert observed == report['native_policy_publication'] == json.loads(data['exchange/native-policy.stdout'])
    assert observed['completed'] is True and observed['commands'] == 13 and observed['expected_refusals'] == 4
    assert observed['policy_versions'] == [1,2,3] and observed['provider'] == '48.0.1'
    assert observed['independent_implementation'] == report['outside_root']+'/installed/qperiapt_continuity_reference/enrollment_exchange.py'
    assert re.fullmatch('[0-9a-f]{64}', observed['native_sha256'])
    assert observed['native_sha256'] == report['publisher_binary_sha256_producer_observation']
    executed = json.loads(data['exchange/native-policy.json'])
    assert executed['exit'] == 0 and data['exchange/native-policy.stderr'] == b''
    binary = executed['argv'][executed['argv'].index('--publisher')+1]
    commands = parse('COMMANDS.json')
    assert tuple(command['label'] for command in commands) == LABELS
    for command in commands:
        label = command['label']
        assert command['argv'][0] == binary
        stdout, stderr = data[prefix+label+'.stdout'], data[prefix+label+'.stderr']
        if label in REFUSALS:
            assert command['exit'] != 0 and stdout == b'' and REFUSALS[label].encode() in stderr
        else:
            assert command['exit'] == 0 and stderr == b''
    authority = parse('init.stdout')
    assert authority == parse('prepare.stdout') == parse('authority.stdout')
    first = parse('issue-first.stdout')
    assert first == parse('retrieve-first.stdout') == parse('retry-first.stdout') == parse('original-after-updates.stdout')
    for folder in ('export-retrieved','export-retry','export-original-after-updates'):
        for name in ('authority.json','policy-pins.json','policy-materials.json'):
            assert data[prefix+folder+'/'+name] == data[prefix+'export-first/'+name]
    publications = []
    for folder, label, version, mode in [('export-first','issue-first',1,2),
                                         ('export-witnessed','issue-witnessed',2,2),
                                         ('export-disabled','issue-disabled',3,0)]:
        output = parse(label+'.stdout')
        assert output['version'] == version and output['request']['bootstrap_mode'] == ('disabled' if mode == 0 else 'reusable_both')
        assert parse(folder+'/authority.json') == authority
        p = PolicyInputs.from_trusted(data[prefix+folder+'/policy-pins.json'],data[prefix+folder+'/policy-materials.json'])
        assert p.pins.sdk_root == base64.urlsafe_b64decode(authority['sdk_root']+'==')
        assert p.pins.sdk_state == base64.urlsafe_b64decode(authority['sdk_state']+'==')
        assert p.pins.policy_root.raw == base64.urlsafe_b64decode(authority['policy_root']+'==')
        assert p.materials.policy == base64.urlsafe_b64decode(output['policy']+'==')
        sdk = verify_sdk(p.pins,p.materials)
        body = p.pins.policy_root.open(p.materials.policy,4,200)
        assert digest(b'SESSION-POLICY',body) == p.pins.policy_digest == bytes(output['digest'])
        r = Reader(body)
        assert r.take(8) == b'QPSESP03' and r.take(32) == bytes(authority['family']) == digest(b'POLICY-AUTHORITY',p.pins.policy_root.raw)
        assert r.integer(8) == p.pins.policy_version == version
        interval = Interval.read(r)
        assert interval.start == output['request']['valid_from'] and interval.end == output['request']['valid_until']
        assert r.take(32) == SUITE and r.take(68) == sdk.wire() and r.integer(1) == mode
        anchor_mode, binding = r.integer(1),r.take(32)
        if version == 2:
            assert anchor_mode == 1 and binding == p.witness.binding
            assert output['request']['anchor'] == dict(kind='required',**parse(folder+'/policy-pins.json')['witness'])
            assert not p.witness.key.shares_component(p.pins.policy_root) and p.witness.key.raw[:1952] != p.pins.sdk_root
        else:
            assert anchor_mode == 0 and binding == bytes(32) and p.witness is None
            assert output['request']['anchor'] == {'kind':'local_only'}
        assert r.integer(2) == output['request']['send_budget'];r.finish()
        publications.append({'version':version,'digest':p.pins.policy_digest.hex(),'dual_signature':True,'sdk_signature':True})
    return {'commands':13,'expected_refusals':4,'public_files':46,'historical_publications':publications,
            'native_sha256_producer_observation':observed['native_sha256'],
            'readback_provider':provider.__version__,'readback_openssl':backend.openssl_version_text(),
            'scope':'Historical signatures and original operation/export consistency only; no clock override or live activation, and no authentication of the operator trust channel.'}
