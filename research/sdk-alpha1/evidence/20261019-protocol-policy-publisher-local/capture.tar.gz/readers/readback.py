"""Read terminal CI outputs only; no artifact code or binary is executed."""
import ast
import io
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent.parent
cohort = json.loads((OUT / "COHORT.json").read_text())
HEAD = cohort["head"]
RUN = cohort["run"]

def api(path):
    return subprocess.check_output(["gh", "api", "repos/billlza/q-periapt/" + path], timeout=60)

run = json.loads(api(f"actions/runs/{RUN}"))
assert run["head_sha"] == HEAD
assert run["path"] == ".github/workflows/reference-account.yml"
(OUT / "RUN_OBSERVED.json").write_text(json.dumps(run, indent=2) + "\n")
artifacts = json.loads(api(f"actions/runs/{RUN}/artifacts"))
expected = {
    "source-head.txt", "rustc.txt", "host.txt", "openssl.txt", "fmt.stdout", "fmt.stderr",
    "tests.stdout", "tests.stderr", "clippy.stdout", "clippy.stderr", "build.stdout",
    "build.stderr", "binary.sha256", "Cargo.lock", "release-tests.stdout", "release-tests.stderr", "node.txt", "web-tests.stdout", "web-tests.stderr",
}
source_paths = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "--", "research/continuity-reference-app/src"], cwd=REPO).decode().splitlines()
source_text = "\n".join(subprocess.check_output(["git", "show", f"{HEAD}:{name}"], cwd=REPO).decode() for name in source_paths if name.endswith(".rs"))
expected_test_names = set(re.findall(r"#\[(?:tokio::)?test\]\s*(?:async )?fn (\w+)", source_text))
assert len(expected_test_names) == 34
lock = subprocess.check_output(["git", "show", f"{HEAD}:research/continuity-reference-app/Cargo.lock"], cwd=REPO)
selected = sys.argv[1:] or ["ubuntu-24.04", "macos-15"]
assert selected and len(selected) == len(set(selected)) and set(selected) <= {"ubuntu-24.04", "macos-15"}
web_paths = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "--", "research/continuity-reference-app/tests/web"], cwd=REPO).decode().splitlines()
web_source = "\n".join(subprocess.check_output(["git", "show", f"{HEAD}:{name}"], cwd=REPO).decode() for name in web_paths if name.endswith(".test.mjs"))
web_names = set(re.findall(r"test\('([^']+)'", web_source))
assert len(web_names) == 17
expected.update({name + suffix for name in ('wheel-backend', 'provider', 'wheel-build', 'exchange') for suffix in ('.stdout','.stderr')})
expected.update({'exchange/' + name for name in ('qperiapt_continuity_reference-0.0.0-py3-none-any.whl','wheel-requirements.txt','install.stdout','install.stderr','install.json','INSTALLED_FILES.json','exchange.stdout','exchange.stderr','exchange.json','client.stdout','client.stderr','client.json','RESULT.json')})
sys.path.insert(0, str(REPO / 'artifact'))
from continuity_independent_python import inspect_wheel, PACKAGE, DIST

def source(name):
    return subprocess.check_output(['git','show',HEAD+':'+name],cwd=REPO)

def exchange(data):
    prefix = 'research/continuity-openssl-peer/'
    report = json.loads(data['exchange/RESULT.json'])
    assert report['schema_version'] == 3 and report['kind'] == 'qperiapt.host_enrollment_exchange'
    assert report['completed'] is True and report['release_claim_eligible'] is False and report['source_commit'] == HEAD
    paths = subprocess.check_output(['git','ls-tree','-r','--name-only',HEAD,'--',prefix+PACKAGE],cwd=REPO).decode().splitlines()
    modules = {Path(p).name:source(p) for p in paths if p.endswith('.py')}
    names = list(paths) + [prefix+n for n in ('tests/enrollment_exchange.py','tests/enrollment_client.py','pyproject.toml','README.md','ENROLLMENT_EXCHANGE.md','ENROLLMENT_CLIENT.md','LICENSE-APACHE','LICENSE-MIT','requirements.txt','build-requirements.txt')]
    names += ['artifact/'+n for n in ('continuity_host_exchange.py','continuity_independent_python.py','continuity_independent_python_run.py','bounded_process.py','evidence_io.py','git_provenance.py','python_bootstrap.py')]
    names += subprocess.check_output(['git','ls-tree','-r','--name-only',HEAD,'--','research/continuity-reference-app'],cwd=REPO).decode().splitlines()
    assert report['source_inputs'] == {p:hashlib.sha256(source(p)).hexdigest() for p in names}
    wheel = data['exchange/qperiapt_continuity_reference-0.0.0-py3-none-any.whl']
    assert hashlib.sha256(wheel).hexdigest() == report['wheel_sha256']
    files = inspect_wheel(wheel,modules,{n:source(prefix+n) for n in ('LICENSE-APACHE','LICENSE-MIT')},source(prefix+'README.md'))
    assert report['module_count'] == len(modules) == 50
    installed = json.loads(data['exchange/INSTALLED_FILES.json'])
    assert set(installed) == set(files) | {DIST+'/'+n for n in ('INSTALLER','REQUESTED','direct_url.json')}
    assert all(installed[n] == hashlib.sha256(b).hexdigest() for n,b in files.items() if n != DIST+'/RECORD')
    assert installed[DIST+'/INSTALLER'] == hashlib.sha256(b'pip\n').hexdigest()
    assert installed[DIST+'/REQUESTED'] == hashlib.sha256(b'').hexdigest()
    executions = {}
    for label, classname, count in [('exchange','ExchangeChecks',8),('client','ClientChecks',16)]:
        test = source(prefix+'tests/enrollment_'+label+'.py')
        names = sorted(n.name for n in ast.walk(ast.parse(test)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
        assert len(names) == count and report[label+'_test_names'] == names
        observed = json.loads(data['exchange/'+label+'.stdout'])
        assert report[label+'_execution'] == observed and observed['successful'] is True and observed['tests'] == len(names)
        assert all(observed[k] == 0 for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
        assert observed['provider_version'] == '48.0.1'
        assert observed['implementation'] == report['outside_root']+'/installed/'+PACKAGE+'/enrollment_'+label+'.py'
        assert all((name+' (__main__.'+classname+'.'+name+') ... ok').encode() in data['exchange/'+label+'.stderr'] for name in names)
        assert json.loads(data['exchange/'+label+'.json'])['exit'] == 0
        executions[label] = {'tests':len(names),'provider':observed['provider_version'],'openssl':observed['openssl']}
    assert json.loads(data['exchange/install.json'])['exit'] == 0
    assert json.loads(data['exchange.stdout']) == report
    assert data['exchange.stderr'] == b''
    return {'native_policy_publication':check_publications(data, report, REPO), 'wheel_sha256':report['wheel_sha256'],'module_count':len(modules),'executions':executions,'source_inputs':len(report['source_inputs'])}

sys.path.insert(0, str(OUT))
from publisher_readback import check_publications, LABELS, EXPORTS
expected.update({'exchange/native-policy'+suffix for suffix in ('.stdout','.stderr','.json')})
expected.update({'exchange/native-policy-public/'+name for name in ('COMMANDS.json','RESULT.json')})
expected.update({'exchange/native-policy-public/'+label+suffix for label in LABELS for suffix in ('.stdout','.stderr')})
expected.update({'exchange/native-policy-public/'+folder+'/'+name for folder in EXPORTS for name in ('authority.json','policy-pins.json','policy-materials.json')})
assert len(expected) == 89

results = []
jobs = json.loads(api(f"actions/runs/{RUN}/jobs"))["jobs"]
for os_name, architecture in [("ubuntu-24.04", "x86_64"), ("macos-15", "aarch64")]:
    if os_name not in selected:
        continue
    selected_job, = [j for j in jobs if os_name in j["name"]]
    job_id = selected_job["id"]
    job = json.loads(api(f"actions/jobs/{job_id}"))
    assert job["run_id"] == RUN and job["head_sha"] == HEAD
    assert job["status"] == "completed" and job["conclusion"] == "success"
    folder = OUT / os_name
    folder.mkdir(exist_ok=True)
    (folder / "JOB.json").write_text(json.dumps(job, indent=2) + "\n")
    artifact, = [a for a in artifacts["artifacts"] if a["name"] == "reference-account-" + os_name]
    assert artifact["workflow_run"]["head_sha"] == HEAD and not artifact["expired"]
    assert 0 < artifact["size_in_bytes"] < 1024 * 1024
    path = folder / "upstream.zip"
    if not path.exists():
        path.write_bytes(api(f"actions/artifacts/{artifact['id']}/zip"))
    payload = path.read_bytes()
    assert len(payload) == artifact["size_in_bytes"]
    assert "sha256:" + hashlib.sha256(payload).hexdigest() == artifact["digest"]
    (folder / "ARTIFACT.json").write_text(json.dumps(artifact, indent=2) + "\n")
    with zipfile.ZipFile(path) as z:
        assert len(z.infolist()) == len(expected) and set(z.namelist()) == expected
        assert sum(i.file_size for i in z.infolist()) < 1024 * 1024
        for i in z.infolist():
            p = PurePosixPath(i.filename)
            assert not p.is_absolute() and ".." not in p.parts and not stat.S_ISLNK(i.external_attr >> 16)
            assert not i.flag_bits & 1
        assert z.testzip() is None
        data = {n: z.read(n) for n in expected}
    assert data["source-head.txt"].decode().strip() == HEAD
    assert data["Cargo.lock"] == lock
    assert data["node.txt"].decode().strip() == "v26.10.0"
    assert data["web-tests.stderr"] == b""
    web_output = data["web-tests.stdout"].decode()
    assert set(re.findall(r"^ok \d+ - (.+)$", web_output, re.M)) == web_names
    assert all(f"# {label} {count}\n" in web_output for label, count in [("tests",17),("pass",17),("fail",0),("cancelled",0),("skipped",0),("todo",0)])
    assert "rustc 1.98.1 " in data["rustc.txt"].decode()
    assert f"host: {architecture}-" in data["rustc.txt"].decode()
    assert data["fmt.stderr"] == data["fmt.stdout"] == b""
    passed = set()
    for stage in ["tests", "release-tests"]:
        stage_passed = set(re.findall(r"^test [\w:]+::(\w+) \.\.\. ok$", data[stage + ".stdout"].decode(), re.M))
        assert stage_passed == expected_test_names
        assert all(f"test result: ok. {count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out" in data[stage + ".stdout"].decode() for count in [28, 6])
        passed = stage_passed
    for stage in ["tests", "release-tests", "clippy", "build"]:
        stderr = data[stage + ".stderr"].decode()
        assert "Finished " in stderr
        assert not re.search(r"^(?:error|warning)(?:\[|:)", stderr, re.M)
    assert "Finished `release` profile" in data["build.stderr"].decode()
    digest = data["binary.sha256"].decode().split()[0]
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    independent = exchange(data)
    public = folder / "public"
    public.mkdir(exist_ok=True)
    for name, body in data.items():
        (public / name).parent.mkdir(parents=True, exist_ok=True)
        (public / name).write_bytes(body)
    results.append({"platform": os_name, "head": HEAD, "run": RUN, "job": job_id, "artifact": artifact["id"], "artifact_sha256": artifact["digest"], "artifact_bytes": len(payload), "members": len(data), "independent_exchange": independent, "test_names": sorted(passed), "web_test_names": sorted(web_names), "binary_sha256_producer_observation": digest, "scope": "Terminal Rust debug/release34 entries (32 behavioral and2 child dispatchers), browser model17 tests, strict Clippy/build, installed independent adapter8/client16 and native publisher CLI13 commands/4 refusals. Historical public SDK and dual protocol signatures independently reverified without backdating activation. Protected native protocol signer; SDK authority and witness pins remain test inputs. No real user/device authorization, operational SDK root issuer, full lifecycle, power-loss, erasure, PCS or release admission."})
(OUT / ("READBACK_" + "-".join(selected) + ".json")).write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
