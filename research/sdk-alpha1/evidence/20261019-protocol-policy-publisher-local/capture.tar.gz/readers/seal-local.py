"""Capture only explicitly selected public outputs and source snapshots."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

repo=Path(__file__).resolve().parents[2]
root=repo/'target/policy-publisher-01'
installed=repo/'target/policy-publisher-installed-01'
head='85a18e75d7605d217e3bb0dcffcdb922b032b6e8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
entries={}
for label in ('strict-fields-green','clippy-03','build-release-02','fmt-check-final','tests-final','release-tests-final','interop-final','actionlint-final','diff-check-final'):
 for suffix in ('.command.json','.stdout','.stderr'):
  p=root/(label+suffix);entries['verification/'+p.name]=p.read_bytes()
for name in ('FINAL_COMMANDS.json','CLI_GREEN.json','anchor-fields-green.stdout','anchor-fields-green.stderr','anchor-history-green.stdout','anchor-history-green.stderr'):
 entries['verification/'+name]=(root/name).read_bytes()
red=root/'anchor-fields-red'
for name in ('CLI_RED.json','cli.stdout','cli.stderr'):
 p=red/name
 entries['before-fix/'+name]=p.read_bytes()
for p in (red/'source').rglob('*.rs'):
 entries['before-fix/source/'+p.relative_to(red/'source').as_posix()]=p.read_bytes()
for label in ('venv','backend','wheel','qualify'):
 for suffix in ('.stdout','.stderr'):entries['installed/'+label+suffix]=(installed/(label+suffix)).read_bytes()
for name in ('installed.py','CLONE_COMMANDS.json','BUILD_COMMANDS.json','BUILD_LOCATION.json','PUBLICATION_READBACK.json'):
 entries['installed/'+name]=(installed/name).read_bytes()
public=installed/'checkout/target/exchange-result'
for p in public.rglob('*'):
 if p.is_file():entries['installed/result/'+p.relative_to(public).as_posix()]=p.read_bytes()
changed=subprocess.check_output(['git','diff','--name-only',head+'^',head],cwd=repo,text=True).splitlines()
assert len(changed)==16
for name in changed:entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
for name in ('readback.py','publisher_readback.py'):entries['readers/'+name]=(repo/'target/policy-publisher-hosted-01'/name).read_bytes()
entries['readers/seal-local.py']=Path(__file__).read_bytes()
for name in entries:
 assert not any(part in ('private-inputs','private-native-policy','private-client','private-exchange') for part in Path(name).parts)
 assert not name.endswith(('.redb','.wrap','.signer','.pem'))
result=json.loads((public/'RESULT.json').read_text());assert result['completed'] is True and result['source_commit']==head
assert result['native_policy_publication']['commands']==13 and result['native_policy_publication']['expected_refusals']==4
files={name:{'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()} for name,value in entries.items()}
entries['PUBLIC_MANIFEST.json']=(json.dumps(files,indent=2)+'\n').encode()
destination=repo/'research/sdk-alpha1/evidence/20261019-protocol-policy-publisher-local';destination.mkdir(exist_ok=True)
archive=destination/'capture.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,value in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(value);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(value))
receipt={'source_commit':head,'capture':{'file':archive.name,'bytes':archive.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'native_binary_sha256_producer_observation':result['publisher_binary_sha256_producer_observation'],'local_checks':{'rust_debug_entries':34,'rust_release_entries':34,'rust_behavioral_tests':32,'rust_child_dispatchers':2,'publisher_process_kill_cuts':8,'strict_clippy':True,'fmt':True,'actionlint':True,'installed_client_tests':16,'installed_adapter_tests':8,'cli_commands':13,'expected_cli_refusals':4,'public_signature_readback_versions':[1,2,3],'source_input_files':len(result['source_inputs']),'wheel_modules':result['module_count'],'wheel_sha256':result['wheel_sha256']},'retained_state_regression':'Old CLI accepted extra witness fields on local_only. Fixed CLI refuses a fresh operation on the same retained database; original issued version4 and all original public exports remain byte-identical. No state recreation or clock override.','scope':'Native protected protocol-policy publisher and installed independent verification, with explicit test SDK authority/witness pin. No operational SDK root issuer, real host/device authorization, consumer activation, power-loss recovery, secure erasure, PCS or full lifecycle/release admission. Private fixture state and original failed binary remain outside this public capture.'}
(destination/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
