import hashlib
import json
import pathlib
import subprocess
import zipfile

DEBUG=pathlib.Path(__file__).resolve().parent
RELEASE=DEBUG.with_name('continuity-android-release-hosted-20261105')
REPO=DEBUG.parents[1]
DEST=REPO/'research/sdk-alpha1/evidence/20261105-hosted-jni-pair'

def sha(data):return hashlib.sha256(data).hexdigest()

files={'controller/capture_hardened.py':pathlib.Path(__file__),
       'controller/HARDENED_PAIR.json':DEBUG/'HARDENED_PAIR.json'}
for profile,root,attempt in (('debug',DEBUG,'replay-03'),('release',RELEASE,'replay-02')):
    for name in ('HARDENED_COMMAND.json','HARDENED_IDENTITY_COMMAND.json','hardened-replay.stdout',
                 'hardened-replay.stderr','hardened-identity.stdout','hardened-identity.stderr'):
        files[profile+'/'+name]=root/name
    for name in ('RESULT.json','REPLAYED.json'):
        files[profile+'/'+attempt+'/'+name]=root/attempt/name
    for label in ('replay','identity'):
        observed=json.loads((root/('hardened-'+label+'.stdout')).read_text().splitlines()[0])
        assert observed['isolated']==observed['no_site']==observed['dont_write_bytecode']==1
        assert 'qperiapt-python-cache.' in observed['private_cache_prefix']
        assert not pathlib.Path(observed['private_cache_prefix']).exists()
    assert json.loads((root/'HARDENED_COMMAND.json').read_text())['returncode']==0
    assert json.loads((root/'HARDENED_IDENTITY_COMMAND.json').read_text())['returncode']==0
for name in ('artifact/python-env.sh','artifact/python_bootstrap.py','artifact/python-run.sh'):
    files['source/'+name]=REPO/name
    assert (REPO/name).read_bytes()==subprocess.check_output(['git','show','5678d1019861fa1b04f3a219ba3fde7e0ddaaba8:'+name],cwd=REPO)
manifest={}
with zipfile.ZipFile(DEST/'HARDENED.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in sorted(files.items()):
        data=p.read_bytes();manifest[name]={'bytes':len(data),'sha256':sha(data)};archive.writestr(name,data)
with zipfile.ZipFile(DEST/'HARDENED.zip') as archive:
    assert set(archive.namelist())==set(manifest) and archive.testzip() is None
    for name,row in manifest.items():
        data=archive.read(name);assert len(data)==row['bytes'] and sha(data)==row['sha256']
catalog=json.loads((DEST/'FILES.json').read_text());catalog['HARDENED.zip']=manifest
(DEST/'FILES.json').write_text(json.dumps(catalog,indent=2,sort_keys=True)+'\n')
data=(DEST/'HARDENED.zip').read_bytes();summary={'bytes':len(data),'sha256':sha(data),'members':len(manifest)}
capture=json.loads((DEST/'CAPTURE.json').read_text());capture['capsules']['HARDENED.zip']=summary
(DEST/'CAPTURE.json').write_text(json.dumps(capture,indent=2)+'\n')
print(json.dumps(summary))
