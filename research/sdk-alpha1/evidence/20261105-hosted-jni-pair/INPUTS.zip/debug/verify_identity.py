import hashlib
import json
import pathlib
import struct
import subprocess
import sys
import zipfile

ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[1]
RAW=ROOT/'expanded'
COMMIT='232ace17915407596d66f3a5fd7c7765251a38cc'
sys.path.insert(0,str(ROOT/'source-232'/'artifact'))
import rust_sdk_profile as sdk
import continuity_package as package
import continuity_c_consumer as c
import continuity_c_witness_openssl as openssl
from evidence_io import parse_strict_json_bytes

def sha(data):return hashlib.sha256(data).hexdigest()
def require(condition,message):
    if not condition:raise ValueError(message)
def load(path):return parse_strict_json_bytes(path.read_bytes(),label=str(path))
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)

def git_hashes(names):
    names=sorted(names)
    require(all('\n' not in n for n in names),'invalid source name')
    data=subprocess.run(['git','cat-file','--batch'],cwd=REPO,input=''.join(COMMIT+':'+n+'\n' for n in names).encode(),
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    cursor=0;result={}
    for name in names:
        end=data.index(b'\n',cursor);header=data[cursor:end].split()
        require(len(header)==3 and header[1]==b'blob','source is not a Git blob')
        length=int(header[2]);start=end+1;cursor=start+length
        result[name]=sha(data[start:cursor]);require(data[cursor:cursor+1]==b'\n','Git framing mismatch');cursor+=1
    require(cursor==len(data),'unparsed Git batch suffix')
    return result

for folder,identifier in ((ROOT,13441811850),(ROOT/'sdk-producer',13405394674)):
    api=load(folder/'ARTIFACT.json');data=(folder/(str(identifier)+'.zip')).read_bytes()
    require(api['id']==identifier and api['size_in_bytes']==len(data) and api['digest']=='sha256:'+sha(data),'GitHub artifact identity mismatch')
    require(api['workflow_run']['head_sha']==COMMIT and api['workflow_run']['id']==42008993544,'artifact workflow lineage differs')

report=load(RAW/'CONTINUITY_PACKAGE.json');jni=load(RAW/'ANDROID_JNI_CONSUMER.json');native=load(RAW/'C_CONSUMER.json')
require(report['source_commit']==COMMIT and report['android_jni_consumer']==jni and report['c_consumer']==native,'package report objects differ')
require(report['source_inputs']==load(RAW/'sources-before.json')==load(RAW/'sources-after.json') and report['sources_unchanged'] is True,'source inventory changed')
require(report['kind']=='qperiapt.continuity_candidate_package_partition' and report['host_os']=='Darwin' and report['host_arch']=='arm64','execution scope differs')
for value in (report,jni,native):
    require(value['build_profiles']==['debug'] and value['partition_completed'] is True and value['completed'] is False
            and value['release_claim_eligible'] is False,'unexecuted profile claim')
require(report['publication_performed'] is False,'unexpected publication claim')
require(git_hashes(report['source_inputs']['files'])==report['source_inputs']['files'],'installed source inputs differ from commit')
jni_sources={'bindings/android/ContinuityPackageConsumer/'+name:value for name,value in jni['source_hashes'].items()}
require(git_hashes(jni_sources)==jni_sources,'JNI source identity differs')

sdk_path=ROOT/'sdk-producer/13405394674.zip'
sdk_archives={}
with zipfile.ZipFile(sdk_path) as archive:
    sdk_bytes=archive.read('sdk-rust-package/RUST_SDK_PACKAGE.json')
    cohort=parse_strict_json_bytes(sdk_bytes,label='original SDK producer report')
    require(sha(sdk_bytes)==report['rust_report_sha256'] and cohort['base_commit']==COMMIT,'SDK producer report differs')
    require(cohort['git_dirty'] is False and cohort['sources_unchanged'] is True and cohort['publication_performed'] is False,'SDK producer scope differs')
    require(git_hashes(cohort['source_inputs']['files'])==cohort['source_inputs']['files'],'SDK explicit source inputs differ')
    for name,row in cohort['crates'].items():
        data=archive.read('sdk-rust-package/crates/'+row['file'])
        require(len(data)==row['bytes'] and sha(data)==row['sha256'],'SDK archive identity differs')
        members=sdk.archive_files(data,name)
        require(len(members)==len(row['files'])==row['members'] and set(members)==set(row['files']),'SDK archive inventory differs')
        sdk_archives[name]={'bytes':len(data),'sha256':sha(data),'members':len(members)}
workspace=git('ls-tree','-r','--name-only',COMMIT,'--','Cargo.toml','Cargo.lock','rust-toolchain.toml','crates').decode().splitlines()
workspace_hashes=git_hashes(workspace);digest=hashlib.sha256()
for name,value in sorted(workspace_hashes.items()):digest.update(name.encode()+b'\0'+bytes.fromhex(value)+b'\0')
require(digest.hexdigest()==cohort['source_inputs']['rust_workspace_sha256']==report['source_inputs']['rust_workspace_sha256'],'SDK workspace root differs')

candidate_bytes=(RAW/report['archive']['file']).read_bytes()
require(len(candidate_bytes)==report['archive']['bytes'] and sha(candidate_bytes)==report['archive']['sha256'],'candidate archive identity differs')
candidate_members=sdk.archive_files(candidate_bytes,package.NAME,version=package.VERSION)
require(set(candidate_members)==set(report['archive']['files']) and len(candidate_members)==len(report['archive']['files']),'candidate member inventory differs')
candidate_sources={'research/continuity-identity-candidate/'+name:sha(data) for name,data in candidate_members.items() if name.startswith(('src/','tests/'))}
require(git_hashes(candidate_sources)==candidate_sources,'candidate packaged source differs')
original_lock=git('show',COMMIT+':research/continuity-identity-candidate/Cargo.lock')
resolutions={}
for label,lock_name,name,features,expected in (
    ('consumer-metadata','consumer-Cargo.lock',package.CONSUMER,frozenset({'connection-tls','control-tls'}),report['resolution']),
    ('c-metadata','c-consumer-Cargo.lock',c.NAME,c.FEATURES,native['resolution'])):
    metadata=load(RAW/(label+'.stdout'));root_id=metadata['resolve']['root']
    root_row=next(p for p in metadata['packages'] if p['id']==root_id)
    consumer=pathlib.Path(root_row['manifest_path']).parent
    require(root_row['name']==name and consumer.parent.name.startswith('qperiapt-continuity-package-'),'consumer origin differs')
    require(pathlib.Path(load(RAW/(label+'.json'))['cwd'])==consumer,'metadata command cwd differs')
    value=package.verify_resolution(metadata,consumer,(RAW/lock_name).read_bytes(),original_lock,
                                    consumer_name=name,required_features=features)
    require(value==expected,'installed graph receipt differs');resolutions[name]=value

jar=RAW/'continuity-android-classes.jar';require(sha(jar.read_bytes())==jni['jar_sha256'],'retained JAR differs')
with zipfile.ZipFile(jar) as archive:
    class_versions={}
    for name in archive.namelist():
        data=archive.read(name)
        require(name.endswith('.class') and data[:4]==b'\xca\xfe\xba\xbe','unexpected JAR content')
        version=struct.unpack('>H',data[6:8])[0];require(version==55,'JAR release level differs')
        class_versions[name]=version
require('--release' in load(RAW/'android-jni-main-compile.json')['argv'],'JAR compilation receipt absent')
row=jni['profiles']['debug'];binaries=native['execution']['debug']['binaries']
require(row['native_sha256']==binaries['C_library']['sha256'] and row['receiver_sha256']==binaries['C_client']['sha256'],'JNI/C binary receipt linkage differs')
fingerprints={k:row[k] for k in ('native_sha256','bridge_sha256','receiver_sha256','test_sha256','policy_target_client_sha256')}
fingerprints.update({k+'_sha256':v for k,v in row['recovery_outcomes']['binaries'].items()})
retained_matches={key:[] for key in fingerprints}
with zipfile.ZipFile(ROOT/'13441811850.zip') as archive:
    for member in archive.infolist():
        value=sha(archive.read(member))
        for key,expected in fingerprints.items():
            if value==expected:retained_matches[key].append(member.filename)

openssl_replayed={}
for kind in ('server','client','rejections'):
    folder=RAW/'c-witness-openssl-public/debug'/kind
    stdout=(RAW/('c-witness-openssl-'+kind+'-debug.stdout')).read_bytes()
    value=openssl.verify_execution(kind,stdout,folder)
    expected=native['execution']['debug']['witness_openssl']['execution'][kind]
    require(value=={k:v for k,v in expected.items() if k!='exported_public_files'},'OpenSSL public outcome differs')
    manifest=load(folder/'PUBLIC_FILES.json');require(manifest['files']==expected['exported_public_files'],'OpenSSL public export receipt differs')
    for name,digest_value in manifest['files'].items():require(sha((folder/name).read_bytes())==digest_value,'OpenSSL public member differs')
    openssl_replayed[kind]=value

current=load(ROOT/'CURRENT_SOURCE.json');before=report['source_inputs']['files'];after=current['source_inputs']['files']
changes={'changed':[name for name in sorted(before.keys()&after.keys()) if before[name]!=after[name]],
         'added':sorted(after.keys()-before.keys()),'removed':sorted(before.keys()-after.keys())}
outcome={'source_commit':COMMIT,'current_commit':current['commit'],'source_input_files':len(before),'current_source_input_files':len(after),
    'source_inputs_sha256':sha(json.dumps(report['source_inputs'],sort_keys=True,separators=(',',':')).encode()),
    'sdk_workspace_sha256':digest.hexdigest(),'current_sdk_workspace_sha256':current['source_inputs']['rust_workspace_sha256'],
    'sdk_report_sha256':sha(sdk_bytes),'sdk_workspace_files':len(workspace),'sdk_archives':sdk_archives,
    'candidate_archive_sha256':sha(candidate_bytes),'candidate_source_files':len(candidate_sources),
    'jni_source_files':len(jni_sources),'jar_sha256':sha(jar.read_bytes()),'jar_classes':len(class_versions),'jar_class_major':55,
    'installed_resolutions':resolutions,'receipt_only_native_binary_fingerprints':fingerprints,'retained_native_binary_matches':retained_matches,
    'source_changes':changes,'openssl_public_outcomes':openssl_replayed,
    'identity_readback_passed':True,'full_native_binary_byte_verification':False,
    'physical_art_aar_qualified':False,'aggregate_completed':False,'release_claim_eligible':False,
    'scope':'Original source, producer, archive, dependency graph and JAR verification plus original OpenSSL public readback. Native library/test fingerprints are retained receipts; absent binary bytes are not asserted verified.'}
(ROOT/'IDENTITY.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps({'source_input_files':len(before),'candidate_source_files':len(candidate_sources),'jni_source_files':len(jni_sources),
    'jar_classes':len(class_versions),'source_changes':{k:len(v) for k,v in changes.items()},'retained_native_binary_matches':retained_matches,
    'openssl_server_exchanges':openssl_replayed['server']['witness_exchanges'],'identity_readback_passed':True}))
