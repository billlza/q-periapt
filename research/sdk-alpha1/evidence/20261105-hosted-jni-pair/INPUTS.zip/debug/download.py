import concurrent.futures
import hashlib
import json
import pathlib
import sys
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent

def capture(item):
    path = ROOT / (str(item['id']) + '.zip')
    digest = hashlib.sha256()
    total = 0
    with urllib.request.urlopen(item['url'], timeout=60) as response, path.open('xb') as output:
        while chunk := response.read(1024 * 1024):
            total += len(chunk)
            if total > item['size']:
                raise ValueError('archive exceeds API size')
            output.write(chunk)
            digest.update(chunk)
    if total != item['size']:
        raise ValueError('archive size does not match API')
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('duplicate archive member')
        if archive.testzip() is not None:
            raise ValueError('archive CRC failure')
        for name in names:
            member = pathlib.PurePosixPath(name)
            if member.is_absolute() or '..' in member.parts or '\\' in name:
                raise ValueError('invalid archive path')
        inventory = [{'name': x.filename, 'bytes': x.file_size} for x in archive.infolist()]
    record = {'id': item['id'], 'name': item['name'], 'bytes': total,
              'sha256': digest.hexdigest(), 'members': inventory}
    (ROOT / (str(item['id']) + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    return {k: record[k] for k in ('id', 'name', 'bytes', 'sha256')} | {'members': len(inventory)}

request = json.load(sys.stdin)
results = []
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    futures = {executor.submit(capture, item): item['id'] for item in request}
    for future in concurrent.futures.as_completed(futures):
        # Do not print network exceptions, which can contain signed URLs.
        try:
            result = future.result()
            results.append(result)
            print(json.dumps(result), flush=True)
        except Exception as error:
            print(json.dumps({'id': futures[future], 'failed': type(error).__name__}), flush=True)
            raise RuntimeError('artifact capture failed; original partial file retained') from None
(ROOT / 'DOWNLOADS.json').write_text(json.dumps(sorted(results, key=lambda x: x['id']), indent=2) + '\n')
