import ast
import hashlib
import json
import pathlib
import stat
import subprocess
import unicodedata
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[1]
COMMIT = '232ace17915407596d66f3a5fd7c7765251a38cc'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

files = set(subprocess.check_output(['git','ls-tree','-r','--name-only',COMMIT,'artifact'],cwd=REPO,text=True).splitlines())
queue = ['artifact/continuity_android_jni.py','artifact/continuity_package.py','artifact/continuity_profiles.py']
sources = {}
while queue:
    name=queue.pop()
    if name in sources:
        continue
    data=subprocess.check_output(['git','show',COMMIT+':'+name],cwd=REPO)
    sources[name]=sha(data)
    path=ROOT/'source-232'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as out:out.write(data)
    for node in ast.walk(ast.parse(data)):
        modules=[a.name for a in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        for module in modules:
            candidate='artifact/'+module.replace('.','/')+'.py'
            if candidate in files:queue.append(candidate)
(ROOT/'READER_SOURCE.json').write_text(json.dumps({'commit':COMMIT,'files':dict(sorted(sources.items()))},indent=2)+'\n')

archive_path=ROOT/'13441811850.zip'
require(sha(archive_path.read_bytes())=='252dd1b4ffefc72f2ccbb7e8739fdbf02404b5ba7695c0c0bce5ffc177bb8b5e','original artifact changed')
out=ROOT/'expanded';out.mkdir()
with zipfile.ZipFile(archive_path) as archive:
    portable=set()
    require(sum(x.file_size for x in archive.infolist())==114585538,'archive expanded size differs')
    for member in archive.infolist():
        path=pathlib.PurePosixPath(member.filename)
        folded=unicodedata.normalize('NFC',member.filename).casefold()
        require(not member.is_dir() and not stat.S_ISLNK(member.external_attr>>16) and
                not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename and
                folded not in portable,'unsafe or colliding archive member')
        portable.add(folded)
    for member in archive.infolist():
        path=out/member.filename;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(archive.read(member))
print(json.dumps({'source_commit':COMMIT,'pinned_reader_modules':len(sources),
                  'extracted_members':len(portable),'expanded_bytes':114585538}))
