import hashlib
import json
import pathlib
import zipfile

DEBUG=pathlib.Path(__file__).resolve().parent
RELEASE=DEBUG.with_name('continuity-android-release-hosted-20261105')
OUT=DEBUG/'capsules';OUT.mkdir()

def sha(data):return hashlib.sha256(data).hexdigest()
def files_under(root):return [p for p in root.rglob('*') if p.is_file()]

groups={'INPUTS.zip':{},'DEBUG.zip':{},'RELEASE.zip':{}}
for p in files_under(DEBUG/'source-232')+files_under(DEBUG/'sdk-producer'):
    groups['INPUTS.zip']['debug/'+p.relative_to(DEBUG).as_posix()]=p
for p in DEBUG.glob('*.py'):
    groups['INPUTS.zip']['debug/'+p.name]=p
for name in ('READER_SOURCE.json','CURRENT_SOURCE.json','PAIR.json'):
    groups['INPUTS.zip']['debug/'+name]=DEBUG/name

for label,root,capsule,artifact in (('debug',DEBUG,'DEBUG.zip','13441811850'),('release',RELEASE,'RELEASE.zip','13443652836')):
    selected={artifact+'.zip',artifact+'.json','ARTIFACT.json','JOB.json','JOB.log','DOWNLOADS.json',
              'IDENTITY.json','TEST_INVENTORY.json','TEST_INVENTORY_SCOPE.json',
              'identity-01.stdout','identity-01.stderr','identity-01.COMMAND.json',
              'replay-01.stdout','replay-01.stderr','replay-01.COMMAND.json'}
    if label=='debug':selected.update({'STATUS.json','INITIAL_REPORT_INVENTORY.json','replay-02.stdout','replay-02.stderr','replay-02.COMMAND.json'})
    for name in selected:groups[capsule][label+'/'+name]=root/name
    for folder in ('replay-01','replay-02') if label=='debug' else ('replay-01',):
        for p in (root/folder).glob('*.json'):
            groups[capsule][label+'/'+p.relative_to(root).as_posix()]=p

inventories={};summary={}
for capsule,paths in groups.items():
    records={}
    with zipfile.ZipFile(OUT/capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(paths.items()):
            data=path.read_bytes();records[name]={'bytes':len(data),'sha256':sha(data)};archive.writestr(name,data)
    with zipfile.ZipFile(OUT/capsule) as archive:
        if set(archive.namelist())!=set(records) or archive.testzip() is not None:raise ValueError('capsule inventory/CRC differs')
        for name,row in records.items():
            data=archive.read(name)
            if len(data)!=row['bytes'] or sha(data)!=row['sha256']:raise ValueError('capsule full-member readback differs')
    data=(OUT/capsule).read_bytes()
    if len(data)>=100*1024**2:raise ValueError('capsule exceeds repository file limit')
    summary[capsule]={'bytes':len(data),'sha256':sha(data),'members':len(records)}
    inventories[capsule]=records
    print(json.dumps({'capsule':capsule,**summary[capsule]}),flush=True)
(OUT/'FILES.json').write_text(json.dumps(inventories,indent=2,sort_keys=True)+'\n')
(OUT/'CAPTURE.json').write_text(json.dumps({'capsules':summary,'original_artifacts':[
    {'id':13441811850,'profile':'debug','bytes':82412095,'sha256':'252dd1b4ffefc72f2ccbb7e8739fdbf02404b5ba7695c0c0bce5ffc177bb8b5e','members':33313},
    {'id':13443652836,'profile':'release','bytes':82536838,'sha256':'bf2e1c2fe4b343fde0f88174827cabebc0b1d8cd8fafa865f949f35fa4c3e3eb','members':33313},
    {'id':13405394674,'profile':'sdk-producer','bytes':5939469,'sha256':'de332b6dde0a76159687b295e060c36438e5e52d079035703dd891b95c8a11f3','members':115}],
    'scope':'Two original completed host JNI partitions, original SDK producer, source and public readbacks. The initial Debug mapping failure is retained. No new native workload, ART/AAR or release qualification.'},indent=2)+'\n')
