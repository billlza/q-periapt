"""Verify the exact committed and frozen source closure; no older fallback."""
from pathlib import Path
import hashlib, subprocess, json
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;PEER=OUT/'source'
HEAD='4cf7a202789843df7980ff7c3a9675f13749e62f'
EXPECTED=json.loads((OUT/'SOURCE_FILES.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def source_bytes(name,expected):
 p=Path(name)
 if p.is_absolute() or '..' in p.parts or str(p)!=name:raise ValueError('source path')
 data=subprocess.check_output(['git','show',HEAD+':research/continuity-openssl-peer/'+name])
 if sha(data)!=expected or (PEER/name).read_bytes()!=data:raise ValueError('committed source differs: '+name)
 return data
def normalized(sources):
 if sources!=EXPECTED:raise ValueError('different committed source inventory')
 for name,expected in sources.items():source_bytes(name,expected)
 return sources
def continuity(sources):
 normalized(sources)
 return {'head':HEAD,'executed_source_files':sources,'current_source_files':sources,'test_harness_only_changes':{},'runtime_sources_identical':True,'executed_helper_root':'Frozen Git source at the exact tested head'}
