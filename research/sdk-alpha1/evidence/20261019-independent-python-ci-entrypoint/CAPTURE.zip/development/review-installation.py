"""Bind the new CLI's installed files, actual process and public registration."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent
built = root / "target/independent-installed-01/source-checkout/target/independent-python-installed-01"
head = "4cf7a202789843df7980ff7c3a9675f13749e62f"
sys.path.insert(0, str(root / "artifact"))
import continuity_independent_python as package
import continuity_independent_python_run as consumer

def read(path):
    return json.loads(path.read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

report = read(built / "PYTHON_INSTALLATION.json")
assert report["source_commit"] == head and report["completed"] and report["sources_unchanged"]
assert not report["release_claim_eligible"] and "failure" not in report
for name, digest in report["source_inputs"].items():
    data = subprocess.check_output(["git", "show", head + ":" + name])
    assert sha(data) == digest == sha((root / name).read_bytes())
wheel = built / consumer.WHEEL
assert sha(wheel.read_bytes()) == report["wheel_sha256"]
source = root / "research/continuity-openssl-peer"
modules = {p.name: p.read_bytes() for p in (source / package.PACKAGE).glob("*.py")}
files = package.inspect_wheel(wheel.read_bytes(), modules,
    {n: (source / n).read_bytes() for n in ("LICENSE-APACHE", "LICENSE-MIT")}, (source / "README.md").read_bytes())
outside = Path(read(built / "LOCATION.json")["path"])
application = outside / "research/continuity-openssl-peer"
all_files = consumer.installed_files(application)
installed = read(built / "INSTALLED_FILES.json")
assert len(installed) == 55
selected = {name: all_files[name] for name in installed}
assert all(sha(body) == installed[name] for name, body in selected.items())
package.verify_installation(selected, files, wheel_url=wheel.as_uri(), digest=report["wheel_sha256"])
harness = {p.relative_to(source).as_posix(): p.read_bytes() for p in consumer.runtime_files()
           if not p.is_relative_to(source / package.PACKAGE)}
assert all_files == selected | harness
probe = read(built / "PROVENANCE.json")
assert probe["modules"] == report["modules"] == {name: sha(body) for name, body in modules.items()}
assert Path(probe["package_root"]) == application / package.PACKAGE
assert all(probe[name] == 1 for name in ("isolated", "no_site", "dont_write_bytecode"))
clone = root / "target/independent-installed-01/source-checkout"
assert all(not Path(name).resolve().is_relative_to(clone) for name in probe["sys_path"])
assert not list(Path(probe["pycache_prefix"]).iterdir())
for label in ("install", "probe", "registration"):
    receipt = read(built / (label + ".json"))
    assert receipt["exit"] == 0 and Path(receipt["cwd"]) == outside
    assert not (built / (label + ".stderr")).read_bytes()
    if label != "install":
        assert {"-I", "-S", "-B", "-X"} <= set(receipt["argv"])
native_args = read(built / "registration.json")["argv"]
native = Path(native_args[native_args.index("--native") + 1])
assert sha(native.read_bytes()) == report["native_sha256"]
public = read(out / "REGISTRATION_READBACK.json")
assert public["head"] == head and public["native_sha256"] == report["native_sha256"]
for label in ("local", "witness"):
    assert public["profiles"][label]["workers"] == report["registration"][label]["workers"]
    assert public["profiles"][label]["actual_SIGKILL"] == report["registration"][label]["process_kills"]
result = {"head": head, "wheel_sha256": report["wheel_sha256"], "native_sha256": report["native_sha256"],
          "source_files": report["source_inputs"], "module_files": len(modules), "installed_files": len(installed),
          "registration": public["profiles"], "elapsed_seconds": read(out / "RUN_EXIT.json")["elapsed_seconds"],
          "scope": "Actual new CLI from ordinary checkout; standard pip installed this exact source-bound wheel. All47 modules loaded outside checkout and installed files remained unchanged after92worker21kill registration. Public signatures/original-operation records replayed; private-state/lifetime assertions remain runtime observations. No deployed account authentication, cross-host carrier, physical erasure, PCS or release admission."}
(out / "INSTALLATION_READBACK.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ("head", "wheel_sha256", "module_files", "installed_files", "elapsed_seconds")}))
