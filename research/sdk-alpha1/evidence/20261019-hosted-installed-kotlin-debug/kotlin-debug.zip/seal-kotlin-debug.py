"""Seal selected terminal contracts and exact consumer packages, retaining scope."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;readback=json.loads((out/'KOTLIN_DEBUG_READBACK.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
folder=root/'research/sdk-alpha1/evidence/20261019-hosted-installed-kotlin-debug';folder.mkdir()
records={}
for label,row in readback['profiles'].items():
 source=out/label;artifact=json.loads((source/'ARTIFACT.json').read_text());raw=source/'terminal.zip'
 assert 'sha256:'+sha(raw.read_bytes())==artifact['digest']
 entries={}
 for name in ['ARTIFACT.json','JOB.json','CONTINUITY_PACKAGE.json','sources-before.json','sources-after.json','SOURCE_READBACK.json']:
  entries[name]=(source/name).read_bytes()
 with zipfile.ZipFile(raw)as z:
  entries[row['archive']]=z.read(row['archive']);assert sha(entries[row['archive']])==row['archive_sha256']
  inventory={i.filename:{'bytes':i.file_size,'crc32':i.CRC}for i in z.infolist()}
  entries['TERMINAL_INVENTORY.json']=(json.dumps(inventory,indent=2)+'\n').encode()
  # Retain the original trace bytes consumed by the selected contract readers.
  language=label.split('-')[0]
  for name in z.namelist():
   if '/'not in name and name.startswith(language+'-')and name.endswith(('.stdout','.stderr','.json')):
    entries['traces/'+name]=z.read(name)
 for p in sorted((source/'foreign-public-readback').rglob('*')):
  if p.is_file():
   assert not p.is_symlink();entries['public/'+p.relative_to(source/'foreign-public-readback').as_posix()]=p.read_bytes()
 for name,expected in readback['reader_sources'].items():
  body=(out/'frozen-2328'/name).read_bytes();assert sha(body)==expected;entries['source/'+name]=body
 for name in ['review-kotlin-debug.py','review-kotlin-debug.stdout','review-kotlin-debug.stderr','verify-sources.py','seal-kotlin-debug.py']:
  entries[name]=(out/name).read_bytes()
 assert not entries['review-kotlin-debug.stderr']
 entries['READBACK.json']=(json.dumps({'head':readback['head'],'profile':row,'scope':readback['scope'],'reader_sources':readback['reader_sources']},indent=2)+'\n').encode()
 manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
 archive=folder/(label+'.zip')
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,body in sorted(entries.items()):
   item=zipfile.ZipInfo(name,(2026,10,19,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,body)
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
  for n,item in manifest.items():assert sha(z.read(n))==item['sha256']and len(z.read(n))==item['bytes']
 records[label]={'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes()),'artifact':artifact['id'],'artifact_bytes':artifact['size_in_bytes'],'artifact_digest':artifact['digest'],'contracts':len(row['contracts']),'package_files':row['package_files']}
 print(label,records[label],flush=True)
checks={'head':readback['head'],'run':39129232908,'captures':records,'scope':readback['scope'],'public_reader_sources':len(readback['reader_sources']),'source_files_verified_against_Git_per_partition':1132,'original_artifacts':'Full terminal ZIPs remain locally retained with GitHub IDs/digests. These captures contain selected public records, actual consumer packages, original readers and relevant trace outputs; not complete terminal ZIPs or all producer checks.'}
(folder/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
