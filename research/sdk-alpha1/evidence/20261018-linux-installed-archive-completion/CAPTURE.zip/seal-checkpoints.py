from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
destination = root / 'research/sdk-alpha1/evidence'
def sha(data):
    return hashlib.sha256(data).hexdigest()

def seal(name, entries, report):
    folder = destination / name
    folder.mkdir(exist_ok=False)
    manifest = {n: {'bytes': len(d), 'sha256': sha(d)} for n, d in sorted(entries.items())}
    entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = folder / 'CAPTURE.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, d in sorted(entries.items()):
            i = zipfile.ZipInfo(n, (2026, 10, 18, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, d)
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(entries)
        assert z.testzip() is None
        for n, item in manifest.items():
            d = z.read(n)
            assert len(d) == item['bytes'] and sha(d) == item['sha256']
    report['capture'] = {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())}
    (folder / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, report['capture'])

out = root / 'target/independent-durable-rekey-hosted-0466-01'
report = json.loads((out / 'READBACK.json').read_text())
assert not (out / 'review.stderr').read_bytes() and not (out / 'download.stderr').read_bytes()
entries = {n: (out / n).read_bytes() for n in ['READBACK.json', 'JOB.json', 'ARTIFACT.json', 'linux-0466.zip',
    'review.py', 'review.stdout', 'review.stderr', 'review-first.py', 'review-first.stderr',
    'check-download.py', 'download.stdout', 'download.stderr']}
for n, expected in report['source_files'].items():
    data = (root / 'research/continuity-openssl-peer' / n).read_bytes()
    assert sha(data) == expected
    entries['source/' + n] = data
report['macOS_hosted'] = 'Still queued when this Linux checkpoint was sealed; local ARM64 qualification is separate.'
report['reader_correction'] = 'First adapted reader confused a bootstrap-final case name with the renamed exchange lane; exact original case name restored, all checks retained.'
seal('20261018-hosted-independent-durable-rekey', entries, report)

out = root / 'target/unix-installed-2328-01'
report = json.loads((out / 'READBACK.json').read_text())
assert not (out / 'review.stderr').read_bytes()
entries = {n: (out / n).read_bytes() for n in ['READBACK.json', 'PUBLIC_REPLAYS.json', 'JOB.json', 'review.py',
    'review.stdout', 'review.stderr', 'review-first.py', 'review-first.stderr', 'review-second.py', 'review-second.stderr', 'seal-checkpoints.py']}
names = ['CONTINUITY_PACKAGE.json', 'C_CONSUMER.json', 'sources-before.json', 'sources-after.json',
    'consumer-Cargo.lock', 'consumer-metadata.stdout', report['candidate_archive']['file']]
for profile in ['debug', 'release']:
    for label in ['consumer', 'c-input-compile', 'c-input-contract']:
        for suffix in ['json', 'stdout', 'stderr']:
            names.append(label + '-' + profile + '.' + suffix)
for n in names:
    entries['public/' + n] = (out / 'public' / n).read_bytes()
report['full_artifact'] = 'Exact 92,282,597-byte ZIP remains at target/unix-installed-2328-01/installed.zip and GitHub artifact 12139878770. Complete original public replay needs that artifact.'
report['reader_corrections'] = ['Canonicalize the selected Linux /tmp consumer root on macOS before the original path verifier.',
    'Verify four additional locally loaded reader modules directly against pinned Git; they are outside the producer source inventory.']
seal('20261018-linux-installed-archive-completion', entries, report)
