"""Read terminal Linux installed results without executing any uploaded binaries."""
from pathlib import Path, PurePosixPath
import hashlib
import importlib
import json
import re
import stat
import subprocess
import sys
import zipfile

root = Path.cwd()
out = root / 'target/unix-installed-2328-01'
sys.path.insert(0, str(root / 'artifact'))
from evidence_io import parse_strict_json_bytes as parse
import continuity_package as package
import continuity_enrollment as enrollment
import continuity_roster_renewal as roster
import continuity_device_replacement as replacement
import continuity_device_retirement as retirement

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(value, message):
    if not value:
        raise ValueError(message)

head = '23280124efd2f0f3003d4ce85e3db665f6ec8a25'
api = lambda path: subprocess.check_output(['gh', 'api', 'repos/billlza/q-periapt/' + path], timeout=60)
job = parse(api('actions/jobs/117682462608'), label='job')
check(job['run_id'] == 39129232908 and job['head_sha'] == head and
      job['status'] == 'completed' and job['conclusion'] == 'success', 'terminal source/job')
(out / 'JOB.json').write_text(json.dumps(job, indent=2) + '\n')
raw = (out / 'installed.zip').read_bytes()
check(len(raw) == 92282597 and sha(raw) == 'd4b0f8d780ec02d4fd05843821d87bcc84e673cff7911456300b2686ba76c960', 'artifact identity')
folder = out / 'public'
folder.mkdir(exist_ok=False)
with zipfile.ZipFile(out / 'installed.zip') as z:
    items = z.infolist()
    check(len(items) == 35089 and len({i.filename for i in items}) == len(items), 'archive inventory')
    check(sum(i.file_size for i in items) < 128 * 1024**2, 'artifact size bound')
    for item in items:
        name = PurePosixPath(item.filename)
        check(not name.is_absolute() and '..' not in name.parts and str(name) == item.filename
              and '\\' not in item.filename and not item.flag_bits & 1
              and not stat.S_ISLNK(item.external_attr >> 16), 'unsafe artifact entry')
        target = folder.joinpath(*name.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(z.read(item))

def load(name):
    return parse((folder / name).read_bytes(), label=name)

report = load('CONTINUITY_PACKAGE.json')
check(report['source_commit'] == head and report['completed'] and report['partition_completed']
      and report['sources_unchanged'] and 'failure' not in report, 'complete package receipt')
check(report['host_os'] == 'Linux' and report['host_arch'] == 'x86_64'
      and report['build_profiles'] == ['debug', 'release'] and report['c_consumer'] == load('C_CONSUMER.json'), 'profiles')
before = load('sources-before.json')
check(before == load('sources-after.json') == report['source_inputs'], 'source identity changed')
check(len(before['files']) == 1132, 'source count')
requests = ''.join(head + ':' + name + '\n' for name in before['files'])
data = subprocess.check_output(['git', 'cat-file', '--batch'], input=requests.encode())
offset = 0
for name, expected in before['files'].items():
    end = data.index(b'\n', offset)
    header = data[offset:end].split()
    check(len(header) == 3 and header[1] == b'blob', 'missing committed source ' + name)
    count = int(header[2]); start = end + 1
    check(sha(data[start:start + count]) == expected, 'source mismatch ' + name)
    offset = start + count + 1
check(offset == len(data), 'source stream trailing bytes')
package.verify_candidate_archive(folder, report['archive'])
candidate_files = package.validate_candidate((folder / report['archive']['file']).read_bytes(), set(report['archive']['files']))
for name, expected in before['files'].items():
    prefix = 'research/continuity-identity-candidate/'
    if name.startswith(prefix) and name[len(prefix):] in candidate_files:
        # Cargo manifest rewriting is checked by the package validator, not byte identity.
        if name.endswith('/Cargo.toml'):
            continue
        check(sha(candidate_files[name[len(prefix):]]) == expected, 'packaged candidate differs ' + name)
metadata = load('consumer-metadata.stdout')
consumer_path = Path(next(p['manifest_path'] for p in metadata['packages'] if p['name'] == package.CONSUMER)).parent
resolved = package.verify_resolution(metadata, consumer_path, (folder / 'consumer-Cargo.lock').read_bytes(),
    subprocess.check_output(['git', 'show', head + ':research/continuity-identity-candidate/Cargo.lock']))
check(resolved == report['resolution'], 'resolved installed dependency graph')

verified = {}
for profile in ['debug', 'release']:
    current = report['execution'][profile]
    check(load('consumer-' + profile + '.json')['returncode'] == 0, 'native execution')
    stdout = (folder / ('consumer-' + profile + '.stdout')).read_bytes()
    check(b'test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in stdout, 'native selected tests')
    rows = {
        'enrollment': enrollment.verify(folder / (profile + '-enrollment-public')),
        'reopened_enrollment': enrollment.verify_reopen(folder / (profile + '-enrollment-reopen-public'),
            current['session_reopen']['test_protocol_time'], current['session_reopen']['session'], public_only=True),
        'roster_renewal': roster.verify(folder / (profile + '-roster-renewal-public')),
        'device_replacement': replacement.verify(folder / (profile + '-device-replacement-public')),
        'device_retirement': retirement.verify(folder / (profile + '-device-retirement-public')),
    }
    for name, result in rows.items():
        expected = current['session_reopen']['enrollment'] if name == 'reopened_enrollment' else current[name]
        check(result == expected, 'Rust public lifecycle replay ' + profile + '/' + name)
    for label in ['c-input-compile', 'c-input-contract']:
        check(load(label + '-' + profile + '.json')['returncode'] == 0, 'C11 input command')
    check({'-std=c11', '-Werror', '-Wpedantic'} <= set(load('c-input-compile-' + profile + '.json')['argv']), 'strict C11')
    check((folder / ('c-input-contract-' + profile + '.stdout')).read_bytes() ==
          b'CONSUMER_INPUT_PASS c11=true seek_set_cur_end=true exact_position=true original_bytes=true\n', 'C11 actual bytes')
    contracts = [
        ('account_owner', 'continuity_c_account', 'verify_execution', 'c-account-trace', 'c-account-public'),
        ('account_delivery', 'continuity_c_account_delivery', 'verify_execution', 'c-account-delivery-trace', 'c-account-delivery-public'),
        ('own_account_delivery', 'continuity_c_account_delivery', 'verify_own_execution', 'c-own-account-delivery-trace', 'c-own-account-delivery-public'),
        ('account_tls', 'continuity_c_account_tls', 'verify_execution', 'c-account-tls-trace', 'c-account-tls-public'),
        ('account_tls_loss', 'continuity_c_account_tls_loss', 'verify_execution', 'c-account-tls-loss-trace', 'c-account-tls-loss-public'),
        ('own_account_tls_loss', 'continuity_c_account_tls_loss', 'verify_own_execution', 'c-own-account-tls-loss-trace', 'c-own-account-tls-loss-public'),
        ('account_witness', 'continuity_c_account_witness', 'verify_execution', 'c-account-witness-trace', 'c-account-witness-public'),
    ]
    for name, module, function, label, directory in contracts:
        check(load(label + '-' + profile + '.json')['returncode'] == 0, 'C contract command')
        result = getattr(importlib.import_module(module), function)((folder / (label + '-' + profile + '.stdout')).read_bytes(), folder / directory / profile)
        expected = report['c_consumer']['execution'][profile][name]
        if 'execution' in expected:
            expected = expected['execution']
        check(all(k in expected and expected[k] == v for k, v in result.items()), 'C contract replay ' + profile + '/' + name)
        rows[name] = result
    verified[profile] = rows

# The original readback modules must themselves be the committed source.
for module in tuple(sys.modules.values()):
    filename = getattr(module, '__file__', None)
    if not filename:
        continue
    path = Path(filename)
    if path.parent == root / 'artifact' and path.suffix == '.py':
        name = str(path.relative_to(root))
        check(name in before['files'] and sha(path.read_bytes()) == before['files'][name], 'reader source mismatch ' + name)

(out / 'PUBLIC_REPLAYS.json').write_text(json.dumps(verified, indent=2) + '\n')
result = {'head': head, 'run': 39129232908, 'job': job['id'], 'job_conclusion': job['conclusion'],
    'artifact_id': 12139878770, 'artifact_bytes': len(raw), 'artifact_sha256': sha(raw),
    'artifact_members': len(items), 'source_files_verified_against_Git': 1132,
    'source_before_after_equal': True, 'installed_dependency_graph_replayed': True,
    'candidate_archive': {k: report['archive'][k] for k in ['file', 'bytes', 'sha256']},
    'original_final_archive_guard_passed': True, 'C11_profiles_replayed': 2,
    'Rust_public_lifecycle_replays': 10, 'C_account_public_contract_replays': 14,
    'scope': 'Complete terminal installed job; local original-reader replay of source/dependency/archive identity, strict C11 and selected public lifecycle contracts. Other C runtime checks retain producer observations; not a local replay of every C contract. Same engine and host; no complete workflow, hardware power-loss, independent protocol or release claim.'}
(out / 'READBACK.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
