import json,pathlib
p=pathlib.Path('target/continuity-browser-journal')
for name in ['io-result.stdout','cut-result.stdout']:
 text=(p/name).read_text();r=json.loads(text.split('### Result\n',1)[1].split('\n### ',1)[0]);print(json.dumps({'file':name,'status':r['status'],'error':r.get('error'),'cases':len(r['rows']),'observations':[{'case':x['case'],'index':x.get('index'),'after':x.get('after'),'pending':x.get('before',{}).get('pending'),'revision':x.get('reopened',{}).get('state',{}).get('revision'),'negatives':len(x.get('negatives',[]))} for x in r['rows']]},indent=2))
