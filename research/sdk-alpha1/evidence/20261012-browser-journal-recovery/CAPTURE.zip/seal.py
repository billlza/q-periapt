import hashlib,json,pathlib,platform,subprocess,zipfile
root=pathlib.Path.cwd();stage=root/'target/continuity-browser-journal';source=stage/'source';out=root/'research/sdk-alpha1/evidence/20261012-browser-journal-recovery'
sha=lambda b:hashlib.sha256(b).hexdigest()
def result(name):return json.loads((stage/name).read_text().split('### Result\n',1)[1].split('\n### ',1)[0])
io=result('io-result.stdout');cut=result('cut-result2.stdout');failed=result('cut-result.stdout')
assert io['status']==cut['status']=='passed' and io['version']==cut['version']=='154.0.8037.99' and not io['pageErrors'] and not cut['pageErrors']
assert failed['status']=='failed' and 'wrong opener not refused' in failed['error'] and 'Conflict' in failed['error']
assert len(io['rows'])==9 and len(cut['rows'])==8
normal=io['rows'][0];assert normal['committed']['counts']['sync']==4 and normal['retry']['counts']['sync']==0 and normal['committed']['state']==normal['retry']['state']==normal['reopened']['state']
for name in ['fork','stale']:assert normal[name]['error']=='Error: Protocol(Checkpoint)' and not normal[name]['ok'] and normal[name]['counts']['sync']==0
for name,rows in [('io',io['rows'][1:]),('cut',cut['rows'])]:
 assert {(r['index'],r['after']) for r in rows}=={(i,a) for i in range(1,5) for a in [False,True]}
 for r in rows:
  before=r['before'];state=r['reopened']['state'];assert state['journal']==r['initial']['state']['journal']
  assert before['pending']==(r['index'] in [2,3])
  assert state['revision']==state['rosterVersion']==(1 if r['index']==1 else 2)
  if before['pending']:assert state['imageDigest']==before['targetDigest']
  else:assert state['imageDigest']==before['imageDigest']
  assert r['retry']['state']['revision']==r['retry']['state']['rosterVersion']==2
  if state['revision']==2:assert r['retry']['state']==state and r['retry']['counts']['sync']==0
  assert not r['final']['pending'] and r['final']['imageDigest']==r['retry']['state']['imageDigest']
  if name=='io':assert not r['interruption']['failure']['ok'] and 'CommitUncertain' in r['interruption']['failure']['error'] and 'injected I/O boundary' in r['interruption']['failure']['error'] and 'closed' in r['interruption']['closed']['error']
  else:assert r['interruption']['outcome']=={'ok':False,'error':'terminated'} and r['interruption']['leaseReleaseMs']<12000
special=next(r for r in cut['rows'] if r['index']==2 and r['after']);assert len(special['negatives'])==3
for n in special['negatives']:
 assert not n['rejected']['ok'] and n['retained']==special['before']
 assert n['rejected']['error']==('Error: Authentication' if n['negative']==1 else 'Error: Conflict')
for label,filename in [('pending','pending-original.redb'),('recovered','browser-recovered.redb')]:
 raw=(stage/'web2/captures'/filename).read_bytes();assert len(raw)==special['captures'][label]['bytes'] and sha(raw)==special['captures'][label]['sha256']
native=json.loads((stage/'native-readback.stdout').read_text());assert native==special['reopened']['state']
assert (stage/'native-bytecompare2.stdout').read_text().strip()=='original-pending-target-equals-browser-and-native-image-byte-for-byte: 6098 bytes'
for name in ['native-admission','native-recovery']:assert 'test result: ok. 1 passed; 0 failed;' in (stage/(name+'.stdout')).read_text()
for name in ['native-create3.stderr','wasm-build.stderr','native-admission.stderr','native-recovery.stderr','native-clippy.stderr','wasm-clippy.stderr','native-readback.stderr','native-bytecompare2.stderr']:
 text=(stage/name).read_text();assert 'Finished ' in text and 'warning:' not in text and '\nerror' not in text,name
for name in ['first-cleanup.stdout','final-cleanup.stdout']:assert result(name)=={'held':[],'pending':[]}
for name in ['first-close.stdout','final-close.stdout']:assert 'closed' in (stage/name).read_text().lower()
for pid in ['97281','97490']:
 p=subprocess.run(['ps','-p',pid,'-o','command='],capture_output=True,text=True);assert p.returncode==1 and not p.stdout.strip()
changed=set(subprocess.check_output(['git','-C',str(source),'diff','--name-only'],text=True).splitlines());assert changed=={'research/continuity-identity-candidate/'+s for s in ['Cargo.toml','Cargo.lock','src/lib.rs','src/durable.rs']}
durable='research/continuity-identity-candidate/src/durable.rs';footer='\n// Isolated qualification build only; absent from the production source.\npub(crate) mod browser_probe;\n';assert (source/durable).read_text()==(root/durable).read_text()+footer
for name in ['opfs.js','q_periapt_continuity_identity_candidate.js','q_periapt_continuity_identity_candidate_bg.wasm']:assert (stage/'web/pkg'/name).read_bytes()==(stage/'web2/pkg'/name).read_bytes()
old_suite=(stage/'web/acceptance.mjs').read_text();new_suite=(stage/'web2/acceptance.mjs').read_text();assert old_suite.replace('negative===2?','negative!==1?')==new_suite
files={}
for directory in ['fixture','web','web2','native']:
 for p in sorted((stage/directory).rglob('*')):
  if p.is_file():files[str(p.relative_to(stage))]=p.read_bytes()
for p in sorted(stage.iterdir()):
 if p.is_file():files[p.name]=p.read_bytes()
for name in changed:files['probe-source/'+name]=(source/name).read_bytes()
for prefix in ['src/durable/browser_probe','src/bin']:
 for p in (source/'research/continuity-identity-candidate'/prefix).rglob('*.rs'):files['probe-source/'+str(p.relative_to(source))]=p.read_bytes()
p=source/'research/continuity-identity-candidate/src/durable/browser_probe.rs';files['probe-source/'+str(p.relative_to(source))]=p.read_bytes()
files['main-source/durable.rs']=(root/durable).read_bytes();files['probe-source/changes.patch']=subprocess.check_output(['git','-C',str(source),'diff','--binary'])
assert len(files)<130,len(files)
out.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,body in sorted(files.items()):z.writestr(name,body)
with zipfile.ZipFile(out/'CAPTURE.zip') as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name,body in files.items():assert z.read(name)==body
checks={'schema':'qpc-browser-journal-recovery/1','status':'local-journal-integration-passed','baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'host':platform.platform(),'architecture':platform.machine(),'capture':{'path':'CAPTURE.zip','sha256':sha((out/'CAPTURE.zip').read_bytes()),'members':len(files)},'files':{n:sha(b) for n,b in sorted(files.items())},'nativeFixtureBinarySha256':sha((root/'target/continuity-browser-engine/rust-target/debug/browser_journal_fixture').read_bytes()),'nativeComparatorBinarySha256':sha((root/'target/continuity-browser-engine/rust-target/debug/compare_browser_journal').read_bytes()),'ioFaults':8,'workerCuts':8,'negativeOpeners':3,'nativeRegressionTests':2,'nativeRecoveryFaultCuts':40,'originalTargetByteEquality':6098,'cleanup':{'locksEmpty':True,'browserClosed':True,'serverPidsAbsent':[97281,97490],'serverExitCodes':[143,143]},'syntheticFixtureKey':'Public constant byte 71 repeated 32 times; fixture only, not a product provisioning method','browserContinuityAdmitted':False}
for name,value in [('CHECKS.json',checks),('RESULT.json',{'io':io,'cut':cut,'native':native})]:
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({k:checks[k] for k in ['status','capture','ioFaults','workerCuts','negativeOpeners','originalTargetByteEquality','cleanup']},indent=2))
