from pathlib import Path
root=Path.cwd();stage=root/'target/continuity-browser-journal';source=stage/'source';crate=source/'research/continuity-identity-candidate';p=crate/'Cargo.toml';s=p.read_text();s=s.replace('[dependencies]','[lib]\ncrate-type = ["cdylib", "rlib"]\n\n[dependencies]\nserde_json = "=1.0.151"');s=s.replace('web-time = "=1.1.0"','web-time = "=1.1.0"\nwasm-bindgen = "=0.2.129"\njs-sys = "=0.3.106"');p.write_text(s)
p=crate/'src/durable.rs';p.write_text(p.read_text()+'\n// Isolated qualification build only; absent from the production source.\npub(crate) mod browser_probe;\n')
p=crate/'src/lib.rs';p.write_text(p.read_text()+'''\n#[cfg(not(target_arch = "wasm32"))]
pub use durable::browser_probe::{prepare_probe, verify_probe};
#[cfg(target_arch = "wasm32")]
pub use durable::browser_probe::JournalProbe;
''')
probe=crate/'src/durable/browser_probe';probe.mkdir()
old=(root/'target/continuity-browser-opfs/probe/src/lib.rs').read_text();backend=old[old.index('const MAX:'):old.index('fn error(')];backend=backend.replace('const TABLE: TableDefinition<&str, &[u8]> = TableDefinition::new("opfs-storage-probe/1");\n','')
backend=backend.replace('fn file_size','fn file_size')
text='''// Isolated qualification backend. Only public test fixtures enter this build.
use js_sys::Uint8Array;
use redb::{Database, StorageBackend};
use std::{io, ops::Bound, sync::{Arc, Mutex}};
use wasm_bindgen::prelude::*;
#[path = "../../../../../crates/q-periapt-host-store/src/database_format.rs"]
mod database_format;
'''+backend+'''
pub(super) type Cleanup = Arc<Mutex<Option<String>>>;
pub(super) fn open(slot:u32)->Result<(Database,Cleanup),String>{
 let cleanup=Arc::new(Mutex::new(None));let backend=Backend{slot,cleanup:cleanup.clone()};
 let len=backend.len().map_err(|e|e.to_string())?;
 if len<16{return Err("explicit open requires existing nonempty file".into())}
 database_format::refuse_unclean_foreign_redb(&backend).map_err(|e|e.to_string())?;
 let mut builder=Database::builder();builder.set_cache_size(2*1024*1024);
 let db=builder.create_with_backend(backend).map_err(|e|e.to_string())?;Ok((db,cleanup))
}
pub(super) fn closed(cleanup:&Cleanup)->Result<(),String>{
 if let Some(error)=cleanup.lock().map_err(|_|"cleanup lock")?.take(){return Err(error)}Ok(())
}
''';(probe/'opfs.rs').write_text(text)
(stage/'fixture').mkdir(mode=0o700)
(stage/'web').mkdir()
