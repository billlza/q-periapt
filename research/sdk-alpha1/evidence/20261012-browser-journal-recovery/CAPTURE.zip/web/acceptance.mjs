export async function run(mode){
 if(!['io','cut'].includes(mode))throw new Error('mode');
 const rows=[],workers=[],prefix='journal-'+mode+'-'+Date.now();
 const expect=(ok,why)=>{if(!ok)throw new Error(why)};
 const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const worker=()=>{const w=probe.create();workers.push(w);return w};
 const call=(w,command,extra={})=>probe.call(w,{command,...extra});
 const ok=async(w,command,extra={})=>{const r=await call(w,command,extra);expect(r.ok,command+': '+JSON.stringify(r));return r.result};
 const released=async name=>{const at=performance.now();for(;;){const locks=await navigator.locks.query();if(![...locks.held,...locks.pending].some(x=>x.name==='qpc-opfs-probe/'+name))return performance.now()-at;expect(performance.now()-at<12000,'lease deadline');await new Promise(r=>setTimeout(r,25))}};
 const open=async(w,name)=>{const at=performance.now();for(;;){const r=await call(w,'open',{name});if(r.ok)return r.result;expect(/NoModificationAllowedError|Busy/.test(r.error),'reopen: '+JSON.stringify(r));expect(performance.now()-at<12000,'file lease deadline');await new Promise(r=>setTimeout(r,25))}};
 try{
  if(mode==='io'){
   const w=worker(),name=prefix+'-normal';await ok(w,'seed',{name});const initial=await open(w,name);expect(initial.state.revision===1&&initial.state.rosterVersion===1,'native genesis');
   const committed=await ok(w,'install');expect(committed.state.revision===2&&committed.state.rosterVersion===2&&committed.counts.sync===4,'intent/state two-phase barriers');
   const retry=await ok(w,'install');expect(equal(retry.state,committed.state)&&retry.counts.sync===0,'same-head retry rewrote image');
   const fork=await call(w,'install',{roster:'fork'});expect(!fork.ok&&/Protocol\(Checkpoint\)/.test(fork.error)&&fork.counts.sync===0,'fork admitted or wrong refusal');
   const stale=await call(w,'install',{roster:'one'});expect(!stale.ok&&/Protocol\(Checkpoint\)/.test(stale.error)&&stale.counts.sync===0,'stale admitted or wrong refusal');
   expect(equal(await ok(w,'state'),committed.state),'refusal changed state');await ok(w,'close');
   const reopened=await open(w,name);expect(equal(reopened.state,committed.state),'normal reopen differs');await ok(w,'close');
   rows.push({case:'normal-and-exact-retry',initial,committed,retry,fork,stale,reopened});
  }
  for(const index of [1,2,3,4])for(const after of [false,true]){
   const w=worker(),name=prefix+'-'+index+'-'+after;await ok(w,'seed',{name});const initial=await open(w,name);let interruption;
   const request={kind:'sync',index,after,action:mode==='io'?'throw':'cut'};
   if(mode==='io'){
    const failure=await call(w,'install',request);expect(!failure.ok&&/CommitUncertain/.test(failure.error)&&/injected I\/O boundary/.test(failure.error),'not original injected commit failure: '+JSON.stringify(failure));
    const closed=await call(w,'state');expect(!closed.ok&&/closed/.test(closed.error),'failed journal stayed usable');await ok(w,'close');interruption={failure,closed};
   }else{
    let settled=false;const pending=call(w,'install',request).then(r=>{settled=true;return r});const at=performance.now();let event;
    for(;;){event=probe.events(w).find(e=>e.event==='cut');if(event)break;expect(!settled,'operation returned before cut');expect(performance.now()-at<10000,'cut not reached');await new Promise(r=>setTimeout(r,10))}
    expect(!settled,'operation returned at cut');probe.terminate(w);const outcome=await pending;expect(outcome.error==='terminated','not terminated');interruption={event,outcome,leaseReleaseMs:await released(name)};
   }
   const recovery=worker();const before=await ok(recovery,'inspect',{name});let negatives=[],captures;
   if(mode==='cut'&&index===2&&after){
    expect(before.pending&&before.revision===1&&before.targetDigest,'intent boundary did not retain original target');
    captures={pending:await ok(recovery,'snapshot',{name,capture:'pending-original'})};
    for(const negative of [1,2,3]){
     const rejected=await call(recovery,'open',{name,negative});expect(!rejected.ok&&(negative===2?/Conflict/.test(rejected.error):/Authentication/.test(rejected.error)),'wrong opener not refused: '+JSON.stringify(rejected));
     const retained=await ok(recovery,'inspect',{name});expect(equal(retained,before),'rejected opener applied/replaced original intent');negatives.push({negative,rejected,retained});
    }
   }
   const reopened=await open(recovery,name);const s=reopened.state;
   expect(equal(s.journal,initial.state.journal),'journal identity changed');
   if(before.pending){expect(s.revision===2&&s.rosterVersion===2&&equal(s.imageDigest,before.targetDigest),'recovery replaced original encrypted target')}
   else{expect(s.revision===before.revision&&equal(s.imageDigest,before.imageDigest),'reopen changed committed image');expect(s.rosterVersion===s.revision&&[1,2].includes(s.revision),'wrong committed pair')}
   const retry=await ok(recovery,'install');expect(retry.state.revision===2&&retry.state.rosterVersion===2,'original roster retry failed');
   if(s.rosterVersion===2)expect(equal(retry.state,s)&&retry.counts.sync===0,'committed retry rewrote target');
   await ok(recovery,'close');const final=await ok(recovery,'inspect',{name});expect(!final.pending&&equal(final.imageDigest,retry.state.imageDigest),'final intent not drained exactly');
   if(captures)captures.recovered=await ok(recovery,'snapshot',{name,capture:'browser-recovered'});
   rows.push({case:mode==='io'?'io-failure':'worker-termination',index,after,initial,interruption,before,negatives,reopened,retry,final,captures});
  }
  return {status:'passed',mode,rows};
 }catch(e){return {status:'failed',mode,error:String(e),rows}}
 finally{for(const w of workers){const errors=probe.events(w).filter(x=>x.event==='error');if(errors.length)rows.push({case:'worker-errors',errors});probe.terminate(w)}}
}
