import init,{JournalProbe} from './pkg/q_periapt_continuity_identity_candidate.js';
import * as io from './pkg/opfs.js';
let owner,slot;
const ready=(async()=>{await init();const r=await fetch('/fixture.json');if(!r.ok)throw new Error('fixture unavailable');return await r.text()})();
self.onmessage=async({data})=>{
 const {id,command}=data;let lastCounts=null;
 try{
  const fixture=await ready;let result;
  if(command==='seed'){
   const r=await fetch('/initial.redb');if(!r.ok)throw new Error('initial unavailable');const bytes=new Uint8Array(await r.arrayBuffer());
   const prepared=await io.acquire(data.name,true);try{if(io.file_write(prepared,0,bytes)!==bytes.length)throw new Error('short import');io.file_sync(prepared)}finally{await io.abortPrepared(prepared)}result={bytes:bytes.length};
  }else if(command==='open'){
   if(owner)throw new Error('already open');slot=undefined;slot=await io.acquire(data.name,false);
   try{owner=JournalProbe.open(slot,fixture,data.negative??0)}catch(e){lastCounts=io.stats(slot);await io.abortPrepared(slot);slot=undefined;throw e}
   result={state:JSON.parse(owner.state()),counts:io.stats(slot)};
  }else if(command==='install'){
   io.fault(slot,data.kind??'none',data.index??0,data.after??false,data.action??'throw');
   result={state:JSON.parse(owner.install(data.roster??'two')),counts:io.stats(slot)};
  }else if(command==='state'){result=JSON.parse(owner.state())}
  else if(command==='close'){
   if(owner){owner.close();owner.free();owner=undefined;result=io.stats(slot);await io.finish(slot);slot=undefined}else result={alreadyClosed:true};
  }else if(command==='inspect'){
   if(owner)throw new Error('already open');const prepared=await io.acquire(data.name,false);
   try{result=JSON.parse(JournalProbe.inspect(prepared,fixture))}finally{await io.abortPrepared(prepared)}
  }else if(command==='snapshot'){
   const bytes=await io.snapshot(data.name);const r=await fetch('/capture/'+data.capture,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:bytes});if(r.status!==201)throw new Error('capture failed '+r.status);
   result={bytes:bytes.length,sha256:[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('')};
  }else throw new Error('unknown command');
  self.postMessage({id,ok:true,result});
 }catch(e){self.postMessage({id,ok:false,error:String(e),counts:slot?io.stats(slot):lastCounts})}
};
