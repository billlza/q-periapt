const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const files=new Map([['/acceptance.mjs','acceptance.mjs'],['/','index.html'],['/worker.mjs','worker.mjs'],['/fixture.json','../fixture/fixture.json'],['/initial.redb','../fixture/initial.redb'],['/pkg/opfs.js','pkg/opfs.js'],['/pkg/q_periapt_continuity_identity_candidate.js','pkg/q_periapt_continuity_identity_candidate.js'],['/pkg/q_periapt_continuity_identity_candidate_bg.wasm','pkg/q_periapt_continuity_identity_candidate_bg.wasm']]);
const captures=path.join(__dirname,'captures');fs.mkdirSync(captures,{mode:0o700});
const server=http.createServer((req,res)=>{const route=new URL(req.url,'http://127.0.0.1').pathname;
 if(req.method==='POST'&&/^\/capture\/[a-z0-9-]{1,96}$/.test(route)){
  let length=0,chunks=[];req.on('data',b=>{length+=b.length;if(length>64*1024*1024){req.destroy();return}chunks.push(b)});req.on('end',()=>{try{fs.writeFileSync(path.join(captures,route.slice(9)+'.redb'),Buffer.concat(chunks),{flag:'wx',mode:0o600});res.writeHead(201);res.end('captured')}catch(e){console.error(e);res.writeHead(500);res.end('capture failed')}});return;
 }
 const file=files.get(route);if(req.method!=='GET'||!file){res.writeHead(404);res.end('not found');return}
 try{res.writeHead(200,{'Content-Type':file.endsWith('.wasm')?'application/wasm':file.endsWith('.html')?'text/html':file.endsWith('.json')?'application/json':file.endsWith('.redb')?'application/octet-stream':'application/javascript','Cache-Control':'no-store'});res.end(fs.readFileSync(path.join(__dirname,file)))}catch(e){console.error(e);res.writeHead(500);res.end('read failed')}
});server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port+'/',pid:process.pid})));
