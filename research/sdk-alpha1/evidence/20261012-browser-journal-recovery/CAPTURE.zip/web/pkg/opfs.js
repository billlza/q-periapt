// Isolated storage feasibility probe; not an SDK/protocol entry.
const slots=new Map(), terminal=new Map();let next=1;
const MAX=64*1024*1024;
const require=(ok,label)=>{if(!ok)throw new Error(label)};
export async function acquire(name,create){
 require(isSecureContext && self instanceof DedicatedWorkerGlobalScope,'dedicated secure Worker required');
 require(/^[a-z0-9-]{1,96}$/.test(name),'probe name');require(slots.size<8 && next<0xffffffff,'slot bound');
 let release,admit,deny;const ready=new Promise((yes,no)=>{admit=yes;deny=no});
 const released=navigator.locks.request('qpc-opfs-probe/'+name,{ifAvailable:true},async lock=>{
  if(!lock)throw new Error('Busy');await new Promise(resolve=>{release=resolve;admit()});
 });released.catch(deny);await ready;
 try {
  const root=await navigator.storage.getDirectory();let file;
  try{file=await root.getFileHandle(name)}catch(e){if(e.name!=='NotFoundError'||!create)throw e}
  if(create && file)throw new Error('Exists');
  file??=await root.getFileHandle(name,{create:true});
  const handle=await file.createSyncAccessHandle();const id=next++;
  slots.set(id,{handle,name,release,released,counts:{read:0,write:0,sync:0,resize:0,close:0},fault:null});return id;
 }catch(e){release();await released;throw e}
}
function entry(id){const e=slots.get(id);require(e,'closed file owner');return e}
function check(offset,length){require(Number.isSafeInteger(offset)&&offset>=0&&Number.isSafeInteger(length)&&length>=0&&offset+length<=MAX,'extent')}
function barrier(e,kind,after){
 const f=e.fault;
 if(f && f.kind===kind && f.index===e.counts[kind] && f.after===after){
  if(f.action==='throw')throw new DOMException('injected I/O boundary','UnknownError');
  self.postMessage({event:'cut',kind,index:f.index,after,name:e.name});
  const deadline=performance.now()+3000;while(performance.now()<deadline){}
  throw new Error('controller did not terminate worker');
 }
}
export function file_size(id){return entry(id).handle.getSize()}
export function file_read(id,offset,out){const e=entry(id);check(offset,out.length);e.counts.read++;barrier(e,'read',false);const n=e.handle.read(out,{at:offset});barrier(e,'read',true);return n}
export function file_write(id,offset,bytes){const e=entry(id);check(offset,bytes.length);e.counts.write++;barrier(e,'write',false);const n=e.handle.write(bytes,{at:offset});barrier(e,'write',true);return n}
export function file_resize(id,size){const e=entry(id);check(size,0);e.counts.resize++;barrier(e,'resize',false);e.handle.truncate(size);barrier(e,'resize',true)}
export function file_sync(id){const e=entry(id);e.counts.sync++;barrier(e,'sync',false);e.handle.flush();barrier(e,'sync',true)}
export function file_close(id){
 const e=entry(id);e.counts.close++;e.handle.close();slots.delete(id);terminal.set(id,{counts:e.counts,released:e.released});e.release();
}
export function stats(id){return structuredClone((slots.get(id)??terminal.get(id)).counts)}
export function fault(id,kind,index,after,action){const e=entry(id);e.counts={read:0,write:0,sync:0,resize:0,close:0};e.fault={kind,index,after,action}}
export async function finish(id){const e=terminal.get(id);if(e){await e.released;terminal.delete(id)}}
export async function abortPrepared(id){if(slots.has(id))file_close(id);await finish(id)}
export async function rawLock(name){const root=await navigator.storage.getDirectory();const file=await root.getFileHandle(name);const h=await file.createSyncAccessHandle();h.close();return true}
export async function snapshot(name){const root=await navigator.storage.getDirectory();const f=await root.getFileHandle(name);const blob=await f.getFile();require(blob.size<=MAX,'snapshot bound');return new Uint8Array(await blob.arrayBuffer())}
