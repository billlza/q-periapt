/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_journalprobe_free: (a: number, b: number) => void;
export const journalprobe_close: (a: number) => [number, number];
export const journalprobe_inspect: (a: number, b: number, c: number) => [number, number, number, number];
export const journalprobe_install: (a: number, b: number, c: number) => [number, number, number, number];
export const journalprobe_open: (a: number, b: number, c: number, d: number) => [number, number, number];
export const journalprobe_state: (a: number) => [number, number, number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
