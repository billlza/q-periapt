/* tslint:disable */
/* eslint-disable */

/**
 * Isolated real-journal browser owner for qualification; not a package entry.
 */
export class JournalProbe {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Close the original journal and surface any backend close error.
     */
    close(): void;
    /**
     * Observe original encrypted image/intent commitments before recovery in this fixture only.
     */
    static inspect(slot: number, fixture: string): string;
    /**
     * Commit an independently pinned exact roster through the original intent/state transactions.
     */
    install(name: string): string;
    /**
     * Open the existing OPFS image after real header admission and original recovery.
     */
    static open(slot: number, fixture: string, negative: number): JournalProbe;
    /**
     * Read authenticated journal metadata without granting traffic authority.
     */
    state(): string;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_journalprobe_free: (a: number, b: number) => void;
    readonly journalprobe_close: (a: number) => [number, number];
    readonly journalprobe_inspect: (a: number, b: number, c: number) => [number, number, number, number];
    readonly journalprobe_install: (a: number, b: number, c: number) => [number, number, number, number];
    readonly journalprobe_open: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly journalprobe_state: (a: number) => [number, number, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
