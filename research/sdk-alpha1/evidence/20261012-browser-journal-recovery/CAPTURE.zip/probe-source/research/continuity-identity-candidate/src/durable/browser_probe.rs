// Isolated qualification module, never present in the released library.
use super::*;
use crate::{AccountPin, RosterCheckpoint};
#[cfg(not(target_arch="wasm32"))]
use crate::{DeviceDescription, RootSigningKey, Validity};
#[cfg(target_arch="wasm32")]
use crate::VerifiedRoster;
use serde_json::{json,Value};
fn bytes(value:&Value,name:&str)->Result<Vec<u8>,String>{serde_json::from_value(value.get(name).ok_or_else(||format!("missing {name}"))?.clone()).map_err(|e|e.to_string())}
fn array(value:&Value,name:&str)->Result<[u8;32],String>{bytes(value,name)?.try_into().map_err(|_|format!("width {name}"))}
fn fixture_key(wrong:bool)->JournalKey{
 let mut bytes=Box::new(ZeroizingBytes::zeroed());
 // Public synthetic fixture key. This is not a product key-provisioning path.
 bytes.as_mut_bytes().fill(if wrong {72}else{71});JournalKey(bytes)
}
struct Config{value:Value}
impl Config{
 fn parse(text:&str)->Result<Self,String>{if text.len()>256*1024{return Err("fixture bound".into())}Ok(Self{value:serde_json::from_str(text).map_err(|e|e.to_string())?})}
 fn account(&self)->Result<[u8;32],String>{array(&self.value,"account")}
 fn identity(&self,wrong:bool)->Result<JournalIdentity,String>{let mut id=array(&self.value,"journal")?;if wrong{*id.first_mut().ok_or("identity")?^=1}JournalIdentity::from_trusted_state(id).map_err(|e|e.to_string())}
 fn pin(&self,roster:&str)->Result<AccountPin,String>{let v=self.value.get(roster).ok_or("roster")?;let checkpoint=RosterCheckpoint::from_trusted_state(v["version"].as_u64().ok_or("version")?,array(v,"digest")?).map_err(|e|e.to_string())?;AccountPin::new(self.account()?,crate::PublicKey::decode(&bytes(&self.value,"root")?).map_err(|e|e.to_string())?,checkpoint,[6;32]).map_err(|e|e.to_string())}
 fn device(&self,wrong:bool)->Result<VerifiedDevice,String>{self.pin("one")?.verify_device(&bytes(&self.value,if wrong{"otherCredential"}else{"credential"})?,&bytes(&self.value["one"],"wire")?,150).map_err(|e|e.to_string())}
 #[cfg(target_arch="wasm32")]
 fn roster(&self,name:&str)->Result<VerifiedRoster,String>{self.pin(name)?.verify_roster(&bytes(&self.value[name],"wire")?,150).map_err(|e|e.to_string())}
}
fn state(journal:&mut DeviceJournal,config:&Config)->Result<String,String>{
 let checkpoint=journal.roster_checkpoint(config.account()?).map_err(|e|e.to_string())?;
 let image=journal.image().map_err(|e|e.to_string())?;
 Ok(json!({"journal":image.id,"revision":image.revision,"imageDigest":image.digest,"rosterVersion":checkpoint.version(),"rosterDigest":checkpoint.digest()}).to_string())
}
/// Prepare fresh public identity fixtures and one actual native encrypted journal.
#[cfg(not(target_arch="wasm32"))]
pub fn prepare_probe(directory:&Path)->Result<(),Box<dyn std::error::Error>>{
 let mut root=RootSigningKey::generate()?;let mut signer=DeviceSigningKey::generate()?;let mut other=DeviceSigningKey::generate()?;
 let validity=Validity::new(100,200)?;
 let certificate=root.issue_device(DeviceDescription::new([5;16],1,[6;32],validity)?,signer.public_key()?)?;
 let other_certificate=root.issue_device(DeviceDescription::new([7;16],1,[6;32],validity)?,other.public_key()?)?;
 let entries=[root.roster_entry(&certificate)?,root.roster_entry(&other_certificate)?];
 let one=root.issue_roster(1,validity,&entries)?;
 let two=root.issue_roster(2,Validity::new(100,210)?,&entries)?;
 let fork=root.issue_roster(2,Validity::new(100,220)?,&entries)?;
 let identity=JournalIdentity::generate()?;
 let record=|r:&crate::IssuedRoster|json!({"wire":r.as_bytes(),"version":r.checkpoint().version(),"digest":r.checkpoint().digest()});
 let fixture=json!({"account":root.account_id()?,"root":root.public_key()?.encode(),"credential":certificate,"otherCredential":other_certificate,"one":record(&one),"two":record(&two),"fork":record(&fork),"journal":identity.as_bytes()}).to_string();
 let config=Config::parse(&fixture)?;let device=config.device(false)?;
 let mut journal=DeviceJournal::provision(&directory.join("initial.redb"),fixture_key(false),&device,identity)?;
 if journal.roster_checkpoint(config.account()?)?!=one.checkpoint(){return Err("genesis checkpoint".into())}
 journal.close();root.close();signer.close();other.close();
 use std::io::Write;use std::os::unix::fs::OpenOptionsExt;
 let mut file=std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(directory.join("fixture.json"))?;file.write_all(fixture.as_bytes())?;file.sync_all()?;
 println!("native-journal-fixture-created");Ok(())
}
/// Reopen a copied browser image through the real native private-file admission.
#[cfg(not(target_arch="wasm32"))]
pub fn verify_probe(path:&Path,fixture:&Path)->Result<String,Box<dyn std::error::Error>>{
 let config=Config::parse(&std::fs::read_to_string(fixture)?)?;let device=config.device(false)?;
 let mut journal=DeviceJournal::open(path,fixture_key(false),&device,config.identity(false)?)?;
 let result=state(&mut journal,&config)?;journal.close();Ok(result)
}
#[cfg(target_arch="wasm32")]
mod opfs;
#[cfg(target_arch="wasm32")]
use wasm_bindgen::prelude::*;
#[cfg(target_arch="wasm32")]
fn error(e:impl std::fmt::Debug)->JsError{JsError::new(&format!("{e:?}"))}
/// Isolated real-journal browser owner for qualification; not a package entry.
#[cfg(target_arch="wasm32")]
#[wasm_bindgen]
pub struct JournalProbe{journal:DeviceJournal,config:Config,cleanup:opfs::Cleanup}
#[cfg(target_arch="wasm32")]
#[wasm_bindgen]
impl JournalProbe{
 /// Open the existing OPFS image after real header admission and original recovery.
 pub fn open(slot:u32,fixture:&str,negative:u32)->Result<Self,JsError>{
  if negative>3{return Err(error("negative-control mode"))}let config=Config::parse(fixture).map_err(error)?;let device=config.device(negative==3).map_err(error)?;
  let (db,cleanup)=opfs::open(slot).map_err(error)?;
  let journal=DeviceJournal::open_database(db,fixture_key(negative==1),&device,config.identity(negative==2).map_err(error)?).map_err(error)?;
  Ok(Self{journal,config,cleanup})
 }
 /// Commit an independently pinned exact roster through the original intent/state transactions.
 pub fn install(&mut self,name:&str)->Result<String,JsError>{
  if !["one","two","fork"].contains(&name){return Err(error("roster selection"))}
  self.journal.install_roster(&self.config.roster(name).map_err(error)?,150).map_err(error)?;self.state()
 }
 /// Read authenticated journal metadata without granting traffic authority.
 pub fn state(&mut self)->Result<String,JsError>{state(&mut self.journal,&self.config).map_err(error)}
 /// Close the original journal and surface any backend close error.
 pub fn close(&mut self)->Result<(),JsError>{self.journal.close();opfs::closed(&self.cleanup).map_err(error)}
 /// Observe original encrypted image/intent commitments before recovery in this fixture only.
 pub fn inspect(slot:u32,fixture:&str)->Result<String,JsError>{
  let config=Config::parse(fixture).map_err(error)?;let device=config.device(false).map_err(error)?;
  let (db,cleanup)=opfs::open(slot).map_err(error)?;let key=fixture_key(false);let owner=bootstrap::storage_owner(&device);
  let (image,pending)=write_intent::load_snapshot(&db,&key,owner).map_err(error)?;
  let target=pending.as_ref().map(|p|p.authenticated_target(&key,owner)).transpose().map_err(error)?;
  let result=json!({"revision":image.revision,"imageDigest":image.digest,"pending":pending.is_some(),"targetDigest":target.map(|i|i.digest)}).to_string();
  drop(db);opfs::closed(&cleanup).map_err(error)?;Ok(result)
 }
}
