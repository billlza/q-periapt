from pathlib import Path
import hashlib,json,os,sys
out=Path(__file__).resolve().parent;root=out.parents[1];sys.path.insert(0,str(root/'artifact'));from continuity_android_jni import qualify_android_jni
s=json.loads((out/'STATE.json').read_text());work=Path(s['work']);base=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244');tc=base/'rustup/toolchains/1.98.1-aarch64-apple-darwin';jdk=base/'continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home'
swift=Path(json.loads((root/'target/swift-root-current/STATE.json').read_text())['work']);native={'completed':True,'execution':{}}
for profile in ['debug','release']:
 p=swift/('native-fixed-'+profile)/'libq_periapt_continuity_c_consumer.dylib';native['execution'][profile]={'binaries':{'C_library':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}}
 client=p.parent/'qpc-c-client';native['execution'][profile]['binaries']['C_client']={'path':str(client),'sha256':hashlib.sha256(client.read_bytes()).hexdigest()}
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO','QPERIAPT','QPC','DYLD','LD_','CC','CXX','AR'))};env.update(CARGO_HOME=str(base/'apple-cargo-home-ff4a153e'),CARGO_TARGET_DIR=str(work/'build'),CARGO_NET_OFFLINE='true',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
s['native']=native;s['environment']=env;s['live_producer']=True;(out/'STATE.json').write_text(json.dumps(s,indent=2)+'\n')
try:
 result=qualify_android_jni(work,out,native,env,jdk);s['completed']=result['completed'];print('Debug/Release Android registry and lifecycle qualification passed',flush=True)
finally:
 s['live_producer']=False;(out/'STATE.json').write_text(json.dumps(s,indent=2)+'\n')
