from pathlib import Path
from types import SimpleNamespace
import ast,base64,json
source=Path(__file__).with_name('device-driver.py')
tree=ast.parse(source.read_text())
loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='host_port')
program=compile(ast.fix_missing_locations(ast.Module(body=[loop],type_ignores=[])),str(source),'exec')
class State:
 def write_text(self,value):self.value=json.loads(value)
def run(results,ports=(55001,),names=('witness-address',),unexpected=None):
 calls=[];state=State();args=[]
 for name,port in zip(names,ports):args+=['-e',name,base64.b64encode(('127.0.0.1:'+str(port)).encode()).decode()]
 queue=iter(results);counter=iter(range(10,40))
 def command(name,cmd,bind_conflict):
  calls.append(cmd);assert bind_conflict and cmd[1]=='--no-rebind'
  if unexpected:raise unexpected
  value=next(queue);return str(cmd[-2][4:]) if value else None
 ns=dict(ports=list(ports),port=ports[0],port_random=SimpleNamespace(randbelow=lambda n:next(counter)),s={},state_path=state,json=json,base64=base64,args=args,command=command)
 try:exec(program,ns)
 except RuntimeError as error:return ns,calls,error
 return ns,calls,None
ns,calls,error=run([True]);assert error is None and len(calls)==1 and ns['s']['owned_reverse_ports']==[55001]
ns,calls,error=run([False,True]);assert error is None and len(calls)==2 and ns['s']['owned_reverse_ports']==[49162] and base64.b64decode(ns['args'][2])==b'127.0.0.1:49162'
ns,calls,error=run([False]*8);assert error is not None and len(calls)==8 and not ns['s'].get('owned_reverse_ports')
ns,calls,error=run([True,False,True],ports=(55001,55002),names=('witness-address','connection-address'));assert error is None and base64.b64decode(ns['args'][2])==b'127.0.0.1:55001' and base64.b64decode(ns['args'][5])==b'127.0.0.1:49162'
error=ValueError('unexpected adb failure')
try:run([],unexpected=error)
except ValueError as actual:assert actual is error
else:raise AssertionError('unexpected ADB failure was swallowed')
print('Five deterministic checks of the actual mapping loop passed: direct, collision, bounded exhaustion, dual endpoints, failure propagation')
