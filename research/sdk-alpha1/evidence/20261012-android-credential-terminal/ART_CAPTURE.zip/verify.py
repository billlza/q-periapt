from pathlib import Path
import hashlib,json,subprocess
import continuity_android_credential_terminal as credential
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-credential-terminal-portmapped-device';results=credential.verify_execution((out/'android-credential.stdout').read_bytes(),out/'cases')
assert sum(r['foreign_processes'] for r in results.values())==222
adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();matches=[r.split()[0] for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(matches)==1
prefix=[adb,'-s',matches[0]]
assert not subprocess.run(prefix+['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.credentialterminalmapped20261012'],capture_output=True,text=True,check=True,timeout=20).stdout.strip()
reverse=subprocess.run(prefix+['reverse','--list'],capture_output=True,text=True,check=True,timeout=20).stdout.splitlines();active={line.split()[-2] for line in reverse if len(line.split())==3 and line.split()[-2].startswith('tcp:')}
for label,record in results.items():
 state=json.loads((out/('device-'+label)/'STATE.json').read_text());assert state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports') and len(state['cases'])==record['foreign_processes']
 for p in (out/('device-'+label)).glob('*-reverse-create-*.json'):
  mapping=json.loads(p.read_text())
  if mapping['exit_code']==0:assert mapping['command'][-2] not in active
 for case in state['cases']:assert case['process_absent_after_stop'] and case['installed_apk_sha256']==state['apk_sha256']
 record.update(installation_retired=True,owned_reverse_maps_absent=True,apk_sha256=state['apk_sha256'],aar_sha256=state['aar_sha256'])
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':results,'same_phone_accepted':True,'additional_api36_hardware_required':False});print('222 ART outcomes, independent target checkpoints, app removal and owned mapping cleanup verified',flush=True)
