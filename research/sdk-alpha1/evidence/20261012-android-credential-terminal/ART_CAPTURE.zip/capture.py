from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import continuity_android_credential as credential
import continuity_android_remote_credential as remote
import continuity_android_credential_terminal as terminal
PUBLIC=credential.PUBLIC+remote.PUBLIC+terminal.PUBLIC
import continuity_android_jni as android
import rust_sdk_profile as sdk
root=Path.cwd();phone=root/'target/continuity-android-credential-terminal-portmapped-device';host=root/'target/continuity-android-credential-terminal-final';aar=root/'target/continuity-android-credential-terminal-aar';out=root/'research/sdk-alpha1/evidence/20261012-android-credential-terminal'
accepted=json.loads((phone/'VERIFIED.json').read_text());assert accepted['completed']
h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert h['completed'] and a['completed']
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==digest and a['source_sha256'][name]==digest
host_cases={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];library=Path(next(a.split('=',1)[1] for a in argv if a.startswith('-Djava.library.path=')))
 cases=library/'credential-cases';fresh=terminal.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),cases)
 assert fresh==h['profiles'][profile]['credential_outcomes'];host_cases[profile]=cases
 assert sdk.snapshot(library/'qpc-c-client',maximum=512*1024*1024).sha256==h['profiles'][profile]['receiver_sha256']
secrets=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
for line in rows:
 if ' device ' in line:secrets.append(line.split()[0].encode())
for path in (phone/'cases').glob('*/inputs/witness-tls-key'):
 value=path.read_bytes();secrets.extend([value,base64.b64encode(value),value.hex().encode()])
out.mkdir()
def archive(filename,files):
 with zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED) as packed:
  for name,path in sorted(files.items()):
   data=path.read_bytes();assert not any(secret and secret in data for secret in secrets),'private value in capture '+name
   info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;packed.writestr(info,data)
 return hashlib.sha256((out/filename).read_bytes()).hexdigest()
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for folder in ['device-*','agp-*']:
 for p in phone.glob(folder+'/*'):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for label in accepted['profiles']:
 for name in PUBLIC:files['cases/'+label+'/'+name]=phone/'cases'/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
files['ANDROID_JNI_CONSUMER.json']=host/'ANDROID_JNI_CONSUMER.json'
for name in ['clippy.stderr','clippy.stdout','clippy.json','artifact-tests.stdout','artifact-tests.stderr','qualify.py','clippy.py','rustfmt.stdout','rustfmt.stderr']:files[name]=host/name
for profile,cases in host_cases.items():
 for label in h['profiles'][profile]['credential_outcomes']:
  for name in PUBLIC:files['cases/'+profile+'/'+label+'/'+name]=cases/label/name
for label,folder in [('initial-expiry-expectation','continuity-android-credential-terminal-host'),('initial-new-effect-expectation','continuity-android-credential-terminal-qualified')]:
 failed=root/'target'/folder
 for name in ['android-jni-debug-credential.json','android-jni-debug-credential.stdout','android-jni-debug-credential.stderr']:
  files[label+'/'+name]=failed/name
host_hash=archive('HOST_CAPTURE.zip',files)
failed=root/'target/continuity-android-credential-terminal-device'
files={n:failed/n for n in ['run.py','device-driver.py','android-credential.json','android-credential.stdout','android-credential.stderr']}
for item in failed.glob('device-*/*'):
 if item.name=='STATE.json' or ('remote-acknowledged-reverse-create-59762.' in item.name):files[item.relative_to(failed).as_posix()]=item
mapping_failure=archive('INITIAL_MAPPING_FAILURE.zip',files)
dex=root/'target/continuity-android-api23-dex'
api23=archive('API23_DEX_CHECK.zip',{p.name:p for p in dex.iterdir() if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.txt'}})

a_hash=archive('AAR_BUILD_CAPTURE.zip',{p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}})
code={('bindings/android/ContinuityPackageConsumer/'+name):hashlib.sha256(data).hexdigest() for name,data in android.source_files().items()}
for name in ['artifact/continuity_android_credential.py','artifact/continuity_android_remote_credential.py','artifact/continuity_android_credential_terminal.py','artifact/continuity_android_jni.py','artifact/continuity_android_witness.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_witness.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential_traffic.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_remote_credential.rs','research/continuity-identity-candidate/tests/owned_connection.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_credential_terminal.rs','bindings/c/ContinuityPackageConsumer/tests/common/witness.rs']:
 code[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
record={'kind':'qperiapt.android_witnessed_credential_terminal_qualification','completed':True,'base_commit':'f7c229882606a73693d3b15f93bf4e7d5d13e200','code_commit':'ae899785b1b40c2f727c7f92cabeb5478c1fcb0b','art_harness':json.loads((phone/'HARNESS.json').read_text()),'code_sha256':code,'device_scope':{'accepted':True,'device_count':1,'api':37,'abi':'arm64-v8a','additional_api36_hardware_required':False},'art_processes':222,'native_credential_counterparty_processes_per_run':44,'profiles':accepted['profiles'],'host_jni':{'completed':True,'qualified_java_processes':654,'credential_java_processes':444,'boundary_processes':2,'local_lifecycle_processes':48,'managed_registry_processes':100,'witness_processes':60,'profiles':['debug','release'],'receiver_sha256':{p:h['profiles'][p]['receiver_sha256'] for p in ['debug','release']}},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'AAR_BUILD_CAPTURE.zip':a_hash,'INITIAL_MAPPING_FAILURE.zip':mapping_failure,'API23_DEX_CHECK.zip':api23},'scope':['Close and expiry reconciliation retain an already committed original operation.','Target-free cancellation is reserved and replayed exactly without witness dispatch. Unavailable remains Pending.','The signed target roster expires under real clocks while the successor credential and original policy remain live. A new staging call refuses it with Validity; committing the cancellation reservation remains Suspended.','Independent historical grant approval closes the target. The actual cleanup ACK is persisted by the witness but its reply is dropped; the original enrollment retains Closed and a later process finishes cleanup.','No Commit or Close is dispatched by cancellation recovery. Fresh activation checks the preceding authority, original identity/journal/next slot are unchanged, and a new third message creates exactly its distinct business effect.'],'initial_test_corrections':['An expired cancellation reservation remains Suspended; the separate fresh staging call verifies target-roster expiry as Validity.','A new post-cancellation message creates an effect; the receiver retry helper expected an existing effect. Separate creation and retry assertions retain both invariants.'],'limitations':['This qualifies required-witness target-roster expiry and independently authorized cancellation. Local-only ExpiredUncommitted and original-policy/runtime-expiry cleanup require their own Android scenarios.','The cancelled successor credential and original policy remain live during this case; only its signed roster authorization expires.','Counterparty is the installed native C consumer on the Mac host; no independent protocol implementation or native Linux endpoint is claimed.'],'test_transport_recovery':{'initial_error':'ADB reverse port already in use before SDK invocation','scope':'isolated test controller; at most eight bind attempts; other errors propagate; owned mappings only','checks':5},'api_floor_followup':'Production Counter64 has no API 26 unsigned-Long helper calls; actual production JAR passes D8 min-api 23 for this specific concern. This is not a full Android API audit.','release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',record);print('Captured witnessed cancellation, real expiry and lost cleanup ACK evidence',flush=True)
