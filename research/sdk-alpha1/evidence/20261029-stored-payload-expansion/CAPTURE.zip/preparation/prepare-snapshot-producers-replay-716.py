"""Apply only the 25 actual remaining goals in the unchanged complete proof tree."""
from pathlib import Path
import hashlib,json,re,shutil
root=Path.cwd();parent=root/'target/p0-origin-complete-snapshot-716'
sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((parent/'complete-snapshot-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
assert not (parent/'initial-send-oracle.failed').exists()
value=(parent/'complete-snapshot-proof.spthy').read_text()
assert sha(value.encode())==terminal['output_sha256']=='1a393025c1cdd4ee8b88fe236ef5c4dde50018fee380a463a4476276fae48ef4'
previous=root/'target/p0-origin-offer-response-final-715/offer-response-final-proof.spthy';old=previous.read_text()
assert sha(old.encode())=='2fea36a4924616476f80dca5172743c7d726b6a3f1cc68b51111c8599960acae'
a=value.index('lemma epoch_generation_secret_derivation_origin ');b=value.index('\nlemma ',a);main=value[a:b]
roots={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(roots)==18 and sum('by sorry' not in t for t in roots.values())==17 and not re.search(r'\binvalid\b',main)
leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',main));assert len(leaves)==25 and main.count('by sorry')==25
frames=[]
for p in sorted((parent/'initial-send-oracle-frames').glob('*.json')):
    row=json.loads(p.read_text());text=(p.parent/row['captured_input']).read_text()
    assert sha(text.encode())==row['input_sha256'] and not row['ranking'];frames.append((row,text))
assert len(frames)==25
methods=[];changes=[]
for leaf,(row,text) in zip(leaves,frames,strict=True):
    chains=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',text)
    if chains:
        assert len(chains)==1;method=chains[0];kind='knowledge_chain'
    else:
        phases=re.findall(r'(?m)^\d+: (PositionedPhaseState\([^\n]+▶₀ #vr(?:\.[0-9]+)?)$',text)
        assert len(phases)==1;method=phases[0];kind='phase_producer'
    changes.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
    methods.append({'frame':row['captured_input'],'frame_sha256':row['input_sha256'],'kind':kind,'method':method})
assert sum(r['kind']=='knowledge_chain' for r in methods)==12 and sum(r['kind']=='phase_producer' for r in methods)==13
for left,right,replacement in reversed(changes):main=main[:left]+replacement+main[right:]
candidate=value[:a]+main+value[b:]
assert 'by sorry' not in main
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,old)
assert candidate[:candidate.index('lemma ')]==old[:old.index('lemma ')]
stage=root/'target/p0-origin-snapshot-producers-replay-716';stage.mkdir();(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'full_parent_sha256':sha(old.encode()),'capture_sha256':sha(value.encode()),'input_sha256':sha(candidate.encode()),'actual_selected_methods':methods,
    'all18_sources_11stored_producers_29queries_retained':True,'collapsed_subtrees':0,'operational_prefix_unchanged':True,
    'independent_replay_no_search_or_oracle':True,'maximum_explicit_prefix':10,'total_depth_limit':16,
    'input_methods_are_not_a_completion_claim':'The checker may create further open children; only the terminal checked output is evidence.',
    'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'chains':12,'phase_producers':13,'collapsed_subtrees':0}))
