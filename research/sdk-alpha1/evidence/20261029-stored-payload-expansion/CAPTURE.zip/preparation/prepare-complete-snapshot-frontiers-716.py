"""Capture all remaining Snapshot leaves without collapsing any subtree."""
from pathlib import Path
import hashlib,json,re,shutil
root=Path.cwd();parent=root/'target/p0-origin-offer-response-final-715'
sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((parent/'offer-response-final-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
source=parent/'offer-response-final-proof.spthy';data=source.read_bytes();assert sha(data)==terminal['output_sha256']=='2fea36a4924616476f80dca5172743c7d726b6a3f1cc68b51111c8599960acae'
value=data.decode();main=value.split('lemma epoch_generation_secret_derivation_origin ',1)[1].split('\nlemma ',1)[0]
sources={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(sources)==18 and sum('by sorry' not in b for b in sources.values())==17 and not re.search(r'\binvalid\b',main)
children={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',sources['Snapshot_case_5'])}
assert len(children)==11 and main.count('by sorry')==27 and all('by sorry' not in children[n] for n in ('Key_Reservation_1','Offer_Signing_2','Response_Reservation_4'))
prefix=max(len(m[1]) for m in re.finditer(r'(?m)^( +)by sorry',main))//2
assert prefix==9
stage=root/'target/p0-origin-complete-snapshot-716';stage.mkdir();(stage/'model.spthy').write_bytes(data)
base=root/'target/p0-origin-source-frontiers-705'
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):shutil.copy2(base/name,stage/name)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1;driver.write_text(driver.read_text().replace('--bound=13','--bound=7'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)))
(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(source),'input_sha256':sha(data),'input_byte_equal_to_independently_checked_full_tree':True,
    'all18_sources_11stored_producers_29queries_retained':True,'closed_sources':17,'closed_stored_producers':['Key_Reservation_1','Offer_Signing_2','Response_Reservation_4'],
    'open_leaves':27,'collapsed_subtrees':0,'existing_open_prefix_maximum':prefix,'remaining_search_bound':7,'total_depth_limit':16,
    'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
