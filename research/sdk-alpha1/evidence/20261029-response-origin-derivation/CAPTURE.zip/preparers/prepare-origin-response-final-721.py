"""Close the captured post-reservation edge and restore the exact whole snapshot proof."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();source=root/'target/p0-origin-response-payload-guided-721'
terminal=json.loads((source/'origin-response-payload-guided-TERMINAL.json').read_text());assert terminal['returncode']==0 and not terminal['timed_out']
parent=source/'origin-response-payload-guided-proof.spthy';data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()==terminal['output_sha256']
text=data.decode();assert 'invalid proof step encountered' not in text
a=text.index('lemma epoch_generation_secret_derivation_origin_with_phase_roots ');e=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+e.start();body=text[a:b]
part=re.search(r'(?ms)^    case Response_Commit_6\n(.*?)(?=^  next|^  qed)',body);assert part and part[0].count('by sorry')==1
frame=json.loads((source/'initial-send-oracle-frames/0005.json').read_text());raw=(source/'initial-send-oracle-frames'/frame['captured_input']).read_bytes()
assert hashlib.sha256(raw).hexdigest()==frame['input_sha256'] and frame['ranking']==[]
goals=[re.fullmatch(r'(\d+):\s*(.*)',line) for line in raw.decode().splitlines()]
edges=[m for m in goals if '~~>' in m[2] and '#known' in m[2]];assert len(edges)==1
method=edges[0][2];needle='by sorry /* Oracle ranked no proof methods */';assert part[0].count(needle)==1
newpart=part[0].replace(needle,'by solve( '+method+' )')
newbody=body[:part.start()]+newpart+body[part.end():]
snapshot=re.search(r'(?ms)^    case Snapshot_case_5\n(.*?)(?=^  next|^  qed)',newbody);assert snapshot and snapshot[0].count('by sorry')==1
saved=(root/'target/p0-origin-response-capture-721/RETAINED_SNAPSHOT_SUBTREE.txt').read_text();assert hashlib.sha256(saved.encode()).hexdigest()=='cd2ce63bd0912a99315467468e540d7e0b2f20d333a93e976aa39c53f9a24281'
newbody=newbody[:snapshot.start()]+saved+newbody[snapshot.end():]
candidate=text[:a]+newbody+text[b:];assert candidate[:a]==text[:a] and candidate[a+len(newbody):]==text[b:]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-final-replay-721';stage.mkdir(exist_ok=False);(stage/'model.spthy').write_text(candidate)
(stage/'run.py').write_bytes((root/'target/p0-origin-context-repair-720/run.py').read_bytes())
record={'parent':str(parent),'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
'actual_captured_method':method,'captured_frame':frame,'all40_snapshot_leaves_restored_byte_for_byte':True,
'no_lemma_formula_operational_rule_or_other_subtree_change':True,'mode':'full replay, no search/oracle',
'completion_boundary':'Origin lemma supports the multi-epoch main secrecy theorem; closing response is not proving either entire theorem.'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='captured_frame'}))

