"""Focus the captured response derivation without changing protocol or lemma formulas."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();old=root/'target/p0-origin-response-capture-721'
t=json.loads((old/'origin-response-capture-TERMINAL.json').read_text())
assert t['returncode']==0 and not t['timed_out']
parent=old/'origin-response-capture-proof.spthy';data=parent.read_bytes()
assert hashlib.sha256(data).hexdigest()==t['output_sha256'] and b'invalid proof step encountered' not in data
frames=sorted((old/'initial-send-oracle-frames').glob('*.json'));assert len(frames)==2
for p in frames:
 r=json.loads(p.read_text());assert hashlib.sha256((p.parent/r['captured_input']).read_bytes()).hexdigest()==r['input_sha256'] and r['ranking']==[]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-guided-721';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_bytes(data)
driver=(old/'run.py').read_text();assert driver.count('--bound=1')==1
(stage/'run.py').write_text(driver.replace('--bound=1','--bound=12'))
(stage/'initial-send-oracle-frames').mkdir()
shell=(old/'initial-send-oracle.sh').read_text().replace(str(old),str(stage))
(stage/'initial-send-oracle.sh').write_text(shell);(stage/'initial-send-oracle.sh').chmod(0o700)
oracle=(old/'initial-send-oracle.py').read_text()
oracle=oracle.replace('"""Capture bounded open proof frontiers; deliberately select no search step."""','"""Follow only current response projection edges and established constructor cases."""')
needle="    with (stage / 'initial-send-oracle.lock').open('a') as lock:"
selection="""    ranked=[];reason='outside-focused-response'
    if any("PositionedPhaseState(" in m[2] and "'Response4'" in m[2] for m in matches):
        choices=[m for m in matches if '~~>' in m[2] and re.search(r'#known(?:\\.[0-9]+)?',m[2])]
        reason='response-deduction-edge'
        if not choices:
            choices=[m for m in matches if 'scope(' in m[2] and 'sign(' in m[2] and '∃ context' in m[2]]
            reason='already-proved-wire-constructor'
        if not choices:
            choices=[m for m in matches if 'last(#known)' in m[2] and 'EntropyLeak(' in m[2]]
            reason='existing-induction-hypothesis'
        if not choices:
            choices=[m for m in matches if re.search(r"\\([a-z][a-z0-9_.]* = 'A'\\)",m[2]) and "'B'" in m[2]]
            reason='already-proved-public-role'
        if choices: ranked=[int(choices[0][1])]
        else: reason='focused-response-needs-new-context'
"""
assert oracle.count(needle)==1
oracle=oracle.replace(needle,selection+needle)
oracle=oracle.replace("'goal_numbers': goals, 'ranking': [], 'diagnostic_stop': True,","'goal_numbers': goals, 'ranking': ranked, 'diagnostic_stop': not ranked,")
oracle=oracle.replace("'stop_reason': 'frontier-capture-no-search',","'stop_reason': reason,")
oracle=oracle.replace("        (stage / 'initial-send-oracle.diagnostic-stop').write_text('frontier-capture-no-search\\n')","        if not ranked: (stage / 'initial-send-oracle.diagnostic-stop').write_text(reason+'\\n')\n        for number in ranked: print(number)")
assert "'ranking': ranked" in oracle and "for number in ranked: print(number)" in oracle
(stage/'initial-send-oracle.py').write_text(oracle)
record={'parent':str(parent),'input_sha256':hashlib.sha256(data).hexdigest(),'no_model_formula_or_other_proof_change':True,
'query': 'epoch_generation_secret_derivation_origin_with_phase_roots','callbacks':32,'remaining_depth':12,'maximum_prefix_depth':4,'total_search_depth_at_most':16,
'focus':'Only response contexts retain Response4 prerequisite; rank current extraction edges, proved constructor/role cases and existing induction hypothesis. Never unfold another phase premise; unknown context returns no rank.',
'retained_snapshot':str(old/'RETAINED_SNAPSHOT_SUBTREE.txt'),'restore_before_whole_frontier_claim':True}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

