"""Follow the remaining response payload projections to their original reservation."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();source=root/'target/p0-origin-response-full-replay-721'
terminal=json.loads((source/'origin-response-full-replay-TERMINAL.json').read_text());assert terminal['returncode']==0 and not terminal['timed_out']
parent=source/'origin-response-full-replay-proof.spthy';data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()==terminal['output_sha256']
text=data.decode();assert 'invalid proof step encountered' not in text
a=text.index('lemma epoch_generation_secret_derivation_origin_with_phase_roots ');end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start();body=text[a:b]
roots={m[1]:m for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
assert roots['Response_Commit_6'][0].count('by sorry')==2 and roots['Snapshot_case_5'][0].count('by sorry')==40
snapshot=roots['Snapshot_case_5'];saved=(root/'target/p0-origin-response-capture-721/RETAINED_SNAPSHOT_SUBTREE.txt').read_text();assert snapshot[0]==saved
newbody=body[:snapshot.start()]+'    case Snapshot_case_5\n    by sorry\n'+body[snapshot.end():]
candidate=text[:a]+newbody+text[b:]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-payload-guided-721';stage.mkdir(exist_ok=False);(stage/'model.spthy').write_text(candidate)
old=root/'target/p0-origin-response-guided-721'
driver=(old/'run.py').read_text();assert driver.count('--bound=12')==1;(stage/'run.py').write_text(driver.replace('--bound=12','--bound=8'))
oracle=(old/'initial-send-oracle.py').read_text()
needle="        if choices: ranked=[int(choices[0][1])]"
replacement="""        if not choices:
            choices=[m for m in matches if 'PositionedPhaseState(' in m[2] and "'Response4'" in m[2]]
            reason='original-response-reservation-source'
        if choices: ranked=[int(choices[0][1])]"""
assert oracle.count(needle)==1;oracle=oracle.replace(needle,replacement)
(stage/'initial-send-oracle.py').write_text(oracle);(stage/'initial-send-oracle-frames').mkdir()
(stage/'initial-send-oracle.sh').write_text((old/'initial-send-oracle.sh').read_text().replace(str(old),str(stage)));(stage/'initial-send-oracle.sh').chmod(0o700)
record={'parent':str(parent),'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
'remaining_depth':8,'conservative_fixed_prefix_depth':8,'total_search_depth_at_most':16,'callback_bound':32,
'basis':'Completed replay exposes exactly two nested response payload projection branches. Response_Compute_5 defines them as h(offer) and kemct(peer,coins); source Response4 is the existing reservation that emits EncapsulationSecret for the already-verified separation lemma.',
'no_new_lemma_assumption_or_operational_change':True,'unknown_context_stops':True,'restoration_of_all40_snapshot_leaves_required':True}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

