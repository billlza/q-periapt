"""Capture the current response leaf while preserving the entire snapshot subtree."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd()
parent=root/'target/p0-origin-context-repair-720/origin-context-repair-proof.spthy'
data=parent.read_bytes()
assert hashlib.sha256(data).hexdigest()=='b8c7948025c223d87ef2dd5200f9eaa587fde56f4e46603f222a5fe971c3dde0'
text=data.decode();assert 'invalid proof step encountered' not in text
name='epoch_generation_secret_derivation_origin_with_phase_roots'
a=text.index('lemma '+name+' ')
e=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+e.start()
body=text[a:b]
assert len(re.findall(r'\bby sorry\b',body))==41
roots={m[1]:m for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',body)}
assert len(roots)==18
snapshot=roots['Snapshot_case_5']
assert snapshot[0].count('by sorry')==40 and roots['Response_Commit_6'][0].count('by sorry')==1
replacement="    case Snapshot_case_5\n    by sorry\n"
newbody=body[:snapshot.start()]+replacement+body[snapshot.end():]
candidate=text[:a]+newbody+text[b:]
assert newbody.count('by sorry')==2
assert candidate[:a]==text[:a] and candidate[a+len(newbody):]==text[b:]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-capture-721';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
(stage/'RETAINED_SNAPSHOT_SUBTREE.txt').write_text(snapshot[0])
old=root/'target/p0-origin-context-capture-720'
for filename in ['run.py','initial-send-oracle.py']:
 (stage/filename).write_bytes((old/filename).read_bytes())
(stage/'initial-send-oracle-frames').mkdir()
shell=(old/'initial-send-oracle.sh').read_text().replace(str(old),str(stage))
(stage/'initial-send-oracle.sh').write_text(shell);(stage/'initial-send-oracle.sh').chmod(0o700)
record={'parent':str(parent),'parent_sha256':hashlib.sha256(data).hexdigest(),
'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'retained_snapshot_sha256':hashlib.sha256(snapshot[0].encode()).hexdigest(),
'full_model_formulas_and_other_proofs_unchanged':True,'focused_holes':2,
'requires_restoring_full_snapshot_before_whole_origin_claim':True,
'expected_order':['non_empty_trace/Response_Commit_6/Response_Compute_5','non_empty_trace/Snapshot_case_5'],
'oracle_ranks_no_method':True,'callback_bound':32,'classification':'diagnostic capture, not proof completion'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

