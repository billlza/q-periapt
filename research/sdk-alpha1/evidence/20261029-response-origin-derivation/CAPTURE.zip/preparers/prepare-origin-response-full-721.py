"""Use two captured current edges and restore every retained snapshot branch."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();source=root/'target/p0-origin-response-tail-capture-721'
terminal=json.loads((source/'origin-response-tail-capture-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out']
parent=source/'origin-response-tail-capture-proof.spthy';data=parent.read_bytes();assert hashlib.sha256(data).hexdigest()==terminal['output_sha256']
text=data.decode();assert 'invalid proof step encountered' not in text
a=text.index('lemma epoch_generation_secret_derivation_origin_with_phase_roots ')
end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start();body=text[a:b]
part=re.search(r'(?ms)^    case Response_Commit_6\n(.*?)(?=^  next|^  qed)',body)
holes=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',part[0]));assert len(holes)==2
changes=[];methods=[]
for n,hole in enumerate(holes):
 frame=json.loads((source/f'initial-send-oracle-frames/{n:04}.json').read_text());raw=(source/'initial-send-oracle-frames'/frame['captured_input']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==frame['input_sha256'] and frame['ranking']==[]
 goals=[re.fullmatch(r'(\d+):\s*(.*)',line) for line in raw.decode().splitlines()]
 edges=[m for m in goals if '~~>' in m[2] and '#known' in m[2]];assert len(edges)==1
 method=edges[0][2];methods.append({'frame':frame['captured_input'],'input_sha256':frame['input_sha256'],'method':method})
 changes.append((hole.start(),hole.end(),'by solve( '+method+' )'))
updated=part[0]
for l,r,v in reversed(changes):updated=updated[:l]+v+updated[r:]
newbody=body[:part.start()]+updated+body[part.end():]
snapshot=re.search(r'(?ms)^    case Snapshot_case_5\n(.*?)(?=^  next|^  qed)',newbody);assert snapshot and snapshot[0].count('by sorry')==1
original=root/'target/p0-origin-response-capture-721/RETAINED_SNAPSHOT_SUBTREE.txt';saved=original.read_text()
assert hashlib.sha256(saved.encode()).hexdigest()=='cd2ce63bd0912a99315467468e540d7e0b2f20d333a93e976aa39c53f9a24281' and saved.count('by sorry')==40
newbody=newbody[:snapshot.start()]+saved+newbody[snapshot.end():]
candidate=text[:a]+newbody+text[b:];assert candidate[:a]==text[:a] and candidate[a+len(newbody):]==text[b:]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-full-replay-721';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate)
(stage/'run.py').write_bytes((root/'target/p0-origin-context-repair-720/run.py').read_bytes())
record={'parent':str(parent),'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
'actual_captured_methods':methods,'all40_snapshot_leaves_restored_byte_for_byte':True,'no_formula_operational_rule_or_other_proof_change':True,
'mode':'full replay, no proof search or oracle','expected_result':'No complete proof claim unless all main obligations verify; count invalid methods separately from honest open leaves.'}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

