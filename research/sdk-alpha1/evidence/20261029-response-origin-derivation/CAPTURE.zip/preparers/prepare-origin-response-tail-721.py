"""Resolve the captured role source, then capture only remaining current goals."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();source=root/'target/p0-origin-response-guided-721'
terminal=json.loads((source/'origin-response-guided-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['timed_out']
parent=source/'origin-response-guided-proof.spthy';data=parent.read_bytes()
assert hashlib.sha256(data).hexdigest()==terminal['output_sha256']
text=data.decode();assert 'invalid proof step encountered' not in text
a=text.index('lemma epoch_generation_secret_derivation_origin_with_phase_roots ')
end=re.search(r'(?m)^/\* All wellformedness|^end$',text[a:]);b=a+end.start()
body=text[a:b]
part=re.search(r'(?ms)^    case Response_Commit_6\n(.*?)(?=^  next|^  qed)',body)
assert part and part[0].count('by sorry')==3
raw=(source/'initial-send-oracle-frames/0007.txt').read_bytes()
frame=json.loads((source/'initial-send-oracle-frames/0007.json').read_text())
assert hashlib.sha256(raw).hexdigest()==frame['input_sha256'] and frame['ranking']==[]
methods=[re.fullmatch(r'(\d+):\s*(!Signer\(.*)',line) for line in raw.decode().splitlines() if '!Signer(' in line]
assert len(methods)==1 and methods[0]
old='by sorry /* Oracle ranked no proof methods */';assert part[0].count(old)==1
newpart=part[0].replace(old,'by solve( '+methods[0][2]+' )')
newbody=body[:part.start()]+newpart+body[part.end():]
candidate=text[:a]+newbody+text[b:]
assert candidate[:a]==text[:a] and candidate[a+len(newbody):]==text[b:]
assert not any(line.strip().endswith('/tamarin-prover') for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines())
stage=root/'target/p0-origin-response-tail-capture-721';stage.mkdir(exist_ok=False)
(stage/'model.spthy').write_text(candidate);base=root/'target/p0-origin-response-capture-721'
for name in ['run.py','initial-send-oracle.py']:(stage/name).write_bytes((base/name).read_bytes())
(stage/'initial-send-oracle-frames').mkdir()
(stage/'initial-send-oracle.sh').write_text((base/'initial-send-oracle.sh').read_text().replace(str(base),str(stage)))
(stage/'initial-send-oracle.sh').chmod(0o700)
record={'parent':str(parent),'parent_sha256':terminal['output_sha256'],'input_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
'actual_captured_role_method':methods[0][2],'basis':'Unfold existing signer origin to bind public responder role. No new assumption or operational change.',
'remaining_response_holes_before_replay':2,'snapshot_retained_outside_focus':str(base/'RETAINED_SNAPSHOT_SUBTREE.txt'),'oracle_ranks_no_method':True,'no_lemma_formula_or_other_subtree_change':True}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

