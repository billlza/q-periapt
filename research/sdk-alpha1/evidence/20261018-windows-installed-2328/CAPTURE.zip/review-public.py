from pathlib import Path
import hashlib,io,json,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'artifact'))
from pathlib import PurePosixPath
import stat

def unpack(data, hashes, destination):
 # These are CI result archives, not the bounded installed consumer package.
 # Both profiles include eleven public C workloads and the Rust lifecycle.
 assert not destination.exists() and len(data)<=128*1024**2
 with zipfile.ZipFile(io.BytesIO(data)) as zipped:
  entries=zipped.infolist()
  assert len(entries)<=4096 and len(entries)==len(hashes)
  assert set(i.filename for i in entries)==set(hashes)
  assert sum(i.file_size for i in entries)<=128*1024**2
  selected={}
  for item in entries:
   path=PurePosixPath(item.filename)
   assert path.parts and not path.is_absolute() and '..' not in path.parts
   assert str(path)==item.filename and '\\' not in item.filename
   assert stat.S_ISREG(item.external_attr>>16) and not item.flag_bits&1
   content=zipped.read(item)
   assert hashlib.sha256(content).hexdigest()==hashes[item.filename]
   selected[path]=content
 destination.mkdir(mode=0o700)
 for name,content in selected.items():
  path=destination.joinpath(*name.parts)
  path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as stream:stream.write(content)

from continuity_windows_network_review import review
out=Path(__file__).resolve().parent;head='23280124efd2f0f3003d4ce85e3db665f6ec8a25';run=39129232911
api=lambda tail:subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+tail],timeout=60)
a=json.loads(api(f'actions/runs/{run}/artifacts'))['artifacts']
rows=[]
for os in ('windows-2022','windows-2025'):
 native=next(x for x in a if x['name']=='windows-installed-c-'+os)
 data=(out/(os.replace('-','')+'.zip')).read_bytes()
 assert len(data)==native['size_in_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==native['digest']
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert not any(i.is_dir() for i in z.infolist())
  hashes={i.filename:hashlib.sha256(z.read(i)).hexdigest() for i in z.infolist()}
 dest=out/os.replace('-','');unpack(data,hashes,dest)
 local=out/('NETWORK_REVIEW-'+os.replace('-','')+'.json');checked=review(dest,local,head)
 cloud=next(x for x in a if x['name']=='windows-lifecycle-readback-'+os)
 assert cloud['workflow_run']['head_sha']==head and not cloud['expired']
 payload=api(f"actions/artifacts/{cloud['id']}/zip")
 assert len(payload)==cloud['size_in_bytes'] and 'sha256:'+hashlib.sha256(payload).hexdigest()==cloud['digest']
 (out/('readback-'+os+'.zip')).write_bytes(payload)
 with zipfile.ZipFile(io.BytesIO(payload)) as z:
  assert z.namelist()==['NETWORK_REVIEW.json']
  assert z.read('NETWORK_REVIEW.json')==local.read_bytes()
 rows.append({'os':os,'native_artifact_id':native['id'],'native_bytes':len(data),'native_digest':native['digest'],'readback_artifact_id':cloud['id'],'readback_digest':cloud['digest'],'local_and_cloud_review_bytes_identical':True})
result={'head':head,'run':run,'profiles':4,'rows':rows,'C_scope':'56 initial-configuration cases,40 original owner suite entries,28 independently replayed C owner workloads and16 root replacement routes, plus24 first-registration carrier/trust scenarios with190 public files perprofile; original strict controls retained (seeNATIVE_C_REVIEW.json); same engine/host, not independent protocol implementation','Rust_scope':'All original installed public lifecycle contracts, same-engine/same-host;279publicfiles/profile; original reader and cloud/local review bytesmatch; no powerloss/performance/release claim'}
with (out/'WINDOWS_LIFECYCLE_REVIEW.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
