from __future__ import annotations

import hashlib
import io
import json
import pathlib
import struct
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from unittest import mock

import release_binary_scan
from release_binary_scan import (
    ReleaseBinaryScanError,
    scan_release_file,
)


class ReleaseBinaryScanTests(unittest.TestCase):
    def test_clean_regular_file_returns_digest_bound_result(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "library.bin"
            path.write_bytes(b"QPERIAPT_ABI2_RELEASE_PAYLOAD")

            result = scan_release_file(path)

            self.assertEqual(result.path, path)
            self.assertEqual(result.bytes, path.stat().st_size)
            self.assertEqual(
                result.sha256,
                "3915493139ec82e20792cd8afa0e04f98d8c3fc358c98dc5db96fb21018b84cf",
            )

    def test_private_paths_are_rejected_in_every_supported_encoding(self) -> None:
        cases = {
            "utf8": "/Users/release/source".encode(),
            "utf16le": "D:\\a\\repo\\target".encode("utf-16-le"),
            "utf16be": "/home/runner/work/repo".encode("utf-16-be"),
            "windows-case-and-slashes": b"c:/users/release/source",
            "github-case-and-slashes": b"d:/A/repo/target",
            "msys-user-home": b"/c/USERS/release/source",
            "msys-github-workspace": b"/D/A/repo/target",
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for label, data in cases.items():
                with self.subTest(label=label):
                    path = root / f"{label}.bin"
                    path.write_bytes(b"prefix" + data + b"suffix")
                    with self.assertRaisesRegex(
                        ReleaseBinaryScanError, "release binary contains"
                    ):
                        scan_release_file(path)

    def test_bare_windows_namespace_markers_are_not_private_paths(self) -> None:
        cases = {
            "machine-code": b"\x81\x3f\x5c\x5c\x3f\x5c\x81",
            "utf8-extended": b"prefix \\\\?\\ suffix",
            "utf8-unc": b"prefix \\\\?\\UNC suffix",
            "utf8-drive-root": b"\\\\?\\C:\\",
            "utf8-namespace-root": b"\\\\?\\GLOBALROOT\\",
            "utf16le-unc": r"\\?\UNC".encode("utf-16-le"),
            "utf16be-posix": r"//?/UNC".encode("utf-16-be"),
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for label, data in cases.items():
                with self.subTest(label=label):
                    path = root / f"{label}.bin"
                    path.write_bytes(data)
                    scan_release_file(path)

    def test_dense_bare_namespace_markers_have_fixed_chunk_work(self) -> None:
        marker_count = 20_000
        marker = "\\\\?\\"
        window = release_binary_scan._WIDE_SCAN_WINDOW_CHARS
        overlap = release_binary_scan._WIDE_EXTENDED_PATH_WINDOW_CODE_UNITS
        step = window - overlap

        def windows(code_units: int) -> int:
            if code_units <= 0:
                return 0
            return 1 + max(0, (code_units - window + step - 1) // step)

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            raw_path = root / "dense-raw.bin"
            raw_path.write_bytes(marker.encode() * marker_count)
            original_pattern = release_binary_scan._WINDOWS_EXTENDED_BYTE_PATTERN
            with mock.patch.object(
                release_binary_scan,
                "_WINDOWS_EXTENDED_BYTE_PATTERN",
                wraps=original_pattern,
            ) as pattern:
                scan_release_file(raw_path)
            self.assertEqual(pattern.search.call_count, 1)

            for encoding in ("utf-16-le", "utf-16-be"):
                for alignment in (0, 1):
                    with self.subTest(encoding=encoding, alignment=alignment):
                        data = b"X" * alignment + (
                            marker * marker_count
                        ).encode(encoding)
                        path = root / f"dense-{encoding}-{alignment}.bin"
                        path.write_bytes(data)
                        maximum_calls = 2 * sum(
                            windows((len(data) - alignment_view) // 2)
                            for alignment_view in (0, 1)
                        )
                        with mock.patch.object(
                            release_binary_scan,
                            "_first_windows_extended_text_match",
                            wraps=(
                                release_binary_scan._first_windows_extended_text_match
                            ),
                        ) as text_match:
                            scan_release_file(path)
                        self.assertGreater(text_match.call_count, 0)
                        self.assertLessEqual(
                            text_match.call_count,
                            maximum_calls,
                        )
                        self.assertLess(
                            text_match.call_count,
                            marker_count // 100,
                        )

    def test_concrete_windows_extended_paths_are_rejected(self) -> None:
        cases = {
            "utf8-drive": b"prefix \\\\?\\C:\\private suffix",
            "utf8-drive-leading-space": rb"\\?\C:\ private",
            "utf8-posix-drive": b"prefix //?/c:/build/output suffix",
            "utf8-unc-root-with-spaces": (
                r"\\?\UNC\private host\secret share".encode()
            ),
            "utf8-quoted-unc-root": rb'"\\?\UNC\private-host\secret-share"',
            "utf8-long-unicode-unc": (
                ("\\\\?\\UNC\\" + "构" * 86 + "\\share").encode()
            ),
            "utf8-volume-namespace": (
                rb"\\?\Volume{01234567-89AB-CDEF-0123-456789ABCDEF}"
                rb"\private\file"
            ),
            "utf8-globalroot-namespace": (
                rb"\\?\GLOBALROOT\Device\HarddiskVolume1\file"
            ),
            "utf8-posix-volume-namespace": (
                rb"//?/Volume{01234567-89AB-CDEF-0123-456789ABCDEF}"
                rb"/private/file"
            ),
            "utf16le-unc-unicode": (
                r"\\?\UNC\构建机\发布".encode("utf-16-le")
            ),
            "utf16le-quoted-unc-root": (
                '"\\\\?\\UNC\\private-host\\secret-share"'.encode(
                    "utf-16-le"
                )
            ),
            "utf16be-drive-odd": (
                b"0" + r"\\?\z:/build/output".encode("utf-16-be")
            ),
            "utf16le-posix-unc-odd": (
                b"0" + r"//?/unc/构建机/发布".encode("utf-16-le")
            ),
            "utf16be-volume-odd": (
                b"0"
                + (
                    r"\\?\Volume{01234567-89AB-CDEF-0123-456789ABCDEF}"
                    r"\private\file"
                ).encode("utf-16-be")
            ),
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for label, data in cases.items():
                with self.subTest(label=label):
                    path = root / f"{label}.bin"
                    path.write_bytes(data)
                    with self.assertRaisesRegex(
                        ReleaseBinaryScanError, "Windows extended"
                    ):
                        scan_release_file(path)

    def test_non_bmp_utf16_extended_unc_path_is_rejected(self) -> None:
        server = "😀" * 255
        share = "🧪" * 80
        text = "A" * 7600 + rf"\\?\UNC\{server}\{share}"
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "wide-unc-boundary.bin"
            path.write_bytes(text.encode("utf-16-le"))
            with self.assertRaisesRegex(
                ReleaseBinaryScanError, "UTF-16 Windows extended UNC path"
            ):
                scan_release_file(path)

    def test_caller_forbidden_text_and_credentials_are_rejected_without_echoing_secret(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            caller_path = root / "caller.bin"
            caller_path.write_bytes(b"prefix/private/build/root/suffix")
            with self.assertRaisesRegex(
                ReleaseBinaryScanError, "caller-forbidden text 0"
            ):
                scan_release_file(caller_path, forbidden_text=["/private/build/root"])

            secret_path = root / "secret.bin"
            secret = b"ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345"
            secret_path.write_bytes(b"prefix" + secret + b"suffix")
            with self.assertRaises(ReleaseBinaryScanError) as captured:
                scan_release_file(secret_path)
            self.assertIn("GitHub token", str(captured.exception))
            self.assertNotIn(secret.decode(), str(captured.exception))

    def test_caller_forbidden_producer_root_is_rejected_in_every_supported_encoding(self) -> None:
        producer_root = r"C:\Build Roots\cargo-home"
        encodings = ("utf-8", "utf-16-le", "utf-16-be")
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for encoding in encodings:
                with self.subTest(encoding=encoding):
                    path = root / f"producer-root-{encoding}.bin"
                    path.write_bytes(
                        b"prefix" + producer_root.encode(encoding) + b"suffix"
                    )
                    with self.assertRaises(ReleaseBinaryScanError) as captured:
                        scan_release_file(path, forbidden_text=[producer_root])
                    message = str(captured.exception)
                    self.assertIn("caller-forbidden text 0", message)
                    self.assertNotIn(producer_root, message)

    def test_forbidden_windows_path_covers_case_separators_and_msys_spelling(self) -> None:
        producer_root = r"C:\Build Roots\cargo-home"
        spellings = (
            r"c:\build roots\CARGO-HOME\registry",
            "c:/BUILD ROOTS/cargo-home/registry",
            r"C:\build roots/cargo-HOME\registry",
            "/c/BUILD ROOTS/Cargo-Home/registry",
        )
        encodings = ("utf-8", "utf-16-le", "utf-16-be")
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for spelling in spellings:
                for encoding in encodings:
                    with self.subTest(spelling=spelling, encoding=encoding):
                        path = root / f"windows-path-{len(spelling)}-{encoding}.bin"
                        path.write_bytes(
                            b"prefix" + spelling.encode(encoding) + b"suffix"
                        )
                        with self.assertRaises(ReleaseBinaryScanError) as captured:
                            scan_release_file(
                                path,
                                forbidden_windows_paths=[producer_root],
                            )
                        message = str(captured.exception)
                        self.assertIn(
                            "caller-forbidden Windows path 0",
                            message,
                        )
                        self.assertNotIn(producer_root, message)

    def test_forbidden_unc_path_covers_case_and_mixed_separators(self) -> None:
        producer_root = r"\\BuildServer\Artifacts\cargo-home"
        payload = "//buildserver/ARTIFACTS\\CARGO-HOME/registry"
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "unc-root.bin"
            path.write_bytes(payload.encode("utf-16-le"))
            with self.assertRaisesRegex(
                ReleaseBinaryScanError,
                "caller-forbidden Windows path 0",
            ):
                scan_release_file(
                    path,
                    forbidden_windows_paths=[producer_root],
                )

    def test_cli_scans_multiple_files_with_repeated_forbidden_roots(self) -> None:
        roots = (r"C:\Build Roots\cargo-home", r"D:\Toolchains\rust")
        with tempfile.TemporaryDirectory() as temporary:
            directory = pathlib.Path(temporary)
            first = directory / "first.bin"
            second = directory / "second.bin"
            first.write_bytes(b"first-safe-payload")
            second.write_bytes(b"second-safe-payload")
            arguments = [
                "release_binary_scan.py",
                str(first),
                str(second),
                "--forbid-windows-path",
                roots[0],
                "--forbid-windows-path",
                roots[1],
            ]
            stdout = io.StringIO()
            with mock.patch.object(sys, "argv", arguments), redirect_stdout(stdout):
                self.assertEqual(release_binary_scan.main(), 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["status"], "pass")
            self.assertEqual(
                [entry["path"] for entry in payload["files"]],
                [str(first), str(second)],
            )

            second.write_bytes(b"prefix/d/toolchains/RUST/suffix")
            with mock.patch.object(sys, "argv", arguments), self.assertRaises(
                SystemExit
            ) as captured:
                release_binary_scan.main()
            message = str(captured.exception)
            self.assertIn("caller-forbidden Windows path 1", message)
            self.assertNotIn(roots[1], message)

    def test_redacted_cli_preserves_failure_location_without_private_paths_or_bytes(self) -> None:
        with tempfile.TemporaryDirectory(prefix="private-path-sentinel-") as temporary:
            first = pathlib.Path(temporary) / "first.bin"
            second = pathlib.Path(temporary) / "private-file-sentinel.bin"
            first.write_bytes(b"safe")
            second.write_bytes(b"prefix private-content-sentinel suffix")
            arguments = ["release_binary_scan.py", "--redact-paths", str(first), str(second),
                         "--forbid-text", "private-content-sentinel"]
            stdout, stderr = io.StringIO(), io.StringIO()
            with mock.patch.object(sys, "argv", arguments), redirect_stdout(stdout), redirect_stderr(stderr):
                self.assertEqual(release_binary_scan.main(), 1)
            report = json.loads(stderr.getvalue())
            self.assertEqual(report, {"status": "fail", "file_index": 1,
                "reason": "caller-forbidden text 0", "byte_offset": 7,
                "sha256": hashlib.sha256(second.read_bytes()).hexdigest()})
            self.assertEqual(stdout.getvalue(), "")
            for secret in (temporary, "private-file-sentinel", "private-content-sentinel"):
                self.assertNotIn(secret, stderr.getvalue())

            second.unlink()
            stderr = io.StringIO()
            with mock.patch.object(sys, "argv", arguments), redirect_stderr(stderr):
                self.assertEqual(release_binary_scan.main(), 1)
            self.assertEqual(json.loads(stderr.getvalue()), {
                "status": "fail", "file_index": 1, "reason": "scan-input-rejected"})

            second.write_bytes(b"safe again")
            stdout, stderr = io.StringIO(), io.StringIO()
            with mock.patch.object(sys, "argv", arguments), redirect_stdout(stdout), redirect_stderr(stderr):
                self.assertEqual(release_binary_scan.main(), 0)
            report = json.loads(stdout.getvalue())
            self.assertEqual(report["status"], "pass")
            self.assertEqual([row["file_index"] for row in report["files"]], [0, 1])
            self.assertTrue(all(set(row) == {"bytes", "file_index", "sha256"} for row in report["files"]))
            self.assertEqual(stderr.getvalue(), "")
            self.assertNotIn(temporary, stdout.getvalue())

    def test_redacted_windows_findings_identify_nested_roots_without_exposing_them(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "library.bin"
            path.write_bytes(br"prefix C:\Users\private-user\cache\source.c" + b"\0")
            arguments = ["release_binary_scan.py", "--redact-paths", str(path),
                         "--forbid-windows-path", r"C:\Users\private-user",
                         "--forbid-windows-path", r"C:\Users\private-user\cache"]
            stderr = io.StringIO()
            with mock.patch.object(sys, "argv", arguments), redirect_stderr(stderr):
                self.assertEqual(release_binary_scan.main(), 1)
            report = json.loads(stderr.getvalue())
            self.assertEqual(report["matched_windows_paths"], [
                {"index": 0, "byte_offset": 7}, {"index": 1, "byte_offset": 7}])
            self.assertNotIn("private-user", stderr.getvalue())
            self.assertNotIn("source.c", stderr.getvalue())

    def test_archive_diagnostic_locates_metadata_without_disclosing_names_or_admitting_it(self) -> None:
        private = b"C:\\Users\\private-person\\source.c\0"
        coff = (struct.pack("<HHIIIHH", 0x8664, 1, 0, 0, 0, 0, 0)
                + struct.pack("<8sIIIIIIHHI", b".debug$S", 0, 0, len(private), 60, 0, 0, 0, 0, 0x42000040)
                + private)
        def archive(name, payload):
            header = (name.ljust(16) + b"0".ljust(12) + b"0".ljust(6) + b"0".ljust(6)
                      + b"644".ljust(8) + str(len(payload)).encode().ljust(10) + b"`\n")
            return b"!<arch>\n" + header + payload + (b"\n" if len(payload) % 2 else b"")
        cases = ((archive(b"//", private), "long-name-table"),
                 (archive(b"private.obj/", coff), "coff-section"),
                 (b"!<arch>\nmalformed " + private, "unclassified-archive-position"))
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "private-library.lib"
            for data, region in cases:
                with self.subTest(region=region):
                    path.write_bytes(data)
                    stderr = io.StringIO()
                    with mock.patch.object(sys, "argv", ["release_binary_scan.py", "--redact-paths", str(path)]), redirect_stderr(stderr):
                        self.assertEqual(release_binary_scan.main(), 1)
                    report = json.loads(stderr.getvalue())
                    self.assertEqual(report["status"], "fail")
                    self.assertEqual(report["archive_location"]["region"], region)
                    if region == "coff-section":
                        self.assertEqual(report["archive_location"]["section"], ".debug$S")
                    for secret in ("private-person", "private.obj", "private-library", "source.c", temporary):
                        self.assertNotIn(secret, stderr.getvalue())

    def test_credentials_are_rejected_in_both_utf16_encodings_and_alignments(self) -> None:
        cases = {
            "utf16le-even": (
                b"prefix",
                "secret_token=correct-horse-battery-staple".encode("utf-16-le"),
                "UTF-16 named token",
            ),
            "utf16le-odd": (
                b"prefix0",
                "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345".encode("utf-16-le"),
                "UTF-16 GitHub token",
            ),
            "utf16be-even": (
                b"prefix",
                "password=correct-horse-battery-staple".encode("utf-16-be"),
                "UTF-16 named password",
            ),
            "utf16be-odd": (
                b"prefix0",
                "-----BEGIN PRIVATE KEY-----".encode("utf-16-be"),
                "UTF-16 private key marker",
            ),
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            for label, (prefix, secret, expected_message) in cases.items():
                with self.subTest(label=label):
                    path = root / f"{label}.bin"
                    path.write_bytes(prefix + secret + b"suffix")
                    with self.assertRaises(ReleaseBinaryScanError) as captured:
                        scan_release_file(path)
                    self.assertIn(expected_message, str(captured.exception))
                    self.assertNotIn(
                        secret.decode(
                            "utf-16-le" if "utf16le" in label else "utf-16-be"
                        ),
                        str(captured.exception),
                    )

    def test_dense_utf16_sensitive_runs_retain_only_the_earliest_match(self) -> None:
        run_count = 50_000

        class TrackedLabel:
            live = 0
            peak = 0

            def __init__(self) -> None:
                type(self).live += 1
                type(self).peak = max(type(self).peak, type(self).live)

            def __del__(self) -> None:
                type(self).live -= 1

            def __str__(self) -> str:
                return "tracked sensitive run"

        data = b"A\x00\xff\xff" * run_count
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "dense-wide-runs.bin"
            path.write_bytes(data)

            def match_every_run(_projected: bytes):
                return TrackedLabel(), 0

            with (
                mock.patch.object(
                    release_binary_scan,
                    "_first_prefiltered_sensitive_match",
                    side_effect=match_every_run,
                ) as matcher,
                self.assertRaisesRegex(
                    ReleaseBinaryScanError,
                    "tracked sensitive run",
                ),
            ):
                scan_release_file(path)

        self.assertGreaterEqual(matcher.call_count, run_count)
        self.assertLessEqual(TrackedLabel.peak, 4)
        self.assertEqual(TrackedLabel.live, 0)

    def test_utf16_credential_crossing_scan_window_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "wide-boundary.bin"
            text = "A" * 8180 + "bearer ABCDEFGHIJKLMNOP"
            path.write_bytes(text.encode("utf-16-le"))

            with self.assertRaisesRegex(
                ReleaseBinaryScanError, "UTF-16 bearer credential"
            ):
                scan_release_file(path)

    def test_symlinks_and_oversized_files_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            target = root / "target.bin"
            target.write_bytes(b"clean")
            link = root / "link.bin"
            link.symlink_to(target)
            with self.assertRaises(ReleaseBinaryScanError):
                scan_release_file(link)
            with self.assertRaises(ReleaseBinaryScanError):
                scan_release_file(target, maximum=4)

    def test_invalid_caller_forbidden_text_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "library.bin"
            path.write_bytes(b"clean")
            for value in ("", "bad\x00value"):
                with self.subTest(value=value), self.assertRaises(
                    ReleaseBinaryScanError
                ):
                    scan_release_file(path, forbidden_text=[value])

    def test_invalid_forbidden_windows_paths_fail_closed(self) -> None:
        invalid = (
            "",
            "relative\\root",
            "C:\\",
            "\\\\server\\share\\",
            "C:\\non-ascii-路径",
            r"C:\Build\foo\..\temp",
            r"C:\Build\temp.",
            r"\\?\C:\Build\temp",
            r"\\?\UNC\server\share\temp",
            r"\??\C:\Build\temp",
            r"\\server.\share\Build",
            r"\\server\share.\Build",
            "\\\\server\\share \\Build",
            r"\\server\share\Build:stream",
            "C:\\" + "x" * release_binary_scan.MAX_FORBIDDEN_WINDOWS_PATH_CHARS,
        )
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "library.bin"
            path.write_bytes(b"clean")
            for value in invalid:
                with self.subTest(value=value), self.assertRaises(
                    ReleaseBinaryScanError
                ):
                    scan_release_file(path, forbidden_windows_paths=[value])


if __name__ == "__main__":
    unittest.main()
