"""Public proof, original-operation, child-lifetime and native receipt readback."""
from pathlib import Path
import hashlib,json,re,sys
root=Path.cwd();out=Path(__file__).resolve().parent;peer=out/'source';base=out/'public/registration'
sys.path.extend([str(peer),str(out)])
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from source_readback import normalized,EXPECTED,HEAD
from fixture_inputs import load,load_witness_pin
from peer.registration_protocol import Intent
from peer.wire import require,ldh
from peer.bootstrap import digest
from peer.rekey import RekeyScope,genesis
from peer.renewal import verify as verify_grant
from peer.pending_recovery_protocol import Proposal
from peer.witness import Operation,commitment,verify
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):return json.loads(path.read_text())
top=read(base/'RESULT.json');require(top['source_files']==EXPECTED and len(EXPECTED)==99,'registered suite uses final sources');normalized(top['source_files'])
require(sha((out/'public/counterpart').read_bytes())==top['native_sha256']and not(out/'public/registration.stderr').read_bytes(),'actual native/runtime identity')
profiles={}
for label in ['local','witness']:
 folder=base/label;r=read(folder/'RESULT.json');native={};workers={};kills=0
 require(not(folder/'native/native.stderr').read_bytes(),'native diagnostics')
 for row in r['native_commands']:
  name=row['case'];require(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name)is not None and name not in native,'native case identity')
  before=(folder/'native/cases'/(name+'.input')).read_bytes();after=(folder/'native/cases'/(name+'.output')).read_bytes()
  require(sha(before)==row['input_sha256']and sha(after[1:])==row['output_sha256']and after[0]==row['status'],'native raw bytes')
  if after[0]==2:require(after[1:].decode()==row['error'],'actual native error')
  native[name]=(before,after,row['command'])
 for row in r['worker_operations']:
  name=row['case'];request=read(folder/(name+'.request.json'));raw=(folder/(name+'.stdout')).read_bytes();error=(folder/(name+'.stderr')).read_text()
  require(name not in workers and request['action']==row['action'],'worker identity/action');workers[name]=request
  if 'signal'in row:
   kills+=1;require(row['signal']=='SIGKILL'and json.loads(raw)=={'pid':row['worker_pid'],'stage':row['cut']}and not error,'actual PID cut')
  elif 'refused'in row:require(not raw and row['refused']in error,'no output on failure')
  else:require(not error and sha(raw)==row['stdout_sha256'],'worker result bytes')
 require(kills==r['process_kills']==(11 if label=='witness'else 10),'actual process-loss count')
 def result(name):return read(folder/(name+'.stdout'))['result']
 def wire(name):return bytes.fromhex(result(name))
 public=folder/'native/public';pin=load_witness_pin(public)if label=='witness'else None
 pins,materials,ctx=load(public,150,witness_pin=pin)
 intent=Intent.from_trusted((folder/'REGISTRATION_INTENT.bin').read_bytes());request=(folder/'REQUEST.bin').read_bytes()
 identity,key=intent.verify_request(request,150)
 require(intent.root==pins.initiator.root and intent.family==ctx.family and intent.device==pins.initiator.device
         and intent.generation==pins.initiator.generation and intent.validity==ctx.devices[0].validity,'independent approved enrollment scope')
 require(key==ctx.initiator and identity.hex()==r['signing_id']and sha(key.raw)==r['public_sha256']and sha(request)==r['request_sha256'],'native-issued exact device identity')
 first=result('original-provision-recovered')
 require(first['phase']=='Preparing'and first['signing_id']==identity.hex()and first['public_key']==key.raw.hex(),'precommitted original identity before request')
 require(wire('original-request')==wire('exact-request-retry')==request and(folder/'ISSUANCE_READY.bin').read_bytes()==b'\1ready','actual original issuance request')
 require(native['original-issuance-retry']==(request,b'\1'+materials.initiator_credential,38),'genuine retained native credential')
 require(native['different-valid-request-is-not-issuance-retry'][1][0]==2 and native['tampered-original-proof'][1][0]==2,'native rejects substituted proof')
 journal=wire('acceptance-original-retry');prepared=wire('original-child-prepared')
 require(result('accepted-original-status')['journal']==journal.hex()==r['journal']and prepared[:32]==journal
         and prepared==wire('original-child-preparation-retry'),'one original future installation')
 if label=='local':require(len(prepared)==96 and prepared[64:]==ctx.digest,'local original scope')
 else:require(native['independent-original-enrollment']==(prepared,b'\1enrolled',30)and len(prepared)==128,'independent exact genesis enrollment')
 initial=wire('initial');reply=native['reply'][1][1:];final=wire('original-final')
 require(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest,'registered initial signature')
 require(ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',initial),'native reply signature')
 require(final[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',initial)+digest(b'reply-wire',reply),'exact original bootstrap transcript')
 session=digest(b'session-id',final[:104]);require(native['complete'][1]==b'\1'+session and wire('activate')==session and session.hex()==r['session'],'same established session')
 require(wire('original-id').hex()==r['original_id']and sha(wire('original-reserved-resume'))==r['original_ciphertext_sha256'],'original message identity')
 require(wire('reopen-without-issuer-files')==wire('original-message-after-renewal')==wire('original-reserved-resume'),'same original ciphertext across reopen and renewal')
 require(wire('callback-message-after-renewal')==wire('closed-callback-original-recovered')and sha(wire('closed-callback-original-recovered'))==r['callback_ciphertext_sha256'],'original withheld callback result recovered')
 require(native['native-original-receive'][1]==b'\1original registered message'and native['receive-closed-callback-original'][1]==b'\1closed callback original'and native['native-new-receive'][1]==b'\1new registered effect','actual native original/new plaintext')
 flights=[wire('owned-rekey-offer'),native['owned-rekey-response'][1][1:],wire('owned-rekey-final'),native['owned-rekey-receipt'][1][1:]]
 RekeyScope(ctx,session,0,genesis(session,ctx.digest)).public_completed(*flights);require(result('owned-rekey-complete')==1,'owned original signer rekey')
 grant=verify_grant((public/'local-renewal-1').read_bytes(),ctx.devices[0],ctx.family,ctx.policy_digest,(public/'pin-local-renewal-1-target').read_bytes(),now=210)
 require(grant.operation==(public/'local-renewal-1-operation').read_bytes(),'independent root grant identity')
 for tag,count in [('first',1),('callback',2)]:
  require(result('registered-current-ACK-'+tag)==0 and result('registered-ACK-'+tag)==count
          and native['native-original-epoch-ACK-'+tag][0]==bytes(8),'actual old/current epoch acknowledgement distinction')
 names={x['case']for x in r['refusals']}
 require({'wrong-independent-intent','wrong-wrapping-key','response-cannot-choose-current-roster','registration-child-directory-alias',
          'closed-parent-revokes-child','new-parent-does-not-revive-old-child','child-cleanup-error-is-not-success',
          'cleanup-error-cannot-revive-parent','nested-registration-call-refused','close-after-commit-withholds-ciphertext'}<=names,'registered negative control coverage')
 require(result('final-original-registration')['signing_id']==identity.hex()and result('final-original-registration')['journal']==journal.hex(),'final original lineage')
 challenges=set();signed=0;confirmed=0
 if label=='witness':
  subject=prepared[:96];p=Proposal.decode((folder/'registered-pending-request.proposal').read_bytes());metadata=(folder/'registered-pending-request.metadata').read_bytes();p.check_metadata(metadata)
  require(ctx.initiator.open((folder/'registered-pending-request.signed').read_bytes(),26,393)==p.wire(),'registered original historical recovery signature')
  require(wire('registered-confirmation-retry')==p.target.wire(),'exact registered confirmation')
  expected=ldh(b'Q-PERIAPT-CONTINUITY-PENDING-WRITE-RECOVERY/v1',p.wire())+(4).to_bytes(8,'big')*2
  require(native['independent-exact-write-approval']==(p.wire()+metadata,b'\1'+expected,36)and native['independent-exact-write-completion'][1]==b'\1'+p.target.wire(),'separate native exact approval/completion')
  for row in r['witness_attempts']:
   name=row['case'];data=(folder/(name+'.request')).read_bytes();require(sha(data)==row['request_sha256'],'witness request bytes')
   body=ctx.initiator.open(data,7,297);operation=Operation(body[200],body[201:]);command=commitment(b'COMMAND',pin.binding+subject+operation.wire())
   require(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==command and command.hex()==row['command_id']and operation.kind==row['kind'],'original registered witness scope')
   challenge=body[168:200];require(any(challenge)and challenge not in challenges and challenge.hex()==row['challenge'],'fresh challenged request');challenges.add(challenge)
   if row['delivery']=='not_dispatched_by_fixture':require(name not in native and row['fault']=='before','actual withheld request');continue
   require(native[name][0]==data and native[name][2]==31,'genuine native witness dispatch');response=native[name][1]
   require(response[0]==row['native_status'],'native witness status')
   if response[0]==2:require(response[1:].decode()==row['error'],'witness refusal');continue
   reply=(folder/(name+'.reply')).read_bytes();require(reply==response[1:]and sha(reply)==row['signed_reply_sha256'],'signed witness raw bytes')
   verified=verify(pin,subject,operation,body,reply);signed+=1
   if row['delivery']=='sent':require(sha(reply)==row['transport_reply_sha256'],'transport reply identity')
   else:require(row['delivery']=='signed_reply_withheld_by_fixture'and row['fault']=='after','lost reply shape')
   if operation.kind==1 and verified.head==p.target and verified.last==commitment(b'COMMAND',pin.binding+subject+Operation.advance(p.expected,p.target.digest).wire()):p.confirm(verified);confirmed+=1
  require(confirmed>=2 and result('renewal-original-recovered')=='Applied','exact Query-only recovery and original joint renewal')
 else:require(result('renewal-original-recovered')['status']=='Committed','local original renewal')
 profiles[label]={'workers':len(workers),'native_commands':len(native),'actual_SIGKILL':kills,'negative_controls':len(r['refusals']),'signed_witness_replies':signed,'unique_challenges':len(challenges),'exact_recovery_queries':confirmed}
summary={'head':HEAD,'source_files':top['source_files'],'native_sha256':top['native_sha256'],'profiles':profiles,
 'scope':'Public signed registration intent/request, issued credential, original IDs, native bytes, rekey/grants, epoch acknowledgements, fresh signed witness replies and PID cut markers verified. Parent/child private encryption, absence/nonmutation and close-fault assertions remain runtime observations. Fault injection runs real child cleanup then raises OSError; no actual OS cleanup fault or physical erasure/power-loss/PCS claim. Native traffic170; not deployed account authentication or full multidevice lifecycle.'}
(out/'REGISTRATION_READBACK.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(profiles))
