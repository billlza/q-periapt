"""Read public recovery records without loading any private fixture or key."""
from pathlib import Path
import ast
import hashlib
import json
import sys
import subprocess

root=Path.cwd();out=root/'target/independent-installed-hosted-4423-01/mac/public';peer=Path(__file__).resolve().parent/'source'
sys.path.append(str(peer))
sys.path.append(str(out.parent))
from source_readback import source_bytes, normalized, continuity
LANES = {'owner': 'durable-rekey', 'storage': 'storage-cuts', 'base': 'session-recovery', 'maximum': 'resolution-capacity', 'disclosure': 'resolution-disclosure', 'capacity': 'capacity', 'control': 'control', 'resolution': 'resolution', 'rekey': 'rekey', 'exchange': 'exchange', 'witness': 'witness', 'peer-lifecycle': 'peer-lifecycle', 'peer-reply-release': 'peer-reply-release'}
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from fixture_inputs import load
from peer.wire import ldh
from peer.bootstrap import digest as bootstrap_digest
from peer.traffic import message_id
def sha(value):return hashlib.sha256(value).hexdigest()
def check(condition,reason):
    if not condition:raise ValueError(reason)

names=['owner','storage','capacity','base','rekey','exchange']
def lane(name):return LANES[name]
reports={name:json.loads((out/lane(name)/'RESULT.json').read_text())for name in names}
owner=reports['owner'];sources=owner['source_files']
for name,expected in sources.items():
    data=source_bytes(name,expected);check(sha(data)==expected,'source changed: '+name)
    if name.endswith('.py'):ast.parse(data,name)
for name,report in reports.items():
    check(not (out/(lane(name)+'.stderr')).read_bytes(),'run diagnostics: '+name)
    if name!='storage':check(normalized(report.get('source_files',report.get('peer_sources')))==normalized(sources),'source closure differs')
    prefix=out/lane(name)/('cases'if name in ['rekey','exchange']else'native/cases')
    for row in report.get('native_commands',[]):
        before=(prefix/(row['case']+'.input')).read_bytes();after=(prefix/(row['case']+'.output')).read_bytes()
        check(sha(before)==row['input_sha256']and sha(after[1:])==row['output_sha256']and after[0]==row['status'],'native record')
        if row['status']==2:check(after[1:].decode()==row['error'],'native refusal')
    for row in report.get('worker_operations',[]):
        value=(out/lane(name)/(row['case']+'.stdout')).read_bytes();err=(out/lane(name)/(row['case']+'.stderr')).read_text()
        request=json.loads((out/lane(name)/(row['case']+'.request.json')).read_text())
        check(request['action']==row['action'],'worker action')
        if 'signal'in row:
            check(row['signal']=='SIGKILL'and json.loads(value)=={'pid':row['worker_pid'],'stage':row['cut']}and not err,'worker PID/cut')
        elif 'refused'in row:check(not value and row['refused']in err,'worker refusal output')
        else:check(sha(value)==row['stdout_sha256']and not err,'worker result hash')
check(len(owner['epochs'])==8 and len(owner['worker_operations'])==150 and owner['process_kills']==11
      and len(owner['native_commands'])==75 and owner['signed_send_budget']==4,'owner workload')
store=reports['storage'];check(store['process_kills']==19 and len(store['results'])==46,'store workload')
markers=[json.loads(p.read_text())for p in (out/'storage-cuts').glob('*.stage')]
check(len(markers)==19 and sorted(m['pid']for m in markers)==sorted(store['killed_worker_pids']),'store worker identity')
check(len(reports['base']['worker_operations'])==27 and reports['base']['process_kills']==6,'base recovery workload')
check(len(reports['rekey']['native_commands'])==132 and len(reports['rekey']['refusals'])==108,'computation workload')
check(len(reports['exchange']['native_commands'])==41 and len(reports['exchange']['python_refusals'])==51,'bootstrap workload')
native=out/'counterpart'
binary=native.read_bytes();check(sha(binary)==owner['native_sha256'],'native binary changed')
check(binary[:4]==b'\xcf\xfa\xed\xfe'and int.from_bytes(binary[4:8],'little')==0x100000c,'native ARM64 MachO')

folder=out/'durable-rekey';cases=folder/'native/cases';_,_,ctx=load(folder/'native/public',150)
check(ctx.send_budget==4,'actual signed policy budget')
def worker(name):return json.loads((folder/(name+'.stdout')).read_text())['result']
def wire(name):return bytes.fromhex(worker(name))
def request(name):return json.loads((folder/(name+'.request.json')).read_text())
initial=wire('original-initial');reply=(cases/'bootstrap-response.output').read_bytes()[1:];final=wire('bootstrap-final')
session=(cases/'bootstrap-complete.output').read_bytes()[1:]
check(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest,'bootstrap initial')
check(ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+bootstrap_digest(b'initial-wire',initial),'bootstrap response')
check(final[:104]==b'QPBSF001'+ctx.digest+bootstrap_digest(b'initial-wire',initial)+bootstrap_digest(b'reply-wire',reply)
      and session==bootstrap_digest(b'session-id',final[:104]),'bootstrap transcript')
check(worker('upgrade-reconciled')==worker('expired-upgrade-status')==5,'upgrade disposition')
check(worker('asymmetric-progress')==[0,1,0,1]and worker('publication-recovered')==[2,2,2,3],'asymmetric/pending progress')
domain=b'Q-PERIAPT-CONTINUITY-REKEY-CANDIDATE/v1/'
def h(label,value):return ldh(domain+label,value)
profile=h(b'offer-profile',b'ML-KEM-768+X25519/ContextBound;ML-DSA-65+P-256/SHA-256;accountable-epoch-ratchet/v6;messages/v3;retained-epochs=4;settled-prefix-attestation/v1;application-send-budget/v1;control-request/v1')
parent=h(b'genesis',session+ctx.digest)
for epoch in range(1,9):
    label=f'epoch-{epoch}-';proposer=1 if epoch%2 else 2
    if epoch%2:wires=[wire(label+'offer'),(cases/(label+'response.output')).read_bytes()[1:],wire(label+'final'),(cases/(label+'receipt.output')).read_bytes()[1:]]
    else:wires=[(cases/(label+'offer.output')).read_bytes()[1:],wire(label+'response'),(cases/(label+'final.output')).read_bytes()[1:],wire(label+'receipt')]
    bodies=[]
    for flight,(control,tag,size)in enumerate(zip(wires,[b'QPRKOF01',b'QPRKRP01',b'QPRKFN01',b'QPRKRC01'],[1369,1337,257,289],strict=True)):
        role=proposer if flight in [0,2]else 3-proposer
        body=(ctx.initiator if role==1 else ctx.responder).open(control,9+flight,size)
        check(body[:153]==tag+profile+ctx.digest+session+(epoch-1).to_bytes(8,'big')+epoch.to_bytes(8,'big')+bytes([role])+parent,'rekey signed scope')
        check(wire(label+f'outbox-{flight}')==control,'recovered control changed')
        bodies.append(body)
    ho,hr,hf=h(b'offer-wire',wires[0]),h(b'response-wire',wires[1]),h(b'final-wire',wires[2])
    check(bodies[1][153:185]==ho and bodies[2][153:217]==ho+hr and bodies[3][153:249]==ho+hr+hf,'rekey wire commitments')
    expected=(2,0)if epoch==1 else(1,3)if epoch==2 else(1,1)
    check(tuple(int.from_bytes(b[-40:-32],'big')for b in bodies[2:])==expected,'signed closing counts')
    parent=h(b'completed-epoch',b''.join(wires))
    check(worker(label+'progress')==[epoch,epoch,epoch,0],'completed progress')
    reverse=request(label+'reverse-receive');frame=bytes.fromhex(reverse['arguments'][0])
    check(frame[:41]==b'QPCMSG03'+session+b'\2'and frame[41:49]==epoch.to_bytes(8,'big')
          and frame[57:89]==message_id(session,2,0,epoch),'new epoch frame')
    check(worker(label+'reverse-receive')==[message_id(session,2,0,epoch).hex(),(bytes(range(256))*64).hex()],'application plaintext')
check(wire('retained-old-outbox')==wire('old-unacknowledged-send'),'old retained ciphertext')
check(bytes.fromhex(request('recover-old-ACK')['arguments'][0])==(cases/'old-unacknowledged-consume.output').read_bytes()[1:],'original ACK recovery')
check(worker('retired-old-status')=='Retired'and worker('expired-progress')==[8,8,8,0],'retirement/expiry status')
check(wire('budget-blocked-id')==wire('budget-slot-preserved')==message_id(session,1,2,1),'budget rejection used slot')
check(request('budget-before-receipt')['arguments']==request('budget-after-ACK')['arguments'],'budget retry input')
check((cases/'closed-release-receive.output').read_bytes()==b'\1committed before close','closed commit recovery')

green=reports['capacity']['admission']
check(green['head_unchanged']and green['final_row_excess']==113,'capacity pre-commit admission')
check(green['pending_plaintext_bytes']==13700 and reports['capacity']['exact_fit_plaintext_bytes']==13587,'exact capacity workload')
check(reports['capacity']['full_size_outbox_messages']==122 and reports['capacity']['exact_fit_committed_and_reopened'],'actual capacity state')
report={'head':'44233741fd28d89b0dd2f30e59baf256cc1b55eb','source_files':sources,'source_continuity':continuity(sources),'native_sha256':owner['native_sha256'],
        'native_architecture':'MachO64 ARM64','provider':owner['provider'],
        'owner':{'epochs':8,'worker_operations':150,'process_kills':11,'native_commands':75,'signed_budget':4,'signed_flights':32},
        'store':{'process_kills':19,'controls':46},'capacity':{'messages':122,'reservation_plaintext':13700,'exact_fit_plaintext':13587,'capacity_boundary_replayed':True},
        'regressions':{'bootstrap_native':41,'bootstrap_refusals':51,'rekey_native':132,'rekey_refusals':108,'base_workers':27,'base_kills':6,'base_native':9},
        'upgrade_from_archived_writer':owner['old_codec_sha256'],'local_red_records':'separate 20261018-independent-durable-rekey capture',
        'limits':['public readback does not load private images or rederive private MAC/AEAD keys',
                  'native counterpart remains the same process; independent workers restart',
                  'fixed-authority local-only owner; no required witness, renewal/revocation or network scheduler',
                  'no hardware power-loss, erasure, PCS proof, installed independent product or complete lifecycle admission']}
(out.parent/'REGRESSION_READBACK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['source_files','limits']}))
