from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
out=Path(__file__).resolve().parent; root=out.parent.parent
s=json.loads((out/'STATE.json').read_text());work=Path(s['work']);consumer=Path(s['consumer'])
label,mode,*patterns=sys.argv[1:];run=out/label;run.mkdir()
for folder in ['src','tests']:
 shutil.copytree(root/'bindings/c/ContinuityPackageConsumer'/folder,consumer/folder,dirs_exist_ok=True)
version='1.90.0' if mode.startswith('msrv') else '1.98.1'
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/(version+'-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/('build-msrv' if mode.startswith('msrv') else 'build')),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
command='clippy' if mode.endswith('clippy') else 'test'
args=[str(tc/'bin/cargo'),command,'--manifest-path',str(consumer/'Cargo.toml'),'--all-features','--locked','--offline','-j','2']
if command=='clippy':args+=['--all-targets']
else:
 args+=['--lib']
 if mode=='release':args+=['--release']
 if patterns:args+=[patterns[0]]
 args+=['--','--nocapture','--test-threads=1']
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob('*') if p.is_file()}
r={'command':args,'mode':mode,'native_archive':json.loads((out/'package-result.json').read_text())['archive'],'files':files,'completed':False}
(run/'START.json').write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
with (run/'stdout').open('wb') as so,(run/'stderr').open('wb') as se:
 process=subprocess.run(args,cwd=consumer,env=env,stdout=so,stderr=se,timeout=1800)
r.update(returncode=process.returncode,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items()))
r['completed']=process.returncode==0 and r['source_unchanged'];(run/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='files'}));print((run/'stdout').read_text()[-2200:]);print((run/'stderr').read_text()[-4500:]);sys.exit(0 if r['completed'] else 1)
