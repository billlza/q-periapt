from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys,tarfile
out=Path(__file__).resolve().parent
s=json.loads((out/'STATE.json').read_text()); work=Path(s['work']); native=Path(s['producer']); consumer=Path(s['consumer'])
assert subprocess.check_output(['git','status','--porcelain'],cwd=native)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()==s['native_head']
source=work/'source'; candidate=source/'research/continuity-identity-candidate'
shutil.copytree(native/'research/continuity-identity-candidate',candidate)
patches=[]
for pkg in sorted((consumer/'packages').iterdir()):
 name=pkg.name.removesuffix('-0.2.0'); dst=source/'crates'/name
 shutil.copytree(pkg,dst)
 patches.extend(['--config',f'patch.crates-io.{name}.path='+json.dumps(str(dst))])
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_'))}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/'build'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
cmd=[str(tc/'bin/cargo'),'package','--manifest-path',str(candidate/'Cargo.toml'),'--locked','--offline','--all-features',*patches,'-j','2']
start=time.monotonic(); (out/'package-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'package.stdout').open('wb') as so,(out/'package.stderr').open('wb') as se:
 r=subprocess.run(cmd,cwd=source,env=env,stdout=so,stderr=se,timeout=1800)
result={'returncode':r.returncode,'seconds':time.monotonic()-start,'native_head':s['native_head']}
if r.returncode==0:
 archive=work/'build/package/q-periapt-continuity-identity-candidate-0.0.0.crate'
 result['archive']={'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
 sys.path.insert(0,str(native/'artifact'))
 import continuity_package as cp
 listed=subprocess.check_output(cmd[:-2]+['--list'],cwd=source,env=env,text=True).splitlines()
 files=cp.validate_candidate(archive.read_bytes(),set(listed))
 dest=consumer/'packages/q-periapt-continuity-identity-candidate-0.0.0'
 for rel,data in files.items():
  p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 result['source_files_verified']=len(files)
(out/'package-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));print((out/'package.stderr').read_text()[-2000:]);sys.exit(r.returncode)
