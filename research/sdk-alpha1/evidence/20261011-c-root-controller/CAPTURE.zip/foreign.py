from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parent.parent
s=json.loads((out/'STATE.json').read_text());work=Path(s['work']);consumer=Path(s['consumer'])
profile=sys.argv[1];runout=out/('foreign-'+profile);runout.mkdir()
for name in ['qpc_owner.h','root_contract_client.c']:shutil.copyfile(root/'bindings/c/ContinuityPackageConsumer'/name,consumer/name)
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_')) and k not in ('CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','SDKROOT','MACOSX_DEPLOYMENT_TARGET')}
env.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(work/'build'),RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'))
sys.path.insert(0,str(root/'artifact'))
import rust_sdk_profile as sdk, continuity_c_consumer as c, continuity_c_root_contract as contract
runtime={k:v for k,v in env.items() if not k.startswith(('DYLD_','LD_'))}
def run(argv,label,*,runtime=None):
 return sdk.command(argv,runout/label,consumer,environment=env if runtime is None else runtime)
files={str(p.relative_to(consumer)):hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.rglob('*') if p.is_file()}
(runout/'START.json').write_text(json.dumps({'files':files,'profile':profile},indent=2)+'\n')
filename='libq_periapt_continuity_c_consumer.dylib';extra=['--release'] if profile=='release' else []
run([str(tc/'bin/cargo'),'rustc','--locked','--offline','--lib','-j','2',*extra,'--','-C','link-arg=-Wl,-install_name,@rpath/'+filename],'library')
installed=work/('root-installed-'+profile);installed.mkdir(mode=0o700)
shutil.copyfile(work/'build'/profile/filename,installed/filename)
exports=run(['/usr/bin/nm','-gU',str(installed/filename)],'exports').decode()
actual={line.split()[-1].removeprefix('_') for line in exports.splitlines() if line.strip()}
assert actual==c.EXPORTS,(actual-c.EXPORTS,c.EXPORTS-actual)
cc=Path(run(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],'clang-path').decode().strip()).resolve()
sysroot=run(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],'sdk-path').decode().strip()
result=contract.qualify(consumer,installed,cc,['-isysroot',sysroot],profile,run,darwin=True,runtime=runtime,filename=filename)
result['exports']=len(actual);result['files_unchanged']=all(hashlib.sha256((consumer/f).read_bytes()).hexdigest()==h for f,h in files.items())
assert result['files_unchanged']
(runout/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
