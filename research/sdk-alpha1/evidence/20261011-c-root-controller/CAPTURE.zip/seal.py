from pathlib import Path
import hashlib,json,re,subprocess,zipfile
out=Path(__file__).resolve().parent;root=out.parent.parent;base=root/'bindings/c/ContinuityPackageConsumer'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='a3147978761ab6cd29b7b320032dea8370eb3244'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
checks=[]
for label,count in [('exact-source-admission',55),('minimum-root',7),('release-root',7),('final-clippy',None),('minimum-clippy',None)]:
 r=json.loads((out/label/'RESULT.json').read_text());assert r['completed'] and r['source_unchanged'] and r['returncode']==0
 for name,h in r['files'].items():
  if name.startswith(('src/','tests/')):assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h,(label,name)
 if count is not None:assert re.search(rf'test result: ok\. {count} passed; 0 failed; 0 ignored;', (out/label/'stdout').read_text())
 checks.append({'label':label,'command':r['command'],'seconds':r['seconds'],'tests':count,'completed':True,'source_matches_implementation':True})
foreign={}
for profile in ('debug','release'):
 label='foreign-'+profile;r=json.loads((out/label/'RESULT.json').read_text());assert r['completed'] and r['files_unchanged'] and r['exports']==151
 assert r['header_sha256']==hashlib.sha256((base/'qpc_owner.h').read_bytes()).hexdigest()
 assert r['source_sha256']==hashlib.sha256((base/'root_contract_client.c').read_bytes()).hexdigest()
 foreign[profile]=r
for label,count in [('codeql-tests',44),('consumer-tests',13),('package-tests',15)]:
 text=(out/(label+'.stderr')).read_text();assert f'Ran {count} tests' in text and text.rstrip().endswith('OK')
assert (out/'source-gate.stdout').read_text().startswith('SDK_SOURCE_READINESS_PASS profile=sdk-020 commit='+head)
assert json.loads((out/'installed-rustfmt.json').read_text())['returncode']==0
native=json.loads((out/'package-result.json').read_text());assert native['returncode']==0 and native['source_files_verified']==425
archive=Path(native['archive']['path']);assert hashlib.sha256(archive.read_bytes()).hexdigest()==native['archive']['sha256']
assert subprocess.check_output(['git','diff',native['native_head'],head,'--','crates','research/continuity-identity-candidate'],cwd=root)==b''
state=json.loads((out/'STATE.json').read_text());state.update(phase='C root controller component qualified locally; compiled-C full lifecycle and language integration remain open',local_producers_running=False,source_gate=True,source_gate_commit=head);(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
dest=root/'research/sdk-alpha1/evidence/20261011-c-root-controller';dest.mkdir()
files={}
for path in sorted(out.rglob('*')):
 if path.is_file() and path.suffix in {'.json','.stdout','.stderr','.py','.patch'} or path.is_file() and path.name in {'stdout','stderr'}:
  assert not path.is_symlink();files[path.relative_to(out).as_posix()]=path.read_bytes()
files['native-archive/'+archive.name]=archive.read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
cap=dest/'CAPTURE.zip'
with zipfile.ZipFile(cap,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(cap) as z:
 assert set(z.namelist())==set(files)
 for name,details in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==details['sha256']
report={'schema':1,'implementation_commit':head,'release_claim_eligible':False,
 'scope':'Unpublished qpc-owner/1 managed root controller, installed native archive; Rust-driven C entry lifecycle and separately compiled C guarded-option contracts. Not full compiled-C lifecycle, other-language or full release qualification.',
 'behavior':['Existing registry handle owns native managed root replacement and retains read access; actual enrolled device is transferred once and idle shared references are closed.',
 'Paired handles share one nonblocking admission, deadline and call-local cancellation. Cancellation of either handle interrupts the real target witness socket; processed-request cancellation retains witness-unknown code 218.',
 'Original resume, separately approved next-target transition and independently committed winner adoption use native proofs and original storage. No invented winner plan or replacement state.',
 'Existing retired reporting, independent host ACK, journal and signer erasure methods accept the committed root controller. Successful old signer erasure preserves successor authority; admitted cleanup error or controller close revokes it.'],
 'validation':checks,'compiled_c_contract':foreign,'candidate_c_exports':151,'new_c_exports':11,'tracked_rust_sources':544,
 'tool_tests':{'codeql_inventory':44,'c_consumer_collector':13,'package_collector':15},
 'source_gate':(out/'source-gate.stdout').read_text().strip(),'installed_rustfmt':True,
 'native_package':native,'sdk_archives_provenance':state['SDK_archives_provenance'],
 'native_and_sdk_sources_unchanged_through_implementation':True,
 'maintainability':{'root_adapter_files':{'root_replacement.rs':351,'alternative.rs':165,'paired.rs':68,'recovery.rs':47,'cleanup.rs':48},'new_native_state_machine':False,'performance_improvement_measured':False},
 'development_failures':'Captured initial failures include a missing private fixture directory, a test incorrectly expecting pre-dispatch cancellation for an already processed witness request, prohibited target-root reuse in a new preparation, and double close in a test helper. These were fixture/expectation corrections, not a claimed product vulnerability red/green.',
 'limitations':['Same-host macOS arm64, same native engine. No Intel Mac support added.',
 'Compiled C program validates layouts/short options with protected pages and installed-library linkage only. Complete compiled C root lifecycle, process cuts and default foreign stack qualification remain open.',
 'Swift/Kotlin root-controller integration, independent endpoint/implementation, physical current/minimum devices, external security review, broader proof/performance/upgrade and full release gates remain open.',
 'No Android emulator investigation or new physical-device stability claim. Existing failed jobs stay failed.',
 'No merge, release, registry publication, or remote push in this component. CodeQL run 38122738417 at remote 3b654771 was still running in the captured snapshot.'],
 'capture':{'file':'CAPTURE.zip','bytes':cap.stat().st_size,'members':len(files),'sha256':hashlib.sha256(cap.read_bytes()).hexdigest()}}
(dest/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'implementation_commit':head,'capture':report['capture'],'checks':str(dest/'CHECKS.json')}))
