from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT=Path.cwd()
BASE=Path(__file__).resolve().parent
OUT=BASE/'debug-roster-capacity-01'
OUT.mkdir()
sys.path.insert(0,str(ROOT/'artifact'))
from bounded_process import capture_output,TimeoutPolicy
binary=ROOT/'target/continuity-managed-maintenance/candidate-build/debug/deps/q_periapt_continuity_identity_candidate-ff34d34402dcdeed'
name='enrollment::tests::witness_renewal::account_renewal::roster::native_common_account_roster_capacity_original_owners_after_complete_g'
listed=subprocess.run([str(binary),'--list','--exact',name],capture_output=True,check=True,timeout=30)
assert listed.stdout.decode().splitlines()[0]==name+': test'
(OUT/'SELECTED_TEST.txt').write_bytes(listed.stdout)
build=json.loads((BASE/'check-02/NATIVE_BUILD_RESULT.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(ROOT/n)==v for n,v in build['source_files'].items())
chain=Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
env=dict(os.environ)
env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
           CARGO_TARGET_DIR=str(ROOT/'target/continuity-managed-maintenance/candidate-build'),
           CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),
           PATH=str(chain)+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),RUSTFLAGS='-D warnings')
state={'completed':False,'passed':False,'release_claim_eligible':False,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
       'source_files':build['source_files'],'binary_sha256':sha(binary),'command':[str(binary),'--exact',name,'--nocapture'],
       'timeout_seconds':5400,'budget_reference':'.github/workflows/ci.yml original 90-minute roster-capacity job; per-attempt 3-second limit unchanged',
       'started_utc':datetime.now(timezone.utc).isoformat(),'scope':'Local Debug execution of the exact 32-member test that failed on hosted Linux Rust 1.90; platform/compiler differences remain explicit.'}
(OUT/'INPUTS.json').write_text(json.dumps(state,indent=2)+'\n')
started=time.monotonic()
try:
    with (OUT/'runtime.stdout').open('xb',buffering=0) as out,(OUT/'runtime.stderr').open('xb',buffering=0) as err:
        result=capture_output(state['command'],timeout_seconds=5400,timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
                              maximum_stdout_bytes=16*1024*1024,maximum_stderr_bytes=16*1024*1024,
                              environment=env,stdout_sink=out.write,stderr_sink=err.write)
    state.update(completed=True,returncode=result.returncode)
    if result.returncode!=0:raise RuntimeError('Debug roster-capacity test failed; original output retained')
    text=result.stdout.decode()
    assert re.findall(r'^test (.+?) \.\.\. ok$',text,re.M)==[name]
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text
    assert sha(binary)==state['binary_sha256'] and all(sha(ROOT/n)==v for n,v in state['source_files'].items())
    state['passed']=True
except BaseException as error:
    state.update(error_type=type(error).__name__,error=str(error))
    raise
finally:
    state.update(elapsed_seconds=time.monotonic()-started,finished_utc=datetime.now(timezone.utc).isoformat())
    with (OUT/'RESULT.json').open('x') as f:json.dump(state,f,indent=2);f.write('\n')
    print(json.dumps({k:state.get(k) for k in ('completed','passed','returncode','elapsed_seconds','error')}),flush=True)

