from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent / 'check-02'
OUT.mkdir()
sys.path.insert(0, str(ROOT / 'artifact'))
from bounded_process import capture_output
env = dict(os.environ)
env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
           CARGO_TARGET_DIR=str(ROOT / 'target/continuity-managed-maintenance/candidate-build'),
           CARGO_BUILD_JOBS='2', RUSTFLAGS='-D warnings',
           OPENSSL_DIR='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed',
           OPENSSL_STATIC='0')
cargo = '/Users/bhmq03@durham.ac.uk/.cargo/bin/cargo'
manifest = 'research/continuity-identity-candidate/Cargo.toml'
commands = [('fmt-check', [cargo, '+1.98.1', 'fmt', '--manifest-path', manifest, '--all', '--', '--check']),
            ('identity-debug', [cargo, '+1.98.1', 'test', '--manifest-path', manifest, '--locked', '--offline', '--lib', '--features', 'anchor-tls,control-tls,connection-tls', 'identity::', '--', '--nocapture']),
            ('native-build', [cargo, '+1.98.1', 'build', '--manifest-path', 'research/continuity-openssl-peer/native/Cargo.toml', '--locked', '--offline', '--release'])]
sources = ['research/continuity-identity-candidate/src/identity.rs',
           'research/continuity-identity-candidate/src/identity/renewal.rs',
           'research/continuity-identity-candidate/src/identity/renewal/tests.rs']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {name: sha(ROOT / name) for name in sources}
rows = []
for name, command in commands:
    started = time.monotonic()
    row = {'name':name,'command':command,'completed':False,'started_utc':datetime.now(timezone.utc).isoformat()}
    try:
        with (OUT / (name + '.stdout')).open('xb', buffering=0) as out, (OUT / (name + '.stderr')).open('xb', buffering=0) as err:
            result = capture_output(command, timeout_seconds=900, maximum_stdout_bytes=16 * 1024 * 1024,
                                    maximum_stderr_bytes=16 * 1024 * 1024, environment=env,
                                    stdout_sink=out.write, stderr_sink=err.write)
        row.update(completed=True,returncode=result.returncode)
        if result.returncode != 0: raise RuntimeError(name + ' failed; retained output')
        if name == 'identity-debug':
            assert b'test result: ok. 12 passed; 0 failed; 0 ignored;' in result.stdout
    except BaseException as error:
        row.update(error_type=type(error).__name__,error=str(error)); raise
    finally:
        row.update(elapsed_seconds=time.monotonic()-started,finished_utc=datetime.now(timezone.utc).isoformat())
        with (OUT / (name + '.json')).open('x') as f:json.dump(row,f,indent=2);f.write('\n')
        rows.append(row);print(json.dumps(row),flush=True)
assert {name:sha(ROOT / name) for name in sources} == before
binary = Path(env['CARGO_TARGET_DIR']) / 'release/q-periapt-independent-peer-counterpart'
record = {'commands':rows,'source_files':before,'binary':str(binary),'binary_sha256':sha(binary),
          'instrumented':False,'scope':'Current-source native counterpart build; runtime qualification is separate.'}
with (OUT / 'NATIVE_BUILD_RESULT.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'native_sha256':record['binary_sha256'],'instrumented':False}),flush=True)
