"""Run the original four-profile workload with cooperative owner cancellation."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ('cancel', 'full')
budget = 2 if mode == 'cancel' else 900
OUT = BASE / ('parallel-cancel-01' if mode == 'cancel' else 'parallel-full-01')
OUT.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
build = json.loads((BASE / 'check-02/NATIVE_BUILD_RESULT.json').read_bytes())
NATIVE = Path(build['binary'])
assert build['instrumented'] is False and sha(NATIVE) == build['binary_sha256']
assert all(sha(ROOT / name) == value for name,value in build['source_files'].items())
assert 'QPC_SIGNATURE_OBSERVATION' not in os.environ
PEER = ROOT / 'research/continuity-openssl-peer'
baseline = json.loads((ROOT / 'target/continuity-independent-macos-failure/INPUTS.json').read_bytes())
assert all(sha(PEER / name) == value for name,value in baseline['source_files'].items())
PROVIDER = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
sys.path.insert(0,str(PEER))
from qperiapt_continuity_reference.provider import load_provider
crypto, backend = load_provider(PROVIDER)
assert baseline['provider'] == {'cryptography':crypto.__version__,'openssl':backend.openssl_version_text()}
from run import Counterpart
from session_driver import SessionDriver
import policy_composition_checks as composition
state = {'mode':mode,'runtime_profiles_passed':False,'deadline_cleanup_control_passed':False,
         'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
         'native_sha256':sha(NATIVE),'source_files':build['source_files'],
         'python_and_native_controller_sources':baseline['source_files'],'provider':baseline['provider'],
         'budget_seconds':budget,'native_exchange_seconds':30,'worker_seconds':30,'workers':2,
         'started_utc':datetime.now(timezone.utc).isoformat(),'profile_outcomes':[],
         'scope':'Original four-profile/two-worker composition with unchanged native and worker deadlines. A total acceptance deadline cancels cooperatively at existing operation boundaries; fixture-owned cleanup remains responsible for its process groups. No generic detached-tree cleanup or hard 900-second wall-clock kill claim.'}
(OUT/'INPUTS.json').write_text(json.dumps(state,indent=2)+'\n')
events=(OUT/'timing.jsonl').open('x',buffering=1)
lock=threading.Lock()
stop=threading.Event()
native_owners=[]
observations=0
deadline=0.0
interrupted=[]
def emit(value):
    global observations
    with lock:
        if observations>=8192:raise RuntimeError('timing observation capacity exceeded')
        events.write(json.dumps(value,sort_keys=True)+'\n');observations+=1
def require_budget():
    if stop.is_set() or time.monotonic()>=deadline:
        stop.set()
        raise TimeoutError('composition total acceptance budget expired')
initialize,transfer,worker,profile=Counterpart.__init__,Counterpart.transfer,SessionDriver.run,composition.run_profile
def observed_initialize(self,*args,**kwargs):
    require_budget()
    initialize(self,*args,**kwargs)
    # Return the initialized owner even if the budget just expired: Fixture must
    # first receive it, so its existing exception path can close that owner.
    with lock:native_owners.append(self)
    try:emit({'event':'native-start','pid':self.process.pid,'unix_ns':time.time_ns()})
    except BaseException:
        self.close()
        raise
def observed_transfer(self,data):
    require_budget()
    started=time.monotonic()
    item={'pid':self.process.pid,'first_byte':data[0],'request_bytes':len(data),
          'request_sha256':hashlib.sha256(data).hexdigest(),'started_unix_ns':time.time_ns()}
    emit({'event':'transfer-start',**item})
    try:
        reply=transfer(self,data)
        item.update(reply_bytes=len(reply),reply_sha256=hashlib.sha256(reply).hexdigest())
        require_budget()
        return reply
    except BaseException as error:
        item.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:emit({'event':'transfer-end',**item,'elapsed_seconds':time.monotonic()-started})
def observed_worker(self,*args,**kwargs):
    require_budget()
    value=worker(self,*args,**kwargs)
    require_budget()
    return value
def observed_profile(args,members,witnessed):
    row={'members':members,'witnessed':witnessed,'entered':False,'completed':False}
    try:
        require_budget()
        row['entered']=True
        result=profile(args,members,witnessed)
        require_budget()
        row['completed']=True
        return result
    except BaseException as error:
        row.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:
        with lock:state['profile_outcomes'].append(row)
Counterpart.__init__,Counterpart.transfer,SessionDriver.run,composition.run_profile=observed_initialize,observed_transfer,observed_worker,observed_profile
def alarm(number,_frame):
    if number!=signal.SIGALRM:interrupted.append(number)
    stop.set()
assert signal.getitimer(signal.ITIMER_REAL)==(0.0,0.0)
previous={n:signal.getsignal(n) for n in (signal.SIGALRM,signal.SIGTERM,signal.SIGHUP)}
for number in previous:signal.signal(number,alarm)
started=time.monotonic()
deadline=started+budget
signal.setitimer(signal.ITIMER_REAL,budget)
error=None
try:
    profiles=composition.run_profiles(SimpleNamespace(output=OUT,native=NATIVE,provider_root=PROVIDER))
    require_budget()
    assert mode=='full','the deliberate cancellation did not fire'
    assert {(r['members'],r['witnessed']) for r in profiles}=={(3,False),(3,True),(32,False),(32,True)}
    state['profiles']=profiles
    state['runtime_profiles_passed']=True
except BaseException as failure:
    error=failure
    state.update(error_type=type(failure).__name__,error=str(failure))
finally:
    signal.setitimer(signal.ITIMER_REAL,0)
    for number,handler in previous.items():signal.signal(number,handler)
    Counterpart.__init__,Counterpart.transfer,SessionDriver.run,composition.run_profile=initialize,transfer,worker,profile
    events.close()
    state['native_cleanup']=[{'pid':owner.process.pid,'returncode':owner.process.poll()} for owner in native_owners]
    live=[owner for owner in native_owners if owner.process.returncode is None]
    state['unexpected_live_native_owners']=len(live)
    for owner in live:owner.close()
    state.update(deadline_triggered=stop.is_set(),external_interrupts=interrupted,
                 elapsed_seconds=time.monotonic()-started,finished_utc=datetime.now(timezone.utc).isoformat(),
                 observation_rows=observations,timing_sha256=sha(OUT/'timing.jsonl'))
    unchanged=sha(NATIVE)==build['binary_sha256'] and all(sha(ROOT/n)==v for n,v in build['source_files'].items())
    unchanged=unchanged and all(sha(PEER/n)==v for n,v in baseline['source_files'].items())
    state['sources_unchanged']=unchanged
    clean=not live and all(row['returncode'] is not None for row in state['native_cleanup'])
    state['native_cleanup_complete']=clean
    state['runtime_profiles_passed']=state['runtime_profiles_passed'] and clean and unchanged and not interrupted
    if mode=='cancel':
        state['deadline_cleanup_control_passed']=(
            isinstance(error,TimeoutError) and str(error)=='composition total acceptance budget expired'
            and stop.is_set() and len(native_owners)==2 and clean and unchanged and not interrupted
            and len(state['profile_outcomes'])==4
            and sum(r['entered'] for r in state['profile_outcomes'])==2
            and all(not r['completed'] and r.get('error')=='composition total acceptance budget expired' for r in state['profile_outcomes']))
    with (OUT/'RESULT.json').open('x') as out:json.dump(state,out,indent=2);out.write('\n')
    print(json.dumps({k:state[k] for k in ('mode','runtime_profiles_passed','deadline_cleanup_control_passed','elapsed_seconds','native_cleanup','sources_unchanged')}),flush=True)
if mode=='full' and not state['runtime_profiles_passed']:
    if error is not None:raise error
    raise RuntimeError('full composition validation failed')
if mode=='cancel' and not state['deadline_cleanup_control_passed']:
    if error is not None:raise error
    raise RuntimeError('deadline cleanup control failed')

