from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import sys
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent / 'full-release-01'
OUT.mkdir()
sys.path.insert(0, str(ROOT / 'artifact'))
from bounded_process import capture_output, TimeoutPolicy
chain = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin')
binary = ROOT / 'target/continuity-managed-maintenance/candidate-build/release/deps/q_periapt_continuity_identity_candidate-d3eb26eb6c704353'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = ['research/continuity-identity-candidate/src/identity.rs',
           'research/continuity-identity-candidate/src/identity/renewal.rs',
           'research/continuity-identity-candidate/src/identity/renewal/tests.rs']
before = {name: sha(ROOT / name) for name in sources}
expected = [line.removesuffix(': test') for line in (OUT.parent / 'RELEASE_TESTS.txt').read_text().splitlines() if line.endswith(': test')]
assert len(expected) == len(set(expected)) == 1461
env = dict(os.environ)
env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
           CARGO_TARGET_DIR=str(ROOT / 'target/continuity-managed-maintenance/candidate-build'),
           CARGO=str(chain / 'cargo'), RUSTC=str(chain / 'rustc'), RUSTDOC=str(chain / 'rustdoc'),
           PATH=str(chain) + ':' + env['PATH'], DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent / 'lib'),
           CARGO_BUILD_JOBS='2', RUSTFLAGS='-D warnings')
record = {'completed': False, 'passed': False, 'release_claim_eligible': False,
          'scope': 'Full local candidate library Release regression with the existing CI release-job 90-minute budget; no platform or final release acceptance.',
          'command': [str(binary), '--nocapture'], 'binary_sha256': sha(binary),
          'source_files': before, 'expected_tests': len(expected), 'timeout_seconds': 5400,
          'budget_reference': '.github/workflows/ci.yml continuity-identity-candidate timeout-minutes: 90; unfiltered Release partition',
          'started_utc': datetime.now(timezone.utc).isoformat()}
with (OUT / 'INPUTS.json').open('x') as f: json.dump(record, f, indent=2); f.write('\n')
started = time.monotonic()
try:
    # Directly own the actual test process group. No outer wrapper kills an
    # intermediate Python supervisor which owns a separately detached group.
    with (OUT / 'runtime.stdout').open('xb') as out, (OUT / 'runtime.stderr').open('xb') as err:
        result = capture_output(record['command'], timeout_seconds=5400,
                                maximum_stdout_bytes=16 * 1024 * 1024, maximum_stderr_bytes=16 * 1024 * 1024,
                                timeout_policy=TimeoutPolicy.LONG_ANALYSIS, environment=env,
                                stdout_sink=out.write, stderr_sink=err.write)
    record.update(completed=True, returncode=result.returncode)
    if result.returncode != 0: raise RuntimeError('full Release regression failed; retained original output')
    text = result.stdout.decode()
    rows = re.findall(r'^test (.+?) \.\.\. ok$', text, re.M)
    assert len(rows) == len(set(rows)) == len(expected) and set(rows) == set(expected), 'actual full test inventory differs'
    assert 'test result: ok. 1461 passed; 0 failed; 0 ignored;' in text
    assert sha(binary) == record['binary_sha256'] and {name: sha(ROOT / name) for name in sources} == before
    record['passed'] = True
except BaseException as error:
    record.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    record.update(elapsed_seconds=time.monotonic() - started, finished_utc=datetime.now(timezone.utc).isoformat())
    with (OUT / 'RESULT.json').open('x') as f: json.dump(record, f, indent=2); f.write('\n')
    print(json.dumps({k:record.get(k) for k in ('completed','passed','returncode','elapsed_seconds','error')}), flush=True)
