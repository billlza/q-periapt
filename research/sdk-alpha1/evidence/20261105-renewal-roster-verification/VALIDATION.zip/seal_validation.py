"""Seal completed current-source verification, including original reader failures."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import subprocess
import zipfile

ROOT=Path.cwd()
BASE=Path(__file__).resolve().parent
OUT=ROOT/'research/sdk-alpha1/evidence/20261105-renewal-roster-verification'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda v:(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
read=lambda folder:json.loads((BASE/folder/'RESULT.json').read_bytes())
release=json.loads((BASE/'full-release-01/READBACK.json').read_bytes())
parallel=read('parallel-full-01')
cancel=read('parallel-cancel-01')
debug=read('debug-roster-capacity-01')
msrv=read('msrv-roster-01')
build=json.loads((BASE/'check-02/NATIVE_BUILD_RESULT.json').read_bytes())
assert release['full_release_tests_passed'] and release['actual_tests']==1461 and not release['original_driver_passed']
assert parallel['runtime_profiles_passed'] and not parallel['deadline_triggered'] and parallel['elapsed_seconds']<900
assert cancel['deadline_cleanup_control_passed'] and not cancel['runtime_profiles_passed'] and cancel['deadline_triggered']
assert debug['passed'] and msrv['passed'] and all(x['returncode']==0 for x in msrv['commands'])
assert all(sha((ROOT/n).read_bytes())==v for n,v in build['source_files'].items())
assert release['source_files']==parallel['source_files']==debug['source_files']==msrv['source_files']==build['source_files']
for folder in ('check-01','check-02'):
    for path in (BASE/folder).glob('*.json'):
        value=json.loads(path.read_bytes())
        if 'returncode' in value:assert value['returncode']==0
prefix=BASE/'parallel-full-01'
native_total=0
profile_rows=[]
for profile in parallel['profiles']:
    count,witnessed=profile['members'],profile['witnessed']
    p=prefix/str(count)/('witness' if witnessed else 'local')
    calls=json.loads((p/'NATIVE.json').read_bytes())
    workers=json.loads((p/'WORKERS.json').read_bytes())
    assert len(workers)==profile['workers'] and sum('signal' in w for w in workers)==profile['process_kills']==15
    assert len({r['case'] for r in calls})==len(calls)
    pids={r['pid'] for r in calls};assert len(pids)==1
    for row in calls:
        request=(p/'native/cases'/(row['case']+'.input')).read_bytes()
        reply=(p/'native/cases'/(row['case']+'.output')).read_bytes()
        assert sha(request)==row['input_sha256'] and reply[0]==row['status'] and sha(reply[1:])==row['output_sha256']
        assert row['error']==(reply[1:].decode('ascii') if reply[0]==2 else None)
    for worker in workers:
        case=worker['case']
        request=json.loads((p/(case+'.request.json')).read_bytes())
        stdout=(p/(case+'.stdout')).read_bytes()
        stderr=(p/(case+'.stderr')).read_bytes()
        assert request['action']==worker['action']
        if 'signal' in worker:
            assert worker['signal']=='SIGKILL' and json.loads(stdout)=={'pid':worker['worker_pid'],'stage':worker['cut']} and not stderr
        elif 'refused' in worker:
            assert not stdout and worker['refused'] in stderr.decode()
        else:
            assert sha(stdout)==worker['stdout_sha256'] and not stderr and set(json.loads(stdout))=={'result'}
    witnesses=json.loads((p/'WITNESS.json').read_bytes()) if witnessed else []
    assert len(witnesses)==(317 if witnessed else 0)
    by_case={r['case']:r for r in calls}
    for row in witnesses:
        request=(p/(row['case']+'.request')).read_bytes()
        assert len(request)==3674 and sha(request)==row['request_sha256'] and request[204]==row['kind']
        assert request[140:172].hex()==row['command_id'] and request[172:204].hex()==row['challenge']
        if row['fault']=='before':
            assert row['case'] not in by_case and row['delivery']=='not_dispatched_by_fixture'
        else:
            native=by_case[row['case']]
            assert native['command']==31 and native['input_sha256']==row['request_sha256'] and native['status']==row['native_status']
            if native['status']==2:
                assert row['delivery']=='native_rejected_no_signed_reply' and row['error']==native['error']
            else:
                reply=(p/(row['case']+'.reply')).read_bytes()
                assert len(reply)==3659 and sha(reply)==row['signed_reply_sha256']==native['output_sha256']
                if row['fault']=='after':assert row['delivery']=='signed_reply_withheld_by_fixture'
                else:
                    actual=reply[:-1]+bytes([reply[-1]^1]) if row['fault']=='corrupt' else reply
                    assert sha(actual)==row['transport_reply_sha256']
                    assert row['delivery']==('corrupted_by_fixture' if row['fault'] else 'sent')
    target=by_case['native-original-R-under-P']
    assert target['command']==40 and target['status']==1
    assert len((p/'native/cases/native-original-R-under-P.output').read_bytes())==73
    native_total+=len(calls)
    profile_rows.append({'members':count,'witnessed':witnessed,'native_commands':len(calls),'native_pid':next(iter(pids)),
                         'witness_attempts':len(witnesses),'workers':len(workers),'process_kills':profile['process_kills']})
assert native_total==818 and {r['native_pid'] for r in profile_rows}=={r['pid'] for r in parallel['native_cleanup']}
assert all(r['returncode'] is not None for r in parallel['native_cleanup'])
timings=[json.loads(line) for line in (prefix/'timing.jsonl').read_text().splitlines()]
assert len(timings)==parallel['observation_rows']==1648
ends=[r for r in timings if r['event']=='transfer-end']
assert len(ends)==822 and all('error' not in r and r['elapsed_seconds']<30 for r in ends)
for folder in ('debug-roster-capacity-01','msrv-roster-01'):
    name='runtime.stderr' if folder.startswith('debug-') else 'roster-capacity.stderr'
    text=(BASE/folder/name).read_text()
    assert 'COMMON_ACCOUNT_ROSTER members=32 original_installations=32 complete_G_then_R=true exact_receipt=true exact_target=true' in text
members={}
def add(name,value):
    path=PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and name not in members
    members[name]=value
for folder in ('check-01','check-02','full-release-01','parallel-cancel-01','parallel-full-01','debug-roster-capacity-01','msrv-roster-01'):
    for path in sorted((BASE/folder).rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            add(folder+'/'+str(path.relative_to(BASE/folder)),path.read_bytes())
for name in ('check.py','full_release.py','read_full_release.py','check_debug_native.py','run_parallel.py',
             'debug_roster_capacity.py','msrv_roster.py','RELEASE_TESTS.txt','SOURCE_IMPACT.json'):
    add(name,(BASE/name).read_bytes())
runtime=[
    ('runtime/release-tests',Path(json.loads((BASE/'full-release-01/INPUTS.json').read_bytes())['command'][0]),release['binary_sha256']),
    ('runtime/debug-tests',Path(debug['command'][0]),debug['binary_sha256']),
    ('runtime/counterpart',Path(build['binary']),build['binary_sha256']),
]
stderr=(BASE/'msrv-roster-01/roster-capacity.stderr').read_text()
match=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',stderr)
assert match
msrv_binary=ROOT/match.group(1)
runtime.append(('runtime/msrv-tests',msrv_binary,sha(msrv_binary.read_bytes())))
for name,path,digest in runtime:
    value=path.read_bytes();assert sha(value)==digest;add(name,value)
source_files=dict(build['source_files'])
for entry in release['declared_panic_tests'].values():source_files[entry['file']]=entry['sha256']
for name in ('research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock',
             'research/continuity-openssl-peer/native/Cargo.toml','research/continuity-openssl-peer/native/Cargo.lock',
             'research/continuity-identity-candidate/src/contract.rs'):
    source_files[name]=sha((ROOT/name).read_bytes())
for name,digest in source_files.items():
    value=(ROOT/name).read_bytes();assert sha(value)==digest;add('source/'+name,value)
for name,value in members.items():
    if any(word in name.lower() for word in ('private','secret','.pem')):
        assert name.endswith(('private-fixture-path','private-witness-path')),name
        text=value.decode();assert text.startswith('/') and '\n' not in text.removesuffix('\n') and '\x00' not in text and '\r' not in text
summary={
    'captured_utc':datetime.now(timezone.utc).isoformat(),'source_commit':'1bdb29a20d1d9c68496648f3be91efad710e4b0c',
    'full_release_library_tests':1461,'full_release_failed':0,'full_release_ignored':0,
    'full_release_seconds':release['elapsed_seconds'],'original_full_release_driver_passed':False,
    'full_release_readback_passed':True,'reader_negative_controls_refused':len(release['reader_negative_controls_refused']),
    'identity_debug_rust_1_98_tests':12,'identity_release_rust_1_98_tests':12,'identity_debug_rust_1_90_tests':12,
    'all_target_strict_clippy_passed':True,'format_check_passed':True,
    'native_counterpart_instrumented':False,'native_sha256':build['binary_sha256'],
    'four_profiles_passed':True,'profiles':profile_rows,'parallel_seconds':parallel['elapsed_seconds'],
    'longest_observed_exchange_seconds':max(r['elapsed_seconds'] for r in ends),
    'native_exchange_limit_seconds':30,'parallel_acceptance_budget_seconds':900,
    'deadline_cleanup_control_seconds':cancel['elapsed_seconds'],'deadline_cleanup_control_passed':True,
    'debug_roster_capacity_rust_1_98_passed':True,'debug_roster_capacity_rust_1_98_seconds':debug['elapsed_seconds'],
    'debug_roster_capacity_rust_1_90_passed':True,'debug_roster_capacity_rust_1_90_seconds':msrv['commands'][1]['elapsed_seconds'],
    'per_witness_attempt_seconds_unchanged':3,'hosted_failures_reclassified':False,
    'source_impact':json.loads((BASE/'SOURCE_IMPACT.json').read_bytes()),
    'private_generated_fixture_state_included':False,'release_claim_eligible':False,
    'scope':'Local Apple Silicon validation of the committed implementation. Full Release inventory and every four-profile native/worker/Witness record were reread. The original full-run inventory-reader failure is retained alongside a declaration-bound corrected readback. Hosted Linux/macOS failures, final packages/platforms, full research/product contracts and external review remain separate.'
}
add('VALIDATION_READBACK.json',dump(summary));add('seal_validation.py',Path(__file__).read_bytes())
with zipfile.ZipFile(OUT/'VALIDATION.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,value in sorted(members.items()):archive.writestr(name,value)
assert (OUT/'VALIDATION.zip').stat().st_size<100*1024*1024
manifest={'archive_bytes':(OUT/'VALIDATION.zip').stat().st_size,'archive_sha256':sha((OUT/'VALIDATION.zip').read_bytes()),
          'members':{name:{'bytes':len(value),'sha256':sha(value)} for name,value in sorted(members.items())}}
with zipfile.ZipFile(OUT/'VALIDATION.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    for name,value in members.items():assert archive.read(name)==value
(OUT/'VALIDATION.json').write_bytes(dump(manifest));(OUT/'VALIDATION_READBACK.json').write_bytes(dump(summary))
print(json.dumps({'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256'],'members':len(members),
                  'native_commands':native_total,'profile_count':len(profile_rows)}))

