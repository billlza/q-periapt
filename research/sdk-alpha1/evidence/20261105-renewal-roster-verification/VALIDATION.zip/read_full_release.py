"""Read the original full Release output with exact declared panic annotations."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
OUT = BASE / 'full-release-01'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record = json.loads((OUT / 'RESULT.json').read_bytes())
inputs = json.loads((OUT / 'INPUTS.json').read_bytes())
assert record['completed'] is True and record['returncode'] == 0
assert record['passed'] is False and record['error'] == 'actual full test inventory differs'
assert all(sha(ROOT / name) == digest for name, digest in inputs['source_files'].items())
assert sha(Path(inputs['command'][0])) == inputs['binary_sha256']
expected = [line.removesuffix(': test') for line in (BASE / 'RELEASE_TESTS.txt').read_text().splitlines() if line.endswith(': test')]
assert len(expected) == len(set(expected)) == 1461
panic_cases = {
    'durable::messages::tests::encoding_compat::legacy_state_oracle_rejects_an_altered_encoding':
        ('research/continuity-identity-candidate/src/durable/messages/tests/encoding_compat.rs', 'persisted session bytes changed'),
    'durable::tests::encoding_compat::legacy_image_oracle_rejects_an_altered_encoding':
        ('research/continuity-identity-candidate/src/durable/tests/encoding_compat.rs', 'journal plaintext bytes changed'),
}
stderr = (OUT / 'runtime.stderr').read_text()
declarations = {}
for name, (path, message) in panic_cases.items():
    source = (ROOT / path).read_text()
    pattern = r'#\[should_panic\(expected = "' + re.escape(message) + r'"\)\]\s*fn ' + re.escape(name.split('::')[-1]) + r'\(\)'
    assert len(re.findall(pattern, source)) == 1
    assert re.search(r"thread '" + re.escape(name) + r"' .* panicked at [^\n]+:\n" + re.escape(message) + r'(?:\n|$)', stderr)
    declarations[name] = {'file':path,'sha256':sha(ROOT / path),'expected_panic':message}
required_rows = {name + (' - should panic' if name in panic_cases else '') for name in expected}
def verify(text):
    rows = re.findall(r'^test (.+?) \.\.\. ok$', text, re.M)
    assert len(rows) == len(set(rows)) == len(required_rows) == 1461
    assert set(rows) == required_rows
    assert re.findall(r'^running \d+ tests$', text, re.M) == ['running 1461 tests']
    summaries = re.findall(r'^test result:.*$', text, re.M)
    assert len(summaries) == 1
    assert re.fullmatch(r'test result: ok\. 1461 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in [0-9]+(?:\.[0-9]+)?s', summaries[0])
    assert not re.search(r'^test .* \.\.\. (?:FAILED|ignored)', text, re.M)
    return rows
text = (OUT / 'runtime.stdout').read_text()
rows = verify(text)
first = 'test ' + next(name for name in expected if name not in panic_cases) + ' ... ok'
panic = 'test ' + next(iter(panic_cases)) + ' - should panic ... ok'
controls = {
    'missing_case':text.replace(first + '\n','',1),
    'duplicate_case':text + first + '\n',
    'unknown_case':text.replace(first,'test unexpected::case ... ok',1),
    'failed_case':text.replace(first,first.removesuffix('ok') + 'FAILED',1),
    'ignored_case':text.replace(first,first.removesuffix('ok') + 'ignored',1),
    'missing_declared_panic_annotation':text.replace(panic,panic.replace(' - should panic',''),1),
    'undeclared_panic_annotation':text.replace(first,first.replace(' ... ok',' - should panic ... ok'),1),
    'extra_summary':text + 'test result: ok. 1461 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1s\n',
    'wrong_test_count':text.replace('running 1461 tests','running 1460 tests',1),
    'nonzero_filtered_count':text.replace('0 filtered out;','1 filtered out;',1),
    'nonzero_failure_summary':text.replace('0 failed;','1 failed;',1),
}
for name, changed in controls.items():
    assert changed != text
    try:
        verify(changed)
    except AssertionError:
        continue
    raise AssertionError('reader accepted negative control: ' + name)
result = {
    'readback_utc':datetime.now(timezone.utc).isoformat(),
    'command_returncode':0,'actual_tests':len(rows),'failed':0,'ignored':0,'filtered_out':0,
    'full_release_tests_passed':True,'original_driver_passed':False,
    'original_driver_failure':record['error'],
    'original_result_sha256':sha(OUT / 'RESULT.json'),
    'stdout_sha256':sha(OUT / 'runtime.stdout'),'stderr_sha256':sha(OUT / 'runtime.stderr'),
    'binary_sha256':inputs['binary_sha256'],'source_files':inputs['source_files'],
    'declared_panic_tests':declarations,'reader_negative_controls_refused':list(controls),
    'elapsed_seconds':record['elapsed_seconds'],'original_timeout_seconds':inputs['timeout_seconds'],
    'reader_sha256':sha(Path(__file__)),'release_claim_eligible':False,
    'scope':'Independent readback of the completed original full Release regression. Both intentional panic annotations and expected panic messages match source declarations. The original failed inventory reader and all raw output are preserved; no runtime test was omitted or rerun.'
}
with (OUT / 'READBACK.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({key:result[key] for key in ('actual_tests','failed','ignored','filtered_out','full_release_tests_passed','original_driver_passed','elapsed_seconds')}))
print('negative controls refused',len(controls))

