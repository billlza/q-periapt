from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT=Path.cwd()
BASE=Path(__file__).resolve().parent
OUT=BASE/'msrv-roster-01'
OUT.mkdir()
sys.path.insert(0,str(ROOT/'artifact'))
from bounded_process import capture_output,TimeoutPolicy
chain=Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/rustup/toolchains/1.90.0-aarch64-apple-darwin/bin')
assert (chain/'rustc').is_file() and (chain/'cargo').is_file()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((BASE/'check-02/NATIVE_BUILD_RESULT.json').read_bytes())
assert all(sha(ROOT/n)==v for n,v in build['source_files'].items())
env=dict(os.environ)
env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
           CARGO_TARGET_DIR=str(BASE/'msrv-build'),CARGO=str(chain/'cargo'),RUSTC=str(chain/'rustc'),RUSTDOC=str(chain/'rustdoc'),
           PATH=str(chain)+':'+env['PATH'],DYLD_FALLBACK_LIBRARY_PATH=str(chain.parent/'lib'),CARGO_BUILD_JOBS='2',
           RUSTFLAGS='-D warnings',OPENSSL_DIR='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed',OPENSSL_STATIC='0')
version=subprocess.run([str(chain/'rustc'),'--version','--verbose'],capture_output=True,check=True,timeout=30,env=env)
assert version.stdout.startswith(b'rustc 1.90.0 (1159e78c4 2025-09-14)') and not version.stderr
(OUT/'rustc.txt').write_bytes(version.stdout)
manifest='research/continuity-identity-candidate/Cargo.toml'
base=[str(chain/'cargo'),'test','--manifest-path',manifest,'--locked','--offline','--lib','--features','anchor-tls,control-tls,connection-tls']
case='enrollment::tests::witness_renewal::account_renewal::roster::native_common_account_roster_capacity_original_owners_after_complete_g'
commands=[('identity',base+['identity::','--','--nocapture'],12),
          ('roster-capacity',base+[case,'--','--exact','--nocapture'],1)]
state={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':build['source_files'],
       'rustc_sha256':sha(chain/'rustc'),'cargo_sha256':sha(chain/'cargo'),'completed':False,'passed':False,
       'release_claim_eligible':False,'commands':[],'started_utc':datetime.now(timezone.utc).isoformat(),
       'scope':'Actual Rust 1.90 minimum-compiler identity regressions and original Debug 32-member roster-capacity case on Apple Silicon. Existing CI job 90-minute budgets and 3-second Witness attempt limits retained. Not a Linux-runner result.'}
(OUT/'INPUTS.json').write_text(json.dumps(state,indent=2)+'\n')
overall=time.monotonic()
try:
    for name,argv,count in commands:
        started=time.monotonic()
        row={'name':name,'command':argv,'timeout_seconds':5400,'completed':False,'started_utc':datetime.now(timezone.utc).isoformat()}
        try:
            with (OUT/(name+'.stdout')).open('xb',buffering=0) as out,(OUT/(name+'.stderr')).open('xb',buffering=0) as err:
                result=capture_output(argv,timeout_seconds=5400,timeout_policy=TimeoutPolicy.LONG_ANALYSIS,
                                      maximum_stdout_bytes=16*1024*1024,maximum_stderr_bytes=16*1024*1024,
                                      environment=env,stdout_sink=out.write,stderr_sink=err.write)
            row.update(completed=True,returncode=result.returncode)
            if result.returncode!=0:raise RuntimeError(name+' failed; original diagnostics retained')
            text=result.stdout.decode()
            assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in text
            if name=='roster-capacity':
                assert re.findall(r'^test (.+?) \.\.\. ok$',text,re.M)==[case]
        except BaseException as error:
            row.update(error_type=type(error).__name__,error=str(error));raise
        finally:
            row.update(elapsed_seconds=time.monotonic()-started,finished_utc=datetime.now(timezone.utc).isoformat())
            with (OUT/(name+'.json')).open('x') as f:json.dump(row,f,indent=2);f.write('\n')
            state['commands'].append(row)
            print(json.dumps(row),flush=True)
    assert all(sha(ROOT/n)==v for n,v in state['source_files'].items())
    state.update(completed=True,passed=True)
except BaseException as error:
    state.update(error_type=type(error).__name__,error=str(error));raise
finally:
    state.update(elapsed_seconds=time.monotonic()-overall,finished_utc=datetime.now(timezone.utc).isoformat())
    with (OUT/'RESULT.json').open('x') as f:json.dump(state,f,indent=2);f.write('\n')
    print(json.dumps({k:state.get(k) for k in ('completed','passed','elapsed_seconds','error')}),flush=True)

