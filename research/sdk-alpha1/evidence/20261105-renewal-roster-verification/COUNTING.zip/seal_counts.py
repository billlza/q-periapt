"""Seal both completed signature-count diagnostics and their exact source/binary identities."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-verification-counts'
OUT=ROOT/'research/sdk-alpha1/evidence/20261105-renewal-roster-verification'
sha=lambda value:hashlib.sha256(value).hexdigest()
dump=lambda value:(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
members={}
def add(name,value):
    p=PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and name not in members
    members[name]=value

results=[]
for index in (1,2):
    folder=BASE/f'counts-profile-0{index}'
    result=json.loads((folder/'DIAGNOSTIC_RESULT.json').read_bytes())
    assert result['completed'] is True and result['qualification_passed'] is False
    assert result['profile']['members']==32 and result['profile']['witnessed'] is True
    assert result['profile']['workers']==91 and result['profile']['process_kills']==15
    mapping=json.loads((folder/'ROSTER_MAPPING.json').read_bytes())
    assert len(mapping['matched'])==4
    for row in mapping['matched']:
        assert sha((folder/row['file']).read_bytes())==row['wire_sha256']
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            add(f'run-{index}/'+str(path.relative_to(folder)),path.read_bytes())
    results.append(result)
comparison=json.loads((BASE/'COMPARISON.json').read_bytes())
assert comparison['baseline_attempts']==22994 and comparison['candidate_attempts']==15569
assert comparison['removed_repeated_roster_attempts']==7425
for purpose,counts in results[0]['signature_counts'].items():
    after=results[1]['signature_counts'][purpose]
    assert counts['distinct_input_digests']==after['distinct_input_digests']
    if purpose!='2':assert counts==after
for name in ('SOURCE_IDENTITY.json','SOURCE_IDENTITY_AFTER.json','COMPARISON.json',
             'instrumentation.patch','roster-reuse.patch','LAUNCH_ATTEMPT01.json',
             'build_attempt01.py','build.py','build_after.py','diagnose_counts.py','diagnose_counts_after.py',
             'BUILD_RESULT.json','fmt.json','fmt.stdout','fmt.stderr','build.json','build.stdout','build.stderr',
             'clippy.json','clippy.stdout','clippy.stderr'):
    add(name,(BASE/name).read_bytes())
for path in sorted((BASE/'after-build-01').iterdir()):
    assert path.is_file() and not path.is_symlink()
    add('after-build-01/'+path.name,path.read_bytes())
for name,digest in (
    ('baseline-counterpart','c63b7dcd6a3c0df35217c6ed06fe051275d5ce1b635b4c8bfaf2ef3cf573b844'),
    ('after-counterpart','fdfef0e643d734528f45e4604cfc6da867e9a9ed7173998651bea4cfcf92c53e'),
):
    value=(BASE/name).read_bytes();assert sha(value)==digest;add(name,value)
for label,filename in (('baseline-source','SOURCE_IDENTITY.json'),('candidate-source','SOURCE_IDENTITY_AFTER.json')):
    identity=json.loads((BASE/filename).read_bytes())
    for name,digest in identity['sources'].items():
        value=subprocess.check_output(['git','show',identity['diagnostic_commit']+':'+name],cwd=ROOT)
        assert sha(value)==digest
        add(label+'/'+name,value)
baseline=results[0]['baseline_python_and_native_sources']
assert baseline==results[1]['baseline_python_and_native_sources']
for name,digest in baseline.items():
    path='research/continuity-openssl-peer/'+name
    value=subprocess.check_output(['git','show','ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20:'+path],cwd=ROOT)
    assert sha(value)==digest
    add('shared-baseline/'+path,value)
for name,value in members.items():
    if any(word in name.lower() for word in ('private','secret','.pem')):
        assert name.endswith(('private-fixture-path','private-witness-path','private_files.py')),name
        if name.endswith('-path'):
            text=value.decode()
            assert text.startswith('/') and '\n' not in text.removesuffix('\n') and '\x00' not in text and '\r' not in text
readback={
    'captured_utc':datetime.now(timezone.utc).isoformat(),
    'baseline_source_commit':results[0]['source_commit'],'candidate_source_commit':results[1]['source_commit'],
    'production_change_commit':'1bdb29a20d1d9c68496648f3be91efad710e4b0c',
    'baseline_native_sha256':results[0]['native_sha256'],'candidate_native_sha256':results[1]['native_sha256'],
    'baseline_attempts':22994,'candidate_attempts':15569,'removed_roster_attempts':7425,
    'baseline_roster_attempts':12648,'candidate_roster_attempts':5223,
    'distinct_input_digests_per_run':170,'other_purpose_counts_identical':True,
    'baseline_roster_counts':{'roster-1':126,'roster-2':7425,'roster-3':4999,'roster-4':98},
    'candidate_roster_counts':{'roster-1':126,'roster-2':2475,'roster-3':2524,'roster-4':98},
    'original_native_exchange_seconds':30,'workers_per_run':91,'process_kills_per_run':15,
    'baseline_target_seconds':comparison['target_exchanges'][0]['elapsed_seconds'],
    'candidate_target_seconds':comparison['target_exchanges'][1]['elapsed_seconds'],
    'qualification_passed':False,'release_claim_eligible':False,'private_state_included':False,
    'baseline_export_note':'The baseline binary was copied and hash-checked before the original Cargo output path was reused by the candidate build. The original build record is preserved unchanged.',
    'input_comparison_scope':'Fresh independently random fixtures: equal counts and workload, not identical input bytes across the two runs. Each roster fingerprint is separately matched to its actual public bytes.',
    'failures_retained':['initial cross-repository Python wrapper refusal before build','case-insensitive build.json/BUILD.json collision after three successful build/check commands'],
    'interpretation':'Every credential, renewal grant, policy and Witness verification count is retained. Three repeated roster verifications per 2,475 historical grant decodes are removed by reusing the two exact independently pinned authenticated rosters within that verification. Instrumentation counts attempts and never caches or changes their cryptographic results.',
    'limits':'Instrumentation and uncontrolled host conditions make timing diagnostic only. This is not proof of the original hosted timeout cause, a fixed remote job, a final source/package qualification, or a formal product resource budget.'
}
add('COUNTING_READBACK.json',dump(readback))
add('seal_counts.py',Path(__file__).read_bytes())
OUT.mkdir()
with zipfile.ZipFile(OUT/'COUNTING.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,value in sorted(members.items()):archive.writestr(name,value)
manifest={'archive_bytes':(OUT/'COUNTING.zip').stat().st_size,'archive_sha256':sha((OUT/'COUNTING.zip').read_bytes()),
          'members':{name:{'bytes':len(value),'sha256':sha(value)} for name,value in sorted(members.items())}}
with zipfile.ZipFile(OUT/'COUNTING.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    for name,value in members.items():assert archive.read(name)==value
(OUT/'COUNTING.json').write_bytes(dump(manifest));(OUT/'COUNTING_READBACK.json').write_bytes(dump(readback))
print(json.dumps({'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256'],'members':len(members)}))

