// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Isolated diagnostic branch instrumentation; not a product verification cache.
use super::{Error, PublicKey, Purpose};
use sha3::{Digest, Sha3_256};
use std::collections::BTreeMap;
use std::fmt::Write;
use std::sync::Mutex;

const MAX_DISTINCT_INPUTS: usize = 8192;
static OBSERVATION: Mutex<Option<BTreeMap<(u8, [u8; 32]), u64>>> = Mutex::new(None);

/// Begin one bounded observation of attempted signature verification inputs.
/// This diagnostic does not change the verification result or cache success.
pub fn begin_signature_observation() -> Result<(), Error> {
    let mut state = OBSERVATION.lock().map_err(|_| Error::Scope)?;
    if state.is_some() {
        return Err(Error::Scope);
    }
    *state = Some(BTreeMap::new());
    Ok(())
}

pub(super) fn record(
    key: &PublicKey,
    purpose: Purpose,
    bound: &[u8],
    signature: &[u8],
) -> Result<(), Error> {
    let mut guard = OBSERVATION.lock().map_err(|_| Error::Scope)?;
    let Some(state) = guard.as_mut() else {
        return Ok(());
    };
    let mut digest = Sha3_256::new();
    digest.update(b"isolated-signature-observation/v1");
    digest.update([purpose as u8]);
    digest.update(key.encode());
    digest.update((bound.len() as u64).to_be_bytes());
    digest.update(bound);
    digest.update((signature.len() as u64).to_be_bytes());
    digest.update(signature);
    let identity = (purpose as u8, digest.finalize().into());
    if !state.contains_key(&identity) && state.len() >= MAX_DISTINCT_INPUTS {
        return Err(Error::Capacity);
    }
    let count = state.entry(identity).or_insert(0);
    *count = count.checked_add(1).ok_or(Error::Capacity)?;
    Ok(())
}

/// Stop the observation and return bounded counts by purpose and input digest.
/// Digests are diagnostic fingerprints, not authorization or a success memo.
pub fn finish_signature_observation() -> Result<String, Error> {
    let state = OBSERVATION
        .lock()
        .map_err(|_| Error::Scope)?
        .take()
        .ok_or(Error::Scope)?;
    let mut output = String::from("purpose,input_sha3_256,attempts\n");
    for ((purpose, digest), count) in state {
        write!(output, "{purpose},").map_err(|_| Error::Encoding)?;
        for byte in digest {
            write!(output, "{byte:02x}").map_err(|_| Error::Encoding)?;
        }
        writeln!(output, ",{count}").map_err(|_| Error::Encoding)?;
    }
    Ok(output)
}
