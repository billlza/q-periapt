from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys
import time

ROOT = Path('/Users/bhmq03@durham.ac.uk/.codex/worktrees/browser-exchange-observation/Q-periapt')
OUT = Path(__file__).resolve().parent / 'after-build-01'
OUT.mkdir()
sys.path.insert(0, str(ROOT / 'artifact'))
from bounded_process import capture_output
os.chdir(ROOT)
env = dict(os.environ)
env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
           CARGO_TARGET_DIR=str(OUT.parent / 'build'), CARGO_BUILD_JOBS='2', RUSTFLAGS='-Dwarnings',
           OPENSSL_DIR='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/release-020/openssl-3.5.9-preparation/installed',
           OPENSSL_STATIC='0')
cargo = '/Users/bhmq03@durham.ac.uk/.cargo/bin/cargo'
manifest = 'research/continuity-openssl-peer/native/Cargo.toml'
commands = [('fmt', [cargo, '+1.98.1', 'fmt', '--manifest-path', manifest, '--all']),
            ('build', [cargo, '+1.98.1', 'build', '--manifest-path', manifest, '--locked', '--offline', '--release']),
            ('clippy', [cargo, '+1.98.1', 'clippy', '--manifest-path', manifest, '--locked', '--offline', '--release', '--', '-D', 'warnings'])]
rows = []
started = time.monotonic()
for name, command in commands:
    row = {'name': name, 'command': command, 'started_utc': datetime.now(timezone.utc).isoformat()}
    with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
        result = capture_output(command, timeout_seconds=900, maximum_stdout_bytes=16 * 1024 * 1024,
                                maximum_stderr_bytes=16 * 1024 * 1024, environment=env,
                                stdout_sink=out.write, stderr_sink=err.write)
    row.update(returncode=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
    rows.append(row)
    with (OUT / (name + '.json')).open('x') as f: json.dump(row, f, indent=2); f.write('\n')
    print(json.dumps(row), flush=True)
    if result.returncode != 0: raise RuntimeError(name + ' failed; retained diagnostics')
binary = OUT.parent / 'build/release/q-periapt-independent-peer-counterpart'
record = {'qualification_passed': False, 'scope': 'Isolated signature-count instrumentation; not a release build or timed comparison',
          'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
          'elapsed_seconds': time.monotonic() - started, 'commands': rows}
with (OUT / 'BUILD_RESULT.json').open('x') as f: json.dump(record, f, indent=2); f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k != 'commands'}), flush=True)
