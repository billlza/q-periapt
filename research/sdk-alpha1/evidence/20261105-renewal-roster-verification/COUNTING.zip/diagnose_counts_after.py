"""Measure the failed 32-member witnessed profile with the exact hosted binary."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-verification-counts'
OUT = BASE / 'counts-profile-02'
PEER = ROOT / 'research/continuity-openssl-peer'
PROVIDER = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-directory-python-akg2_n1g/provider')
NATIVE = BASE / 'after-counterpart'
record = json.loads((ROOT / 'target/continuity-independent-macos-failure/INPUTS.json').read_bytes())
build = json.loads((BASE / 'after-build-01/BUILD_RESULT.json').read_bytes())
identity = json.loads((BASE / 'SOURCE_IDENTITY_AFTER.json').read_bytes())
WORK = Path(identity['worktree'])
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(NATIVE) == build['binary_sha256']
assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
OUT.mkdir()
assert 'QPC_SIGNATURE_OBSERVATION' not in os.environ
os.environ['QPC_SIGNATURE_OBSERVATION'] = str(OUT / 'SIGNATURE_INPUT_COUNTS.csv')
assert all(sha(WORK / n) == v for n,v in identity['sources'].items())
NATIVE.chmod(0o700)
sys.path.insert(0, str(PEER))
from qperiapt_continuity_reference.provider import load_provider
crypto, backend = load_provider(PROVIDER)
assert {'cryptography': crypto.__version__, 'openssl': backend.openssl_version_text()} == record['provider']
from run import Counterpart
from policy_composition_checks import run_profile

state = {'completed': False, 'qualification_passed': False,
         'scope': 'Isolated instrumented native build, 32-member witnessed profile. Exact baseline Python inputs and unchanged transport deadlines. Signature attempts are counted; verification is still executed on every call. This is not qualification or a timing comparison to the hosted binary.',
         'source_commit': identity['diagnostic_commit'], 'native_source_identity': identity,
         'native_sha256': sha(NATIVE), 'baseline_python_and_native_sources': record['source_files'], 'provider': record['provider'],
         'python_version': sys.version, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'whole_diagnostic_budget_seconds': 900, 'original_native_exchange_seconds': 30,
         'native_pids': [], 'driver_sha256': sha(Path(__file__))}
with (OUT / 'DIAGNOSTIC_INPUTS.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
events = (OUT / 'transport-timing.jsonl').open('x', buffering=1)
lock = threading.Lock()
event_count = 0
def emit(value):
    global event_count
    with lock:
        if event_count >= 8192: raise RuntimeError('diagnostic observation capacity exceeded')
        events.write(json.dumps(value, sort_keys=True) + '\n'); event_count += 1
initialize, transfer = Counterpart.__init__, Counterpart.transfer
def observed_initialize(self, *args, **kwargs):
    initialize(self, *args, **kwargs)
    state['native_pids'].append(self.process.pid)
    emit({'event': 'native-start', 'pid': self.process.pid, 'unix_ns': time.time_ns()})
def observed_transfer(self, data):
    started = time.monotonic()
    item = {'pid': self.process.pid, 'first_byte': data[0], 'request_bytes': len(data),
            'request_sha256': hashlib.sha256(data).hexdigest(), 'started_unix_ns': time.time_ns()}
    emit({'event': 'transfer-start', **item})
    try:
        reply = transfer(self, data)
        item.update(reply_bytes=len(reply), reply_sha256=hashlib.sha256(reply).hexdigest())
        return reply
    except BaseException as error:
        item.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        emit({'event': 'transfer-end', **item, 'elapsed_seconds': time.monotonic() - started})
Counterpart.__init__, Counterpart.transfer = observed_initialize, observed_transfer

def budget_expired(_number, _frame):
    raise TimeoutError('single-profile diagnostic reached its 900-second budget')
def interrupted(number, _frame):
    raise SystemExit(128 + number)
assert signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0)
previous = {number: signal.getsignal(number) for number in (signal.SIGALRM, signal.SIGTERM, signal.SIGHUP)}
signal.signal(signal.SIGALRM, budget_expired)
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGHUP, interrupted)
signal.setitimer(signal.ITIMER_REAL, 900)
started = time.monotonic()
try:
    # The alarm unwinds this same owner into the existing Fixture.finally cleanup;
    # it does not kill an intermediate supervisor while leaving its groups alive.
    state['profile'] = run_profile(SimpleNamespace(output=OUT, native=NATIVE, provider_root=PROVIDER), 32, True)
    assert sha(NATIVE) == build['binary_sha256']
    assert all(sha(PEER / name) == expected for name, expected in record['source_files'].items())
    assert all(sha(WORK / n) == v for n,v in identity['sources'].items())
    import csv
    with (OUT / 'SIGNATURE_INPUT_COUNTS.csv').open() as f:
        reader = csv.DictReader(f)
        assert reader.fieldnames == ['purpose', 'input_sha3_256', 'attempts']
        rows = list(reader)
    assert 0 < len(rows) <= 8192
    summary = {}
    seen = set()
    for row in rows:
        purpose, digest, attempts = int(row['purpose']), row['input_sha3_256'], int(row['attempts'])
        assert 1 <= purpose <= 39 and len(digest) == 64 and len(bytes.fromhex(digest)) == 32 and attempts > 0
        assert (purpose, digest) not in seen
        seen.add((purpose, digest))
        item = summary.setdefault(purpose, {'attempts': 0, 'distinct_input_digests': 0, 'largest_repetition': 0})
        item['attempts'] += attempts
        item['distinct_input_digests'] += 1
        item['largest_repetition'] = max(item['largest_repetition'], attempts)
    state['signature_counts'] = summary
    state['signature_counts_sha256'] = sha(OUT / 'SIGNATURE_INPUT_COUNTS.csv')
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    signal.setitimer(signal.ITIMER_REAL, 0)
    for number, handler in previous.items(): signal.signal(number, handler)
    events.close()
    del os.environ['QPC_SIGNATURE_OBSERVATION']
    Counterpart.__init__, Counterpart.transfer = initialize, transfer
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started,
                 observation_rows=event_count, transport_timing_sha256=sha(OUT / 'transport-timing.jsonl'))
    with (OUT / 'DIAGNOSTIC_RESULT.json').open('x') as out: json.dump(state, out, indent=2); out.write('\n')
    print(json.dumps({key: state.get(key) for key in ('completed', 'error', 'elapsed_seconds', 'native_pids')}), flush=True)
