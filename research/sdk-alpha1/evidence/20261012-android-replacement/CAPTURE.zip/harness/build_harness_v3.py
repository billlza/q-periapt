from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
import continuity_c_consumer as c

root=Path.cwd();work=root/'target/continuity-android-replacement';source=work/'c-consumer';out=work/'harness-v3';out.mkdir()
previous=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())
environment=dict(previous['environment'],CARGO_TARGET_DIR=str(work/'harness-build'))
state={'completed':False,'live_producer':True,'source':str(source),'target':environment['CARGO_TARGET_DIR']}
(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 cargo=Path(environment['RUSTC']).parent/'cargo'
 sdk.command([str(cargo.parent/'rustfmt'),'--edition','2021','--config','skip_children=true',str(source/'tests/common/android_retirement.rs'),str(source/'tests/common/android_replacement_traffic.rs'),str(source/'tests/common/peer_bundle.rs'),str(source/'tests/common/android_retirement_android.rs')],out/'rustfmt',source)
 built=sdk.command([str(cargo),'test','--offline','--locked','--test','android','--no-run','--message-format=json','-j','2'],
                   out/'compile',source,environment=environment)
 binary=c.built_artifact(built,source,Path(environment['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
 sdk.command([str(cargo),'clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],out/'clippy',source,environment=environment)
 catalog=sdk.command([str(binary),'--list'],out/'catalog',source,environment=environment)
 required=b'android_retirement::original_android_retirement: test'
 assert catalog.splitlines().count(required)==1
 state.update(completed=True,binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
              catalog_sha256=hashlib.sha256(catalog).hexdigest())
finally:
 state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Independent retirement harness compiled; no lifecycle execution claimed yet.')
