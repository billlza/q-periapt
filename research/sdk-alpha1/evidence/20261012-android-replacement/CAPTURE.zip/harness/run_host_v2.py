from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
import continuity_android_jni as android

root=Path.cwd();work=root/'target/continuity-android-replacement';out=work/'runtime-v2'
build=root/'target/continuity-android-retired-next/owned-boundary-v3';harness=json.loads((work/'harness-v3/STATE.json').read_text())
boundary=json.loads((build/'STATE.json').read_text())
assert harness['completed'] and not harness['live_producer'] and boundary['completed'] and not boundary['live_producer']
changed=[name for name,digest in boundary['source_sha256'].items() if hashlib.sha256((work/'source'/name).read_bytes()).hexdigest()!=digest]
assert changed==['src/androidTest/java/dev/qperiapt/continuity/android/tests/ConfigurationInstrumentation.java'],changed
out.mkdir(mode=0o700);binary=Path(harness['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==harness['binary_sha256']
prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text())
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
state={'completed':False,'live_producer':True,'profiles':{},'source_sha256':{str(p.relative_to(work/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (work/'source').rglob('*') if p.is_file()},
       'harness_sha256':harness['binary_sha256'],'rust_sources':{name:hashlib.sha256((work/'c-consumer'/name).read_bytes()).hexdigest()
       for name in ('tests/android.rs','tests/common/android_retirement.rs','tests/common/android_retirement_android.rs','tests/common/android_replacement_traffic.rs','tests/common/peer_bundle.rs')},
       'scope':'Fresh Android API-created identities on host JVM; original uncertain traffic, native-authorized generation replacement, complete local report, MAC and receipt-purpose rejection, three process cuts, exact cleanup. Android API-created successor activation, new session and exact retry to original native C receiver. Host JVM only; ART is separate.'}
(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 for profile in ('debug','release'):
  directory=out/profile;directory.mkdir(mode=0o700)
  launcher=android._driver(directory,jdk/'bin/java',build/'qperiapt-continuity-android.jar',build/'tests',build/profile)
  program=directory/'driver.py';text=program.read_text();assert text.count("probe = ")==1
  program.write_text(text.replace("probe = ","probe = 'RetiredOwnedProbe' if mode.startswith('retired-owned-') else "))
  compile(program.read_text(),str(program),'exec')
  receiver=prior['native']['execution'][profile]['binaries']['C_client'];assert hashlib.sha256(Path(receiver['path']).read_bytes()).hexdigest()==receiver['sha256']
  environment={k:v for k,v in prior['environment'].items() if not k.startswith(('QPERIAPT_','QPC_'))}
  cases=directory/'cases'
  environment.update(QPC_ANDROID_CASES=str(cases),QPC_ANDROID_DRIVER=str(launcher),QPC_CONFIGURATION_RECEIVER=receiver['path'])
  stdout=sdk.command([str(binary),'--exact','android_retirement::original_android_retirement','--nocapture'],directory/'execution',Path(harness['source']),environment=environment)
  assert stdout.decode().splitlines().count('test android_retirement::original_android_retirement ... ok')==1
  assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout.decode()
  for trust in ('fixed','recoverable'):
   case=cases/('signed-'+trust)
   assert (case/'successor/process-count').read_bytes()==(11).to_bytes(8,'big')
   assert (case/'successor/effect-count').read_bytes()==(2).to_bytes(8,'big')
   assert (case/'retirement-effect-after-successor').read_bytes()==(case/'roster-effect-before').read_bytes()
   assert (case/'process-count').read_bytes()==(21).to_bytes(8,'big')
   assert (case/'retirement-complete-report').read_bytes()==(case/'retirement-verified').read_bytes()
   assert (case/'roster-effect-before').read_bytes()==(case/'retirement-effect-after').read_bytes()
  state['profiles'][profile]={'completed':True,'java_processes':64,'actual_process_cuts':6,
       'C_receiver_sha256':receiver['sha256'],'native_library_sha256':boundary['profiles'][profile]['native_sha256'],
       'bridge_sha256':boundary['profiles'][profile]['bridge_sha256'],'jar_sha256':boundary['jar_sha256']}
 assert all(hashlib.sha256((work/'source'/name).read_bytes()).hexdigest()==digest for name,digest in state['source_sha256'].items())
 assert all(hashlib.sha256((work/'c-consumer'/name).read_bytes()).hexdigest()==digest for name,digest in state['rust_sources'].items())
 state['completed']=True
finally:
 state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Fresh Android-owned retirement passed: 128 host Java processes, 12 actual process cuts.')
