"""Archived Android-created replacement, original-peer retry and retirement bindings."""
from pathlib import Path
import hashlib
import importlib.util
import json
import zipfile

spec = importlib.util.spec_from_file_location('retirement_base', Path(__file__).with_name('readback_base.py'))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
require = base.require


def route(read):
    original = base.route(read)
    def new(name):
        return read('successor/' + name)
    require(new('process-count') == (11).to_bytes(8, 'big'), 'successor process census')
    require(new('original.request') == new('activated.request') == new('reopened.request')
            == read('inputs/successor-request'), 'successor original request changed')
    identity = new('original.identity')
    require(len(identity) == 64 and identity[:32] != read('original.identity')[:32]
            and identity[32:] == read('inputs/successor-journal')
            and identity[32:] != read('original.identity')[32:], 'successor identity or journal reused')
    intent = new('inputs/enrollment-intent')
    old = read('inputs/enrollment-intent')
    require(len(intent) == len(old) == 72 and intent[:16] == old[:16]
            and int.from_bytes(intent[16:24], 'big') == int.from_bytes(old[16:24], 'big') + 1
            and intent[24:] == old[24:], 'successor device generation scope')
    prepared = new('prepared')
    require(len(prepared) == 164 and prepared[:4] == (2).to_bytes(4, 'big')
            and prepared[4:36] == identity[32:] and prepared[36:132] == read('inputs/successor-subject'),
            'successor original prepared subject')
    require(new('inputs/grant-certificate') == read('inputs/successor-certificate')
            and new('inputs/grant-roster') == read('inputs/successor-roster'), 'successor grant changed')
    require(new('roster-peer-admitted.stdout') == b'peer-roster-admitted\n'
            and new('roster-peer-admitted.stderr') == b'', 'explicit receiver roster admission')
    session = new('peer-connected')
    pending = new('peer-unknown')
    require(len(session) == 32 and session == new('inputs/connection-session')
            and session != read('inputs/connection-session') and len(pending) == 64
            and pending[:32] == session and pending[32:] == new('inputs/connection-message')
            and pending[32:] != read('inputs/connection-message'), 'successor traffic identities')
    require(new('peer-acknowledged') == pending, 'successor retry changed original message')
    effect = new('effect-before')
    require(effect == pending + b'persisted before process exit' and new('effect-after') == effect
            and new('effect-count') == (2).to_bytes(8, 'big'), 'successor business effects')
    require(read('retirement-effect-after-successor') == read('roster-effect-before'), 'old effect changed')
    return dict(original, processes=32, successor_processes=11, successor_session=session.hex(),
                successor_message=pending[32:].hex(), successor_same_counterparty=True,
                fresh_successor_effects=1, total_counterparty_effects=2)


def archive(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(len(names) == len(set(names)), 'duplicate member')
        manifest = json.loads(z.read('MANIFEST.json'))
        require(set(names) == set(manifest) | {'MANIFEST.json'}, 'capture inventory')
        for name, digest in manifest.items():
            require(hashlib.sha256(z.read(name)).hexdigest() == digest, 'hash: ' + name)
        results = {}
        for lane in ('host/debug', 'host/release', 'art'):
            for trust in ('fixed', 'recoverable'):
                prefix = lane + '/cases/signed-' + trust + '/'
                results[lane + '/' + trust] = route(lambda name: z.read(prefix + name))
        apk = json.loads(z.read('art/PREPARED_APK.json'))
        pids = []
        for trust in ('fixed', 'recoverable'):
            folder = 'art/device-signed-' + trust + '/'
            state = json.loads(z.read(folder + 'STATE.json'))
            require(state['completed'] and state['cleanup'] and not state['owned_reverse_ports'], 'cleanup')
            require(len(state['cases']) == 32, 'ART process census')
            cuts = [c for c in state['cases'] if c['actual_cut_observed']]
            require(len(cuts) == 3 and {c['mode'] for c in cuts} == {'retired-owned-' + n + '-unknown'
                    for n in ('report', 'journal', 'signer')}, 'ART cuts')
            for case in state['cases']:
                require(case['installed_apk_sha256'] == apk['apk_sha256']
                        and case['process_absent_after_operation'], 'installed identity or process stop')
                require(case['slot'] in ('original', 'successor'), 'private installation slot')
                prefix = 'art/cases/signed-' + trust + ('/successor/' if case['slot'] == 'successor' else '/')
                payload = z.read(prefix + case['output_name'])
                require(hashlib.sha256(payload).hexdigest() == case['result_sha256'], 'ART original output')
                pids.append(case['pid'])
                if case['actual_cut_observed']:
                    raw = z.read(folder + case['label'] + '-instrument.stdout')
                    require(b'INSTRUMENTATION_STATUS: stage=retirement-cut\n' in raw
                            and b'INSTRUMENTATION_RESULT: shortMsg=Process crashed.' in raw
                            and b'INSTRUMENTATION_RESULT: result=' not in raw, 'ART intentional cut trace')
        require(len(set(pids)) == 64 and all(type(p) is int and p > 0 for p in pids), 'ART process identities')
        return {'completed': True, 'archive_members': len(manifest), 'routes': results,
                'host_processes': 128, 'host_process_cuts': 12, 'ART_processes': 64, 'ART_process_cuts': 6,
                'agreed_physical_device_gate': 'passed', 'additional_phone_required': False,
                'scope': 'Public archived bindings. Native execution verifies signatures and secret MACs. Android API-created original and successor identities, independent native issuer, same native C counterparty, exact successor retry, original retirement cleanup. No physical erasure or independent protocol implementation claim.'}
