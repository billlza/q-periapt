"""Capture retained old-root, generation-key and response-payload branches."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
root=Path.cwd();source=root/'target/p0-origin-stored-reservation-replay-713/stored-reservation-replay-proof.spthy'
sha=lambda b:hashlib.sha256(b).hexdigest()
data=source.read_bytes();assert sha(data)=='e43ce04aacc0e10e97b39425752abde81e77ff30b15bec08363f80dfc2e77fe9'
archive=root/'research/sdk-alpha1/evidence/20261028-stored-reservation-origins/CAPTURE.zip'
assert sha(archive.read_bytes())=='556c668188d84c685a09c28121f2b9cdae3aa4192386a3d92d310f892501492b'
with zipfile.ZipFile(archive) as z:assert z.read('experiments/p0-origin-stored-reservation-replay-713/stored-reservation-replay-proof.spthy')==data
value=data.decode();a=value.index('lemma epoch_generation_secret_derivation_origin ');b=value.index('\nlemma ',a);main=value[a:b]
sources={m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',main)}
assert len(sources)==18 and sum('by sorry' not in body for body in sources.values())==17
stored=sources['Snapshot_case_5'];assert stored.count('by sorry')==35
children={m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',stored)}
assert len(children)==11
selected={'Key_Reservation_1':4,'Response_Reservation_4':6};preserved={};focused=stored
for name,body in children.items():
    if name in selected:assert body.count('by sorry')==selected[name]
    else:
        focused=focused.replace(body,'      case '+name+'\n      by sorry\n',1)
        preserved[name]={'sha256':sha(body.encode()),'open_leaves':body.count('by sorry')}
new_main=main.replace(stored,focused,1);candidate=value[:a]+new_main+value[b:]
assert new_main.count('by sorry')==19 and len(preserved)==9
assert max(len(m[1]) for m in re.finditer(r'(?m)^( +)by sorry',new_main))==14
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,value)
assert sha(candidate[:candidate.index('lemma ')].encode())=='3cb837646fa2097468d1fad0a10433f50d5c31b6be5553f20085170c3eef0266'
stage=root/'target/p0-origin-reservation-details-714';stage.mkdir()
(stage/'model.spthy').write_text(candidate);base=root/'target/p0-origin-source-frontiers-705'
for name in ('run.py','initial-send-oracle.py','initial-send-oracle.sh'):shutil.copy2(base/name,stage/name)
driver=stage/'run.py';assert driver.read_text().count('--bound=13')==1;driver.write_text(driver.read_text().replace('--bound=13','--bound=9'))
shell=stage/'initial-send-oracle.sh';shell.write_text(shell.read_text().replace(str(base),str(stage)))
(stage/'initial-send-oracle-frames').mkdir()
record={'full_parent':str(source),'full_parent_sha256':sha(data),'input_sha256':sha(candidate.encode()),'selected_producers':selected,
    'all18_sources_11stored_producers_29queries_retained':True,'closed_sources':17,'full_snapshot_subtree_sha256':sha(stored.encode()),
    'unselected_subtrees_preserved_in_parent':preserved,'must_restore_all_subtrees_before_final_replay':True,
    'focused_open_leaves':19,'existing_open_prefix_maximum':7,'remaining_search_bound':9,'total_depth_limit':16,
    'oracle_callback_limit':32,'oracle_selects_no_search_step':True,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'focused_open_leaves':19,'prefix':7,'remaining_bound':9}))
