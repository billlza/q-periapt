"""Use eight recorded knowledge chains, retaining two automatic contradictions."""
from pathlib import Path
import hashlib,json,re,shutil
root=Path.cwd();capture=root/'target/p0-origin-reservation-details-714'
sha=lambda b:hashlib.sha256(b).hexdigest()
terminal=json.loads((capture/'reservation-details-TERMINAL.json').read_text())
assert terminal['returncode']==0 and not terminal['accepted'] and not terminal['timed_out'] and not terminal['output_exceeded']
assert not (capture/'initial-send-oracle.failed').exists()
value=(capture/'reservation-details-proof.spthy').read_text();assert sha(value.encode())==terminal['output_sha256']=='68567b24ecb79a94157bbe2462c6cd4cc39dda7faa834b40dfcd4b13bafcf07d'
parent=root/'target/p0-origin-stored-reservation-replay-713/stored-reservation-replay-proof.spthy';full=parent.read_text()
assert sha(full.encode())=='e43ce04aacc0e10e97b39425752abde81e77ff30b15bec08363f80dfc2e77fe9'
def region(t):
    a=t.index('lemma epoch_generation_secret_derivation_origin ');b=t.index('\nlemma ',a);return a,b,t[a:b]
def roots(t):return {m[1]:m[0] for m in re.finditer(r'(?ms)^    case (\S+)\n(.*?)(?=^  next|^  qed)',t)}
def children(t):return {m[1]:m[0] for m in re.finditer(r'(?ms)^      case (\S+)\n(.*?)(?=^    next|^    qed)',t)}
a,b,main=region(value);_,_,old_main=region(full);current_roots,old_roots=roots(main),roots(old_main)
assert len(current_roots)==18 and set(current_roots)==set(old_roots) and not re.search(r'\binvalid\b',main)
assert all(current_roots[n]==body for n,body in old_roots.items() if n!='Snapshot_case_5')
focused,original=children(current_roots['Snapshot_case_5']),children(old_roots['Snapshot_case_5'])
assert len(focused)==11 and set(focused)==set(original)
assert 'by contradiction /* from formulas */' in focused['Key_Reservation_1'] and 'by contradiction /* cyclic */' in focused['Response_Reservation_4']
frames=[]
for p in sorted((capture/'initial-send-oracle-frames').glob('*.json')):
    r=json.loads(p.read_text());t=(p.parent/r['captured_input']).read_text();assert sha(t.encode())==r['input_sha256'] and not r['ranking'];frames.append((r,t))
assert len(frames)==17 and main.count('by sorry')==17 and main.count('Oracle ranked no proof methods')==17
selected={'Key_Reservation_1':3,'Response_Reservation_4':5};index=0;methods=[];restored=[];snapshot=current_roots['Snapshot_case_5']
for name,body in focused.items():
    leaves=list(re.finditer(r'by sorry /\* Oracle ranked no proof methods \*/',body))
    if name not in selected:
        assert len(leaves)==1;snapshot=snapshot.replace(body,original[name],1);index+=1
        restored.append({'producer':name,'sha256':sha(original[name].encode()),'open_leaves':original[name].count('by sorry')});continue
    assert len(leaves)==selected[name];changes=[]
    for leaf in leaves:
        row,text=frames[index];goals=re.findall(r'(?m)^\d+: (\(#[a-zA-Z0-9.]+, 0\) ~~> \(#known, 0\))$',text)
        assert len(goals)==1;method=goals[0];changes.append((leaf.start(),leaf.end(),'by solve( '+method+' )'))
        methods.append({'producer':name,'frame_index':index,'frame':row['captured_input'],'frame_sha256':row['input_sha256'],'method':method});index+=1
    updated=body
    for left,right,replacement in reversed(changes):updated=updated[:left]+replacement+updated[right:]
    snapshot=snapshot.replace(body,updated,1)
assert index==17 and len(methods)==8 and len(restored)==9
main=main.replace(current_roots['Snapshot_case_5'],snapshot,1);candidate=value[:a]+main+value[b:]
query=r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]*)\])?:\s*(all-traces|exists-trace)?\s*"((?:[^"\\]|\\.)*)"'
assert len(re.findall(query,candidate))==29 and re.findall(query,candidate)==re.findall(query,full)
assert candidate[:candidate.index('lemma ')]==full[:full.index('lemma ')]
assert main.count('by sorry')==25 and 'Oracle ranked no proof methods' not in main
stage=root/'target/p0-origin-reservation-details-replay-714';stage.mkdir();(stage/'model.spthy').write_text(candidate)
shutil.copy2(root/'target/p0-wire-scope-replay-704/run.py',stage/'run.py')
record={'full_parent_sha256':sha(full.encode()),'capture_sha256':sha(value.encode()),'input_sha256':sha(candidate.encode()),
    'actual_selected_methods':methods,'restored_unselected_producers':restored,'automatic_contradictions_retained':['Key_Reservation_1/Var_fresh_1_key: from formulas','Response_Reservation_4/d_0_fst: cyclic'],
    'all18_sources_11stored_producers_29queries_retained':True,'all17_closed_sources_retained_byte_equal':True,'operational_prefix_unchanged':True,
    'independent_replay_no_search_or_oracle':True,'maximum_explicit_prefix':8,'total_depth_limit':16,'release_claim_eligible':False}
(stage/'PREPARATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'input_sha256':record['input_sha256'],'actual_methods':8,'restored_producers':9,'automatic_contradictions_retained':2}))
