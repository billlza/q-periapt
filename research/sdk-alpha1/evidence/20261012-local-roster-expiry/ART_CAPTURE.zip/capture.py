from pathlib import Path
import hashlib,json,subprocess,zipfile
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_android_local_credential as local
import continuity_android_credential as credential
import continuity_android_remote_credential as remote
import continuity_android_credential_terminal as terminal
root=Path.cwd();phone=root/'target/continuity-android-local-credential-qualified-device';host=root/'target/continuity-android-local-credential-qualified-host';aar=root/'target/continuity-android-local-credential-final-aar';native=root/'target/continuity-local-roster-expiry-fix';out=root/'research/sdk-alpha1/evidence/20261012-local-roster-expiry'
v=json.loads((phone/'VERIFIED.json').read_text());h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());e=json.loads((native/'ENGINES.json').read_text())
assert v['completed'] and h['completed'] and a['completed'] and e['completed'] and not e['live_producer']
native_run=json.loads((native/'FULL_NATIVE.json').read_text());assert native_run['completed'] and not native_run['live_producer'] and native_run['returncode']==0
for prefix in ['green-focused','clippy-native']:assert json.loads((native/(prefix+'.json')).read_text())['returncode']==0
assert json.loads((native/'EXPORTS.json').read_text())['completed']
assert json.loads((host/'clippy.json').read_text())['returncode']==0
assert 'test result: ok. 909 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in (native/'full-native.stdout').read_text()
assert a['native_engine_sha256']==e['android_library_sha256']
for name,data in android.source_files().items():
 digest=hashlib.sha256(data).hexdigest();assert h['source_hashes'][name]==a['source_sha256'][name]==digest
for name,digest in e['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
basic=tuple(name+'.'+suffix for name,_ in android.CASES for suffix in ('stdout','stderr'))+('original.request','resumed.request','after-rejection.request','activated.request','rejected','active-reopened','rekeyed','cancelled','connected.session','uncertain.message','acknowledged.message','reverse.result')
local_public=basic+local.PUBLIC;credential_public=credential.PUBLIC+remote.PUBLIC+terminal.PUBLIC
libraries={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];lib=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')));libraries[profile]=lib
 assert local.verify_execution((host/('android-jni-'+profile+'-execution.stdout')).read_bytes(),lib/'cases')==h['profiles'][profile]['outcomes']
 assert terminal.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),lib/'credential-cases')==h['profiles'][profile]['credential_outcomes']
 for key,filename in [('C_library','libq_periapt_continuity_c_consumer.dylib'),('C_client','qpc-c-client')]:assert hashlib.sha256((lib/filename).read_bytes()).hexdigest()==e['native']['execution'][profile]['binaries'][key]['sha256']
serials=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
for row in subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines():
 if ' device ' in row:serials.append(row.split()[0].encode())
private=[]
import base64
for lib in libraries.values():
 for p in (lib/'credential-cases').glob('*/inputs/witness-tls-key'):
  value=p.read_bytes();private.extend([value,base64.b64encode(value),value.hex().encode()])
assert not subprocess.run(['git','status','--porcelain'],check=True,capture_output=True,text=True).stdout.strip(),'commit the verified code before capturing source identity'
out.mkdir()
def archive(name,files):
 with zipfile.ZipFile(out/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for leaf,path in sorted(files.items()):
   data=path.read_bytes();assert not any(value and value in data for value in serials+private),'private value in '+leaf
   info=zipfile.ZipInfo(leaf);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
 return hashlib.sha256((out/name).read_bytes()).hexdigest()
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for folder in ['device-*','agp-*']:
 for p in phone.glob(folder+'/*'):
  if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for label in v['profiles']:
 for name in local_public:files['cases/'+label+'/'+name]=phone/'cases'/label/name
art=archive('ART_CAPTURE.zip',files)
files={p.relative_to(host).as_posix():p for p in host.rglob('android-jni-*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'}}
for name in ['ANDROID_JNI_CONSUMER.json','qualify.py','clippy.py','clippy.json','clippy.stdout','clippy.stderr','rustfmt.stdout','rustfmt.stderr']:files[name]=host/name
for profile,lib in libraries.items():
 for label in h['profiles'][profile]['outcomes']:
  for name in local_public:files['cases/'+profile+'/'+label+'/'+name]=lib/'cases'/label/name
 for label in h['profiles'][profile]['credential_outcomes']:
  for name in credential_public:files['credential-cases/'+profile+'/'+label+'/'+name]=lib/'credential-cases'/label/name
host_hash=archive('HOST_CAPTURE.zip',files)
files={p.name:p for p in native.iterdir() if p.is_file() and p.name not in {'STATE.json','TURN_IN_PROGRESS.json'} and p.suffix in {'.py','.json','.stdout','.stderr'}}
failed=root/'target/continuity-android-local-credential-host'
for name in ['android-jni-debug-execution.json','android-jni-debug-execution.stdout','android-jni-debug-execution.stderr','artifact-tests.stdout','artifact-tests.stderr']:files['initial-host/'+name]=failed/name
guard=root/'target/continuity-android-local-credential-fixed-host'
for n in ['android-jni-debug-execution.json','android-jni-debug-execution.stdout','android-jni-debug-execution.stderr']:files['activation-still-requires-approval/'+n]=guard/n
for n in ['artifact-tests.stdout','artifact-tests.stderr']:files[n]=guard/n
files['stale-receiver-context.log']=native/'receiver-context-control-cases/fixed/local-receiver.log'
initial_phone=root/'target/continuity-android-local-credential-device'
for n in ['android-local.json','android-local.stdout','android-local.stderr','device-driver.py','run.py']:files['initial-phone-controller/'+n]=initial_phone/n
native_hash=archive('NATIVE_CHECKS.zip',files)
aar_hash=archive('AAR_BUILD_CAPTURE.zip',{p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}})
code={('bindings/android/ContinuityPackageConsumer/'+n):hashlib.sha256(b).hexdigest() for n,b in android.source_files().items()}
for n in ['artifact/continuity_android_jni.py','artifact/continuity_android_local_credential.py','artifact/continuity_package.py','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_local_credential.rs','research/continuity-identity-candidate/src/enrollment/renewal/expiry.rs','research/continuity-identity-candidate/src/enrollment/expired_renewal_tests.rs']:
 code[n]=hashlib.sha256((root/n).read_bytes()).hexdigest()
record={'kind':'qperiapt.local_roster_expiry_recovery','completed':True,'base_commit':'1a50284ff73ecfcf68a6c96d01ab9ee3459d0974','code_commit':subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip(),'code_sha256':code,'art_processes':60,'profiles':v['profiles'],'host_java_processes':726,'native_library_tests':{'passed':909,'failed':0,'ignored':0,'filtered':0,'all_target_all_feature_clippy':True},'reader_tests':{'related_passed':24,'local_reader_latest_rerun_passed':3},'test_corrections':['ExpiredUncommitted intentionally refuses activation until a new independent grant; the initial fallback expectation was incorrect.','A renewed peer must restore its original session context; the ordinary context is correctly refused with Protocol(Scope).','An old controller metadata filename failed before phone installation; the corrected controller completed both profiles.','The initial whole library run hit the generic900-second bound. The same909 tests completed with four threads and a3600-second bound; the timeout is retained.'],'device_scope':{'accepted':True,'api':37,'device_count':1,'additional_api36_hardware_required':False},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'native':e,'artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'NATIVE_CHECKS.zip':native_hash,'AAR_BUILD_CAPTURE.zip':aar_hash},'scope':['Old JNI execution and native regression refuse cleanup after real target-roster expiry while target credential remains live.','Corrected native classification uses the earlier signed credential/roster expiration only after exact journal history proves no commit; committed targets still win.','A live target cannot be abandoned, time backdating remains refused, pending operations cannot be implicitly replaced.','Expiry history alone remains insufficient for activation. A new independent root grant and explicit native peer admission preserve identity, journal, session, next message and acknowledged traffic; the next send creates one new business effect.','Independent subsequent root approval activates the same original identity and journal; exact prior non-commit remains readable while it is pending.'],'limitations':['The Android scenario expires the target roster while preceding credential and original policy remain live; original-policy/runtime-expiry cleanup is separate work.','Counterparty uses the native Rust reference harness on the same Mac host; no independent protocol implementation is claimed.'],'release_claim_eligible':False}
sdk.write_json(out/'CHECKS.json',record);print('Captured local target-roster expiry fix with old/new native, host JNI and actual ART evidence',flush=True)
