from pathlib import Path
import hashlib,json,subprocess
import continuity_android_local_credential as local
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-local-credential-qualified-device';results=local.verify_execution((out/'android-local.stdout').read_bytes(),out/'cases');assert sum(r['foreign_processes'] for r in results.values())==60
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r.split()[0] for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1
prefix=[adb,'-s',selected[0]]
def call(args):
 r=subprocess.run(prefix+args,capture_output=True,text=True,check=True,timeout=20);assert not r.stderr;return r.stdout
assert not call(['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.localcredential20261012']).strip()
active={kind:{row.split()[1] for row in call([kind,'--list']).splitlines() if len(row.split())==3} for kind in ['forward','reverse']}
for label,result in results.items():
 s=json.loads((out/('device-'+label)/'STATE.json').read_text());assert s['completed'] and s['cleanup'] and len(s['cases'])==result['foreign_processes']
 for kind in ['forward','reverse']:
  assert not s.get('owned_'+kind+'_ports')
  assert all('tcp:'+str(p) not in active[kind] for p in s.get('created_'+kind+'_ports',[]))
 assert all(c['process_absent_after_stop'] and c['installed_apk_sha256']==s['apk_sha256'] for c in s['cases'])
 result.update(installation_retired=True,owned_mappings_absent=True,apk_sha256=s['apk_sha256'],aar_sha256=s['aar_sha256'])
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':results,'same_phone_accepted':True,'additional_api36_hardware_required':False});print('60 ART outcomes and owned cleanup verified',flush=True)
