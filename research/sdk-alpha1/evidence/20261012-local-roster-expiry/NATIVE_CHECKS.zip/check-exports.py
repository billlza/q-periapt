from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=root/'target/continuity-local-roster-expiry-fix';s=json.loads((out/'ENGINES.json').read_text());assert s['completed'] and not s['live_producer'];env=json.loads((out/'STATE.json').read_text())['environment'];records={}
for profile in ['debug','release']:
 path=Path(s['native']['execution'][profile]['binaries']['C_library']['path'])
 names={row.split()[-1].removeprefix('_') for row in sdk.command(['/usr/bin/nm','-gU',str(path)],out/('exports-'+profile),root,environment=env).decode().splitlines() if row.strip()}
 assert names==c.EXPORTS;records[profile]={'exports':len(names),'sha256':sdk.snapshot(path,maximum=c.MAX_BINARY).sha256}
llvm=Path('/Users/bill/Library/Android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-nm');path=Path(s['android_library'])
names={row.split()[-1] for row in sdk.command([str(llvm),'-D','--defined-only',str(path)],out/'exports-android',root,environment=env).decode().splitlines() if row.strip()};assert names==c.EXPORTS;records['android']={'exports':len(names),'sha256':sdk.snapshot(path,maximum=c.MAX_BINARY).sha256}
sdk.write_json(out/'EXPORTS.json',{'completed':True,'profiles':records});print('All rebuilt native libraries retain the exact C export contract',flush=True)
