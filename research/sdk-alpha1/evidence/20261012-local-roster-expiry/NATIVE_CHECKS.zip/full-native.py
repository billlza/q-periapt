from pathlib import Path
import json,os,signal,subprocess,time
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-local-roster-expiry-fix';env=json.loads((out/'STATE.json').read_text())['environment'];source=root/'research/continuity-identity-candidate'
argv=[str(Path(env['RUSTC']).parent/'cargo'),'test','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--lib','--','--test-threads=4'];prefix=out/'full-native';started=time.monotonic();record={'argv':argv,'cwd':str(source),'deadline_seconds':3600,'maximum_log_bytes_each':16*1024*1024,'completed':False,'live_producer':True}
state=out/'FULL_NATIVE.json';state.write_text(json.dumps(record,indent=2)+'\n')
with prefix.with_suffix('.stdout').open('xb') as stdout,prefix.with_suffix('.stderr').open('xb') as stderr:
 child=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:
  while child.poll() is None:
   if time.monotonic()-started>=3600:raise TimeoutError('complete native suite exceeded one hour')
   if any(prefix.with_suffix(ext).stat().st_size>16*1024*1024 for ext in ['.stdout','.stderr']):raise RuntimeError('native log bound exceeded')
   time.sleep(1)
  record['returncode']=child.returncode
  if child.returncode!=0:raise RuntimeError('complete native suite failed; retained full-native logs')
  record['completed']=True
 finally:
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
  record.update(live_producer=False,elapsed_seconds=time.monotonic()-started);state.write_text(json.dumps(record,indent=2)+'\n')
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--all-targets','--all-features','--','-D','warnings'],out/'clippy-native',source,environment=env)
print('Complete native suite and strict all-target/all-feature Clippy passed',flush=True)
