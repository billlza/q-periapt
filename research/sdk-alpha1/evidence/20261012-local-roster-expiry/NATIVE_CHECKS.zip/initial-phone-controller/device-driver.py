#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import subprocess,sys,json,hashlib,re,base64,os,zipfile,time
import secrets as port_random
out=Path(__file__).resolve().parent;root=out.parents[1];mode,profile,inputs,target,output=sys.argv[1:];inputs=Path(inputs);output=Path(output)
assert profile in ['fixed','recoverable'];assert mode.startswith('credential-local-') or mode in ['enrollment-create','enrollment-resume','enrollment-reject','enrollment-activate','enrollment-active-reopen','peer-connect','peer-uncertain','peer-retry','peer-rekey','peer-serve','peer-cancel']
label=output.name;assert re.fullmatch(r'[a-z][a-z0-9.-]{0,63}',label)
run=out/('device-'+profile);run.mkdir(mode=0o700,exist_ok=True);state_path=run/'STATE.json';s=json.loads(state_path.read_text()) if state_path.exists() else {'completed':False,'cleanup':False,'cases':[]}
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.localcredential20261012'
lines=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();matches=[line for line in lines if ' device ' in line and 'model:SM_S948U1 ' in line];assert len(matches)==1
serial=matches[0].split()[0];identity=hashlib.sha256(serial.encode()).hexdigest();assert identity=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16';transport=re.search(r'transport_id:(\d+)',matches[0]).group(1)
def command(name,args,expected=0,timeout=30,bind_conflict=False):
 cmd=[adb,'-t',transport]+args;r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
 (run/(label+'-'+name+'.stdout')).write_text(r.stdout);(run/(label+'-'+name+'.stderr')).write_text(r.stderr)
 (run/(label+'-'+name+'.json')).write_text(json.dumps({'command':cmd,'exit_code':r.returncode},indent=2)+'\n')
 if bind_conflict and r.returncode==1 and not r.stdout.strip() and r.stderr.strip()=='adb: error: cannot bind listener: Address already in use':return None
 assert r.returncode==expected and not r.stderr,(name,r.returncode,r.stderr);return r.stdout

def clear_maps():
 for kind in ['reverse','forward']:
  for port in list(s.get('owned_'+kind+'_ports',[])):
   command(kind+'-remove-'+str(port),[kind,'--remove','tcp:'+str(port)])
   s['owned_'+kind+'_ports'].remove(port);state_path.write_text(json.dumps(s,indent=2)+'\n')

def cleanup():
 clear_maps()
 result=command('uninstall',['uninstall',pkg],timeout=60);assert result.strip()=='Success'
 assert not command('uninstalled',['shell','pm','list','packages','--user','0',pkg]).strip();s['cleanup']=True
try:
 if mode=='enrollment-create':
  assert not s.get('installation_attempted');assert not command('preexisting',['shell','pm','list','packages','--user','0',pkg]).strip()
  assert command('api',['shell','getprop','ro.build.version.sdk']).strip()=='37'
  assert command('abi',['shell','getprop','ro.product.cpu.abi']).strip()=='arm64-v8a'
  assert command('pages',['shell','getconf','PAGE_SIZE']).strip()=='4096'
  s.update(device_serial_sha256=identity,api=37,abi='arm64-v8a',page_size=4096)
  with (run/'build-driver.stdout').open('wb') as stdout,(run/'build-driver.stderr').open('wb') as stderr:
   built=subprocess.run([sys.executable,str(out/'build-consumer.py'),str(inputs),profile],stdout=stdout,stderr=stderr,timeout=900)
  assert built.returncode==0,'AGP build'
  build=json.loads((out/('agp-'+profile)/'STATE.json').read_text());assert build['completed']
  project=Path(build['project']);compiled=(project/'app/compile-inputs.txt').read_text().splitlines()
  assert sorted(Path(p).name for p in compiled)==['AuthorityProbe.java', 'CancellationProbe.java', 'ConfigurationInstrumentation.java', 'ConfigurationProbe.java', 'CredentialLocalProbe.java', 'CredentialProbe.java', 'CredentialTerminalProbe.java', 'EnrollmentProbe.java', 'PeerInputs.java', 'PeerProbe.java', 'PeerRenewalProbe.java', 'WitnessInputs.java', 'WitnessProbe.java']
  assert all(Path(p).is_relative_to(project/'app/src/main/java') for p in compiled)
  mapping=(project/'app/build/outputs/mapping/release/mapping.txt').read_text();assert 'dev.qperiapt.continuity.android.Native -> dev.qperiapt.continuity.android.Native:' in mapping
  package=json.loads((out/'PACKAGE-cancel-01.json').read_text())
  with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(build['unsigned_apk']) as apk:
   for name in ['libqperiapt_continuity_jni.so','libq_periapt_continuity_c_consumer.so']:
    assert aar.read('jni/arm64-v8a/'+name)==apk.read('lib/arm64-v8a/'+name)
  jdk=Path('/Users/bill/Library/Java/JavaVirtualMachines/android-studio-jbr-21.jdk/Contents/Home');bt=Path('/Users/bill/Library/Android/sdk/build-tools/36.0.0');env=dict(os.environ,JAVA_HOME=str(jdk),PATH=str(jdk/'bin')+':/usr/bin:/bin')
  def local(name,cmd):
   r=subprocess.run([str(p) for p in cmd],env=env,capture_output=True,text=True,timeout=60);(run/(name+'.stdout')).write_text(r.stdout);(run/(name+'.stderr')).write_text(r.stderr);assert r.returncode==0,(name,r.stderr)
  local('keytool',[jdk/'bin/keytool','-genkeypair','-keystore',run/'qualification.p12','-storepass','qualification-only','-alias','qualification','-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Local Continuity Qualification','-noprompt']);(run/'qualification.p12').chmod(0o600)
  local('sign',[bt/'apksigner','sign','--ks',run/'qualification.p12','--ks-pass','pass:qualification-only','--out',run/'consumer.apk',build['unsigned_apk']]);local('signature',[bt/'apksigner','verify','--verbose',run/'consumer.apk'])
  s['apk_sha256']=hashlib.sha256((run/'consumer.apk').read_bytes()).hexdigest();s['aar_sha256']=package['aar_sha256'];s['installation_attempted']=True;state_path.write_text(json.dumps(s,indent=2)+'\n')
  installed=command('install',['install','--no-incremental','-t',str(run/'consumer.apk')],timeout=90);assert installed.splitlines().count('Success')==1
 else:assert s['installation_attempted'] and not s['cleanup']
 args=['shell','am','instrument','-w','-e','profile',profile,'-e','operation',mode,'-e','label',label]
 if mode in ['enrollment-reject','enrollment-activate']:
  for name in ['grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest']:
   value=(inputs/name).read_bytes();assert 1<=len(value)<=8192;args+=['-e',name,base64.b64encode(value).decode('ascii')]
 reverse_port=None;forward_port=None
 peer_mode=mode if mode.startswith('peer-') else ('peer-retry' if mode in ['credential-local-identity','credential-local-active','credential-local-send'] else None)
 if mode.startswith('credential-local-'):
  keys=[]
  if mode in ['credential-local-stage','credential-local-rejected','credential-local-next-stage','credential-local-next-stage-blocked']:
   prefix='local-second-' if mode.startswith('credential-local-next-') else 'local-first-'
   keys=[prefix+n for n in ['operation','statement','version','digest','grant']]
  if mode in ['credential-local-active','credential-local-send']:keys+=['local-next-message']
  for name in keys:args+=['-e',name,base64.b64encode((inputs/name).read_bytes()).decode('ascii')]
 if peer_mode:
  for file in sorted((inputs/'peer').iterdir()):
   if file.is_file():args+=['-e','peer-'+file.name,base64.b64encode(file.read_bytes()).decode('ascii')]
  keys=['connection-address','connection-initiation' if peer_mode=='peer-connect' else 'connection-session']
  if peer_mode=='peer-retry':keys.append('connection-message')
  for name in keys:
   value=(inputs/name).read_bytes()
   if name=='connection-address' and mode not in ['peer-serve','peer-cancel','credential-local-identity','credential-local-active']:
    match=re.fullmatch(r'127\.0\.0\.1:(\d+)',value.decode());assert match,'owned loopback endpoint'
    original_port=int(match.group(1));assert 1<=original_port<=65535
    for attempt in range(8):
     selected=original_port if attempt==0 else 49152+port_random.randbelow(16384)
     bound=command('reverse-create-'+str(selected),['reverse','--no-rebind','tcp:'+str(selected),'tcp:'+str(original_port)],bind_conflict=True)
     if bound is None:continue
     assert bound.strip()==str(selected);reverse_port=selected
     s.setdefault('owned_reverse_ports',[]).append(selected);s.setdefault('created_reverse_ports',[]).append(selected);state_path.write_text(json.dumps(s,indent=2)+'\n');break
    else:raise RuntimeError('no available reverse port after eight attempts')
    value=('127.0.0.1:'+str(reverse_port)).encode()
   args+=['-e',name,base64.b64encode(value).decode('ascii')]
 args+=[pkg+'/dev.qperiapt.continuity.android.tests.ConfigurationInstrumentation']
 expected=profile+':'+mode+':passed'
 try:
  if mode=='peer-serve':
   stdout_path=run/(label+'-instrument.stdout');stderr_path=run/(label+'-instrument.stderr')
   with stdout_path.open('wb') as stdout,stderr_path.open('wb') as stderr:
    child=subprocess.Popen([adb,'-t',transport]+args,stdout=stdout,stderr=stderr)
    try:
     deadline=time.monotonic()+45
     while True:
      live=stdout_path.read_text()
      if 'INSTRUMENTATION_STATUS_CODE: 2\n' in live:break
      if child.poll() is not None or time.monotonic()>=deadline:raise RuntimeError('listener readiness: '+live)
      time.sleep(.01)
     assert 'INSTRUMENTATION_STATUS: stage=peer-listening\n' in live
     assert 'INSTRUMENTATION_STATUS: apk_sha256='+s['apk_sha256']+'\n' in live
     device_port=int(re.search(r'^INSTRUMENTATION_STATUS: port=(\d+)$',live,re.M).group(1));assert 1<=device_port<=65535
     forward_port=int(command('forward-create',['forward','--no-rebind','tcp:0','tcp:'+str(device_port)]).strip());assert 1<=forward_port<=65535
     s.setdefault('owned_forward_ports',[]).append(forward_port);s.setdefault('created_forward_ports',[]).append(forward_port);state_path.write_text(json.dumps(s,indent=2)+'\n')
     staging=Path(str(output)+'.ready.pending');ready=Path(str(output)+'.ready')
     with staging.open('xb') as marker:marker.write(str(forward_port).encode());marker.flush();os.fsync(marker.fileno())
     assert not ready.exists();staging.rename(ready)
     exit_code=child.wait(timeout=60)
    finally:
     if child.poll() is None:child.kill();child.wait(timeout=10)
   result=stdout_path.read_text();assert exit_code==0 and not stderr_path.read_text(),result
  else:result=command('instrument',args,timeout=90)
 finally:
  clear_maps()
 assert 'INSTRUMENTATION_RESULT: result='+expected+'\n' in result,result
 assert result.rstrip().endswith('INSTRUMENTATION_CODE: -1'),result
 assert 'INSTRUMENTATION_RESULT: apk_sha256='+s['apk_sha256']+'\n' in result,'installed APK hash'
 pid=int(re.search(r'^INSTRUMENTATION_RESULT: pid=(\d+)$',result,re.M).group(1));assert pid not in [case['pid'] for case in s['cases']]
 payload=base64.b64decode(re.search(r'^INSTRUMENTATION_RESULT: result_payload=([^\n]+)$',result,re.M).group(1),validate=True);assert 1<=len(payload)<=8192
 with output.open('xb') as destination:destination.write(payload)
 command('stop',['shell','am','force-stop',pkg]);assert not command('process-absent',['shell','pidof',pkg],expected=1).strip()
 s['cases'].append({'mode':mode,'label':label,'pid':pid,'result_sha256':hashlib.sha256(payload).hexdigest(),'installed_apk_sha256':s['apk_sha256'],'process_absent_after_stop':True})
 if mode=='credential-local-next-reopen':cleanup();s['completed']=True
 state_path.write_text(json.dumps(s,indent=2)+'\n');print(expected)
except BaseException:
 if s.get('installation_attempted') and not s.get('cleanup'):cleanup()
 state_path.write_text(json.dumps(s,indent=2)+'\n');raise
