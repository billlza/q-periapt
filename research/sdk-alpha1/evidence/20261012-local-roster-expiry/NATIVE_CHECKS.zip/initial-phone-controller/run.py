from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_local_credential as local
root=Path.cwd();out=root/'target/continuity-android-local-credential-device';host=root/'target/continuity-android-local-credential-qualified-host'
s=json.loads((host/'STATE.json').read_text());source=Path(s['work'])/'c-consumer';env=s['environment']
assert json.loads((host/'android-jni-debug-execution.json').read_text())['returncode']==0
original=c.built_artifact((host/'android-jni-debug-build.stdout').read_bytes(),source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
binary=out/'android-harness';sdk.copy(original,binary,maximum=c.MAX_BINARY);binary.chmod(0o700)
sdk.write_json(out/'HARNESS.json',{'source':str(original),'copied_sha256':sdk.snapshot(binary,maximum=c.MAX_BINARY).sha256,'base_commit':'1a50284ff73ecfcf68a6c96d01ab9ee3459d0974','test_sources':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_local_credential.rs','research/continuity-identity-candidate/tests/owned_connection.rs','research/continuity-identity-candidate/src/enrollment/renewal/expiry.rs']}})
runtime=dict(env,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(out/'device-driver.py'))
def cleanup():
 adb='/Users/bill/Library/Android/sdk/platform-tools/adb';pkg='dev.qperiapt.continuity.localcredential20261012'
 for record in sorted(out.glob('device-*/STATE.json')):
  state=json.loads(record.read_text())
  if not state.get('installation_attempted') or state.get('cleanup'):continue
  rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines()
  selected=[r.split()[0] for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1
  def call(args):
   r=subprocess.run([adb,'-s',selected[0],*args],capture_output=True,text=True,timeout=60);assert r.returncode==0 and not r.stderr;return r.stdout
  for kind in ['reverse','forward']:
   for port in list(state.get('owned_'+kind+'_ports',[])):
    call([kind,'--remove','tcp:'+str(port)]);state['owned_'+kind+'_ports'].remove(port)
  if call(['shell','pm','list','packages','--user','0',pkg]).strip():assert call(['uninstall',pkg]).strip()=='Success'
  assert not call(['shell','pm','list','packages','--user','0',pkg]).strip();state['cleanup']=True;state['outer_cleanup']=True;record.write_text(json.dumps(state,indent=2)+'\n')
try:
 stdout=sdk.command([str(binary),'--exact','android_lifecycle','--nocapture'],out/'android-local',source,environment=runtime)
 results=local.verify_execution(stdout,out/'cases');sdk.write_json(out/'OUTCOMES.json',results)
except BaseException as original:
 try:cleanup()
 except BaseException as failure:raise BaseExceptionGroup('local renewal qualification and owned cleanup failed',[original,failure])
 raise
print('60 actual ART lifecycle and local-expiry outcomes passed on the accepted phone',flush=True)
