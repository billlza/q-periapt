from pathlib import Path
import json
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent;s=json.loads((out/'STATE.json').read_text());env=s['environment'];source=Path.cwd()/'research/continuity-identity-candidate'
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--lib','expired_successor_roster_with_live_credential_resolves_exact_local_intent','--','--nocapture'],out/'red-behavior',source,environment=env)
