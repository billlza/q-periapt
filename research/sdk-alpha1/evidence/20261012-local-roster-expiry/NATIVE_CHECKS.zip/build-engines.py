from pathlib import Path
import hashlib,json,os,shutil,tempfile
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-local-roster-expiry-fix';s=json.loads((out/'STATE.json').read_text());env=s['environment']
previous=json.loads((out/'ENGINES_SETUP_FAILURE.json').read_text());work=Path(previous['work']);source=Path(previous['mac_source'])
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for tree in ['research/continuity-identity-candidate/src','bindings/c/ContinuityPackageConsumer/src'] for p in (root/tree).rglob('*.rs')}
r={'completed':False,'live_producer':True,'work':str(work),'mac_source':str(source),'source_sha256':sources,'native':{'completed':False,'execution':{}}};(out/'ENGINES.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 mac_env=dict(env,CARGO_TARGET_DIR=str(work/'mac-build'))
 cc=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--find','clang'],out/'cc-path',source,environment=env).decode().strip()
 platform=sdk.command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],out/'sdk-path',source,environment=env).decode().strip()
 for profile in ['debug','release']:
  args=[str(Path(env['RUSTC']).parent/'cargo'),'rustc','--locked','--offline','--lib','-j','2']+(['--release'] if profile=='release' else [])+['--','-C','link-arg=-Wl,-install_name,@rpath/libq_periapt_continuity_c_consumer.dylib']
  sdk.command(args,out/('mac-'+profile+'-fixed'),source,environment=mac_env)
  folder=work/('native-'+profile);folder.mkdir();binaries={}
  name='libq_periapt_continuity_c_consumer.dylib';path=folder/name;shutil.copy2(work/'mac-build'/profile/name,path);binaries['C_library']={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  client=folder/'qpc-c-client'
  sdk.command([cc,'-isysroot',platform,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-pthread',*(['-O2'] if profile=='release' else ['-O0','-g']),*[str(source/n) for n in ['client.c','recovery_client.c','opening_client.c']],'-I',str(source),'-L',str(folder),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(client)],out/('c-client-'+profile),source,environment=env)
  binaries['C_client']={'path':str(client),'sha256':hashlib.sha256(client.read_bytes()).hexdigest()}
  r['native']['execution'][profile]={'binaries':binaries};(out/'ENGINES.json').write_text(json.dumps(r,indent=2)+'\n')
 old_android=json.loads((root/'target/continuity-android-current/FIXED-02.json').read_text());assert old_android['completed'] and not old_android['live_producer']
 android=work/'android-source';shutil.copytree(old_android['source'],android)
 shutil.copytree(root/'research/continuity-identity-candidate/src',android/'packages/q-periapt-continuity-identity-candidate-0.0.0/src',dirs_exist_ok=True)
 shutil.copytree(root/'bindings/c/ContinuityPackageConsumer/src',android/'src',dirs_exist_ok=True)
 settings=json.loads((root/'target/continuity-android-current/STATE.json').read_text());tc=Path(settings['toolchain']);llvm=Path(settings['ndk'])/'toolchains/llvm/prebuilt/darwin-x86_64/bin';cc=llvm/'aarch64-linux-android23-clang'
 android_env=dict(env,CARGO_TARGET_DIR=str(work/'android-build'),CARGO_INCREMENTAL='0',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings -C link-arg=-Wl,-z,max-page-size=16384',DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'),CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=str(cc),CC_aarch64_linux_android=str(cc),AR_aarch64_linux_android=str(llvm/'llvm-ar'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
 sdk.command([str(tc/'bin/cargo'),'build','--locked','--offline','--lib','--target','aarch64-linux-android','--release','-j','2'],out/'android-native',android,environment=android_env)
 library=work/'android-build/aarch64-linux-android/release/libq_periapt_continuity_c_consumer.so';r.update(completed=True,android_source=str(android),android_library=str(library),android_library_sha256=hashlib.sha256(library.read_bytes()).hexdigest());r['native']['completed']=True
finally:
 r['live_producer']=False;(out/'ENGINES.json').write_text(json.dumps(r,indent=2)+'\n')
print('Corrected Debug/Release macOS and API 23 arm64 Android engines built',flush=True)
