from pathlib import Path
import json
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent;s=json.loads((out/'STATE.json').read_text());env=s['environment'];source=Path.cwd()/'research/continuity-identity-candidate'
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--lib','expired_successor_roster_with_live_credential_resolves_exact_local_intent','--','--nocapture'],out/'green-focused',source,environment=env)

sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--lib'],out/'green-library',source,environment=env)
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--manifest-path',str(source/'Cargo.toml'),'--locked','--offline','--all-targets','--all-features','--','-D','warnings'],out/'clippy-native',source,environment=env)
print('Native expiry regression, complete library tests and strict all-target/all-feature Clippy passed',flush=True)
