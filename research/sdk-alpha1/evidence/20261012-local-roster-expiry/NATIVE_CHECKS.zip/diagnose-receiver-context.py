from pathlib import Path
import hashlib,json
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=root/'target/continuity-local-roster-expiry-fix';host=root/'target/continuity-android-local-credential-final-host';s=json.loads((host/'STATE.json').read_text());env=s['environment'];source=Path(s['work'])/'c-consumer'
argv=json.loads((host/'android-jni-debug-boundary.json').read_text())['argv'];lib=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')))
compiled=(out/'receiver-diagnostic-build.stdout').read_bytes()
binary=c.built_artifact(compiled,source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
runtime=dict(env,QPC_ANDROID_CASES=str(out/'receiver-context-control-cases'),QPC_ANDROID_DRIVER=str(lib/'driver'))
sdk.command([str(binary),'--exact','android_lifecycle','--nocapture'],out/'receiver-context-control',source,environment=runtime)
