import {QPeriaptContinuityPublicationPlan as Plan,
 QPeriaptContinuityPublicationPhase as Phase,QPeriaptContinuityPrekeyKind as Kind}
 from '/node_modules/q-periapt-sdk-wasm/web/index.js';
const require=(value,message)=>{if(!value)throw Error(message)};
const bytes=value=>new Uint8Array(value);
const snapshot=value=>{const out={phase:value.phase(),intent:value.intent_digest()?[...value.intent_digest()]:null,
 artifact:value.artifact_digest()?[...value.artifact_digest()]:null,manifest:value.manifest_digest()?[...value.manifest_digest()]:null};value.free();return out};
export async function publication(owner,policy,config,data,close){
 const plan=new Plan(new Uint8Array(32).fill(data.changedPlan?78:77),BigInt(config.from),BigInt(config.until));
 let prepared;
 try {
  plan.generate(Kind.SignedClassical,BigInt(config.from),BigInt(config.until));
  if(data.pubop==='invalid-plan'){
   const id=await owner.next_publication_id();
   const result=await Promise.allSettled([owner.prepare_publication(id,plan,policy,5000,()=>BigInt(Math.floor(Date.now()/1000)))]);
   require(result[0].status==='rejected'&&result[0].reason.ownerClosed===undefined&&!owner.is_closed(),'invalid plan dispatched');
   require((await owner.next_publication_id()).toString()===id.toString(),'invalid plan allocated');
   return {invalid_plan_rejected:true};
  }
  plan.generate(Kind.OneTimeClassical,BigInt(config.from),BigInt(config.until));
  plan.generate(Kind.LastResortPq,BigInt(config.from),BigInt(config.until));
  plan.reuse(new Uint8Array(32).fill(55),Kind.OneTimePq,BigInt(config.from),BigInt(config.until));
  const bound=plan.artifact_size_bound();
  if(data.pubop==='next') {const id=await owner.next_publication_id();return {id:[...id],status:snapshot(await owner.publication_status(id))};}
  const id=bytes(data.publicationId);
  if(data.pubop==='status')return snapshot(await owner.publication_status(id));
  if(data.pubop==='retire')return snapshot(await owner.retire_publication(id,bytes(data.artifact)));
  if(data.pubop==='abandon')return snapshot(await owner.abandon_publication(id,bytes(data.intent),policy));
  let samples=0;const originalClockError=new Error('host trusted clock unavailable');
  const clock=()=>{
   samples++;
   if(data.clock==='throw')throw originalClockError;
   if(data.clock==='number')return Math.floor(Date.now()/1000);
   if(data.clock==='expire'&&samples>=3)return BigInt(config.until);
   if(data.cancelAtClock&&samples===3)close();
   return BigInt(Math.floor(Date.now()/1000));
  };
  try {
   const attempt=owner.prepare_publication(id,plan,policy,data.publicationTimeout??10000,clock);
   if(data.concurrent){
    const results=await Promise.allSettled([attempt,owner.publication_status(id)]);
    require(results[0].status==='fulfilled'&&results[1].status==='rejected'&&results[1].reason.code==='Busy'&&results[1].reason.ownerClosed===false,'publication concurrency contract');
    prepared=results[0].value;
   }else prepared=await attempt;
  }catch(error){
   if(data.clock==='throw'){
    let current=error,found=false;
    for(let i=0;i<12&&current;i++,current=current.cause)if(current===originalClockError){found=true;break;}
    require(error.code==='InvalidClock'&&error.ownerClosed===true&&found,'original clock cause lost');
   }
   throw error;
  }
  const artifact=prepared.bytes();
  require(artifact.length<=bound&&new TextDecoder().decode(artifact.slice(0,8))==='QPPUBA01','publication artifact envelope');
  require(prepared.id().toString()===id.toString(),'publication identity changed');
  const members=prepared.inventory_requests();
  require(members.length===4&&members.every(id=>id instanceof Uint8Array&&id.length===32)&&new Set(members.map(id=>id.toString())).size===4,'publication inventory');
  require(members[3].toString()===new Uint8Array(32).fill(55).toString(),'reused key changed');
  const observed=snapshot(await owner.publication_status(id));
  require(observed.phase===Phase.Prepared&&observed.intent.toString()===prepared.intent_digest().toString()&&observed.artifact.toString()===prepared.artifact_digest().toString(),'publication status');
  const modified=prepared.bytes();modified.fill(0);require(prepared.bytes().toString()===artifact.toString(),'public snapshot changed');
  return {bytes:[...artifact],id:[...id],intent:[...prepared.intent_digest()],artifact:[...prepared.artifact_digest()],members:members.map(id=>[...id]),status:observed,samples};
 }finally{prepared?.free();plan.free()}
}
