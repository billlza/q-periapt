use q_periapt_continuity_identity_candidate as p;
use serde_json::{json, Value};
use std::{collections::BTreeSet, fs::File, io::Read, path::Path, sync::Arc, time::{SystemTime, UNIX_EPOCH}};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn read(path: &Path, bound:u64) -> Result<Vec<u8>> {
 let mut data=Vec::new();File::open(path)?.take(bound+1).read_to_end(&mut data)?;
 if data.len() as u64>bound{return Err("oversized input".into())}Ok(data)
}
fn bytes(v:&Value,name:&str)->Result<Vec<u8>>{Ok(serde_json::from_value(v.get(name).ok_or("missing bytes")?.clone())?)}
fn array(v:&Value,name:&str)->Result<[u8;32]>{Ok(bytes(v,name)?.as_slice().try_into()?)}
fn number(v:&Value,name:&str)->Result<u64>{v.get(name).and_then(Value::as_u64).ok_or_else(||"number".into())}
fn take<'a>(input:&mut &'a [u8],n:usize)->Result<&'a [u8]>{let(head,tail)=input.split_at_checked(n).ok_or("truncated artifact")?;*input=tail;Ok(head)}
fn main()->Result<()> {
 let args=std::env::args().collect::<Vec<_>>();if args.len()!=4{return Err("config grant artifact required".into())}
 let config:Value=serde_json::from_slice(&read(Path::new(&args[1]),1048576)?)?;
 let grant:Value=serde_json::from_slice(&read(Path::new(&args[2]),1048576)?)?;
 let artifact=read(Path::new(&args[3]),131072)?;let mut input=artifact.as_slice();
 let now=SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
 let device=p::AccountPin::new(array(&config,"account")?,p::PublicKey::decode(&bytes(&config,"root")?)?,
  p::RosterCheckpoint::from_trusted_state(number(&grant,"version")?,array(&grant,"digest")?)?,array(&config,"family")?)?
  .verify_device(&bytes(&grant,"certificate")?,&bytes(&grant,"roster")?,now)?;
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(&config,"sdk_policy")?,&bytes(&config,"sdk_signature")?,&bytes(&config,"sdk_root")?,None,q_periapt_sdk::Limits::default())?;
 let sdk_digest=runtime.trusted_state().digest();
 let statement=config.get("policies").and_then(|v|v.get("required")).ok_or("policy")?;
 let policy=p::PolicyPin::new(array(&config,"family")?,p::PublicKey::decode(&bytes(&config,"policy_root")?)?,
  p::PolicyCheckpoint::from_trusted_state(number(statement,"version")?,array(statement,"digest")?)?)?
  .verify(&bytes(statement,"wire")?,Arc::new(runtime),now)?;
 policy.check_mode(p::PrekeyQuality::OneTimeBoth,now)?;
 if take(&mut input,8)?!=b"QPPUBA01" {return Err("artifact tag".into())}
 let id=take(&mut input,32)?.to_vec();let epoch=u64::from_be_bytes(id.get(..8).ok_or("epoch")?.try_into()?);
 let intent=take(&mut input,32)?.to_vec();let artifact_digest=take(&mut input,32)?.to_vec();
 let length=usize::try_from(u32::from_be_bytes(take(&mut input,4)?.try_into()?))?;
 let manifest=device.verify_manifest(take(&mut input,length)?,now)?;
 let context=manifest.context();
 if context.bundle_epoch()!=epoch || context.policy_digest()!=sdk_digest
  || context.suite_digest()!=p::bootstrap_suite_digest() || context.directory_checkpoint()!=[77;32]
  || context.validity()!=p::Validity::new(number(&config,"from")?,number(&config,"until")?)? {
  return Err("independently expected manifest context differs".into())
 }
 let count=usize::from(u16::from_be_bytes(take(&mut input,2)?.try_into()?));if count!=4{return Err("membership count".into())}
 let requests=(0..count).map(|_|Ok(take(&mut input,32)?.to_vec())).collect::<Result<Vec<_>>>()?;
 if requests.iter().collect::<BTreeSet<_>>().len()!=count{return Err("duplicate inventory ID".into())}
 let mut kinds=BTreeSet::new();let mut authenticated=BTreeSet::new();
 for _ in 0..count {
  let n=usize::from(u16::from_be_bytes(take(&mut input,2)?.try_into()?));
  let leaf=manifest.verify_leaf(&p::LeafProof::decode(take(&mut input,n)?)?,now)?;
  kinds.insert(format!("{:?}",leaf.kind()));authenticated.insert(leaf.id());
 }
 if !input.is_empty() || authenticated.len()!=count || kinds!=["SignedClassical","OneTimeClassical","LastResortPq","OneTimePq"].into_iter().map(str::to_owned).collect(){return Err("incomplete or noncanonical membership".into())}
 println!("{}",json!({"manifest_signature_verified":true,"all_leaf_proofs_verified":true,"policy_and_context_verified":true,
  "id":id,"intent":intent,"artifact":artifact_digest,"requests":requests,"manifest_digest":manifest.digest(),
  "outer_metadata_is_not_authority":true,"independent_implementation":false}));Ok(())
}
