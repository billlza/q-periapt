from pathlib import Path
import datetime,hashlib,json,stat,subprocess,zipfile
root=Path.cwd();stage=root/'target/continuity-browser-publication'
output=root/'research/sdk-alpha1/evidence/20261013-browser-publication'
required={'publication-05':10,'base-browser-04':10,'lifecycle-03':9}
reports={}
for name,count in required.items():
 value=json.loads((stage/name/'RESULT.json').read_text());assert value['completed'] is True,name
 cases=value.get('cases',value.get('report',{}).get('cases',[]));assert len(cases)==count,name
 reports[name]=value
for name in ['manifest-signature','membership-proof']:
 assert (stage/'publication-05/logs'/f'{name}.stderr').read_text()=='Error: Authentication\n'
source=json.loads((stage/'PACKAGE_SOURCE_04.json').read_text())
for name,digest in source['overlay'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert json.loads((stage/'error-boundary-after.json').read_text())=={'rejected':True,'markerEscaped':False,'code':'InvalidInput','reusable':True,'freed':True}
contents={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),str(path)
 assert stat.S_ISREG(path.stat().st_mode) and path.stat().st_size<32*1024**2,str(path)
 assert name not in contents and '..' not in Path(name).parts,name
 contents[name]=path.read_bytes()
for name in required:
 for path in sorted((stage/name).rglob('*')):
  if path.is_file() and not any(part.startswith('.') for part in path.relative_to(stage/name).parts):
   add(path,'runs/'+name+'/'+path.relative_to(stage/name).as_posix())
for name in ['publication-01','publication-02','publication-03','publication-04','base-browser-02','base-browser-03','lifecycle-02']:
 add(stage/name/'RESULT.json','prior/'+name+'/RESULT.json')
 for path in sorted((stage/name/'logs').glob('*native.stderr')):add(path,'prior/'+name+'/'+path.name)
 if name=='base-browser-02':add(stage/name/'acceptance.stdout','prior/'+name+'/acceptance.stdout')
for path in sorted(stage.iterdir()):
 if path.is_file() and path.suffix in {'.py','.js','.mjs','.sh','.json','.log','.stdout','.stderr'} and path.name not in {'STATE.json','seal.py'}:
  add(path,'controls/'+path.name)
add(stage/'seal.py','controls/seal.py')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-verifier'/name,'native-verifier/'+name)
for name in ['server.py','controller.js','lifecycle-worker.js']:
 add(root/'target/continuity-browser-recovery'/name,'shared-fixtures/'+name)
add(root/'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs','shared-fixtures/browser_activation_authority.rs')
for name in source['overlay']:add(root/name,'source-overlay/'+name)
packages={}
for number in [1,2,3,4]:
 package=stage/f'source/target/publication-package-0{number}'
 for path in sorted(package.iterdir()):
  if path.is_file() and path.suffix in {'.json','.stdout','.stderr','.tgz'}:add(path,f'packages/{number}/'+path.name)
 consumer=Path(json.loads((package/'consumer-location.json').read_text())['path'])
 for path in sorted((consumer/'inputs').glob('*.json')):
  value=json.loads(path.read_text())
  allowed={'certificate','roster','version','digest','identity'} if path.name.endswith('-grant.json') else {'root','account','description','family','from','until','sdk_policy','sdk_signature','sdk_root','sdk_state','policy_root','policies','witness_id','witness_public','witness_signer_id'}
  assert set(value)==allowed,(path,set(value)-allowed)
  add(path,f'public-inputs/{number}/'+path.name)
 for path in sorted((consumer/'creation').glob('*')):
  if path.is_file():add(path,f'web-fixtures/{number}/'+path.name)
 manifest=consumer/'node_modules/q-periapt-sdk-wasm/PACKAGE_CONTENTS.json'
 add(manifest,f'packages/{number}/PACKAGE_CONTENTS.json')
 archive=package/'q-periapt-sdk-wasm-0.2.0.tgz'
 packages[str(number)]={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
output.mkdir()
with zipfile.ZipFile(output/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for name,data in sorted(contents.items()):
  info=zipfile.ZipInfo(name,(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;archive.writestr(info,data)
checks={'base_commit':source['base_commit'],'source_overlay':source['overlay'],'completed':True,'release_claim_eligible':False,'independent_implementation':False,
 'final_package':packages['4'],'packages':packages,'publication_cases':10,'publication_witness_requests':sum(len(c['witness_records']) for c in reports['publication-05']['cases']),
 'legacy_lifecycle_cases':9,'legacy_witness_requests':sum(len(c['witness_records']) for c in reports['lifecycle-03']['cases']),
 'base_browser_cases':10,'roundtrip_assertions_per_realm':178,'canonical_input_assertions_per_realm':96,
 'packaging_unit_tests':41,'inventory_unit_tests':44,'wasm_clippy':'product and engine passed with -D warnings',
 'error_boundary_before':json.loads((stage/'error-boundary-before.json').read_text()),'error_boundary_after':json.loads((stage/'error-boundary-after.json').read_text()),
 'capture':{'sha256':hashlib.sha256((output/'CAPTURE.zip').read_bytes()).hexdigest(),'members':len(contents),'expanded_bytes':sum(map(len,contents.values()))},
 'limitations':['Local Chrome/Node qualification; not deployed HTTPS or a minimum-browser/compiler matrix.','Native verification uses the same Rust protocol engine; no independent implementation claim.','Expiry is an injected trusted-clock cut; no real expired-policy renewal is demonstrated.','All private authority/key/wrapping directories are excluded; only schema-admitted public inputs are retained.','Hosted CI/CodeQL and full native installed qualification remain separate; no release or publication performed.']}
(output/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'evidence':str(output),'capture':checks['capture'],'final_package':checks['final_package']}))
