import {publication} from './publication-checks.js';
import initialize, { QPeriaptRuntime, QPeriaptContinuityDevice as Device,
  QPeriaptContinuityEnrollment as Enrollment, QPeriaptContinuityPolicy as Policy,
  QPeriaptContinuityAccountTrust as Trust, QPeriaptContinuityWitness as Witness,
  QPeriaptContinuityPrekeyKind as Kind, QPeriaptContinuityPhase as Phase } from '/node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const bytes = value => new Uint8Array(value);
let owner, pendingClose;
self.onmessage = async ({data}) => {
  if (data.cancel) {
    if (!owner) throw Error('no pending owner');
    pendingClose = owner.close();
    postMessage({cancellation_requested:true});
    return;
  }
  let runtime, policy, intent, trust, witness, prepared;
  let value, failure; const observations=[];
  const require=(condition,message)=>{if(!condition)throw Error(message)};
  const status=async label=>{const s=await owner.status();const value={label,phase:s.phase(),journal:s.journal()?[...s.journal()]:null};require(s.roster_refresh()===undefined,"unexpected roster observation");s.free();observations.push(value);return value};
  try {
    const response=await fetch('/inputs/'+data.case+'.json');if(!response.ok)throw Error('public inputs');
    const config=await response.json();const description=bytes(config.description);
    intent=new Enrollment(bytes(config.root),description.slice(0,16),new DataView(description.buffer).getBigUint64(16),bytes(config.family),BigInt(config.from),BigInt(config.until));
    const storage=bytes(data.id.match(/../g).map(value=>parseInt(value,16)));
    if(data.operation==='create') {
      owner=await Device.create(data.name,storage,intent);
      const initial=await owner.status();require(initial.phase()===Phase.Preparing&&initial.journal()===undefined,"initial phase");
      await status("created");
      const requests=await Promise.allSettled([owner.request(BigInt(Math.floor(Date.now()/1000))),owner.request(BigInt(Math.floor(Date.now()/1000)))]);
      if(requests[0].status!=='fulfilled'||requests[1].status!=='rejected'||requests[1].reason.code!=='Busy'||requests[1].reason.ownerClosed!==false||owner.is_closed())throw Error('concurrent request control');
      require(initial.phase()===Phase.Preparing&&initial.journal()===undefined,'snapshot changed');initial.free();
      require((await status('requested')).phase===Phase.Requested,'request phase');
      const request=await owner.request(BigInt(Math.floor(Date.now()/1000)));
      if(request.toString()!==requests[0].value.toString())throw Error('Busy changed original request');
      value={request:[...request],concurrent_request:'WouldBlock; original owner remained usable'};
    } else {
      const grantResponse=await fetch('/inputs/'+data.case+'-grant.json');if(!grantResponse.ok)throw Error('grant');
      const grant=await grantResponse.json();
      const signature=bytes(config.sdk_signature);if(data.badPolicy)signature[0]^=1;
      runtime=new QPeriaptRuntime(bytes(config.sdk_policy),signature,bytes(config.sdk_root),bytes(config.sdk_state),32,4);
      const statement=config.policies.required;const statementBytes=bytes(statement.wire);if(data.badProtocol)statementBytes[statementBytes.length-1]^=1;
      policy=new Policy(runtime,bytes(config.policy_root),bytes(config.family),BigInt(statement.version),bytes(statement.digest),statementBytes,BigInt(Math.floor(Date.now()/1000)));
      const digest=bytes(grant.digest);if(data.badGrant)digest[0]^=1;
      trust=new Trust(bytes(config.account),bytes(config.root),BigInt(grant.version),digest,bytes(config.family));
      owner=await Device.open(data.name,storage,intent);
      const before=await status('opened');
      const journal=await owner.accept(bytes(grant.certificate),bytes(grant.roster),trust,policy,BigInt(Math.floor(Date.now()/1000)));
      const admitted=await status('accepted');require([Phase.Accepted,Phase.Activating,Phase.Active].includes(admitted.phase),'admitted phase');
      require(admitted.journal.toString()===[...journal].toString(),'status replaced original journal');
      if(data.phase==='accept')value={phase:'accepted',journal:[...journal]};
      else if(data.phase==='prepare') {
        prepared=await owner.prepare(policy,BigInt(Math.floor(Date.now()/1000)));
        if(!prepared.requires_witness())throw Error('required witness downgraded');
        require((await status('prepared')).phase===Phase.Accepted,'prepared phase');
        value={phase:'requires-witness-enrollment',journal:[...journal],genesis:[...prepared.image_digest()],subject:[...prepared.subject()]};
      } else if(data.phase==='activate') {
        if(admitted.phase===Phase.Accepted){const preparation=await owner.prepare(policy,BigInt(Math.floor(Date.now()/1000)));require(preparation.requires_witness(),'required witness lost');preparation.free()}
        else require([Phase.Activating,Phase.Active].includes(admitted.phase),'recovery action');
        witness=Witness.for_loopback(bytes(config.witness_id),bytes(data.wrongPin?config.root:config.witness_public),new URL('/witness/'+data.case+'?mode='+(data.mode??'normal'),location.origin).href,data.timeout??5000);
        if(data.cancelBefore)await owner.close();
        const identity=await owner.activate(policy,witness,BigInt(Math.floor(Date.now()/1000)));
        require((await status('active')).phase===Phase.Active,'activation phase');
        if(data.closedRuntime){runtime.close();require((await status('closed-runtime-observation')).phase===Phase.Active,'status renewed authority')}
        const prekey=await owner.generate_prekey(policy,new Uint8Array(32).fill(55),Kind.OneTimePq,BigInt(config.from),BigInt(config.until),BigInt(Math.floor(Date.now()/1000)));
        value=data.pubop?await publication(owner,policy,config,data,()=>{pendingClose=owner.close()}):{phase:'active',journal:[...identity],prekey:[...prekey]};
      } else throw Error('unknown phase');
    }
  } catch(error) { failure=error;if(error.ownerClosed!==undefined){require(Boolean(owner)&&owner.is_closed()===error.ownerClosed,'ownerClosed disagrees');require(error.cause!==undefined,'cause lost')} }
  try {if(pendingClose)await pendingClose;if(owner)await owner.close();}catch(cleanup){failure=new AggregateError(failure?[failure,cleanup]:[cleanup],'operation/cleanup failed');}
  if(owner){require(owner.is_closed(),'explicit close not visible');const result=await Promise.allSettled([owner.status()]);require(result[0].status==='rejected'&&result[0].reason.code==='Closed'&&result[0].reason.ownerClosed===true,'closed status admitted');observations.push({label:'closed',closed:true,code:result[0].reason.code});owner.free();owner=undefined;}pendingClose=undefined;
  prepared?.free();witness?.free();trust?.free();intent?.free();policy?.close();policy?.free();runtime?.close();runtime?.free();
  if(failure)postMessage({done:true,error:String(failure),code:failure.code,ownerClosed:failure.ownerClosed,observations});else postMessage({done:true,value,observations});
};
postMessage({ready:true});
