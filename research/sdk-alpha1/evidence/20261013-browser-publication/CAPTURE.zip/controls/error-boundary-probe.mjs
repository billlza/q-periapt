import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const {path}=JSON.parse(await fs.readFile(process.argv[2],'utf8'));
const sdk=await import(pathToFileURL(path).href);
await sdk.default({module_or_path:await fs.readFile(path.replace(/\.js$/,'_bg.wasm'))});
const plan=new sdk.QPeriaptContinuityPublicationPlan(new Uint8Array(32).fill(77),1n,100n);
const marker=new Error('unexpected input coercion');
const invalid={toString(){throw marker}};
const result={};
try{plan.generate(sdk.QPeriaptContinuityPrekeyKind.SignedClassical,invalid,100n);result.rejected=false}
catch(error){result.rejected=true;result.markerEscaped=error===marker;result.code=error.code}
try{plan.generate(sdk.QPeriaptContinuityPrekeyKind.SignedClassical,1n,100n);plan.generate(sdk.QPeriaptContinuityPrekeyKind.LastResortPq,1n,100n);result.reusable=plan.artifact_size_bound()>0}
catch(error){result.reusable=false;result.reuseError=String(error)}
try{plan.free();result.freed=true}catch(error){result.freed=false;result.freeError=String(error)}
console.log(JSON.stringify(result));
