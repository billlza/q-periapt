from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(Path.cwd()/'target/continuity-browser-recovery'))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-publication';package=stage/'source/target/publication-package-01';web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True)
(web/'creation').mkdir(exist_ok=True)
shutil.copyfile(stage/'publication-worker.js',web/'creation/worker.js')
shutil.copyfile(stage/'publication-checks.js',web/'creation/publication-checks.js')
shutil.copyfile(root/'target/continuity-browser-recovery/controller.js',web/'creation/controller.js')
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Publication qualification</title><script type="module" src="./controller.js"></script>')
session='qpc-witness-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
source=json.loads((package/'sources-before.json').read_text())
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed npm web entry, shared owned device and required signed witness protocol; not HTTPS deployment qualification','source':source,'static_web':static,'native_binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'cases':[],'observations':[]}
sequence=0

def browser(args,label):
 with contextlib.chdir(out):
  result=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(result.stdout);(logs/(label+'.stderr')).write_bytes(result.stderr)
 sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':result.returncode})
 sdk.require(result.returncode==0 and not result.stderr,label+' CLI failure')
 return result.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}'
 script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode()
 sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution failed: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='witness')
 sdk.require(value['diagnostics']==[],'browser diagnostics')
 result=value['result'];state['observations'].append({'case':args['case'],'phase':args.get('phase',args['operation']),'result':result.get('observations',[])})
 return result

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def native(args,label):
 sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

verifier=root/'target/continuity-browser-creation/rust-target/debug/q-periapt-browser-publication-verifier'
state['native_verifier_sha256']=sdk.snapshot(verifier,maximum=256*1024*1024).sha256

def verify_artifact(value,config,grant,label):
 artifact=out/(label+'.bin');artifact.write_bytes(bytes(value['bytes']))
 checked=sdk.command([str(verifier),str(config),str(grant),str(artifact)],logs/(label+'-native'),root,environment=dict(os.environ))
 result=parse_strict_json_bytes(checked,label='native publication verification')
 sdk.require(all(result[field] is True for field in ['manifest_signature_verified','all_leaf_proofs_verified','policy_and_context_verified']),'native proof failed')
 for key in ['id','intent','artifact']:
  sdk.require(result[key]==value[key],'native public metadata differs: '+key)
 sdk.require(result['requests']==value['members'] and result['manifest_digest']==value['status']['manifest'],'native inventory or manifest differs')
 return result

def same(a,b):
 for key in ['id','intent','artifact','bytes','members','status']:
  sdk.require(a[key]==b[key],'original publication changed: '+key)

try:
 with serving(web,out,private,binary) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];addEventListener("error",event=>diagnostics.push(event.message));addEventListener("unhandledrejection",event=>diagnostics.push(String(event.reason)));}); return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700)
    native(['prepare',directory],case+'-authorities');config=inputs/(key+'.json');shutil.copyfile(directory/'PUBLIC.json',config)
    args={'case':key,'name':key+'-'+uuid.uuid4().hex[:10],'id':uuid.uuid4().hex+uuid.uuid4().hex,'operation':'activation'}
    success({**args,'operation':'create'})
    grant=inputs/(key+'-grant.json');native(['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    success({**args,'phase':'accept'});success({**args,'phase':'prepare'})
    native(['enroll',directory,grant,out/'captures'/(key+'-genesis.json')],case+'-enroll')
    success({**args,'phase':'activate'})
    args.update(phase='activate')
    if case=='healthy':sdk.require(success({**args,'pubop':'invalid-plan'})['invalid_plan_rejected'],'invalid plan control')
    initial=success({**args,'pubop':'next'});sdk.require(initial['status']['phase']==0,'next identity reserved early')
    args['publicationId']=initial['id'];row={'case':case,'initial':initial};state['cases'].append(row)
    if case!='healthy':
     options={'expire':{'clock':'expire'},'clock':{'clock':'throw'},'number':{'clock':'number'},'cancel':{'cancelAtClock':True},'deadline':{'publicationTimeout':1}}[case]
     rejected=invoke({**args,'pubop':'prepare',**options});row['rejected']=rejected
     allowed={'expire':['Validity'],'clock':['InvalidClock'],'number':['InvalidClock'],'cancel':['Cancelled','Closed'],'deadline':['Deadline']}[case]
     sdk.require(rejected.get('code') in allowed and rejected.get('ownerClosed') is True,'original publication failure differs: '+json.dumps(rejected))
     status=success({**args,'pubop':'status'});row['after_failure']=status
     if case in ['clock','number']:sdk.require(status['phase']==0,'initial clock failure mutated publication')
     if case in ['expire','cancel']:
      sdk.require(status['phase']==1 and status['intent'] is not None,'original reserved intent missing')
      retired=success({**args,'pubop':'abandon','intent':status['intent']});sdk.require(retired['phase']==3,'abandon failed')
      row['abandoned']=retired
      next_id=success({**args,'pubop':'next'});sdk.require(next_id['id']!=initial['id'] and next_id['status']['phase']==0,'retired ordinal reused')
      args['publicationId']=next_id['id']
    prepared=success({**args,'pubop':'prepare','concurrent':True});row['prepared']=prepared
    row['native_verification']=verify_artifact(prepared,config,grant,case+'-publication')
    retry=success({**args,'pubop':'prepare'});same(prepared,retry);row['retry']=retry
    if case=='healthy':
     conflict=invoke({**args,'pubop':'prepare','changedPlan':True});sdk.require(conflict.get('code')=='Conflict' and conflict.get('ownerClosed') is True,'changed plan was not refused');row['changed_plan']=conflict
     same(prepared,success({**args,'pubop':'prepare'}))
     wrong=prepared['artifact'].copy();wrong[0]^=1
     conflict=invoke({**args,'pubop':'retire','artifact':wrong});sdk.require(conflict.get('code')=='Conflict' and conflict.get('ownerClosed') is True,'wrong artifact retirement admitted');row['wrong_retirement']=conflict
     same(prepared,success({**args,'pubop':'prepare'}))
     original=bytes(prepared['bytes']);manifest_size=int.from_bytes(original[104:108],'big')
     for label,offset in [('manifest-signature',108+manifest_size-1),('membership-proof',len(original)-1)]:
      corrupt=bytearray(original);corrupt[offset]^=1;path=out/(label+'.bin');path.write_bytes(corrupt)
      result=capture_output([str(verifier),str(config),str(grant),str(path)],timeout_seconds=30,maximum_stdout_bytes=1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
      (logs/(label+'.stderr')).write_bytes(result.stderr);sdk.require(result.returncode!=0,'corrupted '+label+' verified')
      row[label+'_rejected']=True
    retired=success({**args,'pubop':'retire','artifact':prepared['artifact']});sdk.require(retired['phase']==3,'prepared history not retired');row['retired']=retired
    sdk.require(success({**args,'pubop':'status'})==retired,'retirement did not survive reopen')
    row['witness_records']=records[key];sdk.require(not failures,'server failures: '+json.dumps(failures))
    print(json.dumps({'case':case,'passed':True,'requests':len(records[key]),'clock_samples':prepared['samples']}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'server failures')
 for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web input changed')
 sdk.require(sdk.snapshot(binary,maximum=256*1024*1024).sha256==state['native_binary_sha256'],'authority binary changed')
 sdk.require(sdk.snapshot(verifier,maximum=256*1024*1024).sha256==state['native_verifier_sha256'],'verifier changed')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
