import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const {path}=JSON.parse(await fs.readFile(process.argv[2],'utf8'));
const sdk=await import(pathToFileURL(path).href);
await sdk.default({module_or_path:await fs.readFile(path.replace(/\.js$/,'_bg.wasm'))});
const results=[];
for(const [label,value] of [['fraction',1.5],['string','1'],['boolean',true],['overflow',4294967297],['negative-wrap',-4294967295],['coercible-object',{valueOf(){return 1}}]]){
 const plan=new sdk.QPeriaptContinuityPublicationPlan(new Uint8Array(32).fill(77),1n,100n);
 let admitted=false;
 try{plan.generate(value,1n,100n);plan.generate(sdk.QPeriaptContinuityPrekeyKind.LastResortPq,1n,100n);admitted=plan.artifact_size_bound()>0}catch(error){if(error.code!=='InvalidInput')throw error}
 finally{plan.free()}
 results.push({label,admitted});
}
console.log(JSON.stringify({scope:'actual generated JS/WASM ABI; no browser storage operation',results}));
