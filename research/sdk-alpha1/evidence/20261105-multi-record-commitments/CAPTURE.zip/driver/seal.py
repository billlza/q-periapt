from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-multi-record-commitments'
PIN = '21176899dfa2cfa9e07a15be6e30de8123a8a1df'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
prior_path = ROOT / 'research/sdk-alpha1/evidence/20261105-hidden-record-commitments/AUDIT.json'
prior = json.loads(prior_path.read_bytes())
files = {}; inventory = {}
extra = [
    'src/durable/messages/closure.rs', 'src/durable/messages/fanout/abandonment.rs',
    'src/durable/messages/fanout/codec.rs', 'src/durable/messages/resolution.rs',
    'src/durable/messages/rekey.rs', 'src/durable/messages/rekey/response.rs',
    'src/durable/messages/rekey/completion.rs',
    'src/durable/messages/tests/reservation_disclosure/aggregate_copy.rs',
    'src/durable/messages/tests/closure.rs']
names = set(prior['source_inputs']) | {'research/continuity-identity-candidate/' + n for n in extra}
for name in sorted(names):
    data = (ROOT / name).read_bytes()
    assert data == subprocess.check_output(['git', 'show', PIN + ':' + name], cwd=ROOT)
    if name in prior['source_inputs']: assert sha(data) == prior['source_inputs'][name]['sha256']
    files['source/' + name] = data
    inventory[name] = {'bytes': len(data), 'sha256': sha(data)}
prefix = ROOT / 'research/continuity-identity-candidate/src'
source = lambda n: (prefix / n).read_text()
durable = source('durable.rs')
image_struct = durable.split('struct Image {', 1)[1].split('\n}', 1)[0]
assert 'nonce' not in image_struct and 'wire:' not in image_struct
seal = durable.split('fn seal(', 1)[1].split('fn unseal(', 1)[0]
assert seal.index('let mut plaintext = crate::codec::encode_secret') < seal.index('getrandom::fill(&mut nonce)')
assert 'plaintext.extend_from_slice(&record.payload);' in seal and 'wire.extend_from_slice(&nonce);' in seal
intent = source('durable/write_intent.rs')
new_bound = intent.split('fn new_bound(', 1)[1].split('fn decode(', 1)[0]
assert 'wire.extend_from_slice(target);' in new_bound and 'Self::decode(&active.key, active.owner, active.id, &wire)' in new_bound
assert 'saved.value() == pending.wire' in intent
constructors = []
for name in inventory:
    if '/tests/' in name or name.endswith('/tests.rs'): continue
    for line, value in enumerate((ROOT / name).read_text().splitlines(), 1):
        if 'PendingWrite::new(' in value or 'PendingWrite::new_bound(' in value:
            constructors.append({'source': name, 'line': line, 'text': value.strip()})
assert len(constructors) == 4
closure = source('durable/messages/closure.rs')
mac = closure.split('fn report_mac(', 1)[1].split('fn require_independent(', 1)[0]
assert '.checked_sub(64)' in mac and 'mac.update(record.payload.get(..prefix)' in mac
assert 'mac.update(&[0; 64]);' in mac
begin = closure.split('async fn begin_closure(', 1)[1].split('pub async fn acknowledge_session_closure(', 1)[0]
ordered = ['getrandom::fill(key.as_mut_bytes())', 'SessionClosureId::from_trusted_state(',
           'report_mac(&image, record, &key)?', 'state.closure = Some(Pending { report, key })',
           'record.phase = DurableStatus::MessagesClosing', 'self.persist(&mut image).await?',
           'self.check_release(&image).await?', 'Ok(report)']
at = 0; closure_order = []
for token in ordered:
    position = begin.index(token, at); closure_order.append({'token': token, 'offset': position}); at = position + len(token)
fanout = source('durable/messages/fanout/abandonment.rs')
fanout_mac = fanout.split('fn report_mac(', 1)[1].split('pub(super) fn validate_report(', 1)[0]
assert 'mac.update(&batch.metadata());' in fanout_mac and 'mac.update(&record.payload);' in fanout_mac
codec = source('durable/messages/fanout/codec.rs')
metadata = codec.split('fn metadata(', 1)[1].split('pub(super) fn record(', 1)[0]
assert 'self.state' not in metadata and 'key.as_bytes()' not in metadata and 'report.as_bytes()' not in metadata
assert 'payload.extend_from_slice(key.as_bytes());' in codec
model = (ROOT / 'target/multi-epoch-replay/replay-01/original.spthy').read_bytes()
assert sha(model) == 'dde5d06a071b1560da0d4c28c3f1fd81a3c39708f9fd8564ee391ddc362bcf7f'
text = model.decode()
snapshot = text.split('rule (modulo E) Snapshot:', 1)[1].split('rule (modulo E) Reveal_Identity:', 1)[0]
cut = text.split('rule (modulo E) Cut:', 1)[1].split('rule (modulo E) Snapshot:', 1)[0]
assert 'Snapshot( s, role, %epoch, revision )' in snapshot
assert 'Out( senc(' in snapshot and 'sdec(' not in snapshot and 'Eq(' not in snapshot
assert 'WrappingKeyLeak( wa )' in cut and 'WrappingKeyLeak( wb )' in cut and 'Out( <wa, wb> )' in cut
query = 'multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
start = text.index('lemma ' + query + ' '); quote = text.index('"', text.index('all-traces', start))
formula = text[quote + 1:text.index('"', quote + 1)].encode()
assert sha(formula) == '0b92ee18d7731c7c83fa05329e486fd6813f8ea13d64ed92215346f10cdf8faa'
assert '%captured_epoch' in formula.decode() and '(#c < #saved)' in formula.decode()
assert 'Confirmed' not in formula.decode()
rules = re.findall(r'^rule \(modulo E\) ([A-Za-z0-9_]+):', text, re.M)
assert rules.count('Cut') == rules.count('Snapshot') == 1
lemma_count = len(re.findall(r'^lemma ', text, re.M)); assert lemma_count == 40
audit = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': PIN,
    'source_inputs': inventory, 'prior_41_source_inputs_unchanged': True,
    'source_scope': 'Pinned source bytes, nonce placement/order, pending constructor call sites, report transcript exclusion and frozen model/formula extraction. This is not whole-program noninterference or a proof-tool execution.',
    'pending_write_constructor_sites': constructors, 'image_struct_retains_outer_nonce': False,
    'plaintext_encoded_before_nonce_sampling': True, 'record_payload_copied_verbatim': True,
    'closure_key_report_tail_excluded_bytes': 64, 'closure_order': closure_order,
    'fanout_metadata_excludes_report_key_tail': True,
    'cleanup_report_macs_cover_private_payload': True,
    'failed_closure_attempt_automatically_invalidates_target': False,
    'model_sha256': sha(model), 'main_formula_sha256': sha(formula), 'retained_queries': lemma_count,
    'snapshot_outputs_encrypted_record': True, 'snapshot_requires_decryption_success': False,
    'main_exclusion_covers_other_target_session_epochs': True,
    'conditional_digest_bound': 'min(1, sum_i epsilon(q_i,Q_i)), q_i <= 1+5*K_i; per-nonce confinement and canonical-header separation required',
    'native_record_interface_refinement_complete': False, 'cleanup_mac_simulation_complete': False,
    'native_execution_performed': False, 'new_tamarin_execution_performed': False,
    'multi_epoch_computational_theorem_complete': False, 'release_claim_eligible': False,
    'primary_reference': {'url': 'https://arxiv.org/pdf/2206.08132', 'theorem': 'Theorem 2, equations (6)-(7)'}}
files['model/original.spthy'] = model
files['model/MAIN.formula.txt'] = formula
files['model/Snapshot.rule.txt'] = ('rule (modulo E) Snapshot:' + snapshot).encode()
files['model/Cut.rule.txt'] = ('rule (modulo E) Cut:' + cut).encode()
files['prior/AUDIT.json'] = prior_path.read_bytes()
files['driver/seal.py'] = Path(__file__).read_bytes()
files['documents/MULTI_RECORD_COMMITMENTS_V1.md'] = (ROOT / 'docs/continuity/MULTI_RECORD_COMMITMENTS_V1.md').read_bytes()
files['SOURCE_AUDIT.json'] = encode(audit)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('SOURCE_AUDIT.json', files['SOURCE_AUDIT.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
