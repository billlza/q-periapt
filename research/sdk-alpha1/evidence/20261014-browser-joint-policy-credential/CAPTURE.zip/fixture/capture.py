from pathlib import Path
import hashlib
import json
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
destination = root / 'research/sdk-alpha1/evidence/20261014-browser-joint-policy-credential'
destination.mkdir(parents=True)
manifest = json.loads((stage / 'SOURCE_OVERLAY.json').read_text())
for name, digest in manifest['overlay'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest, 'source drift: ' + name)
expected = {'run01': ['local', 'required'],
            'run02': ['commit-loss', 'worker-cut', 'closed', 'no-local-fallback'],
            'expiry01': ['local-committed', 'local-pending'],
            'expiry02': ['required-committed', 'required-closed']}
results = {}
members = {}
def include(path, name):
    sdk.require(name not in members and path.is_file() and not path.is_symlink(), 'capture member: ' + name)
    members[name] = sdk.snapshot(path, maximum=64*1024**2).data
for run, cases in expected.items():
    result = json.loads((stage / run / 'RESULT.json').read_text())
    sdk.require(result['completed'] and result['producer_unchanged'] and not result['release_claim_eligible'], 'incomplete run: ' + run)
    sdk.require([row['case'] for row in result['cases']] == cases and all(row['completed'] for row in result['cases']), 'scenario mismatch: ' + run)
    for name, digest in result['producer'].items():
        sdk.require(sdk.snapshot(Path(name), maximum=256*1024**2).sha256 == digest, 'producer drift: ' + name)
    results[run] = result
    for path in (stage / run).rglob('*'):
        relative = path.relative_to(stage / run)
        if path.is_file() and not any(part.startswith('.') for part in relative.parts):
            include(path, run + '/' + relative.as_posix())
    for folder in ('inputs', 'creation'):
        for path in (stage / (run + '-web') / folder).rglob('*'):
            if path.is_file(): include(path, run + '-web/' + path.relative_to(stage / (run + '-web')).as_posix())
for name in ('run.py', 'run-expiry.py', 'worker.js', 'worker-expiry.js', 'controller.js', 'server.py',
             'prepare-expiry.py', 'make-expiry-driver.py', 'verify-scope.py', 'capture.py',
             'SOURCE_OVERLAY.json', 'SCOPE_CHECKS.json', 'LINKER.json', 'failed-issuer-01.rs',
             'build-authority.py', 'build-authority-02.py', 'build-package.sh', 'build-package-02.sh',
             'build-package-03.sh', 'overlay.py', 'check.py', 'msrv.py'):
    include(stage / name, 'fixture/' + name)
for directory in ('authority', 'expiry-authority'):
    for name in ('Cargo.toml', 'Cargo.lock'):
        include(stage / directory / name, 'fixture/' + directory + '/' + name)
    for path in (stage / directory / 'src').rglob('*.rs'):
        include(path, 'fixture/' + directory + '/' + path.relative_to(stage / directory).as_posix())
for prefix in ('native-build', 'native-build-02', 'expiry-build', 'wasm-clippy', 'msrv-check', 'msrv-version', 'scope-format', 'scope-diff', 'package', 'package-02', 'package-03', 'lld-version'):
    for path in stage.glob(prefix + '.*'):
        if path.suffix in ('.json', '.stdout', '.stderr'): include(path, 'checks/' + path.name)
package = Path(manifest['source']) / 'target/browser-joint-package-03'
include(package.parent / 'browser-joint-build.py', 'fixture/browser-joint-build.py')
for path in package.iterdir():
    if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr'):
        include(path, 'package/' + path.name)
for name in manifest['overlay']:
    include(root / name, 'source-overlay/' + name)
archive = destination / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 14, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100600 << 16
        output.writestr(info, data)
with zipfile.ZipFile(archive) as saved:
    sdk.require(saved.testzip() is None and len(saved.namelist()) == len(members), 'capture validation')
    for name, data in members.items(): sdk.require(saved.read(name) == data, 'capture payload drift')
installed = json.loads((package / 'INSTALLED_CONSUMER.json').read_text())
case_results = [{'run': name, 'case': row['case'], 'calls': len(row['calls']),
                 'completed': row['completed'], **({'real_expiry': row['real_expiry']} if 'real_expiry' in row else {})}
                for name, result in results.items() for row in result['cases']]
checks = {'schema': 1, 'completed': True, 'release_claim_eligible': False,
    'source_base': manifest['base_commit'], 'source_overlay': manifest['overlay'],
    'archive': {'path': archive.name, 'sha256': sdk.snapshot(archive).sha256, 'bytes': archive.stat().st_size, 'members': len(members)},
    'installed_package': {'sha256': installed['sha256'], 'manifest_sha256': installed['manifest_sha256'],
                          'node_tests': installed['installed_node_tests'], 'typescript': installed['typescript']},
    'cases': case_results, 'browser_calls': sum(row['calls'] for row in case_results),
    'controls': json.loads((stage / 'SCOPE_CHECKS.json').read_text()),
    'scope': 'Actual installed package in Chrome on macOS arm64; fresh cohorts, same shared native implementation in independent issuer/witness processes',
    'remaining': ['Original application messages and rekey through browser G1/T1 and G2/T2',
                  'Local browser journal-commit/receipt persistence cut during historical continuation',
                  'Independent protocol implementation, other browser engines/platforms, full lifecycle and release gates',
                  'Current remote CI/CodeQL and public release remain separate'],
    'retained_failures': ['package01/02 linker could not load pinned LLVM; package03 sets existing library path after hardened shell boundary',
                          'native-build01 issuer fixture had Arc<Runtime> reference type error; build02 fixed fixture only'],
    'private_material_archived': False}
sdk.write_json(destination / 'CHECKS.json', checks)
print(json.dumps({'captured': True, 'archive': checks['archive'], 'cases': len(case_results), 'browser_calls': checks['browser_calls']}))
