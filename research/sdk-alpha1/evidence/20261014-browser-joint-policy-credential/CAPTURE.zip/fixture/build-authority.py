from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
cargo = Path(env['RUSTC']).parent / 'cargo'
sdk.command([str(cargo), 'build', '--locked', '--offline', '--bins', '--message-format=json',
    '--target-dir', str(stage / 'native-target'), '-j', '2'], stage / 'native-build', stage / 'authority', environment=env)
print('Fresh seed, joint issuer and public witness handlers built')
