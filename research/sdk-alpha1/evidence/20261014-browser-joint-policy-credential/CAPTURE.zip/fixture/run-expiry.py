from pathlib import Path
import time
import contextlib
import json
import os
import shutil
import sys
import uuid
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0, str(Path(__file__).parent))
from server import serving

root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
label, *cases = sys.argv[1:]
allowed = {'local-committed', 'local-pending', 'required-committed', 'required-closed'}
sdk.require(cases and len(cases) == len(set(cases)) and set(cases) <= allowed, 'scenario selection')
package = root / 'target/continuity-browser-publication/source/target/browser-joint-package-03'
installed = Path(json.loads((package / 'consumer-location.json').read_text())['path'])
web = stage / (label + '-web')
shutil.copytree(installed, web, ignore=shutil.ignore_patterns('inputs', 'creation'))
inputs = web / 'inputs'; inputs.mkdir(mode=0o700)
(web / 'creation').mkdir()
for name in ('worker.js', 'controller.js'): shutil.copyfile(stage / ('worker-expiry.js' if name == 'worker.js' else name), web / 'creation' / name)
(web / 'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Joint policy maintenance</title><script type="module" src="./controller.js"></script>')
output = stage / label; output.mkdir(mode=0o700)
logs = output / 'logs'; logs.mkdir()
private = stage / (label + '-private'); private.mkdir(mode=0o700)
session = 'qpc-joint-' + uuid.uuid4().hex
node = Path('/opt/homebrew/bin/node').resolve()
cli = Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binaries = {name: stage / ('native-target/debug/qpc-joint-' + name) for name in ('seed', 'issuer', 'witness')}
binaries['issuer'] = stage / 'expiry-native-target/debug/qpc-joint-expiry-issuer'
static = {p.relative_to(web).as_posix(): sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
sdk.require(all(sdk.snapshot(installed / name).sha256 == digest for name, digest in static.items() if not name.startswith('creation/')), 'installed browser copy drift')
producer = {str(p): sdk.snapshot(p, maximum=256*1024**2).sha256 for p in [node, cli, *binaries.values(), Path(__file__), stage / 'worker-expiry.js', stage / 'controller.js', stage / 'server.py']}
state = {'completed': False, 'release_claim_eligible': False, 'producer': producer, 'static_web': static,
         'scope': 'Real-clock expiry of installed browser joint G/T; historical outcome is separate from current admission; no session traffic claim', 'cases': []}
sequence = 0

def browser(args, name):
    with contextlib.chdir(output):
        result = capture_output([str(node), str(cli), '--session', session, *args], timeout_seconds=80,
            maximum_stdout_bytes=4*1024**2, maximum_stderr_bytes=1024**2, environment=dict(os.environ))
    (logs / (name + '.stdout')).write_bytes(result.stdout); (logs / (name + '.stderr')).write_bytes(result.stderr)
    sdk.write_json(logs / (name + '.json'), {'argv': args, 'returncode': result.returncode})
    sdk.require(result.returncode == 0 and not result.stderr, 'browser CLI failed: ' + name)
    return result.stdout

def invoke(args):
    global sequence
    sequence += 1; name = f'step-{sequence:03}'
    script = logs / (name + '.js')
    script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), ' + json.dumps(args) + '); return {result, diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
    raw = browser(['run-code', '--filename', str(script)], name).decode()
    sdk.require(raw.count('### Result\n') == 1 and '### Error' not in raw, 'browser execution envelope')
    value = parse_strict_json_bytes(raw.split('### Result\n', 1)[1].split('\n### ', 1)[0].encode(), label='joint browser result')
    sdk.require(value['diagnostics'] == [], 'browser diagnostics')
    result = value['result']; sdk.require(result.get('cleanupErrors', []) == [], 'browser cleanup failed')
    state['cases'][-1]['calls'].append({'action': args['action'], 'generation': args.get('generation'), 'result': result})
    return result

def success(args):
    result = invoke(args)
    sdk.require('value' in result and 'error' not in result, 'browser operation failed: ' + json.dumps(result))
    return result['value']

def native(kind, args, name):
    return sdk.command([str(binaries[kind]), *map(str, args)], logs / name, root, environment=dict(os.environ))

def assert_status(value, issued, phase):
    status = value['status']
    sdk.require(status['phase'] == phase and status['operation'] == issued['operation'] and status['statement'] == issued['transaction'], 'wrong joint status')


try:
    with serving(web, output, private, binaries['witness']) as (origin, records, failures):
        try:
            browser(['open', origin + '/creation/index.html', '--browser', 'chrome'], 'open')
            setup = logs / 'setup.js'
            setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[]; addEventListener("error",e=>diagnostics.push(e.message)); addEventListener("unhandledrejection",e=>diagnostics.push(String(e.reason)));}); return {ready:true}; }')
            browser(['run-code', '--filename', str(setup)], 'setup')
            for case in cases:
                key = label + '-' + case; directory = private / key; directory.mkdir(mode=0o700)
                row = {'case': case, 'calls': [], 'completed': False}; state['cases'].append(row)
                profile = case.split('-')[0]
                native('seed', ['prepare-expiring-policy', directory], case + '-seed')
                shutil.copyfile(directory / 'PUBLIC.json', inputs / (key + '.json'))
                cfg = json.loads((directory / 'PUBLIC.json').read_text())
                args = {'case': key, 'name': key + '-' + uuid.uuid4().hex[:8], 'id': uuid.uuid4().hex + uuid.uuid4().hex, 'profile': profile}
                success(dict(args, action='create'))
                original_path = inputs / (key + '-grant.json')
                native('seed', ['issue', directory, output / 'captures' / (key + '.bin'), original_path], case + '-enroll-grant')
                original = json.loads(original_path.read_text())
                accepted = success(dict(args, action='accept')); prepared = success(dict(args, action='prepare'))
                sdk.require(accepted['journal'] == prepared['journal'], 'original journal changed')
                if profile == 'required':
                    sdk.require(prepared['phase'] == 'requires-witness-enrollment', 'required witness omitted')
                    native('witness', ['enroll', directory, original_path, output / 'captures' / (key + '-genesis.json')], case + '-witness-enroll')
                registered = directory / 'REGISTERED.json'
                sdk.write_json(registered, dict(original, journal=prepared['journal']))
                active = success(dict(args, action='activate'))
                sdk.require(active['journal'] == prepared['journal'], 'original activation identity')
                row['journal'] = prepared['journal']
                selected = dict(args, generation=1, operation=list(os.urandom(32)))
                request = success(dict(selected, action='request'))['credentialRequest']
                request_path = output / (key + '-request.json'); sdk.write_json(request_path, request)
                issued_path = inputs / (key + '-joint-1.json')
                issuer_args = [directory, registered, '-', request_path, issued_path, profile]
                native('issuer', ['issue', *issuer_args], case + '-issue')
                issued = json.loads(issued_path.read_text())
                pending = success(dict(selected, action='stage')); assert_status(pending, issued, 2)
                if case == 'local-committed':
                    assert_status(success(dict(selected, action='local-commit')), issued, 4)
                elif case == 'required-committed':
                    proposal = success(dict(selected, action='witness-prepare'))['proposal']
                    metadata = output / (key + '-proposal.bin'); metadata.write_bytes(bytes(proposal))
                    native('issuer', ['approve', *issuer_args, metadata], case + '-approve')
                    lost = invoke(dict(selected, action='commit', proposal=proposal, mode='drop-commit'))
                    sdk.require(lost.get('code') == 'WitnessTransport' and lost.get('ownerClosed') is True, 'unknown result boundary')
                    sdk.require(any(v['trigger'] and v['commit_applied_reply'] for v in records.get(key, [])), 'no actual Applied cut')
                elif case == 'required-closed':
                    cancellation = success(dict(selected, action='cancel-prepare'))
                    metadata = output / (key + '-cancellation.bin'); metadata.write_bytes(bytes(cancellation['cancellation']))
                expiry = issued['policy']['valid_until']
                sdk.require(expiry == cfg['policy_until'] + 60 and time.time() < expiry, 'target not initially live')
                row['real_expiry'] = {'original_until': cfg['policy_until'], 'target_until': expiry, 'waiting_at': int(time.time())}
                print(json.dumps({'case': case, 'waiting_for_real_expiry': expiry, 'now': int(time.time())}), flush=True)
                while time.time() <= expiry:
                    time.sleep(min(10, max(0.1, expiry + 1 - time.time())))
                row['real_expiry']['resumed_at'] = int(time.time())
                if case == 'required-closed':
                    native('issuer', ['cancel', *issuer_args, metadata], case + '-close-after-expiry')
                start = len(records.get(key, []))
                for attempt in range(2):
                    action = 'historical-local' if profile == 'local' else 'history'
                    if case == 'local-pending':
                        result = invoke(dict(selected, action=action))
                        sdk.require(result.get('code') == 'Suspended' and result.get('ownerClosed') is True, 'Pending became a historical terminal')
                        sdk.require(int(result['observedAt']) > expiry, 'browser did not observe real expiry')
                        current = success(dict(selected, action='status')); assert_status(current, issued, 2)
                    else:
                        result = success(dict(selected, action=action)); assert_status(result, issued, 5 if case == 'required-closed' else 4)
                        sdk.require(result['runtimeCreated'] is False and int(result['observedAt']) > expiry, 'historical runtime/time boundary')
                sdk.require(all(v['request_tag'] not in (5,7) for v in records.get(key, [])[start:]), 'passive history sent Commit/Close')
                rejected = invoke(dict(selected, action='joint-activate'))
                sdk.require(rejected.get('code') == 'Validity' and int(rejected['observedAt']) > expiry, 'expired target admitted')
                assert_status(success(dict(selected, action='status')), issued, 2 if case == 'local-pending' else 5 if case == 'required-closed' else 4)
                row['completed'] = True
            sdk.require(not failures, 'witness handler failures: ' + json.dumps(failures))
            state['witness_records'] = records
        finally:
            browser(['close'], 'close')
    for name, digest in producer.items(): sdk.require(sdk.snapshot(Path(name), maximum=256*1024**2).sha256 == digest, 'producer drift')
    for name, digest in static.items(): sdk.require(sdk.snapshot(web / name).sha256 == digest, 'installed web drift')
    state.update(completed=True, producer_unchanged=True)
except BaseException as error:
    state['failure'] = repr(error)
    raise
finally:
    sdk.write_json(output / 'RESULT.json', state)
print(json.dumps({'completed': True, 'cases': cases, 'scope': state['scope']}))
