from pathlib import Path
import hashlib
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
source = root / 'target/continuity-browser-publication/source'
def git(base, *args):
    return subprocess.run(['git', *args], cwd=base, check=True, capture_output=True).stdout
expected = b'e7b3975508babbfbdb6368637f4440d028bce6b3\n'
sdk.require((source / '.git').is_dir() and git(source, 'rev-parse', 'HEAD') == expected
            and not git(source, 'status', '--porcelain'), 'source clone is not expected clean base')
paths = git(root, 'diff', '--name-only', '-z', 'HEAD').decode().strip('\0').split('\0')
paths += [
    'research/continuity-identity-candidate/src/browser/credentials/continuation.rs',
    'crates/q-periapt-sdk-wasm/src/continuity/credentials/continuation.rs',
]
sdk.require(len(paths) == len(set(paths)), 'duplicate overlay')
hashes = {}
for name in paths:
    data = sdk.snapshot(root / name).data
    destination = source / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
git(source, 'add', '--', *paths)
sdk.write_json(stage / 'SOURCE_OVERLAY.json', {'base_commit': expected.decode().strip(), 'source': str(source), 'overlay': hashes})
print('Browser joint package source overlay staged in owned real clone')
