from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
env['CC_wasm32_unknown_unknown'] = '/opt/homebrew/opt/llvm/bin/clang'
cargo = Path(env['RUSTC']).parent / 'cargo'
sdk.command([str(cargo), 'clippy', '--locked', '--offline', '-p', 'q-periapt-sdk-wasm',
    '--features', 'browser-continuity', '--lib', '--target', 'wasm32-unknown-unknown',
    '--target-dir', str(stage / 'wasm-check-target'), '-j', '2', '--', '-D', 'warnings'],
    stage / 'wasm-clippy', root, environment=env)
print('Browser joint API wasm Clippy passed')
