from pathlib import Path
import os
import subprocess
import wasm_sdk_package

toolchain = Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
# Set this after the protected system-shell/Python launcher boundary. /bin/sh
# strips incoming DYLD variables before it can run the existing package command.
os.environ['DYLD_FALLBACK_LIBRARY_PATH'] = str(toolchain / 'lib')
subprocess.run([str(toolchain / 'lib/rustlib/aarch64-apple-darwin/bin/rust-lld'),
                '-flavor', 'wasm', '--version'], check=True)
wasm_sdk_package.main()
