from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
work = stage / 'expiry-authority'
(work / 'src/bin').mkdir(parents=True)
for name in ('Cargo.toml', 'Cargo.lock'):
    sdk.copy(stage / 'authority' / name, work / name)
source = (stage / 'authority/src/bin/qpc-joint-issuer.rs').read_text()
old = '.until()\n                        .checked_add(600)'
sdk.require(source.count(old) == 1, 'exact policy lifetime expression')
source = source.replace(old, '.until()\n                        .checked_add(60)')
source = source.replace('issued["joint"] = json!(proof.as_bytes());',
    'issued["policy"]["valid_until"] = json!(target.historical().validity().until());\n    issued["joint"] = json!(proof.as_bytes());')
(work / 'src/bin/qpc-joint-expiry-issuer.rs').write_text(source)
worker = (stage / 'worker.js').read_text()
worker = worker.replace('let owner, value, primary, ownerClosed, runtime;', 'let owner, value, primary, ownerClosed, runtime, observedAt;')
worker = worker.replace('const description = bytes(cfg.description);', 'observedAt = String(at);\n    const description = bytes(cfg.description);')
worker = worker.replace('BigInt(cfg.until), at);', 'BigInt(Math.min(cfg.until, cfg.policy_until)), at);')
worker = worker.replace('code: primary?.code, ownerClosed, cleanupErrors', 'code: primary?.code, ownerClosed, cleanupErrors, observedAt')
worker = worker.replace('else postMessage({ done: true, value, cleanupErrors });', 'else postMessage({ done: true, value: {...value, observedAt}, cleanupErrors });')
(stage / 'worker-expiry.js').write_text(worker)
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
env.pop('CARGO_TARGET_DIR', None)
cargo = Path(env['RUSTC']).parent / 'cargo'
sdk.command([str(cargo), 'build', '--locked', '--offline', '--bins', '--message-format=json',
    '--target-dir', str(stage / 'expiry-native-target'), '-j', '2'], stage / 'expiry-build', work, environment=env)
print('Fresh real-expiry fixture built; target policy extends original by 60 seconds')
