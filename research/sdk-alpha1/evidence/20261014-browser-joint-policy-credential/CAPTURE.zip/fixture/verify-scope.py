from pathlib import Path
import json
import rust_sdk_profile as sdk
root = Path.cwd()
stage = root / 'target/continuity-browser-joint'
manifest = json.loads((stage / 'SOURCE_OVERLAY.json').read_text())
clone = Path(manifest['source'])
for name, digest in manifest['overlay'].items():
    sdk.require(sdk.snapshot(root / name).sha256 == digest and sdk.snapshot(clone / name).sha256 == digest, 'source overlay drift: ' + name)
env = json.loads((root / 'target/continuity-swift-policy-credential/APPLE_BUILD_ENVIRONMENT_02.json').read_text())
formatter = Path(env['RUSTC']).parent / 'rustfmt'
rust = sorted(name for name in manifest['overlay'] if name.endswith('.rs'))
sdk.command([str(formatter), '--check', '--edition', '2021', '--config', 'skip_children=true', *rust], stage / 'scope-format', root, environment=env)
sdk.command(['git', 'diff', '--check'], stage / 'scope-diff', root)
sdk.write_json(stage / 'SCOPE_CHECKS.json', {
    'overlay_unchanged': True, 'rust_files': rust, 'format_check': 'passed', 'diff_check': 'passed',
    'artifact_controls': {'command': 'QPERIAPT_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14 PYTHONPATH=artifact sh artifact/python-run.sh -m unittest artifact.test_codeql_rust_quality artifact.test_wasm_sdk_package',
                          'cwd': str(clone), 'session': 24633, 'returncode': 0, 'tests': 53, 'elapsed_seconds': 1.983,
                          'receipt': 'Original command session completed; terminal output retained in task tool history'},
    'source_overlay': manifest})
package = clone / 'target/browser-joint-package-03'
print(json.dumps({'scope_checks': 'passed', 'package_json_files': [p.name for p in package.glob('*.json')]}))
