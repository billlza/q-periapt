from pathlib import Path
import os,sys,subprocess,time,json,hashlib
base=Path(__file__).resolve().parent;repo=base.parent.parent
label,mode=sys.argv[1:3];version=sys.argv[3] if len(sys.argv)>3 else '1.98.1'
out=base/label;out.mkdir()
tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/(version+'-aarch64-apple-darwin')
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO_','QPERIAPT_','QPC_','DYLD_','LD_','PYTHON'))}
env.update(PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(repo/('target/native-stack-debug/msrv' if version=='1.90.0' else 'target/native-stack-debug/build')))
paths=list((repo/'crates').rglob('*.rs'))+list((repo/'crates').rglob('Cargo.toml'))+[repo/'Cargo.lock',repo/'Cargo.toml']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sources={str(p.relative_to(repo)):sha(p) for p in paths}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
common=['--locked','--offline','-p','q-periapt-cli','--features','policy-store-migration']
commands={'test':['test',*common,'--','--nocapture'], 'focused':['test',*common,'--bin','qperiapt','io_errors_across_both_providers','--','--nocapture'], 'clippy':['clippy',*common,'--all-targets','--','-D','warnings'], 'build':['build',*common], 'release':['test','--release',*common,'--','--nocapture'], 'default':['test','--locked','--offline','-p','q-periapt-cli']}
command=[str(tc/'bin/cargo'),*commands[mode]];start=time.monotonic()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:r=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
record={'head':head,'command':command,'returncode':r.returncode,'seconds':time.monotonic()-start,'sources':sources,'compiler_sha256':sha(tc/'bin/rustc'),'sources_unchanged':all(sha(repo/p)==h for p,h in sources.items()),'head_unchanged':head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'stdout_sha256':sha(out/'stdout'),'stderr_sha256':sha(out/'stderr')}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='sources'}),flush=True)
print((out/'stdout').read_text()[-4500:],flush=True);print((out/'stderr').read_text()[-4500:],flush=True)
assert record['sources_unchanged'] and record['head_unchanged']
sys.exit(r.returncode)
