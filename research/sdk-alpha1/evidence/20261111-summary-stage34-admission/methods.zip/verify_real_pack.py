"""Exercise the fixed admission API on private copies of retained official packs."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

ROOT = Path('/workspace/scratch/4b61438fb07b')
WORKTREE = ROOT / 'summary-stage34-admission'
OUTPUT = ROOT / 'summary-stage34-admission-validation'
sys.path.insert(0, str(WORKTREE / 'artifact'))
import codeql_summary_projection as projection


def inventory(root: Path) -> dict:
    records = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('unexpected symbolic link: ' + str(path))
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError('unexpected special file: ' + str(path))
        data = path.read_bytes()
        records[path.relative_to(root).as_posix()] = {
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return records


def canonical(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main() -> None:
    start = time.monotonic()
    receipt = {
        'schema': 1,
        'kind': 'qperiapt.stage34_projection_real_pack_admission',
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Python install/validate only; no CodeQL CLI, JVM, compilation, or query invocation',
        'official_bundle': {
            'codeql_version': '2.27.2',
            'archive_bytes': 98247028,
            'archive_sha256': 'acf2050189aeede5b9aa566f8fb382b02ac1ace72f534778f68b06fce5371cea'},
    }
    original = ROOT / 'summary-env-validation-20261111/original-pack'
    candidate = ROOT / 'summary-stage34-feasibility/candidate-query-pack'
    previous = ROOT / 'summary-plan-feasibility/candidate-query-pack'
    private = OUTPUT / 'accepted-pack'
    previous_private = OUTPUT / 'old-stage4-pack'
    evidence = OUTPUT / 'installation-evidence'
    original_before = inventory(original)
    candidate_before = inventory(candidate)
    previous_before = inventory(previous)
    assert len(original_before) == 1342
    assert len(candidate_before) == 1357
    shutil.copytree(original, private)
    evidence.mkdir()
    assert inventory(private) == original_before
    admitted = projection.install(private, evidence)
    validated = projection.validate(private)
    assert admitted == validated == projection.expected_identity()
    effective = inventory(private)
    assert effective == candidate_before
    changed = sorted(name for name in original_before if effective.get(name) != original_before[name])
    added = sorted(set(effective) - set(original_before))
    assert changed == sorted([
        '.codeql/libraries/' + projection.DEPENDENCY_PATH,
        projection.PLAN_PATH])
    assert added == sorted(name for name in admitted['files'] if name != projection.PLAN_PATH)
    assert len(added) == 15
    shutil.copytree(previous, previous_private)
    previous_copy_before = inventory(previous_private)
    assert previous_copy_before == previous_before
    try:
        projection.validate(previous_private)
    except ValueError as exc:
        rejected = {'exception_type': type(exc).__name__, 'message': str(exc)}
        assert 'projection dependency source' in str(exc) and 'DataFlowImpl.qll' in str(exc)
    else:
        raise AssertionError('old Stage4-only pack was accepted')
    assert inventory(previous_private) == previous_copy_before
    assert inventory(original) == original_before
    assert inventory(candidate) == candidate_before
    assert inventory(previous) == previous_before
    receipt.update({
        'finished_utc': datetime.now(timezone.utc).isoformat(),
        'seconds': time.monotonic() - start,
        'source_pack': {'path': str(original), 'file_count': len(original_before),
                        'inventory_sha256': canonical(original_before)},
        'installed_pack': {'path': str(private), 'file_count': len(effective),
                           'inventory_sha256': canonical(effective)},
        'frozen_candidate': {'path': str(candidate), 'file_count': len(candidate_before),
                             'inventory_sha256': canonical(candidate_before)},
        'exact_whole_pack_equality_with_frozen_candidate': True,
        'changed_existing_files': changed,
        'added_files': added,
        'all_39_root_sources_retained': True,
        'other_38_compiled_queries_retained': True,
        'all_1175_effective_dependencies_admitted': True,
        'all_15_stage_files_admitted': True,
        'install_validate_expected_identity_equal': True,
        'identity': admitted,
        'old_stage4_control': {
            'source_path': str(previous),
            'copy_path': str(previous_private),
            'inventory_sha256': canonical(previous_before),
            'rejected': True,
            'rejection': rejected,
            'all_bytes_preserved': True},
        'shared_source_candidate_and_old_stage4_packs_unchanged': True,
        'installation_evidence': inventory(evidence),
    })
    output = OUTPUT / 'REAL_PACK_ADMISSION.json'
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({
        'receipt': str(output),
        'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'seconds': receipt['seconds'],
        'effective_file_count': len(effective),
        'compiler_inputs_digest': admitted['compiler_inputs_digest'],
        'manifest_sha256': admitted['manifest_sha256'],
        'old_stage4_control': rejected}, indent=2))


if __name__ == '__main__':
    main()
