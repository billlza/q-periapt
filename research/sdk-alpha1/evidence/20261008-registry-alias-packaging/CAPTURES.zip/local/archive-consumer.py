from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tempfile, time, tomllib
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'artifact'))
import rust_sdk_profile as sdk

root = Path(__file__).resolve().parents[2]
base = root/'target/registry-alias-current'
output = base/sys.argv[1]
output.mkdir()
package = root/'target/policy-recovery-ffi-current/source/target/registry-alias-rust-package-01'
report = json.loads((package/'RUST_SDK_PACKAGE.json').read_text())
assert report['base_commit'] == 'de2c49e9e572972165a05411d2a11777f06e31b2'
consumer = Path(tempfile.mkdtemp(prefix='qperiapt-maintenance-archive-consumer-')).resolve()
assert not consumer.is_relative_to(root)
# Cargo resolves the optional rustls dependency even though this maintenance
# profile does not activate it. Keep its archive in the resolution closure.
names = (*sdk.CONSUMER_CRATES, 'q-periapt-cli')
selected_names = set(names) - {'q-periapt-rustls'}
inputs = {}
patches = []
for name in names:
    record = report['crates'][name]
    data = (package/'crates'/record['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == record['sha256']
    files = sdk.archive_files(data, name)
    assert set(files) == set(record['files'])
    destination = consumer/'packages'/f'{name}-0.2.0'
    for relative, value in files.items():
        path = destination/relative
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream: stream.write(value)
        inputs[str(path.relative_to(consumer))] = hashlib.sha256(value).hexdigest()
    if name != 'q-periapt-cli':
        patches.append(f'{name} = {{ path = "packages/{name}-0.2.0" }}')
(consumer/'Cargo.toml').write_text('[workspace]\nresolver = "3"\nmembers = ["packages/q-periapt-cli-0.2.0"]\n\n[patch.crates-io]\n'+'\n'.join(patches)+'\n')
shutil.copyfile(root/'Cargo.lock', consumer/'Cargo.lock')
toolbase = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244')
tc = toolbase/'rustup/toolchains/1.98.1-aarch64-apple-darwin'
env = {k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO','QPERIAPT','DYLD','LD_','PYTHON'))}
env.update(RUSTC=str(tc/'bin/rustc'), RUSTDOC=str(tc/'bin/rustdoc'), DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'), CARGO_HOME=str(package/'cargo-home'), CARGO_NET_OFFLINE='true', CARGO_TARGET_DIR=str(consumer/'build'), CARGO_BUILD_JOBS='2', RUSTFLAGS='-D warnings', QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14', PATH=str(tc/'bin')+':/Users/bill/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin')
commands = []
def run(label, argv, cwd):
    start = time.monotonic()
    with (output/f'{label}.stdout').open('wb') as so, (output/f'{label}.stderr').open('wb') as se:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=so, stderr=se, timeout=900)
    record = {'label':label, 'argv':argv, 'cwd':str(cwd), 'returncode':result.returncode, 'seconds':time.monotonic()-start}
    commands.append(record)
    (output/f'{label}.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record), flush=True)
    result.check_returncode()
    if label in ('build', 'metadata'):
        sdk.validate_cargo_output(label, [(output/f'{label}.{suffix}').read_text() for suffix in ('stdout', 'stderr')])
    return (output/f'{label}.stdout').read_bytes()
run('build', ['cargo','build','--offline','--release','-p','q-periapt-cli','--features','policy-store-migration'], consumer)
resolved = json.loads(run('metadata', ['cargo','metadata','--locked','--offline','--format-version','1','--features','policy-store-migration'], consumer))
def registry_packages(data):
    return {(p['name'],p['version'],p['source'],p['checksum']) for p in tomllib.loads(data)['package'] if 'source' in p}
locked = registry_packages((consumer/'Cargo.lock').read_text())
assert locked <= registry_packages((root/'Cargo.lock').read_text())
local = {p['name']:p for p in resolved['packages'] if p['source'] is None}
assert set(local)==selected_names
for name,p in local.items():
    assert Path(p['manifest_path']).resolve() == consumer/'packages'/f'{name}-0.2.0'/'Cargo.toml'
for name, version in [('redb','2.6.4'), ('redb','4.3.0'), ('twox-hash','2.1.4')]:
    assert any(p['name']==name and p['version']==version for p in resolved['packages'])
install = consumer/'installed/bin'
install.mkdir(parents=True)
binary = install/'qperiapt'
shutil.copy2(consumer/'build/release/qperiapt', binary)
binary.chmod(0o755)
run('installed', ['sh','artifact/python-run.sh','artifact/policy_store_migration_installed.py','--binary',str(binary),'--output',str(output/'installed-cases')], root)
for relative, digest in inputs.items():
    assert hashlib.sha256((consumer/relative).read_bytes()).hexdigest()==digest
assert hashlib.sha256(binary.read_bytes()).hexdigest()==hashlib.sha256((consumer/'build/release/qperiapt').read_bytes()).hexdigest()
result = {'source_commit':report['base_commit'],'consumer':str(consumer),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'crates':{n:report['crates'][n]['sha256'] for n in names},'resolved_local_packages':sorted(local),'external_packages':len(locked),'commands':commands,'archive_sources_unchanged':True,'public_registry_installation':False,'release_claim_eligible':False}
(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
