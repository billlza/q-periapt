from pathlib import Path
import hashlib, json, os, subprocess, sys, time
base = Path(__file__).resolve().parent
source = base.parent / 'policy-recovery-ffi-current/source'
out = base / sys.argv[1]
out.mkdir()
toolbase = Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244')
tc = toolbase / 'rustup/toolchains/1.98.1-aarch64-apple-darwin'
def git(*args): return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
head = git('rev-parse', 'HEAD')
assert not git('status', '--porcelain')
env = {k:v for k,v in os.environ.items() if not k.startswith(('CARGO', 'RUST', 'QPERIAPT', 'DYLD', 'LD_', 'PYTHON'))}
env.update(RUSTUP_HOME=str(toolbase/'rustup'), RUSTUP_TOOLCHAIN=tc.name, RUSTUP_AUTO_INSTALL='0', RUSTUP_NO_UPDATE_CHECK='1', RUSTC=str(tc/'bin/rustc'), RUSTDOC=str(tc/'bin/rustdoc'), CARGO_HOME=str(toolbase/'apple-cargo-home-ff4a153e'), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2', DYLD_FALLBACK_LIBRARY_PATH=str(tc/'lib'), DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer', QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14', PATH=str(tc/'bin')+':/Users/bill/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
commands = {
    'tests': ['sh', 'artifact/python-run.sh', '-m', 'unittest', 'discover', '-s', 'artifact', '-p', 'test_*.py'],
    'package': ['sh', 'artifact/rust-publish-contract.sh', '--profile', 'sdk-020', '--output', str(source/'target'/('registry-alias-'+sys.argv[1]))],
}
command = commands[sys.argv[2]]
started = time.monotonic()
with (out/'stdout.log').open('wb') as so, (out/'stderr.log').open('wb') as se:
    result = subprocess.run(command, cwd=source, env=env, stdout=so, stderr=se)
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
record = {'source':str(source), 'head':head, 'command':command, 'returncode':result.returncode, 'seconds':time.monotonic()-started, 'head_unchanged':git('rev-parse','HEAD')==head, 'clean_source_after':not git('status','--porcelain'), 'stdout_sha256':sha(out/'stdout.log'), 'stderr_sha256':sha(out/'stderr.log')}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print((out/'stderr.log').read_text()[-7000:],flush=True)
print((out/'stdout.log').read_text()[-2000:],flush=True)
assert record['head_unchanged'] and record['clean_source_after']
result.check_returncode()
