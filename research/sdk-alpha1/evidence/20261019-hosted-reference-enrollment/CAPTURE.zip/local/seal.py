from pathlib import Path
import hashlib,json,subprocess,zipfile
out=Path(__file__).resolve().parent
repo=out.parent.parent
head='0bc368155447b8c94f5c4151577824abdd91788a'
run=39196969740
metadata=json.loads(subprocess.check_output(['gh','api',f'repos/billlza/q-periapt/actions/runs/{run}'],timeout=60))
assert metadata['head_sha']==head and metadata['status']=='completed' and metadata['conclusion']=='success'
(out/'RUN_TERMINAL.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=[]
entries={}
for platform in ['ubuntu-24.04','macos-15']:
    row,=json.loads((out/f'READBACK_{platform}.json').read_text())
    assert row['head']==head and row['run']==run and len(row['test_names'])==18
    data=(out/platform/'upstream.zip').read_bytes()
    assert len(data)==row['artifact_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==row['artifact_sha256']
    rows.append(row)
    for path in sorted((out/platform).rglob('*')):
        if path.is_file():entries['local/'+path.relative_to(out).as_posix()]=path.read_bytes()
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {'.json','.py','.stdout','.stderr'}:
        entries['local/'+path.name]=path.read_bytes()
sources=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines()
assert len(sources)==22
for name in sources:entries['source/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-hosted-reference-enrollment'
dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for n,item in manifest.items():
        body=z.read(n);assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256']
data=archive.read_bytes()
checks={'head':head,'run':run,'source_files':len(sources),'readbacks':rows,'capture':{'bytes':len(data),'members':len(entries),'sha256':hashlib.sha256(data).hexdigest()},'scope':'Both terminal hosted test/build jobs and exact artifact digests read back. Each has18 test entries including1 dispatcher; ten distinct SIGKILL boundaries are asserted by the frozen producer tests. No executable or child private/marker state was exported. Not installed-client, enrollment HTTP, deployed HTTPS, revocation/full replacement or release admission.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text('''# Hosted reference enrollment transactions

[Run 39196969740](https://github.com/billlza/q-periapt/actions/runs/39196969740)
completed successfully at `0bc368155447b8c94f5c4151577824abdd91788a` on
Linux x86_64 and Apple Silicon. Both terminal artifacts were downloaded and
verified against GitHub's exact digest; no live job logs were read.

Each host passed formatting, 18 test entrypoints (17 behavioral tests and one
child dispatcher), strict all-target Clippy and the release build. The frozen
tests assert ten distinct SIGKILL boundaries, actual native SDK request/signing
and roster verification, account isolation, schema admission and actual TCP.
Readback checked every expected test name, the15+3 result summaries, exact Git
head/lock, target architecture and Rust1.98.1. No ignored or filtered tests were
accepted. Hardware authentication is not claimed: host authentication uses an
upstream software authenticator.

The archive contains both original artifacts, terminal metadata, readback code
and22 exact app/workflow source files. SDK dependency source is identified by
the Git head. Binary hashes are producer observations; executable bytes and
child private/marker state were not exported for replay. The earlier local
failure/repair and actual release-CLI receipt remains separate evidence.

Enrollment HTTP/browser controls, installed independent clients, deployed HTTPS,
device revocation and full root/device replacement remain open. The optional
host application is not an SDK account requirement or a release-admission claim.
''')
print(json.dumps(checks['capture']))
