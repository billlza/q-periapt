use super::{fixture, p, Result};
use mio::{Events, Interest, Poll, Token};
use serde_json::{json, Value};
use std::{fs, io::{self, Read, Write}, net::{SocketAddr, TcpListener, TcpStream}, os::unix::fs::DirBuilderExt, path::Path, sync::{Arc, Mutex}, thread, time::{Duration, Instant}};

pub struct Listener {
    socket: TcpListener,
    registered: mio::net::TcpListener,
    poll: Poll,
    events: Events,
}
impl Listener {
    pub fn bind() -> Result<Self> {
        let socket=TcpListener::bind("127.0.0.1:0")?;
        socket.set_nonblocking(true)?;
        let mut registered=mio::net::TcpListener::from_std(socket.try_clone()?);
        let poll=Poll::new()?;
        poll.registry().register(&mut registered,Token(1),Interest::READABLE)?;
        Ok(Self{socket,registered,poll,events:Events::with_capacity(4)})
    }
    pub fn address(&self)->io::Result<SocketAddr>{self.socket.local_addr()}
    pub fn accept(&mut self,cancel:&p::Cancellation)->Result<TcpStream>{
        let deadline=Instant::now()+Duration::from_secs(20);
        loop {
            if cancel.is_cancelled(){return Err("listener cancelled".into());}
            match self.socket.accept(){
                Ok((stream,_))=>{stream.set_nonblocking(false)?;return Ok(stream)},
                Err(e) if e.kind()==io::ErrorKind::WouldBlock=>{},
                Err(e) if e.kind()==io::ErrorKind::Interrupted=>continue,
                Err(e)=>return Err(e.into()),
            }
            let left=deadline.checked_duration_since(Instant::now()).ok_or("listener deadline")?;
            self.poll.poll(&mut self.events,Some(left.min(Duration::from_millis(50))))?;
        }
    }
}
impl Drop for Listener {
    fn drop(&mut self){if let Err(e)=self.poll.registry().deregister(&mut self.registered){eprintln!("listener deregistration failed: {e}");}}
}

#[derive(Default)]
struct Measurements { rows:Vec<Value>,handle_ns:u128,read_ns:u128,write_ns:u128 }
pub struct Witness {
    pub configured:fixture::WitnessFixture,
    metrics:Arc<Mutex<Measurements>>,
    stop:p::Cancellation,
    worker:Option<thread::JoinHandle<Result<()>>>,
}
impl Witness {
    pub fn start(path:&Path)->Result<Self>{
        fs::DirBuilder::new().mode(0o700).create(path)?;
        let key=p::JournalKey::provision(&path.join("wrap.key"))?;
        let store=Arc::new(Mutex::new(p::AnchorStore::provision(&path.join("witness.redb"),key,p::AnchorSigningKey::generate()?,p::AnchorIdentity::generate()?)?));
        let mut listener=Listener::bind()?;let address=listener.address()?;
        let stop=p::Cancellation::default();let cancellation=stop.clone();
        let metrics=Arc::new(Mutex::new(Measurements::default()));let captured=Arc::clone(&metrics);let owned=Arc::clone(&store);
        let worker=thread::spawn(move||->Result<()>{
            while !cancellation.is_cancelled(){
                let stream=listener.accept(&cancellation);
                if cancellation.is_cancelled(){break;}
                let mut stream=stream?;
                stream.set_read_timeout(Some(Duration::from_secs(3)))?;stream.set_write_timeout(Some(Duration::from_secs(3)))?;
                // Holding this lock through the complete exchange gives the host
                // a post-operation observation barrier without retaining payloads.
                let mut log=captured.lock().map_err(|_|"witness timing lock poisoned")?;
                if log.rows.len()>=16384{return Err("witness measurement capacity".into());}
                let start=Instant::now();let mut size=[0;4];stream.read_exact(&mut size)?;
                if u32::from_be_bytes(size)!=3674{return Err("witness frame width".into());}
                let mut request=vec![0;3674];stream.read_exact(&mut request)?;let read_ns=start.elapsed().as_nanos();
                let start=Instant::now();let reply=owned.lock().map_err(|_|"witness store poisoned")?.handle(&request,fixture::now()?)?;let handle_ns=start.elapsed().as_nanos();
                if reply.len()!=3659{return Err("witness reply width".into());}
                let start=Instant::now();stream.write_all(&3659u32.to_be_bytes())?;stream.write_all(&reply)?;let write_ns=start.elapsed().as_nanos();
                log.read_ns+=read_ns;log.handle_ns+=handle_ns;log.write_ns+=write_ns;
                log.rows.push(json!({"request_tag":request[204],"reply_tag":reply[204],"read_ns":read_ns,"handle_ns":handle_ns,"write_ns":write_ns}));
            }
            Ok(())
        });
        Ok(Self{configured:fixture::WitnessFixture{store,address},metrics,stop,worker:Some(worker)})
    }
    pub fn snapshot(&self)->Result<Value>{
        let v=self.metrics.lock().map_err(|_|"witness timing lock poisoned")?;
        Ok(json!({"requests":v.rows.len(),"handle_ns":v.handle_ns,"read_ns":v.read_ns,"write_ns":v.write_ns,"framed_bytes":v.rows.len()*7341}))
    }
    pub fn finish(&mut self)->Result<Value>{
        self.stop.cancel();
        self.worker.take().ok_or("witness already joined")?.join().map_err(|_|"witness panicked")??;
        self.configured.store.lock().map_err(|_|"witness store poisoned")?.close();
        let v=self.metrics.lock().map_err(|_|"witness timing lock poisoned")?;
        Ok(json!({"rows":v.rows,"handle_ns":v.handle_ns,"read_ns":v.read_ns,"write_ns":v.write_ns,"framed_bytes":v.rows.len()*7341,"closed":true}))
    }
}
impl Drop for Witness {
    fn drop(&mut self){self.stop.cancel();if let Some(t)=self.worker.take(){match t.join(){Ok(Ok(()))=>{},other=>eprintln!("unfinished witness cleanup: {other:?}")}}}
}
