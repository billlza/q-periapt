use super::{fixture,p,observer_io::Listener,Result};
use p::connection_transport::{ConnectionEndpoint,Consumer,Served};
use serde_json::{json,Value};
use std::{fs,io,net::SocketAddr,path::PathBuf,sync::mpsc,thread,time::{Duration,Instant}};
use q_periapt_host_store::filesystem::publish_private_bytes;

#[derive(Clone,Copy)]
pub enum Task { Bootstrap,Message{fail_after_effect:bool},Reopen,Stop }
struct Application {path:PathBuf,calls:u64,effects:u64,elapsed_ns:u128,fail_after_effect:bool}
impl Consumer for Application {
    fn commit(&mut self,session:[u8;32],delivery:&p::CommittedPlaintext)->io::Result<()>{
        let start=Instant::now();self.calls+=1;
        let name=delivery.message_id().as_bytes().iter().map(|v|format!("{v:02x}")).collect::<String>();
        let path=self.path.join(name);let mut value=session.to_vec();value.extend_from_slice(delivery.message_id().as_bytes());value.extend_from_slice(delivery.as_bytes());
        match fs::read(&path){
            Ok(before)=>{if before!=value{return Err(io::Error::other("application retry changed exact input"));}},
            Err(e) if e.kind()==io::ErrorKind::NotFound=>{publish_private_bytes(&path,&value).map_err(io::Error::other)?;self.effects+=1;},
            Err(e)=>return Err(e),
        }
        self.elapsed_ns+=start.elapsed().as_nanos();
        if self.fail_after_effect {self.fail_after_effect=false;return Err(io::Error::other("effect committed; host response intentionally unavailable"));}
        Ok(())
    }
}
pub struct Server {
    pub address:SocketAddr,
    pub open_ns:u128,
    commands:Option<mpsc::Sender<Task>>,
    responses:mpsc::Receiver<Result<Value>>,
    cancel:p::Cancellation,
    worker:Option<thread::JoinHandle<Result<()>>>,
}
impl Server {
    pub fn start(path:PathBuf,witness:Option<fixture::WitnessFixture>)->Result<Self>{
        let (tx,commands)=mpsc::channel();let (reply,responses)=mpsc::channel();let (ready,started)=mpsc::channel();
        let cancel=p::Cancellation::default();let cancelled=cancel.clone();
        let worker=thread::spawn(move||->Result<()>{
            let start=Instant::now();let mut peer=fixture::Peer::open_with_witness(&path,witness.as_ref())?;
            let mut endpoint=Some(ConnectionEndpoint::server(&peer.context,peer.credentials(),fixture::tls_limits())?);let open_ns=start.elapsed().as_nanos();
            let mut listener=Listener::bind()?;let address=listener.address()?;
            let mut application=Application{path:path.join("measured-effects"),calls:0,effects:0,elapsed_ns:0,fail_after_effect:false};
            use std::os::unix::fs::DirBuilderExt;fs::DirBuilder::new().mode(0o700).create(&application.path)?;
            ready.send((address,open_ns)).map_err(|_|"server readiness receiver closed")?;
            loop {
                let task=commands.recv_timeout(Duration::from_secs(30))?;
                if matches!(task,Task::Stop){peer.close();reply.send(Ok(json!({"closed":true,"calls":application.calls,"effects":application.effects,"application_ns":application.elapsed_ns}))).map_err(|_|"server terminal receiver closed")?;break;}
                let result=(||->Result<Value>{
                    if matches!(task,Task::Reopen){
                        let start=Instant::now();drop(endpoint.take());peer.close();peer=fixture::Peer::open_with_witness(&path,witness.as_ref())?;
                        endpoint=Some(ConnectionEndpoint::server(&peer.context,peer.credentials(),fixture::tls_limits())?);
                        return Ok(json!({"reopened":true,"elapsed_ns":start.elapsed().as_nanos()}));
                    }
                    let stream=listener.accept(&cancelled)?;
                    let start=Instant::now();
                    let expected_failure=matches!(task,Task::Message{fail_after_effect:true});application.fail_after_effect=expected_failure;
                    let calls=application.calls;let effects=application.effects;let app_ns=application.elapsed_ns;
                    let served=endpoint.as_ref().ok_or("server endpoint missing")?.serve(stream,peer.actor()?,&mut application,fixture::limits(),&cancelled,fixture::now);
                    let elapsed=start.elapsed().as_nanos();
                    let mut result=match served {
                        Ok(Served::Established(session)) if matches!(task,Task::Bootstrap)=>json!({"established":session}),
                        Ok(Served::Consumed{session,message,duplicate}) if !expected_failure=>json!({"consumed":true,"session":session,"message":message.as_bytes(),"duplicate":duplicate}),
                        Err(p::connection_transport::Error::Application(_)) if expected_failure && application.effects==effects+1=>json!({"application_result_lost":true}),
                        other=>return Err(format!("unexpected server outcome: {other:?}").into()),
                    };
                    result["elapsed_ns"]=json!(elapsed);result["calls"]=json!(application.calls-calls);result["effects"]=json!(application.effects-effects);result["application_ns"]=json!(application.elapsed_ns-app_ns);
                    Ok(result)
                })();
                let failed=result.is_err();reply.send(result).map_err(|_|"server result receiver closed")?;
                if failed{peer.close();return Err("measured server operation failed".into());}
            }
            Ok(())
        });
        let (address,open_ns)=match started.recv_timeout(Duration::from_secs(30)){
            Ok(value)=>value,
            Err(error)=>{cancel.cancel();drop(tx);worker.join().map_err(|_|"server startup panicked")??;return Err(error.into());},
        };
        Ok(Self{address,open_ns,commands:Some(tx),responses,cancel,worker:Some(worker)})
    }
    pub fn begin(&self,task:Task)->Result<()>{self.commands.as_ref().ok_or("server closed")?.send(task).map_err(|_|"server command closed".into())}
    pub fn finish_operation(&self)->Result<Value>{self.responses.recv_timeout(Duration::from_secs(30))?}
    pub fn finish(&mut self)->Result<Value>{
        self.begin(Task::Stop)?;let value=self.finish_operation()?;self.commands.take();
        self.worker.take().ok_or("server already joined")?.join().map_err(|_|"server panicked")??;Ok(value)
    }
}
impl Drop for Server {
    fn drop(&mut self){self.cancel.cancel();self.commands.take();if let Some(t)=self.worker.take(){match t.join(){Ok(Ok(()))=>{},other=>eprintln!("unfinished server cleanup: {other:?}")}}}
}
