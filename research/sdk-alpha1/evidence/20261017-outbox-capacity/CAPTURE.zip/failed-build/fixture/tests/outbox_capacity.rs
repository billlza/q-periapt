//! Actual enrolled-owner outbox capacity; process costs are not isolated SDK memory.
#[path = "/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/research/continuity-identity-candidate/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;
use q_periapt_continuity_identity_candidate as p;
use q_periapt_core::Xof256;
use p::connection_transport::{ConnectionEndpoint, Consumption, Run, Submission};
use observer_peer::{Server, Task};
use serde_json::{json, Value};
use std::{fs, io::Write, path::PathBuf, sync::Arc, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
fn check(value: bool, message: &str) -> Result<()> {
    if value { Ok(()) } else { Err(message.to_owned().into()) }
}
fn body(index: usize, length: usize) -> Vec<u8> {
    (0..length).map(|offset| ((index + offset) % 251) as u8).collect()
}
fn digest(bytes: &[u8]) -> [u8; 32] {
    let mut hash = q_periapt_backends::Sha3_256::new();
    hash.absorb_public(bytes);
    hash.squeeze32()
}
fn memory(label: &str, path: &std::path::Path) -> Result<Value> {
    // The observer reads a documented OS process counter. No product allocator,
    // entropy source, journal representation or timing interval is replaced.
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    let result = unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) };
    if result != 0 { return Err(std::io::Error::last_os_error().into()); }
    let usage = unsafe { usage.assume_init() };
    Ok(json!({"stage":label,"max_rss_bytes":usage.ru_maxrss,
        "journal_file_bytes":fs::metadata(path.join("journal.redb"))?.len()}))
}
fn transmit(client: &mut fixture::Peer, endpoint: &ConnectionEndpoint,
    address: std::net::SocketAddr, session: [u8;32], message: p::MessageId,
    plaintext: &[u8], ad: &[u8]) -> Result<()> {
    let name = client.peer_name.clone();
    let delivered = endpoint.send(client.actor()?, Submission { session, message,
        plaintext, associated_data:ad }, Run { address, server_name:&name,
        limits:p::connection_transport::RunLimits { exchanges:1,..fixture::limits() },
        cancel:&p::Cancellation::default() }, fixture::now)?;
    check(delivered.consumption == Consumption::Confirmed, "peer consumption not confirmed")
}

#[test]
fn measure_outbox_capacity() -> Result<()> {
    let profile = std::env::var("QPC_CAPACITY_PROFILE")?;
    check(matches!(profile.as_str(), "local" | "witness"), "unknown capacity profile")?;
    let length: usize = std::env::var("QPC_CAPACITY_PAYLOAD")?.parse()?;
    check(matches!(length, 0 | p::contract::MAX_PLAINTEXT_BYTES), "unsupported payload")?;
    let output = PathBuf::from(std::env::var_os("QPC_CAPACITY_OUTPUT").ok_or("output required")?);
    let root = PathBuf::from(std::env::var_os("QPERIAPT_PUBLIC_SERVICE_EVIDENCE").ok_or("fresh private root required")?);
    check(output.is_absolute() && !output.exists() && root.is_absolute() && !root.exists(), "fresh output and runtime required")?;
    let mut witness = if profile == "witness" { Some(observer_io::Witness::start(&root.with_extension("witness"))?) } else { None };
    let pin = witness.as_ref().map(|w| &w.configured);
    let setup = fixture::setup_enrolled_with_witness(pin)?;
    let mut client = fixture::Peer::open_with_witness(&setup.initiator, pin)?;
    let mut endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
    let server_witness = pin.map(|w| fixture::WitnessFixture { store:Arc::clone(&w.store), address:w.address });
    let mut server = Server::start(setup.responder.clone(), server_witness)?;
    server.begin(Task::Bootstrap)?;
    let request = p::InitiationId::generate()?;
    let name = client.peer_name.clone();
    let established = endpoint.establish(client.actor()?, request, Run { address:server.address,
        server_name:&name, limits:fixture::limits(), cancel:&p::Cancellation::default() }, fixture::now)?;
    check(server.finish_operation()?["established"] == json!(established.session), "bootstrap peers differ")?;
    let session = established.session;
    let ad = vec![0x73; p::contract::MAX_ASSOCIATED_DATA_BYTES];
    let capacity = p::contract::MAX_OUTSTANDING_MESSAGES;
    check(capacity == 64, "capacity contract changed")?;
    let mut samples = Vec::with_capacity(capacity + 1);
    let mut retained = Vec::with_capacity(capacity + 1);
    let mut resources = vec![memory("established", &setup.initiator)?];
    for index in 0..capacity {
        let plaintext = body(index, length);
        let journal = client.service.stores()?.0;
        let id = journal.next_message_id(&client.context, session, fixture::now()?)?;
        let start = Instant::now();
        let wire = journal.send_message(&client.context, session, id, &plaintext, &ad, fixture::now()?)?;
        let elapsed = start.elapsed().as_nanos();
        check(journal.message_status(&client.context, session, id)? == p::MessageStatus::Committed, "unconfirmed message not committed")?;
        retained.push((id, digest(&wire)));
        samples.push(json!({"index":index,"message":id.as_bytes(),"wire_sha3_256":digest(&wire),"wire_bytes":wire.len(),"commit_ns":elapsed}));
        drop(wire);
        if [1,8,16,32,64].contains(&(index+1)) {
            resources.push(memory(&format!("retained-{}",index+1), &setup.initiator)?);
            println!("OUTBOX_CAPACITY_STAGE retained={}",index+1);
        }
    }
    let journal = client.service.stores()?.0;
    let next = journal.next_message_id(&client.context, session, fixture::now()?)?;
    let extra = body(capacity, length);
    let rejected = journal.send_message(&client.context, session, next, &extra, &ad, fixture::now()?);
    check(matches!(rejected, Err(p::DurableError::Capacity)), "65th outstanding message not rejected as Capacity")?;
    check(journal.message_status(&client.context,session,next)? == p::MessageStatus::Absent, "capacity failure reserved new work")?;
    check(journal.next_message_id(&client.context,session,fixture::now()?)? == next, "capacity failure advanced next ID")?;
    let witness_at_capacity = match witness.as_ref() { Some(w) => w.snapshot()?, None => json!({"requests":0}) };
    server.begin(Task::Reopen)?;
    drop(endpoint); client.close();
    client = fixture::Peer::open_with_witness(&setup.initiator, witness.as_ref().map(|w| &w.configured))?;
    endpoint = ConnectionEndpoint::client(&client.context, client.credentials(), fixture::tls_limits())?;
    check(server.finish_operation()?["reopened"] == true, "original peer did not reopen")?;
    resources.push(memory("reopened-full", &setup.initiator)?);
    let journal = client.service.stores()?.0;
    check(journal.next_message_id(&client.context,session,fixture::now()?)? == next, "reopen changed next ID")?;
    check(matches!(journal.send_message(&client.context,session,next,&extra,&ad,fixture::now()?), Err(p::DurableError::Capacity)), "reopen lost outstanding capacity")?;
    let mut deliveries = Vec::with_capacity(capacity+1);
    for index in 0..=capacity {
        let (id, expected) = *retained.get(index).ok_or("retained original message missing")?;
        let plaintext = body(index, length);
        let journal = client.service.stores()?.0;
        let replayed = journal.send_message(&client.context,session,id,&plaintext,&ad,fixture::now()?)?;
        check(digest(&replayed) == expected, "reopen/replay changed committed ciphertext")?;
        drop(replayed);
        server.begin(Task::Message { fail_after_effect:false })?;
        transmit(&mut client,&endpoint,server.address,session,id,&plaintext,&ad)?;
        let delivery = server.finish_operation()?;
        check(delivery["effects"]==1 && delivery["calls"]==1, "original effect census differs")?;
        check(client.service.stores()?.0.message_status(&client.context,session,id)?==p::MessageStatus::Acknowledged, "ACK not retained")?;
        deliveries.push(json!({"index":index,"message":id.as_bytes(),"peer":delivery}));
        if index == 0 {
            let journal = client.service.stores()?.0;
            check(journal.next_message_id(&client.context,session,fixture::now()?)?==next,"reclamation changed original next ID")?;
            let start=Instant::now();
            let wire=journal.send_message(&client.context,session,next,&extra,&ad,fixture::now()?)?;
            let elapsed=start.elapsed().as_nanos();
            retained.push((next,digest(&wire)));
            samples.push(json!({"index":capacity,"message":next.as_bytes(),"wire_sha3_256":digest(&wire),"wire_bytes":wire.len(),"commit_ns":elapsed}));
            drop(wire);
            resources.push(memory("capacity-reclaimed-and-refilled", &setup.initiator)?);
        }
    }
    resources.push(memory("all-acknowledged", &setup.initiator)?);
    let summary=server.finish()?;
    check(summary["effects"]==capacity+1 && summary["calls"]==capacity+1,"final peer effects differ")?;
    for (index,(id,_)) in retained.iter().enumerate() {
        let name=id.as_bytes().iter().map(|b|format!("{b:02x}")).collect::<String>();
        let actual=fs::read(setup.responder.join("measured-effects").join(name))?;
        let mut expected=session.to_vec(); expected.extend_from_slice(id.as_bytes()); expected.extend_from_slice(&body(index,length));
        check(actual==expected,"independent durable business bytes differ")?;
    }
    client.close(); drop(endpoint); drop(client);
    let witness_record=match witness.as_mut() { Some(w)=>w.finish()?,None=>json!({"closed":true,"rows":[]}) };
    let value=json!({"completed":true,"profile":profile,"payload_bytes":length,"associated_data_bytes":ad.len(),
        "capacity":capacity,"server_open_ns":server.open_ns,"witness_at_capacity":witness_at_capacity,"session":session,"samples":samples,"resources":resources,"deliveries":deliveries,
        "capacity_refused_without_reservation":true,"original_owners_reopened_at_capacity":true,
        "all_replays_exact":true,"all_business_effects_verified":true,"server":summary,"witness":witness_record,
        "sdk_and_server_closed":true,"memory_scope":"Darwin whole-process high-water RSS: both SDK owners, optional witness and observer; not current RSS or isolated SDK allocation", "release_claim_eligible":false});
    let mut file=fs::OpenOptions::new().create_new(true).write(true).open(output)?;
    file.write_all(&serde_json::to_vec_pretty(&value)?)?; file.sync_all()?;
    println!("OUTBOX_CAPACITY_COMPLETE profile={profile} payload={length} retained={capacity} effects={}",capacity+1);
    Ok(())
}
