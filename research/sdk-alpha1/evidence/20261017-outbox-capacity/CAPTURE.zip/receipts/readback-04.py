"""Independently check all four capacity censuses and durable synthetic effects."""
from pathlib import Path
import copy, hashlib, json, statistics
import rust_sdk_profile as sdk
stage=Path(__file__).resolve().parent
cases=(('pilot-max','local',16384),('pilot-empty','local',0),('witness-max','witness',16384),('witness-empty','witness',0))
stages=['established','retained-1','retained-8','retained-16','retained-32','retained-64','reopened-full','capacity-reclaimed-and-refilled','all-acknowledged']
def require(value,message):
    if not value: raise ValueError(message)
def validate(value,run,files,profile,length):
    require(value['completed'] is True and run['completed'] is True,'incomplete runtime')
    require(value['profile']==profile and value['payload_bytes']==length and value['associated_data_bytes']==1024,'profile input mismatch')
    require(value['capacity']==64 and value['release_claim_eligible'] is False,'capacity/scope mismatch')
    for key in ('capacity_refused_without_reservation','original_owners_reopened_at_capacity','all_replays_exact','all_business_effects_verified','sdk_and_server_closed'):
        require(value[key] is True,'missing outcome: '+key)
    require(value['server']['closed'] is True and value['server']['calls']==65 and value['server']['effects']==65,'server effect census')
    samples=value['samples']; deliveries=value['deliveries']; resources=value['resources']
    require(len(samples)==len(deliveries)==65,'incomplete sample set')
    require([r['stage'] for r in resources]==stages,'resource stage order differs')
    peaks=[r['max_rss_bytes'] for r in resources]
    require(all(type(x) is int and x>0 for x in peaks) and peaks==sorted(peaks),'invalid high-water RSS')
    require(run['resources']['max_rss_bytes']>=max(peaks),'whole-process RSS contradicts samples')
    session=bytes(value['session']); require(len(session)==32,'invalid session width')
    names=set()
    for index,(sample,delivery) in enumerate(zip(samples,deliveries,strict=True)):
        require(sample['index']==delivery['index']==index,'sample order substitution')
        require(type(sample['commit_ns']) is int and sample['commit_ns']>0,'invalid API duration')
        require(sample['wire_bytes']==109+length,'wire length differs')
        require(len(bytes(sample['wire_sha3_256']))==32,'ciphertext digest width differs')
        message=bytes(sample['message']); require(len(message)==32 and int.from_bytes(message[:8],'big')==0 and int.from_bytes(message[8:16],'big')==index,'message ordinal differs')
        peer=delivery['peer']
        require(bytes(delivery['message'])==message and bytes(peer['message'])==message and bytes(peer['session'])==session,'peer identity differs')
        require(peer['consumed'] is True and peer['duplicate'] is False and peer['effects']==peer['calls']==1,'peer consumption differs')
        name=message.hex(); require(name not in names,'duplicate durable effect'); names.add(name)
        expected=session+message+bytes((index+offset)%251 for offset in range(length))
        require(files.get(name)==expected,'durable effect bytes differ')
    require(set(files)==names,'durable effect inventory differs')
    return {'profile':profile,'payload_bytes':length,'effects':65,'retained_payload_bytes_at_capacity':64*length,
        'whole_process_max_rss_bytes':run['resources']['max_rss_bytes'],
        'at_capacity_max_rss_bytes':resources[5]['max_rss_bytes'],'at_capacity_journal_bytes':resources[5]['journal_file_bytes'],
        'after_drain_journal_bytes':resources[-1]['journal_file_bytes'],
        'first_eight_commit_median_ms':statistics.median(r['commit_ns'] for r in samples[:8])/1e6,
        'last_eight_fill_commit_median_ms':statistics.median(r['commit_ns'] for r in samples[56:64])/1e6}
summary=[]; sessions=set(); controls=0
build=json.loads((stage/'BUILD_OBSERVED_02.json').read_text())
for label,profile,length in cases:
    root=stage/label; run=json.loads((root/'RUN.json').read_text()); raw=(root/'RESULT.json').read_bytes(); value=json.loads(raw)
    require(run['source_commit']==build['source_commit'] and run['binary_sha256']==build['binary_sha256'],'source/binary identity differs')
    require(hashlib.sha256(raw).hexdigest()==run['result_sha256'],'result hash differs')
    require('test result: ok. 1 passed; 0 failed; 0 ignored;' in (root/'evidence/runtime.stdout').read_text(),'terminal test result absent')
    business=root/'runtime/responder/measured-effects'; files={p.name:p.read_bytes() for p in business.iterdir() if p.is_file() and not p.is_symlink()}
    summary.append({'case':label,**validate(value,run,files,profile,length)})
    require(bytes(value['session']) not in sessions,'fresh sessions reused'); sessions.add(bytes(value['session']))
    for index in range(65):
        altered=copy.deepcopy(value); altered['samples'][index]['index']+=1
        try: validate(altered,run,files,profile,length)
        except ValueError: controls+=1
        else: raise ValueError('reader accepted substituted sample')
    altered=copy.deepcopy(value); altered['original_owners_reopened_at_capacity']=False
    try: validate(altered,run,files,profile,length)
    except ValueError: controls+=1
    else: raise ValueError('reader accepted missing restart')
    for mutation in ('changed-effect','missing-effect'):
        changed=dict(files); name=next(iter(changed))
        if mutation=='changed-effect':changed[name]+=b'x'
        else:del changed[name]
        try: validate(value,run,changed,profile,length)
        except ValueError: controls+=1
        else: raise ValueError('reader accepted damaged effects')
report={'completed':True,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],
    'cases':summary,'business_effects_checked':260,'negative_controls_rejected':controls,
    'scope':'Four native source-bound single-session/epoch capacity observations. No tail, isolated SDK memory, energy, multi-session journal maximum, device or release-performance qualification.',
    'release_claim_eligible':False}
sdk.write_json(stage/'READBACK_04.json',report)
print(json.dumps(report,indent=2))
