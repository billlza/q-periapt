"""Execute one fresh bounded capacity cohort and retain successful or failed state."""
from pathlib import Path
import json, os, platform, re, subprocess, sys, time
from codeql_rust_profile import ProfileRun
import rust_sdk_profile as sdk
root=Path.cwd(); stage=Path(__file__).resolve().parent
label,profile,size=sys.argv[1:]; length=int(size)
sdk.require(re.fullmatch('[a-z0-9-]+',label) is not None and profile in {'local','witness'} and length in {0,16384},'cohort scope invalid')
build=json.loads((stage/'BUILD_OBSERVED_02.json').read_text()); binary=Path(build['binary'])
sdk.require(build['completed'] is True and sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'observer identity differs')
out=stage/label; out.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPERIAPT_PUBLIC_SERVICE_','QPC_CAPACITY_'))}
env.update(QPC_CAPACITY_PROFILE=profile,QPC_CAPACITY_PAYLOAD=str(length),QPC_CAPACITY_OUTPUT=str(out/'RESULT.json'),
    QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'runtime'),RUST_BACKTRACE='1')
run=ProfileRun(root,out,root/'target/continuity-codeql-2272-local-20261016/tools-03/codeql/codeql',env,host='darwin')
report={'completed':False,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],
    'profile':profile,'payload_bytes':length,'associated_data_bytes':1024,'capacity':64,
    'machine':platform.machine(),'os_release':platform.release(),'started_unix':time.time(),
    'load_before':os.getloadavg(),'host_controls':'Other applications and power settings unchanged; host load uncontrolled; no local task builds/tests overlap execution.',
    'release_claim_eligible':False}
try:
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product checkout dirty')
    sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'],'compiled source commit changed')
    print(json.dumps({'cohort':label,'profile':profile,'payload_bytes':length,'phase':'fresh capacity runtime'}),flush=True)
    raw=run.command('runtime',['/usr/bin/time','-l','-o',str(out/'time.txt'),str(binary),'--exact','measure_outbox_capacity','--nocapture','--test-threads=1'],seconds=900)
    sdk.require(b'test result: ok. 1 passed; 0 failed; 0 ignored;' in raw,'capacity test not terminal-successful')
    value=json.loads((out/'RESULT.json').read_text())
    sdk.require(value['completed'] and value['sdk_and_server_closed'] and value['profile']==profile and value['payload_bytes']==length,'runtime scope differs')
    sdk.require(len(value['samples'])==65 and len(value['deliveries'])==65 and value['server']['effects']==65,'complete message census differs')
    sdk.require(all(value[k] is True for k in ('capacity_refused_without_reservation','original_owners_reopened_at_capacity','all_replays_exact','all_business_effects_verified')),'required capacity/recovery observations missing')
    sdk.require([r['index'] for r in value['samples']]==list(range(65)),'message order differs')
    resource=(out/'time.txt').read_text(); rss=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resource,re.M)
    cpu=re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys',resource)
    sdk.require(rss is not None and cpu is not None,'Darwin process resource record absent')
    sdk.require(all(sdk.snapshot(stage/'fixture'/p).sha256==digest for p,digest in build['fixture_files'].items()),'observer source changed')
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product changed during cohort')
    report.update(completed=True,result_sha256=sdk.snapshot(out/'RESULT.json',maximum=32*1024**2).sha256,
        resources={'max_rss_bytes':int(rss[1]),'real_seconds':float(cpu[1]),'user_seconds':float(cpu[2]),'system_seconds':float(cpu[3])},
        stage_resources=value['resources'])
except BaseException as exc:
    report['failure']=repr(exc); raise
finally:
    report.update(finished_unix=time.time(),load_after=os.getloadavg(),runtime_state_preserved=True)
    sdk.write_json(out/'RUN.json',report)
print(json.dumps({'completed':True,'cohort':label,'resources':report['resources']}),flush=True)
