"""Public replay of exact original joint proposals, signed outcomes and process cuts."""
from pathlib import Path
import ast,hashlib,json,re,sys
root=Path.cwd();peer=root/'research/continuity-openssl-peer';out=root/'target/independent-public-inputs-01';base=out/'qualified-local-renewal'
sys.path.append(str(peer));sys.path.append(str(out))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from source_readback import source_bytes,continuity,normalized
from evidence_io import parse_strict_json_bytes
from fixture_inputs import load,load_witness_pin
from peer.witness import Operation,commitment,verify
from peer.local_renewal_protocol import Proposal
from peer.renewal import verify as verify_grant
from peer.bootstrap import digest
from peer.rekey import RekeyScope,genesis

def check(value,reason):
 if not value:raise ValueError(reason)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return parse_strict_json_bytes(path.read_bytes(),label=str(path))
report=read(base/'RESULT.json');sources=report['source_files']
check(len(sources)==88,'exact source inventory')
for name,expected in sources.items():
 data=source_bytes(name,expected);check(sha(data)==expected,'source hash')
 if name.endswith('.py'):ast.parse(data,name)
binary=(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
check(sha(binary)==report['native_sha256'] and binary[:4]==b'\xcf\xfa\xed\xfe' and int.from_bytes(binary[4:8],'little')==0x100000c,'actual ARM64 native executable')
check(not (out/'qualified-local-renewal.stderr').read_bytes(),'runtime diagnostics')
profiles={}
for label,expected_workers,kills_expected,outcome in [('applied',48,14,'Applied'),('closed',24,4,'Closed'),('unprepared-close',23,4,'Closed'),('pending-write',9,0,'OrdinaryWorkRemainsPending')]:
 folder=base/label;r=read(folder/'RESULT.json');native={};workers={}
 check(r['outcome']==outcome and len(r['worker_operations'])==expected_workers,'exact profile workload '+label)
 check(not (folder/'native/native.stderr').read_bytes(),'native diagnostics')
 for row in r['native_commands']:
  name=row['case'];check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name),'case path')
  before=(folder/'native/cases'/(name+'.input')).read_bytes();after=(folder/'native/cases'/(name+'.output')).read_bytes()
  check(sha(before)==row['input_sha256'] and sha(after[1:])==row['output_sha256'] and after[0]==row['status'],'actual native bytes')
  check(name not in native,'native case reuse');native[name]=(before,after,row['command'])
  if after[0]==2:check(after[1:].decode()==row['error'],'native refusal detail')
 kills=0
 for row in r['worker_operations']:
  name=row['case'];check(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',name),'worker path')
  request=read(folder/(name+'.request.json'));raw=(folder/(name+'.stdout')).read_bytes();error=(folder/(name+'.stderr')).read_text()
  check(request['action']==row['action'] and name not in workers,'worker action/identity');workers[name]=request
  if 'signal' in row:
   kills+=1;check(row['signal']=='SIGKILL' and read(folder/(name+'.stdout'))=={'pid':row['worker_pid'],'stage':row['cut']} and not error,'real cut identity')
  elif 'refused' in row:check(not raw and row['refused'] in error,'no output on refusal')
  else:check(not error and sha(raw)==row['stdout_sha256'],'successful worker bytes')
 check(kills==kills_expected==r['process_kills'],'actual kill count')
 def result(name):return read(folder/(name+'.stdout'))['result']
 public=folder/'native/public';pin=load_witness_pin(public);_,_,ctx=load(public,150,witness_pin=pin)
 enrolled=native['enrollment'][0];subject=enrolled[:96]
 check(len(enrolled)==128 and enrolled.hex()==result('provision') and subject[32:]==ctx.witness.owner+ctx.witness.policy,'exact genesis owner/policy')
 initial=bytes.fromhex(result('initial'));reply=native['bootstrap-reply'][1][1:];final=bytes.fromhex(result('finish'))
 check(ctx.initiator.open(initial,5,2440)[:40]==b'QPBSI001'+ctx.digest,'actual initial signature')
 check(ctx.responder.open(reply,6,1256)[:72]==b'QPBSR001'+ctx.digest+digest(b'initial-wire',initial),'actual response signature')
 check(final[:104]==b'QPBSF001'+ctx.digest+digest(b'initial-wire',initial)+digest(b'reply-wire',reply),'exact transcript')
 session=digest(b'session-id',final[:104]);check(result('activate')==session.hex() and native['complete'][1]==b'\1'+session,'same original session')
 check(result('original-id')==r['original_id'] and sha(bytes.fromhex(result('original-send')))==r['original_ciphertext_sha256'],'original outbox identity')
 proposals={}
 for index,filename in [(1,'first-proposal'),(2,'second-proposal')]:
  if not (folder/filename).exists():continue
  wire=(folder/filename).read_bytes();p=Proposal.decode(wire)
  target=(public/('pin-local-renewal-'+str(index)+'-target')).read_bytes()
  grant=verify_grant((public/('local-renewal-'+str(index))).read_bytes(),ctx.devices[0],ctx.family,ctx.policy_digest,target,now=210 if index==1 else 310)
  check(p.witness==pin.binding and p.subject==subject and p.operation==grant.operation and p.statement==grant.statement,'actual joint grant/proposal binding')
  check(grant.operation==(public/('local-renewal-'+str(index)+'-operation')).read_bytes() and grant.statement==(public/('local-renewal-'+str(index)+'-statement')).read_bytes(),'independent/native grant agreement')
  proposals[p.binding]=p
  if index==1:check(sha(wire)==r['first_proposal_sha256'],'original public proposal')
 challenges=set();signed=0;outcomes={};joint={};faults=[]
 for row in r['witness_attempts']:
  name=row['case'];wire=(folder/(name+'.request')).read_bytes();check(len(wire)==3674 and sha(wire)==row['request_sha256'],'request file')
  body=ctx.initiator.open(wire,7,297);operation=Operation(body[200],body[201:]);command=commitment(b'COMMAND',pin.binding+subject+operation.wire())
  check(body[:136]==b'QPANRQ01'+pin.binding+subject and body[136:168]==command and command.hex()==row['command_id'] and operation.kind==row['kind'],'request binding')
  check(body[168:200] not in challenges and any(body[168:200]) and body[168:200].hex()==row['challenge'],'fresh challenge');challenges.add(body[168:200])
  if row['fault']:faults.append(row)
  if row['delivery']=='not_dispatched_by_fixture':
   check(name not in native and row['fault']=='before','undispatched original');continue
  check(native[name][0]==wire and native[name][2]==31,'real request dispatch')
  response=native[name][1];check(response[0]==row['native_status'],'native status')
  if response[0]==2:
   check(row['delivery']=='native_rejected_no_signed_reply' and response[1:].decode()==row['error'],'actual unsigned refusal');continue
  reply=(folder/(name+'.reply')).read_bytes();check(response[1:]==reply and sha(reply)==row['signed_reply_sha256'],'actual signed reply')
  verified=verify(pin,subject,operation,body,reply);signed+=1;outcomes[verified.outcome]=outcomes.get(verified.outcome,0)+1
  if operation.kind in (5,6,7,8):
   p=proposals[operation.arguments[:32]];check(operation==p.command(operation.kind),'exact original renewal command')
   disposition=p.observe(verified);joint.setdefault(p.operation.hex(),[]).append((operation.kind,disposition))
  if row['delivery']=='sent':check(sha(reply)==row['transport_reply_sha256'],'actual transport bytes')
  else:check(row['delivery']=='signed_reply_withheld_by_fixture' and row['fault']=='after','retained lost reply')
 if label=='pending-write':
  check(not proposals and not joint and len(faults)==1 and faults[0]['kind']==2,'ordinary-only pending write')
  last=r['witness_attempts'][-1];check(last['command_id']==faults[0]['command_id'] and last['delivery']=='native_rejected_no_signed_reply','same ordinary command refused after expiry')
  check(native['clock-210'][0]==(210).to_bytes(8,'big'),'actual fixture expiry')
 else:
  first=Proposal.decode((folder/'first-proposal').read_bytes());first_events=joint[first.operation.hex()]
  check(result('unavailable-recovery')=='Unavailable' and result('ready-terminal-recovery')==outcome and result('retained-terminal-status')==outcome,'unknown/terminal separation')
  check(bytes.fromhex(result('historical-original-prepare-retry'))==first.wire(),'historical exact retry')
  check((8,'Acknowledged') in first_events,'genuine terminal ACK')
  first_ack=first_events.index((8,'Acknowledged'))
  check((6,'Unavailable') in first_events[first_ack+1:] and all(state=='Acknowledged' for kind,state in first_events if kind==8),'status pruned, exact ACK retained at floor')
  check(any(x['kind']==8 and x['fault']=='after' for x in faults),'lost ACK exercised')
  if label=='applied':
   check((5,'Applied') in first_events and result('format-six')==6,'applied joint authority')
   check(result('original-outbox-recovered')==result('original-send'),'original ciphertext preserved')
   check(native['native-original-receive'][1]==b'\1original retained message' and native['native-renewed-receive'][1]==b'\1new under local extension','actual native plaintext')
   check(native['independent-prepare'][:2]==(first.wire(),b'\1Prepared'),'independent genuine preparation')
   second=Proposal.decode((folder/'second-proposal').read_bytes());check(result('expired-policy-terminal-recovery')=='Applied' and (5,'Applied') in joint[second.operation.hex()],'second chained grant')
   check(native['independent-second-prepare'][:2]==(second.wire(),b'\1Prepared') and native['clock-401'][0]==(401).to_bytes(8,'big'),'actual second prepare and policy expiry')
   flights=[bytes.fromhex(result('renewed-rekey-offer')),native['renewed-rekey-response'][1][1:],bytes.fromhex(result('renewed-rekey-final')),native['renewed-rekey-receipt'][1][1:]]
   RekeyScope(ctx,session,0,genesis(session,ctx.digest)).public_completed(*flights)
   check(result('renewed-rekey-confirm')==1,'same-session renewed rekey')
  else:
   check(result('format-five-retained')==5 and not any(kind==5 and state=='Applied' for kind,state in first_events),'closed original format')
   if label=='unprepared-close':check(native['independent-historical-close'][:2]==(first.wire(),b'\1Closed'),'explicit root-authorized historical close')
   else:check((7,'Closed') in first_events,'real device close')
 profiles[label]={'workers':len(workers),'native_commands':len(native),'signed_witness_replies':signed,'unique_challenges':len(challenges),'actual_SIGKILL':kills,'negative_controls':len(r['refusals']),'outcome':outcome,'witness_outcomes':outcomes}
summary={'base_head':'ace757f40d1af6eaad75397a6909624082e76e2b','source_files':normalized(sources),'source_continuity':continuity(sources),'native_sha256':report['native_sha256'],'native_architecture':'MachO64 ARM64','profiles':profiles,'scope':'Public exact sources, native binary/bytes, root grants, original joint proposals, challenged signed outcomes, traffic/rekey and PID cut markers. Private MAC/AEAD, unchanged sealed target, staging quota and in-process cancellation assertions are not independently rederived. Native traffic clock stays 170; no full native enrollment, separate-host installation, whole-witness rollback, physical erasure, power-loss or PCS claim.'}
(out/'LOCAL_RENEWAL_READBACK.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(profiles))
