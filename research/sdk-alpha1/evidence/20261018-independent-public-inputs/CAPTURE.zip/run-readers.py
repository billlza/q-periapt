from pathlib import Path
import concurrent.futures,json,os,subprocess
out=Path(__file__).resolve().parent
names=['regressions','control','resolution','witness','peer-lifecycle','reply-release','local-renewal','local-credential','pending']
def run(name):
 command=['sh','artifact/python-run.sh',str(out/('review-'+name+'.py'))]
 with (out/('review-'+name+'.stdout')).open('xb') as o,(out/('review-'+name+'.stderr')).open('xb') as e:
  code=subprocess.run(command,stdout=o,stderr=e,env=dict(os.environ,QPERIAPT_PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14'),timeout=300).returncode
 result={'reader':name,'exit':code};print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,names))
(out/'READERS.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit'] for r in results):raise SystemExit(1)
