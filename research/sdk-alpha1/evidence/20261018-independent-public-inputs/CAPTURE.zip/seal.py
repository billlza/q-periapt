"""Seal public bootstrap inputs, current/historical boundaries and owner regression."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;peer=root/'research/continuity-openssl-peer';folder=root/'research/sdk-alpha1/evidence/20261018-independent-public-inputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
sources=json.loads((out/'SOURCE_FILES.json').read_text());assert len(sources)==88
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE','LOCAL_RENEWAL','LOCAL_CREDENTIAL','PENDING','PUBLIC_INPUTS']
reports={name:json.loads((out/(name+'_READBACK.json')).read_text())for name in labels}
for name,r in reports.items():
 if name!='REPLY_RELEASE':assert r['source_files']==sources and r['native_sha256']==reports['PUBLIC_INPUTS']['native_sha256']
runs=json.loads((out/'FINAL_RUNS.json').read_text());assert len(runs)==18 and all(r['exit']==0 for r in runs)
assert len(json.loads((out/'READERS.json').read_text()))==9 and all(r['exit']==0 for r in json.loads((out/'READERS.json').read_text()))
assert json.loads((out/'PUBLIC_READBACK_RUN.json').read_text())['exit']==0
with zipfile.ZipFile(root/'research/sdk-alpha1/evidence/20261018-independent-pending-recovery/CAPTURE.zip')as z:
 assert json.loads(z.read('NATIVE_SOURCES.json'))==json.loads((out/'NATIVE_SOURCES.json').read_text())
 assert sha(z.read('counterpart'))==sha((out/'counterpart').read_bytes())
entries={}
def add(name,data):
 assert name not in entries
 assert not data.startswith((b'QPREFJ01',b'QPREFI01',b'QPREFW01',b'QPRFLC01',b'QPRFLI01',*(('QPREFS0'+str(i)).encode()for i in range(1,9))))
 entries[name]=data
def tree(name):
 for p in sorted((out/name).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink()and p.name not in {'head','intent','authority','configuration','signer','key','wrong-signer'}and not p.name.startswith('.stage-')
  add(name+'/'+str(p.relative_to(out/name)),p.read_bytes())
for row in runs:
 name=row['output'];tree(name)
 for ext in ['stdout','stderr']:add(name+'.'+ext,(out/(name+'.'+ext)).read_bytes())
 assert not entries[name+'.stderr']
for p in sorted(out.glob('*')):
 if p.is_file()and p.suffix in ['.py','.json','.txt']and p.name!='seal.py':add(p.name,p.read_bytes())
add('seal.py',Path(__file__).read_bytes())
for name in ['importer-build','importer-clippy','quality-0','quality-1',
             'review-regressions','review-control','review-resolution','review-witness','review-peer-lifecycle','review-reply-release','review-local-renewal','review-local-credential','review-pending','review-public-inputs','readers','qualified']:
 for ext in ['stdout','stderr']:add(name+'.'+ext,(out/(name+'.'+ext)).read_bytes())
 if name.startswith('importer-'):assert not re.search(rb'(?m)^(error:|warning:)',entries[name+'.stderr'])
 else:assert not entries[name+'.stderr']
for name,expected in sources.items():
 b=(peer/name).read_bytes();assert sha(b)==expected and b==(out/'source'/name).read_bytes();add('source/'+name,b)
for name in ['README.md','PUBLIC_INPUTS.md']:add('source/'+name,(peer/name).read_bytes())
for name in ['counterpart','importer']:add(name,(out/name).read_bytes())
assert sha(entries['counterpart'])==reports['PUBLIC_INPUTS']['native_sha256']and sha(entries['importer'])==reports['PUBLIC_INPUTS']['importer_sha256']
for name in ['.github/workflows/independent-continuity.yml','research/continuity-identity-candidate/examples/import_bootstrap_bundle.rs','research/continuity-identity-candidate/Cargo.toml','research/continuity-identity-candidate/Cargo.lock']:add('integration/'+name,(root/name).read_bytes())
add('SOURCE_DIFF.patch',subprocess.check_output(['git','diff','--','.github/workflows/independent-continuity.yml','research/continuity-openssl-peer']))
scope={'base_head':'ace757f40d1af6eaad75397a6909624082e76e2b','change':'Independent native-compatible QPBNDL01 public input. Current verification unchanged. Original verification derives a candidate common interval start, rejects future snapshots, reuses all ordinary signature/pin/intersection checks, and requires independently retained original digest. Worker uses actual requested time instead of fixed150.',
 'qualification':'18entrypoints/10readers;exact88sources,79PythonAST,725Rustfiles.20actualRustimportercalls(2success18typedrefusal),49independentnegativecontrols,45960truncationcases. Expired historicalsnapshotcannotcreate local/witnessstate. All17existingentrypointsspannedcurrenthistoricalworker. No failures in final cohort.',
 'native':'Original2806counterpart and all725Rustsources match committedace7 capture exactly. Native importer268ee built/Clippiedstrictly offline/locked; importer source already existed, unchanged. No rebuild/repeatClippy of unchanged counterpart.',
 'limits':'Public context verification is neither account authentication nor enrollment; no installed/deployed service/lifetime-nativeRuntime promise. Pins and expectedoriginaldigest remain independent host inputs. Private journal/cancellation/no-output assertions remain runtime evidence. Fullsameaccount,pin/policy/witness/device/root replacement,installedlifecycle,resource/energy,retained-statePCS/refinement,finalABI/integration/externalreview/release stayopen.'}
add('SCOPE.json',(json.dumps(scope,indent=2)+'\n').encode())
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())};add('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode())
folder.mkdir();archive=folder/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(entries.items()):
  item=zipfile.ZipInfo(name,(2026,10,18,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,data)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for name,item in manifest.items():assert len(z.read(name))==item['bytes']and sha(z.read(name))==item['sha256']
result={'readbacks':reports,'quality':json.loads(entries['QUALITY.json']),'capture':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())},'scope':scope}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
