from pathlib import Path
import shutil
stage=Path('target/continuity-browser-network');crate=stage/'source/research/continuity-identity-candidate'
p=crate/'Cargo.toml';s=p.read_text().replace('[dependencies]','[lib]\ncrate-type = ["cdylib", "rlib"]\n\n[dependencies]\nserde_json = "=1.0.151"\nq-periapt-sig = { version = "=0.2.0", path = "../../crates/q-periapt-sig" }',1)
s=s.replace('web-time = "=1.1.0"','web-time = "=1.1.0"\nwasm-bindgen = "=0.2.129"\njs-sys = "=0.3.106"\nwasm-bindgen-futures = "=0.4.79"');p.write_text(s)
p=crate/'src/durable/anchoring.rs';s=p.read_text();start=s.index('    pub(crate) async fn open_anchored_admitted(');point=s.index('        let owner = bootstrap::storage_owner(device);',start)
prefix=s[start:point];assert prefix.endswith('        let db = open_private_database(path)?;\n')
helper=prefix.replace('open_anchored_admitted','open_anchored_database_admitted',1).replace('        path: &Path,','        db: Database,',1).replace('        let db = open_private_database(path)?;\n','')
s=s[:point]+s[point:]
s=s[:start]+prefix+'''        Self::open_anchored_database_admitted(db, key, device, policy, expected_id, client, admission).await
    }
'''+helper+s[point:];p.write_text(s)
p=crate/'src/crypto/persistence.rs';p.write_text(p.read_text()+'''
// Isolated fixture import. Uses the original sealed role/id/public-key checks.
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
pub(crate) fn probe_device(wrapping: &JournalKey, id: SigningKeyId, wire: &[u8]) -> Result<super::DeviceSigningKey, DurableError> {
    unseal(wrapping, id, 2, wire).map(|m|super::DeviceSigningKey(Some(m)))
}
''')
p=crate/'src/crypto.rs';p.write_text(p.read_text()+'''
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
pub(crate) use persistence::probe_device;
''')
p=crate/'src/durable.rs';p.write_text(p.read_text()+'\n// Isolated browser witness/journal qualification.\npub(crate) mod network_probe;\n')
p=crate/'src/lib.rs';p.write_text(p.read_text()+'''
#[cfg(not(target_arch = "wasm32"))]
pub use durable::network_probe::{prepare_network_probe, serve_network_probe, verify_network_probe};
#[cfg(target_arch = "wasm32")]
pub use durable::network_probe::NetworkJournalProbe;
''')
folder=crate/'src/durable/network_probe';folder.mkdir()
shutil.copyfile(Path('target/continuity-browser-journal/source/research/continuity-identity-candidate/src/durable/browser_probe/opfs.rs'),folder/'opfs.rs')
(stage/'web').mkdir();(stage/'cases').mkdir(mode=0o700)
