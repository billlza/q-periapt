async page=>{
 const pageErrors=[],consoleErrors=[];page.on('pageerror',e=>pageErrors.push(String(e)));
 page.on('console',m=>{if(m.type()==='error')consoleErrors.push({text:m.text(),location:m.location()})});
 await page.waitForFunction(()=>typeof window.runNetworkProbe==='function');
 const result=await page.evaluate(()=>window.runNetworkProbe());
 if(pageErrors.length)throw new Error(JSON.stringify(pageErrors));
 const unexpected=consoleErrors.filter(e=>!/^http:\/\/127\.0\.0\.1:\d+\/witness\/(drop-before|drop-after)\?mode=/.test(e.location.url));
 if(unexpected.length)throw new Error(JSON.stringify(unexpected));
 return {version:page.context().browser().version(),result,pageErrors,expectedTransportConsole:consoleErrors};
}
