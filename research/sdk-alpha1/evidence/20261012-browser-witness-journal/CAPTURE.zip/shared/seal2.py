import hashlib,json,pathlib,platform,subprocess,zipfile
root=pathlib.Path.cwd();parent=root/'target/continuity-browser-network';stage=parent/'cohort2';source=parent/'source'
out=root/'research/sdk-alpha1/evidence/20261012-browser-witness-journal'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pass_build(name):
    events=[json.loads(s) for s in (parent/name).read_text().splitlines()]
    finished=[x for x in events if x.get('reason')=='build-finished'];assert finished and finished[-1]['success'],name
    assert not [x for x in events if x.get('reason')=='compiler-message' and x['message']['level'] in ['warning','error']],name
for name in ['native-build3.jsonl','native-clippy1.jsonl','wasm-clippy1.jsonl','msrv-check.jsonl','main-native-clippy.jsonl','main-wasm-clippy.jsonl','main-msrv-check.jsonl']:pass_build(name)
result=json.loads((stage/'RESULT.json').read_text());browser=result['browser'];rows=browser['result']['rows'];assert len(rows)==7
assert browser['result']['status']=='passed' and browser['pageErrors']==browser['expectedTransportConsole']==[]
assert browser['result']['server']['failures']==[]
for row,native in zip(rows,result['native'],strict=True):
    assert row['mode']==native['case'] and row['recovered']==native['native']['after']
    assert row['exactRetry']=={'writes':0,'syncs':0}
    assert row['after']['revision']==2 and row['after']['pending'] is False
    captured=(stage/'cases'/row['mode']/'browser-recovered.redb').read_bytes()
    assert len(captured)==row['capture']['bytes'] and sha(captured)==row['capture']['sha256']
    if row['mode']!='normal':
        pending_bytes=(stage/'cases'/row['mode']/'pending-original.redb').read_bytes()
        assert len(pending_bytes)==row['pendingCapture']['bytes'] and sha(pending_bytes)==row['pendingCapture']['sha256']
        assert row['before']['revision']==1 and row['before']['pending'] is True
        assert row['before']['targetDigest']==row['after']['imageDigest']
        assert row['witnessBeforeRecovery']['revision']==(1 if row['mode']=='drop-before' else 2)
        assert native['byteEquality']=='original-pending-target-equals-browser-and-native-image-byte-for-byte: 5986 bytes'
assert '959 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (root/'target/continuity-browser-async/native-test1.stdout').read_text()
for name,n in [('policy-request-test.stdout',7),('credential-request-test.stdout',10)]:assert f'{n} passed; 0 failed; 0 ignored;' in (root/'target/continuity-browser-async'/name).read_text()
for pid in range(22787,22795):
    p=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True);assert p.returncode==1 and not p.stdout.strip(),pid
assert "Browser 'qpc-browser-network2' closed" in (stage/'browser-close.stdout').read_text()
assert not (stage/'server.stderr').read_text().strip()
files={}
for p in parent.iterdir():
    if p.is_file() and p.suffix in ['.py','.cjs','.js','.sh','.patch','.stdout','.stderr','.jsonl','.json'] and p.name not in ['HANDOFF.json','seal2.stdout','seal2.stderr','seal-final.stdout','seal-final.stderr']:files['shared/'+p.name]=p.read_bytes()
for name in ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']:
    p=parent/'cases'/name/'browser-recovered.redb';files['first-cohort/cases/'+name+'/browser-recovered.redb']=p.read_bytes()
for p in stage.iterdir():
    if p.is_file() and p.suffix in ['.py','.cjs','.js','.sh','.patch','.stdout','.stderr','.jsonl']:files['network/'+p.name]=p.read_bytes()
for p in (stage/'web').rglob('*'):
    if p.is_file():files['network/web/'+str(p.relative_to(stage/'web'))]=p.read_bytes()
selected={'fixture.json','initial.redb','pending-original.redb','browser-recovered.redb','native-recovered.redb','trace.jsonl','prepare.stdout','prepare.stderr','server.stderr','native-verify.stdout','native-verify.stderr','native-compare.stdout','native-compare.stderr'}
for case in (stage/'cases').iterdir():
    if case.is_dir():
        for p in case.iterdir():
            if p.name in selected or (p.suffix=='.bin' and p.name.startswith(('request-','reply-'))):files['network/cases/'+case.name+'/'+p.name]=p.read_bytes()
# Native witness wrapping keys/signing files and witness databases are intentionally
# excluded. Device wrapping byte171 is explicitly public synthetic fixture material.
assert not any(pathlib.PurePosixPath(n).name in ['witness.key','witness.signer','witness.redb','device.signer'] for n in files)
changed=subprocess.check_output(['git','-C',str(source),'diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','-C',str(source),'ls-files','--others','--exclude-standard'],text=True).splitlines()
for name in sorted(set(changed+untracked)):files['probe-source/'+name]=(source/name).read_bytes()
files['probe-source/changes.patch']=subprocess.check_output(['git','-C',str(source),'diff','--binary'])
for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines():files['main-source/'+name]=(root/name).read_bytes()
files['main-source/changes.patch']=subprocess.check_output(['git','diff','--binary'])
async_stage=root/'target/continuity-browser-async'
for p in async_stage.iterdir():
    if p.is_file() and (p.suffix in ['.py','.rs','.patch','.stdout','.stderr','.jsonl','.js'] or p.name=='CHECKS.json'):files['async/'+p.name]=p.read_bytes()
for sub in ['guard-web/clean','guard-web/red']:
    for p in (async_stage/sub).rglob('*'):
        if p.is_file():files['async/'+str(p.relative_to(async_stage))]=p.read_bytes()
comparator=root/'target/continuity-browser-journal/source/research/continuity-identity-candidate/src/bin/compare_browser_journal.rs'
files['native-comparator.rs']=comparator.read_bytes()
# Empty stdout files carry no trace content; retain their exact inventory in
# CHECKS instead of duplicating them as empty archive members. Failed/nonempty
# output and stderr remain archived. Never read the active sealing outputs.
empty_stdout=sorted(n for n,b in files.items() if n.endswith('.stdout') and not b)
for name in empty_stdout:del files[name]
assert len(files)<650,len(files)
out.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(files.items()):z.writestr(name,body)
with zipfile.ZipFile(out/'CAPTURE.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(files)
    for name,body in files.items():assert z.read(name)==body
checks={
 'schema':'qpc-browser-witness-journal/1','status':'shared-async-engine-and-required-journal-integration-passed',
 'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'host':platform.platform(),'architecture':platform.machine(),
 'capture':{'path':'CAPTURE.zip','sha256':sha((out/'CAPTURE.zip').read_bytes()),'members':len(files)},
 'files':{n:sha(b) for n,b in sorted(files.items())},
 'emptyStdoutFiles':empty_stdout,
 'emptyStdoutSha256':sha(b''),
 'browserCases':7,'nativeRecoveries':7,'byteEqualPendingTargets':6,'targetBytes':5986,
 'nativeTests':{'fullPreFinalRequestHelpers':959,'laterPolicyRequest':7,'laterCredentialRequest':10},
 'clippy':['native-all-features','wasm32-unknown-unknown'],'msrv':'native Rust1.90.0 all features',
 'cleanup':{'browserClosed':True,'serverAndWitnessPidsAbsent':list(range(22787,22795)),'serverExitCode':0},
 'failedCaptureAudit':'First-cohort comparator opened the original six recovery snapshots; redb open/close updated their storage metadata, breaking whole-file hashes. All first-cohort files remain locally. Cohort2 compares copies and verifies browser and pending originals still match their captured SHA256 values.',
 'fixtures':'Public byte171 wrapping material for freshly generated device fixture only. Native witness private keys and state excluded from archive.',
 'nativeFixtureBinarySha256':sha((root/'target/continuity-browser-engine/rust-target/debug/examples/network_probe').read_bytes()),
 'nativeComparatorBinarySha256':sha((root/'target/continuity-browser-engine/rust-target/debug/compare_browser_journal').read_bytes()),
 'browserContinuityAdmitted':False,'releaseClaimEligible':False,
 'remaining':['Public browser installation/signing/wrapping-key owners and operation adapter','Whole-profile rollback/eviction recovery','Peer transport and full product lifecycle','Exact new installed-package qualification and release gates'],
}
with (out/'CHECKS.json').open('x') as f:json.dump(checks,f,indent=2);f.write('\n')
with (out/'RESULT.json').open('x') as f:json.dump(result,f,separators=(',',':'));f.write('\n')
print(json.dumps({k:checks[k] for k in ['status','capture','browserCases','nativeRecoveries','byteEqualPendingTargets','targetBytes']},indent=2))
