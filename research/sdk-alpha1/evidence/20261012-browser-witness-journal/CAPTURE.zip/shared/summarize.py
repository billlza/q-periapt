import json,pathlib
stage=pathlib.Path('target/continuity-browser-network')
value=json.loads((stage/'browser-result.stdout').read_text().split('### Result\n',1)[1].split('\n### ',1)[0])
assert value['result']['status']=='passed' and not value['pageErrors']
assert len(value['result']['rows'])==7
native=json.loads((stage/'native-results.json').read_text());assert len(native)==7
for row,native_row in zip(value['result']['rows'],native,strict=True):
    assert row['mode']==native_row['case']
    assert native_row['native']['after']==row['recovered']
    if row['mode']!='normal':assert native_row['byteEquality']=='original-pending-target-equals-browser-and-native-image-byte-for-byte: 5986 bytes'
print(json.dumps({'browser':value['version'],'cases':[{'mode':r['mode'],'status':r['status'],'witnessBefore':r['witnessBeforeRecovery']['revision'],'pending':r['before']['pending'],'failure':r['failure']} for r in value['result']['rows']],'nativeRecovered':len(native),'byteEqualCases':sum('byteEquality' in r for r in native),'pageErrors':value['pageErrors'],'expectedTransportConsole':value['expectedTransportConsole']},indent=2))
with (stage/'RESULT.json').open('x') as f:json.dump({'browser':value,'native':native},f,separators=(',',':'));f.write('\n')
