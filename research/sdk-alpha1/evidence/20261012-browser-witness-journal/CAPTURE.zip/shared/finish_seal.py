from pathlib import Path
parent=Path('target/continuity-browser-network');p=parent/'seal2.py';s=p.read_text()
old="and p.name!='HANDOFF.json':files['shared/'+p.name]=p.read_bytes()"
new="and p.name not in ['HANDOFF.json','seal2.stdout','seal2.stderr','seal-final.stdout','seal-final.stderr']:files['shared/'+p.name]=p.read_bytes()"
assert old in s;s=s.replace(old,new)
point='assert len(files)<650,len(files)'
assert point in s;s=s.replace(point,"""# Empty stdout files carry no trace content; retain their exact inventory in
# CHECKS instead of duplicating them as empty archive members. Failed/nonempty
# output and stderr remain archived. Never read the active sealing outputs.
empty_stdout=sorted(n for n,b in files.items() if n.endswith('.stdout') and not b)
for name in empty_stdout:del files[name]
"""+point)
s=s.replace("'files':{n:sha(b) for n,b in sorted(files.items())},","'files':{n:sha(b) for n,b in sorted(files.items())},\n 'emptyStdoutFiles':empty_stdout,\n 'emptyStdoutSha256':sha(b''),")
p.write_text(s)
