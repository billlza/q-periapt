from pathlib import Path
parent=Path('target/continuity-browser-network');s=(parent/'seal.py').read_text()
s=s.replace("root=pathlib.Path.cwd();stage=root/'target/continuity-browser-network';source=stage/'source'", "root=pathlib.Path.cwd();parent=root/'target/continuity-browser-network';stage=parent/'cohort2';source=parent/'source'")
s=s.replace('(stage/name).read_text().splitlines()', '(parent/name).read_text().splitlines()')
s=s.replace('range(10070,10078)', 'range(22787,22795)').replace("Browser 'qpc-browser-network' closed", "Browser 'qpc-browser-network2' closed")
point="        assert row['before']['revision']==1 and row['before']['pending'] is True"
s=s.replace(point,"""        pending_bytes=(stage/'cases'/row['mode']/'pending-original.redb').read_bytes()
        assert len(pending_bytes)==row['pendingCapture']['bytes'] and sha(pending_bytes)==row['pendingCapture']['sha256']
"""+point)
point='files={}\n'
s=s.replace(point,point+"""for p in parent.iterdir():
    if p.is_file() and p.suffix in ['.py','.cjs','.js','.sh','.patch','.stdout','.stderr','.jsonl','.json'] and p.name!='HANDOFF.json':files['shared/'+p.name]=p.read_bytes()
for name in ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']:
    p=parent/'cases'/name/'browser-recovered.redb';files['first-cohort/cases/'+name+'/browser-recovered.redb']=p.read_bytes()
""")
s=s.replace("'fixtures':'Public byte171", "'failedCaptureAudit':'First-cohort comparator opened the original six recovery snapshots; redb open/close updated their storage metadata, breaking whole-file hashes. All first-cohort files remain locally. Cohort2 compares copies and verifies browser and pending originals still match their captured SHA256 values.',\n 'fixtures':'Public byte171")
(parent/'seal2.py').write_text(s)
