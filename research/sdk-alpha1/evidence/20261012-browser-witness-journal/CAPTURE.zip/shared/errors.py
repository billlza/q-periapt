import json,pathlib,sys
for name in sys.argv[1:]:
    for line in pathlib.Path('target/continuity-browser-network',name).read_text().splitlines():
        item=json.loads(line)
        if item.get('reason')=='compiler-message' and item['message']['level'] in ['error','warning']:print(item['message']['rendered'])
