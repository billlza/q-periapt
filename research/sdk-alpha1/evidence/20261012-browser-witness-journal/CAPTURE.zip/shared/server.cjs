const http=require('node:http'),fs=require('node:fs'),fsp=fs.promises,path=require('node:path'),{spawn}=require('node:child_process'),crypto=require('node:crypto');
const stage=path.resolve(process.argv[2]),binary=path.resolve(process.argv[3]),web=path.join(stage,'web');
const cases=new Map(),failures=[];let stopping=false;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const name of ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']){
 const directory=path.join(stage,'cases',name),errors=fs.openSync(path.join(directory,'server.stderr'),'wx',0o600);
 const child=spawn(binary,['serve',directory],{stdio:['pipe','pipe',errors]});fs.closeSync(errors);
 const c={directory,child,buffer:Buffer.alloc(0),pending:null,records:[],count:0,failed:null};cases.set(name,c);
 function fail(e){c.failed=String(e);if(c.pending){const p=c.pending;c.pending=null;clearTimeout(p.timer);p.reject(e)}if(!stopping)failures.push({name,error:String(e)})}
 child.on('error',fail);child.on('exit',(code,signal)=>{if(!stopping||code!==0)fail(new Error(`witness exited ${code}/${signal}`))});
 child.stdout.on('data',bytes=>{
  try{
   c.buffer=Buffer.concat([c.buffer,bytes]);if(c.buffer.length>65536)throw new Error('native frame bound');
   if(c.buffer.length<4)return;const n=c.buffer.readUInt32BE();if(n>32768||n===0)throw new Error('native frame width');if(c.buffer.length<4+n)return;
   const frame=c.buffer.subarray(4,4+n);c.buffer=c.buffer.subarray(4+n);if(!c.pending||c.buffer.length)throw new Error('unsolicited native response');
   const value=JSON.parse(frame.toString());
   if(!Array.isArray(value.reply)||value.reply.length!==3659||!value.head)throw new Error('native response shape');
   const p=c.pending;c.pending=null;clearTimeout(p.timer);p.resolve({reply:Buffer.from(value.reply),head:value.head});
  }catch(e){fail(e);child.kill('SIGTERM')}
 });
 c.exchange=request=>new Promise((resolve,reject)=>{
  if(c.failed||c.pending){reject(new Error(c.failed??'native witness busy'));return}
  const timer=setTimeout(()=>{fail(new Error('native witness deadline'));child.kill('SIGTERM')},10000);
  c.pending={resolve,reject,timer};const frame=Buffer.alloc(4+request.length);frame.writeUInt32BE(request.length);request.copy(frame,4);
  child.stdin.write(frame,e=>{if(e)fail(e)});
 });
}
function record(c,value){c.records.push(value);fs.appendFileSync(path.join(c.directory,'trace.jsonl'),JSON.stringify(value)+'\n',{mode:0o600})}
async function body(req,max){let size=0,parts=[];for await(const chunk of req){size+=chunk.length;if(size>max)throw new Error('body bound');parts.push(chunk)}return Buffer.concat(parts)}
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value))}
async function serve(req,res){
 const u=new URL(req.url,'http://127.0.0.1');let m;
 if(req.method==='GET'&&u.pathname==='/status'){json(res,200,{failures,cases:Object.fromEntries([...cases].map(([name,c])=>[name,{pending:!!c.pending,failed:c.failed,records:c.records}]))});return}
 if(req.method==='POST'&&(m=/^\/witness\/([a-z-]+)$/.exec(u.pathname))){
  const c=cases.get(m[1]);if(!c)throw new Error('case');const mode=u.searchParams.get('mode');if(!['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid'].includes(mode))throw new Error('mode');
  const request=await body(req,3674);if(request.length!==3674)throw new Error('request width');const count=++c.count;
  fs.writeFileSync(path.join(c.directory,`request-${count}.bin`),request,{flag:'wx',mode:0o600});record(c,{phase:'request',count,mode,sha256:hash(request)});
  if(mode==='drop-before'){record(c,{phase:'not-dispatched',count,mode});res.destroy();return}
  const result=await c.exchange(request);fs.writeFileSync(path.join(c.directory,`reply-${count}.bin`),result.reply,{flag:'wx',mode:0o600});record(c,{phase:'reply',count,mode,head:result.head,sha256:hash(result.reply)});
  if(mode==='drop-after'){res.destroy();return}
  if(['timeout','cancel','kill-after'].includes(mode)){
   const timer=setTimeout(()=>{record(c,{phase:'hold-expired',count,mode});res.destroy()},7000);
   res.once('close',()=>{clearTimeout(timer);record(c,{phase:'client-closed',count,mode})});return;
  }
  if(mode==='invalid')result.reply[result.reply.length-1]^=1;
  res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':result.reply.length,'Cache-Control':'no-store'});res.end(result.reply);return;
 }
 if(req.method==='POST'&&(m=/^\/capture\/([a-z-]+)\/([a-z-]+\.redb)$/.exec(u.pathname))){
  const c=cases.get(m[1]);if(!c)throw new Error('case');const content=await body(req,64*1024*1024);const f=await fsp.open(path.join(c.directory,m[2]),'wx',0o600);try{await f.writeFile(content);await f.sync()}finally{await f.close()}json(res,201,{bytes:content.length,sha256:hash(content)});return;
 }
 if(req.method==='GET'&&(m=/^\/fixture\/([a-z-]+)\/(fixture\.json|initial\.redb)$/.exec(u.pathname))){
  const c=cases.get(m[1]);if(!c)throw new Error('case');const data=await fsp.readFile(path.join(c.directory,m[2]));res.writeHead(200,{'Cache-Control':'no-store','Content-Length':data.length});res.end(data);return;
 }
 if(req.method!=='GET')throw new Error('method');const relative=u.pathname==='/'?'index.html':u.pathname.slice(1);const file=path.resolve(web,relative);
 if(!file.startsWith(web+path.sep)||!/^[-a-zA-Z0-9_/]+\.(?:html|mjs|js|wasm)$/.test(relative))throw new Error('static route');
 const data=await fsp.readFile(file),type=file.endsWith('.wasm')?'application/wasm':file.endsWith('.html')?'text/html':'text/javascript';
 res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store','Content-Length':data.length});res.end(data);
}
const server=http.createServer((req,res)=>{serve(req,res).catch(e=>{failures.push({request:req.url,error:String(e)});console.error(e);if(!res.headersSent)json(res,500,{error:String(e)});else res.destroy()})});
server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:`http://127.0.0.1:${server.address().port}/`,pid:process.pid,children:[...cases].map(([name,c])=>({name,pid:c.child.pid}))})));
process.on('SIGTERM',()=>{stopping=true;server.close();for(const c of cases.values())c.child.stdin.end();server.closeAllConnections()});
