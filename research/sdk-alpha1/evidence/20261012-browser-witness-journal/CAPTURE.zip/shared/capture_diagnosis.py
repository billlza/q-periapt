import hashlib,json,pathlib
stage=pathlib.Path('target/continuity-browser-network');result=json.loads((stage/'RESULT.json').read_text())
rows=[]
for row in result['browser']['result']['rows']:
 p=stage/'cases'/row['mode']/'browser-recovered.redb';b=p.read_bytes()
 rows.append({'case':row['mode'],'bytes':len(b),'capturedBytes':row['capture']['bytes'],'captureSha256':row['capture']['sha256'],'afterNativeComparatorSha256':hashlib.sha256(b).hexdigest(),'comparatorOpenedOriginal':row['mode']!='normal'})
with (stage/'capture-diagnosis.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
print(json.dumps([{'case':r['case'],'changed':r['captureSha256']!=r['afterNativeComparatorSha256']} for r in rows]))
