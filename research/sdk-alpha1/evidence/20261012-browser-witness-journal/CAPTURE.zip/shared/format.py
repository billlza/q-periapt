import pathlib,subprocess
root=pathlib.Path('target/continuity-browser-network/source').resolve()
paths=subprocess.check_output(['git','-C',str(root),'diff','--name-only','--','*.rs'],text=True).splitlines()
paths+=subprocess.check_output(['git','-C',str(root),'ls-files','--others','--exclude-standard','--','*.rs'],text=True).splitlines()
subprocess.run(['/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains/1.98.1-aarch64-apple-darwin/bin/rustfmt','--edition','2021','--config','skip_children=true',*[str(root/p) for p in sorted(set(paths))]],check=True)
