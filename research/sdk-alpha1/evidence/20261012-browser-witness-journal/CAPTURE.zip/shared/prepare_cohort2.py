import pathlib,shutil
stage=pathlib.Path('target/continuity-browser-network');second=stage/'cohort2';second.mkdir()
shutil.copytree(stage/'web',second/'web');(second/'cases').mkdir(mode=0o700)
for name in ['prepare_cases.py','native_verify.py','summarize.py']:
    s=(stage/name).read_text().replace("pathlib.Path('target/continuity-browser-network')","pathlib.Path('target/continuity-browser-network/cohort2')").replace("Path('target/continuity-browser-network')","Path('target/continuity-browser-network/cohort2')")
    if name=='native_verify.py':
        old="""        with (case/'native-compare.stdout').open('xb') as out,(case/'native-compare.stderr').open('xb') as err:
            subprocess.run([str(compare),str(original),str(case/'browser-recovered.redb'),str(target)],stdout=out,stderr=err,check=True,timeout=60)"""
        new="""        pending_copy=case/'pending-for-compare.redb';browser_copy=case/'browser-for-compare.redb'
        for src,dst in [(original,pending_copy),(case/'browser-recovered.redb',browser_copy)]:
            with src.open('rb') as source,dst.open('xb') as destination:shutil.copyfileobj(source,destination)
            dst.chmod(0o600)
        with (case/'native-compare.stdout').open('xb') as out,(case/'native-compare.stderr').open('xb') as err:
            subprocess.run([str(compare),str(pending_copy),str(browser_copy),str(target)],stdout=out,stderr=err,check=True,timeout=60)"""
        assert old in s;s=s.replace(old,new)
    (second/name).write_text(s)
