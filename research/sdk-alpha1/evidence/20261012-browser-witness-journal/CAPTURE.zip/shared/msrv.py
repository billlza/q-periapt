from pathlib import Path
stage=Path('target/continuity-browser-network');source=Path('target/continuity-browser-engine/cargo.sh').read_text()
assert 'RUSTUP_TOOLCHAIN=1.98.1-aarch64-apple-darwin' in source
with (stage/'cargo-msrv.sh').open('x') as f:f.write(source.replace('RUSTUP_TOOLCHAIN=1.98.1-aarch64-apple-darwin','RUSTUP_TOOLCHAIN=1.90.0-aarch64-apple-darwin'))
