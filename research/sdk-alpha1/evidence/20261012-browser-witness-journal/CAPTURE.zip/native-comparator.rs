//! Compare the exact encrypted target retained before browser recovery with both resulting images.
use redb::{ReadableDatabase,TableDefinition};
use std::path::Path;
const TABLE:TableDefinition<&str,&[u8]>=TableDefinition::new("continuity_device_candidate_v21");
fn snapshot(path:&Path)->Result<(Vec<u8>,Option<Vec<u8>>),Box<dyn std::error::Error>>{
 let db=q_periapt_host_store::filesystem::open_private_database(path)?;
 let read=db.begin_read()?;let table=read.open_table(TABLE)?;
 let image=table.get("image")?.ok_or("missing image")?.value().to_vec();
 let pending=table.get("pending")?.map(|v|v.value().to_vec());Ok((image,pending))
}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let args=std::env::args().skip(1).collect::<Vec<_>>();let [pending_path,browser_path,native_path]=args.as_slice()else{return Err("three paths required".into())};
 let (before,pending)=snapshot(Path::new(pending_path))?;let pending=pending.ok_or("original intent absent")?;
 if pending.get(..8)!=Some(b"QPWINT01"){return Err("not the ordinary original write intent".into())}
 let length=u32::from_be_bytes(pending.get(152..156).ok_or("intent header")?.try_into()?) as usize;
 let end=156usize.checked_add(length).ok_or("length overflow")?;
 if pending.len()!=end.checked_add(32).ok_or("tag overflow")?{return Err("intent envelope length".into())}
 let target=pending.get(156..end).ok_or("target extent")?;
 let (browser,browser_pending)=snapshot(Path::new(browser_path))?;let (native,native_pending)=snapshot(Path::new(native_path))?;
 if browser_pending.is_some()||native_pending.is_some()||before==target||browser!=target||native!=target{return Err("original encrypted target was not preserved exactly".into())}
 println!("original-pending-target-equals-browser-and-native-image-byte-for-byte: {} bytes",target.len());Ok(())
}
