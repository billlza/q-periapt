from pathlib import Path
stage=Path('target/continuity-browser-async')
p=stage/'source/research/continuity-identity-candidate/src/enrollment/policy_renewal/request.rs'
s=p.read_text()
with (stage/'policy-request-before.rs').open('x') as f:f.write(s)
s=s.replace('    pub fn policy_renewal_request(', '    pub async fn policy_renewal_request(')
old='''        let result = self
            .prepare_renewal_request(original_policy)
            .and_then(|prepared| prepared.policy_request(operation, original_policy));'''
new='''        let result = self.policy_renewal_request_attempt(operation, original_policy).await;'''
assert old in s;s=s.replace(old,new)
old='''        let result = (|| {
            let mut prepared = self.prepare_renewal_request(original_policy).await?;
            prepared.policy_scope(operation, original_policy)
        })()
        .await;'''
new='''        let result = self.policy_renewal_scope_attempt(operation, original_policy).await;'''
assert old in s;s=s.replace(old,new)
pos=s.rfind('\n}')
s=s[:pos]+'''
    async fn policy_renewal_request_attempt(
        &mut self,
        operation: PolicyRenewalId,
        original_policy: &HistoricalSessionPolicy,
    ) -> Result<PolicyRenewalRequest, DurableError> {
        let prepared = self.prepare_renewal_request(original_policy).await?;
        prepared.policy_request(operation, original_policy).await
    }
    async fn policy_renewal_scope_attempt(
        &mut self,
        operation: PolicyRenewalId,
        original_policy: &HistoricalSessionPolicy,
    ) -> Result<crate::PolicyRenewalScope, DurableError> {
        let mut prepared = self.prepare_renewal_request(original_policy).await?;
        prepared.policy_scope(operation, original_policy)
    }
'''+s[pos:]
p.write_text(s)
