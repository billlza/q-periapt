from pathlib import Path
stage=Path('target/continuity-browser-async')
for name in ['propagate','fix_policy_request','format_changed','prepare_guard_probe']:
    source=(stage/(name+'.py')).read_text()
    source=source.replace("stage/'source/", "stage/'source-next/")
    source=source.replace("continuity-browser-async/source'", "continuity-browser-async/source-next'")
    if name=='fix_policy_request':
        source=source.replace('.prepare_renewal_request(original_policy)\n            .and_then', '.prepare_renewal_request(original_policy).await\n            .and_then')
    with (stage/(name+'_next.py')).open('x') as f:f.write(source)
