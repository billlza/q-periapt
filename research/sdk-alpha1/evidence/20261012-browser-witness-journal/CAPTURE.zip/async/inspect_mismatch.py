import json,pathlib
for line in pathlib.Path('target/continuity-browser-async/check2.jsonl').read_text().splitlines():
 m=json.loads(line)
 if m.get('reason')=='compiler-message' and (m['message'].get('code') or {}).get('code')=='E0308':
  e=m['message'];print(e['rendered']);print([(s['file_name'],s['byte_start'],s['byte_end'],s['is_primary']) for s in e['spans']]);break
