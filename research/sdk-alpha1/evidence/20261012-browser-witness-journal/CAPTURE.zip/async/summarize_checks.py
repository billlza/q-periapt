import json,pathlib,collections,sys
for name in sys.argv[1:]:
 messages=[json.loads(x) for x in pathlib.Path('target/continuity-browser-async',name).read_text().splitlines()];errors=[m['message'] for m in messages if m.get('reason')=='compiler-message' and m['message']['level']=='error'];print(name, len(errors),dict(collections.Counter((e.get('code') or {}).get('code') for e in errors)))
 for e in errors:
  if (e.get('code') or {}).get('code') not in ['E0277','E0308','E0599']:
   s=next((s for s in e['spans'] if s['is_primary']),{});print((e.get('code') or {}).get('code'),s.get('file_name'),s.get('line_start'),e['message'])
