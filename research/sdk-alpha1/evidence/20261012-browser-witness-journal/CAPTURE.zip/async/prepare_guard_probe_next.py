from pathlib import Path
import shutil
stage=Path('target/continuity-browser-async');crate=stage/'source-next/research/continuity-identity-candidate'
backup=stage/'before-guard-probe';backup.mkdir()
for relative in ['Cargo.toml','Cargo.lock','src/lib.rs']:
    p=backup/relative;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(crate/relative,p)
p=crate/'Cargo.toml';s=p.read_text();assert '[lib]' not in s
s=s.replace('[dependencies]', '[lib]\ncrate-type = ["cdylib", "rlib"]\n\n[dependencies]',1)
s=s.replace('web-time = "=1.1.0"','web-time = "=1.1.0"\nwasm-bindgen = "=0.2.129"')
p.write_text(s)
p=crate/'src/lib.rs'
p.write_text(p.read_text()+'''
// Isolated future ownership qualification only; not a released export.
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
mod browser_async_probe;
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
pub use browser_async_probe::future_drop_probe;
''')
shutil.copyfile(stage/'future_drop_probe.rs',crate/'src/browser_async_probe.rs')
(stage/'guard-web').mkdir()
