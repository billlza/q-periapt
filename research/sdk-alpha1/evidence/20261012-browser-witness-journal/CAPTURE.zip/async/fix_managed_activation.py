from pathlib import Path
p=Path('target/continuity-browser-async/source/research/continuity-identity-candidate/src/enrollment/managed_root.rs');s=p.read_text();start=s.index('    pub async fn activate_successor(');end=s.index('    /// Obtain the committed successor',start);old=s[start:end];Path('target/continuity-browser-async/managed-activation-before.rs').write_text(old);assert 'self.run(|owners| {' in old
body=old.split('self.run(|owners| {',1)[1].rsplit('\n        })',1)[0]
new='''    pub async fn activate_successor(
        &mut self,
        enrollment: DeviceEnrollment,
        policy: &VerifiedSessionPolicy,
        now: u64,
        transport: Box<dyn AnchorTransport>,
        timeout: Duration,
    ) -> Result<EnrolledDevice, DurableError> {
        // As in run(), the operation owns the controller until success. Future
        // drop also revokes every delegated owner through Owners::drop.
        let mut owners = self.active.take().ok_or(DurableError::Closed)?;
        let result = Self::activate_successor_owned(
            &mut owners, enrollment, policy, now, transport, timeout,
        ).await?;
        self.active = Some(owners);
        Ok(result)
    }
    async fn activate_successor_owned(
        owners: &mut Owners,
        mut enrollment: DeviceEnrollment,
        policy: &VerifiedSessionPolicy,
        now: u64,
        transport: Box<dyn AnchorTransport>,
        timeout: Duration,
    ) -> Result<EnrolledDevice, DurableError> {'''+body+'''\n    }\n'''
p.write_text(s[:start]+new+s[end:])
