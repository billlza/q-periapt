from pathlib import Path
p=Path('target/continuity-browser-async/source/research/continuity-identity-candidate/Cargo.toml');s=p.read_text().replace('[dependencies]','[dependencies]\nmaybe-async = "=0.2.11"',1).replace('web-time = "=1.1.0"','web-time = "=1.1.0"\nasync-trait = "=0.1.92"');p.write_text(s)
