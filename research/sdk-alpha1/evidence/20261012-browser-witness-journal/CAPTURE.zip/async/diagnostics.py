import json,pathlib,collections
p=pathlib.Path('target/continuity-browser-async/check1.jsonl');messages=[json.loads(x) for x in p.read_text().splitlines()];errors=[m['message'] for m in messages if m.get('reason')=='compiler-message' and m['message']['level']=='error'];print('errors',len(errors),collections.Counter((e.get('code') or {}).get('code') for e in errors))
for e in errors[:4]:
 print(e['message']);print(json.dumps(e['spans'][:1],ensure_ascii=False)[:800]);print(json.dumps(e['children'],ensure_ascii=False)[:1500])
