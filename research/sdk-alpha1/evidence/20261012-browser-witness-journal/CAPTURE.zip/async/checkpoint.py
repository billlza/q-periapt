import datetime,hashlib,json,pathlib,re,subprocess
root=pathlib.Path.cwd();stage=root/'target/continuity-browser-async'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def build_pass(name):
    events=[json.loads(x) for x in (stage/name).read_text().splitlines()]
    finished=[x for x in events if x.get('reason')=='build-finished']
    assert finished and finished[-1]['success'],name
    assert not [x for x in events if x.get('reason')=='compiler-message' and x['message']['level'] in ['error','warning']],name
def result(name):
    return json.loads((stage/name).read_text().split('### Result\n',1)[1].splitlines()[0])
for name in ['native-clippy2.jsonl','wasm-clippy2.jsonl']:build_pass(name)
green=result('guard-clean-result.stdout');red=result('guard-red-result.stdout')
assert green['status']=='passed' and not green['errors']
assert red['status']=='expected-regression-observed' and not red['errors']
for name,count in [('policy-request-test.stdout',7),('credential-request-test.stdout',10)]:
    assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in (stage/name).read_text(),name
transport=stage/'source-next/research/continuity-identity-candidate/src/anchor/transport.rs'
assert transport.read_bytes()==(stage/'guard-transport-green.rs').read_bytes()
wasm=stage/'guard-web/clean/pkg/q_periapt_continuity_identity_candidate_bg.wasm'
assert wasm.read_bytes()==(stage/'restored-pkg'/wasm.name).read_bytes()
assert (stage/'pre-round7.patch').read_bytes()==(stage/'original-source-current.patch').read_bytes()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='ddf9096254f2b3d96954e5a295b8be42137092ab'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
checks={
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Explicit asynchronous shared engine and fail-closed signing owner; isolated prototype, not complete browser witness/journal admission.',
 'base':head,
 'engine_patch_sha256':digest(stage/'async-engine-before-probe.patch'),
 'native_clippy':'native-clippy2.jsonl, all features, -D warnings, passed',
 'wasm_clippy':'wasm-clippy2.jsonl, wasm32-unknown-unknown, -D warnings, passed',
 'native_request_tests':17,
 'browser_green':green,'browser_counterfactual':red,
 'green_wasm_sha256':digest(wasm),
 'red_wasm_sha256':digest(stage/'guard-web/red/pkg'/wasm.name),
 'source_and_rebuilt_green_restored':True,
 'limitations':['Fault carrier only; no fabricated authority. No real network witness or asynchronous required-journal recovery tested yet.', '959-test full native suite remains on immutable pre-round7 source. These later request boundary changes separately have17passing regressions. Final integrated exact-source full suite and packages remain open.', 'Initial test-name filter selected0tests; this is not counted. Listed actual modules and ran7policy-request+10credential-request cases.', 'First browser page had a favicon404. New clean page supplies a data favicon and asserts no console/page errors. Both results retained.']
}
(stage/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
state={
 'goal_status':'active','turn_classification':'progress','observed_utc':checks['observed_utc'],
 'main_commit':head,'main_clean':True,'integrated':False,'pushed':False,
 'current_prototype':str(stage/'source-next'),
 'prototype_rule':'Use source-next and *_next.py tools. It contains temporary browser_async_probe.rs and its WASM-only lib reexport, manifest cdylib/wasm-bindgen changes. Production-intended engine diff is separately saved as async-engine-before-probe.patch; neither is admitted into Main.',
 'engine_patch_sha256':checks['engine_patch_sha256'],
 'validation':checks,
 'native_full_suite':{'session':75456,'source':str(stage/'source'),'input_patch':'pre-round7.patch','patch_sha256':digest(stage/'pre-round7.patch'),'status':'running, no terminal result claimed; freeze source until handle terminal','log':'native-test1.stdout','count':959},
 'owned_browser':'qpc-async-guard closed','owned_server':{'session':61023,'pid':6653,'exit':143},
 'owned_other_producers':'All guard builds, request regressions and Clippy terminal; only native full suite75456 remains.',
 'next':['Recover full native suite75456 terminal result; do not restart or mutate its source while active. Compare failed cases if any, preserve outputs.', 'Next substantive work is actual asynchronous Fetch/witness plus original required-journal pending intent and OPFS crash recovery. This guard probe is only a prerequisite, not full browser acceptance. Preserve exact witness request/reply verification, before/after monotonic deadline, original intent and unknown outcome. No blocking XHR, cached absence, local-only downgrade or fabricated success.', 'Browser API still needs owned operation serialization, explicit cancellation that aborts transport and awaits cleanup, and full installation/signing/wrapping-key persistence. Ignoring a Promise does not drop its Rust future.', 'FutureDrop takes AnchorClient signer until fully verified timely success; failed or dropped exchange leaves signer absent. Root activation similarly takes Owners until success. Named helper functions preserve cleanup return boundaries under maybe_async must_be_sync; never replace them with plain async blocks whose native macro conversion lets ? escape cleanup.', 'Before admission, perform final exact-source native suite, MSRV and affected package checks. Full0.2.0 scope remains active including independent implementation, PCS argument and measured product costs.', 'Check prior dc256 CodeQL38304182825 terminal before pushing3qualified Main commits. Only authorized push: git push https://github.com/billlza/q-periapt.git HEAD:refs/heads/lza/sdk-020-alpha1. Do not push this unfinished prototype.', 'Preserve accepted single API37 Android and canonical iPad device gates, no Intel Mac, no ClosedT2 or retainedT1 reopening. Two-agent cumulative budget exhausted; no new/reopened agents.'],
}
(stage/'HANDOFF.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({'main':head,'current_prototype':state['current_prototype'],'native_request_tests':17,'green_wasm':checks['green_wasm_sha256'],'full_suite_session':75456}))
