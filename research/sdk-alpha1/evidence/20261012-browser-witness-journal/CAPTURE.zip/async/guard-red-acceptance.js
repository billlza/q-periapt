async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.goto('http://127.0.0.1:50214/red/');
 const results=await page.evaluate(async()=>{
  const m=await import('./pkg/q_periapt_continuity_identity_candidate.js');await m.default();
  let windowError;
  try{m.future_drop_probe();throw new Error('counterfactual incorrectly passed')}catch(e){windowError=String(e)}
  const worker=new Worker('./worker.js',{type:'module'});
  const workerError=await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>{worker.terminate();reject(new Error('worker deadline'))},20000);
   worker.onmessage=e=>{clearTimeout(timer);worker.terminate();e.data.error?resolve(e.data.error):reject(new Error('counterfactual worker passed'))};
   worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(new Error(e.message))};
   worker.postMessage('run');
  });
  return {windowError,workerError};
 });
 const expected='in-flight signer survived failed or dropped exchange';
 if(!results.windowError.includes(expected)||!results.workerError.includes(expected)||errors.length)throw new Error(JSON.stringify({results,errors}));
 return {status:'expected-regression-observed',version:page.context().browser().version(),results,errors};
}
