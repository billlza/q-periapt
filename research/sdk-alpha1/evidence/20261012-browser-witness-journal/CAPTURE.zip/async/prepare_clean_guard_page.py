from pathlib import Path
import shutil
stage=Path('target/continuity-browser-async');old=stage/'guard-web';new=old/'clean';new.mkdir()
shutil.copytree(old/'pkg',new/'pkg');shutil.copyfile(old/'worker.js',new/'worker.js')
page=(stage/'guard-page.html').read_text().replace('<title>', '<link rel="icon" href="data:,"><title>',1)
(new/'index.html').write_text(page)
