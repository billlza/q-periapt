import init,{future_drop_probe} from './pkg/q_periapt_continuity_identity_candidate.js';
self.onmessage=async()=>{try{await init();self.postMessage({result:future_drop_probe()})}catch(e){self.postMessage({error:String(e)})}};
