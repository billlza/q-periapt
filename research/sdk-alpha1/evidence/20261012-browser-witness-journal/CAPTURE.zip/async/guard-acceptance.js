async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.waitForFunction(()=>typeof window.runGuardProbe==='function');
 const result=await page.evaluate(()=>window.runGuardProbe());
 if(errors.length)throw new Error(JSON.stringify(errors));
 const expected='unpolled-preserved;pending-drop-closed;transport-error-closed;invalid-reply-closed;closed-retries-no-dispatch';
 if(result.window!==expected||result.worker!==expected)throw new Error('guard result mismatch');
 return {status:'passed',version:page.context().browser().version(),result};
}
