// Isolated browser regression probe, not a public product API.
use crate::{AnchorClient, AnchorClientError, AnchorIdentity, AnchorOperation, AnchorPin,
    AnchorSigningKey, AnchorSubject, AnchorTransport, DeviceSigningKey, Error, MonotonicInstant};
use std::{future::Future, io, sync::{Arc, atomic::{AtomicUsize, Ordering}}, task::{Context, Poll, Waker}, time::Duration};
use wasm_bindgen::prelude::*;

enum Fault { Pending, Transport, InvalidReply }
struct Carrier { calls: Arc<AtomicUsize>, fault: Fault }
#[async_trait::async_trait(?Send)]
impl AnchorTransport for Carrier {
    async fn exchange(&mut self, request: &[u8], _: MonotonicInstant) -> io::Result<Vec<u8>> {
        if request.len() != 3674 { return Err(io::Error::other("signed request width")); }
        self.calls.fetch_add(1, Ordering::SeqCst);
        match self.fault {
            Fault::Pending => std::future::pending().await,
            Fault::Transport => Err(io::ErrorKind::ConnectionReset.into()),
            Fault::InvalidReply => Ok(vec![0;3659]),
        }
    }
}
fn err(value: impl std::fmt::Debug) -> JsError { JsError::new(&format!("{value:?}")) }
fn require(value: bool, message: &str) -> Result<(), JsError> {
    if value { Ok(()) } else { Err(JsError::new(message)) }
}
fn client(fault: Fault) -> Result<(AnchorClient, Arc<AtomicUsize>), JsError> {
    let mut witness = AnchorSigningKey::generate().map_err(err)?;
    let pin = AnchorPin::new(AnchorIdentity::generate().map_err(err)?, witness.public_key().map_err(err)?);
    witness.close();
    let calls = Arc::new(AtomicUsize::new(0));
    let client = AnchorClient::new(pin, DeviceSigningKey::generate().map_err(err)?,
        Box::new(Carrier { calls: Arc::clone(&calls), fault }), Duration::from_secs(2)).map_err(err)?;
    Ok((client, calls))
}
fn closed(client: &mut AnchorClient, subject: AnchorSubject, calls: &AtomicUsize) -> Result<(), JsError> {
    require(matches!(client.signer_public_key(), Err(Error::Closed)), "in-flight signer survived failed or dropped exchange")?;
    let mut future = Box::pin(client.exchange(subject, AnchorOperation::query()));
    let mut cx = Context::from_waker(Waker::noop());
    require(matches!(future.as_mut().poll(&mut cx), Poll::Ready(Err(AnchorClientError::Verification(Error::Closed)))), "closed client accepted retry")?;
    require(calls.load(Ordering::SeqCst)==1, "closed client dispatched another request")
}
/// Check real Rust future ownership in a browser; fault carrier never grants authority.
#[wasm_bindgen]
pub fn future_drop_probe() -> Result<String, JsError> {
    let subject = AnchorSubject::from_trusted_state(&[1;96]).map_err(err)?;
    let (mut pending, calls) = client(Fault::Pending)?;
    drop(pending.exchange(subject, AnchorOperation::query()));
    require(calls.load(Ordering::SeqCst)==0, "unpolled future dispatched")?;
    pending.signer_public_key().map_err(err)?;
    let mut future = Box::pin(pending.exchange(subject, AnchorOperation::query()));
    let mut cx = Context::from_waker(Waker::noop());
    require(matches!(future.as_mut().poll(&mut cx), Poll::Pending), "carrier did not suspend")?;
    require(calls.load(Ordering::SeqCst)==1, "suspended request missing")?;
    drop(future);
    closed(&mut pending, subject, &calls)?;
    let (mut failed, calls) = client(Fault::Transport)?;
    let mut future = Box::pin(failed.exchange(subject, AnchorOperation::query()));
    require(matches!(future.as_mut().poll(&mut cx), Poll::Ready(Err(AnchorClientError::Transport(ref e))) if e.kind()==io::ErrorKind::ConnectionReset), "transport failure changed classification")?;
    drop(future);
    closed(&mut failed, subject, &calls)?;
    let (mut invalid, calls) = client(Fault::InvalidReply)?;
    let mut future = Box::pin(invalid.exchange(subject, AnchorOperation::query()));
    require(matches!(future.as_mut().poll(&mut cx), Poll::Ready(Err(AnchorClientError::Verification(_)))), "invalid witness reply admitted")?;
    drop(future);
    closed(&mut invalid, subject, &calls)?;
    Ok("unpolled-preserved;pending-drop-closed;transport-error-closed;invalid-reply-closed;closed-retries-no-dispatch".into())
}
