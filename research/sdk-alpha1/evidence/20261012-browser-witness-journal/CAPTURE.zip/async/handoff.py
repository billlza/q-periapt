import datetime,json,pathlib,subprocess,sys
stage=pathlib.Path('target/continuity-browser-async');root=pathlib.Path.cwd()
state={
 'goal_status':'active','turn_classification':'progress',
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'main_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'main_clean':not bool(subprocess.check_output(['git','status','--porcelain'],text=True)),
 'prototype':str((stage/'source').resolve()),'integrated':False,'pushed':False,
 'scope':'Explicit asynchronous witness calls in shared engine; native synchronous APIs through target-conditional maybe-async must_be_sync. Whole browser owner admission not yet qualified.',
 'dependencies':{'maybe-async':'=0.2.11','async-trait':'=0.1.92, wasm only'},
 'cleanup':'Named attempt helpers retain return and cleanup boundaries. Never convert async blocks to native plain blocks where ?/return bypasses cleanup. AnchorClient takes signer until verified timely reply; future drop/error retains closed client. Managed root activation takes Owners until success.',
 'validation':{'native_check5':'pass, before round6 edits','wasm_check7':'5 errors; known policy_request closure and 3 outer awaits remain','native_test1':'running session75456; do not mutate source until terminal'},
 'owned_sessions':{'native_test1':75456},
 'pending_scripts':['propagate.py 7 dryrun reviewed; fix_policy_request.py must run after propagation and be adjusted for inserted .await','future_drop_probe.rs drafted but not installed or executed'],
 'next':['Recover producer states before any input mutation. Finish wasm call graph and run native/wasm Clippy -D warnings. No warning suppression.', 'Test browser future-drop semantics with fault carrier (never grant fabricated witness authority). Then real asynchronous signed witness/journal pending-intent recovery, deadlines and cancellation. Do not equate simple build or isolated guard test to full browser admission.', 'Native full regressions must be terminal and exact inputs identified. No package/source gate claim for prototype.', 'Check dc256 CodeQL terminal before pushing three qualified Main commits to sole authorized lza/sdk-020-alpha1 destination. Preserve full0.2.0 scope, no Intel Mac, accepted single API37 Android and canonical iPad gates.'],
 'agent_budget':'two cumulative delegates used; no new/reopened agents'
}
path=stage/'HANDOFF.json'
if path.exists():
 previous=json.loads(path.read_text());state['prior_checkpoint']=previous.get('observed_utc')
path.write_text(json.dumps(state,indent=2)+'\n')
for relative,key in [('target/continuity-browser-journal/HANDOFF.json','next_checkpoint'),('target/continuity-android-roster-integration/CONTINUATION.json','browser_async_checkpoint')]:
 p=pathlib.Path(relative);value=json.loads(p.read_text());value[key]=str(path);p.write_text(json.dumps(value,indent=2)+'\n')
print(path)
