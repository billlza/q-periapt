import json,pathlib,subprocess,sys,collections
stage=pathlib.Path('target/continuity-browser-async').resolve();crate=stage/'source/research/continuity-identity-candidate';iteration=int(sys.argv[1]);apply='--apply' in sys.argv
messages=[json.loads(x) for x in (stage/f'check{iteration}.jsonl').read_text().splitlines()];errors=[m['message'] for m in messages if m.get('reason')=='compiler-message' and m['message']['level']=='error']
points=collections.defaultdict(set);skipped=[]
mapper=pathlib.Path('target/continuity-browser-engine/rust-target/debug/continuity-async-syntax-map').resolve();map_cache={}
def syntax(p):
 if p not in map_cache:map_cache[p]=json.loads(subprocess.check_output([str(mapper),str(p)],text=True))
 return map_cache[p]
for e in errors:
 code=(e.get('code') or {}).get('code');primary=next((s for s in e['spans'] if s['is_primary']),None)
 if code=='E0277' and 'Future' in json.dumps(e) and primary:
  p=(crate/primary['file_name']).resolve()
  if not p.is_relative_to(crate/'src'):skipped.append(e['message']);continue
  raw=p.read_bytes();end=primary['byte_end']
  if raw[end-1:end]==b'?':points[p].add(end-1);continue
 found=(primary.get('label') or '').partition(', found ')[2] if primary else ''
 if primary and ((code=='E0308' and 'future' in found.lower()) or (code=='E0599' and 'Future<' in json.dumps(e))):
  p=(crate/primary['file_name']).resolve()
  if p.is_relative_to(crate/'src'):
   info=syntax(p);start=primary['byte_start'];end=primary['byte_end']
   if code=='E0308' and any(c['start']==start and c['end']==end for c in info['calls']):
    points[p].add(end);continue
   if code=='E0599':
    calls=[c for c in info['calls'] if c['start']<=start<end<=c['end'] and c.get('name') in ['is_err','is_ok','map','map_err','and_then','ok','err']]
    if calls:
     call=min(calls,key=lambda c:c['end']-c['start'])
     if call['receiver_call']:points[p].add(call['receiver_end']);continue
     if call['receiver_variable']:
      functions=[f for f in info['functions'] if f['start']<=start<f['end']]
      if functions:
       f=min(functions,key=lambda f:f['end']-f['start']);bindings=[v for v in f['locals'] if v['name']==call['receiver_variable'] and v['end']<start]
       if len(bindings)==1:points[p].add(bindings[0]['end']);continue
 suggestions=[]
 def scan(node):
  for s in node.get('spans',[]):
   if s.get('suggested_replacement')=='.await' and s['byte_start']==s['byte_end']:suggestions.append(s)
  for c in node.get('children',[]):scan(c)
 scan(e)
 if suggestions:
  for s in suggestions:
   p=(crate/s['file_name']).resolve()
   if p.is_relative_to(crate/'src'):points[p].add(s['byte_start'])
 else:skipped.append({'code':code,'message':e['message'],'file':primary and primary['file_name'],'line':primary and primary['line_start']})
maps={p:syntax(p)['functions'] for p in points}
attribute=b'#[cfg_attr(not(all(target_arch = "wasm32", target_os = "unknown")), maybe_async::must_be_sync)]\n'
plan=[];outputs={}
for p,positions in points.items():
 raw=p.read_bytes();functions=maps[p];groups={}
 for pos in positions:
  candidates=[f for f in functions if f['start']<=pos<f['end']]
  if not candidates:raise RuntimeError(f'no function at {p}:{pos}')
  f=min(candidates,key=lambda x:x['end']-x['start']);groups.setdefault(f['fn'],(f,set()))[1].add(pos)
 edits=[];scopes=set()
 for f,positions in groups.values():
  wrapper=f['wrapper'];extract=bool(wrapper and all(wrapper['body_start']<=n<wrapper['body_end'] for n in positions))
  if extract:
   helper=f['name']+'_attempt';assert not any(x['name']==helper for x in functions),(p,helper)
   body=raw[wrapper['body_start']:wrapper['body_end']]
   for pos in sorted(positions,reverse=True):body=body[:pos-wrapper['body_start']]+b'.await'+body[pos-wrapper['body_start']:]
   sig=raw[f['fn']:f['body_start']];a=f['name_start']-f['fn'];b=f['name_end']-f['fn'];sig=b'async '+sig[:a]+helper.encode()+sig[b:]
   cfg=b''.join(raw[a:b]+b'\n' for a,b in f['cfg'])
   declaration=b'\n'+cfg+(attribute if f['kind']=='function' else b'')+sig+body+b'\n'
   call=('self.' if wrapper['method'] else '')+helper+'('+', '.join(wrapper['args'])+').await'
   edits.append((wrapper['call_start'],wrapper['call_end'],call.encode()));edits.append((f['end'],f['end'],declaration))
  else:
   edits.extend((pos,pos,b'.await') for pos in positions)
  if not f['async']:edits.append((f['fn'],f['fn'],b'async '))
  if f['scope'] not in scopes and b'maybe_async::must_be_sync' not in raw[f['scope']:f['scope_token']]:
   edits.append((f['scope'],f['scope'],attribute));scopes.add(f['scope'])
  plan.append({'file':str(p.relative_to(crate)),'function':f['name'],'awaits':len(positions),'cleanup_helper':extract})
 # All replacements must be disjoint. Multiple insertions at the same point are explicit.
 ranges=sorted((a,b) for a,b,_ in edits if a!=b)
 assert all(b<=c for (a,b),(c,d) in zip(ranges,ranges[1:])),(p,ranges)
 output=raw
 for a,b,replacement in sorted(edits,key=lambda e:(e[0],e[1]),reverse=True):output=output[:a]+replacement+output[b:]
 outputs[p]=output
print(json.dumps({'round':iteration,'plan':plan,'skipped':skipped},indent=2))
if apply:
 backup=stage/f'edits{iteration}';backup.mkdir()
 for p,value in outputs.items():
  saved=backup/p.relative_to(crate);saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(p.read_bytes());p.write_bytes(value)
 (backup/'PLAN.json').write_text(json.dumps({'plan':plan,'skipped':skipped},indent=2)+'\n')
