import json,pathlib,sys
for line in pathlib.Path('target/continuity-browser-async',sys.argv[1]).read_text().splitlines():
    item=json.loads(line)
    if item.get('reason')=='compiler-message' and item['message']['level']=='error':
        print(item['message']['rendered'])
