    pub async fn activate_successor(
        &mut self,
        mut enrollment: DeviceEnrollment,
        policy: &VerifiedSessionPolicy,
        now: u64,
        transport: Box<dyn AnchorTransport>,
        timeout: Duration,
    ) -> Result<EnrolledDevice, DurableError> {
        self.run(|owners| {
            let (checkpoint, proposal) = owners.successor()?;
            let image = enrollment.image_without_policy_renewal()?;
            let device = enrollment.admitted(&image, policy, now)?;
            let Phase::Accepted { admission, .. } = &image.phase else {
                return Err(DurableError::Suspended);
            };
            if device.account_id() != proposal.successor_account()
                || proposal.successor().journal_parts()
                    != (
                        *admission.journal.as_bytes(),
                        crate::bootstrap::storage_owner(&device),
                        admission.policy,
                    )
            {
                return Err(DurableError::Conflict);
            }
            enrollment.select_account_authority(JournalAccountAuthority::new(
                owners.registry.access()?,
                checkpoint,
            )?)?;
            let client =
                enrollment.anchor_client(policy, now, owners.pin.clone(), transport, timeout)?;
            enrollment.activate(policy, now, Some(client)).await
        })
    }
