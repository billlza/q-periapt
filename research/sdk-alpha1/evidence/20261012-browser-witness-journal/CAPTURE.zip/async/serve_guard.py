from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
directory=Path('target/continuity-browser-async/guard-web').resolve()
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(directory)))
print(f'http://127.0.0.1:{server.server_port}/',flush=True)
server.serve_forever()
