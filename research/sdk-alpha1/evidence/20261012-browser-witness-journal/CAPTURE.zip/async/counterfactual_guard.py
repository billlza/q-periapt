from pathlib import Path
import sys
stage=Path('target/continuity-browser-async')
p=stage/'source-next/research/continuity-identity-candidate/src/anchor/transport.rs'
backup=stage/'guard-transport-green.rs'
if sys.argv[1]=='restore':
    p.write_bytes(backup.read_bytes())
else:
    s=p.read_text()
    with backup.open('xb') as f:f.write(p.read_bytes())
    restore='        self.signer = Some(signer);\n'
    assert s.count(restore)==1;s=s.replace(restore,'')
    point='        let request = AnchorRequest::new(&self.pin, subject, operation, &signer)?;\n'
    assert s.count(point)==1
    s=s.replace(point,point+'        // Counterfactual only: leave the signer on the owner during suspension.\n'+restore)
    p.write_text(s)
