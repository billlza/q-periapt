from pathlib import Path
p=Path('target/continuity-browser-async/syntax-map/src/main.rs');s=p.read_text();s=s.replace('functions:Vec<Value>,owner:', 'functions:Vec<Value>,calls:Vec<Value>,owner:')
s=s.replace('  self.functions.push(json!', '''  let locals=block.stmts.iter().filter_map(|stmt|{let syn::Stmt::Local(local)=stmt else{return None};let syn::Pat::Ident(name)=&local.pat else{return None};let expr=&local.init.as_ref()?.expr;if !matches!(expr.as_ref(),syn::Expr::Call(_)|syn::Expr::MethodCall(_)){return None}let r=expr.span().byte_range();Some(json!({"name":name.ident.to_string(),"start":r.start,"end":r.end}))}).collect::<Vec<_>>();
  self.functions.push(json!''')
s=s.replace('"kind":kind,"wrapper":', '"kind":kind,"locals":locals,"wrapper":')
s=s.replace("impl<'ast> Visit<'ast> for Walker {", '''impl<'ast> Visit<'ast> for Walker {
 fn visit_expr_call(&mut self,node:&'ast syn::ExprCall){let r=node.span().byte_range();self.calls.push(json!({"start":r.start,"end":r.end,"kind":"call"}));visit::visit_expr_call(self,node);}
 fn visit_expr_method_call(&mut self,node:&'ast syn::ExprMethodCall){let r=node.span().byte_range();let receiver=node.receiver.span().byte_range();let var=if let syn::Expr::Path(p)=node.receiver.as_ref(){p.path.get_ident().map(|i|i.to_string())}else{None};self.calls.push(json!({"start":r.start,"end":r.end,"kind":"method","name":node.method.to_string(),"receiver_start":receiver.start,"receiver_end":receiver.end,"receiver_variable":var,"receiver_call":matches!(node.receiver.as_ref(),syn::Expr::Call(_)|syn::Expr::MethodCall(_))}));visit::visit_expr_method_call(self,node);}
''')
s=s.replace('"functions":walker.functions}', '"functions":walker.functions,"calls":walker.calls}')
p.write_text(s)
