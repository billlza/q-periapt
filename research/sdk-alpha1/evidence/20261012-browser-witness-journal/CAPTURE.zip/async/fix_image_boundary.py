from pathlib import Path
p=Path('target/continuity-browser-async/source/research/continuity-identity-candidate/src/durable.rs');s=p.read_text();start=s.index('    async fn image(&mut self)');end=s.index('    async fn persist(',start);old=s[start:end];Path('target/continuity-browser-async/image-before.rs').write_text(old)
assert 'load(&active.db, &active.key, active.owner).and_then(|mut image| {' in old
body=old.split('load(&active.db, &active.key, active.owner).and_then(|mut image| {',1)[1].split('\n        });',1)[0]
new='''    async fn image(&mut self) -> Result<Image, DurableError> {
        let result = self.image_attempt().await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn image_attempt(&mut self) -> Result<Image, DurableError> {
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        let mut image = load(&active.db, &active.key, active.owner)?;'''+body+'''\n    }\n'''
p.write_text(s[:start]+new+s[end:])
