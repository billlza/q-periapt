    async fn image(&mut self) -> Result<Image, DurableError> {
        let active = self.active.as_mut().ok_or(DurableError::Closed)?;
        let result = load(&active.db, &active.key, active.owner).and_then(|mut image| {
            if image.id == active.id && image.protection == active.protection {
                active.attach_account_authority(&mut image)?;
                active.check_current(&image).await?;
                active.check_account_authority(&image)?;
                if let Some(completion) = &active.enrollment_completion {
                    rosters::check_enrollment_policy_completion(&image, completion)?;
                    image.enrollment_completion = Some(std::sync::Arc::clone(completion));
                }
                Ok(image)
            } else {
                Err(DurableError::Conflict)
            }
        });
        if result.is_err() {
            self.close();
        }
        result
    }
