use super::*;
use crate::MonotonicInstant;
use js_sys::Uint8Array;
use wasm_bindgen::prelude::*;
#[wasm_bindgen(raw_module = "./fetch.js")]
extern "C" {
    #[wasm_bindgen(catch)]
    async fn witness_exchange(
        slot: u32,
        request: Vec<u8>,
        milliseconds: f64,
    ) -> Result<JsValue, JsValue>;
}
struct FetchCarrier(u32);
#[async_trait::async_trait(?Send)]
impl AnchorTransport for FetchCarrier {
    async fn exchange(
        &mut self,
        request: &[u8],
        deadline: MonotonicInstant,
    ) -> io::Result<Vec<u8>> {
        let remaining = deadline
            .checked_duration_since(MonotonicInstant::now())
            .filter(|d| !d.is_zero())
            .ok_or(io::ErrorKind::TimedOut)?;
        let reply = witness_exchange(self.0, request.to_vec(), remaining.as_secs_f64() * 1000.0)
            .await
            .map_err(|e| match e.as_f64() {
                Some(1.0) => io::ErrorKind::ConnectionReset.into(),
                Some(2.0) => io::ErrorKind::TimedOut.into(),
                Some(3.0) => io::ErrorKind::Interrupted.into(),
                Some(4.0) => io::ErrorKind::InvalidData.into(),
                _ => io::Error::other(format!("witness host error: {e:?}")),
            })?;
        if !reply.is_instance_of::<Uint8Array>() {
            return Err(io::ErrorKind::InvalidData.into());
        }
        let reply = Uint8Array::new(&reply);
        if reply.length() != 3659 {
            return Err(io::ErrorKind::InvalidData.into());
        }
        Ok(reply.to_vec())
    }
}
fn error(e: impl std::fmt::Debug) -> JsError {
    JsError::new(&format!("{e:?}"))
}
/// Isolated original required-witness journal owner; no production arbitrary backend entry.
#[wasm_bindgen]
pub struct NetworkJournalProbe {
    journal: DeviceJournal,
    config: Config,
    cleanup: opfs::Cleanup,
}
#[wasm_bindgen]
impl NetworkJournalProbe {
    /// Authenticate original OPFS image and reconcile its exact witness intent before release.
    pub async fn open(
        slot: u32,
        transport: u32,
        fixture: &str,
        timeout: u32,
    ) -> Result<Self, JsError> {
        if !(100..=5000).contains(&timeout) {
            return Err(error("fixture timeout"));
        }
        let config = Config::parse(fixture).map_err(error)?;
        let device = config.device().map_err(error)?;
        let signer = crate::crypto::probe_device(
            &fixture_key(),
            config.signer_id().map_err(error)?,
            &bytes(&config.0, "sealedSigner").map_err(error)?,
        )
        .map_err(error)?;
        signer.check_device(&device).map_err(error)?;
        let client = AnchorClient::new(
            config.witness().map_err(error)?,
            signer,
            Box::new(FetchCarrier(transport)),
            Duration::from_millis(timeout as u64),
        )
        .map_err(error)?;
        let (db, cleanup) = opfs::open(slot).map_err(error)?;
        let journal = DeviceJournal::open_anchored_database_admitted(
            db,
            fixture_key(),
            &device,
            &config.policy().map_err(error)?,
            config.identity().map_err(error)?,
            client,
            AccountAuthorityOpen::Existing(None),
        )
        .await
        .map_err(error)?;
        Ok(Self {
            journal,
            config,
            cleanup,
        })
    }
    /// Apply the exact signed next roster through original two-phase intent and witness advance.
    pub async fn install(&mut self) -> Result<String, JsError> {
        self.journal
            .install_roster(&self.config.roster().map_err(error)?, 150)
            .await
            .map_err(error)?;
        self.state().await
    }
    /// Freshly authenticated head and retained roster metadata; no traffic permission.
    pub async fn state(&mut self) -> Result<String, JsError> {
        state(&mut self.journal, &self.config).await.map_err(error)
    }
    /// Close after any in-flight call has settled and surface backend cleanup errors.
    pub fn close(&mut self) -> Result<(), JsError> {
        self.journal.close();
        opfs::closed(&self.cleanup).map_err(error)
    }
    /// Observe the exact authenticated pending intent without witness reconciliation.
    pub fn inspect(slot: u32, fixture: &str) -> Result<String, JsError> {
        let config = Config::parse(fixture).map_err(error)?;
        let (db, cleanup) = opfs::open(slot).map_err(error)?;
        let result = inspect(&db, &config).map_err(error);
        drop(db);
        opfs::closed(&cleanup).map_err(error)?;
        result
    }
}
