// Isolated qualification, not a package or public storage-admission API.
use super::*;
use crate::{
    AccountPin, AnchorClient, AnchorIdentity, AnchorPin, AnchorTransport, HistoricalSessionPolicy,
    PolicyCheckpoint, PolicyPin, PublicKey, RosterCheckpoint, SigningKeyId, VerifiedRoster,
};
use serde_json::{json, Value};
use std::time::Duration;
fn text_error(e: impl std::fmt::Debug) -> String {
    format!("{e:?}")
}
fn bytes(v: &Value, name: &str) -> Result<Vec<u8>, String> {
    serde_json::from_value(
        v.get(name)
            .ok_or_else(|| format!("missing {name}"))?
            .clone(),
    )
    .map_err(text_error)
}
fn array(v: &Value, name: &str) -> Result<[u8; 32], String> {
    bytes(v, name)?
        .try_into()
        .map_err(|_| format!("width {name}"))
}
fn fixture_key() -> JournalKey {
    // Public synthetic wrapping material: only this generated fixture cohort uses it.
    JournalKey(Box::new(ZeroizingBytes::from_bytes([171; 32])))
}
struct Config(Value);
impl Config {
    fn parse(text: &str) -> Result<Self, String> {
        if text.len() > 256 * 1024 {
            return Err("fixture bound".into());
        }
        serde_json::from_str(text).map(Self).map_err(text_error)
    }
    fn field(&self, name: &str) -> Result<&Value, String> {
        self.0.get(name).ok_or_else(|| format!("missing {name}"))
    }
    fn account(&self) -> Result<[u8; 32], String> {
        array(&self.0, "account")
    }
    fn identity(&self) -> Result<JournalIdentity, String> {
        JournalIdentity::from_trusted_state(array(&self.0, "journal")?).map_err(text_error)
    }
    fn signer_id(&self) -> Result<SigningKeyId, String> {
        SigningKeyId::from_trusted_state(array(&self.0, "signerId")?).map_err(text_error)
    }
    fn account_pin(&self, name: &str) -> Result<AccountPin, String> {
        let value = self.field(name)?;
        let version = value
            .get("version")
            .and_then(Value::as_u64)
            .ok_or("roster version")?;
        let checkpoint = RosterCheckpoint::from_trusted_state(version, array(value, "digest")?)
            .map_err(text_error)?;
        AccountPin::new(
            self.account()?,
            PublicKey::decode(&bytes(&self.0, "root")?).map_err(text_error)?,
            checkpoint,
            array(&self.0, "family")?,
        )
        .map_err(text_error)
    }
    fn device(&self) -> Result<VerifiedDevice, String> {
        self.account_pin("one")?
            .verify_device(
                &bytes(&self.0, "credential")?,
                &bytes(self.field("one")?, "wire")?,
                150,
            )
            .map_err(text_error)
    }
    fn roster(&self) -> Result<VerifiedRoster, String> {
        self.account_pin("two")?
            .verify_roster(&bytes(self.field("two")?, "wire")?, 150)
            .map_err(text_error)
    }
    fn witness(&self) -> Result<AnchorPin, String> {
        Ok(AnchorPin::new(
            AnchorIdentity::from_trusted_state(array(&self.0, "witnessId")?).map_err(text_error)?,
            PublicKey::decode(&bytes(&self.0, "witnessPublic")?).map_err(text_error)?,
        ))
    }
    fn policy(&self) -> Result<HistoricalSessionPolicy, String> {
        let value = self.field("policy")?;
        let version = value
            .get("version")
            .and_then(Value::as_u64)
            .ok_or("policy version")?;
        let pin = PolicyPin::new(
            array(&self.0, "family")?,
            PublicKey::decode(&bytes(value, "public")?).map_err(text_error)?,
            PolicyCheckpoint::from_trusted_state(version, array(value, "digest")?)
                .map_err(text_error)?,
        )
        .map_err(text_error)?;
        pin.verify_historical(&bytes(value, "wire")?)
            .map_err(text_error)
    }
}
fn inspect(db: &Database, config: &Config) -> Result<String, String> {
    let device = config.device()?;
    let owner = bootstrap::storage_owner(&device);
    let key = fixture_key();
    let (image, pending) = write_intent::load_snapshot(db, &key, owner).map_err(text_error)?;
    if image.id != *config.identity()?.as_bytes() {
        return Err("journal identity".into());
    }
    let target = pending
        .as_ref()
        .map(|p| p.authenticated_target(&key, owner))
        .transpose()
        .map_err(text_error)?;
    Ok(json!({"revision":image.revision,"imageDigest":image.digest,"pending":pending.is_some(),"targetDigest":target.map(|i|i.digest)}).to_string())
}
#[cfg_attr(not(target_arch = "wasm32"), maybe_async::must_be_sync)]
async fn state(journal: &mut DeviceJournal, config: &Config) -> Result<String, String> {
    let roster = journal
        .roster_checkpoint(config.account()?)
        .await
        .map_err(text_error)?;
    let image = journal.image().await.map_err(text_error)?;
    Ok(json!({"revision":image.revision,"imageDigest":image.digest,"rosterVersion":roster.version(),"rosterDigest":roster.digest()}).to_string())
}
#[cfg(not(target_arch = "wasm32"))]
mod native;
#[cfg(not(target_arch = "wasm32"))]
pub use native::{prepare_network_probe, serve_network_probe, verify_network_probe};
#[cfg(target_arch = "wasm32")]
mod browser;
#[cfg(target_arch = "wasm32")]
pub use browser::NetworkJournalProbe;
#[cfg(target_arch = "wasm32")]
mod opfs;
