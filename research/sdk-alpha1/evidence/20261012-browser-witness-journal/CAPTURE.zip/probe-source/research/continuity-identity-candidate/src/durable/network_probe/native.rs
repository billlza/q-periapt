use super::*;
use crate::{
    AllowedPrekeyModes, AnchorRequirement, AnchorSigningKey, AnchorStore, ApplicationSendBudget,
    DeviceDescription, DeviceSigningKey, PolicySigningKey, PrekeyQuality, RootSigningKey,
    SessionPolicyParameters, Validity,
};
use q_periapt_sig::Signer;
use std::{
    fs,
    io::{Read, Write},
    sync::{Arc, Mutex},
};
use zeroize::Zeroize;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

fn runtime() -> Result<Arc<q_periapt_sdk::Runtime>> {
    let policy=b"schema_version=1\npolicy_version=1\nmin_nist_level=3\ndefault_profile=\"ContextBound\"\nallowed_kems=[\"ML-KEM-768\",\"X25519\"]\nallowed_sigs=[\"ML-DSA-65\"]\ndeprecated=[]\n";
    let (mut secret, public) = q_periapt_backends::MlDsa65::generate([180; 32]);
    let mut signature = vec![0; q_periapt_backends::ML_DSA_65_SIG_LEN];
    let signed = q_periapt_backends::MlDsa65.sign(
        &secret,
        &q_periapt_policy::policy_signature_message(policy),
        &[181; 32],
        &mut signature,
    );
    secret.zeroize();
    signed.map_err(|e| format!("algorithm fixture signature: {e:?}"))?;
    Ok(Arc::new(q_periapt_sdk::Runtime::from_signed_policy(
        policy,
        &signature,
        &public,
        None,
        q_periapt_sdk::Limits::default(),
    )?))
}
/// Generate a fresh required-witness journal and independently retained native witness.
pub fn prepare_network_probe(directory: &Path) -> Result<()> {
    let directory = directory.canonicalize()?;
    let witness_key = JournalKey::provision(&directory.join("witness.key"))?;
    let witness_signer_id = SigningKeyId::generate()?;
    let witness_signer = AnchorSigningKey::provision(
        &directory.join("witness.signer"),
        &witness_key,
        witness_signer_id,
    )?;
    let mut store = AnchorStore::provision(
        &directory.join("witness.redb"),
        witness_key,
        witness_signer,
        AnchorIdentity::generate()?,
    )?;
    let pin = store.pin()?;
    let runtime = runtime()?;
    let mut issuer = PolicySigningKey::generate()?;
    let validity = Validity::new(100, 200)?;
    let policy = issuer.issue_session_policy(
        &runtime,
        SessionPolicyParameters::new(
            1,
            validity,
            AllowedPrekeyModes::new(&[PrekeyQuality::OneTimeBoth])?,
            AnchorRequirement::required(&pin),
            ApplicationSendBudget::new(128)?,
        )?,
    )?;
    let policy_pin = PolicyPin::new(
        issuer.policy_family()?,
        issuer.public_key()?,
        policy.checkpoint(),
    )?;
    let verified_policy = policy_pin.verify(policy.as_bytes(), runtime, 150)?;
    let family = issuer.policy_family()?;
    let mut root = RootSigningKey::generate()?;
    let signer_id = SigningKeyId::generate()?;
    let mut signer =
        DeviceSigningKey::provision(&directory.join("device.signer"), &fixture_key(), signer_id)?;
    let credential = root.issue_device(
        DeviceDescription::new([185; 16], 1, family, validity)?,
        signer.public_key()?,
    )?;
    let entry = root.roster_entry(&credential)?;
    let one = root.issue_roster(1, validity, std::slice::from_ref(&entry))?;
    let two = root.issue_roster(2, Validity::new(100, 210)?, std::slice::from_ref(&entry))?;
    let account = root.account_id()?;
    let device = AccountPin::new(account, root.public_key()?, one.checkpoint(), family)?
        .verify_device(&credential, one.as_bytes(), 150)?;
    let id = JournalIdentity::generate()?;
    let mut journal = DeviceJournal::provision_anchored(
        &directory.join("initial.redb"),
        fixture_key(),
        &device,
        &verified_policy,
        id,
        150,
    )?;
    let genesis = journal.anchor_genesis(&device, &verified_policy)?;
    store.enroll(&genesis, &device, &verified_policy, 150)?;
    let record = |r: &crate::IssuedRoster| json!({"wire":r.as_bytes(),"version":r.checkpoint().version(),"digest":r.checkpoint().digest()});
    let config=json!({"account":account,"family":family,"root":root.public_key()?.encode(),"credential":credential,
        "one":record(&one),"two":record(&two),"journal":id.as_bytes(),"signerId":signer_id.as_bytes(),
        "sealedSigner":fs::read(directory.join("device.signer"))?,"witnessId":pin.identity().as_bytes(),"witnessPublic":pin.public_key().encode(),
        "witnessSignerId":witness_signer_id.as_bytes(),
        "policy":{"wire":policy.as_bytes(),"version":policy.checkpoint().version(),"digest":policy.checkpoint().digest(),"public":issuer.public_key()?.encode()}}).to_string();
    q_periapt_host_store::filesystem::publish_private_bytes(
        &directory.join("fixture.json"),
        config.as_bytes(),
    )?;
    journal.close();
    store.close();
    signer.close();
    root.close();
    issuer.close();
    verified_policy.close();
    Ok(())
}
fn reopen(directory: &Path, config: &Config) -> Result<AnchorStore> {
    let wrapping = JournalKey::open(&directory.join("witness.key"))?;
    let signer = AnchorSigningKey::open(
        &directory.join("witness.signer"),
        &wrapping,
        SigningKeyId::from_trusted_state(array(&config.0, "witnessSignerId")?)?,
    )?;
    let store = AnchorStore::open(
        &directory.join("witness.redb"),
        wrapping,
        signer,
        config.witness()?.identity(),
    )?;
    if store.pin()?.binding() != config.witness()?.binding() {
        return Err("witness binding".into());
    }
    Ok(store)
}
/// Process framed signed requests for a loopback HTTP harness; stdout contains only bounded frames.
pub fn serve_network_probe(directory: &Path) -> Result<()> {
    let config = Config::parse(&fs::read_to_string(directory.join("fixture.json"))?)?;
    let mut store = reopen(directory, &config)?;
    let mut input = std::io::stdin().lock();
    let mut output = std::io::stdout().lock();
    let subject =
        crate::AnchorSubject::for_device(config.identity()?, &config.device()?, &config.policy()?)?;
    loop {
        let mut header = [0; 4];
        let n = input.read(&mut header)?;
        if n == 0 {
            break;
        }
        input.read_exact(header.get_mut(n..).ok_or("header width")?)?;
        if u32::from_be_bytes(header) != 3674 {
            return Err("request frame width".into());
        }
        let mut request = vec![0; 3674];
        input.read_exact(&mut request)?;
        let wire = store.handle(&request, 150)?;
        let head = store.network_probe_head(subject)?;
        let reply=json!({"reply":wire,"head":{"revision":head.revision(),"digest":head.digest(),"fence":head.fence()}}).to_string().into_bytes();
        if reply.len() > 32768 {
            return Err("reply bound".into());
        }
        output.write_all(&(reply.len() as u32).to_be_bytes())?;
        output.write_all(&reply)?;
        output.flush()?;
    }
    store.close();
    Ok(())
}
struct Carrier(Arc<Mutex<AnchorStore>>);
impl AnchorTransport for Carrier {
    fn exchange(&mut self, request: &[u8], _: crate::MonotonicInstant) -> io::Result<Vec<u8>> {
        self.0
            .lock()
            .map_err(|_| io::Error::other("witness lock"))?
            .handle(request, 150)
            .map_err(io::Error::other)
    }
}
/// Recover a copied browser image through native private-file admission and the original witness.
pub fn verify_network_probe(directory: &Path, path: &Path) -> Result<String> {
    let config = Config::parse(&fs::read_to_string(directory.join("fixture.json"))?)?;
    let db = open_private_database(path)?;
    let before = inspect(&db, &config)?;
    drop(db);
    let store = Arc::new(Mutex::new(reopen(directory, &config)?));
    let signer = DeviceSigningKey::open(
        &directory.join("device.signer"),
        &fixture_key(),
        config.signer_id()?,
    )?;
    let client = AnchorClient::new(
        config.witness()?,
        signer,
        Box::new(Carrier(Arc::clone(&store))),
        Duration::from_secs(5),
    )?;
    let mut journal = DeviceJournal::open_anchored_admitted(
        path,
        fixture_key(),
        &config.device()?,
        &config.policy()?,
        config.identity()?,
        client,
        AccountAuthorityOpen::Existing(None),
    )?;
    let after = state(&mut journal, &config)?;
    let observed: Value = serde_json::from_str(&after)?;
    if observed.get("rosterVersion").and_then(Value::as_u64)
        != Some(config.roster()?.checkpoint().version())
    {
        return Err("native recovered roster".into());
    }
    journal.close();
    store.lock().map_err(|_| "witness lock")?.close();
    Ok(json!({"before":serde_json::from_str::<Value>(&before)?,"after":observed}).to_string())
}
