// Isolated qualification backend. Only public test fixtures enter this build.
use js_sys::Uint8Array;
use redb::{Database, StorageBackend};
use std::{
    io,
    ops::Bound,
    sync::{Arc, Mutex},
};
use wasm_bindgen::prelude::*;
#[path = "../../../../../crates/q-periapt-host-store/src/database_format.rs"]
mod database_format;
const MAX: u64 = 64 * 1024 * 1024;
#[wasm_bindgen(raw_module = "./opfs.js")]
extern "C" {
    #[wasm_bindgen(catch)]
    fn file_size(slot: u32) -> Result<f64, JsValue>;
    #[wasm_bindgen(catch)]
    fn file_read(slot: u32, offset: f64, out: &Uint8Array) -> Result<f64, JsValue>;
    #[wasm_bindgen(catch)]
    fn file_write(slot: u32, offset: f64, bytes: &Uint8Array) -> Result<f64, JsValue>;
    #[wasm_bindgen(catch)]
    fn file_resize(slot: u32, size: f64) -> Result<(), JsValue>;
    #[wasm_bindgen(catch)]
    fn file_sync(slot: u32) -> Result<(), JsValue>;
    #[wasm_bindgen(catch)]
    fn file_close(slot: u32) -> Result<(), JsValue>;
}
fn host(e: JsValue) -> io::Error {
    io::Error::other(format!("OPFS callback: {e:?}"))
}
fn bounds(offset: u64, count: usize) -> io::Result<()> {
    if offset
        .checked_add(count as u64)
        .is_some_and(|end| end <= MAX)
    {
        Ok(())
    } else {
        Err(io::Error::new(io::ErrorKind::InvalidInput, "OPFS extent"))
    }
}
fn integer(value: f64, maximum: u64) -> io::Result<u64> {
    if value.is_finite() && value.fract() == 0.0 && value >= 0.0 && value <= maximum as f64 {
        Ok(value as u64)
    } else {
        Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "OPFS result width",
        ))
    }
}
#[derive(Debug)]
struct Backend {
    slot: u32,
    cleanup: Arc<Mutex<Option<String>>>,
}
impl StorageBackend for Backend {
    fn len(&self) -> io::Result<u64> {
        integer(file_size(self.slot).map_err(host)?, MAX)
    }
    fn read(&self, offset: u64, out: &mut [u8]) -> io::Result<()> {
        bounds(offset, out.len())?;
        let array = Uint8Array::new_with_length(out.len() as u32);
        let result = file_read(self.slot, offset as f64, &array)
            .map_err(host)
            .and_then(|n| integer(n, out.len() as u64));
        if result? != out.len() as u64 {
            return Err(io::ErrorKind::UnexpectedEof.into());
        }
        array.copy_to(out);
        Ok(())
    }
    fn write(&self, offset: u64, bytes: &[u8]) -> io::Result<()> {
        bounds(offset, bytes.len())?;
        let array = Uint8Array::from(bytes);
        let n = integer(
            file_write(self.slot, offset as f64, &array).map_err(host)?,
            bytes.len() as u64,
        )?;
        if n != bytes.len() as u64 {
            return Err(io::ErrorKind::WriteZero.into());
        }
        Ok(())
    }
    fn set_len(&self, len: u64) -> io::Result<()> {
        bounds(len, 0)?;
        file_resize(self.slot, len as f64).map_err(host)
    }
    fn sync_data(&self) -> io::Result<()> {
        file_sync(self.slot).map_err(host)
    }
    fn try_lock_range(
        &self,
        start: Bound<u64>,
        end: Bound<u64>,
    ) -> Result<bool, redb::BackendError> {
        if start != Bound::Unbounded || end != Bound::Unbounded {
            return Err(redb::BackendError::Unsupported);
        }
        self.len()?;
        Ok(true) // JS already acquired the exclusive SyncAccessHandle.
    }
    fn close(&self) -> io::Result<()> {
        if let Err(error) = file_close(self.slot).map_err(host) {
            *self
                .cleanup
                .lock()
                .map_err(|_| io::Error::other("cleanup lock"))? = Some(error.to_string());
            return Err(error);
        }
        Ok(())
    }
}

pub(super) type Cleanup = Arc<Mutex<Option<String>>>;
pub(super) fn open(slot: u32) -> Result<(Database, Cleanup), String> {
    let cleanup = Arc::new(Mutex::new(None));
    let backend = Backend {
        slot,
        cleanup: cleanup.clone(),
    };
    let len = backend.len().map_err(|e| e.to_string())?;
    if len < 16 {
        return Err("explicit open requires existing nonempty file".into());
    }
    database_format::refuse_unclean_foreign_redb(&backend).map_err(|e| e.to_string())?;
    let mut builder = Database::builder();
    builder.set_cache_size(2 * 1024 * 1024);
    let db = builder
        .create_with_backend(backend)
        .map_err(|e| e.to_string())?;
    Ok((db, cleanup))
}
pub(super) fn closed(cleanup: &Cleanup) -> Result<(), String> {
    if let Some(error) = cleanup.lock().map_err(|_| "cleanup lock")?.take() {
        return Err(error);
    }
    Ok(())
}
