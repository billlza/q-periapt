//! Isolated native witness and browser-journal recovery qualification harness.
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = std::env::args().skip(1);
    let mode = args.next().ok_or("mode")?;
    let directory = args.next().ok_or("directory")?;
    let directory = std::path::Path::new(&directory);
    match mode.as_str() {
        "prepare" => q_periapt_continuity_identity_candidate::prepare_network_probe(directory)?,
        "serve" => q_periapt_continuity_identity_candidate::serve_network_probe(directory)?,
        "verify" => {
            let input = args.next().ok_or("journal")?;
            println!(
                "{}",
                q_periapt_continuity_identity_candidate::verify_network_probe(
                    directory,
                    std::path::Path::new(&input)
                )?
            );
        }
        _ => return Err("mode".into()),
    }
    Ok(())
}
