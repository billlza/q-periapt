/* tslint:disable */
/* eslint-disable */

/**
 * Isolated original required-witness journal owner; no production arbitrary backend entry.
 */
export class NetworkJournalProbe {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Close after any in-flight call has settled and surface backend cleanup errors.
     */
    close(): void;
    /**
     * Observe the exact authenticated pending intent without witness reconciliation.
     */
    static inspect(slot: number, fixture: string): string;
    /**
     * Apply the exact signed next roster through original two-phase intent and witness advance.
     */
    install(): Promise<string>;
    /**
     * Authenticate original OPFS image and reconcile its exact witness intent before release.
     */
    static open(slot: number, transport: number, fixture: string, timeout: number): Promise<NetworkJournalProbe>;
    /**
     * Freshly authenticated head and retained roster metadata; no traffic permission.
     */
    state(): Promise<string>;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_networkjournalprobe_free: (a: number, b: number) => void;
    readonly networkjournalprobe_close: (a: number) => [number, number];
    readonly networkjournalprobe_inspect: (a: number, b: number, c: number) => [number, number, number, number];
    readonly networkjournalprobe_install: (a: number) => any;
    readonly networkjournalprobe_open: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly networkjournalprobe_state: (a: number) => any;
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined___js_sys_cb007e04167f9a7___Function_fn_wasm_bindgen_5ef15f9c59dd1dc3___JsValue_____wasm_bindgen_5ef15f9c59dd1dc3___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_5ef15f9c59dd1dc3___convert__closures_____invoke___wasm_bindgen_5ef15f9c59dd1dc3___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_5ef15f9c59dd1dc3___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
