const require=(ok,message)=>{if(!ok)throw new Error(message)};
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
class Client{
 constructor(){this.worker=new Worker('./worker.mjs',{type:'module'});this.next=1;this.pending=new Map();this.worker.onmessage=({data})=>{const p=this.pending.get(data.id);if(!p)return;this.pending.delete(data.id);clearTimeout(p.timer);p.resolve(data)};this.worker.onerror=e=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error(e.message))}this.pending.clear()}}
 rpc(command,values={}){const id=this.next++;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('worker RPC deadline: '+command))},30000);this.pending.set(id,{resolve,reject,timer});this.worker.postMessage({id,command,...values})})}
 async ok(command,values={}){const r=await this.rpc(command,values);require(r.ok,`${command}: ${r.error}`);return r.result}
 stop(){this.worker.terminate();for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error('Worker terminated'))}this.pending.clear()}
}
async function server(){const r=await fetch('/status');require(r.ok,'server status');const value=await r.json();require(value.failures.length===0,JSON.stringify(value.failures));return value}
async function committed(name,mode){const end=performance.now()+8000;while(performance.now()<end){const value=await server();const row=value.cases[name].records.find(r=>r.phase==='reply'&&r.mode===mode);if(row){require(row.head.revision===2,'fault did not follow witness commit');return row}await new Promise(r=>setTimeout(r,15))}throw new Error('witness commit was not observed')}
async function unlocked(name){const end=performance.now()+5000;while(performance.now()<end){const locks=await navigator.locks.query();if(!locks.held.some(l=>l.name==='qpc-opfs-probe/'+name))return;await new Promise(r=>setTimeout(r,15))}throw new Error('terminated Worker retained file lock')}
window.runNetworkProbe=async()=>{
 const rows=[];const prefix='network-'+crypto.randomUUID();window.networkRows=rows;
 for(const mode of ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']){
  const name=prefix+'-'+mode;let client=new Client();let fault,pendingCapture=null;
  try{
   await client.ok('configure',{caseName:mode});await client.ok('seed',{name});
   const initial=await client.ok('open',{name,timeout:mode==='timeout'?1000:5000});require(initial.state.revision===1&&initial.state.rosterVersion===1,'initial required journal');
   if(['cancel','kill-after'].includes(mode)){
    const pending=client.rpc('install',{mode}).then(result=>({result}),e=>({error:String(e)}));
    await committed(mode,mode);
    const busy=await client.rpc('state');require(!busy.ok&&busy.error==='Busy','concurrent owner operation admitted');
    if(mode==='cancel'){
     const t=performance.now();await client.ok('cancel');fault=(await pending).result;
     require(fault&&!fault.ok&&fault.error.includes('Interrupted'),'cancel classification');require(performance.now()-t<2000,'cancellation did not settle');require(fault.carrier.active===0,'cancel left fetch active');
    }else{
     client.stop();fault=await pending;require(fault.error?.includes('Worker terminated'),'worker termination result');await unlocked(name);
     client=new Client();await client.ok('configure',{caseName:mode});
    }
   }else{
    fault=await client.rpc('install',{mode});
    if(mode==='normal'){require(fault.ok&&fault.result.state.revision===2&&fault.result.state.rosterVersion===2,'normal commit')}
    else{require(!fault.ok,'fault returned success');const kind=mode==='timeout'?'TimedOut':mode==='invalid'?'Authentication':'ConnectionReset';require(fault.error.includes(kind),`wrong ${mode} error: ${fault.error}`);require(fault.carrier.active===0,'failure left fetch active')}
   }
   if(mode!=='normal'&&mode!=='kill-after'){
    const closed=await client.rpc('state');require(!closed.ok&&closed.error.includes('Closed'),'failed journal owner still usable');
   }
   await client.ok('close');
   const before=await client.ok('inspect',{name});
   const trace=(await server()).cases[mode].records;
   const lastHead=trace.filter(r=>r.phase==='reply').at(-1)?.head;
   if(mode==='normal'){require(!before.pending&&before.revision===2,'normal pending state')}
   else{require(before.pending&&before.revision===1&&before.targetDigest,'original pending intent missing');require(lastHead.revision===(mode==='drop-before'?1:2),'unexpected witness commit state');pendingCapture=await client.ok('snapshot',{name,capture:'pending-original'})}
   const recovered=await client.ok('open',{name});require(recovered.state.revision===2&&recovered.state.rosterVersion===2,'recovery target');
   if(mode!=='normal')require(equal(recovered.state.imageDigest,before.targetDigest),'recovery replaced original target');
   const retried=await client.ok('install');require(retried.counts.write===0&&retried.counts.sync===0,'exact retry wrote another journal transition');
   await client.ok('close');const after=await client.ok('inspect',{name});require(!after.pending&&after.revision===2,'pending not reconciled');
   const capture=await client.ok('snapshot',{name,capture:'browser-recovered'});await client.ok('remove',{name});
   rows.push({mode,status:'passed',before,after,recovered:recovered.state,witnessBeforeRecovery:lastHead,exactRetry:{writes:retried.counts.write,syncs:retried.counts.sync},capture,pendingCapture,failure:mode==='normal'?null:fault.error});
   document.querySelector('#result').textContent=JSON.stringify(rows);
  }finally{client.stop()}
 }
 const final=await server();require(Object.values(final.cases).every(c=>!c.pending&&!c.failed),'native witness still busy or failed');
 return {status:'passed',rows,server:final};
};
