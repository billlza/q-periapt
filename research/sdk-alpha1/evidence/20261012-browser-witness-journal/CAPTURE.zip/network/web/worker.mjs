import init,{NetworkJournalProbe} from './pkg/q_periapt_continuity_identity_candidate.js';
import * as io from './pkg/opfs.js';import * as net from './pkg/fetch.js';
const ready=init();let owner,slot,transport,busy=false,config,caseName;
const json=text=>JSON.parse(text);
self.onmessage=async({data})=>{
 const {id,command}=data;
 if(command==='cancel'){
  try{if(!transport)throw new Error('no carrier');net.cancel(transport);self.postMessage({id,ok:true,result:net.status(transport)})}catch(e){self.postMessage({id,ok:false,error:String(e)})}return;
 }
 if(busy){self.postMessage({id,ok:false,error:'Busy'});return}
 busy=true;
 try{
  await ready;let result;
  if(command==='configure'){
   if(config)throw new Error('already configured');caseName=data.caseName;const r=await fetch('/fixture/'+caseName+'/fixture.json');if(!r.ok)throw new Error('fixture unavailable');config=await r.text();result={configured:true};
  }else if(command==='seed'){
   const r=await fetch('/fixture/'+caseName+'/initial.redb');if(!r.ok)throw new Error('initial unavailable');const bytes=new Uint8Array(await r.arrayBuffer());
   const prepared=await io.acquire(data.name,true);try{if(io.file_write(prepared,0,bytes)!==bytes.length)throw new Error('short import');io.file_sync(prepared)}finally{await io.abortPrepared(prepared)}result={bytes:bytes.length};
  }else if(command==='open'){
   if(owner||slot||transport)throw new Error('existing owner');slot=await io.acquire(data.name,false);transport=net.create(caseName);
   try{owner=await NetworkJournalProbe.open(slot,transport,config,data.timeout??5000)}catch(e){await io.abortPrepared(slot);slot=undefined;net.close(transport);transport=undefined;throw e}
   result={state:json(await owner.state()),counts:io.stats(slot),carrier:net.status(transport)};
  }else if(command==='install'){
   if(!owner)throw new Error('no owner');io.fault(slot,'none',0,false,'throw');net.arm(transport,data.mode??'normal',2);
   result={state:json(await owner.install()),counts:io.stats(slot),carrier:net.status(transport)};
  }else if(command==='state'){
   if(!owner)throw new Error('no owner');result=json(await owner.state());
  }else if(command==='close'){
   if(owner){owner.close();owner.free();owner=undefined}if(slot){await io.abortPrepared(slot);slot=undefined}if(transport){const saved=net.status(transport);net.close(transport);transport=undefined;result={carrier:saved}}else result={alreadyClosed:true};
  }else if(command==='inspect'){
   if(owner||slot)throw new Error('existing owner');const prepared=await io.acquire(data.name,false);try{result=json(NetworkJournalProbe.inspect(prepared,config))}finally{await io.abortPrepared(prepared)}
  }else if(command==='snapshot'){
   const bytes=await io.snapshot(data.name);const r=await fetch('/capture/'+caseName+'/'+data.capture+'.redb',{method:'POST',body:bytes});if(r.status!==201)throw new Error('capture failed '+r.status);result=await r.json();
  }else if(command==='remove'){
   if(owner||slot)throw new Error('existing owner');const root=await navigator.storage.getDirectory();await root.removeEntry(data.name);result={removed:true};
  }else throw new Error('unknown command');
  self.postMessage({id,ok:true,result});
 }catch(e){self.postMessage({id,ok:false,error:String(e),counts:slot?io.stats(slot):null,carrier:transport?net.status(transport):null})}
 finally{busy=false}
};
