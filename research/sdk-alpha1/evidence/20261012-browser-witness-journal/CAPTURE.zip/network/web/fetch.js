// Bounded asynchronous fixture carrier. Signed protocol verification remains in Rust.
const owners=new Map();let next=1;
export function create(caseName){if(!/^[a-z0-9-]+$/.test(caseName)||owners.size>=8)throw new Error('carrier scope');const id=next++;owners.set(id,{caseName,cancelled:false,active:new Set(),calls:0,fault:null});return id}
function owner(id){const value=owners.get(id);if(!value)throw new Error('closed carrier');return value}
export function arm(id,mode,index){const o=owner(id);if(o.active.size)throw new Error('carrier busy');o.calls=0;o.fault={mode,index}}
export function cancel(id){const o=owner(id);o.cancelled=true;for(const attempt of o.active)attempt.abort(3)}
export function status(id){const o=owner(id);return {cancelled:o.cancelled,active:o.active.size,calls:o.calls}}
export function close(id){const o=owner(id);if(o.active.size)throw new Error('carrier busy');owners.delete(id)}
export async function witness_exchange(id,request,milliseconds){
 const o=owner(id);if(o.cancelled)throw 3;
 if(!(request instanceof Uint8Array)||request.length!==3674||!Number.isFinite(milliseconds)||milliseconds<=0||milliseconds>60000)throw 4;
 const controller=new AbortController();const attempt={reason:0,abort(reason){if(!this.reason){this.reason=reason;controller.abort()}}};
 const count=++o.calls;const mode=o.fault?.index===count?o.fault.mode:'normal';
 o.active.add(attempt);const timer=setTimeout(()=>attempt.abort(2),Math.ceil(milliseconds));let reader;
 try{
  const reply=await fetch('/witness/'+o.caseName+'?mode='+encodeURIComponent(mode),{method:'POST',body:request,signal:controller.signal,credentials:'omit',redirect:'error',cache:'no-store',headers:{'Content-Type':'application/octet-stream'}});
  if(reply.status!==200||!reply.body)throw 1;
  const length=reply.headers.get('Content-Length');if(length!==null&&length!=='3659')throw 4;
  reader=reply.body.getReader();const result=new Uint8Array(3659);let offset=0;
  while(true){const chunk=await reader.read();if(chunk.done)break;if(!(chunk.value instanceof Uint8Array)||offset+chunk.value.length>result.length)throw 4;result.set(chunk.value,offset);offset+=chunk.value.length}
  if(offset!==3659)throw 4;if(attempt.reason)throw attempt.reason;
  return result;
 }catch(e){controller.abort();if(attempt.reason)throw attempt.reason;if([1,2,3,4].includes(e))throw e;throw 1}
 finally{
  clearTimeout(timer);o.active.delete(attempt);
  if(reader)reader.releaseLock();
 }
}
