from pathlib import Path
import subprocess
stage=Path('target/continuity-browser-network/cohort2');binary=Path('target/continuity-browser-engine/rust-target/debug/examples/network_probe').resolve()
for name in ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']:
    directory=(stage/'cases'/name).resolve();directory.mkdir(mode=0o700)
    with (directory/'prepare.stdout').open('xb') as out,(directory/'prepare.stderr').open('xb') as err:
        subprocess.run([str(binary),'prepare',str(directory)],stdout=out,stderr=err,timeout=60,check=True)
    print(name,flush=True)
