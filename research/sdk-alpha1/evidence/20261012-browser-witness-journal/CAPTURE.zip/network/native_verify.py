import hashlib,json,pathlib,shutil,subprocess
stage=pathlib.Path('target/continuity-browser-network/cohort2').resolve()
binary=pathlib.Path('target/continuity-browser-engine/rust-target/debug/examples/network_probe').resolve()
compare=pathlib.Path('target/continuity-browser-engine/rust-target/debug/compare_browser_journal').resolve()
rows=[]
for name in ['normal','drop-before','drop-after','timeout','cancel','kill-after','invalid']:
    case=stage/'cases'/name;original=case/('browser-recovered.redb' if name=='normal' else 'pending-original.redb')
    target=case/'native-recovered.redb'
    with original.open('rb') as src,target.open('xb') as dst:shutil.copyfileobj(src,dst)
    target.chmod(0o600)
    with (case/'native-verify.stdout').open('xb') as out,(case/'native-verify.stderr').open('xb') as err:
        subprocess.run([str(binary),'verify',str(case),str(target)],stdout=out,stderr=err,check=True,timeout=60)
    value=json.loads((case/'native-verify.stdout').read_text());assert value['after']['revision']==2 and value['after']['rosterVersion']==2
    row={'case':name,'native':value}
    if name!='normal':
        pending_copy=case/'pending-for-compare.redb';browser_copy=case/'browser-for-compare.redb'
        for src,dst in [(original,pending_copy),(case/'browser-recovered.redb',browser_copy)]:
            with src.open('rb') as source,dst.open('xb') as destination:shutil.copyfileobj(source,destination)
            dst.chmod(0o600)
        with (case/'native-compare.stdout').open('xb') as out,(case/'native-compare.stderr').open('xb') as err:
            subprocess.run([str(compare),str(pending_copy),str(browser_copy),str(target)],stdout=out,stderr=err,check=True,timeout=60)
        row['byteEquality']=(case/'native-compare.stdout').read_text().strip()
    rows.append(row);print(name,flush=True)
with (stage/'native-results.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
