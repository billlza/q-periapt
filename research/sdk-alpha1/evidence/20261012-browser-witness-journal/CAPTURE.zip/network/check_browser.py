import json,pathlib
stage=pathlib.Path('target/continuity-browser-network/cohort2')
v=json.loads((stage/'browser-result.stdout').read_text().split('### Result\n',1)[1].split('\n### ',1)[0])
assert v['result']['status']=='passed' and len(v['result']['rows'])==7 and not v['pageErrors']
assert all(r['mode']=='normal' or r['pendingCapture'] for r in v['result']['rows'])
print(json.dumps({'status':v['result']['status'],'browser':v['version'],'cases':len(v['result']['rows']),'pageErrors':v['pageErrors'],'expectedTransportConsole':v['expectedTransportConsole']}))
