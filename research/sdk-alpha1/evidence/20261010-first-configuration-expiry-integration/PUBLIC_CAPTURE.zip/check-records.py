from pathlib import Path
import hashlib,json,shutil,sys,tempfile
b=Path(__file__).resolve().parent;sys.path.insert(0,str(b/'source/artifact'))
import continuity_first_configuration as configuration
import continuity_configuration_policy as policy
import rust_sdk_profile as sdk
root=b/'native-debug/outside/configuration-c-debug';stdout=(b/'native-debug/configuration-c-debug.stdout').read_bytes()
expected=configuration.verify_execution(stdout,root,language='C');rows=[]
with tempfile.TemporaryDirectory(prefix='qpc-expiry-public-controls-',dir=b) as directory:
 copy=Path(directory)/'public';shutil.copytree(root,copy)
 def refuse(label, data=stdout):
  try:configuration.verify_execution(data,copy,language='C')
  except ValueError as error:rows.append({'control':label,'refusal':str(error)})
  else:raise RuntimeError('accepted invalid evidence: '+label)
 def alter(path,value,label):
  original=path.read_bytes()
  try:path.write_bytes(value);refuse(label)
  finally:path.write_bytes(original)
 for line in stdout.splitlines(keepends=True):
  if line.startswith(b'INDEPENDENT_'):refuse('remove marker '+line.decode().strip(),stdout.replace(line,b'',1))
 for name in expected['scenarios']:
  folder=copy/name;carrier,profile=name.split('-')
  for leaf in policy.EXPIRY:
   path=folder/leaf;raw=path.read_bytes()
   for label,value in [('truncated',raw[:-1]),('changed',bytes([raw[0]^1])+raw[1:])]:alter(path,value,name+'/'+leaf+'/'+label)
  observation=expected['expiry_observations'][name];until=observation['policy_until'];at=observation['observed_at'];adopted=observation['receiver_adopted_at'];identity_until=int.from_bytes((folder/'intent.bin').read_bytes()[64:72],'big');body=(folder/'original-policy.bin').read_bytes();from_time=int.from_bytes(body[52:60],'big')
  for label,times in [('different expiry',(until+1,at,adopted)),('before expiry',(until,until-1,adopted)),('receiver after expiry',(until,at,until)),('receiver before validity',(until,at,from_time-1)),('expired identity',(until,identity_until,adopted))]:alter(folder/'expiry-observation.bin',b''.join(n.to_bytes(8,'big') for n in times),name+'/'+label)
  expiry=policy.expiry_marker('C',carrier,profile).encode();renewal=policy.marker('C',carrier,profile).encode()
  changed=stdout.replace(expiry,b'PHASE_PLACEHOLDER',1).replace(renewal,expiry,1).replace(b'PHASE_PLACEHOLDER',renewal,1);refuse(name+'/reversed phase order',changed)
  other='local-recoverable' if name=='local-fixed' else 'local-fixed';alter(folder/'receiver-policy.bin',(copy/other/'receiver-policy.bin').read_bytes(),name+'/receiver policy from other registration')
 sdk.require(configuration.verify_execution(stdout,copy,language='C')==expected,'public controls did not restore original inputs')
sdk.require(configuration.verify_execution(stdout,root,language='C')==expected,'original public inputs changed')
result={'completed':True,'actual_C_Debug_records':190,'controls':rows,'count':len(rows),'source_stdout_sha256':hashlib.sha256(stdout).hexdigest(),'release_claim_eligible':False}
(b/'ACTUAL_RECORD_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n');print('Actual expiry record rejection controls passed:',len(rows))
