from pathlib import Path
import hashlib,json,os,subprocess,time
b=Path(__file__).resolve().parent;s=b/'consumer';out=b/'strict-checks-01';out.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=lambda:{str(p.relative_to(s)):sha(p) for p in s.rglob('*') if p.is_file()}
record=dict(inputs=inputs(),runs=[],completed=False)
try:
 for version,command in [('1.98.1',['clippy','--all-targets','--locked','--offline','--','-D','warnings']),('1.90.0',['check','--test','first_configuration','--locked','--offline'])]:
  tc=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/rustup/toolchains')/(version+'-aarch64-apple-darwin')
  env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','DYLD','LD_','QPERIAPT','QPC','PYTHON'))}
  env.update(RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),RUSTFLAGS='-D warnings',CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(b/'check-build'),PATH=str(tc/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
  cmd=[str(tc/'bin/cargo'),*command];start=time.monotonic()
  with (out/(version+'.stdout')).open('wb') as so,(out/(version+'.stderr')).open('wb') as se:p=subprocess.run(cmd,cwd=s,env=env,stdout=so,stderr=se,timeout=1200)
  row=dict(version=version,command=cmd,returncode=p.returncode,seconds=time.monotonic()-start);record['runs'].append(row);print(json.dumps(row),flush=True);p.check_returncode()
 record['completed']=True
finally:
 record['source_unchanged']=inputs()==record['inputs'];(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
 if not record['source_unchanged']:raise RuntimeError('source changed during producer')
