from pathlib import Path
import datetime,hashlib,json,subprocess,sys,zipfile
b=Path(__file__).resolve().parent;root=b.parents[1];sys.path.insert(0,str(b/'source/artifact'))
import continuity_first_configuration as configuration
import rust_sdk_profile as sdk
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
alignment=json.loads((b/'SOURCE_ALIGNMENT.json').read_text())
for n,h in alignment['files'].items():sdk.require(sha(root/n)==sha(b/'source'/n)==h,'validated source drift: '+n)
sdk.require(not subprocess.check_output(['git','diff','--name-only'],cwd=b/'source'),'snapshot has unstaged changes')
patch=subprocess.check_output(['git','diff','--cached','--binary'],cwd=b/'source');(b/'VALIDATED.patch').write_bytes(patch)
profiles=[];operations=set();files=set();scenarios=0
specs=[('C',p,'',f'native-{p}') for p in ('debug','release')]
specs += [('Swift',p,'',f'execution-swift-{p}') for p in ('debug','release')]
specs += [('Kotlin',p,g,f'execution-kotlin-{p}-{g}') for p in ('debug','release') for g in ('g1','serial')]
for language,profile,gc,name in specs:
 out=b/name;record=json.loads((out/'RESULT.json').read_text());sdk.require(record['completed'],'incomplete profile '+name)
 sdk.require(record['source_unchanged'] if language=='C' else record['binaries_unchanged'],'mutated producer '+name)
 suffix=language.lower()+'-'+profile+('-'+gc if gc else '')
 stdout=out/('configuration-'+suffix+'.stdout');evidence=out/'configuration-public'/language.lower()/profile/(gc or 'default')
 checked=configuration.verify_execution(stdout.read_bytes(),evidence,language=language)
 sdk.require(all(record['result'][k]==v for k,v in checked.items()),'public readback differs from producer '+name)
 sdk.require(len(checked['public_readbacks'])==190 and len(checked['scenarios'])==6 and checked['real_clock_policy_expiry'],'expiry scope differs')
 for case in checked['scenarios']:
  operation=(evidence/case/'policy-request.bin').read_bytes()[:32].hex();sdk.require(operation not in operations,'reused operation across matrix');operations.add(operation)
 profiles.append({'run':name,'language':language,'profile':profile,'collector':gc or None,'scenarios':6,'public_files':190,'seconds':record['seconds'],'expiry_observations':checked['expiry_observations']});scenarios+=6
 for p in out.iterdir():
  if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.log','.txt'):files.add(p)
 files.update(p for p in evidence.rglob('*') if p.is_file())
sdk.require(scenarios==48 and len(operations)==48,'matrix incomplete')
strict=json.loads((b/'strict-checks-01/RESULT.json').read_text());sdk.require(strict['completed'] and strict['source_unchanged'],'strict checks incomplete')
controls=json.loads((b/'ACTUAL_RECORD_CONTROLS.json').read_text());sdk.require(controls['completed'] and controls['count']==114,'control matrix incomplete')
for profile in ('debug','release'):
 r=json.loads((b/f'swift-{profile}-01/RESULT.json').read_text());sdk.require(r['returncode']==0,'Swift tests failed')
 stdout=(b/f'swift-{profile}-01/stdout.log').read_text();sdk.require('Executed 62 tests, with 0 failures' in stdout,'Swift unit scope differs')
kotlin=json.loads((b/'kotlin-build-01/RESULT.json').read_text());sdk.require(kotlin['completed'] and kotlin['source_unchanged'] and kotlin['repository_unchanged'],'Kotlin build changed')
native={str(p.relative_to(root)):sha(p) for p in (root/'bindings/c/ContinuityPackageConsumer/src').rglob('*.rs')}
for n,h in native.items():sdk.require(sha(b/'consumer'/Path(n).relative_to('bindings/c/ContinuityPackageConsumer'))==h,'native source drift')
producer=Path(kotlin['repository']).parents[1];kotlin_library={}
for directory in ('src','gradle'):
 for p in (root/'bindings/kotlin/ContinuityPackageConsumer'/directory).rglob('*'):
  if p.is_file():
   relative=p.relative_to(root/'bindings/kotlin/ContinuityPackageConsumer');sdk.require(sha(p)==sha(producer/relative),'Kotlin SDK library source changed: '+str(relative));kotlin_library[str(relative)]=sha(p)
for n in ('build.gradle.kts','settings.gradle.kts'):
 p=root/'bindings/kotlin/ContinuityPackageConsumer'/n;sdk.require(sha(p)==sha(producer/n),'Kotlin SDK build input changed');kotlin_library[n]=sha(p)
for name in ('swift-debug-01','swift-release-01','kotlin-build-01','strict-checks-01'):
 files.update(p for p in (b/name).iterdir() if p.is_file())
for name in ('SOURCE_ALIGNMENT.json','VALIDATED.patch','ACTUAL_RECORD_CONTROLS.json','reader-checks.stdout','reader-checks.stderr','run-native.py','run-foreign-current.py','run-swift.py','build-kotlin-client.py','check-current.py','check-records.py','seal-current.py'):files.add(b/name)
archive=b/'PUBLIC_CAPTURE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(b)))
with zipfile.ZipFile(archive) as z:sdk.require(z.testzip() is None,'archive corruption')
checks={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':alignment['base_head'],'source':{'current_files':alignment['files'],'validated_snapshot_patch_sha256':hashlib.sha256(patch).hexdigest(),'tracked_Rust_sources':447},'scope':'Current mandatory first-use protocol-policy expiry and original-message recovery; explicit independent sender configuration, enrolled native reference receiver, same-host macOS arm64, shared native engine','profiles':profiles,'scenarios':48,'unique_policy_operations':len(operations),'public_records':48*190//6,'actual_record_negative_controls':114,'reader_and_source_gate_unit_tests':73,'Swift_unit_tests_per_profile':62,'Rust_checks':strict['runs'],'unchanged_native_sources':native,'unchanged_Kotlin_SDK_build_inputs':kotlin_library,'native_exports':132,'native_api_changes':False,'sdk_policy_replacement_qualified':False,'independent_protocol_implementation':False,'physical_platform_qualified':False,'release_claim_eligible':False,'archive':{'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files)},'remaining':['Full installed-package pipeline and exact committed-head source gate/CI','Physical devices and minimum OS qualification','SDK policy replacement in this composed first-use path','Independent protocol implementation and broader 0.2 release requirements']}
(b/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({k:v for k,v in checks.items() if k not in ('source','profiles','Rust_checks','unchanged_native_sources','unchanged_Kotlin_SDK_build_inputs')}))
