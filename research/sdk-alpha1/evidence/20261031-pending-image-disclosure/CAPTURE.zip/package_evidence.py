"""Pin owning sources and package actual pending-image disclosure evidence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import re
import subprocess
import zipfile

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=WORK.parents[1]
OUT=ROOT/'outputs'
REPO=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
COMMIT='4ae5f77ad6e81dce956be24511d7f5e429924bde'
C='research/continuity-identity-candidate/src/'
SOURCES=[
 C+'durable.rs',C+'durable/write_intent.rs',C+'durable/write_intent/tests.rs',
 C+'durable/messages/rekey.rs',C+'durable/messages/rekey/response.rs',
 C+'durable/messages/tests.rs',C+'durable/messages/tests/reservation_disclosure.rs',
 C+'durable/messages/fanout/codec.rs',C+'durable/messages/fanout/abandonment.rs',
 C+'durable/messages/fanout.rs',C+'durable/messages/retired.rs',C+'durable/messages/resolution.rs',
 C+'durable/retired_report.rs',C+'durable/pending_recovery.rs',
 C+'durable/write_intent/pending_recovery.rs',C+'durable/write_intent/retired_cleanup.rs',
 'crates/q-periapt-sdk/src/expert/replay.rs',C+'crypto.rs',
]


def sha(b):
 return hashlib.sha256(b).hexdigest()


def git(root,*args):
 return subprocess.run(['git',*args],cwd=root,check=True,capture_output=True,timeout=30).stdout


def main():
 source={}
 for rel in SOURCES:
  data=(REPO/rel).read_bytes()
  if data!=git(REPO,'show',COMMIT+':'+rel):
   raise ValueError('owning source changed: '+rel)
  p=HERE/'source'/rel
  p.parent.mkdir(parents=True,exist_ok=True)
  p.write_bytes(data)
  source[rel]={'bytes':len(data),'sha256':sha(data)}
 model=WORK/'proof/two-rounds-phase-full-template-01.spthy'
 model_bytes=model.read_bytes()
 if sha(model_bytes)!='373f9846742b6453b1f9d6bda801f2f91fca234b7be9cc862dcf153fc345da63':
  raise ValueError('selected model input differs from pinned prior evidence')
 text=model_bytes.decode()
 begin=re.search(r'^lemma ',text,re.M).start()
 prefix=text[:begin]
 marker='lemma multi_epoch_fresh_reservations_recover_symbolic_message_secrecy '
 start=text.index(marker)
 end=text.index('\n/*',start)
 formula=text[start:end]
 (HERE/'MODEL_OPERATIONAL_PREFIX.spthy.fragment').write_text(prefix)
 (HERE/'MAIN_FORMULA.txt').write_text(formula+'\n')
 source_record={'source_commit':COMMIT,'files':source,'source_and_baseline_byte_equal':True,
  'model':{'source':str(model),'sha256':sha(model_bytes),'prefix_sha256':sha(prefix.encode()),
           'formula_sha256':sha((formula+'\n').encode()),'operational_rules_and_formula_modified':False},
  'scope':'Owning-source identity and exact model excerpts, not a machine-checked refinement.'}
 (HERE/'SOURCE_READBACK.json').write_text(json.dumps(source_record,indent=2)+'\n')
 good=json.loads((HERE/'attempt-02/CHECKS.json').read_text())
 bad=json.loads((HERE/'attempt-01/CHECKS.json').read_text())
 if not good['all_selected_checks_passed'] or good['recovered_future_messages']!=12:
  raise ValueError('corrected probes not complete')
 if bad['all_selected_checks_passed'] or bad['checks'][0]['returncode']!=101:
  raise ValueError('original rejected compile evidence changed')
 for attempt,record in [('attempt-01',bad),('attempt-02',good)]:
  for row in record['checks']:
   for stream in ['stdout','stderr']:
    data=(HERE/attempt/row[stream]).read_bytes()
    if sha(data)!=row[stream+'_sha256']:
     raise ValueError('raw stream identity mismatch')
 checkout=Path(json.loads((HERE/'PREPARATION.json').read_text())['isolated_checkout'])
 modified='research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'
 if git(checkout,'diff','--name-only','HEAD').decode().splitlines()!=[modified]:
  raise ValueError('unexpected isolated source edits')
 if sha((checkout/modified).read_bytes())!=good['probe_sha256']:
  raise ValueError('tested probe changed')
 patch=(HERE/'ISOLATED_PROBE-formatted-v2.patch').read_bytes()
 if sha(patch)!=good['patch_sha256'] or patch!=git(checkout,'diff','--binary','HEAD','--',modified):
  raise ValueError('exact test-only patch mismatch')
 # No fixture private directory, plaintext or captured token is copied here.
 files={str(p.relative_to(HERE)):p.read_bytes() for p in sorted(HERE.rglob('*')) if p.is_file()}
 if any('__pycache__' in n for n in files):
  raise ValueError('unexpected generated cache')
 name='Q-periapt-pending-image-exposure'
 archive=OUT/(name+'.zip')
 if archive.exists():
  raise ValueError('refusing to overwrite prior evidence')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for member,data in files.items():
   info=zipfile.ZipInfo(member,date_time=(2026,10,31,0,0,0))
   info.compress_type=zipfile.ZIP_DEFLATED
   info.external_attr=0o100644<<16
   z.writestr(info,data,compresslevel=9)
 with zipfile.ZipFile(archive) as z:
  if z.namelist()!=list(files) or z.testzip() is not None:
   raise ValueError('archive member identity or integrity differs')
  for member,data in files.items():
   if z.read(member)!=data:
    raise ValueError('archive readback differs: '+member)
 report=OUT/(name+'.txt')
 report.write_bytes(files['REPORT.txt'])
 result={'observed_utc':datetime.now(timezone.utc).isoformat(),'source_commit':COMMIT,
  'isolated_probe_checkout':str(checkout),'runtime_files_modified':False,'main_worktree_modified':False,
  'source_files_checked':len(source),'model_changed':False,
  'checks':[{'test':r['test'],'returncode':r['returncode'],'elapsed_seconds':r['elapsed_seconds']} for r in good['checks']],
  'passed_native_tests':2,'failed_native_tests':0,'filtered_per_command':1389,
  'original_compile_failure_retained':True,'recovered_future_messages':12,
  'current_image_contains_captured_token':False,'pending_target_contains_captured_token':True,
  'target_applied_at_capture':False,'kem_result_computed_at_capture':False,
  'exact_original_target_applied_after_recovery':True,'wrong_wrapping_key_rejected':True,
  'full_model_refinement_proved':False,'computational_PQ_security_proved':False,
  'power_loss_qualified':False,'final_release_package_qualified':False,'goal_complete':False,
  'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
             'members':len(files),'all_members_read_back_equal':True},
  'report':{'file':report.name,'sha256':sha(report.read_bytes())},
  'probe_patch':{'file':'ISOLATED_PROBE-formatted-v2.patch','sha256':sha(patch)},
  'members':{n:{'bytes':len(data),'sha256':sha(data)} for n,data in files.items()}}
 (OUT/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='members'}))


if __name__=='__main__':
 main()
