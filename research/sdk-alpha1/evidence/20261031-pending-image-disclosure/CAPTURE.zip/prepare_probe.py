"""Extend a test-only isolated checkout at the exact pre-apply intent boundary."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
CHECKOUT=HERE.parent/'pending-write-exposure-checkout'
MAIN=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
COMMIT='4ae5f77ad6e81dce956be24511d7f5e429924bde'
REL='research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(root,*args):
    return subprocess.run(['git',*args],cwd=root,check=True,capture_output=True,timeout=30).stdout


def once(text,old,new):
    if text.count(old)!=1:
        raise ValueError('unexpected source multiplicity: '+old[:120])
    return text.replace(old,new)


def main():
    if git(CHECKOUT,'rev-parse','HEAD').decode().strip()!=COMMIT or git(CHECKOUT,'status','--porcelain'):
        raise ValueError('isolated checkout not clean at the selected baseline')
    original=(CHECKOUT/REL).read_bytes()
    if original!=git(MAIN,'show',COMMIT+':'+REL) or original!=(MAIN/REL).read_bytes():
        raise ValueError('test baseline identity differs')
    old=original.decode()
    start=old.index('fn kill_after_reservation(')
    end=old.index('\nfn reservation_disclosure(',start)
    helper=old[start:end]
    helper=once(helper,'fn kill_after_reservation(','fn kill_before_reservation_apply(')
    helper=once(helper,'.env("QPERIAPT_MESSAGES_STAGE", cut.stage())',
        '.env("QPERIAPT_JOURNAL_CRASH_DIR", path)\n'
        '            .env("QPERIAPT_WRITE_INTENT_CRASH_PHASE", (DurableStatus::Messages as u8).to_string())')
    helper=once(helper,'        cut.stage()\n    );','        "intent durable"\n    );')
    boundary=r'''
    // Read the actual committed image and the independently durable pending
    // image before ordinary open is allowed to reconcile and apply the target.
    let (captured, expected_target) = {
        let db = open_private_database(&path.join("state.redb")).expect("raw acquired database");
        let host = JournalKey::open(&path.join("key")).expect("disclosed wrapping key");
        let owner = crate::bootstrap::storage_owner(match cut {
            Cut::KeyReserved => p.f.initiator_device(),
            Cut::EncapsulationReserved => p.f.local_device(),
        });
        let (old, pending) = crate::durable::write_intent::load_snapshot(&db, &host, owner)
            .expect("authenticate both acquired rows without applying");
        let pending = pending.expect("write intent must already be durable");
        let target = pending.authenticated_target(&host, owner).expect("decrypt pending image");
        assert_eq!(target.revision, old.revision + 1);
        assert_eq!(target.id, old.id);
        let read = db.begin_read().expect("read acquisition");
        let table = read.open_table(crate::durable::TABLE).expect("table");
        let image_wire = table.get("image").expect("read current image").expect("current image");
        let intent_wire = table.get("pending").expect("read pending").expect("pending row");
        let expected = fs::read(path.join("saved-target-image")).expect("retained original target");
        assert!(image_wire.value() != expected.as_slice(), "target has not been applied");
        assert!(intent_wire.value() == fs::read(path.join("saved-write-intent")).expect("retained exact intent"));
        assert_eq!(crate::durable::image_hash(&expected), target.digest);
        let payload = &target.records.get(&record_id(&p.session)).expect("pending member").payload;
        let prior = State::decode(payload).expect("decode pending control state");
        assert_eq!((prior.send_epoch, prior.receive_epoch), (0, 0));
        let control = captured_control_range(payload);
        let token_start = control.end.checked_sub(cut.token_len()).expect("reservation width");
        let token = SealedOperation::from_bytes(&payload[token_start..control.end])
            .expect("exact pending KEM reservation");
        let old_record = old.records.get(&record_id(&p.session)).expect("current member");
        assert!(!old_record.payload.windows(token.as_bytes().len())
            .any(|bytes| bytes == token.as_bytes()), "current image does not contain this token");
        // Only this captured object, not a database, pending image or live owner,
        // is passed to the future predictor. No secret bytes are logged.
        let disclosed = Disclosure {
            cut,
            journal: target.id,
            root: prior.rekey,
            host_key: key(host.0.as_bytes()).expect("one-time host key capture"),
            token,
        };
        eprintln!("PENDING_WRITE_CAPTURE cut={} current_image_has_token=false pending_image_has_token=true applied=false computed=false", cut.stage());
        (disclosed, expected)
    };
'''
    helper=once(helper,'    match cut {\n        Cut::KeyReserved => {\n            p.ji = reopen',
                boundary+'    match cut {\n        Cut::KeyReserved => {\n            p.ji = reopen')
    for member in ['ji','jr']:
        former=f'            Disclosure::capture(cut, &mut p.{member}, &p.session)'
        latter=f'''            let recovered = Disclosure::capture(cut, &mut p.{member}, &p.session);
            assert!(recovered.token.as_bytes() == captured.token.as_bytes(), "same original reservation");
            let active = p.{member}.active.as_ref().expect("reopened owner");
            let read = active.db.begin_read().expect("read applied state");
            let table = read.open_table(crate::durable::TABLE).expect("table");
            assert!(table.get("image").expect("image").expect("saved image").value() == expected_target);
            assert!(table.get("pending").expect("intent readback").is_none());
            captured'''
        helper=once(helper,former,latter)
    revised=once(old,'fn reservation_disclosure(cut: Cut) {',
        'fn reservation_disclosure_with(\n    cut: Cut,\n'
        '    capture: fn(&mut Pair, Cut, Option<&[u8]>) -> Disclosure,\n) {')
    revised=once(revised,'    let disclosed = kill_after_reservation(&mut p, cut, early_offer.as_deref());',
        '    let disclosed = capture(&mut p, cut, early_offer.as_deref());')
    added=r'''

fn reservation_disclosure(cut: Cut) {
    reservation_disclosure_with(cut, kill_after_reservation);
}

#[test]
fn pending_write_generation_token_predicts_future_traffic_before_state_apply() {
    reservation_disclosure_with(Cut::KeyReserved, kill_before_reservation_apply);
}

#[test]
fn pending_write_encapsulation_token_predicts_future_traffic_before_state_apply() {
    reservation_disclosure_with(Cut::EncapsulationReserved, kill_before_reservation_apply);
}
'''
    revised += '\n// Isolated pending-write acquisition probe; no product path changes.\n'+helper+added
    (CHECKOUT/REL).write_text(revised)
    (HERE/'baseline-reservation-disclosure.rs').write_bytes(original)
    (HERE/'probe-reservation-disclosure.rs').write_text(revised)
    delta=git(CHECKOUT,'diff','--binary','HEAD','--',REL)
    (HERE/'ISOLATED_PROBE.patch').write_bytes(delta)
    if git(CHECKOUT,'diff','--name-only','HEAD').decode().splitlines()!=[REL]:
        raise ValueError('unexpected isolated modifications')
    if (MAIN/REL).read_bytes()!=original:
        raise ValueError('main user worktree changed')
    report={'baseline_commit':COMMIT,'isolated_checkout':str(CHECKOUT),'changed_test_file':REL,
            'baseline_sha256':sha(original),'probe_sha256':sha(revised.encode()),'patch_sha256':sha(delta),
            'runtime_files_modified':False,'main_worktree_modified':False,
            'scope':'Two real-process tests acquire durable pending target before ordinary state apply, then predict real future ciphertext using only captured key/root/token and public wires.',
            'tests_executed':False,'power_loss_qualification':False,'full_model_refinement':False}
    (HERE/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


if __name__=='__main__':
    main()
