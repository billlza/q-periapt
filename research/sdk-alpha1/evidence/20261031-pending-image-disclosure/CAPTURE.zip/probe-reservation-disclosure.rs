// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Finite passive disclosures of actual durable reservations, not a recovery proof.
use super::*;
use crate::durable::tests::ChildGuard;
use q_periapt_sdk::{
    expert::replay::{RecoveryKey, SealedOperation},
    Ciphertext, PublicKey, Runtime, CIPHERTEXT_LEN,
};
use std::{
    process::{Command, Stdio},
    time::{Duration, Instant},
};

#[derive(Clone, Copy, Debug)]
enum Cut {
    KeyReserved,
    EncapsulationReserved,
}
impl Cut {
    fn stage(self) -> &'static str {
        match self {
            Self::KeyReserved => "rekey-key-reserved",
            Self::EncapsulationReserved => "rekey-response-kem-reserved",
        }
    }
    fn token_len(self) -> usize {
        match self {
            Self::KeyReserved => 277,
            Self::EncapsulationReserved => 245,
        }
    }
}

// This is the attacker's complete private input. No journal, signer, live root
// or later reservation is reachable through it after capture. Runtime admission
// below supplies only the already authenticated public policy configuration.
struct Disclosure {
    cut: Cut,
    journal: [u8; 32],
    root: ZeroizingBytes<32>,
    host_key: ZeroizingBytes<32>,
    token: SealedOperation,
}
impl Disclosure {
    fn capture(cut: Cut, journal: &mut DeviceJournal, session: &[u8; 32]) -> Self {
        let image = journal
            .image()
            .expect("durable reservation after process loss");
        let payload = &image
            .records
            .get(&record_id(session))
            .expect("state")
            .payload;
        let prior = State::decode(payload).expect("authenticated checkpoint");
        assert_eq!((prior.send_epoch, prior.receive_epoch), (0, 0));
        // Capture the same actual sealed Control reservation. The independent
        // lifecycle tail appended to State contains no attacker input here.
        let control = captured_control_range(payload);
        let token_start = control
            .end
            .checked_sub(cut.token_len())
            .expect("reservation width");
        let token = SealedOperation::from_bytes(
            payload
                .get(token_start..control.end)
                .expect("exact final reservation field"),
        )
        .expect("sealed reservation");
        Self {
            cut,
            journal: image.id,
            root: prior.rekey,
            host_key: key(journal.active.as_ref().expect("open").key.0.as_bytes())
                .expect("one-time wrapping key disclosure"),
            token,
        }
    }

    fn recover_shared(
        &self,
        recovery: &RecoveryKey,
        runtime: &Runtime,
        offer: &[u8],
        response: &[u8],
    ) -> Result<ZeroizingBytes<32>, q_periapt_sdk::Error> {
        let (body, _) = crate::crypto::open_envelope(offer).expect("public offer");
        let prefix = body.get(..153).expect("offer profile/context/epoch prefix");
        let operation = rekey_digest(b"operation", &[self.journal.as_slice(), prefix].concat());
        let peer = PublicKey::from_bytes(body.get(153..).expect("public hybrid key"))?;
        let (response_body, _) = crate::crypto::open_envelope(response).expect("public response");
        let ciphertext = Ciphertext::from_bytes(
            response_body
                .get(185..185 + CIPHERTEXT_LEN)
                .expect("public ciphertext"),
        )?;
        let context = rekey_digest(b"response-kem", offer);
        match self.cut {
            Cut::KeyReserved => {
                let owner = recovery.generate_key(
                    runtime,
                    &rekey_digest(b"key", &operation),
                    &self.token,
                )?;
                assert_eq!(owner.public_key()?.to_bytes(), peer.to_bytes());
                owner
                    .decapsulate(&ciphertext, &context)?
                    .export_for_protocol()
            }
            Cut::EncapsulationReserved => {
                let scope = rekey_digest(
                    b"response-operation",
                    &[
                        self.journal.as_slice(),
                        &operation,
                        &rekey_digest(b"offer-wire", offer),
                    ]
                    .concat(),
                );
                let result = recovery.encapsulate(runtime, &scope, &peer, &context, &self.token)?;
                assert_eq!(result.ciphertext.to_bytes(), ciphertext.to_bytes());
                result.secret.export_for_protocol()
            }
        }
    }

    fn predict_traffic(
        &self,
        runtime: &Runtime,
        offer: &[u8],
        response: &[u8],
        expected_epoch: u64,
    ) -> [Traffic; 2] {
        let mut wrong_key = key(self.host_key.as_bytes()).expect("negative control");
        *wrong_key.as_mut_bytes().first_mut().expect("key byte") ^= 1;
        let wrong = RecoveryKey::from_host_key(wrong_key.as_bytes()).expect("wrong wrapping key");
        assert!(matches!(
            self.recover_shared(&wrong, runtime, offer, response),
            Err(q_periapt_sdk::Error::InvalidPrivateKey)
        ));
        let recovery = RecoveryKey::from_host_key(self.host_key.as_bytes()).expect("disclosed key");
        let shared = self
            .recover_shared(&recovery, runtime, offer, response)
            .expect("reserved entropy predicts the future hybrid contribution");
        let (response_body, _) = crate::crypto::open_envelope(response).expect("public response");
        let core = response_body
            .get(..185 + CIPHERTEXT_LEN)
            .expect("response core");
        let mut info =
            b"Q-PERIAPT-CONTINUITY-REKEY-CANDIDATE/v1/pending-root/HKDF-SHA256/".to_vec();
        info.extend_from_slice(&rekey_digest(b"response-core", core));
        let mut root = ZeroizingBytes::<32>::zeroed();
        Hkdf::<Sha256>::new(Some(self.root.as_bytes()), shared.as_bytes())
            .expand(&info, root.as_mut_bytes())
            .expect("predicted next root");

        let (offer_body, _) = crate::crypto::open_envelope(offer).expect("public offer");
        let context = offer_body.get(40..72).expect("public context digest");
        let session: [u8; 32] = offer_body
            .get(72..104)
            .expect("public session")
            .try_into()
            .expect("width");
        let target = u64::from_be_bytes(
            offer_body
                .get(112..120)
                .expect("target")
                .try_into()
                .expect("width"),
        );
        assert_eq!(target, expected_epoch);
        let mut info =
            b"Q-PERIAPT-CONTINUITY-REKEY-CANDIDATE/v1/epoch-traffic/HKDF-SHA256/ChaCha20Poly1305/"
                .to_vec();
        info.extend_from_slice(context);
        info.extend_from_slice(&target.to_be_bytes());
        info.extend_from_slice(&rekey_digest(
            b"traffic-transcript",
            &[offer, response].concat(),
        ));
        let mut material = ZeroizingBytes::<128>::zeroed();
        Hkdf::<Sha256>::new(Some(&session), root.as_bytes())
            .expand(&info, material.as_mut_bytes())
            .expect("predicted traffic owners");
        [
            Traffic::from_material(session, 2, target, material.as_bytes())
                .expect("intercept initiator"),
            Traffic::from_material(session, 1, target, material.as_bytes())
                .expect("intercept responder"),
        ]
    }
}

fn kill_after_reservation(p: &mut Pair, cut: Cut, offer: Option<&[u8]>) -> Disclosure {
    let path = match cut {
        Cut::KeyReserved => {
            p.ji.close();
            &p.pi
        }
        Cut::EncapsulationReserved => {
            p.jr.close();
            &p.pr
        }
    };
    let mut public =
        p.f.reusable
            .public_key()
            .expect("public")
            .to_bytes()
            .to_vec();
    public.extend_from_slice(&p.f.once.public_key().expect("public").to_bytes());
    fs::write(path.join("public-keys"), public).expect("fixture public keys");
    fs::write(path.join("session"), p.session).expect("session");
    fs::write(
        path.join("operation"),
        match cut {
            Cut::KeyReserved => "rekey",
            Cut::EncapsulationReserved => "rekey-response",
        },
    )
    .expect("operation");
    if let Some(offer) = offer {
        fs::write(path.join("rekey-offer"), offer).expect("public offer");
    }
    let log = fs::File::create_new(path.join("disclosure-child.log")).expect("child log");
    let mut child = ChildGuard(
        Command::new(std::env::current_exe().expect("binary"))
            .args([
                "--exact",
                "durable::messages::tests::message_crash_child",
                "--nocapture",
            ])
            .env("QPERIAPT_MESSAGES_CRASH_DIR", path)
            .env("QPERIAPT_MESSAGES_STAGE", cut.stage())
            .stdout(Stdio::from(log.try_clone().expect("clone log")))
            .stderr(Stdio::from(log))
            .spawn()
            .expect("owned child"),
    );
    let deadline = Instant::now() + Duration::from_secs(20);
    while !path.join("ready").exists() {
        assert!(
            child.0.try_wait().expect("status").is_none() && Instant::now() < deadline,
            "reservation was not committed before the deadline"
        );
        std::thread::sleep(Duration::from_millis(10));
    }
    assert_eq!(
        fs::read_to_string(path.join("ready")).expect("cut"),
        cut.stage()
    );
    assert!(
        !path.join("rekey-effect").exists(),
        "KEM computation must not precede this cut"
    );
    assert!(!path.join("returned").exists());
    child.0.kill().expect("kill owned child");
    assert!(!child.0.wait().expect("reap").success());
    match cut {
        Cut::KeyReserved => {
            p.ji = reopen(path, p.f.initiator_device());
            assert_eq!(
                p.ji.rekey_offer_status(&p.f.initiator, p.session)
                    .expect("phase"),
                RekeyOfferStatus::KeyReserved
            );
            Disclosure::capture(cut, &mut p.ji, &p.session)
        }
        Cut::EncapsulationReserved => {
            p.jr = reopen(path, p.f.local_device());
            assert_eq!(
                p.jr.rekey_response_status(&p.f.responder, p.session)
                    .expect("phase"),
                RekeyResponseStatus::EncapsulationReserved
            );
            Disclosure::capture(cut, &mut p.jr, &p.session)
        }
    }
}

fn reservation_disclosure_with(
    cut: Cut,
    capture: fn(&mut Pair, Cut, Option<&[u8]>) -> Disclosure,
) {
    let mut p = Pair::new();
    p.activate();
    let early_offer = if matches!(cut, Cut::EncapsulationReserved) {
        Some(
            p.ji.prepare_rekey_offer(&p.f.initiator, p.session, &p.f.signer_i, 150)
                .expect("offer before response reservation"),
        )
    } else {
        None
    };
    let disclosed = capture(&mut p, cut, early_offer.as_deref());
    // From this point the predictor gets only the captured snapshot, public
    // policy, control wires and ciphertext. Identity owners stay with the peers.
    let offer =
        p.ji.prepare_rekey_offer(&p.f.initiator, p.session, &p.f.signer_i, 150)
            .expect("resume exact offer");
    if let Some(early) = early_offer {
        assert_eq!(early, offer);
    }
    let response =
        p.jr.respond_rekey_offer(&p.f.responder, p.session, &offer, &p.f.signer_r, 150)
            .expect("resume exact response");
    let runtime = match cut {
        Cut::KeyReserved => {
            &p.f.initiator
                .current_policy()
                .expect("fixture policy owner")
                .runtime
        }
        Cut::EncapsulationReserved => {
            &p.f.responder
                .current_policy()
                .expect("fixture policy owner")
                .runtime
        }
    };
    let intercepts = disclosed.predict_traffic(runtime, &offer, &response, 1);
    assert_eq!(complete_rekey(&mut p), 1);
    let recovered = recover_messages(&mut p, intercepts, 1);
    eprintln!("SEALED_RESERVATION_DISCLOSURE cut={} confirmed_epoch=1 recovered_messages={recovered} directions=2 private_input=one_snapshot", cut.stage());
}

fn recover_messages(
    p: &mut Pair,
    [mut intercept_i, mut intercept_r]: [Traffic; 2],
    epoch: u64,
) -> usize {
    p.ji.close();
    p.jr.close();
    p.ji = reopen(&p.pi, p.f.initiator_device());
    p.jr = reopen(&p.pr, p.f.local_device());
    let mut recovered = 0;
    for _ in 0..3 {
        for from_initiator in [true, false] {
            let (sender, receiver, sc, rc, intercept) = if from_initiator {
                (
                    &mut p.ji,
                    &mut p.jr,
                    &p.f.initiator,
                    &p.f.responder,
                    &mut intercept_i,
                )
            } else {
                (
                    &mut p.jr,
                    &mut p.ji,
                    &p.f.responder,
                    &p.f.initiator,
                    &mut intercept_r,
                )
            };
            let mut plaintext = Zeroizing::new(vec![0; 128]);
            getrandom::fill(&mut plaintext).expect("post-disclosure application data");
            let id = sender
                .next_message_id(sc, p.session, 150)
                .expect("new epoch ID");
            assert_eq!(id.epoch().expect("epoch"), epoch);
            let wire = sender
                .send_message(sc, p.session, id, &plaintext, b"application", 150)
                .expect("committed send");
            assert_eq!(
                receiver
                    .receive_message(rc, p.session, &wire, b"application", 150)
                    .expect("honest delivery")
                    .as_bytes(),
                plaintext.as_slice()
            );
            assert_eq!(
                intercept
                    .receive(&wire, b"application")
                    .expect("actual future message decryption from prior disclosure")
                    .as_bytes(),
                plaintext.as_slice()
            );
            recovered += 1;
        }
    }
    assert_eq!(recovered, 6);
    recovered
}

#[test]
fn disclosed_key_reservation_exposes_traffic_computed_after_restart() {
    reservation_disclosure(Cut::KeyReserved);
}

#[test]
fn disclosed_encapsulation_reservation_exposes_traffic_computed_after_restart() {
    reservation_disclosure(Cut::EncapsulationReserved);
}

// Select the retained key-generation token from an authenticated committed
// offer. The predictor receives neither an identity owner nor future state.
fn capture_committed_second_offer(p: &mut Pair, offer: &[u8]) -> Disclosure {
    let image = p.jr.image().expect("single responder snapshot");
    let payload = &image
        .records
        .get(&record_id(&p.session))
        .expect("state")
        .payload;
    let captured = State::decode(payload).expect("authenticated snapshot");
    assert_eq!(
        (
            captured.control.confirmed_epoch(),
            captured.send_epoch,
            captured.receive_epoch
        ),
        (1, 1, 1)
    );
    let control = captured_control_range(payload);
    let token_end = control.end.checked_sub(offer.len()).expect("offer width");
    let token_start = token_end.checked_sub(277).expect("key token width");
    assert!(token_start > control.start);
    assert_eq!(
        payload.get(token_start - 1),
        Some(&3),
        "committed offer phase"
    );
    assert_eq!(
        payload.get(token_end..control.end),
        Some(offer),
        "exact public offer"
    );
    Disclosure {
        // This selects key-generation replay, not a first-reservation cut:
        // the token survives in phase 3 after the signed offer is committed.
        cut: Cut::KeyReserved,
        journal: image.id,
        root: captured.rekey,
        host_key: key(p.jr.active.as_ref().expect("open").key.0.as_bytes())
            .expect("disclosed wrapping key"),
        token: SealedOperation::from_bytes(payload.get(token_start..token_end).expect("token"))
            .expect("sealed token"),
    }
}

#[test]
fn lagging_peer_confirmation_does_not_bound_second_epoch_disclosure() {
    let mut p = Pair::new();
    p.activate();
    let offer =
        p.ji.prepare_rekey_offer(&p.f.initiator, p.session, &p.f.signer_i, 150)
            .expect("first offer");
    let response =
        p.jr.respond_rekey_offer(&p.f.responder, p.session, &offer, &p.f.signer_r, 150)
            .expect("first response");
    let final_wire =
        p.ji.accept_rekey_response(&p.f.initiator, p.session, &response, &p.f.signer_i, 150)
            .expect("first final");
    let held_receipt =
        p.jr.finish_rekey(&p.f.responder, p.session, &final_wire, &p.f.signer_r, 150)
            .expect("hold first receipt");
    let lagging =
        p.ji.rekey_progress(&p.f.initiator, p.session)
            .expect("lagging peer");
    assert_eq!(
        (
            lagging.confirmed_epoch,
            lagging.sending_epoch,
            lagging.receiving_epoch,
            lagging.pending_epoch
        ),
        (0, 1, 0, Some(1))
    );
    let next_offer =
        p.jr.prepare_rekey_offer(&p.f.responder, p.session, &p.f.signer_r, 150)
            .expect("second offer before first receipt delivery");
    let ahead =
        p.jr.rekey_progress(&p.f.responder, p.session)
            .expect("ahead peer");
    assert_eq!(
        (
            ahead.confirmed_epoch,
            ahead.sending_epoch,
            ahead.receiving_epoch,
            ahead.pending_epoch
        ),
        (1, 1, 1, Some(2))
    );
    assert_eq!(
        p.jr.rekey_offer_status(&p.f.responder, p.session)
            .expect("second offer status"),
        RekeyOfferStatus::Committed
    );
    assert_eq!(
        p.ji.rekey_progress(&p.f.initiator, p.session)
            .expect("still lagging"),
        lagging
    );
    let disclosed = capture_committed_second_offer(&mut p, &next_offer);
    // No later private state is passed to the predictor. Restart both honest
    // peers; only then deliver the delayed receipt and public second exchange.
    p.ji.close();
    p.jr.close();
    p.ji = reopen(&p.pi, p.f.initiator_device());
    p.jr = reopen(&p.pr, p.f.local_device());
    assert_eq!(
        p.ji.rekey_progress(&p.f.initiator, p.session)
            .expect("durable lag"),
        lagging
    );
    assert_eq!(
        p.jr.rekey_progress(&p.f.responder, p.session)
            .expect("durable lead"),
        ahead
    );
    assert_eq!(
        p.jr.prepare_rekey_offer(&p.f.responder, p.session, &p.f.signer_r, 150)
            .expect("same second offer"),
        next_offer
    );
    assert_eq!(
        p.ji.accept_rekey_receipt(&p.f.initiator, p.session, &held_receipt, 150)
            .expect("delayed first receipt"),
        1
    );
    let next_response =
        p.ji.respond_rekey_offer(&p.f.initiator, p.session, &next_offer, &p.f.signer_i, 150)
            .expect("second response");
    let runtime =
        &p.f.responder
            .current_policy()
            .expect("public policy")
            .runtime;
    let intercepts = disclosed.predict_traffic(runtime, &next_offer, &next_response, 2);
    assert_eq!(complete_rekey(&mut p), 2);
    let recovered = recover_messages(&mut p, intercepts, 2);
    eprintln!("ASYMMETRIC_RESERVATION_DISCLOSURE lagging_confirmed=0 captured_confirmed=1 captured_pending=2 captured_phase=3 recovered_epoch=2 recovered_messages={recovered} directions=2 private_input=one_responder_snapshot");
}

// Isolated pending-write acquisition probe; no product path changes.
fn kill_before_reservation_apply(p: &mut Pair, cut: Cut, offer: Option<&[u8]>) -> Disclosure {
    let path = match cut {
        Cut::KeyReserved => {
            p.ji.close();
            &p.pi
        }
        Cut::EncapsulationReserved => {
            p.jr.close();
            &p.pr
        }
    };
    let mut public =
        p.f.reusable
            .public_key()
            .expect("public")
            .to_bytes()
            .to_vec();
    public.extend_from_slice(&p.f.once.public_key().expect("public").to_bytes());
    fs::write(path.join("public-keys"), public).expect("fixture public keys");
    fs::write(path.join("session"), p.session).expect("session");
    fs::write(
        path.join("operation"),
        match cut {
            Cut::KeyReserved => "rekey",
            Cut::EncapsulationReserved => "rekey-response",
        },
    )
    .expect("operation");
    if let Some(offer) = offer {
        fs::write(path.join("rekey-offer"), offer).expect("public offer");
    }
    let log = fs::File::create_new(path.join("disclosure-child.log")).expect("child log");
    let mut child = ChildGuard(
        Command::new(std::env::current_exe().expect("binary"))
            .args([
                "--exact",
                "durable::messages::tests::message_crash_child",
                "--nocapture",
            ])
            .env("QPERIAPT_MESSAGES_CRASH_DIR", path)
            .env("QPERIAPT_JOURNAL_CRASH_DIR", path)
            .env("QPERIAPT_WRITE_INTENT_CRASH_PHASE", (DurableStatus::Messages as u8).to_string())
            .stdout(Stdio::from(log.try_clone().expect("clone log")))
            .stderr(Stdio::from(log))
            .spawn()
            .expect("owned child"),
    );
    let deadline = Instant::now() + Duration::from_secs(20);
    while !path.join("ready").exists() {
        assert!(
            child.0.try_wait().expect("status").is_none() && Instant::now() < deadline,
            "reservation was not committed before the deadline"
        );
        std::thread::sleep(Duration::from_millis(10));
    }
    assert_eq!(
        fs::read_to_string(path.join("ready")).expect("cut"),
        "intent durable"
    );
    assert!(
        !path.join("rekey-effect").exists(),
        "KEM computation must not precede this cut"
    );
    assert!(!path.join("returned").exists());
    child.0.kill().expect("kill owned child");
    assert!(!child.0.wait().expect("reap").success());

    // Read the actual committed image and the independently durable pending
    // image before ordinary open is allowed to reconcile and apply the target.
    let (captured, expected_target) = {
        let db = open_private_database(&path.join("state.redb")).expect("raw acquired database");
        let host = JournalKey::open(&path.join("key")).expect("disclosed wrapping key");
        let owner = crate::bootstrap::storage_owner(match cut {
            Cut::KeyReserved => p.f.initiator_device(),
            Cut::EncapsulationReserved => p.f.local_device(),
        });
        let (old, pending) = crate::durable::write_intent::load_snapshot(&db, &host, owner)
            .expect("authenticate both acquired rows without applying");
        let pending = pending.expect("write intent must already be durable");
        let target = pending.authenticated_target(&host, owner).expect("decrypt pending image");
        assert_eq!(target.revision, old.revision + 1);
        assert_eq!(target.id, old.id);
        let read = db.begin_read().expect("read acquisition");
        let table = read.open_table(crate::durable::TABLE).expect("table");
        let image_wire = table.get("image").expect("read current image").expect("current image");
        let intent_wire = table.get("pending").expect("read pending").expect("pending row");
        let expected = fs::read(path.join("saved-target-image")).expect("retained original target");
        assert!(image_wire.value() != expected.as_slice(), "target has not been applied");
        assert!(intent_wire.value() == fs::read(path.join("saved-write-intent")).expect("retained exact intent"));
        assert_eq!(crate::durable::image_hash(&expected), target.digest);
        let payload = &target.records.get(&record_id(&p.session)).expect("pending member").payload;
        let prior = State::decode(payload).expect("decode pending control state");
        assert_eq!((prior.send_epoch, prior.receive_epoch), (0, 0));
        let control = captured_control_range(payload);
        let token_start = control.end.checked_sub(cut.token_len()).expect("reservation width");
        let token = SealedOperation::from_bytes(&payload[token_start..control.end])
            .expect("exact pending KEM reservation");
        let old_record = old.records.get(&record_id(&p.session)).expect("current member");
        assert!(!old_record.payload.windows(token.as_bytes().len())
            .any(|bytes| bytes == token.as_bytes()), "current image does not contain this token");
        // Only this captured object, not a database, pending image or live owner,
        // is passed to the future predictor. No secret bytes are logged.
        let disclosed = Disclosure {
            cut,
            journal: target.id,
            root: prior.rekey,
            host_key: key(host.0.as_bytes()).expect("one-time host key capture"),
            token,
        };
        eprintln!("PENDING_WRITE_CAPTURE cut={} current_image_has_token=false pending_image_has_token=true applied=false computed=false", cut.stage());
        (disclosed, expected)
    };
    match cut {
        Cut::KeyReserved => {
            p.ji = reopen(path, p.f.initiator_device());
            assert_eq!(
                p.ji.rekey_offer_status(&p.f.initiator, p.session)
                    .expect("phase"),
                RekeyOfferStatus::KeyReserved
            );
            let recovered = Disclosure::capture(cut, &mut p.ji, &p.session);
            assert!(recovered.token.as_bytes() == captured.token.as_bytes(), "same original reservation");
            let active = p.ji.active.as_ref().expect("reopened owner");
            let read = active.db.begin_read().expect("read applied state");
            let table = read.open_table(crate::durable::TABLE).expect("table");
            assert!(table.get("image").expect("image").expect("saved image").value() == expected_target);
            assert!(table.get("pending").expect("intent readback").is_none());
            captured
        }
        Cut::EncapsulationReserved => {
            p.jr = reopen(path, p.f.local_device());
            assert_eq!(
                p.jr.rekey_response_status(&p.f.responder, p.session)
                    .expect("phase"),
                RekeyResponseStatus::EncapsulationReserved
            );
            let recovered = Disclosure::capture(cut, &mut p.jr, &p.session);
            assert!(recovered.token.as_bytes() == captured.token.as_bytes(), "same original reservation");
            let active = p.jr.active.as_ref().expect("reopened owner");
            let read = active.db.begin_read().expect("read applied state");
            let table = read.open_table(crate::durable::TABLE).expect("table");
            assert!(table.get("image").expect("image").expect("saved image").value() == expected_target);
            assert!(table.get("pending").expect("intent readback").is_none());
            captured
        }
    }
}


fn reservation_disclosure(cut: Cut) {
    reservation_disclosure_with(cut, kill_after_reservation);
}

#[test]
fn pending_write_generation_token_predicts_future_traffic_before_state_apply() {
    reservation_disclosure_with(Cut::KeyReserved, kill_before_reservation_apply);
}

#[test]
fn pending_write_encapsulation_token_predicts_future_traffic_before_state_apply() {
    reservation_disclosure_with(Cut::EncapsulationReserved, kill_before_reservation_apply);
}
