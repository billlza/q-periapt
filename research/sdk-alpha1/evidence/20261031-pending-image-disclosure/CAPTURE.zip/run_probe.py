"""Run the isolated pre-apply acquisition probes with unchanged strict bounds."""
from contextlib import chdir
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
W=HERE.parent
ROOT=W.parents[1]
CHECKOUT=W/'pending-write-exposure-checkout'
MAIN=Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
REL='research/continuity-identity-candidate/src/durable/messages/tests/reservation_disclosure.rs'
sys.path.insert(0,str(CHECKOUT/'artifact'))
from bounded_process import capture_output,BoundedProcessError


def sha(b):
 return hashlib.sha256(b).hexdigest()


def git(root,*args):
 return subprocess.run(['git',*args],cwd=root,check=True,capture_output=True,timeout=30).stdout


def main():
 stage=HERE/'attempt-01'
 stage.mkdir(exist_ok=False)
 env=dict(os.environ)
 env.update(CARGO_HOME=str(ROOT/'work/rust-runtime/cargo'),RUSTUP_HOME=str(ROOT/'work/rust-runtime/rustup'),
  RUSTUP_AUTO_INSTALL='0',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(W/'receipt-mapping-build'),
  CARGO_TERM_COLOR='never',RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings')
 env['PATH']=str(ROOT/'work/rust-runtime/cargo/bin')+os.pathsep+env['PATH']
 formatted=subprocess.run(['rustup','run','1.98.1','rustfmt','--edition','2021',str(CHECKOUT/REL)],
                         env=env,capture_output=True,timeout=60,check=False)
 (stage/'format.stdout').write_bytes(formatted.stdout)
 (stage/'format.stderr').write_bytes(formatted.stderr)
 if formatted.returncode or formatted.stderr:
  raise RuntimeError('scoped rustfmt did not succeed without diagnostics')
 git(CHECKOUT,'diff','--check')
 if git(CHECKOUT,'diff','--name-only','HEAD').decode().splitlines()!=[REL]:
  raise ValueError('unexpected isolated changed files')
 if git(CHECKOUT,'ls-files','--others','--exclude-standard'):
  raise ValueError('unexpected untracked source files')
 baseline=(HERE/'baseline-reservation-disclosure.rs').read_bytes()
 if (MAIN/REL).read_bytes()!=baseline:
  raise ValueError('user source differs from prepared baseline')
 code=(CHECKOUT/REL).read_bytes()
 (HERE/'probe-reservation-disclosure-formatted.rs').write_bytes(code)
 delta=git(CHECKOUT,'diff','--binary','HEAD','--',REL)
 (HERE/'ISOLATED_PROBE-formatted.patch').write_bytes(delta)
 tracked=git(CHECKOUT,'ls-files','-z').decode().strip('\0').split('\0')
 source={rel:sha((CHECKOUT/rel).read_bytes()) for rel in tracked if (CHECKOUT/rel).is_file() and not (CHECKOUT/rel).is_symlink()}
 tests=['durable::messages::tests::reservation_disclosure::pending_write_generation_token_predicts_future_traffic_before_state_apply',
        'durable::messages::tests::reservation_disclosure::pending_write_encapsulation_token_predicts_future_traffic_before_state_apply']
 record={'started_utc':datetime.now(timezone.utc).isoformat(),'checks':[],'all_selected_checks_passed':False,
  'baseline_commit':git(CHECKOUT,'rev-parse','HEAD').decode().strip(),'probe_sha256':sha(code),
  'patch_sha256':sha(delta),'runtime_files_modified':False,'source_sha256':source,
  'timeout_each_seconds':900,'jobs':2,'power_loss_qualified':False,'full_model_refinement_proved':False,
  'scope':'One private pending-image acquisition at each first KEM reservation; no later private input to predictor. Product and user worktree unchanged.'}
 (stage/'STARTED.json').write_text(json.dumps({'pid':os.getpid(),'tests':tests,'timeout_each_seconds':900})+'\n')
 try:
  for i,test in enumerate(tests):
   args=['cargo','+1.98.1','test','--locked','--manifest-path','research/continuity-identity-candidate/Cargo.toml',
         '--lib','-j','2',test,'--','--exact','--nocapture']
   start=time.monotonic()
   with chdir(CHECKOUT),(stage/f'{i:02d}.stdout').open('xb') as out,(stage/f'{i:02d}.stderr').open('xb') as err:
    result=capture_output(args,environment=env,timeout_seconds=900,maximum_stdout_bytes=16*1024**2,
                          maximum_stderr_bytes=16*1024**2,stdout_sink=out.write,stderr_sink=err.write)
   row={'test':test,'argv':args,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-start,
        'stdout':f'{i:02d}.stdout','stderr':f'{i:02d}.stderr',
        'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)}
   record['checks'].append(row)
   (stage/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n')
   print(json.dumps(row),flush=True)
   if result.returncode!=0:
    raise RuntimeError(result.stderr.decode()[-6000:])
   if f'test {test} ... ok'.encode() not in result.stdout or b'test result: ok. 1 passed; 0 failed; 0 ignored;' not in result.stdout:
    raise ValueError('exact native test did not pass')
   if re.search(rb'(?mi)^\s*(warning|error)(?:\[|:)',result.stderr):
    raise ValueError('new warning/error diagnostic')
   if b'current_image_has_token=false pending_image_has_token=true applied=false computed=false' not in result.stderr:
    raise ValueError('missing pre-apply acquisition evidence')
   if b'confirmed_epoch=1 recovered_messages=6 directions=2 private_input=one_snapshot' not in result.stderr:
    raise ValueError('missing future-message decryption evidence')
  after={rel:sha((CHECKOUT/rel).read_bytes()) for rel in source}
  if after!=source or (MAIN/REL).read_bytes()!=baseline:
   raise ValueError('source identity changed during execution')
  record.update(all_selected_checks_passed=True,source_unchanged_during_checks=True,
                main_worktree_test_file_unchanged=True,recovered_future_messages=12)
 except BaseException as error:
  record['failure']={'type':type(error).__name__,'message':str(error)}
  if isinstance(error,BoundedProcessError):
   record['failure'].update(kind=error.kind,cleanup_ambiguous=error.cleanup_ambiguous)
  raise
 finally:
  record['driver_sha256']=sha(Path(__file__).read_bytes())
  record['finished_utc']=datetime.now(timezone.utc).isoformat()
  (stage/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n')


if __name__=='__main__':
 main()
