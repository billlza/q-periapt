from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path.cwd();stage=root/'target/continuity-browser-product';dest=root/'research/sdk-alpha1/evidence/20261013-product-browser-lifecycle';dest.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((stage/'final-run/RESULT.json').read_text());assert report['completed'] and len(report['cases'])==8
assert sum(len(c['witness_records']) for c in report['cases'])==308
for c in report['cases']:
 assert c['active']==c['reopened'] and len(c['active']['prekey'])==1184
 records=c['witness_records'];changes=[r for r in records if r['changed']]
 assert [(r['before']['revision'],r['after']['revision']) for r in changes]==[(1,2),(2,3)]
 assert all(r['before']['fence']==1==r['after']['fence'] for r in records)
 for a,b in zip(records,records[1:]):assert a['after']==b['before']
base=json.loads((stage/'base-final/RESULT.json').read_text());assert base['completed'] and len(base['report']['cases'])==10
creation=json.loads((stage/'creation-regression/public/BROWSER_ENROLLMENT.json').read_text());assert creation['completed'] and len(creation['native_verified'])==19
source=json.loads((stage/'SOURCE-03.json').read_text())
for name,digest in source['files'].items():assert sha(root/name)==sha(stage/'source'/name)==digest
members={}
def add(path,name):
 assert path.is_file() and not path.is_symlink() and name not in members;members[name]=path
for name in source['files']:add(root/name,'source-overlay/'+name)
for p in (stage/'sources-package-02').rglob('*'):
 if p.is_file():add(p,'source-overlay-package-02/'+p.relative_to(stage/'sources-package-02').as_posix())
for folder in ['run-01','final-run']:
 for item in ['logs','captures','witness']:
  for p in (stage/folder/item).rglob('*'):
   if p.is_file() and not any(part.startswith('.') for part in p.relative_to(stage/folder).parts):add(p,folder+'/'+p.relative_to(stage/folder).as_posix())
 add(stage/folder/'RESULT.json',folder+'/RESULT.json')
for folder in ['base-red','base-final']:
 for p in (stage/folder).iterdir():
  if p.is_file():add(p,folder+'/'+p.name)
for p in (stage/'creation-regression/public').rglob('*'):
 if p.is_file() and not any(part.startswith('.') for part in p.relative_to(stage/'creation-regression/public').parts):add(p,'creation/'+p.relative_to(stage/'creation-regression/public').as_posix())
for name in ['root.bin','description.bin']:add(stage/'creation-regression/web/inputs'/name,'creation-public-inputs/'+name)
packages=[]
for suffix in ['', '-02', '-03']:
 folder=stage/'source/target'/('product-package'+suffix)
 for p in folder.iterdir():
  if p.is_file():add(p,'package'+suffix+'/'+p.name)
 if suffix:
  packages.append(json.loads((folder/'INSTALLED_CONSUMER.json').read_text()))
  add(folder/'package/PACKAGE_CONTENTS.json','package'+suffix+'/PACKAGE_CONTENTS.json')
  add(folder/'package/THIRD_PARTY/rust/INVENTORY.json','package'+suffix+'/LICENSE_INVENTORY.json')
consumer=Path(packages[0]['installed']).parent.parent
for p in (consumer/'inputs').glob('*.json'):add(p,'public-inputs/'+p.name)
for p in stage.iterdir():
 if p.is_file() and p.suffix in ['.py','.js','.sh','.json','.stdout','.stderr']:add(p,'driver/'+p.name)
for name in ['product-clippy-02.stdout','product-clippy-02.stderr','owner-clippy.stdout','owner-clippy.stderr']:
 add(root/'target/continuity-browser-witness'/name,'earlier-checks/'+name)
witness=root/'target/continuity-browser-witness/source/research/continuity-identity-candidate'
for name in ['Cargo.toml','Cargo.lock','examples/browser_activation_authority.rs','src/anchor/store.rs']:add(witness/name,'native-witness-adapter/'+name)
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
checks={'completed':True,'release_claim_eligible':False,'base_commit':source['base'],
 'capture':{'sha256':sha(archive),'members':len(members),'bytes':archive.stat().st_size},
 'cases':[{'case':c['case'],'requests':len(c['witness_records']),'rejected':c.get('rejected'),'prekey_sha256':hashlib.sha256(bytes(c['active']['prekey'])).hexdigest()} for c in report['cases']],
 'concurrent_request_controls':8,'actual_witness_requests':308,'base_browser_cases':10,'native_verified_creation_requests':19,
 'package_archives':[{'sha256':r['sha256'],'manifest_sha256':r['manifest_sha256'],'installed_node_tests':r['installed_node_tests'],'typescript':r['typescript'],'license_packages':r['license_packages'],'node_version':r['runtime']['version']} for r in packages],
 'runtime_equivalence':json.loads((stage/'RUNTIME_EQUIVALENCE.json').read_text()),
 'checks':{'engine_wasm_clippy':True,'product_wasm_clippy':True,'product_native_clippy':True,'rustfmt':True,'artifact_tests':22},
 'not_yet_qualified':['deployed HTTPS','complete session/publication/root/roster and migration browser APIs','stable recovery-status and structured error surface','new browser build on minimum Rust compiler','full 0.2.0 release scope'],
 'note':'Isolated native authority/witness only; browser calls installed public npm web exports without an experimental WASM adapter. Existing 19108614 Rust/C/Swift package producer remains separate and live.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks['capture']))
