import initialize, { QPeriaptRuntime, QPeriaptContinuityDevice as Device,
  QPeriaptContinuityEnrollment as Enrollment, QPeriaptContinuityPolicy as Policy,
  QPeriaptContinuityAccountTrust as Trust, QPeriaptContinuityWitness as Witness,
  QPeriaptContinuityPrekeyKind as Kind } from '/node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const bytes = value => new Uint8Array(value);
let owner, pendingClose;
self.onmessage = async ({data}) => {
  if (data.cancel) {
    if (!owner) throw Error('no pending owner');
    pendingClose = owner.close();
    postMessage({cancellation_requested:true});
    return;
  }
  let runtime, policy, intent, trust, witness, prepared;
  let value, failure;
  try {
    const response=await fetch('/inputs/'+data.case+'.json');if(!response.ok)throw Error('public inputs');
    const config=await response.json();const description=bytes(config.description);
    intent=new Enrollment(bytes(config.root),description.slice(0,16),new DataView(description.buffer).getBigUint64(16),bytes(config.family),BigInt(config.from),BigInt(config.until));
    const storage=bytes(data.id.match(/../g).map(value=>parseInt(value,16)));
    if(data.operation==='create') {
      owner=await Device.create(data.name,storage,intent);
      const requests=await Promise.allSettled([owner.request(BigInt(Math.floor(Date.now()/1000))),owner.request(BigInt(Math.floor(Date.now()/1000)))]);
      if(requests[0].status!=='fulfilled'||requests[1].status!=='rejected'||!String(requests[1].reason).includes('WouldBlock'))throw Error('concurrent request control');
      const request=await owner.request(BigInt(Math.floor(Date.now()/1000)));
      if(request.toString()!==requests[0].value.toString())throw Error('Busy changed original request');
      value={request:[...request],concurrent_request:'WouldBlock; original owner remained usable'};
    } else {
      const grantResponse=await fetch('/inputs/'+data.case+'-grant.json');if(!grantResponse.ok)throw Error('grant');
      const grant=await grantResponse.json();
      const signature=bytes(config.sdk_signature);if(data.badPolicy)signature[0]^=1;
      runtime=new QPeriaptRuntime(bytes(config.sdk_policy),signature,bytes(config.sdk_root),bytes(config.sdk_state),32,4);
      const statement=config.policies.required;
      policy=new Policy(runtime,bytes(config.policy_root),bytes(config.family),BigInt(statement.version),bytes(statement.digest),bytes(statement.wire),BigInt(Math.floor(Date.now()/1000)));
      const digest=bytes(grant.digest);if(data.badGrant)digest[0]^=1;
      trust=new Trust(bytes(config.account),bytes(config.root),BigInt(grant.version),digest,bytes(config.family));
      owner=await Device.open(data.name,storage,intent);
      const journal=await owner.accept(bytes(grant.certificate),bytes(grant.roster),trust,policy,BigInt(Math.floor(Date.now()/1000)));
      if(data.phase==='accept')value={phase:'accepted',journal:[...journal]};
      else if(data.phase==='prepare') {
        prepared=await owner.prepare(policy,BigInt(Math.floor(Date.now()/1000)));
        if(!prepared.requires_witness())throw Error('required witness downgraded');
        value={phase:'requires-witness-enrollment',journal:[...journal],genesis:[...prepared.image_digest()],subject:[...prepared.subject()]};
      } else if(data.phase==='activate') {
        witness=Witness.for_loopback(bytes(config.witness_id),bytes(data.wrongPin?config.root:config.witness_public),new URL('/witness/'+data.case+'?mode='+(data.mode??'normal'),location.origin).href,data.timeout??5000);
        if(data.cancelBefore)await owner.close();
        const identity=await owner.activate(policy,witness,BigInt(Math.floor(Date.now()/1000)));
        const prekey=await owner.generate_prekey(policy,new Uint8Array(32).fill(55),Kind.OneTimePq,BigInt(config.from),BigInt(config.until),BigInt(Math.floor(Date.now()/1000)));
        value={phase:'active',journal:[...identity],prekey:[...prekey]};
      } else throw Error('unknown phase');
    }
  } catch(error) { failure=error; }
  try {if(pendingClose)await pendingClose;if(owner)await owner.close();}catch(cleanup){failure=new AggregateError(failure?[failure,cleanup]:[cleanup],'operation/cleanup failed');}
  if(owner){owner.free();owner=undefined;}pendingClose=undefined;
  prepared?.free();witness?.free();trust?.free();intent?.free();policy?.close();policy?.free();runtime?.close();runtime?.free();
  if(failure)postMessage({done:true,error:String(failure),code:failure.code});else postMessage({done:true,value});
};
postMessage({ready:true});
