from pathlib import Path
import contextlib,json,os,sys,uuid,shutil
from bounded_process import capture_output
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
sys.path.insert(0,str(Path(__file__).parent))
from server import serving
root=Path.cwd();stage=root/'target/continuity-browser-product';package=stage/'source/target/product-package-02';web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=stage/sys.argv[1];out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();private=stage/(sys.argv[1]+'-private');private.mkdir(mode=0o700)
inputs=web/'inputs';inputs.mkdir(mode=0o700,exist_ok=True)
(web/'creation').mkdir(exist_ok=True)
for name in ('worker.js','controller.js'):shutil.copyfile(stage/name,web/'creation'/name)
(web/'creation/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Required witness qualification</title><script type="module" src="./controller.js"></script>')
session='qpc-witness-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
source=json.loads((package/'sources-before.json').read_text())
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file() and inputs not in p.parents}
state={'completed':False,'scope':'actual installed npm web entry, shared owned device and required signed witness protocol; not HTTPS deployment qualification','source':source,'static_web':static,'native_binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'cases':[]}
sequence=0

def browser(args,label):
 with contextlib.chdir(out):
  result=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(result.stdout);(logs/(label+'.stderr')).write_bytes(result.stderr)
 sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':result.returncode})
 sdk.require(result.returncode==0 and not result.stderr,label+' CLI failure')
 return result.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:03}'
 script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode()
 sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution failed: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='witness')
 sdk.require(value['diagnostics']==[],'browser diagnostics')
 return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']

def native(args,label):
 sdk.command([str(binary),*map(str,args)],logs/label,root,environment=dict(os.environ))

try:
 with serving(web,out,private,binary) as (origin,records,failures):
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];document.cookie="ambient_witness_control=present; Path=/witness/; SameSite=Strict";addEventListener("error",event=>diagnostics.push(event.message));addEventListener("unhandledrejection",event=>diagnostics.push(String(event.reason)));}); return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case in sys.argv[2:]:
    key=sys.argv[1]+'-'+case;directory=private/key;directory.mkdir(mode=0o700)
    native(['prepare',directory],case+'-prepare-authorities');shutil.copyfile(directory/'PUBLIC.json',inputs/(key+'.json'))
    base={'case':key,'name':key+'-'+uuid.uuid4().hex[:10],'id':uuid.uuid4().hex+uuid.uuid4().hex,'operation':'activation'}
    request=success({**base,'operation':'create'})
    grant=inputs/(key+'-grant.json');native(['issue',directory,out/'captures'/(key+'.bin'),grant],case+'-issue')
    accepted=success({**base,'phase':'accept'});prepared=success({**base,'phase':'prepare'})
    sdk.require(prepared['phase']=='requires-witness-enrollment' and prepared['journal']==accepted['journal'],'required witness lost original journal')
    genesis=out/'captures'/(key+'-genesis.json');native(['enroll',directory,grant,genesis],case+'-enroll')
    row={'case':case,'key':key,'accepted':accepted,'prepared':prepared};state['cases'].append(row)
    if case!='healthy':
     options={
       'precancel':{'cancelBefore':True},'wrong-pin':{'wrongPin':True},
       'drop':{'mode':'drop-after-advance'},'timeout':{'mode':'timeout-after-advance','timeout':2000},
       'cancel':{'mode':'hold-after-advance','cancelOnAdvance':True},
       'corrupt':{'mode':'corrupt'},'oversized':{'mode':'oversized'}}[case]
     rejected=invoke({**base,'phase':'activate',**options});row['rejected']=rejected
     sdk.require('error' in rejected,'fault accepted: '+case)
     expected={'precancel':'Closed','wrong-pin':'Scope','drop':'Network','timeout':'TimedOut','cancel':'Interrupted','corrupt':'Anchor(Verification(Authentication))','oversized':'InvalidData'}[case]
     sdk.require(expected in rejected['error'],'wrong failure: '+json.dumps(rejected))
     if case in ['precancel','wrong-pin']:sdk.require(not records.get(key),'pre-dispatch failure sent request')
     if case in ['drop','timeout','cancel']:sdk.require(any(r['after']['revision'] > r['before']['revision'] for r in records[key]),'witness never committed')
     if case=='cancel':sdk.require(rejected['cancellationRequested'],'cancellation did not reach pending operation')
    active=success({**base,'phase':'activate'});reopened=success({**base,'phase':'activate'})
    sdk.require(active==reopened and active['journal']==accepted['journal'] and len(active['prekey'])==1184,'original prekey/journal changed')
    row.update(active=active,reopened=reopened)
    native(['enroll',directory,grant,genesis],case+'-reenroll')
    head=parse_strict_json_bytes((logs/(case+'-reenroll.stdout')).read_bytes(),label='witness head')
    sdk.require(head==records[key][-1]['after'],'retry enrollment reset advanced witness')
    sdk.require(success({**base,'phase':'activate'})==active,'reenrollment lost original state')
    if case=='healthy':
     for field,expected in [('badPolicy','policy denied'),('badGrant','Checkpoint')]:
      rejected=invoke({**base,'phase':'activate',field:True});sdk.require(expected in rejected.get('error',''),'wrong trust-input rejection: '+str(rejected));row[field]=rejected
      sdk.require(success({**base,'phase':'activate'})==active,'failed trust input changed original state')
    row['witness_records']=records[key]
    sdk.require(not failures,'server failures: '+json.dumps(failures))
    print(json.dumps({'case':case,'passed':True,'requests':len(records[key])}),flush=True)
  finally:browser(['close'],'close')
 sdk.require(not failures,'server failures: '+json.dumps(failures))
 sdk.require(json.loads((package/'sources-after.json').read_text())==source,'package source changed')
 for name,digest in static.items():sdk.require(sdk.snapshot(web/name).sha256==digest,'web input changed')
 sdk.require(sdk.snapshot(binary,maximum=256*1024*1024).sha256==state['native_binary_sha256'],'native witness changed')
 state['completed']=True
except BaseException as error:state['failure']=repr(error);raise
finally:sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
