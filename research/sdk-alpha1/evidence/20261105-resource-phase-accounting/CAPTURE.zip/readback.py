from pathlib import Path
from collections import Counter
import copy
import datetime
import hashlib
import json
import math
import subprocess
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.pycache_prefix
ROOT = Path.cwd()
BASE = ROOT / 'research/sdk-alpha1/evidence/20261104-installed-resource-baseline'
OUT = Path(__file__).resolve().parent
CAPTURE_SHA = '60fb59b6d6b55a7f964cdbdc6ac3e28b5f185033fffce6c0be8b17c5aa19832e'
SOURCE = '21e00e9c3cfd193b9f51491888347f583620dfe0'
PAIRS = {(1, 1): 'query/current', (2, 2): 'advance/advanced', (4, 5): 'admit-authority/authority-current'}
FIELDS = ('read_ns', 'handle_ns', 'write_ns')
WIDTH = 4 + 3674 + 4 + 3659

def require(condition, message):
    if not condition:
        raise ValueError(message)

def natural(value):
    return type(value) is int and 0 <= value < 2**128

def quantile(values, numerator, denominator):
    require(bool(values), 'empty timing population')
    return sorted(values)[(len(values) * numerator + denominator - 1) // denominator - 1]

def group(rows):
    kinds = {}
    for pair, name in PAIRS.items():
        selected = [row for row in rows if (row['request_tag'], row['reply_tag']) == pair]
        require(bool(selected), 'this baseline phase is missing a recorded operation kind')
        kinds[name] = {'exchanges': len(selected), 'framed_bytes': len(selected) * WIDTH,
            **{field: sum(row[field] for row in selected) for field in FIELDS},
            'observed_handle_p50_ns': quantile([r['handle_ns'] for r in selected], 1, 2),
            'observed_handle_p95_ns': quantile([r['handle_ns'] for r in selected], 95, 100)}
    return {'exchanges': len(rows), 'framed_bytes': len(rows) * WIDTH,
        **{field: sum(row[field] for row in rows) for field in FIELDS}, 'kinds': kinds}

def analyze(record):
    require(record['completed'] is True and record['profile'] == 'witness', 'baseline scope differs')
    witness = record['witness']
    prefix = record['witness_at_capacity']
    require(set(witness) == {'closed', 'framed_bytes', 'rows', *FIELDS} and witness['closed'] is True,
            'complete witness census missing')
    require(set(prefix) == {'requests', 'framed_bytes', *FIELDS}, 'capacity barrier schema differs')
    rows = witness['rows']
    require(type(rows) is list and 0 < len(rows) <= 16384, 'row capacity differs')
    require(natural(prefix['requests']) and 0 < prefix['requests'] < len(rows), 'capacity barrier index differs')
    for row in rows:
        require(type(row) is dict and set(row) == {'request_tag', 'reply_tag', *FIELDS}, 'row schema differs')
        require(type(row['request_tag']) is int and type(row['reply_tag']) is int,
                'tag integer type differs')
        require((row['request_tag'], row['reply_tag']) in PAIRS, 'unexpected pair in successful baseline')
        require(all(natural(row[field]) for field in FIELDS), 'timing counter differs')
    boundary = prefix['requests']
    for observed, selected in [(witness, rows), (prefix, rows[:boundary])]:
        require(natural(observed['framed_bytes']) and observed['framed_bytes'] == len(selected) * WIDTH,
                'framed byte census differs')
        for field in FIELDS:
            require(natural(observed[field]) and observed[field] == sum(row[field] for row in selected),
                    'timing sum differs at full or capacity barrier')
    phases = {'through_first_capacity_refusal': group(rows[:boundary]),
              'reopen_repeated_refusal_replay_delivery_and_close': group(rows[boundary:])}
    total = group(rows)
    for field in ('exchanges', 'framed_bytes', *FIELDS):
        require(sum(value[field] for value in phases.values()) == total[field], 'phase conservation differs')
    total['readonly_exchanges'] = total['kinds']['query/current']['exchanges'] + total['kinds']['admit-authority/authority-current']['exchanges']
    return {'phases': phases, 'total': total,
        'phase_boundary': 'Mutex-protected snapshot after first Capacity closes sender, before server Reopen and both original-owner reopens.',
        'limits': 'Observed service-handler intervals and framed Witness bytes; no ordinary-send cost, throughput, CPU allocation, TCP/TLS overhead, stationary tail guarantee or current-source performance qualification.'}

archive_bytes = (BASE / 'CAPTURE.zip').read_bytes()
require(hashlib.sha256(archive_bytes).hexdigest() == CAPTURE_SHA, 'original capsule digest differs')
manifest = json.loads((BASE / 'SHA256.json').read_text())
inputs = {}
results = {}
controls = []
with zipfile.ZipFile(BASE / 'CAPTURE.zip') as archive:
    require(archive.testzip() is None, 'original capsule CRC failed')
    selected = ['witness-01/RESULT.json', 'witness-02/RESULT.json',
        'qualified-observer/tests/journal_capacity.rs', 'qualified-observer/tests/observer_io.rs',
        'build-03/OBSERVER_BUILD.json']
    for name in selected:
        data = archive.read(name)
        expected = manifest[name]
        require(hashlib.sha256(data).hexdigest() == expected['sha256'] and len(data) == expected['bytes'],
                'original member differs')
        destination = OUT / 'inputs' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(data)
        inputs[name] = expected
    for name in ('witness-01', 'witness-02'):
        original = json.loads(archive.read(name + '/RESULT.json'))
        results[name] = analyze(original)
        mutations = [
            ('wrong_prefix_index', lambda r: r['witness_at_capacity'].__setitem__('requests', r['witness_at_capacity']['requests'] - 1)),
            ('wrong_prefix_bytes', lambda r: r['witness_at_capacity'].__setitem__('framed_bytes', r['witness_at_capacity']['framed_bytes'] + 1)),
            ('wrong_total_bytes', lambda r: r['witness'].__setitem__('framed_bytes', r['witness']['framed_bytes'] - 1)),
            ('wrong_prefix_sum', lambda r: r['witness_at_capacity'].__setitem__('handle_ns', r['witness_at_capacity']['handle_ns'] + 1)),
            ('wrong_full_sum', lambda r: r['witness'].__setitem__('read_ns', r['witness']['read_ns'] + 1)),
            ('missing_row', lambda r: r['witness']['rows'].pop()),
            ('wrong_reply', lambda r: r['witness']['rows'][0].__setitem__('reply_tag', 2)),
            ('boolean_tag', lambda r: r['witness']['rows'][0].__setitem__('request_tag', True)),
            ('negative_time', lambda r: r['witness']['rows'][0].__setitem__('write_ns', -1)),
            ('unknown_field', lambda r: r['witness']['rows'][0].__setitem__('unrecorded', 1)),
            ('unclosed_worker', lambda r: r['witness'].__setitem__('closed', False)),
        ]
        for label, mutate in mutations:
            altered = copy.deepcopy(original)
            mutate(altered)
            try:
                analyze(altered)
            except ValueError:
                controls.append({'case': name, 'mutation': label, 'rejected': True})
            else:
                raise AssertionError('altered observation accepted: ' + label)

source_inputs = {}
for name in ('research/continuity-identity-candidate/src/anchor.rs',
             'research/continuity-identity-candidate/src/anchor/store/commands.rs',
             'research/continuity-identity-candidate/src/crypto.rs'):
    data = subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=ROOT)
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
    source_inputs[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
        'identical_at_current_readback': data == (ROOT / name).read_bytes()}

result = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': SOURCE, 'original_capsule_sha256': CAPTURE_SHA,
    'original_observer_source_commit': '539845d573ac0af5fe104aabed2f96a86f9eac8b',
    'original_observer_binary_sha256': '73271b3a8fca2bcad2119b1dd248a61cecfcfd9c6cc457b1d211b0ffac1972c2',
    'input_members': inputs, 'source_inputs': source_inputs,
    'framed_exchange_bytes': WIDTH, 'tag_byte_offset': 4 + 8 + 32 + 96 + 32 + 32,
    'cases': results, 'negative_controls': controls, 'workloads_rerun': False,
    'scope': 'Further accounting of two historical installed-engine observations; no current artifact promotion, frozen budget, device/energy result, new cryptographic wire verification or altered native gate.'}
require(result['tag_byte_offset'] == 204, 'tag offset arithmetic differs')
with (OUT / 'READBACK.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'cases': {k: {'prefix_exchanges': v['phases']['through_first_capacity_refusal']['exchanges'],
    'suffix_exchanges': v['phases']['reopen_repeated_refusal_replay_delivery_and_close']['exchanges'],
    'total': v['total']['exchanges'], 'readonly': v['total']['readonly_exchanges']} for k, v in results.items()},
    'negative_controls_rejected': len(controls)}))
