from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-hkdf-expand-table'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-hkdf-expand-table'
COMMIT = 'cc38ea0718400bc78b79a03e0ccc3c3a8fa725f6'
DEP = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hkdf-0.13.0')
VENDOR = ROOT / 'target/continuity-root-qrom/portable-encoding/vendor/hkdf-0.13.0'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
files = {}
sources = {}
prefix = 'research/continuity-identity-candidate/'
for relative in ['Cargo.toml', 'Cargo.lock', 'src/durable/messages.rs',
                 'src/durable/messages/rekey/response.rs', 'src/durable/messages/rekey/completion.rs']:
    name = prefix + relative; body = (ROOT / name).read_bytes()
    assert body == subprocess.check_output(['git', 'show', COMMIT + ':' + name], cwd=ROOT)
    files['source/' + name] = body; sources[name] = sha(body)
for relative in ['Cargo.toml', 'src/lib.rs', 'src/hmac_impl.rs', 'src/errors.rs', 'LICENSE-APACHE', 'LICENSE-MIT']:
    body = (DEP / relative).read_bytes()
    assert body == (VENDOR / relative).read_bytes(), relative
    files['dependency/hkdf-0.13.0/' + relative] = body
dependency = (DEP / 'src/lib.rs').read_text()
loop = dependency.split('pub fn expand_multi_info(', 1)[1].split('pub fn expand(', 1)[0]
tokens = ['if okm.len() > chunk_len * 255', 'return Err(InvalidLength)',
          'okm.chunks_mut(chunk_len).enumerate()', 'let mut hmac = self.hmac.clone()',
          'if let Some(ref prev) = prev', 'hmac.update(prev)', 'for info in info_components',
          'hmac.update(info)', 'hmac.update(&[u8::try_from(block_n).expect("should convert") + 1])',
          'let output = hmac.finalize()', 'block.copy_from_slice(&output[..block_len])', 'prev = Some(output)']
positions = []; offset = 0
for token in tokens:
    at = loop.index(token, offset); positions.append({'token': token, 'offset': at}); offset = at + len(token)
assert 'self.expand_multi_info(&[info], okm)' in dependency
messages = (ROOT / prefix / 'src/durable/messages.rs').read_text()
response = (ROOT / prefix / 'src/durable/messages/rekey/response.rs').read_text()
completion = (ROOT / prefix / 'src/durable/messages/rekey/completion.rs').read_text()
assert [t.count('Hkdf::<Sha256>::new(') for t in [messages, response, completion]] == [2, 2, 2]
sections = {
    'message-chain': (messages.split('fn step(', 1)[1].split('fn associated(', 1)[0], 64, 'label(b"chain")'),
    'initial-state': (messages.split('impl State {', 1)[1].split('fn encode', 1)[0], 160, 'label(b"initial/HKDF-SHA256/ChaCha20Poly1305")'),
    'pending-root': (response.split('fn derive_root(', 1)[1].split('fn confirmation(', 1)[0], 32, 'b"pending-root/HKDF-SHA256/"'),
    'response-confirmation': (response.split('fn confirmation(', 1)[1].split('pub(super) fn check_body(', 1)[0], 32, 'b"responder-confirmation"'),
    'final-receipt-confirmation': (completion.split('fn control_mac(', 1)[1].split('fn make_body(', 1)[0], 32, 'b"-confirmation"'),
    'epoch-traffic': (completion.split('fn add_epoch(', 1)[1].split('fn close_send(', 1)[0], 128, 'b"epoch-traffic/HKDF-SHA256/ChaCha20Poly1305/"')}
call_sites = {}
for name, (text, width, label) in sections.items():
    assert text.count('Hkdf::<Sha256>::new(') == text.count('.expand(') == 1
    assert label in text
    if name == 'pending-root': assert 'Result<ZeroizingBytes<32>, Error>' in text
    else: assert f'ZeroizingBytes::<{width}>::zeroed()' in text
    call_sites[name] = {'output_bytes': width, 'blocks': width // 32, 'label_anchor': label}
audit = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed': True, 'source_commit': COMMIT,
    'source_files': sources, 'hkdf_version': '0.13.0', 'dependency_lib_sha256': sha((DEP / 'src/lib.rs').read_bytes()),
    'dependency_matches_prior_vendor': True, 'dependency_loop_order': positions,
    'call_sites': call_sites, 'source_hkdf_calls': 6,
    'scope': 'Pinned source/dependency byte and literal-order checks for the manual ideal-row interface identity; no new primitive run, empirical probability estimate or machine-checked cryptographic proof.',
    'mathematical_result': 'Perfect equality of the stated classical Expand-only interface and a full-info-indexed prefix-consistent random block table, after the row is already idealized.',
    'invalid_extensions': ['Independent table per requested output length', 'Untreated separate raw-row access', 'Independent rows for identical actual PRKs'],
    'underlying_hmac_idealization_established_here': False, 'multi_root_composition_established': False,
    'product_sources_changed': False, 'release_claim_eligible': False,
    'primary_reference': 'https://www.rfc-editor.org/rfc/rfc5869.html#section-2.3'}
files['driver/seal.py'] = Path(__file__).read_bytes()
files['documents/HKDF_EXPAND_TABLE_V1.md'] = (ROOT / 'docs/continuity/HKDF_EXPAND_TABLE_V1.md').read_bytes()
files['SOURCE_AUDIT.json'] = encode(audit)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('SOURCE_AUDIT.json', files['SOURCE_AUDIT.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
