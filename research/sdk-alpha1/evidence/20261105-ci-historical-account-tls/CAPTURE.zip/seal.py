from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-historical-queue-closeout'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-historical-account-tls'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
obj = lambda p: json.loads(p.read_bytes())
archive_path = BASE / 'artifact-13401893480.zip'
archive_bytes = archive_path.read_bytes()
assert len(archive_bytes) == 32122337
assert sha(archive_bytes) == '14c44eec973c539125f1ff75c4f872a2a000073071ce6a0156180953fc51d4ff'
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 7675
    assert z.testzip() is None
    assert not any(n.startswith('c-account-tls-public/') for n in z.namelist())
    assert not any(n.endswith('account-tls-phases') for n in z.namelist())
    for p in (BASE / 'selected-artifact').iterdir():
        assert p.is_file() and p.read_bytes() == z.read(p.name)
    package = json.loads(z.read('CONTINUITY_PACKAGE.json'))
    native = json.loads(z.read('C_CONSUMER.json'))
    assert package['source_commit'] == '7e3a89faf2c79cd9111128b06e41d3ef503f063c'
    assert not package['partition_completed'] and not native['partition_completed']
    assert package['failure'] == native['failure'] == 'TLS account admitted exchange workload differs'
    assert 'android_jni_consumer' not in package and 'c_consumer' not in package
    receipt = json.loads(z.read('c-account-tls-trace-release.json'))
    assert receipt['returncode'] == 0
    assert z.read('c-account-tls-trace-release.stderr') == b''
    assert '1 passed; 0 failed; 0 ignored; 0 measured; 8 filtered out; finished in 9.58s' in z.read('c-account-tls-trace-release.stdout').decode()
for name in ['artifact/continuity_c_account_tls.py', 'artifact/continuity_c_account_witness.py']:
    assert (BASE / 'old-source' / name).read_bytes() == (BASE / 'merge-source' / name).read_bytes()
checker = (BASE / 'old-source/artifact/continuity_c_account_tls.py').read_text()
assert 'bootstrap={"C": 121, "Swift": 127, "Kotlin": 126}[language]' in checker
exporter = (BASE / 'old-source/artifact/continuity_c_account_witness.py').read_text()
assert exporter.index('checked = verify(stdout, selected, language=language)') < exporter.index('public = witness.export_selected(checked, selected')
push = obj(BASE / 'jobs-41724505316.json')
pr = obj(BASE / 'jobs-41724563802-0941.json')
assert len(push['jobs']) == push['total_count'] == 70
assert all(j['status'] == 'completed' for j in push['jobs'])
assert len(pr['jobs']) == pr['total_count'] == 70
pending = [j for j in pr['jobs'] if j['status'] != 'completed']
assert [(j['id'], j['status']) for j in pending] == [(126266162501, 'in_progress')]
for status in ['queued', 'waiting', 'pending', 'requested']:
    name = 'queued-runs-0941.json' if status == 'queued' else status + '-runs.json'
    data = obj(BASE / name)
    assert data['total_count'] == 0 and data['workflow_runs'] == []
coverage = (BASE / 'job-127156928118.log').read_text()
assert 'Total of 6 artifact(s) downloaded' in coverage
assert 'ValueError: partition is unfinished or makes a complete-package claim' in coverage
swift = (BASE / 'job-126266162426.log').read_text()
assert 'ea0a9c08d00356266c8ec23c6848b3bd0097f15b' in swift
assert 'ValueError: TLS account admitted exchange workload differs' in swift
assert 'Artifact ID 13403870843' in swift
pin = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
workflow_files = sorted((BASE / 'wave-source/.github/workflows').glob('*.yml'))
assert len(workflow_files) == 16
for p in workflow_files:
    name = p.relative_to(BASE / 'wave-source').as_posix()
    assert p.read_bytes() == subprocess.check_output(['git', 'show', pin + ':' + name])
focused = ['.github/workflows/continuity-android-installed.yml', '.github/continuity-android-installed.json']
assert subprocess.check_output(['git', 'diff', '--name-only', '6084f3bfb09333f6b66291b38809ed512296a27b', pin, '--', *focused]) == b''
assert subprocess.check_output(['git', 'diff', '--name-only', '475cd23923e45819b01b6041c91c44540ec056ec', '232ace17915407596d66f3a5fd7c7765251a38cc', '--', '.github']) == b''
for candidate in ['232ace17915407596d66f3a5fd7c7765251a38cc', pin]:
    subprocess.run(['git', 'merge-base', '--is-ancestor', '69ed5b42e59a648a834ed83e132e30a1ca3b7e31', candidate], check=True)
ci = (BASE / 'wave-source/.github/workflows/ci.yml').read_text()
assert 'artifact/rust_sdk_publication.py dry-run' in ci
release = (BASE / 'wave-source/.github/workflows/abi2-platform-candidate.yml').read_text()
assert 'on:\n  push:\n    tags:\n' in release
audit = {
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'source_scope': 'Older same-branch queue occupants, separate from the twelve terminal current-head runs.',
    'push_run': 41724505316, 'push_head': '7e3a89faf2c79cd9111128b06e41d3ef503f063c',
    'pull_request_run': 41724563802, 'pull_request_checkout': 'ea0a9c08d00356266c8ec23c6848b3bd0097f15b',
    'newly_read_failure_jobs': [126268252580, 126266162426, 127156928118],
    'foreign_named_failures_stop_at_c_account_tls': True,
    'c_account_tls_census_expected_by_old_checker': {'C': 121, 'Swift': 127, 'Kotlin': 126},
    'hosted_actual_phase_counts_available': False,
    'missing_public_phase_reason': 'Pinned exporter invokes full verification before exporting selected public files; verification raised.',
    'android_named_artifact': {'id': 13401893480, 'downloaded': True, 'bytes': len(archive_bytes),
        'sha256': sha(archive_bytes), 'members': 7675, 'all_member_crc_checks_passed': True,
        'full_container_retained_locally': str(archive_path.relative_to(ROOT)),
        'full_container_in_capsule': False, 'selected_members_in_capsule': True},
    'swift_named_artifact': {'id': 13403870843, 'downloaded': False, 'upload_reported_bytes': 32124394,
        'upload_reported_sha256': '3b9fb64257fa91c842d13ab1c3c26d74b41b24cbbdac190c244ecb43c87159b0'},
    'native_test_in_downloaded_artifact': {'returncode': 0, 'passed': 1, 'filtered': 8, 'runtime_seconds': 9.58},
    'coverage_downloaded_partitions': 6, 'coverage_completed': False,
    'remaining_active_jobs_in_latest_snapshot': [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'started_at': j['started_at']} for j in pending],
    'ready_to_push': False, 'remote_mutation_performed': False,
    'workflow_audit': {'source_commit': pin, 'files': 16,
        'focused_android_trigger_paths_unchanged_in_both_updates': True,
        'ci_registry_publication_operation': 'dry-run', 'abi_platform_candidate_trigger': 'explicit named tags only',
        'scope': 'Source and trigger review for the prepared two branch refspecs; no tag, release or package publication authorization.'},
    'release_claim_eligible': False,
}
files = {}
for p in sorted(BASE.rglob('*')):
    if p.is_file() and p != archive_path:
        files[p.relative_to(BASE).as_posix()] = p.read_bytes()
files['prior/NEXT_WAVE_PREPARATION.json'] = (ROOT / 'target/continuity-wave-readiness/NEXT_WAVE_PREPARATION.json').read_bytes()
files['SOURCE_AUDIT.json'] = encode(audit)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('SOURCE_AUDIT.json', files['SOURCE_AUDIT.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream:
        stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
