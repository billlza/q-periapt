import json, os, subprocess, time
from pathlib import Path
out=Path(__file__).resolve().parent
repo=out.parent.parent
runtime=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env=os.environ.copy()
env.update(PATH=str(runtime/'bin')+':'+env['PATH'], RUSTC=str(runtime/'bin/rustc'), DYLD_LIBRARY_PATH=str(runtime/'lib'), CARGO_TARGET_DIR=str(repo/'target/continuity-reference-app'), RUSTFLAGS='-D warnings')
manifest=['--manifest-path','research/continuity-reference-app/Cargo.toml']
steps=[('fmt',['cargo','fmt',*manifest]),('node-tests',['node','--test','--test-reporter=tap',*[str(p.relative_to(repo)) for p in sorted((repo/'research/continuity-reference-app/tests/web').glob('*.test.mjs'))]]),('actionlint',['/opt/homebrew/bin/actionlint','.github/workflows/reference-account.yml']),('rust-tests-01',['cargo','test','--offline','--locked',*manifest]),('clippy-01',['cargo','clippy','--offline','--locked','--all-targets',*manifest,'--','-D','warnings']),('release-tests-01',['cargo','test','--offline','--locked','--release',*manifest]),('build-01',['cargo','build','--offline','--locked','--release',*manifest]),('fmt-check',['cargo','fmt',*manifest,'--','--check']),('diff-check',['git','diff','--check'])]
results=[]
for name,args in steps:
    start=time.monotonic()
    with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
        result=subprocess.run(args,cwd=repo,env=env,stdout=stdout,stderr=stderr,timeout=900)
    row=dict(step=name,command=args,exit_code=result.returncode,seconds=round(time.monotonic()-start,2))
    results.append(row)
    (out/'CHECK_COMMANDS.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
