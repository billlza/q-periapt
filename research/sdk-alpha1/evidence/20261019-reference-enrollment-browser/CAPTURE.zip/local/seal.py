from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
out=Path(__file__).resolve().parent;repo=out.parent.parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('83bb4b29') and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
commands=json.loads((out/'CURRENT_CHECK_COMMANDS.json').read_text());assert len(commands)==11 and all(x['exit_code']==0 for x in commands)
assert '# pass 16\n' in (out/'current-node-tests.stdout').read_text() and '# fail 0\n' in (out/'current-node-tests.stdout').read_text()
assert '# fail 2\n' in (out/'reapproval-red.stdout').read_text()
for n in ['current-rust-tests','current-clippy','current-build']:
 t=(out/(n+'.stderr')).read_text();assert 'Finished ' in t and not re.search(r'^(warning|error)(?:\[|:)',t,re.M)
for count in [20,6]:assert f'{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (out/'current-rust-tests.stdout').read_text()
startup=json.loads((out/'BROWSER_STARTUP.json').read_text());binary=repo/'target/continuity-reference-app/release/q-periapt-continuity-reference-app'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==startup['binary_sha256']
sources=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','research/continuity-reference-app','.github/workflows/reference-account.yml'],cwd=repo,text=True).splitlines();assert len(sources)==37
entries={}
for name in sources:
 data=subprocess.check_output(['git','show',head+':'+name],cwd=repo);assert data==(repo/name).read_bytes();entries['source/'+name]=data
rust='\n'.join(data.decode() for name,data in entries.items() if name.endswith('.rs'))
names=set(re.findall(r'#\[(?:tokio::)?test\]\s*(?:async )?fn (\w+)',rust));assert len(names)==26
assert names==set(re.findall(r'^test [\w:]+::(\w+) \.\.\. ok$',(out/'current-rust-tests.stdout').read_text(),re.M))
js='\n'.join(data.decode() for name,data in entries.items() if name.endswith('.test.mjs'))
names=set(re.findall(r"test\('([^']+)'",js));assert len(names)==16
assert names==set(re.findall(r'^ok \d+ - (.+)$',(out/'current-node-tests.stdout').read_text(),re.M))
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in {'.stdout','.stderr','.json','.py'}:entries['local/'+p.name]=p.read_bytes()
for p in sorted((out/'reapproval-red').iterdir()):
 assert p.is_file() and p.suffix=='.mjs';entries['local/reapproval-red/'+p.name]=p.read_bytes()
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'research/sdk-alpha1/evidence/20261019-reference-enrollment-browser';dest.mkdir()
a=dest/'CAPTURE.zip'
with zipfile.ZipFile(a,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for n,r in manifest.items():
  b=z.read(n);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
copy=out/'release-strict-final';assert not copy.exists();shutil.copy2(binary,copy)
checks={'head':head,'source_files':len(sources),'capture':{'bytes':a.stat().st_size,'members':len(entries),'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'current_validation':{'node_model_transport_tests':16,'node_test_substitutes':'Explicit HTTP/storage substitutes; not browser or SDK device admission','rust_debug_entries':26,'behavioral_rust_entries':25,'child_dispatcher_entries':1,'strict_clippy':'passed','strict_release_build':'passed','js_syntax_fmt_diff':'passed','workflow_lint':'actionlint-02 passed unchanged final workflow'},'earlier_release_suite':'26 Rust entries passed before final browser-only corrections; final host CI will run both profiles on its immutable head. Do not label that earlier suite as final browser behavior evidence.','browser_startup':startup,'red_green':'Two original model regressions failed: an unresolved stale reapproval blocked a distinct authorized decision for the same source; a separately selected reapproval proof was ignored. Both now pass while old attempt/request bytes remain retained. Native host independently rejects changed proof for an Approved source. New initial-device invitations still cannot replace an unresolved initial invitation.','scope':'Browser controls implemented for optional host. Exact u64, account/origin-bound records, proof pinned before submission, explicit source/successor selection, failed attempts retained, historical issuance separate from current observation. No new SDK/account dependency, user DB upgrade, full real-browser login/grant, installed independent-client live-policy admission, power-loss or release claim.'}
(dest/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'README.md').write_text(f'''# Browser enrollment control and recovery checks

Source `{head}` adds optional browser controls using the existing authenticated
HTTP transactions. Original correlations are saved before requests. Submitted
proofs remain immutable; a new explicit reapproval retains its own correlation
and selected predecessor. Failed attempts stay in the record. The host still
atomically admits one source successor and rejects a changed approved device key.

All 16 Node model/transport regressions passed, using explicitly substituted HTTP
and storage. Two added recovery regressions first failed and now pass without
overwriting the original attempt/proof. Current Rust debug tests passed 26 entries
(25 behavioral tests and one dispatcher), including actual HTTP and exact static
module delivery. Strict all-target Clippy, final release build, JavaScript syntax,
format/diff checks and workflow lint passed. Earlier release tests also passed,
before the final browser-only corrections; they are recorded with that boundary.

The final release executable reopened the original empty preview database. Actual
Chrome initialization showed the optional example, initialized module content,
hidden anonymous enrollment controls and no captured console error/warning entries.
This was read-only: no account, credential or device was created. Browser translation
was observed, so completion tracking uses internal state instead of displayed text.

The capture preserves exact source, positive/negative regressions and local driver
diagnostics. A local check driver stopped on an existing output filename, and a
later label replacement selected a nonexistent lint executable; neither was a
passed check. They were corrected with explicit command lists and preserved outputs.
Private databases, cookies, private keys and executable bytes are excluded. The
real user's account database and localhost8087 service were untouched.

Complete real-browser authorization with an installed independent consumer and
live signed policy/trust remains open. Browser local storage is not a rollback
witness or power-loss durability guarantee. This is component progress, not full
0.2.0 lifecycle or release admission.
''')
print(json.dumps(checks['capture']))
