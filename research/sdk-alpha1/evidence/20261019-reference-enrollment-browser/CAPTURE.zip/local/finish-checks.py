import hashlib,json,os,subprocess,time
from pathlib import Path
out=Path(__file__).resolve().parent;repo=out.parent.parent
runtime=Path('/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin')
env=os.environ.copy();env.update(PATH=str(runtime/'bin')+':'+env['PATH'],RUSTC=str(runtime/'bin/rustc'),DYLD_LIBRARY_PATH=str(runtime/'lib'),CARGO_TARGET_DIR=str(repo/'target/continuity-reference-app'),RUSTFLAGS='-D warnings')
results=[]
steps=[(f'syntax-{p.stem}',['node','--check',str(p.relative_to(repo))],None) for p in sorted((repo/'research/continuity-reference-app/web').glob('*.mjs'))]
steps += [('syntax-app',['node','--input-type=module','--check'],(repo/'research/continuity-reference-app/web/app.js').read_bytes()),('build-final',['cargo','build','--offline','--locked','--release','--manifest-path','research/continuity-reference-app/Cargo.toml'],None),('diff-final',['git','diff','--check'],None)]
for name,command,input_bytes in steps:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
  done=subprocess.run(command,cwd=repo,env=env,input=input_bytes,stdout=stdout,stderr=stderr,timeout=900)
 row={'step':name,'command':command,'exit_code':done.returncode,'seconds':round(time.monotonic()-start,2)}
 if input_bytes is not None: row['stdin_sha256']=hashlib.sha256(input_bytes).hexdigest()
 results.append(row);(out/'FINISH_CHECK_COMMANDS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if done.returncode: raise SystemExit(done.returncode)
