from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ci-readback-23'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-ci-foreign-policy-readback'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode()
status = json.loads((BASE / 'CI_STATUS.json').read_bytes())
jobs = {j['id']: (r['run_id'], j) for r in status['results'] for j in r['jobs']}
assert len(jobs) == 334
observed = {}
for run_id, job in jobs.values():
    key = job['conclusion'] or job['status']; observed[key] = observed.get(key, 0) + 1
assert observed == status['counts'] == {'success': 297, 'failure': 27, 'skipped': 2, 'queued': 3, 'in_progress': 5}
expected = {
    126456505946: ('failure', '9aa535b48b464ec4d4a8b5a4b20221049a6067b9'),
    126456505984: ('failure', '9aa535b48b464ec4d4a8b5a4b20221049a6067b9'),
    126449257926: ('failure', '475cd23923e45819b01b6041c91c44540ec056ec'),
    126449257992: ('failure', '475cd23923e45819b01b6041c91c44540ec056ec'),
    126449258002: ('success', '475cd23923e45819b01b6041c91c44540ec056ec')}
classifications = {}
for job_id, (conclusion, commit) in expected.items():
    run_id, job = jobs[job_id]
    assert job['conclusion'] == conclusion and job['status'] == 'completed'
    text = (BASE / f'job-{job_id}.log').read_text()
    assert re.search(r'git log -1 --format=%H\n\S+Z ' + commit + r'\s*\n', text)
    matches = re.findall(r'Artifact (.+?) has been successfully uploaded! Final size is ([0-9]+) bytes\. Artifact ID is ([0-9]+)', text)
    digests = re.findall(r'SHA256 digest of uploaded artifact is ([0-9a-f]{64})', text)
    assert len(matches) == len(digests) == 1
    name, size, artifact_id = matches[0]
    row = {'run_id': run_id, 'job_id': job_id, 'name': job['name'], 'conclusion': conclusion,
           'actual_checkout': commit, 'full_log_sha256': sha(text.encode()),
           'reported_artifact': {'name': name, 'bytes': int(size), 'id': int(artifact_id), 'sha256': digests[0]},
           'artifact_downloaded_locally': False}
    if conclusion == 'failure':
        assert 'report["witness_exchanges"] == 142' in text
        assert 'ValueError: OpenSSL server exchange census differs' in text
        assert 'result["c_consumer"] = qualify_c(' in text
        row.update(classification='P0 old exact 142 C/OpenSSL prerequisite',
                   hosted_numeric_server_count_disclosed=False, foreign_consumer_execution_established=False,
                   android_device_or_emulator_failure=False)
    else:
        clean = re.sub(r'^\S+Z ?', '', text, flags=re.M)
        marker = clean.index('"kind": "qperiapt.policy_maintenance_package"')
        begin = clean.rfind('{', 0, marker)
        report, end = json.JSONDecoder().raw_decode(clean[begin:])
        assert report['completed'] and report['sources_unchanged']
        assert report['source_commit'] == report['builder_commit'] == commit
        assert report['target'] == 'aarch64-apple-darwin'
        assert not report['runtime']['minimum_os_execution_qualified']
        assert not report['publication_performed'] and not report['release_claim_eligible']
        row.update(classification='Installed Apple-Silicon policy-maintenance package passed at the original hosted source',
                   logged_package_report=report, minimum_os_execution_qualified=False)
    classifications[str(job_id)] = row
classification = {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'snapshot_observed_at': status['observed_at'], 'wave_counts': status['counts'],
    'jobs': classifications, 'observed_p0_failure_count': 21,
    'prior_p0_failure_count': 17,
    'prior_capture': '20261105-ci-debug-capacity-readback',
    'effective_wave_open': True, 'push_performed': False, 'rerun_performed': False,
    'workflow_cancelled': False, 'release_claim_eligible': False}
files = {'capture/' + p.name: p.read_bytes() for p in BASE.iterdir() if p.is_file()}
files['CLASSIFICATION.json'] = encode(classification)
files['FILES.json'] = encode({n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == body for name, body in files.items())
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload), 'all_members_read_back': True}
DEST.mkdir(exist_ok=False)
for name, body in [('CAPTURE.zip', payload), ('CLASSIFICATION.json', files['CLASSIFICATION.json']),
                   ('FILES.json', files['FILES.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(body)
print(json.dumps(summary, indent=2), flush=True)
