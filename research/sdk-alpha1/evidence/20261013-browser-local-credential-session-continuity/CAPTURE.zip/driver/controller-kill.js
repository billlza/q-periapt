globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', { type: 'module' });
  let stopped = false, started;
  const finish = (error, value) => { stopped = true; clearTimeout(timer); worker.terminate(); if (error) reject(error); else resolve({ ...value, cancellationRequested: false }); };
  const timer = setTimeout(() => finish(Error('worker deadline')), 45000);
  worker.onerror = event => finish(Error(event.message));
  worker.onmessage = async ({ data }) => {
    try {
      if (data.ready) {
        started = performance.now(); worker.postMessage(args);
        if (args.killOnAdvance) {
          while (!stopped) {
            const response = await fetch('/status/' + args.case, { credentials: 'omit', cache: 'no-store' });
            if (!response.ok) throw Error('witness status');
            const trigger = (await response.json()).find(row => row.trigger && row.mode === args.mode);
            if (trigger) {
              const expected = 'qperiapt-continuity-storage/2/' + args.name;
              const before = await navigator.locks.query();
              if (!before.held.some(lock => lock.name === expected && lock.mode === 'exclusive')) throw Error('original worker does not hold its storage lease');
              const elapsed = performance.now() - started;
              if (!(elapsed < 20000 && args.timeout === 30000)) throw Error('cannot prove kill before held reply or SDK deadline');
              worker.terminate();
              const deadline = performance.now() + 5000;
              while (true) {
                const locks = await navigator.locks.query();
                if (![...locks.held, ...locks.pending].some(lock => lock.name === expected)) break;
                if (performance.now() >= deadline) throw Error('terminated worker retained its native storage lease');
                await new Promise(resolve => setTimeout(resolve, 20));
              }
              finish(undefined, { done: true, value: { workerTerminated: true, sdkCloseRequested: false, heldBeforeKill: true, nativeLeaseReleased: true, elapsedBeforeKillMs: elapsed, command: trigger.command, witnessChanged: trigger.changed } });
              break;
            }
            await new Promise(resolve => setTimeout(resolve, 20));
          }
        }
      } else if (data.done) {
        if (data.value?.request) {
          const response = await fetch('/capture/' + args.case + '.bin', { method: 'POST', body: new Uint8Array(data.value.request) });
          if (!response.ok) throw Error('request capture'); delete data.value.request;
        }
        if (data.value?.phase === 'requires-witness-enrollment') {
          const response = await fetch('/capture/' + args.case + '-genesis.json', { method: 'POST', body: JSON.stringify(data.value) });
          if (!response.ok) throw Error('genesis capture');
        }
        finish(undefined, data);
      }
    } catch (error) { finish(error); }
  };
});
