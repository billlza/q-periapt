from pathlib import Path
import base64
import hashlib
import json
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = root / 'target/continuity-browser-local-credential-sessions'
package = root / 'target/continuity-browser-publication/source/target/peer-credential-package-01'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runs = ['run02', 'run03', 'run04', 'run05']
reports = {n: load(stage / n / 'RESULT.json') for n in runs}
assert all(r['completed'] for r in reports.values())
cases = {c['case']: c for r in reports.values() for c in r['cases']}
assert set(cases) == {'live', 'expired-local', 'expired-both', 'drop-commit', 'drop-ack', 'close-after-commit', 'cancel', 'kill-after-commit', 'kill-after-ack'}
assert sum(len(r['cases']) for r in reports.values()) == 9

def digest(domain, data):
    return hashlib.sha3_256(len(domain).to_bytes(8, 'big') + domain + len(data).to_bytes(8, 'big') + data).digest()

for name, c in cases.items():
    a = c['native_admission']
    assert all(a[k] for k in ['admitted', 'exact_retry', 'same_original_journal', 'reopened_original_session'])
    assert a['session'] == c['session'] and a['version'] == 2
    assert c['staged']['phase'] == c['prepared']['status']['phase'] == 2
    assert c['final']['phase'] == 4 and c['final']['target']['version'] == '2'
    assert c['final']['operation'] == a['operation'] and c['final']['target']['digest'] == a['digest']
    assert c['current']['journal'] == c['original']['journal']
    assert c['progress_before'] == c['progress_after']
    assert c['progress_before']['pending'] == '1' and c['progress_before']['confirmed'] == '0'
    assert c['rekey']['epoch'] == '1' and c['fresh_message'] != c['message']
    assert c['delivery'] == {'consumption': 1, 'status': 3}
    assert c['reverse_finished']['same_original_wire'] and c['reverse_finished']['authenticated_browser_consumption']
    assert c['received']['application']['effects'] == c['received']['application']['calls'] == 1
    assert not c['duplicate']['callbackInvoked']
    assert c['duplicate']['reply'] == c['received']['reply'] and c['duplicate']['application'] == c['received']['application']
    frames = c['peer_records']
    assert len([x for x in frames if x['kind'] == 1]) == len([x for x in frames if x['kind'] == 2]) == 1
    control = [x for x in frames if x['kind'] == 4]
    messages = [x for x in frames if x['kind'] == 3]
    assert control[0]['trigger'] and control[0]['request_sha256'] == control[1]['request_sha256']
    assert len(messages) == 3 and messages[0]['request_sha256'] == messages[1]['request_sha256'] != messages[2]['request_sha256']
    if name.startswith('expired-'):
        e = c['real_expiry']
        assert e['pending_at'] < e['browser_until'] < e['renew_at']
        assert c['expired_before_grant']['code'] == c['expired_fresh_bootstrap']['code'] == 'Validity'
        assert c['current']['prekeyStatus'] == 2 and c['current']['newPrekey']
        if name == 'expired-local':
            assert e['peer_until'] > e['renew_at']
        else:
            assert e['peer_until'] < e['renew_at']
            assert all(c['native_renewal'][k] for k in ['previous_expired', 'committed', 'activated', 'same_original_journal'])
            assert c['peer_admission']['version'] == '2'
    else:
        assert c['current']['prekey'] == c['original']['prekey']
    faults = [x for x in c['witness_records'] if x['trigger']]
    if 'after_loss' in c or 'after_kill' in c:
        observed = c.get('after_loss', c.get('after_kill'))
        ack = name in ['drop-ack', 'kill-after-ack']
        assert observed['proposal'] == c['prepared']['proposal'] and observed['status']['phase'] == (4 if ack else 2)
        proposal = bytes(c['prepared']['proposal'])
        binding = digest(b'Q-PERIAPT-ANCHOR-CREDENTIAL-PROPOSAL/v1', proposal)
        assert binding == bytes(c['prepared']['binding'])
        command = digest(b'Q-PERIAPT-CONTINUITY-ANCHOR-COMMAND/v1', proposal[8:136] + bytes([8 if ack else 5]) + binding + bytes(64))
        assert len(faults) == 1 and bytes(faults[0]['command']) == command and faults[0]['changed'] == (not ack)
        if 'after_loss' in c:
            assert c['renewal_loss']['code'] == ('Cancelled' if name == 'cancel' else 'WitnessTransport')
            assert c['renewal_loss']['ownerClosed']
            assert c['renewal_loss']['cancellationRequested'] == (name == 'cancel')
        else:
            killed = c['worker_kill']
            assert all(killed[k] for k in ['workerTerminated', 'heldBeforeKill', 'nativeLeaseReleased'])
            assert not killed['sdkCloseRequested'] and 0 < killed['elapsedBeforeKillMs'] < 20000
            assert killed['command'] == faults[0]['command'] and killed['witnessChanged'] == (not ack)
    else:
        assert not faults

engine = load(stage / 'ENGINE.json')
assert not engine['product_code_changed']
receipt = load(package / 'INSTALLED_CONSUMER.json')
assert receipt['source_bound'] and receipt['sources_unchanged']
assert receipt['sha256'] == sha(package / 'q-periapt-sdk-wasm-0.2.0.tgz')
installed = Path(load(package / 'consumer-location.json')['path'])
for run, r in reports.items():
    for name, value in r['source']['inputs'].items():
        assert sha(root / name) == value, name
    for name, value in r['native'].items():
        assert sha(Path(name)) == value, name
    for name, value in r['static_web'].items():
        assert sha(stage / (run + '-web') / name) == value, name
        if not name.startswith('creation/'):
            assert sha(installed / name) == value, name
assert 'error[E0369]' in (stage / 'native-build.log').read_text()
assert 'Finished' in (stage / 'native-build-02.log').read_text()
assert not (stage / 'run01/RESULT.json').exists()
assert 'q-periapt-browser-local-credential-peer' in (stage / 'run01.log').read_text()

diagnostics = stage / 'android-ci-diagnostics/c199104eb3b6bae1fce047d4ba407840/proof'
instrumentation = (diagnostics / 'adb-instrumentation.txt').read_text()
encoded_result = next(x.split('=', 1)[1] for x in instrumentation.splitlines() if x.startswith('INSTRUMENTATION_RESULT: qperiapt_result_json_base64='))
android_result = json.loads(base64.b64decode(encoded_result, validate=True))
assert android_result['status'] == 'pass' and android_result['passed_tests'] == ['runtimeVersionOnly']
assert 'INSTRUMENTATION_CODE: -1' in instrumentation
mismatches = [load(diagnostics / ('adb-package-cleanup-1-attempt-' + str(n) + '.err')) for n in [1, 3]]
assert [m['observed_bytes'] for m in mismatches] == [2780672, 0]
assert all(m['failure'] == 'bytes-mismatch' and m['expected_bytes'] == 13702871 for m in mismatches)
assert "device 'emulator-5584' not found" in (diagnostics / 'emulator-state-failure.txt').read_text()
assert 'ANDROID_AGP_RUNTIME_PASS profile=agp_sdk_full_release' in (stage / 'android-runtime-16k.log').read_text()

members, raw = {}, {}
def add(p, name):
    assert p.is_file() and not p.is_symlink() and name not in members
    assert not any(x.endswith('-private') or x.startswith('private-') for x in p.parts)
    members[name] = p

for p in sorted(stage.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.js', '.json', '.log', '.txt'] and p.name not in ['seal.log', 'finalize.log', 'HANDOFF.json']:
        add(p, 'driver/' + p.name)
for name in ['Cargo.toml', 'Cargo.lock', 'src/main.rs']:
    add(stage / 'native-peer' / name, 'native-peer/' + name)
add(root / 'target/continuity-browser-witness/source/research/continuity-identity-candidate/examples/browser_activation_authority.rs', 'authority/witness.rs')
add(root / 'target/continuity-browser-credential-commit/authority/src/main.rs', 'authority/credential.rs')
for run, r in reports.items():
    folder = stage / run
    for p in sorted(folder.iterdir()):
        if p.is_file(): add(p, run + '/' + p.name)
    for part in ['logs', 'captures', 'peer']:
        for p in sorted((folder / part).rglob('*')):
            if p.is_file(): add(p, run + '/' + p.relative_to(folder).as_posix())
    for part in ['native', 'witness']:
        for p in sorted((folder / part).rglob('*')):
            if p.is_file(): raw[run + '/' + p.relative_to(folder).as_posix()] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    for c in r['cases']:
        records = folder / 'witness' / (run + '-' + c['case']) / 'RECORDS.json'
        add(records, run + '/' + records.relative_to(folder).as_posix())
        for record in load(records):
            if record['trigger']:
                for p in sorted(records.parent.glob(f"{record['number']:03}.*")):
                    if p.is_file(): add(p, run + '/' + p.relative_to(folder).as_posix())
    for p in sorted((stage / (run + '-web') / 'inputs').iterdir()):
        if p.is_file(): add(p, 'public-inputs/' + p.name)
for p in sorted(diagnostics.iterdir()):
    if p.is_file(): add(p, 'android-ci/failed-cleanup/' + p.name)
for name in ['INSTALLED_CONSUMER.json', 'sources-before.json', 'sources-after.json']:
    add(package / name, 'package/' + name)
raw_bytes = (json.dumps(raw, sort_keys=True, indent=2) + '\n').encode()
manifest = {n: {'sha256': sha(p), 'bytes': p.stat().st_size} for n, p in sorted(members.items())}
manifest['FULL_RAW_TRACE_MANIFEST.json'] = {'sha256': hashlib.sha256(raw_bytes).hexdigest(), 'bytes': len(raw_bytes)}
encoded = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
dest = root / 'research/sdk-alpha1/evidence/20261013-browser-local-credential-session-continuity'
dest.mkdir()
archive = dest / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, p in sorted(members.items()): z.write(p, n)
    z.writestr('FULL_RAW_TRACE_MANIFEST.json', raw_bytes)
    z.writestr('MANIFEST.json', encoded)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n, m in manifest.items():
        assert hashlib.sha256(z.read(n)).hexdigest() == m['sha256'] and len(z.read(n)) == m['bytes']
checks = {
    'completed': True, 'release_claim_eligible': False, 'engine': engine,
    'case_count': 9, 'cases': sorted(cases),
    'package': {k: receipt[k] for k in ['sha256', 'manifest_sha256', 'source_bound', 'sources_unchanged']},
    'real_expiry': {n: c['real_expiry'] for n, c in cases.items() if 'real_expiry' in c},
    'worker_termination': {n: c['worker_kill'] for n, c in cases.items() if 'worker_kill' in c},
    'capture': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': len(manifest) + 1, 'manifest_sha256': hashlib.sha256(encoded).hexdigest()},
    'android_ci': {'run': 38419890920, 'job': 115377130350, 'source_commit': engine['engine_commit'], 'conclusion': 'failure', 'full_consumer': 'qualified pass', 'minimal_instrumentation': android_result, 'minimal_cleanup': 'unresolved; truncated APK copies then device unavailable', 'root_cause': 'not established; no SDK assertion failure observed'},
    'scope': 'Original established browser sessions across local and bilateral same-key G, witness loss/cancellation and real Worker termination. Same Rust implementation over loopback. Not whole-browser/OS crash, power loss, independent implementation, cross-host/device, performance, PCS or full-release qualification.'
}
sdk.write_json(dest / 'CHECKS.json', checks)
print(json.dumps(checks['capture']))
