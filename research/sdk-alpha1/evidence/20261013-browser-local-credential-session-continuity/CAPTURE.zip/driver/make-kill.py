from pathlib import Path
stage=Path.cwd()/'target/continuity-browser-local-credential-sessions'
s=(stage/'server.py').read_text();needle="'oversized','drop-ack']";assert s.count(needle)==1;s=s.replace(needle,"'oversized','drop-ack','kill-after-advance','kill-after-ack']")
needle="mode_counts[(case,mode)]==3 if mode=='drop-ack'";assert s.count(needle)==1;s=s.replace(needle,"mode_counts[(case,mode)]==3 if mode in ['drop-ack','kill-after-ack']")
needle="            if trigger and mode in ['drop-after-advance','drop-ack']:";assert s.count(needle)==1;s=s.replace(needle,"            if trigger and mode in ['kill-after-advance','kill-after-ack']:\n                time.sleep(20);self.close_connection=True;return\n"+needle)
(stage/'server_kill.py').write_text(s)
s=(stage/'run.py').read_text().replace('from server import serving','from server_kill import serving')
needle="for name in ['worker.js','controller.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)";assert s.count(needle)==1
s=s.replace(needle,"for name in ['worker.js','session-checks.js']:shutil.copyfile(stage/name,web/'creation'/name)\nshutil.copyfile(stage/'controller-kill.js',web/'creation/controller.js')")
start=s.index('allowed=');end=s.index('\ndef browser',start)
s=s[:start]+"allowed={'kill-after-commit','kill-after-ack'}\nsdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0"+s[end:]
needle="    if case in ['drop-commit','drop-ack','close-after-commit','cancel']:";assert s.count(needle)==1
s=s.replace(needle,"""    if case.startswith('kill-'):
     mode='kill-after-advance' if case=='kill-after-commit' else 'kill-after-ack'
     row['worker_kill']=success({**args,'action':'commit-credential','mode':mode,'killOnAdvance':True,'timeout':30000})
     sdk.require(row['worker_kill']['workerTerminated'] and row['worker_kill']['nativeLeaseReleased'] and row['worker_kill']['heldBeforeKill'] and not row['worker_kill']['sdkCloseRequested'],'worker kill/release not observed')
     observed=success({**args,'action':'recover-credential','historicalOnly':True});row['after_kill']=observed
     sdk.require(observed['proposal']==created['proposal'] and observed['status']['phase']==(4 if case=='kill-after-ack' else 2),'killed worker lost original preparation/terminal')
     final=success({**args,'action':'reconcile-credential','historicalOnly':True})
    elif case in ['drop-commit','drop-ack','close-after-commit','cancel']:""")
(stage/'run-kill.py').write_text(s)
