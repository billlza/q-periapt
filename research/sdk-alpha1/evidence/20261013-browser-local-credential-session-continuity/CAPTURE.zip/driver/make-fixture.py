from pathlib import Path
import shutil
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-local-credential-sessions';old=root/'target/continuity-browser-peer-credential'
for name in ['server.py','controller.js','worker.js','session-checks.js']:shutil.copyfile(old/name,stage/name)
p=stage/'controller.js';s=p.read_text();needle='row.trigger && row.armedMode === args.armFault';assert s.count(needle)==1;p.write_text(s.replace(needle,'row.trigger && (args.armFault ? row.armedMode === args.armFault : row.mode === args.mode)'))
dest=stage/'native-peer';(dest/'src').mkdir(parents=True)
for name in ['Cargo.toml','Cargo.lock']:(dest/name).write_text((old/'native-peer'/name).read_text().replace('q-periapt-browser-peer-credential-peer','q-periapt-browser-local-credential-peer'))
s=(old/'native-peer/src/main.rs').read_text();needle=' match mode.as_str(){';assert s.count(needle)==1
s=s.replace(needle,needle+'\n  "admit-browser" if args.len()==5=>admit_browser_renewal(dir,Path::new(&args[3]),Path::new(&args[4]))?,')
(dest/'src/main.rs').write_text(s+'\n'+(stage/'admit-browser.rs.txt').read_text())
s=(old/'run.py').read_text().replace('continuity-browser-peer-credential','continuity-browser-local-credential-sessions').replace('q-periapt-browser-peer-credential-peer','q-periapt-browser-local-credential-peer').replace('q-periapt-browser-roster-authority','q-periapt-browser-credential-commit-authority')
needle="web=Path(json.loads((package/'consumer-location.json').read_text())['path']);out=";assert s.count(needle)==1
s=s.replace(needle,"installed_web=Path(json.loads((package/'consumer-location.json').read_text())['path']);web=stage/(sys.argv[1]+'-web');shutil.copytree(installed_web,web,ignore=shutil.ignore_patterns('inputs','creation'));out=")
needle="state={'completed':False";assert s.count(needle)==1
s=s.replace(needle,"sdk.require(all(sdk.snapshot(installed_web/n).sha256==d for n,d in static.items() if not n.startswith('creation/')),'installed static copy drift')\nstate={'completed':False")
start=s.index('allowed=');end=s.index('\ndef browser',start)
s=s[:start]+"allowed={'live','drop-commit','drop-ack','close-after-commit','cancel','expired-local','expired-both'}\nsdk.require(bool(sys.argv[2:]) and set(sys.argv[2:])<=allowed and len(set(sys.argv[2:]))==len(sys.argv[2:]),'unknown or repeated scenario');sequence=0"+s[end:]
start=s.index('   for case in sys.argv[2:]:');end=s.index("  finally:browser(['close'],'close')",start)
s=s[:start]+(stage/'body.py.txt').read_text()+s[end:]
s=s.replace('actual installed browser peer G admission and original session/message/rekey continuity; independently retained native root/witness, same Rust implementation and loopback, not independent implementation/PCS/release','actual installed browser local and bilateral G with original session/message/rekey continuity; same Rust native implementation and loopback, not independent implementation/PCS/release')
(stage/'run.py').write_text(s)
sdk.write_json(stage/'ENGINE.json',{'engine_commit':'8b15054f9f014ccca9cc92f3507e5027b268860d','product_code_changed':False,'package':str(root/'target/continuity-browser-publication/source/target/peer-credential-package-01')})
