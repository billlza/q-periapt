import {sessionAction} from './session-checks.js';
import initialize, * as sdk from '/node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const b=v=>new Uint8Array(v), check=(v,m)=>{if(!v)throw Error(m)};
let owner,closePending;
self.onmessage=async({data})=>{
 if(data.cancel){check(owner,'cancel owner');closePending=owner.close();postMessage({cancellation_requested:true});return;}
 const owned=[],own=v=>{owned.push(v);return v};let value,failure;const observations=[];
 const get=async name=>{const r=await fetch('/inputs/'+name);if(!r.ok)throw Error('missing public input');return r.json()};
 const snapshot=async()=>{const s=own(await owner.status()),r=ownOptional(s.roster_refresh());return {phase:s.phase(),journal:s.journal()?[...s.journal()]:null,refresh:r?{previous:String(own(r.previous()).version()),target:String(own(r.target()).version()),outcome:r.outcome()??null,observedAt:r.observed_at()===undefined?null:String(r.observed_at())}:null}};
 const ownOptional=v=>v===undefined?undefined:own(v);
 const rosterProgress=async()=>{const p=ownOptional(await owner.witnessed_roster_refresh_progress());if(!p)return null;const previous=own(p.previous()),target=own(p.target()),proposal=ownOptional(p.proposal());return {stage:p.stage(),retired:p.retired(),operation:[...p.operation_id()],previous:String(previous.version()),target:String(target.version()),proposal:proposal?[...proposal.bytes()]:null}};
 const credentialStatus=async()=>{
  const s=own(await owner.credential_renewal_status()),cp=ownOptional(s.target()),head=ownOptional(s.observed_head());
  const id=s.operation_id(),statement=s.statement();return {phase:s.phase(),operation:id?[...id]:null,statement:statement?[...statement]:null,target:cp?{version:String(cp.version()),digest:[...cp.digest()]}:null,observed:head?{version:String(head.version()),digest:[...head.digest()]}:null,observedAt:s.observed_at()===undefined?null:String(s.observed_at())};
 };
 try {
  const cfg=await get(data.case+'.json'),description=b(cfg.description),at=BigInt(data.at??Math.floor(Date.now()/1000));
  const intent=own(new sdk.QPeriaptContinuityEnrollment(b(cfg.root),description.slice(0,16),1n,b(cfg.family),BigInt(cfg.from),BigInt(cfg.until)));
  const storage=b(data.id.match(/../g).map(v=>parseInt(v,16)));
  if(data.action==='create'){
   owner=await sdk.QPeriaptContinuityDevice.create(data.name,storage,intent);value={request:[...await owner.request(at)]};
  }else{
   const grant=await get(data.case+'-grant.json'),statement=cfg.policies[data.profile??'required'];
   const history=own(new sdk.QPeriaptContinuityHistoricalPolicy(b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire)));
   let runtime,policy;
   if(!data.historicalOnly){runtime=own(new sdk.QPeriaptRuntime(b(cfg.sdk_policy),b(cfg.sdk_signature),b(cfg.sdk_root),b(cfg.sdk_state),32,4));policy=own(new sdk.QPeriaptContinuityPolicy(runtime,b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire),at));}
   const account=(v)=>own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),BigInt(v.version),b(v.digest),b(cfg.family)));
   owner=await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);observations.push(await snapshot());
   const witness=own(sdk.QPeriaptContinuityWitness.for_loopback(b(cfg.witness_id),b(data.wrongWitness?cfg.root:cfg.witness_public),new URL('/witness/'+data.case+'?mode='+(data.mode??'normal'),location.origin).href,data.timeout??5000));
   const target=async()=>{const v=await get(data.targetFile??data.case+'-target.json');return own(new sdk.QPeriaptContinuityRosterTarget(account(v),b(v.certificate),b(v.roster),at))};
   const proposal=()=>own(new sdk.QPeriaptContinuityRosterProposal(b(data.proposal)));
   if(data.closePolicy)policy.close();if(data.closeRuntime)runtime.close();
   if(data.action==='session'){
    await owner.activate(policy,witness,at);value=await sessionAction(owner,policy,runtime,cfg,grant,data);
   }else if(data.action==='peer-credential'){
    await owner.activate(policy,witness,at);
    const peer=await get(data.case+'-peer.json'),target=await get(data.targetFile??data.case+'-peer-renewal.json');
    const trust=own(new sdk.QPeriaptContinuityAccountTrust(b(peer.account),b(peer.root),BigInt(target.version),b(target.digest),b(cfg.family)));
    const approved=own(new sdk.QPeriaptContinuityCredentialGrant(b(target.grant),trust,history,at));
    const id=b(data.peerOperation);if(data.wrongOperation)id[0]^=1;
    if(data.closedPeerPolicy)policy.close();if(data.closedPeerRuntime)runtime.close();
    if(data.armFault){const armed=await fetch('/arm/'+data.case,{method:'POST',body:JSON.stringify({mode:data.armFault})});check(armed.status===201,'fault not armed after activation');}
    const cp=own(await owner.admit_peer_credential_renewal(approved,id,policy,at));value={version:String(cp.version()),digest:[...cp.digest()]};
   }else if(data.action==='accept'){
value={journal:[...await owner.accept(b(grant.certificate),b(grant.roster),account(grant),policy,at)]};}
   else if(data.action==='prepare'){
    const p=own(await owner.prepare(policy,at)),s=await snapshot();value=p.requires_witness()?{phase:'requires-witness-enrollment',journal:s.journal,genesis:[...p.image_digest()],subject:[...p.subject()]}:{phase:'prepared-local',journal:s.journal};
   }else if(data.action==='activate'){
    const id=data.profile==='local'?await owner.activate_local(policy,at):await owner.activate(policy,witness,at);
    observations.push({activatedJournal:[...id]});
    if(data.inventoryOnly){
     const prekeyStatus=await owner.prekey_status(policy,new Uint8Array(32).fill(55));
     const newKey=await owner.generate_prekey(policy,new Uint8Array(32).fill(56),sdk.QPeriaptContinuityPrekeyKind.OneTimePq,at,at+300n,at);
     value={journal:[...id],prekeyStatus,newPrekey:[...newKey],status:await snapshot()};
    }else{
    const key=await owner.generate_prekey(policy,new Uint8Array(32).fill(55),sdk.QPeriaptContinuityPrekeyKind.OneTimePq,BigInt(cfg.from),BigInt(cfg.until),at);
    value={journal:[...id],prekey:[...key],status:await snapshot(),progress:await rosterProgress()};
    }
   }else if(data.action==='credential-status')value=await credentialStatus();
   else if(data.action==='stage-credential'){
    const next=await get(data.case+'-renewal.json');
    const g=own(new sdk.QPeriaptContinuityCredentialGrant(b(next.grant),account(next),history,at));
    own(await owner.stage_credential_renewal(g,b(data.operationId),policy,at));value=await credentialStatus();
   }else if(data.action==='prepare-credential'){
    const p=own(await owner.prepare_witnessed_credential_renewal(history,policy,witness,at));
    value={proposal:[...p.bytes()],binding:[...p.binding()],statement:[...p.statement()],status:await credentialStatus()};
   }else if(data.action==='recover-credential'){
    const p=ownOptional(await owner.recover_witnessed_credential_renewal_preparation(history,at));value={proposal:p?[...p.bytes()]:null,status:await credentialStatus()};
   }else if(data.action==='prepare-cancellation'){
    const p=own(await owner.prepare_witnessed_credential_cancellation(history,at));value={cancellation:[...p.bytes()],status:await credentialStatus()};
   }else if(data.action==='commit-credential'){
    const p=own(new sdk.QPeriaptContinuityCredentialProposal(b(data.credentialProposal)));
    own(await owner.commit_witnessed_credential_renewal(p,history,policy,witness,at));value=await credentialStatus();
   }else if(data.action==='reconcile-credential'||data.action==='close-credential'){
    const fn=data.action==='reconcile-credential'?'reconcile_witnessed_credential_renewal':'close_witnessed_credential_renewal';
    own(await owner[fn](b(data.operationId),b(data.statement),history,witness,at));value=await credentialStatus();
   }else if(data.action==='expire-credential'){
    own(await owner.reconcile_expired_credential_renewal(b(data.operationId),b(data.statement),policy,at));value=await credentialStatus();
   }else if(data.action==='scalar'){
    let hooks=0;const coercible={valueOf(){hooks++;return 1n}};
    const rejected=[];
    for(const bad of [(1n<<64n)+1n,1n-(1n<<64n),'1',true,coercible]){
     let error;try{own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),bad,b(grant.digest),b(cfg.family)))}catch(e){error=e}
     check(error?.code==='InvalidInput','account version wrapped/coerced');rejected.push(String(typeof bad));
    }
    for(const bad of [(1n<<64n)+at,at-(1n<<64n),String(at),true,coercible]){
     let error;try{await owner.request(bad)}catch(e){error=e}
     check(error?.code==='InvalidInput','request time wrapped/coerced');
    }
    check(hooks===0,'scalar coercion hook executed');value={rejected:10,hooks,status:await snapshot()};
   }else if(data.action==='new-credential-operation')value={operation:[...sdk.QPeriaptContinuityCredentialRequest.new_operation_id()]};
   else if(data.action==='credential-request'){
    const request=own(data.profile==='local'||data.forceLocal?await owner.credential_renewal_request(b(data.operationId),history):await owner.witnessed_credential_renewal_request(b(data.operationId),history,witness));
    const requestValue={operation:[...request.operation_id()]};
    for(const k of ['journal','original_owner','original_policy_digest','current_policy_digest','original_roster_digest','previous_roster_digest','original_credential','original_roster','previous_credential','previous_roster'])requestValue[k]=[...request[k]()];
    for(const k of ['current_policy_version','original_roster_version','previous_roster_version','previous_valid_from','previous_valid_until'])requestValue[k]=String(request[k]());
    const authorization=request.current_policy_authorization();requestValue.current_policy_authorization=authorization===undefined?null:[...authorization];
    value={requestValue,status:await snapshot(),runtimeCreated:runtime!==undefined};
   }else if(data.action==='new-operation')value={operation:[...sdk.QPeriaptContinuityRosterProposal.new_operation_id()]};
   else if(data.action==='prepare-roster'){
    const p=own(await owner.prepare_witnessed_roster_refresh(b(data.operationId),history,policy,await target(),witness,at));
    value={proposal:[...p.bytes()],binding:[...p.binding()],progress:await rosterProgress()};
   }else if(data.action==='recover-preparation'){
    const p=ownOptional(await owner.recover_witnessed_roster_refresh_preparation(history));value={proposal:p?[...p.bytes()]:null,progress:await rosterProgress()};
   }else if(data.action==='progress')value={progress:await rosterProgress()};
   else if(data.action==='commit')value={state:await owner.commit_witnessed_roster_refresh(proposal(),history,policy,witness,at),progress:await rosterProgress()};
   else if(data.action==='reconcile')value={state:await owner.reconcile_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='close-roster')value={state:await owner.close_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='abandon')value={progress:(own(await owner.abandon_unprepared_roster_refresh(b(data.operationId),history)),await rosterProgress())};
   else if(data.action==='local-refresh'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest)));
    own(await owner.refresh_local_roster(previous,b(t.roster),account(t),policy,at));value={status:await snapshot()};
   }else if(data.action==='local-resolve'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest))),targetCp=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(t.version),b(t.digest)));
    const result=own(await owner.resolve_local_roster_refresh(previous,targetCp,history,at));value={outcome:result.outcome(),observed:own(result.observed()).version().toString(),status:await snapshot()};
   }else throw Error('unknown action');
  }
 }catch(error){failure=error;if(error.ownerClosed!==undefined)check(owner?.is_closed()===error.ownerClosed,'owner closure mismatch');}
 try{if(closePending)await closePending;if(owner)await owner.close();}catch(error){failure=new AggregateError(failure?[failure,error]:[error],'operation/cleanup failed')}
 if(owner){check(owner.is_closed(),'owner close missing');owner.free();owner=undefined}closePending=undefined;
 for(const object of owned.reverse()){if(typeof object.close==='function')object.close();object.free()}
 postMessage(failure?{done:true,error:String(failure),code:failure.code,ownerClosed:failure.ownerClosed,observations}:{done:true,value,observations});
};
postMessage({ready:true});
