from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile
import time
import tomllib
import urllib.request

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ios-simulator-matrix'
MANIFEST = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib/rustlib/multirust-channel-manifest.toml')
SOURCE_SHA = 'e44f4ea0a633aa3e497e4dd161424419fbd7bdc203606ef840634fdd22dab9bf'
data = MANIFEST.read_bytes()
assert hashlib.sha256(data).hexdigest() == SOURCE_SHA
manifest = tomllib.loads(data.decode())
assert manifest['date'] == '2026-09-03' and manifest['pkg']['rust']['version'] == '1.98.1 (48a229cea 2026-09-01)'
target = manifest['pkg']['rust-std']['target']['x86_64-apple-ios']
url = target['xz_url']
assert target['available'] and url == 'https://static.rust-lang.org/dist/2026-09-03/rust-std-1.98.1-x86_64-apple-ios.tar.xz'
assert target['xz_hash'] == 'e31f61ee797e63e9ab2a381a8efbe8a3fb37987f04e4f92eae2930a2dc6f68cf'
out = BASE / 'rust-std-1.98.1-x86_64-apple-ios.tar.xz'
state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'url': url, 'expected_sha256': target['xz_hash'], 'manifest_sha256': SOURCE_SHA,
         'scope': 'Task-private iOS simulator standard-library download; no toolchain installation or product qualification.',
         'network_timeout_seconds': 60, 'download_deadline_seconds': 180,
         'maximum_download_bytes': 128 * 1024**2, 'global_toolchain_modified': False}
started = time.monotonic()
try:
    with urllib.request.urlopen(url, timeout=60) as response, out.open('xb') as stream:
        assert response.status == 200
        total = 0
        while chunk := response.read(1024**2):
            assert time.monotonic() - started < 180, 'Download deadline exceeded'
            total += len(chunk)
            assert total <= 128 * 1024**2
            stream.write(chunk)
        state['bytes'] = total
    with out.open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    state['sha256'] = actual
    assert actual == target['xz_hash'], 'Pinned Rust component checksum differs'
    with tarfile.open(out, mode='r:xz') as archive:
        members = archive.getmembers()
        assert len(members) < 2048 and sum(row.size for row in members) < 512 * 1024**2
        state['archive_members'] = len(members)
        state['uncompressed_member_bytes'] = sum(row.size for row in members)
        state['metadata_members'] = [row.name for row in members if row.name.endswith(('manifest.in', '/components', '/LICENSE-APACHE', '/LICENSE-MIT'))]
    assert hashlib.sha256(MANIFEST.read_bytes()).hexdigest() == SOURCE_SHA
    with (BASE / 'rust-channel-manifest.toml').open('xb') as stream: stream.write(data)
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    with (BASE / 'DOWNLOAD_RESULT.json').open('x') as stream:
        json.dump(state, stream, indent=2); stream.write('\n')
    print(json.dumps(state, indent=2), flush=True)
