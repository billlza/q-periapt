"""The retained iOS simulator distribution matrix, without Intel macOS."""
from pathlib import Path
import json
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'artifact'))
import continuity_apple_package as apple
import continuity_c_consumer as c


class RetainedSimulatorMatrix(unittest.TestCase):
    def test_retained_ios_simulator_matrix(self):
        self.assertEqual(set(apple.TARGETS), {
            'aarch64-apple-darwin', 'aarch64-apple-ios',
            'aarch64-apple-ios-sim', 'x86_64-apple-ios'})
        self.assertNotIn('x86_64-apple-darwin', apple.TARGETS)

    def test_x86_ios_static_artifact_keeps_exact_provenance(self):
        consumer = Path('/private/qualified/c-consumer')
        build = Path('/private/qualified/apple/native')
        target = 'x86_64-apple-ios'
        expected = build / target / 'release' / apple.LIBRARY
        record = {'reason': 'compiler-artifact', 'manifest_path': str(consumer / 'Cargo.toml'),
                  'target': {'name': c.LIBRARY, 'crate_types': ['staticlib']},
                  'profile': {'opt_level': '3', 'test': False}, 'filenames': [str(expected)]}
        self.assertEqual(apple.built_static((json.dumps(record) + '\n').encode(), consumer, build, target), expected)


if __name__ == '__main__':
    unittest.main()
