from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import tarfile
import tempfile

import continuity_apple_package as apple
import continuity_package as package
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ios-simulator-matrix'
OLD_CHAIN = Path('/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/rustup/toolchains/1.98.1-aarch64-apple-darwin')
CHAIN = BASE / 'toolchain'
FOUNDATION = Path('/private/var/folders/_1/c5pzdh_j04q963k2csf4vlkh0000gn/T/qperiapt-continuity-package-g03ryny6')
PREFIX = 'rust-std-1.98.1-x86_64-apple-ios/'
COMPONENT = PREFIX + 'rust-std-x86_64-apple-ios/'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')

def inventory(root):
    return {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': digest(p)}
            for p in sorted(root.rglob('*')) if p.is_file()}

state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
         'scope': 'Task-private copy of the pinned compiler plus manifest-pinned x86_64 iOS standard library; separate admitted C source/cache copy.',
         'original_toolchain': str(OLD_CHAIN), 'task_toolchain': str(CHAIN),
         'global_toolchain_modified': False, 'rustup_install_performed': False,
         'foundation': str(FOUNDATION), 'driver_sha256': digest(Path(__file__))}
write(BASE / 'PREPARATION_START.json', state)
try:
    assert package.ROOT == ROOT
    sdk.validate_no_registry_credentials(os.environ)
    assert not CHAIN.exists()
    symlinks = [str(p) for p in OLD_CHAIN.rglob('*') if p.is_symlink()]
    assert not symlinks, symlinks[:10]
    before = inventory(OLD_CHAIN)
    sdk.command(['/bin/cp', '-cR', str(OLD_CHAIN), str(CHAIN)], BASE / 'copy-toolchain', ROOT)
    assert inventory(CHAIN) == before == inventory(OLD_CHAIN)
    archive = BASE / 'rust-std-1.98.1-x86_64-apple-ios.tar.xz'
    assert digest(archive) == 'e31f61ee797e63e9ab2a381a8efbe8a3fb37987f04e4f92eae2930a2dc6f68cf'
    additions = {}
    with tarfile.open(archive, 'r:xz') as tf:
        members = tf.getmembers()
        assert len(members) == 76 and len({m.name for m in members}) == len(members)
        assert sum(m.size for m in members) < 512 * 1024**2
        for member in members:
            path = PurePosixPath(member.name)
            assert member.isfile() or member.isdir()
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
            assert member.name.startswith(PREFIX.rstrip('/'))
        manifest = tf.extractfile(COMPONENT + 'manifest.in').read().decode()
        for line in manifest.splitlines():
            assert line.startswith('file:lib/rustlib/x86_64-apple-ios/lib/'), line
            relative = line.removeprefix('file:')
            assert relative not in additions
            member = tf.getmember(COMPONENT + relative)
            assert member.isfile()
            data = tf.extractfile(member).read()
            assert len(data) == member.size
            destination = CHAIN / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream: stream.write(data)
            additions[relative] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        expected_members = {COMPONENT + p for p in additions} | {COMPONENT + 'manifest.in'}
        assert {m.name for m in members if m.isfile() and m.name.startswith(COMPONENT)} == expected_members
    assert inventory(CHAIN) == before | additions
    assert inventory(OLD_CHAIN) == before
    env = dict(os.environ, RUSTC=str(CHAIN / 'bin/rustc'), DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'))
    state['rustc'] = sdk.command([str(CHAIN / 'bin/rustc'), '--version', '--verbose'], BASE / 'private-rustc', ROOT, environment=env).decode()
    assert state['rustc'].splitlines()[0] == 'rustc 1.98.1 (48a229cea 2026-09-01)'
    std = sdk.command([str(CHAIN / 'bin/rustc'), '--print', 'target-libdir', '--target', 'x86_64-apple-ios'], BASE / 'private-target', ROOT, environment=env).decode().strip()
    assert Path(std).resolve(strict=True) == (CHAIN / 'lib/rustlib/x86_64-apple-ios/lib').resolve(strict=True)
    source_before = apple.file_hashes(FOUNDATION / 'c-consumer')
    swift = json.loads((ROOT / 'target/continuity-swift-managed-cohort/INPUTS.json').read_bytes())
    assert source_before == swift['c_source_before']
    outside = Path(tempfile.mkdtemp(prefix='qperiapt-continuity-ios-matrix-')).resolve(strict=True)
    state['outside'] = str(outside)
    write(BASE / 'LOCATION.json', {'path': str(outside)})
    sdk.command(['/bin/cp', '-cR', str(FOUNDATION / 'c-consumer'), str(outside / 'c-consumer')], BASE / 'copy-consumer', ROOT)
    assert apple.file_hashes(outside / 'c-consumer') == source_before == apple.file_hashes(FOUNDATION / 'c-consumer')
    (outside / 'cargo-home').mkdir()
    registry_before = inventory(FOUNDATION / 'cargo-home/registry')
    sdk.command(['/bin/cp', '-cR', str(FOUNDATION / 'cargo-home/registry'), str(outside / 'cargo-home/registry')], BASE / 'copy-registry', ROOT)
    assert inventory(outside / 'cargo-home/registry') == registry_before == inventory(FOUNDATION / 'cargo-home/registry')
    state.update(completed=True, original_toolchain_files=before, added_standard_library=additions,
                 private_toolchain_files=before | additions, c_source_files=source_before,
                 registry_files=registry_before, foundation_unchanged=True)
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    write(BASE / 'PREPARATION_RESULT.json', state)
    print(json.dumps({k: state.get(k) for k in ['completed', 'outside', 'error_type', 'error']}, indent=2), flush=True)
