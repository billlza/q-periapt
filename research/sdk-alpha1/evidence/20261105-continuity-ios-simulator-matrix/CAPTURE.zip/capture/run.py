from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import sys

import continuity_apple_package as apple
import continuity_package as package
import rust_sdk_profile as sdk
from rust_sdk_msrv import validate_report

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ios-simulator-matrix'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = BASE / 'result-01'
REPORT = SOURCE / 'target/managed-sdk-cohort/RUST_SDK_PACKAGE.json'
REPORT_SHA = '93fbef9dace1af6550a85095f6d2392285197a8fe589838f4d6f8447ba03c4f8'
CHANGED_INPUTS = {'.github/workflows/ci.yml', 'artifact/continuity_apple_package.py',
                  'artifact/continuity_apple_consumer.py',
                  'bindings/swift/ContinuityPackageConsumer/ApplePackageREADME.md'}

def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')

def validate_files(root, expected):
    for name, row in expected.items():
        path = root / name
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], name

def main():
    assert ROOT == package.ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sdk.validate_no_registry_credentials(os.environ)
    readiness = json.loads((BASE / 'PREPARATION_RESULT.json').read_bytes())
    assert readiness['completed'] and readiness['foundation_unchanged']
    outside = Path(readiness['outside'])
    chain = Path(readiness['task_toolchain'])
    before = package.source_inputs()
    foundation = json.loads((ROOT / 'target/continuity-swift-managed-cohort/INPUTS.json').read_bytes())
    previous = foundation['source_inputs']
    assert before['rust_workspace_sha256'] == previous['rust_workspace_sha256']
    assert before['files'].keys() == previous['files'].keys()
    differences = {n: {'previous': previous['files'][n], 'current': before['files'][n]}
                   for n in before['files'] if before['files'][n] != previous['files'][n]}
    assert set(differences) == CHANGED_INPUTS, sorted(differences)
    assert digest(REPORT) == REPORT_SHA
    cohort = validate_report(REPORT.read_bytes(), REPORT_SHA, REPORT_SHA, before['rust_workspace_sha256'])
    for row in cohort['crates'].values():
        path = REPORT.parent / 'crates' / row['file']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    validate_files(chain, readiness['private_toolchain_files'])
    assert apple.file_hashes(outside / 'c-consumer') == readiness['c_source_files'] == foundation['c_source_before']
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    commit = sdk.command(['git', 'rev-parse', 'HEAD'], OUTPUT / 'git-head', ROOT).decode().strip()
    assert sdk.command(['git', 'diff', '--name-only', 'HEAD', '--'], OUTPUT / 'git-tracked-status', ROOT) == b''
    # The user's unrelated untracked census directory is intentionally untouched.
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    env.update(CARGO_HOME=str(outside / 'cargo-home'), CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never',
               CARGO_HTTP_MULTIPLEXING='false', CARGO_INCREMENTAL='0',
               RUSTC=str(chain / 'bin/rustc'), RUSTDOC=str(chain / 'bin/rustdoc'),
               RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
               DYLD_FALLBACK_LIBRARY_PATH=str(chain / 'lib'),
               PATH=str(chain / 'bin') + os.pathsep + env.get('PATH', os.defpath))
    state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
             'scope': 'Four-target Continuity Apple package: actual macOS arm64 installed probe and separate iOS arm64 device, arm64 simulator and x86_64 simulator consumer builds.',
             'source_commit': commit, 'source_inputs': before, 'changes_from_qualified_foundation': differences,
             'sdk_producer_commit': cohort['base_commit'], 'sdk_report_sha256': REPORT_SHA,
             'preparation_sha256': digest(BASE / 'PREPARATION_RESULT.json'),
             'driver_sha256': digest(Path(__file__)), 'stream_helper_sha256': digest(helper),
             'outside': str(outside), 'release_claim_eligible': False,
             'publication_performed': False, 'global_toolchain_modified': False,
             'ios_runtime_claimed': False, 'intel_macos_in_scope': False}
    write(BASE / 'INPUTS.json', state)
    try:
        state['apple_package'] = apple.qualify_apple(outside, OUTPUT, env)
        assert state['apple_package']['completed']
        assert set(state['apple_package']['native']) == set(apple.TARGETS)
        assert set(state['apple_package']['slices']) == set(apple.SLICES)
        assert set(state['apple_package']['consumer']) == {'macos', 'ios', 'simulator', 'simulator-x86_64'}
        assert package.source_inputs() == before
        assert apple.file_hashes(outside / 'c-consumer') == readiness['c_source_files']
        assert apple.file_hashes(Path(readiness['foundation']) / 'c-consumer') == readiness['c_source_files']
        validate_files(chain, readiness['private_toolchain_files'])
        validate_files(Path(readiness['original_toolchain']), readiness['original_toolchain_files'])
        assert digest(REPORT) == REPORT_SHA
        state.update(completed=True, source_inputs_unchanged=True, original_toolchain_unchanged=True,
                     foundation_source_unchanged=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'DRIVER_RESULT.json', state)
        print(json.dumps({k: state.get(k) for k in ['completed', 'source_commit', 'error_type', 'error']}, indent=2), flush=True)

if __name__ == '__main__': main()
