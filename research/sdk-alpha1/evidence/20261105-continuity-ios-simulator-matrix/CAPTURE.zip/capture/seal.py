from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-ios-simulator-matrix'
OUTPUT = BASE / 'result-01'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-continuity-ios-simulator-matrix'

def encode(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def digest(data): return hashlib.sha256(data).hexdigest()
def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()

launch = json.loads(read(BASE / 'LAUNCH_RESULT.json'))
driver = json.loads(read(BASE / 'DRIVER_RESULT.json'))
apple = json.loads(read(OUTPUT / 'CONTINUITY_APPLE_PACKAGE.json'))
assert launch['completed'] and launch['returncode'] == 0 and driver['completed']
assert driver['source_inputs_unchanged'] and driver['original_toolchain_unchanged'] and driver['foundation_source_unchanged']
assert driver['apple_package'] == apple and apple['completed'] and apple['sources_unchanged']
assert set(apple['targets']) == {'aarch64-apple-darwin', 'aarch64-apple-ios', 'aarch64-apple-ios-sim', 'x86_64-apple-ios'}
assert set(apple['slices']) == {'macos', 'ios', 'simulator'}
assert apple['slices']['simulator']['targets'] == ['aarch64-apple-ios-sim', 'x86_64-apple-ios']
assert set(apple['consumer']) == {'macos', 'ios', 'simulator', 'simulator-x86_64'}
assert apple['consumer']['macos']['native_owner_probe'] is True
for key, target, slice_name in [('macos', 'aarch64-apple-darwin', 'macos'), ('ios', 'aarch64-apple-ios', 'ios'),
                               ('simulator', 'aarch64-apple-ios-sim', 'simulator'), ('simulator-x86_64', 'x86_64-apple-ios', 'simulator')]:
    row = apple['consumer'][key]
    assert row['target'] == target and row['selected_archive_sha256'] == apple['slices'][slice_name]['sha256']
package_bytes = read(OUTPUT / apple['archive']['file'])
assert digest(package_bytes) == apple['archive']['sha256'] and len(package_bytes) == apple['archive']['bytes']
with zipfile.ZipFile(io.BytesIO(package_bytes)) as archive:
    names = [p.filename for p in archive.infolist() if not p.is_dir()]
    assert len(names) == len(set(names))
    root = 'QPeriaptContinuity/'
    contents = json.loads(archive.read(root + 'PACKAGE_CONTENTS.json'))
    expected = {root + name for name in contents['files']} | {root + 'PACKAGE_CONTENTS.json'}
    assert set(names) == expected
    assert contents['targets'] == apple['targets']
    for name, sha in contents['files'].items(): assert digest(archive.read(root + name)) == sha
    package_members = len(names)
commands = []
for path in OUTPUT.rglob('*.json'):
    data = json.loads(read(path))
    if 'argv' in data:
        assert data['returncode'] == 0 and data['completed'], path
        for suffix in ['stdout', 'stderr']:
            assert digest(read(path.with_suffix('.' + suffix))) == data[suffix + '_sha256']
        commands.append(path.relative_to(OUTPUT).as_posix())
assert len(commands) >= 30
for path, sha in driver['source_inputs']['files'].items(): assert digest(read(ROOT / path)) == sha, path
files = {}
for path in sorted(OUTPUT.rglob('*')):
    assert not path.is_symlink()
    if path.is_file(): files['qualification/' + path.relative_to(OUTPUT).as_posix()] = read(path)
for path in sorted((BASE / 'baseline-source').rglob('*')):
    if path.is_file(): files['baseline-source/' + path.relative_to(BASE / 'baseline-source').as_posix()] = read(path)
for path in sorted(BASE.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.stdout', '.stderr', '.py', '.toml'}:
        if path.name.startswith('seal.'): continue
        files['capture/' + path.name] = read(path)
for name in ['.github/workflows/ci.yml', 'artifact/continuity_apple_package.py', 'artifact/continuity_apple_consumer.py',
             'artifact/test_continuity_apple_package.py', 'bindings/swift/ContinuityPackageConsumer/ApplePackageREADME.md']:
    files['corrected-source/' + name] = read(ROOT / name)
files['capture/seal.py'] = read(Path(__file__))
readback = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(),
            'source_commit': driver['source_commit'], 'sdk_producer_commit': driver['sdk_producer_commit'],
            'sdk_report_sha256': driver['sdk_report_sha256'], 'targets': apple['targets'], 'slices': apple['slices'],
            'consumer': apple['consumer'], 'package_archive': apple['archive'],
            'package_members_read_back': package_members, 'command_receipts': len(commands),
            'parent_elapsed_seconds': launch['elapsed_seconds'], 'parent_timeout_seconds': launch['timeout_seconds'],
            'component_timeout_seconds': launch['component_timeout_seconds'],
            'component_stream_limit_bytes': launch['component_stream_limit_bytes'],
            'source_inputs_unchanged': True, 'original_toolchain_unchanged': True, 'foundation_source_unchanged': True,
            'old_contract_tests': 'Two tests: one failure and one error on the retained three-target baseline.',
            'corrected_contract_tests': 2, 'apple_validation_tests': 10, 'related_tests': 50,
            'macos_runtime': 'arm64 installed public owner probe',
            'ios_runtime_claimed': False, 'intel_macos_in_scope': False,
            'hosted_ci_claimed': False, 'publication_performed': False, 'release_claim_eligible': False}
for n, count in [('contract-01', 2), ('unit-01', 10), ('related-01', 50)]:
    data = read(BASE / (n + '.stderr')).decode()
    assert f'Ran {count} tests' in data and data.endswith('\nOK\n')
baseline = read(BASE / 'baseline.stderr').decode()
assert 'FAILED (failures=1, errors=1)' in baseline
files['READBACK.json'] = encode(readback)
manifest = {n: {'bytes': len(b), 'sha256': digest(b)} for n, b in sorted(files.items())}
files['FILES.json'] = encode(manifest)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, body)
payload = buffer.getvalue()
assert len(payload) < 100 * 1024**2
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    for name, body in files.items(): assert archive.read(name) == body
summary = {'bytes': len(payload), 'members': len(files), 'sha256': digest(payload)}
DEST.mkdir(parents=True, exist_ok=False)
for name, data in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']),
                   ('READBACK.json', files['READBACK.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as stream: stream.write(data)
print(json.dumps(summary, indent=2), flush=True)
