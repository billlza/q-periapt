# Swift/Kotlin peer configuration component

`FOREIGN_VERIFIED.json` binds the final facade sources, unit checks, four component
archives and six actual outside-checkout consumer runs. This work remains an
isolated 0.2.0 prototype and has not been integrated into the product checkout.
The native/C implementation is the unchanged `NATIVE_C_CAPTURE.zip` checkpoint.

The public `PeerDeviceExpectation` and `PeerConfiguration` types keep independent
account, roster, device, generation, directory and TLS expectations separate from
the untrusted signed bootstrap bundle. Device methods accept these values for
fresh preparation or explicit original-session reopen. They retain the existing
NativeOwner and parent lifetime machinery. Kotlin snapshots bounded public arrays;
Swift uses immutable value storage and confines pointer borrows to the synchronous
native preparation. No raw key or native handle is exposed by these methods.

Swift passes 62 tests in Debug and Release with warnings as errors. Kotlin passes
64 tests with Debug/G1 and Release/Serial using strict pinned dependencies and
compiler warnings as errors. Java compilation/execution proves the new public
inputs and method signatures are usable, while the synthetic internal method is
inaccessible to Java source. One diagnostic probe initially assumed English javac
output; the corrected probe uses machine diagnostic keys and retains the original
Chinese cannot-find-symbol result.

Both Swift archives and both Kotlin Maven archives were unpacked outside the
checkout. Their licenses, members, native library hashes and runtime dependencies
were verified. Swift rebuilt and ran from those archives. Kotlin resolved the
candidate artifact from each unpacked Maven repository with dependencies inside
its private outside cache. Actual Debug/Release runs used both G1 and Serial for
Kotlin. All six selected flows passed native Rust-coordinated registration,
separate-process TLS, unknown committed delivery, roster refresh, original-session
reopen and same-message recovery with one independently observed application
effect. Initial SDK provisioning in this test still uses the existing fixture
helper; full first-configuration-to-connection composition remains a separate gate.

The lifetime probes exercise the new configured route with real owners:

- A live child remains usable after the public device wrapper is released or
  observed collected; it retains the original native parent.
- Explicit parent close makes the retained child fail and releases the real
  stores before another original device is reopened.
- Cancelling a pending child produces cancellation without revoking its parent.
- After closing the last child of an already-collected public JVM parent, the
  native parent becomes eligible for asynchronous Cleaner disposal. The test uses
  the existing bounded 64-slot reclamation observation, then attempts storage open
  once. Storage errors are never retried. Swift ARC cleanup is immediate here.

The first Kotlin probe incorrectly demanded synchronous Cleaner completion and
also closed one handle twice through an explicit close plus `use`. Those failures
are retained. Only the qualification probe was corrected: the existing library
Release/call/close/disposed implementation is byte-identical to the product base.
No automatic fallback or relaxed native close behavior was introduced.

Remaining work includes product source/header/export/census integration and the
required installed CI gate, witnesses/continued-policy coverage through the new
route, first-install composition, complete package lifecycle regressions, Linux
and physical/minimum-OS validation, and the larger independent-protocol, security
and performance requirements. These results do not qualify the whole release.
