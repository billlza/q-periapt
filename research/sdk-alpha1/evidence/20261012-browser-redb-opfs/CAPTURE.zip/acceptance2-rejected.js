async (page) => {
  await page.goto('http://127.0.0.1:61817/');
  await page.waitForFunction(() => !!globalThis.probe);
  const errors = []; page.on('pageerror', e => errors.push(String(e)));
  const result = await page.evaluate(async () => {
    const rows=[], workers=[], prefix='accept-'+Date.now();
    const expect=(yes,why)=>{if(!yes)throw new Error(why)};
    const worker=()=>{const w=probe.create();workers.push(w);return w};
    const call=(w,command,extra={})=>probe.call(w,{command,...extra});
    const ok=async(w,command,extra={})=>{const r=await call(w,command,extra);expect(r.ok,command+': '+JSON.stringify(r));return r.result};
    const pair=r=>expect((r.revision==='0'&&r.image==='initial')||(r.revision==='1'&&r.image==='target'),'torn state: '+JSON.stringify(r));
    const released=async(name)=>{const start=performance.now();for(;;){const s=await navigator.locks.query();if(![...s.held,...s.pending].some(x=>x.name==='qpc-opfs-probe/'+name))return performance.now()-start;expect(performance.now()-start<12000,'lease not released');await new Promise(r=>setTimeout(r,25))}};
    const reopen=async(w,name)=>{const start=performance.now();for(;;){const r=await call(w,'open',{name});if(r.ok)return r.result;expect(/NoModificationAllowedError|Busy/.test(r.error),'reopen: '+JSON.stringify(r));expect(performance.now()-start<12000,'OPFS lock not released');await new Promise(r=>setTimeout(r,25))}};
    const cut=async(w,name,command,index,after)=>{
      let settled=false;const pending=call(w,command,{expected:'0',value:'target',kind:'sync',index,after,action:'cut'}).then(r=>{settled=true;return r});
      const start=performance.now();let event;
      for(;;){event=probe.events(w).find(x=>x.event==='cut');if(event)break;expect(!settled,'operation returned before cut');expect(performance.now()-start<10000,'cut not reached');await new Promise(r=>setTimeout(r,10))}
      expect(!settled,'operation returned at cut');probe.terminate(w);const outcome=await pending;expect(outcome.error==='terminated','cut result');
      return {event,leaseReleaseMs:await released(name),outcome};
    };
    try {
      const a=worker(), b=worker(), name=prefix+'-exclusive';
      const initial=await ok(a,'create',{name});
      const busy=await call(b,'open',{name});expect(!busy.ok&&/Busy/.test(busy.error),'second owner admitted');
      const raw=await call(b,'raw-lock',{name});expect(!raw.ok&&/NoModificationAllowedError/.test(raw.error),'raw OPFS handle admitted');
      const replaced=await ok(a,'replace',{expected:'0',value:'target'});expect(replaced.revision==='1'&&replaced.image==='target','normal replace');expect(replaced.counts.sync===2,'two-phase barrier count');
      await ok(a,'close');const opened=await ok(b,'open',{name});expect(opened.revision==='1'&&opened.image==='target','normal reopen');await ok(b,'close');
      rows.push({case:'exclusive-and-reopen',initial,busy,raw,replaced,opened});
      const n=worker();const native=await ok(n,'native',{name:prefix+'-native'});expect(native.revision==='2'&&native.image==='native-committed','native format return');await ok(n,'close');rows.push({case:'native-roundtrip',native});
      for(const index of [1,2])for(const after of [false,true]){
        const w=worker(),name=prefix+'-fault-'+index+'-'+after;
        await ok(w,'create',{name});const failure=await call(w,'replace',{expected:'0',value:'target',kind:'sync',index,after,action:'throw'});
        expect(!failure.ok&&/injected I\/O boundary/.test(failure.error),'fault did not fail: '+JSON.stringify(failure));
        const state=await call(w,'state');expect(!state.ok&&/closed/.test(state.error),'failed owner stayed usable');await ok(w,'close');
        const recovered=await reopen(w,name);pair(recovered);await ok(w,'close');rows.push({case:'io-failure',index,after,failure,state,recovered});
      }
      for(const index of [1,2])for(const after of [false,true]){
        const w=worker(),name=prefix+'-cut-'+index+'-'+after;await ok(w,'create',{name});
        const stopped=await cut(w,name,'replace',index,after);const recovery=worker();const recovered=await reopen(recovery,name);pair(recovered);await ok(recovery,'close');rows.push({case:'worker-termination',index,after,...stopped,recovered});
      }
      const w=worker(),name=prefix+'-one-phase';await ok(w,'create',{name});
      const stopped=await cut(w,name,'one-phase',1,true);const r=worker();const before=await ok(r,'hash',{name});const refusal=await call(r,'open',{name});
      expect(!refusal.ok&&/unclean redb image was not committed in two phases/.test(refusal.error),'one-phase image admitted: '+JSON.stringify(refusal));
      const after=await ok(r,'hash',{name});expect(before.sha256===after.sha256&&before.bytes===after.bytes,'refused image changed');
      rows.push({case:'one-phase-negative-control',...stopped,before,refusal,after});
      return {status:'passed',userAgent:navigator.userAgent,rows};
    } catch(e){return {status:'failed',error:String(e),rows}}
    finally {for(const w of workers){const e=probe.events(w).filter(x=>x.event==='error');if(e.length)rows.push({case:'worker-errors',errors:e});probe.terminate(w)}}
  });
  if(errors.length||result.rows.some(r=>r.case==='worker-errors'))result.status='failed';
  return {...result,pageErrors:errors};
}
