use redb::{Database,Durability,ReadableDatabase,ReadableTable,TableDefinition};
const TABLE:TableDefinition<&str,&[u8]>=TableDefinition::new("opfs-storage-probe/1");
fn main()->Result<(),Box<dyn std::error::Error>>{
 let path=std::env::args().nth(1).ok_or("path required")?;
 let db=Database::open(path)?;
 {let read=db.begin_read()?;let table=read.open_table(TABLE)?;
  if table.len()?!=2{return Err("unexpected row count".into())}
  if table.get("revision")?.ok_or("revision")?.value()!=1u64.to_be_bytes(){return Err("browser revision differs".into())}
  if table.get("image")?.ok_or("image")?.value()!=b"browser-committed"{return Err("browser payload differs".into())}}
 let mut tx=db.begin_write()?;tx.set_durability(Durability::Immediate)?;tx.set_two_phase_commit(true);
 {let mut table=tx.open_table(TABLE)?;table.insert("revision",2u64.to_be_bytes().as_slice())?;table.insert("image",b"native-committed".as_slice())?;}
 tx.commit()?;drop(db);println!("native-read-browser-and-commit:passed");Ok(())
}
