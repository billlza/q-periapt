import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path.cwd(); stage=root/'target/continuity-browser-opfs'; out=root/'research/sdk-alpha1/evidence/20261012-browser-redb-opfs'
def digest(b):return hashlib.sha256(b).hexdigest()
def result(name):
    text=(stage/name).read_text()
    return json.loads(text.split('### Result\n',1)[1].split('\n### ',1)[0])
r=result('acceptance3.stdout'); assert r['status']=='passed' and r['pageErrors']==[] and len(r['rows'])==11
rows=r['rows'];assert rows[0]['case']=='exclusive-and-reopen' and not rows[0]['busy']['ok'] and 'NoModificationAllowedError' in rows[0]['raw']['error']
assert rows[0]['replaced']['counts']['sync']==2
assert rows[1]['native']=={'revision':'2','image':'native-committed'}
for offset,kind in ((2,'io-failure'),(6,'worker-termination')):
    cases=rows[offset:offset+4];assert {(x['index'],x['after']) for x in cases}=={(1,False),(1,True),(2,False),(2,True)}
    for x in cases:
        assert x['case']==kind
        expected=('0','initial') if x['index']==1 else ('1','target')
        assert (x['recovered']['revision'],x['recovered']['image'])==expected
        if kind=='io-failure': assert not x['failure']['ok'] and 'injected I/O boundary' in x['failure']['error'] and x['state']['error']=='Error: closed'
        else: assert x['outcome']=={'ok':False,'error':'terminated'} and 0<=x['leaseReleaseMs']<12000
negative=rows[-1];assert negative['case']=='one-phase-negative-control' and negative['before']==negative['after']
assert not negative['refusal']['ok'] and 'not committed in two phases' in negative['refusal']['error']
assert negative['refusal']['counts']['write']==0
cleanup=result('cleanup-before.stdout');assert cleanup['version']=='154.0.8037.99' and cleanup['locks']=={'held':[],'pending':[]}
assert 'closed' in (stage/'browser-close.stdout').read_text().lower()
for pid in ('64905','66882'):
    p=subprocess.run(['ps','-p',pid,'-o','command='],capture_output=True,text=True)
    assert p.returncode==1 and not p.stdout.strip(),(pid,p.stdout)
assert '37 passed; 0 failed' in (stage/'native-filesystem.stdout').read_text()
assert (stage/'native2.stdout').read_text().strip()=='native-read-browser-and-commit:passed'
for log in ('check.stderr','build.stderr','build3.stderr','native2.stderr','native-filesystem.stderr'):assert 'warning:' not in (stage/log).read_text()
assert '0.2.129' in (stage/'probe/Cargo.toml').read_text()
files={}
for directory in ('probe','runtime2'):
    for p in sorted((stage/directory).rglob('*')):
        if p.is_file():files[str(p.relative_to(stage))]=p.read_bytes()
for p in sorted(stage.iterdir()):
    if p.is_file() and p.name!='seal.py':files[p.name]=p.read_bytes()
files['seal.py']=(stage/'seal.py').read_bytes()
assert len(files)<100, len(files)
files['final-source/database_format.rs']=(root/'crates/q-periapt-host-store/src/database_format.rs').read_bytes()
out.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(files.items()):z.writestr(name,body)
with zipfile.ZipFile(out/'CAPTURE.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(files)
    for name,body in files.items():assert z.read(name)==body
checks={'schema':'qpc-browser-redb-opfs-experiment/1','status':'storage-experiment-passed','baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'capture':{'path':'CAPTURE.zip','sha256':digest((out/'CAPTURE.zip').read_bytes()),'members':len(files)},'files':{n:digest(b) for n,b in sorted(files.items())},'runtime':cleanup,'nativeFilesystemTests':37,'cases':11,'browserContinuityAdmitted':False,'cleanup':{'webLocksReleased':True,'ownedBrowserClosed':True,'ownedServerPidsAbsent':[64905,66882]}}
for name,value in [('CHECKS.json',checks),('RESULT.json',r)]:
    with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({k:checks[k] for k in ('status','capture','nativeFilesystemTests','cases','cleanup')},indent=2))
