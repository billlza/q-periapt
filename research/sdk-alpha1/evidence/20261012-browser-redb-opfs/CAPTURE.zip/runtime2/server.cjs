const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const files=new Map([['/native.redb','native.redb'],['/','index.html'],['/index.html','index.html'],['/worker.mjs','worker.mjs'],['/pkg/opfs.js','pkg/opfs.js'],['/pkg/qpc_opfs_probe.js','pkg/qpc_opfs_probe.js'],['/pkg/qpc_opfs_probe_bg.wasm','pkg/qpc_opfs_probe_bg.wasm']]);
const server=http.createServer((req,res)=>{
 const route=new URL(req.url,'http://127.0.0.1').pathname;
 if(req.method==='POST'&&route==='/capture'){
  let length=0,chunks=[];req.on('data',b=>{length+=b.length;if(length>64*1024*1024){req.destroy();return}chunks.push(b)});
  req.on('end',()=>{try{fs.writeFileSync(path.join(__dirname,'browser.redb'),Buffer.concat(chunks),{flag:'wx',mode:0o600});res.writeHead(201);res.end('captured')}catch(e){console.error(e);res.writeHead(500);res.end('capture failed')}});return;
 }
 const file=files.get(route);if(req.method!=='GET'||!file){res.writeHead(404);res.end('not found');return}
 try{res.writeHead(200,{'Content-Type':file.endsWith('.wasm')?'application/wasm':file.endsWith('.html')?'text/html':'application/javascript','Cache-Control':'no-store'});res.end(fs.readFileSync(path.join(__dirname,file)))}catch(e){console.error(e);res.writeHead(500);res.end('read failed')}
});server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port+'/',pid:process.pid})));
