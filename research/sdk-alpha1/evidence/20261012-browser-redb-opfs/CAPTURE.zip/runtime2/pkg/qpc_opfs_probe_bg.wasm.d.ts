/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_storageprobe_free: (a: number, b: number) => void;
export const storageprobe_close: (a: number) => [number, number];
export const storageprobe_image: (a: number) => [number, number, number, number];
export const storageprobe_one_phase_negative_control: (a: number, b: bigint, c: any) => [number, number];
export const storageprobe_open: (a: number, b: number) => [number, number, number];
export const storageprobe_replace: (a: number, b: bigint, c: any) => [number, number];
export const storageprobe_revision: (a: number) => [bigint, number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
