async(page)=>{
 await page.waitForFunction(()=>globalThis.probe);const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 return await page.evaluate(async()=>{
  const w=probe.create(),r=[],name='basic-'+Date.now();
  r.push(await probe.call(w,{command:'create',name}));
  if(!r[0].ok)return r;
  r.push(await probe.call(w,{command:'replace',expected:'0',value:'browser-committed'}));
  r.push(await probe.call(w,{command:'close'}));
  r.push(await probe.call(w,{command:'open',name}));
  r.push(await probe.call(w,{command:'close'}));
  r.push(await probe.call(w,{command:'snapshot',name}));
  probe.terminate(w);return r;
 });
}
