import init,{StorageProbe} from './pkg/qpc_opfs_probe.js';
import * as io from './pkg/opfs.js';
let owner,slot,name;
const ready=init();
self.onmessage=async({data})=>{
 const {id,command}=data;let lastCounts=null;
 try{
  await ready;let result;
  if(command==='open'||command==='create'){
   if(owner)throw new Error('already open');name=data.name;slot=undefined;slot=await io.acquire(name,command==='create');
   try{owner=StorageProbe.open(slot,command==='create')}catch(e){lastCounts=io.stats(slot);await io.abortPrepared(slot);slot=undefined;throw e}
   result={revision:owner.revision().toString(),image:new TextDecoder().decode(owner.image()),counts:io.stats(slot)};
  }else if(command==='replace'){
   io.fault(slot,data.kind??'none',data.index??0,data.after??false,data.action??'throw');
   owner.replace(BigInt(data.expected),new TextEncoder().encode(data.value));
   result={revision:owner.revision().toString(),image:new TextDecoder().decode(owner.image()),counts:io.stats(slot)};
  }else if(command==='close'){
   if(owner){owner.close();owner.free();owner=undefined;result=io.stats(slot);await io.finish(slot);slot=undefined}else result={alreadyClosed:true};
  }else if(command==='raw-lock'){result=await io.rawLock(data.name)}
  else if(command==='snapshot'){
   const bytes=await io.snapshot(data.name);const response=await fetch('/capture',{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:bytes});
   if(!response.ok)throw new Error('capture failed');result={bytes:bytes.length};
  }else throw new Error('unknown command');
  self.postMessage({id,ok:true,result});
 }catch(e){self.postMessage({id,ok:false,error:String(e),counts:slot?io.stats(slot):lastCounts})}
};
