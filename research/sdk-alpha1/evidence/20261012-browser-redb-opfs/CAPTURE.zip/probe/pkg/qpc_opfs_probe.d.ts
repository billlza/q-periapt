/* tslint:disable */
/* eslint-disable */

export class StorageProbe {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    close(): void;
    image(): Uint8Array;
    static open(slot: number, create: boolean): StorageProbe;
    replace(expected: bigint, bytes: Uint8Array): void;
    revision(): bigint;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_storageprobe_free: (a: number, b: number) => void;
    readonly storageprobe_close: (a: number) => [number, number];
    readonly storageprobe_image: (a: number) => [number, number, number, number];
    readonly storageprobe_open: (a: number, b: number) => [number, number, number];
    readonly storageprobe_replace: (a: number, b: bigint, c: any) => [number, number];
    readonly storageprobe_revision: (a: number) => [bigint, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
