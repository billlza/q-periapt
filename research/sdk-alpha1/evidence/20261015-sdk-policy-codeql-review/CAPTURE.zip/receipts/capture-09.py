from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
report=json.loads((stage/'DISPOSITIONS_08.json').read_text());tests=json.loads((stage/'TESTS_07.json').read_text())
sdk.require(tests['completed'] and tests['tests']==5,'targeted verification incomplete')
files={}
def add(path,name):
 sdk.require(name not in files and not path.is_symlink(),'duplicate/symlink capture')
 files[name]=sdk.snapshot(path,maximum=32*1024**2).data
for path in stage.iterdir():
 if path.is_file() and path.suffix in {'.py','.json','.stdout','.stderr','.txt'} and path.name not in {'alerts-01.stdout','sarif-02.stdout'}:
  add(path,'receipts/'+path.name)
add(stage/'sarif-02.stdout','analysis/rust.sarif')
for directory in ['sources-04','supplemental-06']:
 for path in (stage/directory).rglob('*'):
  if path.is_file():add(path,directory+'/'+path.relative_to(stage/directory).as_posix())
for source in report['source_comparison']+report['supplemental_sources']:
 sdk.require(sdk.snapshot(root/source['path']).sha256==source['current_sha256'],'reviewed source changed')
out=root/'research/sdk-alpha1/evidence/20261015-sdk-policy-codeql-review';out.mkdir()
with zipfile.ZipFile(out/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
 for name,data in sorted(files.items()):
  item=zipfile.ZipInfo(name);item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
  archive.writestr(item,data)
manifest={'source_commit':report['comparison_commit'],'analysis_commit':report['analysis_merge'],'analysis_id':report['analysis_id'],
 'capture_sha256':sdk.snapshot(out/'CAPTURE.zip',maximum=64*1024**2).sha256,
 'sarif_sha256':report['sarif_sha256'],'members':{n:hashlib.sha256(d).hexdigest() for n,d in sorted(files.items())},
 'reviewed_alert_numbers':[700,537],'reviewed_results':[789,792],'supplied_flow_threads':8,'supplied_flow_locations':292,
 'tests_passed':5,'remote_dismissal_performed':False,'release_claim_eligible':False}
sdk.write_json(out/'CAPTURE.json',manifest);sdk.write_json(out/'DISPOSITIONS.json',report)
with zipfile.ZipFile(out/'CAPTURE.zip') as archive:
 sdk.require(set(archive.namelist())==set(files) and len(archive.namelist())==len(files),'archive inventory differs')
 for name,digest in manifest['members'].items():sdk.require(hashlib.sha256(archive.read(name)).hexdigest()==digest,'archive member hash differs')
 raw=archive.read('analysis/rust.sarif');sdk.require(hashlib.sha256(raw).hexdigest()==report['sarif_sha256'],'raw analysis changed')
 retained=json.loads(raw)['runs'][0]['results'];selected=json.loads(archive.read('receipts/SELECTED_04.json'))
 sdk.require(len(retained)==878 and all(retained[i]==selected['results'][str(i)] for i in [789,792]),'selected reports do not match raw analysis')
 sdk.require(selected['flows']==json.loads(files['receipts/SELECTED_04.json'])['flows'],'reported flows changed')
 for source in report['source_comparison']:
  for kind in ['analysis','current']:
   sdk.require(hashlib.sha256(archive.read('sources-04/'+kind+'/'+source['path'])).hexdigest()==source[kind+'_sha256'],'source comparison differs')
 for label,expected in [('sealed',4),('entropy',1)]:
  receipt=json.loads(archive.read('receipts/test-07-'+label+'.json'))
  sdk.require(receipt['returncode']==0 and f'test result: ok. {expected} passed; 0 failed; 0 ignored;'.encode() in archive.read('receipts/test-07-'+label+'.stdout'),'test terminal differs')
sdk.write_json(out/'READBACK.json',{'completed':True,'members':len(files),'capture_sha256':manifest['capture_sha256'],'raw_results':878,'selected_results':2,'reported_flow_threads':8,'reported_flow_locations':292,'source_pairs':len(report['source_comparison'])+len(report['supplemental_sources']),'tests':5,'remote_alerts_changed':False})
print('Scoped SDK policy-value review archived and independently reread:',len(files),'members')
