from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
prepared=json.loads((root/'target/continuity-apple-roster-cache-20261015/PREPARED_03.json').read_text())
env=dict(prepared['environment'],CARGO_TARGET_DIR=str(stage/'sdk-build-07'))
cargo=str(Path(env['RUSTC']).parent/'cargo')
for label,filter,expected in [('sealed','sealed_',4),('entropy','entropy_failure_returns_quota_and_never_publishes_a_key_or_result',1)]:
 out=sdk.command([cargo,'test','--locked','--offline','-p','q-periapt-sdk','--features','sealed-operations','--lib',filter,'-j','2','--','--nocapture'],stage/('test-07-'+label),root,environment=env)
 sdk.require(f'test result: ok. {expected} passed; 0 failed; 0 ignored;'.encode() in out,'selected tests missing')
sdk.write_json(stage/'TESTS_07.json',{'completed':True,'tests':5,'source_commit':'abc731a11e60c91c30bbaa362eb36095c0157c93','scope':'Existing SDK sealed-operation binding/authentication/revocation and entropy-failure tests; not whole-program information-flow proof or a new CodeQL analysis.'})
print('Five existing SDK replay/entropy boundary tests passed')
