from pathlib import Path
from collections import defaultdict
import hashlib,json,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
raw=sdk.snapshot(stage/'sarif-02.stdout');sarif=json.loads(raw.data);run=sarif['runs'][0]
sdk.require(len(run['results'])==878,'unexpected retained result inventory')
selected={i:run['results'][i] for i in [789,792]};locations=defaultdict(set);flows=[]
for index,result in selected.items():
 sdk.require(result['ruleId']=='rust/hard-coded-cryptographic-value','wrong selected rule')
 for loc in result.get('locations',[])+result.get('relatedLocations',[]):
  p=loc['physicalLocation'];locations[p['artifactLocation']['uri']].add(p['region']['startLine'])
 for ci,flow in enumerate(result['codeFlows']):
  for ti,thread in enumerate(flow['threadFlows']):
   steps=[]
   for si,item in enumerate(thread['locations']):
    loc=item['location'];p=loc.get('physicalLocation')
    sdk.require(p is not None,'unlocated supplied flow')
    path=p['artifactLocation']['uri'];line=p['region']['startLine'];locations[path].add(line)
    steps.append({'index':si,'file':path,'line':line,'message':loc.get('message',{}).get('text','')})
   flows.append({'result_index':index,'code_flow':ci,'thread_flow':ti,'steps':steps})
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();old='760da743a40e1a5876e973308c2341d2b000eeff'
sdk.require(head=='abc731a11e60c91c30bbaa362eb36095c0157c93','comparison head changed')
additional=['research/continuity-identity-candidate/src/bootstrap/staged.rs','research/continuity-identity-candidate/src/bootstrap/response_staged.rs','research/continuity-identity-candidate/src/durable.rs','research/continuity-identity-candidate/src/lib.rs']
for name in additional:locations[name]
identities=[];excerpts=[]
for name,lines in sorted(locations.items()):
 prior=subprocess.check_output(['git','show',old+':'+name]);current=sdk.snapshot(root/name).data
 for label,data in [('analysis',prior),('current',current)]:
  dest=stage/'sources-04'/label/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as output:output.write(data)
 identities.append({'path':name,'analysis_sha256':hashlib.sha256(prior).hexdigest(),'current_sha256':hashlib.sha256(current).hexdigest(),'same':prior==current,'reported_lines':sorted(lines)})
 oldlines=prior.decode().splitlines()
 for line in sorted(lines):excerpts.append(f'{name}:{line}: '+oldlines[line-1])
sdk.write_json(stage/'SELECTED_04.json',{'analysis_id':1930866657,'analysis_merge':old,'comparison_commit':head,'sarif_sha256':raw.sha256,'analysis_results':878,'results':selected,'flows':flows,'sources':identities})
with (stage/'FLOW_LINES_04.txt').open('x') as f:f.write('\n'.join(excerpts)+'\n')
print('flows',len(flows),'steps',sum(len(f['steps']) for f in flows),'files',len(identities))
print('changed source files',[r['path'] for r in identities if not r['same']])
for flow in flows:
 sequence=[]
 for s in flow['steps']:
  value=(s['file'],s['line'])
  if not sequence or sequence[-1]!=value:sequence.append(value)
 print('flow',flow['result_index'],flow['code_flow'],'steps',len(flow['steps']),'first',sequence[:5],'last',sequence[-4:])
