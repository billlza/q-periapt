from pathlib import Path
import hashlib,json,re,subprocess
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
selected=json.loads((stage/'SELECTED_04.json').read_text());alerts=json.loads((stage/'ALERTS_06.json').read_text())
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==selected['comparison_commit'],'comparison head drifted')
for source in selected['sources']+json.loads((stage/'SUPPLEMENTAL_06.json').read_text()):
 sdk.require(sdk.snapshot(root/source['path']).sha256==source['current_sha256'],'reviewed source changed')
for number,index in [(700,789),(537,792)]:
 a=alerts[str(number)]['most_recent_instance'];r=selected['results'][str(index)];loc=r['locations'][0]['physicalLocation']
 sdk.require(a['commit_sha']==selected['analysis_merge'] and a['location']['path']==loc['artifactLocation']['uri'] and a['location']['start_line']==loc['region']['startLine'],'alert/result identity mismatch')
 sdk.require(a['message']['text']==re.sub(r'\[([^\]]+)\]\([0-9]+\)',r'\1',r['message']['text']),'alert/result sink list mismatch')
def anchor(path,needle):
 lines=(root/path).read_text().splitlines();hits=[i+1 for i,t in enumerate(lines) if needle in t]
 sdk.require(bool(hits),'source anchor missing: '+needle)
 return {'path':path,'lines':hits,'text':needle}
report={'schema_version':1,'analysis_id':1930866657,'analysis_merge':selected['analysis_merge'],
 'comparison_commit':selected['comparison_commit'],'analysis_results':878,'open_pr_alerts_observed':1761,
 'sarif_sha256':selected['sarif_sha256'],'reviewed_result_indices':[789,792],'reviewed_alert_numbers':[700,537],
 'supplied_flow_threads':len(selected['flows']),'supplied_flow_locations':sum(len(f['steps']) for f in selected['flows']),
 'method':'Read every supplied flow location and the owning methods, each named sink, nonce generation/restoration, policy binding construction, JournalKey construction and current changed ownership paths. This is a bounded static disposition, not a new whole-program analysis.',
 'dispositions':[
 {'alert':700,'sarif_index':789,'classification':'false positive for hard-coded key at the two named journal cipher sinks',
 'source':'Runtime::is_enabled returns Result<bool> from a Configuration variant match. PolicyPin::verify and VerifiedSessionPolicy::check_mode use it as a refusal condition and retain the original runtime/historical policy; check_mode returns Result<()> rather than key bytes.',
 'sink':'Both seal and unseal_image initialize XChaCha20Poly1305 from key.0.as_bytes() of their separately supplied JournalKey. Active retains that key, and seal_next_image borrows it. The C consumer loads wrap.key before activation and passes that owner through installation/journal constructors.',
 'flow_join':'The reported path crosses policy admission, the containing service/journal owner, and its independent key field. It does not establish an assignment from the boolean to JournalKey bytes.',
 'required_behavior':'Keep enablement/current-policy refusal checks; removing them or randomizing the boolean would not fix a key source.'},
 {'alert':537,'sarif_index':792,'classification':'false positive for hard-coded nonce/key at all five named sinks',
 'source':'Runtime::policy_binding initializes 68 bytes, then overwrites all 32 root-digest bytes and all 36 encoded trusted-policy-state bytes before return. It is intentionally public deterministic application-policy identity, not secret material or entropy.',
 'nonce_sinks':'InitiationPlan::reserve and ResponsePlan::reserve use bootstrap::nonce(), which fills a separate 32-byte array through getrandom and propagates failure. Their private decode functions restore that distinct nonce field from the authenticated durable plan. The three reported prefix calls borrow self.nonce, not the SDK policy binding.',
 'sealed_operation_boundary':'The policy binding occupies an authenticated wire header. RecoveryKey::reserve independently fills operation entropy and a 24-byte AEAD nonce; open validates the exact binding and authenticates the ciphertext before returning entropy. Neither converts the binding into a bootstrap nonce or journal key.',
 'key_sinks':'The same two JournalKey-backed cipher constructors as alert700 remain separate from policy metadata. Fresh key creation fills all 32 bytes before publication; reopen/decode copies the exact retained 32-byte key payload and propagates shape/read errors.',
 'required_behavior':'Keep deterministic policy identity, complete overwrite, entropy-error propagation and authenticated exact replay. Rejecting zero bytes in this public metadata or regenerating nonce during recovery would change the intended contract.'}],
 'source_comparison':selected['sources'],
 'supplemental_sources':json.loads((stage/'SUPPLEMENTAL_06.json').read_text()),
 'current_anchors':[
 anchor('crates/q-periapt-sdk/src/lib.rs','pub fn policy_binding('),anchor('crates/q-periapt-sdk/src/lib.rs','pub fn is_enabled('),
 anchor('crates/q-periapt-sdk/src/expert/replay.rs','let mut wire = binding('),anchor('crates/q-periapt-sdk/src/expert/replay.rs','let expected = binding('),
 anchor('research/continuity-identity-candidate/src/session_policy.rs','!runtime.is_enabled()?'),anchor('research/continuity-identity-candidate/src/session_policy.rs','!self.runtime.is_enabled()?'),
 anchor('research/continuity-identity-candidate/src/bootstrap.rs','fn nonce()'),anchor('research/continuity-identity-candidate/src/bootstrap/staged.rs','nonce: nonce()?'),
 anchor('research/continuity-identity-candidate/src/bootstrap/response_staged.rs','let nonce = nonce()?'),
 anchor('research/continuity-identity-candidate/src/durable.rs','XChaCha20Poly1305::new_from_slice(key.0.as_bytes())'),
 anchor('research/continuity-identity-candidate/src/durable.rs','pub(crate) fn prepare_file()'),anchor('research/continuity-identity-candidate/src/durable.rs','pub(crate) fn decode_file('),
 anchor('bindings/c/ContinuityPackageConsumer/src/device.rs','p::JournalKey::open(')],
 'limits':['Nine of the 17 supplied-flow/sink source files changed between the analyzed and current commits. Their original and current bytes are retained; no claim of whole-file equality or inherited current CodeQL acceptance is made.',
 'The current key-source, nonce-source, policy guard and ownership transfer paths were reread; this does not review every change in those nine files.',
 'The result contains four supplied flow threads per alert; related sink locations are checked even where no separate thread is supplied.',
 'Stored fresh material can remain exposed after a retained-state compromise. This review does not establish post-compromise recovery, cryptographic erasure, same-UID storage isolation or global nonce uniqueness.',
 'Only these two identified reports receive a disposition. No subtraction from unrelated or earlier inventories and no aggregate security-pass claim.'],
 'product_modified':False,'remote_dismissal_performed':False,'queries_or_severity_changed':False,'release_claim_eligible':False}
sdk.write_json(stage/'DISPOSITIONS_08.json',report)
print('Two exact SDK hard-coded-value reports disposed; 8 supplied flows / 292 locations retained; no product or remote alert change')
