from pathlib import Path
from collections import Counter
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
raw=sdk.command(['gh','api','--paginate','--slurp','repos/billlza/q-periapt/code-scanning/alerts?state=open&per_page=100&ref=refs/pull/111/merge'],stage/'alerts-01',root)
pages=json.loads(raw);rows=[r for page in pages for r in page]
sdk.require(len(rows)==len({r['number'] for r in rows}),'duplicate alert inventory')
summary={'open_alerts':len(rows),'by_rule':dict(Counter(r['rule']['id'] for r in rows)),
 'source_instances':dict(Counter(r['most_recent_instance']['commit_sha'] for r in rows)),
 'candidates':[{'number':r['number'],'rule':r['rule']['id'],'severity':r['rule']['security_severity_level'],
  'path':r['most_recent_instance']['location']['path'],'line':r['most_recent_instance']['location']['start_line'],
  'commit':r['most_recent_instance']['commit_sha']} for r in rows if r['most_recent_instance']['location']['path'].startswith('crates/') and '/src/' in r['most_recent_instance']['location']['path'] and '/tests' not in r['most_recent_instance']['location']['path']]}
sdk.write_json(stage/'INVENTORY_01.json',summary)
print(json.dumps(summary,indent=2))
