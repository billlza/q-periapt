from pathlib import Path
import os,sys,subprocess,json,time,hashlib
b=Path(__file__).resolve().parent;label,profile=sys.argv[1:];out=b/label;out.mkdir();source=b/'swift-publication-source';native=b/('swift-publication-installed-native-'+profile)
env={k:v for k,v in os.environ.items() if not k.startswith(('SWIFT','CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))};env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cmd=['/usr/bin/xcrun','swift','test','--package-path',str(source),'--scratch-path',str(b/('swift-publication-build-'+profile)),'--configuration',profile,'-j','2','-Xswiftc','-warnings-as-errors','-Xswiftc','-strict-concurrency=complete','-Xcc','-I'+str(source/'native/include'),'-Xlinker','-L'+str(native),'-Xlinker','-rpath','-Xlinker',str(native)]
t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,env=env,stdout=so,stderr=se,timeout=900)
r=dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-t);(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((out/'stderr.log').read_text()[-7000:]);print((out/'stdout.log').read_text()[-1500:]);p.check_returncode()
