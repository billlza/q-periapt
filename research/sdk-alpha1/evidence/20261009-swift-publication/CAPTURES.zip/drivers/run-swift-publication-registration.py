from pathlib import Path
import os,subprocess,sys,json,time,hashlib
b=Path(__file__).resolve().parent;root=b.parents[1];label,profile=sys.argv[1:];out=b/label;out.mkdir(mode=0o700)
build='publication-c-test-build-'+profile+('-03' if profile=='debug' else '-02');r=json.loads((b/build/'RESULT.json').read_text());assert r['returncode']==0
artifacts=[json.loads(line) for line in (b/build/'stdout.log').read_text().splitlines()]
paths=[Path(r['executable']) for r in artifacts if r.get('reason')=='compiler-artifact' and r['target']['name']=='enrollment' and r.get('executable')];assert len(paths)==1;harness=paths[0]
client=b/('swift-publication-build-'+profile)/profile/'ContinuityClient';native=b/('swift-publication-installed-native-'+profile)/'libq_periapt_continuity_c_consumer.dylib';assert client.is_file() and native.is_file()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
inputs={str(p):sha(p) for p in [harness,client,native]}
source={str(p.relative_to(b/'swift-publication-source')):sha(p) for p in (b/'swift-publication-source').rglob('*') if p.is_file()}
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))};env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_C_OWNER_CLIENT=str(client),QPERIAPT_INSTALLED_CLIENT_LANGUAGE='Swift',QPERIAPT_EXPECTED_CONTINUITY_LIBRARY=str(native),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(out/'evidence'))
cmd=[str(harness),'--exact','c_registered_publication_recovers_exact_artifact_before_normal_connection','--nocapture'];t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,cwd=b/'publication-consumer',env=env,stdout=so,stderr=se,timeout=300)
r={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-t,'binaries':inputs,'binaries_unchanged':all(sha(Path(path))==h for path,h in inputs.items()),'swift_inputs':source,'swift_inputs_unchanged':all(sha(b/'swift-publication-source'/path)==h for path,h in source.items()),'scope':'Actual Swift public owner/CLI through shared native C engine. This run does not execute the C CLI short-buffer probe; C boundary unit/component checks provide that evidence separately.'}
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ('swift_inputs','binaries')}));print((out/'stderr.log').read_text()[-5000:]);assert r['binaries_unchanged'] and r['swift_inputs_unchanged'];p.check_returncode()
