from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = Path(__file__).resolve().parents[2]
REPO = SOURCE.parents[2]
ROOT = REPO / 'target/continuity-fanout-resources-20261106'
DEST = REPO / 'research/sdk-alpha1/evidence/20261106-installed-fanout-observer'
build = json.loads((ROOT/'build-01/OBSERVER_BUILD.json').read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True
outside = Path(json.loads((ROOT/'build-01/LOCATION.json').read_bytes())['path'])
files = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink()
    files[name] = path

def tree(prefix, directory):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            add(prefix+'/'+path.relative_to(directory).as_posix(),path)

tree('build-01',ROOT/'build-01')
for name,digest in build['observer_source'].items():
    path = outside/'observer'/name
    assert sha(path.read_bytes()) == digest
    add('observer/'+name,path)
binary = Path(build['binary'])
assert sha(binary.read_bytes()) == build['binary_sha256']
add('binary/journal_fanout',binary)
for name,record in build['archives'].items():
    version = '0.0.0' if name == 'q-periapt-continuity-identity-candidate' else '0.2.0'
    directory = SOURCE / ('target/continuity-installed-rust-current' if version=='0.0.0' else 'target/sdk-020/crates')
    path = directory/(name+'-'+version+'.crate')
    assert path.stat().st_size == record['bytes'] and sha(path.read_bytes()) == record['sha256']
    add('archives/'+path.name,path)
for name,relative in [('RUST_SDK_PACKAGE.json','target/sdk-020/RUST_SDK_PACKAGE.json'),
    ('CONTINUITY_PACKAGE.json','target/continuity-installed-rust-current/CONTINUITY_PACKAGE.json')]:
    add('archives/'+name,SOURCE/relative)
labels = ['validation-'+profile+'-'+layout+'-01' for profile in ('local','witness') for layout in ('peer','own')]
for label in labels:
    directory = ROOT/label
    run = json.loads((directory/'RUN.json').read_bytes())
    assert run['completed'] is True and run['performance_qualified'] is False and run['release_claim_eligible'] is False
    assert run['driver_sha256'] == sha((SOURCE/'target/current-rust-readback/run-fanout-smoke.py').read_bytes())
    assert sha((directory/'RESULT.json').read_bytes()) == run['result_sha256']
    assert (directory/'readback.stderr').read_bytes() == b''
    tree('cohorts/'+label,directory)
for name in ('build-fanout-observer.py','run-fanout-smoke.py','readback-fanout.py','capture-fanout.py'):
    add('controller/'+name,SOURCE/'target/current-rust-readback'/name)
for name in ('fanout-observer-build','fanout-local-peer-controller','fanout-witness-peer-controller',
    'fanout-local-own-controller','fanout-witness-own-controller'):
    for suffix in ('stdout','stderr'):
        add('controller/'+name+'.'+suffix,SOURCE.parent/(name+'.'+suffix))
reader_source = {}
for name in ('python-run.sh','python-env.sh','python_bootstrap.py','evidence_io.py'):
    relative = 'artifact/'+name
    path = SOURCE/relative
    original = subprocess.run(['git','show',build['source_commit']+':'+relative],cwd=SOURCE,
        check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    assert original.stderr == b'' and original.stdout == path.read_bytes()
    add('reader-source/'+relative,path)
    reader_source[relative] = {'bytes':len(original.stdout),'sha256':sha(original.stdout)}
DEST.mkdir()
manifest = {}
with zipfile.ZipFile(DEST/'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):
        data = path.read_bytes()
        manifest[name] = {'bytes':len(data),'sha256':sha(data)}
        archive.writestr(name,data)
with zipfile.ZipFile(DEST/'CAPTURE.zip') as archive:
    assert len(archive.namelist()) == len(manifest) and set(archive.namelist()) == set(manifest)
    for name,expected in manifest.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
for label in labels:
    (DEST/(label.removeprefix('validation-').removesuffix('-01').upper().replace('-','_')+'_READBACK.json')).write_bytes(
        (ROOT/label/'READBACK.json').read_bytes())
(DEST/'readback.py').write_bytes((SOURCE/'target/current-rust-readback/readback-fanout.py').read_bytes())
(DEST/'FILES.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(DEST/'READER_SOURCE.json').write_text(json.dumps({'source_commit':build['source_commit'],
    'git_matched_files':reader_source},indent=2,sort_keys=True)+'\n')
summary = {'source_commit':build['source_commit'],'sdk_report_sha256':build['sdk_report_sha256'],
    'observer_binary_sha256':build['binary_sha256'],'bytes':(DEST/'CAPTURE.zip').stat().st_size,
    'sha256':sha((DEST/'CAPTURE.zip').read_bytes()),'members':len(manifest),'cohorts':4,
    'synthetic_business_files':104,'performance_qualified':False,'release_claim_eligible':False,
    'scope':'Actual installed two-recipient fanout observer; four functional cohorts, original source/build/strict checks, ten installed archives, binary, emitted spans, exact Witness counters and public business files. No private keys/stores, ciphertext replay archive, controlled performance or frozen budget claim.'}
(DEST/'CAPTURE.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary))
