from pathlib import Path
import datetime
import json
import os
import platform
import re
import subprocess
import sys
import time

import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
SOURCE = package.ROOT
REPO = SOURCE.parents[2]
STAGE = REPO / 'target/continuity-fanout-resources-20261106'
label, profile, layout = sys.argv[1:]
assert re.fullmatch(r'validation-(?:local|witness)-(?:own|peer)-[0-9]{2}', label)
assert profile in {'local', 'witness'} and layout in {'own', 'peer'}
assert label.startswith('validation-' + profile + '-' + layout + '-')
build_file = STAGE / 'build-01/OBSERVER_BUILD.json'
build = json.loads(build_file.read_bytes())
assert build['completed'] is True and build['sources_unchanged'] is True
assert build['tests_executed'] is False and build['release_claim_eligible'] is False
assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (build['source_commit'], False)
outside = Path(json.loads((STAGE / 'build-01/LOCATION.json').read_bytes())['path'])
consumer = outside / 'observer'
binary = Path(build['binary'])
sdk_report_path = SOURCE / 'target/sdk-020/RUST_SDK_PACKAGE.json'
assert sdk.snapshot(sdk_report_path).sha256 == build['sdk_report_sha256']
sdk_report = json.loads(sdk_report_path.read_bytes())
candidate_root = SOURCE / 'target/continuity-installed-rust-current'
candidate = json.loads((candidate_root / 'CONTINUITY_PACKAGE.json').read_bytes())

def verify_inputs():
    assert sdk.snapshot(binary, maximum=256 * 1024**2).sha256 == build['binary_sha256']
    for name, digest in build['observer_source'].items():
        assert sdk.snapshot(consumer / name).sha256 == digest
    for name, record in build['archives'].items():
        if name == package.NAME:
            source = candidate_root / candidate['archive']['file']
            archived = sdk.snapshot(source)
            members = package.validate_candidate(archived.data, set(candidate['archive']['files']))
            version = package.VERSION
        else:
            source = sdk_report_path.parent / 'crates' / sdk_report['crates'][name]['file']
            archived = sdk.snapshot(source)
            members = sdk.archive_files(archived.data, name)
            version = sdk.VERSION
        assert archived.sha256 == record['sha256'] and archived.size == record['bytes']
        assert len(members) == record['members']
        folder = consumer / 'packages' / (name + '-' + version)
        assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()} == set(members)
        for relative, data in members.items():
            assert sdk.snapshot(folder / relative).data == data

verify_inputs()
OUT = STAGE / label
OUT.mkdir(mode=0o700)
private = outside / (label + '-private')
private.mkdir(mode=0o700)
env = {k: v for k, v in os.environ.items() if not k.startswith(('DYLD_', 'LD_', 'QPC_', 'QPERIAPT_'))}
env.update(QPC_JOURNAL_PROFILE=profile, QPC_FANOUT_LAYOUT=layout,
    QPC_JOURNAL_OUTPUT=str(OUT / 'RESULT.json'),
    QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(private / 'installation'), RUST_BACKTRACE='1')
processes = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pcpu,pmem,etime,comm'], check=True,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
assert processes.stderr == b''
concurrent = [line for line in processes.stdout.decode().splitlines()
    if re.search(r'qperiapt-continuity-package-|/(?:rustc|cargo|java)$', line)]
record = {'completed': False, 'source_commit': build['source_commit'], 'profile': profile, 'layout': layout,
    'binary_sha256': build['binary_sha256'], 'build_report_sha256': sdk.snapshot(build_file).sha256,
    'driver_sha256': sdk.snapshot(Path(__file__)).sha256,
    'observer_source': build['observer_source'], 'private_runtime': str(private),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'platform': platform.platform(), 'machine': platform.machine(), 'load_before': os.getloadavg(),
    'allocator_environment': {k: v for k, v in os.environ.items() if k.startswith('Malloc')},
    'concurrent_task_processes': concurrent,
    'host_controls': 'Functional observer validation only. Other qualification processes may overlap; no power, thermal, allocator or other application controls were changed.',
    'performance_qualified': False, 'release_claim_eligible': False,
    'scope': 'Validate the installed two-recipient fanout observer and preserve raw observations; no controlled timing comparison, 32-recipient capacity or frozen resource budget.'}
started = time.monotonic()
try:
    hardware = sdk.command(['/usr/sbin/sysctl', 'hw.model', 'hw.ncpu', 'hw.memsize', 'machdep.cpu.brand_string'],
        OUT / 'hardware', SOURCE, environment=env)
    record['hardware'] = hardware.decode()
    stdout = sdk.command(['/usr/bin/time', '-l', '-o', str(OUT / 'time.txt'), str(binary),
        '--exact', 'measure_installed_fanout', '--nocapture', '--test-threads=1'],
        OUT / 'runtime', consumer, environment=env)
    assert re.search(rb'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out;', stdout, re.M)
    assert ('FANOUT_RESOURCE_COMPLETE profile=' + profile + ' layout=' + layout + ' ordinary=12 effects=26').encode() in stdout
    result = json.loads((OUT / 'RESULT.json').read_bytes())
    assert result['completed'] is True and result['profile'] == profile and result['layout'] == layout
    assert result['ordinary_batches'] == 12 and result['ordinary_member_deliveries'] == 24
    assert result['recipient_count'] == len(result['servers']) == 2
    assert len(result['effects']) == 26 and result['total_batches'] == 13 and len(result['spans']) == 89
    assert all(row['closed'] is True and row['effects'] == 13 for row in result['servers'])
    assert [row['calls'] for row in result['servers']] == [14, 13]
    verify_inputs()
    assert sdk.inspect_package_source(SOURCE, allow_dirty=False) == (build['source_commit'], False)
    record.update(completed=True, sources_unchanged=True,
        result_sha256=sdk.snapshot(OUT / 'RESULT.json', maximum=32 * 1024**2).sha256)
except BaseException as error:
    record['failure'] = str(error)
    raise
finally:
    record.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        seconds=time.monotonic() - started, load_after=os.getloadavg(), private_runtime_preserved=True)
    sdk.write_json(OUT / 'RUN.json', record)
print(json.dumps({'completed': record['completed'], 'profile': profile, 'layout': layout,
    'performance_qualified': False}), flush=True)
