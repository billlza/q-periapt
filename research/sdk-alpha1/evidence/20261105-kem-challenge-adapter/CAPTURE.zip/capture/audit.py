from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-kem-challenge-adapter'
PIN='baa4e975a2502cbb2a33e1e18dd19b37be663abe'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==PIN
names=[
    'research/continuity-identity-candidate/src/crypto.rs',
    'research/continuity-identity-candidate/src/durable.rs',
    'research/continuity-identity-candidate/src/durable/write_intent.rs',
    'research/continuity-identity-candidate/src/durable/messages.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/driver.rs',
    'crates/q-periapt-sdk/src/expert/replay.rs','crates/q-periapt-sdk/src/lib.rs',
    'crates/q-periapt-kem/src/lib.rs','crates/q-periapt-core/src/lib.rs',
    'docs/continuity/STORAGE_RECOVERY_V1.md',
]
sources={}
inventory={}
for name in names:
    data=(ROOT/name).read_bytes()
    assert data==subprocess.check_output(['git','show',PIN+':'+name]),name
    sources[name]=data.decode()
    inventory[name]={'bytes':len(data),'sha256':sha(data)}
    p=BASE/'source'/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(data)

def sequence(name,start,needles):
    text=sources[name]
    cursor=text.index(start)
    points=[]
    for label,needle in needles:
        index=text.index(needle,cursor)
        points.append({'step':label,'line':text.count('\n',0,index)+1,'literal':needle})
        cursor=index+len(needle)
    return {'source':name,'start':start,'ordered_source_locations':points}

base='research/continuity-identity-candidate/src/durable/messages/'
generation=sequence(base+'rekey.rs','pub async fn prepare_rekey_offer(',[
    ('reserve-original-key','.reserve_key('),
    ('persist-key-reservation','self.store_message_state(&mut image, &state).await?;'),
    ('execute-original-key','let key = match recovery.generate_key('),
    ('construct-public-offer','let mut body = state.control.prefix('),
    ('reserve-signing','let signing = SigningReservation::reserve('),
    ('persist-signing','self.store_message_state(&mut image, &state).await?;'),
    ('sign-offer','let signature = match signing.sign('),
    ('persist-ready-offer','self.store_message_state(&mut image, &state).await?;'),
    ('release-authority','self.check_session_context_release('),
])
response=sequence(base+'rekey/response.rs','pub async fn respond_rekey_offer(',[
    ('authenticate-offer','verify_offer(&state, context, offer)?;'),
    ('reserve-original-encapsulation','.reserve_encapsulation('),
    ('persist-encapsulation','self.store_message_state(&mut image, &state).await?;'),
    ('execute-original-encapsulation','let result = match recovery.encapsulate('),
    ('reserve-response-signing','let signing = SigningReservation::reserve('),
    ('persist-body-root-signing','self.store_message_state(&mut image, &state).await?;'),
    ('sign-response','let signature = match signing.sign(signer, &signing_scope, Purpose::RekeyResponse, body)'),
    ('persist-ready-response','self.store_message_state(&mut image, &state).await?;'),
    ('release-authority','self.check_session_context_release('),
    ('return-original-wire','Ok(wire)'),
])
acceptance=sequence(base+'rekey/completion.rs','pub async fn accept_rekey_response(',[
    ('ready-original-offer','if let Some(super::Plan::Ready {'),
    ('verify-saved-offer','self.check_cached_wire(context, target, RekeyFlight::Offer, offer)?;'),
    ('verify-peer-response','verify_wire(context, target, RekeyFlight::Response, reply)?;'),
    ('expected-original-prefix','let prefix = response::prefix('),
    ('check-body-width-and-prefix','if body.len() != response::RESPONSE_BODY_LEN || !body.starts_with(&prefix)'),
    ('restore-original-owner','let owner = match recovery.generate_key('),
    ('match-recreated-public-key','if owner\n                .public_key()'),
    ('parse-ciphertext','let ciphertext = Ciphertext::from_bytes('),
    ('decapsulate','.decapsulate(&ciphertext, &response::kem_context(offer))'),
    ('derive-root','let root = response::derive_root('),
    ('verify-root-confirmation','response::check_body(&prefix, body, &root)?;'),
    ('persist-final-signing','self.store_message_state(&mut image, &state).await?;'),
    ('sign-final','let signature = self.sign_cutover('),
    ('install-sending-epoch','state.add_epoch(&context.digest(), &root, &offer, &response)?;'),
    ('persist-final-ready','self.store_message_state(&mut image, &state).await?;'),
])
crypto=sources['research/continuity-identity-candidate/src/crypto.rs']
assert 'pub(crate) enum Purpose {' in crypto and 'RekeyResponse = 10,' in crypto
completion=sources[base+'rekey/completion.rs']
assert completion.count('flight.purpose()')==1
assert '.verify(flight.purpose(), body, signature)?;' in completion
assert '!matches!(self.step, Step::FinalReady { .. })' in completion
uses=[]
for p in (ROOT/'research/continuity-identity-candidate/src').rglob('*.rs'):
    if 'tests' in p.parts or p.name.endswith('tests.rs'):continue
    for line,text in enumerate(p.read_text().splitlines(),1):
        if 'Purpose::RekeyResponse' in text:
            uses.append({'source':p.relative_to(ROOT).as_posix(),'line':line,'text':text.strip()})
assert len(uses)==4,uses
assert sum('signing.sign(' in row['text'] for row in uses)==1
assert 'One authoritative lineage per configured device is a host responsibility.' in sources['docs/continuity/STORAGE_RECOVERY_V1.md']

model=(ROOT/'target/multi-epoch-replay/replay-01/original.spthy').read_bytes()
assert sha(model)=='dde5d06a071b1560da0d4c28c3f1fd81a3c39708f9fd8564ee391ddc362bcf7f'
text=model.decode();query='multi_epoch_fresh_reservations_recover_symbolic_message_secrecy'
start=text.index('lemma '+query+' ');quote=text.index('"',text.index('all-traces',start))
formula=text[quote+1:text.index('"',quote+1)].encode()
assert sha(formula)=='0b92ee18d7731c7c83fa05329e486fd6813f8ea13d64ed92215346f10cdf8faa'
with (BASE/'MAIN.formula.txt').open('xb') as f:f.write(formula)
docs=['docs/continuity/KEM_CHALLENGE_ADAPTER_V1.md','docs/continuity/COMPUTATIONAL_RECOVERY_V1.md',
      'docs/continuity/EXTERNAL_REVIEW_BRIEF.md',
      'research/sdk-alpha1/evidence/20261105-kem-challenge-adapter/README.md']
doc_inputs={}
for name in docs:
    p=ROOT/name;data=p.read_bytes()
    for link in re.findall(r'\]\(([^)]+)\)',data.decode()):
        if '://' not in link and not link.startswith('#'):
            assert (p.parent/link.split('#',1)[0]).resolve().is_file(),(name,link)
    doc_inputs[name]={'bytes':len(data),'sha256':sha(data)}
for name,record in inventory.items():assert sha((ROOT/name).read_bytes())==record['sha256']
result={'completed_utc':datetime.now(timezone.utc).isoformat(),'source_commit':PIN,
    'source_inputs':inventory,'document_inputs':doc_inputs,'source_inputs_unchanged':True,
    'generation_order':generation,'response_order':response,'new_acceptance_order':acceptance,
    'literal_response_purpose_uses':sorted(uses,key=lambda r:(r['source'],r['line'])),
    'purpose_enum_visibility':'pub(crate)','response_purpose_code':10,
    'scope':'Pinned-source identity, source locations/order, purpose-use inventory, retained formula identity and local link readback; manual reduction is separate.',
    'main_model_sha256':sha(model),'main_formula_sha256':sha(formula),
    'new_kem_execution':False,'new_native_test_execution':False,'new_tamarin_execution':False,
    'proof_checker':False,'full_native_prefix_simulator_complete':False,'release_claim_eligible':False}
with (BASE/'SOURCE_AUDIT.json').open('xb') as f:f.write(encode(result))
print(json.dumps({'source_files':len(inventory),'ordered_paths':3,'response_purpose_uses':len(uses),
    'source_inputs_unchanged':True,'main_formula_unchanged':True},indent=2),flush=True)
