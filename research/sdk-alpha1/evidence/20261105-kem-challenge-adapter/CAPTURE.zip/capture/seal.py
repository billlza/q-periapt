from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'target/continuity-kem-challenge-adapter'
DEST=ROOT/'research/sdk-alpha1/evidence/20261105-kem-challenge-adapter'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
audit=json.loads((BASE/'SOURCE_AUDIT.json').read_bytes())
for group in ['source_inputs','document_inputs']:
    for name,item in audit[group].items():
        data=(ROOT/name).read_bytes()
        assert len(data)==item['bytes'] and sha(data)==item['sha256'],name
files={}
for p in BASE.rglob('*'):
    assert not p.is_symlink()
    if p.is_file():files['capture/'+p.relative_to(BASE).as_posix()]=p.read_bytes()
for name in audit['document_inputs']:files['documents/'+name]=(ROOT/name).read_bytes()
files['FILES.json']=encode({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,5,0,0,0));info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
payload=buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert len(archive.namelist())==len(files) and set(archive.namelist())==set(files)
    for name,data in files.items():assert archive.read(name)==data
summary={'captured_utc':datetime.now(timezone.utc).isoformat(),'bytes':len(payload),
    'members':len(files),'sha256':sha(payload),'all_members_read_back':True,
    'source_commit':audit['source_commit'],'source_files':len(audit['source_inputs']),
    'ordered_source_paths':3,'native_prefix_simulator_complete':False,
    'new_primitive_or_tamarin_execution':False,'release_claim_eligible':False}
for name,data in [('CAPTURE.zip',payload),('FILES.json',files['FILES.json']),
                  ('SOURCE_AUDIT.json',encode(audit)),('SHA256.json',encode(summary))]:
    with (DEST/name).open('xb') as f:f.write(data)
print(json.dumps(summary,indent=2),flush=True)
