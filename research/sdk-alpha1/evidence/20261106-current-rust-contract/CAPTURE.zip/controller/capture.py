from pathlib import Path
import ast
import hashlib
import json
import sys
import zipfile

import continuity_package as package

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = Path.cwd()
control = source.parent
repo = source.parents[2]
output = source / 'target/continuity-installed-rust-current'
dest = repo / 'research/sdk-alpha1/evidence/20261106-current-rust-contract'
assert not dest.exists()
report = json.loads((output / 'CONTINUITY_PACKAGE.json').read_text())
readback = json.loads((control / 'READBACK.json').read_text())
descriptor = json.loads((control / 'descriptor/RESULT.json').read_text())
assert report['completed'] and readback['completed'] and descriptor['completed']
assert descriptor['candidate_archive_sha256'] == report['archive']['sha256']
assert readback['report_sha256'] == hashlib.sha256((output / 'CONTINUITY_PACKAGE.json').read_bytes()).hexdigest()
files = {}
def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), name
    files[name] = path
def tree(prefix, path):
    for leaf in sorted(path.rglob('*')):
        assert not leaf.is_symlink()
        if leaf.is_file(): add(prefix + '/' + leaf.relative_to(path).as_posix(), leaf)
tree('run', output)
tree('public', control / 'public-replay')
tree('descriptor', control / 'descriptor')
for name in ['PREFLIGHT.json','REQUEST.json','RESULT.json','READBACK.json','PUBLIC_FILES.json',
    'READBACK_DRIVER_CORRECTION.json','controller.stdout','controller.stderr','qualification.stdout',
    'qualification.stderr','readback.stdout','readback.stderr','readback-02.stdout','readback-02.stderr',
    'descriptor.stdout','descriptor.stderr','descriptor-02.stdout','descriptor-02.stderr']:
    add('controller/' + name, control / name)
for name in ['run.py','readback.py','readback-02.py','descriptor.py','capture.py']:
    add('controller/' + name, source / 'target/qualification' / name)
add('source/target/replay.py', source / 'target/qualification/replay.py')
for name, digest in report['source_inputs']['files'].items():
    path = source / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    add('source/' + name, path)
queue = [source / 'target/qualification' / name for name in ['replay.py','readback-02.py','descriptor.py','capture.py']]
seen = set()
while queue:
    path = queue.pop()
    if path in seen: continue
    seen.add(path)
    if path.is_relative_to(source / 'artifact'):
        name = 'source/' + path.relative_to(source).as_posix()
        if name not in files: add(name, path)
    for node in ast.walk(ast.parse(path.read_bytes())):
        modules = [alias.name for alias in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        for module in modules:
            local = source / 'artifact' / (module.replace('.', '/') + '.py')
            if local.is_file(): queue.append(local)
add('source/docs/continuity/BUDGETS_V1.json', source / 'docs/continuity/BUDGETS_V1.json')
previous = repo / 'target/continuity-current-sdk-5678/source'
producer = previous / 'target/sdk-020/RUST_SDK_PACKAGE.json'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == report['rust_report_sha256']
add('sdk/RUST_SDK_PACKAGE.json', producer)
for name in readback['archive_member_changes_from_5678']:
    add('before/research/continuity-identity-candidate/' + name, previous / 'research/continuity-identity-candidate' / name)
binary = Path(descriptor['descriptor_binary'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == descriptor['descriptor_sha256']
add('binaries/contract_report', binary)
dest.mkdir()
manifest = {}
with zipfile.ZipFile(dest / 'CAPTURE.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        info=zipfile.ZipInfo(name,(2026,11,6,7,36,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=(0o100755 if name=='binaries/contract_report' else 0o100644)<<16
        z.writestr(info,data)
with zipfile.ZipFile(dest / 'CAPTURE.zip') as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest)
    for name,row in manifest.items():
        data=z.read(name)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
data=(dest/'CAPTURE.zip').read_bytes()
summary={'source_commit':report['source_commit'],'archive_bytes':len(data),'members':len(manifest),
    'archive_sha256':hashlib.sha256(data).hexdigest(),'sdk_report_sha256':report['rust_report_sha256'],
    'sdk_archives_reused_from':'../20261105-current-sdk-producer/CAPTURE.zip',
    'sdk_archive_capsule_sha256':'2fac380b3ba4a24c9d96d52166c0bcc152dff37c1f9658d287cc0498b8aa9bd5',
    'scope':'New exact Continuity crate, same SDK archive inputs, installed Rust pair, public replay inputs and actual descriptor binary. Original test binaries retired by qualifier; no private runtime trees or signing/wrapping keys exported.'}
for name,value in [('FILES.json',manifest),('READBACK.json',readback),('DESCRIPTOR.json',descriptor),('CAPTURE.json',summary)]:
    with (dest/name).open('x') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
with (dest/'CONTINUITY_PACKAGE.json').open('xb') as stream:stream.write((output/'CONTINUITY_PACKAGE.json').read_bytes())
print(json.dumps(summary))
