from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import sys
import time

import continuity_package as package
from bounded_process import capture_output

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = Path.cwd()
control = source.parent
output = source / 'target/continuity-installed-rust-current'
report = json.loads((output / 'CONTINUITY_PACKAGE.json').read_text())
assert report['completed'] and report['source_commit'] == '4c595a2a382a052979f6ea7c174a19c5e7935315'
assert json.loads((control / 'READBACK.json').read_text())['completed']
outside = Path(json.loads((output / 'location.json').read_text())['path'])
consumer = outside / 'consumer'
target = outside / 'descriptor-build'
assert not target.exists()
result_dir = control / 'descriptor'
result_dir.mkdir()
tool = Path('/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin')
env = {k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','DYLD_','LD_','QPERIAPT_'))}
env.update(CARGO_HOME=str(outside/'cargo-home'),CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true',
    CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',RUSTC=str(tool/'bin/rustc'),RUSTDOC=str(tool/'bin/rustdoc'),
    RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',RUSTUP_AUTO_INSTALL='0',
    DYLD_FALLBACK_LIBRARY_PATH=str(tool/'lib'),PATH=str(tool/'bin')+os.pathsep+env.get('PATH',os.defpath),
    QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lock_digest=sha(consumer/'Cargo.lock')
commands=[]
def run(argv,label):
    row={'argv':argv,'cwd':str(Path.cwd()),'started_utc':datetime.now(timezone.utc).isoformat(),'completed':False,'timeout_seconds':900}
    started=time.monotonic()
    try:
        with (result_dir/(label+'.stdout')).open('xb') as stdout,(result_dir/(label+'.stderr')).open('xb') as stderr:
            result=capture_output(argv,timeout_seconds=900,maximum_stdout_bytes=16*1024**2,
                maximum_stderr_bytes=16*1024**2,environment=env,stdout_sink=stdout.write,stderr_sink=stderr.write)
        row.update(completed=True,returncode=result.returncode)
        assert result.returncode==0,label
        return result.stdout
    finally:
        row['seconds']=time.monotonic()-started
        (result_dir/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
        commands.append(row)
record={'completed':False,'source_commit':report['source_commit'],'candidate_archive_sha256':report['archive']['sha256'],
    'scope':'Actual installed-archive example and shared library contract. No ABI freeze, foreign platform or resource qualification.'}
try:
    built=run([str(tool/'bin/cargo'),'build','--manifest-path',str(consumer/'Cargo.toml'),'--locked','--offline',
        '-j','2','--release','--package',package.NAME,'--example','contract_report','--message-format=json'],'build')
    rows=[r for line in built.splitlines() if (r:=json.loads(line)).get('executable') and r.get('reason')=='compiler-artifact']
    assert len(rows)==1 and rows[0]['target']['name']=='contract_report'
    expected_source=consumer/'packages'/f'{package.NAME}-{package.VERSION}'/'examples/contract_report.rs'
    assert Path(rows[0]['target']['src_path']).resolve()==expected_source
    binary=Path(rows[0]['executable']).resolve(strict=True)
    assert binary.is_relative_to(target)
    digest=sha(binary)
    run(['sh','artifact/python-run.sh','artifact/continuity_contract.py','--consumer',str(binary),
        '--output',str(result_dir/'contract')],'contract')
    contract=json.loads((result_dir/'contract/CONTRACT.json').read_text())
    assert contract['completed'] and contract['consumer_sha256']==digest==sha(binary)
    assert contract['contract']['schema_version']==3 and contract['contract']['maximums']['retained_fanout_records']==16
    assert sha(consumer/'Cargo.lock')==lock_digest
    package.verify_candidate_files(consumer/'packages'/f'{package.NAME}-{package.VERSION}',
        package.validate_candidate((output/report['archive']['file']).read_bytes(),set(report['archive']['files'])))
    record.update(completed=True,descriptor_binary=str(binary),descriptor_sha256=digest,
        descriptor_bytes=binary.stat().st_size,lock_unchanged=True,archive_example_path_verified=True,
        schema=3,retained_fanout_records=16)
finally:
    record.update(commands=commands,finished_utc=datetime.now(timezone.utc).isoformat())
    (result_dir/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
