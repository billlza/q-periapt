from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

import continuity_package as package
from rust_sdk_msrv import validate_report

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = Path.cwd()
control = source.parent
previous = source.parents[2] / 'target/continuity-current-sdk-5678/source'
expected_commit = '4c595a2a382a052979f6ea7c174a19c5e7935315'
commit, dirty = package.sdk.inspect_package_source(source, allow_dirty=False)
assert (commit, dirty) == (expected_commit, False)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, value):
    with (control / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
current = package.source_inputs()
old = json.loads((previous / 'target/continuity-installed-kotlin-release-current/sources-before.json').read_text())
assert set(current['files']) == set(old['files']) and len(current['files']) == 1401
changed = {name: {'before': old['files'][name], 'after': digest}
    for name, digest in current['files'].items() if old['files'][name] != digest}
assert set(changed) == {
    'artifact/continuity_kotlin_consumer.py',
    'research/continuity-identity-candidate/examples/contract_report.rs',
    'research/continuity-identity-candidate/src/contract.rs',
    'research/continuity-identity-candidate/src/durable/messages/fanout.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/closure.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/fanout.rs'}
assert current['rust_workspace_sha256'] == old['rust_workspace_sha256'] == 'c064df108a07da40099f9c2fe8115577d54f421fea918a0fefb1810d76a42c4d'
report = previous / 'target/sdk-020/RUST_SDK_PACKAGE.json'
digest = sha(report)
assert digest == '1e40fc2ae0c7c113509ae2a5c5a858cbd73a8a6fd7f63e66203316c4c61e228d'
cohort = validate_report(report.read_bytes(), digest, digest, current['rust_workspace_sha256'])
assert cohort['base_commit'] == '5678d1019861fa1b04f3a219ba3fde7e0ddaaba8'
archives = {}
for name, record in cohort['crates'].items():
    path = report.parent / 'crates' / record['file']
    assert sha(path) == record['sha256'] and path.stat().st_size == record['bytes']
    archives[name] = {'path': str(path), 'sha256': record['sha256'], 'bytes': record['bytes']}
write('PREFLIGHT.json', {'verified_utc': datetime.now(timezone.utc).isoformat(),
    'source_commit': commit, 'git_dirty': dirty, 'source_inputs': current,
    'previous_source_commit': cohort['base_commit'], 'changed_candidate_inputs': changed,
    'unchanged_sdk_workspace_sha256': current['rust_workspace_sha256'],
    'sdk_report_sha256': digest, 'original_sdk_report_accepted_by_unmodified_gate': True,
    'sdk_archives': archives})
toolchain = '/Users/bhmq03@durham.ac.uk/.rustup/toolchains/1.98.1-aarch64-apple-darwin'
argv = ['sh', 'artifact/python-run.sh', 'artifact/continuity_package.py',
    '--report', str(report), '--report-sha256', digest, '--toolchain-root', toolchain,
    '--output', 'target/continuity-installed-rust-current']
assert not (source / 'target/continuity-installed-rust-current').exists()
write('REQUEST.json', {'started_utc': datetime.now(timezone.utc).isoformat(),
    'argv': argv, 'cwd': str(source), 'driver_sha256': sha(Path(__file__)),
    'scope': 'Original unpartitioned installed Rust qualifier, both Debug and Release. Reused exact SDK producer inputs; freshly packaged changed Continuity candidate. No C/Swift/Kotlin/JNI/device, formal contract admission or release claim.'})
env = dict(os.environ, QPERIAPT_PYTHON='/Users/bhmq03@durham.ac.uk/.local/bin/python3', RUSTUP_AUTO_INSTALL='0')
started = time.monotonic()
with (control / 'qualification.stdout').open('xb') as stdout, (control / 'qualification.stderr').open('xb') as stderr:
    result = subprocess.run(argv, cwd=source, env=env, stdout=stdout, stderr=stderr)
record = {'completed_utc': datetime.now(timezone.utc).isoformat(), 'returncode': result.returncode,
    'seconds': time.monotonic() - started, 'stdout_sha256': sha(control / 'qualification.stdout'),
    'stderr_sha256': sha(control / 'qualification.stderr')}
write('RESULT.json', record)
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
