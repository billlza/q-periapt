from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

import continuity_package as package
import rust_sdk_profile as sdk

assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
source = Path.cwd()
control = source.parent
previous = source.parents[2] / 'target/continuity-current-sdk-5678/source'
output = source / 'target/continuity-installed-rust-current'
producer = previous / 'target/sdk-020'
report = json.loads((output / 'CONTINUITY_PACKAGE.json').read_text())
preflight = json.loads((control / 'PREFLIGHT.json').read_text())
assert json.loads((control / 'RESULT.json').read_text())['returncode'] == 0
assert report['source_commit'] == '4c595a2a382a052979f6ea7c174a19c5e7935315'
assert report['completed'] and report['partition_completed']
assert report['build_profiles'] == ['debug', 'release'] and report['requested_consumers'] == ['Rust']
assert not report['publication_performed'] and not report['release_claim_eligible']
assert report['source_inputs'] == preflight['source_inputs'] == package.source_inputs()
assert report['source_inputs'] == json.loads((output / 'sources-before.json').read_text())
assert report['source_inputs'] == json.loads((output / 'sources-after.json').read_text())
assert report['rust_report_sha256'] == sdk.snapshot(producer / 'RUST_SDK_PACKAGE.json').sha256
outside = Path(json.loads((output / 'location.json').read_text())['path'])
assert outside.is_absolute() and not outside.is_relative_to(source)
consumer = outside / 'consumer'
package.verify_candidate_archive(output, report['archive'])
files = package.validate_candidate((output / report['archive']['file']).read_bytes(), set(report['archive']['files']))
package.verify_candidate_files(consumer / 'packages' / f'{package.NAME}-{package.VERSION}', files)
cohort = json.loads((producer / 'RUST_SDK_PACKAGE.json').read_text())
sdk.verify_consumed_sources(consumer, producer, cohort['crates'])
old_output = previous / 'target/continuity-installed-rust-current'
old_report = json.loads((old_output / 'CONTINUITY_PACKAGE.json').read_text())
old_files = sdk.archive_files((old_output / old_report['archive']['file']).read_bytes(), package.NAME, version=package.VERSION)
assert set(files) == set(old_files)
changes = {name: {'before': hashlib.sha256(old_files[name]).hexdigest(), 'after': hashlib.sha256(files[name]).hexdigest()}
    for name in files if old_files[name] != files[name]}
assert set(changes) == {'examples/contract_report.rs', 'src/contract.rs', 'src/durable/messages/fanout.rs',
    'src/durable/messages/tests/closure.rs', 'src/durable/messages/tests/fanout.rs'}
old_constant = b'const MAX_FANOUTS: usize = 16;\n'
new_import = b'use crate::contract::MAX_RETAINED_FANOUT_RECORDS as MAX_FANOUTS;\n'
assert old_files['src/durable/messages/fanout.rs'].count(old_constant) == 1
assert files['src/durable/messages/fanout.rs'].count(new_import) == 1
assert old_files['src/durable/messages/fanout.rs'].replace(old_constant, b'') == files['src/durable/messages/fanout.rs'].replace(new_import, b'')
commands = {}
for path in sorted(output.glob('*.json')):
    row = json.loads(path.read_text())
    if 'argv' in row:
        assert row['returncode'] == 0, path
        commands[path.name] = {'returncode': 0, 'receipt_sha256': sdk.snapshot(path).sha256}
public = control / 'public-replay'
public.mkdir()
copied = {}
def copy(src, dst):
    snap = sdk.snapshot(src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('xb') as stream:
        stream.write(snap.data)
    copied[dst.relative_to(public).as_posix()] = {'bytes': snap.size, 'sha256': snap.sha256}
def tree(src, dst):
    for path in sorted(src.rglob('*')):
        assert not path.is_symlink()
        if path.is_file(): copy(path, dst / path.relative_to(src))
profiles = {}
for profile in ['debug', 'release']:
    original = outside / (profile + '-runtime')
    reopened = outside / (profile + '-runtime-session-reopen')
    expected = dict(report['execution'][profile])
    binary = expected.pop('binary')
    observed = package.verify_execution((output / ('consumer-' + profile + '.stdout')).read_bytes(),
        original, reopened, outside / (profile + '-runtime-roster-renewal/public'),
        outside / (profile + '-runtime-device-replacement/public'),
        outside / (profile + '-runtime-device-retirement/public'))
    assert observed == expected and not Path(binary['path']).exists()
    target = public / (profile + '-runtime')
    copy(original / 'public-result.json', target / 'public-result.json')
    for name in expected['application_readbacks']:
        copy(original / name, target / name)
    for name in ['closure-id', 'cleanup-complete', 'cleanup-verified']:
        copy(original / 'responder' / name, target / 'responder' / name)
    tree(output / (profile + '-enrollment-public'), target / 'enrollment-public')
    new_reopened = public / (profile + '-runtime-session-reopen')
    for name in ['public-reopen-result.json', 'original-outbox', 'restored-outbox',
                 'initiator/reopen-test-time', 'responder/reopen-test-time',
                 *expected['session_reopen']['application_file']]:
        copy(reopened / name, new_reopened / name)
    tree(output / (profile + '-enrollment-reopen-public'), new_reopened)
    for label in ['roster-renewal', 'device-replacement', 'device-retirement']:
        tree(output / (profile + '-' + label + '-public'), public / (profile + '-' + label))
    replayed = package.verify_execution((output / ('consumer-' + profile + '.stdout')).read_bytes(),
        target, new_reopened, public / (profile + '-roster-renewal'),
        public / (profile + '-device-replacement'), public / (profile + '-device-retirement'))
    assert replayed == observed
    profiles[profile] = {'complete_tests_passed': 3, 'tests_filtered': 0,
        'original_public_readback_matches': True, 'copied_public_replay_matches': True,
        'retired_binary_receipt': binary, 'retired_binary_bytes_available': False,
        'outcome_sha256': hashlib.sha256(json.dumps(observed, sort_keys=True).encode()).hexdigest()}
for name in ['package-build-storage.json', 'rust-build-storage.json']:
    row = json.loads((output / name).read_text())
    assert row['completed'] and not Path(row['directory']).exists()
result = {'completed': True, 'verified_utc': datetime.now(timezone.utc).isoformat(),
    'source_commit': report['source_commit'], 'source_inputs_unchanged': True,
    'source_input_count': len(report['source_inputs']['files']), 'sdk_report_sha256': report['rust_report_sha256'],
    'sdk_workspace_sha256': report['source_inputs']['rust_workspace_sha256'],
    'report_sha256': sdk.snapshot(output / 'CONTINUITY_PACKAGE.json').sha256,
    'candidate_archive': {k: report['archive'][k] for k in ['file','bytes','sha256']},
    'candidate_archive_members': len(files), 'archive_member_changes_from_5678': changes,
    'fanout_runtime_source_unchanged_except_constant_reference': True,
    'installed_candidate_tree_verified': True, 'installed_sdk_trees_verified': len(sdk.CONSUMER_CRATES),
    'profiles': profiles, 'commands': commands, 'public_files_copied': len(copied),
    'scope': 'Installed archive-derived Rust Debug/Release and public-only reread on one host. No foreign/device qualification, independent cryptographic implementation, new resource budget or release acceptance.'}
for name, value in [('READBACK.json',result), ('PUBLIC_FILES.json',copied)]:
    with (control / name).open('x') as stream: stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['completed','source_input_count','candidate_archive','candidate_archive_members','public_files_copied']}))
