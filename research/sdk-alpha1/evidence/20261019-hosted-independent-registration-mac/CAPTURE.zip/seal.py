"""Seal terminal registration outputs after all eleven frozen-source readers pass."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent
head='f7a79e80b0e76f797072d76b3b659768d7628ef8'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda name:json.loads((out/name).read_text())
sources=read('SOURCE_FILES.json');assert len(sources)==99
labels=['REGRESSION','CONTROL','RESOLUTION','WITNESS','PEER_LIFECYCLE','REPLY_RELEASE','LOCAL_RENEWAL','LOCAL_CREDENTIAL','PENDING','PUBLIC_INPUTS','REGISTRATION']
reports={name:read(name+'_READBACK.json')for name in labels}
for name,report in reports.items():
 if name!='REPLY_RELEASE':assert report['head']==head and report['source_files']==sources and report['native_sha256']==reports['REGISTRATION']['native_sha256']
readers=read('READERS.json');assert len(readers)==11 and all(r['exit']==0 for r in readers)
job=read('JOB.json');artifact=read('ARTIFACT.json')
assert job['head_sha']==head and job['run_id']==39174029062 and job['status']=='completed'and job['conclusion']=='success'
archive=out/'mac-f7a7.zip';raw=archive.read_bytes()
assert len(raw)==artifact['size_in_bytes']and 'sha256:'+sha(raw)==artifact['digest']
with zipfile.ZipFile(archive)as z:members=len(z.namelist())
entries={archive.name:raw}
for p in sorted(out.iterdir()):
 if p.is_file()and p.suffix in {'.py','.json','.txt','.stdout','.stderr'}:entries[p.name]=p.read_bytes()
assert all(not value for name,value in entries.items()if name.endswith('.stderr'))
for name,expected in sources.items():
 value=(out/'source'/name).read_bytes();assert sha(value)==expected;entries['source/'+name]=value
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
folder=root/'research/sdk-alpha1/evidence/20261019-hosted-independent-registration-mac';folder.mkdir()
path=folder/'CAPTURE.zip'
with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(entries.items()):
  i=zipfile.ZipInfo(n,(2026,10,19,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
with zipfile.ZipFile(path)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
 for n,row in manifest.items():assert len(z.read(n))==row['bytes']and sha(z.read(n))==row['sha256']
result={'head':head,'run':job['run_id'],'job':job['id'],'job_conclusion':job['conclusion'],'artifact_id':artifact['id'],'artifact_bytes':len(raw),'artifact_digest':artifact['digest'],'artifact_members':members,'readbacks':reports,'capture':{'bytes':path.stat().st_size,'members':len(entries),'sha256':sha(path.read_bytes())},'scope':'19 terminal independent reference entrypoints and11 public readers at frozen99-source head. Real native enrollment/traffic/rekey/renewal/pending recovery; private owner/MAC/absence/cleanup assertions remain runtime observations. Separate trusted fixture controller is not deployed account authentication; no full multidevice,installed lifecycle,PCS,energy,physical erasure or0.2.0 release admission.'}
(folder/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['capture']))
