"""Public-only readback; private root/MAC/AEAD computations stay in runtime tests."""
import ast
import hashlib
import json
from pathlib import Path
import sys

root=Path.cwd();source=root/'research/continuity-openssl-peer';out=root/'target/independent-rekey-01'
sys.path.append(str(source))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
from fixture_inputs import load
from peer.wire import ldh
def sha(b):return hashlib.sha256(b).hexdigest()
def check(value,message):
    if not value: raise ValueError(message)

reports={name:json.loads((out/name/'RESULT.json').read_text())for name in ['qualified','volatile-qualified','durable-qualified']}
r=reports['qualified'];sources=r['source_files']
for name,report in reports.items():
    check(report.get('source_files',report.get('peer_sources'))==sources,'different source closure')
    prefix=out/name/('native/cases'if name=='durable-qualified'else'cases')
    for case in report['native_commands']:
        before=(prefix/(case['case']+'.input')).read_bytes();after=(prefix/(case['case']+'.output')).read_bytes()
        check(sha(before)==case['input_sha256']and sha(after[1:])==case['output_sha256']and after[0]==case['status'],'native record')
        if case['status']==2:check(after[1:].decode()==case['error'],'native error record')
for name,expected in sources.items():
    data=(source/name).read_bytes();check(sha(data)==expected,'source changed: '+name)
    if name.endswith('.py'):ast.parse(data,name)
binary=root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart'
b=binary.read_bytes();check(sha(b)==r['native_sha256'],'native executable changed')
check(b[:4]==b'\xcf\xfa\xed\xfe'and int.from_bytes(b[4:8],'little')==0x100000c,'actual ARM64 MachO')
check(len(r['epochs'])==8 and len(r['native_commands'])==132 and len(r['refusals'])==108,'rekey workload')
check(len({x['case']for x in r['refusals']})==108,'duplicate refusal')
check(len(reports['volatile-qualified']['native_commands'])==41 and len(reports['volatile-qualified']['python_refusals'])==51,'old traffic regression')
d=reports['durable-qualified'];check(d['process_kills']==6 and len(d['worker_operations'])==27 and len(d['codec_refusals'])==6,'durable regression')
for row in d['worker_operations']:
    value=(out/'durable-qualified'/(row['case']+'.stdout')).read_bytes()
    if 'signal'in row:check(json.loads(value)=={'pid':row['worker_pid'],'stage':row['cut']},'worker PID/cut')
    elif 'stdout_sha256'in row:check(sha(value)==row['stdout_sha256'],'worker output')
    else:check(not value,'refusal released output')

public=out/'qualified';cases=public/'cases';_,_,context=load(public/'public',150)
session=(cases/'final.output').read_bytes()[1:]
domain=b'Q-PERIAPT-CONTINUITY-REKEY-CANDIDATE/v1/'
def h(label,value):return ldh(domain+label,value)
profile=h(b'offer-profile',b'ML-KEM-768+X25519/ContextBound;ML-DSA-65+P-256/SHA-256;accountable-epoch-ratchet/v6;messages/v3;retained-epochs=4;settled-prefix-attestation/v1;application-send-budget/v1;control-request/v1')
parent=h(b'genesis',session+context.digest)
tags=[b'QPRKOF01',b'QPRKRP01',b'QPRKFN01',b'QPRKRC01'];sizes=[1369,1337,257,289]
messages=b'Q-PERIAPT-CONTINUITY-MESSAGES-CANDIDATE/v2/'
def frame(wire,role,epoch,size):
    counters=epoch.to_bytes(8,'big')+bytes(8)
    identity=counters+ldh(messages+b'epoch-message-id',session+bytes([role])+counters)[:16]
    check(len(wire)==109+size and wire[:41]==b'QPCMSG03'+session+bytes([role])and wire[41:57]==counters
          and wire[57:89]==identity and int.from_bytes(wire[89:93],'big')==size,'epoch frame')
def application(value):
    n=int.from_bytes(value[:2],'big');check(n<=1024,'AD capacity');return value[2:2+n],value[2+n:]
def ack(wire,role,epoch):
    check(len(wire)==89 and wire[:41]==b'QPCMACK2'+session+bytes([role])and wire[41:49]==epoch.to_bytes(8,'big')
          and wire[49:57]==(1).to_bytes(8,'big'),'epoch ACK')
for epoch,row in enumerate(r['epochs'],1):
    label=f'epoch-{epoch}-';wires=[(public/(label+n)).read_bytes()for n in ['offer','response','final','receipt']]
    bodies=[];proposer=1 if epoch%2 else 2
    for flight,(wire,size,tag)in enumerate(zip(wires,sizes,tags,strict=True)):
        role=proposer if flight in [0,2]else 3-proposer
        body=(context.initiator if role==1 else context.responder).open(wire,9+flight,size)
        check(body[:153]==tag+profile+context.digest+session+(epoch-1).to_bytes(8,'big')+epoch.to_bytes(8,'big')+bytes([role])+parent,'signed prefix')
        bodies.append(body)
    ho,hr,hf=h(b'offer-wire',wires[0]),h(b'response-wire',wires[1]),h(b'final-wire',wires[2])
    check(bodies[1][153:185]==ho and bodies[2][153:217]==ho+hr and bodies[3][153:249]==ho+hr+hf,'control hashes')
    check(all(int.from_bytes(body[-40:-32],'big')==(0 if epoch==1 else 1)for body in bodies[2:]),'signed closing counts')
    parent=h(b'completed-epoch',b''.join(wires));check(row['epoch']==epoch and row['predecessor']==parent.hex(),'completed predecessor')
    state=(cases/(label+'completed.output')).read_bytes();check(state==b'\1'+epoch.to_bytes(8,'big')*3+bytes(8),'completed counters')
    if epoch%2==0:
        state=(cases/(label+'final-progress.output')).read_bytes();check(state==b'\1'+(epoch-1).to_bytes(8,'big')+epoch.to_bytes(8,'big')+(epoch-1).to_bytes(8,'big')+epoch.to_bytes(8,'big'),'asymmetric final progress')
    ad,wire=application((cases/(label+'receive.input')).read_bytes());frame(wire,1,epoch,row['plaintext_bytes'])
    expected=(b'',b'independent rekey application',bytes(range(256))*64)[epoch%3]
    check(len(ad)==row['AD_bytes']and (cases/(label+'receive.output')).read_bytes()==b'\1'+expected,'application plaintext')
    name='send'if epoch%2 else'early-send';frame((cases/(label+name+'.output')).read_bytes()[1:],2,epoch,row['plaintext_bytes'])
    request=(cases/(label+name+'.input')).read_bytes()
    check(application(request[32:])==(ad,expected),'native outgoing application')
    ack((cases/(label+'consume.output')).read_bytes()[1:],1,epoch);ack((cases/(label+'acknowledge.input')).read_bytes(),2,epoch)
    check((cases/(label+'acknowledge.output')).read_bytes()==b'\1'+(1).to_bytes(8,'big'),'native ACK acceptance')
report={'base_head':'0cff3934a8042816259944f2e4fd28236e61c49a','source_files':sources,'native_sha256':r['native_sha256'],
        'native_architecture':'MachO64 ARM64','provider':r['provider'],'epochs':8,'four_flight_envelopes':32,
        'native_commands':132,'refusals':108,'native_same_process_reopens':8,'public_transcript_readback':True,
        'volatile_regression':{'native_commands':41,'refusals':51},
        'epoch_zero_durable_regression':{'kills':6,'operations':27,'native_commands':9,'codec_refusals':6},
        'limits':['independent rekey computations/traffic are volatile; no durable rekey owner yet',
                  'runtime independently computes secret KEM/MAC/AEAD; public readback rechecks signatures/fields only',
                  'fully settled history workload; no independent retention/resolution or aggregate unconfirmed budget owner',
                  'no new PCS proof, hardware power loss, cross-host or release qualification']}
(out/'READBACK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['source_files','limits']}))
