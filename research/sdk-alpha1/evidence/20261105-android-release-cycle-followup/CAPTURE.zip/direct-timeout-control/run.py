from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
from bounded_process import capture_output, BoundedProcessError

base = Path(__file__).resolve().parent
record = {'started_utc': datetime.now(timezone.utc).isoformat(), 'completed': False,
          'scope': 'One deadline owns the actual test group; no nested supervisor process',
          'source_sha256': hashlib.sha256(Path('artifact/bounded_process.py').read_bytes()).hexdigest()}
try:
    try:
        capture_output(['/bin/sh', 'artifact/python-run.sh', str(base / 'leaf.py'), str(base / 'leaf.json')],
                       timeout_seconds=2, maximum_stdout_bytes=4096, maximum_stderr_bytes=4096)
    except BoundedProcessError as error:
        assert error.kind == 'timeout' and not error.cleanup_ambiguous
        record['expected_error'] = {'kind': error.kind, 'cleanup_ambiguous': error.cleanup_ambiguous}
    else:
        raise AssertionError('The execution deadline did not fail')
    leaf = json.loads((base / 'leaf.json').read_bytes())
    record['leaf'] = leaf
    observation = subprocess.run(['ps', '-p', str(leaf['pid']) + ',' + str(leaf['pgid']),
                                  '-o', 'pid=,ppid=,pgid=,state=,command='], text=True, capture_output=True)
    assert observation.returncode == 1 and not observation.stdout and not observation.stderr
    record.update(completed=True, surviving_leaf_or_leader=False, manual_cleanup_required=False)
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    with (base / 'RESULT.json').open('x') as out: json.dump(record, out, indent=2); out.write('\n')
    print(json.dumps(record), flush=True)
