"""Read back the directly supervised Release cycle, keeping the failed parent separate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import tempfile
import zipfile
import continuity_android_joint_cycle as cycle

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-android-cycle-followup'
SOURCE = ROOT / 'target/continuity-managed-maintenance/source-f560d803'
OUTPUT = BASE / 'public'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-android-release-cycle-followup'
sha = lambda data: hashlib.sha256(data).hexdigest()
obj = lambda path: json.loads(path.read_bytes())
result = obj(BASE / 'RESULT.json')
command = obj(OUTPUT / 'android-jni-release-joint-cycle.json')
assert result['completed'] and result['release_claim_eligible'] is False
assert command['completed'] and command['returncode'] == 0 and command['timeout_seconds'] == 900
assert command['maximum_stdout_bytes'] == command['maximum_stderr_bytes'] == 16 * 1024**2
stdout = (OUTPUT / 'android-jni-release-joint-cycle.stdout').read_bytes()
assert not (OUTPUT / 'android-jni-release-joint-cycle.stderr').read_bytes()
assert b'6 passed; 0 failed; 0 ignored' in stdout
private = Path(result['private_fixture_root']) / 'joint-cycle-cases'
for label, expected in result['outcomes'].items():
    carrier, trust = label.split('-')
    assert cycle.verify_execution(stdout, private / label, carrier, trust, batch=True) == expected
    assert cycle.verify_execution(stdout, OUTPUT / ('android-jni-release-joint-cycle-' + label), carrier, trust, batch=True) == expected
assert set(result['outcomes']) == set(cycle.TESTS)
assert sum(value['foreign_processes'] for value in result['outcomes'].values()) == 434
files = {}
def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink()
    data = path.read_bytes(); assert len(data) <= 256 * 1024**2
    files[name] = data
for path in sorted(OUTPUT.rglob('*')):
    if path.is_file(): add('public/' + path.relative_to(OUTPUT).as_posix(), path)
for name in ['INPUTS.json', 'RESULT.json', 'seal.py']: add('driver/' + name, BASE / name)
add('driver/run.py', SOURCE / 'target/android-joint-cycle-followup/run.py')
add('driver/streamed_command.py', ROOT / 'target/continuity-installed-managed-cohort/run_package.py')
for path in sorted((ROOT / 'target/continuity-direct-boundary-check').iterdir()):
    if path.is_file(): add('direct-timeout-control/' + path.name, path)
control = obj(ROOT / 'target/continuity-direct-boundary-check/RESULT.json')
assert control['completed'] and not control['surviving_leaf_or_leader'] and not control['manual_cleanup_required']
add('parent/LAUNCH_RESULT.json', ROOT / 'target/continuity-android-managed-cohort/LAUNCH_RESULT.json')
assert obj(ROOT / 'target/continuity-android-managed-cohort/LAUNCH_RESULT.json')['completed'] is False
runtime = {}
for number, (path, expected) in enumerate(sorted(result['runtime_files_before'].items())):
    path = Path(path); assert sha(path.read_bytes()) == expected
    name = f'runtime/{number:03}-{path.name}'
    add(name, path); runtime[name] = {'original_path': str(path), 'sha256': expected}
for name in ['continuity_android_joint_cycle.py', 'continuity_android_joint_policy.py',
             'continuity_android_witness_joint.py', 'continuity_android_contract.py', 'bounded_process.py']:
    assert (SOURCE / 'artifact' / name).read_bytes() == (ROOT / 'artifact' / name).read_bytes()
    add('source/artifact/' + name, SOURCE / 'artifact' / name)
summary = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'completed_component': True,
           'original_parent_aggregate_completed': False, 'release_claim_eligible': False,
           'source_commit': result['source_commit'], 'command_seconds': command['elapsed_seconds'],
           'followup_seconds': result['elapsed_seconds'], 'routes': result['outcomes'],
           'foreign_adapter_processes': 434, 'runtime_entries': runtime,
           'scope': 'Six Release host JNI joint-cycle routes over the original ff072 installed cohort. Fresh private state, direct 900-second/16-MiB command ownership. No new candidate-root, ART, emulator, device or release acceptance.'}
files['READBACK.json'] = (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()
DEST.mkdir()
archive = DEST / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for name, data in sorted(files.items()):
        item = zipfile.ZipInfo(name, (2000, 1, 1, 0, 0, 0)); item.external_attr = 0o100644 << 16
        item.compress_type = zipfile.ZIP_DEFLATED; packed.writestr(item, data)
with zipfile.ZipFile(archive) as packed:
    assert packed.testzip() is None and set(packed.namelist()) == set(files)
    for name, data in files.items(): assert packed.read(name) == data
    with tempfile.TemporaryDirectory(prefix='qpc-cycle-export-readback-') as temporary:
        exported = Path(temporary)
        for name, data in files.items():
            if name.startswith('public/'):
                path = exported / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        for label, expected in result['outcomes'].items():
            carrier, trust = label.split('-')
            assert cycle.verify_execution(stdout, exported / 'public' / ('android-jni-release-joint-cycle-' + label), carrier, trust, batch=True) == expected
index = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
         'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())},
         'exported_routes_verified': sorted(result['outcomes'])}
for name, data in [('CAPTURE.json', index), ('READBACK.json', summary)]:
    with (DEST / name).open('x') as out: json.dump(data, out, indent=2, sort_keys=True); out.write('\n')
print(json.dumps({'bytes': index['archive_bytes'], 'sha256': index['archive_sha256'], 'members': len(files)}), flush=True)
