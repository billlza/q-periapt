"""Run the unfinished Release cycle directly under its original command budget."""
from pathlib import Path
from datetime import datetime, timezone
import contextlib
import hashlib
import json
import os
import runpy
import tempfile
import time

from bounded_process import capture_output
from continuity_apple_package import file_hashes
from continuity_kotlin_consumer import tool_identity
import continuity_android_joint_cycle as cycle
import continuity_package as package
import rust_sdk_profile as sdk

MAIN = Path('/Users/bhmq03@durham.ac.uk/Desktop/Q-periapt')
SOURCE = MAIN / 'target/continuity-managed-maintenance/source-f560d803'
PARENT = MAIN / 'target/continuity-android-managed-cohort'
OLD = SOURCE / 'target/android-managed-qualification/result-01'
BASE = MAIN / 'target/continuity-android-cycle-followup'
OUTPUT = BASE / 'public'
COMMIT = 'ff072bd66b1f5d3bdbb80171ee39bad15cbc3c20'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_bytes())
def save(path, value):
    with path.open('x') as out: json.dump(value, out, indent=2); out.write('\n')

assert Path.cwd() == SOURCE and sdk.ROOT == SOURCE
assert read(MAIN / 'target/continuity-direct-boundary-check/RESULT.json')['completed']
assert read(PARENT / 'LAUNCH_RESULT.json')['completed'] is False
assert read(PARENT / 'ORPHAN_CLEANUP_RESULT.json')['after'] == []
for argv, expected in [(['git', 'rev-parse', 'HEAD'], (COMMIT + '\n').encode()),
                       (['git', 'status', '--porcelain'], b'')]:
    check = capture_output(argv, timeout_seconds=30, maximum_stdout_bytes=65536, maximum_stderr_bytes=65536)
    assert check.returncode == 0 and not check.stderr and check.stdout == expected
inputs = read(PARENT / 'INPUTS.json')
before = package.source_inputs(); assert before == inputs['source_inputs']
outside = Path(inputs['outside']); consumer = outside / 'c-consumer'
assert file_hashes(consumer) == inputs['c_source_before']
java_home = Path(inputs['tools']['java']['root'])
assert tool_identity(java_home) == inputs['tools']['java']
command = read(OLD / 'android-jni-release-joint-cycle.json')
binary = Path(command['argv'][0])
assert command['argv'][1:] == ['android_policy_renewal::joint::cycle::', '--test-threads=6', '--show-output']
assert command['timeout_seconds'] == 900 and command['maximum_stdout_bytes'] == command['maximum_stderr_bytes'] == 16 * 1024**2
boundary = read(OLD / 'android-jni-release-boundary.json')['argv']
installed = Path(next(value.split('=', 1)[1] for value in boundary if value.startswith('-Djava.library.path=')))
jar, tests = map(Path, boundary[boundary.index('-cp') + 1].split(os.pathsep))
sealed = read(MAIN / 'research/sdk-alpha1/evidence/20261105-android-parent-timeout/FILES.json')
assert digest(jar) == sealed['output/continuity-android-classes.jar']['sha256']
runtime_files = [binary, jar, installed / 'driver', installed / 'libqperiapt_continuity_jni.dylib',
                 installed / 'libq_periapt_continuity_c_consumer.dylib', installed / 'qpc-c-client',
                 installed / 'qpc-configuration-client']
runtime_files.extend(sorted(tests.rglob('*.class')))
runtime_before = {str(path): digest(path) for path in runtime_files}
assert runtime_before[str(installed / 'qpc-c-client')] == inputs['native_binaries']['release/C_client']['sha256']
assert runtime_before[str(installed / 'libq_periapt_continuity_c_consumer.dylib')] == inputs['native_binaries']['release/C_library']['sha256']
environment = {key: value for key, value in os.environ.items()
               if key not in {'JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS', 'CLASSPATH'}
               and not key.startswith(('JAVA_', 'GRADLE_', 'KOTLIN_', 'QPERIAPT_', 'QPC_', 'LD_', 'DYLD_', 'CARGO_', 'RUST'))}
environment.update(command['selected_environment'])
environment.update(QPC_ANDROID_DRIVER=str(installed / 'driver'),
                   QPC_CONFIGURATION_RECEIVER=str(installed / 'qpc-c-client'),
                   QPC_CONFIGURATION_TARGET_CLIENT=str(installed / 'qpc-configuration-client'))
BASE.mkdir(); OUTPUT.mkdir()
fresh = Path(tempfile.mkdtemp(prefix='qpc-android-cycle-followup-')).resolve(strict=True)
state = {'completed': False, 'release_claim_eligible': False, 'source_commit': COMMIT,
         'scope': 'Independent completion of the six Release host-JNI joint-cycle routes; original aggregate remains failed. Fresh fixture state; no claim for current Windows-fixed source, ART, device or release.',
         'started_utc': datetime.now(timezone.utc).isoformat(), 'private_fixture_root': str(fresh),
         'parent_timeout_sha256': digest(PARENT / 'LAUNCH_RESULT.json'),
         'source_inputs': before, 'runtime_files_before': runtime_before,
         'java_identity': inputs['tools']['java'], 'driver_sha256': digest(Path(__file__)),
         'timeout_seconds': 900, 'stream_limit_bytes': 16 * 1024**2,
         'supervision': 'The live Python owner calls the bounded primitive directly on the Rust test process; no outer Python supervisor deadline.'}
save(BASE / 'INPUTS.json', state)
streamed_command = runpy.run_path(str(MAIN / 'target/continuity-installed-managed-cohort/run_package.py'),
                                run_name='direct_cycle_stream_capture')['streamed_command']
def run(argv, label, cwd, runtime):
    assert argv == command['argv'] and label == 'release-joint-cycle' and cwd == consumer
    return streamed_command(argv, OUTPUT / ('android-jni-' + label), cwd, environment=runtime)
started = time.monotonic()
try:
    state['outcomes'] = cycle.qualify(binary, consumer, fresh, OUTPUT, 'release', environment, run)
    assert set(state['outcomes']) == set(cycle.TESTS)
    assert package.source_inputs() == before and file_hashes(consumer) == inputs['c_source_before']
    assert {str(path): digest(path) for path in runtime_files} == runtime_before
    assert tool_identity(java_home) == inputs['tools']['java']
    state['completed'] = True
except BaseException as error:
    state.update(error_type=type(error).__name__, error=str(error))
    for name in ('kind', 'cleanup_ambiguous', 'signal_number'):
        if hasattr(error, name): state[name] = getattr(error, name)
    raise
finally:
    state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
    save(BASE / 'RESULT.json', state)
    print(json.dumps({key: state.get(key) for key in ('completed', 'error', 'elapsed_seconds', 'private_fixture_root')}), flush=True)
