import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'artifact'))
from pathlib import Path, PureWindowsPath
import hashlib,io,json,re,subprocess,zipfile
from evidence_io import parse_strict_json_bytes as parsed
from installed_rust_graph import external_lock
out=Path(__file__).resolve().parent
head='b47eb5417d3c25cb7bd05dd91e56ad73777c56fb';runid=39108513606
api=lambda tail: subprocess.check_output(['gh','api','repos/billlza/q-periapt/'+tail],timeout=60)
run=parsed(api(f'actions/runs/{runid}'),label='run')
assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==head
metadata=parsed(api(f'actions/runs/{runid}/artifacts'),label='artifacts')
with zipfile.ZipFile(out/'producer.zip') as z:
 producer_bytes=z.read('INPUT.json');producer=parsed(producer_bytes,label='producer')
 assert producer['source_commit']==head
 with zipfile.ZipFile(io.BytesIO(z.read('consumer.zip'))) as payload:
  original_lock=payload.read('original-Cargo.lock')
  header=payload.read('qpc_owner.h')
expected_cases={(name,trust,'0' if name in ('create','reconcile','open') else '1') for name in ('create','reconcile','open','duplicate','busy','missing','advanced') for trust in ('fixed','recoverable')}
expected_build={'AWS_LC_SYS_STATIC_x86_64_pc_windows_msvc':'1','AWS_LC_SYS_USE_SYSTEM_x86_64_pc_windows_msvc':'0','AWS_LC_SYS_CFLAGS_x86_64_pc_windows_msvc':'/WX /Ddllexport='}
rows=[]
for os in ('windows-2022','windows-2025'):
 a=next(a for a in metadata['artifacts'] if a['name']=='windows-installed-c-'+os)
 assert a['workflow_run']['head_sha']==head and not a['expired']
 path=out/(os.replace('-', '')+'.zip')
 if not path.exists():path.write_bytes(api(f"actions/artifacts/{a['id']}/zip"))
 data=path.read_bytes();assert len(data)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==a['digest']
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  names=z.namelist();assert len(names)==len(set(names))
  documents={name:parsed(z.read(name),label=name) for name in names if name.endswith('.json') and '/' not in name}
  result=documents['RESULT.json']
  assert result['input']==producer and result['input_sha256']==hashlib.sha256(producer_bytes).hexdigest()
  assert result['aws_lc_build']==expected_build and set(result['profiles'])=={'debug','release'}
  assert result['rustc'].splitlines()[0]=='rustc 1.98.1 (48a229cea 2026-09-01)' and 'host: x86_64-pc-windows-msvc' in result['rustc']
  assert z.read('source-head.stdout').decode().strip()==head
  graph=parsed(z.read('metadata.stdout'),label='resolved graph')
  local={p['name']:p for p in graph['packages'] if p['name'].startswith('q-periapt')}
  assert set(local)==set(producer['versions'])|{producer['consumer']}
  base=PureWindowsPath(local[producer['consumer']]['manifest_path']).parent
  assert base.is_absolute() and base.drive.lower()=='c:' and base.name=='consumer'
  assert PureWindowsPath(documents['metadata.json']['cwd'])==base
  for name,version in producer['versions'].items():
   row=local[name];assert row['source'] is None and row['version']==version
   assert PureWindowsPath(row['manifest_path'])==base/'packages'/f'{name}-{version}'/'Cargo.toml'
  for p in graph['packages']:
   if not p['name'].startswith('q-periapt'):assert p['source']=='registry+https://github.com/rust-lang/crates.io-index'
  locked=z.read('Cargo.lock');before=external_lock(original_lock);after=external_lock(locked)
  assert all(before.get(k)==v for k,v in after.items())
  assert result['resolution']['lockfile_sha256']==hashlib.sha256(locked).hexdigest()
  for name,record in documents.items():
   if name!='RESULT.json':assert record['returncode']==0,name
  for name in names:
   if name.endswith(('.stdout','.stderr')):
    assert not re.search(r'(?mi)^\s*(warning:|error:)',z.read(name).decode()),name
  profiles={}
  for profile in ('debug','release'):
   row=result['profiles'][profile]
   assert {tuple(x) for x in row['cases']}==expected_cases and len(row['cases'])==14
   runtime=z.read(profile+'-runtime.stdout').decode();diagnostics=z.read(profile+'-runtime.stderr').decode()
   assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in runtime
   markers=re.findall(r'^WINDOWS_INSTALLED_C_FIRST_USE case=(\w+) trust=(\w+) exit=(\d+) expected=true$',diagnostics,re.M)
   assert len(markers)==14 and set(markers)==expected_cases
   assert z.read(profile+'-guard.stdout').decode().strip()=='QPC_CONFIGURATION_HEADER_GUARD_PASS'
   platform_command=documents[profile+'-platform-runtime.json']
   assert len(platform_command['argv'])==1 and PureWindowsPath(platform_command['argv'][0]).name=='consumer-platform-test.exe'
   assert z.read(profile+'-platform-runtime.stdout').decode().strip()=='CONSUMER_PLATFORM_PASS native_worker_join=true monotonic_clock=true sleep_completed=true'
   assert z.read(profile+'-report-runtime.stdout').decode().strip()=='REPORT_BUFFER_PASS canonical_bytes=true size_limit=true failure_sticky=true'
   assert PureWindowsPath(documents[profile+'-report-runtime.json']['argv'][0]).name=='report-buffer-test.exe'
   report_compile=documents[profile+'-report-compile.json']['argv']
   assert report_compile[:6]==['clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic'] and report_compile[6:-3]==(['-O0','-g'] if profile=='debug' else ['-O2'])
   assert PureWindowsPath(report_compile[-3]).name=='report_buffer_test.c'

   compiled=documents[profile+'-platform-compile.json']['argv']
   assert compiled[:6]==['clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic']
   assert compiled[6:-3]==(['-O0','-g'] if profile=='debug' else ['-O2'])
   assert PureWindowsPath(compiled[-3]).name=='consumer_platform_test.c'

   # Preserve every initial-configuration assertion and add current controls.
   effects=re.findall(r'^WINDOWS_C_EFFECT case=([a-z-]+) original_boundary=true$',diagnostics,re.M)
   assert len(effects)==6 and set(effects)=={'commit','directory-reparse','ancestor-reparse','leaf-reparse','hardlink','public-acl'}
   assert diagnostics.splitlines().count('WINDOWS_C_RECORD bounded_read=true exact_retention=true missing_original_refused=true')==1
   expected_owner={
    'c_client_owns_installed_connection_rekeys_and_reconciles_exact_delivery',
    'c_device_parents_keep_peer_lifetimes_and_reconcile_original_delivery',
    'c_configured_peers_reopen_and_reconcile_original_delivery',
    'c_server_preserves_callback_failures_unknown_commits_replay_and_rekey',
    'c_recovery_preserves_complete_loss_accounting_after_revocation_and_process_exit',
    'installed_owner_restores_expired_advertisement_and_reconciles_original_message',
    'c_account_owner_requires_all_devices_and_reconciles_original_members',
    'fixture::service_peer_process',
    'fixture::owned_services_connect_restart_rekey_and_reconcile_unknown_delivery',
    'fixture::reopen::public_session_reopen_after_expiry_reconciles_unknown_commit_over_real_tls'}
   owner=z.read(profile+'-owner-runtime.stdout').decode()
   actual_owner=re.findall(r'^test ([a-z_:]+) \.\.\. ok$',owner,re.M)
   assert len(actual_owner)==10 and set(actual_owner)==expected_owner
   assert 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in owner
   assert row['owner_tests']==sorted(expected_owner)
   assert documents[profile+'-owner-runtime.json']['argv']==['cargo','test','--locked','--test','c_owner',*(['--release'] if profile=='release' else []),'--','--nocapture']
   image=z.read(profile+'-live-image.stdout').decode()
   image_pass='WINDOWS_LIVE_IMAGE_PASS bounded=true original_bytes=true original_lock_held=true ordinary_read_refused=true competing_writer_refused=true verbatim_path=true'
   assert image.splitlines().count(image_pass)==1
   observations=re.findall(r'^WINDOWS_LIVE_IMAGE_CRT phase=(\d+) success=(\d+) stage=(\d+) errno=(\d+) native=(\d+) dos=(\d+) closed=(\d+)$',image,re.M)
   assert len(observations)==3
   assert observations[0][0:3]==('0','1','0') and observations[0][-1]=='0'
   for phase,success,stage,errno,native,dos,closed in observations[1:]:
    assert success=='0' and stage!='0' and ('32' in (native,dos)) and closed=='0'
   assert [r[0] for r in observations]==['0','1','2']
   assert z.read(profile+'-root-publication.stdout').decode().strip()=='WINDOWS_ROOT_PUBLICATION_PASS maximum=8388608 default_limit=1048576 exact_duplicate_retained=true conflict_preserves_original=true bounds_before_publication=true full_readback=true'
   assert z.read(profile+'-root-contract.stdout').decode().strip()=='ROOT_C_CONTRACT guarded_short_scope=true guarded_short_alternative=true outputs_preserved=true lifecycle_qualified=false'
   assert z.read(profile+'-effect-preflight.stdout').decode()=='effect-contract: two exact effects, duplicate idempotence, wrong payload and conflicting replay refused\nrecord-contract: bounded read, exact retention, missing and changed originals refused\n'
   publication=z.read(profile+'-publication-probe.stdout').decode()
   assert publication.splitlines().count('WINDOWS_RENAME_PROBE variant=2 bytes=184 success=1 error=0 source=1 target=0')==1
   assert len(re.findall(r'^WINDOWS_RENAME_COLLISION success=0 error=(?:80|183)$',publication,re.M))==1
   for control,source in (('live-image','live_image_test.c'),('root-publication','root_publication_test.c'),('effect','application_effect_test.c'),('publication-probe','windows_publication_probe.c')):
    argv=documents[profile+'-'+control+'-compile.json']['argv']
    assert argv[:6]==['clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic']
    flags=['-O0','-g'] if profile=='debug' else ['-O2']
    assert argv[6:6+len(flags)]==flags
    assert PureWindowsPath(argv[6+len(flags)]).name==source
    assert argv[7+len(flags):-1]==['-lntdll','-ladvapi32','-o']
   assert set(row['owner_public'])=={'client','device','configured','account','server','recovery','restore'}
   assert set(row['roots']['public'])=={'original','transition','bound-transition','adoption'}
   input_control=z.read(profile+'-input.stdout').decode()
   assert input_control.splitlines()[-1]=='WINDOWS_INPUT_PASS unicode=true extended_separator=true native_sdk_child_path=true held_publisher_read=true mandatory_lock_preserved=true missing_pending=true malformed_refused=true'
   assert len(input_control.splitlines())==3
   assert re.fullmatch(r'WINDOWS_INPUT_RAW_EXTENDED success=0 error=\d+',input_control.splitlines()[0])
   assert input_control.splitlines()[1]=='WINDOWS_INPUT_OLD_MARKER success=0 error=32'
   compiled=documents[profile+'-input-compile.json']['argv']
   flags=['-O0','-g'] if profile=='debug' else ['-O2']
   assert compiled[:6]==['clang','-std=c11','-Wall','-Wextra','-Werror','-Wpedantic']
   assert compiled[6:6+len(flags)]==flags and PureWindowsPath(compiled[6+len(flags)]).name=='windows_input_test.c'
   assert compiled[7+len(flags):-1]==['-lntdll','-ladvapi32','-o']
   configuration=row['configuration']
   assert set(configuration['verification']['scenarios'])=={f'{carrier}-{trust}' for carrier in ('local','signed','tls') for trust in ('fixed','recoverable')}
   assert len(configuration['files'])==190
   assert configuration['binaries']=={'first-configuration.exe':row['client_sha256'],'owner-client.exe':row['owner_client_sha256'],'q_periapt_continuity_c_consumer.dll':row['files']['q_periapt_continuity_c_consumer.dll']}


   payload_bytes=z.read(profile+'-c-input.zip');assert hashlib.sha256(payload_bytes).hexdigest()==row['zip_sha256']
   with zipfile.ZipFile(io.BytesIO(payload_bytes)) as payload:
    assert len(payload.namelist())==3 and set(payload.namelist())==set(row['files'])
    for name,sha in row['files'].items():assert hashlib.sha256(payload.read(name)).hexdigest()==sha
    assert payload.read('qpc_owner.h')==header
    dll=payload.read('q_periapt_continuity_c_consumer.dll')
   dllpath=out/(os+'-'+profile+'-b47.dll');dllpath.write_bytes(dll)
   pe=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/llvm-readobj','--coff-exports',str(dllpath)],text=True)
   exports=re.findall(r'^  Name: (\S+)$',pe,re.M)
   assert len(exports)==157 and set(exports)==set(producer['exports'])
   profiles[profile]={'independent_DLL_sha256':hashlib.sha256(dll).hexdigest(),'independent_exports':157,'guard_passed':True,'actual_C_process_cases':14,'trust_modes':['fixed','recoverable'],'typed_refusals':[500,703,203,107],'duplicate_complete_file_image_preserved':True,'held_owner_floor_and_enabled_state_preserved':True,'client_sha256_producer_observation':row['client_sha256'],'original_owner_entries':10,'effect_controls':6,'live_image_CRT_observations':observations,'mapped_image_original_lock_retained':True,'root_publication_bytes':8388608,'root_default_limit':1048576,'root_guard':True,'extended_input_and_shared_marker_control':True,'native_UTF8_SDK_child_path_checked_before_normalization':True,'first_registration_scenarios':6,'configuration_public_files':190}
  rows.append({'os':os,'artifact_id':a['id'],'artifact_sha256':a['digest'],'artifact_bytes':a['size_in_bytes'],'metadata_and_original_dependency_lock_verified':True,'profiles':profiles})
report={'head':head,'run':runid,'qualified':True,'scope':'Installed Windows C controls, initial configuration and original ten owner test entries; root/public lifecycle semantics require separate independent replay. Same engine and host; no independent implementation, power-loss or release admission.','jobs':2,'profiles':4,'C_case_processes':56,'guard_processes':4,'platform_processes':4,'bounded_report_processes':4,'platform_scope':'Native caller worker/join/clock/sleep only; no C SDK foreign-worker or full lifecycle qualification','SDK_archives':9,'candidate_archives':1,'artifacts':rows,'client_digest_scope':'Client executable hashes are producer observations; downloaded DLL/header/import-library hashes and PE exports were independently checked.'}
(out/'NATIVE_C_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'qualified':True,'run':runid,'profiles':4,'actual_C_cases':56,'guards':4,'independent_exact_exports_per_DLL':157}))
