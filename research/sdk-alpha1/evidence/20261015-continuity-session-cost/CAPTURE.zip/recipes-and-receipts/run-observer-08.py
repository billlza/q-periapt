from pathlib import Path
import json
import os
import platform
import re
import subprocess
import sys
import time
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
label=sys.argv[1];samples=int(sys.argv[2]);profiles=sys.argv[3:]
sdk.require(re.fullmatch(r'[a-z0-9-]+',label) is not None and 8<=samples<=128 and samples%4==0,'run scope')
sdk.require(profiles and len(profiles)==len(set(profiles)) and set(profiles)<={'local','witness'},'profile selection')
build=json.loads((stage/'BUILD_07.json').read_text());binary=Path(build['binary'])
sdk.require(build['completed'] and sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'measured executable changed')
output=stage/label;output.mkdir(mode=0o700)
state={'completed':False,'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],'profiles':profiles,'samples_per_block':samples,'machine':platform.machine(),'os_release':platform.release(),'clock':'Rust Instant monotonic wall time','process_rss_unit':'bytes, per Darwin getrusage(2)','observations':[],'release_claim_eligible':False,'energy_measured':False,'host_controls':'Uncontrolled host; no other applications or power settings changed','memory_scope':'Whole test process: two SDK peers, optional witness, test harness, workload buffers and bounded timing records; not isolated SDK peak memory'}
try:
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'source tree dirty')
    sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'],'source head changed')
    for profile in profiles:
        folder=output/profile;folder.mkdir(mode=0o700)
        environment={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','LD_','QPERIAPT_PUBLIC_SERVICE_','QPC_COST_'))}
        environment.update(QPC_COST_PROFILE=profile,QPC_COST_SAMPLES=str(samples),QPC_COST_OUTPUT=str(folder/'RESULT.json'),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(folder/'runtime'),RUST_BACKTRACE='1')
        row={'profile':profile,'completed':False,'load_before':os.getloadavg(),'started_unix':time.time()};state['observations'].append(row)
        print(json.dumps({'profile':profile,'phase':'fresh runtime','samples':samples}),flush=True)
        raw=sdk.command(['/usr/bin/time','-l','-o',str(folder/'time.txt'),str(binary),'--exact','measure_session_cost','--nocapture','--test-threads=1'],folder/'command',root,environment=environment)
        sdk.require(re.search(rb'test result: ok\. 1 passed; 0 failed; 0 ignored;',raw) is not None,'actual measurement test did not complete')
        value=json.loads((folder/'RESULT.json').read_text());sdk.require(value['completed'] and value['sdk_and_server_closed'] and value['profile']==profile and value['samples_per_block']==samples,'result scope')
        sdk.require(len(value['samples'])==samples and value['server']['effects']==samples+1 and value['server']['calls']==samples+2,'complete workload census')
        resource=(folder/'time.txt').read_text();cpu=re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys',resource);rss=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resource,re.M)
        sdk.require(cpu is not None and rss is not None,'Darwin time resource record missing')
        row.update(completed=True,result_sha256=sdk.snapshot(folder/'RESULT.json').sha256,resources={'real_seconds':float(cpu[1]),'user_seconds':float(cpu[2]),'system_seconds':float(cpu[3]),'max_rss_bytes':int(rss[1])},load_after=os.getloadavg(),finished_unix=time.time(),runtime_sealed=True)
        print(json.dumps({'profile':profile,'completed':True,'resources':row['resources']}),flush=True)
    for name,digest in build['fixture_files'].items():sdk.require(sdk.snapshot(stage/'fixture-06'/name).sha256==digest,'consumed fixture source changed')
    sdk.require(sdk.snapshot(binary,maximum=256*1024**2).sha256==build['binary_sha256'],'measured executable changed')
    sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'],'source changed during observation')
    state['completed']=True
except BaseException as error:
    state['failure']=repr(error);raise
finally:
    sdk.write_json(output/'RUN.json',state)
print(json.dumps({'completed':True,'profiles':profiles,'samples_per_block':samples}))
