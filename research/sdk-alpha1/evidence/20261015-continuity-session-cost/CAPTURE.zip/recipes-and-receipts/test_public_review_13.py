from pathlib import Path
import copy
import json
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parent))
from public_review_12 import verify

class CostEvidenceControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        stage=Path(__file__).parent
        cls.cases=[json.loads((stage/f'block-09-{block:02}'/profile/'RESULT.json').read_text()) for block in range(5) for profile in ['local','witness']]
    def test_all_completed_captures(self):
        self.assertEqual(sum(verify(row)['samples'] for row in self.cases),640)
    def test_every_sample_identity_substitution(self):
        for case in self.cases:
            for index in range(len(case['samples'])):
                with self.subTest(profile=case['profile'],process=case['process_id'],index=index):
                    value=copy.deepcopy(case);value['samples'][index]['index']=-1
                    with self.assertRaisesRegex(ValueError,'order'):verify(value)
    def test_missing_sample(self):
        value=copy.deepcopy(self.cases[0]);value['samples'].pop()
        with self.assertRaisesRegex(ValueError,'census'):verify(value)
    def test_false_consumption(self):
        value=copy.deepcopy(self.cases[0]);value['samples'][0]['server']['consumed']=False
        with self.assertRaisesRegex(ValueError,'receiver'):verify(value)
    def test_invalid_time(self):
        value=copy.deepcopy(self.cases[0]);value['samples'][0]['send_ns']=-1
        with self.assertRaisesRegex(ValueError,'duration'):verify(value)
    def test_forged_witness_aggregate(self):
        value=copy.deepcopy(self.cases[1]);value['witness']['handle_ns']+=1
        with self.assertRaisesRegex(ValueError,'aggregate'):verify(value)
    def test_authority_admission_cannot_replace_hot_query(self):
        value=copy.deepcopy(self.cases[1]);index=value['samples'][0]['witness_before']['requests']
        value['witness']['rows'][index]['request_tag']=4;value['witness']['rows'][index]['reply_tag']=5
        with self.assertRaisesRegex(ValueError,'hot send'):verify(value)
    def test_missing_retired_refusal(self):
        value=copy.deepcopy(self.cases[0]);value['recovery']['retired_send_refused']=False
        with self.assertRaisesRegex(ValueError,'retired send'):verify(value)
    def test_recovery_created_second_effect(self):
        value=copy.deepcopy(self.cases[0]);value['recovery']['recovered_server']['effects']=1
        with self.assertRaisesRegex(ValueError,'recovery'):verify(value)

if __name__=='__main__':unittest.main()
