from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
pilot=json.loads((stage/'pilot-08/RUN.json').read_text());sdk.require(pilot['completed'],'pilot incomplete')
rows=[]
try:
    for block in range(5):
        label=f'block-09-{block:02}'
        order=['local','witness'] if block%2==0 else ['witness','local']
        print(json.dumps({'block':block,'phase':'begin','order':order,'samples_per_profile':64}),flush=True)
        sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(stage/'run-observer-08.py'),label,'64',*order],stage/(label+'-driver'),root)
        run=json.loads((stage/label/'RUN.json').read_text());sdk.require(run['completed'],'block did not complete')
        rows.append({'block':block,'label':label,'order':order,'run_sha256':sdk.snapshot(stage/label/'RUN.json').sha256})
        print(json.dumps({'block':block,'completed':True,'results':run['observations']}),flush=True)
finally:
    sdk.write_json(stage/'BATCHES_09.json',{'completed':len(rows)==5,'blocks':rows,'samples_per_profile_per_block':64,'profiles':['local','witness'],'all_fresh_runtime_cohorts':True,'release_claim_eligible':False})
