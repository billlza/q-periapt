from pathlib import Path
import json
import os
import subprocess
import tomllib
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;fixture=stage/'fixture'
toolchain=root/'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin/bin'
environment=dict(os.environ);environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e',CARGO_NET_OFFLINE='true',RUSTFLAGS='-D warnings',CARGO_TARGET_DIR=str(stage/'native-target-02'),PATH=str(toolchain)+':'+environment['PATH'])
cargo=str(toolchain/'cargo')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root),'product tree changed before measurement build')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
sdk.command([cargo,'metadata','--format-version','1','--offline','--manifest-path',str(fixture/'Cargo.toml')],stage/'metadata-02',root,environment=environment)
def registry(path):return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
actual=registry(fixture/'Cargo.lock');allowed=registry(root/'Cargo.lock')|registry(root/'research/continuity-identity-candidate/Cargo.lock')
sdk.require(actual<=allowed,'measurement dependency drift: '+repr(actual-allowed))
sources={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()}
sdk.write_json(stage/'BUILD_INPUTS_02.json',{'source_commit':head,'fixture_files':sources,'canonical_registry_dependencies':sorted(actual),'environment':{key:environment[key] for key in ['CARGO_HOME','CARGO_NET_OFFLINE','RUSTFLAGS','CARGO_TARGET_DIR','PATH']}})
sdk.command([cargo,'test','--locked','--offline','--release','--no-run','--test','session_cost','--message-format=json','--manifest-path',str(fixture/'Cargo.toml')],stage/'compile-02',root,environment=environment)
outputs=[json.loads(line) for line in (stage/'compile-02.stdout').read_text().splitlines() if line.startswith('{')]
bins=[r['executable'] for r in outputs if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='session_cost']
sdk.require(len(bins)==1,'measured binary identity')
sdk.require(sources=={str(p.relative_to(fixture)):sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()},'fixture changed during compilation')
sdk.require(not subprocess.check_output(['git','status','--porcelain'],cwd=root) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head,'product source changed during build')
sdk.write_json(stage/'BUILD_02.json',{'completed':True,'source_commit':head,'binary':bins[0],'binary_sha256':sdk.snapshot(Path(bins[0]),maximum=256*1024**2).sha256,'fixture_files':sources,'profile':'release opt-level=3 thin-LTO codegen-units=1 overflow-checks=true','warnings_as_errors':True})
print('Isolated native session observer compiled against the unchanged source: '+head)
