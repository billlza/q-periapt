from pathlib import Path
import json
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))
from public_review import verify,quantiles
batches=json.loads((stage/'BATCHES_09.json').read_text());sdk.require(batches['completed'] and len(batches['blocks'])==5,'batch census')
summary={'completed':False,'source_commit':'1fefe0f7154ac063d8488276442a62a5095f2a6d','blocks':[],'profiles':{},'total_hot_sends':0,'public_effects_verified':0,'release_claim_eligible':False,'raw_reserve_ns_means':'next_message_id read-only current slot lookup, not durable reservation; reservation occurs inside send_message','limitations':['Uncontrolled macOS host and one implementation','Fresh mutually authenticated hybrid TLS connection for each send; no TLS resumption','Local-only and required-witness policies are distinct security contracts','Whole-process RSS includes both peers, optional witness and bounded observation records','Observed sample quantiles do not establish production tails, non-regression, energy or throughput guarantees']}
pids=set();sessions=set();all_rows={'local':[],'witness':[]};resources={'local':[],'witness':[]}
for block in batches['blocks']:
    directory=stage/block['label'];run=json.loads((directory/'RUN.json').read_text())
    sdk.require(sdk.snapshot(directory/'RUN.json').sha256==block['run_sha256'] and run['completed'],'block receipt differs')
    sdk.require(run['profiles']==(['local','witness'] if block['block']%2==0 else ['witness','local']),'profile order changed')
    for observation in run['observations']:
        profile=observation['profile'];folder=directory/profile;value=json.loads((folder/'RESULT.json').read_text());checked=verify(value)
        sdk.require(observation['completed'] and observation['runtime_sealed'] and sdk.snapshot(folder/'RESULT.json').sha256==observation['result_sha256'],'runtime receipt changed')
        sdk.require(value['process_id'] not in pids and tuple(value['session']) not in sessions,'runtime identity reused');pids.add(value['process_id']);sessions.add(tuple(value['session']))
        # These are the observer's explicit public synthetic business outputs.
        # No key, encrypted journal, or SDK owner is opened by this reader.
        effects=folder/'runtime/responder/measured-effects'
        sdk.require({p.name for p in effects.iterdir()}==set(checked['effects']),'public effect-file census')
        for name,expected in checked['effects'].items():sdk.require(sdk.snapshot(effects/name,maximum=32768).data==expected,'actual public application payload differs')
        rows=value['samples'];all_rows[profile].extend(rows);resources[profile].append(observation['resources'])
        summary['blocks'].append({'block':block['block'],'profile':profile,'samples':len(rows),'payloads':{str(size):quantiles([r['send_ns'] for r in rows if r['payload_bytes']==size]) for size in [0,64,1024,16384]},'send_ns':quantiles([r['send_ns'] for r in rows]),'witness_request_counts':sorted({sum(v.values()) for v in checked['witness_per_sample']}),'witness_query_counts':sorted({v.get(1,0) for v in checked['witness_per_sample']}),'witness_advance_counts':sorted({v.get(2,0) for v in checked['witness_per_sample']}),'witness_handle_ns':quantiles([r['witness_after']['handle_ns']-r['witness_before']['handle_ns'] for r in rows]) if profile=='witness' else None,'setup_ns':value['setup_ns'],'client_open_ns':value['client_open_ns'],'server_open_ns':value['server_open_ns'],'bootstrap_ns':value['bootstrap']['elapsed_ns'],'rekey_ns':value['rekey']['elapsed_ns'],'recovery_ns':value['recovery']['recovery_send_ns'],'client_reopen_ns':value['recovery']['client_reopen_ns'],'resources':observation['resources'],'load_before':observation['load_before'],'load_after':observation['load_after']})
        summary['total_hot_sends']+=len(rows);summary['public_effects_verified']+=len(checked['effects'])
for profile,rows in all_rows.items():
    summary['profiles'][profile]={'samples':len(rows),'payloads':{str(size):quantiles([r['send_ns'] for r in rows if r['payload_bytes']==size]) for size in [0,64,1024,16384]},'send_ns':quantiles([r['send_ns'] for r in rows]),'slot_lookup_ns':quantiles([r['reserve_ns'] for r in rows]),'status_ns':quantiles([r['status_ns'] for r in rows]),'application_ns':quantiles([r['server']['application_ns'] for r in rows]),'max_rss_bytes':[r['max_rss_bytes'] for r in resources[profile]]}
sdk.require(summary['total_hot_sends']==640 and summary['public_effects_verified']==650 and len(pids)==10,'full measurement census')
summary['completed']=True;sdk.write_json(stage/'SUMMARY_10.json',summary)
print(json.dumps({'completed':True,'hot_sends':640,'public_effects_verified':650,'profiles':summary['profiles']}))
