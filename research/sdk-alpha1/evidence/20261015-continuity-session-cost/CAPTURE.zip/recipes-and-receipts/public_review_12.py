"""Check observer accounting and public business outputs without opening SDK stores."""
from collections import Counter
import math

def require(value,message):
    if not value:raise ValueError(message)

def duration(value):
    require(type(value) is int and 0<value<120_000_000_000,'invalid monotonic duration')

def identity(value):
    require(isinstance(value,list) and len(value)==32 and all(type(x) is int and 0<=x<=255 for x in value) and any(value),'invalid public identity')
    return bytes(value)

def verify(value):
    require(value['completed'] and value['sdk_and_server_closed'] and not value['release_claim_eligible'],'producer incomplete')
    profile=value['profile'];count=value['samples_per_block']
    require(profile in {'local','witness'} and type(count) is int and 8<=count<=128 and count%4==0,'workload scope')
    session=identity(value['session']);rows=value['samples'];require(len(rows)==count,'sample census')
    wire=value['witness'];require(wire['closed'] and len(wire['rows'])<=16384,'witness closure/capacity')
    prefix=[{'requests':0,'handle_ns':0,'read_ns':0,'write_ns':0,'framed_bytes':0}]
    for row in wire['rows']:
        require((row['request_tag'],row['reply_tag']) in {(1,1),(2,2),(4,5)},'unexpected witness request/outcome')
        for field in ['handle_ns','read_ns','write_ns']:duration(row[field])
        prior=prefix[-1]
        prefix.append({'requests':prior['requests']+1,'framed_bytes':prior['framed_bytes']+7341,**{field:prior[field]+row[field] for field in ['handle_ns','read_ns','write_ns']}})
    for field in ['handle_ns','read_ns','write_ns','framed_bytes']:require(wire[field]==prefix[-1][field],'witness aggregate differs')
    require(bool(wire['rows'])==(profile=='witness'),'security profile/witness differs')
    def snapshots(item):
        before,after=item['witness_before'],item['witness_after']
        for snapshot in (before,after):
            n=snapshot['requests'];require(type(n) is int and 0<=n<len(prefix) and snapshot==prefix[n],'witness timing prefix differs')
        require(before['requests']<=after['requests'],'witness counter reversed')
        return Counter(r['request_tag'] for r in wire['rows'][before['requests']:after['requests']])
    for field in ['setup_ns','client_open_ns','server_open_ns']:duration(value[field])
    bootstrap=value['bootstrap'];duration(bootstrap['elapsed_ns']);snapshots(bootstrap)
    require(bootstrap['server']['established']==value['session'] and bootstrap['exchanges']>=1,'bootstrap confirmation differs')
    seen=set();effects={};counts=[]
    for index,row in enumerate(rows):
        require(row['index']==index and row['payload_bytes']==[0,64,1024,16384][index%4] and row['epoch']==int(index>=count//2),'sample identity/order differs')
        message=identity(row['message']);require(message not in seen,'message identity reused');seen.add(message)
        require(int.from_bytes(message[:8],'big')==row['epoch'],'message epoch differs')
        for field in ['reserve_ns','send_ns','status_ns','total_ns']:duration(row[field])
        require(row['total_ns']>=sum(row[k] for k in ['reserve_ns','send_ns','status_ns']),'overlapping/disordered timing intervals')
        receiver=row['server'];require(receiver['consumed'] and not receiver['duplicate'] and receiver['session']==value['session'] and receiver['message']==row['message'] and receiver['calls']==receiver['effects']==1,'receiver outcome differs')
        duration(receiver['elapsed_ns']);duration(receiver['application_ns']);require(receiver['application_ns']<=receiver['elapsed_ns'],'application interval outside server operation')
        sample_counts=snapshots(row);require(set(sample_counts)<={1,2},'unexpected authority admission during hot send');counts.append(dict(sample_counts))
        effects[message.hex()]=session+message+bytes([index%251])*row['payload_bytes']
    rekey=value['rekey'];duration(rekey['elapsed_ns']);snapshots(rekey)
    require(rekey['server']['epoch']==1 and rekey['exchanges']>=1,'rekey confirmation differs')
    recovery=value['recovery'];message=identity(recovery['message']);require(message not in seen,'recovery reuses prior message')
    require(recovery['retired_send_refused'],'retired send must be refused')
    for field in ['unknown_ns','client_reopen_ns','recovery_send_ns','retired_refusal_ns']:duration(recovery[field])
    require(recovery['lost']['application_result_lost'] and recovery['lost']['calls']==recovery['lost']['effects']==1,'unknown original effect missing')
    require(recovery['reopened_server']['reopened'],'original receiver was not reopened')
    require(recovery['recovered_server']['consumed'] and not recovery['recovered_server']['duplicate'] and recovery['recovered_server']['session']==value['session'] and recovery['recovered_server']['message']==recovery['message'] and recovery['recovered_server']['calls']==1 and recovery['recovered_server']['effects']==0,'unknown effect recovery changed outcome')
    recovery_counts=snapshots(recovery)
    initial_authority=sum(r['request_tag']==4 for r in wire['rows'][:bootstrap['witness_before']['requests']])
    total_authority=sum(r['request_tag']==4 for r in wire['rows'])
    require((initial_authority,recovery_counts.get(4,0),total_authority)==((4,2,6) if profile=='witness' else (0,0,0)),'authority activation/reopen census differs')
    effects[message.hex()]=session+message+b'original unknown effect'
    require(value['server']['closed'] and value['server']['effects']==count+1 and value['server']['calls']==count+2,'complete business-effect census differs')
    return {'profile':profile,'samples':count,'effects':effects,'witness_per_sample':counts}

def quantiles(values):
    require(values and all(type(v) is int and v>0 for v in values),'empty/invalid samples')
    ordered=sorted(values)
    return {'count':len(values),'p50':ordered[math.ceil(len(values)*.5)-1],'p95':ordered[math.ceil(len(values)*.95)-1],'min':ordered[0],'max':ordered[-1]}
