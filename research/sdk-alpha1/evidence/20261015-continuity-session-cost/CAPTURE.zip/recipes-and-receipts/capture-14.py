from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(stage))
from public_review_12 import verify
sys.path.insert(0,str(root/'target/continuity-apple-pending-continuation/attempt-12'))
from public_capture_check import contains_private_pem
summary=json.loads((stage/'SUMMARY_12.json').read_text());build=json.loads((stage/'BUILD_07.json').read_text())
sdk.require(summary['completed'] and summary['total_hot_sends']==640 and summary['public_effects_verified']==650,'measurement readback incomplete')
sdk.require(json.loads((stage/'public-controls-13.json').read_text())['returncode']==0,'reader controls incomplete')
sdk.require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['source_commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=root),'source changed before seal')
for name,digest in build['fixture_files'].items():sdk.require(sdk.snapshot(stage/'fixture-06'/name).sha256==digest,'measured fixture changed')
sdk.require(sdk.snapshot(Path(build['binary']),maximum=256*1024**2).sha256==build['binary_sha256'],'measured executable changed')
entries={}
def add(path,name):
    sdk.require(name not in entries and not path.is_symlink(),'capture duplicate/symlink')
    entries[name]=sdk.snapshot(path,maximum=32*1024**2).data
for path in sorted(stage.iterdir()):
    if path.is_file() and path.suffix in {'.py','.json','.stdout','.stderr'} and path.name!='resource-units-13.stdout':add(path,'recipes-and-receipts/'+path.name)
entries['recipes-and-receipts/resource-unit-excerpt.txt']=b'Darwin getrusage(2), observed on macOS 27.0.1: ru_maxrss is "the maximum resident set size utilized (in bytes)."\n'
for version in ['fixture','fixture-06']:
    for path in sorted((stage/version).rglob('*')):
        if path.is_file():add(path,version+'/'+path.relative_to(stage/version).as_posix())
reference=root/'research/continuity-identity-candidate/tests'
add(reference/'owned_connection.rs','reference/owned_connection.rs')
for path in sorted((reference/'owned_connection').rglob('*.rs')):add(path,'reference/owned_connection/'+path.relative_to(reference/'owned_connection').as_posix())
for label in ['pilot-05','pilot-08',*[f'block-09-{n:02}' for n in range(5)]]:
    folder=stage/label;run=json.loads((folder/'RUN.json').read_text());add(folder/'RUN.json',label+'/RUN.json')
    for observation in run['observations']:
        profile=observation['profile'];base=folder/profile
        for name in ['command.json','command.stdout','command.stderr','time.txt']:
            add(base/name,label+'/'+profile+'/'+name)
        if (base/'RESULT.json').exists():
            add(base/'RESULT.json',label+'/'+profile+'/RESULT.json')
            value=json.loads((base/'RESULT.json').read_text());checked=verify(value)
            for name,expected in checked['effects'].items():
                actual=base/'runtime/responder/measured-effects'/name
                sdk.require(sdk.snapshot(actual,maximum=32768).data==expected,'public effect changed during capture')
                add(actual,label+'/'+profile+'/public-effects/'+name)
        else:sdk.require(label=='pilot-05' and not run['completed'],'missing accepted result')
add(root/'target/continuity-apple-pending-continuation/attempt-12/public_capture_check.py','recipes-and-receipts/public_capture_check.py')
for name,payload in entries.items():
    sdk.require(not any(part in {'runtime','node_modules','.git','__pycache__'} or part.endswith(('.redb','.key')) for part in Path(name).parts),'private runtime path selected')
    if not name.endswith(('.py','.rs','.toml','.lock')):sdk.require(not contains_private_pem(name,payload),'private PEM data selected')
out=root/'research/sdk-alpha1/evidence/20261015-continuity-session-cost';out.mkdir()
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,payload in sorted(entries.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;bundle.writestr(info,payload)
manifest={'source_commit':build['source_commit'],'binary_sha256':build['binary_sha256'],'capture_sha256':sdk.snapshot(archive,maximum=128*1024**2).sha256,'members':len(entries),'files':{name:hashlib.sha256(payload).hexdigest() for name,payload in sorted(entries.items())},'native_processes':10,'hot_sends':640,'public_effects':650,'rekeys':10,'unknown_result_recoveries':10,'retired_send_refusals':10,'reader_tests':9,'sample_substitutions_rejected':640,'sdk_implementation_changed':False,'release_claim_eligible':False,'failed_pilot_retained':True,'failed_reader_retained':True,'private_stores_and_keys_excluded':True}
sdk.write_json(out/'CAPTURE.json',manifest);sdk.copy(stage/'SUMMARY_12.json',out/'SUMMARY.json')
with zipfile.ZipFile(archive) as bundle:
    sdk.require(set(bundle.namelist())==set(entries) and len(bundle.namelist())==len(entries),'capture inventory')
    for name,digest in manifest['files'].items():sdk.require(hashlib.sha256(bundle.read(name)).hexdigest()==digest,'capture member hash')
    for block in range(5):
        for profile in ['local','witness']:
            prefix=f'block-09-{block:02}/{profile}/';checked=verify(json.loads(bundle.read(prefix+'RESULT.json')))
            for name,expected in checked['effects'].items():sdk.require(bundle.read(prefix+'public-effects/'+name)==expected,'archive effect/readback differs')
sdk.write_json(out/'READBACK.json',{'completed':True,'capture_sha256':manifest['capture_sha256'],'members':len(entries),'hot_sends':640,'public_effects_verified':650,'private_runtime_opened':False})
print(json.dumps({'completed':True,'members':len(entries),'capture_sha256':manifest['capture_sha256']}))
