from pathlib import Path
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(stage/'test_public_review_13.py')],stage/'public-controls-13',root)
sdk.command(['sysctl','machdep.cpu.brand_string','hw.physicalcpu','hw.logicalcpu','hw.memsize'],stage/'host-13',root)
sdk.command(['sw_vers'],stage/'os-13',root)
sdk.command(['/usr/bin/man','2','getrusage'],stage/'resource-units-13',root)
print('Performance evidence controls and host/resource-unit capture complete')
