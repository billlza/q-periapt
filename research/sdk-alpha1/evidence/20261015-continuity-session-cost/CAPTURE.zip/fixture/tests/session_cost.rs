//! Source-bound measurements; this observer makes no release or PCS claim.
#[path="/Users/bill/Documents/Codex/sdk-020-lifecycle-ci-20261006/research/continuity-identity-candidate/tests/owned_connection.rs"]
mod fixture;
mod observer_io;
mod observer_peer;
use q_periapt_continuity_identity_candidate as p;
use p::connection_transport::{ConnectionEndpoint,Consumption,Run,Submission};
use serde_json::{json,Value};
use std::{fs,io::Write,path::PathBuf,sync::Arc,time::Instant};
use observer_peer::{Server,Task};
type Result<T>=std::result::Result<T,Box<dyn std::error::Error+Send+Sync>>;
fn check(value:bool,message:&str)->Result<()>{if value{Ok(())}else{Err(message.to_owned().into())}}
fn witness_snapshot(witness:Option<&observer_io::Witness>)->Result<Value>{
    match witness{Some(w)=>w.snapshot(),None=>Ok(json!({"requests":0,"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0}))}
}
fn send(client:&mut fixture::Peer,endpoint:&ConnectionEndpoint,address:std::net::SocketAddr,session:[u8;32],message:p::MessageId,plaintext:&[u8])->Result<p::connection_transport::Delivered>{
    let name=client.peer_name.clone();let actor=client.actor()?;
    Ok(endpoint.send(actor,Submission{session,message,plaintext,associated_data:b"session-cost/v1"},Run{address,server_name:&name,limits:p::connection_transport::RunLimits{exchanges:1,..fixture::limits()},cancel:&p::Cancellation::default()},fixture::now)?)
}

#[test]
fn measure_session_cost()->Result<()>{
    let profile=std::env::var("QPC_COST_PROFILE")?;
    check(matches!(profile.as_str(),"local"|"witness"),"unknown cost profile")?;
    let count:usize=std::env::var("QPC_COST_SAMPLES")?.parse()?;
    check((8..=128).contains(&count)&&count%4==0,"invalid measurement sample count")?;
    let output=PathBuf::from(std::env::var_os("QPC_COST_OUTPUT").ok_or("output required")?);
    let root=PathBuf::from(std::env::var_os("QPERIAPT_PUBLIC_SERVICE_EVIDENCE").ok_or("fresh private evidence root required")?);
    check(output.is_absolute()&&!output.exists()&&root.is_absolute()&&!root.exists(),"fresh output and runtime required")?;
    let mut witness=if profile=="witness"{Some(observer_io::Witness::start(&root.with_extension("witness"))?)}else{None};
    let pin=witness.as_ref().map(|w|&w.configured);
    let start=Instant::now();let setup=fixture::setup_enrolled_with_witness(pin)?;let setup_ns=start.elapsed().as_nanos();
    let start=Instant::now();let mut client=fixture::Peer::open_with_witness(&setup.initiator,pin)?;
    let mut endpoint=ConnectionEndpoint::client(&client.context,client.credentials(),fixture::tls_limits())?;let client_open_ns=start.elapsed().as_nanos();
    let server_witness=pin.map(|w|fixture::WitnessFixture{store:Arc::clone(&w.store),address:w.address});
    let mut server=Server::start(setup.responder.clone(),server_witness)?;
    let before=witness_snapshot(witness.as_ref())?;server.begin(Task::Bootstrap)?;
    let request=p::InitiationId::generate()?;let name=client.peer_name.clone();let start=Instant::now();
    let established=endpoint.establish(client.actor()?,request,Run{address:server.address,server_name:&name,limits:fixture::limits(),cancel:&p::Cancellation::default()},fixture::now)?;
    let bootstrap_ns=start.elapsed().as_nanos();let received=server.finish_operation()?;
    check(received["established"]==json!(established.session),"bootstrap peers disagree")?;
    let bootstrap=json!({"elapsed_ns":bootstrap_ns,"exchanges":established.exchanges,"server":received,"witness_before":before,"witness_after":witness_snapshot(witness.as_ref())?});
    let mut samples=Vec::with_capacity(count);let mut rekey=Value::Null;
    for index in 0..count {
        if index==count/2 {
            let before=witness_snapshot(witness.as_ref())?;
            server.begin(Task::Rekey{session:established.session,target:1})?;
            let start=Instant::now();let control=p::control_transport::ControlEndpoint::client(&client.context,established.session,client.credentials(),fixture::tls_limits())?;
            let (service,signer)=client.service.parts()?;let (journal,_)=service.stores()?;
            let done=control.run(p::control_transport::Session{journal,context:&client.context,signer},p::control_transport::Run{target:1,address:server.address,server_name:&client.peer_name,limits:fixture::limits(),cancel:&p::Cancellation::default()},fixture::now)?;
            let elapsed_ns=start.elapsed().as_nanos();let peer=server.finish_operation()?;
            check(done.epoch==1&&peer["epoch"]==1,"both peers must confirm epoch 1")?;
            rekey=json!({"elapsed_ns":elapsed_ns,"exchanges":done.exchanges,"server":peer,"witness_before":before,"witness_after":witness_snapshot(witness.as_ref())?});
        }
        let size=[0,64,1024,16384][index%4];let plaintext=vec![u8::try_from(index%251)?;size];
        let before=witness_snapshot(witness.as_ref())?;let total=Instant::now();let start=Instant::now();
        let message=client.service.stores()?.0.next_message_id(&client.context,established.session,fixture::now()?)?;let reserve_ns=start.elapsed().as_nanos();
        server.begin(Task::Message{fail_after_effect:false})?;let start=Instant::now();
        let delivered=send(&mut client,&endpoint,server.address,established.session,message,&plaintext)?;let send_ns=start.elapsed().as_nanos();
        check(delivered.consumption==Consumption::Confirmed&&delivered.message==message&&delivered.exchanges==1,"unconfirmed measured delivery")?;
        let start=Instant::now();let status=client.service.stores()?.0.message_status(&client.context,established.session,message)?;let status_ns=start.elapsed().as_nanos();
        check(status==p::MessageStatus::Acknowledged,"measured message not durably acknowledged")?;
        let receiver=server.finish_operation()?;
        check(receiver["consumed"]==true&&receiver["duplicate"]==false&&receiver["session"]==json!(established.session)&&receiver["message"]==json!(message.as_bytes())&&receiver["calls"]==1&&receiver["effects"]==1,"measured receiver effect differs")?;
        let total_ns=total.elapsed().as_nanos();let after=witness_snapshot(witness.as_ref())?;
        samples.push(json!({"index":index,"payload_bytes":size,"epoch":if index<count/2{0}else{1},"message":message.as_bytes(),"reserve_ns":reserve_ns,"send_ns":send_ns,"status_ns":status_ns,"total_ns":total_ns,"server":receiver,"witness_before":before,"witness_after":after}));
    }
    // One real external effect is durable but the host refuses consumption.
    // Restrict this invocation to one attempt, retain the original message, then
    // explicitly reopen both owners and reconcile it through the same SDK.
    let message=client.service.stores()?.0.next_message_id(&client.context,established.session,fixture::now()?)?;
    let plaintext=b"original unknown effect";let before=witness_snapshot(witness.as_ref())?;
    server.begin(Task::Message{fail_after_effect:true})?;let start=Instant::now();
    let error=send(&mut client,&endpoint,server.address,established.session,message,plaintext).expect_err("missing response cannot confirm consumption");let unknown_ns=start.elapsed().as_nanos();let lost=server.finish_operation()?;
    check(lost["application_result_lost"]==true&&lost["effects"]==1,"original effect not established")?;
    check(client.service.stores()?.0.message_status(&client.context,established.session,message)?==p::MessageStatus::Committed,"unknown delivery promoted to acknowledged")?;
    server.begin(Task::Reopen)?;let start=Instant::now();drop(endpoint);client.close();client=fixture::Peer::open_with_witness(&setup.initiator,witness.as_ref().map(|w|&w.configured))?;
    endpoint=ConnectionEndpoint::client(&client.context,client.credentials(),fixture::tls_limits())?;let reopen_ns=start.elapsed().as_nanos();let reopened_server=server.finish_operation()?;
    server.begin(Task::Message{fail_after_effect:false})?;let start=Instant::now();let confirmed=send(&mut client,&endpoint,server.address,established.session,message,plaintext)?;let recovery_ns=start.elapsed().as_nanos();let recovered_server=server.finish_operation()?;
    check(confirmed.consumption==Consumption::Confirmed&&recovered_server["calls"]==1&&recovered_server["effects"]==0,"recovery changed original effect")?;
    server.begin(Task::Message{fail_after_effect:false})?;let start=Instant::now();let duplicate=send(&mut client,&endpoint,server.address,established.session,message,plaintext)?;let duplicate_ns=start.elapsed().as_nanos();let duplicate_server=server.finish_operation()?;
    check(duplicate.consumption==Consumption::Confirmed&&duplicate_server["duplicate"]==true&&duplicate_server["calls"]==0&&duplicate_server["effects"]==0,"duplicate repeated external effect")?;
    check(client.service.stores()?.0.message_status(&client.context,established.session,message)?==p::MessageStatus::Acknowledged,"recovered message not durably acknowledged")?;
    let recovery=json!({"message":message.as_bytes(),"failure":error.to_string(),"unknown_ns":unknown_ns,"client_reopen_ns":reopen_ns,"recovery_send_ns":recovery_ns,"duplicate_send_ns":duplicate_ns,"lost":lost,"reopened_server":reopened_server,"recovered_server":recovered_server,"duplicate_server":duplicate_server,"witness_before":before,"witness_after":witness_snapshot(witness.as_ref())?});
    let server_summary=server.finish()?;check(server_summary["effects"]==count+1&&server_summary["calls"]==count+2,"final application census")?;
    client.close();drop(endpoint);drop(client);drop(setup);
    let witness_record=match witness.as_mut(){Some(w)=>w.finish()?,None=>json!({"rows":[],"handle_ns":0,"read_ns":0,"write_ns":0,"framed_bytes":0,"closed":true})};
    let result=json!({"completed":true,"profile":profile,"samples_per_block":count,"process_id":std::process::id(),"setup_ns":setup_ns,"client_open_ns":client_open_ns,"server_open_ns":server.open_ns,"session":established.session,"bootstrap":bootstrap,"samples":samples,"rekey":rekey,"recovery":recovery,"server":server_summary,"witness":witness_record,"sdk_and_server_closed":true,"release_claim_eligible":false});
    let mut file=fs::OpenOptions::new().create_new(true).write(true).open(output)?;file.write_all(&serde_json::to_vec_pretty(&result)?)?;file.sync_all()?;
    println!("SESSION_COST_COMPLETE profile={profile} samples={count} effects={} rekey=1",count+1);
    Ok(())
}
