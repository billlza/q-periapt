from pathlib import Path
import hashlib,json,shutil
import rust_sdk_profile as sdk
import continuity_android_jni as android
root=Path.cwd();out=root/'target/continuity-android-roster-integration';prior=json.loads((root/'target/continuity-local-policy-roster/STATE.json').read_text());assert prior['completed'] and not prior['live_producer'];source=Path(prior['source']);outside=source.parent;env=prior['environment'];tool=Path(env['RUSTC']).parent
files=['tests/android.rs','tests/common/android_roster_local.rs','tests/common/android_roster_traffic.rs','tests/common/android_roster_witness.rs','tests/common/android_roster_peer.rs','tests/common/android_policy_renewal.rs','tests/common/android_policy_renewal/roster.rs','tests/common/android_policy_renewal/local_roster.rs','tests/common/witness.rs']
sdk.command([str(tool/'rustfmt'),'--edition','2021','--config','skip_children=true',*[str(root/'bindings/c/ContinuityPackageConsumer'/name) for name in files]],out/'rustfmt',root)
for name in files:shutil.copy2(root/'bindings/c/ContinuityPackageConsumer'/name,source/name)
record={'completed':False,'live_producer':True,'source':str(source),'environment':env,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for tree in ['bindings/android/ContinuityPackageConsumer','bindings/c/ContinuityPackageConsumer/tests'] for p in (root/tree).rglob('*') if p.is_file()},'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'artifact').glob('continuity_android*.py')}};(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 sdk.command([str(tool/'cargo'),'clippy','--offline','--locked','--test','android','-j','2','--','-D','warnings'],out/'clippy',source,environment=dict(env,CARGO_TARGET_DIR=str(outside/'clippy-build')))
 native={'completed':True,'execution':prior['native']['execution']};jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');result=android.qualify_android_jni(outside,out,native,env,jdk);sdk.write_json(out/'RESULT.json',result);assert result['completed']
 assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in record['source_sha256'].items());assert all(hashlib.sha256((root/'artifact'/name).read_bytes()).hexdigest()==digest for name,digest in record['artifact_sha256'].items());record['completed']=True
finally:
 record['live_producer']=False;(out/'STATE.json').write_text(json.dumps(record,indent=2)+'\n')
print('Integrated Debug/Release Android JNI qualification completed',flush=True)
