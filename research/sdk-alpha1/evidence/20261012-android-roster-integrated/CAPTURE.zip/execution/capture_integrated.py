from pathlib import Path
import hashlib,json,tempfile,zipfile
import continuity_android_roster as local
import continuity_android_roster_witness as witness
import continuity_android_policy_roster as policy
import continuity_android_contract as contract
root=Path.cwd();src=root/'target/continuity-android-roster-integration';out=root/'research/sdk-alpha1/evidence/20261012-android-roster-integrated';out.mkdir(exist_ok=True)
state=json.loads((src/'STATE.json').read_text());result=json.loads((src/'RESULT.json').read_text());assert state['completed'] and not state['live_producer'] and result['completed']
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in state['source_sha256'].items());assert all(hashlib.sha256((root/'artifact'/n).read_bytes()).hexdigest()==h for n,h in state['artifact_sha256'].items())
members={}
def add(n,p):
 assert n not in members and p.is_file() and not p.is_symlink();members[n]=p.read_bytes()
for path in src.glob('android-jni-*'):
 if path.is_file() and path.suffix in ('.json','.stdout','.stderr','.public'):add('execution/'+path.name,path)
 elif path.is_dir():
  for p in path.rglob('*'):
   if p.is_file():add('execution/'+str(p.relative_to(src)),p)
for name in ('RESULT.json','qualify.py','clippy.json','clippy.stdout','clippy.stderr','capture_integrated.py'):add('execution/'+name,src/name)
safe={k:v for k,v in state.items() if k!='environment'};members['execution/STATE.json']=(json.dumps(safe,indent=2)+'\n').encode()
for name in state['source_sha256']:add('source/'+name,root/name)
for name in state['artifact_sha256']:add('source/artifact/'+name,root/'artifact'/name)
archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in sorted(members.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='qperiapt-roster-archive-') as temporary,zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
 z.extractall(temporary);execution=Path(temporary)/'execution'
 for profile,data in result['profiles'].items():
  contract.verify_catalog((execution/f'android-jni-{profile}-test-catalog.stdout').read_bytes())
  for lane,reader in [('roster-local',lambda b,p:local.verify_local(b,p,remote=False)),('roster-peer',lambda b,p:local.verify_local(b,p,remote=True)),('roster-witness',witness.verify_execution),('policy-roster',policy.verify_execution)]:
   prefix=execution/f'android-jni-{profile}-{lane}';assert reader(prefix.with_suffix('.stdout').read_bytes(),prefix)==data['roster_outcomes'][lane]
def count(v):
 return sum((x if k=='foreign_processes' else count(x) if isinstance(x,dict) else 0) for k,x in v.items())
lifecycle_counts={name:count(data) for name,data in result['profiles'].items()};assert lifecycle_counts=={'debug':1720,'release':1720},lifecycle_counts
for profile in lifecycle_counts:
 boundary=json.loads((src/f'android-jni-{profile}-boundary.json').read_text())
 assert boundary['returncode']==0 and boundary['argv'][-1]=='dev.qperiapt.continuity.android.BridgeProbe'
 assert (src/f'android-jni-{profile}-boundary.stdout').read_bytes()==b'configuration:bridge:passed\n'
counts={name:value+1 for name,value in lifecycle_counts.items()}
receipt={'completed':True,'profile_processes':counts,'lifecycle_processes_per_profile':lifecycle_counts,'JNI_boundary_processes_per_profile':1,'total_host_Java_processes':3442,'roster_export_routes':44,'roster_export_host_processes':1960,'archive_members':len(members),'capture_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_before_after_equal':True,'all_archive_member_hashes_verified':True,'all_roster_public_exports_reread':True,'private_keys_or_journals_archived':False,'agreed_phone_gate':'already passed; recorded separately','release_claim_eligible':False}
(out/'CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
