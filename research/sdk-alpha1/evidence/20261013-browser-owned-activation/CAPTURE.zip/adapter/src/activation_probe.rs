//! Isolated test adapter: all authority comes from real signed public inputs.
use super::*;
use crate::{AccountPin,PolicyPin,PolicyCheckpoint,RosterCheckpoint,VerifiedSessionPolicy,InstallationPreparation,PrekeyId,LeafKind};
use serde_json::{Value,json};
use std::sync::Arc;
fn bytes(value:&Value,name:&str)->Result<Vec<u8>,DurableError>{serde_json::from_value(value.get(name).ok_or(crate::Error::Encoding)?.clone()).map_err(|_|crate::Error::Encoding.into())}
fn array(value:&Value,name:&str)->Result<[u8;32],DurableError>{bytes(value,name)?.try_into().map_err(|_|crate::Error::Encoding.into())}
fn number(value:&Value,name:&str)->Result<u64,DurableError>{value.get(name).and_then(Value::as_u64).ok_or_else(||crate::Error::Encoding.into())}
fn parse(text:&str)->Result<Value,DurableError>{if text.len()>131072{return Err(DurableError::Capacity)}serde_json::from_str(text).map_err(|_|crate::Error::Encoding.into())}
fn policy(config:&Value,kind:&str,now:u64)->Result<VerifiedSessionPolicy,DurableError>{
 let state=q_periapt_policy::TrustedPolicyState::decode(&bytes(config,"sdk_state")?).map_err(|_|crate::Error::Encoding)?;
 let runtime=q_periapt_sdk::Runtime::from_signed_policy(&bytes(config,"sdk_policy")?,&bytes(config,"sdk_signature")?,&bytes(config,"sdk_root")?,Some(&state),q_periapt_sdk::Limits::default()).map_err(crate::Error::from)?;
 let statement=config.get("policies").and_then(|value|value.get(kind)).ok_or(crate::Error::Encoding)?;
 let pin=PolicyPin::new(array(config,"family")?,PublicKey::decode(&bytes(config,"policy_root")?)?,PolicyCheckpoint::from_trusted_state(number(statement,"version")?,array(statement,"digest")?)?)?;
 Ok(pin.verify(&bytes(statement,"wire")?,Arc::new(runtime),now)?)
}
async fn run(mut enrollment:DeviceEnrollment,config:&Value,grant:&Value,phase:&str,kind:&str,now:u64)->Result<Value,DurableError>{
 let policy=policy(config,kind,now)?;
 let pin=AccountPin::new(array(config,"account")?,PublicKey::decode(&bytes(config,"root")?)?,RosterCheckpoint::from_trusted_state(number(grant,"version")?,array(grant,"digest")?)?,array(config,"family")?)?;
 let journal=enrollment.accept(&bytes(grant,"certificate")?,&bytes(grant,"roster")?,&pin,&policy,now).await?;
 match phase {
  "accept" => Ok(json!({"phase":"accepted","journal":journal.as_bytes()})),
  "prepare" => match enrollment.prepare(&policy,now).await? {
    InstallationPreparation::Local => Ok(json!({"phase":"prepared-local","journal":journal.as_bytes()})),
    InstallationPreparation::RequiresEnrollment(genesis) => Ok(json!({"phase":"requires-witness-enrollment","journal":journal.as_bytes(),"genesis":genesis.image_digest()})),
  },
  "activate" => {
    let mut active=enrollment.activate(&policy,now,None).await?;
    let (service,signer,device)=active.parts()?;signer.check_device(device)?;
    let (store,archives)=service.stores()?;
    if store.identity()?!=journal{return Err(DurableError::Conflict)}
    let public=store.generate_prekey(&policy,device,PrekeyId::from_trusted_state([55;32])?,LeafKind::OneTimePq,Validity::new(number(config,"from")?,number(config,"until")?)?,now).await?;
    let value=json!({"phase":"active","journal":journal.as_bytes(),"prekey":public.public_key(),"archive_count":archives.session_ids()?.len()});
    active.close();policy.close();Ok(value)
  },
  _ => Err(crate::Error::State.into()),
 }
}
/// Test the shared owner; never imports private fixture keys or supplies a policy digest alone.
#[wasm_bindgen]
pub async fn activation_step(name:String,id:String,config:String,grant:String,phase:String,kind:String,now:u64)->Result<String,JsValue>{
 let config=parse(&config).map_err(js)?;let grant=parse(&grant).map_err(js)?;
 let root=bytes(&config,"root").map_err(js)?;let description=bytes(&config,"description").map_err(js)?;
 let owner=BrowserEnrollmentProbe::open(name,id,root,description).await?;
 let enrollment=owner.enrollment.borrow_mut().take().ok_or_else(||js(DurableError::Closed))?;
 let result=run(enrollment,&config,&grant,&phase,&kind,now).await;
 let cleanup=owner.close().await;
 match (result,cleanup) {
  (Ok(value),Ok(()))=>Ok(value.to_string()),
  (Err(error),Ok(()))=>Err(js(error)),
  (Ok(_),Err(error))=>Err(error),
  (Err(primary),Err(cleanup))=>Err(Storage::combine_failures(&js(primary),&cleanup)),
 }
}
