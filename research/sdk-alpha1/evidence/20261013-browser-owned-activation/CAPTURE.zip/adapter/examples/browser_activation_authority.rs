//! Isolated real native issuer; exports only public trust inputs and grants.
use q_periapt_continuity_identity_candidate as p;
use q_periapt_sig::Signer;
use q_periapt_host_store::filesystem::publish_private_bytes;
use serde_json::{json, Value};
use std::{fs, path::Path, time::{SystemTime, UNIX_EPOCH}};
use zeroize::Zeroizing;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn now() -> Result<u64> { Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs()) }
fn bytes(value: &Value, field: &str) -> Result<Vec<u8>> { Ok(serde_json::from_value(value.get(field).ok_or("missing field")?.clone())?) }
fn root(dir: &Path) -> Result<p::RootSigningKey> {
    let key=p::JournalKey::open(&dir.join("private-wrap.key"))?;
    let id=p::SigningKeyId::from_trusted_state(fs::read(dir.join("root-id.bin"))?.as_slice().try_into()?)?;
    Ok(p::RootSigningKey::open(&dir.join("private-root.key"), &key, id)?)
}
fn description(value: &Value) -> Result<p::DeviceDescription> {
    let d=bytes(value,"description")?;
    if d.len()!=72 { return Err("description width".into()); }
    Ok(p::DeviceDescription::new(d[0..16].try_into()?,u64::from_be_bytes(d[16..24].try_into()?),d[24..56].try_into()?,p::Validity::new(u64::from_be_bytes(d[56..64].try_into()?),u64::from_be_bytes(d[64..72].try_into()?))?)?)
}
fn main() -> Result<()> {
    let args=std::env::args().collect::<Vec<_>>();
    let mode=args.get(1).ok_or("mode")?;let dir=Path::new(args.get(2).ok_or("directory")?);
    match mode.as_str() {
        "prepare" => {
            if args.len()!=3 { return Err("arguments".into()); }
            let wrap=p::JournalKey::provision(&dir.join("private-wrap.key"))?;
            let id=p::SigningKeyId::generate()?;
            let root=p::RootSigningKey::provision(&dir.join("private-root.key"),&wrap,id)?;
            publish_private_bytes(&dir.join("root-id.bin"),id.as_bytes())?;
            let authority=p::PolicySigningKey::provision(&dir.join("private-policy.key"),&wrap,p::SigningKeyId::generate()?)?;
            let family=authority.policy_family()?;
            let mut seed=Zeroizing::new([0;32]);getrandom::fill(seed.as_mut())?;
            let (sk,public)=q_periapt_backends::MlDsa65::generate(*seed);let sk=Zeroizing::new(sk);
            let sdk_policy=b"schema_version=1\npolicy_version=1\nmin_nist_level=3\ndefault_profile=\"ContextBound\"\nallowed_kems=[\"ML-KEM-768\",\"X25519\"]\nallowed_sigs=[\"ML-DSA-65\"]\ndeprecated=[]\n";
            getrandom::fill(seed.as_mut())?;let mut signature=vec![0;q_periapt_backends::ML_DSA_65_SIG_LEN];
            q_periapt_backends::MlDsa65.sign(sk.as_ref(),&q_periapt_policy::policy_signature_message(sdk_policy),seed.as_ref(),&mut signature).map_err(|e|format!("sign: {e:?}"))?;
            let runtime=q_periapt_sdk::Runtime::from_signed_policy(sdk_policy,&signature,&public,None,q_periapt_sdk::Limits::default())?;
            let at=now()?;let validity=p::Validity::new(at-1,at+3600)?;
            let witness=p::AnchorSigningKey::provision(&dir.join("private-witness.key"),&wrap,p::SigningKeyId::generate()?)?;
            let pin=p::AnchorPin::new(p::AnchorIdentity::generate()?,witness.public_key()?);
            let mut policies=serde_json::Map::new();
            for (name,version,anchor) in [("local",1,p::AnchorRequirement::local_only()),("required",2,p::AnchorRequirement::required(&pin))] {
                let issued=authority.issue_session_policy(&runtime,p::SessionPolicyParameters::new(version,validity,p::AllowedPrekeyModes::new(&[p::PrekeyQuality::OneTimeBoth])?,anchor,p::ApplicationSendBudget::new(8)?)?)?;
                policies.insert(name.into(),json!({"wire":issued.as_bytes(),"version":issued.checkpoint().version(),"digest":issued.checkpoint().digest()}));
            }
            let mut description=vec![73;16];description.extend_from_slice(&1u64.to_be_bytes());description.extend_from_slice(&family);description.extend_from_slice(&(at-1).to_be_bytes());description.extend_from_slice(&(at+3600).to_be_bytes());
            let config=json!({"root":root.public_key()?.encode(),"account":root.account_id()?,"description":description,"family":family,"from":at-1,"until":at+3600,
                "sdk_policy":sdk_policy.as_slice(),"sdk_signature":signature,"sdk_root":public.as_slice(),"sdk_state":runtime.trusted_state().encode().as_slice(),"policy_root":authority.public_key()?.encode(),"policies":policies});
            publish_private_bytes(&dir.join("PUBLIC.json"),&serde_json::to_vec_pretty(&config)?)?;
            println!("fresh native authorities prepared");
        }
        "issue" => {
            if args.len()!=5 { return Err("arguments".into()); }
            let config:Value=serde_json::from_slice(&fs::read(dir.join("PUBLIC.json"))?)?;
            let root=root(dir)?;let intent=p::EnrollmentIntent::new(root.public_key()?,description(&config)?);
            let request=fs::read(args.get(3).ok_or("request")?)?;
            let verified=p::VerifiedEnrollmentRequest::verify(&request,&intent,now()?)?;
            let certificate=root.issue_enrollment(&verified,now()?)?;
            let roster=root.issue_roster(1,p::Validity::new(config["from"].as_u64().ok_or("from")?,config["until"].as_u64().ok_or("until")?)?,&[root.roster_entry(&certificate)?])?;
            let grant=json!({"certificate":certificate,"roster":roster.as_bytes(),"version":roster.checkpoint().version(),"digest":roster.checkpoint().digest(),"identity":verified.identity().as_bytes()});
            publish_private_bytes(Path::new(args.get(4).ok_or("grant")?),&serde_json::to_vec_pretty(&grant)?)?;
            println!("original browser request verified and grant issued");
        }
        _ => return Err("mode".into()),
    }
    Ok(())
}
