from pathlib import Path
import shutil,json,os
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-activation';web=stage/'web';inputs=web/'inputs';inputs.mkdir(mode=0o700)
private=stage/'private-authority';private.mkdir(mode=0o700)
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
sdk.command([str(binary),'prepare',str(private)],stage/'native-prepare',root,environment=dict(os.environ))
config=json.loads((private/'PUBLIC.json').read_text());sdk.copy(private/'PUBLIC.json',inputs/'PUBLIC.json')
for field,name in [('root','root.bin'),('description','description.bin')]: (inputs/name).write_bytes(bytes(config[field]))
for name in ['storage-root.js','storage-catalogue.js','storage-database.js']:
 sdk.copy(stage/'source/research/continuity-identity-candidate/src/storage/browser'/name,web/'pkg'/name)
sdk.copy(root/'crates/q-periapt-sdk-wasm/package/web/storage-io.js',web/'pkg/storage-io.js')
folder=web/'creation';folder.mkdir()
s=(root/'research/continuity-identity-candidate/tests/browser/worker.js').read_text()
s=s.replace('BrowserEnrollmentProbe }','BrowserEnrollmentProbe, activation_step }',1)
s=s.replace("import { lease }", "import { StorageRoot } from '../pkg/storage-root.js';\nimport { lease }",1)
s=s.replace('  const restores = [];', '''  const restores = [];
  if (boundary?.startsWith('after-')) {
    const method = StorageRoot.prototype.publishDatabase;
    StorageRoot.prototype.publishDatabase = async function(path, file) {
      const value = await method.call(this, path, file);
      if (path.endsWith('/' + boundary.slice(6) + '.redb')) cut(boundary);
      return value;
    };
    return () => { StorageRoot.prototype.publishDatabase = method; };
  }''',1)
s=s.replace("if (mutation === 'delete-enrollment') {", "if (mutation.startsWith('delete-child-')) {\n        const path = paths.find(path => path.endsWith('/' + mutation.slice(13) + '.redb')); required(path, 'child expected'); tx.objectStore('files').delete(path);\n      } else if (mutation === 'delete-enrollment') {",1)
s=s.replace('    restore = instrument(boundary);', '''    restore = instrument(boundary);
    if (operation === 'activation') {
      const config = await (await fetch('/inputs/PUBLIC.json')).json();
      const grant = await (await fetch('/inputs/' + data.grant)).json();
      if (data.badPolicy) config.sdk_signature[0] ^= 1;
      if (data.badGrant) grant.digest[0] ^= 1;
      const value = await activation_step(name, id, JSON.stringify(config), JSON.stringify(grant), data.phase, data.kind, BigInt(Math.floor(Date.now() / 1000)));
      result = { value: JSON.parse(value) }; return;
    }''',1)
(folder/'worker.js').write_text(s)
(folder/'index.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Owned activation</title><script type="module" src="./controller.js"></script>')
