from pathlib import Path
import contextlib,hashlib,json,os,uuid
from bounded_process import capture_output
from continuity_browser_http import serving
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-activation';web=stage/'publication-web';out=stage/'publication-run';out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();inputs=web/'inputs';session='qpc-activation-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
source={p.relative_to(stage/'source').as_posix():sdk.snapshot(p).sha256 for p in (stage/'source').rglob('*') if p.is_file()}
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
state={'completed':False,'scope':'isolated signed-public-input adapter exercising shared storage and native enrollment/SDK engines','source':source,'static_web':static,'native_binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'cases':[]}
sequence=0
def browser(args,label):
 with contextlib.chdir(out):
  r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr)
 sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode})
 sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure')
 return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:02}'
 script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode()
 sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution failed: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='activation')
 sdk.require(value['diagnostics']==[],'browser diagnostics')
 return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
try:
 with serving(web,out) as origin:
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];addEventListener("error",event=>diagnostics.push(event.message));addEventListener("unhandledrejection",event=>diagnostics.push(String(event.reason)));}); return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case,kind in [('installation','local'),('journal','local'),('archives','local')]:
    name=case+'-'+uuid.uuid4().hex[:10];identity=uuid.uuid4().hex+uuid.uuid4().hex
    base={'name':name,'id':identity,'operation':'activation','kind':kind,'grant':name+'.json'}
    request=success({**base,'operation':'create','capture':name+'.bin'})
    public=out/'creation'/ (name+'.bin');sdk.require(sdk.snapshot(public).sha256==request['sha256'],'captured request changed')
    sdk.command([str(binary),'issue',str(stage/'private-authority'),str(public),str(inputs/base['grant'])],logs/(name+'-issue'),root,environment=dict(os.environ))
    accepted=success({**base,'phase':'accept'})
    value=success({**base,'operation':'publication-receipt','child':case})
    sdk.require(value['failed']['code']=='CommitUnknown' and 'ClosePending' in value['failed']['causes'] and value['elapsed_ms']>=19000 and value['receipts'][-1]==0,'publication receipt was not preserved')
    sdk.require(value['prepared']['journal']==accepted['journal']==value['active']['journal'] and len(value['active']['prekey'])==1184,'late completion changed original journal')
    state['cases'].append({'case':case,'accepted':accepted,'publication':value})
  finally:
   browser(['close'],'close')
 for name,digest in source.items(): sdk.require(sdk.snapshot(stage/'source'/name).sha256==digest,'source changed')
 for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'static browser input changed')
 sdk.require(sdk.snapshot(binary,maximum=256*1024*1024).sha256==state['native_binary_sha256'],'native issuer changed')
 state['completed']=True
except BaseException as error:
 state['failure']=repr(error);raise
finally:
 sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
