from pathlib import Path
import contextlib,hashlib,json,os,uuid
from bounded_process import capture_output
from continuity_browser_http import serving
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-activation';web=stage/'web';out=stage/'run-03';out.mkdir(mode=0o700)
logs=out/'logs';logs.mkdir();inputs=web/'inputs';session='qpc-activation-'+uuid.uuid4().hex
node=Path('/opt/homebrew/bin/node').resolve();cli=Path('/Users/bill/.npm/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js')
binary=root/'target/continuity-browser-creation/rust-target/debug/examples/browser_activation_authority'
source={p.relative_to(stage/'source').as_posix():sdk.snapshot(p).sha256 for p in (stage/'source').rglob('*') if p.is_file()}
static={p.relative_to(web).as_posix():sdk.snapshot(p).sha256 for p in web.rglob('*') if p.is_file()}
state={'completed':False,'scope':'isolated signed-public-input adapter exercising shared storage and native enrollment/SDK engines','source':source,'static_web':static,'native_binary_sha256':sdk.snapshot(binary,maximum=256*1024*1024).sha256,'cases':[]}
sequence=0
def browser(args,label):
 with contextlib.chdir(out):
  r=capture_output([str(node),str(cli),'--session',session,*args],timeout_seconds=80,maximum_stdout_bytes=4*1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
 (logs/(label+'.stdout')).write_bytes(r.stdout);(logs/(label+'.stderr')).write_bytes(r.stderr)
 sdk.write_json(logs/(label+'.json'),{'argv':args,'returncode':r.returncode})
 sdk.require(r.returncode==0 and not r.stderr,label+' CLI failure')
 return r.stdout

def invoke(args):
 global sequence
 sequence+=1;label=f'step-{sequence:02}'
 script=logs/(label+'.js');script.write_text('async page => { const result = await page.evaluate(args => globalThis.invoke(args), '+json.dumps(args)+'); return {result,diagnostics:await page.evaluate(()=>globalThis.diagnostics)}; }')
 raw=browser(['run-code','--filename',str(script)],label).decode()
 sdk.require(raw.count('### Result\n')==1 and '### Error' not in raw,'browser execution failed: '+label)
 value=parse_strict_json_bytes(raw.split('### Result\n',1)[1].split('\n### ',1)[0].encode(),label='activation')
 sdk.require(value['diagnostics']==[],'browser diagnostics')
 return value['result']

def success(args):
 value=invoke(args);sdk.require('value' in value and 'error' not in value,'operation failed: '+json.dumps(value));return value['value']
try:
 with serving(web,out) as origin:
  try:
   browser(['open',origin+'/creation/index.html','--browser','chrome'],'open')
   setup=logs/'setup.js';setup.write_text('async page => { await page.waitForFunction(()=>typeof globalThis.invoke === "function"); await page.evaluate(()=>{globalThis.diagnostics=[];addEventListener("error",event=>diagnostics.push(event.message));addEventListener("unhandledrejection",event=>diagnostics.push(String(event.reason)));}); return {ready:true}; }')
   browser(['run-code','--filename',str(setup)],'setup')
   for case,kind in [('happy','local'),('after-installation','local'),('after-journal','local'),('after-archives','local'),('delete-journal','local'),('required','required')]:
    name=case+'-'+uuid.uuid4().hex[:10];identity=uuid.uuid4().hex+uuid.uuid4().hex
    base={'name':name,'id':identity,'operation':'activation','kind':kind,'grant':name+'.json'}
    request=success({**base,'operation':'create','capture':name+'.bin'})
    public=out/'creation'/ (name+'.bin');sdk.require(sdk.snapshot(public).sha256==request['sha256'],'captured request changed')
    sdk.command([str(binary),'issue',str(stage/'private-authority'),str(public),str(inputs/base['grant'])],logs/(name+'-issue'),root,environment=dict(os.environ))
    accepted=success({**base,'phase':'accept'})
    original=success({**base,'operation':'inspect'})
    bad=invoke({**base,'phase':'accept','badPolicy':True});sdk.require(bad.get('error')=='Error: Protocol(Runtime(PolicyDenied))','bad signed SDK policy was not refused')
    after_bad=success({**base,'operation':'inspect'});sdk.require(original==after_bad,'failed policy modified original catalogue')
    cut=None
    if case.startswith('after-'):
     cut=invoke({**base,'phase':'prepare','boundary':case});sdk.require(cut.get('cut')==case and cut['release'][-1]==0,'Worker cut/release missing')
    prepared=success({**base,'phase':'prepare'})
    sdk.require(prepared['journal']==accepted['journal'],'preparation replaced original journal')
    row={'case':case,'kind':kind,'request':request,'accepted':accepted,'bad_policy':bad,'cut':cut,'prepared':prepared}
    if kind=='required':
     sdk.require(prepared['phase']=='requires-witness-enrollment','required witness silently downgraded')
     refused=invoke({**base,'phase':'activate'});sdk.require('AnchorRequired' in refused.get('error',''),'required witness activation was not refused')
     row['missing_witness']=refused
    else:
     active=success({**base,'phase':'activate'});reopened=success({**base,'phase':'activate'})
     sdk.require(active==reopened and active['journal']==accepted['journal'] and active['phase']=='active' and len(active['prekey'])==1184,'original operational prekey or journal changed')
     row['active']=active;row['reopened']=reopened
     malformed=invoke({**base,'phase':'activate','badGrant':True});sdk.require(malformed.get('error')=='Error: Protocol(Checkpoint)','changed independent roster pin returned an unexpected result')
     row['bad_roster_pin']=malformed
     sdk.require(success({**base,'phase':'activate'})==active,'rejection changed original active state')
     if case=='delete-journal':
      success({**base,'operation':'inspect','mutation':'delete-child-journal'})
      before=success({**base,'operation':'inspect'});rejected=invoke({**base,'phase':'activate'});after=success({**base,'operation':'inspect'})
      sdk.require('Corrupt' in rejected.get('error','') and before==after,'published journal loss was repaired')
      row['lost_journal']=rejected
    state['cases'].append(row)
  finally:
   browser(['close'],'close')
 for name,digest in source.items(): sdk.require(sdk.snapshot(stage/'source'/name).sha256==digest,'source changed')
 for name,digest in static.items(): sdk.require(sdk.snapshot(web/name).sha256==digest,'static browser input changed')
 sdk.require(sdk.snapshot(binary,maximum=256*1024*1024).sha256==state['native_binary_sha256'],'native issuer changed')
 state['completed']=True
except BaseException as error:
 state['failure']=repr(error);raise
finally:
 sdk.write_json(out/'RESULT.json',state)
print(json.dumps({'completed':state['completed'],'cases':len(state['cases'])}))
