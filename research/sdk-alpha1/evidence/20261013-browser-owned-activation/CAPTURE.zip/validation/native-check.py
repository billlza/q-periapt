from pathlib import Path
import hashlib,json,os,re,signal,subprocess
stage=Path(__file__).resolve().parent;root=stage.parents[1];source=stage/'source';out=stage/'native-check';out.mkdir(mode=0o700)
files={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
state={'completed':False,'live_producer':True,'source':str(source),'inputs':files,'tests':[]}
def save(): (out/'RUN.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for index,selected in enumerate(['installation','enrollment::tests::original_enrollment','durable::tests::provisioning']):
  argv=['sh',str(root/'target/continuity-browser-creation/cargo.sh'),'test','--manifest-path',str(source/'research/continuity-identity-candidate/Cargo.toml'),'--lib','--all-features','--locked','--offline',selected,'--','--test-threads=4']
  record={'filter':selected,'argv':argv};state['tests'].append(record);save()
  with (out/f'test-{index}.stdout').open('xb') as stdout,(out/f'test-{index}.stderr').open('xb') as stderr:
   process=subprocess.Popen(argv,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True);record['pid']=process.pid;save()
   try:record['returncode']=process.wait(timeout=2400)
   except subprocess.TimeoutExpired:
    record['timed_out']=True;os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    record['returncode']=process.returncode;save();raise
  text=(out/f'test-{index}.stdout').read_text();matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text)
  assert record['returncode']==0 and len(matches)==1 and int(matches[0])>0,selected
  record['passed']=int(matches[0]);save()
 for name,digest in files.items(): assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
 state['completed']=True
finally:
 state['live_producer']=False;save()
print(json.dumps({'completed':state['completed'],'counts':[row.get('passed') for row in state['tests']]}))
