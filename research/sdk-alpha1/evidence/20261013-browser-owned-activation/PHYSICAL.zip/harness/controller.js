// Isolated real Worker lifecycle controller.
globalThis.invoke = async args => {
  const result = await new Promise((resolve, reject) => {
    const worker = new Worker('./worker.js', { type: 'module' });
    const timer = setTimeout(() => { worker.terminate(); reject(Error('worker deadline')); }, 45000);
    const done = value => { clearTimeout(timer); worker.terminate(); resolve(value); };
    worker.onmessage = ({ data }) => {
      if (data.ready) worker.postMessage(args);
      else if (data.done || data.cut) done(data);
    };
    worker.onerror = event => { clearTimeout(timer); worker.terminate(); reject(Error(event.message)); };
  });
  if (result.cut) {
    const until = performance.now() + 15000;
    result.release = [];
    for (;;) {
      const locks = await navigator.locks.query();
      const held = [...locks.held, ...locks.pending].filter(row => row.name === 'qperiapt-continuity-storage/2/' + args.name).length;
      result.release.push(held); if (!held) break;
      if (performance.now() > until) throw Error('terminated Worker retained root');
      await new Promise(resolve => setTimeout(resolve, 20));
    }
  }
  if (result.value?.request) {
    const reply = await fetch('./capture/' + args.capture, { method: 'POST', body: new Uint8Array(result.value.request) });
    if (!reply.ok) throw Error('request capture failed');
    delete result.value.request;
  }
  return result;
};
