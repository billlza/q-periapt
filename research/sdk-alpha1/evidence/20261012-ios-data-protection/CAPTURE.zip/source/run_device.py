from pathlib import Path
import sys,json,os,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from device_support import OUT,APP,BUNDLE,selected,command,installed
import rust_sdk_profile as sdk
r=Path.cwd();device=selected();control=OUT/'device-control';control.mkdir();fixture=json.loads((OUT/'FIXTURE.json').read_text())
if installed(device,control/'before'):raise RuntimeError('run-owned app already installed')
state={'completed':False,'live_producer':True,'cleanup_armed':True,'bundle_id':BUNDLE,'app_executable_sha256':hashlib.sha256((Path(APP['app'])/'ContinuityIOSRunner').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(Path(fixture['binary']).read_bytes()).hexdigest()}
p=OUT/'DEVICE_STATE.json';p.write_text(json.dumps(state,indent=2)+'\n')
try:
 command(device,['device','install','app',APP['app']],control/'install',timeout=60)
 if not installed(device,control/'installed'):raise RuntimeError('installation not observed')
 for n in ['device-cases','device-public']:(OUT/n).mkdir(mode=0o700)
 env=dict(os.environ,QPC_PROTECTION_CLIENT=str(OUT/'ios_client.py'),QPC_PROTECTION_CASES=str(OUT/'device-cases'),QPC_PROTECTION_PUBLIC=str(OUT/'device-public'))
 sdk.command([fixture['binary'],'--exact','ios_complete_protection_preserves_original_identity','--nocapture'],OUT/'device-fixture',r,environment=env)
 rows=[json.loads(p.read_text()) for p in (OUT/'device-execution').glob('*/RESULT.json')]
 if len(rows)!=5 or any(not x['completed'] for x in rows):raise RuntimeError('device matrix incomplete')
 state['completed']=True
finally:
 state['live_producer']=False
 for attempt in range(6):
  if installed(device,control/f'cleanup-query-{attempt}'):
   command(device,['device','uninstall','app',BUNDLE],control/f'uninstall-{attempt}',allow_failure=True)
  else:state['cleanup_armed']=False;break
 p.write_text(json.dumps(state,indent=2)+'\n')
 if state['cleanup_armed']:raise RuntimeError('device cleanup unresolved')
print('Two physical iPad identities retained through observed Complete-protection denial and unlock reactivation',flush=True)
