from pathlib import Path
import json,hashlib,zipfile,tempfile,re
r=Path.cwd();o=r/'target/continuity-ios-data-protection';out=r/'research/sdk-alpha1/evidence/20261012-ios-data-protection'
def digest(b):return hashlib.sha256(b).hexdigest()
def verify(root):
 s=json.loads((root/'DEVICE_STATE.json').read_text());assert s['completed'] and not s['live_producer'] and not s['cleanup_armed']
 stdout=(root/'device-fixture.stdout').read_text();assert (root/'device-fixture.stderr').read_bytes()==b''
 assert re.findall(r'^test ([a-z_]+) \.\.\. ok$',stdout,re.M)==['ios_complete_protection_preserves_original_identity']
 assert '1 passed; 0 failed; 0 ignored; 0 measured; 3 filtered out;' in stdout
 rows=[json.loads(p.read_text()) for p in (root/'device-execution').glob('*/RESULT.json')]
 assert len(rows)==5 and len({x['run'] for x in rows})==5
 assert {(x['mode'],x['profile']) for x in rows}=={('create','fixed'),('enroll','fixed'),('create','recoverable'),('enroll','recoverable'),('lock-cycle','both')}
 by={}
 for x in rows:
  assert x['completed'];p=root/'device-execution'/x['run'];marker=f'QPC_PROTECTION_PASS mode={x["mode"]} profile={x["profile"]} run={x["run"]}\n'.encode()
  assert (p/'receipt.txt').read_bytes()==marker and (p/'launch.stderr').read_bytes()==b''
  lines=(p/'launch.stdout').read_bytes().splitlines();ready=f'QPC_IOS_READY run={x["run"]}'.encode()
  assert lines.count(ready)==1 and lines.count(marker.rstrip(b'\n'))==1 and lines.index(ready)<lines.index(marker.rstrip(b'\n'))
  assert lines.count(b'The app terminated with the exit code 0.')==1
  status=json.loads((p/'launch.status.json').read_text());assert status['returncode']==0 and status['startup_admitted']
  assert json.loads((p/'admission.status.json').read_text())['returncode']==0
  data=(p/'public-result.bin').read_bytes();assert digest(data)==x['public_sha256'];by[(x['mode'],x['profile'])]=data
  if x['mode']=='lock-cycle':
   assert status['lock_ready'] and status['locked_observed']
   locked=f'QPC_PROTECTION_LOCKED run={x["run"]} available=false sentinel_errno=1 fixed=702 recoverable=702'.encode()
   arm=f'QPC_PROTECTION_READY run={x["run"]} files=40 profiles=2'.encode()
   assert lines.count(arm)==lines.count(locked)==1 and lines.index(arm)<lines.index(locked)<lines.index(marker.rstrip(b'\n'))
   report=json.loads((p/'report.json').read_text());assert report==dict(fixed_refusal=702,recoverable_refusal=702,namespace_unchanged=True,original_identity_journal_publication=True,protected_data_unavailable=True,protected_entries=40,sentinel_errno=1,unlock_reactivation=True)
 originals=[];restored=[]
 for profile in ['fixed','recoverable']:
  assert f'QPC_PROTECTION_VERIFIED profile={profile} signature=true original_identity=true journal=true publication=true activation=true' in stdout
  p=root/'device-public'/profile;original=(p/'original-request.bin').read_bytes();active=(p/'active-snapshot.bin').read_bytes();after=(p/'restored-snapshot.bin').read_bytes()
  assert len(original)==5506 and len(active)==5602 and active==after
  assert original==by[('create',profile)]==active[:5506] and active==by[('enroll',profile)]
  originals.append(original);restored.append(after)
 assert originals[0]!=originals[1] and b''.join(restored)==by[('lock-cycle','both')]
 return report
report=verify(o)
app=json.loads((o/'APP.json').read_text());state=json.loads((o/'DEVICE_STATE.json').read_text());fixture=json.loads((o/'FIXTURE.json').read_text())
assert digest((Path(app['app'])/'ContinuityIOSRunner').read_bytes())==state['app_executable_sha256']
assert digest(Path(fixture['binary']).read_bytes())==state['fixture_sha256']
log=(o/'build.log').read_text();assert '** BUILD SUCCEEDED **' in log and 'warning:' not in log and 'error:' not in log
package=r/'target/continuity-ios-binary-package';checks=json.loads((package/'PACKAGE_CHECKS.json').read_text())
assert digest((package/'QPeriaptContinuity-ios-candidate.zip').read_bytes())==checks['archive_sha256']
manifest=json.loads((package/'installed/QPeriaptContinuity/MANIFEST.json').read_text())
for n,h in manifest.items():assert digest((package/'installed/QPeriaptContinuity'/n).read_bytes())==h
members={}
def add(name,path):
 if path.is_dir():
  for p in path.rglob('*'):
   if p.is_file() and not p.is_symlink():members[name+'/'+str(p.relative_to(path))]=p.read_bytes()
 else:members[name]=path.read_bytes()
for n in ['DEVICE_STATE.json','device-control','device-execution','device-public','device-fixture.stdout','device-fixture.stderr','device-fixture.json']:add('execution/'+n,o/n)
for n in ['app/Sources','app/project.json','app/Info.plist','ios_client.py','device_support.py','run_device.py','build.py','build_app.py','capture.py','c-consumer/tests/ios_protection.rs']:add('source/'+n,o/n)
for n in ['fixture-build.stdout','fixture-build.stderr','fixture-build.json','build.log','project.log']:add('build/'+n,o/n)
for n in ['PACKAGE_CHECKS.json','SOURCE_MATCH.json']:add('package/'+n,package/n)
add('package/installed-MANIFEST.json',package/'installed/QPeriaptContinuity/MANIFEST.json')
add('prior-failure/Protection.swift',o/'failures/transferred-enrollment-status/Protection.swift')
for n in ['DEVICE_STATE.json','device-fixture.stdout','device-fixture.stderr','device-execution']:add('prior-failure/'+n,o/'failures/transferred-enrollment-status'/n)
assert not any(Path(n).name in {'STATE.json','SIGNING.json','tls-key','wrap.key','signer.key'} or n.endswith('.redb') for n in members)
out.mkdir();archive=out/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps({n:digest(b) for n,b in sorted(members.items())},indent=2)+'\n')
with tempfile.TemporaryDirectory() as tmp,zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('MANIFEST.json'));assert len(z.namelist())==len(set(z.namelist()))==len(m)+1
 assert all(digest(z.read(n))==h for n,h in m.items());z.extractall(tmp);assert verify(Path(tmp)/'execution')==report
result=dict(report,physical_platform='iPadOS 27.0.1 arm64',device_model='iPad Pro 11-inch (M4)',Swift_device_calls=5,profiles=['fixed','recoverable'],independently_verified_original_requests=2,package_sha256=checks['archive_sha256'],app_executable_sha256=state['app_executable_sha256'],fixture_sha256=state['fixture_sha256'],run_owned_app_removed=True,all_capture_hashes_verified=True,archived_public_records_reread=True,capture_members=len(members),capture_sha256=digest(archive.read_bytes()),release_claim_eligible=False,scope='Explicitly closed local-profile owners; host-applied Complete file protection; background denial and unlocked reopen/activation. No live-owner erasure, interrupted write, witness availability, reboot or power-loss claim.')
(out/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
