// SPDX-License-Identifier: Apache-2.0 OR MIT
import Foundation
import QPeriaptContinuity
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

struct ClientError: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
}
func withFile<T>(_ file: FileHandle, _ body: (FileHandle) throws -> T) throws -> T {
    let result: Result<T, Error>
    do { result = .success(try body(file)) } catch { result = .failure(error) }
    do { try file.close() } catch {
        switch result {
        case .success: throw error
        case .failure(let original): throw ClientError("\(original); file close also failed: \(error)")
        }
    }
    return try result.get()
}
func load(_ source: URL, _ name: String, _ maximum: Int) throws -> [UInt8] {
    try withFile(FileHandle(forReadingFrom: source.appendingPathComponent(name))) { file in
        var bytes = Data()
        while bytes.count <= maximum {
            guard let next = try file.read(upToCount: maximum + 1 - bytes.count), !next.isEmpty else { break }
            bytes.append(next)
        }
        guard !bytes.isEmpty, bytes.count <= maximum else { throw ClientError("input width: \(name)") }
        return Array(bytes)
    }
}
func exact(_ source: URL, _ name: String, _ count: Int) throws -> [UInt8] {
    let bytes = try load(source, name, count)
    guard bytes.count == count else { throw ClientError("exact input width: \(name)") }
    return bytes
}
func counter(_ bytes: ArraySlice<UInt8>) throws -> UInt64 {
    guard bytes.count == 8 else { throw ClientError("counter width") }
    return bytes.reduce(0) { ($0 << 8) | UInt64($1) }
}
func trust(_ source: URL, _ recoverable: Bool) throws -> SdkPolicyTrust {
    let root = try exact(source, "sdk-root", 1952)
    if recoverable {
        return try .recoverable(scope: exact(source, "recovery-scope", 32), initialRoot: root,
                                recoveryRoot: exact(source, "recovery-root", 1952))
    }
    return try .fixed(root: root)
}
func policy(_ source: URL) throws -> PolicyDocument {
    try PolicyDocument(root: exact(source, "policy-root", 1985), family: exact(source, "family", 32),
        checkpoint: PolicyCheckpoint(version: counter(exact(source, "policy-version", 8)[...]),
                                     digest: exact(source, "policy-digest", 32)), wire: load(source, "protocol-policy", 8192))
}
func initial(_ source: URL, _ recoverable: Bool) throws -> InstallationConfiguration {
    try InstallationConfiguration(
        sdk: InitialSdkPolicy(trust: trust(source, recoverable), policy: load(source, "sdk-policy", 65536),
            signature: exact(source, "sdk-signature", 3309),
            recoveryEnrollment: recoverable ? exact(source, "recovery-enrollment", 3309) : nil),
        protocolPolicy: policy(source),
        tls: LocalTlsIdentity(certificate: load(source, "tls-cert", 8192), privateKey: load(source, "tls-key", 8192)))
}
func witness(_ source: URL, _ carrier: String?, wrong: Bool) throws -> ConfigurationWitness? {
    guard let carrier else { return nil }
    var identity = try exact(source, "witness-id", 32)
    if wrong { identity[0] ^= 1 }
    let key = try exact(source, "witness-public", 1985)
    guard let address = String(bytes: try load(source, "witness-address", 128), encoding: .utf8) else { throw ClientError("address encoding") }
    if carrier == "signed" { return try .signedTCP(identity: identity, publicKey: key, address: address, timeoutMilliseconds: 3000) }
    guard carrier == "tls", let name = String(bytes: try load(source, "witness-tls-name", 128), encoding: .utf8) else { throw ClientError("TLS carrier/name") }
    return try .mutualTLS(identity: identity, publicKey: key, address: address, timeoutMilliseconds: 3000,
        peerCertificate: load(source, "witness-tls-peer", 8192), serverName: name,
        localIdentity: LocalTlsIdentity(certificate: load(source, "witness-tls-cert", 8192), privateKey: load(source, "witness-tls-key", 8192)))
}
func peerInput(_ source: URL) throws -> PeerConfiguration {
    let path = source.appendingPathComponent("peer", isDirectory: true)
    func device(_ prefix: String) throws -> PeerDeviceExpectation {
        let pin = try AccountPin(account: AccountID(bytes: exact(path, prefix + "-account", 32)),
            root: exact(path, prefix + "-root", 1985), family: exact(path, "family", 32),
            checkpoint: RosterCheckpoint(version: counter(exact(path, prefix + "-roster-version", 8)[...]), digest: exact(path, prefix + "-roster-digest", 32)))
        return try PeerDeviceExpectation(account: pin, device: exact(path, prefix + "-device", 16), generation: counter(exact(path, prefix + "-generation", 8)[...]))
    }
    guard let name = String(bytes: try load(path, "tls-peer-name", 128), encoding: .utf8) else { throw ClientError("peer name UTF-8") }
    return try PeerConfiguration(initiator: device("initiator"), responder: device("responder"), directory: exact(path, "directory", 32),
        bundle: load(path, "bootstrap.bundle", 65536), tlsPeerCertificate: load(path, "tls-peer", 8192), tlsPeerName: name)
}
func traffic(_ device: ContinuityDevice, source: URL, mode: String) throws -> [UInt8] {
    let input = try peerInput(source)
    guard let address = String(bytes: try load(source, "connection-address", 128), encoding: .utf8) else { throw ClientError("address UTF-8") }
    let original: SessionID? = mode == "connect" ? nil : try SessionID(bytes: exact(source, "connection-session", 32))
    let peer: ContinuityOwner
    if let original { peer = try device.preparePeerReopen(configuration: input, quality: .oneTimeBoth, role: .initiator, session: original) }
    else { peer = try device.preparePeer(configuration: input, quality: .oneTimeBoth, role: .initiator) }
    var result: Result<[UInt8], Error>
    do {
        try peer.finishOpen()
        if let session = original {
            let uncertain = mode == "uncertain-send"
            let message = uncertain ? try peer.nextMessage(session: session) : try MessageID(bytes: exact(source, "connection-message", 32))
            do {
                let sent = try peer.send(peer: address, session: session, message: message, plaintext: Array("persisted before process exit".utf8), associatedData: Array("configuration-v1".utf8))
                guard !uncertain, sent.consumption == .confirmed else { throw ClientError("incorrect delivery result") }
            } catch let failure as ContinuityFailure {
                guard uncertain, [303, 309, 310, 311].contains(failure.code) else { throw failure }
            }
            guard try peer.status(session: session, message: message) == (uncertain ? .committed : .acknowledged) else { throw ClientError("original message status differs") }
            result = .success(session.bytes + message.bytes)
        } else {
            result = .success(try peer.establish(peer: address, request: InitiationID(bytes: exact(source, "connection-initiation", 32))).session.bytes)
        }
    } catch { result = .failure(error) }
    do { try peer.close() } catch {
        switch result { case .success: throw error; case .failure(let original): throw ClientError("\(original); peer close also failed: \(error)") }
    }
    return try result.get()
}
func expect(_ code: Int32, _ body: () throws -> Void) throws {
    do { try body(); throw ClientError("expected native refusal \(code)") }
    catch let failure as ContinuityFailure { guard failure.code == code else { throw failure } }
}

