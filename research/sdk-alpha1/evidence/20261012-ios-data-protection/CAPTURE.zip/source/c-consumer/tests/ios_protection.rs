// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Physical Swift/iOS consumers generate their own identities and use real transport.
use q_periapt_continuity_identity_candidate as p;
use q_periapt_host_store::filesystem::publish_private_bytes;
use std::{
    fs,
    os::unix::fs::DirBuilderExt,
    path::{Path, PathBuf},
    process::{Command, Stdio},
    time::{Duration, Instant},
};
use zeroize::Zeroizing;
#[path = "../packages/q-periapt-continuity-identity-candidate-0.0.0/tests/owned_connection.rs"]
mod fixture;
#[path = "common/recovery_inputs.rs"]
mod recovery_inputs;
use recovery_inputs::install_recovery;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;

fn independent_inputs(
    source: &Path,
    inputs: &Path,
) -> Result<(p::RootSigningKey, p::EnrollmentIntent, p::Validity)> {
    for name in [
        "sdk-policy",
        "sdk-signature",
        "sdk-root",
        "family",
        "policy-root",
        "policy-version",
        "policy-digest",
        "protocol-policy",
        "tls-cert",
        "tls-key",
    ] {
        let bytes = Zeroizing::new(fs::read(source.join(name))?);
        publish_private_bytes(&inputs.join(name), &bytes)?;
    }
    install_recovery(inputs)?;
    let authority = p::RootSigningKey::generate()?;
    let family = fixture::array(inputs, "family")?;
    let now = fixture::now()?;
    let validity = p::Validity::new(now.saturating_sub(1), now.checked_add(1800).ok_or("clock")?)?;
    let intent = p::EnrollmentIntent::new(
        authority.public_key()?,
        p::DeviceDescription::new([104; 16], 1, family, validity)?,
    );
    let mut wire = vec![104; 16];
    wire.extend_from_slice(&1u64.to_be_bytes());
    wire.extend_from_slice(&family);
    wire.extend_from_slice(&validity.from().to_be_bytes());
    wire.extend_from_slice(&validity.until().to_be_bytes());
    publish_private_bytes(
        &inputs.join("enrollment-root"),
        &authority.public_key()?.encode(),
    )?;
    publish_private_bytes(&inputs.join("enrollment-intent"), &wire)?;
    Ok((authority, intent, validity))
}

fn issue_grant(
    inputs: &Path,
    authority: &p::RootSigningKey,
    intent: &p::EnrollmentIntent,
    validity: p::Validity,
    original: &[u8],
) -> Result<(Vec<u8>, p::IssuedRoster)> {
    let verified = p::VerifiedEnrollmentRequest::verify(original, intent, fixture::now()?)?;
    let certificate = authority.issue_enrollment(&verified, fixture::now()?)?;
    let roster = authority.issue_roster(1, validity, &[authority.roster_entry(&certificate)?])?;
    for (name, bytes) in [
        ("grant-certificate", certificate.clone()),
        ("grant-roster", roster.as_bytes().to_vec()),
        ("trusted-account", authority.account_id()?.to_vec()),
        (
            "trusted-roster-version",
            roster.checkpoint().version().to_be_bytes().to_vec(),
        ),
        (
            "trusted-roster-digest",
            roster.checkpoint().digest().to_vec(),
        ),
    ] {
        publish_private_bytes(&inputs.join(name), &bytes)?;
    }
    Ok((certificate, roster))
}


#[test]
fn ios_complete_protection_preserves_original_identity() -> Result<()> {
    let root = PathBuf::from(std::env::var_os("QPC_PROTECTION_CASES").ok_or("case directory")?);
    let client = PathBuf::from(std::env::var_os("QPC_PROTECTION_CLIENT").ok_or("client")?);
    let public = PathBuf::from(std::env::var_os("QPC_PROTECTION_PUBLIC").ok_or("public")?);
    let mut retained = Vec::new();
    for profile in ["fixed", "recoverable"] {
        let reference = fixture::setup(fixture::enrollment::SetupKind::EnrolledExpiringPolicy(3600))?;
        let base = root.join(profile); fs::DirBuilder::new().mode(0o700).create(&base)?;
        let inputs = base.join("inputs"); fs::DirBuilder::new().mode(0o700).create(&inputs)?;
        let (authority, intent, validity) = independent_inputs(&reference.initiator, &inputs)?;
        protection_run(&client, "create", profile, &inputs, &base, &base.join("created"))?;
        let original = fs::read(base.join("created"))?;
        let verified = p::VerifiedEnrollmentRequest::verify(&original, &intent, fixture::now()?)?;
        issue_grant(&inputs, &authority, &intent, validity, &original)?;
        protection_run(&client, "enroll", profile, &inputs, &base, &base.join("active"))?;
        let active = fs::read(base.join("active"))?;
        assert_eq!(&active[..original.len()], original);
        assert_eq!(active.len(), original.len() + 96);
        let output = public.join(profile); fs::DirBuilder::new().mode(0o700).create(&output)?;
        for name in ["enrollment-root", "enrollment-intent", "grant-certificate", "grant-roster"] {
            publish_private_bytes(&output.join(name), &fs::read(inputs.join(name))?)?;
        }
        publish_private_bytes(&output.join("original-request.bin"), &original)?;
        publish_private_bytes(&output.join("active-snapshot.bin"), &active)?;
        retained.push((profile, intent, verified.identity(), original, active));
    }
    protection_run(&client, "lock-cycle", "both", &root, &root, &root.join("lock-result"))?;
    let all = fs::read(root.join("lock-result"))?;
    assert_eq!(all.len(), retained.iter().map(|x| x.4.len()).sum::<usize>());
    let mut offset=0;
    for (profile, intent, identity, original, active) in retained {
        let next=offset+active.len(); let restored=&all[offset..next];
        assert_eq!(restored, active);
        assert_eq!(p::VerifiedEnrollmentRequest::verify(&restored[..original.len()], &intent, fixture::now()?)?.identity(), identity);
        publish_private_bytes(&public.join(profile).join("restored-snapshot.bin"), restored)?;
        println!("QPC_PROTECTION_VERIFIED profile={profile} signature=true original_identity=true journal=true publication=true activation=true");
        offset=next;
    }
    Ok(())
}
fn protection_run(client: &Path, mode: &str, profile: &str, source: &Path, target: &Path, output: &Path) -> Result<()> {
    let log=output.with_extension("stdout"); let error=output.with_extension("stderr");
    let mut child=fixture::OwnedChild(Command::new(client).args([mode,profile]).arg(source).arg(target).arg(output)
        .stdout(Stdio::from(fs::File::create(&log)?)).stderr(Stdio::from(fs::File::create(&error)?)).spawn()?);
    let deadline=Instant::now()+Duration::from_secs(if mode=="lock-cycle" { 840 } else { 120 });
    let status=loop { if let Some(status)=child.0.try_wait()? { break status; } if Instant::now()>=deadline { return Err("bounded physical protection test timed out".into()); } std::thread::sleep(Duration::from_millis(50)); };
    assert!(status.success(), "protection driver failed: {}", fs::read_to_string(&error)?);
    assert!(fs::read(error)?.is_empty());
    assert_eq!(fs::read_to_string(log)?, format!("{profile}:{mode}:passed\n"));
    Ok(())
}
