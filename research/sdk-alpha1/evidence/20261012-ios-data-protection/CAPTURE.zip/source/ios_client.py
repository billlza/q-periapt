#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import sys,json,hashlib,secrets,tempfile,subprocess,threading,queue,time
from device_support import OUT,BUNDLE,selected,command
ALLOWED={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest','protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope','recovery-root','recovery-enrollment','grant-certificate','grant-roster','trusted-account','trusted-roster-version','trusted-roster-digest'}
def main():
 if len(sys.argv)!=6:raise RuntimeError('argument count')
 mode,profile,source,target,output=sys.argv[1:];source=Path(source);destination=Path(output)
 if (mode,profile) not in {(a,b) for a in ('create','enroll') for b in ('fixed','recoverable')}|{('lock-cycle','both')}:raise RuntimeError('unexpected operation')
 if not destination.is_absolute() or destination.exists():raise RuntimeError('public output must be fresh')
 run=secrets.token_hex(16);capture=OUT/'device-execution'/run;capture.mkdir(parents=True)
 device=selected();domain=['--domain-type','appDataContainer','--domain-identifier',BUNDLE]
 if mode!='lock-cycle':
  for p in source.iterdir():
   if p.is_symlink() or not p.is_file() or p.name not in ALLOWED or p.stat().st_size>65536:raise RuntimeError('unexpected provisioning input')
  command(device,['device','copy','to','--source',str(source),'--destination','Documents/inputs-'+profile,*domain],capture/'inputs')
 observed=[];errors=[];messages=queue.Queue();admitted=False;ready=False;locked=False;deadline=time.monotonic()+(800 if mode=='lock-cycle' else 80)
 def sanitize(data):
  for value in (device['identifier'],device['hardwareProperties'].get('udid','')):
   if value:data=data.replace(value.encode(),b'<selected-device>')
  return data
 with tempfile.TemporaryDirectory() as tmp,open(Path(tmp)/'stderr','w+b') as err:
  process=subprocess.Popen(['xcrun','devicectl','device','process','launch','--device',device['identifier'],'--timeout','820','--console',BUNDLE,mode,profile,run],stdout=subprocess.PIPE,stderr=err)
  def reader():
   try:
    size=0
    with (capture/'launch.stdout').open('xb') as log:
     for line in process.stdout:
      size+=len(line)
      if size>262144:raise RuntimeError('console bound exceeded')
      line=sanitize(line);observed.append(line);log.write(line);log.flush();messages.put(line.rstrip(b'\r\n'))
    messages.put(None)
   except BaseException as e:errors.append(e);messages.put(None)
  thread=threading.Thread(target=reader);thread.start()
  try:
   while True:
    if time.monotonic()>=deadline:raise TimeoutError('bounded device operation deadline')
    try:line=messages.get(timeout=1)
    except queue.Empty:continue
    if line is None:break
    if line==f'QPC_IOS_READY run={run}'.encode():
     if admitted:raise RuntimeError('duplicate startup admission')
     p=Path(tmp)/'admission';p.write_text(run+'\n')
     command(device,['device','copy','to','--source',str(p),'--destination',f'Documents/admission-{run}.txt',*domain],capture/'admission',timeout=15);admitted=True
    if line.startswith(f'QPC_PROTECTION_READY run={run} '.encode()):
     if mode!='lock-cycle' or ready:raise RuntimeError('unexpected lock readiness')
     ready=True;(OUT/'READY.json').write_text(json.dumps({'run':run,'profiles':2,'ready':True,'unix_time':time.time()},indent=2)+'\n')
    if line.startswith(f'QPC_PROTECTION_LOCKED run={run} '.encode()):
     if not ready or locked:raise RuntimeError('unexpected locked proof')
     locked=True;(OUT/'LOCKED.json').write_text(json.dumps({'run':run,'locked':True,'observation':line.decode(),'unix_time':time.time()},indent=2)+'\n')
   code=process.wait(timeout=10);thread.join(timeout=5)
   if errors or thread.is_alive():raise RuntimeError('console collection failed')
   err.flush();err.seek(0);stderr=sanitize(err.read());(capture/'launch.stderr').write_bytes(stderr)
   (capture/'launch.status.json').write_text(json.dumps({'returncode':code,'startup_admitted':admitted,'lock_ready':ready,'locked_observed':locked},indent=2)+'\n')
   marker=f'QPC_PROTECTION_PASS mode={mode} profile={profile} run={run}\n'.encode();stdout=b''.join(observed)
   if code or stderr or not admitted or stdout.splitlines().count(marker.rstrip(b'\n'))!=1 or stdout.splitlines().count(b'The app terminated with the exit code 0.')!=1:raise RuntimeError('missing successful device terminal proof; see '+str(capture))
   if mode=='lock-cycle' and not (ready and locked):raise RuntimeError('protected unavailability not observed')
  finally:
   if process.poll() is None:process.terminate();process.wait(timeout=10)
   thread.join(timeout=5)
   if not (capture/'launch.stderr').exists():err.flush();err.seek(0);(capture/'launch.stderr').write_bytes(sanitize(err.read()))
 for leaf,local in [(f'receipt-{run}.txt','receipt.txt'),(f'result-{run}.bin','public-result.bin')]+([(f'report-{run}.json','report.json')] if mode=='lock-cycle' else []):
  command(device,['device','copy','from','--source','Documents/'+leaf,'--destination',str(capture/local),*domain],capture/(local+'-copy'))
 if (capture/'receipt.txt').read_bytes()!=marker:raise RuntimeError('receipt differs')
 data=(capture/'public-result.bin').read_bytes()
 if not 1<=len(data)<=65536:raise RuntimeError('public output width')
 with destination.open('xb') as file:file.write(data)
 (capture/'RESULT.json').write_text(json.dumps({'completed':True,'mode':mode,'profile':profile,'run':run,'public_sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
 print(profile+':'+mode+':passed')
if __name__=='__main__':
 try:main()
 except Exception as error:print(str(error),file=sys.stderr);sys.exit(1)
