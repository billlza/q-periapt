import UIKit
import Foundation
import Darwin
import QPeriaptContinuity

func closeAfter<T>(_ close: () throws -> Void, _ body: () throws -> T) throws -> T {
    let result = Result(catching: body)
    do { try close() } catch { throw ClientError("owner close failed: \(error); operation: \(result)") }
    return try result.get()
}
struct ProtectionInput {
    let profile: String, source: URL, path: String
    var recoverable: Bool { profile == "recoverable" }
    func open() throws -> ContinuityConfiguration {
        try .prepareOpen(path: path, trust: trust(source, recoverable), protocolPolicy: policy(source))
    }
    func operation(_ mode: String) throws -> [UInt8] {
        let configuration = mode == "create" ? try ContinuityConfiguration.prepareCreate(path:path,input:initial(source,recoverable)) : try open()
        let owner = try closeAfter({ try configuration.close() }) {
            try configuration.finishOpen()
            let intent = try ReplacementInputs(source:source,path:path).intent()
            return mode == "create" ? try configuration.createEnrollment(intent:intent) : try configuration.resumeEnrollment(intent:intent)
        }
        return try closeAfter({ try owner.close() }) {
            let request = try owner.request()
            if mode == "create" { return request }
            if mode == "enroll" {
                let input = ReplacementInputs(source:source,path:path)
                let journal = try owner.accept(certificate:input.read("grant-certificate"),roster:input.read("grant-roster"),pin:input.account())
                guard case .local(let prepared) = try owner.prepareStorage(), prepared == journal else { throw ClientError("local journal mismatch") }
            }
            let device = try owner.activate()
            return try closeAfter({ try device.close() }) {
                let status = try owner.status()
                guard status.phase == .active, let journal = status.journal else { throw ClientError("original enrollment inactive") }
                return request + status.signingID.bytes + journal.bytes + (try device.nextPublication().bytes)
            }
        }
    }
    func lockedRefusal() throws -> Int32 {
        let configuration = try open()
        return try closeAfter({ try configuration.close() }) {
            do { try configuration.finishOpen(); throw ClientError("protected SDK store unexpectedly opened") }
            catch let failure as ContinuityFailure {
                // OpenConfiguration -> PolicyStore::open_inner -> open_private_file.
                guard failure.code == 702 else { throw failure }
                return failure.code
            }
        }
    }
}

@main @MainActor
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application:UIApplication,configurationForConnecting session:UISceneSession,options:UIScene.ConnectionOptions)->UISceneConfiguration {
        let value=UISceneConfiguration(name:"Protection",sessionRole:session.role);value.delegateClass=SceneDelegate.self;return value
    }
}
@MainActor
final class SceneDelegate:UIResponder,UIWindowSceneDelegate {
    var window:UIWindow?
    private var started=false
    func scene(_ scene:UIScene,willConnectTo session:UISceneSession,options:UIScene.ConnectionOptions) {
        guard let scene=scene as? UIWindowScene else { exit(1) }
        let view=UIViewController();view.view.backgroundColor = .systemBackground
        let label=UILabel();label.text="Continuity storage protection validation";label.textAlignment = .center;label.translatesAutoresizingMaskIntoConstraints=false;view.view.addSubview(label)
        NSLayoutConstraint.activate([label.centerXAnchor.constraint(equalTo:view.view.centerXAnchor),label.centerYAnchor.constraint(equalTo:view.view.centerYAnchor)])
        let window=UIWindow(windowScene:scene);window.rootViewController=view;window.makeKeyAndVisible();self.window=window
    }
    func sceneDidBecomeActive(_ scene:UIScene) {
        guard !started else { return };started=true
        Task { await ProtectionRunner.execute() }
    }
    func sceneWillResignActive(_ scene:UIScene) { ProtectionRunner.beginBackground() }
}
@MainActor
enum ProtectionRunner {
    static var armed=false
    static var background:UIBackgroundTaskIdentifier = .invalid
    static func emit(_ text:String) throws { try FileHandle.standardOutput.write(contentsOf:Data((text+"\n").utf8)) }
    static func beginBackground() {
        guard armed,background == .invalid else { return }
        background=UIApplication.shared.beginBackgroundTask(withName:"Check closed protected stores") {
            // Expiration is an explicit unsuccessful test, never a protection pass.
            fputs("QPC_PROTECTION_FAIL background task expired before locked proof\n",stderr);exit(2)
        }
    }
    static func endBackground() {
        if background != .invalid { UIApplication.shared.endBackgroundTask(background);background = .invalid }
    }
    static func tree(_ root:URL) throws -> [URL] {
        var result=[root]
        for child in try FileManager.default.contentsOfDirectory(at:root,includingPropertiesForKeys:[.isDirectoryKey,.isSymbolicLinkKey]) {
            let properties=try child.resourceValues(forKeys:[.isDirectoryKey,.isSymbolicLinkKey])
            guard properties.isSymbolicLink == false else { throw ClientError("unexpected symbolic link") }
            if properties.isDirectory == true { result += try tree(child) } else { result.append(child) }
        }
        return result
    }
    static func inventory(_ root:URL) throws -> [String:String] {
        var result=[String:String]()
        for path in try tree(root) {
            let attributes=try FileManager.default.attributesOfItem(atPath:path.path)
            guard attributes[.protectionKey] as? FileProtectionType == .complete else { throw ClientError("complete protection missing") }
            let name=String(path.path.dropFirst(root.path.count))
            result[name]="\(attributes[.type]!)|\(attributes[.size]!)|\(attributes[.systemFileNumber]!)|\(attributes[.modificationDate]!)"
        }
        return result
    }
    static func execute() async {
        do { try await run();exit(0) }
        catch { endBackground();fputs("QPC_PROTECTION_FAIL \(error)\n",stderr);exit(1) }
    }
    static func run() async throws {
        let args=Array(CommandLine.arguments.dropFirst())
        guard args.count==3,["create","enroll","lock-cycle"].contains(args[0]),["fixed","recoverable","both"].contains(args[1]),args[2].count==32,args[2].allSatisfy({"0123456789abcdef".contains($0)}) else { throw ClientError("arguments") }
        let mode=args[0],profile=args[1],run=args[2],fm=FileManager.default
        let docs=try fm.url(for:.documentDirectory,in:.userDomainMask,appropriateFor:nil,create:false)
        try emit("QPC_IOS_READY run=\(run)")
        let clock=ContinuousClock(),admission=docs.appendingPathComponent("admission-\(run).txt"),startupDeadline=clock.now.advanced(by:.seconds(20))
        while !fm.fileExists(atPath:admission.path) {
            guard clock.now<startupDeadline else { throw ClientError("host startup admission timed out") }
            try await Task.sleep(for:.milliseconds(20))
        }
        guard try Data(contentsOf:admission)==Data((run+"\n").utf8) else { throw ClientError("host admission differs") }
        let root=docs.appendingPathComponent("private-continuity",isDirectory:true)
        if !fm.fileExists(atPath:root.path) { try fm.createDirectory(at:root,withIntermediateDirectories:false,attributes:[.posixPermissions:0o700]) }
        guard let resolved=realpath(root.path,nil) else { throw NSError(domain:NSPOSIXErrorDomain,code:Int(errno)) }
        let canonical=String(cString:resolved);free(resolved)
        func input(_ name:String)->ProtectionInput { ProtectionInput(profile:name,source:docs.appendingPathComponent("inputs-"+name),path:canonical+"/"+name) }
        let result:[UInt8]
        if mode != "lock-cycle" { result=try input(profile).operation(mode) }
        else {
            guard profile=="both",UIApplication.shared.isProtectedDataAvailable else { throw ClientError("protected data unavailable before test") }
            let names=["fixed","recoverable"]
            let before=try names.map { try input($0).operation("resume") }
            let sentinel=root.appendingPathComponent("public-sentinel")
            try Data("public protection control\n".utf8).write(to:sentinel,options:.withoutOverwriting)
            let paths=try tree(root)
            for path in paths { try fm.setAttributes([.protectionKey:FileProtectionType.complete],ofItemAtPath:path.path) }
            let original=try inventory(root)
            guard try Data(contentsOf:sentinel)==Data("public protection control\n".utf8) else { throw ClientError("unlocked sentinel differs") }
            // Ensure the exact protected state still opens while unlocked.
            for (index,name) in names.enumerated() { guard try input(name).operation("resume")==before[index] else { throw ClientError("pre-lock protected reopen changed original") } }
            // Reopening redb may update bookkeeping; freeze the baseline only after all owners close.
            let baseline=try inventory(root)
            guard Set(baseline.keys)==Set(original.keys) else { throw ClientError("namespace changed before lock") }
            armed=true
            try emit("QPC_PROTECTION_READY run=\(run) files=\(paths.count) profiles=2")
            let lockDeadline=clock.now.advanced(by:.seconds(600))
            while UIApplication.shared.isProtectedDataAvailable {
                guard clock.now<lockDeadline else { throw ClientError("no protected-data-unavailable transition") }
                try await Task.sleep(for:.milliseconds(50))
            }
            guard background != .invalid else { throw ClientError("no UIKit background execution grant") }
            let fd=open(sentinel.path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW),openError=errno
            if fd>=0 { guard close(fd)==0 else { throw ClientError("unexpected control close failed") };throw ClientError("complete sentinel opened while locked") }
            guard openError==EACCES || openError==EPERM else { throw NSError(domain:NSPOSIXErrorDomain,code:Int(openError)) }
            var codes=[Int32]()
            for name in names { codes.append(try input(name).lockedRefusal()) }
            guard !UIApplication.shared.isProtectedDataAvailable else { throw ClientError("unlock raced refusal checks") }
            try emit("QPC_PROTECTION_LOCKED run=\(run) available=false sentinel_errno=\(openError) fixed=\(codes[0]) recoverable=\(codes[1])")
            armed=false;endBackground()
            let unlockDeadline=clock.now.advanced(by:.seconds(180))
            while !UIApplication.shared.isProtectedDataAvailable {
                guard clock.now<unlockDeadline else { throw ClientError("unlock deadline") }
                try await Task.sleep(for:.milliseconds(50))
            }
            guard try inventory(root)==baseline else { throw ClientError("locked attempts changed original files or namespace") }
            var recovered=[UInt8]()
            for (index,name) in names.enumerated() {
                let value=try input(name).operation("resume")
                guard value==before[index] else { throw ClientError("original public request, signer, journal or publication changed") }
                recovered += value
            }
            let report:[String:Any] = ["protected_data_unavailable":true,"sentinel_errno":openError,"fixed_refusal":codes[0],"recoverable_refusal":codes[1],"protected_entries":paths.count,"namespace_unchanged":true,"original_identity_journal_publication":true,"unlock_reactivation":true]
            try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]).write(to:docs.appendingPathComponent("report-\(run).json"),options:.withoutOverwriting)
            result=recovered
        }
        try durableIOS(result,docs.appendingPathComponent("result-\(run).bin").path)
        let marker="QPC_PROTECTION_PASS mode=\(mode) profile=\(profile) run=\(run)"
        try durableIOS(Array((marker+"\n").utf8),docs.appendingPathComponent("receipt-\(run).txt").path)
        try emit(marker)
    }
}
