globalThis.invoke = args => new Promise((resolve, reject) => {
  const worker = new Worker('./worker.js', {type:'module'});
  let stopped=false, outcome, closeReceipt;
  const finish=(error,result)=>{if(stopped)return;stopped=true;clearTimeout(timer);worker.terminate();if(error)reject(error);else resolve(result);};
  const timer=setTimeout(()=>finish(Error('pending recovery Worker deadline')),45000);
  const interrupt=async marker=>{
    const before=await navigator.locks.query();
    if(before.held.length!==1)throw Error('original root lease missing before Worker interruption');
    const name=before.held[0].name,start=performance.now();worker.terminate();
    for(;;){const after=await navigator.locks.query();if(!after.held.some(v=>v.name===name))break;if(performance.now()-start>10000)throw Error('original root lease release deadline');await new Promise(r=>setTimeout(r,20));}
    finish(undefined,{done:true,...marker,rootHeldBefore:1,releaseWaitMs:performance.now()-start});
  };
  worker.onerror=e=>finish(Error(e.message));
  worker.onmessage=async({data})=>{
    try {
      if(data.ready){
        worker.postMessage(args);
        if(args.cancelAfterQuery || args.killAfterQuery){
          for(;;){if(stopped)return;const response=await fetch('/status/'+args.case,{credentials:'omit',cache:'no-store'});if(!response.ok)throw Error('query observation');const records=await response.json();
            if(records.some(r=>r.mode==='hold-query' && r.cut===args.cut && r.trigger && r.request_tag===1)){
              if(args.killAfterQuery)await interrupt({workerTerminatedBeforeConfirmation:true});else worker.postMessage({controlClose:true});break;
            }
            await new Promise(r=>setTimeout(r,20));
          }
        }
      }else if(data.localConfirmationObserved){
        if(!args.killAfterLocalConfirmation)throw Error('unexpected local confirmation marker');
        await interrupt({workerTerminatedAfterConfirmation:true});
      }else if(data.closeComplete){
        closeReceipt=data;if(data.error || data.closed!==true)throw Error('original cancellation close failed');
        if(outcome)finish(undefined,{...outcome,closeReceipt});
      }else if(data.done){
        if(args.action==='create' && data.value?.request){const response=await fetch('/capture/'+args.case+'.bin',{method:'POST',body:new Uint8Array(data.value.request)});if(!response.ok)throw Error('enrollment capture');delete data.value.request;}
        if(data.value?.phase==='requires-witness-enrollment'){const response=await fetch('/capture/'+args.case+'-genesis.json',{method:'POST',body:JSON.stringify(data.value)});if(!response.ok)throw Error('genesis capture');}
        if(args.cancelAfterQuery){outcome=data;if(closeReceipt)finish(undefined,{...outcome,closeReceipt});}else finish(undefined,data);
      }
    }catch(error){finish(error);}
  };
});
