import {sessionAction} from './session-checks.js';
import initialize, * as sdk from '/node_modules/q-periapt-sdk-wasm/web/index.js';
await initialize();
const b=v=>new Uint8Array(v), check=(v,m)=>{if(!v)throw Error(m)};
let owner,closePending;
self.onmessage=async({data})=>{
 if(data.controlClose){
  try{check(owner,'cancel owner');closePending=owner.close();await closePending;postMessage({closeComplete:true,closed:owner.is_closed()});}
  catch(error){postMessage({closeComplete:true,error:String(error),code:error?.code});}
  return;
 }
 const owned=[],own=v=>{owned.push(v);return v};let value,failure;const observations=[],cleanupErrors=[];
 const get=async name=>{const r=await fetch('/inputs/'+name);if(!r.ok)throw Error('missing public input');return r.json()};
 const snapshot=async()=>{const s=own(await owner.status()),r=ownOptional(s.roster_refresh());return {phase:s.phase(),journal:s.journal()?[...s.journal()]:null,refresh:r?{previous:String(own(r.previous()).version()),target:String(own(r.target()).version()),outcome:r.outcome()??null,observedAt:r.observed_at()===undefined?null:String(r.observed_at())}:null}};
 const ownOptional=v=>v===undefined?undefined:own(v);
 const rosterProgress=async()=>{const p=ownOptional(await owner.witnessed_roster_refresh_progress());if(!p)return null;const previous=own(p.previous()),target=own(p.target()),proposal=ownOptional(p.proposal());return {stage:p.stage(),retired:p.retired(),operation:[...p.operation_id()],previous:String(previous.version()),target:String(target.version()),proposal:proposal?[...proposal.bytes()]:null}};
 try {
  const cfg=await get(data.case+'.json'),description=b(cfg.description),at=BigInt(data.at??Math.floor(Date.now()/1000));
  const intent=own(new sdk.QPeriaptContinuityEnrollment(b(cfg.root),description.slice(0,16),1n,b(cfg.family),BigInt(cfg.from),BigInt(cfg.until)));
  const storage=b(data.id.match(/../g).map(v=>parseInt(v,16)));
  if(data.action==='create'){
   owner=await sdk.QPeriaptContinuityDevice.create(data.name,storage,intent);value={request:[...await owner.request(at)]};
  }else{
   const grant=await get(data.case+'-grant.json'),statement=cfg.policies[data.profile??'required'];
   const history=own(new sdk.QPeriaptContinuityHistoricalPolicy(b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire)));
   let runtime,policy;
   if(!data.historicalOnly){runtime=own(new sdk.QPeriaptRuntime(b(cfg.sdk_policy),b(cfg.sdk_signature),b(cfg.sdk_root),b(cfg.sdk_state),32,4));policy=own(new sdk.QPeriaptContinuityPolicy(runtime,b(cfg.policy_root),b(cfg.family),BigInt(statement.version),b(statement.digest),b(statement.wire),at));}
   const account=(v)=>own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),BigInt(v.version),b(v.digest),b(cfg.family)));
   owner=await sdk.QPeriaptContinuityDevice.open(data.name,storage,intent);observations.push(await snapshot());
   const witness=own(sdk.QPeriaptContinuityWitness.for_loopback(b(cfg.witness_id),b(data.wrongWitness?cfg.root:cfg.witness_public),new URL('/witness/'+data.case+'?mode='+(data.mode??'normal')+'&cut='+(data.cut??'0'),location.origin).href,data.timeout??5000));
   const target=async()=>{const v=await get(data.targetFile??data.case+'-target.json');return own(new sdk.QPeriaptContinuityRosterTarget(account(v),b(v.certificate),b(v.roster),at))};
   const proposal=()=>own(new sdk.QPeriaptContinuityRosterProposal(b(data.proposal)));
   if(data.closePolicy)policy.close();if(data.closeRuntime)runtime.close();
   if(data.action.startsWith('pending-')) {
    check(runtime===undefined,'pending recovery constructed an operational runtime');
    if(data.action==='pending-request'){
     const r=own(await owner.pending_write_recovery_request(history,witness));
     value={proposal:[...r.proposal()],binding:[...r.binding()],metadata:[...r.metadata()],signed:[...r.signed_request()],document:r.to_json()};
    }else if(data.action==='pending-confirm'){
     await owner.confirm_pending_write_recovery(b(data.approved),b(data.metadata),history,witness);
     if(data.killAfterLocalConfirmation){postMessage({localConfirmationObserved:true});await new Promise(()=>{});}
     value={confirmed:true};
    }else throw Error('unknown pending action');
    value.runtimeCreated=false;value.observedAt=Number(at);
   }else if(data.action==='session') {
    if(data.continued){
     const approved=await get(data.case+'-approval.json');
     runtime=own(new sdk.QPeriaptRuntime(b(cfg.sdk_policy),b(cfg.sdk_signature),b(cfg.sdk_root),b(cfg.sdk_state),32,4));
     policy=own(new sdk.QPeriaptContinuityPolicy(runtime,b(cfg.policy_root),b(cfg.family),BigInt(approved.version),b(approved.digest),b(approved.policy),at));
     await owner.activate_witnessed_policy_renewal(history,policy,witness,at);
    }else await owner.activate(policy,witness,at);
    value=await sessionAction(owner,policy,runtime,cfg,grant,data,history);
   }else if(data.action.startsWith('p-')) {
    const issued=await get(data.case+'-approval.json');
    const historicalTarget=own(new sdk.QPeriaptContinuityHistoricalPolicy(b(cfg.policy_root),b(cfg.family),BigInt(issued.version),b(issued.digest),b(issued.policy)));
    const target=()=>{if(!runtime)runtime=own(new sdk.QPeriaptRuntime(b(cfg.sdk_policy),b(cfg.sdk_signature),b(cfg.sdk_root),b(cfg.sdk_state),32,4));return own(new sdk.QPeriaptContinuityPolicy(runtime,b(cfg.policy_root),b(cfg.family),BigInt(issued.version),b(issued.digest),b(issued.policy),at))};
    const ps=async()=>{const p=own(await owner.policy_renewal_status());return {phase:p.phase(),operation:p.operation_id()?[...p.operation_id()]:null,statement:p.statement()?[...p.statement()]:null,target:p.target_version()===undefined?null:String(p.target_version()),abandonment:p.abandonment()??null}};
    const wp=async()=>{const p=ownOptional(await owner.witnessed_policy_renewal_progress());if(!p)return null;const q=own(p.proposal());return {stage:p.stage(),retired:p.retired(),proposal:[...q.bytes()],statement:[...q.statement()],target:String(p.target_version())}};
    if(data.action==='p-stage'){
     const request=own(data.profile==='local'?await owner.policy_renewal_request(b(data.operationId),history):await owner.witnessed_policy_renewal_request(b(data.operationId),history,witness));
     const current=target();let wrong;
     try { own(new sdk.QPeriaptContinuityPolicyGrant(b(issued.account_approval),b(issued.account_approval),request,history,history,current,at)) } catch(e){wrong=e}
     check(wrong?.code,'duplicate approval accepted');
     const g=own(new sdk.QPeriaptContinuityPolicyGrant(b(issued.account_approval),b(issued.policy_approval),request,history,history,current,at));
     check(JSON.stringify([...g.statement()])===JSON.stringify(issued.statement),'grant statement drift');
     own(await owner.stage_policy_renewal(g,b(data.operationId),history,current,at));
     own(await owner.stage_policy_renewal(g,b(data.operationId),history,current,at));
     check(JSON.stringify([...await owner.pending_policy_renewal_approval(b(data.operationId))])===JSON.stringify([...g.bytes()]),'original approval drift');
     value={status:await ps(),progress:await wp(),negativeApproval:wrong.code};
    } else if(data.action==='p-status')value={status:await ps(),progress:await wp(),runtimeCreated:runtime!==undefined};
    else if(data.action==='p-prepare'){
     const p=own(await owner.prepare_witnessed_policy_renewal(history,history,target(),witness,at));
     const recovered=ownOptional(await owner.recover_witnessed_policy_renewal_preparation(history));
     check(recovered&&JSON.stringify([...p.bytes()])===JSON.stringify([...recovered.bytes()]),'proposal recovery drift');
     value={proposal:[...p.bytes()],status:await ps(),progress:await wp()};
    } else if(data.action==='p-commit'){
     const p=own(new sdk.QPeriaptContinuityPolicyProposal(b(data.proposal)));
     value={remote:await owner.commit_witnessed_policy_renewal(p,history,target(),witness,at),status:await ps(),progress:await wp()};
    } else if(data.action==='p-reconcile'||data.action==='p-close') {
     const method=data.action==='p-close'?'close_witnessed_policy_renewal':'reconcile_witnessed_policy_renewal';
     value={remote:await owner[method](b(data.operationId),b(issued.statement),history,witness),status:await ps(),progress:await wp(),runtimeCreated:runtime!==undefined};
    } else if(data.action==='p-local-commit'){
     own(await owner.reconcile_policy_renewal(history,target(),at));value={status:await ps()};
    } else if(data.action==='p-historical'){
     own(await owner.recover_historical_policy_renewal(b(data.operationId),b(issued.statement),history));value={status:await ps(),runtimeCreated:runtime!==undefined};
    } else if(data.action==='p-activate'){
     const current=target();const id=data.profile==='local'||data.forceLocal?await owner.activate_local_policy_renewal(history,current,at):await owner.activate_witnessed_policy_renewal(history,current,witness,at);
     value={journal:[...id],status:await ps(),progress:await wp(),enrollment:await snapshot()};
    } else throw Error('unknown policy action');
   }else if(data.action==='accept'){value={journal:[...await owner.accept(b(grant.certificate),b(grant.roster),account(grant),policy,at)]};}
   else if(data.action==='prepare'){
    const p=own(await owner.prepare(policy,at)),s=await snapshot();value=p.requires_witness()?{phase:'requires-witness-enrollment',journal:s.journal,genesis:[...p.image_digest()],subject:[...p.subject()]}:{phase:'prepared-local',journal:s.journal};
   }else if(data.action==='activate'){
    const id=data.profile==='local'?await owner.activate_local(policy,at):await owner.activate(policy,witness,at);
    observations.push({activatedJournal:[...id]});
    const key=await owner.generate_prekey(policy,new Uint8Array(32).fill(55),sdk.QPeriaptContinuityPrekeyKind.OneTimePq,BigInt(cfg.from),BigInt(Math.min(cfg.until,cfg.policy_until)),at);
    value={journal:[...id],prekey:[...key],status:await snapshot(),progress:await rosterProgress()};
   }else if(data.action==='scalar'){
    let hooks=0;const coercible={valueOf(){hooks++;return 1n}};
    const rejected=[];
    for(const bad of [(1n<<64n)+1n,1n-(1n<<64n),'1',true,coercible]){
     let error;try{own(new sdk.QPeriaptContinuityAccountTrust(b(cfg.account),b(cfg.root),bad,b(grant.digest),b(cfg.family)))}catch(e){error=e}
     check(error?.code==='InvalidInput','account version wrapped/coerced');rejected.push(String(typeof bad));
    }
    for(const bad of [(1n<<64n)+at,at-(1n<<64n),String(at),true,coercible]){
     let error;try{await owner.request(bad)}catch(e){error=e}
     check(error?.code==='InvalidInput','request time wrapped/coerced');
    }
    check(hooks===0,'scalar coercion hook executed');value={rejected:10,hooks,status:await snapshot()};
   }else if(data.action==='new-policy-operation')value={operation:[...sdk.QPeriaptContinuityPolicyRequest.new_operation_id()]};
   else if(data.action==='policy-request'){
    const request=own(data.profile==='local'||data.forceLocal?await owner.policy_renewal_request(b(data.operationId),history):await owner.witnessed_policy_renewal_request(b(data.operationId),history,witness));
    const requestValue={operation:[...request.operation_id()]};
    for(const k of ['journal','original_owner','original_credential_digest','current_credential_digest','current_roster_digest','original_policy_digest','previous_policy_digest','original_credential','original_roster','current_credential','current_roster'])requestValue[k]=[...request[k]()];
    for(const k of ['current_roster_version','original_policy_version','previous_policy_version'])requestValue[k]=String(request[k]());
    const authorization=request.previous_policy_authorization();requestValue.previous_policy_authorization=authorization===undefined?null:[...authorization];
    value={requestValue,status:await snapshot(),runtimeCreated:runtime!==undefined};
   }else if(data.action==='new-operation')value={operation:[...sdk.QPeriaptContinuityRosterProposal.new_operation_id()]};
   else if(data.action==='prepare-roster'){
    const p=own(await owner.prepare_witnessed_roster_refresh(b(data.operationId),history,policy,await target(),witness,at));
    value={proposal:[...p.bytes()],binding:[...p.binding()],progress:await rosterProgress()};
   }else if(data.action==='recover-preparation'){
    const p=ownOptional(await owner.recover_witnessed_roster_refresh_preparation(history));value={proposal:p?[...p.bytes()]:null,progress:await rosterProgress()};
   }else if(data.action==='progress')value={progress:await rosterProgress()};
   else if(data.action==='commit')value={state:await owner.commit_witnessed_roster_refresh(proposal(),history,policy,witness,at),progress:await rosterProgress()};
   else if(data.action==='reconcile')value={state:await owner.reconcile_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='close-roster')value={state:await owner.close_witnessed_roster_refresh(proposal(),history,witness),progress:await rosterProgress()};
   else if(data.action==='abandon')value={progress:(own(await owner.abandon_unprepared_roster_refresh(b(data.operationId),history)),await rosterProgress())};
   else if(data.action==='local-refresh'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest)));
    own(await owner.refresh_local_roster(previous,b(t.roster),account(t),policy,at));value={status:await snapshot()};
   }else if(data.action==='local-resolve'){
    const t=await get(data.targetFile??data.case+'-target.json'),previous=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(data.previous.version),b(data.previous.digest))),targetCp=own(new sdk.QPeriaptContinuityCheckpoint(BigInt(t.version),b(t.digest)));
    const result=own(await owner.resolve_local_roster_refresh(previous,targetCp,history,at));value={outcome:result.outcome(),observed:own(result.observed()).version().toString(),status:await snapshot()};
   }else throw Error('unknown action');
  }
 }catch(error){failure=error;if(error.ownerClosed!==undefined)check(owner?.is_closed()===error.ownerClosed,'owner closure mismatch');}
 try{if(closePending)await closePending;if(owner)await owner.close();}catch(error){cleanupErrors.push(String(error));}
 if(owner){try{check(owner.is_closed(),'owner close missing');owner.free();}catch(error){cleanupErrors.push(String(error));}owner=undefined;}closePending=undefined;
 for(const object of owned.reverse()){
  try{if(typeof object.close==='function')await object.close();}catch(error){cleanupErrors.push(String(error));}
  try{object.free();}catch(error){cleanupErrors.push(String(error));}
 }
 postMessage(failure||cleanupErrors.length?{done:true,error:String(failure??'cleanup failure'),code:failure?.code,ownerClosed:failure?.ownerClosed,observations,cleanupErrors}:{done:true,value,observations,cleanupErrors});
};
postMessage({ready:true});
