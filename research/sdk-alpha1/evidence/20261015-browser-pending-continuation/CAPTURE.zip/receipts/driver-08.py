from pathlib import Path
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
sdk.command([sys.executable,'-B',str(root/'artifact/python_bootstrap.py'),str(stage/'harness-06/run-07.py'),'run-08','unapplied','applied'],stage/'run-08',root)
print('Browser composed recovery producer returned successfully')
