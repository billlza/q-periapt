"""Read only public protocol receipts; never open browser or native owners."""
import json


def require(value, message):
    if not value:
        raise ValueError(message)


def verify(state):
    require(state['completed'] and state['producer_unchanged'] and not state['release_claim_eligible'], 'producer status')
    require(not state['fixture_failures'], 'fixture failure')
    require([row['case'] for row in state['cases']] == ['unapplied', 'applied'], 'case census')
    census = {}
    for row in state['cases']:
        case = row['case']
        selected = [entry for entry in state['observations'] if entry['case'].endswith('-' + case)]
        key = selected[0]['case']
        require(all(entry['case'] == key for entry in selected), 'mixed runtime cohorts')
        prefix = ['create', 'accept', 'prepare', 'activate', 'new-request', 'establish', 'new-message', 'send', 'status', 'drive-rekey', 'rekey-progress', 'new-policy-operation', 'peer-roster', 'pending-request', 'pending-request']
        recovery = (['pending-confirm'] if case == 'unapplied' else []) + ['pending-confirm', 'pending-confirm', 'pending-request', 'pending-request', 'pending-confirm', 'pending-request', 'pending-confirm', 'pending-request', 'pending-confirm', 'pending-confirm']
        suffix = ['policy-request', 'p-stage', 'p-prepare', 'p-commit', 'p-activate', 'pending-confirm', 'rekey-progress', 'rekey-progress', 'status', 'drive-rekey', 'send', 'receive', 'receive', 'new-message', 'send']
        require([v['action'] for v in selected] == prefix + recovery + suffix, 'Worker call sequence')
        require(all(v['result'].get('cleanupErrors', []) == [] for v in selected), 'Worker cleanup')
        codes = [v['result'].get('code') for v in selected if 'error' in v['result']]
        expected = ['PeerTransport', 'PeerTransport', 'WitnessTransport'] + (['Scope'] if case == 'unapplied' else []) + ['Authentication', 'Cancelled', 'Absent', 'Conflict', 'Conflict']
        require(codes == expected, 'refusal census')
        require(all(v['result'].get('ownerClosed') is True for v in selected if 'error' in v['result']), 'failed owner stayed open')
        pending = row['pending_recovery']
        require(pending['controller_invoked'] == (case == 'unapplied'), 'applied target needed an invented second approval')
        require(pending['confirmation_request_tags'] == [1] * 5, 'confirmation performed a mutation')
        inspection = pending['inspection']
        require(inspection['verified'] and not inspection['mutated_witness'] and inspection['roster_changes'] == 1 and inspection['original_unconfirmed_messages'] == 1, 'independent complete-delta inspection')
        require(inspection['proposal_binding'] == pending['binding'] and inspection['session'] == row['session'] and inspection['message'] == row['message'], 'original operation scope')
        cuts = pending['interruptions']
        require(len(cuts) == 3 and cuts[0]['code'] == 'Cancelled' and cuts[0]['closeReceipt'] == {'closeComplete': True, 'closed': True}, 'cancelled original query')
        require(cuts[1]['workerTerminatedBeforeConfirmation'] and cuts[2]['workerTerminatedAfterConfirmation'], 'actual Worker terminations')
        require(all(c['rootHeldBefore'] == 1 and 0 <= c['releaseWaitMs'] <= 10000 for c in cuts[1:]), 'root lease release')
        recovered = [v['result']['value'] for v in selected if v['action'] == 'pending-request' and 'value' in v['result']]
        require(len(recovered) == 5, 'pending readback census')
        until = row['real_expiry']['policy_until']
        require(row['real_expiry']['pending_at'] < until < row['real_expiry']['renew_at'] < row['real_expiry']['credentials_until'], 'real expiry order')
        require(all(v['runtimeCreated'] is False and v['observedAt'] > until and v['proposal'] == pending['proposal'] and v['metadata'] == pending['metadata'] for v in recovered), 'changed original pending bytes or runtime permission')
        document = json.loads(recovered[0]['document'])
        require(document['proposal'] == bytes(pending['proposal']).hex() and document['binding'] == bytes(pending['binding']).hex(), 'public projection scope')
        before, after = document['source'], document['target']
        require(before['local_account'] == after['local_account'] == bytes(inspection['local_account']).hex(), 'account changed')
        require(before['head']['fence'] == after['head']['fence'] and int(before['head']['revision']) + 1 == int(after['head']['revision']), 'ordinary target shape')
        require([v['id'] for v in before['records']] == [v['id'] for v in after['records']], 'complete record identity census')
        sessions = [[v for v in view['records'] if v['metadata']['kind'] == 'session'] for view in (before, after)]
        require(len(sessions[0]) == 1 and sessions[0] == sessions[1], 'session changed inside roster-only intent')
        s = sessions[0][0]['metadata']['session']
        require(s['session'] == bytes(row['session']).hex() and s['state']['kind'] == 'live' and s['state']['previous_closure'] is None, 'closed or substituted session')
        unknown = [entry['message'] for epoch in s['state']['epochs'] for entry in epoch['accounting']['unconfirmed']]
        require(unknown == [bytes(row['message']).hex()], 'original unknown message accounting')
        require(row['active']['journal'] == row['original']['journal'] and row['active']['status']['phase'] == 3, 'new journal substituted for renewal')
        require(row['committed']['remote'] == 2 and row['committed']['progress']['retired'], 'policy not committed and retired')
        native = row['native_policy']
        require(native['policy_renewed'] and native['same_original_journal'] and native['original_policy_expired'] and native['session'] == row['session'], 'peer authority not independently renewed')
        require(row['progress_before'] == row['progress_after'] and row['progress_before']['pending'] == '1' and row['progress_before']['confirmed'] == '0', 'original rekey replaced')
        require(row['rekey']['epoch'] == '1' and row['delivery'] == {'consumption': 1, 'status': 3}, 'original traffic not confirmed')
        require(row['fresh_message'] != row['message'] and row['native_effects'] == 2 and row['completed'], 'fresh work absent or duplicate effect')
        require(row['received']['application']['calls'] == row['received']['application']['effects'] == 1, 'original reverse effect')
        require(not row['duplicate']['callbackInvoked'] and row['duplicate']['reply'] == row['received']['reply'] and row['duplicate']['application'] == row['received']['application'], 'duplicate reverse delivery')
        require(row['reverse_finished']['same_original_wire'] and row['reverse_finished']['authenticated_browser_consumption'], 'native reverse outbox unconfirmed')
        frames = state['peer_records'][key]
        control = [v for v in frames if v['kind'] == 4]
        application = [v for v in frames if v['kind'] == 3]
        require(len(control) >= 2 and control[0]['trigger'] and control[0]['request_sha256'] == control[1]['request_sha256'], 'changed pending control replay')
        require(len(application) == 3 and application[0]['trigger'] and application[0]['request_sha256'] == application[1]['request_sha256'] != application[2]['request_sha256'], 'changed original ciphertext or reused new ciphertext')
        fault = row['ordinary_fault']
        require(fault['request_tag'] == 2 and fault['trigger'] and fault['dispatched'] == (case == 'applied'), 'wrong original write cut')
        census[case] = {'worker_calls': len(selected), 'worker_terminations': 2, 'query_cancellations': 1, 'native_effects': 2, 'epoch': 1, 'independent_completion': pending['controller_invoked']}
    require(sum(v['worker_calls'] for v in census.values()) == len(state['observations']), 'extra Worker calls')
    return census
