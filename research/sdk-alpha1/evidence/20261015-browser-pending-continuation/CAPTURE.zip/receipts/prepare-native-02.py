from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
fixture = stage / 'native-fixture-02'
fixture.mkdir()
inputs = {
    'src/bin/seed.rs': root / 'target/continuity-browser-policy-sessions/authority/src/main.rs',
    'src/bin/peer.rs': root / 'target/continuity-browser-policy-sessions/native-peer-v2/src/main.rs',
    'src/bin/issuer.rs': root / 'target/continuity-browser-policy-adoption/issuer/src/main.rs',
    'src/bin/witness.rs': root / 'target/continuity-browser-pending-recovery/fixture-03/src/bin/qpc-fanout-witness.rs',
    'src/bin/pending/control.rs': root / 'target/continuity-browser-pending-recovery/fixture-03/src/bin/pending/control.rs',
    'src/bin/pending/inspect.rs': stage / 'inspect_pending.rs',
}
for name, path in inputs.items():
    sdk.copy(path, fixture / name)
path = fixture / 'src/bin/witness.rs'
text = path.read_text()
old = '#[path = "retirement/control.rs"]\nmod retirement;'
sdk.require(text.count(old) == 1, 'witness module boundary')
text = text.replace(old, '#[path = "pending/inspect.rs"]\nmod inspection;')
old = '''        "retire-device" | "retain-inventory" | "retain-report" | "ack-report" => {
            retirement::run(mode, dir, &cfg, &args, now)?
        }'''
sdk.require(text.count(old) == 1, 'witness mode boundary')
text = text.replace(old, '        "inspect-pending" => inspection::run(&cfg, &args)?,')
path.write_text(text)
manifest = (root / 'target/continuity-browser-policy-sessions/authority/Cargo.toml').read_text()
manifest = manifest.replace('q-periapt-browser-policy-session-authority', 'q-periapt-browser-pending-continuation-fixture')
manifest = manifest.replace('getrandom = "0.4"', 'getrandom = "=0.4.3"').replace('zeroize = "1"', 'zeroize = "=1.9.0"')
with (fixture / 'Cargo.toml').open('x') as stream:
    stream.write(manifest)
sdk.write_json(stage / 'NATIVE_SOURCE_02.json', {'fixture': str(fixture),
    'copied_inputs': {name: {'path': str(path), 'sha256': sdk.snapshot(path).sha256} for name, path in inputs.items()},
    'files': {str(path.relative_to(fixture)): sdk.snapshot(path).sha256 for path in fixture.rglob('*') if path.is_file()},
    'purpose': 'fresh browser pending roster recovery and bilateral policy continuation; no old runtime reopened'})
print('Fresh four-program native fixture prepared from existing approved flows and a public-only exact-delta inspector')
