from pathlib import Path
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
bootstrap=str(root/'artifact/python_bootstrap.py')
sdk.command([sys.executable,'-B',bootstrap,str(stage/'test_public_review.py')],stage/'public-controls-09',root)
sdk.command([sys.executable,'-B',bootstrap,str(stage/'inspect-controls-11.py')],stage/'inspector-driver-11',root)
print('Public behavior reader and independent approval inspector controls passed')
