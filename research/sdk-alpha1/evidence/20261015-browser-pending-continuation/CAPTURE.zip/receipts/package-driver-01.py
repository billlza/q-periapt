from pathlib import Path
import json
import subprocess
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
clone = root / 'target/continuity-browser-publication/source'
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'main source not clean')
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone), 'package clone not clean')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
sdk.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == head, 'package clone source differs')
source = clone / 'target/browser-pending-recovery-build.py'
helper = clone / 'target/browser-pending-continuation-build-01.py'
sdk.copy(source, helper)
sdk.write_json(stage / 'PACKAGE_SOURCE_01.json', {'source_commit': head, 'clone': str(clone),
    'helper_sha256': sdk.snapshot(helper).sha256, 'build_script_sha256': sdk.snapshot(stage / 'build-package-01.sh').sha256,
    'output': str(clone / 'target/browser-pending-continuation-package-01'), 'browser_runtime': 'not-run'})
sdk.command(['/bin/sh', str(stage / 'build-package-01.sh')], stage / 'package-01', root)
record = json.loads((clone / 'target/browser-pending-continuation-package-01/INSTALLED_CONSUMER.json').read_text())
sdk.require(record['installed_node_tests'] == 'passed' and record['sources_unchanged'] and record['source_bound'], 'package consumption incomplete')
sdk.require(record['browser_runtime'] == 'not-run', 'package builder must not claim browser execution')
sdk.write_json(stage / 'PACKAGE_01.json', record)
print('Current-source browser archive built and installed; actual browser runtime remains a separate step')
