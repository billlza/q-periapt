//! Read-only control-plane check against independently retained public inputs.
use super::*;

fn roster_metadata(peer: &Value, roster: &Value) -> Result<Vec<u8>> {
    let family = array(peer, "family")?;
    let checkpoint = p::RosterCheckpoint::from_trusted_state(number(roster, "version")?, array(roster, "digest")?)?;
    let root = p::PublicKey::decode(&bytes(peer, "root")?)?;
    let pin = p::AccountPin::new(array(peer, "account")?, root.clone(), checkpoint, family)?;
    let device = pin.verify_historical_device(&bytes(peer, "certificate")?, &bytes(roster, "roster")?)?;
    let wire = bytes(roster, "roster")?;
    let mut public = b"QPROWR01".to_vec();
    public.extend_from_slice(&array(peer, "account")?);
    public.extend_from_slice(&family);
    public.extend_from_slice(&checkpoint.version().to_be_bytes());
    public.extend_from_slice(&checkpoint.digest());
    public.extend_from_slice(&root.encode());
    public.extend_from_slice(&u32::try_from(wire.len())?.to_be_bytes());
    public.extend_from_slice(&wire);
    let mut history = b"QPRHST01".to_vec();
    history.extend_from_slice(&u32::try_from(public.len())?.to_be_bytes());
    history.extend_from_slice(&public);
    history.extend_from_slice(&1u16.to_be_bytes());
    history.extend_from_slice(&device.device_id());
    history.extend_from_slice(&device.generation().to_be_bytes());
    history.extend_from_slice(&device.credential_digest());
    Ok(history)
}

pub(super) fn run(cfg: &Value, args: &[String]) -> Result<()> {
    if args.len() != 10 { return Err("inspect-pending directory proposal metadata peer target session message output".into()); }
    let bounded = |name: &str, limit: u64| -> Result<Vec<u8>> {
        let mut value = Vec::new();
        fs::File::open(name)?.take(limit + 1).read_to_end(&mut value)?;
        if value.len() as u64 > limit { return Err("public inspection input bound".into()); }
        Ok(value)
    };
    let proposal = p::AnchorPendingWriteRecoveryProposal::from_trusted_state(&bounded(&args[3], 393)?)?;
    let metadata = bounded(&args[4], 8388608)?;
    let peer = load(Path::new(&args[5]))?;
    let target = load(Path::new(&args[6]))?;
    if array(&peer, "account")? != array(&target, "account")? || bytes(&peer, "root")? != bytes(&target, "root")?
        || array(&peer, "family")? != array(&target, "family")? || number(&peer, "version")? != 1 || number(&target, "version")? != 2 {
        return Err("independent remote roster scope differs".into());
    }
    let session: [u8; 32] = bounded(&args[7], 32)?.try_into().map_err(|_| "session width")?;
    let message = p::MessageId::from_trusted_state(bounded(&args[8], 32)?.try_into().map_err(|_| "message width")?)?;
    let before = roster_metadata(&peer, &peer)?;
    let after = roster_metadata(&peer, &target)?;
    let old_checkpoint = p::RosterCheckpoint::from_trusted_state(number(&peer, "version")?, array(&peer, "digest")?)?;
    let new_checkpoint = p::RosterCheckpoint::from_trusted_state(number(&target, "version")?, array(&target, "digest")?)?;
    let view = proposal.inspect_metadata(&metadata)?;
    let source = view.source();
    let destination = view.target();
    if source.local_account != array(cfg, "account")? || source.local_account != destination.local_account
        || source.next_fanout_ordinal != destination.next_fanout_ordinal || source.records.len() != destination.records.len() {
        return Err("original local account or complete record census changed".into());
    }
    let mut roster_changes = 0;
    let mut unconfirmed = 0;
    for (old, actual) in source.records.iter().zip(&destination.records) {
        let mut expected = old.clone();
        if let p::retired_device::RecordMetadata::Roster { account, checkpoint, public_history } = &mut expected.metadata {
            if *account == array(&peer, "account")? {
                if *checkpoint != old_checkpoint || *public_history != before || expected.context != old_checkpoint.digest() {
                    return Err("original remote roster differs from retained issuer inputs".into());
                }
                expected.context = new_checkpoint.digest();
                *checkpoint = new_checkpoint;
                *public_history = after.clone();
                roster_changes += 1;
            }
        }
        if &expected != actual { return Err("pending write changes more than the independently approved roster".into()); }
        if let p::retired_device::RecordMetadata::Session(value) = &old.metadata {
            if value.session == session {
                let p::retired_device::SessionState::Live { epochs, .. } = &value.state else { return Err("original session not live".into()); };
                unconfirmed += epochs.iter().flat_map(|epoch| &epoch.accounting.unconfirmed).filter(|entry| entry.message_id() == message).count();
            }
        }
    }
    if roster_changes != 1 || unconfirmed != 1 { return Err("roster update or original unknown-message census differs".into()); }
    publish_private_bytes(Path::new(&args[9]), &serde_json::to_vec_pretty(&json!({
        "verified": true, "roster_changes": roster_changes, "original_unconfirmed_messages": unconfirmed,
        "proposal_binding": proposal.binding(), "local_account": source.local_account,
        "session": session, "message": message.as_bytes(), "mutated_witness": false
    }))?)?;
    println!("exact ordinary R1-to-R2 delta and original unknown message verified from public inputs");
    Ok(())
}
