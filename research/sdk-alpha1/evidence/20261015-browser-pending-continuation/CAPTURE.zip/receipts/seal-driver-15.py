from pathlib import Path
import sys
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
bootstrap=str(root/'artifact/python_bootstrap.py')
sdk.command([sys.executable,'-B',bootstrap,str(stage/'capture-10.py')],stage/'capture-15',root)
sdk.command([sys.executable,'-B',bootstrap,str(stage/'document-12.py')],stage/'document-15',root)
print('Browser checkpoint archive and current admission documentation complete')
