from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
output=root/'research/sdk-alpha1/evidence/20261015-browser-pending-continuation'
capture=json.loads((output/'CAPTURE.json').read_text());readback=json.loads((output/'READBACK.json').read_text())
sdk.require(readback['completed'] and readback['archive_sha256']==capture['archive_sha256'],'public readback incomplete')
readme=f'''# Installed browser pending recovery through renewed traffic

The current-source npm archive completed two fresh Chrome Worker flows through
the installed web entry and real IndexedDB storage. Both retain one original
session, an unacknowledged application message and a partially completed rekey
before an ordinary remote-roster R1-to-R2 write loses its result. The roster keeps
the existing peer as an authorized member; this is a nonterminal update, not a
request to resume a deliberately closed session.

| Original R2 outcome | Worker calls | Actual Worker terminations | Held Query cancellation | Independent completion |
| --- | --- | --- | --- | --- |
| Not dispatched to witness | {capture['case_census']['unapplied']['worker_calls']} | 2 | 1 | Exact original target approved and completed |
| Applied; reply lost | {capture['case_census']['applied']['worker_calls']} | 2 | 1 | None; fresh authenticated Query suffices |

P0 expires by real wall clock before recovery; credentials remain valid. Public
recovery requests create no operational runtime and send no network request.
Complete original proposal and metadata survive a cancelled held Query and Worker
termination before confirmation. A second termination occurs after local
confirmation but before the host receives success. The root lease is observed
before each termination and its release is observed before reopening. Exact
confirmation retries remain Query-only; absence alone is refused. Modified
metadata is rejected before network access, and an unapplied target cannot be
confirmed before the independent controller completes it.

The controller's separate inspector verifies signed public R1/R2 material using
independently retained account and device inputs. It compares every source and
target record, allowing exactly one remote-roster change while retaining the
original live session, unknown message and pending rekey. Its approval is distinct
from the historical device signature. The ordinary HTTP endpoint never invokes
privileged completion. Five substituted public inputs are refused by the same
inspector without opening a private runtime or publishing an approval.

After recovery, independent account and policy roots approve P1 against the
original enrollment request. Witness preparation, commitment and retirement
complete on the same journal. The native counterpart separately renews its own
authority. Old direct session reopening is refused; the explicit continuation
path retains the original pending rekey and message. Both flows finish epoch 1,
replay the identical first control frame and original application ciphertext,
confirm the existing receiver effect, and complete the original reverse-direction
message. A duplicate reverse frame invokes no second application callback. A new
message has a distinct ID and ciphertext, reaches confirmed consumption and leaves
exactly two native effects: the original message and the new message. Confirmation
of the old pending-write target conflicts after the policy operation advances the
head.

Source is `{capture['source_commit']}`. The same actual archive was built and
installed outside the checkout; installed Node and strict TypeScript checks
passed before browser execution. Fresh native fixtures use the current canonical
dependency versions and strict warning-as-error compilation. Initial lockfile
generation selected seven newer transitive dependencies and was rejected before
compilation; using the existing lockfile with Cargo metadata retained the canonical
versions. Both rejected preparation lockfiles are preserved. No SDK implementation,
protocol, storage grammar or security policy changed in this checkpoint.

| Artifact | SHA-256 |
| --- | --- |
| Installed npm archive | `{capture['installed_package_sha256']}` |
| Public capture | `{capture['archive_sha256']}` |

`CAPTURE.zip` contains {capture['members']} public members, including executed
fixtures, public inputs, command receipts and all {capture['worker_calls']} Worker
results. Independent readback checks every member hash and the complete behavior
census. Public-reader controls reject every individual call substitution, a
claimed second approval on the applied route, missing termination, changed replay
ciphertext and extra business effects. Private identities, keys, browser profiles,
runtime stores and compiler outputs are excluded. The browser session and fixture
server are closed; these runtime cohorts are sealed and must not be reopened.

The older [pending recovery checkpoint](../20261014-browser-pending-write-recovery/README.md)
intentionally finishes by closing sessions and accounting for loss. This checkpoint
adds a separate nonterminal path to actual continued traffic. It uses the same Rust
engine on both sides and a loopback carrier. It does not establish independent
implementation interoperability, mobile-browser qualification, deployed HTTPS,
physical power-loss durability or post-compromise secrecy. Protocol recovery
analysis, remaining lifecycle/platform composition, Linux/independent endpoints,
performance/energy/tail and peak-memory costs, maintenance/freeze, external review
and exact-source hosted checks remain 0.2.0 release gates. The single accepted
Android phone remains sufficient for its recorded scope; no Intel Mac requirement
is introduced.
'''
with (output/'README.md').open('x') as stream:stream.write(readme)

def replace_file(path,old,new):
    text=path.read_text();sdk.require(text.count(old)==1,'document boundary '+str(path));path.write_text(text.replace(old,new))
replace_file(root/'research/continuity-identity-candidate/README.md',
'''permission; foreign native bindings and broader platform qualification remain open.''',
'''permission. C/Swift/Kotlin and configured Android expose the same contract.
[Physical Swift continuation](../sdk-alpha1/evidence/20261015-apple-pending-continuation/README.md)
and [installed browser continuation](../sdk-alpha1/evidence/20261015-browser-pending-continuation/README.md)
now compose exact recovery with independently approved renewal and original-session
traffic. Broader lifecycle and platform qualification remain open.''')
replace_file(root/'research/continuity-identity-candidate/README.md',
'''implemented; browser bindings and bounded network-carrier qualification remain
separate work. It does not replace the TLS-bound carrier or establish PCS.''',
'''implemented, including the installed browser peer transport and
[session/rekey qualification](../sdk-alpha1/evidence/20261013-browser-session-rekey/README.md).
Deployed carriers and complete platform qualification retain separate gates.
This does not replace the TLS-bound carrier or establish PCS.''')
replace_file(root/'research/continuity-identity-candidate/README.md',
'''witnessed activation and original public prekey recovery. Signed prekey
publication, complete session/root/roster lifecycle,
peer transport, HTTPS deployment and installed browser packaging remain
integration work. The prototype''',
'''witnessed activation, signed prekey publication, peer transport and installed
session/rekey and renewal flows. The current
[admission matrix](../../docs/continuity/PRODUCT_ADMISSION.md) distinguishes those
qualified paths from complete lifecycle, managed account-root cutover, mobile
browser and deployed HTTPS requirements. The prototype''')
replace_file(root/'docs/continuity/PRODUCT_ADMISSION.md',
'''Broader interruption/concurrency and authority lifecycle; browser permanent retirement and composed renewal-to-cleanup recovery''',
'''Broader interruption/concurrency and deployed authority lifecycle; browser permanent retirement and composed renewal-to-cleanup have separate installed checkpoints, while complete lifecycle qualification remains open''')
replace_file(root/'docs/continuity/PRODUCT_ADMISSION.md',
'''confirms that an unapplied ordinary intent can block both the renewal request and
preparation of an independently approved G/T after witness expiry. An already-applied
target with a lost reply reconciles. Independent replacement and permanent retired
accounting are a separate exit path, now exposed by the browser owner; they do not
provide in-place renewal or managed account-root cutover. Atomic persistence,''',
'''records the original failure: an unapplied ordinary intent blocks renewal after
witness expiry, while an already-applied target with a lost reply reconciles.
The subsequent [exact pending-write recovery](../../research/sdk-alpha1/evidence/20261014-browser-pending-write-recovery/README.md)
adds independently approved completion followed by historical confirmation, G/T
renewal and original loss accounting. The separate
[browser continuation checkpoint](../../research/sdk-alpha1/evidence/20261015-browser-pending-continuation/README.md)
uses a nonterminal R2 update and composes that recovery with bilateral P1 renewal,
the original pending rekey and actual original/new message consumption. Recovery
alone grants no traffic authority. Independent replacement and permanent retired
accounting remain a separate exit, and managed account-root cutover retains its
own gate. Atomic persistence,''')
path=root/'research/continuity-identity-candidate/PENDING_WRITE_RECOVERY.md'
with path.open('a') as stream:stream.write('''

The [installed browser continuation checkpoint](../sdk-alpha1/evidence/20261015-browser-pending-continuation/README.md)
uses a nonterminal remote R2 write with an original unknown message and pending
rekey. It preserves exact recovery across actual expiry, held-Query cancellation
and Worker loss before/after confirmation, then independently renews both peers'
policy authority. Identical original control/ciphertext replay, authenticated
consumption and distinct new traffic complete on the original session. An applied
target needs only a fresh Query; an unapplied target needs independent exact
completion. This is separate from the older intentionally closed-session cleanup
trace and does not establish PCS or complete platform admission.
''')
with (root/'docs/SDK_0_2_RELEASE_READINESS.md').open('a') as stream:stream.write(f'''

### Installed browser recovery through renewed traffic — 2026-10-15

The [public checkpoint](../research/sdk-alpha1/evidence/20261015-browser-pending-continuation/README.md)
binds the installed npm archive `{capture['installed_package_sha256']}` to source
`{capture['source_commit']}`. Two fresh flows execute {capture['worker_calls']} Workers,
four actual Worker terminations and two held-Query cancellations. A nonterminal
remote R2 write remains bound to the original live session, unknown message and
pending rekey across real policy expiry. The unapplied route uses independent
exact completion; the applied route uses only Query confirmation. Bilateral P1
renewal then permits original control/ciphertext replay, epoch 1 completion,
bidirectional consumption and a distinct fresh message, with exactly two native
effects per route. Public-only readback and substitution controls validate the
complete behavior census. No product implementation changed. This adds actual
traffic after recovery; it does not close PCS, independent/Linux endpoints,
remaining lifecycle/platform admission, resource-cost, maintenance/freeze,
external-review or hosted exact-source gates.
''')
print('Current admission summaries updated while retaining the older failure and closure traces')
