from pathlib import Path
import json
import os
import tomllib
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
fixture = stage / 'native-fixture-05'
toolchain = root / 'target/continuity-browser-credential-renewal/rustup/toolchains/1.98.1-aarch64-apple-darwin/bin'
environment = dict(os.environ)
environment.update(CARGO_HOME='/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/apple-cargo-home-ff4a153e', CARGO_NET_OFFLINE='true', RUSTFLAGS='-D warnings', CARGO_TARGET_DIR=str(stage / 'native-target-05'), PATH=str(toolchain) + ':' + environment['PATH'])
cargo = str(toolchain / 'cargo')
sdk.command([cargo, 'fmt', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'native-format-05', root, environment=environment)
sdk.command([cargo, 'metadata', '--format-version', '1', '--offline', '--manifest-path', str(fixture / 'Cargo.toml')], stage / 'native-lock-05', root, environment=environment)
def registry(path):
    return {(p['name'], p['version'], p.get('checksum')) for p in tomllib.loads(path.read_text())['package'] if 'source' in p}
allowed = registry(root / 'Cargo.lock') | registry(root / 'research/continuity-identity-candidate/Cargo.lock')
actual = registry(fixture / 'Cargo.lock')
sdk.require(actual <= allowed, 'fixture dependency drift: ' + repr(actual - allowed))
sources = {str(p.relative_to(fixture)): sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()}
sdk.write_json(stage / 'NATIVE_SOURCE_05.json', {'files': sources, 'dependency_census': sorted(actual), 'registry_subset_of_current_locks': True})
sdk.command([cargo, 'build', '--locked', '--offline', '--manifest-path', str(fixture / 'Cargo.toml'), '--bins'], stage / 'native-build-05', root, environment=environment)
sdk.require(sources == {str(p.relative_to(fixture)): sdk.snapshot(p).sha256 for p in fixture.rglob('*') if p.is_file()}, 'native sources changed during build')
sdk.write_json(stage / 'NATIVE_BUILD_05.json', {'files': sources, 'binaries': {name: {'path': str(stage / 'native-target-05/debug' / name), 'sha256': sdk.snapshot(stage / 'native-target-05/debug' / name, maximum=256*1024*1024).sha256} for name in ['seed', 'peer', 'issuer', 'witness']}})
print('Fresh native fixture build complete with canonical dependency census')
