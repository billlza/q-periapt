from pathlib import Path
import json
import os
import copy
from bounded_process import capture_output
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;run=stage/'harness-06/run-08'
state=json.loads((run/'RESULT.json').read_text());sdk.require(state['completed'],'runtime cohort incomplete')
out=stage/'inspection-controls-11';out.mkdir(mode=0o700)
binary=stage/'native-target-05/debug/witness'
sdk.require(sdk.snapshot(binary,maximum=256*1024**2).sha256==state['native'][str(binary)],'inspector changed')
inputs=stage/'harness-06/run-08-web/inputs';source=run/'accounting/unapplied'
public=out/'public';public.mkdir(mode=0o700)
for src,name in [(inputs/'run-08-unapplied.json','PUBLIC.json'),(inputs/'run-08-unapplied-peer.json','peer.json'),(inputs/'run-08-unapplied-r2.json','target.json')]:sdk.copy(src,public/name)
for name in ['proposal.bin','metadata.bin','session.bin','message.bin']:sdk.copy(source/name,public/name)
defaults=['proposal.bin','metadata.bin','peer.json','target.json','session.bin','message.bin']
cases={'valid':{},'wrong-message':{5:'wrong-message.bin'},'wrong-session':{4:'wrong-session.bin'},'changed-metadata':{1:'changed-metadata.bin'},'wrong-target-version':{3:'wrong-target.json'},'changed-roster-signature':{3:'changed-roster.json'}}
for original,name in [('message.bin','wrong-message.bin'),('session.bin','wrong-session.bin'),('metadata.bin','changed-metadata.bin')]:
    data=bytearray((public/original).read_bytes());data[-1]^=1
    with (public/name).open('xb') as f:f.write(data)
target=json.loads((public/'target.json').read_text())
wrong=copy.deepcopy(target);wrong['version']=1;sdk.write_json(public/'wrong-target.json',wrong)
wrong=copy.deepcopy(target);wrong['roster'][-1]^=1;sdk.write_json(public/'changed-roster.json',wrong)
before={p.name:sdk.snapshot(p).sha256 for p in public.iterdir()}
records=[]
for name,changes in cases.items():
    args=[str(public/changes.get(i,path)) for i,path in enumerate(defaults)]
    result_path=out/(name+'-review.json')
    argv=[str(binary),'inspect-pending',str(public),*args,str(result_path)]
    result=capture_output(argv,timeout_seconds=20,maximum_stdout_bytes=1024*1024,maximum_stderr_bytes=1024*1024,environment=dict(os.environ))
    for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        with (out/(name+'.'+suffix)).open('xb') as f:f.write(data)
    sdk.require((result.returncode==0)==(name=='valid'),'unexpected exact-delta control result: '+name)
    sdk.require(result_path.exists()==(name=='valid'),'refused inspection published approval')
    row={'name':name,'argv':argv,'returncode':result.returncode,'approval_published':result_path.exists()};sdk.write_json(out/(name+'.json'),row);records.append(row)
sdk.require(before=={p.name:sdk.snapshot(p).sha256 for p in public.iterdir()},'public inspector modified inputs')
sdk.write_json(out/'RESULT.json',{'completed':True,'controls':records,'inputs_unchanged':True,'private_runtime_accessed':False})
print('Exact-delta inspector accepted the original public view and rejected all five substitutions without runtime access')
