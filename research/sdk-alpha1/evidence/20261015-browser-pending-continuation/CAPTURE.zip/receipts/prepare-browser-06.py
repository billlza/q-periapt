from pathlib import Path
import ast
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
output = stage / 'harness-06'
output.mkdir()
policy = root / 'target/continuity-browser-policy-sessions'
pending = root / 'target/continuity-browser-pending-recovery/harness07'
def replace(text, old, new):
    sdk.require(text.count(old) == 1, 'unique preparation boundary: ' + old[:80])
    return text.replace(old, new)
worker = (policy / 'worker-expiry.js').read_text()
worker = replace(worker, " if(data.cancel){check(owner,'cancel owner');closePending=owner.close();postMessage({cancellation_requested:true});return;}", """ if(data.controlClose){
  try{check(owner,'cancel owner');closePending=owner.close();await closePending;postMessage({closeComplete:true,closed:owner.is_closed()});}
  catch(error){postMessage({closeComplete:true,error:String(error),code:error?.code});}
  return;
 }""")
worker = replace(worker, "(data.mode??'normal'),location.origin)", "(data.mode??'normal')+'&cut='+(data.cut??'0'),location.origin)")
worker = replace(worker, "   if(data.action==='session') {", """   if(data.action.startsWith('pending-')) {
    check(runtime===undefined,'pending recovery constructed an operational runtime');
    if(data.action==='pending-request'){
     const r=own(await owner.pending_write_recovery_request(history,witness));
     value={proposal:[...r.proposal()],binding:[...r.binding()],metadata:[...r.metadata()],signed:[...r.signed_request()],document:r.to_json()};
    }else if(data.action==='pending-confirm'){
     await owner.confirm_pending_write_recovery(b(data.approved),b(data.metadata),history,witness);
     if(data.killAfterLocalConfirmation){postMessage({localConfirmationObserved:true});await new Promise(()=>{});}
     value={confirmed:true};
    }else throw Error('unknown pending action');
    value.runtimeCreated=false;value.observedAt=Number(at);
   }else if(data.action==='session') {""")
# Record cleanup failures explicitly, keeping original error code available.
worker = replace(worker, " const owned=[],own=v=>{owned.push(v);return v};let value,failure;const observations=[];", " const owned=[],own=v=>{owned.push(v);return v};let value,failure;const observations=[],cleanupErrors=[];")
old = """ try{if(closePending)await closePending;if(owner)await owner.close();}catch(error){failure=new AggregateError(failure?[failure,error]:[error],'operation/cleanup failed')}
 if(owner){check(owner.is_closed(),'owner close missing');owner.free();owner=undefined}closePending=undefined;
 for(const object of owned.reverse()){if(typeof object.close==='function')object.close();object.free()}
 postMessage(failure?{done:true,error:String(failure),code:failure.code,ownerClosed:failure.ownerClosed,observations}:{done:true,value,observations});"""
new = """ try{if(closePending)await closePending;if(owner)await owner.close();}catch(error){cleanupErrors.push(String(error));}
 if(owner){try{check(owner.is_closed(),'owner close missing');owner.free();}catch(error){cleanupErrors.push(String(error));}owner=undefined;}closePending=undefined;
 for(const object of owned.reverse()){
  try{if(typeof object.close==='function')await object.close();}catch(error){cleanupErrors.push(String(error));}
  try{object.free();}catch(error){cleanupErrors.push(String(error));}
 }
 postMessage(failure||cleanupErrors.length?{done:true,error:String(failure??'cleanup failure'),code:failure?.code,ownerClosed:failure?.ownerClosed,observations,cleanupErrors}:{done:true,value,observations,cleanupErrors});"""
worker = replace(worker, old, new)
helper = (policy / 'session-checks.js').read_text()
helper = replace(helper, "  const selected=bytes(data.session);if(data.wrongSession)selected[0]^=1;", """  if(action==='peer-roster') {
   const response=await fetch('/inputs/'+data.targetFile);check(response.ok,'independent target roster');const target=await response.json();
   const trust=own(new Account(bytes(peerConfig.account),bytes(peerConfig.root),BigInt(target.version),bytes(target.digest),bytes(config.family)));
   const checkpoint=own(await owner.admit_peer_roster(bytes(target.roster),trust,policy,now()));
   return {version:String(checkpoint.version()),digest:[...checkpoint.digest()]};
  }
  const selected=bytes(data.session);if(data.wrongSession)selected[0]^=1;""")
server = (pending / 'server.py').read_text()
policy_server = (policy / 'server.py').read_text()
start = policy_server.index('        def peer(')
end = policy_server.index('        def do_POST(', start)
first = server.index('        def peer(')
last = server.index('        def do_POST(', first)
server = server[:first] + policy_server[start:end] + server[last:]
server = replace(server, '    peers, peer_faulted = {}, set()', '    peers, peer_faulted = {}, set()\n    ready_proofs, control_receipts = {}, {}')
server = replace(server, "peer = re.fullmatch(r'/peer/([a-z0-9-]+)/([01])', target.path)", "peer = re.fullmatch(r'/peer/([a-z0-9-]+)', target.path)")
server = replace(server, "self.peer(peer[1], int(peer[2]), modes['mode'][0], data)", "self.peer(peer[1], modes['mode'][0], data)")
ast.parse(server)
for name, text in [('worker.js',worker), ('session-checks.js',helper), ('server.py',server), ('controller.js',(pending/'controller.js').read_text())]:
    with (output/name).open('x') as stream: stream.write(text)
sdk.write_json(stage/'BROWSER_SOURCE_06.json', {'files': {str(p.relative_to(output)): sdk.snapshot(p).sha256 for p in output.iterdir()}})
print('Fresh browser fixture prepared; no runtime state opened')
