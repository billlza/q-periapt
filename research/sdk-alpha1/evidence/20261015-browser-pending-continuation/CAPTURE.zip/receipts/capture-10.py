from pathlib import Path
import hashlib
import json
import sys
import tempfile
import zipfile
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(stage))
from public_review import verify
sys.path.insert(0,str(root/'target/continuity-apple-pending-continuation/attempt-12'))
from public_capture_check import contains_private_pem
run=stage/'harness-06/run-08';state=json.loads((run/'RESULT.json').read_text());census=verify(state)
sdk.require(json.loads((stage/'run-08.json').read_text())['returncode']==0,'outer producer incomplete')
sdk.require(json.loads((stage/'public-controls-09.json').read_text())['returncode']==0,'public controls incomplete')
sdk.require(json.loads((stage/'inspection-controls-11/RESULT.json').read_text())['completed'],'independent inspection controls incomplete')
package=json.loads((stage/'PACKAGE_01.json').read_text())
sdk.require(package['installed_node_tests']=='passed' and package['source_bound'] and package['sources_unchanged'],'installed consumer incomplete')
sdk.require(sdk.snapshot(Path(package['archive'])).sha256==package['sha256'],'package archive changed')
for path,digest in {**state['native'],**state['producer']}.items():sdk.require(sdk.snapshot(Path(path),maximum=256*1024**2).sha256==digest,'consumed producer changed')
for name,digest in state['static_web'].items():sdk.require(sdk.snapshot(stage/'harness-06/run-08-web'/name).sha256==digest,'executed web package changed')
source=json.loads((stage/'PACKAGE_SOURCE_01.json').read_text())
entries={}
allowed={'.py','.sh','.rs','.js','.json','.stdout','.stderr','.md','.toml','.lock','.bin','.request','.reply'}
def add(path,name):
    sdk.require(name not in entries and not path.is_symlink(),'duplicate or symlink capture')
    entries[name]=sdk.snapshot(path,maximum=64*1024**2).data
def tree(base,prefix):
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix in allowed:
            relative=path.relative_to(base)
            sdk.require(not any(part in {'__pycache__','node_modules','.git','.playwright'} or part.endswith('-private') for part in relative.parts),'private or generated evidence selected')
            add(path,prefix+'/'+relative.as_posix())
for path in sorted(stage.iterdir()):
    if path.is_file() and path.suffix in allowed:add(path,'receipts/'+path.name)
for path in sorted((stage/'harness-06').iterdir()):
    if path.is_file() and path.suffix in allowed:add(path,'harness/'+path.name)
tree(run,'run')
tree(stage/'harness-06/run-08-web/inputs','public-inputs')
tree(stage/'inspection-controls-11','inspection-controls')
for name in ['Cargo.toml','Cargo.lock']:add(stage/'native-fixture-05'/name,'native/'+name)
tree(stage/'native-fixture-05/src','native/src')
for attempt in ['02','04']:
    tree(stage/('native-fixture-'+attempt),'preparation/native-'+attempt)
package_dir=Path(package['archive']).parent
for path in package_dir.iterdir():
    if path.is_file() and path.suffix in {'.json','.stdout','.stderr'}:add(path,'package/'+path.name)
add(root/'target/continuity-apple-pending-continuation/attempt-12/public_capture_check.py','recipes/public_capture_check.py')
for name,payload in entries.items():
    sdk.require(not any(part.endswith('-private') or part.endswith('.redb') or part.endswith('.key') for part in Path(name).parts),'private path selected')
    if not name.endswith(('.py','.sh','.rs','.js','.toml','.lock')):sdk.require(not contains_private_pem(name,payload),'private PEM data selected')
output=root/'research/sdk-alpha1/evidence/20261015-browser-pending-continuation';output.mkdir()
archive=output/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for name,payload in sorted(entries.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        bundle.writestr(info,payload)
manifest={'source_commit':source['source_commit'],'archive_sha256':sdk.snapshot(archive,maximum=128*1024**2).sha256,
    'members':len(entries),'files':{name:hashlib.sha256(payload).hexdigest() for name,payload in sorted(entries.items())},
    'installed_package_sha256':package['sha256'],'case_census':census,'worker_calls':sum(v['worker_calls'] for v in census.values()),
    'worker_terminations':4,'query_cancellations':2,'sdk_implementation_changed':False,'release_claim_eligible':False,
    'scope':'Actual installed Chrome Workers and IndexedDB; independent native controller with the same Rust implementation on loopback',
    'excluded':'Private identities, keys, runtime stores, browser profiles, caches and compiler outputs'}
sdk.write_json(output/'CAPTURE.json',manifest)
with zipfile.ZipFile(archive) as bundle:
    sdk.require(len(bundle.namelist())==len(entries) and set(bundle.namelist())==set(entries),'archive inventory mismatch')
    for name,digest in manifest['files'].items():sdk.require(hashlib.sha256(bundle.read(name)).hexdigest()==digest,'archive member changed')
    sdk.require(verify(json.loads(bundle.read('run/RESULT.json')))==census,'archive behavior reread differs')
sdk.write_json(output/'READBACK.json',{'completed':True,'archive_sha256':manifest['archive_sha256'],'members':len(entries),'case_census':census,'private_keys_excluded':True})
print(json.dumps({'completed':True,'archive_sha256':manifest['archive_sha256'],'members':len(entries),'case_census':census}))
