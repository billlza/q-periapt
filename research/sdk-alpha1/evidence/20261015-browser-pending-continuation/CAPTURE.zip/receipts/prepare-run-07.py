from pathlib import Path
import ast
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent;harness=stage/'harness-06'
source=root/'target/continuity-browser-policy-sessions/run-bilateral-v2.py'
text=source.read_text()
def change(old,new):
 global text
 sdk.require(text.count(old)==1,'unique driver boundary: '+old[:100]);text=text.replace(old,new)
change("root=Path.cwd();stage=root/'target/continuity-browser-policy-sessions';package=root/'target/continuity-browser-publication/source/target/policy-session-package-01'", "root=Path.cwd();stage=Path(__file__).resolve().parent;package=root/'target/continuity-browser-publication/source/target/browser-pending-continuation-package-01'")
change("stage/('worker-expiry.js' if name=='worker.js' else name)", "stage/name")
change("<title>Session continuity across original roster maintenance</title>", "<link rel=\"icon\" href=\"data:,\"><title>Pending recovery and original session continuation</title>")
start=text.index("binary=root/");end=text.index('\nstatic=',start)
text=text[:start]+"binary=stage.parent/'native-target-05/debug';authority=binary/'witness';provisioner=binary/'seed';roster=binary/'issuer';peer=binary/'peer'"+text[end:]
change("allowed={'bilateral','expired-bilateral'}", "allowed={'unapplied','applied'}")
change("'observations':value['result'].get('observations',[])", "'result':value['result']")
change("return value['result']", "sdk.require(value['result'].get('cleanupErrors',[])==[],'Worker cleanup failure');return value['result']")
change("['prepare-expiring-policy' if case=='expired-bilateral' else 'prepare',directory]", "['prepare-expiring-policy',directory]")
change("if case=='expired-bilateral':", "if case in allowed:")
change("==(case=='expired-bilateral')", "is True")
change("scope':'Actual installed browser independent P with original pending ciphertext/control replay, recovery and bidirectional traffic; same Rust implementation and loopback, not independent implementation/PCS/release'", "scope':'Installed browser exact ordinary pending R2 recovery across expiry, cancellation and Worker loss, bilateral P renewal, original ciphertext/control and bidirectional traffic; same Rust engine and loopback, not independent implementation/PCS/release'")
change("   for case in sys.argv[2:]:", """   for case in sys.argv[2:]:
    print(json.dumps({'case':case,'phase':'fresh enrollment'}),flush=True)""")
marker="    args['operationId']=success({**args,'action':'new-policy-operation','historicalOnly':True})['operation']"
change(marker, marker+"""
    target_file=inputs/(key+'-r2.json')
    native(peer,['peer-target',directory,2,'member',target_file],case+'-peer-r2')
    mode='drop-advance' if case=='applied' else 'drop-before-advance'
    row['ordinary_cut']=rejected({**args,'action':'session','sessionAction':'peer-roster','targetFile':target_file.name,'mode':mode,'cut':'1'},'WitnessTransport')
    fault=[r for r in witness_records[key] if r['mode']==mode and r['cut']=='1' and r['trigger']]
    sdk.require(len(fault)==1 and fault[0]['request_tag']==2 and fault[0]['dispatched']==(case=='applied'),'incorrect R2 write cut')
    row['ordinary_fault']=fault[0]
""")
marker="    request=success({**args,'action':'policy-request','historicalOnly':True});row['request']=request"
change(marker, """    row['pending_recovery']=recover_pending(args,case,directory,row,witness_records,inputs,out,authority)
"""+marker)
change("    args.update(continued=True,historicalOnly=True)", """    late=invoke({**args,'action':'pending-confirm','historicalOnly':True,'approved':row['pending_recovery']['proposal'],'metadata':row['pending_recovery']['metadata']})
    sdk.require(late.get('code')=='Conflict','advanced P head accepted stale pending-write confirmation')
    args.update(continued=True,historicalOnly=True)""")
change("    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;", "    fresh=success({**args,'action':'session','sessionAction':'new-message'})['message'];row['fresh_message']=fresh;sdk.require(fresh!=args['message'],'new work reused original message identity');")
change("    row['witness_records']=witness_records[key];", "    effects=list((directory/'peer/effects').iterdir());sdk.require(len(effects)==2,'new message did not create exactly one new effect');row['completed']=True;row['native_effects']=len(effects)\n    row['witness_records']=witness_records[key];")
change("except BaseException as error:state['failure']=repr(error);raise", "except BaseException as error:state['failure']=repr(error);raise")
change("finally:sdk.write_json(out/'RESULT.json',state)", "finally:\n state['witness_records']=witness_records if 'witness_records' in globals() else {};state['peer_records']=peer_records if 'peer_records' in globals() else {};state['fixture_failures']=failures if 'failures' in globals() else [];sdk.write_json(out/'RESULT.json',state)")
boundary='try:\n with serving('
sdk.require(text.count(boundary)==1,'driver try boundary')
functions='''
def recover_pending(args,case,directory,row,records,inputs,out,witness):
    base={**args,'historicalOnly':True}; observed=len(records[args['case']])
    pending=success({**base,'action':'pending-request'})
    repeated=success({**base,'action':'pending-request'})
    for field in ['proposal','metadata','document','binding']:sdk.require(pending[field]==repeated[field],'original retained input changed')
    sdk.require(not pending['runtimeCreated'] and pending['observedAt']>row['real_expiry']['policy_until'],'operational permission used during recovery')
    sdk.require(len(records[args['case']])==observed,'public pending request sent witness traffic')
    folder=out/'accounting'/case;folder.mkdir(parents=True,mode=0o700)
    def retain(name,value):
        path=folder/name
        with path.open('xb') as stream:stream.write(value);stream.flush();os.fsync(stream.fileno())
        fd=os.open(folder,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
        sdk.require(path.read_bytes()==value,'retained public input readback');return path
    proposal=retain('proposal.bin',bytes(pending['proposal']));metadata=retain('metadata.bin',bytes(pending['metadata']));signed=retain('signed.bin',bytes(pending['signed']))
    retain('inspection.json',pending['document'].encode());session=retain('session.bin',bytes(args['session']));message=retain('message.bin',bytes(args['message']))
    review=folder/'independent-review.json'
    native(witness,['inspect-pending',directory,proposal,metadata,inputs/(args['case']+'-peer.json'),inputs/(args['case']+'-r2.json'),session,message,review],case+'-inspect-pending')
    independent=json.loads(review.read_text());sdk.require(independent['verified'] and not independent['mutated_witness'] and independent['proposal_binding']==pending['binding'],'independent exact-delta review failed')
    confirm={**base,'action':'pending-confirm','approved':pending['proposal'],'metadata':pending['metadata']}
    if case=='unapplied':
        rejected(confirm,'Scope')
    damaged=list(pending['metadata']);damaged[-1]^=1;before=len(records[args['case']])
    rejected({**confirm,'metadata':damaged},'Authentication')
    sdk.require(len(records[args['case']])==before,'modified metadata reached witness')
    result={'proposal':pending['proposal'],'metadata':pending['metadata'],'binding':pending['binding'],'inspection':independent,'interruptions':[],'controller_invoked':False}
    if case=='unapplied':
        completion=folder/'controller.json'
        native(witness,['complete-pending-write',directory,proposal,metadata,signed,completion],case+'-complete-exact-pending')
        record=json.loads(completion.read_text());sdk.require(record['confirmed'] and record['proposal_binding']==pending['binding'] and record['at']>row['real_expiry']['policy_until'],'wrong independently completed intent')
        result['controller_invoked']=True;result['controller']=record
    before=len(records[args['case']])
    cancel=invoke({**confirm,'mode':'hold-query','cut':'10','cancelAfterQuery':True})
    sdk.require(cancel.get('code')=='Cancelled' and cancel.get('ownerClosed') is True and cancel.get('closeReceipt')=={'closeComplete':True,'closed':True},'held-query cancellation failed')
    result['interruptions'].append(cancel)
    for field in ['proposal','metadata']:sdk.require(success({**base,'action':'pending-request'})[field]==pending[field],'cancellation changed original intent')
    cut=invoke({**confirm,'mode':'hold-query','cut':'20','killAfterQuery':True})
    sdk.require(cut.get('workerTerminatedBeforeConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual pre-confirmation Worker termination')
    result['interruptions'].append(cut)
    retained=success({**base,'action':'pending-request'})
    sdk.require(retained['proposal']==pending['proposal'] and retained['metadata']==pending['metadata'],'Worker loss changed original intent')
    cut=invoke({**confirm,'killAfterLocalConfirmation':True})
    sdk.require(cut.get('workerTerminatedAfterConfirmation') is True and cut.get('rootHeldBefore')==1,'missing actual post-confirmation Worker termination')
    result['interruptions'].append(cut)
    rejected({**base,'action':'pending-request'},'Absent')
    for _ in range(2):sdk.require(success(confirm)['confirmed'],'exact repeated confirmation failed')
    tags=[r['request_tag'] for r in records[args['case']][before:]]
    sdk.require(tags==[1,1,1,1,1],'confirmation did not remain Query-only')
    result.update(confirmation_request_tags=tags,public_retained={p.name:sdk.snapshot(p).sha256 for p in folder.iterdir() if p.is_file()})
    print(json.dumps({'case':case,'phase':'original pending write recovered','controller_invoked':result['controller_invoked'],'worker_terminations':2}),flush=True)
    return result

'''
text=text.replace(boundary,functions+boundary)
change("state={'completed':False,", "producer={str(p):sdk.snapshot(p,maximum=256*1024*1024).sha256 for p in [node,cli,Path(__file__),stage/'worker.js',stage/'controller.js',stage/'session-checks.js',stage/'server.py']}\nstate={'completed':False,'release_claim_eligible':False,'producer':producer,")
change(" state['completed']=True", " for n,d in producer.items():sdk.require(sdk.snapshot(Path(n),maximum=256*1024*1024).sha256==d,'producer drift')\n state['producer_unchanged']=True;state['completed']=True")
ast.parse(text)
with (harness/'run-07.py').open('x') as stream:stream.write(text)
sdk.write_json(stage/'RUN_SOURCE_07.json',{'driver_sha256':sdk.snapshot(harness/'run-07.py').sha256,'base_driver_sha256':sdk.snapshot(source).sha256})
print('Composed browser driver prepared; no sealed runtime cohort reopened')
