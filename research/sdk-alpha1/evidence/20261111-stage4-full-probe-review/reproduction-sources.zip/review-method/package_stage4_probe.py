"""Read-only verification and packaging of the terminated original Stage4 probe.

This script invokes only git show/ls-tree for immutable source retrieval. It
never invokes CodeQL, changes the query pack, or starts evaluation or compilation.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import json
import re
import stat
import subprocess
import zipfile

W = Path('/workspace/scratch/4b61438fb07b')
ROOT = W / 'codeql-projection-full-probe'
E = ROOT / 'evidence'
PACK = ROOT / 'query-pack'
REPO = W / 'q-periapt'
OUT = W / 'stage4-probe-review-20261111'
COMMIT = '443f05fa4da60093f57b6f529fccf19c17373300'
SPEC_COMMIT = '11ba16eb257c4d68ed967fa554d9a36b362848b0'
PROTOTYPE = W / 'summary-plan-feasibility/review-packet'
FULL = 'queries/summary/SummaryStats.ql'
STARTED = datetime.now(timezone.utc).isoformat()

def require(value, label):
    if not value:
        raise ValueError(label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def identity(data):
    return {'bytes': len(data), 'sha256': sha(data)}

def snapshot(path):
    for component in (path, *path.parents):
        require(not component.is_symlink(), 'symlink: ' + str(component))
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), 'nonregular: ' + str(path))
    data = path.read_bytes()
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
            'file changed while reading: ' + str(path))
    require(len(data) == after.st_size, 'read size: ' + str(path))
    return data

def git(path, commit=COMMIT):
    return subprocess.check_output(['git', 'show', commit + ':' + path], cwd=REPO)

def write_json(name, obj):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, sort_keys=True, indent=2) + '\n')

def write_raw(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def archive(name, files):
    with zipfile.ZipFile(OUT / name, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path, data in sorted(files.items()):
            info = zipfile.ZipInfo(path, (2026, 11, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)

def semantic(data):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    obj = json.loads(data, object_pairs_hook=pairs,
                     parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    require(isinstance(obj, dict) and obj, 'empty result')
    counts = {}
    for key, table in obj.items():
        require(isinstance(table, dict) and isinstance(table.get('tuples'), list), 'result table')
        counts[key] = len(table['tuples'])
        table['tuples'].sort(key=lambda row: canonical(row).decode())
    return sha(canonical(obj)), counts

OUT.mkdir()
report = json.loads(snapshot(E / 'LOCAL_PROBE.json'))
partial = json.loads(snapshot(E / 'PARTIAL_RESULTS.json'))
expected = json.loads(gzip.decompress(snapshot(PROTOTYPE / 'DEPENDENCY_INVENTORIES.json.gz')))['candidate']
proto_manifest = json.loads(snapshot(PROTOTYPE / 'MANIFEST.json'))
require(identity(snapshot(PROTOTYPE / 'DEPENDENCY_INVENTORIES.json.gz'))['sha256']
        == proto_manifest['files']['DEPENDENCY_INVENTORIES.json.gz']['sha256'], 'prototype inventory source')
spec_bytes = git('artifact/codeql_summary_projection.json', SPEC_COMMIT)
spec = json.loads(spec_bytes)
require(spec['capsule_sha256'] == report['plan']['capsule_sha256'], 'same Stage4 capsule')
require(spec['files'] == report['plan']['files'], 'same Stage4 capsule closure')
require(sha(canonical(expected)) == report['dependency_inventory_sha256']
        == spec['dependency_inventory']['effective_inventory_sha256'], 'same dependency inventory')

# Recheck every dependency, including the exact path set, without invoking the installer.
dep_root = PACK / '.codeql/libraries'
observed = {}
for path in sorted(dep_root.rglob('*')):
    require(not path.is_symlink(), 'dependency symlink')
    if path.is_file():
        observed[path.relative_to(dep_root).as_posix()] = identity(snapshot(path))
require(observed == expected and len(observed) == 1175, 'dependency postcheck')
require(set(observed) == {p.relative_to(dep_root).as_posix() for p in dep_root.rglob('*') if p.is_file()},
        'dependency path census changed')

query_manifest_bytes = git('artifact/codeql_rust_queries.json')
query_manifest = json.loads(query_manifest_bytes)
require(sha(query_manifest_bytes) == spec['query_manifest_sha256'], 'query manifest SHA')
require(query_manifest['queries'] == report['query_hashes'], 'query source pin map')
queries, compiled = {}, {}
query_records = {}
for relative, expected_sha in sorted(query_manifest['queries'].items()):
    source = identity(snapshot(PACK / relative))
    qlx = identity(snapshot((PACK / relative).with_suffix('.qlx')))
    require(source['sha256'] == expected_sha, 'query source ' + relative)
    require(qlx['sha256'] == report['compiled_query_hashes'][relative], 'query QLX ' + relative)
    queries[relative] = source['sha256']
    compiled[relative] = qlx['sha256']
    query_records[relative] = {'source': source, 'compiled': qlx}
require(len(queries) == 39 and sha(canonical(compiled)) == spec['compiled_inventory_sha256'], '39 QLX census')
stages = {}
for relative, record in spec['files'].items():
    actual = identity(snapshot(PACK / relative))
    require(actual == record, 'capsule member ' + relative)
    stages[relative] = actual
header = snapshot(PACK / spec['plan_path']).partition(b'\n...\n')[0].decode()
stage_names = re.findall(r'^- filename: (.+)$', header, re.MULTILINE)
require(len(stage_names) == len(set(stage_names)) == 15, '15 stage closure')
require({'.codeql/precompiled/' + n for n in stage_names} == set(stages) - {spec['plan_path']}, 'header stage paths')
require(re.findall(r'^inputsDigest: (\w+)$', header, re.MULTILINE) == [spec['compiler_inputs_digest']], 'compiler key')
support = {rel: identity(snapshot(PACK / rel)) for rel in spec['query_pack_support_files']}
require(support == spec['query_pack_support_files'] and len(support) == 9, 'support source identity')
root_qll = {p.relative_to(PACK).as_posix() for p in PACK.rglob('*.qll')
            if '.codeql' not in p.relative_to(PACK).parts}
require(root_qll == {p for p in support if p.endswith('.qll')}, 'all six root QLL paths')
loaded = report['observations']['precompiled_query_loads']
require(len(loaded) == 39 and set(loaded) == {str((PACK / p).with_suffix('.qlx')) for p in queries},
        'recorded 39 QLX load census')
require(report['observations']['query_compilations'] == 0, 'recorded zero query compile')
write_raw('QUERY_PACK_INVENTORY.json.gz', gzip.compress(canonical({
    'dependencies': observed, 'queries': query_records, 'stage_closure': stages, 'support_files': support}), mtime=0))
write_json('QUERY_PACK_POSTCHECK.json', {
    'kind': 'qperiapt.stage4_probe_readonly_postcheck', 'status': 'pass',
    'checked_pack': str(PACK), 'started_utc': STARTED,
    'finished_utc': datetime.now(timezone.utc).isoformat(),
    'same_pack_as_original_frozen_suite': True,
    'dependency_file_count': len(observed), 'dependency_exact_path_set': True,
    'dependency_inventory_sha256': sha(canonical(observed)),
    'query_source_count': len(queries), 'compiled_query_count': len(compiled),
    'compiled_inventory_sha256': sha(canonical(compiled)),
    'stage_count': len(stage_names), 'compiler_inputs_digest': spec['compiler_inputs_digest'],
    'full_summary_qlx': stages[spec['plan_path']], 'support_file_count': len(support),
    'root_qll_exact_path_count': len(root_qll),
    'query_scope': 'The exact 39-query frozen suite. The bundled root pack also contains unused queries; this receipt does not relabel those as part of the selected suite.',
    'expected_dependency_source': {'path': str(PROTOTYPE / 'DEPENDENCY_INVENTORIES.json.gz'),
        **identity(snapshot(PROTOTYPE / 'DEPENDENCY_INVENTORIES.json.gz'))},
    'additional_support_spec': {'commit': SPEC_COMMIT, 'path': 'artifact/codeql_summary_projection.json',
        **identity(spec_bytes), 'role': 'Later published identity specification for the identical original Stage4 capsule; not the controller version executed by this probe.'},
    'recorded_precompiled_loads': len(loaded), 'recorded_query_compilations': 0,
    'new_codeql_processes': 0, 'query_pack_writes': 0,
})

# Independently recompute all semantic identities from existing raw decoded bytes.
require(set(partial['results']) == set(queries) - {FULL}, 'partial exact census')
decoded_archive = {}
results = {}
for relative, record in sorted(partial['results'].items()):
    item = {}
    for prefix in ['partial-fresh-', 'retained-']:
        stem = prefix + Path(relative).stem + '-decoded'
        raw = snapshot(E / (stem + '.stdout'))
        sem, counts = semantic(raw)
        command = json.loads(snapshot(E / (stem + '.json')))
        require(command['returncode'] == 0, 'original decode exit ' + stem)
        for suffix in ['stdout', 'stderr', 'json']:
            decoded_archive[stem + '.' + suffix] = snapshot(E / (stem + '.' + suffix))
        bqrs_rel = (record['path'] if prefix == 'partial-fresh-'
                    else 'retained-bqrs/' + str(Path(relative).with_suffix('.bqrs')))
        bqrs = identity(snapshot(E / bqrs_rel))
        expected_record = record if prefix == 'partial-fresh-' else report['retained_results'][relative]
        require(sem == expected_record['semantic_sha256'] and bqrs['sha256'] == expected_record['bqrs_sha256'],
                'result receipt identity ' + stem)
        item[prefix.rstrip('-')] = {'decoded': identity(raw), 'semantic_sha256': sem,
                                   'table_rows': counts, 'bqrs': bqrs, 'bqrs_path': bqrs_rel}
    require(item['partial-fresh']['semantic_sha256'] == item['retained']['semantic_sha256'], 'semantic mismatch ' + relative)
    require(record['retained_semantics_equal'] is True and record['decode_status'] == 'decoded', 'record status')
    original_fresh = ROOT / 'results/codeql/rust-queries' / Path(relative).with_suffix('.bqrs')
    require(identity(snapshot(original_fresh)) == item['partial-fresh']['bqrs'], 'fresh result snapshot identity')
    item['equal'] = True
    results[relative] = item
archive('decoded-results.zip', decoded_archive)
write_json('PARTIAL_SEMANTICS_REVIEW.json', {
    'kind': 'qperiapt.stage4_partial_semantics_independent_readback', 'status': 'pass',
    'checked_utc': datetime.now(timezone.utc).isoformat(),
    'expected_queries': 39, 'captured_queries': len(results), 'decoded_queries': len(results),
    'equal_retained_queries': len(results), 'missing_queries': [FULL],
    'canonicalization': 'Strict JSON object parsing; each table tuples array sorted by compact sorted-key JSON; SHA256 of the complete compact sorted-key JSON. This preserves all columns, rows, duplicate tuples, and table metadata.',
    'new_decoders_executed': 0, 'raw_decoded_archive': 'decoded-results.zip',
    'results': results,
})

# Keep the executed entrypoint and the immutable import closure in a single ZIP.
method = snapshot(W / 'run_projection_full_probe.py')
require(sha(method) == report['method_sha256'], 'original method bytes')
require(sha(git('artifact/codeql_summary_control.py')) == report['controller_sha256'], 'actual controller commit')
tracked = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', COMMIT, 'artifact'], cwd=REPO).decode().splitlines())
todo = ['artifact/codeql_summary_control.py']
sources = {}
while todo:
    path = todo.pop()
    if path in sources:
        continue
    raw = git(path)
    sources[path] = raw
    for node in ast.walk(ast.parse(raw)):
        names = ([n.name for n in node.names] if isinstance(node, ast.Import)
                 else [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
        for name in names:
            local = 'artifact/' + name.split('.')[0] + '.py'
            if local in tracked:
                todo.append(local)
sources['artifact/codeql_rust_queries.json'] = query_manifest_bytes
sources['artifact/codeql_summary_dynamic_plan.json'] = git('artifact/codeql_summary_dynamic_plan.json')
sources['local-method/run_projection_full_probe.py'] = method
sources['review-method/package_stage4_probe.py'] = snapshot(Path(__file__))
sources['review-spec/codeql_summary_projection.json'] = spec_bytes
sources['frozen.qls'] = snapshot(ROOT / 'frozen.qls')
archive('reproduction-sources.zip', sources)
write_json('REPRODUCTION_SOURCES.json', {
    'kind': 'qperiapt.stage4_probe_source_binding', 'method_record_matched': True,
    'controller_record_matched': True, 'controller_source_commit': COMMIT,
    'controller_source_tree': subprocess.check_output(['git', 'rev-parse', COMMIT + '^{tree}'], cwd=REPO).decode().strip(),
    'method_path': str(W / 'run_projection_full_probe.py'), 'method': identity(method),
    'controller': identity(sources['artifact/codeql_summary_control.py']),
    'import_closure_scope': 'The six repository Python modules from the actual controller commit. The entrypoint records its own and controller hashes; imported-module hashes are reconstructed from that source commit, not claimed as independent runtime instrumentation.',
    'archive': 'reproduction-sources.zip',
    'files': {p: identity(data) for p, data in sorted(sources.items())},
    'replay': 'Extract the archive into an isolated workspace. Restore the fixed retained input artifact and official CodeQL Rust bundle plus the original prototype pack/capsule identified by raw/LOCAL_PROBE.json and raw/SOURCE_TRANSPORT.json. The archived method has original absolute workspace paths; adapt only the workspace location explicitly and record that derivative method hash. Its ARTIFACT directory must contain the archived commit-443f05fa import closure. Do not execute in the currently running probe workspace.',
    'later_working_tree_edits': 'Files in the integration worktree were updated after the original Python import. The current worktree controller is not substituted for the archived executed version.',
})

# Hash the large evaluator log once; retain its identity rather than duplicate it.
readback = json.loads(snapshot(W / 'summary-probe-stage3-readback/STAGE3_READBACK.json'))
log_path = E / report['observations']['logs'][0]['path']
full_hash, prefix_hash = hashlib.sha256(), hashlib.sha256()
prefix_remaining = readback['source']['prefix_bytes']
before = log_path.stat()
with log_path.open('rb') as stream:
    while block := stream.read(1024 * 1024):
        full_hash.update(block)
        prefix_hash.update(block[:prefix_remaining])
        prefix_remaining = max(0, prefix_remaining - len(block))
after = log_path.stat()
require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), 'evaluator log changed')
require(full_hash.hexdigest() == report['observations']['logs'][0]['sha256'], 'full evaluator log hash')
require(prefix_remaining == 0 and prefix_hash.hexdigest() == readback['source']['prefix_sha256'], 'Stage3 snapshot prefix hash')
write_json('EXTERNAL_ARTIFACTS.json', {
    'kind': 'qperiapt.stage4_large_original_evidence_identities',
    'evaluator_log': {'path': str(log_path), 'bytes': after.st_size, 'sha256': full_hash.hexdigest(),
        'storage': 'Original raw results artifact; not duplicated or recompressed in this review packet.'},
    'stage3_snapshot_prefix': {'bytes': readback['source']['prefix_bytes'], 'sha256': prefix_hash.hexdigest()},
    'process_samples': {'path': str(E / 'PROCESS_RESOURCES.jsonl'), **identity(snapshot(E / 'PROCESS_RESOURCES.jsonl'))},
    'database_inputs_receipt': {'path': str(E / 'DATABASE_INPUTS.json'), **identity(snapshot(E / 'DATABASE_INPUTS.json'))},
    'retained_input': report['source'], 'input_identity': report['input_identity'],
})
for name in ['LOCAL_PROBE.json', 'query.json', 'query.stdout', 'query.stderr', 'PARTIAL_RESULTS.json',
             'PROCESS_RESOURCES.json', 'DATABASE_ARCHIVE.json', 'SOURCE_TRANSPORT.json', 'version.json',
             'version.stdout', 'version.stderr']:
    write_raw('raw/' + name, snapshot(E / name))
for name in ['STAGE3_READBACK.json', 'STAGE3_RA_READBACK.json']:
    write_raw('stage3/' + name, snapshot(W / 'summary-probe-stage3-readback' / name))
for name in ['COMPILE_STARTED.json', 'COMPILE.json', 'RESOURCE_CONTEXT.json']:
    write_raw('overlap/' + name, snapshot(W / 'summary-stage34-feasibility/review-packet' / name))
write_json('REVIEW.json', {
    'kind': 'qperiapt.stage4_full_probe_review', 'review_started_utc': STARTED,
    'review_finished_utc': datetime.now(timezone.utc).isoformat(),
    'execution_status': 'incomplete', 'returncode': report['evaluation']['returncode'],
    'supervisor_stop_reason': report['evaluation']['stopped'],
    'supervised_seconds': report['evaluation']['seconds'],
    'invocation_utc': report['evaluator_invocation_utc'], 'receipt_finished_utc': report['finished_utc'],
    'configuration': report['configuration'], 'query_pack_postcheck': 'pass',
    'partial_semantic_comparisons': {'passed': len(results), 'total_available': 38},
    'missing_query': FULL, 'new_codeql_processes': 0,
    'termination_cause': 'Undetermined. The recorded return code is 137 and stderr ends with Killed; no kernel or cgroup cause record is available. The supervisor did not record a timeout stop.',
    'concurrent_compile': {'started_utc': '2026-11-11T11:33:01.649495+00:00',
        'finished_utc': '2026-11-11T11:34:40.929829+00:00', 'sources': ['overlap/COMPILE_STARTED.json', 'overlap/COMPILE.json']},
    'performance_interpretation': 'The probe overlapped a separately recorded Stage3+Stage4 compilation near termination. Its incomplete wall time is not a clean performance baseline, and no exact kernel kill time or speedup is inferred.',
    'stage3_diagnostic_scope': 'The original Stage4 candidate was still evaluating Stage3 in the fixed-prefix readback. The snapshot and RA identify a Stage3 recursive full-read relation as a concrete optimization target; the separate Stage3+Stage4 candidate is a different plan.',
    'actions': {'codeql_started': False, 'compiler_started': False, 'query_started': False,
                'fixture_started': False, 'query_pack_modified': False, 'remote_modified': False},
})
print(json.dumps({'output': str(OUT), 'verified_semantic_pairs': len(results),
                  'verified_dependencies': len(observed), 'verified_selected_qlx': len(compiled),
                  'source_archive_bytes': (OUT / 'reproduction-sources.zip').stat().st_size,
                  'decoded_archive_bytes': (OUT / 'decoded-results.zip').stat().st_size}, indent=2))
