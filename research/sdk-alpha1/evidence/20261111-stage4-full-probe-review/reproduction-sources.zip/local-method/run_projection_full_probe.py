"""Recorded local execution of the admitted projection prototype on the retained database."""

from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import platform
import re
import shutil
import sys
import time

WORK = Path('/workspace/scratch/4b61438fb07b')
ROOT = WORK / 'codeql-projection-full-probe'
EVIDENCE = ROOT / 'evidence'
ARTIFACT = WORK / 'codeql-performance-integration/artifact'
PROTOTYPE = WORK / 'summary-plan-feasibility'
PACKET = PROTOTYPE / 'review-packet'
CODEQL = PROTOTYPE / 'tool/codeql/codeql'
HEAP_MB, NATIVE_MB, THREADS, DEADLINE = 1024, 4096, 4, 3600
sys.path.insert(0, str(ARTIFACT))
import codeql_summary_control as control


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'dependency symlink')
        if path.is_file():
            result[path.relative_to(root).as_posix()] = {
                'bytes': path.stat().st_size, 'sha256': digest(path)}
    return result


report = {
    'schema': 1,
    'kind': 'qperiapt.summary_projection_local_probe',
    'started_utc': utc(),
    'completed': False,
    'sarif_published': False,
    'release_claim_eligible': False,
    'scope': 'Local development budget; separate from the fixed 14,000 MiB hosted paired profiles.',
    'configuration': {'heap_mb': HEAP_MB, 'native_mb': NATIVE_MB,
                      'threads': THREADS, 'deadline_seconds': DEADLINE},
    'source': control.SOURCE,
    'input_identity': json.loads((EVIDENCE / 'SOURCE_TRANSPORT.json').read_text())['input_identity'],
    'host': {'kernel': platform.release(), 'cpus': os.cpu_count(),
             'meminfo': Path('/proc/meminfo').read_text(), 'cpuinfo': Path('/proc/cpuinfo').read_text()},
    'method_sha256': digest(Path(__file__)),
    'controller_sha256': digest(ARTIFACT / 'codeql_summary_control.py'),
}
control.write_json(EVIDENCE / 'LOCAL_PROBE.json', report)
phase = 'admit_inputs'
queries = None
environment = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'),
               'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
try:
    require(report['input_identity'] == control.INPUT_IDENTITY, 'retained input identity')
    bundle = PROTOTYPE / 'codeql-bundle-rust-linux64.tar.zst'
    require(bundle.stat().st_size == control.TOOL_BUNDLE_BYTES
            and digest(bundle) == control.TOOL_BUNDLE_SHA256, 'official CLI bundle identity')
    require(digest(CODEQL) == control.CODEQL_LAUNCHER_SHA256, 'launcher identity')
    require(digest(PACKET / 'MANIFEST.json') ==
            '86b4b5f6ca48cacd79ef78ac11248f8aa2140e1e0d6ba4781885e5ed60e0d757',
            'prototype packet identity')
    manifest = json.loads((PACKET / 'MANIFEST.json').read_text())
    for name in ['CANDIDATE_CAPSULE.json', 'DEPENDENCY_INVENTORIES.json.gz', 'CANDIDATE_SOURCE.json']:
        require(digest(PACKET / name) == manifest['files'][name]['sha256'], 'prototype record identity')
    capsule = json.loads((PACKET / 'CANDIDATE_CAPSULE.json').read_text())
    require(digest(PACKET / 'codeql-stage4-projected-read.zip') == capsule['capsule_sha256'],
            'prototype capsule identity')
    pack = ROOT / 'query-pack'
    shutil.copytree(PROTOTYPE / 'candidate-query-pack', pack)
    dependency_expected = json.loads(gzip.decompress(
        (PACKET / 'DEPENDENCY_INVENTORIES.json.gz').read_bytes()))['candidate']
    require(inventory(pack / '.codeql/libraries') == dependency_expected, 'resolved dependency inventory')
    for name, expected in capsule['files'].items():
        path = pack / name
        require(path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'],
                'compiled capsule member: ' + name)
    query_hashes = json.loads((ARTIFACT / 'codeql_rust_queries.json').read_text())['queries']
    queries = {relative: pack / relative for relative in query_hashes}
    require({name: digest(path) for name, path in queries.items()} == query_hashes, '39 query sources')
    compiled = {name: digest(path.with_suffix('.qlx')) for name, path in queries.items()}
    original_pack = CODEQL.parent / 'qlpacks/codeql/rust-queries/0.1.44'
    require(all(compiled[name] == digest((original_pack / name).with_suffix('.qlx'))
                for name in queries if name != control.FULL_SUMMARY), 'other 38 compiled queries')
    header = (pack / capsule['plan_path']).read_bytes().partition(b'\n...\n')[0].decode()
    require(re.findall(r'^inputsDigest: ([a-z0-9]+)$', header, re.MULTILINE)
            == [capsule['compiler_inputs_digest']], 'effective compiler input key')
    report.update(plan=capsule, query_hashes=query_hashes, compiled_query_hashes=compiled,
                  dependency_inventory_sha256=control.canonical_sha(dependency_expected))
    for name in ['tmp', 'cache', 'results']:
        (ROOT / name).mkdir(mode=0o700)
    (EVIDENCE / 'evaluator').mkdir(mode=0o700)
    version = control.small_command([str(CODEQL), 'version', '--format=terse'],
                                    EVIDENCE / 'version', environment)
    require(version.strip() == b'2.27.2', 'CLI version')
    with (ROOT / 'frozen.qls').open('x') as stream:
        stream.write(''.join('- query: ' + json.dumps(str(queries[name])) + '\n' for name in sorted(queries)))
    phase = 'decode_retained_results'
    report['retained_results'] = control.decode_retained_results(CODEQL, queries, ROOT, environment)
    command = [str(CODEQL), 'execute', 'queries', f'-J-Xmx{HEAP_MB}M', f'--off-heap-ram={NATIVE_MB}',
               '-J-XX:+PrintFlagsFinal', f'--threads={THREADS}', '--threat-model=local', '--warnings=show',
               '--dynamic-join-order-mode=all', '--no-rerun', '--verbosity=progress', '--evaluator-log-level=5',
               '--common-caches=' + str(ROOT / 'cache'), '--logdir=' + str(EVIDENCE / 'evaluator'),
               '--output=' + str(ROOT / 'results'), '--', str(ROOT / 'database/db-rust'),
               'path:' + str(ROOT / 'frozen.qls')]
    report['query_command'] = command
    report['evaluator_invocation_utc'] = utc()
    control.write_json(EVIDENCE / 'LOCAL_PROBE.json', report)
    print(json.dumps({'phase': 'evaluate', 'invocation_utc': report['evaluator_invocation_utc'],
                      'configuration': report['configuration']}), flush=True)
    phase = 'evaluate'
    report['evaluation'] = control.run_queries(command, EVIDENCE, environment, seconds=DEADLINE)
    require(report['evaluation']['returncode'] == 0, 'query evaluation return code')
    observations = control.evaluator_observations(EVIDENCE)
    require(observations['max_heap_bytes_observed'] == [HEAP_MB * 1024**2]
            and observations['off_heap_mb_observed'] == [NATIVE_MB], 'actual memory allocation')
    require(sorted(observations['precompiled_query_loads']) ==
            sorted(str(path.with_suffix('.qlx')) for path in queries.values())
            and observations['query_compilations'] == 0, 'exact precompiled load census')
    report['observations'] = observations
    require(inventory(pack / '.codeql/libraries') == dependency_expected, 'post-evaluation dependencies')
    require({name: digest(path) for name, path in queries.items()} == query_hashes, 'post-evaluation sources')
    require({name: digest(path.with_suffix('.qlx')) for name, path in queries.items()} == compiled,
            'post-evaluation compiled queries')
    phase = 'decode_results'
    report['results'] = control.decode_results(CODEQL, queries, ROOT, environment)
    control.validate_retained_results(report['retained_results'], report['results'], queries)
    report['completed'] = True
except BaseException as error:
    report['failure'] = {'phase': phase, 'type': type(error).__name__, 'message': str(error)[:1200]}
    if (EVIDENCE / 'query.json').exists():
        report['evaluation'] = json.loads((EVIDENCE / 'query.json').read_text())
    if phase in ['evaluate', 'decode_results'] and queries:
        try:
            report['observations'] = control.evaluator_observations(EVIDENCE)
            report['partial_results'] = control.retain_partial_results(
                CODEQL, queries, ROOT, environment, report.get('retained_results', {}),
                cleanup_ambiguous=report.get('evaluation', {}).get('cleanup_ambiguous', False))
        except BaseException as capture_error:
            report['capture_failure'] = {'type': type(capture_error).__name__, 'message': str(capture_error)[:500]}
finally:
    report['finished_utc'] = utc()
    control.write_json(EVIDENCE / 'LOCAL_PROBE.json', report)
    print(json.dumps({'completed': report['completed'], 'phase': phase,
                      'failure': report.get('failure'), 'finished_utc': report['finished_utc']}), flush=True)
sys.exit(0 if report['completed'] else 1)
