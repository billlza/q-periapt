from pathlib import Path
import json
import secrets
import rust_sdk_profile as sdk

root = Path.cwd(); stage = Path(__file__).resolve().parent
cfg = json.loads((stage/'PREPARING_03.json').read_text()); outside = Path(cfg['outside'])
old = Path('/private/var/folders/c7/2dhh484x7m7bg6qkx91_92lm0000gn/T/qperiapt-canonical-ipad-jfo2a42h/consumer')
app = outside/'device-consumer'
selected = ['AppDelegate.swift','ConfigurationCommands.swift','ReplacementInputs.swift',
            'Runner.swift','USBOperation.swift','USBRelay.c','USBRelay.h']
for name in selected: sdk.copy(old/'Sources'/name,app/'Sources'/name)
sdk.copy(old/'Info.plist', app/'Info.plist')
sdk.copy(stage/'PendingCommands.swift', app/'Sources/PendingCommands.swift')
text = (old/'Sources/ReplacementCommands.swift').read_text()
text = text.replace('        if mode.hasPrefix("root-") { try RootCommands.run(args); return }\n','')
start = text.index('        if mode.hasPrefix("retired-owned-")')
end = text.index('        var cleanup:', start)
text = text[:start]+text[end:]
start = text.index('            if mode == "retired-owned-operational-denied"')
end = text.index('            let enrollment', start)
text = text[:start]+text[end:]
text = text.replace('mode == "policy-create"','mode == "managed-witness-create"')
text = text.replace('case "policy-prepare":','case "managed-witness-prepare":')
text = text.replace('case "policy-activate":','case "managed-witness-activate":')
text = text.replace('            case "policy-identity": return try credentialIdentity(enrollment)\n','')
key = '            switch mode {\n'
sdk.require(text.count(key)==1,'dispatch shape')
text = text.replace(key,'            if mode.hasPrefix("pending-") { return try PendingCommands.execute(mode, input:input, enrollment:enrollment) }\n'+key)
with (app/'Sources/ReplacementCommands.swift').open('x') as stream: stream.write(text)
path = app/'Sources/Runner.swift'; text = path.read_text()
old_dispatch = '''            if mode.hasPrefix("retired-owned-") { try ReplacementCommands.run(command) }
            else { try await usbOperation(arguments:command,source:source,mode:mode,run:run) }
'''
sdk.require(text.count(old_dispatch)==1,'runner dispatch shape')
path.write_text(text.replace(old_dispatch,'            try await usbOperation(arguments:command,source:source,mode:mode,run:run)\n'))
project = json.loads((old/'project.json').read_text())
project['packages']['Continuity']['path'] = '../apple-package/installed/QPeriaptContinuity'
settings = project['targets']['ContinuityIOSRunner']['settings']['base']
bundle = 'dev.qperiapt.PendingRecovery.r'+secrets.token_hex(12)
settings['PRODUCT_BUNDLE_IDENTIFIER'] = bundle
for key in ['DEVELOPMENT_TEAM','CODE_SIGN_IDENTITY','CODE_SIGN_STYLE']: settings.pop(key)
settings['CODE_SIGNING_ALLOWED'] = 'NO'
sdk.write_json(app/'project.json',project)
sdk.write_json(stage/'APP_SOURCE_05.json',{'consumer':str(app),'bundle':bundle,
    'source_files':{str(p.relative_to(app)):sdk.snapshot(p).sha256 for p in app.rglob('*') if p.is_file()},
    'scope':'Public configured Swift enrollment, exact pending write and pre-call cancellation; opaque USB transport'})
print('Small Swift device consumer prepared; existing root-replacement commands are not included')
