from pathlib import Path
import ast
import rust_sdk_profile as sdk

parent=Path(__file__).resolve().parent;previous=parent/'attempt-14';stage=parent/'attempt-24'
text=(previous/'capture-19.py').read_text()
text=text.replace('parent=stage.parent','parent=stage.parent;previous=parent/\'attempt-14\'')
for label in ['project','build','sign','signature']:
    text=text.replace("'"+label+"-16'","'"+label+"-24'")
text=text.replace("'prepare-capture-19.py']:","'prepare-capture-19.py','prepare-fresh-launch-24.py','prepare-capture-27.py']:")
text=text.replace("for name in ['build-app-07.py','build-app-16.py','run-device-08.py','verify-device-09.py',\n 'capture-19.py'",
                  "for name in ['build-app-24.py','run-device-08.py','verify-device-09.py',\n 'capture-27.py'")
text=text.replace("add(stage/'BUILD_COLLISION_16.json'","add(previous/'BUILD_COLLISION_16.json'")
text=text.replace("add(stage/(prefix+'.'+suffix),'failed/build/", "add(previous/(prefix+'.'+suffix),'failed/build/")
text=text.replace("(stage/'startup-only-15')","(previous/'startup-only-15')")
text=text.replace("stage/'startup-only-15'","previous/'startup-only-15'")
key="for name,digest in app['source_files'].items():";sdk.require(text.count(key)==1,'second failure insertion')
extra='''for name in ['APP.json','APP_SOURCE_05.json','RESULT_08.json','DEVICE_STATE_08.json','OWN_CRASH_INVENTORY_23.json']:
    add(previous/name,'failed/second/'+name)
for prefix in ['project-16','build-16','sign-16','signature-16','device-08-signed-fixed-unapplied','device-08-signed-recoverable-applied']:
    for suffix in ['json','stdout','stderr']:add(previous/(prefix+'.'+suffix),'failed/second/'+prefix+'.'+suffix)
for name in ['build-app-16.py','run-device-08.py','ios_client.py','device_support.py','usb_transport.py']:
    add(previous/name,'failed/second/recipes/'+name)
old_app=json.loads((previous/'APP_SOURCE_05.json').read_text())
for name,digest in old_app['source_files'].items():
    path=Path(old_app['consumer'])/name;sdk.require(sdk.snapshot(path).sha256==digest,'second failed app source changed')
    add(path,'failed/second/source/'+name)
for directory in ['device-control-08','device-execution','public-08']:
    for path in (previous/directory).rglob('*'):
        if path.is_file():add(path,'failed/second/'+directory+'/'+path.relative_to(previous/directory).as_posix())
add(parent/'LOCK_STATE_13.json','failed/first/LOCK_STATE_13.json')
'''
text=text.replace(key,extra+key)
key="signing=json.loads((root/'target/continuity-ios-device-preparation/SIGNING.json').read_text())"
extra='''for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
    secret=(previous/'device-cases-08'/label/'inputs/tls-key').read_bytes()
    for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'second failed cohort key included')
'''
text=text.replace(key,extra+key)
text=text.replace("for base in [stage/'device-execution',previous/'startup-only-15']:",
                  "for base in [stage/'device-execution',previous/'device-execution',previous/'startup-only-15']:")
text=text.replace("'distinct_process_identifiers_verified':True}","'distinct_process_identifiers_verified':True,'fresh_process_flag_and_post_exit_absence':True}")
ast.parse(text)
with (stage/'capture-27.py').open('x') as stream:stream.write(text)
document=(previous/'document-20.py').read_text()
needle='''The later accepted functional cohort uses fresh state and requires 39 distinct
process identifiers, exact launch arguments and structured exit-zero/no-core-dump
results. The original pre-admission exit remains unexplained; successful later
execution is not evidence that its cause was fixed.'''
replacement='''The next functional cohort completed its fixed/unapplied route in 20 processes,
then its recoverable/applied route failed after ten operations at the same
post-expiry launch boundary. Its structured result confirms exit 1 without a core
dump; no UIKit lifecycle or startup admission appeared. Both failed cohorts were
cleaned and retained.

CoreDevice documents that console launch may attach to an existing application.
The original driver did not explicitly require a new process, despite that being
the fixture's contract. The accepted driver records prelaunch process inventory,
uses `--terminate-existing` for its owned test bundle, requires a fresh distinct
PID and structured exit-zero/no-core-dump result, and queries that PID absent
after exit. It does not retry a failed SDK operation or weaken any recovery check.
This enforces the process contract; no existing-process cause for the earlier
exits is asserted. Their cause remains unresolved, and later successful execution
does not retrospectively fix them.'''
sdk.require(document.count(needle)==1,'startup failure document shape');document=document.replace(needle,replacement)
ast.parse(document)
with (stage/'document-28.py').open('x') as stream:stream.write(document)
final=(previous/'finalize-21.py').read_text()
for label in ['diff','stage','commit','clone-fetch','clone-checkout','source-gate']:
    final=final.replace("stage/'"+label+"-21'","stage/'"+label+"-29'")
final=final.replace("stage/'CHECKPOINT_21.json'","stage/'CHECKPOINT_29.json'")
ast.parse(final)
with (stage/'finalize-29.py').open('x') as stream:stream.write(final)
print('Capture plan retains both failed cohorts and enforces distinct verified process acceptance')
