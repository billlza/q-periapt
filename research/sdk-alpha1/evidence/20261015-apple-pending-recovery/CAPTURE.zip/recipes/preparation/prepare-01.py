from pathlib import Path
import json
import subprocess
import tempfile
import rust_sdk_profile as sdk
import continuity_package as candidate

root = Path.cwd(); stage = Path(__file__).resolve().parent
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain']), 'source must be clean')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
baseline = json.loads((root/'target/continuity-android-pending-continuation/BUILD_18.json').read_text())
core = root/'target/continuity-browser-publication/source/target/pending-inspection-package-10'
records = json.loads((core/'CORE_ARCHIVES.json').read_text())
sdk.require(records['completed'] and records['candidate']['sha256'] == baseline['candidate_sha256'], 'archive identity')
outside = Path(tempfile.mkdtemp(prefix='qpc-apple-pending-')).resolve()
consumer = outside/'c-consumer'
fixture = root/'bindings/c/ContinuityPackageConsumer'
for path in sorted(fixture.rglob('*')):
    if path.is_file(): sdk.copy(path, consumer/path.relative_to(fixture))
sdk.extract_recorded_crates(consumer, core, records['crates'])
record = records['candidate']; archive = sdk.snapshot(core/record['file'])
sdk.require(archive.sha256 == record['sha256'], 'candidate archive changed')
for name, data in candidate.validate_candidate(archive.data, set(record['files'])).items():
    path = consumer/'packages/q-periapt-continuity-identity-candidate-0.0.0'/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
with (consumer/'Cargo.toml').open('a') as stream:
    stream.write('q-periapt-continuity-identity-candidate = { path = "packages/q-periapt-continuity-identity-candidate-0.0.0" }\n')
sdk.copy(root/'research/continuity-identity-candidate/Cargo.lock', consumer/'Cargo.lock')
sdk.write_json(stage/'PREPARED_01.json', {'outside': str(outside), 'consumer': str(consumer),
    'source_commit': source, 'engine_source_commit': records['source_commit'],
    'candidate_sha256': record['sha256'], 'environment': baseline['environment'],
    'harness': baseline['harness'], 'harness_sha256': baseline['harness_sha256'],
    'receiver': baseline['receiver'], 'receiver_sha256': baseline['receiver_sha256']})
print('Fresh Apple package source prepared from ten verified Cargo archives')
