from pathlib import Path
import ast
import rust_sdk_profile as sdk

parent=Path(__file__).resolve().parent;stage=parent/'attempt-14'
text=(parent/'capture-10.py').read_text()
text=text.replace('root=Path.cwd();stage=Path(__file__).resolve().parent','root=Path.cwd();stage=Path(__file__).resolve().parent;parent=stage.parent')
text=text.replace("archive=stage/'package-04'/package['archive']['file']","archive=parent/'package-04'/package['archive']['file']")
text=text.replace("for name in ['APP.json','APP_SOURCE_05.json','RESOLUTION_03.json','RESULT_08.json','VERIFIED_09.json','PREFLIGHT.md']:",
                  "for name in ['APP.json','APP_SOURCE_05.json','RESULT_08.json','VERIFIED_09.json']:")
text=text.replace("for prefix in ['candidate-list-03','candidate-package-03','resolution-03','project-07','build-07','sign-07','signature-07','catalog-08']:",
                  "for prefix in ['project-16','build-16','sign-16','signature-16','catalog-08']:")
text=text.replace("(stage/'package-04').rglob('*')","(parent/'package-04').rglob('*')")
text=text.replace("path.relative_to(stage/'package-04')","path.relative_to(parent/'package-04')")
start=text.index("for name in ['prepare-01.py'");end=text.index("for name,digest in app['source_files'].items():",start)
text=text[:start]+'''for name in ['prepare-01.py','package-02.py','prepare-03.py','package-04.py','prepare-app-05.py',
 'PendingCommands.swift','prepare-driver-06.py','prepare-diagnostic-14.py','startup-diagnostic-15.py','repair-build-16.py','prepare-capture-19.py']:
    add(parent/name,'recipes/preparation/'+name)
for name in ['build-app-07.py','build-app-16.py','run-device-08.py','verify-device-09.py',
 'capture-19.py','ios_client.py','device_support.py','usb_transport.py']:
    add(stage/name,'recipes/accepted/'+name)
for prefix in ['candidate-list-03','candidate-package-03','resolution-03']:
    for suffix in ['json','stdout','stderr']:add(parent/(prefix+'.'+suffix),'package/'+prefix+'.'+suffix)
for name in ['PREFLIGHT.md','RESOLUTION_03.json','APP.json','APP_SOURCE_05.json','RESULT_08.json','DEVICE_STATE_08.json']:
    add(parent/name,'failed/first/'+name)
for prefix in ['project-07','build-07','sign-07','signature-07','device-08-signed-fixed-unapplied']:
    for suffix in ['json','stdout','stderr']:add(parent/(prefix+'.'+suffix),'failed/first/'+prefix+'.'+suffix)
for name in ['build-app-07.py','run-device-08.py','ios_client.py','device_support.py','usb_transport.py']:
    add(parent/name,'failed/first/recipes/'+name)
failed_source=json.loads((parent/'APP_SOURCE_05.json').read_text())
for name,digest in failed_source['source_files'].items():
    path=Path(failed_source['consumer'])/name;sdk.require(sdk.snapshot(path).sha256==digest,'original failed app source changed')
    add(path,'failed/first/source/'+name)
for directory in ['device-control-08','device-execution']:
    for path in (parent/directory).rglob('*'):
        if path.is_file():add(path,'failed/first/'+directory+'/'+path.relative_to(parent/directory).as_posix())
add(stage/'BUILD_COLLISION_16.json','failed/build/BUILD_COLLISION_16.json')
for prefix in ['project-07','build-07']:
    for suffix in ['json','stdout','stderr']:add(stage/(prefix+'.'+suffix),'failed/build/'+prefix+'.'+suffix)
for path in (stage/'startup-only-15').rglob('*'):
    if path.is_file():add(path,'startup-diagnostic/'+path.relative_to(stage/'startup-only-15').as_posix())
''' +text[end:]
key="signing=json.loads((root/'target/continuity-ios-device-preparation/SIGNING.json').read_text())"
sdk.require(text.count(key)==1,'capture signing boundary')
text=text.replace(key,'''secret=(parent/'device-cases-08/signed-fixed-unapplied/inputs/tls-key').read_bytes()
for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'failed cohort test key included')
''' +key)
key="for name,payload in list(files.items()):"
sdk.require(text.count(key)==1,'capture redaction boundary')
text=text.replace(key,'''# Structured CoreDevice files are retained with the selected hardware identity redacted.
for base in [stage/'device-execution',stage/'startup-only-15']:
    for path in base.rglob('PROCESS_RESULT.json'):
        identity=json.loads(path.read_text()).get('deviceIdentifier')
        if identity:redactions[identity]='<SELECTED_DEVICE>'
''' +key)
key="'protocol_or_storage_changed':False,'release_claim_eligible':False,'goal_active':True}"
sdk.require(text.count(key)==1,'capture scope')
text=text.replace(key,"'protocol_or_storage_changed':False,'release_claim_eligible':False,'goal_active':True,\n 'failed_physical_startup_retained':True,'startup_failure_cause_resolved':False,\n 'original_failed_signed_binary_overwritten':True,'distinct_process_identifiers_verified':True}")
ast.parse(text)
with (stage/'capture-19.py').open('x') as stream:stream.write(text)
document=(parent/'document-11.py').read_text()
needle='The initial preparation rejected an older archive whose recovery document no'
replacement='''The first physical cohort completed ten operations, then its post-expiry launch
returned exit 1 before startup admission, with no SDK or observation-file receipt.
That cohort failed and was cleaned. A fresh diagnostic application added UIKit
lifecycle records and structured CoreDevice termination results. Two startup-only
launches, separated by 190 seconds idle and calling no SDK operation, passed.
The later accepted functional cohort uses fresh state and requires 39 distinct
process identifiers, exact launch arguments and structured exit-zero/no-core-dump
results. The original pre-admission exit remains unexplained; successful later
execution is not evidence that its cause was fixed.

Preparing the diagnostic build also exposed an operator recipe error: a fresh
source directory reused the earlier DerivedData and link-map locations. The old
signed app and link map were overwritten before signing refused an existing
entitlements file. Original source, build/sign/run receipts and recorded hashes
remain; the old signed executable is no longer asserted available. The unsigned
replacement is retained locally. The accepted build uses independent DerivedData,
link-map and signing paths, with absence checks before mutation. SDK source and
private runtime state were not modified by this error.

The initial preparation rejected an older archive whose recovery document no'''
sdk.require(document.count(needle)==1,'document failure location');document=document.replace(needle,replacement)
document=document.replace('all 39 startup admissions and app exits, container result','all 39 startup admissions and structured app exits, container result')
ast.parse(document)
with (stage/'document-20.py').open('x') as stream:stream.write(document)
final=(parent/'finalize-12.py').read_text()
for name in ['diff','stage','commit','clone-fetch','clone-checkout','source-gate']:
    final=final.replace("stage/'"+name+"-12'","stage/'"+name+"-21'")
final=final.replace("stage/'CHECKPOINT_12.json'","stage/'CHECKPOINT_21.json'")
ast.parse(final)
with (stage/'finalize-21.py').open('x') as stream:stream.write(final)
print('New capture plan retains failed physical startup, independent diagnostic and build-output collision')
