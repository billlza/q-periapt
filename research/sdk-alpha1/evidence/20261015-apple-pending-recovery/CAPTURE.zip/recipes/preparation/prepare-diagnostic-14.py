from pathlib import Path
import ast
import json
import secrets
import shutil
import rust_sdk_profile as sdk

root=Path.cwd();parent=Path(__file__).resolve().parent;stage=parent/'attempt-14';stage.mkdir(mode=0o700)
old=json.loads((parent/'APP_SOURCE_05.json').read_text())
prepared=json.loads((parent/'PREPARED_03.json').read_text());outside=Path(prepared['outside'])
consumer=outside/'device-consumer-14';shutil.copytree(Path(old['consumer']),consumer)
for name in ['PREPARED_03.json','build-app-07.py','run-device-08.py','verify-device-09.py','device_support.py','ios_client.py','usb_transport.py']:
    sdk.copy(parent/name,stage/name)
sdk.copy(parent/'package-04/CONTINUITY_APPLE_PACKAGE.json',stage/'package-04/CONTINUITY_APPLE_PACKAGE.json')
path=consumer/'Sources/AppDelegate.swift';text=path.read_text()
key='final class AppDelegate: UIResponder, UIApplicationDelegate {\n';sdk.require(text.count(key)==1,'AppDelegate shape')
text=text.replace(key,key+'''    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE didFinish protected=\\(application.isProtectedDataAvailable)\\n".utf8)) }
        catch { exit(76) }
        return true
    }
''')
key='        guard let windowScene = scene as? UIWindowScene else {'
text=text.replace(key,'''        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE sceneConnect\\n".utf8)) }
        catch { exit(76) }
'''+key)
key='        guard !started else { return }'
text=text.replace(key,'''        do { try FileHandle.standardOutput.write(contentsOf: Data("QPC_IOS_LIFECYCLE sceneActive\\n".utf8)) }
        catch { exit(76) }
'''+key);path.write_text(text)
path=consumer/'Sources/Runner.swift';text=path.read_text();key='            let source=documents.appendingPathComponent("inputs-"+scenario,isDirectory:true)'
sdk.require(text.count(key)==1,'runner source shape')
text=text.replace(key,'''            if mode == "startup-only" {
                let marker="QPC_IOS_STARTUP_ONLY_PASS run=\\(run)\\n"
                try durableIOS(Array(marker.utf8),documents.appendingPathComponent("startup-"+run+".txt").path)
                try FileHandle.standardOutput.write(contentsOf:Data(marker.utf8));exit(0)
            }
'''+key);path.write_text(text)
path=consumer/'project.json';project=json.loads(path.read_text());bundle='dev.qperiapt.PendingRecovery.r'+secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER']=bundle
path.write_text(json.dumps(project,indent=2)+'\n')
sdk.write_json(stage/'APP_SOURCE_05.json',{'consumer':str(consumer),'bundle':bundle,
 'source_files':{str(p.relative_to(consumer)):sdk.snapshot(p).sha256 for p in consumer.rglob('*') if p.is_file() and '.xcodeproj' not in str(p.relative_to(consumer))},
 'scope':'Same public configured flow, with independent pre-SDK startup diagnostics'})
path=stage/'usb_transport.py';text=path.read_text()
old="'--timeout','90','--console',bundle";new="'--timeout','90','--json-output',str(capture/'launch-raw.json'),'--console',bundle"
sdk.require(text.count(old)==1,'launch argument shape');text=text.replace(old,new)
key="   if code!=(77 if mode in CUT else 0):raise RuntimeError('device launch command failed')"
sdk.require(text.count(key)==1,'launch terminal shape')
text=text.replace(key,"   if (capture/'launch-raw.json').exists():\n    raw=json.loads((capture/'launch-raw.json').read_text());(capture/'PROCESS_RESULT.json').write_text(json.dumps(raw.get('result',{}),indent=2)+'\\n')\n"+key)
ast.parse(text);path.write_text(text)
(stage/'ios_client.py').chmod(0o700)
print('Fresh diagnostic app source prepared; old failed cohort and signed app remain unchanged')
