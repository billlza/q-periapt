from pathlib import Path
import ast
import json
import rust_sdk_profile as sdk

parent=Path(__file__).resolve().parent;stage=parent/'attempt-14'
prepared=json.loads((stage/'PREPARED_03.json').read_text());outside=Path(prepared['outside'])
old=json.loads((parent/'APP.json').read_text())
current=Path(old['app'])/'ContinuityIOSRunner'
actual=sdk.snapshot(current,maximum=128*1024**2)
sdk.copy(current,stage/'failed-diagnostic-executable-07',maximum=128*1024**2)
sdk.write_json(stage/'BUILD_COLLISION_16.json',{'completed':False,'original_signed_binary_overwritten':True,
 'original_signed_sha256':old['executable_sha256'],'replacement_unsigned_sha256':actual.sha256,
 'cause':'Fresh consumer source shared the original DerivedData and link-map paths; signing then refused the existing entitlements file.',
 'preserved':'Original sources, build/sign/install/run receipts, recorded original hash and failed runtime cohort are unchanged.',
 'private_runtime_state_changed':False,'sdk_source_changed':False})
text=(stage/'build-app-07.py').read_text()
replacements={"outside/'device-build-07'":"outside/'device-build-16'",
 "outside/'consumer07-$(TARGET_NAME)-LinkMap.txt'":"outside/'consumer16-$(TARGET_NAME)-LinkMap.txt'",
 "outside/'consumer07-ContinuityIOSRunner-LinkMap.txt'":"outside/'consumer16-ContinuityIOSRunner-LinkMap.txt'",
 "outside/'app-entitlements-07.plist'":"outside/'app-entitlements-16.plist'"}
for old,new in replacements.items():
    sdk.require(text.count(old)==1,'build output path shape');text=text.replace(old,new)
for name in ['project','build','sign','signature']:
    text=text.replace("stage/'"+name+"-07'","stage/'"+name+"-16'")
text=text.replace("('build-07.'+suffix)","('build-16.'+suffix)")
key="env={key:os.environ[key]";sdk.require(text.count(key)==1,'build environment shape')
text=text.replace(key,"sdk.require(not build.exists() and not (outside/'consumer16-ContinuityIOSRunner-LinkMap.txt').exists() and not (outside/'app-entitlements-16.plist').exists(),'fresh build outputs required')\n"+key)
ast.parse(text)
with (stage/'build-app-16.py').open('x') as stream:stream.write(text)
print('Dedicated build, link-map and signing outputs prepared with pre-mutation collision checks')
