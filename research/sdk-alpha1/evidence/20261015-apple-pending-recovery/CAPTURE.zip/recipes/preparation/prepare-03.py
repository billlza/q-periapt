from pathlib import Path
import json
import shutil
import subprocess
import tempfile
import rust_sdk_profile as sdk
import continuity_package as candidate
import continuity_c_consumer as c

root = Path.cwd(); stage = Path(__file__).resolve().parent
sdk.require(not subprocess.check_output(['git', 'status', '--porcelain']), 'source must be clean')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
baseline = json.loads((root/'target/continuity-android-pending-continuation/BUILD_18.json').read_text())
env = json.loads((root/'target/continuity-android-pending-recovery/ENVIRONMENT_01.json').read_text())
core = root/'target/continuity-browser-publication/source/target/pending-inspection-package-10'
records = json.loads((core/'CORE_ARCHIVES.json').read_text())
sdk.require(records['completed'], 'archive producer incomplete')
outside = Path(tempfile.mkdtemp(prefix='qpc-apple-pending-current-')).resolve()
consumer = outside/'c-consumer'; fixture = root/'bindings/c/ContinuityPackageConsumer'
for path in sorted(fixture.rglob('*')):
    if path.is_file(): sdk.copy(path, consumer/path.relative_to(fixture))
sdk.extract_recorded_crates(consumer, core, records['crates'])
producer = outside/'source'; patches = []
for name in sdk.CONSUMER_CRATES:
    destination = producer/'crates'/name
    shutil.copytree(consumer/'packages'/(name+'-'+sdk.VERSION), destination)
    patches += ['--config', 'patch.crates-io.'+name+'.path='+json.dumps(str(destination))]
relative = 'research/continuity-identity-candidate'
for name in subprocess.check_output(['git', 'ls-files', '--', relative], text=True).splitlines():
    sdk.copy(root/name, producer/name)
sdk.write_json(stage/'PREPARING_03.json', {'outside':str(outside), 'source_commit':source})
cargo = str(Path(env['RUSTC']).parent/'cargo')
env = dict(env, CARGO_TARGET_DIR=str(outside/'crate-build'))
args = [cargo, 'package', '--manifest-path', str(producer/relative/'Cargo.toml'),
        '--locked', '--offline', '--all-features', *patches]
listed = sdk.command([*args, '--list'], stage/'candidate-list-03', producer, environment=env).decode().splitlines()
sdk.require(len(listed) == len(set(listed)), 'duplicate candidate inventory')
sdk.command([*args, '-j', '2'], stage/'candidate-package-03', producer, environment=env)
sdk.validate_cargo_package_completion(candidate.NAME, [(stage/('candidate-package-03.'+suffix)).read_text() for suffix in ['stdout','stderr']])
archive = sdk.snapshot(outside/'crate-build/package'/f'{candidate.NAME}-{candidate.VERSION}.crate')
files = candidate.validate_candidate(archive.data, set(listed))
sdk.copy(archive.path, stage/archive.path.name)
for name, data in files.items():
    path = consumer/'packages'/f'{candidate.NAME}-{candidate.VERSION}'/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
with (consumer/'Cargo.toml').open('a') as stream:
    stream.write('q-periapt-continuity-identity-candidate = { path = "packages/q-periapt-continuity-identity-candidate-0.0.0" }\n')
sdk.copy(root/relative/'Cargo.lock', consumer/'Cargo.lock')
original = (consumer/'Cargo.lock').read_bytes()
metadata = json.loads(sdk.command([cargo,'metadata','--offline','--format-version','1'], stage/'resolution-03', consumer, environment=env))
resolution = candidate.verify_resolution(metadata,consumer,(consumer/'Cargo.lock').read_bytes(),original,
                                        consumer_name=c.NAME,required_features=c.FEATURES)
sdk.write_json(stage/'RESOLUTION_03.json', resolution)
sdk.write_json(stage/'PREPARED_03.json', {'outside':str(outside), 'consumer':str(consumer),
    'source_commit':source, 'engine_source_commit':source, 'candidate_sha256':archive.sha256,
    'candidate_files':{name:sdk.hashlib.sha256(data).hexdigest() for name,data in files.items()},
    'environment':env, 'harness':baseline['harness'], 'harness_sha256':baseline['harness_sha256'],
    'receiver':baseline['receiver'], 'receiver_sha256':baseline['receiver_sha256']})
print('Current candidate archive compiled and exact ten-package resolution verified')
