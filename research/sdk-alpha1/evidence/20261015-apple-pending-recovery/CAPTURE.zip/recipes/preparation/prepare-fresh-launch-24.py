from pathlib import Path
import ast
import json
import secrets
import rust_sdk_profile as sdk

parent=Path(__file__).resolve().parent;old=parent/'attempt-14';stage=parent/'attempt-24';stage.mkdir(mode=0o700)
prepared=json.loads((parent/'PREPARED_03.json').read_text());outside=Path(prepared['outside'])
original=json.loads((old/'APP_SOURCE_05.json').read_text());consumer=outside/'device-consumer-24'
for name,digest in original['source_files'].items():
    source=Path(original['consumer'])/name;sdk.require(sdk.snapshot(source).sha256==digest,'source baseline changed')
    sdk.copy(source,consumer/name)
project_path=consumer/'project.json';project=json.loads(project_path.read_text())
bundle='dev.qperiapt.PendingRecovery.r'+secrets.token_hex(12)
project['targets']['ContinuityIOSRunner']['settings']['base']['PRODUCT_BUNDLE_IDENTIFIER']=bundle
project_path.write_text(json.dumps(project,indent=2)+'\n')
sdk.write_json(stage/'APP_SOURCE_05.json',{'consumer':str(consumer),'bundle':bundle,
 'source_files':{name:sdk.snapshot(consumer/name).sha256 for name in original['source_files']},
 'scope':'Public configured Swift pending recovery; explicit fresh test-process startup and structured lifetime observations'})
for name in ['PREPARED_03.json','run-device-08.py','verify-device-09.py','device_support.py','ios_client.py','usb_transport.py']:
    sdk.copy(old/name,stage/name)
(stage/'ios_client.py').chmod(0o700)
sdk.copy(parent/'package-04/CONTINUITY_APPLE_PACKAGE.json',stage/'package-04/CONTINUITY_APPLE_PACKAGE.json')
text=(old/'build-app-16.py').read_text()
for before,after in [('device-build-16','device-build-24'),('consumer16-','consumer24-'),('app-entitlements-16.plist','app-entitlements-24.plist')]:
    sdk.require(before in text,'build output identity');text=text.replace(before,after)
for name in ['project','build','sign','signature']:
    text=text.replace("stage/'"+name+"-16'","stage/'"+name+"-24'")
text=text.replace("('build-16.'+suffix)","('build-24.'+suffix)")
ast.parse(text)
with (stage/'build-app-24.py').open('x') as stream:stream.write(text)
path=stage/'usb_transport.py';text=path.read_text()
old_args="'--console',bundle";sdk.require(text.count(old_args)==1,'launch flag shape')
text=text.replace(old_args,"'--console','--terminate-existing',bundle")
key=" args=['xcrun','devicectl'";sdk.require(text.count(key)==1,'launch construction')
text=text.replace(key," _,before=command(device,['device','info','processes','--search','ContinuityIOSRunner'],capture/'prelaunch')\n prior=before['result']['runningProcesses']\n prior_pids={row['processIdentifier'] for row in prior}\n (capture/'PRELAUNCH_PROCESSES.json').write_text(json.dumps(prior,indent=2)+'\\n')\n"+key)
key="   if code!=(77 if mode in CUT else 0):raise RuntimeError('device launch command failed')";sdk.require(text.count(key)==1,'terminal boundary')
text=text.replace(key,key+"\n   terminal=raw['result'];pid=terminal['process']['processIdentifier']\n   if terminal['launchOptions']['terminateExistingInstances'] is not True or pid in prior_pids:raise RuntimeError('launch did not establish a fresh process')\n   if terminal['terminationResult']!={'exitCode':(77 if mode in CUT else 0),'wasCoreDumpCreated':False}:raise RuntimeError('structured termination differs')\n   _,after=command(device,['device','info','processes','--filter',f'processIdentifier = {pid}'],capture/'postlaunch')\n   if after['result']['runningProcesses']:raise RuntimeError('reported terminated app process remains visible')")
ast.parse(text);path.write_text(text)
path=stage/'verify-device-09.py';text=path.read_text()
key="    pid=process['process']['processIdentifier']";sdk.require(text.count(key)==1,'verifier process selection')
text=text.replace(key,"    sdk.require(process['launchOptions']['terminateExistingInstances'] is True,'fresh-process flag absent')\n"+key)
key="    sdk.require(isinstance(pid,int) and pid>0 and pid not in pids,'physical process identity repeated');pids.add(pid)"
sdk.require(text.count(key)==1,'verifier pid census')
text=text.replace(key,key+"\n    before=json.loads((folder/'PRELAUNCH_PROCESSES.json').read_text())\n    sdk.require(pid not in {row['processIdentifier'] for row in before},'existing process was reused')")
ast.parse(text);path.write_text(text)
print('Fresh app, isolated build paths, explicit new process and pre/post PID checks prepared')
