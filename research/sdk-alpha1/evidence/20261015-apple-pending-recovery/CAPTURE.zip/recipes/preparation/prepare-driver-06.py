from pathlib import Path
import ast
import rust_sdk_profile as sdk

root=Path.cwd();stage=Path(__file__).resolve().parent;old=root/'target/continuity-canonical-ipad-root'
for name in ['device_support.py','usb_transport.py']:
    text=(old/name).read_text()
    if name=='device_support.py':
        text=text.replace("APP['bundle_id']","APP['bundle']")
    ast.parse(text)
    with (stage/name).open('x') as stream:stream.write(text)
text=(old/'ios_client.py').read_text()
start=text.index('CUT=');end=text.index('def validate(',start)
text=text[:start]+'''CUT=set()
MODES={'managed-witness-create','managed-witness-prepare','managed-witness-activate',
 'authority-create','authority-peer-associate','roster-witness-peer-unassociated',
 'roster-witness-peer-connect','roster-witness-peer-uncertain','pending-identity',
 'pending-request','pending-request-absent','pending-activate-expired','pending-roster-unknown',
 'pending-confirm','pending-confirm-damaged','pending-confirm-unapproved','pending-confirm-cancelled'}
ALLOWED={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest',
 'protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope',
 'recovery-root','recovery-enrollment','grant-certificate','grant-roster','trusted-account',
 'trusted-roster-version','trusted-roster-digest','connection-address','connection-initiation',
 'connection-session','connection-message','witness-id','witness-public','witness-address',
 'witness-subject','witness-carrier','authority-id','authority-application','authority-checkpoint',
 'authority-peer-application','remote-roster','remote-roster-version','remote-roster-digest',
 'pending-proposal','pending-metadata'}
PEER={'family','directory','bootstrap.bundle','tls-peer','tls-peer-name','approved-certificate','approved-roster'}|{p+s for p in ('initiator','responder') for s in ('-account','-root','-roster-version','-roster-digest','-device','-generation')}
''' +text[end:]
text=text.replace("  elif not nested and f.name in {'root-target','root-original-target'} and f.is_dir() and not f.is_symlink():validate(f,True)\n",'')
text=text.replace('f.stat().st_size>131072','f.stat().st_size>(8388608 if f.name=="pending-metadata" else 131072)')
text=text.replace("(source/'root-target' if mode.startswith('root-peer-') else source)",'source')
key=' validate(source)\n'
sdk.require(text.count(key)==1,'driver validation shape')
text=text.replace(key," if not source.resolve().is_relative_to(OUT/'device-cases-08') or not destination.resolve().is_relative_to(OUT/'device-cases-08'):raise RuntimeError('run-owned paths required')\n"+key)
ast.parse(text)
with (stage/'ios_client.py').open('x') as stream:stream.write(text)
(stage/'ios_client.py').chmod(0o700)
print('Bounded fresh-cohort Apple driver prepared; only public results can be copied back')
