from collections import Counter
from pathlib import Path
import hashlib
import json
import rust_sdk_profile as sdk
import continuity_android_pending as pending

stage=Path(__file__).resolve().parent
result=json.loads((stage/'RESULT_08.json').read_text());app=json.loads((stage/'APP.json').read_text())
sdk.require(result['completed'] and result['cleanup'] and not result['live_producer'],'physical run not terminal and cleaned')
observed={};pids=set()
for folder in (stage/'device-execution').iterdir():
    sdk.require(folder.is_dir() and not folder.is_symlink(),'unexpected execution entry')
    row=json.loads((folder/'RESULT.json').read_text());usb=json.loads((folder/'USB_TRANSPORT.json').read_text())
    sdk.require(row['completed'] and row['app_exit']==0 and row['run']==folder.name,'physical operation incomplete')
    sdk.require(usb['completed'] and usb['startup_admitted'],'missing startup or relay terminal')
    marker=f"QPC_IOS_REPLACEMENT_PASS mode={row['mode']} profile={row['profile']} run={row['run']}\n".encode()
    stdout=(folder/'launch.stdout').read_bytes().splitlines()
    sdk.require(stdout.count(marker.strip())==1 and stdout.count(b'The app terminated with the exit code 0.')==1,'missing exact app termination')
    sdk.require((folder/'launch.stderr').read_bytes()==b'' and (folder/'receipt.txt').read_bytes()==marker,'physical diagnostics or receipt mismatch')
    sdk.require(hashlib.sha256((folder/'public-result.bin').read_bytes()).hexdigest()==row['public_result_sha256'],'physical public result changed')
    process=json.loads((folder/'PROCESS_RESULT.json').read_text())
    termination=process['terminationResult']
    sdk.require(termination['exitCode']==0 and termination['wasCoreDumpCreated'] is False,'structured termination differs')
    sdk.require(process['launchOptions']['arguments']==[row['mode'],row['profile'],row['case'],row['run'],'signed','managed'],'structured invocation differs')
    sdk.require(process['launchOptions']['terminateExistingInstances'] is True,'fresh-process flag absent')
    pid=process['process']['processIdentifier']
    sdk.require(isinstance(pid,int) and pid>0 and pid not in pids,'physical process identity repeated');pids.add(pid)
    before=json.loads((folder/'PRELAUNCH_PROCESSES.json').read_text())
    sdk.require(pid not in {row['processIdentifier'] for row in before},'existing process was reused')
    key=(row['case'],row['profile']);observed.setdefault(key,[]).append(row['mode'])
expected={}
for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
    carrier,profile,outcome=label.split('-')
    case=hashlib.sha256(str(stage/'device-cases-08'/label/'installation').encode()).hexdigest()[:32]
    expected[(case,profile)]=[mode for _,mode in pending.cases(outcome=='applied')]
    stdout=(stage/('device-08-'+label+'.stdout')).read_bytes()
    sdk.require(pending.verify_execution(stdout,stage/'public-08',label)[label]==result['cases'][label],'public recovery readback differs')
sdk.require(set(observed)==set(expected) and all(Counter(observed[key])==Counter(modes) for key,modes in expected.items()),'profile or operation census differs')
sdk.require(sum(map(len,observed.values()))==39,'Swift invocation count')
for name,digest in app['driver_files'].items():sdk.require(sdk.snapshot(stage/name).sha256==digest,'executed driver changed')
for name,digest in app['source_files'].items():sdk.require(sdk.snapshot(Path(app['consumer'])/name).sha256==digest,'executed Swift source changed')
sdk.write_json(stage/'VERIFIED_09.json',{'completed':True,'public_readers':2,'physical_swift_processes':39,
 'startup_admissions':39,'explicit_exit_zero':39,'profile_census':True,'owned_cleanup':True,
 'package_sha256':app['package_sha256'],'executable_sha256':app['executable_sha256']})
print('Independent Apple public, process, admission and profile census readback passed')
