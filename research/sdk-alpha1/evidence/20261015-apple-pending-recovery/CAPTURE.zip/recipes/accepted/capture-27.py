from pathlib import Path
import base64
import hashlib
import json
import tempfile
import zipfile
import rust_sdk_profile as sdk
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent;parent=stage.parent;previous=parent/'attempt-14'
verified=json.loads((stage/'VERIFIED_09.json').read_text());result=json.loads((stage/'RESULT_08.json').read_text())
app=json.loads((stage/'APP.json').read_text());prepared=json.loads((stage/'PREPARED_03.json').read_text())
package=json.loads((stage/'package-04/CONTINUITY_APPLE_PACKAGE.json').read_text())
sdk.require(verified['completed'] and result['completed'] and result['cleanup'] and package['completed'],'incomplete producer')
archive=parent/'package-04'/package['archive']['file']
sdk.require(sdk.snapshot(archive,maximum=256*1024**2).sha256==app['package_sha256'],'Apple package changed')
sdk.require(sdk.snapshot(Path(app['app'])/'ContinuityIOSRunner',maximum=128*1024**2).sha256==app['executable_sha256'],'signed app changed')
output=root/'research/sdk-alpha1/evidence/20261015-apple-pending-recovery';output.mkdir()
files={}
def add(path,name):
    sdk.require(name not in files,'duplicate capture entry')
    files[name]=sdk.snapshot(path,maximum=32*1024**2).data
def logs(prefix,label):
    for suffix in ['json','stdout','stderr']:add(stage/(prefix+'.'+suffix),label+'.'+suffix)
for name in ['APP.json','APP_SOURCE_05.json','RESULT_08.json','VERIFIED_09.json']:
    add(stage/name,'receipts/'+name)
redacted_prepared={key:value for key,value in prepared.items() if key!='environment'}
files['receipts/PREPARED_03.json']=(json.dumps(redacted_prepared,indent=2,sort_keys=True)+'\n').encode()
for prefix in ['project-24','build-24','sign-24','signature-24','catalog-08']:
    logs(prefix,'commands/'+prefix)
for path in (parent/'package-04').rglob('*'):
    if path.is_file() and path.suffix in ['.json','.stdout','.stderr']:
        add(path,'package/'+path.relative_to(parent/'package-04').as_posix())
for name in ['prepare-01.py','package-02.py','prepare-03.py','package-04.py','prepare-app-05.py',
 'PendingCommands.swift','prepare-driver-06.py','prepare-diagnostic-14.py','startup-diagnostic-15.py','repair-build-16.py','prepare-capture-19.py','prepare-fresh-launch-24.py','prepare-capture-27.py']:
    add(parent/name,'recipes/preparation/'+name)
for name in ['build-app-24.py','run-device-08.py','verify-device-09.py',
 'capture-27.py','ios_client.py','device_support.py','usb_transport.py']:
    add(stage/name,'recipes/accepted/'+name)
for prefix in ['candidate-list-03','candidate-package-03','resolution-03']:
    for suffix in ['json','stdout','stderr']:add(parent/(prefix+'.'+suffix),'package/'+prefix+'.'+suffix)
for name in ['PREFLIGHT.md','RESOLUTION_03.json','APP.json','APP_SOURCE_05.json','RESULT_08.json','DEVICE_STATE_08.json']:
    add(parent/name,'failed/first/'+name)
for prefix in ['project-07','build-07','sign-07','signature-07','device-08-signed-fixed-unapplied']:
    for suffix in ['json','stdout','stderr']:add(parent/(prefix+'.'+suffix),'failed/first/'+prefix+'.'+suffix)
for name in ['build-app-07.py','run-device-08.py','ios_client.py','device_support.py','usb_transport.py']:
    add(parent/name,'failed/first/recipes/'+name)
failed_source=json.loads((parent/'APP_SOURCE_05.json').read_text())
for name,digest in failed_source['source_files'].items():
    path=Path(failed_source['consumer'])/name;sdk.require(sdk.snapshot(path).sha256==digest,'original failed app source changed')
    add(path,'failed/first/source/'+name)
for directory in ['device-control-08','device-execution']:
    for path in (parent/directory).rglob('*'):
        if path.is_file():add(path,'failed/first/'+directory+'/'+path.relative_to(parent/directory).as_posix())
add(previous/'BUILD_COLLISION_16.json','failed/build/BUILD_COLLISION_16.json')
for prefix in ['project-07','build-07']:
    for suffix in ['json','stdout','stderr']:add(previous/(prefix+'.'+suffix),'failed/build/'+prefix+'.'+suffix)
for path in (previous/'startup-only-15').rglob('*'):
    if path.is_file():add(path,'startup-diagnostic/'+path.relative_to(previous/'startup-only-15').as_posix())
for name in ['APP.json','APP_SOURCE_05.json','RESULT_08.json','DEVICE_STATE_08.json','OWN_CRASH_INVENTORY_23.json']:
    add(previous/name,'failed/second/'+name)
for prefix in ['project-16','build-16','sign-16','signature-16','device-08-signed-fixed-unapplied','device-08-signed-recoverable-applied']:
    for suffix in ['json','stdout','stderr']:add(previous/(prefix+'.'+suffix),'failed/second/'+prefix+'.'+suffix)
for name in ['build-app-16.py','run-device-08.py','ios_client.py','device_support.py','usb_transport.py']:
    add(previous/name,'failed/second/recipes/'+name)
old_app=json.loads((previous/'APP_SOURCE_05.json').read_text())
for name,digest in old_app['source_files'].items():
    path=Path(old_app['consumer'])/name;sdk.require(sdk.snapshot(path).sha256==digest,'second failed app source changed')
    add(path,'failed/second/source/'+name)
for directory in ['device-control-08','device-execution','public-08']:
    for path in (previous/directory).rglob('*'):
        if path.is_file():add(path,'failed/second/'+directory+'/'+path.relative_to(previous/directory).as_posix())
add(parent/'LOCK_STATE_13.json','failed/first/LOCK_STATE_13.json')
for name,digest in app['source_files'].items():
    path=Path(app['consumer'])/name;sdk.require(sdk.snapshot(path).sha256==digest,'app source changed')
    add(path,'consumer/'+name)
for name in ['artifact/continuity_android_pending.py','artifact/continuity_android_contract.py',
 'artifact/continuity_apple_package.py','artifact/continuity_apple_consumer.py',
 'bindings/c/ContinuityPackageConsumer/qpc_owner.h']:
    add(root/name,'source/'+name)
for path in (root/'bindings/swift/ContinuityPackageConsumer/Sources/QPeriaptContinuity').glob('*.swift'):
    add(path,'source/'+path.relative_to(root).as_posix())
for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
    logs('device-08-'+label,'execution/'+label)
    for name in pending.public(label.endswith('-applied')):
        add(stage/'public-08'/label/name,'public/'+label+'/'+name)
for directory in ['device-control-08','device-execution']:
    for path in (stage/directory).rglob('*'):
        if path.is_file():
            sdk.require(path.suffix in ['.json','.stdout','.stderr','.txt','.bin'],'unexpected device evidence type')
            add(path,directory+'/'+path.relative_to(stage/directory).as_posix())
for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
    secret=(stage/'device-cases-08'/label/'inputs/tls-key').read_bytes()
    for payload in files.values():
        sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'private test TLS key in capture')
secret=(parent/'device-cases-08/signed-fixed-unapplied/inputs/tls-key').read_bytes()
for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'failed cohort test key included')
for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
    secret=(previous/'device-cases-08'/label/'inputs/tls-key').read_bytes()
    for payload in files.values():sdk.require(secret not in payload and base64.b64encode(secret) not in payload,'second failed cohort key included')
signing=json.loads((root/'target/continuity-ios-device-preparation/SIGNING.json').read_text())
redactions={result['device_sha256']:'<SELECTED_DEVICE_SHA256>',
    signing['identity']:'<EXISTING_SIGNING_IDENTITY>',signing['team']:'<EXISTING_SIGNING_TEAM>',
    signing['profile_uuid']:'<EXISTING_PROFILE_UUID>'}
# Structured CoreDevice files are retained with the selected hardware identity redacted.
for base in [stage/'device-execution',previous/'device-execution',previous/'startup-only-15']:
    for path in base.rglob('PROCESS_RESULT.json'):
        identity=json.loads(path.read_text()).get('deviceIdentifier')
        if identity:redactions[identity]='<SELECTED_DEVICE>'
for name,payload in list(files.items()):
    if name.endswith(('.json','.stdout','.stderr','.py','.txt')):
        for value,replacement in redactions.items():payload=payload.replace(value.encode(),replacement.encode())
        files[name]=payload
capture=output/'CAPTURE.zip'
with zipfile.ZipFile(capture,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,payload in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        bundle.writestr(info,payload)
manifest={'format':1,'source_commit':prepared['source_commit'],'candidate_sha256':prepared['candidate_sha256'],
 'apple_package_sha256':app['package_sha256'],'ios_staticlib_sha256':app['native_slice_sha256'],
 'app_sha256':app['executable_sha256'],'capture_sha256':sdk.snapshot(capture,maximum=32*1024**2).sha256,
 'members':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},
 'physical_model':result['device_model'],'physical_os':result['device_os'],'physical_swift_processes':39,
 'startup_admissions':39,'routes':2,'cleanup':True,'sdk_implementation_changed':False,
 'protocol_or_storage_changed':False,'release_claim_eligible':False,'goal_active':True,
 'failed_physical_startup_retained':True,'startup_failure_cause_resolved':False,
 'original_failed_signed_binary_overwritten':True,'distinct_process_identifiers_verified':True,'fresh_process_flag_and_post_exit_absence':True}
sdk.write_json(output/'CAPTURE.json',manifest)
with tempfile.TemporaryDirectory(prefix='qpc-apple-pending-readback-') as temporary:
    extracted=Path(temporary)
    with zipfile.ZipFile(capture) as bundle:
        sdk.require(set(bundle.namelist())==set(files),'archive inventory')
        for name,digest in manifest['members'].items():
            payload=bundle.read(name);sdk.require(hashlib.sha256(payload).hexdigest()==digest,'archive member digest')
            if name.startswith('public/'):
                path=extracted/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(payload)
        for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
            stdout=bundle.read('execution/'+label+'.stdout')
            sdk.require(pending.verify_execution(stdout,extracted/'public',label)[label]==result['cases'][label],'archive public readback')
sdk.write_json(output/'READBACK.json',{'completed':True,'members':len(files),
 'capture_sha256':manifest['capture_sha256'],'private_keys_excluded':True,'public_readers':2})
print('Physical Apple pending recovery captured and independently reread')
