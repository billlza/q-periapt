from pathlib import Path
import datetime
import fnmatch
import hashlib
import json
import os
import plistlib
import re
import subprocess
import rust_sdk_profile as sdk
import continuity_apple_package as apple
from continuity_apple_consumer import verify_linkage

root=Path.cwd();stage=Path(__file__).resolve().parent
prepared=json.loads((stage/'PREPARED_03.json').read_text());outside=Path(prepared['outside'])
source=json.loads((stage/'APP_SOURCE_05.json').read_text());consumer=Path(source['consumer'])
package=json.loads((stage/'package-04/CONTINUITY_APPLE_PACKAGE.json').read_text())
sdk.require(package['completed'],'Apple package incomplete')
for name,digest in source['source_files'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'app source changed')
signing=json.loads((root/'target/continuity-ios-device-preparation/SIGNING.json').read_text())
profile_bytes=sdk.snapshot(Path(signing['profile_path'])).data
profile=plistlib.loads(subprocess.check_output(['/usr/bin/security','cms','-D','-i',signing['profile_path']],stderr=subprocess.PIPE,timeout=20))
sdk.require(profile['UUID']==signing['profile_uuid'] and profile['TeamIdentifier']==[signing['team']],'profile identity changed')
sdk.require(profile['ExpirationDate'].replace(tzinfo=datetime.timezone.utc)>datetime.datetime.now(datetime.timezone.utc),'profile expired')
sdk.require(signing['identity'] in {hashlib.sha1(cert).hexdigest().upper() for cert in profile['DeveloperCertificates']},'certificate outside profile')
bundle=source['bundle'];application=signing['team']+'.'+bundle
sdk.require(fnmatch.fnmatchcase(application,profile['Entitlements']['application-identifier']),'bundle outside profile')
build=outside/'device-build-24';link=outside/'consumer24-$(TARGET_NAME)-LinkMap.txt'
sdk.require(not build.exists() and not (outside/'consumer24-ContinuityIOSRunner-LinkMap.txt').exists() and not (outside/'app-entitlements-24.plist').exists(),'fresh build outputs required')
env={key:os.environ[key] for key in ['HOME','TMPDIR','LANG','LC_ALL','USER','LOGNAME','PATH'] if key in os.environ}
sdk.command(['/opt/homebrew/bin/xcodegen','generate','--spec','project.json'],stage/'project-24',consumer,environment=env)
stdout=sdk.command(['/usr/bin/xcodebuild','-project',str(consumer/'ContinuityIOS.xcodeproj'),
 '-scheme','ContinuityIOSRunner','-configuration','Release','-sdk','iphoneos','-destination','generic/platform=iOS',
 '-derivedDataPath',str(build),'ARCHS=arm64','CODE_SIGNING_ALLOWED=NO','LD_GENERATE_MAP_FILE=YES',
 'LD_MAP_FILE_PATH='+str(link),'build'],stage/'build-24',consumer,environment=env)
sdk.require(b'** BUILD SUCCEEDED **' in stdout,'consumer build completion missing')
for suffix in ['stdout','stderr']:
    sdk.require(not re.search(rb'(?im)(?:^|[^a-z])(warning|error):',(stage/('build-24.'+suffix)).read_bytes()),'consumer diagnostic')
app=build/'Build/Products/Release-iphoneos/ContinuityIOSRunner.app';binary=app/'ContinuityIOSRunner'
library=app.parent/apple.LIBRARY
sdk.require(sdk.snapshot(library,maximum=128*1024**2).sha256==package['native']['aarch64-apple-ios']['sha256'],'native slice differs')
linkage=verify_linkage(outside/'consumer24-ContinuityIOSRunner-LinkMap.txt',library,binary)
sdk.require(plistlib.loads((app/'Info.plist').read_bytes())['CFBundleIdentifier']==bundle,'bundle differs')
entitlements={'application-identifier':application,'com.apple.developer.team-identifier':signing['team'],
 'get-task-allow':profile['Entitlements']['get-task-allow'],'keychain-access-groups':[application]}
sdk.require(any(fnmatch.fnmatchcase(application,p) for p in profile['Entitlements']['keychain-access-groups']),'keychain scope')
entitlement_file=outside/'app-entitlements-24.plist'
with entitlement_file.open('xb') as stream:stream.write(plistlib.dumps(entitlements))
with (app/'embedded.mobileprovision').open('xb') as stream:stream.write(profile_bytes)
sdk.command(['/usr/bin/codesign','--force','--sign',signing['identity'],'--entitlements',str(entitlement_file),
 '--generate-entitlement-der',str(app)],stage/'sign-24',consumer,environment=env)
sdk.command(['/usr/bin/codesign','--verify','--strict','--deep',str(app)],stage/'signature-24',consumer,environment=env)
for name,digest in source['source_files'].items():sdk.require(sdk.snapshot(consumer/name).sha256==digest,'source changed during build')
sdk.write_json(stage/'APP.json',{'completed':True,'app':str(app),'bundle':bundle,'executable_sha256':sdk.snapshot(binary,maximum=128*1024**2).sha256,
 'native_slice_sha256':package['native']['aarch64-apple-ios']['sha256'],'package_sha256':package['archive']['sha256'],
 'linkage':linkage,'source_files':source['source_files'],'consumer':str(consumer),
 'driver_files':{name:sdk.snapshot(stage/name).sha256 for name in ['ios_client.py','device_support.py','usb_transport.py','run-device-08.py']}})
print('Swift public pending-recovery consumer built and signed against the current Apple archive')
