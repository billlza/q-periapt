#!/opt/homebrew/opt/python@3.14/bin/python3.14
from pathlib import Path
import sys,json,hashlib,secrets,shutil,tempfile
from device_support import OUT,BUNDLE,selected,command

CUT=set()
MODES={'managed-witness-create','managed-witness-prepare','managed-witness-activate',
 'authority-create','authority-peer-associate','roster-witness-peer-unassociated',
 'roster-witness-peer-connect','roster-witness-peer-uncertain','pending-identity',
 'pending-request','pending-request-absent','pending-activate-expired','pending-roster-unknown',
 'pending-confirm','pending-confirm-damaged','pending-confirm-unapproved','pending-confirm-cancelled'}
ALLOWED={'sdk-policy','sdk-signature','sdk-root','family','policy-root','policy-version','policy-digest',
 'protocol-policy','tls-cert','tls-key','enrollment-root','enrollment-intent','recovery-scope',
 'recovery-root','recovery-enrollment','grant-certificate','grant-roster','trusted-account',
 'trusted-roster-version','trusted-roster-digest','connection-address','connection-initiation',
 'connection-session','connection-message','witness-id','witness-public','witness-address',
 'witness-subject','witness-carrier','authority-id','authority-application','authority-checkpoint',
 'authority-peer-application','remote-roster','remote-roster-version','remote-roster-digest',
 'pending-proposal','pending-metadata'}
PEER={'family','directory','bootstrap.bundle','tls-peer','tls-peer-name','approved-certificate','approved-roster'}|{p+s for p in ('initiator','responder') for s in ('-account','-root','-roster-version','-roster-digest','-device','-generation')}
def validate(source,nested=False):
 for f in source.iterdir():
  if f.name=='peer' and f.is_dir() and not f.is_symlink():
   if any(not p.is_file() or p.is_symlink() or p.name not in PEER or p.stat().st_size>65536 for p in f.iterdir()):raise RuntimeError('peer input boundary')
  elif not f.is_file() or f.is_symlink() or f.name not in ALLOWED or f.stat().st_size>(8388608 if f.name=="pending-metadata" else 131072):raise RuntimeError('input boundary: '+f.name)
def main():
 if len(sys.argv)!=6:raise RuntimeError('replacement argument count')
 mode,profile,src,target,output=sys.argv[1:]
 if mode not in MODES or profile not in {'fixed','recoverable'}:raise RuntimeError('mode/profile')
 source=Path(src);destination=Path(output)
 if not source.is_dir() or source.is_symlink() or not destination.is_absolute() or destination.exists():raise RuntimeError('input/output paths')
 if not source.resolve().is_relative_to(OUT/'device-cases-08') or not destination.resolve().is_relative_to(OUT/'device-cases-08'):raise RuntimeError('run-owned paths required')
 validate(source)
 case=hashlib.sha256(target.encode()).hexdigest()[:32];run=secrets.token_hex(16);capture=OUT/'device-execution'/run;capture.mkdir(parents=True)
 device=selected();domain=['--domain-type','appDataContainer','--domain-identifier',BUNDLE]
 command(device,['device','copy','to','--source',str(source),'--destination','Documents/inputs-'+case,*domain],capture/'inputs')
 try:
  import usb_transport
  result=usb_transport.launch(device,BUNDLE,mode,profile,case,run,capture,{r:p.read_text() for r,p in [('peer',source/'connection-address'),('witness',source/'witness-address')] if p.exists()},'signed',True)
 except Exception:
  command(device,['device','copy','from','--source','Documents/observation-'+run+'.txt','--destination',str(capture/'operation-observation.txt'),*domain],capture/'observation-copy',allow_failure=True)
  raise
 expected_exit=77 if mode in CUT else 0
 marker=f'QPC_IOS_REPLACEMENT_{"CUT" if mode in CUT else "PASS"} mode={mode} profile={profile} run={run}\n'.encode()
 if result.stdout.splitlines().count(marker.rstrip(b'\n'))!=1 or result.stdout.splitlines().count(f'The app terminated with the exit code {expected_exit}.'.encode())!=1 or b'QPC_IOS_REPLACEMENT_FAIL' in result.stdout+result.stderr:raise RuntimeError('missing terminal iOS replacement proof')
 if result.stderr:raise RuntimeError('device command diagnostic')
 command(device,['device','copy','from','--source','Documents/receipt-'+run+'.txt','--destination',str(capture/'receipt.txt'),*domain],capture/'receipt-copy')
 if (capture/'receipt.txt').read_bytes()!=marker:raise RuntimeError('container receipt differs')
 command(device,['device','copy','from','--source','Documents/result-'+run+'.bin','--destination',str(capture/'public-result.bin'),*domain],capture/'result-copy')
 data=(capture/'public-result.bin').read_bytes()
 if not 1<=len(data)<=8388608:raise RuntimeError('public result width')
 with destination.open('xb') as f:f.write(data)
 (capture/'RESULT.json').write_text(json.dumps({'completed':True,'mode':mode,'profile':profile,'case':case,'run':run,'app_exit':expected_exit,'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'public_result_sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
 if mode not in CUT:print(profile+':'+mode+':passed')
 return expected_exit
if __name__=='__main__':
 try:code=main()
 except Exception as error:print(str(error),file=sys.stderr);sys.exit(1)
 sys.exit(code)
