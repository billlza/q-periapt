from pathlib import Path
import hashlib
import json
import plistlib
import subprocess
import sys
import rust_sdk_profile as sdk
import continuity_android_contract as contract
import continuity_android_pending as pending

root=Path.cwd();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(stage))
from device_support import APP,BUNDLE,selected,command,installed

prepared=json.loads((stage/'PREPARED_03.json').read_text())
sdk.require(APP['completed'],'app build incomplete')
binary=Path(APP['app'])/'ContinuityIOSRunner'
sdk.require(sdk.snapshot(binary,maximum=128*1024**2).sha256==APP['executable_sha256'],'app identity changed')
for name,digest in APP['driver_files'].items():sdk.require(sdk.snapshot(stage/name).sha256==digest,'driver changed')
for name,digest in APP['source_files'].items():sdk.require(sdk.snapshot(Path(APP['consumer'])/name).sha256==digest,'app source changed')
for name in ['harness','receiver']:
    sdk.require(sdk.snapshot(Path(prepared[name]),maximum=256*1024**2).sha256==prepared[name+'_sha256'],'runtime changed')
sdk.require(not subprocess.check_output(['git','diff','610234b0b684e4e39bad97a953f5c66e74df2e91','--',
 'research/continuity-identity-candidate/src','research/continuity-identity-candidate/Cargo.toml',
 'research/continuity-identity-candidate/Cargo.lock','bindings/c/ContinuityPackageConsumer/src',
 'bindings/c/ContinuityPackageConsumer/Cargo.toml']),'reference harness engine differs')
device=selected()
profile=plistlib.loads(subprocess.check_output(['/usr/bin/security','cms','-D','-i',str(Path(APP['app'])/'embedded.mobileprovision')],stderr=subprocess.PIPE,timeout=20))
sdk.require(device['hardwareProperties']['udid'] in profile['ProvisionedDevices'],'offered device is not provisioned')
control=stage/'device-control-08';control.mkdir(mode=0o700)
sdk.require(not installed(device,control/'before'),'fresh owned bundle already installed')
cases=stage/'device-cases-08';cases.mkdir(mode=0o700)
public=stage/'public-08';public.mkdir(mode=0o700)
state={'completed':False,'live_producer':True,'cleanup':False,'owned_install_attempted':False,
 'device_model':device['hardwareProperties']['marketingName'],'device_os':device['deviceProperties']['osVersionNumber'],
 'device_sha256':hashlib.sha256(device['identifier'].encode()).hexdigest(),'source_commit':prepared['source_commit'],
 'package_sha256':APP['package_sha256'],'app_sha256':APP['executable_sha256'],'completed_routes':[]}
state_path=stage/'DEVICE_STATE_08.json'
def progress():state_path.write_text(json.dumps(state,indent=2)+'\n')
progress();results={}
try:
    state['owned_install_attempted']=True;progress()
    command(device,['device','install','app',APP['app']],control/'install',timeout=60)
    sdk.require(installed(device,control/'installed'),'owned installation not observed')
    env=dict(prepared['environment'],QPC_ANDROID_DRIVER=str(stage/'ios_client.py'),QPC_ANDROID_CASES=str(cases),
             QPC_CONFIGURATION_RECEIVER=prepared['receiver'])
    contract.verify_catalog(sdk.command([prepared['harness'],'--list'],stage/'catalog-08',root,environment=env))
    for label in ['signed-fixed-unapplied','signed-recoverable-applied']:
        stdout=sdk.command([prepared['harness'],'--exact',pending.TESTS[label],'--nocapture'],stage/('device-08-'+label),root,environment=env)
        result=pending.verify_execution(stdout,cases,label)
        for name in pending.public(label.endswith('-applied')):sdk.copy(cases/label/name,public/label/name)
        sdk.require(pending.verify_execution(stdout,public,label)==result,'public copy differs')
        results.update(result);state['completed_routes'].append(label);progress()
        print('Physical Swift pending-write route passed: '+label,flush=True)
    rows=[json.loads(p.read_text()) for p in (stage/'device-execution').glob('*/RESULT.json')]
    expected=sum(record['foreign_processes'] for record in results.values())
    sdk.require(expected==39 and len(rows)==expected and all(row['completed'] and row['app_exit']==0 for row in rows),'physical call census')
    sdk.require(len({row['run'] for row in rows})==expected,'reused physical invocation')
    for path in (stage/'device-execution').glob('*/USB_TRANSPORT.json'):
        row=json.loads(path.read_text());sdk.require(row['completed'] and row['startup_admitted'],'missing startup admission or transport completion')
    sdk.require(sdk.snapshot(binary,maximum=128*1024**2).sha256==APP['executable_sha256'],'app changed during execution')
    state.update(completed=True,physical_swift_processes=expected,cases=results)
except BaseException as error:
    state['failure']=repr(error)
    raise
finally:
    state['live_producer']=False
    try:
        if state['owned_install_attempted']:
            if installed(device,control/'cleanup-before'):
                command(device,['device','uninstall','app',BUNDLE],control/'uninstall',timeout=60)
            state['cleanup']=not installed(device,control/'cleanup-after')
            sdk.require(state['cleanup'],'owned app cleanup unresolved')
    except BaseException as error:
        state['cleanup_failure']=repr(error)
        raise
    finally:
        progress();sdk.write_json(stage/'RESULT_08.json',state)
print('Physical Swift exact pending recovery passed in 39 processes; owned application removed')
