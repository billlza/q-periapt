# Preparation observations

The first preparation (`prepare-01.py`) rejected the previous candidate archive
because `PENDING_WRITE_RECOVERY.md` differed from the current clean source. The
observed exception was `ValueError: candidate archive source differs:
PENDING_WRITE_RECOVERY.md`. No app was installed and no runtime cohort existed.

The same shell invocation continued to `package-02.py` after preparation failed;
that process refused the absent `PREPARED_01.json`. This was a recipe dependency
error. Subsequent preparation and package producers are dispatched separately,
only after the preceding terminal success. Neither failure is an SDK result.

`prepare-03.py` regenerated and compiled the candidate archive from clean source
84d2a029f745b915b38ac4b7999f0ccb05343386. All ten installed dependency origins and
the current candidate source bytes were checked with the existing validators.
The new candidate archive is
75ef9337d54c8cab7c84e392c76bc1f399449178d71a1e80065494f9e822c714.
The original failed recipes are retained and must not be rerun.
