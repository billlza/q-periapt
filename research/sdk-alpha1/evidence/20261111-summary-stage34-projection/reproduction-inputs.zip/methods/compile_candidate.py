#!/usr/bin/env python3
"""One bounded compile of the independently bound Stage3+Stage4 candidate."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from bounded_process import BoundedProcessError, capture_output

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT.parent


def main():
    command = [
        str(BASE / "summary-plan-feasibility/tool/codeql/codeql"),
        "query", "compile", "--precompile", "--dynamic-join-order-mode=all",
        "--no-default-compilation-cache", "--common-caches=" + str(ROOT / "cache"),
        "--threads=1", "--ram=2048", "-J-Xmx1536M", "--dump-ra", "--format=text",
        "--logdir=" + str(ROOT / "logs"), "--",
        str(ROOT / "candidate-query-pack/queries/summary/SummaryStats.ql"),
    ]
    memory = {line.split(":", 1)[0]: line.split(":", 1)[1].strip()
              for line in Path("/proc/meminfo").read_text().splitlines()}
    available_kib = int(memory["MemAvailable"].split()[0])
    record = {
        "kind": "qperiapt.stage3_stage4_projection_compile",
        "command": command, "supervisor_seconds": 180,
        "threads": 1, "heap_mib": 1536, "ram_option_mib": 2048,
        "minimum_mem_available_kib": 2621440,
        "observed_mem_available_kib": available_kib,
        "maximum_stdout_bytes": 64 * 1024**2,
        "maximum_stderr_bytes": 64 * 1024**2,
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_receipt_sha256": hashlib.sha256((ROOT / "evidence/SOURCE_IDENTITY.json").read_bytes()).hexdigest(),
        "bounded_process_sha256": hashlib.sha256(Path(__file__).with_name("bounded_process.py").read_bytes()).hexdigest(),
        "concurrent_compiles_started_by_this_task": 0,
    }
    if available_kib < 2621440:
        record["status"] = "not_started_memory_below_declared_minimum"
        (ROOT / "evidence/COMPILE_MEMORY_HOLD.json").write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(record, indent=2), flush=True)
        return 2
    (ROOT / "evidence/COMPILE_STARTED.json").write_text(json.dumps(record, indent=2) + "\n")
    started = time.monotonic()
    with (ROOT / "summary-stage34-all.ra").open("xb") as stdout, (ROOT / "compile.stderr").open("xb") as stderr:
        try:
            outcome = capture_output(
                command, timeout_seconds=180,
                maximum_stdout_bytes=record["maximum_stdout_bytes"],
                maximum_stderr_bytes=record["maximum_stderr_bytes"],
                stdout_sink=stdout.write, stderr_sink=stderr.write,
                environment=dict(os.environ),
            )
            record.update(status="completed", exit_code=outcome.returncode)
        except BoundedProcessError as error:
            record.update(status="supervisor_failure", error_kind=error.kind,
                          error=str(error), cleanup_ambiguous=getattr(error, "cleanup_ambiguous", None))
    record["wall_seconds"] = time.monotonic() - started
    record["completed_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record["files"] = {}
    for name in ("summary-stage34-all.ra", "compile.stderr"):
        data = (ROOT / name).read_bytes()
        record["files"][name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    (ROOT / "evidence/COMPILE.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)
    return 0 if record.get("exit_code") == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
