#!/usr/bin/env python3
"""Read one new fixture execution against the two retained complete baselines."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT.parent
PREVIOUS = BASE / "summary-env-validation-20261111"


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def inventory(root):
    return {str(p.relative_to(root)): identity(p) for p in sorted(root.rglob("*")) if p.is_file()}


def read_json(path):
    def pairs(items):
        d = {}
        for key, value in items:
            if key in d:
                raise ValueError("duplicate key " + key)
            d[key] = value
        return d
    return json.loads(path.read_text(), object_pairs_hook=pairs)


def relation_readback(log):
    found = {}
    loads, compiles = [], []
    with log.open() as stream:
        for line in stream:
            if "[PROGRESS] execute queries> [1/1] Loaded " in line:
                loads.append(line.rstrip())
            if "Compiling query plan" in line:
                compiles.append(line.rstrip())
            if " >>> Created relation " not in line or " rows and digest " not in line:
                continue
            for stage in (3, 4):
                for relation in ("fwdFlowRead/11", "fwdFlowReadTarget/6"):
                    if f"Stage{stage}::{relation}#" not in line:
                        continue
                    rows, digest = line.split(" with ", 1)[1].split(" rows and digest ", 1)
                    key = f"Stage{stage}::{relation}"
                    assert key not in found
                    found[key] = {"rows": int(rows), "digest": digest.strip().removesuffix("."), "line": line.rstrip()}
    return {"relations": found, "loads": loads, "implicit_compiles": compiles}


def main():
    result = {
        "kind": "qperiapt.stage3_stage4_nonempty_fixture_comparison",
        "status": "complete_equal_nonempty_results",
        "new_evaluations": 1,
        "retained_baselines_rerun": False,
        "comparison_method": "Full decoded JSON equality, retaining all result sets, column descriptors, ordered rows, values and multiplicity.",
        "timing_scope": "Elapsed time records this new execution. The original two arms ran with another analysis active; this execution followed that analysis's termination. These observations are not a controlled speed comparison.",
    }
    new_output = ROOT / "evidence/decode-stage34/stdout.log"
    decoded = read_json(new_output)
    baselines = {}
    for mode in ("all", "projection"):
        old = PREVIOUS / "evidence" / ("decode-" + mode) / "stdout.log"
        assert read_json(old) == decoded
        log = next((PREVIOUS / "arms" / mode / "logs").glob("*.log"))
        baselines[mode] = {
            "decoded": identity(old),
            "bqrs": identity(PREVIOUS / "arms" / mode / "results/codeql/rust-queries/queries/summary/SummaryStats.bqrs"),
            "evaluator_log": identity(log),
            "readback": relation_readback(log),
        }
    log = next((ROOT / "fixture/logs").glob("*.log"))
    new = relation_readback(log)
    assert len(new["loads"]) == 1 and not new["implicit_compiles"]
    assert str(ROOT / "candidate-query-pack/queries/summary/SummaryStats.qlx") in new["loads"][0]
    for stage in (3, 4):
        full = f"Stage{stage}::fwdFlowRead/11"
        target = f"Stage{stage}::fwdFlowReadTarget/6"
        assert new["relations"][target]["rows"] > 0
        for baseline in baselines.values():
            assert (new["relations"][full]["rows"], new["relations"][full]["digest"]) == (
                baseline["readback"]["relations"][full]["rows"], baseline["readback"]["relations"][full]["digest"])
    capsule = read_json(ROOT / "evidence/CANDIDATE_CAPSULE.json")
    pack = ROOT / "candidate-query-pack"
    original = PREVIOUS / "original-pack"
    expected = inventory(original)
    expected.update(capsule["files"])
    library = ".codeql/libraries/codeql/dataflow/2.1.15/codeql/dataflow/internal/DataFlowImpl.qll"
    source = read_json(ROOT / "evidence/SOURCE_IDENTITY.json")
    expected[library] = source["candidate_source"]
    assert inventory(pack) == expected
    initial_db = json.loads(gzip.decompress((PREVIOUS / "evidence/INITIAL_DATABASE_FILES.json.gz").read_bytes()))
    changed = []
    for name, before in initial_db.items():
        after = identity(ROOT / "fixture/database" / name)
        if after != before:
            changed.append(name)
    assert all(name.startswith("db-rust/default/cache/") for name in changed)
    evaluation = read_json(ROOT / "evidence/evaluate-stage34/RESULT.json")
    decode = read_json(ROOT / "evidence/decode-stage34/RESULT.json")
    assert evaluation["exit_code"] == decode["exit_code"] == 0
    assert evaluation["status"] == decode["status"] == "completed"
    assert evaluation["wall_seconds"] < 300
    values = dict(decoded["#select"]["tuples"])
    assert values["Taint sources - active"] > 0 and values["Taint reach - nodes tainted"] > 0
    result.update(
        complete_results_equal_to_both_baselines=True,
        semantic_sha256=hashlib.sha256(json.dumps(decoded, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        result_sets={name: {"columns": value["columns"], "row_count": len(value["tuples"])} for name, value in decoded.items()},
        summary_values=values,
        evaluation_exit_code=evaluation["exit_code"],
        evaluation_wall_seconds=evaluation["wall_seconds"],
        decoded=identity(new_output),
        bqrs=identity(ROOT / "fixture/results/codeql/rust-queries/queries/summary/SummaryStats.bqrs"),
        evaluator_log=identity(log),
        compiled_plan_key=capsule["compiler_inputs_digest"],
        current_readback=new,
        retained_baselines=baselines,
        full_read_rows_and_digests_preserved_in_both_stages=True,
        complete_query_pack_postexecution_files=len(expected),
        complete_query_pack_matches_only_declared_source_and_capsule_changes=True,
        immutable_initial_database_files_unchanged=sum(not name.startswith("db-rust/default/cache/") for name in initial_db),
        changed_initial_database_files_only_evaluator_cache=changed,
    )
    (ROOT / "evidence/FIXTURE_COMPARISON.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    lines = new["loads"] + [v["line"] for v in new["relations"].values()]
    (ROOT / "evidence/FIXTURE_EVALUATOR_EXCERPTS.txt").write_text("\n".join(lines) + "\n")
    print(json.dumps({"status": result["status"], "rows": len(decoded["#select"]["tuples"]), "semantic_sha256": result["semantic_sha256"], "wall_seconds": evaluation["wall_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
