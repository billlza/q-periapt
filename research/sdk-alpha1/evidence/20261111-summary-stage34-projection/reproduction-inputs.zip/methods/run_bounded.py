#!/usr/bin/env python3
"""Run one declared local fixture step with preserved bounded diagnostics."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from bounded_process import BoundedProcessError, capture_output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--timeout", type=int, required=True)
    parser.add_argument("--cwd", type=Path, required=True)
    parser.add_argument("--rust-toolchain-bin", type=Path)
    parser.add_argument("--sysroot", type=Path)
    parser.add_argument("--sysroot-src", type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    root = Path(__file__).resolve().parent.parent
    destination = root / "evidence" / args.name
    destination.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    rust = args.rust_toolchain_bin or root.parent / "rustix-paper-toolchain/install/bin"
    env["PATH"] = str(rust) + os.pathsep + env.get("PATH", "")
    env["CARGO_NET_OFFLINE"] = "true"
    extractor_environment = {}
    for argument, name in ((args.sysroot, "CODEQL_EXTRACTOR_RUST_SYSROOT"),
                           (args.sysroot_src, "CODEQL_EXTRACTOR_RUST_SYSROOT_SRC")):
        if argument is not None:
            extractor_environment[name] = str(argument.resolve())
    env.update(extractor_environment)
    record = {
        "kind": "qperiapt.local_env_fixture_step",
        "name": args.name,
        "command": command,
        "cwd": str(args.cwd.resolve()),
        "supervisor_timeout_seconds": args.timeout,
        "maximum_stdout_bytes": 64 * 1024 * 1024,
        "maximum_stderr_bytes": 64 * 1024 * 1024,
        "rust_toolchain_bin": str(rust),
        "cargo_net_offline": True,
        "extractor_environment": extractor_environment,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "bounded_process_sha256": hashlib.sha256(
            Path(__file__).with_name("bounded_process.py").read_bytes()
        ).hexdigest(),
    }
    (destination / "STARTED.json").write_text(json.dumps(record, indent=2) + "\n")
    os.chdir(args.cwd)
    started = time.monotonic()
    with (destination / "stdout.log").open("wb") as stdout, (
        destination / "stderr.log"
    ).open("wb") as stderr:
        try:
            result = capture_output(
                command,
                timeout_seconds=args.timeout,
                maximum_stdout_bytes=record["maximum_stdout_bytes"],
                maximum_stderr_bytes=record["maximum_stderr_bytes"],
                stdout_sink=stdout.write,
                stderr_sink=stderr.write,
                environment=env,
            )
            record.update(status="completed", exit_code=result.returncode)
        except BoundedProcessError as error:
            record.update(
                status="supervisor_failure",
                error_kind=error.kind,
                error=str(error),
                cleanup_ambiguous=getattr(error, "cleanup_ambiguous", None),
            )
    record["wall_seconds"] = time.monotonic() - started
    record["completed_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    record["streams"] = {
        name: {
            "bytes": (destination / name).stat().st_size,
            "sha256": hashlib.sha256((destination / name).read_bytes()).hexdigest(),
        }
        for name in ("stdout.log", "stderr.log")
    }
    (destination / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)
    return 0 if record.get("exit_code") == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
