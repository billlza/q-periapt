from pathlib import Path
import hashlib, json, os, subprocess, sys, time
import continuity_c_enrollment as enrollment

b=Path(__file__).resolve().parent;root=b.parents[1]
label,profile,generation=sys.argv[1:]
assert profile in ('debug','release')
output=b/label;output.mkdir(mode=0o700)
report_path=root/'target/policy-recovery-ffi-current/source/target/continuity-retirement-ce70bf83/CONTINUITY_PACKAGE.json'
old=json.loads(report_path.read_text());assert old['completed'] and old['sources_unchanged'] and old['source_commit']=='ce70bf83a6f131b6727b67e9c9a4b8266abe72ef'
old_binaries=old['c_consumer']['execution'][profile]['binaries']
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(report_path)=='f98598c1e77096785a3b5c7fc3e868cc642740c0d06329f9d503c658a57bf1a2'
old_client=Path(old_binaries['C_client']['path']);old_library=Path(old_binaries['C_library']['path'])
assert all(sha(Path(old_binaries[k]['path']))==old_binaries[k]['sha256'] for k in ('C_client','C_library'))
symbols=subprocess.check_output(['/usr/bin/nm','-gU',str(old_library)],text=True)
exports=[line.split()[-1] for line in symbols.splitlines() if line.split() and line.split()[-1].startswith('_qpc_')]
assert len(exports)==119 and '_qpc_device_v1_prepare_publication' not in exports
client=b/'successor-publication-c-client-build-04'/profile/'qpc-c-client'
library=b/('swift-publication-installed-native-'+profile)/'libq_periapt_continuity_c_consumer.dylib'
build=b/('v22-reader-build-'+profile+'-'+generation)
assert json.loads((build/'RESULT.json').read_text())['returncode']==0
rows=[json.loads(line) for line in (build/'stdout.log').read_text().splitlines()]
paths=[Path(row['executable']) for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']=='enrollment' and row.get('executable')]
assert len(paths)==1;harness=paths[0]
inputs={str(path):sha(path) for path in (client,library,old_client,old_library,harness)}
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON'))}
env.update(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',QPERIAPT_C_OWNER_CLIENT=str(client),QPERIAPT_V21_CLIENT=str(old_client),QPERIAPT_PUBLIC_SERVICE_EVIDENCE=str(output/'evidence'))
command=[str(harness),'--exact',enrollment.PUBLICATION_TEST,'--nocapture'];started=time.monotonic()
with (output/'stdout.log').open('wb') as stdout,(output/'stderr.log').open('wb') as stderr:
    process=subprocess.run(command,cwd=b/'v22-reader-consumer',env=env,stdout=stdout,stderr=stderr,timeout=300)
result=dict(command=command,returncode=process.returncode,seconds=time.monotonic()-started,
    binaries=inputs,binaries_unchanged=all(sha(Path(path))==digest for path,digest in inputs.items()),
    old_source=old['source_commit'],old_report_sha256=sha(report_path),old_exports=exports,
    old_loader=subprocess.check_output(['/usr/bin/otool','-L',str(old_client)],text=True),
    scope='Actual pinned prior v21-only C executable/library against one freshly created installation. Control admits v21, then current publication upgrades the same image, old reader must return QPC_CORRUPT for Prepared and Retired publication states without changing logical records, wrapping/signer bytes, unopened archives or namespace; physical redb metadata changes are separately recorded, and the current client retries original bytes and continues its normal workload.')
(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('binaries','old_exports','old_loader')}),flush=True)
if process.returncode:print((output/'stderr.log').read_text()[-4000:],flush=True)
assert result['binaries_unchanged'];process.check_returncode()
stdout=(output/'stdout.log').read_text()
assert stdout.count('V21_READER stage=before tag=QPVLT021 accepted_control=true rejected_209=false protected_records_unchanged=true')==1
for stage in ('prepared','retired'):
    assert stdout.count('V21_READER stage='+stage+' tag=QPVLT022 accepted_control=false rejected_209=true protected_records_unchanged=true')==1
    assert any(line.startswith('V21_READER_METADATA stage='+stage+' ') and line.endswith('logical_tables_unchanged=4 key_files_unchanged=true archives_bytes_unchanged=true namespace_unchanged=true') for line in stdout.splitlines())
checked=enrollment.export(stdout.encode(),output/'evidence',output/'public-readback',language='C',publication=True)
(output/'VERIFIED.json').write_text(json.dumps(checked,indent=2)+'\n')
for name in ('before','prepared','retired'):
    for stream in ('stdout','stderr'):
        data=(output/'evidence/enrolled'/f'v21-reader-{name}.{stream}').read_bytes()
        (output/f'old-reader-{name}.{stream}').write_bytes(data)
print('Actual v21 acceptance, v22 refusal and unchanged-state/current retry controls passed.',flush=True)
