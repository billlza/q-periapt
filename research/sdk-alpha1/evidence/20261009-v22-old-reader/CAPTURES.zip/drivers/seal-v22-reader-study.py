from pathlib import Path
import hashlib, json, zipfile, datetime, shutil

b=Path(__file__).resolve().parent;root=b.parents[1]
out=root/'research/sdk-alpha1/evidence/20261009-v22-old-reader'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
study=json.loads((b/'V22_READER_STUDY.json').read_text())
probe=b/'v22-reader-consumer/tests/enrollment.rs'
assert sha(probe)==study['fixture_probe_sha256']
assert sha(root/'bindings/c/ContinuityPackageConsumer/tests/enrollment.rs')==study['fixture_base_sha256']
files={};profiles={}
for profile in ('debug','release'):
    label='v22-reader-runtime-'+profile+'-06';directory=b/label
    run=json.loads((directory/'RESULT.json').read_text());readback=json.loads((directory/'VERIFIED.json').read_text())
    assert run['returncode']==0 and run['binaries_unchanged'] and readback['completed']
    assert all(sha(Path(path))==digest for path,digest in run['binaries'].items())
    text=(directory/'stdout.log').read_text()
    for stage in ('before','prepared','retired'):
        expected='V21_READER stage='+stage+' tag='+('QPVLT021 accepted_control=true rejected_209=false' if stage=='before' else 'QPVLT022 accepted_control=false rejected_209=true')+' protected_records_unchanged=true'
        assert text.count(expected)==1
        if stage!='before':
            assert any(line.startswith('V21_READER_METADATA stage='+stage+' ') and line.endswith('logical_tables_unchanged=4 key_files_unchanged=true archives_bytes_unchanged=true namespace_unchanged=true') for line in text.splitlines())
    profiles[profile]={'run':run,'complete_original_workload':readback}
    for path in directory.iterdir():
        if path.is_file():files['runs/'+label+'/'+path.name]=path
    for path in (directory/'public-readback').rglob('*'):
        if path.is_file():files['public/'+profile+'/'+str(path.relative_to(directory/'public-readback'))]=path
    build='v22-reader-build-'+profile+'-06'
    result=json.loads((b/build/'RESULT.json').read_text());assert result['returncode']==0
    assert result['inputs']['tests/enrollment.rs']==sha(probe)
    for path in (b/build).iterdir():
        if path.is_file():files['builds/'+build+'/'+path.name]=path
assert json.loads((b/'v22-reader-clippy-02/RESULT.json').read_text())['returncode']==0
for label in ('v22-reader-clippy-02','v22-reader-runtime-debug-01','v22-reader-runtime-debug-02','v22-reader-runtime-debug-03','v22-reader-runtime-debug-04'):
    for path in (b/label).iterdir():
        if path.is_file():files['diagnostics/'+label+'/'+path.name]=path
for name in ('V22_READER_STUDY.json','V22_READER_PATCH.diff','V22_REDB_CLOSE_SOURCE.txt','V22_REDB_CLOSE_SOURCE.json'):
    files['study/'+name]=b/name
files['study/enrollment.rs']=probe
redb=Path(json.loads((b/'V22_REDB_CLOSE_SOURCE.json').read_text())['file']).parents[1]
for name in ('LICENSE-MIT','LICENSE-APACHE'):files['study/redb-'+name]=redb/name
for name in ('run-v22-reader-build.py','run-v22-reader-runtime.py','seal-v22-reader-study.py'):files['drivers/'+name]=b/name
out.mkdir()
with zipfile.ZipFile(out/'CAPTURES.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
with zipfile.ZipFile(out/'CAPTURES.zip') as archive:
    assert archive.testzip() is None and all(hashlib.sha256(archive.read(name)).hexdigest()==sha(path) for name,path in files.items())
record=dict(schema_version=1,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    current_source='f9ae04b992ae1e80dba4d1278f50a02ea86367a2',old_source='ce70bf83a6f131b6727b67e9c9a4b8266abe72ef',
    isolated_probe=study,profiles=profiles,clippy='passed --test enrollment -- -D warnings',
    captures=dict(file='CAPTURES.zip',sha256=sha(out/'CAPTURES.zip'),bytes=(out/'CAPTURES.zip').stat().st_size,members=len(files)),
    observed={'old_admits_original_v21':True,'old_refuses_prepared_v22_with_209':True,'old_refuses_retired_floor_v22_with_209':True,
              'all_four_user_table_transcripts_unchanged':True,'wrapping_and_signer_bytes_unchanged':True,
              'namespace_unchanged':True,'unopened_archives_bytes_unchanged_on_refusal':True,
              'whole_database_files_unchanged':False,'current_original_retry_and_normal_traffic_passed':True},
    hypothesis_correction='Whole-file immutability was an overstrong initial hypothesis. Actual old-reader rejection changes physical bytes of the four opened redb databases; redb4.3.0 closes by committing allocator metadata. All user key/value transcripts were compared and remained identical. The admitted v21 control also opens archives and changes its physical metadata. Diagnostic debug04 had an inaccurate baseline archive label; final debug/release06 traces correct it explicitly.',
    scope='Live macOS arm64 process/format compatibility using actual pinned old executables and libraries. No old binary recompilation, protocol/production code change, query suppression, crash/power-loss, physical erasure or general future-schema compatibility claim.',
    release_claim_eligible=False)
(out/'QUALIFICATION.json').write_text(json.dumps(record,indent=2)+'\n')
preflight=root/'research/sdk-alpha1/evidence/20261009-successor-owned-publication'
for source,target in [('PREFLIGHT_F9AE04B9.json','PREFLIGHT.json'),('PREFLIGHT_F9AE04B9.zip','PREFLIGHT.zip')]:
    with (preflight/target).open('xb') as stream:stream.write((b/source).read_bytes())
print(json.dumps(record['captures']))
