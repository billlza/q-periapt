from pathlib import Path
import hashlib,json,zipfile
import rust_sdk_profile as sdk
root=Path.cwd();stage=root/'target/continuity-browser-rekey';package=root/'target/continuity-browser-publication/source/target/rekey-package-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
overlay=json.loads((stage/'SOURCE_OVERLAY.json').read_text())
for n,d in overlay['overlay'].items():assert sha(root/n)==d,n
reports={n:json.loads((stage/n/'RESULT.json').read_text()) for n in ['run-01','run-02','base-01']}
assert all(r['completed'] for r in reports.values())
assert len(reports['run-01']['cases'])==1 and len(reports['run-02']['cases'])==6
for n,r in [(n,reports[n]) for n in ['run-01','run-02']]:
 for binary,d in r['native'].items():assert sha(Path(binary))==d,binary
 for c in r['cases']:
  assert [v['epoch'] for v in c['rekeys']]==['1','2']
  assert len(c['native_control'])==4 and c['native_control'][-1]['done'] and c['native_control'][-1]['epoch']==3
  assert c['delivery']=={'consumption':1,'status':3} and c['reverse']['authenticated_browser_consumption'] and c['reverse']['same_original_wire']
  assert bytes(c['message'])[:8]==bytes(c['reverse']['message'])[:8]==(3).to_bytes(8,'big')
  if c['case'] not in ['happy','control-limit']:
   records=c['peer_records'];faults=[i for i,v in enumerate(records) if v['trigger']];assert len(faults)==1
   i=faults[0];original=records[i];retry=next(v for v in records[i+1:] if v['kind']==4)
   assert original['request_sha256']==retry['request_sha256'],'browser control replay changed original'
   if c['case']=='control-drop-final':
    frame=stage/n/'peer'/c.get('key',n+'-'+c['case'])/f"{original['number']:03}"/'request.bin'
    assert frame.read_bytes()[13:21]==b'QPRKFN01','fault did not cut the final flight'

assert json.loads((package/'sources-before.json').read_text())==json.loads((package/'sources-after.json').read_text())
receipt=json.loads((package/'INSTALLED_CONSUMER.json').read_text());assert sha(package/'q-periapt-sdk-wasm-0.2.0.tgz')==receipt['sha256']
members={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in members
 assert not any(v.endswith('-private') or v.startswith('private-') for v in p.parts),p
 members[name]=p
for n in ['SOURCE_OVERLAY.json','base-browser.py','run-sessions.py','server.py','controller.js','session-worker.js','session-checks.js','build-package.sh','check-native-msrv.sh','seal.py']:add(stage/n,'driver/'+n)
for n in ['Cargo.toml','Cargo.lock','src/main.rs']:add(stage/'native-peer'/n,'native-peer/'+n)
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.log','.stdout','.stderr'] and not p.name.startswith('seal'):add(p,'commands/'+p.name)
for n in ['INSTALLED_CONSUMER.json','sources-before.json','sources-after.json','build-web.json','build-nodejs.json','typescript.json']:add(package/n,'package/'+n)
for n in ['run-01','run-02','base-01']:
 add(stage/n/'RESULT.json',n+'/RESULT.json')
 if (stage/n/'logs').exists():
  for p in sorted((stage/n/'logs').iterdir()):
   if p.is_file():add(p,n+'/logs/'+p.name)
for folder in ['captures','peer','native','witness']:
 for p in sorted((stage/'run-01'/folder).rglob('*')):
  if p.is_file():add(p,'run-01/'+p.relative_to(stage/'run-01').as_posix())
for p in sorted((stage/'run-01').glob('*-reply.bin')):add(p,'run-01/'+p.name)
for n in overlay['overlay']:add(root/n,'source/'+n)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(members.items())}
manifest_bytes=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
dest=root/'research/sdk-alpha1/evidence/20261013-browser-session-rekey';dest.mkdir()
archive=dest/'CAPTURE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):z.write(p,n)
 z.writestr('MANIFEST.json',manifest_bytes)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)==manifest[n]['sha256']
checks={'completed':True,'release_claim_eligible':False,'source':overlay,
 'package':{k:receipt[k] for k in ['sha256','manifest_sha256','source_bound','sources_unchanged','typescript']},
 'capture':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members)+1,'member_manifest':'MANIFEST.json','member_manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest()},
 'scope':'Installed Chrome dedicated Workers with OPFS/IndexedDB, required signed witness and bidirectional native/browser rekey, same shared engine and loopback diagnostics; not independent implementation, deployment, arbitrary schedules or PCS proof.',
 'cases':{n:[{'case':c['case'],'rejection':c.get('control_rejected'),'rekeys':c['rekeys'],'native_control':c['native_control'],'witness_requests':len(c['witness_records']),'peer_requests':len(c['peer_records']),'bidirectional_epoch':3} for c in r['cases']] for n,r in reports.items() if n!='base-01'},
 'validation':{'core_tests':11,'new_control_tests':4,'new_control_transport_loss_cuts':10,'existing_control_tls_tests':9,'base_installed_browser_cases':10,'artifact_controls':53,'tracked_rust_files':612,'native_clippy':'control-tls,connection-tls lib/tests -D warnings passed','product_wasm_clippy':'-D warnings passed','product_wasm_msrv':'Rust1.90.0 passed','native_control_msrv':'Rust1.90.0 passed'},
 'fixture_authority':'research/sdk-alpha1/evidence/20261013-browser-required-witness',
 'excluded':['private keys/wrapping material/journals/browser profiles','independent implementation and cross-host or HTTPS/CORS deployment','full browser/version/device matrix','PCS recovery proof, root/roster renewal, migration and full release approval']}
sdk.write_json(dest/'CHECKS.json',checks)
print(json.dumps(checks['capture']))
