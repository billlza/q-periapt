"""Separate traffic-key and fresh-payload deduction from the leak conditions."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
sdk.require(json.loads((stage / 'origin-prior-09-TERMINAL.json').read_text())['accepted'], 'causal root origin unverified')
base = (stage / 'origin-prior-09-proof.spthy').read_text()
lemmas = '''lemma traffic_key_derivation_requires_prior_root [use_induction,reuse]:
 "All s role root transcript #known.
    KU(h(<'traffic',s,role,root,transcript>))@known
    ==> (Ex #prior. KU(root)@prior & prior < known)"
by sorry

lemma message_derivation_requires_prior_traffic_key [use_induction,reuse]:
 "All s role key payload #sent #known.
    Message(s,role,key,payload)@sent & KU(payload)@known
    ==> (Ex #prior. KU(key)@prior & prior < known)"
by sorry

'''
marker = 'lemma response_confirmation_has_origin_or_prior_root'
sdk.require(base.count(marker) == 1, 'insertion ambiguous')
variant = base.replace(marker, lemmas + marker)
with (stage / 'traffic-11.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'TRAFFIC_11.json', {
    'input_sha256': sdk.snapshot(stage / 'traffic-11.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'origin-prior-09-proof.spthy').sha256,
    'new_obligations_precede_other_helpers': True,
    'operational_model_unchanged': True, 'new_disclosure_restrictions': False,
    'main_secrecy_verified': False, 'release_claim_eligible': False,
})
