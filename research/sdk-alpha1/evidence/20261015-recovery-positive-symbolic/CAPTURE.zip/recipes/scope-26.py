"""Keep independent proof groups from instantiating unrelated reusable lemmas."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
text = (stage / 'composed-16.spthy').read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
matches = list(decl.finditer(text))
blocks = {m.group(1): (m, text[m.start():matches[i+1].start() if i+1<len(matches) else text.rfind('\nend')]) for i,m in enumerate(matches)}
prior = json.loads((root / 'target/continuity-recovery-root-composition-20261015/CERTIFIED_22.json').read_text())['verified_obligations']
old_names = [name for name in blocks if name in prior]
new_names = [name for name in blocks if name not in prior][:5]
sdk.require(new_names == ['traffic_key_derivation_requires_prior_root', 'message_derivation_requires_prior_traffic_key', 'response_confirmation_has_origin_or_prior_root', 'computed_root_identifies_session', 'accepted_root_has_origin_or_prior_derivation'], 'new group inventory differs')
hidden = [name for name in old_names if 'reuse' in (blocks[name][0].group(2) or '').split(', ')]
sdk.require(len(hidden) == 7, 'prior reusable inventory differs')
out = text[:matches[0].start()] + ''.join(blocks[name][1] for name in old_names)
for name in new_names:
    match, block = blocks[name]
    header = block[:block.index(':')]
    sdk.require(header.endswith(']'), 'annotation block missing')
    replacement = header[:-1] + ', ' + ', '.join('hide_lemma=' + value for value in hidden) + ']'
    out += replacement + block[len(header):]
out += ''.join(block for name, (_, block) in blocks.items() if name not in old_names + new_names) + '\nend\n'
rows = {m.group(1): m for m in decl.finditer(out)}
sdk.require(set(rows) == set(blocks), 'property inventory changed')
for name, (match, _) in blocks.items():
    sdk.require(re.search(r'"[^"]*"', match.group()).group() == re.search(r'"[^"]*"', rows[name].group()).group(), 'property formula changed')
    if name not in new_names:
        sdk.require(match.group() == rows[name].group(), 'non-target declaration changed')
with (stage / 'scoped-26.spthy').open('x') as output:
    output.write(out)
sdk.write_json(stage / 'SCOPING_26.json', {
    'input_sha256': sdk.snapshot(stage / 'scoped-26.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'composed-16.spthy').sha256,
    'original_eight_checked_first': old_names,
    'hidden_from_each_new_property': hidden,
    'new_property_order': new_names,
    'all_formulas_unchanged': True, 'original_five_complete_declarations_unchanged': True,
    'no_model_or_threat_change': True, 'all_thirteen_still_required_verified': True,
    'source': 'https://tamarin-prover.com/manual/master/book/007_property-specification.html#lemma-annotations',
    'release_claim_eligible': False,
})
