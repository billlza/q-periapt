"""Compose checked causal dependencies and isolate the final message-link search."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def blocks(text):
    matches = list(decl.finditer(text))
    return matches, {m.group(1): (m, text[m.start():matches[i+1].start() if i+1<len(matches) else text.rfind('\nend')]) for i,m in enumerate(matches)}
def scoped(block, hidden):
    header = block[:block.index(':')]
    sdk.require(header.endswith(']'), 'proof annotations missing')
    return header[:-1] + ', ' + ', '.join('hide_lemma=' + name for name in hidden) + ']' + block[len(header):]
base = (stage / 'composed-17-proof.spthy').read_text()
sdk.require(json.loads((stage / 'composed-17-TERMINAL.json').read_text())['accepted'], 'base group incomplete')
matches, current = blocks(base)
root_name = 'computed_root_derivation_requires_session_leak'
constructor_name = 'root_constructor_requires_prior_coins_or_snapshot'
encap_name = 'encapsulation_derivation_requires_session_leak'
root_result = json.loads((stage / 'derived-root-42-TERMINAL.json').read_text())
sdk.require(root_result['results'][root_name] == {'status': 'verified', 'steps': 20} and not root_result['accepted'], 'conditional root proof differs')
_, constructor = blocks((stage / 'root-constructor-40-proof.spthy').read_text())
_, derived = blocks((stage / 'derived-root-42-proof.spthy').read_text())
_, old_message = blocks((root / 'target/continuity-recovery-crypto-provenance-20261015/message-20.spthy').read_text())
message_name = 'message_derivation_requires_session_leak'
before = [name for name, (match, _) in current.items()
          if match.start() < current[root_name][0].start()
          and 'reuse' in {value.strip() for value in (match.group(2) or '').split(',')}]
sdk.require(len(before) == 12, 'prior reusable inventory differs')
constructor_block = scoped(constructor[constructor_name][1], before)
root_block = scoped(derived[root_name][1], [name for name in before if name != encap_name])
message_dependencies = {'traffic_key_derivation_requires_prior_root', 'message_derivation_requires_prior_traffic_key', 'message_root_has_authenticated_origin', root_name}
message_block = old_message[message_name][0].group() + '\nby sorry\n\n'
message_block = scoped(message_block, [name for name in before + [constructor_name, root_name] if name not in message_dependencies])
out = base[:matches[0].start()]
for name, (_, block) in current.items():
    if name == root_name:
        out += constructor_block + root_block + message_block
    else:
        out += block
out += '\nend\n'
with (stage / 'causal-base-43.spthy').open('x') as output:
    output.write(out)
new_matches = list(decl.finditer(out))
conditional = out[:new_matches[0].start()] + ''.join(m.group() + '\nby sorry\n\n' for m in new_matches) + 'end\n'
with (stage / 'message-link-43.spthy').open('x') as output:
    output.write(conditional)
sdk.require([m.group() for m in decl.finditer(out)] == [m.group() for m in decl.finditer(conditional)], 'conditional formula changed')
sdk.write_json(stage / 'CAUSAL_COMPOSITION_43.json', {
    'base_sha256': sdk.snapshot(stage / 'composed-17-proof.spthy').sha256,
    'full_input_sha256': sdk.snapshot(stage / 'causal-base-43.spthy').sha256,
    'conditional_input_sha256': sdk.snapshot(stage / 'message-link-43.spthy').sha256,
    'constructor_dependencies': [], 'root_dependencies': [encap_name, constructor_name],
    'message_dependencies': sorted(message_dependencies),
    'unused_reusable_lemmas_hidden_only_in_new_auxiliary_proofs': True,
    'original_five_complete_declarations_unchanged': True,
    'protocol_model_unchanged': True, 'all_dependencies_still_required_by_final_gate': True,
    'release_claim_eligible': False,
})
