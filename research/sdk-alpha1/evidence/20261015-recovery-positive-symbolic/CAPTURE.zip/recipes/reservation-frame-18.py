"""Anchor root induction at the fresh contribution rather than a later computation."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
sdk.require(json.loads((stage / 'traffic-12-TERMINAL.json').read_text())['accepted'], 'causal helpers unverified')
base = (stage / 'traffic-12-proof.spthy').read_text()
unique = '''lemma encapsulation_contribution_identifies_reservation [reuse]:
 "All s peer other other_peer coins #first #second.
    EncapsulationSecret(s,peer,coins)@first
  & EncapsulationSecret(other,other_peer,coins)@second
    ==> s = other & first = second"
by sorry

'''
frame = '''lemma reserved_contribution_root_requires_session_leak [use_induction,reuse]:
 "All s peer coins old digest #reserved #known.
    EncapsulationSecret(s,peer,coins)@reserved
  & KU(h(<'pending-root',old,coins,digest>))@known
    ==> (Ex role #x. IdentityLeak(s,role)@x)
      | (Ex kind #x. EntropyLeak(s,kind)@x)
      | (Ex revision #x. Snapshot(s,revision)@x)"
by sorry

'''
first = 'lemma traffic_key_derivation_requires_prior_root'
later = 'lemma computed_root_derivation_requires_session_leak'
sdk.require(base.count(first) == base.count(later) == 1, 'insertion ambiguous')
variant = base.replace(first, unique + first).replace(later, frame + later)
with (stage / 'reservation-frame-18.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'RESERVATION_FRAME_18.json', {
    'input_sha256': sdk.snapshot(stage / 'reservation-frame-18.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'traffic-12-proof.spthy').sha256,
    'root_constructor_unchanged': True, 'new_observer_or_state_change': False,
    'origin_or_prior_knowledge_helpers_present': True,
    'conditional_search_requires_complete_dependency_replay': True,
    'release_claim_eligible': False,
})
