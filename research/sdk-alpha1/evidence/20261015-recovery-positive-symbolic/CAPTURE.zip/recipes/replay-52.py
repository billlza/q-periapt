"""Run one bounded proof experiment and require all earlier reusable lemmas."""
from pathlib import Path
import json,os,re,signal,subprocess,sys,time
import rust_sdk_profile as sdk
root=Path.cwd();stage=Path(__file__).resolve().parent
filename,label,seconds,*selected=sys.argv[1:]
sdk.require(re.fullmatch(r'[a-z0-9-]+\.spthy',filename) is not None and re.fullmatch(r'[a-z0-9-]+',label) is not None,'invalid experiment identity')
limit=int(seconds);sdk.require(1<=limit<=900,'invalid time bound');source=stage/filename;sdk.require(source.is_file(),'missing model')
declarations=list(re.finditer(r'(?m)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:',source.read_text()))
inventory=[m.group(1) for m in declarations];sdk.require(len(inventory)==len(set(inventory)) and selected and set(selected)<=set(inventory),'invalid lemma selection')
required=set(selected)
for m in declarations:
 attrs={x.strip() for x in (m.group(2) or '').split(',')}
 if 'sources' in attrs or ('reuse' in attrs and any(inventory.index(m.group(1))<inventory.index(n) for n in selected)):required.add(m.group(1))
t=json.loads((root/'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text());output=stage/(label+'-proof.spthy');sdk.require(not output.exists(),'proof output exists')
argv=[t['tamarin'],'--with-maude='+t['maude'],str(source),'--heuristic=s','--derivcheck-timeout=60','--quit-on-warning','--output='+str(output),'--output-json='+str(stage/(label+'-traces.json')),'+RTS','-N2','-M12G','-s','-RTS']
start=time.monotonic();timed_out=False;output_exceeded=False
with (stage/(label+'.stdout')).open('xb') as out,(stage/(label+'.stderr')).open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 sdk.write_json(stage/(label+'-STARTED.json'),{'pid':p.pid,'argv':argv,'maximum_seconds':limit,'required_verified_lemmas':sorted(required),'input_sha256':sdk.snapshot(source).sha256})
 while p.poll() is None:
  timed_out=time.monotonic()-start>=limit;output_exceeded=max(out.tell(),err.tell())>32*1024**2
  if timed_out or output_exceeded:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   break
  time.sleep(0.2)
 code=p.wait(timeout=5)
summary=(stage/(label+'.stdout')).read_text().rsplit('summary of summaries:',1)[-1]
parsed=re.findall(r'^\s*(\w+) \((?:all-traces|exists-trace)\): (verified|falsified - found trace|analysis incomplete) \((\d+) steps\)',summary,re.M)
results={n:{'status':s,'steps':int(k)} for n,s,k in parsed}
accepted=code==0 and not timed_out and not output_exceeded and set(results)==set(inventory) and output.is_file() and all(results.get(n,{}).get('status')=='verified' for n in required)
sdk.write_json(stage/(label+'-TERMINAL.json'),{'argv':argv,'returncode':code,'timed_out':timed_out,'output_exceeded':output_exceeded,'elapsed_seconds':time.monotonic()-start,'results':results,'accepted':accepted,'required_verified_lemmas':sorted(required),'input_sha256':sdk.snapshot(source).sha256,'output_sha256':sdk.snapshot(output).sha256 if output.is_file() else None,'release_claim_eligible':False})
print(json.dumps({'label':label,'returncode':code,'timed_out':timed_out,'results':results,'accepted':accepted}),flush=True)
