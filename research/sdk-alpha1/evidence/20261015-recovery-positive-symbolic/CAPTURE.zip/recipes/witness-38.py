"""Check the single-identity-disclosure witness and its precise scope."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
initial = json.loads((stage / 'single-identity-witness-36-TERMINAL.json').read_text())
replay = json.loads((stage / 'single-identity-replay-37-TERMINAL.json').read_text())
name = 'compromised_responder_can_accept_known_root'
sdk.require(initial['accepted'] and replay['accepted'] and replay['results'][name]['status'] == 'verified', 'witness not replayed')
sdk.require(not any(arg.startswith('--prove') for arg in replay['argv']), 'replay requested search')
sdk.require(replay['input_sha256'] == initial['output_sha256'] == sdk.snapshot(stage / 'single-identity-witness-36-proof.spthy').sha256, 'witness identity differs')
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
texts = {}
for label, source in [('input', 'single-identity-witness-35.spthy'), ('certificate', 'single-identity-witness-36-proof.spthy'), ('replay', 'single-identity-replay-37-proof.spthy')]:
    texts[label] = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(stage / source), '--parse-only'], stage / ('witness-' + label + '-parse-38'), root).decode()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
rows = {label: {m.group(1): m.group() for m in decl.finditer(text)} for label, text in texts.items()}
sdk.require(rows['input'] == rows['certificate'] == rows['replay'] and next(iter(rows['input'])) == name, 'witness declarations or dependency order changed')
sdk.require(texts['certificate'].split('\nlemma ', 1)[0] == texts['replay'].split('\nlemma ', 1)[0]
            == (stage / 'complete-parse-30.stdout').read_text().split('\nlemma ', 1)[0], 'witness model differs')
graphs = json.loads((stage / 'single-identity-replay-37-traces.json').read_text())['graphs']
sdk.require(len(graphs) == 1, 'trace inventory differs')
nodes = graphs[0]['jgNodes']
acts = [(node, act) for node in nodes for act in node.get('jgnMetadata', {}).get('jgnActs', [])]
def tree(value):
    if 'jgnConst' in value:
        return ('constant', value['jgnConst'])
    sdk.require('jgnFunct' in value and 'jgnParams' in value, 'unexpected symbolic term')
    return (value['jgnFunct'], tuple(tree(arg) for arg in value['jgnParams']))
accepted = [(node, act) for node, act in acts if act['jgnFactName'] == 'AcceptedRoot']
leaks = [(node, act) for node, act in acts if act['jgnFactName'] == 'IdentityLeak']
known = [(node, act) for node, act in acts if node['jgnId'] == '#known' and act['jgnFactName'] == '!KU']
sdk.require(len(accepted) == len(leaks) == len(known) == 1, 'witness event counts differ')
session, secret = map(tree, accepted[0][1]['jgnFactTerms'])
sdk.require(list(map(tree, leaks[0][1]['jgnFactTerms'])) == [session, ('constant', "'B'")], 'disclosed identity differs')
sdk.require(tree(known[0][1]['jgnFactTerms'][0]) == secret, 'known and accepted roots differ')
sdk.require(not any(act['jgnFactName'] in ('ResponseRoot', 'EntropyLeak', 'Snapshot') for _, act in acts), 'unexpected root source or extra leak')
sdk.write_json(stage / 'WITNESS_38.json', {
    'completed': True, 'property': name,
    'initial_steps': initial['results'][name]['steps'], 'replay_steps': replay['results'][name]['steps'],
    'independent_replay_without_search': True, 'no_preceding_helper': True,
    'same_known_and_accepted_root': True, 'exactly_one_target_responder_identity_leak': True,
    'leak_rule': leaks[0][0]['jgnLabel'],
    'no_honest_response_root_computation': True, 'no_entropy_or_snapshot_leak': True,
    'trace_sha256': sdk.snapshot(stage / 'single-identity-replay-37-traces.json').sha256,
    'earlier_weaker_witness': 'Initial19/replay40 trace contained two disclosures of the same responder key; stronger witness restricts all identity-disclosure events to one target event.',
    'does_not_assert_application_decryption_or_sdk_attack': True,
    'does_not_contradict_positive_query_that_excludes_identity_disclosure': True,
    'release_claim_eligible': False,
})
print('Exactly one target responder identity disclosure precedes acceptance of the attacker-known root; independent trace verified')
