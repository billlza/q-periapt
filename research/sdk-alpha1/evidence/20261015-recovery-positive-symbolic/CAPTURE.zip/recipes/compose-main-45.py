"""Restore storage timing proofs and search the unchanged public recovery query."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def blocks(text):
    matches = list(decl.finditer(text))
    return matches, {m.group(1): (m, text[m.start():matches[i+1].start() if i+1<len(matches) else text.rfind('\nend')]) for i,m in enumerate(matches)}
def scoped(block, hidden):
    header = block[:block.index(':')]
    sdk.require(header.endswith(']'), 'annotation block missing')
    return header[:-1] + ', ' + ', '.join('hide_lemma=' + name for name in hidden) + ']' + block[len(header):]
base = (stage / 'causal-base-43.spthy').read_text()
matches, current = blocks(base)
_, message = blocks((stage / 'message-link-44-proof.spthy').read_text())
_, timing = blocks((root / 'target/continuity-recovery-secrecy-20261015/helpers-proof-04.spthy').read_text())
result = json.loads((stage / 'message-link-44-TERMINAL.json').read_text())
sdk.require(result['results']['message_derivation_requires_session_leak'] == {'status': 'verified', 'steps': 18}
            and not result['accepted'], 'conditional message result differs')
prior_reuse = []
out = base[:matches[0].start()]
scopes = {}
for name, (match, block) in current.items():
    if name == 'message_derivation_requires_session_leak':
        block = message[name][1]
    elif name in ('retained_record_has_saved_origin', 'stored_records_follow_fresh_reservations'):
        keep = {'retained_record_has_saved_origin'} if name == 'stored_records_follow_fresh_reservations' else set()
        hidden = [value for value in prior_reuse if value not in keep]
        block = scoped(timing[name][1], hidden)
        scopes[name] = sorted(keep)
    elif name == 'encapsulation_secret_requires_session_leak':
        keep = {'encapsulation_derivation_requires_session_leak'}
        block = scoped(block, [value for value in prior_reuse if value not in keep])
        scopes[name] = sorted(keep)
    out += block
    if 'reuse' in {value.strip() for value in (match.group(2) or '').split(',')}:
        prior_reuse.append(name)
out += '\nend\n'
new_matches = list(decl.finditer(out))
for original in matches:
    current_match = next(m for m in new_matches if m.group(1) == original.group(1))
    sdk.require(re.sub(r'\s+', '', re.search(r'"[^"]*"', original.group()).group())
                == re.sub(r'\s+', '', re.search(r'"[^"]*"', current_match.group()).group()), 'logical query changed')
with (stage / 'complete-base-45.spthy').open('x') as output:
    output.write(out)
conditional = out[:new_matches[0].start()] + ''.join(m.group() + '\nby sorry\n\n' for m in new_matches) + 'end\n'
with (stage / 'main-search-45.spthy').open('x') as output:
    output.write(conditional)
sdk.write_json(stage / 'MAIN_COMPOSITION_45.json', {
    'full_input_sha256': sdk.snapshot(stage / 'complete-base-45.spthy').sha256,
    'conditional_input_sha256': sdk.snapshot(stage / 'main-search-45.spthy').sha256,
    'storage_proofs_restored': {'retained_record_has_saved_origin': 13, 'stored_records_follow_fresh_reservations': 42},
    'auxiliary_scopes': scopes, 'all_formulas_unchanged': True,
    'public_recovery_formula_and_annotations_unchanged': True,
    'search_result_must_not_be_admitted_before_complete_replay': True,
    'release_claim_eligible': False,
})
