"""Expose the causal confirmation-tag obligation before root acceptance."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
sdk.require(json.loads((stage / 'unique-03-TERMINAL.json').read_text())['accepted'], 'root uniqueness unverified')
base = (stage / 'unique-03-proof.spthy').read_text()
lemma = '''lemma response_confirmation_has_origin_or_prior_root [use_induction,reuse]:
 "All s root digest ciphertext #known.
    KU(h(<'response-confirmation',root,<'response',s,digest,ciphertext>>))@known
    ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < known)
      | (Ex #prior. KU(root)@prior & prior < known)"
by sorry

'''
marker = 'lemma computed_root_identifies_session'
sdk.require(base.count(marker) == 1, 'insertion ambiguous')
variant = base.replace(marker, lemma + marker)
sdk.require(variant.split('\nlemma ', 1)[0] == base.split('\nlemma ', 1)[0], 'operational model changed')
with (stage / 'confirmation-06.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'CONFIRMATION_06.json', {
    'input_sha256': sdk.snapshot(stage / 'confirmation-06.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'unique-03-proof.spthy').sha256,
    'new_obligation_precedes_all_dependencies': True,
    'no_identity_entropy_snapshot_or_replication_restriction': True,
    'operational_model_unchanged': True, 'release_claim_eligible': False,
})
