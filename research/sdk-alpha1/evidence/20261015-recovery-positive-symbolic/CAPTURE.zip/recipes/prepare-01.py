"""Test root uniqueness and origin-or-prior-knowledge without restricting leaks."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
prior = root / 'target/continuity-recovery-root-composition-20261015'
base = (prior / 'authentication-04.spthy').read_text()
unique = '''lemma computed_root_identifies_session [reuse]:
 "All s other root #first #second.
    ResponseRoot(s,root)@first & ResponseRoot(other,root)@second
    ==> s = other"
by sorry

'''
origin = '''lemma accepted_root_has_origin_or_prior_derivation [use_induction,reuse]:
 "All s root #accepted.
    AcceptedRoot(s,root)@accepted
    ==> (Ex #computed. ResponseRoot(s,root)@computed & computed < accepted)
      | (Ex #known. KU(root)@known & known < accepted)"
by sorry

'''
first = 'lemma signing_secret_derivation_origin'
later = 'lemma computed_root_derivation_requires_session_leak'
sdk.require(base.count(first) == base.count(later) == 1, 'lemma insertion ambiguous')
variant = base.replace(first, unique + first).replace(later, origin + later)
sdk.require(variant.split('\nlemma ', 1)[0] == base.split('\nlemma ', 1)[0], 'operational model changed')
with (stage / 'isolation-01.spthy').open('x') as output:
    output.write(variant)
with (stage / 'run-02.py').open('x') as output:
    output.write((prior / 'run-02.py').read_text())
sdk.write_json(stage / 'INPUTS_01.json', {
    'base_commit': 'b75613fc05a4df028c3fa947574a8adee7d0faf8',
    'base_model_sha256': sdk.snapshot(prior / 'authentication-04.spthy').sha256,
    'input_sha256': sdk.snapshot(stage / 'isolation-01.spthy').sha256,
    'new_obligations': ['computed_root_identifies_session', 'accepted_root_has_origin_or_prior_derivation'],
    'new_observer_state_io_or_restriction': False,
    'identity_entropy_and_snapshot_disclosure_remain_unrestricted': True,
    'conditional_search_requires_later_complete_dependency_replay': True,
    'main_secrecy_verified': False, 'release_claim_eligible': False,
})
