"""Verify complete causal-proof dependencies, controls and final model identity."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
previous = json.loads((root / 'target/continuity-recovery-root-composition-20261015/CERTIFIED_22.json').read_text())['verified_obligations']
new = {'traffic_key_derivation_requires_prior_root': 142,
    'message_derivation_requires_prior_traffic_key': 352,
    'response_confirmation_has_origin_or_prior_root': 147,
    'computed_root_identifies_session': 2,
    'accepted_root_has_origin_or_prior_derivation': 8}
expected = {**previous, **new}
result = json.loads((stage / 'composed-17-TERMINAL.json').read_text())
control = json.loads((stage / 'missing-confirmation-28-TERMINAL.json').read_text())
reservation = json.loads((stage / 'reservation-replay-29-TERMINAL.json').read_text())
def verified(row):
    return {name: value['steps'] for name, value in row['results'].items() if value['status'] == 'verified'}
sdk.require(result['accepted'] and result['returncode'] == 0 and verified(result) == expected, 'complete group differs')
sdk.require(not any(arg.startswith('--prove') for arg in result['argv']), 'group replay requested search')
sdk.require(result['input_sha256'] == sdk.snapshot(stage / 'composed-16.spthy').sha256
            and result['output_sha256'] == sdk.snapshot(stage / 'composed-17-proof.spthy').sha256, 'group identity differs')
sdk.require(control['returncode'] == 0 and not control['accepted']
    and verified(control) == {name: steps for name, steps in new.items() if name != 'response_confirmation_has_origin_or_prior_root'}, 'missing-dependency control differs')
sdk.require(reservation['accepted'] and verified(reservation) == {'encapsulation_contribution_identifies_reservation': 2}
    and not any(arg.startswith('--prove') for arg in reservation['argv']), 'reservation replay differs')
sdk.require(reservation['input_sha256'] == sdk.snapshot(stage / 'reservation-unique-23-proof.spthy').sha256, 'reservation input changed')
semantics = json.loads((stage / 'SEMANTICS_25.json').read_text())
sdk.require(semantics['completed'] and semantics['inputs']['composed'] == result['input_sha256'], 'semantic identity differs')
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
texts = {}
for label, filename in [('complete', 'composed-17-proof.spthy'), ('reservation', 'reservation-replay-29-proof.spthy')]:
    texts[label] = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(stage / filename), '--parse-only'], stage / (label + '-parse-30'), root).decode()
before = (stage / 'composed-parse-25.stdout').read_text()
sdk.require([m.group() for m in decl.finditer(before)] == [m.group() for m in decl.finditer(texts['complete'])], 'complete declarations changed')
prefix = before.split('\nlemma ', 1)[0]
sdk.require(all(value.split('\nlemma ', 1)[0] == prefix for value in texts.values()), 'final model differs')
original = {m.group(1): m.group() for m in decl.finditer((stage / 'original-parse-25.stdout').read_text())}
reservation_decls = {m.group(1): m.group() for m in decl.finditer(texts['reservation'])}
sdk.require(all(reservation_decls[name] == value for name, value in original.items()), 'reservation copy changed original properties')
sdk.require(next(iter(reservation_decls)) == 'encapsulation_contribution_identifies_reservation', 'reservation query has dependencies')
sdk.write_json(stage / 'CERTIFIED_30.json', {
    'completed': True, 'verified_combined_obligations': expected,
    'new_causal_obligations': new,
    'certificate_sha256': result['output_sha256'],
    'independent_group_replay_without_search': True,
    'group_replay_seconds': result['elapsed_seconds'], 'group_heap_gib': 8,
    'missing_confirmation_dependency_rejected_despite_exit_zero': True,
    'separate_reservation_uniqueness_replayed_steps': 2,
    'final_models_and_original_five_declarations_unchanged': True,
    'new_observer_actions': 0, 'main_secrecy_verified': False,
    'release_claim_eligible': False,
})
print('Thirteen-property replay and separate reservation uniqueness verified; missing confirmation dependency rejected')
