"""Reject missing, weakened or newly restricted recovery models before proof admission."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
base = (stage / 'final-positive-49.spthy').read_text()
matches = list(decl.finditer(base))
main = 'clean_reservation_recovers_symbolic_message_secrecy'
i = next(i for i, match in enumerate(matches) if match.group(1) == main)
canonical = (root / 'research/continuity-recovery-symbolic/protected-state.spthy').read_text()
original = next(match.group() for match in decl.finditer(canonical) if match.group(1) == main)
needle = 'Ex r #x. IdentityLeak(s,r)'
sdk.require(original.count(needle) == 1, 'original identity condition changed')
stronger = original.replace(needle, 'Ex other r #x. IdentityLeak(other,r)')
mutations = {
    'missing-main': base[:matches[i].start()] + base[matches[i+1].start():],
    'forbid-other-identity-leaks': base[:matches[i].start()] + stronger + base[matches[i].end():],
    'forbid-all-snapshots': base[:matches[0].start()] + 'restriction DisableSnapshots:\n "not (Ex s revision #captured. Snapshot(s,revision)@captured)"\n\n' + base[matches[0].start():],
}
def parse(label, source):
    return sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
        str(source), '--parse-only'], stage / (label + '-parse-51'), root).decode()
def declarations(text):
    return {m.group(1): m.group() for m in decl.finditer(text)}
expected = parse('admission-base', stage / 'final-positive-49.spthy')
expected_queries = declarations(expected)
sdk.require(len(expected_queries) == 23, 'full property inventory differs')
original_queries = declarations((stage / 'original-parse-25.stdout').read_text())
sdk.require(len(original_queries) == 5 and all(expected_queries[name] == value for name, value in original_queries.items()), 'original five complete declarations changed')
results = {}
for label, text in mutations.items():
    path = stage / (label + '-51.spthy')
    with path.open('x') as output:
        output.write(text)
    parsed = parse(label, path)
    same_queries = declarations(parsed) == expected_queries
    same_prefix = parsed.split('\nlemma ', 1)[0] == expected.split('\nlemma ', 1)[0]
    sdk.require(not (same_queries and same_prefix), 'modified model admitted')
    results[label] = {'input_sha256': sdk.snapshot(path).sha256,
                     'parser_succeeded': True, 'same_complete_queries': same_queries,
                     'same_protocol_and_restriction_prefix': same_prefix, 'admitted': False}
conditional = json.loads((stage / 'main-search-48-TERMINAL.json').read_text())
sdk.require(conditional['returncode'] == 0 and conditional['results'][main]['status'] == 'verified'
            and not conditional['accepted'], 'conditional main result was incorrectly admitted')
sdk.write_json(stage / 'ADMISSION_CONTROLS_51.json', {
    'completed': True, 'base_input_sha256': sdk.snapshot(stage / 'final-positive-49.spthy').sha256,
    'original_five_complete_declarations_unchanged': True,
    'full_query_inventory': sorted(expected_queries), 'mutations': results,
    'main_verified_with_missing_dependencies_rejected_despite_exit_zero': True,
    'complete_group_still_requires_terminal_replay': True,
    'release_claim_eligible': False,
})
print('Deleted main theorem, forbidden other-session identity leaks and forbidden snapshots all rejected; conditional main remains unaccepted')
