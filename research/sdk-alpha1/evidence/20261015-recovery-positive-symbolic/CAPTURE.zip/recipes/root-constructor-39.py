"""Test causal provenance of the exact root constructor without a future-event guard."""
from pathlib import Path
import json
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
base = (stage / 'isolation-01.spthy').read_text()
lemma = '''lemma root_constructor_requires_prior_coins_or_snapshot [use_induction,reuse]:
 "All s old coins offer_hash ciphertext #known.
    KU(h(<'pending-root',old,coins,h(<'response',s,offer_hash,ciphertext>)>))@known
    ==> (Ex #prior. KU(coins)@prior & prior < known)
      | (Ex revision #captured. Snapshot(s,revision)@captured & captured < known)"
by sorry

'''
marker = 'lemma computed_root_identifies_session'
sdk.require(base.count(marker) == 1, 'insertion ambiguous')
variant = base.replace(marker, lemma + marker)
with (stage / 'root-constructor-39.spthy').open('x') as output:
    output.write(variant)
sdk.write_json(stage / 'ROOT_CONSTRUCTOR_39.json', {
    'input_sha256': sdk.snapshot(stage / 'root-constructor-39.spthy').sha256,
    'base_sha256': sdk.snapshot(stage / 'isolation-01.spthy').sha256,
    'exact_existing_root_constructor': True,
    'query_has_no_response_computation_or_reservation_event_guard': True,
    'new_query_precedes_all_helpers': True, 'all_other_proof_bodies_deferred': True,
    'no_disclosure_or_replication_restriction_added': True,
    'operational_model_unchanged': True, 'release_claim_eligible': False,
})
