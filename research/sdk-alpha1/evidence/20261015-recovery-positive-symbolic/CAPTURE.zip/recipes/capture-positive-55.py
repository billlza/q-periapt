"""Freeze the accepted symbolic recovery certificate and every failed approach."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
positive = json.loads((stage / 'POSITIVE_CERTIFIED_54.json').read_text())
sdk.require(positive['completed'] and positive['main_secrecy_verified'], 'positive theorem not admitted')
for name in ('CERTIFIED_30.json', 'SEMANTICS_25.json', 'ADMISSION_CONTROLS_51.json', 'WITNESS_38.json', 'CI_QUEUE_31.json'):
    sdk.require(json.loads((stage / name).read_text())['completed'], 'required evidence check incomplete')
sdk.require(positive['certificate_sha256'] == sdk.snapshot(stage / 'final-positive-53-proof.spthy').sha256, 'certificate changed')
groups = {int(line.split(None, 2)[1]) for line in subprocess.check_output(['ps', '-axo', 'pid=,pgid=,command='], text=True).splitlines() if len(line.split(None, 2)) == 3}
owned = {}
for path in sorted(stage.glob('*STARTED*.json')):
    row = json.loads(path.read_text())
    sdk.require(row['pid'] not in groups, 'owned process group still present')
    owned[path.name] = {'pid': row['pid'], 'process_group_absent': True}
sdk.write_json(stage / 'CLEANUP_55.json', {'completed': True, 'owned': owned})
sdk.write_json(stage / 'LATE_PREPARATION_NOTES_55.json', {
    'completed': True,
    'compose_main_45': 'Raw formula comparison rejected ASCII input versus Unicode closed-proof syntax before writing output. Fresh recipe47 uses the pinned parser; original formulas are equal. No main-search46 was run.',
    'proof_scoping': 'Only new auxiliary declarations use hide_lemma to omit irrelevant already-proved premises. All20 obligations remain required. Original five complete declarations and all protocol rules/restrictions remain unchanged.',
    'heap_retry': '8GiB full replay exited251 with explicit heap exhaustion after606 seconds. Identical input/proof methods at12GiB verifies all20 after335.9 seconds; no controlled performance claim.',
})
files = {}
def add(path, name):
    sdk.require(name not in files, 'duplicate archive member')
    files[name] = sdk.snapshot(path, maximum=32 * 1024**2).data
for path in sorted(stage.iterdir()):
    sdk.require(path.is_file(), 'unexpected evidence directory')
    sdk.require(path.suffix in ('.py', '.spthy', '.json', '.stdout', '.stderr'), 'unexpected evidence file')
    folder = 'proof' if path.suffix == '.spthy' else 'recipes' if path.suffix == '.py' else 'receipts'
    add(path, folder + '/' + path.name)
prior = root / 'target/continuity-recovery-root-composition-20261015'
for name in ('authentication-04.spthy', 'composed-13-proof.spthy', 'CERTIFIED_22.json'):
    add(prior / name, 'prior/' + name)
add(root / 'target/continuity-recovery-crypto-provenance-20261015/message-20.spthy', 'prior/message-20.spthy')
add(root / 'target/continuity-recovery-secrecy-20261015/helpers-proof-04.spthy', 'prior/helpers-proof-04.spthy')
add(root / 'target/continuity-recovery-disclosure-20261015/export-36.spthy', 'prior/original-witnesses-export-36.spthy')
tools = root / 'target/continuity-recovery-symbolic-20261015'
for name in ('TOOLS_08.json', 'tool-contract-09.json', 'tool-contract-09.stdout', 'tool-contract-09.stderr'):
    add(tools / name, 'toolchain/' + name)
add(root / 'research/continuity-recovery-symbolic/protected-state.spthy', 'source/protected-state.spthy')
for name in ('.github/workflows/ci.yml', '.github/workflows/codeql.yml'):
    add(root / name, 'source/' + name)
output = root / 'research/sdk-alpha1/evidence/20261015-recovery-positive-symbolic'
output.mkdir()
archive = output / 'CAPTURE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, data)
manifest = {'format': 1, 'base_commit': 'b75613fc05a4df028c3fa947574a8adee7d0faf8',
    'capture_sha256': sdk.snapshot(archive, maximum=64 * 1024**2).sha256,
    'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'positive_recovery_certificate': positive,
    'identity_compromise_witness': json.loads((stage / 'WITNESS_38.json').read_text()),
    'separate_reservation_uniqueness_steps': 2,
    'observer_actions': 6, 'new_observer_actions_this_checkpoint': 0,
    'original_five_complete_declarations_unchanged': True,
    'observer_erasure_preserves_canonical_protocol': True,
    'owned_process_groups_terminal': True,
    'product_code_changed': False, 'canonical_model_changed': False,
    'automated_release_ci_gate_added': False, 'release_claim_eligible': False}
sdk.write_json(output / 'CAPTURE.json', manifest)
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(set(zipped.namelist())) == len(files), 'archive inventory differs')
    for name, digest in manifest['members'].items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == digest, 'archive member differs')
    sdk.require(json.loads(zipped.read('receipts/POSITIVE_CERTIFIED_54.json')) == positive, 'positive certificate readback differs')
    for name in ('WITNESS_38.json', 'ADMISSION_CONTROLS_51.json', 'CLEANUP_55.json'):
        sdk.require(json.loads(zipped.read('receipts/' + name))['completed'], 'archived check incomplete')
sdk.write_json(output / 'READBACK.json', {'completed': True, 'members': len(files),
    'capture_sha256': manifest['capture_sha256'], 'main_secrecy_verified': True,
    'verified_group_count': 20, 'original_five_declarations_unchanged': True,
    'identity_compromise_witness_replayed': True, 'private_sdk_runtime_data_selected': False,
    'release_claim_eligible': False})
print(json.dumps({'members': len(files), 'capture_sha256': manifest['capture_sha256'],
    'main_secrecy_verified': True, 'verified_group_count': 20, 'release_claim_eligible': False}))
