"""Restore every security dependency before replaying the public positive theorem."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
result = json.loads((stage / 'main-search-48-TERMINAL.json').read_text())
sdk.require(not result['accepted'] and result['returncode'] == 0, 'conditional result differs')
selected = {'encapsulation_secret_requires_session_leak': 6,
            'clean_reservation_recovers_symbolic_message_secrecy': 9}
for name, steps in selected.items():
    sdk.require(result['results'][name] == {'status': 'verified', 'steps': steps}, 'candidate proof missing')
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
def blocks(text):
    matches = list(decl.finditer(text))
    return matches, {m.group(1): (m, text[m.start():matches[i+1].start() if i+1<len(matches) else text.rfind('\nend')]) for i,m in enumerate(matches)}
base = (stage / 'complete-base-47.spthy').read_text()
matches, current = blocks(base)
_, proofs = blocks((stage / 'main-search-48-proof.spthy').read_text())
out = base[:matches[0].start()] + ''.join(proofs[name][1] if name in selected else block for name, (_, block) in current.items()) + '\nend\n'
with (stage / 'final-positive-49.spthy').open('x') as output:
    output.write(out)
required = list(json.loads((stage / 'CERTIFIED_30.json').read_text())['verified_combined_obligations'])
required += ['root_constructor_requires_prior_coins_or_snapshot', 'computed_root_derivation_requires_session_leak',
    'message_derivation_requires_session_leak', 'retained_record_has_saved_origin',
    'stored_records_follow_fresh_reservations', *selected]
sdk.require(len(required) == len(set(required)) == 20, 'required group inventory differs')
sdk.write_json(stage / 'FINAL_POSITIVE_INPUT_49.json', {
    'input_sha256': sdk.snapshot(stage / 'final-positive-49.spthy').sha256,
    'required_verified_lemmas': required,
    'complete_required_proof_bodies_restored': True,
    'original_three_execution_witnesses_keep_separate_checked_certificates': True,
    'no_automatic_proof_search_in_final_replay': True,
    'main_secrecy_not_admitted_until_replay': True,
    'release_claim_eligible': False,
})
print('Prepared complete twenty-property dependency replay; public theorem is not yet admitted')
