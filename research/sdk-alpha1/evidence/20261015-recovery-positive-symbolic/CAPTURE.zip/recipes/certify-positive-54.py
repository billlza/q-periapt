"""Admit the unchanged public recovery theorem only with its complete replayed group."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
result = json.loads((stage / 'final-positive-53-TERMINAL.json').read_text())
failed = json.loads((stage / 'final-positive-50-TERMINAL.json').read_text())
inputs = json.loads((stage / 'FINAL_POSITIVE_INPUT_49.json').read_text())
controls = json.loads((stage / 'ADMISSION_CONTROLS_51.json').read_text())
required = set(inputs['required_verified_lemmas'])
sdk.require(len(required) == 20 and result['accepted'] and result['returncode'] == 0
    and not result['timed_out'] and not result['output_exceeded'], 'complete replay not successful')
sdk.require(set(result['required_verified_lemmas']) == required, 'required dependency inventory differs')
verified = {name: row['steps'] for name, row in result['results'].items() if row['status'] == 'verified'}
sdk.require(set(verified) == required, 'some dependency missing or unexpected property admitted')
main = 'clean_reservation_recovers_symbolic_message_secrecy'
sdk.require(verified[main] == 9, 'public theorem result differs')
separate = {'recovery_is_executable', 'pre_cut_generation_reservation_remains_exposed',
            'later_storage_access_defeats_fresh_reservations'}
sdk.require(set(result['results']) == required | separate
    and all(result['results'][name]['status'] == 'analysis incomplete' for name in separate), 'separate witness inventory differs')
sdk.require(not any(arg.startswith('--prove') for arg in result['argv']), 'final replay requested automatic search')
sdk.require(result['input_sha256'] == failed['input_sha256'] == inputs['input_sha256']
    == controls['base_input_sha256'] == sdk.snapshot(stage / 'final-positive-49.spthy').sha256, 'input identity changed')
sdk.require(result['output_sha256'] == sdk.snapshot(stage / 'final-positive-53-proof.spthy').sha256, 'certificate changed')
def stable_argv(argv):
    return [value for value in argv if not value.startswith(('--output=', '--output-json=', '-M'))]
sdk.require(stable_argv(result['argv']) == stable_argv(failed['argv'])
            and '-M8G' in failed['argv'] and '-M12G' in result['argv'], 'resource retry changed more than heap/output paths')
sdk.require(failed['returncode'] == 251 and not failed['accepted'] and controls['completed'], 'failure/control history differs')
tools = json.loads((root / 'target/continuity-recovery-symbolic-20261015/TOOLS_08.json').read_text())
parsed = sdk.command([tools['tamarin'], '--with-maude=' + tools['maude'],
    str(stage / 'final-positive-53-proof.spthy'), '--parse-only'], stage / 'positive-certificate-parse-54', root).decode()
before = (stage / 'admission-base-parse-51.stdout').read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
rows = lambda text: {match.group(1): match.group() for match in decl.finditer(text)}
sdk.require(rows(parsed) == rows(before), 'final complete declarations changed')
prefix = parsed.split('\nlemma ', 1)[0]
sdk.require(prefix == before.split('\nlemma ', 1)[0]
            == (stage / 'complete-parse-30.stdout').read_text().split('\nlemma ', 1)[0], 'final operational model changed')
canonical = rows((stage / 'original-parse-25.stdout').read_text())
sdk.require(len(canonical) == 5 and all(rows(parsed)[name] == value for name, value in canonical.items()), 'original properties changed')
sdk.require(sdk.snapshot(root / 'research/continuity-recovery-symbolic/protected-state.spthy').sha256
            == '7802d0a937cd3f1afd75cb256c4cadc17b714f042f4894f4d471b3ea3d7bf902', 'canonical model changed')
sdk.write_json(stage / 'POSITIVE_CERTIFIED_54.json', {
    'completed': True, 'main_secrecy_verified': True,
    'main_theorem': main, 'main_checked_steps': 9,
    'verified_group': verified, 'required_property_count': 20,
    'input_sha256': result['input_sha256'], 'certificate_sha256': result['output_sha256'],
    'independent_process_replay_without_search': True,
    'replay_seconds': result['elapsed_seconds'], 'heap_gib': 12, 'threads': 2,
    'original_five_complete_declarations_unchanged': True,
    'operational_model_matches_checked_six_observer_projection': True,
    'unchanged_canonical_sha256': sdk.snapshot(root / 'research/continuity-recovery-symbolic/protected-state.spthy').sha256,
    'separate_original_witness_checkpoint': '20261015-recovery-symbolic-disclosure',
    'separate_witnesses_not_claimed_replayed_in_this_invocation': sorted(separate),
    'missing_dependency_and_model_mutation_controls_rejected': True,
    'eight_gib_heap_exhaustion_retained': True,
    'other_session_leakage_not_restricted': True,
    'scope': 'Single exchange per independently initialized pair, perfect primitives and ideal protected storage. No computational, shared-device, multi-epoch, explicit-storage equivalence or SDK refinement claim.',
    'release_claim_eligible': False,
})
print(json.dumps({'main_secrecy_verified': True, 'verified_properties': len(verified),
    'certificate_sha256': result['output_sha256'], 'replay_seconds': result['elapsed_seconds'],
    'original_five_declarations_unchanged': True, 'release_claim_eligible': False}))
