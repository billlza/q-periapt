"""Search root secrecy with its two explicit dependencies, then require full replay."""
from pathlib import Path
import json, re
import rust_sdk_profile as sdk

stage = Path(__file__).resolve().parent
sdk.require(json.loads((stage / 'root-constructor-40-TERMINAL.json').read_text())['accepted'], 'constructor provenance unverified')
base = (stage / 'composed-17-proof.spthy').read_text()
constructor = (stage / 'root-constructor-40-proof.spthy').read_text()
decl = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[[^\]]+\])?:\s*(?:all-traces|exists-trace)?\s*"[^"]*"')
matches = list(decl.finditer(base))
blocks = {m.group(1): m.group() + '\nby sorry\n\n' for m in matches}
cm = list(decl.finditer(constructor))
sdk.require(cm[0].group(1) == 'root_constructor_requires_prior_coins_or_snapshot', 'constructor query not first')
body = constructor[cm[0].start():cm[1].start()]
head = body[:body.index(':')]
sdk.require(head.endswith(']'), 'constructor annotation missing')
body = head[:-1] + ', hide_lemma=encapsulation_derivation_requires_session_leak]' + body[len(head):]
root_name = 'computed_root_derivation_requires_session_leak'
encap_name = 'encapsulation_derivation_requires_session_leak'
out = base[:matches[0].start()] + blocks[encap_name] + body + blocks[root_name]
out += ''.join(block for name, block in blocks.items() if name not in (encap_name, root_name)) + '\nend\n'
with (stage / 'derive-root-41.spthy').open('x') as output:
    output.write(out)
sdk.write_json(stage / 'DERIVE_ROOT_41.json', {
    'input_sha256': sdk.snapshot(stage / 'derive-root-41.spthy').sha256,
    'constructor_certificate_sha256': sdk.snapshot(stage / 'root-constructor-40-proof.spthy').sha256,
    'root_search_dependencies': [encap_name, cm[0].group(1)],
    'encapsulation_body_deferred_not_admitted': True,
    'constructor_replay_hides_unneeded_encapsulation_statement': True,
    'root_query_formula_unchanged': True,
    'protocol_state_and_disclosure_rules_unchanged': True,
    'final_admission_requires_all_dependencies_restored_and_verified': True,
    'release_claim_eligible': False,
})
