"""Record CI queue facts separately from proof results and close owned processes."""
from pathlib import Path
import json, re, subprocess
from evidence_io import parse_strict_json_bytes
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
old = parse_strict_json_bytes((stage / 'older-ci-05.stdout').read_bytes(), label='older CI snapshot')
raw = (stage / 'current-ci-jobs-05.stdout').read_text()
pages = []
position = 0
decoder = json.JSONDecoder()
while position < len(raw):
    while position < len(raw) and raw[position].isspace():
        position += 1
    if position == len(raw):
        break
    _, end = decoder.raw_decode(raw, position)
    pages.append(parse_strict_json_bytes(raw[position:end].encode(), label='current CI jobs page'))
    position = end
jobs = [job for page in pages for job in page['jobs']]
sdk.require(len(jobs) == len({job['id'] for job in jobs}) == 51, 'job page inventory differs')
sdk.require(all(job['head_sha'] == '9d396755c3f872d3a59932c6fe106b2b5e1b2e59' for job in jobs), 'CI source differs')
remaining = [{key: job[key] for key in ('id', 'name', 'status', 'labels', 'runner_id')} for job in jobs if job['status'] != 'completed']
sdk.require(len(remaining) == 7 and all(job['status'] == 'queued' and job['runner_id'] == 0 for job in remaining), 'queue snapshot differs')
ci = (root / '.github/workflows/ci.yml').read_text()
codeql = (root / '.github/workflows/codeql.yml').read_text()
sdk.require(re.search(r'(?m)^\s*concurrency:', ci) is None, 'main CI now has a concurrency group')
sdk.require('\nconcurrency:\n' in codeql and '\n  cancel-in-progress: true\n' in codeql, 'CodeQL group differs')
sdk.write_json(stage / 'CI_QUEUE_31.json', {
    'completed': True, 'current_run': 38692135318,
    'current_source': '9d396755c3f872d3a59932c6fe106b2b5e1b2e59',
    'successful_jobs': sum(job['conclusion'] == 'success' for job in jobs),
    'total_jobs': len(jobs), 'queued_jobs': remaining,
    'older_run': 38585131481, 'older_source': old['headSha'],
    'older_running_jobs': [{key: job[key] for key in ('name', 'status', 'startedAt', 'url')} for job in old['jobs'] if job['status'] == 'in_progress'],
    'queue_cause_established': False, 'main_ci_has_cancellation_group': False,
    'codeql_has_separate_cancellation_group': True,
    'previous_cancellation_explanation_corrected': True,
    'run_cancelled_or_restarted': False, 'workflow_changed': False,
})
groups = {int(line.split(None, 2)[1]) for line in subprocess.check_output(['ps', '-axo', 'pid=,pgid=,command='], text=True).splitlines() if len(line.split(None, 2)) == 3}
owned = {}
for path in sorted(stage.glob('*STARTED*.json')):
    row = json.loads(path.read_text())
    sdk.require(row['pid'] not in groups, 'owned process group still present')
    owned[path.name] = {'pid': row['pid'], 'process_group_absent': True}
sdk.write_json(stage / 'CLEANUP_31.json', {'completed': True, 'owned': owned})
sdk.write_json(stage / 'PREPARATION_NOTES_31.json', {
    'completed': True,
    'reservation_19': 'Rejected by quit-on-warning because first/second equality omitted # prefixes and introduced free message variables. Fresh input20 fixes the intended timepoint equality; all checks remain strict.',
    'reservation_21': 'Timed out at90 seconds while retaining other stored proofs. Fresh input22 defers those bodies, so the independent first reservation lemma can be checked separately.',
    'scope_26': 'Preparation stopped before writing an output because its comma-space tokenizer did not recognize wrapped reuse annotations. No hide_lemma change was applied. The original unscoped thirteen-property replay completed successfully.',
    'unused_composed_15': 'Prepared eleven-property intermediate input was not executed; composed16 includes the subsequently checked traffic properties.',
    'message_first_14': 'Independent reordered message proof search timed out at120 seconds. The accepted352-step proof uses the preceding verified142-step traffic-key helper.',
})
print('CI queue/cancellation distinction recorded; all owned proof groups terminal')
