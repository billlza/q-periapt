from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import stat
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-rekey-classical-alias'
RUN = BASE / 'run-02'
DEST = ROOT / 'research/sdk-alpha1/evidence/20261105-rekey-classical-alias'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode()
result = json.loads((RUN / 'RESULT.json').read_bytes())
launch = json.loads((RUN / 'LAUNCH_RESULT.json').read_bytes())
assert result['completed'] and result['source_inputs_unchanged'] and launch['completed']
assert result['clippy_passed'] and result['rustfmt_passed']
assert result['production_implementation_unchanged_from_full_release']
for name, digest in result['source_inputs']['files'].items():
    assert sha((ROOT / name).read_bytes()) == digest, name
for profile in ['debug', 'release']:
    stdout = (RUN / ('test-' + profile + '.stdout')).read_text()
    stderr = (RUN / ('test-' + profile + '.stderr')).read_text()
    row = result['profiles'][profile]
    assert all(stdout.splitlines().count('test ' + name + ' ... ok') == 1 for name in row['tests'])
    assert all(stderr.splitlines().count(marker) == 1 for marker in row['markers'])
    assert 'test result: ' + row['summary'] in stdout
initial = json.loads((BASE / 'LAUNCH_RESULT.json').read_bytes())
assert initial['completed'] is False and initial['returncode'] == 1
assert json.loads((BASE / 'test-debug.json').read_bytes())['returncode'] == 101
assert 'offer: Suspended' in (BASE / 'test-debug.stderr').read_text()
assert 'FAILED. 1 passed; 1 failed;' in (BASE / 'test-debug.stdout').read_text()
files = {}
selected = [p for p in BASE.iterdir() if p.is_file() and p.name not in ['seal.stdout', 'seal.stderr']]
selected += [p for root in [RUN, BASE / 'initial-source'] for p in root.rglob('*') if p.is_file()]
for path in selected:
    assert not path.is_symlink()
    files['capture/' + path.relative_to(BASE).as_posix()] = path.read_bytes()
sources = [
    'research/continuity-identity-candidate/src/durable/messages/tests.rs',
    'research/continuity-identity-candidate/src/durable/messages/tests/classical_alias.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/response.rs',
    'research/continuity-identity-candidate/src/durable/messages/rekey/completion.rs',
    'research/continuity-identity-candidate/src/crypto.rs',
    'research/continuity-identity-candidate/src/crypto/classical_compromise_tests.rs',
    'research/continuity-identity-candidate/Cargo.toml', 'research/continuity-identity-candidate/Cargo.lock',
    'docs/continuity/AUTHENTICATED_BODY_LEMMA_V1.md', '.github/workflows/ci.yml']
for name in sources: files['source/' + name] = (ROOT / name).read_bytes()
for name in ['LICENSE', 'LICENSE-APACHE', 'LICENSE-MIT']:
    files['LICENSES/' + name] = (ROOT / 'research/continuity-identity-candidate' / name).read_bytes()
readback = {'completed': True, 'captured_utc': datetime.now(timezone.utc).isoformat(),
            'source_base_commit': result['source_commit'], 'working_tree_test_delta': result['working_tree_test_delta'],
            'production_implementation_unchanged_from_full_release': True,
            'profiles': result['profiles'], 'clippy_all_features_all_targets': True, 'rustfmt_checked': True,
            'source_inputs_unchanged': True, 'parent_elapsed_seconds': launch['elapsed_seconds'],
            'parent_timeout_seconds': launch['timeout_seconds'], 'component_timeout_seconds': launch['component_timeout_seconds'],
            'initial_fixture_failure_retained': True,
            'initial_fixture_failure_cause': result['fixture_correction'],
            'scope': 'Actual native cryptography and durable rekey endpoints for two classical-only signature aliases, original-wire controls, exact retries after reopen and rejection-state preservation.',
            'full_native_aggregate_rerun': False, 'hosted_ci_claimed': False,
            'accepted_prefix_theorem_completed': False, 'release_claim_eligible': False}
files['READBACK.json'] = encode(readback)
files['FILES.json'] = encode({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())})
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
payload = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert set(archive.namelist()) == set(files)
    for name, data in files.items(): assert archive.read(name) == data
summary = {'bytes': len(payload), 'members': len(files), 'sha256': sha(payload)}
DEST.mkdir(parents=True, exist_ok=False)
for name, data in [('CAPTURE.zip', payload), ('FILES.json', files['FILES.json']), ('READBACK.json', files['READBACK.json']), ('SHA256.json', encode(summary))]:
    with (DEST / name).open('xb') as f: f.write(data)
print(json.dumps(summary, indent=2), flush=True)
