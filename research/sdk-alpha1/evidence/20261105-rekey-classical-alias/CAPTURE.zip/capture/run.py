from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import runpy
import sys

import continuity_package as package
import rust_sdk_profile as sdk

ROOT = Path.cwd()
BASE = ROOT / 'target/continuity-rekey-classical-alias'
CHAIN = ROOT / 'target/continuity-managed-maintenance/private-toolchain-1.98.1'
BUILD = BASE / 'build'
OLD_BUILD = ROOT / 'target/continuity-managed-maintenance/candidate-build'
MANIFEST = 'research/continuity-identity-candidate/Cargo.toml'
PARENT = 'research/continuity-identity-candidate/src/durable/messages/tests.rs'
TEST = 'research/continuity-identity-candidate/src/durable/messages/tests/classical_alias.rs'
FILTER = 'durable::messages::tests::classical_alias::'
NAMES = [FILTER + name for name in [
    'classical_offer_alias_authenticates_but_cannot_replace_the_retained_rekey_offer',
    'classical_response_alias_passes_root_confirmation_but_final_binds_the_original_wire']]
MARKERS = [
    'REKEY_OFFER_CLASSICAL_ALIAS controls=1 aliases=1 body_unchanged=1 pq_bytes_unchanged=1 alias_authenticated=1 original_offer_bound=1 exact_retry_after_reopen=1',
    'REKEY_RESPONSE_CLASSICAL_ALIAS controls=1 aliases=1 body_unchanged=1 pq_bytes_unchanged=1 root_confirmation_passed=1 original_response_bound_at_final=1 exact_retry_after_reopen=1']

def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def write(path, data):
    with path.open('x') as f: json.dump(data, f, indent=2); f.write('\n')

def main():
    assert ROOT == package.ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sdk.validate_no_registry_credentials(os.environ)
    before = package.source_inputs()
    baseline = json.loads((ROOT / 'target/continuity-aggregate-diagnosis/FORMAL_RELEASE_RESULT.json').read_bytes())
    assert baseline['completed'] and baseline['source_unchanged']
    changed = {n: {'qualified': h, 'current': digest(ROOT / n)} for n, h in baseline['source_before'].items()
               if digest(ROOT / n) != h}
    assert set(changed) == {PARENT, '.github/workflows/ci.yml'}, sorted(changed)
    assert TEST not in baseline['source_before'] and TEST in before['files']
    helper = ROOT / 'target/continuity-installed-managed-cohort/run_package.py'
    sdk.command = runpy.run_path(str(helper), run_name='installed_stream_capture_helpers')['streamed_command']
    tools = package.compiler_identity(CHAIN)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'DYLD_', 'LD_', 'QPERIAPT_'))}
    env.update(CARGO_HOME='/Users/bhmq03@durham.ac.uk/Documents/Codex/2026-10-30/la/work/rust-runtime/cargo',
               CARGO_TARGET_DIR=str(BUILD), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2',
               CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never',
               RUSTC=str(CHAIN / 'bin/rustc'), RUSTDOC=str(CHAIN / 'bin/rustdoc'),
               RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings',
               DYLD_FALLBACK_LIBRARY_PATH=str(CHAIN / 'lib'),
               PATH=str(CHAIN / 'bin') + os.pathsep + env.get('PATH', os.defpath))
    commit = sdk.command(['git', 'rev-parse', 'HEAD'], BASE / 'source-head', ROOT).decode().strip()
    state = {'completed': False, 'started_utc': datetime.now(timezone.utc).isoformat(),
             'source_commit': commit, 'working_tree_test_delta': [PARENT, TEST],
             'source_inputs': before, 'tool_binaries': tools, 'changes_from_full_release_inputs': changed,
             'production_implementation_unchanged_from_full_release': True,
             'driver_sha256': digest(Path(__file__)), 'command_helper_sha256': digest(helper),
             'scope': 'Actual native rekey classical-signature alias regression in Debug and Release, with original-wire positive controls, persistent rejection/retry checks and real new-epoch traffic.',
             'full_native_suite_rerun': False, 'hosted_ci_claimed': False, 'release_claim_eligible': False,
             'profiles': {}}
    write(BASE / 'INPUTS.json', state)
    try:
        assert not BUILD.exists()
        sdk.command(['/bin/cp', '-cR', str(OLD_BUILD), str(BUILD)], BASE / 'copy-build-cache', ROOT)
        for profile in ['debug', 'release']:
            argv = [str(CHAIN / 'bin/cargo'), 'test', '--manifest-path', MANIFEST, '--lib', '--all-features', '--locked', '--offline']
            if profile == 'release': argv += ['--release']
            argv += [FILTER, '--', '--nocapture']
            stdout = sdk.command(argv, BASE / ('test-' + profile), ROOT, environment=env).decode()
            stderr = (BASE / ('test-' + profile + '.stderr')).read_text()
            assert all(stdout.splitlines().count('test ' + name + ' ... ok') == 1 for name in NAMES)
            summaries = re.findall(r'^test result: (.+)$', stdout, re.M)
            assert len(summaries) == 1 and summaries[0].startswith('ok. 2 passed; 0 failed; 0 ignored;'), summaries
            assert all(stderr.splitlines().count(marker) == 1 for marker in MARKERS)
            assert not re.search(r'(?im)^(?:warning|error)(?:\[|:)', stderr)
            state['profiles'][profile] = {'tests': NAMES, 'markers': MARKERS, 'summary': summaries[0]}
        sdk.command([str(CHAIN / 'bin/cargo'), 'clippy', '--manifest-path', MANIFEST, '--all-features', '--all-targets',
                     '--locked', '--offline', '--', '-D', 'warnings'], BASE / 'clippy', ROOT, environment=env)
        sdk.command([str(CHAIN / 'bin/rustfmt'), '--edition', '2021', '--check', PARENT, TEST], BASE / 'rustfmt', ROOT, environment=env)
        assert package.source_inputs() == before and package.compiler_identity(CHAIN) == tools
        state.update(completed=True, source_inputs_unchanged=True, clippy_passed=True, rustfmt_passed=True)
    except BaseException as error:
        state.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(BASE / 'RESULT.json', state)
        print(json.dumps({k: state.get(k) for k in ['completed', 'error_type', 'error']}, indent=2), flush=True)

if __name__ == '__main__': main()
