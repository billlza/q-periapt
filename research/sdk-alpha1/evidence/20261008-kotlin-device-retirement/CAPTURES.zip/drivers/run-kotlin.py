from pathlib import Path
import subprocess,sys,os,json,time,hashlib
b=Path(__file__).resolve().parent;label,*tasks=sys.argv[1:];out=b/label;out.mkdir();source=b/'kotlin/bindings/kotlin/ContinuityPackageConsumer'
base=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed');java=base/'jdk-25.0.4.1+1/Contents/Home';gradle=base/'gradle-9.8.0/bin/gradle'
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK','GRADLE','KOTLIN','CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON')) and k not in ('_JAVA_OPTIONS','CLASSPATH')};env.update(JAVA_HOME=str(java),GRADLE_USER_HOME=str(b/'kotlin-gradle-home'),PATH=str(java/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
cmd=[str(gradle),'--no-daemon','--offline','--warning-mode','fail','--dependency-verification','strict','--max-workers','2','-Dorg.gradle.java.installations.auto-download=false','-Pkotlin.compiler.execution.strategy=in-process','-Dorg.gradle.java.home='+str(java),'--project-dir',str(source),'-Pqperiapt.continuity.lib='+str(b/'artifacts/debug-purpose/libq_periapt_continuity_c_consumer.dylib'),*tasks];t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,env=env,cwd=b,stdout=so,stderr=se,timeout=900)
r=dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-t);(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((out/'stderr.log').read_text()[-5000:]);print((out/'stdout.log').read_text()[-3000:]);p.check_returncode()
