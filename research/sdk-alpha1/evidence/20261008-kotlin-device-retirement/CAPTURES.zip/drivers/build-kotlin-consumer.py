from pathlib import Path
import os,sys,json,shutil,subprocess,time,hashlib
import continuity_kotlin_consumer as gate
b=Path(__file__).resolve().parent;build=b/'kotlin/bindings/kotlin/ContinuityPackageConsumer';consumer=b/'kotlin-installed-consumer';shutil.copytree(build/'consumer',consumer)
contract=gate.maven_contract();published=build/'build/candidate-maven';maven=b/'kotlin-maven'
for p in (published/contract.path).iterdir():
 dest=maven/contract.path/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
verified=gate.jvm.verify_maven(maven,contract=contract);gate.jvm.pin_consumer_dependencies(consumer,maven,contract=contract)
tools=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed');java=tools/'jdk-25.0.4.1+1/Contents/Home';gradle=tools/'gradle-9.8.0/bin/gradle';out=b/'kotlin-consumer-build-01';out.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('JAVA','JDK','GRADLE','KOTLIN','CARGO','RUST','QPERIAPT','QPC','DYLD','LD_','PYTHON')) and k not in ('_JAVA_OPTIONS','CLASSPATH')};env.update(JAVA_HOME=str(java),GRADLE_USER_HOME=str(b/'kotlin-gradle-home'),PATH=str(java/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
cmd=[str(gradle),'--no-daemon','--offline','--warning-mode','fail','--dependency-verification','strict','--max-workers','2','-Dorg.gradle.java.installations.auto-download=false','-Pkotlin.compiler.execution.strategy=in-process','-Dorg.gradle.java.home='+str(java),'--project-dir',str(consumer),'installDist','recordRuntime','-Pqperiapt.repository='+str(maven)];t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:p=subprocess.run(cmd,env=env,cwd=b,stdout=so,stderr=se,timeout=900)
r=dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-t,maven=verified);(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='maven'}));print((out/'stderr.log').read_text()[-4000:]);print((out/'stdout.log').read_text()[-2500:]);p.check_returncode()
distribution=consumer/'build/install/continuity-installed-consumer';r['runtime_closure']=gate.runtime_closure((consumer/'build/runtime.tsv').read_bytes(),distribution,verified['jar_sha256'],b);r['owner_tests']=gate.verify_test_reports(build/'build/test-results/test');(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['owner_tests']))
