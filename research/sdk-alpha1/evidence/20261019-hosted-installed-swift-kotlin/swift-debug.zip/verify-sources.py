"""Bind one completed partition's source manifest to actual immutable Git blobs."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
out=Path(__file__).resolve().parent
head='23280124efd2f0f3003d4ce85e3db665f6ec8a25'
sha=lambda b:hashlib.sha256(b).hexdigest()
reference=None;results=[]
for label in sys.argv[1:]:
 folder=out/label;report=json.loads((folder/'CONTINUITY_PACKAGE.json').read_text())
 before=json.loads((folder/'sources-before.json').read_text());assert before==json.loads((folder/'sources-after.json').read_text())==report['source_inputs']
 assert report['source_commit']==head and len(before['files'])==1132
 if reference is None:
  request=''.join(head+':'+n+'\n'for n in before['files'])
  data=subprocess.check_output(['git','cat-file','--batch'],input=request.encode());offset=0
  for name,expected in before['files'].items():
   end=data.index(b'\n',offset);header=data[offset:end].split();assert len(header)==3 and header[1]==b'blob'
   count=int(header[2]);start=end+1;assert sha(data[start:start+count])==expected,name
   offset=start+count+1
  assert offset==len(data);reference=before
 else:assert before==reference
 artifact=json.loads((folder/'ARTIFACT.json').read_text());archive=folder/'terminal.zip'
 assert 'sha256:'+sha(archive.read_bytes())==artifact['digest']
 with zipfile.ZipFile(archive)as z:
  candidate=report['archive'];raw=z.read(candidate['file']);assert len(raw)==candidate['bytes']and sha(raw)==candidate['sha256']
  if label.startswith('android-'):
   foreign=report['android_jni_consumer'];assert sha(z.read('continuity-android-classes.jar'))==foreign['jar_sha256']
 row={'label':label,'head':head,'git_verified_sources':len(reference['files']),'artifact':artifact['id'],'artifact_digest':artifact['digest'],'candidate_archive':{k:candidate[k]for k in ['file','bytes','sha256']},'scope':'Terminal artifact, candidate archive, before/after source manifest and1132 committed Git blobs verified; Android packaged JAR checked when applicable. No binary execution or full public-contract replay.'}
 (folder/'SOURCE_READBACK.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row)
print(json.dumps(results))
