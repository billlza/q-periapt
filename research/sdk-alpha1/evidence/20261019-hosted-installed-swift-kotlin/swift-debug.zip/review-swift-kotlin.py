"""Re-read shipped packages and selected public foreign-owner contracts."""
from pathlib import Path
import hashlib,importlib,json,sys,zipfile
out=Path(__file__).resolve().parent;frozen=out/'frozen-2328';sys.path.insert(0,str(frozen/'artifact'))
import continuity_package_archive as archive
import continuity_c_account as account
sha=lambda b:hashlib.sha256(b).hexdigest()
reports={}
for label in ['swift-debug','kotlin-release']:
 language,profile=label.rsplit('-',1);pretty=language.title();folder=out/label
 original=json.loads((folder/'CONTINUITY_PACKAGE.json').read_text());row=original[language+'_consumer']['profiles'][profile]
 module=importlib.import_module('continuity_'+language+'_consumer');root_module=importlib.import_module('continuity_'+language+'_root')
 routes=[]
 def add(name,log,directory,verify,expected,extra=()):routes.append((name,log,directory,verify,expected,extra))
 for kind in ['client','server','recovery']:
  function={'client':'verify_execution','server':'verify_server_execution','recovery':'verify_recovery_execution'}[kind]
  if language=='swift':
   log='swift-'+(''if kind=='client'else kind+'-')+'trace-'+profile+'.stdout'
   directory='swift-public/'+(''if kind=='client'else kind+'/')+profile
   expected=row[{'client':'execution','server':'server_execution','recovery':'recovery_execution'}[kind]]
  else:log=f'kotlin-{kind}-trace-{profile}.stdout';directory=f'kotlin-public/{kind}/{profile}';expected=row['traces'][kind]['execution']
  add(kind,log,directory,getattr(module,function),expected)
 if language=='swift':add('account','swift-account-trace-debug.stdout','swift-public/account/debug',lambda b,p:account.verify_execution(b,p,language='Swift'),row['account_owner']['execution'])
 else:
  for collector in ['Serial','G1']:
   add('account-'+collector,f'kotlin-account-{collector.lower()}-trace-release.stdout',f'kotlin-public/account/release/{collector}',module.verify_account_execution,row['account_owner'][collector]['execution'])
 for name,kind,fn in [('account_delivery','delivery','verify_execution'),('own_account_delivery','delivery','verify_own_execution'),('account_tls','tls','verify_execution'),('account_tls_loss','tls_loss','verify_execution'),('own_account_tls_loss','tls_loss','verify_own_execution'),('account_witness','witness','verify_execution')]:
  selected=importlib.import_module('continuity_c_account_'+kind);verify=getattr(selected,fn);stem=name.replace('_','-')
  add(name,f'{language}-{stem}-trace-{profile}.stdout',f'{language}-{stem}-public/{profile}',lambda b,p,v=verify,l=pretty:v(b,p,language=l),row[name]['execution'])
 variants=['original','adoption','transition','bound-transition']
 for collector in ([None]if language=='swift'else ['Serial','G1']):
  for variant in variants:
   if language=='swift':
    log=f'swift-root-debug-{variant}.stdout';directory=f'swift-root-public/debug/{variant}';expected=row['root_lifecycle']['routes'][variant]
    verify=lambda b,p,v=variant:root_module.verify_execution(b,p,variant=v)
   else:
    stem=f'release-{collector.lower()}-{variant}';log=f'kotlin-root-{stem}.stdout';directory=f'kotlin-root-public/{stem}';expected=row['root_lifecycle']['collectors'][collector][variant]
    verify=lambda b,p,v=variant,c=collector:root_module.verify_execution(b,p,variant=v,collector=c)
   add('root-'+str(collector)+'-'+variant,log,directory,verify,expected,('exported_public_files',))
 replay=folder/'foreign-public-readback';replay.mkdir();checked={}
 with zipfile.ZipFile(folder/'terminal.zip')as z:
  packaged=z.read(row['archive']);assert sha(packaged)==row['archive_sha256']
  archive.unpack(packaged,row['files'],folder/'verified-foreign-package')
  for name,log,directory,verify,expected,extra in routes:
   prefix=directory+'/';names=[n for n in z.namelist()if n.startswith(prefix)]
   assert names,(name,prefix)
   for n in names:
    p=replay/n;p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert p.read_bytes()==z.read(n)
    else:p.write_bytes(z.read(n))
   result=verify(z.read(log),replay/directory)
   assert result=={k:v for k,v in expected.items()if k not in extra},name
   checked[name]={'result':result,'public_files':len(names),'stdout_sha256':sha(z.read(log))}
 reports[label]={'archive':row['archive'],'archive_sha256':sha(packaged),'package_files':len(row['files']),'contracts':checked}
manifest=json.loads((frozen/'SOURCE_FILES.json').read_text());loaded={}
for module in tuple(sys.modules.values()):
 name=getattr(module,'__file__',None)
 if not name:continue
 p=Path(name)
 if p.parent!=frozen/'artifact':continue
 relative=str(p.relative_to(frozen));assert sha(p.read_bytes())==manifest[relative];loaded[relative]=manifest[relative]
result={'head':'23280124efd2f0f3003d4ce85e3db665f6ec8a25','profiles':reports,'reader_sources':loaded,'scope':'Exact shipped foreign package bytes and original public client/server/recovery,account delivery/TLS/witness/unknown outcome and root lifecycle readers replayed. Same-host shared native engine; original execution and private authentication remain producer observations. No rerun of uploaded binaries, independent cryptographic signature implementation, physical-device test, full remaining foreign contract replay or six-partition release admission.'}
(out/'SWIFT_KOTLIN_READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({name:{'package_files':r['package_files'],'contracts':len(r['contracts'])}for name,r in reports.items()}))
