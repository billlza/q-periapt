from pathlib import Path
import json
import continuity_android_policy_renewal as renewal
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent
records=renewal.verify_execution((out/'android-policy-fixed.stdout').read_bytes(),out/'cases-fixed','fixed')
for label,result in records.items():
 state=json.loads((out/('device-'+label)/'STATE.json').read_text());assert state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports');assert len(state['cases'])==result['foreign_processes'];assert [(x['label'],x['mode']) for x in state['cases']]==list(renewal.cases(label.split('-',1)[0]));assert all(x['process_absent_after_stop'] for x in state['cases'])
sdk.write_json(out/'FIXED_VERIFIED.json',{'scope':'fixed-trust Android independent-policy renewal; recoverable trust is still running','profiles':records,'art_processes':117,'complete_profile':True,'complete_qualification':False})
print('All 117 fixed-trust ART calls and original-operation public evidence verified',flush=True)
