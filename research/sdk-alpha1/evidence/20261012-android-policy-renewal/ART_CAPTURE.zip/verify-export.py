from pathlib import Path
import json
import continuity_android_policy_renewal as renewal
import rust_sdk_profile as sdk
out=Path(__file__).resolve().parent;destination=out/'public-export';destination.mkdir();records={};digests={}
for trust in renewal.TESTS:
 source=out/('cases-'+trust);target=destination/trust
 for carrier in ['local','signed','tls']:
  label=carrier+'-'+trust
  for name in renewal.public(carrier):
   p=target/label/name;sdk.copy(source/label/name,p);digests[str(p.relative_to(destination))]=sdk.snapshot(p).sha256
 stdout=(out/('android-policy-'+trust+'.stdout')).read_bytes()
 current=renewal.verify_execution(stdout,source,trust);assert renewal.verify_execution(stdout,target,trust)==current;records.update(current)
assert records==json.loads((out/'OUTCOMES.json').read_text())
sdk.write_json(out/'PUBLIC_EXPORT_VERIFIED.json',{'completed':True,'profiles':records,'files':digests,'art_processes':234,'scope':'Reverification of the six completed real ART routes after correcting only the public export list.'});print('Real 234-process ART public export and independent readback passed',flush=True)
