from pathlib import Path
import base64,hashlib,json,subprocess,zipfile
import rust_sdk_profile as sdk
import continuity_android_jni as android
import continuity_android_local_credential as local
import continuity_android_witness as witnessed
import continuity_android_credential as credential
import continuity_android_remote_credential as remote
import continuity_android_credential_terminal as terminal
import continuity_android_policy_expiry as expiry
import continuity_android_policy_renewal as renewal
root=Path.cwd();phone=root/'target/continuity-android-policy-renewal-device-final';host=root/'target/continuity-android-policy-renewal-host-resumed-v2';aar=root/'target/continuity-android-policy-renewal-aar';focused=root/'target/continuity-android-policy-renewal';out=root/'research/sdk-alpha1/evidence/20261012-android-policy-renewal'
v=json.loads((phone/'VERIFIED.json').read_text());h=json.loads((host/'ANDROID_JNI_CONSUMER.json').read_text());a=json.loads((aar/'PACKAGE.json').read_text());assert v['completed'] and h['completed'] and a['completed']
assert json.loads((focused/'clippy-final.json').read_text())['returncode']==0
assert json.loads((focused/'rustfmt-final.json').read_text())['exit_code']==0
assert json.loads((focused/'shared-regression/execution.json').read_text())['returncode']==0
assert set(h['profiles'])=={'debug','release'}
host_processes=0
for profile in h['profiles'].values():
 assert profile['boundary_checks']
 count=1+sum(item['foreign_processes'] for key,value in profile.items() if key=='outcomes' or key.endswith('_outcomes') for item in value.values());assert count==741;host_processes+=count
assert host_processes==1482 and sum(r['foreign_processes'] for r in v['profiles'].values())==234
engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());assert engines['completed'] and not engines['live_producer'] and a['native_engine_sha256']==engines['android_library_sha256']
for name,digest in engines['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
for name,data in android.source_files().items():assert h['source_hashes'][name]==a['source_sha256'][name]==hashlib.sha256(data).hexdigest()
code=json.loads((focused/'CODE_FILES.json').read_text())
for name,digest in code.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
libraries={}
for profile in ['debug','release']:
 argv=json.loads((host/('android-jni-'+profile+'-boundary.json')).read_text())['argv'];lib=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')));libraries[profile]=lib
 assert local.verify_execution((host/('android-jni-'+profile+'-execution.stdout')).read_bytes(),lib/'cases')==h['profiles'][profile]['outcomes']
 assert terminal.verify_execution((host/('android-jni-'+profile+'-credential.stdout')).read_bytes(),lib/'credential-cases')==h['profiles'][profile]['credential_outcomes']
 for lane,managed in [('witness',False),('authority',True)]:assert witnessed.verify_execution((host/('android-jni-'+profile+'-'+lane+'.stdout')).read_bytes(),lib/(lane+'-cases'),managed=managed)==h['profiles'][profile][lane+'_outcomes']
 for module,prefix,key in [(expiry,'policy-expiry','policy_expiry_outcomes'),(renewal,'policy-renewal','policy_renewal_outcomes')]:
  records={}
  for trust in module.TESTS:records.update(module.verify_execution((host/('android-jni-'+profile+'-'+prefix+'-'+trust+'.stdout')).read_bytes(),lib/(prefix+'-'+trust+'-cases'),trust))
  assert records==h['profiles'][profile][key]
serials=[];adb='/Users/bill/Library/Android/sdk/platform-tools/adb'
for row in subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines():
 if ' device ' in row:serials.append(row.split()[0].encode())
private=[]
for folder in [phone,focused,*libraries.values(),root/'target/continuity-android-policy-renewal-device']:
 for pattern in ['**/inputs/tls-key','**/inputs/witness-tls-key']:
  for path in folder.glob(pattern):
   value=path.read_bytes();private.extend([value,base64.b64encode(value),value.hex().encode()])
assert not subprocess.run(['git','status','--porcelain'],check=True,capture_output=True,text=True).stdout.strip(),'commit verified code before capture'
out.mkdir()
def archive(name,files):
 with zipfile.ZipFile(out/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for leaf,path in sorted(files.items()):
   data=path.read_bytes();assert not any(value and value in data for value in serials+private),'private value in '+leaf
   info=zipfile.ZipInfo(leaf);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
 return hashlib.sha256((out/name).read_bytes()).hexdigest()
def logs(folder):return {p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.public'} and p.name!='STATE.json'}
files={p.name:p for p in phone.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
for p in phone.glob('device-*/*'):
 if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:files[p.relative_to(phone).as_posix()]=p
for trust in renewal.TESTS:
 for carrier in ['local','signed','tls']:
  label=carrier+'-'+trust
  for name in renewal.public(carrier):files['cases-'+trust+'/'+label+'/'+name]=phone/('cases-'+trust)/label/name
art=archive('ART_CAPTURE.zip',files)
files=logs(host);files['qualify.py']=host/'qualify.py'
for profile,lib in libraries.items():
 for trust in renewal.TESTS:
  for carrier in ['local','signed','tls']:
   label=carrier+'-'+trust
   for name in renewal.public(carrier):files['policy-renewal/'+profile+'/'+label+'/'+name]=lib/('policy-renewal-'+trust+'-cases')/label/name
host_hash=archive('HOST_CAPTURE.zip',files)
files={p.name:p for p in focused.iterdir() if p.is_file() and p.name!='STATE.json' and p.suffix in {'.py','.json','.stdout','.stderr'}}
for folder in ['smoke-06','shared-regression']:
 for leaf,path in logs(focused/folder).items():files[folder+'/'+leaf]=path
for carrier in ['local','signed','tls']:
 for name in renewal.public(carrier):files['smoke-06/cases/'+carrier+'-fixed/'+name]=focused/'smoke-06/cases'/(carrier+'-fixed')/name
for attempt in ['continuity-android-policy-renewal-host','continuity-android-policy-renewal-device']:
 for leaf,path in logs(root/'target'/attempt).items():files[attempt+'/'+leaf]=path
for folder in ['continuity-android-policy-renewal-host-final','continuity-android-policy-renewal-host-resumed']:
 base=root/'target'/folder
 for p in base.iterdir():
  if p.is_file() and p.name!='STATE.json' and p.suffix in {'.py','.json','.stdout','.stderr'}:files[folder+'/'+p.name]=p
smoke_hash=archive('FOCUSED_CAPTURE.zip',files)
files={p.name:p for p in aar.iterdir() if p.is_file() and p.suffix in {'.py','.json','.stdout','.stderr'}}
prepared=root/'target/continuity-android-policy-renewal-device'
for leaf,path in logs(prepared/'agp-prepared').items():files['agp/'+leaf]=path
files['agp/STATE.json']=prepared/'agp-prepared/STATE.json'
for name in ['prepare-apk.py','build-consumer.py','PREPARED_APK.json','keytool.stdout','keytool.stderr','sign.stdout','sign.stderr','signature.stdout','signature.stderr']:files[name]=prepared/name
aar_hash=archive('AAR_BUILD_CAPTURE.zip',files)
record={'kind':'qperiapt.android_independent_policy_renewal','completed':True,'base_commit':'3ae7bba1b661635850a2216df49c939d07589385','code_commit':subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip(),'code_sha256':code,'profiles':v['profiles'],'art_processes':234,'host_java_processes':1482,'device_scope':{'accepted':True,'api':37,'device_count':1,'additional_api36_hardware_required':False},'native_engine_sha256':a['native_engine_sha256'],'aar_sha256':a['aar_sha256'],'unchanged_native_source_sha256':engines['source_sha256'],'native_regression_scope':'Native runtime source and engine bytes match the preceding 909-test local-roster-expiry qualification. Java/JNI adapters and foreign harnesses are newly tested here.','artifacts':{'ART_CAPTURE.zip':art,'HOST_CAPTURE.zip':host_hash,'FOCUSED_CAPTURE.zip':smoke_hash,'AAR_BUILD_CAPTURE.zip':aar_hash},'scope':['Original P0 expires in real time; live independent P2 requires account-root and policy-root approvals.','Fixed and recoverable SDK trust each cover local storage, signed witness TCP and mutual TLS. Local storage uses explicit pins; required witness uses a live managed registry.','Bad approval, changed scope and cancelled staging preserve absence and original request.','Required-witness Commit really persists and loses its reply. Exact proposal history recovers Applied, retires it, and sends no additional Commit or Close.','Current target selection and required registry are independently enforced; target activation restores original signer, journal, session and message with one business effect.'],'limitations':['SDK authority expiry/revocation, roster renewal, device retirement and root replacement are separate Android software scenarios.','Witness, issuer and receiver are native reference endpoints on the Mac host; no independent protocol implementation is claimed.'],'verification_notes':['JNI field capacity 16 failed the 17-field policy stage; the shared bounded capacity and static assertion are corrected, with strict JNI boundary checks.','Local journals cannot silently acquire required-witness protection; the tests preserve this native contract.','Required-witness resolve refuses the local-only resolver with AnchorRequired; actual proposal reconciliation is used.','New Rust test slice diagnostics were fixed with checked access. The earlier phone and host qualification were intentionally stopped and their owned assets cleaned, then the final harness reran.','The source census first refused four untracked new Rust files; the standalone mirror stages those exact source files before rerunning.'],'release_claim_eligible':False}
record['verification_notes'].append('The original export list named a result file never generated by the C target-creation command. A new copy-and-reverify test fails before correction and passes after it. Exact successful host commands are revalidated and reused only after source, tool, AAR and native-library identity checks; remaining commands execute normally.')
record['reader_tests']=35
record['package_tests']=27
record['source_inventory_tests']=81
record['host_recovery_receipt']='HOST_CAPTURE.zip:RECOVERED_COMMANDS.json'
sdk.write_json(out/'CHECKS.json',record);print('Captured independent Android policy renewal with original traffic recovery',flush=True)
