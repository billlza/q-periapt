from pathlib import Path
import hashlib,json,subprocess
import rust_sdk_profile as sdk
import continuity_android_policy_renewal as expiry
root=Path.cwd();out=root/'target/continuity-android-policy-renewal-device-final';results={}
for trust in expiry.TESTS:results.update(expiry.verify_execution((out/('android-policy-'+trust+'.stdout')).read_bytes(),out/('cases-'+trust),trust))
assert sum(r['foreign_processes'] for r in results.values())==234
adb='/Users/bill/Library/Android/sdk/platform-tools/adb';rows=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,check=True,timeout=15).stdout.splitlines();selected=[r.split()[0] for r in rows if ' device ' in r and hashlib.sha256(r.split()[0].encode()).hexdigest()=='326ab0b4b03710a725a5c931ecddeb262bfab2f26974fd965028ce5599779b16'];assert len(selected)==1
prefix=[adb,'-s',selected[0]]
def call(args):
 r=subprocess.run(prefix+args,capture_output=True,text=True,check=True,timeout=20);assert not r.stderr;return r.stdout
assert not call(['shell','pm','list','packages','--user','0','dev.qperiapt.continuity.policyrenewal20261012']).strip()
active={row.split()[1] for row in call(['reverse','--list']).splitlines() if len(row.split())==3}
for label,record in results.items():
 state=json.loads((out/('device-'+label)/'STATE.json').read_text());assert state['completed'] and state['cleanup'] and not state.get('owned_reverse_ports') and len(state['cases'])==record['foreign_processes']
 for p in (out/('device-'+label)).glob('*-reverse-create-*.json'):
  r=json.loads(p.read_text())
  if r['exit_code']==0:assert r['command'][-2] not in active
 assert all(c['process_absent_after_stop'] and c['installed_apk_sha256']==state['apk_sha256'] for c in state['cases'])
 record.update(installation_retired=True,owned_mappings_absent=True,apk_sha256=state['apk_sha256'],aar_sha256=state['aar_sha256'])
sdk.write_json(out/'VERIFIED.json',{'completed':True,'profiles':results,'same_phone_accepted':True,'additional_api36_hardware_required':False});print('234 ART outcomes and owned cleanup verified',flush=True)
