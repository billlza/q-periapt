from pathlib import Path
import hashlib,json,os,zipfile
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_android_jni as android
root=Path.cwd();old=root/'target/continuity-android-policy-renewal-host-final';out=Path(__file__).resolve().parent;output=out
s=json.loads((old/'STATE.json').read_text());assert not s['live_producer']
result=json.loads((old/'ANDROID_JNI_CONSUMER.json').read_text());assert not result['completed'] and result['profiles']=={}
engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());native=engines['native'];assert engines['completed'] and not engines['live_producer']
for name,digest in engines['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
source=android.source_files();assert {n:hashlib.sha256(data).hexdigest() for n,data in source.items()}==result['source_hashes']
java_home=Path(result['tools']['root']);tools=android.tool_identity(java_home);assert tools==result['tools'];java,javac=(java_home/'bin'/n for n in ('java','javac'))
argv=json.loads((old/'android-jni-debug-boundary.json').read_text())['argv'];installed_old=Path(next(x.split('=',1)[1] for x in argv if x.startswith('-Djava.library.path=')));work=installed_old.parent;builder=work/'source';tests=work/'tests';jar=old/'continuity-android-classes.jar'
assert {p.relative_to(builder).as_posix():p.read_bytes() for p in builder.rglob('*') if p.is_file()}==source
jar_hash=sdk.snapshot(jar).sha256
package=json.loads((root/'target/continuity-android-policy-renewal-aar/PACKAGE.json').read_text())
with zipfile.ZipFile(package['aar']) as aar,zipfile.ZipFile(jar) as j:
 assert aar.read('classes.jar')==jar.read_bytes(),'host classes differ from physically qualified AAR classes'
sdk.copy(jar,out/'continuity-android-classes.jar')
clang=Path(result['compiler']['path']);platform=Path((old/'android-jni-sdk-path.stdout').read_text().strip()).resolve(strict=True)
assert sdk.snapshot(clang,maximum=c.MAX_BINARY).sha256==result['compiler']['sha256']
assert sdk.snapshot(platform/'SDKSettings.json').sha256==result['compiler']['sdk_settings_sha256']
environment=s['environment'];env={k:v for k,v in environment.items() if k not in {'JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','CLASSPATH'} and not k.startswith(('JAVA_','GRADLE_','KOTLIN_','QPERIAPT_','QPC_','LD_'))}
consumer=Path(s['work'])/'c-consumer';target=Path(environment['CARGO_TARGET_DIR']);cargo=str(Path(environment['RUSTC']).parent/'cargo');CASES=android.CASES;_driver=android._driver
# Recovery is only for the exact successful commands preceding a public-file export error.
recover=set(('debug-bridge','debug-boundary','debug-build','debug-execution','debug-witness','debug-authority','debug-credential','debug-policy-expiry-fixed','debug-policy-expiry-recoverable','debug-policy-target-client','debug-policy-renewal-fixed'))
recovered=[]
def run(argv,label,cwd=work,runtime=None):
 prefix=out/('android-jni-'+label)
 if label not in recover:return sdk.command(argv,prefix,cwd,environment=env if runtime is None else runtime)
 previous=old/('android-jni-'+label);receipt=json.loads(previous.with_suffix('.json').read_text())
 assert receipt=={'argv':argv,'cwd':str(cwd),'returncode':0},label
 stdout=sdk.snapshot(previous.with_suffix('.stdout')).data;stderr=sdk.snapshot(previous.with_suffix('.stderr')).data
 sdk.validate_cargo_output(prefix.name,[stdout.decode(),stderr.decode()])
 for extension in ['.json','.stdout','.stderr']:sdk.copy(previous.with_suffix(extension),prefix.with_suffix(extension))
 recovered.append({'label':label,'receipt_sha256':sdk.snapshot(previous.with_suffix('.json')).sha256,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest()})
 return stdout
for name in ['java-version','javac-version','main-compile','test-compile','clang-path','sdk-path']:
 for ext in ['.json','.stdout','.stderr']:sdk.copy(old/('android-jni-'+name+ext),out/('android-jni-'+name+ext))
state=dict(s,completed=False,live_producer=True,resumed_from=str(old));(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
    for profile in ('debug','release'):
        installed=work/profile
        if profile=='release':installed.mkdir(mode=0o700)
        record=native['execution'][profile]['binaries']['C_library'];library=Path(record['path'])
        assert sdk.snapshot(library,maximum=c.MAX_BINARY).sha256==record['sha256']
        receiver_record=native['execution'][profile]['binaries']['C_client'];receiver=installed/'qpc-c-client'
        assert sdk.snapshot(Path(receiver_record['path']),maximum=c.MAX_BINARY).sha256==receiver_record['sha256']
        if profile=='debug':
            assert sdk.snapshot(installed/library.name,maximum=c.MAX_BINARY).sha256==record['sha256']
            assert sdk.snapshot(receiver,maximum=c.MAX_BINARY).sha256==receiver_record['sha256']
        else:
            sdk.copy(library,installed/library.name,maximum=c.MAX_BINARY)
            sdk.copy(Path(receiver_record['path']),receiver,maximum=c.MAX_BINARY);receiver.chmod(0o700)
        bridge = installed / "libqperiapt_continuity_jni.dylib"
        run([str(clang), "-std=c11", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-fvisibility=hidden",
             "-isysroot", str(platform), "-I" + str(consumer), "-I" + str(java_home / "include"),
             "-I" + str(java_home / "include/darwin"), "-dynamiclib",
             *map(str, sorted((builder / "jni").glob("*.c"))), "-L" + str(installed),
             "-lq_periapt_continuity_c_consumer", "-Wl,-rpath,@loader_path", "-o", str(bridge)], profile + "-bridge")
        boundary = run([str(java), "--enable-native-access=ALL-UNNAMED", "-Xcheck:jni",
                        "-Djava.library.path=" + str(installed), "-cp", str(jar) + os.pathsep + str(tests),
                        "dev.qperiapt.continuity.android.BridgeProbe"], profile + "-boundary")
        sdk.require(boundary == b"configuration:bridge:passed\n" and
                    sdk.snapshot(output / ("android-jni-" + profile + "-boundary.stderr")).data == b"",
                    "JNI boundary checks omitted an outcome or reported diagnostics")
        extra = ["--release"] if profile == "release" else []
        built = run([cargo, "test", "--locked", "--offline", "--test", "android", "--no-run", "--message-format=json", "-j", "2", *extra],
                    profile + "-build", consumer)
        binary = c.built_artifact(built, consumer, target / profile, library=False, test_name="android")
        driver = _driver(installed, java, jar, tests, installed)
        cases = installed / "cases"
        runtime = dict(env, QPC_ANDROID_CASES=str(cases), QPC_ANDROID_DRIVER=str(driver))
        checked = run([str(binary), "--exact", "android_lifecycle", "--nocapture"], profile + "-execution", consumer, runtime)
        import continuity_android_local_credential as local_credential
        outcomes = local_credential.verify_execution(checked, cases)
        for trust in outcomes:
            for name in local_credential.PUBLIC:
                sdk.copy(cases / trust / name, output / f"android-jni-{profile}-{trust}-{name}.public")
        for trust in outcomes:
            for label, _ in CASES:
                for suffix in ("stdout", "stderr"):
                    sdk.copy(cases / trust / f"{label}.{suffix}", output / f"android-jni-{profile}-{trust}-{label}.{suffix}")
        import continuity_android_witness as witnessed
        import continuity_android_credential as credential
        import continuity_android_remote_credential as remote_credential
        import continuity_android_credential_terminal as terminal
        witness_results = {}
        for lane, managed, test in (("witness", False, witnessed.TEST), ("authority", True, "android_witness::managed_first_registration"),
                                    ("credential", True, credential.TEST)):
            witness_cases = installed / (lane + "-cases")
            witness_runtime = dict(env, QPC_ANDROID_CASES=str(witness_cases), QPC_ANDROID_DRIVER=str(driver), QPC_CONFIGURATION_RECEIVER=str(receiver))
            witnessed_stdout = run([str(binary), "--exact", test, "--nocapture"],
                                   profile + "-" + lane, consumer, witness_runtime)
            witness_outcomes = (terminal.verify_execution(witnessed_stdout, witness_cases) if lane == "credential"
                                else witnessed.verify_execution(witnessed_stdout, witness_cases, managed=managed))
            witness_results[lane] = witness_outcomes
            for label in witness_outcomes:
                carrier = label.split("-", 1)[0]
                public = ["genesis", "signed-witness-transcript"]
                if managed: public += ["authority-created", "authority-reopened"]
                if lane == "credential": public += list(credential.PUBLIC) + list(remote_credential.PUBLIC) + list(terminal.PUBLIC)
                public += [name + "." + suffix for name, _ in witnessed.cases(carrier, managed=managed) for suffix in ("stdout", "stderr")]
                for name in public:
                    sdk.copy(witness_cases / label / name, output / f"android-jni-{profile}-{lane}-{label}-{name}.public")
        import continuity_android_policy_expiry as expiry
        expiry_results = {}
        for trust, test in expiry.TESTS.items():
            expiry_cases = installed / ("policy-expiry-" + trust + "-cases")
            expiry_runtime = dict(env, QPC_ANDROID_CASES=str(expiry_cases), QPC_ANDROID_DRIVER=str(driver))
            expiry_stdout = run([str(binary), "--exact", test, "--nocapture"], profile + "-policy-expiry-" + trust, consumer, expiry_runtime)
            records = expiry.verify_execution(expiry_stdout, expiry_cases, trust)
            expiry_results.update(records)
            for label in records:
                for name in expiry.public(label.endswith("-applied")):
                    sdk.copy(expiry_cases / label / name, output / f"android-jni-{profile}-policy-expiry-{label}-{name}.public")
        import continuity_android_policy_renewal as policy_renewal
        target_client = installed / "qpc-configuration-client"
        run([str(clang), "-std=c11", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-isysroot", str(platform),
             str(consumer / "first_configuration_client.c"), "-I" + str(consumer), "-L" + str(installed),
             "-lq_periapt_continuity_c_consumer", "-Wl,-rpath,@loader_path", "-o", str(target_client)], profile + "-policy-target-client")
        policy_results = {}
        for trust, test in policy_renewal.TESTS.items():
            policy_cases = installed / ("policy-renewal-" + trust + "-cases")
            policy_runtime = dict(env, QPC_ANDROID_CASES=str(policy_cases), QPC_ANDROID_DRIVER=str(driver),
                                  QPC_CONFIGURATION_TARGET_CLIENT=str(target_client), QPC_CONFIGURATION_RECEIVER=str(receiver))
            policy_stdout = run([str(binary), "--exact", test, "--nocapture"], profile + "-policy-renewal-" + trust, consumer, policy_runtime)
            records = policy_renewal.verify_execution(policy_stdout, policy_cases, trust)
            policy_results.update(records)
            for label in records:
                for name in policy_renewal.public(label.split("-", 1)[0]):
                    sdk.copy(policy_cases / label / name, output / f"android-jni-{profile}-policy-renewal-{label}-{name}.public")
        result["profiles"][profile] = {"policy_renewal_outcomes": policy_results,
            "policy_target_client_sha256": sdk.snapshot(target_client, maximum=c.MAX_BINARY).sha256,
            "policy_expiry_outcomes": expiry_results, "credential_outcomes": witness_results["credential"], "witness_outcomes": witness_results["witness"], "authority_outcomes": witness_results["authority"], "outcomes": outcomes, "boundary_checks": True, "native_sha256": record["sha256"],
            "bridge_sha256": sdk.snapshot(bridge, maximum=c.MAX_BINARY).sha256,
            "receiver_sha256": sdk.snapshot(receiver, maximum=c.MAX_BINARY).sha256,
            "test_sha256": sdk.snapshot(binary, maximum=c.MAX_BINARY).sha256}
    assert set(r['label'] for r in recovered)==recover
    assert android.source_files()==source and android.tool_identity(java_home)==tools and sdk.snapshot(jar).sha256==jar_hash
    result.update(completed=True,jar_sha256=jar_hash,resumed_from=str(old),recovery_reason='Public export listed receiver-target-created, which the C CLI intentionally never emits. Actual prior test commands succeeded and are reverified against exact command identities and source/package bytes.')
    state['completed']=True
    print('Completed full Debug/Release policy qualification after verified export recovery',flush=True)
finally:
    state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
    sdk.write_json(out/'RECOVERED_COMMANDS.json',recovered)
    sdk.write_json(out/'ANDROID_JNI_CONSUMER.json',result)
