from pathlib import Path
import json
import rust_sdk_profile as sdk
import continuity_c_consumer as c
import continuity_first_configuration as first
root=Path.cwd();base=root/'target/continuity-android-policy-renewal';out=base/'shared-regression';out.mkdir();s=json.loads((base/'STATE.json').read_text());source=Path(s['source']);env=s['environment'];binary=c.built_artifact((base/'harness-build-resolution.stdout').read_bytes(),source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='first_configuration');engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());public=out/'public';public.mkdir(mode=0o700)
runtime=dict(env,QPC_CONFIGURATION_CLIENT=str(base/'build-07/qpc-configuration-client'),QPC_CONFIGURATION_LANGUAGE='C',QPC_CONFIGURATION_RECEIVER=engines['native']['execution']['debug']['binaries']['C_client']['path'],QPERIAPT_CONFIGURATION_EVIDENCE=str(public));runtime.pop('QPERIAPT_PUBLIC_SERVICE_EVIDENCE',None)
stdout=sdk.command([str(binary),'independent_c_','--nocapture','--test-threads=1'],out/'execution',source,environment=runtime)
checked=first.verify_execution(stdout,public,language='C');sdk.write_json(out/'VERIFIED.json',checked);print('Existing local/signed/TLS native policy renewal and expiry regression passed',flush=True)
