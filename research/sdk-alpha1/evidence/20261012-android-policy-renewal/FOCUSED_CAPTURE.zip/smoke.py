from pathlib import Path
import json,os,sys
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();base=root/'target/continuity-android-policy-renewal';state=json.loads((base/'STATE.json').read_text());assert not state['live_producer'];out=base/sys.argv[1];out.mkdir();build=base/sys.argv[3];source=Path(state['source']);env=state['environment']
compiled=(base/(sys.argv[2]+'.stdout')).read_bytes();binary=c.built_artifact(compiled,source,Path(env['CARGO_TARGET_DIR'])/'debug',library=False,test_name='android')
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home');engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text())
driver=out/'driver';driver.write_text('#!'+sys.executable+'\nimport os,sys\nmode,profile,inputs,target,output=sys.argv[1:]\nprobe="PolicyProbe" if mode.startswith("policy-") else "AuthorityProbe"\ncommand='+repr([str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(build),'-cp',str(build/'classes')+os.pathsep+str(build/'tests')])+'\ncommand += ["dev.qperiapt.continuity.android.tests."+probe,inputs,target,profile,mode,output]\nos.execv(command[0],command)\n');driver.chmod(0o700)
runtime=dict(env,QPC_ANDROID_CASES=str(out/'cases'),QPC_ANDROID_DRIVER=str(driver),QPC_CONFIGURATION_RECEIVER=engines['native']['execution']['debug']['binaries']['C_client']['path'],QPC_CONFIGURATION_TARGET_CLIENT=str(build/'qpc-configuration-client'))
sdk.command([str(binary),'--exact','android_policy_renewal::fixed','--nocapture'],out/'execution',source,environment=runtime)
print('Fixed-trust local/signed/TLS policy renewal smoke completed',flush=True)
