from pathlib import Path
import json,shutil,sys
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-renewal';state=json.loads((out/'STATE.json').read_text());assert not state['live_producer'];source=Path(state['source']);old=json.loads((root/'target/continuity-android-policy-expiry-host/STATE.json').read_text());original=Path(old['work'])/'c-consumer'
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(original/name,source/name)
# Refresh only current code; keep the installed archive dependency graph intact.
for p in (root/'bindings/c/ContinuityPackageConsumer').rglob('*'):
 if p.is_file() and p.name not in {'Cargo.toml','Cargo.lock'}:
  target=source/p.relative_to(root/'bindings/c/ContinuityPackageConsumer');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for name in ['owned_connection.rs','owned_connection/enrollment.rs']:shutil.copy2(root/'research/continuity-identity-candidate/tests'/name,source/'packages/q-periapt-continuity-identity-candidate-0.0.0/tests'/name)
state['live_producer']=True;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 sdk.command([str(Path(state['environment']['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--test','first_configuration','--test','enrollment','--no-run','--message-format=json','-j','2'],out/sys.argv[1],source,environment=state['environment'])
finally:
 state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Installed-package harness build completed',flush=True)
