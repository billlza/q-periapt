from pathlib import Path
import json,sys
import rust_sdk_profile as sdk
import continuity_c_consumer as c
root=Path.cwd();out=root/'target/continuity-android-policy-renewal'/sys.argv[1];out.mkdir();source=root/'bindings/android/ContinuityPackageConsumer'
state=json.loads((root/'target/continuity-android-policy-expiry-host/STATE.json').read_text());assert state['completed'] and not state['live_producer']
engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());assert engines['completed'] and not engines['live_producer']
jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
classes=out/'classes';classes.mkdir();tests=out/'tests';tests.mkdir()
sdk.command([str(jdk/'bin/javac'),'--release','11','-Xlint:all','-Werror','-d',str(classes),*map(str,sorted((source/'src/main/java').rglob('*.java')))],out/'main-compile',root)
clang=sdk.command(['xcrun','--sdk','macosx','--find','clang'],out/'clang-path',root).decode().strip();platform=sdk.command(['xcrun','--sdk','macosx','--show-sdk-path'],out/'sdk-path',root).decode().strip()
library=Path(engines['native']['execution']['debug']['binaries']['C_library']['path']);sdk.copy(library,out/library.name,maximum=c.MAX_BINARY)
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-fvisibility=hidden','-isysroot',platform,'-I'+str(root/'bindings/c/ContinuityPackageConsumer'),'-I'+str(jdk/'include'),'-I'+str(jdk/'include/darwin'),'-dynamiclib',*map(str,sorted((source/'jni').glob('*.c'))),'-L'+str(out),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(out/'libqperiapt_continuity_jni.dylib')],out/'bridge',root)
sdk.command([str(jdk/'bin/javac'),'--release','17','-Xlint:all','-Werror','-cp',str(classes),'-d',str(tests),*map(str,sorted((source/'src/test/java').glob('*.java')))],out/'test-compile',root)
sdk.command([str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-Xcheck:jni','-Djava.library.path='+str(out),'-cp',str(classes)+':'+str(tests),'dev.qperiapt.continuity.android.BridgeProbe'],out/'boundary',root)
print('Java main/tests, strict native JNI build and existing boundary probe passed',flush=True)
