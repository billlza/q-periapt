from pathlib import Path
import continuity_android_policy_renewal as renewal
import rust_sdk_profile as sdk
out=Path.cwd()/'target/continuity-android-policy-renewal/smoke-06'
result=renewal.verify_execution((out/'execution.stdout').read_bytes(),out/'cases','fixed')
sdk.write_json(out/'VERIFIED.json',result);print('117 host Java policy renewal processes and all public linkage verified',flush=True)
