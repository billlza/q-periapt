from pathlib import Path
import json,shutil,tempfile
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-renewal';previous=json.loads((root/'target/continuity-android-policy-expiry-host/STATE.json').read_text());assert previous['completed'] and not previous['live_producer']
files=['research/continuity-identity-candidate/tests/owned_connection.rs','research/continuity-identity-candidate/tests/owned_connection/enrollment.rs','bindings/c/ContinuityPackageConsumer/tests/first_configuration.rs','bindings/c/ContinuityPackageConsumer/tests/common/first_expiry.rs','bindings/c/ContinuityPackageConsumer/tests/common/first_policy.rs','bindings/c/ContinuityPackageConsumer/tests/common/policy_request.rs','bindings/c/ContinuityPackageConsumer/tests/enrollment/independent_policy.rs','bindings/c/ContinuityPackageConsumer/tests/common/receiver_policy.rs','bindings/c/ContinuityPackageConsumer/tests/android.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/flow.rs','bindings/c/ContinuityPackageConsumer/tests/common/android_policy_renewal/traffic.rs']
rust=Path(previous['environment']['RUSTC']).parent
sdk.command([str(rust/'rustfmt'),'--edition','2021','--config','skip_children=true',*files],out/'format',root)
work=Path(tempfile.mkdtemp(prefix='qperiapt-android-policy-renewal-')).resolve();source=work/'c-consumer'
shutil.copytree(Path(previous['work'])/'c-consumer',source,ignore=shutil.ignore_patterns('target','.git'))
for p in (root/'bindings/c/ContinuityPackageConsumer').rglob('*'):
 if p.is_file():
  dest=source/p.relative_to(root/'bindings/c/ContinuityPackageConsumer');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for name in ['owned_connection.rs','owned_connection/enrollment.rs']:
 shutil.copy2(root/'research/continuity-identity-candidate/tests'/name,source/'packages/q-periapt-continuity-identity-candidate-0.0.0/tests'/name)
env=dict(previous['environment'],CARGO_TARGET_DIR=str(work/'build'))
sdk.write_json(out/'STATE.json',{'work':str(work),'environment':env,'source':str(source),'base_commit':'3ae7bba1b661635850a2216df49c939d07589385','completed':False,'live_producer':True})
try:
 sdk.command([str(rust/'cargo'),'test','--locked','--offline','--test','android','--test','first_configuration','--test','enrollment','--no-run','--message-format=json','-j','2'],out/'harness-build',source,environment=env)
finally:
 state=json.loads((out/'STATE.json').read_text());state['live_producer']=False;(out/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
print('Fresh installed-package harnesses compiled',flush=True)
