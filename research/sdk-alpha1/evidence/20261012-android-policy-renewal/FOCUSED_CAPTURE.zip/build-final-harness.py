from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-renewal';s=json.loads((root/'target/continuity-android-policy-renewal-host/STATE.json').read_text());assert not s['live_producer'];env=s['environment']
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'test','--locked','--offline','--test','android','--no-run','--message-format=json','-j','2'],out/'harness-final',Path(s['source']),environment=env)
print('Final Android harness compiled',flush=True)
