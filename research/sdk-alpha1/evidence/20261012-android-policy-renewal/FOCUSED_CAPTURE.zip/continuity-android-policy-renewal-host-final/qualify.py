from pathlib import Path
import json
import continuity_android_jni as android
out=Path(__file__).resolve().parent;root=out.parents[1];s=json.loads((out/'STATE.json').read_text());engines=json.loads((root/'target/continuity-local-roster-expiry-fix/ENGINES.json').read_text());assert engines['completed'] and not engines['live_producer']
work=Path(s['work']);env=s['environment'];native=engines['native'];jdk=Path('/Users/bill/Documents/Codex/sdk-020-recovery-20260929-160244/continuity-kotlin-development/toolchains/installed/jdk-25.0.4.1+1/Contents/Home')
s.update(native=native,live_producer=True);(out/'STATE.json').write_text(json.dumps(s,indent=2)+'\n')
try:
 result=android.qualify_android_jni(work,out,native,env,jdk);s['completed']=result['completed'];print('Corrected native engines pass full Debug/Release Android JNI lifecycle qualification',flush=True)
finally:
 s['live_producer']=False;(out/'STATE.json').write_text(json.dumps(s,indent=2)+'\n')
