from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-renewal';s=json.loads((out/'STATE.json').read_text());env=dict(s['environment'],CARGO_TARGET_DIR=str(out/'clippy-build'))
sdk.command([str(Path(env['RUSTC']).parent/'cargo'),'clippy','--locked','--offline','--test','android','--test','first_configuration','--test','enrollment','-j','2','--','-D','warnings'],out/'clippy',Path(s['source']),environment=env)
print('Android, first-configuration and enrollment strict Clippy passed',flush=True)
