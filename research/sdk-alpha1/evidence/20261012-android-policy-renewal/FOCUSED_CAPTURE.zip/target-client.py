from pathlib import Path
import json
import rust_sdk_profile as sdk
root=Path.cwd();out=root/'target/continuity-android-policy-renewal';build=out/'build-04';s=json.loads((out/'STATE.json').read_text());source=Path(s['source']);clang=(build/'clang-path.stdout').read_text().strip();platform=(build/'sdk-path.stdout').read_text().strip()
sdk.command([clang,'-std=c11','-Wall','-Wextra','-Werror','-Wpedantic','-isysroot',platform,str(source/'first_configuration_client.c'),'-I',str(source),'-L',str(build),'-lq_periapt_continuity_c_consumer','-Wl,-rpath,@loader_path','-o',str(build/'qpc-configuration-client')],out/'target-client-build',root)
print('Native counterpart configuration client compiled',flush=True)
