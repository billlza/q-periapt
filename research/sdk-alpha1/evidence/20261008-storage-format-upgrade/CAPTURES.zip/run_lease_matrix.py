#!/usr/bin/env python3
"""Check one continuous lease when recovering the retained interrupted files."""
import collections
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
OUT = ROOT / sys.argv[1]
OUT.mkdir(mode=0o700)
BIN = ROOT / "build/debug/policy-store-lease-probe"

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def identity():
    files = list((ROOT / "bridge/src").rglob("*.rs")) + [ROOT / "bridge/Cargo.toml", ROOT / "bridge/Cargo.lock", BIN, Path(__file__), ROOT / "matrix-01/RESULT.json"]
    return {str(p.relative_to(REPO)): sha(p) for p in files}

before = identity()
results = []
inputs = list(sorted((ROOT / "matrix-01").glob("*/cut.redb")))
inputs += [ROOT / "control-01/policy.redb"]
for i, source in enumerate(inputs):
    label = source.parent.name
    d = OUT / label
    d.mkdir(mode=0o700)
    candidate = d / "candidate.redb"
    shutil.copyfile(source, candidate)
    candidate.chmod(0o600)
    with source.open("rb") as stream:
        header = stream.read(320)
    versions = [header[64], header[192]]
    c = [str(BIN), "lease", str(candidate)]
    start = time.monotonic()
    with (d / "stdout").open("wb") as out, (d / "stderr").open("wb") as err:
        try:
            rc = subprocess.run(c, stdout=out, stderr=err, timeout=30, check=False).returncode
        except subprocess.TimeoutExpired:
            rc = "timeout"
    records = []
    for line in (d / "stdout").read_text().splitlines():
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    final = records[-1] if records else {}
    expected_legacy = versions != [3, 3]
    peers = sum(r.get("independent_competitors_refused", 0) for r in records)
    ok = rc == 0 and final.get("lease_handoff") is True and final.get("legacy_used") == expected_legacy and peers == (10 if expected_legacy else 6)
    result = {"case": label, "source": str(source), "source_sha256": sha(source),
              "input_versions": versions, "command": c, "returncode": rc,
              "seconds": time.monotonic()-start, "records": records, "ok": ok,
              "stdout_sha256": sha(d / "stdout"), "stderr_sha256": sha(d / "stderr")}
    (d / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    if ok:
        candidate.unlink()
    results.append(result)
    if (i+1) % 20 == 0:
        print(json.dumps({"completed": i+1, "failures": sum(not r["ok"] for r in results)}), flush=True)
after = identity()
result = {"source_before": before, "source_after": after, "source_unchanged": before == after,
          "case_count": len(results), "passed": sum(r["ok"] for r in results),
          "peer_refusals": sum(sum(e.get("independent_competitors_refused",0) for e in r["records"]) for r in results),
          "dispatch": dict(collections.Counter("legacy" if r["input_versions"] != [3,3] else "current" for r in results)),
          "failed": [r["case"] for r in results if not r["ok"]],
          "scope": "Public exact fixture only, macOS independent processes, no power-loss or product migration API claim"}
(OUT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k:v for k,v in result.items() if k not in ("source_before","source_after")}),flush=True)
sys.exit(0 if before == after and not result["failed"] else 1)
