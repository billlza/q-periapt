#![forbid(unsafe_code)]
use std::{
    collections::BTreeMap, error::Error, fs::OpenOptions, os::unix::fs::OpenOptionsExt, path::Path,
};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
const TABLE: redb::TableDefinition<&str, &[u8]> = redb::TableDefinition::new("sdk_host_policy_v1");
fn hex(s: &str) -> Result<Vec<u8>> {
    if !s.len().is_multiple_of(2) {
        return Err("odd hex".into());
    }
    (0..s.len())
        .step_by(2)
        .map(|i| Ok(u8::from_str_radix(s.get(i..i + 2).ok_or("hex width")?, 16)?))
        .collect()
}
fn main() -> Result<()> {
    let arg = std::env::args().nth(1).ok_or("output path")?;
    let path = Path::new(&arg);
    let fixtures = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../../bindings/sdk-policy-recovery-vectors.json");
    let fields: BTreeMap<String, String> = serde_json::from_slice(&std::fs::read(fixtures)?)?;
    let get = |name: &str| hex(fields.get(name).ok_or("missing public fixture")?);
    let request = get("request")?;
    let image = BTreeMap::from([
        ("schema", b"QPeriapt-Host-Policy-v1".to_vec()),
        ("root", get("initial_root")?),
        ("policy", get("initial_policy")?),
        ("signature", get("initial_signature")?),
        (
            "state",
            request
                .get(112..148)
                .ok_or("public request state")?
                .to_vec(),
        ),
    ]);
    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(path)?;
    let mut builder = redb::Database::builder();
    builder.set_cache_size(2 * 1024 * 1024);
    let db = builder.create_with_backend(redb::backends::FileBackend::new(file)?)?;
    let mut tx = db.begin_write()?;
    tx.set_durability(redb::Durability::Immediate);
    tx.set_two_phase_commit(true);
    {
        let mut table = tx.open_table(TABLE)?;
        for (name, data) in image {
            table.insert(name, data.as_slice())?;
        }
    }
    tx.commit()?;
    drop(db);
    println!("LEGACY_POLICY_FORMAT2_FIXTURE_CREATED");
    Ok(())
}
