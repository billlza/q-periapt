//! Experimental descriptor handoff; admits only the public fixture image.
use super::{Result, expected, image_hash, read_image};
use q_periapt_host_store::filesystem::{
    LockedFileBackend, MAX_PRIVATE_DATABASE_BYTES, open_private_file, refuse_unclean_foreign_redb,
};
use redb::{ReadableDatabase, ReadableTable, StorageBackend, TableHandle};
use serde_json::json;
use std::{
    collections::BTreeMap,
    io,
    os::unix::fs::MetadataExt,
    path::Path,
    sync::{Arc, Mutex},
};

#[derive(Debug)]
struct Shared {
    backend: LockedFileBackend,
    failure: Mutex<Option<io::Error>>,
}
impl Shared {
    fn observe<T>(&self, result: io::Result<T>) -> io::Result<T> {
        result.map_err(|error| {
            // Diagnostic copy for this experiment. Product code must retain a
            // shared original error rather than flattening its source chain.
            let mut first = self.failure.lock().expect("I/O record");
            if first.is_none() {
                *first = Some(io::Error::new(error.kind(), error.to_string()));
            }
            error
        })
    }
}
#[derive(Debug)]
struct Legacy(Arc<Shared>);
fn extent(offset: u64, len: u64) -> io::Result<()> {
    if offset
        .checked_add(len)
        .is_some_and(|end| end <= MAX_PRIVATE_DATABASE_BYTES)
    {
        Ok(())
    } else {
        Err(io::Error::other("migration extent exceeds bound"))
    }
}
impl redb_upgrade::StorageBackend for Legacy {
    fn len(&self) -> io::Result<u64> {
        self.0.observe(self.0.backend.len())
    }
    fn read(&self, offset: u64, len: usize) -> io::Result<Vec<u8>> {
        extent(offset, len as u64)?;
        let mut out = vec![0; len];
        self.0.observe(self.0.backend.read(offset, &mut out))?;
        Ok(out)
    }
    fn write(&self, offset: u64, bytes: &[u8]) -> io::Result<()> {
        extent(offset, bytes.len() as u64)?;
        self.0.observe(self.0.backend.write(offset, bytes))
    }
    fn set_len(&self, len: u64) -> io::Result<()> {
        extent(0, len)?;
        self.0.observe(self.0.backend.set_len(len))
    }
    fn sync_data(&self, _eventual: bool) -> io::Result<()> {
        self.0.observe(self.0.backend.sync_data())
    }
}
fn input_path() -> Result<std::path::PathBuf> {
    Ok(std::env::args().nth(2).ok_or("path")?.into())
}
pub fn legacy_busy() -> Result<()> {
    let file = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(input_path()?)?;
    match redb_upgrade::backends::FileBackend::new(file) {
        Err(redb_upgrade::DatabaseError::DatabaseAlreadyOpen) => Ok(()),
        Err(error) => Err(error.into()),
        Ok(_) => Err("legacy competitor acquired the held file".into()),
    }
}
pub fn current_busy() -> Result<()> {
    let file = open_private_file(&input_path()?, false)?;
    match LockedFileBackend::new(file) {
        Err(redb::DatabaseError::DatabaseAlreadyOpen) => Ok(()),
        Err(error) => Err(error.into()),
        Ok(_) => Err("current competitor acquired the held file".into()),
    }
}
fn peers(path: &Path, phase: &str) -> Result<()> {
    for command in ["legacy-busy", "current-busy"] {
        let out = std::process::Command::new(std::env::current_exe()?)
            .arg(command)
            .arg(path)
            .output()?;
        if !out.status.success() {
            return Err(format!(
                "{phase} {command}: {:?}: {}",
                out.status.code(),
                String::from_utf8_lossy(&out.stderr)
            )
            .into());
        }
    }
    println!(
        "{}",
        json!({"lease_phase":phase,"independent_competitors_refused":2})
    );
    Ok(())
}
pub fn run() -> Result<()> {
    let path = input_path()?;
    let image = expected()?;
    let file = open_private_file(&path, false)?;
    let inode_probe = file.try_clone()?;
    let backend = LockedFileBackend::new(file)?;
    let meta = inode_probe.metadata()?;
    if meta.nlink() != 1 || !(320..=MAX_PRIVATE_DATABASE_BYTES).contains(&meta.len()) {
        return Err("private inode/extent differs".into());
    }
    refuse_unclean_foreign_redb(&backend)?;
    let mut header = [0; 320];
    backend.read(0, &mut header)?;
    if header.get(..9) != Some(&[b'r', b'e', b'd', b'b', 0x1a, 0x0a, 0xa9, 0x0d, 0x0a])
        || header[9] & !7 != 0
    {
        return Err("format preflight differs".into());
    }
    // Validate each complete slot before its version can select a provider.
    // This is corruption detection, not authentication. Both slots must pass:
    // this migration experiment does not authorize rollback to a surviving slot.
    for start in [64, 192] {
        let slot = header.get(start..start + 128).ok_or("short commit slot")?;
        let stored = u128::from_le_bytes(
            slot.get(112..128)
                .ok_or("slot checksum width")?
                .try_into()?,
        );
        let calculated =
            twox_hash::XxHash3_128::oneshot_with_seed(0, slot.get(..112).ok_or("slot body width")?);
        if stored != calculated {
            return Err("slot checksum mismatch before provider dispatch".into());
        }
    }
    let slots = [header[64], header[192]];
    let legacy = match slots {
        [3, 3] => false,
        [2, 2] | [2, 3] | [3, 2] => true,
        _ => return Err("unsupported format slots".into()),
    };
    peers(&path, "admitted")?;
    let backend = if legacy {
        let shared = Arc::new(Shared {
            backend,
            failure: Mutex::new(None),
        });
        let mut builder = redb_upgrade::Database::builder();
        builder.set_cache_size(2 * 1024 * 1024);
        let mut db = builder.create_with_backend(Legacy(Arc::clone(&shared)))?;
        if read_image(&db)? != image {
            return Err("legacy image differs from authenticated expectation".into());
        }
        peers(&path, "legacy-authenticated")?;
        db.upgrade()?;
        if read_image(&db)? != image {
            return Err("upgrade changed the logical image".into());
        }
        drop(db);
        if let Some(error) = shared.failure.lock().expect("I/O record").take() {
            return Err(error.into());
        }
        peers(&path, "legacy-dropped")?;
        Arc::try_unwrap(shared)
            .map_err(|_| "legacy provider retained the shared lease")?
            .backend
    } else {
        backend
    };
    peers(&path, "handoff")?;
    let mut builder = redb::Database::builder();
    builder.set_cache_size(2 * 1024 * 1024);
    let db = builder.create_with_backend(backend)?;
    let read = db.begin_read()?;
    let tables = read.list_tables()?.collect::<Vec<_>>();
    if tables.len() != 1
        || tables[0].name() != "sdk_host_policy_v1"
        || read.list_multimap_tables()?.next().is_some()
    {
        return Err("current table inventory differs".into());
    }
    let table = read.open_table(redb::TableDefinition::<&str, &[u8]>::new(
        "sdk_host_policy_v1",
    ))?;
    let mut actual = BTreeMap::new();
    for entry in table.iter()? {
        let (k, v) = entry?;
        actual.insert(k.value().to_owned(), v.value().to_vec());
    }
    if actual != image {
        return Err("current reader image differs".into());
    }
    peers(&path, "current-authenticated")?;
    drop(table);
    drop(read);
    drop(db);
    drop(inode_probe);
    // The production SDK now admits the same exact image after the final owner
    // closes. No legacy provider is opened again on this format-v3 database.
    super::verify(&path, &image)?;
    println!(
        "{}",
        json!({"lease_handoff":true,"legacy_used":legacy,"initial_slots":slots,"image_sha256":image_hash(&image)})
    );
    Ok(())
}
