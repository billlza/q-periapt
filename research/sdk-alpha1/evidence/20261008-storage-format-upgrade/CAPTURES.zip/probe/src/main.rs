#![forbid(unsafe_code)]
use q_periapt_sdk::{Limits, Runtime};
use redb_upgrade::{ReadableTable, StorageBackend, TableHandle};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    error::Error,
    fs::{File, OpenOptions},
    io::{self, Write},
    os::unix::fs::FileExt,
    path::Path,
    sync::{
        Arc, Mutex,
        atomic::{AtomicUsize, Ordering},
    },
};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
const TABLE: redb_upgrade::TableDefinition<&str, &[u8]> =
    redb_upgrade::TableDefinition::new("sdk_host_policy_v1");
fn hex(s: &str) -> Result<Vec<u8>> {
    if !s.len().is_multiple_of(2) {
        return Err("odd hex".into());
    }
    (0..s.len())
        .step_by(2)
        .map(|i| Ok(u8::from_str_radix(s.get(i..i + 2).ok_or("hex width")?, 16)?))
        .collect()
}
fn expected() -> Result<BTreeMap<String, Vec<u8>>> {
    let path = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../../bindings/sdk-policy-recovery-vectors.json");
    let f: BTreeMap<String, String> = serde_json::from_slice(&std::fs::read(path)?)?;
    let get = |name: &str| hex(f.get(name).ok_or("missing public fixture")?);
    let policy = get("initial_policy")?;
    let signature = get("initial_signature")?;
    let root = get("initial_root")?;
    let runtime = Runtime::from_signed_policy(&policy, &signature, &root, None, Limits::default())?;
    Ok(BTreeMap::from([
        ("schema".into(), b"QPeriapt-Host-Policy-v1".to_vec()),
        ("root".into(), root),
        ("policy".into(), policy),
        ("signature".into(), signature),
        ("state".into(), runtime.trusted_state().encode().to_vec()),
    ]))
}
fn image_hash(image: &BTreeMap<String, Vec<u8>>) -> String {
    let mut h = Sha256::new();
    for (name, bytes) in image {
        h.update((name.len() as u64).to_be_bytes());
        h.update(name.as_bytes());
        h.update((bytes.len() as u64).to_be_bytes());
        h.update(bytes);
    }
    h.finalize().iter().map(|b| format!("{b:02x}")).collect()
}
fn header(path: &Path) -> Result<serde_json::Value> {
    let f = File::open(path)?;
    let mut bytes = [0; 193];
    f.read_exact_at(&mut bytes, 0)?;
    Ok(json!({"god":bytes[9],"primary":bytes[9]&1,"slot_versions":[bytes[64],bytes[192]]}))
}
#[derive(Debug)]
struct Control {
    count: AtomicUsize,
    phase: AtomicUsize,
    target: usize,
    after: bool,
    exit: bool,
    triggered: AtomicUsize,
    events: Mutex<Vec<serde_json::Value>>,
}
impl Control {
    fn event(&self, kind: &str, offset: u64, len: u64) -> usize {
        let phase = self.phase.load(Ordering::SeqCst);
        if phase == 0 {
            return 0;
        }
        let index = self.count.fetch_add(1, Ordering::SeqCst) + 1;
        self.events
            .lock()
            .expect("event record")
            .push(json!({"index":index,"phase":phase,"kind":kind,"offset":offset,"length":len}));
        index
    }
    fn boundary(&self, index: usize, after: bool) -> io::Result<()> {
        if index != 0 && index == self.target && self.after == after {
            self.triggered
                .store(self.phase.load(Ordering::SeqCst), Ordering::SeqCst);
            if self.exit {
                println!(
                    "{}",
                    json!({"cut":index,"after":after,"phase":self.phase.load(Ordering::SeqCst)})
                );
                io::stdout().flush()?;
                std::process::exit(72);
            }
            return Err(io::Error::other("injected upgrade I/O boundary"));
        }
        Ok(())
    }
}
#[derive(Debug)]
struct Backend {
    inner: redb_upgrade::backends::FileBackend,
    control: Arc<Control>,
}
impl StorageBackend for Backend {
    fn len(&self) -> io::Result<u64> {
        self.inner.len()
    }
    fn read(&self, offset: u64, len: usize) -> io::Result<Vec<u8>> {
        self.inner.read(offset, len)
    }
    fn set_len(&self, len: u64) -> io::Result<()> {
        let n = self.control.event("set_len", 0, len);
        self.control.boundary(n, false)?;
        self.inner.set_len(len)?;
        self.control.boundary(n, true)
    }
    fn write(&self, offset: u64, data: &[u8]) -> io::Result<()> {
        let n = self.control.event("write", offset, data.len() as u64);
        self.control.boundary(n, false)?;
        self.inner.write(offset, data)?;
        self.control.boundary(n, true)
    }
    fn sync_data(&self, eventual: bool) -> io::Result<()> {
        let n = self
            .control
            .event(if eventual { "barrier" } else { "sync" }, 0, 0);
        self.control.boundary(n, false)?;
        self.inner.sync_data(eventual)?;
        self.control.boundary(n, true)
    }
}
fn read_image(db: &redb_upgrade::Database) -> Result<BTreeMap<String, Vec<u8>>> {
    let read = db.begin_read()?;
    let tables = read.list_tables()?.collect::<Vec<_>>();
    if tables.len() != 1
        || tables[0].name() != "sdk_host_policy_v1"
        || read.list_multimap_tables()?.next().is_some()
    {
        return Err("unexpected table inventory".into());
    }
    let table = read.open_table(TABLE)?;
    let mut image = BTreeMap::new();
    for entry in table.iter()? {
        let (k, v) = entry?;
        image.insert(k.value().to_owned(), v.value().to_vec());
    }
    Ok(image)
}
fn upgrade(
    path: &Path,
    image: &BTreeMap<String, Vec<u8>>,
    target: usize,
    after: bool,
    exit: bool,
) -> Result<()> {
    let file = OpenOptions::new().read(true).write(true).open(path)?;
    let control = Arc::new(Control {
        count: AtomicUsize::new(0),
        phase: AtomicUsize::new(0),
        target,
        after,
        exit,
        triggered: AtomicUsize::new(0),
        events: Mutex::new(Vec::new()),
    });
    let mut builder = redb_upgrade::Database::builder();
    builder.set_cache_size(2 * 1024 * 1024);
    let mut db = builder.create_with_backend(Backend {
        inner: redb_upgrade::backends::FileBackend::new(file)?,
        control: Arc::clone(&control),
    })?;
    if &read_image(&db)? != image {
        return Err("logical input differs".into());
    }
    control.phase.store(1, Ordering::SeqCst);
    let outcome = db.upgrade().map_err(|e| format!("{e:?}"));
    let valid = if outcome.is_ok() {
        Some(read_image(&db)? == *image)
    } else {
        None
    };
    control.phase.store(2, Ordering::SeqCst);
    drop(db);
    let triggered = control.triggered.load(Ordering::SeqCst);
    println!(
        "{}",
        json!({"image_sha256":image_hash(image),"upgrade_result":outcome,"logical_preserved":valid,"header":header(path)?,"fault_phase":triggered,"events":&*control.events.lock().expect("events")})
    );
    if outcome.is_err() || triggered != 0 || valid != Some(true) {
        return Err("upgrade or close did not complete cleanly".into());
    }
    Ok(())
}
fn verify(path: &Path, image: &BTreeMap<String, Vec<u8>>) -> Result<()> {
    let root = image.get("root").ok_or("root")?;
    match q_periapt_host_store::PolicyStore::open(path, root, Limits::default()) {
        Ok(store) => {
            let runtime = store.runtime()?;
            let equal =
                runtime.trusted_state().encode().as_slice() == image.get("state").ok_or("state")?;
            let enabled = runtime.is_enabled()?;
            println!(
                "{}",
                json!({"current_reader":"redb4.3-owned-SDK","ok":equal&&enabled,"header":header(path)?})
            );
            if !equal || !enabled {
                return Err("authenticated state changed".into());
            }
            Ok(())
        }
        Err(e) => {
            println!(
                "{}",
                json!({"current_reader":"redb4.3-owned-SDK","ok":false,"error":format!("{e:?}"),"header":header(path)?})
            );
            Err(e.into())
        }
    }
}
fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    let command = args.get(1).ok_or("command")?;
    let path = Path::new(args.get(2).ok_or("path")?);
    let image = expected()?;
    match command.as_str() {
        "verify" => verify(path, &image),
        "upgrade" => upgrade(
            path,
            &image,
            args.get(3).ok_or("target")?.parse()?,
            args.get(4).ok_or("edge")? == "after",
            args.get(5).ok_or("fault")? == "exit",
        ),
        _ => Err("unknown command".into()),
    }
}
