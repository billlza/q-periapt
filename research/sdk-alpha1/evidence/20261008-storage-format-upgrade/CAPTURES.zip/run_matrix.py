#!/usr/bin/env python3
"""Isolated real-file migration experiment; never opens deployment state."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
BIN = ROOT / "build/debug/policy-store-upgrade-probe"
BASE = ROOT / "control-01/original-v2.redb"
OUT = ROOT / sys.argv[1]
OUT.mkdir(mode=0o700)

def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()

def header(path):
    with path.open("rb") as f:
        h = f.read(320)
    return {"god": h[9], "primary": h[9] & 1, "versions": [h[64], h[192]]}

def copy(src, dst):
    shutil.copyfile(src, dst)
    dst.chmod(0o600)

def command(directory, label, args):
    start = time.monotonic()
    with (directory / (label + ".stdout")).open("wb") as out, (directory / (label + ".stderr")).open("wb") as err:
        try:
            p = subprocess.run([str(BIN), *map(str, args)], stdout=out, stderr=err, timeout=30, check=False)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = "timeout"
    output = (directory / (label + ".stdout")).read_text()
    records = []
    for line in output.splitlines():
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return {"command": [str(BIN), *map(str, args)], "returncode": rc,
            "seconds": time.monotonic() - start, "records": records,
            "stdout_sha256": sha(directory / (label + ".stdout")),
            "stderr_sha256": sha(directory / (label + ".stderr"))}

def identity():
    files = [ROOT / "probe/src/main.rs", ROOT / "probe/Cargo.toml", ROOT / "probe/Cargo.lock",
             ROOT / "fixture/src/main.rs", ROOT / "fixture/Cargo.toml", ROOT / "fixture/Cargo.lock",
             Path(__file__), BIN, BASE, REPO / "bindings/sdk-policy-recovery-vectors.json"]
    return {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
            "files": {str(p.relative_to(REPO)): sha(p) for p in files}}

before = identity()
baseline = json.loads((ROOT / "control-01/upgrade.stdout").read_text())
results = []
for event in baseline["events"]:
    for edge in ("before", "after"):
        for fault in ("error", "exit"):
            label = f'{event["index"]:02d}-{edge}-{fault}'
            d = OUT / label
            d.mkdir(mode=0o700)
            cut = d / "cut.redb"
            copy(BASE, cut)
            result = {"case": label, "baseline_event": event}
            result["fault"] = command(d, "fault", ["upgrade", cut, event["index"], edge, fault])
            result["cut_header"] = header(cut)
            result["cut_sha256"] = sha(cut)
            triggered = any(r.get("cut") == event["index"] or r.get("fault_phase", 0) > 0 for r in result["fault"]["records"])
            result["fault_observed"] = triggered
            candidate = d / "candidate.redb"
            copy(cut, candidate)
            result["current"] = command(d, "current", ["verify", candidate])
            result["after_current_header"] = header(candidate)
            result["current_changed_file"] = sha(candidate) != result["cut_sha256"]
            current = result["current"]
            if current["returncode"] == 0:
                result["outcome"] = "current_authenticated_exact_state"
            elif any("UpgradeRequired(2)" in r.get("error", "") for r in current["records"]):
                result["retry"] = command(d, "retry", ["upgrade", candidate, 0, "before", "error"])
                result["verify_retry"] = command(d, "verify-retry", ["verify", candidate])
                result["outcome"] = "legacy_retry_then_current_exact_state" if result["retry"]["returncode"] == 0 and result["verify_retry"]["returncode"] == 0 else "retry_failed"
            else:
                result["outcome"] = "current_refused_other"
            result["final_header"] = header(candidate)
            (d / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
            # Retain the untouched interrupted database. The ordinary verified
            # candidate is reproducible from it and logs; keep only failures.
            if result["outcome"] in ("current_authenticated_exact_state", "legacy_retry_then_current_exact_state"):
                candidate.unlink()
            results.append(result)
            if len(results) % 12 == 0:
                print(json.dumps({"completed": len(results), "outcomes": dict(collections.Counter(r["outcome"] for r in results))}), flush=True)
after = identity()
result = {"at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_before": before,
          "source_after": after, "source_unchanged": before == after,
          "case_count": len(results), "faults_observed": sum(r["fault_observed"] for r in results),
          "outcomes": dict(collections.Counter(r["outcome"] for r in results)),
          "current_refusal_modified": [r["case"] for r in results if r["current"]["returncode"] != 0 and r["current_changed_file"]],
          "failed_or_missing": [r["case"] for r in results if not r["fault_observed"] or r["outcome"] not in ("current_authenticated_exact_state", "legacy_retry_then_current_exact_state")],
          "cases": [{"case": r["case"], "outcome": r["outcome"], "cut_header": r["cut_header"]} for r in results],
          "limits": ["Only public policy fixture and macOS process-cut/typed I/O faults; not power-loss emulation", "Experimental current-first retry sequence does not retain one lock across processes", "Format conversion does not establish freshness or witness reconciliation", "No product migration API implemented"]}
(OUT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("source_before", "source_after", "cases")}), flush=True)
sys.exit(0 if before == after and not result["failed_or_missing"] else 1)
