#!/usr/bin/env python3
"""Paired negative controls; expected old panic is a reproduced defect."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
out = root / sys.argv[1]
out.mkdir(mode=0o700)
def sha(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
results = []
for slot in (64,192):
    for label, name in (("before", "policy-store-lease-probe-without-checksum"), ("after", "policy-store-lease-probe")):
        d = out / f"{slot}-{label}"
        d.mkdir(mode=0o700)
        f = d / "corrupt.redb"
        shutil.copyfile(root / "lease-control-01/policy.redb", f)
        f.chmod(0o600)
        with f.open("r+b") as stream:
            stream.seek(slot)
            assert stream.read(1) == b"\x03"
            stream.seek(slot)
            stream.write(b"\x02")
        before = sha(f)
        binary = root / "build/debug" / name
        command = [str(binary), "lease", str(f)]
        with (d/"stdout").open("wb") as stdout,(d/"stderr").open("wb") as stderr:
            r = subprocess.run(command,stdout=stdout,stderr=stderr,timeout=30,check=False)
        message = (d/"stderr").read_text()
        expected = r.returncode == (101 if label == "before" else 1) and before == sha(f)
        expected &= "panicked at" in message if label == "before" else "slot checksum mismatch before provider dispatch" in message
        item = {"slot":slot,"variant":label,"command":command,"binary_sha256":sha(binary),
                "returncode":r.returncode,"file_unchanged":before==sha(f),"expected_observation":expected,
                "input_sha256":before,"stdout_sha256":sha(d/"stdout"),"stderr_sha256":sha(d/"stderr")}
        results.append(item)
        (d/"RESULT.json").write_text(json.dumps(item,indent=2)+"\n")
(out/"RESULT.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results),flush=True)
sys.exit(0 if all(r["expected_observation"] for r in results) else 1)
