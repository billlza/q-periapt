import Foundation
import Darwin

@main
struct ContinuityIOSRunner {
    static func main() async {
        do {
            try await Task.sleep(for:.milliseconds(500))
            let args=Array(CommandLine.arguments.dropFirst())
            guard args.count==6, ["fixed","recoverable"].contains(args[1]), args[4]=="signed", args[5]=="managed",
                  args[0].utf8.count<64, args[2].count==32, args[3].count==32,
                  (args[2]+args[3]).allSatisfy({"0123456789abcdef".contains($0)}) else { throw ClientError("replacement arguments") }
            let mode=args[0],profile=args[1],scenario=args[2],run=args[3]
            let documents=try FileManager.default.url(for:.documentDirectory,in:.userDomainMask,appropriateFor:nil,create:false)
            let source=documents.appendingPathComponent("inputs-"+scenario,isDirectory:true)
            let privateRoot=documents.appendingPathComponent("private-continuity",isDirectory:true)
            if !FileManager.default.fileExists(atPath:privateRoot.path) { try FileManager.default.createDirectory(at:privateRoot,withIntermediateDirectories:false,attributes:[.posixPermissions:0o700]) }
            guard let resolved=realpath(privateRoot.path,nil) else { throw NSError(domain:NSPOSIXErrorDomain,code:Int(errno)) }
            let canonical=String(cString:resolved);free(resolved)
            let path=canonical+"/installation-"+scenario, output=documents.appendingPathComponent("result-"+run+".bin").path
            let command=["ContinuityIOSRunner",mode,profile,source.path,path,output,run]
            if mode.hasPrefix("retired-owned-") { try ReplacementCommands.run(command) }
            else { try await usbOperation(arguments:command,source:source,mode:mode,run:run) }
            let marker="QPC_IOS_REPLACEMENT_PASS mode=\(mode) profile=\(profile) run=\(run)\n"
            try durableIOS(Array(marker.utf8),documents.appendingPathComponent("receipt-"+run+".txt").path)
            try FileHandle.standardOutput.write(contentsOf:Data(marker.utf8));exit(0)
        } catch {
            do { try FileHandle.standardError.write(contentsOf:Data("QPC_IOS_REPLACEMENT_FAIL \(error)\n".utf8)) }
            catch { exit(74) };exit(1)
        }
    }
}
