import Foundation
import Darwin
import QPeriaptContinuity

func requireIOS(_ value: Bool, _ message: String) throws {
    guard value else { throw ClientError(message) }
}
func bigNumber<T: FixedWidthInteger>(_ value: T) -> [UInt8] {
    var wire = value.bigEndian
    return withUnsafeBytes(of: &wire) { Array($0) }
}
func durableIOS(_ bytes: [UInt8], _ path: String) throws {
    let fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0o600)
    guard fd >= 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let file = FileHandle(fileDescriptor: fd, closeOnDealloc: false)
    let outcome = Result { try file.write(contentsOf: Data(bytes)); try file.synchronize() }
    do { try file.close() } catch { throw ClientError("file close: \(error); operation: \(outcome)") }
    try outcome.get()
    let parent = (path as NSString).deletingLastPathComponent
    let directory = open(parent, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW)
    guard directory >= 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
    let synced = fsync(directory), syncError = errno, closed = close(directory), closeError = errno
    guard synced == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(syncError)) }
    guard closed == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(closeError)) }
}
struct ReplacementInputs {
    let source: URL, path: String
    func read(_ name: String, _ maximum: Int = 65536) throws -> [UInt8] { try load(source, name, maximum) }
    func fixed(_ name: String, _ size: Int) throws -> [UInt8] { try exact(source, name, size) }
    func intent() throws -> EnrollmentIntent {
        let value = try fixed("enrollment-intent",72)
        return try EnrollmentIntent(root: fixed("enrollment-root",1985), device: Array(value[0..<16]),
            generation: counter(value[16..<24]), family: Array(value[24..<56]),
            validFrom: counter(value[56..<64]), validUntil: counter(value[64..<72]))
    }
    func account() throws -> AccountPin {
        try AccountPin(account: AccountID(bytes: fixed("trusted-account",32)), root: fixed("enrollment-root",1985),
            family: fixed("family",32), checkpoint: RosterCheckpoint(version: counter(fixed("trusted-roster-version",8)[...]), digest: fixed("trusted-roster-digest",32)))
    }
    func registryTrust() throws -> AccountAuthorityTrust {
        try AccountAuthorityTrust(identity: AccountAuthorityID(bytes: fixed("authority-id",32)), family: fixed("family",32),
                                  witness: fixed("witness-id",32), publicKey: fixed("witness-public",1985))
    }
    func checkpoint() throws -> AccountAuthorityCheckpoint {
        let value = try fixed("authority-checkpoint",72)
        return try AccountAuthorityCheckpoint(application: ApplicationAccountID(bytes: Array(value[0..<32])),
            revision: counter(value[32..<40]), account: AccountID(bytes: Array(value[40..<72])))
    }
    var registryPath: String { path + "-authority" }
}
func checkpointBytes(_ value: AccountAuthorityCheckpoint) -> [UInt8] {
    value.application.bytes + bigNumber(value.revision) + value.account.bytes
}
