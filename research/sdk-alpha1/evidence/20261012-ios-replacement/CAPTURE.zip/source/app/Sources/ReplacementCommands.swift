import Foundation
import Darwin
import QPeriaptContinuity

enum ReplacementCommands {
    static func run(_ args: [String]) throws {
        guard args.count == 7 else { throw ClientError("replacement argument count") }
        let mode=args[1], profile=args[2], input=ReplacementInputs(source: URL(fileURLWithPath: args[3]),path: args[4])
        if mode.hasPrefix("retired-owned-") && mode != "retired-owned-operational-denied" {
            try retiredOperation(input, mode:mode, profile:profile, output:args[5], run:args[6]); return
        }
        var cleanup: [() throws -> Void] = []
        let outcome = Result {
            if mode.hasPrefix("authority-") {
                let registry: ContinuityAccountAuthority
                if mode == "authority-create" {
                    guard mkdir(input.registryPath,0o700)==0 else { throw NSError(domain:NSPOSIXErrorDomain,code:Int(errno)) }
                    try ContinuityAccountAuthority.provisionWrappingKey(path:input.registryPath)
                    registry = try .prepareCreate(path:input.registryPath,trust:input.registryTrust())
                } else { registry = try .prepareOpen(path:input.registryPath,trust:input.registryTrust()) }
                cleanup.append { try registry.close() }; try registry.finishOpen()
                return try associate(input,registry:registry,peer:mode == "authority-peer-associate")
            }
            let create = mode == "policy-create", recoverable = profile == "recoverable"
            let configuration = create ? try ContinuityConfiguration.prepareCreate(path:input.path,input:initial(input.source,recoverable)) :
                try ContinuityConfiguration.prepareOpen(path:input.path,trust:trust(input.source,recoverable),protocolPolicy:policy(input.source))
            cleanup.append { try configuration.close() }; try configuration.finishOpen()
            let selected = try witness(input.source,"signed",wrong:false)
            if mode == "retired-owned-operational-denied" {
                try expect(215) { _ = try configuration.resumeEnrollment(intent:input.intent(),witness:selected) }
                return bigNumber(UInt32(215))
            }
            let enrollment = create ? try configuration.createEnrollment(intent:input.intent(),witness:selected) :
                try configuration.resumeEnrollment(intent:input.intent(),witness:selected)
            cleanup.append { try enrollment.close() }
            if create { return try enrollment.request() }
            let registry = try ContinuityAccountAuthority.prepareOpen(path:input.registryPath,trust:input.registryTrust())
            cleanup.append { try registry.close() }; try registry.finishOpen()
            try enrollment.selectAccountAuthority(registry,checkpoint:input.checkpoint())
            switch mode {
            case "policy-prepare":
                let journal = try enrollment.accept(certificate:input.read("grant-certificate"),roster:input.read("grant-roster"),pin:input.account())
                guard case .requiresEnrollment(let genesis) = try enrollment.prepareStorage(), genesis.journal == journal else { throw ClientError("required original genesis") }
                return bigNumber(UInt32(2)) + journal.bytes + genesis.subject + genesis.imageDigest
            case "policy-identity": return try credentialIdentity(enrollment)
            case "policy-activate":
                let request = try enrollment.request(), device = try enrollment.activate()
                cleanup.append { try device.close() }; try device.cancel(); return request
            case "roster-witness-peer-unassociated","roster-witness-peer-connect","roster-witness-peer-uncertain","roster-witness-peer-retry":
                let device = try enrollment.activate(); cleanup.append { try device.close() }
                if mode == "roster-witness-peer-unassociated" {
                    let peer = try device.preparePeer(configuration:peerInput(input.source),quality:.oneTimeBoth,role:.initiator)
                    cleanup.append { try peer.close() }; try expect(201) { try peer.finishOpen() }; return bigNumber(UInt32(201))
                }
                let selectedMode = mode == "roster-witness-peer-connect" ? "connect" : mode == "roster-witness-peer-uncertain" ? "uncertain-send" : "retry-send"
                return try traffic(device,source:input.source,mode:selectedMode)
            default: throw ClientError("unknown replacement operation")
            }
        }
        var failures: [String] = []
        for close in cleanup.reversed() { do { try close() } catch { failures.append(String(describing:error)) } }
        guard failures.isEmpty else { throw ClientError("replacement cleanup \(failures); operation: \(outcome)") }
        try durableIOS(outcome.get(),args[5])
    }
    private static func associate(_ input: ReplacementInputs,registry:ContinuityAccountAuthority,peer:Bool) throws -> [UInt8] {
        let application = try ApplicationAccountID(bytes:input.fixed(peer ? "authority-peer-application" : "authority-application",32))
        let source = peer ? input.source.appendingPathComponent("peer") : input.source
        let pin: AccountPin
        if peer {
            pin = try AccountPin(account:AccountID(bytes:exact(source,"responder-account",32)),root:exact(source,"responder-root",1985),family:input.fixed("family",32),
                checkpoint:RosterCheckpoint(version:counter(exact(source,"responder-roster-version",8)[...]),digest:exact(source,"responder-roster-digest",32)))
        } else { pin = try input.account() }
        let certificate = try load(source,peer ? "approved-certificate" : "grant-certificate",8192)
        let roster = try load(source,peer ? "approved-roster" : "grant-roster",65536)
        try expect(201) { _ = try registry.checkpoint(application:application) }
        var corrupt = peer ? roster : certificate; corrupt[corrupt.count-1] ^= 1
        try expect(102) { _ = try registry.associate(application:application,pin:pin,certificate:peer ? certificate : corrupt,roster:peer ? corrupt : roster) }
        try expect(201) { _ = try registry.checkpoint(application:application) }
        let value = try registry.associate(application:application,pin:pin,certificate:certificate,roster:roster)
        try requireIOS(value.revision == 1 && value.application == application,"approved account association")
        try requireIOS(registry.associate(application:application,pin:pin,certificate:certificate,roster:roster) == value,"association replay")
        try requireIOS(registry.checkpoint(application:application) == value,"association readback")
        if peer { try requireIOS(registry.checkpoint(application:input.checkpoint().application) == input.checkpoint(),"local account checkpoint changed") }
        else { try expect(211) { try ContinuityAccountAuthority.provisionWrappingKey(path:input.registryPath) } }
        return checkpointBytes(value)
    }
}
