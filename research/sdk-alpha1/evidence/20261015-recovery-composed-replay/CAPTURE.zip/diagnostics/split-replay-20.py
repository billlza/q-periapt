"""Isolate one proof body's replay cost; this is NOT a complete proof qualification."""
from pathlib import Path
import json
import re
import continuity_recovery_profiles as profiles
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
data = proof.load_inputs(root, "shared-storage")["positive"]
text = data.decode()
declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
lemmas = list(declaration.finditer(text))
case = profiles.SHARED_STORAGE.cases["positive"]
sdk.require(len(lemmas) == len(case.all_traces) + len(case.exists_traces), "certificate inventory differs")
sdk.require({m.group(1) for m in lemmas} == set(case.expected_results()), "unexpected certificate query")
sdk.require(all("sources" not in (m.group(2) or "").split(",") for m in lemmas), "global source lemmas require separate dependency analysis")
selected = "accepted_root_has_authenticated_origin"
pieces = [text[:lemmas[0].start()]]
dependencies = []
for index, match in enumerate(lemmas):
    name = match.group(1)
    end = lemmas[index + 1].start() if index + 1 < len(lemmas) else text.rindex("\nend")
    if name == selected:
        pieces.append(text[match.start():end])
    else:
        pieces.append(match.group() + "\nby sorry\n\n")
    if name == selected:
        selected_dependencies = list(dependencies)
    if "reuse" in {attribute.strip() for attribute in (match.group(2) or "").split(",")}:
        sdk.require((match.group(3) or "all-traces") == "all-traces", "reused existential lemma")
        dependencies.append(name)
output_text = "".join(pieces) + "\nend\n"
output = stage / "split-replay-20.spthy"
sdk.require([m.group() for m in declaration.finditer(output_text)] == [m.group() for m in lemmas], "theorem declarations changed")
sdk.require(output_text[:lemmas[0].start()] == text[:lemmas[0].start()], "operational theory changed")
with output.open("x") as stream:
    stream.write(output_text)
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
sdk.command([tools["tamarin"], "--with-maude=" + tools["maude"], str(output), "--parse-only", "--quit-on-warning"], stage / "split-parse-20", root)
original_runner = root / "target/continuity-recovery-multi-epoch-20261015/run-02.py"
with (stage / "split-run-20.py").open("xb") as stream:
    stream.write(sdk.snapshot(original_runner).data)
sdk.write_json(stage / "SPLIT_PREPARED_20.json", {
    "certificate_sha256": case.sha256, "input_sha256": sdk.snapshot(output).sha256,
    "selected_query": selected, "conservative_prior_reuse_dependencies": selected_dependencies,
    "all_declarations_and_operational_theory_preserved": True,
    "selected_proof_body_preserved_exactly": True,
    "unselected_proofs_replaced_with_incomplete_placeholders": True,
    "may_not_be_accepted_as_a_whole_certificate": True,
    "future_composition_requirement": "Every theorem and every earlier reuse dependency must independently verify against this exact operational theory and declaration inventory; check the complete acyclic graph before acceptance.",
})
print("Single-body replay diagnostic prepared; complete-certificate acceptance remains prohibited")
