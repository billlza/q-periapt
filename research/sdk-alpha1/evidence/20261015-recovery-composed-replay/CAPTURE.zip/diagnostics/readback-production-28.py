"""Reread the actual complete profile, including every conditional part and witness."""
from dataclasses import replace
from pathlib import Path
import json
import re
import subprocess
import continuity_recovery_composition as composition
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
directory = stage / "production-24"
terminal = json.loads((stage / "PRODUCTION_TERMINAL_24.json").read_text())
receipt = json.loads((directory / "RESULT.json").read_text())
sdk.require(terminal["accepted"] and terminal["returncode"] == 0 and receipt["accepted"], "production profile incomplete")
sdk.require(sdk.snapshot(directory / "RESULT.json").sha256 == terminal["receipt_sha256"], "profile receipt changed")
sources = proof.source_digests()
sdk.require(sources == terminal["source_hashes"] and all(receipt[key] == digest for key, digest in sources.items()), "checker identity differs")
inputs = proof.load_inputs(root, "shared-storage")
spec = proof.select_profile("shared-storage")
sdk.require(receipt["model_sha256"] == spec.model_sha256 and receipt["archive_sha256"] == spec.archive_sha256
            and set(receipt["groups"]) == set(spec.cases), "profile scope or inventory differs")
case = spec.cases["positive"]
manifest_path = directory / "positive/COMPOSITION.json"
manifest = json.loads(sdk.snapshot(manifest_path, maximum=proof.MAXIMUM_BYTES).data)
sdk.require(sdk.snapshot(manifest_path).sha256 == receipt["groups"]["positive"]["composition_sha256"], "composition manifest changed")
records = manifest["nodes"]
metrics = {}
files = {}
for index, node in enumerate(composition.plan(inputs["positive"], case)):
    label = f"node-{index:02d}"
    source = directory / "positive" / (label + "-input.spthy")
    output = directory / "positive" / (label + "-checked.spthy")
    stdout = directory / "positive" / (label + ".stdout")
    stderr = directory / "positive" / (label + ".stderr")
    snapshots = {name: sdk.snapshot(path, maximum=proof.MAXIMUM_BYTES)
                 for name, path in (("input", source), ("output", output), ("stdout", stdout), ("stderr", stderr))}
    sdk.require(snapshots["input"].data == node.data, "conditional input differs from pinned original projection")
    sdk.require(snapshots["output"].sha256 == records[node.name]["result"]["certificate_sha256"], "checked output changed")
    conditional = replace(case, verified=(node.name,), compose_proofs=False)
    found = proof._verify_summary(snapshots["stdout"].data, source, output, conditional.expected_results())
    sdk.require(found == records[node.name]["result"]["verified"], "conditional verdict changed")
    error_text = snapshots["stderr"].data.decode()
    sdk.require(re.search(r"(?im)^\s*(?:warning|error|fatal)\b", error_text) is None, "conditional diagnostic")
    residency = re.search(r"([0-9,]+) bytes maximum residency", error_text)
    sdk.require(residency is not None, "conditional residency missing")
    metrics[node.name] = {"elapsed_seconds": records[node.name]["result"]["elapsed_seconds"],
                         "ghc_maximum_residency_bytes": int(residency.group(1).replace(",", ""))}
    files[node.name] = {name: snapshot.sha256 for name, snapshot in snapshots.items()}
verified = composition.combine(inputs["positive"], records, case)
sdk.require(verified == manifest["verified"] == receipt["groups"]["positive"]["verified"], "conjunction differs")
witnesses = {}
for label in ("attack", "execution"):
    source = directory / (label + "-input.spthy")
    output = directory / (label + "-checked.spthy")
    stdout = directory / (label + ".stdout")
    stderr = directory / (label + ".stderr")
    sdk.require(sdk.snapshot(source).data == inputs[label], "witness input changed")
    found = proof.verify_summary(sdk.snapshot(stdout).data, label, source, output, "shared-storage")
    group = receipt["groups"][label]
    sdk.require(group["returncode"] == 0 and group["verified"] == found
                and sdk.snapshot(output).sha256 == group["certificate_sha256"], "witness result differs")
    sdk.require(re.search(r"(?im)^\s*(?:warning|error|fatal)\b", sdk.snapshot(stderr).data.decode()) is None, "witness diagnostic")
    witnesses[label] = found
    files[label] = {path.name: sdk.snapshot(path).sha256 for path in (source, output, stdout, stderr)}
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
sdk.require(head == "72587c2a867b9b9e9aa06e3fe25d8016e2b18b2d"
            and not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "source checkout changed")
sdk.write_json(stage / "PRODUCTION_READBACK_28.json", {
    "accepted": True, "head": head, "source_hashes": sources, "properties": verified,
    "witnesses": witnesses, "files": files, "metrics": metrics,
    "elapsed_seconds": terminal["elapsed_seconds"],
    "positive_elapsed_seconds": receipt["groups"]["positive"]["elapsed_seconds"],
    "maximum_ghc_residency_bytes": max(item["ghc_maximum_residency_bytes"] for item in metrics.values()),
    "longest_property_seconds": max(item["elapsed_seconds"] for item in metrics.values()),
    "not_a_controlled_performance_benchmark": True,
    "hosted_linux_replay_still_required": True, "multi_epoch_secrecy_proved": False,
    "release_claim_eligible": False,
})
print("Actual production profile independently reread: 20 properties and both witnesses pass")
