"""Retain complete related checks on the standalone source checkout."""
from pathlib import Path
import re
import subprocess
import sys
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
sdk.require(head.startswith("72587c2a") and not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "unexpected source state")
python = [sys.executable, "-B", str(root / "artifact/python_bootstrap.py")]
sdk.command([*python, "-m", "unittest", "artifact.test_continuity_recovery_composition",
    "artifact.test_continuity_recovery_proof", "artifact.test_continuity_recovery_profiles",
    "artifact.test_continuity_recovery_shared_storage", "artifact.test_formal_toolchain_contract",
    "artifact.test_formal_tool_asset", "artifact.test_bounded_process",
    "artifact.test_proof_to_byte_release"], stage / "tests-25", root)
count = re.search(r"Ran ([0-9]+) tests", (stage / "tests-25.stderr").read_text())
sdk.require(count is not None, "test count missing")
sdk.command([*python, str(root / "artifact/source_results_assembler.py"), "ci-source-gate",
    sdk.snapshot(root / "artifact/results.json").sha256, head, "--profile", "sdk-020"], stage / "source-gate-25", root)
sdk.command(["git", "diff", "--check"], stage / "diff-25", root)
sdk.require(not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "checks changed source")
sdk.write_json(stage / "QUALIFIED_25.json", {"head": head, "tests_passed": int(count.group(1)),
    "source_gate_passed": True, "clean_source": True,
    "actual_production_replay_separate": "PRODUCTION_TERMINAL_24.json",
    "hosted_replay_still_required": True})
print("Related tests and source gate passed on " + head)
