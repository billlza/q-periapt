"""Run the actual shared-storage CLI entrypoint with the pinned local tools."""
from pathlib import Path
import json
import os
import time
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
os.environ["PATH"] = os.pathsep.join((str(Path(tools["tamarin"]).parent), str(Path(tools["maude"]).parent), os.environ["PATH"]))
destination = stage / "production-24"
source_hashes = proof.source_digests()
sdk.write_json(stage / "PRODUCTION_STARTED_24.json", {
    "pid": os.getpid(), "entrypoint": "continuity_recovery_proof.main",
    "profile": "shared-storage", "output": str(destination), "source_hashes": source_hashes,
    "private_sdk_or_device_workload": False,
})
started = time.monotonic()
code = proof.main(["--profile", "shared-storage", "--output", str(destination)])
receipt = json.loads((destination / "RESULT.json").read_text())
sdk.require(proof.source_digests() == source_hashes, "checker changed during production replay")
sdk.write_json(stage / "PRODUCTION_TERMINAL_24.json", {
    "returncode": code, "accepted": code == 0 and receipt["accepted"],
    "elapsed_seconds": time.monotonic() - started, "source_hashes": source_hashes,
    "receipt_sha256": sdk.snapshot(destination / "RESULT.json").sha256,
})
raise SystemExit(code)
