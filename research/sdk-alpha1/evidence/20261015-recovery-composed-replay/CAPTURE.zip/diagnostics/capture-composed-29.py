"""Seal terminal replay diagnostics, the full production run and both readbacks."""
from pathlib import Path
import hashlib
import json
import zipfile
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
readback = json.loads((stage / "PRODUCTION_READBACK_28.json").read_text())
experimental = json.loads((stage / "COMPOSITION_READBACK_27.json").read_text())
qualification = json.loads((stage / "QUALIFIED_25.json").read_text())
sdk.require(readback["accepted"] and experimental["accepted"] and qualification["tests_passed"] == 211,
            "qualification incomplete")
patterns = [
    "hosted-artifact-10.*", "hosted-pr-artifact-18.json", "hosted-pr-18.*", "HOSTED_PR_18.json", "tamarin-hosted-08.log",
    "prepare-allocation-15.py", "allocation-run-15.py", "shared-storage-15.spthy", "allocation-15*", "ALLOCATION_PREPARED_15.json",
    "review-allocation-19.py", "ALLOCATION_REVIEW_19.json", "split-replay-20.*", "split-run-20.py", "split-parse-20.*", "SPLIT_PREPARED_20.json",
    "split-replay-21*", "compose-replay-22.py", "production-replay-24.py", "PRODUCTION_STARTED_24.json", "PRODUCTION_TERMINAL_24.json",
    "production-driver-24.*", "qualify-composition-25.py", "QUALIFIED_25.json", "tests-25.*", "source-gate-25.*", "diff-25.*",
    "readback-composition-27.py", "COMPOSITION_READBACK_27.json", "readback-production-28.py", "PRODUCTION_READBACK_28.json", "capture-composed-29.py",
]
files = {"diagnostics/" + path.name: path for pattern in patterns for path in stage.glob(pattern) if path.is_file()}
for name in ("split-22", "production-24"):
    for path in (stage / name).rglob("*"):
        sdk.require(not path.is_symlink(), "symlink in replay capture")
        if path.is_file():
            files[name + "/" + str(path.relative_to(stage / name))] = path
for name in ("artifact/continuity_recovery_proof.py", "artifact/continuity_recovery_profiles.py",
             "artifact/continuity_recovery_composition.py", "artifact/test_continuity_recovery_composition.py",
             "artifact/fixtures/continuity-recovery-composition-v1.json", "research/continuity-recovery-symbolic/shared-storage.spthy",
             "research/continuity-recovery-symbolic/README.md", ".github/workflows/ci.yml"):
    files["source/" + name] = root / name
files["tools/TOOLS_08.json"] = root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json"
public = root / "research/sdk-alpha1/evidence/20261015-recovery-composed-replay"
public.mkdir()
archive = public / "CAPTURE.zip"
members = {}
expanded = 0
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(files.items()):
        data = sdk.snapshot(path, maximum=16*1024**2).data
        expanded += len(data)
        sdk.require(expanded <= 64*1024**2, "capture exceeds bound")
        entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(entry, data)
        members[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as zipped:
    sdk.require(len(zipped.namelist()) == len(members), "capture inventory differs")
    for name, expected in members.items():
        sdk.require(hashlib.sha256(zipped.read(name)).hexdigest() == expected, "capture readback failed")
digest = sdk.snapshot(archive).sha256
sdk.write_json(public / "CAPTURE.json", {
    "archive_sha256": digest, "members": members, "expanded_bytes": expanded,
    "source_commit": readback["head"], "source_hashes": readback["source_hashes"],
    "qualified_tests": qualification["tests_passed"], "source_gate_passed": True,
    "actual_production_entrypoint_accepted": True, "properties": len(readback["properties"]),
    "witnesses": readback["witnesses"], "production_elapsed_seconds": readback["elapsed_seconds"],
    "production_positive_elapsed_seconds": readback["positive_elapsed_seconds"],
    "maximum_ghc_residency_bytes": readback["maximum_ghc_residency_bytes"],
    "longest_property_seconds": readback["longest_property_seconds"],
    "hosted_linux_replay_still_required": True, "multi_epoch_secrecy_proved": False,
    "private_sdk_device_state_included": False, "release_claim_eligible": False,
})
sdk.write_json(public / "READBACK.json", {"completed": True, "archive_sha256": digest,
    "members": len(members), "expanded_bytes": expanded, "all_members_rehashed": True,
    "original_proof_segments_and_declarations_preserved": True,
    "complete_acyclic_dependency_graph_verified": True,
    "release_claim_eligible": False})
print(json.dumps({"archive_bytes": archive.stat().st_size, "expanded_bytes": expanded,
                  "members": len(members), "sha256": digest}))
