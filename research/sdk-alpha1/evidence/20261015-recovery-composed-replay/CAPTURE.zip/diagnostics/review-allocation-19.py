"""Reject an incomplete replay as a candidate CI resource configuration."""
from pathlib import Path
import json
import os
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
terminal = json.loads((stage / "allocation-15-TERMINAL.json").read_text())
started = json.loads((stage / "allocation-15-STARTED.json").read_text())
sdk.require(terminal["timed_out"] and not terminal["accepted"] and not terminal["results"], "result needs a different review")
try:
    os.killpg(started["pid"], 0)
except ProcessLookupError:
    pass
else:
    raise ValueError("owned prover process group still exists")
sdk.require(sdk.snapshot(root / "artifact/continuity_recovery_proof.py").sha256 == "118bab1de610680693a9c76a3d1e1f634db221aeaf1f0f3663ef83120addee70", "production proof runner changed")
sdk.write_json(stage / "ALLOCATION_REVIEW_19.json", {
    "terminal": terminal, "candidate_runtime_option": "-A64m",
    "qualifies_for_ci": False, "production_gate_unchanged": True,
    "owned_prover_group_absent": True, "security_counterexample": False,
    "causal_performance_comparison": False,
    "comparison_limit": "The historical baseline used a separate run; this attempt overlapped a second bounded prover. No timing regression or speedup is established.",
    "next_resource_diagnostic": "Measure individual proof verification phases or inspect the major-GC cost before changing another runtime option; keep full theorem and dependency inventories.",
})
print("Incomplete allocation experiment retained; production proof parameters unchanged")
