"""Read back the independent PR recovery replay artifact with API digest binding."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import zipfile
import rust_sdk_profile as sdk
stage = Path(__file__).resolve().parent
api = "repos/billlza/q-periapt/actions/artifacts/12006697888"
metadata = json.loads(subprocess.check_output(["gh", "api", api], timeout=30))
sdk.require(metadata["workflow_run"]["id"] == 38800623985 and metadata["workflow_run"]["head_sha"] == "e860b55e020566931345468b29743da6a11392d0", "artifact source differs")
sdk.require(metadata["size_in_bytes"] <= 1024**2, "artifact exceeds bound")
data = subprocess.check_output(["gh", "api", "--allow-escape-sequences", api + "/zip"], timeout=60)
sdk.require(len(data) == metadata["size_in_bytes"] and "sha256:" + hashlib.sha256(data).hexdigest() == metadata["digest"], "artifact digest differs")
with (stage / "hosted-pr-18.zip").open("xb") as stream:
    stream.write(data)
sdk.write_json(stage / "hosted-pr-artifact-18.json", metadata)
results = {}
with zipfile.ZipFile(io.BytesIO(data)) as zipped:
    sdk.require(len(zipped.infolist()) <= 64 and sum(info.file_size for info in zipped.infolist()) <= 8*1024**2, "expanded artifact exceeds bound")
    for profile in ("independent", "key-scoped", "shared-storage"):
        results[profile] = json.loads(zipped.read(profile + "/RESULT.json"))
sdk.require(results["independent"]["accepted"] and results["key-scoped"]["accepted"], "earlier profiles failed")
sdk.require(not results["shared-storage"]["accepted"] and results["shared-storage"]["error"] == "command timed out after 900 seconds", "shared storage needs a different diagnosis")
sdk.write_json(stage / "HOSTED_PR_18.json", {"artifact": metadata["id"], "sha256": hashlib.sha256(data).hexdigest(), "results": results, "release_claim_eligible": False})
print(json.dumps({name: {"accepted": value["accepted"], "error": value.get("error")} for name,value in results.items()}))
