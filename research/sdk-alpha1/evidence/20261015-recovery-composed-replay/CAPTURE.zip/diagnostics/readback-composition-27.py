"""Independently reread every experimental part through the production checker."""
from dataclasses import replace
from pathlib import Path
import copy
import json
import os
import re
import continuity_recovery_composition as composition
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
directory = stage / "split-22"
case = proof.certificate("positive", "shared-storage")
source = proof.load_inputs(root, "shared-storage")["positive"]
nodes = composition.plan(source, case)
prepared = json.loads((directory / "PREPARED.json").read_text())
result = json.loads((directory / "RESULT.json").read_text())
tools = json.loads((root / "target/continuity-recovery-symbolic-20261015/TOOLS_08.json").read_text())
records = {}
files = {}
metrics = {}
for index, node in enumerate(nodes):
    label = f"node-{index:02d}"
    paths = {kind: directory / (label + suffix) for kind, suffix in (
        ("input", ".spthy"), ("output", "-proof.spthy"), ("stdout", ".stdout"),
        ("stderr", ".stderr"), ("started", "-STARTED.json"), ("terminal", "-TERMINAL.json"))}
    snapshots = {kind: sdk.snapshot(path, maximum=proof.MAXIMUM_BYTES) for kind, path in paths.items()}
    files[node.name] = {kind: value.sha256 for kind, value in snapshots.items()}
    sdk.require(snapshots["input"].data == node.data and snapshots["input"].sha256 == prepared["nodes"][node.name]["sha256"], "part differs from original pinned proof projection")
    started = json.loads(snapshots["started"].data)
    terminal = json.loads(snapshots["terminal"].data)
    expected_argv = [tools["tamarin"], "--with-maude=" + tools["maude"], str(paths["input"]),
        "--heuristic=s", "--derivcheck-timeout=60", "--quit-on-warning", "--output=" + str(paths["output"]),
        "+RTS", "-N1", "-M12G", "-s", "-RTS"]
    sdk.require(started["argv"] == terminal["argv"] == expected_argv and started["maximum_seconds"] == 600,
                "part command or resource contract differs")
    sdk.require(terminal["returncode"] == 0 and not terminal["timed_out"] and not terminal["output_exceeded"], "part did not complete")
    sdk.require(terminal["input_sha256"] == node.sha256 and terminal["output_sha256"] == snapshots["output"].sha256, "terminal identity differs")
    stderr = snapshots["stderr"].data.decode("utf-8", errors="strict")
    sdk.require(re.search(r"(?im)^\s*(?:warning|error|fatal)\b", stderr) is None, "part emitted a diagnostic")
    conditional = replace(case, verified=(node.name,), sha256=node.sha256, compose_proofs=False)
    verified = proof._verify_summary(snapshots["stdout"].data, paths["input"], paths["output"], conditional.expected_results())
    sdk.require(set(verified) == {node.name}, "part did not verify exactly its property")
    try:
        os.killpg(started["pid"], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError("old prover group or reused group id needs inspection")
    residency = re.search(r"([0-9,]+) bytes maximum residency", stderr)
    sdk.require(residency is not None, "runtime residency missing")
    metrics[node.name] = {"elapsed_seconds": terminal["elapsed_seconds"],
                         "ghc_maximum_residency_bytes": int(residency.group(1).replace(",", ""))}
    records[node.name] = {"source_certificate_sha256": case.sha256, "input_sha256": node.sha256,
                         "dependencies": list(node.dependencies),
                         "result": {"returncode": 0, "verified": verified,
                                    "certificate_sha256": snapshots["output"].sha256}}
verified = composition.combine(source, records, case)
sdk.require(result["accepted"] and set(result["verified"]) == set(verified), "producer result differs from independent readback")
controls = {}
first = nodes[0].name
for mutation in ("missing-helper", "missing-main", "incomplete-helper", "wrong-source", "cycle"):
    modified = copy.deepcopy(records)
    if mutation == "missing-helper":
        del modified[first]
    elif mutation == "missing-main":
        del modified[proof.select_profile("shared-storage").main]
    elif mutation == "incomplete-helper":
        modified[first]["result"]["verified"] = {}
    elif mutation == "wrong-source":
        modified[first]["source_certificate_sha256"] = "0" * 64
    else:
        modified[first]["dependencies"] = [nodes[-1].name]
    try:
        composition.combine(source, modified, case)
    except composition.CompositionError:
        controls[mutation] = "rejected"
    else:
        raise ValueError("production composition checker accepted " + mutation)
sdk.write_json(stage / "COMPOSITION_READBACK_27.json", {
    "accepted": True, "source_certificate_sha256": case.sha256,
    "source_model_sha256": proof.select_profile("shared-storage").model_sha256,
    "verified": verified, "files": files, "metrics": metrics, "countercontrols": controls,
    "all_commands_without_proof_search": True, "all_owned_process_groups_absent": True,
    "production_checker_digests": proof.source_digests(),
    "actual_production_profile_still_separate": "PRODUCTION_TERMINAL_24.json",
    "release_claim_eligible": False,
})
print("Independent production-checker readback: all 20 properties and dependency closure pass")
