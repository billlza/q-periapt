"""Experimental acyclic composition of every proof in the pinned certificate.

Each invocation verifies one original proof body with unchanged declarations.
Earlier reuse lemmas are explicit dependencies, never independently accepted
axioms. Only a complete verified acyclic graph can qualify the conjunction.
Production CI still uses the original whole-certificate replay.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import continuity_recovery_profiles as profiles
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk

root = Path.cwd()
stage = Path(__file__).resolve().parent
output = stage / "split-22"
output.mkdir()
case = profiles.SHARED_STORAGE.cases["positive"]
data = proof.load_inputs(root, "shared-storage")["positive"]
text = data.decode()
declaration = re.compile(r'(?ms)^lemma\s+(\w+)(?:\s+\[([^\]]+)\])?:\s*(all-traces|exists-trace)?\s*"([^\"]*)"')
lemmas = list(declaration.finditer(text))
declarations = [match.group() for match in lemmas]
names = [match.group(1) for match in lemmas]
sdk.require(len(names) == len(set(names)) and set(names) == set(case.expected_results()), "declaration inventory differs")
attributes = [{value.strip() for value in (match.group(2) or "").split(",")} for match in lemmas]
sdk.require(all("sources" not in values for values in attributes), "source lemmas need a different dependency graph")
selected_names = [name for name in names if name in case.verified]
sdk.require(set(selected_names) == set(case.all_traces) and len(selected_names) == 20, "universal inventory differs")
runner = root / "target/continuity-recovery-multi-epoch-20261015/run-02.py"
with (output / "run.py").open("xb") as stream:
    stream.write(sdk.snapshot(runner).data)
graph = {}
for name in selected_names:
    index = names.index(name)
    dependencies = [names[prior] for prior in range(index) if "reuse" in attributes[prior]]
    sdk.require(all(dependency in selected_names and names.index(dependency) < index for dependency in dependencies), "unproved or cyclic dependency")
    graph[name] = dependencies


def validate(records):
    sdk.require(set(records) == set(selected_names), "incomplete theorem graph")
    certified = set()
    for name in selected_names:
        record = records[name]
        sdk.require(record["dependencies"] == graph[name] and set(graph[name]) <= certified,
                    "dependency graph is not closed in source order")
        sdk.require(record["source_certificate_sha256"] == case.sha256, "source certificate differs")
        terminal = record["terminal"]
        sdk.require(terminal["returncode"] == 0 and not terminal["timed_out"]
                    and not terminal["output_exceeded"], "conditional replay did not complete")
        sdk.require(terminal["input_sha256"] == prepared[name]["sha256"], "replay input differs")
        sdk.require(set(terminal["results"]) == set(names), "terminal query inventory differs")
        for query, (mode, _) in case.expected_results().items():
            expected = "verified" if query == name else "analysis incomplete"
            row = terminal["results"][query]
            sdk.require(row["mode"] == mode and row["status"] == expected, "unexpected conditional verdict")
        sdk.require(terminal["output_sha256"] is not None, "missing checked proof output")
        certified.add(name)
    return sorted(certified)


prepared = {}
for ordinal, selected in enumerate(selected_names):
    pieces = [text[:lemmas[0].start()]]
    selected_body_hash = None
    for index, match in enumerate(lemmas):
        end = lemmas[index + 1].start() if index + 1 < len(lemmas) else text.rindex("\nend")
        if match.group(1) == selected:
            piece = text[match.start():end]
            selected_body_hash = hashlib.sha256(piece.encode()).hexdigest()
        else:
            piece = match.group() + "\nby sorry\n\n"
        pieces.append(piece)
    content = "".join(pieces) + "\nend\n"
    sdk.require(content[:lemmas[0].start()] == text[:lemmas[0].start()], "operational theory changed")
    sdk.require([m.group() for m in declaration.finditer(content)] == declarations, "theorem declarations changed")
    path = output / f"node-{ordinal:02d}.spthy"
    with path.open("x") as stream:
        stream.write(content)
    prepared[selected] = {"file": path.name, "sha256": sdk.snapshot(path).sha256,
                          "original_proof_segment_sha256": selected_body_hash}
sdk.write_json(output / "PREPARED.json", {
    "source_certificate_sha256": case.sha256, "source_model_sha256": profiles.SHARED_STORAGE.model_sha256,
    "nodes": prepared, "dependencies": graph, "all_declarations_and_operational_prefix_unchanged": True,
    "source_lemmas_present": False, "proof_search": False,
    "case_deadline_seconds": 600, "heap_gib": 12, "threads": 1,
})
records = {}
result = {"accepted": False, "production_gate_changed": False, "records": records,
          "release_claim_eligible": False}
try:
    for ordinal, selected in enumerate(selected_names):
        label = f"node-{ordinal:02d}"
        print(f"Replaying conditional proof {ordinal + 1}/20: {selected}", flush=True)
        sdk.command([sys.executable, "-B", str(root / "artifact/python_bootstrap.py"), str(output / "run.py"),
            prepared[selected]["file"], label, "replay", "600", "12", "no-graph", selected],
            output / (label + "-command"), root)
        terminal = json.loads((output / (label + "-TERMINAL.json")).read_text())
        started = json.loads((output / (label + "-STARTED.json")).read_text())
        try:
            os.killpg(started["pid"], 0)
        except ProcessLookupError:
            pass
        else:
            raise ValueError("conditional prover group remains live")
        sdk.require(terminal["returncode"] == 0 and not terminal["timed_out"] and not terminal["output_exceeded"], "conditional replay failed")
        sdk.require(terminal["results"].get(selected, {}).get("status") == "verified", "selected proof incomplete")
        sdk.require(sdk.snapshot(output / prepared[selected]["file"]).sha256 == prepared[selected]["sha256"], "conditional input mutated")
        sdk.require(sdk.snapshot(output / (label + "-proof.spthy")).sha256 == terminal["output_sha256"], "checked output differs")
        records[selected] = {"dependencies": graph[selected], "source_certificate_sha256": case.sha256,
                             "terminal": terminal, "owned_prover_group_absent": True}
    result["verified"] = validate(records)
    controls = {}
    for mutation in ("missing-first-proof", "missing-main-proof", "incomplete-helper", "wrong-certificate", "cycle"):
        changed = json.loads(json.dumps(records))
        first = selected_names[0]
        if mutation == "missing-first-proof":
            del changed[first]
        elif mutation == "missing-main-proof":
            del changed[profiles.SHARED_STORAGE.main]
        elif mutation == "incomplete-helper":
            changed[first]["terminal"]["results"][first]["status"] = "analysis incomplete"
        elif mutation == "wrong-certificate":
            changed[first]["source_certificate_sha256"] = "0" * 64
        else:
            changed[first]["dependencies"] = [selected_names[-1]]
        try:
            validate(changed)
        except ValueError:
            controls[mutation] = "rejected"
        else:
            raise ValueError("composition accepted invalid proof graph: " + mutation)
    result["countercontrols"] = controls
    sdk.require(proof.load_inputs(root, "shared-storage")["positive"] == data, "source certificate changed")
    result["accepted"] = True
except BaseException as exc:
    result["error"] = str(exc)
    raise
finally:
    sdk.write_json(output / "RESULT.json", result)
print("All 20 original properties verified through a closed acyclic dependency graph; production CI unchanged")
