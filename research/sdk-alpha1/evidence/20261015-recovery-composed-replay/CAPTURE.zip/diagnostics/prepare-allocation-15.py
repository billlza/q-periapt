"""Single-variable runtime experiment for the unchanged shared-storage proof."""
from pathlib import Path
import hashlib
import continuity_recovery_proof as proof
import rust_sdk_profile as sdk
root = Path.cwd()
stage = Path(__file__).resolve().parent
original = root / "target/continuity-recovery-multi-epoch-20261015/run-02.py"
runner = original.read_text()
needle = 'argv.extend(("+RTS", "-N1", f"-M{heap_gib}G", "-s", "-RTS"))'
sdk.require(runner.count(needle) == 1, "runner resource boundary changed")
changed = runner.replace(needle, needle.replace('"-s"', '"-A64m", "-s"'))
with (stage / "allocation-run-15.py").open("x") as stream:
    stream.write(changed)
data = proof.load_inputs(root, "shared-storage")["positive"]
with (stage / "shared-storage-15.spthy").open("xb") as stream:
    stream.write(data)
sdk.write_json(stage / "ALLOCATION_PREPARED_15.json", {
    "certificate_sha256": hashlib.sha256(data).hexdigest(),
    "runner_original_sha256": sdk.snapshot(original).sha256,
    "runner_sha256": sdk.snapshot(stage / "allocation-run-15.py").sha256,
    "only_runtime_parameter_change": "-A64m", "maximum_seconds": 900,
    "heap_gib": 12, "threads": 1, "proof_search": False,
    "baseline": "target/continuity-recovery-shared-storage-ci-20261015/replay-02",
    "baseline_conditions_not_a_controlled_benchmark": True,
})
