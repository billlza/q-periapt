"""Reproduce the exact pre-fix prototype guard, preserving its failed store."""
from pathlib import Path
import hashlib
import runpy
import sys
import types

root=Path.cwd();peer=root/'research/continuity-openssl-peer';sys.path.append(str(peer))
from provider import load_provider
load_provider(root/'target/independent-bootstrap-01/provider')
import peer.state_codec as codec
source=(root/'target/independent-durable-rekey-01/epoch_codec-before-capacity.py.txt').read_bytes()
if hashlib.sha256(source).hexdigest()!='dc0d3b158e69364b7961fdf537966d183c1f6315e7313c575e3dc694236a952e':
    raise ValueError('pre-fix source does not match the first runtime manifest')
old=types.ModuleType('peer.before_capacity_guard');old.__package__='peer'
exec(compile(source,'pre-fix-epoch-codec','exec'),old.__dict__)
codec.encode_epochs=old.encode_epochs
sys.argv=[str(peer/'capacity_checks.py'),'--provider-root',str(root/'target/independent-bootstrap-01/provider'),
          '--native',str(root/'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart'),
          '--output',str(root/'target/independent-durable-rekey-01/capacity-red')]
runpy.run_path(sys.argv[0],run_name='__main__')
