"""Canonical authenticated-local snapshots, never a network import capability."""
# SPDX-License-Identifier: Apache-2.0 OR MIT
from __future__ import annotations

from dataclasses import dataclass
import hmac

from .authority import Context
from .bootstrap import Initiator, digest, mac
from .journal import MAX_STATE
from .kem import HybridPrivate
from .epoch_state import EpochState
from .epoch_codec import encode_epochs, decode_epochs
from .epoch_validation import validate
from .traffic_codec import encode_traffic, decode_traffic
from .snapshot_fields import SendPlan, encode_pending, decode_pending
from .wire import Reader, require


@dataclass(repr=False)
class State:
    operation: Initiator
    traffic: EpochState | None = None
    pending: SendPlan | None = None
    format_version: int = 2

    def close(self):
        self.operation.close()
        if self.traffic is not None:
            self.traffic.close()
        self.pending = None


def encode(state: State) -> bytes:
    op = state.operation
    require(not op._closed, "closed snapshot owner")
    phase = 3 if state.traffic is not None else (2 if op._reply is not None else 1)
    require(state.format_version in (1, 2), "snapshot format version")
    tag = b"QPREFS01" if state.format_version == 1 else b"QPREFS02"
    result = bytearray(tag + op._context.digest + bytes([phase]))
    result.extend(op._initial)
    if phase == 1:
        require(op._reply_key is not None and op._first_secret is not None and state.pending is None,
                "waiting snapshot state")
        result.extend(op._reply_key._checkpoint() + op._first_secret)
    else:
        require(op._reply is not None and op._final is not None and op._session_id is not None,
                "completed snapshot state")
        result.extend(op._reply + op._final + op._session_id)
        if phase == 2:
            require(op._root is not None and state.pending is None, "pending confirmed root")
            result.extend(op._root)
        else:
            require(op._root is None and state.traffic is not None, "root transfer marker")
            owner = state.traffic
            if state.format_version == 1:
                validate(owner, state.pending)
                require(owner.confirmed == owner.sending == owner.receiving == 0
                        and owner.plan is None and owner.last is None, "legacy snapshot requires epoch zero")
                result.extend(encode_traffic(owner.traffic(0), legacy_root=owner.root))
                result.extend(encode_pending(state.pending))
            else:
                result.extend(encode_epochs(owner, state.pending))
    require(len(result) <= MAX_STATE, "snapshot aggregate capacity")
    return bytes(result)


def decode(payload: bytes, context: Context) -> State:
    require(len(payload) <= MAX_STATE, "snapshot aggregate capacity")
    reader = Reader(payload)
    tag = reader.take(8)
    require(tag in (b"QPREFS01", b"QPREFS02") and reader.take(32) == context.digest, "snapshot schema/context")
    phase = reader.integer(1)
    require(phase in (1, 2, 3), "snapshot phase")
    op = Initiator.__new__(Initiator)
    op._context, op._closed = context, False
    op._initial = reader.take(5817)
    body = context.initiator.open(op._initial, 5, 2440)
    require(body[:40] == b"QPBSI001" + context.digest, "snapshot initial scope")
    op._reply_key = op._first_secret = op._reply = op._final = op._session_id = op._root = None
    state = State(op, format_version=1 if tag == b"QPREFS01" else 2)
    try:
        if phase == 1:
            op._reply_key = HybridPrivate._restore(reader.take(96))
            op._first_secret = reader.take(32)
            require(body[72:1288] == op._reply_key.public(), "snapshot reply-key binding")
            t0 = digest(b"initial-core", body[:-32])
            confirmation = context.sdk.initial_confirmation(op._first_secret, t0)
            require(hmac.compare_digest(mac(confirmation, t0), body[-32:]), "snapshot initial confirmation")
        else:
            op._reply, op._final, op._session_id = reader.take(4633), reader.take(136), reader.take(32)
            reply = context.responder.open(op._reply, 6, 1256)
            h0, h1 = digest(b"initial-wire", op._initial), digest(b"reply-wire", op._reply)
            require(reply[:72] == b"QPBSR001" + context.digest + h0
                    and op._final[:104] == b"QPBSF001" + context.digest + h0 + h1
                    and op._session_id == digest(b"session-id", op._final[:104]), "snapshot completed transcript")
            if phase == 2:
                op._root = reader.take(32)
            else:
                if state.format_version == 1:
                    state.traffic = EpochState.initial(decode_traffic(reader, context, op._session_id, legacy=True))
                    state.pending = decode_pending(reader)
                    validate(state.traffic, state.pending)
                else:
                    state.traffic, state.pending = decode_epochs(reader, context, op._session_id)
        reader.finish()
        require(encode(state) == payload, "noncanonical snapshot")
        return state
    except BaseException:
        state.close()
        raise
