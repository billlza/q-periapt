"""Seal only the explicitly selected public records; never follow fixture paths."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path.cwd()
out = root / 'target/independent-durable-rekey-01'
peer = root / 'research/continuity-openssl-peer'
evidence = root / 'research/sdk-alpha1/evidence'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def seal(folder, entries, report):
    folder.mkdir(exist_ok=False)
    manifest = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(entries.items())}
    entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = folder / 'CAPTURE.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(entries)
        assert z.testzip() is None
        for name, item in manifest.items():
            data = z.read(name)
            assert len(data) == item['bytes'] and digest(data) == item['sha256']
    report['capture'] = {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': digest(archive.read_bytes())}
    (folder / 'CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(folder.name, report['capture'])

report = json.loads((out / 'READBACK.json').read_text())
entries = {}
lanes = ['owner-final', 'store-final', 'bound-final', 'base-final', 'rekey-final', 'bootstrap-final', 'capacity-red', 'quota-red', 'close-red']
for lane in lanes:
    for path in sorted((out / lane).rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink()
        relative = path.relative_to(out)
        assert path.name not in {'head', 'intent', '.stage-head', 'config.json', 'signing-key', 'wrapping-key'}
        data = path.read_bytes()
        assert not data.startswith((b'QPREFJ01', b'QPREFI01', b'QPREFS01', b'QPREFS02'))
        entries[str(relative)] = data
    for suffix in ['stdout', 'stderr']:
        entries[lane + '.' + suffix] = (out / (lane + '.' + suffix)).read_bytes()
for name in ['READBACK.json', 'review.py', 'review.stdout', 'review.stderr', 'seal.py', 'capacity_red.py',
             'epoch_codec-before-capacity.py.txt', 'private_files_before_reserved_slot.py.txt',
             'durable-before-close-guard.py.txt']:
    entries[name] = (out / name).read_bytes()
for command in ['build', 'clippy', 'fmt', 'actionlint']:
    for suffix in ['stdout', 'stderr']:
        entries[command + '.' + suffix] = (out / (command + '.' + suffix)).read_bytes()
for name, expected in report['source_files'].items():
    data = (peer / name).read_bytes()
    assert digest(data) == expected
    entries['source/' + name] = data
for name in ['README.md', 'STORAGE.md']:
    entries['source/' + name] = (peer / name).read_bytes()
entries['source/independent-continuity.yml'] = (root / '.github/workflows/independent-continuity.yml').read_bytes()
entries['counterpart'] = (root / 'target/independent-bootstrap-01/native-target/release/q-periapt-independent-peer-counterpart').read_bytes()
assert digest(entries['counterpart']) == report['native_sha256']
report['validation'] = {'strict_release_build': True, 'strict_all_target_clippy': True, 'rustfmt': True,
                        'actionlint': True, 'python_AST_and_public_readback': True, 'tracked_Rust_files': 722}
report['private_state'] = 'Original private failed fixtures remain local; only path references, never their contents, are captured.'
report['red_scope'] = 'Three defects in the new uncommitted independent reference prototype, not the established Rust SDK.'
seal(evidence / '20261018-independent-durable-rekey', entries, report)

win = root / 'target/windows-installed-2328-01'
entries = {}
for name in ['PRODUCER_REVIEW.json', 'NATIVE_C_REVIEW.json', 'WINDOWS_LIFECYCLE_REVIEW.json',
             'NETWORK_REVIEW-windows2022.json', 'NETWORK_REVIEW-windows2025.json',
             'readback-windows-2022.zip', 'readback-windows-2025.zip']:
    entries[name] = (win / name).read_bytes()
for stem in ['review-producer', 'review-runtime', 'review-public']:
    for suffix in ['py', 'stdout', 'stderr']:
        entries[stem + '.' + suffix] = (win / (stem + '.' + suffix)).read_bytes()
with zipfile.ZipFile(win / 'producer.zip') as z:
    entries['producer-INPUT.json'] = z.read('INPUT.json')
producer = json.loads(entries['producer-INPUT.json'])
native = json.loads(entries['NATIVE_C_REVIEW.json'])
for os_name in ['windows-2022', 'windows-2025']:
    folder = win / os_name.replace('-', '')
    entries[os_name + '/RESULT.json'] = (folder / 'RESULT.json').read_bytes()
    for profile in ['debug', 'release']:
        dll = win / (os_name + '-' + profile + '-fd42.dll')
        observed = next(a for a in native['artifacts'] if a['os'] == os_name)['profiles'][profile]
        assert digest(dll.read_bytes()) == observed['independent_DLL_sha256']
        exports = subprocess.check_output(['/opt/homebrew/opt/llvm/bin/llvm-readobj', '--coff-exports', str(dll)])
        names = re.findall(rb'^  Name: (\S+)$', exports, re.M)
        assert len(names) == 157 and {n.decode() for n in names} == set(producer['exports'])
        entries[os_name + '/' + profile + '-exports.txt'] = exports
        for task in ['runtime', 'owner-runtime']:
            for suffix in ['stdout', 'stderr']:
                name = profile + '-' + task + '.' + suffix
                entries[os_name + '/' + name] = (folder / name).read_bytes()
changed = subprocess.check_output(['git', 'diff', '23280124', '--name-only'], text=True).splitlines()
assert all(n.startswith(('research/continuity-openssl-peer/', 'research/sdk-alpha1/evidence/')) or n in
           ['docs/SDK_0_2_RELEASE_READINESS.md', '.github/workflows/independent-continuity.yml'] for n in changed)
continuity = {'from_head': '23280124efd2f0f3003d4ce85e3db665f6ec8a25',
              'working_base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              'changed_tracked_paths': changed, 'product_candidate_bindings_toolchain_unchanged': True,
              'scope': 'Independent reference and evidence-only changes; no product runtime change.'}
entries['SOURCE_CONTINUITY.json'] = (json.dumps(continuity, indent=2) + '\n').encode()
report = {'head': native['head'], 'run': native['run'], 'installed_lifecycle_qualified': True,
          'producer': json.loads(entries['PRODUCER_REVIEW.json']), 'native': native,
          'public_readback': json.loads(entries['WINDOWS_LIFECYCLE_REVIEW.json']),
          'full_native_artifacts': 'target/windows-installed-2328-01 and retained GitHub artifacts; compact capture omits complete native ZIPs/DLLs.',
          'scope': 'Installed Windows Debug/Release C/Rust lifecycle. Same engine and host, no independent implementation, hardware power loss, performance or release admission.'}
seal(evidence / '20261018-windows-installed-2328', entries, report)
