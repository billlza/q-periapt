// SPDX-License-Identifier: Apache-2.0 OR MIT
//! Original enrollment owns terminal durability, exact witness ACK and cleanup.
mod cancellation;
use super::*;
use crate::{
    AnchorCredentialRenewalProposal as Proposal, AnchorCredentialRenewalState as State,
    AnchorOperation, AnchorSubject,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum Terminal {
    Applied,
    Closed,
}
impl Terminal {
    fn byte(self) -> u8 {
        match self {
            Self::Applied => 1,
            Self::Closed => 2,
        }
    }
    fn state(self) -> State {
        match self {
            Self::Applied => State::Applied,
            Self::Closed => State::Closed,
        }
    }
}
#[derive(Clone, Copy)]
pub(super) struct Coordination {
    pub(super) intent: WitnessedCredentialIntent,
    terminal: Option<Terminal>,
}
pub(super) struct ClosedRenewal {
    operation: CredentialRenewalId,
    statement: [u8; 32],
    target: RosterCheckpoint,
}
impl ClosedRenewal {
    pub(super) fn status(&self) -> CredentialRenewalStatus {
        CredentialRenewalStatus::Closed {
            operation: self.operation,
            statement: self.statement,
            target: self.target,
        }
    }
}
pub(super) struct WitnessRenewal {
    floor: u64,
    pub(super) closed: Option<ClosedRenewal>,
    pub(super) coordination: Option<Coordination>,
}
impl WitnessRenewal {
    pub(super) fn roster_floor(&self) -> u64 {
        self.floor
    }
    pub(super) fn new() -> Self {
        Self {
            floor: 0,
            closed: None,
            coordination: None,
        }
    }
    pub(super) fn check_next(&self, grant: &VerifiedCredentialRenewal) -> Result<(), DurableError> {
        if self.coordination.is_some() {
            return Err(DurableError::Suspended);
        }
        if grant.successor_device().roster().checkpoint().version() <= self.floor
            || self
                .closed
                .as_ref()
                .is_some_and(|c| c.operation == grant.operation())
        {
            return Err(Error::Retired.into());
        }
        Ok(())
    }
    pub(super) fn validate(&self, renewal: &LocalRenewal) -> Result<(), DurableError> {
        if renewal.time_floor != 0 || renewal.expired.is_some() {
            return Err(DurableError::Corrupt);
        }
        let expected_floor = self
            .closed
            .as_ref()
            .map(|c| c.target.version())
            .or_else(|| renewal.completed.as_ref().map(|c| c.target.version()))
            .unwrap_or(0);
        if self.floor != expected_floor {
            return Err(DurableError::Corrupt);
        }
        if let Some(closed) = &self.closed {
            crate::codec::nonzero(&closed.statement)?;
            if renewal.completed.as_ref().is_some_and(|c| {
                c.operation == closed.operation || c.target.version() >= closed.target.version()
            }) || renewal
                .pending
                .as_ref()
                .is_some_and(|p| p.operation == closed.operation)
            {
                return Err(DurableError::Corrupt);
            }
        }
        if let Some(coord) = self.coordination {
            let p = coord.intent;
            if matches!(p, WitnessedCredentialIntent::Cancellation(_))
                && coord.terminal == Some(Terminal::Applied)
            {
                return Err(DurableError::Corrupt);
            }
            let matches = match coord.terminal {
                None => renewal
                    .pending
                    .as_ref()
                    .is_some_and(|v| v.operation == p.operation() && v.statement == p.statement()),
                Some(Terminal::Applied) => {
                    renewal.pending.is_none()
                        && self.closed.is_none()
                        && renewal.completed.as_ref().is_some_and(|v| {
                            v.operation == p.operation() && v.statement == p.statement()
                        })
                }
                Some(Terminal::Closed) => {
                    renewal.pending.is_none()
                        && self.closed.as_ref().is_some_and(|v| {
                            v.operation == p.operation() && v.statement == p.statement()
                        })
                }
            };
            if !matches {
                return Err(DurableError::Corrupt);
            }
        }
        Ok(())
    }
    pub(super) fn encode(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.floor.to_be_bytes());
        match &self.closed {
            None => out.push(0),
            Some(c) => {
                out.push(1);
                out.extend_from_slice(c.operation.as_bytes());
                out.extend_from_slice(&c.statement);
                out.extend_from_slice(&c.target.version().to_be_bytes());
                out.extend_from_slice(&c.target.digest());
            }
        }
        match self.coordination {
            None => out.push(0),
            Some(c) => {
                match c.intent {
                    WitnessedCredentialIntent::Proposal(p) => {
                        out.push(if p.policy_renewal().is_some() {
                            5
                        } else if p.policy_continuation().is_some() {
                            3
                        } else {
                            1
                        });
                        out.extend_from_slice(&p.to_bytes());
                    }
                    WitnessedCredentialIntent::Cancellation(c) => {
                        out.push(if c.policy_renewal().is_some() {
                            6
                        } else if c.policy_continuation().is_some() {
                            4
                        } else {
                            2
                        });
                        out.extend_from_slice(&c.to_bytes());
                    }
                }
                out.push(c.terminal.map_or(0, Terminal::byte));
            }
        }
    }
    pub(super) fn decode(
        d: &mut Decoder<'_>,
        cancellation: bool,
        policy_coordination: bool,
        policy_cancellation: bool,
        independent_policy: bool,
    ) -> Result<Self, DurableError> {
        let floor = d.u64()?;
        let closed = match d.array::<1>()? {
            [0] => None,
            [1] => Some(ClosedRenewal {
                operation: CredentialRenewalId::from_trusted_state(d.array()?)?,
                statement: d.array()?,
                target: RosterCheckpoint::from_trusted_state(d.u64()?, d.array()?)?,
            }),
            _ => return Err(DurableError::Corrupt),
        };
        let coordination = match d.array::<1>()? {
            [0] => None,
            [kind @ 1..=6]
                if kind == 1
                    || (kind == 2 && cancellation)
                    || (kind == 3 && policy_coordination && !policy_cancellation)
                    || (kind == 4 && policy_cancellation)
                    || ((kind == 5 || kind == 6) && independent_policy) =>
            {
                Some(Coordination {
                    intent: if kind == 1 || kind == 3 || kind == 5 {
                        WitnessedCredentialIntent::Proposal(Proposal::from_trusted_state(
                            d.take(if kind == 1 { 296 } else { 329 })?,
                        )?)
                    } else {
                        WitnessedCredentialIntent::Cancellation(
                            crate::AnchorCredentialRenewalCancellation::from_trusted_state(
                                d.take(if kind == 2 { 248 } else { 281 })?,
                            )?,
                        )
                    },
                    terminal: match d.array::<1>()? {
                        [0] => None,
                        [1] => Some(Terminal::Applied),
                        [2] => Some(Terminal::Closed),
                        _ => return Err(DurableError::Corrupt),
                    },
                })
            }
            _ => return Err(DurableError::Corrupt),
        };
        if coordination.is_some_and(|c| match c.intent {
            WitnessedCredentialIntent::Proposal(p) => {
                p.policy_renewal().is_some() && !independent_policy
            }
            WitnessedCredentialIntent::Cancellation(c) => {
                c.policy_renewal().is_some() && !independent_policy
            }
        }) {
            return Err(DurableError::Corrupt);
        }
        if cancellation
            != coordination
                .is_some_and(|c| matches!(c.intent, WitnessedCredentialIntent::Cancellation(_)))
        {
            return Err(DurableError::Corrupt);
        }
        Ok(Self {
            floor,
            closed,
            coordination,
        })
    }
}

#[cfg_attr(
    not(all(target_arch = "wasm32", target_os = "unknown")),
    maybe_async::must_be_sync
)]
impl DeviceEnrollment {
    fn image_for_witnessed_credential(&mut self) -> Result<Image, DurableError> {
        let image = self.image()?;
        image.require_credential_policy_retired()?;
        Ok(image)
    }
    /// Build a historical renewal carrier from the original controlled signer.
    /// This does not admit the credential or permit traffic after expiry. Every
    /// renewal operation separately binds the original policy, journal and intent.
    pub async fn credential_renewal_anchor_client(
        &mut self,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
        pin: AnchorPin,
        transport: Box<dyn AnchorTransport>,
        timeout: Duration,
    ) -> Result<AnchorClient, DurableError> {
        let result = self
            .credential_renewal_anchor_client_attempt(policy.as_ref(), now, pin, transport, timeout)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn credential_renewal_anchor_client_attempt(
        &mut self,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        pin: AnchorPin,
        transport: Box<dyn AnchorTransport>,
        timeout: Duration,
    ) -> Result<AnchorClient, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        self.check_witness_client(None)?;
        let original = self.original_device(&image, now).await?;
        let Phase::Accepted {
            admission,
            stage: AdmissionPhase::Active | AdmissionPhase::Refreshing { .. },
            ..
        } = &image.phase
        else {
            return Err(DurableError::Suspended);
        };
        if admission.policy != policy.checkpoint().digest()
            || policy.anchor_requirement().binding() != Some(pin.binding())
        {
            return Err(DurableError::Conflict);
        }
        policy.check_external_signer(pin.public_key())?;
        if pin.public_key().shares_component(&original.authority_key) {
            return Err(Error::Scope.into());
        }
        Ok(AnchorClient::new(
            pin,
            self.signer(image.identity, false).await?,
            transport,
            timeout,
        )?)
    }
    async fn witness_scope(
        &self,
        image: &Image,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
    ) -> Result<(VerifiedDevice, JournalIdentity), DurableError> {
        let policy = policy.as_ref();
        let original = self.original_device(image, now).await?;
        self.witness_scope_for_original(image, policy, now, original)
    }
    fn witness_cancellation_scope(
        &self,
        image: &Image,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
    ) -> Result<(VerifiedDevice, JournalIdentity), DurableError> {
        let original = self.original_device_metadata_at(image, now)?;
        self.witness_scope_for_original(image, policy, now, original)
    }
    fn witness_scope_for_original(
        &self,
        image: &Image,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        original: VerifiedDevice,
    ) -> Result<(VerifiedDevice, JournalIdentity), DurableError> {
        let Phase::Accepted {
            admission,
            stage: AdmissionPhase::Active,
            ..
        } = &image.phase
        else {
            return Err(DurableError::Suspended);
        };
        if admission.policy != policy.checkpoint().digest()
            || policy.anchor_requirement().binding().is_none()
            || !image.renewal.as_ref().is_some_and(LocalRenewal::witnessed)
        {
            return Err(DurableError::Conflict);
        }
        let renewal = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        let admitted = self.historical_device(
            &admission.certificate,
            &admission.roster,
            admission.checkpoint,
            now,
        )?;
        let completed = renewal.completed.as_ref();
        let adopted = renewal
            .adopted_policy
            .as_deref()
            .map(|bytes| self.retained_policy(bytes))
            .transpose()?;
        if let Some(t) = &adopted {
            Self::check_policy_scope(t, &original, admission)?;
        }
        if admitted.credential_digest()
            != completed.map_or(original.credential_digest(), |c| c.credential)
            || admitted.account_id() != original.account_id()
            || admitted.device_id() != original.device_id()
            || admitted.generation() != original.generation()
            || admitted.key != original.key
            || admitted.description.family != original.description.family
            || completed.is_some_and(|c| {
                c.owner != crate::bootstrap::storage_owner(&original)
                    || c.policy != admission.policy
                    || admission.checkpoint.version() < c.target.version()
                    || (admission.checkpoint.version() == c.target.version()
                        && admission.checkpoint != c.target)
            })
        {
            return Err(DurableError::Conflict);
        }
        if let Some(coord) = image
            .renewal
            .as_ref()
            .and_then(|r| r.witness.as_ref())
            .and_then(|w| w.coordination)
        {
            if coord.intent.subject()
                != AnchorSubject::for_device(admission.journal, &original, policy)?
                || Some(coord.intent.witness_binding()) != policy.anchor_requirement().binding()
            {
                return Err(DurableError::Conflict);
            }
            if coord.terminal == Some(Terminal::Applied) {
                let p = coord.intent.proposal()?;
                if p.policy_continuation() != adopted.as_ref().map(|t| t.statement_digest())
                    || p.policy_renewal()
                        != self
                            .completed_policy_approval(image)?
                            .map(|p| p.statement_digest())
                {
                    return Err(DurableError::Conflict);
                }
            }
        }
        Ok((original, admission.journal))
    }
    #[cfg(all(test, unix))]
    pub(in crate::enrollment) fn persisted_witness_terminal(
        &mut self,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
        proposal: Proposal,
    ) -> Result<PersistedRenewalTerminal, DurableError> {
        self.persisted_witness_intent_terminal(
            policy.as_ref(),
            now,
            WitnessedCredentialIntent::Proposal(proposal),
        )
    }
    pub(in crate::enrollment) async fn persisted_witness_intent_terminal(
        &mut self,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        proposal: WitnessedCredentialIntent,
    ) -> Result<PersistedRenewalTerminal, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        self.witness_scope(&image, policy, now).await?;
        let coord = image
            .renewal
            .as_ref()
            .and_then(|r| r.witness.as_ref())
            .and_then(|w| w.coordination)
            .ok_or(DurableError::Conflict)?;
        if coord.intent != proposal {
            return Err(DurableError::Conflict);
        }
        Ok(PersistedRenewalTerminal {
            intent: proposal,
            independent_policy: self
                .completed_policy_approval(&image)?
                .map(|p| p.statement_digest()),
            state: coord.terminal.ok_or(DurableError::Conflict)?.state(),
            completed: image.renewal.as_ref().and_then(|r| r.completed.clone()),
            adopted_policy: image
                .renewal
                .as_ref()
                .and_then(|r| r.adopted_policy.as_deref())
                .map(|bytes| self.retained_policy(bytes).map(|t| t.statement_digest()))
                .transpose()?,
        })
    }
    pub(in crate::enrollment) async fn witness_lease(
        &self,
        original: &VerifiedDevice,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        id: JournalIdentity,
    ) -> Result<DeviceInstallation, DurableError> {
        let policy = policy.as_ref();
        let mut owner = DeviceInstallation::open_bound_with_storage(
            self.storage.clone(),
            self.paths.installation.clone(),
            &self.key().await?,
            original,
            policy,
        )
        .await?;
        if owner.identity()? != id || owner.status()? != crate::InstallationStatus::Active {
            return Err(DurableError::Conflict);
        }
        Ok(owner)
    }
    fn pending_grant(
        &self,
        image: &Image,
        original: &VerifiedDevice,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
    ) -> Result<VerifiedCredentialRenewal, DurableError> {
        let policy = policy.as_ref();
        let pending = image
            .renewal
            .as_ref()
            .and_then(|r| r.pending.as_ref())
            .ok_or(DurableError::Conflict)?;
        let grant = VerifiedCredentialRenewal::from_journal(&pending.wire, original.roster())?;
        let continuation = pending
            .continuation
            .as_deref()
            .map(|bytes| self.retained_policy(bytes))
            .transpose()?;
        if let Some(t) = &continuation {
            let Phase::Accepted { admission, .. } = &image.phase else {
                return Err(DurableError::Corrupt);
            };
            Self::check_policy_scope(t, original, admission)?;
        }
        let companions = self.account_grants(image, &grant, original)?;
        let target = LocalRenewalTarget {
            companions: &companions,
            policy_renewal: None,
            grant: &grant,
            continuation: continuation.as_ref(),
        };
        if grant.operation() != pending.operation
            || target.receipt()?.statement != pending.statement
            || grant.original_storage_owner() != crate::bootstrap::storage_owner(original)
            || grant.policy_digest() != policy.checkpoint().digest()
        {
            return Err(DurableError::Conflict);
        }
        grant.resolve_established(original, policy.checkpoint().digest())?;
        Ok(grant)
    }
    fn check_witnessed_pending(
        &self,
        image: &Image,
        original: &VerifiedDevice,
        grant: &VerifiedCredentialRenewal,
        intent: WitnessedCredentialIntent,
    ) -> Result<(), DurableError> {
        let renewal = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        let pending = renewal.pending.as_ref().ok_or(DurableError::Conflict)?;
        if intent.operation() != grant.operation()
            || intent.operation() != pending.operation
            || intent.statement() != pending.statement
        {
            return Err(DurableError::Conflict);
        }
        let policy = pending
            .continuation
            .as_deref()
            .or(renewal.adopted_policy.as_deref())
            .map(|bytes| self.retained_policy(bytes))
            .transpose()?;
        if let Some(t) = &policy {
            let Phase::Accepted { admission, .. } = &image.phase else {
                return Err(DurableError::Corrupt);
            };
            Self::check_policy_scope(t, original, admission)?;
        }
        let independent = self
            .completed_policy_approval(image)?
            .map(|p| p.statement_digest());
        match intent {
            WitnessedCredentialIntent::Proposal(p)
                if p.statement() == grant.statement_digest()
                    && p.policy_continuation() == policy.as_ref().map(|t| t.statement_digest())
                    && p.policy_renewal() == independent
                    && p.adopts_policy() == pending.continuation.is_some() =>
            {
                Ok(())
            }
            WitnessedCredentialIntent::Cancellation(c)
                if c.statement() == grant.statement_digest()
                    && c.policy_continuation() == policy.as_ref().map(|t| t.statement_digest())
                    && c.policy_renewal() == independent
                    && c.adopts_policy() == pending.continuation.is_some() =>
            {
                Ok(())
            }
            _ => Err(DurableError::Conflict),
        }
    }
    /// Recover an existing exact journal proposal into this original enrollment.
    /// This never creates/reseals a target or sends a witness command. `None`
    /// means no retained local proposal, never witness NoCommit. It remains usable
    /// with independently verified historical policy after policy/runtime expiry.
    pub async fn recover_witnessed_credential_renewal_preparation(
        &mut self,
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
    ) -> Result<Option<Proposal>, DurableError> {
        let result = self
            .recover_witnessed_preparation(policy.as_ref(), now, None)
            .await
            .and_then(|intent| intent.map(WitnessedCredentialIntent::proposal).transpose());
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn recover_witnessed_preparation(
        &mut self,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        client: Option<&AnchorClient>,
    ) -> Result<Option<WitnessedCredentialIntent>, DurableError> {
        let result = self
            .recover_witnessed_preparation_attempt(policy, now, client)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn recover_witnessed_preparation_attempt(
        &mut self,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        client: Option<&AnchorClient>,
    ) -> Result<Option<WitnessedCredentialIntent>, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        let (original, id) = self.witness_scope(&image, policy, now).await?;
        let renewal = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        let coordination = renewal
            .witness
            .as_ref()
            .ok_or(DurableError::Corrupt)?
            .coordination;
        if let Some(coord) = coordination.filter(|c| c.terminal.is_some()) {
            return Ok(Some(coord.intent)); // Historical retained metadata only.
        }
        if renewal.pending.is_none() {
            return Ok(None);
        }
        let grant = self.pending_grant(&image, &original, policy)?;
        let _lease = self.witness_lease(&original, policy, id).await?;
        let proposal = self
            .inspect_original_credential_intent_using(&original, policy, id, client)
            .await?;
        let Some(proposal) = proposal else {
            if coordination.is_some() {
                return Err(DurableError::Conflict);
            }
            return Ok(None);
        };
        self.check_witnessed_pending(&image, &original, &grant, proposal)?;
        Ok(Some(
            self.retain_witnessed_preparation(image, policy, now, proposal)
                .await?,
        ))
    }

    async fn retain_witnessed_preparation(
        &mut self,
        mut image: Image,
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        proposal: WitnessedCredentialIntent,
    ) -> Result<WitnessedCredentialIntent, DurableError> {
        let witness = image
            .renewal
            .as_mut()
            .and_then(|r| r.witness.as_mut())
            .ok_or(DurableError::Corrupt)?;
        match witness.coordination {
            Some(c) if c.intent == proposal && c.terminal.is_none() => {}
            None => {
                witness.coordination = Some(Coordination {
                    intent: proposal,
                    terminal: None,
                });
                #[cfg(all(test, unix))]
                if matches!(proposal, WitnessedCredentialIntent::Cancellation(_)) {
                    super::super::tests::witness_selection_boundary("cancellation-parent", false);
                }
                self.save(&image)?;
                #[cfg(all(test, unix))]
                if matches!(proposal, WitnessedCredentialIntent::Cancellation(_)) {
                    super::super::tests::witness_selection_boundary("cancellation-parent", true);
                }
            }
            _ => return Err(DurableError::Conflict),
        }
        let readback = self.image_for_witnessed_credential()?;
        if matches!(proposal, WitnessedCredentialIntent::Cancellation(_)) {
            self.witness_cancellation_scope(&readback, policy, now)?;
        } else {
            self.witness_scope(&readback, policy, now).await?;
        }
        let saved = readback
            .renewal
            .as_ref()
            .and_then(|r| r.witness.as_ref())
            .and_then(|w| w.coordination)
            .ok_or(DurableError::Corrupt)?;
        if saved.intent != proposal || saved.terminal.is_some() {
            return Err(DurableError::Conflict);
        }
        Ok(proposal)
    }
    /// Prepare the original staged renewal once and durably retain its exact
    /// proposal. The returned public proposal needs independent witness approval;
    /// it is not itself permission to commit. Unknown results preserve both files.
    pub async fn prepare_witnessed_credential_renewal(
        &mut self,
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: AnchorClient,
    ) -> Result<Proposal, DurableError> {
        self.prepare_witnessed_policy_continuation(policy.historical(), policy, now, client)
            .await
    }
    /// Seal the original staged G/T target, or G retaining an adopted T or independent P.
    /// An independent P requires its original enrollment completion and a distinct
    /// proposal binding; it is never re-adopted as T. P0 authenticates the installation,
    /// and the current policy admits the new credential. This
    /// returns only an exact proposal for independent witness approval, no owner.
    pub async fn prepare_witnessed_policy_continuation(
        &mut self,
        original_policy: &crate::HistoricalSessionPolicy,
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: AnchorClient,
    ) -> Result<Proposal, DurableError> {
        let result = self
            .prepare_witnessed_policy_continuation_attempt(original_policy, policy, now, client)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn prepare_witnessed_policy_continuation_attempt(
        &mut self,
        original_policy: &crate::HistoricalSessionPolicy,
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: AnchorClient,
    ) -> Result<Proposal, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        let (original, id) = self.witness_scope(&image, original_policy, now).await?;
        let grant = self.pending_grant(&image, &original, original_policy)?;
        let companions = self.account_grants(&image, &grant, &original)?;
        let renewal = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        let continuation = renewal
            .pending
            .as_ref()
            .and_then(|p| p.continuation.as_deref())
            .map(|bytes| self.retained_policy(bytes))
            .transpose()?;
        client.check_device(&original)?;
        if Some(client.pin().binding()) != policy.anchor_requirement().binding()
            || policy.anchor_requirement() != original_policy.anchor_requirement()
        {
            return Err(DurableError::Conflict);
        }
        let lease = self.witness_lease(&original, original_policy, id).await?;
        let proposal = match self
            .inspect_original_credential_intent_using(&original, original_policy, id, Some(&client))
            .await?
            .map(WitnessedCredentialIntent::proposal)
            .transpose()?
        {
            Some(p) => p,
            None => {
                if image
                    .renewal
                    .as_ref()
                    .and_then(|r| r.witness.as_ref())
                    .is_some_and(|w| w.coordination.is_some())
                {
                    return Err(DurableError::Conflict);
                }
                let mut journal = self
                    .open_original_journal(&original, original_policy, id, client)
                    .await?;
                let authority =
                    RetainedInstallationAuthority::active_installation(&original, original_policy);
                let independent = self.completed_policy_approval(&image)?;
                if let Some(completion) = if independent.is_some() {
                    self.policy_enrollment_completion(&image, original_policy)?
                } else {
                    None
                } {
                    journal
                        .retain_enrollment_policy_completion(completion)
                        .await?;
                }
                journal
                    .prepare_enrollment_renewal(
                        &crate::installation::PolicyScope {
                            authority: &authority,
                            original_policy,
                            original_device: &original,
                        },
                        &LocalRenewalTarget {
                            companions: &companions,
                            policy_renewal: independent.as_ref().map(|p| (p, &original)),
                            grant: &grant,
                            continuation: continuation.as_ref(),
                        },
                        policy,
                        now,
                        image.renewal.as_ref().and_then(|r| r.completed.as_ref()),
                    )
                    .await?
            }
        };
        self.check_witnessed_pending(
            &image,
            &original,
            &grant,
            WitnessedCredentialIntent::Proposal(proposal),
        )?;
        let proposal = self
            .retain_witnessed_preparation(
                image,
                original_policy,
                now,
                WitnessedCredentialIntent::Proposal(proposal),
            )
            .await?
            .proposal()?;
        drop(lease);
        Ok(proposal)
    }

    /// Observe and finish only an original prepared renewal. Never sends Commit
    /// or Close. Exact terminal durability precedes ACK and local intent removal.
    /// Prepared/Unavailable remain Pending unless an exact terminal was retained.
    pub async fn reconcile_witnessed_credential_renewal(
        &mut self,
        operation: CredentialRenewalId,
        statement: [u8; 32],
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
        client: &mut AnchorClient,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let policy = policy.as_ref();
        self.run_witnessed_renewal(
            operation,
            statement,
            policy,
            now,
            client,
            RenewalAction::Observe,
        )
        .await
    }
    /// Explicitly commit a root-approved original proposal while its successor is
    /// live, then complete cross-store recovery. Unknown replies return no owner.
    pub async fn commit_witnessed_credential_renewal(
        &mut self,
        operation: CredentialRenewalId,
        statement: [u8; 32],
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: &mut AnchorClient,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        self.run_witnessed_renewal(
            operation,
            statement,
            policy.historical(),
            now,
            client,
            RenewalAction::Commit(policy),
        )
        .await
    }
    /// Commit the exact staged policy transaction under independently live P1.
    /// Historical P0 remains the installation identity. Unknown replies require
    /// original-operation reconciliation; successful completion releases no owner.
    pub async fn commit_witnessed_policy_continuation(
        &mut self,
        proposal: &Proposal,
        original_policy: &crate::HistoricalSessionPolicy,
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: &mut AnchorClient,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let result = self
            .commit_witnessed_policy_continuation_attempt(
                proposal,
                original_policy,
                policy,
                now,
                client,
            )
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn commit_witnessed_policy_continuation_attempt(
        &mut self,
        proposal: &Proposal,
        original_policy: &crate::HistoricalSessionPolicy,
        policy: &VerifiedSessionPolicy,
        now: u64,
        client: &mut AnchorClient,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        let coord = image
            .renewal
            .as_ref()
            .and_then(|r| r.witness.as_ref())
            .and_then(|w| w.coordination)
            .ok_or(DurableError::Conflict)?;
        if coord.intent != WitnessedCredentialIntent::Proposal(*proposal) {
            return Err(DurableError::Conflict);
        }
        self.run_witnessed_renewal(
            proposal.operation(),
            proposal.transaction_statement(),
            original_policy,
            now,
            client,
            RenewalAction::Commit(policy),
        )
        .await
    }

    /// Explicitly close an independently prepared original proposal. A competing
    /// successful Commit remains Committed; early Closed does not expire C0/C1.
    pub async fn close_witnessed_credential_renewal(
        &mut self,
        operation: CredentialRenewalId,
        statement: [u8; 32],
        policy: &impl AsRef<crate::HistoricalSessionPolicy>,
        now: u64,
        client: &mut AnchorClient,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let policy = policy.as_ref();
        self.run_witnessed_renewal(
            operation,
            statement,
            policy,
            now,
            client,
            RenewalAction::Close,
        )
        .await
    }
    async fn run_witnessed_renewal(
        &mut self,
        operation: CredentialRenewalId,
        statement: [u8; 32],
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        client: &mut AnchorClient,
        action: RenewalAction<'_>,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let result = self
            .coordinate_witnessed_renewal(operation, statement, policy, now, client, action)
            .await;
        if result.is_err() {
            self.close();
        }
        result
    }
    async fn coordinate_witnessed_renewal(
        &mut self,
        operation: CredentialRenewalId,
        statement: [u8; 32],
        policy: &crate::HistoricalSessionPolicy,
        now: u64,
        client: &mut AnchorClient,
        action: RenewalAction<'_>,
    ) -> Result<CredentialRenewalStatus, DurableError> {
        let mut image = self.image_for_witnessed_credential()?;
        let (original, id) = self.witness_scope(&image, policy, now).await?;
        client.check_device(&original)?;
        if Some(client.pin().binding()) != policy.anchor_requirement().binding() {
            return Err(DurableError::Conflict);
        }
        let prepared = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        if prepared
            .witness
            .as_ref()
            .ok_or(DurableError::Corrupt)?
            .coordination
            .is_none()
        {
            if let Some(pending) = &prepared.pending {
                if pending.operation != operation || pending.statement != statement {
                    return Err(DurableError::Conflict);
                }
                self.recover_witnessed_preparation(policy, now, Some(client))
                    .await?;
                image = self.image_for_witnessed_credential()?;
            }
        }
        let renewal = image.renewal.as_ref().ok_or(DurableError::Corrupt)?;
        let witness = renewal.witness.as_ref().ok_or(DurableError::Corrupt)?;
        let Some(coord) = witness.coordination else {
            if renewal
                .pending
                .as_ref()
                .is_some_and(|p| p.operation == operation && p.statement == statement)
            {
                return if matches!(action, RenewalAction::Observe) {
                    renewal.status()
                } else {
                    Err(DurableError::Suspended)
                };
            }
            if let Some(c) = renewal
                .completed
                .as_ref()
                .filter(|c| c.operation == operation && c.statement == statement)
            {
                return Ok(CredentialRenewalStatus::Committed {
                    operation,
                    statement,
                    target: c.target,
                });
            }
            if let Some(c) = witness
                .closed
                .as_ref()
                .filter(|c| c.operation == operation && c.statement == statement)
            {
                return Ok(c.status());
            }
            return Err(DurableError::Conflict);
        };
        let proposal = coord.intent;
        if proposal.operation() != operation || proposal.statement() != statement {
            return Err(DurableError::Conflict);
        }
        let _lease = self.witness_lease(&original, policy, id).await?;
        self.check_original_witness_selection(&original, id, client)
            .await?;
        if coord.terminal.is_none() {
            let grant = self.pending_grant(&image, &original, policy)?;
            self.check_witnessed_pending(&image, &original, &grant, proposal)?;
            let continuation = renewal
                .pending
                .as_ref()
                .and_then(|p| p.continuation.as_deref())
                .map(|bytes| self.retained_policy(bytes))
                .transpose()?;
            let companions = self.account_grants(&image, &grant, &original)?;
            let target = LocalRenewalTarget {
                companions: &companions,
                policy_renewal: None,
                grant: &grant,
                continuation: continuation.as_ref(),
            };
            let receipt = target.receipt()?;
            // Verify exact retained intent before dispatching even an explicit
            // command. A substituted local proposal cannot cause remote work.
            if self
                .inspect_original_credential_intent_using(&original, policy, id, Some(client))
                .await?
                != Some(proposal)
            {
                return Err(DurableError::Conflict);
            }
            let command = match action {
                RenewalAction::Observe => None,
                RenewalAction::Commit(current) => {
                    self.authorize_journal_commit(&original, id, client).await?;
                    let adopted = renewal
                        .adopted_policy
                        .as_deref()
                        .map(|bytes| self.retained_policy(bytes))
                        .transpose()?;
                    if let Some(t) = continuation.as_ref().or(adopted.as_ref()) {
                        t.check_context_policy(policy, current)?;
                    } else if let Some(p) = self.completed_policy_approval(&image)? {
                        p.check_context_policy(policy, current)?;
                        p.check_renewed_identity(&original, &grant)?;
                    } else if policy.checkpoint() != current.checkpoint() {
                        return Err(DurableError::Conflict);
                    }
                    admit(grant.successor_device(), current, now)?;
                    for peer in &companions {
                        admit(peer.successor_device(), current, now)?;
                    }
                    Some(AnchorOperation::commit_credential_renewal(
                        &proposal.proposal()?,
                    ))
                }
                RenewalAction::Close => match proposal {
                    WitnessedCredentialIntent::Proposal(p) => {
                        Some(AnchorOperation::close_credential_renewal(&p))
                    }
                    WitnessedCredentialIntent::Cancellation(_) => None,
                },
            };
            if let Some(command) = command {
                proposal.interpret(&client.exchange(proposal.subject(), command).await?)?;
            }
            let observed = self
                .recover_original_credential_intent(&original, policy, id, proposal, client)
                .await?;
            #[cfg(all(test, unix))]
            super::super::tests::renewal::boundary("witness-observed");
            let terminal = match observed {
                State::Applied => Terminal::Applied,
                State::Closed => Terminal::Closed,
                State::Prepared | State::Unavailable => return renewal.status(),
                State::Acknowledged => return Err(Error::State.into()),
            };
            let renewal = image.renewal.as_mut().ok_or(DurableError::Corrupt)?;
            let witness = renewal.witness.as_mut().ok_or(DurableError::Corrupt)?;
            witness.floor = grant.successor_device().roster().checkpoint().version();
            witness.coordination = Some(Coordination {
                intent: proposal,
                terminal: Some(terminal),
            });
            match terminal {
                Terminal::Applied => {
                    witness.closed = None;
                    image = self.persist_renewal_completion(image, &grant, receipt)?;
                }
                Terminal::Closed => {
                    witness.closed = Some(ClosedRenewal {
                        operation,
                        statement,
                        target: grant.successor_device().roster().checkpoint(),
                    });
                    renewal.pending = None;
                    self.save(&image)?;
                    image = self.image_for_witnessed_credential()?;
                }
            }
        }
        self.witness_scope(&image, policy, now).await?;
        let durable = image
            .renewal
            .as_ref()
            .and_then(|r| r.witness.as_ref())
            .and_then(|w| w.coordination)
            .ok_or(DurableError::Corrupt)?;
        if durable.intent != proposal {
            return Err(DurableError::Conflict);
        }
        durable.terminal.ok_or(DurableError::Corrupt)?;
        #[cfg(all(test, unix))]
        super::super::tests::renewal::boundary("witness-terminal");
        // This crate-private entry accepts only the authenticated durable record,
        // never caller-constructed terminal metadata. It checks local bytes before
        // sending ACK and deletes only the exact intent, retaining the image.
        let terminal = self
            .persisted_witness_intent_terminal(policy, now, proposal)
            .await?;
        self.retire_original_credential_intent(&original, policy, id, &terminal, client)
            .await?;
        #[cfg(all(test, unix))]
        super::super::tests::renewal::boundary("witness-retired");
        let witness = image
            .renewal
            .as_mut()
            .and_then(|r| r.witness.as_mut())
            .ok_or(DurableError::Corrupt)?;
        witness.coordination = None;
        self.save(&image)?;
        #[cfg(all(test, unix))]
        super::super::tests::renewal::boundary("witness-complete");
        self.credential_renewal_status()
    }
    /// Restore the original controlled owner after an exact policy transaction
    /// has completed and its witness slot has been acknowledged. This never
    /// commits a staged target implicitly. Historical P0 binds the installation;
    /// independently live P1 and fresh exact G/T admission gate owner release.
    /// Established sessions can then reopen through the owning service.
    pub async fn activate_witnessed_policy_continuation(
        mut self,
        original_policy: &crate::HistoricalSessionPolicy,
        policy: &VerifiedSessionPolicy,
        now: u64,
        anchor: AnchorClient,
    ) -> Result<EnrolledDevice, DurableError> {
        let image = self.image_for_witnessed_credential()?;
        let (original, id) = self.witness_scope(&image, original_policy, now).await?;
        let renewal = image.renewal.as_ref().ok_or(DurableError::Conflict)?;
        if renewal.pending.is_some()
            || renewal
                .witness
                .as_ref()
                .is_none_or(|w| w.coordination.is_some())
        {
            return Err(DurableError::Suspended);
        }
        let completed = renewal.completed.as_ref().ok_or(DurableError::Conflict)?;
        let adopted = self.retained_policy(
            renewal
                .adopted_policy
                .as_deref()
                .ok_or(DurableError::Conflict)?,
        )?;
        adopted.check_context_policy(original_policy, policy)?;
        let mut service = self
            .reconcile_installation(&original, original_policy, Some(anchor))
            .await?;
        let journal = service.stores()?.0;
        if journal.identity()? != id {
            return Err(DurableError::Conflict);
        }
        let authority =
            RetainedInstallationAuthority::active_installation(&original, original_policy);
        journal
            .check_witnessed_policy_completion(&authority, &adopted, completed)
            .await?;
        self.release_continued_owner(image, service, original_policy, policy, now)
            .await
    }
    pub(super) async fn activate_witnessed(
        mut self,
        mut image: Image,
        policy: &VerifiedSessionPolicy,
        now: u64,
        anchor: Option<AnchorClient>,
    ) -> Result<EnrolledDevice, DurableError> {
        let original = self.original_device(&image, now).await?;
        let current = self.admitted_renewed(&image, policy, now).await?;
        let authority = RetainedInstallationAuthority::active_installation(&original, policy);
        let mut service = self
            .reconcile_installation(&original, policy, anchor)
            .await?;
        let journal = service.stores()?.0;
        let Phase::Accepted {
            admission, stage, ..
        } = &mut image.phase
        else {
            return Err(DurableError::Corrupt);
        };
        if journal.identity()? != admission.journal {
            return Err(DurableError::Conflict);
        }
        if let AdmissionPhase::Refreshing { previous } = *stage {
            let checkpoint = journal.roster_checkpoint(current.account_id()).await?;
            if checkpoint != previous && checkpoint != admission.checkpoint {
                return Err(DurableError::Conflict);
            }
            if journal.install_roster(current.roster(), now).await? != admission.checkpoint {
                return Err(DurableError::Conflict);
            }
            *stage = AdmissionPhase::Active;
            self.save(&image)?;
        }
        if image
            .renewal
            .as_ref()
            .is_some_and(|r| r.completed.is_some())
        {
            journal
                .check_renewed_local_device(&authority, &current, policy, now)
                .await?;
        }
        journal
            .check_enrollment_authority(&current, policy, now)
            .await?;
        let signer = self.signer(image.identity, false).await?;
        admit(&current, policy, now)?;
        Ok(EnrolledDevice {
            active: Some(Box::new(EnrolledOwners {
                enrollment: self,
                service,
                signer,
                device: current,
            })),
        })
    }
}
#[derive(Clone, Copy)]
enum RenewalAction<'a> {
    Observe,
    Commit(&'a VerifiedSessionPolicy),
    Close,
}
